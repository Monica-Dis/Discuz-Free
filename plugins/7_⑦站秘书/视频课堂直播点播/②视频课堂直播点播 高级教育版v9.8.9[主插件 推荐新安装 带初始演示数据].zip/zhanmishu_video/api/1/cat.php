<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$video = zhanmishu_video::getInstance();
$videoconfig = $video->config;


$cat = $video->get_cat_tree();
$sample_cat_list =  $video->cat_tree_to_sample();
$catpid = $_GET['cat_id'] ? $video->get_pidbycat_id($_GET['cat_id'] + 0) : '0';
$catson =  $video->get_cat_tree($catpid ? $catpid : $_GET['cat_id'] + 0);

if ($mod == 'index') {
    $rewrite_cat = $_GET['cat_id'] ? $_GET['cat_id'] : '0';
    $rewrite_vip = $_GET['groupselect'] ? $_GET['groupselect'] : '0';
    $rewrite_diff = $_GET['diff'] ? $_GET['diff'] : '0';
    $rewrite_order = $_GET['order'] ? $_GET['order'] : '0';
}

$videoBaseUrl = 'plugin.php?id=zhanmishu_video:video';
$pdata = $_GET;
unset($pdata['page']);
$mpurl = 'plugin.php?'.urldecode(http_build_query($pdata));
$cdata = $_GET;
unset($cdata['cat_id']);
unset($cdata['page']);

$caturl = 'plugin.php?'.urldecode(http_build_query($cdata));
$ddata = $_GET;
unset($ddata['diff']);
$durl = 'plugin.php?'.urldecode(http_build_query($ddata));
$odata = $_GET;
unset($odata['order']);
$ourl = 'plugin.php?'.urldecode(http_build_query($odata));
$gdata = $_GET;
unset($gdata['groupselect']);
unset($gdata['page']);
$gurl = 'plugin.php?'.urldecode(http_build_query($gdata));


$field = array();
$field['isdel'] = '0';
$field['issell'] = '1';
if ($_GET['cat_id']) {
    $this_cat_son = $video->get_cat_tree($_GET['cat_id'] + 0);
    if (empty($this_cat_son['son'])) {
        $field['cat_id'] = $_GET['cat_id'] + 0;
    }else{
        $cat_ids = array();
        $cat_ids[$_GET['cat_id'] + 0] = $_GET['cat_id'] + 0;
        foreach ($this_cat_son['son'] as $key => $value) {
            $cat_ids[$value['cat_id']] = $value['cat_id'];
        }

        $ids .= ' ('.implode(',', $cat_ids).') ';

        $field['cat_id'] = array('key'=>'cat_id','relation'=>'in', 'value'=> $ids);
    }
    
    $catinfo = $video->get_cat_by_cat_id($_GET['cat_id'] + 0);
}
if ($_GET['diff']) {
    $field['diff'] = $_GET['diff'] + 0;
}
// if ($_GET['groupselect']) {
//     $field['course_group'] = array('value'=>'#'.daddslashes($_GET['groupselect']).'#','type'=>'like');
// }
if ($_GET['groupselect']) {
    $field['course_group'] = array(
        'relation'=> 'sql',
        'sql'=> 'CONCAT(\',\',course_group,\',\') LIKE \'%'.daddslashes($_GET['groupselect']).'%\''
    );
}

$num = $video->get_type_course_num($field); 
$perpage=20;
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
$pages= ceil($num / $perpage);
$start = $num - ($num - $perpage*$curpage+$perpage);


if ($_GET['order'] == 'new') {
    $sort = array('dateline'=>'desc');
}else if($_GET['order'] == 'hot'){
    $sort = array('views'=>'desc');
}else {
    $sort = array('course_weight'=>'desc','cid'=>'desc');
}

$list = $video->get_type_course($start,$perpage,$sort,'',$field);



if (defined('IN_MOBILE')) {
    $cate = array_chunk($video->get_cat_by_level('1',array('cat_touchorder'=>'asc')),8);
}else{
    dheader('location:'.$_G['siteurl']);
}

$groupicons = $video->get_group_icons();

$navtitle = $catinfo['cat_name'] ? $catinfo['cat_name'].' - '.$videoconfig['index_title'] : $videoconfig['index_title'];
$metakeywords = $catinfo['cat_name'] ? $catinfo['cat_name'].','.$videoconfig['metakeywords']:$videoconfig['metakeywords'];
$metadescription = $catinfo['cat_name'] ? $catinfo['cat_name'].','.$videoconfig['metadescription']:$videoconfig['metadescription'];


if ($_GET['dtype']) {

    $list_column = array('cat_id','cid','course_content','course_group','course_img','course_intro','course_length','course_name','course_price','course_thumbimg','course_type','course_weight','dateline','diff','isdel','issell','learns
','progress','replies','selltimes','uid','username','views','cat_name');
    foreach ($list as $key => $value) {
        if ($value['uid']) {
            $user = getuserbyuid($value['uid']);
            $list[$key]['username'] = $user['username'];
        }
        $list[$key]['cat_name'] = $sample_cat_list[$value['cat_id']];
        foreach ($value as $k => $value) {
            if (!in_array($k,$list_column)) {
                unset($list[$key][$k]);
            }
        }
    }


    $swiper = $video-> get_touch_swiper();
    $best = $video->get_touch_best();
    $outapi = array(
        'msg'=>'success',
        'code'=>'0',
        'data'=>array(),
    );
    $outapi['data']['meta']['description'] = $metadescription;
    $outapi['data']['meta']['title'] = $navtitle;
    $outapi['data']['meta']['keywords'] = $metakeywords;
    $outapi['data']['cat'] = $cat;

    if ($_GET['filter'] == 'list') {
        $outapi['data']['list']['data'] = array_values($list);
        $outapi['data']['list']['count'] = $num;
    }else{
        $outapi['data']['list']['data'] = array_values($list);
        $outapi['data']['list']['count'] = $num;
        $outapi['data']['catinfo'] = $catinfo;
        $outapi['data']['groupicons'] = $groupicons;
    }

    echo json_encode($video->auto_to_utf8($outapi));
    exit;
}


include template('zhanmishu_video:'.$mod);


?>