<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *    	Ӧ�ø���֧�֣�https://dism.taobao.com $
 */	

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$order = zhanmishu_video::getInstance();
$orderconfig = $order->config;
if (!$_G['uid']) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}

$act = $_GET['act'] ? $_GET['act'] : 'list';

if ($_GET['oid']) {
	$o = $order->get_order_byoid($_GET['oid'] + 0);
	if (empty($o) || $o['buyer_uid'] !== $_G['uid']) {
		showmessage(lang('plugin/zhanmishu_video', 'data_error'));
	}
}

if ($o['ispayed'] =='0' && $o['out_trade_no'] && $o['checknum'] == '0') {
	$order->check_ispay_byout_trade_no($o['out_trade_no']);
}

 $o['status'] = $order->update_order_status_byoid($o['oid']);


if ($act =='list') {

	if (!$orderconfig['issign']) {
		unset($zhanmishu_videoconf['orderstatus']['3']);
		unset($zhanmishu_videoconf['orderstatus']['4']);
		unset($zhanmishu_videoconf['orderstatus']['5']);
		unset($zhanmishu_videoconf['orderstatus']['6']);
	}
	if (!$orderconfig['email']) {

		unset($zhanmishu_videoconf['orderstatus']['5']);
		unset($zhanmishu_videoconf['orderstatus']['6']);
	}

	$field = array('buyer_uid'=>$_G['uid']);
	if ($_GET['status']) {
		$field['status'] = $_GET['status'] + 0;
		if ($_GET['status'] == '-2' || $_GET['status'] == '7') {
			$field['status'] = array('key'=>'status','relation'=>'in', 'value'=>'(-2 , 7)');
		}
	}

	$perpage=20;
	$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
	$num = $order->get_orders_num($field);

	$pages= ceil($num / $perpage);
	$start = $num - ($num - $perpage*$curpage+$perpage);
	$orders = $order->get_type_order($start,$perpage,'desc','',$field);

	foreach ($orders as $key => $value) {
		$orders[$key]['status'] = $order->update_order_status_byoid($value['oid']);
		if ($orders[$key]['course_img']) {
			$orders[$key]['course_img'] = $order->auto_to_url($orders[$key]['course_img']);
		}else if ($orders[$key]['course_column_img']) {
			$orders[$key]['course_img'] = $order->auto_to_url($orders[$key]['course_column_img']);
			$orders[$key]['course_column_img'] = $orders[$key]['course_img'];
			$orders[$key]['course_name'] = $orders[$key]['course_column_name'];
			$orders[$key]['course_price'] = $orders[$key]['course_column_price'];
		}else{
			$orders[$key]['course_img'] = $order->auto_to_url('source/plugin/zhanmishu_video/template/img/noimg.jpg');
		}
		
	}

}else if ($act=='contract') {
	if ($_GET['oid']) {

		if (submitcheck('ordersignsubmit',1)) {

			$images = zms_uploadimg('zhanmishu_video/sign/');
			if (!empty($images)) {
				if ($images['verifyimg1']) {
					$orderk= '1';
					$images['verifyimg'] = $images['verifyimg1'];
				}else if ($images['verifyimg2']) {
					$orderk= '2';
					$images['verifyimg'] = $images['verifyimg2'];
				}

				$noorderk = $orderk == '1' ? '2' : '1';
				include template('zhanmishu_video:order/order_contract_ajax');
				exit;
			}
			if (!$_GET['sign_img1'] || !$_GET['sign_img2']) {
				showmessage(lang('plugin/zhanmishu_video', 'data_error'));
			}

			if ($o['issign'] =='0') {
				$img = array(
				'sign_img2'=> daddslashes($_GET['sign_img2']),
				'sign_img1'=> daddslashes($_GET['sign_img1']),
				'issign'=>'1',
				'sign_time'=>TIMESTAMP
				);
				C::t("#zhanmishu_video#zhanmishu_video_order")->update($o['oid'],$img);
				$msg = lang('plugin/zhanmishu_video','sign_success');
			}else{
				$msg = lang('plugin/zhanmishu_video','have_signed');
			}

			$js = '<script type="text/javascript">showDialog("'.$msg.'","notice","",function(){top.location.href="'.dreferer().'";})</script>';
			showmessage(lang('plugin/zhanmishu_video',''), '', array(), array('msgtype' => 3,'showdialog'=>true,'showmsg'=>false,'extrajs'=>$js));
		}


	}else{
		$field = array('buyer_uid'=>$_G['uid']);
		if ($_GET['contractstatus']) {
			$field['order_type'] ='1';
			switch ($_GET['contractstatus']) {
				case '1'://finish
					$field['ispayed'] ='1';
					$field['issign'] ='1';
					$field['isconfirm'] ='1';
					$field['ismail'] ='1';
					$field['issuccess'] ='1';
					$field['isclosed'] ='0';
					break;

				case '2': // no sign
					$field['ispayed'] ='1';
					$field['isconfirm'] ='0';
					$field['issign'] ='0';
					$field['ismail'] ='0';
					$field['issuccess'] ='0';
					$field['isclosed'] ='0';
					break;

				case '3':// wait confirm
					$field['ispayed'] ='1';
					$field['isconfirm'] ='0';
					$field['issign'] ='1';
					$field['ismail'] ='0';
					$field['issuccess'] ='0';
					$field['isclosed'] ='0';
					break;
				case '4':// wait mail
					$field['ispayed'] ='1';
					$field['isconfirm'] ='1';
					$field['issign'] ='1';
					$field['ismail'] ='1';
					$field['issuccess'] ='0';
					$field['isclosed'] ='0';
					break;
				
				case '5':// wait success
					$field['ispayed'] ='1';
					$field['isconfirm'] ='1';
					$field['issign'] ='1';
					$field['ismail'] ='1';
					$field['issuccess'] ='0';
					$field['isclosed'] ='0';
					break;
				case '6':// closed
					$field['isclosed'] ='1';
					break;
				
				default:
					# code...
					break;
			}
		}
		$orders = $order->get_type_order(0,0,'','',$field); 
	}
}else if ($act=='mail') {

	if ($_GET['formhash'] == formhash()) {
		C::t("#zhanmishu_video#zhanmishu_video_order")->update($o['oid'],array('ismail'=>'1'));
		$msg = lang('plugin/zhanmishu_video','email_success');
		$js = '<script type="text/javascript">showDialog("'.$msg.'","notice","",function(){top.location.href="'.dreferer().'";})</script>';
		showmessage(lang('plugin/zhanmishu_video',''), '', array(), array('msgtype' => 3,'showdialog'=>true,'showmsg'=>false,'extrajs'=>$js));
	}
}else if ($act=='closed') {
	if ($o['ispayed'] =='1') {
		$js = '<script type="text/javascript">showDialog("'.lang('plugin/zhanmishu_video','cannot_closed_tips').'","notice","",function(){top.location.href="'.dreferer().'";})</script>';
		showmessage(lang('plugin/zhanmishu_video','cannot_closed_tips'), '', array(), array('msgtype' => 3,'showdialog'=>true,'showmsg'=>false,'extrajs'=>$js));
	}
	if ($_GET['formhash'] == formhash() && $o['oid']) {
		C::t("#zhanmishu_video#zhanmishu_video_order")->update($o['oid'],array('isclosed'=>'1'));
		$js = '<script type="text/javascript">showDialog("'.lang('plugin/zhanmishu_video','closed_tips').'","notice","",function(){top.location.href="'.dreferer().'";})</script>';
		showmessage(lang('plugin/zhanmishu_video','closed_tips'), '', array(), array('msgtype' => 3,'showdialog'=>true,'showmsg'=>false,'extrajs'=>$js));
	}
}else if ($act=='down') {
	if ($o['status'] =='1') {
		$c = $order->get_course_bycid($o['cid']);
		$o = array_merge($c,$o);
	}
}

if ($_GET['dtype']) {
	$outapi = array(
		'msg'=>'success',
		'code'=>'0',
		'data'=>array(),
	);
	$outapi['data']['orders'] = $orders;
	$outapi['data']['count'] = $num;
	$outapi['data']['pages'] = $pages;
	$outapi['data']['orderstatus'] = $zhanmishu_videoconf['orderstatus'];

	$outapi = zhanmishu_course::auto_charset_change($outapi,CHARSET,'utf-8');
	echo json_encode($outapi);
	exit;
}


//print_r($orders);

include template('zhanmishu_video:'.$mod);

?>