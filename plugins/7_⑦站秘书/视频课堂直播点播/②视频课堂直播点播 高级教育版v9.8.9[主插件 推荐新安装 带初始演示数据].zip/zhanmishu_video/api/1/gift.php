<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 




if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$videoHander = zhanmishu_video::getInstance();

$creditSetting = explode(',',$_G['setting']['creditnames']);
$credits_type = $videoHander->config['gift_credits_type'];
$credits_name = '';
foreach ($creditSetting as $key => $value) {
    $value = array_filter(explode('|',$value));
    if ($value[0] == $credits_type) {
        $credits_name = $value[1];
    }
}
$memberCount = C::t("common_member_count")->fetch($_G['uid']);
$gifts = $videoHander->get_gift_list();
$groupicons = $videoHander->get_group_icons();

if ((defined('IN_MOBILE_API') && $_GET['presentGiftSubmit'] == 'yes')) {
    if (!$_G['uid']) {
        $return =array(
            'code' => '-10001',
            'msg' => 'please_login'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;
    }else if (!isset($_GET['gift_id'])) {
        $return = array(
            'code' => '-10004',
            'msg' => 'gift_id_is_required'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;
    }

    $videoInfo = $videoHander->get_video_by_vid($_GET['vid'] + 0);
    if (empty($videoInfo)) {
        $videoInfo = $videoHander->get_course_bycid($_GET['cid'] + 0);
         $videoInfo['video_name'] = $videoInfo['course_name'];
    }

    $gift = $gifts[$_GET['gift_id']];
    if (empty($gift)) {
        $return = array(
            'code' => '-10006',
            'msg' => 'gift_is_not_exists'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;
    }
    if (!$videoInfo['uid']) {
        $return = array(
            'code' => '-10007',
            'msg' => 'teacher_isnot_exists'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;
    }

    $num = $_GET['num'] ? $_GET['num'] + 0 : '1';
    $moneyNum = $gift['gift_score'] * $num;

    $giftData = array();
    $giftData['uid'] = $videoInfo['uid'];
    $giftData['present_uid'] = $_G['uid'];
    $giftData['present_username'] = $_G['username'];
    $giftData['gift_name'] = $gift['gift_name'];
    $giftData['gift_icon'] = $gift['gift_icon'];
    $giftData['gift_score'] = $gift['gift_score'];
    $giftData['credits_type'] = $credits_type;
    $giftData['num'] = $num;
    $giftData['total_score'] = $moneyNum;
    $giftData['dateline'] = TIMESTAMP;

    if ($videoHander->gift_checklowerlimit('-'.$moneyNum) !== true) {
        $return = array(
            'code' => '-10008',
            'msg' => 'cr_isnot_enough_please_pay_times'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;
    }else{
        $gid = C::t("#zhanmishu_video#zhanmishu_video_gift")->insert($giftData);

        if (!$gid) {
            $return = array(
                'code' => '-10009',
                'msg' => 'insert_gift_data_error'
            );
            echo zhanmishu_api::resultToJson($return);
        }

        $c = array();
        $c['gid']=$gid;
        $c['cid']=$giftData['cid'];
        $c['vid']=$giftData['vid'];
        $c['video_name']=$videoInfo['video_name'];
        $c['time']=date('Y-m-d H:i:s',$giftData['dateline']);

        $videoHander->gift_updatemembercount($_G['uid'],'-'.$moneyNum,lang('plugin/zhanmishu_video','gift_paytype_extcredits'),lang('plugin/zhanmishu_video','gift_paytype_extcredits_intro',$c));

        $c['present_username'] = $_G['username'];

        if ($videoHander->config['teacher_per']) {
            $videoHander->gift_updatemembercount($giftData['uid'],ceil($moneyNum * $videoHander->config['teacher_per']),lang('plugin/zhanmishu_video','gift_paytype_extcredits_percentage'),lang('plugin/zhanmishu_video','gift_paytype_extcredits_percentage_intro',$c));
        }

        $return = array(
            'code' => '1',
            'msg' => 'success'
        );
        $return['extcredits'.$credits_type] = -$moneyNum;
        echo zhanmishu_api::resultToJson($return);
        exit;

    }


}else{

    $return = array();
    $return['uid'] = $_G['uid'];
    $return['groupid'] = $_G['groupid'];
    $return['username'] = $_G['username'];
    $return['extcredits'.$credits_type] = $memberCount['extcredits'.$credits_type];
    $return['credits_name'] = $credits_name;
    $return['credits_type'] = $credits_type;
    $return['formhash'] = FORMHASH;
    $return['avatar'] = avatar($_G['uid'], 'middle', true);;
    $return['gifts'] = array_values($gifts);
    $return['groupicons'] = $groupicons;

    echo zhanmishu_api::resultToJson($return);
    exit;

}


