<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 




if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$videoHander = zhanmishu_video::getInstance();


$profile = $videoHander->get_item_list();
$groupicons = $videoHander->get_group_icons();

$outapi = array();

$outapi['code'] = '0';
$outapi['msg'] = 'success';
$outapi['data']['uid'] = $_G['uid'];
$outapi['data']['groupid'] = $_G['groupid'];
$outapi['data']['username'] = $_G['username'];
$outapi['data']['formhash'] = FORMHASH;
$outapi['data']['avatar'] = avatar($_G['uid'], 'middle', true);;
$outapi['data']['userItem'] = array_values($profile);
$outapi['data']['groupicons'] = $groupicons;

echo json_encode($videoHander->auto_to_utf8($outapi));
exit;
