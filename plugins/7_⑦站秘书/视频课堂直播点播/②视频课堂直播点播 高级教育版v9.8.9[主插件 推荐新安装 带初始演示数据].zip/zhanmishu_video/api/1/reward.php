<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 




if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$videoHander = zhanmishu_video::getInstance();

if ($_GET['action'] == 'setting') {
    $reward = $videoHander->get_reward_list();
    echo zhanmishu_api::resultToJson($reward);
    exit;
}else if ($_GET['action'] == 'reward') {
    if (!$_G['uid']) {
        $return =array(
            'code' => '-10001',
            'msg' => 'please_login'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;
    }
    // if (!$_GET['vid']) {
    //     $return =array(
    //         'code' => '-70001',
    //         'msg' => 'vid_is_required'
    //     );
    //     echo zhanmishu_api::resultToJson($return);
    //     exit;
    // }
    if (!$_GET['total_fee']) {
        $return =array(
            'code' => '-70003',
            'msg' => 'total_fee_is_required'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;
    }


    // CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_reward (
    //   `rid` mediumint(8)  unsigned NOT NULL AUTO_INCREMENT,
    //   `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
    //   `vid` mediumint(8) unsigned NOT NULL DEFAULT '0',
    //   `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
    //   `present_uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
    //   `present_username` mediumint(8) unsigned NOT NULL DEFAULT '0',
    //   `teacher_name` varchar(127) NOT NULL DEFAULT '',
    //   `total_fee` smallint(3) NOT NULL DEFAULT '0',
    //   `dateline` int(10) unsigned NOT NULL DEFAULT '0',
    //   PRIMARY KEY (gid),
    //   KEY uid (uid),
    //   KEY present_uid (present_uid),
    //   KEY present_username (present_username),
    //   KEY teacher_name (teacher_name),
    //   KEY dateline (dateline)
    // );

    $videoInfo = $videoHander->get_video_by_vid($_GET['vid'] + 0);
    if (empty($videoInfo)) {
        // 那么就去找cid了
        $videoInfo = $videoHander->get_course_bycid($_GET['cid'] + 0);
    }

    $out_trade_no = $videoHander->get_rand_trade_no();
    $rewardLog = array();
    $rewardLog['uid'] = $videoInfo['uid'];
    if($videoInfo['vid']){
        $rewardLog['vid'] = $videoInfo['vid'];
    }
    
    $rewardLog['cid'] = $videoInfo['cid'];
    $rewardLog['present_uid'] = $_G['uid'];
    $rewardLog['out_trade_no'] = $out_trade_no;
    $rewardLog['present_username'] = $_G['username'];
    // $rewardLog['teacher_name'] = $_G['username'];
    $rewardLog['total_fee'] = ceil($_GET['total_fee'] * 100);
    $rewardLog['dateline'] = TIMESTAMP;

    $rid = C::t('#zhanmishu_video#zhanmishu_video_reward')->insert($rewardLog,true);
    if (!$rid) {
         $return =array(
            'code' => '-70004',
            'msg' => 'reward_error'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;      
    }
    
    //生成订单
    $zmsPayExists =  $videoHander->ZmsIsWepayExists();
    if ($zmsPayExists) {
        include_once DISCUZ_ROOT.'source/plugin/zhanmishu_wepay/source/function/api_function.php';
        $user = getuserbyuid($videoInfo['uid']);
        $orderInfo = array();
        $orderInfo['out_trade_no'] = $rewardLog['out_trade_no'];
        $orderInfo['body'] = lang('plugin/zhanmishu_video','rewardTitle',array('username'=>$user['username']));
        $orderInfo['body_intro'] = lang('plugin/zhanmishu_video','rewardTitleContent',array('username'=>$user['username'], 'time'=> dgmdate(TIMESTAMP), 'number'=> $rewardLog['total_fee'] / 100));
        $orderInfo['total_fee'] = $rewardLog['total_fee'] / 100;
        $orderInfo['openId'] = $_GET['openid'];

        if ($_GET['platform'] == 'minapp') {
            $payType = 'wechat_app';
        }else if ($_GET['platform'] == 'app') {
            $payType = 'app';
        }else{
            $payType = '';
        }
        if (!$orderInfo['openId']) {
            if (is_file(DISCUZ_ROOT.'source/plugin/zhanmishu_wechat/source/class/zhanmishu_wechat_member.php')) {
                if (!class_exists('zhanmishu_wechat_member')) {
                    C::import('zhanmishu_wechat_member','plugin/zhanmishu_wechat/source/class');
                }
                
                $orderInfo['openId'] = zhanmishu_wechat_member::get_openid_by_uid($_G['uid'],$_GET['platform']);     
            }
        }
        $payInfo = zhanmishu_pay_api($orderInfo,'1',$payType);
        $return = array();
        $return['reward'] = $rewardLog;
        $return['payInfo'] = $payInfo;
        echo zhanmishu_api::resultToJson($return);
        exit;
    }


}else if ($_GET['action'] == 'check') {
    $out_trade_nos = daddslashes($_GET['out_trade_no']);
    $out_trade_nos = explode(',', $out_trade_nos);

    $payStatusMore = array();
    foreach ($out_trade_nos as $key => $out_trade_no) {
        $payStatus = $videoHander->check_reward_ispay_byout_trade_no($out_trade_no);
        $payStatusMore[$key] = $payStatus;
    }
    if (count($out_trade_nos) == 1) {
        echo zhanmishu_api::resultToJson($payStatus);
        exit;
    }else{
        echo zhanmishu_api::resultToJson($payStatusMore);
        exit;
    }

    
}

