<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *    	Ӧ�ø���֧�֣�https://dism.taobao.com $
 */	

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$video = zhanmishu_video::getInstance();

$videoconfig = $video->config;

$cat = $video->get_cat_tree();
$sample_cat_list =  $video->cat_tree_to_sample();
$catpid = $_GET['cat_id'] ? $video->get_pidbycat_id($_GET['cat_id'] + 0) : '0';
$catson =  $video->get_cat_tree($catpid ? $catpid : $_GET['cat_id'] + 0);

if ($mod == 'index') {
	$rewrite_cat = $_GET['cat_id'] ? $_GET['cat_id'] : '0';
	$rewrite_vip = $_GET['groupselect'] ? $_GET['groupselect'] : '0';
	$rewrite_diff = $_GET['diff'] ? $_GET['diff'] : '0';
	$rewrite_order = $_GET['order'] ? $_GET['order'] : '0';
}

$videoBaseUrl = 'plugin.php?id=zhanmishu_video:video';
$pdata = $_GET;
unset($pdata['page']);
$mpurl = 'plugin.php?'.urldecode(http_build_query($pdata));
$cdata = $_GET;
unset($cdata['cat_id']);
unset($cdata['page']);

$caturl = 'plugin.php?'.urldecode(http_build_query($cdata));
$ddata = $_GET;
unset($ddata['diff']);
$durl = 'plugin.php?'.urldecode(http_build_query($ddata));
$odata = $_GET;
unset($odata['order']);
$ourl = 'plugin.php?'.urldecode(http_build_query($odata));
$gdata = $_GET;
unset($gdata['groupselect']);
unset($gdata['page']);
$gurl = 'plugin.php?'.urldecode(http_build_query($gdata));


$field = array();
$field['isdel'] = '0';
$field['issell'] = '1';



if ($_GET['search_key']) {
	if (defined('IN_MOBILE_API')) {
		$_GET['search_key'] = zhanmishu_course::auto_charset_change($_GET['search_key'],'UTF-8',CHARSET);
	}
	$field['course_name'] = array(
		'key'=>'course_name',
		'value'=>'%'.daddslashes($_GET['search_key']).'%',
		'relation'=>'like'
	);
}

if ($_GET['cat_id']) {
	$this_cat_son = $video->get_cat_tree($_GET['cat_id'] + 0);
	if (empty($this_cat_son['son'])) {
		$field['cat_id'] = $_GET['cat_id'] + 0;
	}else{
		$cat_ids = array();
		$cat_ids[$_GET['cat_id'] + 0] = $_GET['cat_id'] + 0;
		foreach ($this_cat_son['son'] as $key => $value) {
			$cat_ids[$value['cat_id']] = $value['cat_id'];
		}
		$ids .= ' ('.implode(',', $cat_ids).') ';

		$field['cat_id'] = array('key'=>'cat_id','relation'=>'in', 'value'=> $ids);
	}
	$catinfo = $video->get_cat_by_cat_id($_GET['cat_id'] + 0);
}else{
	$catinfo = null;
}
if ($_GET['diff']) {
	$field['diff'] = $_GET['diff'] + 0;
}
if ($_GET['groupselect']) {
    $field['course_group'] = array(
        'relation'=> 'sql',
        'sql'=> 'CONCAT(\',\',course_group,\',\') LIKE \'%'.daddslashes($_GET['groupselect']).'%\''
    );
}

$num = $video->get_type_course_num($field);

if ($videoconfig['clumnnums'] == 3) {
	$perpage = 8;
}else{
	$perpage = 8;
}
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
$pages= ceil($num / $perpage);
$start = $num - ($num - $perpage*$curpage+$perpage);


if ($_GET['order'] == 'new') {
	$sort = array('dateline'=>'desc');
}else if($_GET['order'] == 'hot'){
	$sort = array('views'=>'desc');
}else if($_GET['order'] == 'low_price'){
	$sort = array('course_price'=>'asc');
}else if($_GET['order'] == 'views'){
	$sort = array('views'=>'desc');
}else if($_GET['order'] == 'high_price'){
	$sort = array('course_price'=>'desc');
}else if($_GET['order'] == 'learns'){
	$sort = array('learns'=>'desc');
}else if($_GET['order'] == 'replies'){
	$sort = array('replies'=>'desc');
}else {
	$sort = array('course_weight'=>'desc','cid'=>'desc');
}

$list = $video->get_type_course_filter_format($start,$perpage,$sort,$field);

$liveList = $video->get_videos_group_by_cid(0,5,array('start_time'=>'desc'),array('isdel'=>'0','islive'=>'1'));
foreach ($liveList as $key => $value) {
	$liveList[$key]['video_url'] = '';
	$liveCourse = $video->get_course_bycid($value['cid']);
	if (empty($liveCourse) || $liveCourse['isdel'] == '1' || $liveCourse['issell'] == '0' ) {
		unset($liveList[$key]);
		continue;
	}
	$liveList[$key] = array_merge($liveCourse,$value);
	$liveList[$key]['tags'] = $video->get_course_tags_bycid($value['cid']);
	$liveList[$key]['course_img'] = zhanmishu_video::getImageThumb($liveCourse['course_img'], 375, 150 ,true);
	$liveList[$key]['course_img'] = str_replace('source/plugin/zhanmishu_video/','',$_G['siteurl']).$liveList[$key]['course_img'];

	if ($value['uid']) {
		$user = getuserbyuid($value['uid']);
		$liveList[$key]['username'] = $user['username'];
	}
}

$navList = $video->get_nav_list();

$columnsField = array();
$columnsField[] = array(
	'relation'=>'sql', 
	'sql'=>' isdel = 0 '
);
$columns = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch_all(0, 4, 'desc', $columnsField);

foreach ($columns as $key => $value) {
	$columns[$key]['course_column_img'] = zhanmishu_video::getImageThumb($value['course_column_img'], 375, 150 ,true);
	$columns[$key]['course_column_img'] = str_replace('source/plugin/zhanmishu_video/','',$_G['siteurl']).$columns[$key]['course_column_img'];

	if ($value['uid']) {
		$user = getuserbyuid($value['uid']);
		$columns[$key]['username'] = $user['username'];
	}
}


if (defined('IN_MOBILE_API')) {
	$cate = array_chunk($video->get_cat_by_level('1',array('cat_touchorder'=>'asc')),8);
	$swiper = $video->get_app_swiper();
	$best = $video->get_app_best();
}else{
	$swiper = $video-> get_pc_swiper();
	$best = $video->get_pc_best();
	$multi = multi($num, $perpage, $curpage, $mpurl, '0');
}
foreach ($swiper as $key => $value) {
	if (zhanmishu_video::check_url($swiper[$key]['image']) == 'url') {
		$filePath = str_replace($_G['siteurl'], '', $swiper[$key]['image']);

		$swiper[$key]['image'] = $_G['siteurl'].zhanmishu_video::getImageThumb($filePath, 750, 300 ,true);
	}
}
$groupicons = $video->get_group_icons();

$navtitle = $catinfo['cat_name'] ? $catinfo['cat_name'].' - '.$videoconfig['index_title'] : $videoconfig['index_title'];
$metakeywords = $catinfo['cat_name'] ? $catinfo['cat_name'].','.$videoconfig['metakeywords']:$videoconfig['metakeywords'];
$metadescription = $catinfo['cat_name'] ? $catinfo['cat_name'].','.$videoconfig['metadescription']:$videoconfig['metadescription'];


if ($_GET['dtype']) {
	$outapi = array(
		'msg'=>'success',
		'code'=>'0',
		'data'=>array(),
	);
	$outapi['data']['meta']['description'] = $metadescription;
	$outapi['data']['meta']['title'] = $navtitle;
	$outapi['data']['meta']['keywords'] = $metakeywords;
	$outapi['data']['cat'] = $cat;
	$outapi['data']['shareText'] = $video->getShareText('index',$catinfo);

	if ($_GET['filter'] == 'list') {
		$outapi['data']['list']['data'] = array_values($list);
		$outapi['data']['list']['count'] = $num;
	}else{
		$outapi['data']['swiper'] = $swiper;
		$outapi['data']['best'] = $best;
		$outapi['data']['list']['data'] = array_values($list);
		$outapi['data']['live']['data'] = array_values($liveList);
		$outapi['data']['columns']['data'] = array_values($columns);
		$outapi['data']['navList']['data'] = array_values($navList);
		$outapi['data']['list']['count'] = $num;
		$outapi['data']['catinfo'] = $catinfo;
		$outapi['data']['groupicons'] = $groupicons;
	}

	echo json_encode($video->auto_to_utf8($outapi));
	exit;
}

foreach ($list as $key => $value) {
	if ($value['islive']) {
		$list[$key]['tags'] = $video->get_course_tags_bycid($value['cid']);
	}
}

include template('zhanmishu_video:'.$mod);


?>