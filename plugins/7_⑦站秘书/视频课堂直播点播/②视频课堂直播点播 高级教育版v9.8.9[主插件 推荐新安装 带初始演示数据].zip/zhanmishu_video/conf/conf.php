<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *    	Ӧ�ø���֧�֣�https://dism.taobao.com $
 */	

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$zhanmishu_videoconf = array();

$zhanmishu_videoconf['video_urltype']['0']=lang('plugin/zhanmishu_video', 'video_urltype_0');
$zhanmishu_videoconf['video_urltype']['1']=lang('plugin/zhanmishu_video', 'video_urltype_1');

$zhanmishu_videoconf['course_type']['0']=lang('plugin/zhanmishu_video', 'video_urltype_0');
$zhanmishu_videoconf['course_type']['1']=lang('plugin/zhanmishu_video', 'video_urltype_1');

$zhanmishu_videoconf['isfree']['0']=lang('plugin/zhanmishu_video', 'isfree_0');
$zhanmishu_videoconf['isfree']['1']=lang('plugin/zhanmishu_video', 'isfree_1');

$zhanmishu_videoconf['diff']['1']=lang('plugin/zhanmishu_video', 'diff_1');
$zhanmishu_videoconf['diff']['2']=lang('plugin/zhanmishu_video', 'diff_2');
$zhanmishu_videoconf['diff']['3']=lang('plugin/zhanmishu_video', 'diff_3');

$zhanmishu_videoconf['progress']['1']=lang('plugin/zhanmishu_video', 'progress_1');
$zhanmishu_videoconf['progress']['2']=lang('plugin/zhanmishu_video', 'progress_2');
$zhanmishu_videoconf['progress']['3']=lang('plugin/zhanmishu_video', 'progress_3');
$zhanmishu_videoconf['progress']['4']=lang('plugin/zhanmishu_video', 'progress_4'); 

$zhanmishu_videoconf['orderstatus']['0']=lang('plugin/zhanmishu_video', 'all'); 
$zhanmishu_videoconf['orderstatus']['2']=lang('plugin/zhanmishu_video', 'none_pay'); 
$zhanmishu_videoconf['orderstatus']['3']=lang('plugin/zhanmishu_video', 'none_sign'); 
$zhanmishu_videoconf['orderstatus']['4']=lang('plugin/zhanmishu_video', 'none_confirm'); 
$zhanmishu_videoconf['orderstatus']['5']=lang('plugin/zhanmishu_video', 'none_mail'); 
$zhanmishu_videoconf['orderstatus']['6']=lang('plugin/zhanmishu_video', 'none_success'); 
$zhanmishu_videoconf['orderstatus']['1']=lang('plugin/zhanmishu_video', 'success'); 
$zhanmishu_videoconf['orderstatus']['7']=lang('plugin/zhanmishu_video', 'closed'); 
$zhanmishu_videoconf['orderstatus']['-2']=lang('plugin/zhanmishu_video', 'closed'); 

$zhanmishu_videoconf['contractstatus']['0']=lang('plugin/zhanmishu_video', 'all'); 
$zhanmishu_videoconf['contractstatus']['2']=lang('plugin/zhanmishu_video', 'none_sign'); 
$zhanmishu_videoconf['contractstatus']['3']=lang('plugin/zhanmishu_video', 'none_confirm'); 
$zhanmishu_videoconf['contractstatus']['4']=lang('plugin/zhanmishu_video', 'none_mail'); 
$zhanmishu_videoconf['contractstatus']['5']=lang('plugin/zhanmishu_video', 'none_success'); 
$zhanmishu_videoconf['contractstatus']['1']=lang('plugin/zhanmishu_video', 'success'); 
$zhanmishu_videoconf['contractstatus']['6']=lang('plugin/zhanmishu_video', 'closed'); 

$zhanmishu_videoconf['video_url_type']['0']=lang('plugin/zhanmishu_video', 'type_auto_set'); 
$zhanmishu_videoconf['video_url_type']['1']=lang('plugin/zhanmishu_video', 'qiniuoss'); 
$zhanmishu_videoconf['video_url_type']['2']=lang('plugin/zhanmishu_video', 'downloadurl'); 
$zhanmishu_videoconf['video_url_type']['3']=lang('plugin/zhanmishu_video', 'videourl'); 
$zhanmishu_videoconf['video_url_type']['4']=lang('plugin/zhanmishu_video', 'videohtmlcode'); 
$zhanmishu_videoconf['video_url_type']['5']=lang('plugin/zhanmishu_video', 'livehtmlcode'); 
$zhanmishu_videoconf['video_url_type']['6']=lang('plugin/zhanmishu_video', 'RTMPlive'); 
$zhanmishu_videoconf['video_url_type']['7']=lang('plugin/zhanmishu_video', 'HLSlive'); 
$zhanmishu_videoconf['video_url_type']['8']=lang('plugin/zhanmishu_video', 'FLVlive'); 
$zhanmishu_videoconf['video_url_type']['9']=lang('plugin/zhanmishu_video', 'autolive'); 
$zhanmishu_videoconf['video_url_type']['10']=lang('plugin/zhanmishu_video', 'oss_storage'); 
$zhanmishu_videoconf['video_url_type']['11']=lang('plugin/zhanmishu_video', 'aliyun_live'); 
$zhanmishu_videoconf['video_url_type']['13']=lang('plugin/zhanmishu_video', 'baidu_live'); 
$zhanmishu_videoconf['video_url_type']['12']=lang('plugin/zhanmishu_video', 'aliyun_live_record'); 

$zhanmishu_videoconf['qiniuurl']='';


$zhanmishu_videoconf['touch']['swiper']['0'] = array('name'=>'','url'=>'','image'=>'source/plugin/zhanmishu_video/template/touch/images/img1.jpg','intro'=>'');
$zhanmishu_videoconf['touch']['swiper']['1'] = array('name'=>'','url'=>'','image'=>'source/plugin/zhanmishu_video/template/touch/images/img3.jpg','intro'=>'');
$zhanmishu_videoconf['touch']['swiper']['2'] = array('name'=>'','url'=>'','image'=>'source/plugin/zhanmishu_video/template/touch/images/img4.jpg','intro'=>'');

$zhanmishu_videoconf['pc']['swiper']['0'] = array('name'=>'','url'=>'','image'=>'source/plugin/zhanmishu_video/template/img/index1_01.jpg','intro'=>'');
$zhanmishu_videoconf['pc']['swiper']['1'] = array('name'=>'','url'=>'','image'=>'source/plugin/zhanmishu_video/template/img/index1_05.jpg','intro'=>'');
$zhanmishu_videoconf['pc']['swiper']['2'] = array('name'=>'','url'=>'','image'=>'source/plugin/zhanmishu_video/template/img/index1_03.jpg','intro'=>'');

?>