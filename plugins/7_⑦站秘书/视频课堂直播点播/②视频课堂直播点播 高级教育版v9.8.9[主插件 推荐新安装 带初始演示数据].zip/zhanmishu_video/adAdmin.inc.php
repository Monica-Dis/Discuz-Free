<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/function/common_function.php';
$videoHander = zhanmishu_video::getInstance();
$url = 'plugins&operation=config&identifier=zhanmishu_video&pmod=adAdmin';
$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_video&pmod=adAdmin';
$action = $_GET['act'] ? daddslashes($_GET['act']) : 'minappAdSetting';

$perpage=20;
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
$pages= ceil($num / $perpage);
$start = $num - ($num - $perpage*$curpage+$perpage);
echo '<br>';
echo '<br>';

$formurl = 'plugins&operation=config&identifier=zhanmishu_video&pmod=adAdmin';
zms_showtitle(lang('plugin/zhanmishu_video', 'course_admin'),array(
    $addarray,
    array(lang('plugin/zhanmishu_video', 'minappAdSetting'),$url.'&act=minappAdSetting',$status = $action =='minappAdSetting'?'1':'0'),
    array(lang('plugin/zhanmishu_video', 'appAdSetting'),$url.'&act=appAdSetting',$status = $action =='appAdSetting'?'1':'0')
));

if ($action == 'minappAdSetting'){
    if (submitcheck('minappAdSetting')) {
        $minappAd = array();
        $minappAd['wechatVideoAd'] = daddslashes($_GET['wechatVideoAd']);
        $minappAd['wechatListAd'] = daddslashes($_GET['wechatListAd']);
        $minappAd['wechatListAdNum'] = intval($_GET['wechatListAdNum']);

        $videoHander->writetocache('minappAd', $minappAd);
        cpmsg(lang('plugin/zhanmishu_video', 'success'),'action='.$url,'success');
    }
    $minappAd = $videoHander->GetFromCache('minappAd');
    

    showformheader($formurl,'enctype="multipart/form-data"');

    showtableheader(lang('plugin/zhanmishu_video','minappAdTips'));
    showsetting(lang('plugin/zhanmishu_video', 'wechatVideoAd'), 'wechatVideoAd', $minappAd['wechatVideoAd'], 'text','','',lang('plugin/zhanmishu_video', 'wechatVideoAdDesc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'wechatListAd'), 'wechatListAd', $minappAd['wechatListAd'], 'text','','',lang('plugin/zhanmishu_video', 'wechatListAdDesc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'wechatListAdNum'), 'wechatListAdNum', $minappAd['wechatListAdNum'], 'text','','',lang('plugin/zhanmishu_video', 'wechatListAdNumDesc'),'size="10"');
    showsubmit('minappAdSetting',lang('plugin/zhanmishu_video', 'submit'));

    showtablefooter(); /*Dism_taobao-com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/

}else if ($action == 'appAdSetting'){
    if (submitcheck('appAdSetting')) {
        $appAd = array();
        $appAd['adpid'] = daddslashes($_GET['adpid']);
        // $appAd['unitId'] = daddslashes($_GET['unitId']);
        $appAd['appAdNum'] = intval($_GET['appAdNum']);

        $videoHander->writetocache('appAd', $appAd);
        cpmsg(lang('plugin/zhanmishu_video', 'success'),'action='.$url.'&act=appAdSetting','success');
    }
    $appAd = $videoHander->GetFromCache('appAd');
    

    showformheader($formurl.'&act=appAdSetting','enctype="multipart/form-data"');

    showtableheader(lang('plugin/zhanmishu_video','minappAdTips'));
    showsetting(lang('plugin/zhanmishu_video', 'adpid'), 'adpid', $appAd['adpid'], 'text','','',lang('plugin/zhanmishu_video', 'adpidDesc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'appAdNum'), 'appAdNum', $appAd['appAdNum'], 'text','','',lang('plugin/zhanmishu_video', 'appAdNumDesc'),'size="10"');
    showsubmit('appAdSetting',lang('plugin/zhanmishu_video', 'submit'));

    showtablefooter(); /*Dism_taobao-com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/
}
//dis'.'m.tao'.'bao.com
?>