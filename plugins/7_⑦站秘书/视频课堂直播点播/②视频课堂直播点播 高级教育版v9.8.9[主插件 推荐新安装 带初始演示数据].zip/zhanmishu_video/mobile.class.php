<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_zhanmishu_video {
    function common(){
        global $_G;
        if(!defined('IN_MOBILE_API')) {
            return;
        }
        $_G['siteurl'] = str_replace('source/plugin/zhanmishu_video/','',$_G['siteurl']);
        if(!$_G['uid']) {
            $token = $_GET['token'];
            if (!is_file(DISCUZ_ROOT.'source/plugin/zhanmishu_wechat/source/class/zhanmishu_wechat_member.php')) {
                return;
            }
            if (!class_exists('zhanmishu_wechat_member',false)) {
                C::import('zhanmishu_wechat_member','plugin/zhanmishu_wechat/source/class');
            }
            if (!$token) {
                $headers = zhanmishu_wechat_member::getallheaders();
                $token = $headers['Authorization'];
            }
            if ($token) {
                zhanmishu_wechat_member::login_by_token($token);
            }
        }
        // if(class_exists('mobile_api', false) && method_exists('mobile_api', 'common')) {
        //     mobile_api::common();
        // }
    }
    function global_footer_mobile(){
        return '';
    }

}
//From: Dism��taobao��com
?>