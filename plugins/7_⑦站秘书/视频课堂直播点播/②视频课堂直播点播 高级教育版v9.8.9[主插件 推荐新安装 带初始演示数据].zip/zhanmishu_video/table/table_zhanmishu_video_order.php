<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *		应用更新支持：https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!class_exists('table_zhanmishu_base',false)) {
    C::import('table_zhanmishu_base','plugin/zhanmishu_app/table');
}
class table_zhanmishu_video_order extends table_zhanmishu_base {

	public function __construct() {
		$this->_table = 'zhanmishu_video_order';
		$this->_pk = 'oid';

		parent::__construct();
	}

	// 获取某课程所有购买用户uid
	public function fetch_uids($cid = ''){
		if (!$cid) {
			return array();
		}

		$field = array();
		$field['cid'] = $cid;

		return DB::fetch_all('select buyer_uid from %t where cid = %d', array($this->_table, $cid));
	}
	
	public function sum($field = array()){
		return self::fetch_sum('total_fee', $field);	
	}
	public function get_one_order_byfield($field){
		return self::fetch_one($field);
	}


	public function get_orders_num($field){
		return self::fetch_num($field);
	}

	public function update_ordertype_bycid($cid,$order_type){
		if (!$cid) {
			return false;
		}

		DB::update($this->_table,array('order_type'=>$order_type),'cid='.$cid);
	}


	public function get_order_by_out_trade_no($out_trade_no){
		if (!$out_trade_no) {
			return false;
		}

		return DB::fetch_first('select * from %t where out_trade_no = %s',array($this->_table,$out_trade_no));
	}

	public function set_pay_overdue($time){
		$time = $time * 3600 * 24;
		DB::update($this->_table,array('ispayed'=>'2'),' dateline < '.(TIMESTAMP - $time));
	}

	public function get_type_order($start = 0, $limit = 0, $sort = '',$type = '',$field) {
		return self::fetch_all($start, $limit, $sort, $field);
	}

}
//From: Dism·taobao·com
?>