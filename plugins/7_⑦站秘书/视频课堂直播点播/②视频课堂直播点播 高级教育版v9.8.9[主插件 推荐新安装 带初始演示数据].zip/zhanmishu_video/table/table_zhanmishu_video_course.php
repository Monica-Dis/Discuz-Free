<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *		Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!class_exists('table_zhanmishu_base',false)) {
    C::import('table_zhanmishu_base','plugin/zhanmishu_app/table');
}

class table_zhanmishu_video_course extends table_zhanmishu_base {

	public function __construct() {
		$this->_table = 'zhanmishu_video_course';
		$this->_pk = 'cid';

		parent::__construct();
	}
	public function get_one_course_byfield($field){
		if (!empty($field)) {
			$where = ' where ';
			$tmp = array();
			foreach ($field as $key => $value) {
				if (!is_array($value)) {
					$tmp[] = ' '.$key.' = \''.$value.'\' ';
				}else if(is_array($value) &&  $value['relation']){
					switch (trim(strtolower($value['relation']))) {
						case 'like':
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
							break;
						case 'in':
							$tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
							break;
						case 'not in':
							$tmp[] = ' '.$value['key'].' not in '.$value['value'].' ';
							break;
						case 'sql':
							$tmp[] = $value['sql'];
							break;
						default:
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
							break;
					}
				}
			}
			$where .= implode(' and ', $tmp);
		}else{
			$where = '';
		}
		return DB::fetch_first('SELECT * FROM '.DB::table($this->_table).$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
	public function get_type_course_num($field=array()){

		if (!empty($field)) {
			$where = ' where ';
			$tmp = array();
			foreach ($field as $key => $value) {
				if (!is_array($value)) {
					$tmp[] = ' '.$key.' = \''.$value.'\' ';
				}else if(is_array($value) &&  $value['relation']){
					switch (trim(strtolower($value['relation']))) {
						case 'like':
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
							break;
						case 'in':
							$tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
							break;
						case 'not in':
							$tmp[] = ' '.$value['key'].' not in '.$value['value'].' ';
							break;
						case 'sql':
							$tmp[] = $value['sql'];
							break;
						default:
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
							break;
					}
				}
			}
			$where .= implode(' and ', $tmp);
		}else{
			$where = '';
		}

 
		$count = DB::fetch_first('SELECT count(*) as num FROM '.DB::table($this->_table).$where);
		return $count['num'];
			
	}
	public function get_type_course($start = 0, $limit = 0, $sort = '',$type = '',$field) {

		if (is_array($sort) && !empty($sort)) {
			$order = ' ORDER BY ';
			$tmp=array();
			foreach ($sort as $key => $value) {
				$tmp[] = DB::order($key, $value);
			}
			$order .= implode(',', $tmp);
			
		}else if($sort) {
			$this->checkpk();
			$order = $sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '';
		}

		if (!empty($field)) {
			$where = ' where ';
			$tmp = array();
			foreach ($field as $key => $value) {
				if (!is_array($value)) {
					$tmp[] = ' '.$key.' = \''.$value.'\' ';
				}else if(is_array($value) &&  $value['relation']){
					switch (trim(strtolower($value['relation']))) {
						case 'like':
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
							break;
						case 'in':
							$tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
							break;
						case 'not in':
							$tmp[] = ' '.$value['key'].' not in '.$value['value'].' ';
							break;
						case 'sql':
							$tmp[] = $value['sql'];
							break;
						default:
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
							break;
					}
				}
			}
			$where .= implode(' and ', $tmp);
		}else{
			$where = '';
		}

		return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).$where.$order.DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');

	}

}

//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>