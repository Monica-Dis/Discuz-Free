<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!class_exists('table_zhanmishu_base',false)) {
    C::import('table_zhanmishu_base','plugin/zhanmishu_app/table');
}
class table_zhanmishu_video_reward extends table_zhanmishu_base {

    public function __construct() {
        $this->_table = 'zhanmishu_video_reward';
        $this->_pk = 'rid';

        parent::__construct();
    }


    public function get_one_reward_byfield($field){
        if (!empty($field)) {
            $where = ' where ';
        }else{
            $where = '';
        }

        $i = 1;
        foreach ($field as $key => $value) {
            if ($i == count($field)) {
                $where = $where.' '.$key.' = \''.$value.'\' ';
            }else{
                $where = $where.' '.$key.' = \''.$value.'\' and ';
            }

            ++$i;
        }
        return DB::fetch_first('SELECT * FROM '.DB::table($this->_table).$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
    }

    public function get_type_reward_num($field=array()){
        if (!empty($field)) {
            $where = ' where ';
        }else{
            $where = '';
        }

        $i = 1;
        foreach ($field as $key => $value) {
            if ($i == count($field)) {
                $where = $where.' '.$key.' = \''.$value.'\' ';
            }else{
                $where = $where.' '.$key.' = \''.$value.'\' and ';
            }

            ++$i;
        }
        $count = DB::fetch_first('SELECT count(*) as num FROM '.DB::table($this->_table).$where);
        return $count['num'];
    }

    public function get_type_reward($start = 0, $limit = null, $sort = '',$type = '',$field = array()) {
        if($sort) {
            $this->checkpk();
        }

        if (!empty($field)) {
            $where = ' where ';
        }else{
            $where = '';
        }

        $i = 1;
        foreach ($field as $key => $value) {
            if ($i == count($field)) {
                $where = $where.' '.$key.' = \''.$value.'\' ';
            }else{
                $where = $where.' '.$key.' = \''.$value.'\' and ';
            }

            ++$i;
        }


        return  DB::fetch_all('SELECT * FROM '.DB::table($this->_table).$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '',array(),'reward_id');

    }

}
//dis'.'m.tao'.'bao.com
?>