<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *		Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_zhanmishu_video_autho extends discuz_table {

	public function __construct() {
		$this->_table = 'zhanmishu_video_autho';
		$this->_pk = 'aid';

		parent::__construct();
	}
	public function get_one_autho_byfield($field){
		if (!empty($field)) {
			$where = ' where ';
			$tmp = array();
			foreach ($field as $key => $value) {
				if (!is_array($value)) {
					$tmp[] = ' '.$key.' = \''.$value.'\' ';
				}else if(is_array($value) &&  $value['relation']){
					switch (trim(strtolower($value['relation']))) {
						case 'like':
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
							break;
						case 'in':
							$tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
							break;
						case 'not in':
							$tmp[] = ' '.$value['key'].' not in '.$value['value'].' ';
							break;
						case 'sql':
							$tmp[] = $value['sql'];
							break;
						default:
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
							break;
					}
				}
			}
			$where .= implode(' and ', $tmp);
		}else{
			$where = '';
		}
		return DB::fetch_first('SELECT * FROM '.DB::table($this->_table).$where.($sort ? ' autho BY '.DB::autho($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}


	public function get_authos_num($field){
		if (!empty($field)) {
			$where = ' where ';
			$tmp = array();
			foreach ($field as $key => $value) {
				if (!is_array($value)) {
					$tmp[] = ' '.$key.' = \''.$value.'\' ';
				}else if(is_array($value) &&  $value['relation']){
					switch (trim(strtolower($value['relation']))) {
						case 'like':
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
							break;
						case 'in':
							$tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
							break;
						case 'not in':
							$tmp[] = ' '.$value['key'].' not in '.$value['value'].' ';
							break;
						case 'sql':
							$tmp[] = $value['sql'];
							break;
						default:
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
							break;
					}
				}
			}
			$where .= implode(' and ', $tmp);
		}else{
			$where = '';
		}
		$count = DB::fetch_first('SELECT count(*) as num FROM '.DB::table($this->_table).$where);
		return $count['num'];
	}


	public function get_type_autho($start = 0, $limit = 0, $sort = '',$type = '',$field) {
		if($sort) {
			$this->checkpk();
		}

		if (!empty($field)) {
			$where = ' where ';
			$tmp = array();
			foreach ($field as $key => $value) {
				if (!is_array($value)) {
					$tmp[] = ' '.$key.' = \''.$value.'\' ';
				}else if(is_array($value) &&  $value['relation']){
					switch (trim(strtolower($value['relation']))) {
						case 'like':
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
							break;
						case 'in':
							$tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
							break;
						case 'not in':
							$tmp[] = ' '.$value['key'].' not in '.$value['value'].' ';
							break;
						case 'sql':
							$tmp[] = $value['sql'];
							break;
						default:
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
							break;
					}
				}
			}
			$where .= implode(' and ', $tmp);
		}else{
			$where = '';
		}
		return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).$where.($sort ? ' autho BY '.DB::autho($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}

	public function get_autho_num_byuidcid($cid,$uid,$device,$isautho='1'){
		if (!$cid || !$uid || !$device) {
			return false;
		}

		return DB::fetch_all('SELECT count(device) as num from %t where uid = %d and cid = %d and isautho=%d group by device',array($this->_table,$uid,$cid,$isautho));
	}

}
//From: Dism��taobao��com
?>