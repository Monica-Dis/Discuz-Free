<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *		Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if (!class_exists('table_zhanmishu_base',false)) {
    C::import('table_zhanmishu_base','plugin/zhanmishu_app/table');
}
class table_zhanmishu_video extends table_zhanmishu_base {

	public function __construct() {
		$this->_table = 'zhanmishu_video';
		$this->_pk = 'vid';

		parent::__construct();
	}
	public function update_islive_by_video_urltype($video_urltype = array(),$limit = 200){
		if (empty($video_urltype)) {
			return false; 
		}
		$video_urltypes = '('.implode(',',$video_urltype).')';

		DB::update($this->_table,array('islive'=>'1'),' video_urltype in '.$video_urltypes.' limit '.$limit);
	}
	public function get_videos_group_by_cid($start, $limit, $sort = '',$field=array()) {
		if($sort) {
			$this->checkpk();
		}

		if (is_array($sort)) {
			$tmp = array();
			foreach ($sort as $key => $value) {
				$tmp[] = DB::order($key, $value);
			}
			$tmp = implode(' , ', $tmp);

			$order = ' ORDER BY '.$tmp;
		}else{
			$order = $sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '';
		}

		if (!empty($field)) {
			$where = ' where ';
			$tmp = array();
			foreach ($field as $key => $value) {
				if (!is_array($value)) {
					$tmp[] = ' '.$key.' = \''.$value.'\' ';
				}else if(is_array($value) &&  $value['relation']){
					switch (trim(strtolower($value['relation']))) {
						case 'like':
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
							break;
						case 'in':
							$tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
							break;
						case 'not in':
							$tmp[] = ' '.$value['key'].' not in '.$value['value'].' ';
							break;
						case 'sql':
							$tmp[] = $value['sql'];
							break;
						default:
							$tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
							break;
					}
				}
			}
			$where .= implode(' and ', $tmp);
		}else{
			$where = '';
		}
		return  DB::fetch_all('SELECT * FROM '.DB::table($this->_table).$where . ' group by cid' .($order).DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
	public function get_one_video_byfield($field, $order=''){
		return self::fetch_one($field, $order);
	}

	public function get_type_video_num($field=array()){
		return self::fetch_num($field);
	}

	public function get_type_video($start, $limit, $sort = '',$type = '',$field) {
		return self::fetch_all($start, $limit, $sort, $field);
	}

}
//From: Dism��taobao��com
?>