<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!class_exists('table_zhanmishu_base',false)) {
    C::import('table_zhanmishu_base','plugin/zhanmishu_app/table');
}
class table_zhanmishu_teacher_info extends table_zhanmishu_base {

    public function __construct() {
        $this->_table = 'zhanmishu_teacher_info';
        $this->_pk = 'uid';

        parent::__construct();
    }


    public function get_one_info_byfield($field){
        return self::fetch_one($field);
    }

    public function get_type_info_num($field=array()){
        return self::fetch_num($field);
    }

    public function get_type_info($start, $limit, $sort = '',$field) {
        return self::fetch_all($start, $limit, $sort = '',$field);
    }

}
//dis'.'m.tao'.'bao.com
?>