<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';
$videoHander = zhanmishu_video::getInstance();

$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_video&pmod=couponAdmin';
$formurl = 'plugins&operation=config&identifier=zhanmishu_video&pmod=couponAdmin';

$perpage=20;
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
echo '<br>';
echo '<br>';


$_GET['method'] = $_GET['method'] ? $_GET['method'] : 'couponAdmin';
$pageAdminItem = array(
    'normal'=>array(
        'menu'=> array(
            array(
                'title'=>lang('plugin/zhanmishu_video','couponEdit'),
                'link'=>$mpurl.'&method=couponEdit',
                'selected'=> $_GET['method'] == 'couponEdit' ? 'selected' : ''
            ),
            array(
                'title'=>lang('plugin/zhanmishu_video','couponAdmin'),
                'link'=>$mpurl.'&method=couponAdmin',
                'selected'=> $_GET['method'] == 'couponAdmin' ? 'selected' : ''
            )
        ),
    )
);
zhanmishu_app_admin::importPureCss();
zhanmishu_app_admin::importJquery();
zhanmishu_app_admin::menuHorizontal($pageAdminItem['normal']['title'],$pageAdminItem['normal']['menu']);

if ($_GET['method'] == 'couponAdmin') {

    $field = array();
    if ($_GET['cid'] > 0) {
        $field['cid'] = $_GET['cid'] + 0;
    }
    if ($_GET['useUid']) {
        $field['useUid'] = $_GET['useUid'] + 0;
    }
    if ($_GET['isUsed'] > 0) {
        $field['isUsed'] = $_GET['isUsed'] == 2 ? 1 : 0;
    }
    if ($_GET['coupon_code']) {
        $field['coupon_code'] = daddslashes($_GET['coupon_code']);
    }

    $num = zhanmishu_video_model_coupon::fetch_num($field);
    $pages= ceil($num / $perpage);
    $start = $num - ($num - $perpage*$curpage+$perpage);
    $coupons = zhanmishu_video_model_coupon::fetch_all_admin_format($start, $perpage, 'desc', $field);

    if (submitcheck('outputsubmit')) {
        ob_end_clean();
        set_time_limit(0);
        $fileName = 'coupon-'.TIMESTAMP;
        header('Content-Encoding: none');
        header('Content-Type: application/vnd.ms-excel');   //header设置
        header("Content-Disposition: attachment;filename=".$fileName.".csv");
        header('Cache-Control: max-age=0');

        $fp = fopen('php://output','a');    //打开php文件句柄，php://output表示直接输出到PHP缓存,a表示将输出的内容追加到文件末尾
        
        for ($i=0; $i < $pages; $i++) {
            if ($i == 0) {
                foreach ($coupons as $key => $value) {
                    if (is_array($value)) {
                         fputcsv($fp, zhanmishu_video::auto_charset_change(zhanmishu_video_model_coupon::outputFormat($value), CHARSET, 'gbk'));
                    }
                }
            }else{
                $starti = $num - ($num - $perpage*($i + 1)+$perpage);
                $couponsi = zhanmishu_video_model_coupon::fetch_all_admin_format($starti, $perpage, 'desc', $field);
                foreach ($couponsi as $key => $value) {
                    if (is_array($value)) {
                         fputcsv($fp, zhanmishu_video::auto_charset_change(zhanmishu_video_model_coupon::outputFormat($value), CHARSET, 'gbk'));
                    }
                }
            }
        }
        exit();
    }

    showtips(lang('plugin/zhanmishu_video', 'couponTips'),'',true,lang('plugin/zhanmishu_video', 'couponTipsTitle'));

    showtableheader(); /*dism·taobao·com*/

    showformheader('plugins&operation=config&identifier=zhanmishu_video&pmod=couponAdmin&method=couponAdmin');
    $_G['showsetting_multirow'] = 1;
    $_G['showsetting_multirow_n'] = 0;
    showsetting(
        lang('plugin/zhanmishu_video','isUsed'), 
        array('isUsed', array(
            array(0, lang('plugin/zhanmishu_video', 'all')),
            array(1, lang('plugin/zhanmishu_video', 'isUsed_0')),
            array(2, lang('plugin/zhanmishu_video', 'isUsed_1'))
            )
        ), $_GET['isUsed'], 'select');
    showsetting(lang('plugin/zhanmishu_video', 'coupon_code'), 'coupon_code', $_GET['coupon_code'], 'text');
    showsetting(lang('plugin/zhanmishu_video', 'cid_limit'), 'cid', $_GET['cid'], 'text');
    showsetting(lang('plugin/zhanmishu_video', 'useUid_limit'), 'useUid', $_GET['useUid'], 'text');
    showsubmit('searchsubmit', lang('plugin/zhanmishu_video', 'searchsubmit'));
    showtablefooter(); /*Dism_taobao-com*/


    showformheader($formurl.'&method=couponAdmin','enctype="multipart/form-data"');
    showtableheader(lang('plugin/zhanmishu_video','index_item_intro'));
    showsubtitle(array(
        lang('plugin/zhanmishu_video', 'couponid'),
        lang('plugin/zhanmishu_video', 'course_name'),
        lang('plugin/zhanmishu_video', 'uid'),
        lang('plugin/zhanmishu_video', 'coupon_name'),
        lang('plugin/zhanmishu_video', 'coupon_code'),
        lang('plugin/zhanmishu_video', 'coupon_price'),
        lang('plugin/zhanmishu_video', 'coupon_price_limit'),
        lang('plugin/zhanmishu_video', 'useUid'),
        lang('plugin/zhanmishu_video', 'isLock'),
        lang('plugin/zhanmishu_video', 'isUsed'),
        lang('plugin/zhanmishu_video', 'dateline'),
        lang('plugin/zhanmishu_video', 'use_time'),
        lang('plugin/zhanmishu_video', 'expire_time'),
        lang('plugin/zhanmishu_video', 'act')
    ));
    foreach ($coupons as $key => $value) {
        showtablerow('class="partition"',array('class="td25"', 'class="td25"', 'class="td28"'),$value);
    }

    $multi = multi($num, $perpage, $curpage, $mpurl, '0', '10');
    showtablefooter(); /*Dism_taobao-com*/
    echo $multi;
    showsubmit('outputsubmit', lang('plugin/zhanmishu_video', 'output', array('number'=>$num)));
    showformfooter(); /*dis'.'m.tao'.'bao.com*/  
}else if ($_GET['method'] == 'couponDelete') {
    if ($_GET['formhash'] == formhash()) {
        $coupon = zhanmishu_video_model_coupon::delete($_GET['couponid'] + 0);
        cpmsg(lang('plugin/zhanmishu_video', 'success'),dreferer(),'success');
    }
}else if ($_GET['method'] == 'couponEdit') {
    if (submitcheck('editCouponSubmit')) {    
        if ($_GET['couponid']) {
            $coupon['couponid'] = $_GET['couponid'] + 0;
            $coupon = zhanmishu_video_model_coupon::fetch($_GET['couponid'] + 0);
        }else{
            $coupon = array();
        }
        $coupon['cid'] = $_GET['cid'] + 0;
        
        if (is_numeric($_GET['useUid'])) {
            $coupon['useUid'] = $_GET['useUid'] + 0;
        }else if($_GET['useUid']){
            loaducenter();
            if($data = uc_get_user(daddslashes($_GET['useUid']))) {
                list($useUid, $username, $email) = $data;
                $coupon['useUid'] = $useUid;
            } else {
                cpmsg(lang('plugin/zhanmishu_video', 'user_is_notexists'),'','error');

            }
        }
        $coupon['coupon_number'] =$_GET['coupon_number'] ? $_GET['coupon_number'] + 0 : 1;

        $coupon['coupon_name'] = daddslashes($_GET['coupon_name']);
        $coupon['coupon_price'] = ceil($_GET['coupon_price'] * 100);
        $coupon['coupon_price_limit'] = ceil($_GET['coupon_price_limit'] * 100);
        $coupon['uid'] = $_G['uid'];
        $coupon['dateline'] = TIMESTAMP;
        if ($_GET['expire_time'] > 0) {
            $coupon['expire_time'] = ($_GET['expire_time'] * 24 * 3600) + strtotime(dgmdate(TIMESTAMP, 'd'));
        }else{
            $coupon['expire_time'] = 0;
        }

        if ($coupon['couponid']) {
            zhanmishu_video_model_coupon::insert($coupon);
        }else{
            for ($i=0; $i < $coupon['coupon_number']; $i++) {
                $coupon['coupon_code'] = zhanmishu_course::randCouponCode();
                zhanmishu_video_model_coupon::insert($coupon);
            }
        }
    
        cpmsg(lang('plugin/zhanmishu_video', 'success'),'action=plugins&operation=config&identifier=zhanmishu_video&pmod=couponAdmin&method=couponAdmin','success');
    }

    if ($_GET['couponid']) {
        $coupon = zhanmishu_video_model_coupon::fetch($_GET['couponid'] + 0, true);
    }
    showformheader($formurl.'&method=couponEdit','enctype="multipart/form-data"');
    showtableheader(); /*dism·taobao·com*/
    if ($coupon['couponid']) {
        showsetting(lang('plugin/zhanmishu_video', 'couponid'), 'couponid', $coupon['couponid'], 'text','','',lang('plugin/zhanmishu_video', 'couponid_desc'),'size="10"');
    }
    showsetting(lang('plugin/zhanmishu_video', 'coupon_name'), 'coupon_name', $coupon['coupon_name'], 'text','','',lang('plugin/zhanmishu_video', 'coupon_name_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'coupon_price'), 'coupon_price', $coupon['coupon_price'], 'text','','',lang('plugin/zhanmishu_video', 'coupon_price_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'coupon_price_limit'), 'coupon_price_limit', $coupon['coupon_price_limit'], 'text','','',lang('plugin/zhanmishu_video', 'coupon_price_limit_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'coupon_number'), 'coupon_number', $coupon['coupon_number'], 'text','','',lang('plugin/zhanmishu_video', 'coupon_number_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'cid'), 'cid', $coupon['cid'], 'text','','',lang('plugin/zhanmishu_video', 'coupon_cid_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'useUid'), 'useUid', $coupon['useUid'], 'text','','',lang('plugin/zhanmishu_video', 'useUid_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'expire_time'), 'expire_time', $coupon['expire_time'], 'text','','',lang('plugin/zhanmishu_video', 'expire_time_desc'),'size="10"');
    // showsetting(lang('plugin/zhanmishu_video', 'tagids'), 'tagids', $coupon['tagids'], 'text', '','',lang('plugin/zhanmishu_video', 'tid_desc'),'size="10"');
    // showsetting(lang('plugin/zhanmishu_video', 'invitedes'), 'invitedes', $coupon['invitedes'], 'text', '','',lang('plugin/zhanmishu_video', 'invitedes_desc'),'size="10"');
    // showsetting(lang('plugin/zhanmishu_video', 'invites'), 'invites', $coupon['invites'], 'text','','',lang('plugin/zhanmishu_video', 'invites_desc'),'size="10"');
    showsubmit('editCouponSubmit');
    showtablefooter(); /*Dism_taobao-com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/

}
