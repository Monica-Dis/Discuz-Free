<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/function/common_function.php';
$videoHander = zhanmishu_video::getInstance();

$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_video&pmod=pcadmin';
$formurl = 'plugins&operation=config&identifier=zhanmishu_video&pmod=pcadmin';

$_GET['act'] = $_GET['act'] ? $_GET['act'] : 'swiper';
echo '<br>';
echo '<br>';
zms_showtitle(lang('plugin/zhanmishu_video', 'pcadmin'),array(
    array(lang('plugin/zhanmishu_video', 'swiper'),$formurl.'&act=swiper',$_GET['act'] =='swiper'?'1':'0'),
    // array(lang('plugin/zhanmishu_video', '�Ƽ�����'),$formurl.'&act=recommend',$status = $input['act'] =='recommend'?'1':'0'),
    array(lang('plugin/zhanmishu_video', 'best_recommend'),$formurl.'&act=best',$_GET['act'] =='best'?'1':'0')
));


if (submitcheck('sb_editswiper')) {
    $images = zhanmishu_video::uploadimg();

    $swiper = array();
    foreach ($_GET['urlType'] as $key => $value) {
        if (in_array($key, $_GET['delete'])) {
            continue;
        }
        $swiper[] = array(
            'name'=>$_GET['name'][$key],
            'image'=> $images[$key] ? $images[$key] : $_GET['image'][$key],
            'cid'=>$_GET['cid'][$key],
            'url'=>$_GET['url'][$key],
            'urlType'=>$_GET['urlType'][$key],
            'platform'=>$_GET['platform'][$key]
        );
    }

    $videoHander->update_pc_swipercache_init($swiper);
    cpmsg(lang('plugin/zhanmishu_video', 'update_swiper_success'),dreferer(),'success');

}else if (submitcheck('sb_editbest')) {
    $images = zhanmishu_video::uploadimg();
    $best = array();
    foreach ($_GET['cid'] as $key => $value) {
        if (in_array($key, $_GET['delete'])) {
            continue;
        }
        $c = $videoHander->get_course_bycid($_GET['cid'][$key]);
        if (empty($c) || !$c) {
            cpmsg(lang('plugin/zhanmishu_video', 'cid_isnot_exists'),dreferer(),'error');
        }

        $best[] = array(
            'cid'=>$_GET['cid'][$key],
            'image'=> $images[$key] ? $images[$key] : $_GET['image'][$key],
        );
    }
    $videoHander->update_pc_bestcache_init($best);

    cpmsg(lang('plugin/zhanmishu_video', 'update_best_success'),dreferer(),'success');
}else{
    if ($_GET['act'] == 'swiper') {
        $swiper = $videoHander->get_pc_swiper();
        showformheader($formurl.'&act=editcat','enctype="multipart/form-data"');
        showtableheader(lang('plugin/zhanmishu_video','swiper'));
        showsubtitle(array(
            lang('plugin/zhanmishu_video', 'delete'),
            //lang('plugin/zhanmishu_video', '���'),
            lang('plugin/zhanmishu_video', 'swiper_name'),
            lang('plugin/zhanmishu_video', 'imgurl'),
            lang('plugin/zhanmishu_video', 'url')
        ));

        foreach ($swiper as $key => $value) {
            $value['id'] = $key;
            $linkTypeSelect = array(
                $value['urlType'] == '0' ? ' selected' : '',
                $value['urlType'] == '1' ? ' selected' : '',
            );
            // ѡ��״̬
            $recommendType = array(
                $value['platform'] == '0' ? ' selected' : '',
                $value['platform'] == '1' ? ' selected' : '',
                $value['platform'] == '2' ? ' selected' : '',
                $value['platform'] == '3' ? ' selected' : '',
            );

            $image = $value['image'] ? $value['image'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
            $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'
            <select name="urlType['.$value['id'].']">
                <option value ="0" '.$linkTypeSelect[0].'>'.lang('plugin/zhanmishu_app', 'URL').'</option>
                <option value ="1" '.$linkTypeSelect[1].'>'.lang('plugin/zhanmishu_app', 'appPage').'</option>
            </select>';
            $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform['.$value['id'].']">
                    <option value ="0" '.$recommendType[0].'>'.lang('plugin/zhanmishu_app', 'public').'</option>
                    <option value ="1" '.$recommendType[1].'>'.lang('plugin/zhanmishu_app', 'H5').'</option>
                    <option value ="2" '.$recommendType[2].'>'.lang('plugin/zhanmishu_app', 'minapp').'</option>
                    <option value ="3" '.$recommendType[3].'>'.lang('plugin/zhanmishu_app', 'app').'</option>
                </select>';

            showformheader($formurl.'&act=editcat','enctype="multipart/form-data"');
                $videoHanderarr = array(
                '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                '<input type="text" required class="txt" name="name['.$value['id'].']" value="'.$value['name'].'" />',
                '<img src="'.$image.'" width="40px" height="40px"><input type="text" required class="txt" style="width:100px;" name="image['.$value['id'].']" placeholder="'.lang('plugin/zhanmishu_app','image_placeholder').'" value="'.$value['image'].'" />
                <input style="width:140px" type="file"  name="image_file['.$value['id'].']" value="" />',
                '<input type="hidden"  name="cid['.$value['id'].']" value="'.$value['cid'].'" />
                <input type="text" required  name="url['.$value['id'].']" value="'.$value['url'].'" />'.$urlType
            );
            showtablerow('',array('class="td25"', 'class="td25"', 'class="td25"', 'class="td25"', 'class="td25"'), $videoHanderarr);

        }
        echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_video', 'addswiper').'</a></div></tr>';

        showsubmit('sb_editswiper',lang('plugin/zhanmishu_video', 'submit'));

        showtablefooter(); /*Dism_taobao-com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/   

        $image = 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
        $placeholder = lang('plugin/zhanmishu_app','image_placeholder');
        $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'<select name="urlType[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'URL').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'appPage').'</option></select>';
        $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'public').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'H5').'</option><option value ="2">'.lang('plugin/zhanmishu_app', 'minapp').'</option><option value ="3">'.lang('plugin/zhanmishu_app', 'app').'</option></select>';
    echo <<<EOT
    <script type="text/JavaScript">
        var rowtypedata = [
            [
                [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                [1,'<input type="text" required class="txt" name="name[]" value="">', 'td25'],
                [1,'<img src="{$image}" width="40px" height="40px"><input type="text" required class="txt" style="width:100px;" name="image[]" placeholder="{$placeholder}" value="" /><input style="width:140px" type="file"  name="image_file[]" value="" />', 'td22'],
                [1,'<input type="text" required class="" name="url[]" value="">{$urlType}', 'td22']

            ]
            
        ];
    </script>
EOT;

    }else if ($_GET['act'] =='best') {
        showformheader($formurl.'&act=editbest','enctype="multipart/form-data"');
        showtableheader(lang('plugin/zhanmishu_video','edit_best_recommend'));
        showsubtitle(array(
            lang('plugin/zhanmishu_video', 'delete'),
            lang('plugin/zhanmishu_video', 'bestimg'),
            lang('plugin/zhanmishu_video', 'cid'),
        ));

        $best = $videoHander->get_pc_best();
        foreach ($best as $key => $value) {
            $linkTypeSelect = array(
                $value['urlType'] == '0' ? ' selected' : '',
                $value['urlType'] == '1' ? ' selected' : '',
            );
            // ѡ��״̬
            $recommendType = array(
                $value['platform'] == '0' ? ' selected' : '',
                $value['platform'] == '1' ? ' selected' : '',
                $value['platform'] == '2' ? ' selected' : '',
                $value['platform'] == '3' ? ' selected' : '',
            );

            $image = $value['image'] ? $value['image'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
            showformheader($formurl.'&act=editcat','enctype="multipart/form-data"');
                $videoHanderarr = array(
                '<input type="checkbox" class="txt" name="delete['.$key.']" value="'.$key.'" '.$protected.' />',
                '<img src="'.$image.'" width="40px" height="40px"><input type="text" required class="txt" style="width:100px;" name="cat_icon['.$value['id'].']" placeholder="'.lang('plugin/zhanmishu_app','image_placeholder').'" value="'.$value['image'].'" />
                <input style="width:140px" type="file"  name="image_file['.$value['id'].']" value="" />',
                '<input type="text" required class="txt" name="cid['.$key.']" value="'.$value['cid'].'" />',
            );
            showtablerow('',array('class="td25"','class="td25"', 'class="td25"', 'class="td25"'), $videoHanderarr);
        }


        echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_video', 'addbestrecommend').'</a></div></tr>';


        showsubmit('sb_editbest',lang('plugin/zhanmishu_video', 'submit'));

        showtablefooter(); /*Dism_taobao-com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
        $image = 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
        $placeholder = lang('plugin/zhanmishu_app','image_placeholder');
    echo <<<EOT
    <script type="text/JavaScript">
        var rowtypedata = [
            [
                [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                [1,'<img src="{$image}" width="40px" height="40px"><input type="text" class="txt" style="width:100px;" name="image[]" placeholder="{$placeholder}" value="" /><input style="width:140px" type="file"  name="image_file[]" value="" />', 'td22'],
                [1,'<input type="text" required class="txt" name="cid[]" value="">', 'td25'],
            ]
            
        ];
    </script>
EOT;


    }




}
//From: Dism��taobao��com
?>