<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT.'./source/function/function_admincp.php';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/function/common_function.php';
$rewrite = zhanmishu_video::getInstance();
if (submitcheck('rewritesubmit')) {
	$rewrite->ZmswriteToCache('rewriteRule',$_GET['rule']);
}

$rulesearch = $rewrite->ZmsGetFromCache('rewriteRule');


showformheader('plugins&operation=config&do=59&identifier=zhanmishu_video&pmod=rewrite');
showtableheader(lang('plugin/zhanmishu_video', 'rewritesubmit'));
	showsubtitle(array(
		lang('plugin/zhanmishu_video', lang('plugin/zhanmishu_video','page')),
		lang('plugin/zhanmishu_video', lang('plugin/zhanmishu_video','mark')),
		lang('plugin/zhanmishu_video', lang('plugin/zhanmishu_video','rule')),
		//lang('plugin/zhanmishu_video', lang('plugin/zhanmishu_video','isopen'))
	));

$videoindex = $rulesearch['videoindex'] ? $rulesearch['videoindex'] : 'course';
$videolist = $rulesearch['videolist'] ? $rulesearch['videolist'] : 'course/cat_{cat}/diff_{diff}/vip_{vip}/order_{order}';
$coursepage = $rulesearch['coursepage'] ? $rulesearch['coursepage'] : 'course/{cid}';
$course_videopage = $rulesearch['course_videopage'] ? $rulesearch['course_videopage'] : 'course/{cid}/{vid}';


showtablerow('', array('class="td25"', 'class="td31"','class="longtxt"'), array(
					'<div class="td31">'.lang('plugin/zhanmishu_video','videoindex').'</div>',
					'<div class="td31"></div>',
					'<div class="longtxt"><input type="text" class="longtxt" name="rule[videoindex]" value="'.$videoindex.'" /></div>',
					//'<div class="td25"><input type="checkbox" name="isopen[videoindex]" value="" /></div>',
				));
showtablerow('', array('class="td25"', 'class="td31"','class="longtxt"'), array(
					'<div class="td31">'.lang('plugin/zhanmishu_video','videolist').'</div>',
					'<div class="td31">{cat}{diff}{vipgroupid}{order}</div>',
					'<div class="longtxt"><input type="text" class="longtxt" name="rule[videolist]" value="'.$videolist.'" /></div>',
					//'<div class="td25"><input type="checkbox" name="isopen[videolist]" value="" /></div>',
				));
showtablerow('', array('class="td25"', 'class="td31"','class="longtxt"'), array(
					'<div class="td31">'.lang('plugin/zhanmishu_video','coursepage').'</div>',
					'<div class="td31">{cid}</div>',
					'<div class="longtxt"><input type="text" class="longtxt" name="rule[coursepage]" value="'.$coursepage.'" /></div>',
					//'<div class="td25"><input type="checkbox" name="isopen[coursepage]" value="" /></div>',
				));
showtablerow('', array('class="td25"', 'class="td31"','class="longtxt"'), array(
					'<div class="td31">'.lang('plugin/zhanmishu_video','course_videopage').'</div>',
					'<div class="td31">{cid}{vid}</div>',
					'<div class="longtxt"><input type="text" class="longtxt" name="rule[course_videopage]" value="'.$course_videopage.'" /></div>',
					//'<div class="td25"><input type="checkbox" name="isopen[course_videopage]" value="" /></div>',
				));
	showsubmit('rewritesubmit',lang('plugin/zhanmishu_video', 'submit'));
showtablefooter(); /*Dism_taobao-com*/
showformfooter(); /*dis'.'m.tao'.'bao.com*/	


$rule = $rulesearch;
$videoindex = $rule['videoindex'] ? $rule['videoindex'] : 'course';
$videolist = $rule['videolist'] ? $rule['videolist'] : 'course/cat_{cat}/diff_{diff}/vip_{vip}/order_{order}';
$coursepage = $rule['coursepage'] ? $rule['coursepage'] : 'course/{cid}';
$course_videopage = $rule['course_videopage'] ? $rule['course_videopage'] : 'course/{cid}/{vid}';

$rewritedata = array('rulesearch' => array
        (
            'course_videopage' => $course_videopage,
            'coursepage' => $coursepage,
            'videolist' => $videolist,
            'videoindex' => $videoindex, 
        ),

    'rulereplace' => array
        (
            'course_videopage' => 'plugin.php?id=zhanmishu_video:video&mod=video&cid={cid}&vid={vid}',
            'coursepage' => 'plugin.php?id=zhanmishu_video:video&mod=video&cid={cid}',
            'videolist' => 'plugin.php?id=zhanmishu_video:video&cat_id={cat}&diff={diff}&groupselect={vip}&order={order}',
            'videoindex' => 'plugin.php?id=zhanmishu_video:video',
        ),

    'rulevars' => array
        (
            'course_videopage' => array
                (
                	'{cid}'=>'([0-9]+)',
                	'{vid}'=>'([0-9]+)',
                ),
            'videoindex' => array
                (
                ),
            'videolist' => array
                (
                    '{cat}'=>'([0-9]+)',
                    '{diff}'=>'([0-9]+)',
                    '{vip}'=>'([0-9]+)',
                    '{order}'=> '(\w+)'
                ),
            'coursepage' => array
                (
                    '{cid}'=>'([0-9]+)',
                ),
        ),

);
$rule['{apache1}'] = $rule['{apache2}'] = $rule['{iis}'] = $rule['{iis7}'] = $rule['{zeus}'] = $rule['{nginx}'] = '';



foreach($rewritedata['rulesearch'] as $k => $v) {

	$v = !$_G['setting']['rewriterule'][$k] ? $v : $_G['setting']['rewriterule'][$k];
	$pvmaxv = count($rewritedata['rulevars'][$k]) + 2;
	$vkeys = array_keys($rewritedata['rulevars'][$k]);
	$rewritedata['rulereplace'][$k] = pvsort($vkeys, $v, $rewritedata['rulereplace'][$k]);
	$v = str_replace($vkeys, $rewritedata['rulevars'][$k], addcslashes($v, '?*+^$.[]()|'));
	$rule['{apache1}'] .= "\t".'RewriteCond %{QUERY_STRING} ^(.*)$'."\n\t".'RewriteRule ^(.*)/'.$v.'$ $1/'.pvadd($rewritedata['rulereplace'][$k])."&%1\n";
	if($k != 'forum_archiver') {
		$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^'.$v.'$ '.$rewritedata['rulereplace'][$k]."&%1\n";
	} else {
		$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^archiver/'.$v.'$ archiver/'.$rewritedata['rulereplace'][$k]."&%1\n";
	}
	$rule['{iis}'] .= 'RewriteRule ^(.*)/'.$v.'(\?(.*))*$ $1/'.addcslashes(pvadd($rewritedata['rulereplace'][$k]).'&$'.($pvmaxv + 1), '.?')."\n";
	$rule['{iis7}'] .= "\t\t".'&lt;rule name="'.$k.'"&gt;'."\n\t\t\t".'&lt;match url="^(.*/)*'.str_replace('\.', '.', $v).'\?*(.*)$" /&gt;'."\n\t\t\t".'&lt;action type="Rewrite" url="{R:1}/'.str_replace(array('&', 'page\%3D'), array('&amp;amp;', 'page%3D'), addcslashes(pvadd($rewritedata['rulereplace'][$k], 1).'&{R:'.$pvmaxv.'}', '?')).'" /&gt;'."\n\t\t".'&lt;/rule&gt;'."\n";
	$rule['{zeus}'] .= 'match URL into $ with ^(.*)/'.$v.'\?*(.*)$'."\n".'if matched then'."\n\t".'set URL = $1/'.pvadd($rewritedata['rulereplace'][$k]).'&$'.$pvmaxv."\nendif\n";
	

	$rule['{nginx}'] .= 'rewrite ^([^\.]*)/'.$v.'$ $1/'.stripslashes(pvadd($rewritedata['rulereplace'][$k]))." last;\n";


}

echo str_replace(array_keys($rule), $rule, cplang('rewrite_message'));


function pvsort($key, $v, $s) {
	$r = '/';
	$p = '';
	foreach($key as $k) {
		$r .= $p.preg_quote($k);
		$p = '|';
	}
	$r .= '/';
	preg_match_all($r, $v, $a);
	$a = $a[0];
	$a = array_flip($a);
	foreach($a as $key => $value) {
		$s = str_replace($key, '$'.($value + 1), $s);
	}
	return $s;
}

function pvadd($s, $t = 0) {
	$s = str_replace(array('$4', '$3', '$2', '$1'), array('~5', '~4', '~3', '~2'), $s);
	if(!$t) {
		return str_replace(array('~5','~4', '~3', '~2'), array('$5','$4', '$3', '$2'), $s);
	} else {
		return str_replace(array('~5', '~4', '~3', '~2'), array('{R:5}','{R:4}', '{R:3}', '{R:2}'), $s);
	}

}

function checkfiles($currentdir, $ext = '', $sub = 1, $skip = '') {
	global $md5data;
	$dir = @opendir(DISCUZ_ROOT.$currentdir);
	$exts = '/('.$ext.')$/i';
	$skips = explode(',', $skip);

	while($entry = @readdir($dir)) {
		$file = $currentdir.$entry;
		if($entry != '.' && $entry != '..' && (($ext && preg_match($exts, $entry) || !$ext) || $sub && is_dir($file)) && !in_array($entry, $skips)) {
			if($sub && is_dir($file)) {
				checkfiles($file.'/', $ext, $sub, $skip);
			} else {
				if(is_dir($file)) {
					$md5data[$file] = md5($file);
				} else {
					$md5data[$file] = md5_file($file);
				}
			}
		}
	}
}

function checkcachefiles($currentdir) {
	global $_G;
	$dir = opendir($currentdir);
	$exts = '/\.php$/i';
	$showlist = $modifylist = $addlist = array();
	while($entry = readdir($dir)) {
		$file = $currentdir.$entry;
		if($entry != '.' && $entry != '..' && preg_match($exts, $entry)) {
			$fp = fopen($file, "rb");
			$cachedata = fread($fp, filesize($file));
			fclose($fp);

			if(preg_match("/^<\?php\n\/\/Discuz! cache file, DO NOT modify me!\n\/\/Identify: (\w+)\n\n(.+?)\?>$/s", $cachedata, $match)) {
				$showlist[$file] = $md5 = $match[1];
				$cachedata = $match[2];

				if(md5($entry.$cachedata.$_G['config']['security']['authkey']) != $md5) {
					$modifylist[$file] = $md5;
				}
			} else {
				$showlist[$file] = '';
			}
		}
	}

	return array($showlist, $modifylist, $addlist);
}

function checkmailerror($type, $error) {
	global $alertmsg;
	$alertmsg .= !$alertmsg ? $error : '';
}

function getremotefile($file) {
	global $_G;
	@set_time_limit(0);
	$file = $file.'?'.TIMESTAMP.rand(1000, 9999);
	$str = @implode('', @file($file));
	if(!$str) {
		$str = dfsockopen($file);
	}
	return $str;
}







?>