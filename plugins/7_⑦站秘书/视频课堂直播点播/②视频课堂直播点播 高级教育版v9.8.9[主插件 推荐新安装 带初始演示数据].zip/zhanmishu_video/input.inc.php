<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/function/common_function.php';

$action = $_GET['act'] ? daddslashes($_GET['act']) : 'admin';
$url = 'plugins&operation=config&identifier=zhanmishu_video&pmod=input';
$videoHander = zhanmishu_video::getInstance();

$perpage=20;
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;

if ($action == 'adminvideo' && $_GET['cid']) {
	$addarray = array(lang('plugin/zhanmishu_video', 'add_video'),$url.'&act=adminvideo&m=add&cid='.$_GET['cid'],$status = $action =='add'?'1':'0');
}else{
	$addarray = array(lang('plugin/zhanmishu_video', 'add_course'),$url.'&act=add',$status = $action =='add'?'1':'0');
}
echo '<br>';
echo '<br>';
zms_showtitle(lang('plugin/zhanmishu_video', 'course_admin'),array(
	$addarray,
	array(lang('plugin/zhanmishu_video', 'course_admin'),$url.'&act=admin',$status = $action =='admin'?'1':'0'),
	array(lang('plugin/zhanmishu_video', 'course_column_admin'),$url.'&act=course_column_admin',$status = $action =='course_column_admin'?'1':'0'),
	array(lang('plugin/zhanmishu_video', 'order_admin'),$url.'&act=order',$status = $action =='order'?'1':'0'),
	array(lang('plugin/zhanmishu_video', 'setvipbyhand'),$url.'&act=setvipbyhand',$status = $action =='setvipbyhand'?'1':'0')
));
if ($action =='add') {

	if (submitcheck('course_addsubmit')) {
		$images = zms_uploadimg();


		if ($_GET['cid']) {
			$cid = $_GET['cid'] + 0;
			$course = C::t("#zhanmishu_video#zhanmishu_video_course")->fetch($cid);
		}else{
			$course = array();
		}

		$course['course_img'] = $images['course_img'] ? daddslashes($images['course_img']) : daddslashes($_GET['course_img']);
		$course['site_sign_img1'] = $images['site_sign_img1'] ? daddslashes($images['site_sign_img1']) : daddslashes($_GET['site_sign_img1']);
		$course['site_sign_img2'] = $images['site_sign_img2'] ? daddslashes($images['site_sign_img2']) : daddslashes($_GET['site_sign_img2']);


		if (isset($course['views'])) {
			$course['views'] =  $course['views'] ? $course['views'] : 0;
			$course['views_add'] =  $course['views_add'] ? $course['views_add'] : 0;
			$course['views_add'] = $_GET['views'] - $course['views'] + $course['views_add'];
			$course['views'] = $_GET['views'] + 0;
		}
		if (isset($course['learns'])) {
			$course['learns'] = $course['learns'] ? $course['learns'] : 0;
			$course['learns_add'] = $course['learns_add'] ? $course['learns_add'] : 0;
			$course['learns_add'] = $_GET['learns'] - $course['learns'] + $course['learns_add'];
			$course['learns'] = $_GET['learns'] + 0;
		}

		if ($_GET['course_teacher']) {
			if ((intval($course['course_teacher']) == $course['course_teacher']) && $course['course_teacher']) {
				$course['uid'] = $_GET['course_teacher'] + 0;
			}else{
				$course_teacher = daddslashes($_GET['course_teacher']);
				loaducenter();
				if($data = uc_get_user($course_teacher)) {
					list($uid, $username, $email) = $data;
					$course['uid'] = $uid;
				} else if ($user = C::t('common_member')->fetch_by_username($course_teacher)) {
					$course['uid'] = $user['uid'];
				}else {
					cpmsg(lang('plugin/zhanmishu_video', 'course_teacher_isnot_exists'),'','error');

				}
			}
			
		}else{
			$course['uid'] = $_G['uid'];
		}
		$course['course_name'] = daddslashes($_GET['course_name']);
		$course['live_url'] = daddslashes($_GET['live_url']);
		$course['course_type'] = $_GET['course_type'] + 0;

		$course['course_group'] = $_GET['course_group'];
		$course['course_group'] = $course['course_group'] = zhanmishu_course::settingNumberFormat($course['course_group'], 'string');

		//trim($course['course_group'],'#')

		$course['course_weight'] = $_GET['course_weight'] + 0;
		$course['course_intro'] = daddslashes($_GET['course_intro']);
		$course['course_price'] = intval($_GET['course_price'] * 100);
		$course['dateline'] = TIMESTAMP;
		$course['diff'] = $_GET['diff'] + 0;
		$course['ProfileID'] = $_GET['ProfileID'] + 0; 
		$course['drmnums'] = $_GET['drmnums'] + 0; 
		$course['baiduurl'] = daddslashes($_GET['baiduurl']); 
		$course['fileurl'] = daddslashes($_GET['fileurl']); 
		$course['baiduurlpwd'] = daddslashes($_GET['baiduurlpwd']); 
		// $course['360url'] = $input['360url']; 
		// $course['360urlpwd'] = $input['360urlpwd']; 
		$course['rarpwd'] = daddslashes($_GET['rarpwd']); 
		// $course['yourproductid'] = $input['yourproductid'];
		$course['progress'] = daddslashes($_GET['progress']);
		if (!$course['course_name'] || !$course['course_intro']) {
			cpmsg(lang('plugin/zhanmishu_video', 'must_finish_info'),'','error');
		}

		if ($_GET['cat_id']) {
			$course['cat_id'] = $_GET['cat_id'] + 0;
		}
		$isreplace = $course['cid'] ? true : false;
		$cid = C::t("#zhanmishu_video#zhanmishu_video_course")->insert($course,true,$isreplace);

		if ($isreplace) {
			C::t("#zhanmishu_video#zhanmishu_video_order")->update_ordertype_bycid($course['cid'],$course['course_type']);
		}

		cpmsg(lang('plugin/zhanmishu_video', 'add_course_success_and_add_video'),'action=plugins&operation=config&identifier=zhanmishu_video&pmod=input&act=admin','success');

		
	}else{

		$groupselect = array();
		$query = C::t('common_usergroup')->range();
		foreach($query as $group) {
			if (in_array($group['groupid'], array(4,5,6,7))) {
				continue;
			}
			$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
			if($group['type'] == 'member' && $group['creditshigher'] == 0) {
				$groupselect[$group['type']] .= "<option value=\"$group[groupid]\">$group[grouptitle]</option>\n";
			} else {
				$groupselect[$group['type']] .= "<option value=\"$group[groupid]\">$group[grouptitle]</option>\n";
			}
		}
		$groupselect = '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
			($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
			($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
			'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup>';


		showformheader($url.'&act=add','enctype="multipart/form-data"');
		showtableheader(); /*dism·taobao·com*/
		showsetting(lang('plugin/zhanmishu_video', 'course_name'), 'course_name', '', 'text','','',lang('plugin/zhanmishu_video', 'course_name_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_weight'), 'course_weight', $course['course_weight'], 'text','','',lang('plugin/zhanmishu_video', 'course_weight_desc'),'size="10"');

		showsetting(lang('plugin/zhanmishu_video', 'course_price'), 'course_price', '', 'text','','',lang('plugin/zhanmishu_video', 'course_price_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_teacher'), 'course_teacher', '', 'text','','',lang('plugin/zhanmishu_video', 'course_teacher_desc'),'size="10"');
		// showsetting(lang('plugin/zhanmishu_video', 'live_url'), 'live_url', '', 'textarea','','',lang('plugin/zhanmishu_video', 'live_url_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_type'), array('course_type',array(array('0',$zhanmishu_videoconf['course_type']['0']),array('1',$zhanmishu_videoconf['course_type']['1']))), $v['course_type'], 'mradio','','',lang('plugin/zhanmishu_video', 'course_type_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_group'), 'course_group', '', '<select name="course_group[]"  multiple="multiple" size="10">'.$groupselect.'</select><td class="vtop tips2" s="1">'.lang('plugin/zhanmishu_video','course_group_desc').'</td>');

		$diff_sellect = array();
		foreach ($zhanmishu_videoconf['diff'] as $key => $value) {
			$diff_sellect[] = array($key,$value);
		}
		showsetting(lang('plugin/zhanmishu_video', 'diff'), array('diff',$diff_sellect), $v['diff'], 'mradio','','',lang('plugin/zhanmishu_video', 'isfree_desc'),'size="10"');
		foreach ($zhanmishu_videoconf['progress'] as $key => $value) {
			$progress_sellect[] = array($key,$value);
		}
		showsetting(lang('plugin/zhanmishu_video', 'progress'), array('progress',$progress_sellect), $v['progress'], 'mradio','','',lang('plugin/zhanmishu_video', 'isfree_desc'),'size="10"');
		$video_cat = $videoHander->get_cat_select();
		showsetting(lang('plugin/zhanmishu_video', 'cat_id'), array('cat_id',$video_cat), $v['cat_id'], 'mradio','','',lang('plugin/zhanmishu_video', 'isfree_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_img'), 'course_img', '', 'filetext','','',lang('plugin/zhanmishu_video', 'course_img_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'site_sign_img1'), 'site_sign_img1', '', 'filetext','','',lang('plugin/zhanmishu_video', 'site_sign_img1_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'site_sign_img2'), 'site_sign_img2', '', 'filetext','','',lang('plugin/zhanmishu_video', 'site_sign_img2_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_intro'), 'course_intro', '', 'textarea','','',lang('plugin/zhanmishu_video', 'course_intro_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'views'), 'views', '', 'text','','',lang('plugin/zhanmishu_video', 'views_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'learns'), 'learns', '', 'text','','',lang('plugin/zhanmishu_video', 'learns_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'ProfileID'), 'ProfileID', '', 'text','','',lang('plugin/zhanmishu_video', 'ProfileID_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'drmnums'), 'drmnums', '', 'text','','',lang('plugin/zhanmishu_video', 'drmnums_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'fileurl'), 'fileurl', '', 'text','','',lang('plugin/zhanmishu_video', 'fileurl_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'baiduurl'), 'baiduurl', '', 'text','','',lang('plugin/zhanmishu_video', 'baiduurl_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'baiduurlpwd'), 'baiduurlpwd', '', 'text','','',lang('plugin/zhanmishu_video', 'baiduurlpwd_desc'),'size="10"');
		// showsetting(lang('plugin/zhanmishu_video', '360url'), '360url', '', 'text','','',lang('plugin/zhanmishu_video', '360url_desc'),'size="10"');
		// showsetting(lang('plugin/zhanmishu_video', '360urlpwd'), '360urlpwd', '', 'text','','',lang('plugin/zhanmishu_video', '360urlpwd_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'rarpwd'), 'rarpwd', '', 'text','','',lang('plugin/zhanmishu_video', 'rarpwd_desc'),'size="10"');
		// showsetting(lang('plugin/zhanmishu_video', 'yourproductid'), 'yourproductid', '', 'text','','',lang('plugin/zhanmishu_video', 'yourproductid_desc'),'size="10"');
		showsubmit('course_addsubmit');
		showtablefooter(); /*Dism_taobao-com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/
	}	
}else if ($action =='editk' && $_GET['cid']) {
	$course = $videoHander->get_course_bycid($_GET['cid'] + 0);
	$user = getuserbyuid($course['uid']);
	$course['course_teacher'] = $user['username'];

	$course['course_group'] = zhanmishu_course::settingNumberFormat($course['course_group'], 'array');
 
	$groupselect = array();
	$query = C::t('common_usergroup')->range();
	foreach($query as $group) {
		if (in_array($group['groupid'], array(4,5,6,7))) {
			continue;
		}
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		if(in_array($group['groupid'], $course['course_group'])) {
			$groupselect[$group['type']] .= "<option value=\"$group[groupid]\" selected>$group[grouptitle]</option>\n";
		} else {
			$groupselect[$group['type']] .= "<option value=\"$group[groupid]\">$group[grouptitle]</option>\n";
		}
	}
	$groupselect = '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
		($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
		($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
		'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup>';


		showformheader($url.'&act=add','enctype="multipart/form-data"');
		showtableheader(); /*dism·taobao·com*/
		showsetting(lang('plugin/zhanmishu_video', 'cid'), 'cid', $course['cid'], 'text','','',lang('plugin/zhanmishu_video', ''),'size="10" readonly="readonly"');
		showsetting(lang('plugin/zhanmishu_video', 'course_name'), 'course_name', $course['course_name'], 'text','','',lang('plugin/zhanmishu_video', 'course_name_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_weight'), 'course_weight', $course['course_weight'], 'text','','',lang('plugin/zhanmishu_video', 'course_weight_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_price'), 'course_price', $course['course_price'] / 100, 'text','','',lang('plugin/zhanmishu_video', 'course_price_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_teacher'), 'course_teacher', $course['course_teacher'], 'text','','',lang('plugin/zhanmishu_video', 'course_teacher_desc'),'size="10"');
		// showsetting(lang('plugin/zhanmishu_video', 'live_url'), 'live_url', stripcslashes($course['live_url']), 'textarea','','',lang('plugin/zhanmishu_video', 'live_url_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_type'), array('course_type',array(array('0',$zhanmishu_videoconf['course_type']['0']),array('1',$zhanmishu_videoconf['course_type']['1']))), $course['course_type'], 'mradio','','',lang('plugin/zhanmishu_video', 'course_type_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_group'), 'course_group', '', '<select name="course_group[]"  multiple="multiple" size="10">'.$groupselect.'</select><td class="vtop tips2" s="1">'.lang('plugin/zhanmishu_video','course_group_desc').'</td>');

		$diff_sellect = array();
		foreach ($zhanmishu_videoconf['diff'] as $key => $value) {
			$diff_sellect[] = array($key,$value);
		}
		showsetting(lang('plugin/zhanmishu_video', 'diff'), array('diff',$diff_sellect), $course['diff'] ? $course['diff'] : '0', 'mradio','','',lang('plugin/zhanmishu_video', 'isfree_desc'),'size="10"');
		foreach ($zhanmishu_videoconf['progress'] as $key => $value) {
			$progress_sellect[] = array($key,$value);
		}
		showsetting(lang('plugin/zhanmishu_video', 'progress'), array('progress',$progress_sellect), $course['progress']? $course['progress'] : '0', 'mradio','','',lang('plugin/zhanmishu_video', 'isfree_desc'),'size="10"');
		$video_cat = $videoHander->get_cat_select();
		showsetting(lang('plugin/zhanmishu_video', 'cat_id'), array('cat_id',$video_cat), $course['cat_id'], 'mradio','','',lang('plugin/zhanmishu_video', 'isfree_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_img'), 'course_img', $course['course_img'], 'filetext','','',lang('plugin/zhanmishu_video', 'course_img_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'site_sign_img1'), 'site_sign_img1', $course['site_sign_img1'], 'filetext','','',lang('plugin/zhanmishu_video', 'course_img_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'site_sign_img2'), 'site_sign_img2', $course['site_sign_img2'], 'filetext','','',lang('plugin/zhanmishu_video', 'course_img_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'course_intro'), 'course_intro', dstripslashes($course['course_intro']), 'textarea','','',lang('plugin/zhanmishu_video', 'course_intro_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'views'), 'views', $course['views'], 'text','','',lang('plugin/zhanmishu_video', 'views_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'learns'), 'learns', $course['learns'], 'text','','',lang('plugin/zhanmishu_video', 'learns_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'ProfileID'), 'ProfileID', $course['ProfileID'], 'text','','',lang('plugin/zhanmishu_video', 'ProfileID_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'drmnums'), 'drmnums', $course['drmnums'], 'text','','',lang('plugin/zhanmishu_video', 'drmnums_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'fileurl'), 'fileurl', $course['fileurl'], 'text','','',lang('plugin/zhanmishu_video', 'fileurl_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'baiduurl'), 'baiduurl', $course['baiduurl'], 'text','','',lang('plugin/zhanmishu_video', 'baiduurl_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'baiduurlpwd'), 'baiduurlpwd', $course['baiduurlpwd'], 'text','','',lang('plugin/zhanmishu_video', 'baiduurlpwd_desc'),'size="10"');
		// showsetting(lang('plugin/zhanmishu_video', '360url'), '360url', $course['360url'], 'text','','',lang('plugin/zhanmishu_video', '360url_desc'),'size="10"');
		// showsetting(lang('plugin/zhanmishu_video', '360urlpwd'), '360urlpwd', $course['360urlpwd'], 'text','','',lang('plugin/zhanmishu_video', '360urlpwd_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'rarpwd'), 'rarpwd', $course['rarpwd'], 'text','','',lang('plugin/zhanmishu_video', 'rarpwd_desc'),'size="10"');
		// showsetting(lang('plugin/zhanmishu_video', 'yourproductid'), 'yourproductid', $course['yourproductid'], 'text','','',lang('plugin/zhanmishu_video', 'yourproductid_desc'),'size="10"');
		showsubmit('course_addsubmit');
		showtablefooter(); /*Dism_taobao-com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/


}else if ($action =='delk' &&  FORMHASH == $_GET['formhash'] && $_GET['cid']) {

	//is course_exists
	$videoHander->delete_k($_GET['cid'] + 0);
	cpmsg(lang('plugin/zhanmishu_video', 'delte_success'),'action=plugins&operation=config&identifier=zhanmishu_video&pmod=input&act=admin','success');
}else if ($action =='outsellk' &&  FORMHASH == $_GET['formhash'] && $_GET['cid']) {

	//is course_exists
	$rs = $videoHander->set_course_upatesale($_GET['cid'] + 0);

	cpmsg(lang('plugin/zhanmishu_video', 'update_sell_success'),'action=plugins&operation=config&identifier=zhanmishu_video&pmod=input&act=admin','success');
}else if ($action =='admin') {

	$mpurl=ADMINSCRIPT.'?action='.$url;
	$num = $videoHander->get_type_course_num(array('isdel'=>'0'));
	$pages= ceil($num / $perpage);
	$start = $num - ($num - $perpage*$curpage+$perpage);
	$courses = $videoHander->get_type_course_fmt($start,$perpage,'desc','',array('isdel'=>'0'));


	showtableheader(); /*dism·taobao·com*/
		showsubtitle(array(
			lang('plugin/zhanmishu_video', 'cid'),
			lang('plugin/zhanmishu_video', 'sellner'),
			lang('plugin/zhanmishu_video', 'title'),
			lang('plugin/zhanmishu_video', 'issell'),
			lang('plugin/zhanmishu_video', 'sellnum'),
			lang('plugin/zhanmishu_video', 'price'),
			lang('plugin/zhanmishu_video', 'diff'),
			lang('plugin/zhanmishu_video', 'progress'),
			lang('plugin/zhanmishu_video', 'img'),
			lang('plugin/zhanmishu_video', 'datetime'),
			lang('plugin/zhanmishu_video', 'act')));
		foreach ($courses as $key => $value) {
			unset($value['course_intro']);
			showtablerow('class="partition"',array('class="td15"', 'class="td28"'),$value);
		}
	showtablefooter(); /*Dism_taobao-com*/
	$multi = multi($num, $perpage, $curpage, $mpurl, '0', '10');
	echo $multi;
}else if ($action =='course_column_admin') {
	$mpurl=ADMINSCRIPT.'?action='.$url;

	if ($_GET['method'] == 'delete' && formhash() == $_GET['formhash']) {
		if ($_GET['columnid']) {
			$data = array();
			$data['isdel'] = '1';
			zhanmishu_video_model_column::update($_GET['columnid'] + 0, $data);
			cpmsg(lang('plugin/zhanmishu_video', 'delte_success'), 'action='.$url.'&act=course_column_admin' ,'success');
		}
	}
	
	$courses = zhanmishu_video_model_column::fetch_all_admin_format($start,$perpage,'desc',array('isdel'=>'0'));
	$num = zhanmishu_video_model_column::fetch_num(array('isdel'=>'0'));
	$pages= ceil($num / $perpage);
	$start = $num - ($num - $perpage*$curpage+$perpage);


	showtableheader(); /*dism·taobao·com*/
		showsubtitle(array(
			lang('plugin/zhanmishu_video', 'columnid'),
			lang('plugin/zhanmishu_video', 'sellner'),
			lang('plugin/zhanmishu_video', 'course_column_name'),
			lang('plugin/zhanmishu_video', 'issell'),
			lang('plugin/zhanmishu_video', 'sellnum'),
			lang('plugin/zhanmishu_video', 'price'),
			lang('plugin/zhanmishu_video', 'dateline'),
			lang('plugin/zhanmishu_video', 'act')));
		foreach ($courses as $key => $value) {
			showtablerow('class="partition"',array('class="td15"', 'class="td28"'),$value);
		}
	showtablefooter(); /*Dism_taobao-com*/
	$multi = multi($num, $perpage, $curpage, $mpurl, '0', '10');
	echo $multi;
}else if ($action =='adminvideo' && (($_GET['m'] =='add'  && $_GET['cid']) || ($_GET['m'] =='edit' && $_GET['vid']))) {
	if (submitcheck('video_addsubmit')) {
		$images = zms_uploadimg();

		if ($_GET['vid']) {
			$video_data = $videoHander->get_video_by_vid($_GET['vid'] + 0);
		}else{
			$video_data = array();
		}

		$video_data['video_img'] = daddslashes($images['video_img'] ? $images['video_img'] : $_GET['video_img']);
		$video_data['uid'] = $_G['uid'];
		$video_data['video_name'] = daddslashes($_GET['video_name']);
		$video_data['video_intro'] = daddslashes($_GET['video_intro']);
		$video_data['video_url'] = daddslashes($_GET['video_url']);
		$video_data['video_urltype'] = $_GET['video_urltype'] + 0;
		$video_data['video_length'] = $_GET['video_length'] + 0;
		$video_data['isfree'] = $_GET['isfree'] + 0;
		$video_data['video_price'] = strval(intval($_GET['video_price'] * 100));
		$video_data['dateline'] = TIMESTAMP;
		$video_data['cid'] = $_GET['cid'] + 0;

		if (!$video_data['video_name']) {
			cpmsg(lang('plugin/zhanmishu_video', 'must_finish_videoname'),'','error');
		}
		if ($_GET['vid']) {
			$video_data['vid'] = $_GET['vid'] + 0;
		}
		$isreplace = $video_data['vid'] ? true : false;

		C::t("#zhanmishu_video#zhanmishu_video")->insert($video_data,false,$isreplace);
		// 更新课程信息
		$videoHander->update_course_info($video_data['cid']);

		cpmsg(lang('plugin/zhanmishu_video', 'add_video_success'),'action=plugins&operation=config&identifier=zhanmishu_video&pmod=input&act=adminvideo&m=admin&cid='.$_GET['cid'],'success');

		
	}else{

		$v = $videoHander->get_video_by_vid($_GET['vid'] + 0);
		$cid = $v['cid'] ? $v['cid'] : $_GET['cid'] + 0;
		showformheader($url.'&act=adminvideo&m=add&cid='.$cid,'enctype="multipart/form-data"');
		showtableheader(); /*dism·taobao·com*/
		if ($v['vid']) {
			showsetting(lang('plugin/zhanmishu_video', 'vid'), 'vid', $v['vid'], 'text','','',lang('plugin/zhanmishu_video', ''),'size="10" readonly="readonly"');
		}

		showsetting(lang('plugin/zhanmishu_video', 'video_name'), 'video_name', $v['video_name'], 'text','','',lang('plugin/zhanmishu_video', ''),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'video_url'), 'video_url', dstripslashes($v['video_url']), 'textarea','','',lang('plugin/zhanmishu_video', 'video_url_desc'),'size="10"');

		$urltype_sellect = array();
		foreach ($zhanmishu_videoconf['video_url_type'] as $key => $value) {
			$urltype_sellect[] = array($key,$value);
		}
		showsetting(lang('plugin/zhanmishu_video', 'video_urltype'), array('video_urltype',$urltype_sellect), $v['video_urltype']? $v['video_urltype'] : '0', 'mradio','','',lang('plugin/zhanmishu_video', 'isfree_desc'),'size="10"');

		//showsetting(lang('plugin/zhanmishu_video', 'video_urltype'), array('video_urltype',array(array('0',$urltype_sellect['video_urltype']['0']),array('1',$urltype_sellect['video_urltype']['1']))), $v['video_urltype'], 'mradio','','',lang('plugin/zhanmishu_video', 'course_urltype_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'isfree'), array('isfree',array(array('0',$zhanmishu_videoconf['isfree']['0']),array('1',$zhanmishu_videoconf['isfree']['1']))), $v['isfree'], 'mradio','','',lang('plugin/zhanmishu_video', 'isfree_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'video_price'), 'video_price', $v['video_price'] / 100, 'text','','',lang('plugin/zhanmishu_video', 'course_price_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'video_length'), 'video_length', $v['video_length'], 'text','','',lang('plugin/zhanmishu_video', 'video_length_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'video_img'), 'video_img', $v['video_img'], 'filetext','','',lang('plugin/zhanmishu_video', 'course_img_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'video_intro'), 'video_intro', dstripslashes($v['video_intro']), 'textarea','','',lang('plugin/zhanmishu_video', 'course_intro_desc'),'size="10"');
		showsubmit('video_addsubmit');
		showtablefooter(); /*Dism_taobao-com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/
	}

}else if ($action =='adminvideo' && $_GET['m'] =='admin' && $_GET['cid']) {

	$mpurl=ADMINSCRIPT.'?action='.$url.'&act=adminvideo&m=admin&cid='.($_GET['cid']+0);
	$num = $videoHander->get_type_video_num(array('cid'=>$_GET['cid'] + 0 ));
	$pages= ceil($num / $perpage);
	$start = $num - ($num - $perpage*$curpage+$perpage);


	$videoes = $videoHander->get_type_video_fmt($start,$perpage,'desc','',array('cid'=>$_GET['cid'] + 0,'isdel'=>'0'));
	showtableheader(); /*dism·taobao·com*/
		showsubtitle(array(
			lang('plugin/zhanmishu_video', 'vid'),
			lang('plugin/zhanmishu_video', 'video_name'),
			lang('plugin/zhanmishu_video', 'video_price'),
			lang('plugin/zhanmishu_video', 'isfree'),
			lang('plugin/zhanmishu_video', 'video_url'),
			lang('plugin/zhanmishu_video', 'video_urltype'),
			lang('plugin/zhanmishu_video', 'video_length'),
			lang('plugin/zhanmishu_video', 'selltimes'),
			lang('plugin/zhanmishu_video', 'video_img'),
			lang('plugin/zhanmishu_video', 'dateline'),
			lang('plugin/zhanmishu_video', 'act')));
		foreach ($videoes as $key => $value) {
			$value['video_url'] = '<a href="'.$value['video_url'].'" target="_blank">'.lang('plugin/zhanmishu_video','click_check').'</a>';
			showtablerow('',array('class="td15"', 'class="td32"', 'class="td28"', 'class="td28"', 'class="td31"'),array_values($value));
		}
	showtablefooter(); /*Dism_taobao-com*/
	$multi = multi($num, $perpage, $curpage, $mpurl, '0', '10');
	echo $multi;
}else if ($action =='adminvideo' && $_GET['m'] =='delete' &&  FORMHASH == $_GET['formhash'] && $_GET['vid']) {
	
	$videoHander->delete_video($_GET['vid'] + 0);
	cpmsg(lang('plugin/zhanmishu_video', 'delete_video_success'),dreferer(),'success');
}else if ($action =='order' &&  $_GET['m'] =='setpay' &&  FORMHASH == $_GET['formhash'] && $_GET['oid']) {
	$r = $videoHander->order_setpay($_GET['oid'] + 0,$_GET['paystatus'] + 0);
	$videoHander->update_order_status_byoid($_GET['oid'] + 0);
	if ($r['code'] > 0) {
		cpmsg(lang('plugin/zhanmishu_video', $r['msg']),dreferer(),'success');
	}
	cpmsg(lang('plugin/zhanmishu_video', $r['msg']),dreferer(),'error');

}else if ($action =='order' &&  $_GET['m'] =='setcontract' &&  FORMHASH == $_GET['formhash'] && $_GET['oid']) {
	$r = $videoHander->order_setcontract($_GET['oid'] + 0,$_GET['contractstatus']+0);
	if ($r['code'] > 0) {
		cpmsg(lang('plugin/zhanmishu_video', $r['msg']),dreferer(),'success');
	}
	cpmsg(lang('plugin/zhanmishu_video', $r['msg']),dreferer(),'error');

}else if ($action =='order' &&  $_GET['m'] =='setmail' &&  FORMHASH == $_GET['formhash'] && $_GET['oid']) {
	$r = $videoHander->order_setmail($_GET['oid'] + 0,$_GET['mailstatus']+0);
	if ($r['code'] > 0) {
		cpmsg(lang('plugin/zhanmishu_video', $r['msg']),dreferer(),'success');
	}
	cpmsg(lang('plugin/zhanmishu_video', $r['msg']),dreferer(),'error');

}else if ($action =='order' &&  $_GET['m'] =='cleanplaycount' &&  FORMHASH == $_GET['formhash'] && $_GET['oid']) {
	$r = $videoHander->cleanplaycount($_GET['oid'] + 0);
	if ($r['code'] > 0) {
		cpmsg(lang('plugin/zhanmishu_video', $r['msg']),dreferer(),'success');
	}
	cpmsg(lang('plugin/zhanmishu_video', $r['msg']),dreferer(),'error');

}else if ($action =='order' &&  $_GET['m'] =='checkorder' &&  FORMHASH == $_GET['formhash'] && $_GET['oid']) {
	$o = $videoHander->get_order_byoid_fmt($_GET['oid'] + 0);
	if (empty($o)) {
		cpmsg(lang('plugin/zhanmishu_video', 'order_isnot_exists'),dreferer(),'error');
	}
	include template('zhanmishu_video:admin/order_info');

}else if ($action =='order') {
	$mpurl=ADMINSCRIPT.'?action='.$url.'&act=order';
	$field = array();
	$query = array();
	$query['out_trade_no'] = $_GET['out_trade_no'];
	$query['orderstatus'] = $_GET['orderstatus'];
	$query['course_column_name'] = $_GET['course_column_name'];
	$query['course_name'] = $_GET['course_name'];

	$mpurl .= '&'.http_build_query($query);

	if ($_GET['out_trade_no']) {
		$field['out_trade_no'] = daddslashes($_GET['out_trade_no']);
	}
	if ($_GET['orderstatus'] == '1') {
		$field['ispayed'] = '0';
	}else if ($_GET['orderstatus'] == '2') {
		$field['ispayed'] =  '1';
	}

	if ($_GET['course_column_name']) {
		$field['course_column_name'] = array(
			'relation' => 'like',
			'key' => 'course_column_name',
			'value' => daddslashes($_GET['course_column_name']),
		);
	}

	if ($_GET['course_name']) {
		$field['course_name'] = array(
			'relation' => 'like',
			'key' => 'course_name',
			'value' => daddslashes($_GET['course_name']),
		);
	}

	if ($_GET['course_teacher']) {
		if (is_numeric($_GET['course_teacher'])) {
			$field['uid'] = $_GET['course_teacher'] + 0;
		}else{
			$course_teacher = daddslashes($_GET['course_teacher']);
			loaducenter();
			if($data = uc_get_user($course_teacher)) {
				list($uid, $username, $email) = $data;
			} else {
				cpmsg(lang('plugin/zhanmishu_video', 'course_teacher_isnot_exists'),'','error');
			}
			$field['uid'] = $uid;
		}
	}
	$num = $videoHander->get_orders_num($field);
	$pages= ceil($num / $perpage);
	$start = $num - ($num - $perpage*$curpage+$perpage);
	$orders = $videoHander->get_orders_fmt($start,$perpage,'desc', $field);


	$total_fee = C::t("#zhanmishu_video#zhanmishu_video_order")->fetch_sum('total_fee', $field);

	showtableheader(); /*dism·taobao·com*/
	showformheader('plugins&operation=config&identifier=zhanmishu_video&pmod=input&act=order');
	$_G['showsetting_multirow'] = 1;
	$_G['showsetting_multirow_n'] = 0;
	showsetting(
		lang('plugin/zhanmishu_video','orderstatus'), 
		array('orderstatus', array(
			array('', lang('plugin/zhanmishu_video', 'all')),
			array(1, lang('plugin/zhanmishu_video', 'none_pay')),
			array(2, lang('plugin/zhanmishu_video', 'success'))
			)
		), intval($_GET['orderstatus']), 'select');
	showsetting(lang('plugin/zhanmishu_video', 'out_trade_no'), 'out_trade_no', $_GET['out_trade_no'], 'text');
	showsetting(lang('plugin/zhanmishu_video', 'course_name'), 'course_name', $_GET['course_name'], 'text');
	showsetting(lang('plugin/zhanmishu_video', 'course_teacher'), 'course_teacher', $_GET['course_teacher'], 'text');
	showsetting(lang('plugin/zhanmishu_video', 'course_column_name'), 'course_column_name', $_GET['course_column_name'], 'text');

	showsubmit('searchsubmit', lang('plugin/zhanmishu_video', 'searchsubmit'));
	showtablefooter(); /*Dism_taobao-com*/

	showtableheader(lang('plugin/zhanmishu_video', 'total_fee_sum', array('total_fee'=>$total_fee / 100)));
		showsubtitle(array(
			lang('plugin/zhanmishu_video', 'oid'),
			lang('plugin/zhanmishu_video', 'cid'),
			lang('plugin/zhanmishu_video', 'cname'),
			lang('plugin/zhanmishu_video', 'vid'),
			lang('plugin/zhanmishu_video', 'ispayed'),
			lang('plugin/zhanmishu_video', 'course_price'),
			lang('plugin/zhanmishu_video', 'buyer_uid'),
			lang('plugin/zhanmishu_video', 'out_trade_no'),
			lang('plugin/zhanmishu_video', 'orderdateline'),
			lang('plugin/zhanmishu_video', 'pay_time'),
			lang('plugin/zhanmishu_video', 'orderstatus'),
			lang('plugin/zhanmishu_video', 'act')));
		foreach ($orders as $key => $value) {
			showtablerow('class="partition"',array('class="td15"', 'class="td28"'),$value);
		}
	showtablefooter(); /*Dism_taobao-com*/

	$multi = multi($num, $perpage, $curpage, $mpurl, '0', '10');
	echo $multi;
	showtableheader(); /*dism·taobao·com*/
	showtablefooter(); /*Dism_taobao-com*/

}else if ($action =='setvipbyhand') {
	if ($_GET['setvipbyhand_addsubmit'] &&  FORMHASH == $_GET['formhash']) {
	$cid = $_GET['cid'] + 0;
	$video = zhanmishu_video::getInstance();
	$course = $videoHander->get_course_bycid($cid,false,true);
	
	if (empty($course)) {
		cpmsg(lang('plugin/zhanmishu_video', 'course_isnot_exists'),dreferer(),'error');
	}

	$out_trade_no = $videoHander->get_rand_trade_no();
	$o = array();
	$o['uid'] = $course['uid'];
	$o['course_name'] = $course['course_name'];
	$o['total_fee'] = $course['course_price'];
	$o['course_intro'] = $course['course_intro'];
	$o['course_img'] = $course['course_img'];
	$o['course_price'] = $course['course_price'];
	$o['order_type'] = $course['course_type'];
	$o['cid'] = $course['cid'];
	$o['buyer_uid'] = $_G['uid'];
	$o['out_trade_no'] = $out_trade_no;
	$o['dateline'] = TIMESTAMP;

		exit;
	}

	$mpurl=ADMINSCRIPT.'?action='.$url.'&act=setvipbyhand';

		showformheader($url.'&act=setvipbyhand','enctype="multipart/form-data"');
		showtableheader(); /*dism·taobao·com*/
		showsetting(lang('plugin/zhanmishu_video', 'username'), 'username', '', 'text','','',lang('plugin/zhanmishu_video', 'username_desc'),'size="10"');
		showsetting(lang('plugin/zhanmishu_video', 'cid'), 'cid', '', 'text','','',lang('plugin/zhanmishu_video', 'cid_desc'),'size="10"');
		showsubmit('setvipbyhand_addsubmit');
		showtablefooter(); /*Dism_taobao-com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/

}

//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>