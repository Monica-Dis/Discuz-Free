<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'source/plugin/mobile/json.class.php';
class zhanmishu_admin_api extends CJSON{
    public static function encode($data = array()){
        return json_encode(self::auto_charset_change($data),JSON_NUMERIC_CHECK);
    }

    public static function resultToJson($data,$code = '0',$msg = 'success') {
        $outapi = array();
        $outapi['code'] = $code;
        $outapi['msg'] = $msg;
        $outapi['result'] = $data;

        return self::encode($outapi);
    }

    public static function auto_charset_change($data,$charset='',$toCharset='UTF-8'){
        $charset = $charset ? $charset : CHARSET;
        if (!is_array($data)) {
            return diconv($data,$charset,$toCharset);
        }else if (is_array($data)) {
            $tmp = array();
            foreach ($data as $key => $value) {
                $nkey = diconv($key,$charset,$toCharset);
                $nvalue = self::auto_charset_change($value,$charset,$toCharset);
                $tmp[$nkey] = $nvalue;
            }
            return $tmp;
        }
        return false;
    }
}
