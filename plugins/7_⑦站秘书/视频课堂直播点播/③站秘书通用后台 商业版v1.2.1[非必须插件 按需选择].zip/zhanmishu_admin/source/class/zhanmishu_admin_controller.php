<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
} 


class zhanmishu_admin_controller
{
    public $adminHander;
    function __construct(zhanmishu_admin $adminHander) {
        $this->adminHander = & $adminHander;
    }
    public function add() {
        
    }
    public function delete() {

    }
    public function edit() {

    }
    public function fetch(){

    }
    public function checkFormhash($formhash = ''){
        return $formhash == formhash();
    }

    public static function resultToJsonOutPut($data = array(), $msg = '', $code = '' ,$isChangeCharset = true){
        if (!$data['msg'] && $msg) {
            $data['msg'] = $msg;
        }
        if (!$data['code'] && $code) {
            $data['code'] = $code;
        }
        echo zhanmishu_admin_api::resultToJson($data,'','',$isChangeCharset);
        exit;
    }

    public static function showMessage($message = '' , $code = '' , $url='') {
        if (defined('IN_MOBILE_API')) {
           return self::resultToJsonOutPut(array(), $message, $code);
        }
        if (defined('IN_ADMINCP')) {
            if ($code > 0) {
                $type = 'success';
            }else{
                $type = 'error';
            }
            cpmsg($message,$url,$type);
        }
        if ($code > 0) {
            $type = 'right';
        }else{
            $type = 'error';
        }
        showmessage($message,$url,array('alert'=>$type));
    }

    public static function submitcheck($var, $allowget = 0, $seccodecheck = 0, $secqaacheck = 0){
        if (defined('IN_MOBILE_API')) {
            if(!getgpc($var)) {
                return FALSE;
            } else {
                global $_G;
                if($allowget || ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_GET['formhash']) && $_GET['formhash'] == formhash() && empty($_SERVER['HTTP_X_FLASH_VERSION']) && (empty($_SERVER['HTTP_REFERER']) ||
                    strncmp($_SERVER['HTTP_REFERER'], 'http://wsq.discuz.com/', 22) === 0 || preg_replace("/https?:\/\/([^\:\/]+).*/i", "\\1", $_SERVER['HTTP_REFERER']) == preg_replace("/([^\:]+).*/", "\\1", $_SERVER['HTTP_HOST']))) || true) {
                    if(checkperm('seccode')) {
                        if($secqaacheck && !check_secqaa($_GET['secanswer'], $_GET['secqaahash'])) {
                            $outapi = array(
                                'msg'=>'submit_secqaa_invalid',
                                'code'=>'-11',
                            );
                            sefl::resultToJsonOutPut($outapi);
                            
                        }
                        if($seccodecheck && !check_seccode($_GET['seccodeverify'], $_GET['seccodehash'], 0, $_GET['seccodemodid'])) {
                            $outapi = array(
                                'msg'=>'submit_seccode_invalid',
                                'code'=>'-12',
                            );
                            sefl::resultToJsonOutPut($outapi);
                        }
                    }
                    return TRUE;
                } else {
                    $outapi = array(
                        'msg'=>'submit_invalid',
                        'code'=>'-13',
                    );
                    sefl::resultToJsonOutPut($outapi);
                }
            }          
        }
        return submitcheck($var, $allowget = 0, $seccodecheck = 0, $secqaacheck = 0);
    }
    
}