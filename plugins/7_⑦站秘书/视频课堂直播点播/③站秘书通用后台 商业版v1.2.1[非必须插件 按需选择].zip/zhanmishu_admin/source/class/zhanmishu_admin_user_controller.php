<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
} 

/**
 * 
 */
class zhanmishu_admin_user_controller extends zhanmishu_admin_controller
{
    function login($params = array()) {
        global $_G;
        $params = zhanmishu_admin_api::auto_charset_change($params,'UTF-8',CHARSET);
        $username = daddslashes($params['username']);
        $password = daddslashes($params['password']);
        $idhash = daddslashes($params['idhash']);
        $seccode = daddslashes($params['seccode']);

        if (!$username || !$password || !$idhash || !$seccode) {
            if (!$username) {
                $msg = lang('plugin/zhanmishu_admin','username_is_required');
                $code = -20001;
            }else if (!$password) {
                $msg = lang('plugin/zhanmishu_admin','password_is_required');
                $code = -20002;
            }else if (!$idhash) {
                $msg = lang('plugin/zhanmishu_admin','idhash_is_required');
                $code = -20003;
            }else if (!$seccode) {
                $msg = lang('plugin/zhanmishu_admin','seccode_is_required');
                $code = -20004;
            }

            $return = array(
                'msg'=>$msg,
                'code'=>$code
            );
            echo zhanmishu_admin_api::resultToJson($return);
            exit;
        }

        if (!check_seccode($seccode,$idhash)) {
            $msg = lang('plugin/zhanmishu_admin','seccode_is_error');
            $code = -20005;
            $return = array(
                'msg'=>$msg,
                'code'=>$code
            );
            echo zhanmishu_admin_api::resultToJson($return);
            exit;
        }

        loaducenter();
        $result = uc_user_login($username,$password,0);
        if ($result[0] > 0) {
            $member = getuserbyuid($result[0], 1);
            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            dsetcookie('lip', $_G['member']['lastip'].','.$_G['member']['lastvisit']);
            C::t('common_member_status')->update($_G['uid'], array('lastip' => $_G['clientip'], 'lastvisit' =>TIMESTAMP, 'lastactivity' => TIMESTAMP));

            $code = '1';
            $msg = 'success';

            $access = array();
            $teacher = array();
            if ($_G['groupid'] == '1') {
                $access[] = 'admin';
            }
            if (is_file(DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/class/zhanmishu_video.php')) {
                if (!class_exists('zhanmishu_video',false)) {
                    C::import('zhanmishu_video','plugin/zhanmishu_video/source/class');
                }                $videoHander = zhanmishu_video::getInstance();
                if ($videoHander->checkIsTeacher()) {
                    $access[] = 'teacher';
                    $teacher = $videoHander->getTeacherInfo($_G['uid']);
                }
            }

            $return = array(
                    'member'=>array(
                        'uid'=>$_G['uid'],
                        'formhash'=>FORMHASH,
                        'username'=>$_G['username'],
                        'groupid'=>$_G['groupid'],
                        'avatar'=>avatar($_G['uid'], 'middle', true),
                        'access'=>$access,
                        'roles'=>$access,
                        'teacher'=>$teacher,
                    ),
                'msg'=>$msg,
                'code'=>$code
            );
            echo zhanmishu_admin_api::resultToJson($return);
            exit;
        }else{
            $msg = lang('plugin/zhanmishu_admin','username_or_password_error');
            $code = $result[0];
            
        }
        $return = array(
            'msg'=>$msg,
            'code'=>$code
        );
        echo zhanmishu_admin_api::resultToJson($return);
        exit;
    }
    public function userInfo(){
        global $_G;
        if ($_G['uid'] > 0) {
            $code = '1';
            $msg = 'success';

            $access = array();
            $teacher = array();
            if ($_G['groupid'] == '1') {
                $access[] = 'admin';
            }
            if (is_file(DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/class/zhanmishu_video.php')) {
                if (!class_exists('zhanmishu_video',false)) {
                    C::import('zhanmishu_video','plugin/zhanmishu_video/source/class');
                }
        
                $videoHander = zhanmishu_video::getInstance();
                if ($videoHander->checkIsTeacher()) {
                    $access[] = 'teacher';
                    $teacher = $videoHander->getTeacherInfo($_G['uid']);
                }
            }

            $return = array(
                    'member'=>array(
                        'uid'=>$_G['uid'],
                        'formhash'=>FORMHASH,
                        'username'=>$_G['username'],
                        'groupid'=>$_G['groupid'],
                        'avatar'=>avatar($_G['uid'], 'middle', true),
                        'access'=>$access,
                        'roles'=>$access,
                        'teacher'=>$teacher,
                    ),
                'msg'=>$msg,
                'code'=>$code
            );
            echo zhanmishu_admin_api::resultToJson($return);
            exit;
        }else{
            $msg = lang('plugin/zhanmishu_admin','token_time_out');
            $code = $result[0];
            
        }
        $return = array(
            'msg'=>$msg,
            'code'=>$code
        );
        echo zhanmishu_admin_api::resultToJson($return);
        exit;
    }
}