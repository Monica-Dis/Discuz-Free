<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_admin/source/Autoloader.php';

$mod = $_GET['mod'] ?  $_GET['mod'] : 'index';
$version = $_GET['version'] ?  $_GET['version'] : '1';

if (!in_array($mod, array('user','setting'))) {
    $return = array(
        'msg'=>'module_error',
        'code'=>'-9999'
    );
    echo zhanmishu_admin_api::encode($return);
    exit;
}

$apifile = DISCUZ_ROOT.'./source/plugin/zhanmishu_admin/api/'.$version.'/'.$mod.'.php';

if(file_exists($apifile)) {
    require_once $apifile;
} else {
    if($version > 1) {
        for($i = $version; $i >= 1; $i--) {
            $apifile = DISCUZ_ROOT.'./source/plugin/zhanmishu_admin/api/'.$i.'/'.$mod.'.php';
            if(file_exists($apifile)) {
                $version = $i;
                require_once $apifile;
                break;
            } elseif($i==1 && !file_exists($apifile)) {
                zhanmishu_admin_api::encode(array('msg' => 'module_not_exists','code'=>'-9999'));
            }
        }
    } else {
        zhanmishu_admin_api::encode(array('msg' => 'module_not_exists','code'=>'-9999'));
    }
}
//dis'.'m.tao'.'bao.com
?>