<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: api.php 33591 2013-07-12 06:39:49Z DISM-TAOBAO-COM $
 */

// header("Access-Control-Allow-Origin: *");

define('IN_QIWEI_API', true);
define('IN_MOBILE_API', 1);
define('IN_MOBILE', 1);



$dir = '../../../';
chdir($dir);

$_GET['id'] = 'zhanmishu_admin:api';
$_GET['dtype'] = '1';
$_GET['mod'] = isset($_GET['mod']) ?  $_GET['mod'] : 'index';
$_GET['version'] = isset($_GET['version']) ? $_GET['version'] : '1';
include 'plugin.php';