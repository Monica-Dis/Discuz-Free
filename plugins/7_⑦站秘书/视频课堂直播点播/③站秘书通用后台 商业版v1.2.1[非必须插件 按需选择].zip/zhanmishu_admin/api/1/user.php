<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$adminHander = new zhanmishu_admin();

$userController = new zhanmishu_admin_user_controller($adminHander);

if (method_exists($userController, $_GET['action'])) {
    $action = $_GET['action'] ? $_GET['action'] : 'index';
    $userController->$action($_GET);
}
