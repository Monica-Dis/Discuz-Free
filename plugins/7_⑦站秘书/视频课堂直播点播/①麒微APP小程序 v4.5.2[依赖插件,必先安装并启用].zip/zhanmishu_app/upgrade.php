<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
  exit('Access Denied');
}

$tablechatInfo = DB::table('zhanmishu_app_chat');
$countchatInfo = DB::fetch_first('show tables like \''.$tablechatInfo.'\'');
if (empty($countchatInfo)) {
  $sql .= "CREATE TABLE IF NOT EXISTS pre_zhanmishu_app_chat (
  `chat_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groupid` int(11) unsigned NOT NULL DEFAULT '0',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `to_uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `islive` tinyint(1) NOT NULL DEFAULT '0',
  `isread` tinyint(1) NOT NULL DEFAULT '0',
  `message_type` tinyint(1) NOT NULL DEFAULT '0',
  `chat_type` tinyint(1) NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '0',
  `isdel` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `score` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isforbid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `message` varchar(2000) NOT NULL DEFAULT '',
  `voice_length` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `views` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `praises` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (chat_id),
  KEY dateline (dateline),
  KEY parent_id (parent_id),
  KEY uid (uid),
  KEY groupid (groupid),
  KEY to_uid (to_uid)
);\n";

}else{

}


if ($sql) {
    runquery($sql);
}


$finish = true;