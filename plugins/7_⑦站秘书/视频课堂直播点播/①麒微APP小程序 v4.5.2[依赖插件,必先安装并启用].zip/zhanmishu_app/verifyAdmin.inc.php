<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_app/source/Autoloader.php';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_app/source/Autoloader.php';

$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_app&pmod=verifyAdmin';
$formurl = 'plugins&operation=config&identifier=zhanmishu_app&pmod=verifyAdmin';

$perpage=20;
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;



$_GET['method'] = $_GET['method'] ? $_GET['method'] : 'createVerify';
$verifyAdminItem = array(
    'normal'=>array(
        'menu'=> array(
            array(
                'title'=>lang('plugin/zhanmishu_app','verifyIndex'),
                'link'=>$mpurl.'&method=verifyIndex',
                'selected'=> $_GET['method'] == 'verifyIndex' ? 'selected' : ''
            ),
            array(
                'title'=>lang('plugin/zhanmishu_app','createVerify'),
                'link'=>$mpurl.'&method=createVerify',
                'selected'=> $_GET['method'] == 'createVerify' ? 'selected' : ''
            )
        ),
    )
);
zhanmishu_app_admin::importPureCss();
zhanmishu_app_admin::importJquery();
zhanmishu_app_admin::menuHorizontal($verifyAdminItem['normal']['title'],$verifyAdminItem['normal']['menu']);

if ($_GET['method'] == 'verifyIndex') {
    $num = zhanmishu_app_model_verify::fetch_num();

    $pages= ceil($num / $perpage);
    $start = $num - ($num - $perpage*$curpage+$perpage);

    $verifys = zhanmishu_app_model_verify::fetch_all_admin_format($start, $perpage, 'desc', array());
    showformheader($formurl.'&method=createVerifyPage','enctype="multipart/form-data" ');
    showtableheader(); /*dism·taobao·com*/
        // $returnArray[$key]['id'] = $value['id'];
        // $returnArray[$key]['verify_name'] = $value['verify_name'];
        // $returnArray[$key]['verify_intro'] = $value['verify_intro'];
        // $returnArray[$key]['type'] = $value['type'];
        // $returnArray[$key]['groupid'] = $value['groupid'];
        // $returnArray[$key]['main_group'] = $value['main_group'];
        // $returnArray[$key]['field'] = $value['field'];
        // $returnArray[$key]['dateline'] = $value['dateline'];
        showsubtitle(
            array(
                lang('plugin/zhanmishu_app', 'checkbox'),
                lang('plugin/zhanmishu_app', 'id'),
                lang('plugin/zhanmishu_app', 'verify_name'),
                lang('plugin/zhanmishu_app', 'verify_intro'),
                lang('plugin/zhanmishu_app', 'type'),
                lang('plugin/zhanmishu_app', 'groupid'),
                lang('plugin/zhanmishu_app', 'main_group'),
                lang('plugin/zhanmishu_app', 'field'),
                lang('plugin/zhanmishu_app', 'dateline')
            )
        );
        foreach ($verifys as $key => $value) {
            array_unshift($value,'<input type="checkbox" class="txt" name="selected['.$value['id'].']" value="'.$value['id'].'" />');
            showtablerow('class="partition"',array('class="td25"', 'class="td15"', 'class="td28"'),$value);
        }
    $multi = multi($num, $perpage, $curpage, $mpurl, '0', '10');
    echo $multi;
    showsubmit('createVerifyPage',lang('plugin/zhanmishu_app', 'submit'));

    showtablefooter(); /*Dism_taobao-com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/ 
}else if ($_GET['method'] == 'createVerifyPage') {
    $vids = $_GET['selected'];
    foreach ($vids as $key => $value) {
        $vids[$key] = intval($value);
        if (!$vids[$key]) {
            unset($vids[$key]);
        }
    }

    echo $_G['siteurl'].'plugin.php?id=zhanmishu_app:index&action=verifyPage#vids='.implode('-',$vids);
    exit;

}else if ($_GET['method'] == 'createVerify') {

    if (submitcheck('createVerify')) {


        cpmsg(lang('plugin/zhanmishu_app', 'edit_success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=verifyAdmin&method=verifyIndex','success');

    }else{

        showformheader($formurl.'&method=createVerify','enctype="multipart/form-data" ');
        showtableheader(); /*dism·taobao·com*/

        showtableheader(lang('plugin/zhanmishu_app','fieldAdmin'));

        //以单选形式输出表单(显示授权信息链接 radio)：

        $varname = array('field', array(), 'isfloat');
        foreach(C::t('common_member_profile_setting')->fetch_all_by_available(1) as $value) {
            if ($value['formtype'] != 'text') {
                continue;
            }
            if(!in_array($value['fieldid'], array('constellation', 'zodiac', 'birthyear', 'birthmonth', 'birthprovince', 'birthdist', 'birthcommunity', 'resideprovince', 'residedist', 'residecommunity'))) {
                $varname[1][] = array($value['fieldid'], $value['title'], $value['fieldid']);
            }
        }
        showsetting('members_verify_setting_field', $varname, $items['field'], 'omcheckbox');
        showsubmit('createVerify',lang('plugin/zhanmishu_app', 'submit'));

        showtablefooter(); /*Dism_taobao-com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/   
    echo <<<EOT
    <script type="text/JavaScript">
        ;(function($){
            $('.fastUpload').on('click', function () {
                uploadIcon($(this));
            });
        })(jQuery);
    </script>
EOT;

    }    
}

