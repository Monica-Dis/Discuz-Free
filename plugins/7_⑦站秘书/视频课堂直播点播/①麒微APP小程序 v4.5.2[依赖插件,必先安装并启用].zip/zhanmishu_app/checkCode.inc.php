<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: discuzcode.func.php 36284 2016-12-12 00:47:50Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


include template("zhanmishu_app:checkCode");