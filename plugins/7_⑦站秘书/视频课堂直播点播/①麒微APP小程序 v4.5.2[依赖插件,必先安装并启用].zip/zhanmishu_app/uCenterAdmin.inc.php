<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_app/source/Autoloader.php';
$appHander = zhanmishu_app::getInstance();

$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_app&pmod=uCenterAdmin';
$formurl = 'plugins&operation=config&identifier=zhanmishu_app&pmod=uCenterAdmin';


$_GET['method'] = $_GET['method'] ? $_GET['method'] : 'mySetting';
$uCenterItem = array(
    'normal'=>array(
        'menu'=> array(
            array(
                'title'=>lang('plugin/zhanmishu_app','mySetting'),
                'link'=>$mpurl.'&method=mySetting',
                'selected'=> $_GET['method'] == 'mySetting' ? 'selected' : ''
            ),
            array(
                'title'=>lang('plugin/zhanmishu_app','emojiSetting'),
                'link'=>$mpurl.'&method=emojiSetting',
                'selected'=> $_GET['method'] == 'emojiSetting' ? 'selected' : ''
            ),
            array(
                'title'=>lang('plugin/zhanmishu_app','versionSetting'),
                'link'=>$mpurl.'&method=versionSetting',
                'selected'=> $_GET['method'] == 'versionSetting' ? 'selected' : ''
            ),
            array(
                'title'=>lang('plugin/zhanmishu_app','guideImgSetting'),
                'link'=>$mpurl.'&method=guideImgSetting',
                'selected'=> $_GET['method'] == 'guideImgSetting' ? 'selected' : ''
            )
        )
    )
);

zhanmishu_app_admin::importPureCss();
zhanmishu_app_admin::menuHorizontal($uCenterItem['normal']['title'],$uCenterItem['normal']['menu']);


if ($_GET['method'] == 'versionSetting') {
    if (submitcheck('versionSettingSubmit')) {

        $version = array();
        foreach ($_GET['version'] as $key => $value) {
            if (!$value || in_array($key, $_GET['delete'])) {
                continue;
            }
            $version[] = array(
                'version'=>$_GET['version'][$key],
                'limit_version'=>$_GET['limit_version'][$key],
                'type'=>$_GET['type'][$key],
                'android_url'=>$_GET['android_url'][$key],
                'ios_url'=>$_GET['ios_url'][$key],
                'description'=>$_GET['description'][$key]
            );
        }

        $appHander->writeToCache('versionSetting',$version);
        

        cpmsg(lang('plugin/zhanmishu_app', 'update_version_success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=uCenterAdmin','success');

    }else{

        $version = $appHander->GetFromCache('versionSetting');



        showformheader($formurl.'&method=versionSetting','enctype="multipart/form-data"');
        showtableheader(lang('plugin/zhanmishu_app','versionSettingDesc'));
        showsubtitle(array(
            lang('plugin/zhanmishu_app', 'version'),
            lang('plugin/zhanmishu_app', 'limit_version'),
            lang('plugin/zhanmishu_app', 'type'),
            lang('plugin/zhanmishu_app', 'android_url'),
            lang('plugin/zhanmishu_app', 'ios_url'),
            lang('plugin/zhanmishu_app', 'update_description')
        ));

        foreach ($version as $key => $value) {
            $versionType = array(
                $value['type'] == '0' ? ' selected' : '',
                $value['type'] == '1' ? ' selected' : '',
            );
            $type = '<select name="type[]">
                <option value ="0" '.$versionType[0].'>'.lang('plugin/zhanmishu_app', 'release').'</option>
                <option value ="1" '.$versionType[1].'>'.lang('plugin/zhanmishu_app', 'beta').'</option>
            </select>';

            $appHanderarr = array(
                '<input type="text" class="txt" name="version['.$value['id'].']" value="'.$value['version'].'" />',
                '<input type="text" class="txt" name="limit_version['.$value['id'].']" value="'.$value['limit_version'].'" />',
                $type,
                '<input type="text" class="txt" name="android_url['.$value['id'].']" value="'.$value['android_url'].'" />',
                '<input type="text" class="txt" name="ios_url['.$value['id'].']" value="'.$value['ios_url'].'" />',
                '<textarea  name="description['.$value['id'].']" value="'.$value['description'].'" >'.$value['description'].'</textarea>',
            );
            showtablerow('',
                array(
                    'class="td22"', 
                    'class="td22"', 
                    'class="td22"', 
                    'class="td22"',
                    'class="td22"',
                ),
                $appHanderarr
            );

        }
        echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_app', 'adduCenterItem').'</a></div></tr>';

        showsubmit('versionSettingSubmit');
        showformfooter(); /*dis'.'m.tao'.'bao.com*/

        $versionType = array(
            '',
            '',
        );
        $type = '<select name="type[]"><option value ="0" '.$versionType[0].'>'.lang('plugin/zhanmishu_app', 'release').'</option><option value ="1" '.$versionType[1].'>'.lang('plugin/zhanmishu_app', 'beta').'</option></select>';
        echo <<<EOT
        <script type="text/JavaScript">
            var rowtypedata = [
                [
                    [1,'<input type="text" required class="txt" name="version[]" value="">', 'td22'],
                    [1,'<input type="text" required class="txt" name="limit_version[]" value="">', 'td22'],
                    [1,'{$type}', 'td22'],
                    [1,'<input type="text" required class="txt" name="android_url[]" value="">', 'td22'],
                    [1,'<input type="text" required class="txt" name="ios_url[]" value="">', 'td22'],
                    [1,'<textarea required class="" name="description[]" value=""></textarea>', 'td22'],
                ]
            ];
        </script>
EOT;

    }
}else if ($_GET['method'] == 'mySetting') {
    if (submitcheck('mySettingSubmit')) {
        $images = zhanmishu_app::uploadimg();

        $uCenter_list = array();
        foreach ($_GET['title'] as $key => $value) {
            if (!$value || in_array($key, $_GET['delete'])) {
                continue;
            }
            $uCenter_list[] = array(
                'order'=>$_GET['order'][$key],
                'groupid'=>$_GET['groupid'][$key],
                'title'=>$_GET['title'][$key],
                'image'=>$images[$key] ? $images[$key] : $_GET['image'][$key] ,
                'url'=>$_GET['url'][$key],
                'urlType'=>$_GET['urlType'][$key],
                'platform'=>$_GET['platform'][$key],
                'description'=>$_GET['description'][$key]
            );
        }

        $appHander->writeToCache('uCenterAdminMy',$uCenter_list);
        cpmsg(lang('plugin/zhanmishu_app', 'update_uCenter_list_success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=uCenterAdmin','success');

    }else{
        $uCenter_list = $appHander->GetFromCache('uCenterAdminMy');
        if (empty($uCenter_list)) {
            $appHander->importInitUcenter();
        }
        showformheader($formurl.'&method=mySetting','enctype="multipart/form-data"');
        showtableheader(lang('plugin/zhanmishu_app','uCenterAdminMyDesc'));
        showsubtitle(array(
            lang('plugin/zhanmishu_app', 'delete'),
            lang('plugin/zhanmishu_app', 'order'),
            lang('plugin/zhanmishu_app', 'item_groupid'),
            lang('plugin/zhanmishu_app', 'title'),
            lang('plugin/zhanmishu_app', 'icon'),
            lang('plugin/zhanmishu_app', 'url'),
            lang('plugin/zhanmishu_app', 'description')
        ));

        foreach ($uCenter_list as $key => $value) {
            $value['id'] = $key;
            $linkTypeSelect = array(
                $value['urlType'] == '0' ? ' selected' : '',
                $value['urlType'] == '1' ? ' selected' : '',
            );
            $recommendType = array(
                $value['platform'] == '0' ? ' selected' : '',
                $value['platform'] == '1' ? ' selected' : '',
                $value['platform'] == '2' ? ' selected' : '',
                $value['platform'] == '3' ? ' selected' : '',
            );



            $image = $value['image'] ? $value['image'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
            $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'
            <select name="urlType[]">
                <option value ="0" '.$linkTypeSelect[0].'>'.lang('plugin/zhanmishu_app', 'URL').'</option>
                <option value ="1" '.$linkTypeSelect[1].'>'.lang('plugin/zhanmishu_app', 'appPage').'</option>
            </select>';
            $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]">
                    <option value ="0" '.$recommendType[0].'>'.lang('plugin/zhanmishu_app', 'public').'</option>
                    <option value ="1" '.$recommendType[1].'>'.lang('plugin/zhanmishu_app', 'H5').'</option>
                    <option value ="2" '.$recommendType[2].'>'.lang('plugin/zhanmishu_app', 'minapp').'</option>
                    <option value ="3" '.$recommendType[3].'>'.lang('plugin/zhanmishu_app', 'app').'</option>
                </select>';

                $appHanderarr = array(
                '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                '<input type="text" class="txt" name="order['.$value['id'].']" value="'.$value['order'].'" />',
                '<input type="text" class="txt" name="groupid['.$value['id'].']" value="'.$value['groupid'].'" />',
                '<input type="text" class="txt" name="title['.$value['id'].']" value="'.$value['title'].'" />',
                '<img src="'.$image.'" width="40px" height="40px"><input type="text" class="txt" style="width:100px;" name="image['.$value['id'].']" placeholder="'.lang('plugin/zhanmishu_app','image_placeholder').'" value="'.$value['image'].'" />
                <input style="width:140px" type="file"  name="image_file['.$value['id'].']" value="" />',
                '<input type="text"  name="url['.$value['id'].']" value="'.$value['url'].'" />'.$urlType,
                '<textarea  name="description['.$value['id'].']" value="'.$value['description'].'" >'.$value['description'].'</textarea>',
            );
            showtablerow('',
                array(
                    'class="td25"', 
                    'class="td25"', 
                    'class="td25"', 
                    'class="td22"',
                    'class="td25"',
                    'class="td22"',
                    'class="td22"'
                ),
                $appHanderarr
            );

        }
        echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_app', 'adduCenterItem').'</a></div></tr>';

        showsubmit('mySettingSubmit');
        showformfooter(); /*dis'.'m.tao'.'bao.com*/

        $placeholder = lang('plugin/zhanmishu_app','image_placeholder');
        $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'<select name="urlType[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'URL').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'appPage').'</option></select>';
        $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'public').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'H5').'</option><option value ="2">'.lang('plugin/zhanmishu_app', 'minapp').'</option><option value ="3">'.lang('plugin/zhanmishu_app', 'app').'</option></select>';

        echo <<<EOT
        <script type="text/JavaScript">
            var rowtypedata = [
                [
                    [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                    [1,'<input type="text" class="txt" name="order[]" value="">', 'td25'],
                    [1,'<input type="text" class="txt" name="groupid[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="title[]" value="">', 'td22'],
                    [1,'<img src="source/plugin/zhanmishu_app/template/images/noimg.jpg" width="40px" height="40px"><input type="text" class="txt" style="width:100px;" placeholder="{$placeholder}" name="image[]" value="" /><input type="file" class="" name="image_file[]" style="width:140px;" value="">', 'td25'],
                    [1,'<input type="text" required class="" name="url[]" value="">{$urlType}', 'td22'],
                    [1,'<textarea required class="" name="description[]" value=""></textarea>', 'td22'],
                ]
            ];
        </script>
EOT;

    }
}else if ($_GET['method'] == 'emojiSetting') {
    if (submitcheck('emojiSettingSubmit')) {
        $emoji_list = array();
        foreach ($_GET['alt'] as $key => $value) {
            if (!$value || in_array($key, $_GET['delete'])) {
                continue;
            }
            $emoji_list[] = array(
                'order'=>$_GET['order'][$key],
                'alt'=>$_GET['alt'][$key],
                'icon'=>$_GET['icon'][$key],
            );
        }

        $appHander->writeToCache('emoji',$emoji_list);
        
        cpmsg(lang('plugin/zhanmishu_app', 'update_emojit_success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=uCenterAdmin','success');

    }else{
        $emojis = scandir(DISCUZ_ROOT.'source/plugin/zhanmishu_app/template/images/emoji');
        unset($emojis[0]);
        unset($emojis[1]);

        $emoji_list = $appHander->GetFromCache('emoji');
        if (!$emoji_list || empty($emoji_list)) {
            $appHander->importInitEmoji();
        }else{
            // 循环已经有的表情，如果表情存在，删除新文件列表，如果没有，则删除表情列表
            foreach ($emoji_list as $key => $value) {
                $emojiKey = array_search($value['icon'], $emojis);
                if ($emojiKey) {
                    unset($emojis[$emojiKey]);
                }else{
                   unset($emoji_list[$key]); 
                }
            }
            foreach ($emojis as $key => $value) {
                $emoji_list[] =array(
                    'order' => '',
                    'alt' => '',
                    'icon' => $value,
                );
            }
        }

        showformheader($formurl.'&method=emojiSetting','enctype="multipart/form-data"');
        showtableheader(lang('plugin/zhanmishu_app','emojiSettingDesc'));
        showsubtitle(array(
            lang('plugin/zhanmishu_app', 'delete'),
            lang('plugin/zhanmishu_app', 'order'),
            lang('plugin/zhanmishu_app', 'alt'),
            lang('plugin/zhanmishu_app', 'icon')
        ));

        foreach ($emoji_list as $key => $value) {
            $value['id'] = $key;

            $image = 'source/plugin/zhanmishu_app/template/images/emoji/'.$value['icon'];
                $appHanderarr = array(
                '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                '<input type="text" class="txt" name="order['.$value['id'].']" value="'.$value['order'].'" />',
                '<input type="text" class="txt" name="alt['.$value['id'].']" value="'.$value['alt'].'" />',
                '<img src="'.$image.'" width="40px" height="40px"><input type="hidden" class="txt" name="icon['.$value['id'].']" value="'.$value['icon'].'" />'.$value['icon']
            );
            showtablerow('',
                array(
                    'class="td25"', 
                    'class="td25"', 
                    'class="td22"',
                    'class="td25"',
                ),
                $appHanderarr
            );

        }

        showsubmit('emojiSettingSubmit');
        showformfooter(); /*dis'.'m.tao'.'bao.com*/

    }
}
else if ($_GET['method'] == 'guideImgSetting') {
    if (submitcheck('guideImgSettingSubmit')) {
        $images = zhanmishu_app::uploadimg();

        $guideImg = array();
        foreach ($_GET['title'] as $key => $value) {
            if (!$value || in_array($key, $_GET['delete'])) {
                continue;
            }
            $guideImg[] = array(
                'order'=>$_GET['order'][$key],
                'title'=>$_GET['title'][$key],
                'image'=>$images[$key] ? $images[$key] : $_GET['image'][$key] ,
                'url'=>$_GET['url'][$key],
                'urlType'=>$_GET['urlType'][$key],
                'description'=>$_GET['description'][$key]
            );
        }

        $appHander->writeToCache('guideImg',$guideImg);
        

        cpmsg(lang('plugin/zhanmishu_app', 'update_success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=uCenterAdmin','success');

    }else{

        $guideImg = $appHander->GetFromCache('guideImg');

        if (empty($guideImg)) {
            $appHander->importInitGuide();
        }

        showformheader($formurl.'&method=guideImgSetting','enctype="multipart/form-data"');
        showtableheader(lang('plugin/zhanmishu_app','guideImgSettingDesc'));
        showsubtitle(array(
            lang('plugin/zhanmishu_app', 'delete'),
            lang('plugin/zhanmishu_app', 'order'),
            lang('plugin/zhanmishu_app', 'title'),
            lang('plugin/zhanmishu_app', 'image'),
            lang('plugin/zhanmishu_app', 'url'),
            lang('plugin/zhanmishu_app', 'description')
        ));

        foreach ($guideImg as $key => $value) {
            $value['id'] = $key;
            $linkTypeSelect = array(
                $value['urlType'] == '0' ? ' selected' : '',
                $value['urlType'] == '1' ? ' selected' : '',
            );


            $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'
            <select name="urlType[]">
                <option value ="0" '.$linkTypeSelect[0].'>'.lang('plugin/zhanmishu_app', 'URL').'</option>
                <option value ="1" '.$linkTypeSelect[1].'>'.lang('plugin/zhanmishu_app', 'appPage').'</option>
            </select>';

            $image = $value['image'] ? $value['image'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';

                $appHanderarr = array(
                '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                '<input type="text" class="txt" name="order['.$value['id'].']" value="'.$value['order'].'" />',
                '<input type="text" class="txt" name="title['.$value['id'].']" value="'.$value['title'].'" />',
                '<a href ="'.$value['image'].'" target="_blank"><img src="'.$image.'" width="60px" height="140px"></a><input type="text" class="txt" style="width:100px;" name="image['.$value['id'].']" placeholder="'.lang('plugin/zhanmishu_app','image_placeholder').'" value="'.$value['image'].'" />
                <input style="width:140px" type="file"  name="image_file['.$value['id'].']" value="" />',
                '<input type="text"  name="url['.$value['id'].']" value="'.$value['url'].'" />'.$urlType,
                '<textarea  name="description['.$value['id'].']" value="'.$value['description'].'" >'.$value['description'].'</textarea>',
            );
            showtablerow('',
                array(
                    'class="td25"', 
                    'class="td25"', 
                    'class="td25"', 
                    'class="td22"',
                    'class="td22"',
                    'class="td22"'
                ),
                $appHanderarr
            );

        }
        echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_app', 'adduCenterItem').'</a></div></tr>';

        showsubmit('guideImgSettingSubmit');
        showformfooter(); /*dis'.'m.tao'.'bao.com*/

        $placeholder = lang('plugin/zhanmishu_app','image_placeholder');
        $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'<select name="urlType[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'URL').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'appPage').'</option></select>';
        $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'public').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'H5').'</option><option value ="2">'.lang('plugin/zhanmishu_app', 'minapp').'</option><option value ="3">'.lang('plugin/zhanmishu_app', 'app').'</option></select>';

        echo <<<EOT
        <script type="text/JavaScript">
            var rowtypedata = [
                [
                    [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                    [1,'<input type="text" class="txt" name="order[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="title[]" value="">', 'td22'],
                    [1,'<a href="javascript:;" target="_blank"><img src="source/plugin/zhanmishu_app/template/images/noimg.jpg" width="60px" height="140px"><input type="text" class="txt" style="width:100px;" placeholder="{$placeholder}" name="image[]" value="" /></a><input type="file" class="" name="image_file[]" style="width:140px;" value="">', 'td25'],
                    [1,'<input type="text" required class="" name="url[]" value="">{$urlType}', 'td22'],
                    [1,'<textarea required class="" name="description[]" value=""></textarea>', 'td22'],
                ]
            ];
        </script>
EOT;

    }
}