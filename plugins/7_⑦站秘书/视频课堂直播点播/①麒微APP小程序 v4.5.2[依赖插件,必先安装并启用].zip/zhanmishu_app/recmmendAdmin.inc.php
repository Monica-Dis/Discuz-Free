<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_app/source/Autoloader.php';
$appHander = zhanmishu_app::getInstance();

$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_app&pmod=recmmendAdmin';
$formurl = 'plugins&operation=config&identifier=zhanmishu_app&pmod=recmmendAdmin';


$_GET['method'] = $_GET['method'] ? $_GET['method'] : 'find_topic';
$recommendItem = array(
    'normal'=>array(
        'menu'=> array(
            array(
                'title'=>lang('plugin/zhanmishu_app','find_topic'),
                'link'=>$mpurl.'&method=find_topic',
                'selected'=> $_GET['method'] == 'find_topic' ? 'selected' : ''
            )
        ),
    )
);

zhanmishu_app_admin::importPureCss();
zhanmishu_app_admin::menuHorizontal($recommendItem['normal']['title'],$recommendItem['normal']['menu']);


if ($_GET['method'] == 'find_topic') {
    if (submitcheck('FindRcommendTopicSubmit')) {
        $images = zhanmishu_app::uploadimg();

        $recmmend_list = array();
        foreach ($_GET['title'] as $key => $value) {
            if (!$value || in_array($key, $_GET['delete'])) {
                continue;
            }
            $recmmend_list[] = array(
                'order'=>$_GET['order'][$key],
                'title'=>$_GET['title'][$key],
                'image'=>$images[$key] ? $images[$key] : $_GET['image'][$key] ,
                'url'=>$_GET['url'][$key],
                'urlType'=>$_GET['urlType'][$key],
                'platform'=>$_GET['platform'][$key],
                'description'=>$_GET['description'][$key]
            );
        }

        $appHander->writeToCache('recmmend',$recmmend_list);
        

        cpmsg(lang('plugin/zhanmishu_app', 'update_recmmend_list_success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=recmmendAdmin','success');

    }else{

        $recmmend_list = $appHander->GetFromCache('recmmend');

        showformheader($formurl.'&act=editcat','enctype="multipart/form-data"');
        showtableheader(lang('plugin/zhanmishu_app','recmmend_list'));
        showsubtitle(array(
            lang('plugin/zhanmishu_app', 'delete'),
            lang('plugin/zhanmishu_app', 'order'),
            lang('plugin/zhanmishu_app', 'title'),
            lang('plugin/zhanmishu_app', 'image'),
            lang('plugin/zhanmishu_app', 'url'),
            lang('plugin/zhanmishu_app', 'description')
        ));

        foreach ($recmmend_list as $key => $value) {
            $value['id'] = $key;
            $linkTypeSelect = array(
                $value['urlType'] == '0' ? ' selected' : '',
                $value['urlType'] == '1' ? ' selected' : '',
            );
            $recommendType = array(
                $value['platform'] == '0' ? ' selected' : '',
                $value['platform'] == '1' ? ' selected' : '',
                $value['platform'] == '2' ? ' selected' : '',
                $value['platform'] == '3' ? ' selected' : '',
            );

            $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'
            <select name="urlType[]">
                <option value ="0" '.$linkTypeSelect[0].'>'.lang('plugin/zhanmishu_app', 'URL').'</option>
                <option value ="1" '.$linkTypeSelect[1].'>'.lang('plugin/zhanmishu_app', 'appPage').'</option>
            </select>';

            $image = $value['image'] ? $value['image'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
            $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]">
                    <option value ="0" '.$recommendType[0].'>'.lang('plugin/zhanmishu_app', 'public').'</option>
                    <option value ="1" '.$recommendType[1].'>'.lang('plugin/zhanmishu_app', 'H5').'</option>
                    <option value ="2" '.$recommendType[2].'>'.lang('plugin/zhanmishu_app', 'minapp').'</option>
                    <option value ="3" '.$recommendType[3].'>'.lang('plugin/zhanmishu_app', 'app').'</option>
                </select>';

                $appHanderarr = array(
                '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                '<input type="text" class="txt" name="order['.$value['id'].']" value="'.$value['order'].'" />',
                '<input type="text" class="txt" name="title['.$value['id'].']" value="'.$value['title'].'" />',
                '<img src="'.$image.'" width="149px" height="82px">
                <input type="text" class="txt" style="width:143px;" name="image['.$value['id'].']" placeholder="'.lang('plugin/zhanmishu_app','image_placeholder').'" value="'.$value['image'].'" />
                <input style="width:143px" type="file"  name="image_file['.$value['id'].']" value="" />',
                '<input type="text"  name="url['.$value['id'].']" value="'.$value['url'].'" />'.$urlType,
                '<textarea  name="description['.$value['id'].']" value="'.$value['description'].'" >'.$value['description'].'</textarea>',
            );
            showtablerow('',
                array(
                    'class="td25"', 
                    'class="td25"', 
                    'class="td22"',
                    'class="td25"',
                    'class="td22"',
                    'class="td22"'
                ),
                $appHanderarr
            );

        }
        echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_app', 'addRecommendItem').'</a></div></tr>';

        showsubmit('FindRcommendTopicSubmit');
        showformfooter(); /*dis'.'m.tao'.'bao.com*/

        $placeholder = lang('plugin/zhanmishu_app','image_placeholder');
        $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'<select name="urlType[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'URL').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'appPage').'</option></select>';
        $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'public').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'H5').'</option><option value ="2">'.lang('plugin/zhanmishu_app', 'minapp').'</option><option value ="3">'.lang('plugin/zhanmishu_app', 'app').'</option></select>';

        echo <<<EOT
        <script type="text/JavaScript">
            var rowtypedata = [
                [
                    [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                    [1,'<input type="text" class="txt" name="order[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="title[]" value="">', 'td22'],
                    [1,'<img src="source/plugin/zhanmishu_app/template/images/noimg.jpg" width="149px" height="82px"><input type="text" class="txt" style="width:143px;" placeholder="{$placeholder}" name="image[]" value="" /><input type="file" class="" name="image_file[]" style="width:143px;" value="">', 'td25'],
                    [1,'<input type="text" required class="" name="url[]" value="">{$urlType}', 'td22'],
                    [1,'<textarea required class="" name="description[]" value=""></textarea>', 'td22'],
                ]
            ];
        </script>
EOT;

    }
}