<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * 
 */
class zhanmishu_app_video extends zhanmishu_app
{
    public function findVideos(){
        global $_G;

        require_once libfile('function/attachment');
        $inforum = '';
        $authorid = '';
        $authorid = '';
        $attachments = array();
        $attachuids = $attachusers = array();
        $_GET['perpage'] = intval($_GET['perpage']) < 1 ? 20 : intval($_GET['perpage']);
        $perpage = ($_GET['pp'] ? $_GET['pp'] : $_GET['perpage']) / 10;
        $page = $_GET['page'] > 0 ? $_GET['page'] + 0 : '1';
        $attachmentcount = 0;

        for($attachi = 0;$attachi < 10;$attachi++) {
            $attachmentarray = array();
            $attachmentcount += C::t('#zhanmishu_app#forum_attachment_app')->fetch_all_for_manage($attachi, $inforum, $authorid, $_GET['filename'], $_GET['keywords'], $_GET['sizeless'], $_GET['sizemore'], $_GET['dlcountless'], $_GET['dlcountmore'], $_GET['daysold'], 1,'','','mp4');
            $query = C::t('#zhanmishu_app#forum_attachment_app')->fetch_all_for_manage($attachi, $inforum, $authorid, $_GET['filename'], $_GET['keywords'], $_GET['sizeless'], $_GET['sizemore'], $_GET['dlcountless'], $_GET['dlcountmore'], $_GET['daysold'], 0, (($page - 1) * $perpage), $perpage,'mp4');
            foreach($query as $attachment) {
                $attachuids[$attachment['uid']] = $attachment['uid'];
                $attachmentarray[] = $attachment;
            }
            $attachusers += C::t('common_member')->fetch_all($attachuids);

            $attachments = array_merge($attachments,$attachmentarray);
        }

        $attachData = array();
        $attachData['list'] = $attachments;
        $attachData['count'] = $attachmentcount;
        return $attachData;
    }

    function attachConvertThreadList($attachList = array()) {

        $threadList = array();
        foreach ($attachList as $key => $attach) {
            $threadList[$key] = $this->getThreadInfo($attach['tid']);
            $threadList[$key]['dbdateline'] = $attach['dateline'];
        }
        return $threadList;
    }
}