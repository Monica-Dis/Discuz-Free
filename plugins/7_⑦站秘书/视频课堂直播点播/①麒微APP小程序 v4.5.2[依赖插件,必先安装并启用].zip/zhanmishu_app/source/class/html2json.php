<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class html2json {
    public function html2jsonobj($html,$encoding='UTF-8') {
        $dom = new \DOMDocument();
        $html = str_replace("\n",'', str_replace("\r\n",'', $html));//替换多余的换行符
        $dom->loadHTML('<?xml encoding="'.$encoding.'">' . $html);//编码格式
        $returnobj = $this->element2obj($dom->documentElement);
        $return=[];
        if( isset($returnobj['children'][0]['children']) && !empty($returnobj['children'][0]['children']) ){
            $return=$returnobj['children'][0]['children'];
        }
        return json_encode(['nodes'=>$return]);
    }
    public function html2jsonarr($html,$encoding='UTF-8'){
        $dom = new \DOMDocument();
        $html = str_replace("\n",'', str_replace("\r\n",'', $html));//替换多余的换行符
        $dom->loadHTML('<?xml encoding="'.$encoding.'">' . $html);//编码格式
        return $this->element2obj($dom->documentElement);
    }
    private function element2obj($element) {
        $obj = array("name" => str_replace('section', 'span', $element->tagName));
        foreach ($element->attributes as $attribute) {
            if (
                trim($attribute->value)!= '') {
                $obj['attrs'][$attribute->name] = $attribute->value;
                if ($attribute->name == 'src') {//如果是图片则让他的最大尺寸不要超过100%
                    $obj['attrs']['style'] = 'margin: 0px; padding: 0px; max-width: 100%;max-height:100%';
                }
            }
        }
        if (!isset($obj['attrs'])) {
            $obj['attrs'] = array();
        }
        if (!isset($obj['attrs']['style'])) {
             $obj['attrs']['style'] = '';
        }
        
        foreach ($element->childNodes as $subElement) {
            if ($subElement->nodeType == XML_TEXT_NODE) {//text节点
                if (trim($subElement->wholeText)!= '') {//屏蔽为空的text节点
                    $obj["children"][] =['type' =>'text','text' =>$subElement->wholeText];
                }
            } else {
                $obj["children"][] = $this->element2obj($subElement);
            }
        }
        return $obj;
    }
}