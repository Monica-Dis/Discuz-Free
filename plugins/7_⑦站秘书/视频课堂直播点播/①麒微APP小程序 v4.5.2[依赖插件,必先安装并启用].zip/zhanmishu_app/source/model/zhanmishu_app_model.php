<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (!class_exists('zhanmishu_base',false)) {
    C::import('zhanmishu_base','plugin/zhanmishu_app/source/class');
}
/**
 * 
 */
class zhanmishu_app_model
{

    static function strToArray($str){
        $str = str_replace(array("\r\n", "\r", "\n"), array('$#','$#','$#'), $str);
        $arr = explode('$#', $str);

        $arr = array_filter($arr);
        return $arr;
    }
    static function arrayToStr($array = array()){
        return implode("\r\n", $array);
    }
    /**
     * array_column() // 不支持低版本;
     * 以下方法兼容PHP低版本
     */
    static function  darray_column($array = array(), $column_key='', $index_key=null){

        if (function_exists('array_column')) {
            return array_column($array, $column_key, $index_key);
        }
        $result = array();
        foreach($array as $arr) {
            if(!is_array($arr)) continue;

            if(is_null($column_key)){
                $value = $arr;
            }else{
                $value = $arr[$column_key];
            }

            if(!is_null($index_key)){
                $key = $arr[$index_key];
                $result[$key] = $value;
            }else{
                $result[] = $value;
            }
        }
        return $result; 
    }
}