<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * 
 */
class zhanmishu_app_model_user extends zhanmishu_app_model
{
    public function getUser($username = '', $isUid = true){
        if(!$username){
            return array();
        }
        $isUid = $isUid ? true : false;
        loaducenter();
        return uc_get_user($username, $isUid);
    }
    public function fetchUser($user = array()){
        $username = $user['username'];
        $uid = $user['uid'];
        $field1 = $user['field1'];
        $email = $user['email'];

        if(!$username && !$uid && !$field1 && !$email){
            return array();
        }

        if($uid){
            $member = getuserbyuid($uid);
        }
        if ($username && empty($member)) {
            $member  = self::fetch_by_username($username);
        }
        if ($field1 && empty($member)) {
            $member  = self::fetch_by_field1($field1);
        }
        if ($email && empty($member)) {
            $member  = self::fetch_by_email($email);
        }

        return $member;
    }
    public function fetch_by_username($username=''){
        $user = C::t("common_member")->fetch_by_username($username);
        return $user;
    }
    public function fetch_by_email($email=''){
        $user = C::t("common_member")->fetch_by_email($email);
        return $user;
    }

    public function fetch_by_field1($field1=''){
        $user = DB::fetch_first('SELECT * from %t where field1 = %s', array('common_member_profile', $field1));
        return $user;
    }
    public function ucDeleteUser($uid){
        if(!$uid){
            return false;
        }

        loaducenter();
        $rs = uc_user_delete($uid);

        if($rs > 0){
            return true;
        }
        return false;

    }
    public function register($user, $groupid = 10){
        global $_G;
        $groupid = $groupid ? $groupid : 10;
        loaducenter();
        $uid = uc_user_register($user['username'], $user['password'], $user['email']);

        if ($uid > 0) {
            $ip=$_G['clientip'];
            C::t('common_member')->insert($uid, $user['username'], md5(random(10)), $user['email'], $ip, $groupid, null);
            include_once libfile('function/stat');
            updatestat('register');
        }
        return $uid;
        
    }

}