<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_common_connect_guest.php 29265 2012-03-31 06:03:26Z yexinhao $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_zhanmishu_app_forum_video extends discuz_table {

    public function __construct() {
        $this->_table = 'zhanmishu_app_forum_video';
        $this->_pk = 'pid';

        parent::__construct();
    }

    public function get_one_pid_byfield(array $field = array()){
        if (!empty($field)) {
            $where = ' where ';

            $tmp = array();
            foreach ($field as $key => $value) {
                if (is_string($value)) {
                    $tmp[] = ' '.$key.' = \''.$value.'\' ';
                }else if($value['relation']){
                    switch (trim(strtolower($value['relation']))) {
                        case 'like':
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
                            break;
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        default:
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
                            break;
                    }
                }
            }
            $where .= implode(' and ', $tmp);

        }else{
            $where = '';
        }

        return DB::fetch_first('SELECT * FROM '.DB::table($this->_table).$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
    }
    public function get_pids_num($field=array()){
        if (!empty($field) && is_array($field)) {
            $where = ' where ';
            $tmp = array();
            foreach ($field as $key => $value) {
                if (is_string($value)) {
                    $tmp[] = ' '.$key.' = \''.$value.'\' ';
                }else if($value['relation']){
                    switch (trim(strtolower($value['relation']))) {
                        case 'like':
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
                            break;
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        default:
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
                            break;
                    }
                }
            }
            $where .= implode(' and ', $tmp);

        }else{
            $where = '';
        }

        $count = DB::fetch_first('SELECT count(*) as num FROM '.DB::table($this->_table).$where);
        return $count['num'];
    }
    public function get_type_pid($start=0, $limit=20, $sort = '', $field=array()) {
        if($sort) {
            $this->checkpk();
        }

        if (is_array($sort)) {
            $tmp = array();
            foreach ($sort as $key => $value) {
                $tmp[] = DB::order($key, $value);
            }
            $tmp = implode(' , ', $tmp);

            $order = ' ORDER BY '.$tmp;
        }else{
            $order = $sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '';
        }
        if (!empty($field)) {
            $where = ' where ';

            $tmp = array();
            foreach ($field as $key => $value) {
                if (is_string($value)) {
                    $tmp[] = ' '.$key.' = \''.$value.'\' ';
                }else if($value['relation']){

                    switch (trim(strtolower($value['relation']))) {
                        case 'like':
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
                            break;
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        default:
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
                            break;
                    }
                }
            }
            $where .= implode(' and ', $tmp);

        }else{
            $where = '';
        }
        return  DB::fetch_all('SELECT * FROM '.DB::table($this->_table).$where.$order.DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '',array());

    }

}