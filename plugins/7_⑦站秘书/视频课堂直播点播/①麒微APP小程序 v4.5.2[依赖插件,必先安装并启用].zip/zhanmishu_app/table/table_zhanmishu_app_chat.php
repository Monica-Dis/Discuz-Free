<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_zhanmishu_app_chat extends discuz_table {

    public function __construct() {
        $this->_table = 'zhanmishu_app_chat';
        $this->_pk = 'chat_id';

        parent::__construct();
    }

    public function chatingList($uid = ''){
        if (!$uid) {
            return false;
        }
        return DB::fetch_all('SELECT distinct to_uid, uid from %t where isdel = 0 and ( uid = %s or to_uid = %s) order by chat_id desc',array($this->_table,$uid,$uid));
    }

    public function delete_chat_byuid($uid=0,$cid=0){
        return DB::update($this->_table,array('isdel'=>'1'),'uid='.$uid.' and cid = '.$cid);
    }

    public function get_one_chat_byfield($field , $sort=''){
        if (!empty($field)) {
            $where = ' where ';

            $tmp = array();
            foreach ($field as $key => $value) {
                if (!is_array($value)) {
                    $tmp[] = ' '.$key.' = \''.$value.'\' ';
                }else if(is_array($value) &&  $value['relation']){
                    switch (trim(strtolower($value['relation']))) {
                        case 'like':
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
                            break;
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        default:
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
                            break;
                    }
                }
            }
            $where .= implode(' and ', $tmp);

        }else{
            $where = '';
        }
        return DB::fetch_first('SELECT * FROM '.DB::table($this->_table).$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
    }

    public function get_type_chat_num($field=array()){

        if (!empty($field)) {
            $where = ' where ';

            $tmp = array();
            foreach ($field as $key => $value) {
                if (!is_array($value)) {
                    $tmp[] = ' '.$key.' = \''.$value.'\' ';
                }else if(is_array($value) &&  $value['relation']){
                    switch (trim(strtolower($value['relation']))) {
                        case 'like':
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
                            break;
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        default:
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
                            break;
                    }
                }
            }


            $where .= implode(' and ', $tmp);

        }else{
            $where = '';
        }

        $count = DB::fetch_first('SELECT count(*) as num FROM '.DB::table($this->_table).$where);

        return $count['num'];
    }

    public function get_type_chat($start, $limit =20, $sort = '',$field) {
        if($sort) {
            $this->checkpk();
        }


        if (is_array($sort)) {
            $tmp = array();
            foreach ($sort as $key => $value) {
                $tmp[] = DB::order($key, $value);
            }
            $tmp = implode(' , ', $tmp);

            $order = ' ORDER BY '.$tmp;
        }else{
            $order = $sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '';
        }

        if (!empty($field)) {
            $where = ' where ';

            $tmp = array();
            foreach ($field as $key => $value) {
                if (!is_array($value)) {
                    $tmp[] = ' '.$key.' = \''.$value.'\' ';
                }else if(is_array($value) &&  $value['relation']){
                    switch (trim(strtolower($value['relation']))) {
                        case 'like':
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
                            break;
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        default:
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
                            break;
                    }
                }
            }


            $where .= implode(' and ', $tmp);

        }else{
            $where = '';
        }
        return  DB::fetch_all('SELECT * FROM '.DB::table($this->_table).$where.($order).DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
    }

}
//dis'.'m.tao'.'bao.com
?>