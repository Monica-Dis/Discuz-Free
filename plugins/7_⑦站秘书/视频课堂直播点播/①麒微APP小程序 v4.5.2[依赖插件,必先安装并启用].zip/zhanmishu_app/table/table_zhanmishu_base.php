<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_zhanmishu_base extends discuz_table {
    public function delete_one($field = array(), $limit = 1){
        if (empty($field)) {
            return;
        }

        if (!empty($field)) {
            $tmp = array();
            foreach ($field as $key => $value) {
                if (!is_array($value)) {
                    //$tmp[] = ' '.$key.' = \''.$value.'\' ';
                    $tmp[] = DB::field($key, $value, '=');
                }else if(is_array($value) &&  $value['relation']){
                    switch (trim(strtolower($value['relation']))) {
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        case 'like':
                            $tmp[] = DB::field($key, '%'.trim(strtolower($value['value'])).'%', trim(strtolower($value['relation'])));
                            break;
                        case 'in':
                            $tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
                            break;
                        case 'not in':
                            $tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
                            break;
                        default:
                            $tmp[] = DB::field($key, trim(strtolower($value['value'])), trim(strtolower($value['relation'])));
                            break;
                    }
                }
            }
            $condition .= implode(' and ', $tmp);
        }

        return DB::delete($this->_table, $condition, $limit);
    }

    public function fetch_one($field = array(), $order=''){
        if($order) {
            $this->checkpk();
        }
        if (is_array($order)) {
            $tmp = array();
            foreach ($order as $key => $value) {
                $tmp[] = DB::order($key, $value);
            }
            $tmp = implode(' , ', $tmp);

            $order = ' ORDER BY '.$tmp;
        }else{
            $order = $order ? ' ORDER BY '.DB::order($this->_pk, $order) : '';
        }
        if (!empty($field)) {
            $where = ' where ';
            $tmp = array();
            foreach ($field as $key => $value) {
                if (!is_array($value)) {
                    //$tmp[] = ' '.$key.' = \''.$value.'\' ';
                    $tmp[] = DB::field($key, $value, '=');
                }else if(is_array($value) &&  $value['relation']){
                    switch (trim(strtolower($value['relation']))) {
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        case 'like':
                            $tmp[] = DB::field($key, '%'.trim(strtolower($value['value'])).'%', trim(strtolower($value['relation'])));
                            break;
                        case 'in':
                            $tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
                            break;
                        case 'not in':
                            $tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
                            break;
                        default:
                            $tmp[] = DB::field($key, trim(strtolower($value['value'])), trim(strtolower($value['relation'])));
                            break;
                    }
                }
            }
            $where .= implode(' and ', $tmp);
        }else{
            $where = '';
        }
        return DB::fetch_first('SELECT * FROM '.DB::table($this->_table).$where.$order.DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
    }

    public function fetch_num($field=array()){
        if (!empty($field)) {
            $where = ' where ';
            $tmp = array();
            foreach ($field as $key => $value) {
                if (!is_array($value)) {
                    //$tmp[] = ' '.$key.' = \''.$value.'\' ';
                    $tmp[] = DB::field($key, $value, '=');
                }else if(is_array($value) &&  $value['relation']){
                    switch (trim(strtolower($value['relation']))) {
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        case 'like':
                            $tmp[] = DB::field($key, '%'.trim(strtolower($value['value'])).'%', trim(strtolower($value['relation'])));
                            break;
                        case 'in':
                            $tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
                            break;
                        case 'not in':
                            $tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
                            break;
                        default:
                            $tmp[] = DB::field($key, trim(strtolower($value['value'])), trim(strtolower($value['relation'])));
                            break;
                    }
                }
            }
            $where .= implode(' and ', $tmp);
        }else{
            $where = '';
        }

        $count = DB::fetch_first('SELECT count(*) as num FROM '.DB::table($this->_table).$where);
        return $count['num'];
    }

    public function fetch_sum($sumKey='', $field=array()){
        if (!$sumKey) {
            return false;
        }
        if (!empty($field)) {
            $where = ' where ';
            $tmp = array();
            foreach ($field as $key => $value) {
                if (!is_array($value)) {
                    //$tmp[] = ' '.$key.' = \''.$value.'\' ';
                    $tmp[] = DB::field($key, $value, '=');
                }else if(is_array($value) &&  $value['relation']){
                    switch (trim(strtolower($value['relation']))) {
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        case 'like':
                            $tmp[] = DB::field($key, '%'.trim(strtolower($value['value'])).'%', trim(strtolower($value['relation'])));
                            break;
                        case 'in':
                            $tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
                            break;
                        case 'not in':
                            $tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
                            break;
                        default:
                            $tmp[] = DB::field($key, trim(strtolower($value['value'])), trim(strtolower($value['relation'])));
                            break;
                    }
                }
            }
            $where .= implode(' and ', $tmp);
        }else{
            $where = '';
        }

        $sum = DB::fetch_first('SELECT sum('.$sumKey.') as num FROM '.DB::table($this->_table).$where);
        return $sum['num'];
    }
    public function fetch_all($start = 0, $limit = 100, $order = '',$field = array()) {
        if($order) {
            $this->checkpk();
        }

        if (is_array($order)) {
            $tmp = array();
            foreach ($order as $key => $value) {
                $tmp[] = DB::order($key, $value);
            }
            $tmp = implode(' , ', $tmp);

            $order = ' ORDER BY '.$tmp;
        }else{
            $order = $order ? ' ORDER BY '.DB::order($this->_pk, $order) : '';
        }
        if (!empty($field)) {
            $where = ' where ';
            $tmp = array();
            foreach ($field as $key => $value) {
                if (!is_array($value)) {
                    $tmp[] = ' '.$key.' = \''.$value.'\' ';
                }else if(is_array($value) &&  $value['relation']){
                    switch (trim(strtolower($value['relation']))) {
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        case 'like':
                            $tmp[] = DB::field($key, '%'.trim(strtolower($value['value'])).'%', trim(strtolower($value['relation'])));
                            break;
                        case 'in':
                            $tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
                            break;
                        case '=':
                            $tmp[] = ' '.$value['key'].' = '.$value['value'].' ';
                            break;
                        case 'not in':
                            $tmp[] = ' '.$value['key'].' in '.$value['value'].' ';
                            break;
                        default:
                            $tmp[] = DB::field($key, trim(strtolower($value['value'])), trim(strtolower($value['relation'])));
                            break;
                    }
                }
            }
            $where .= implode(' and ', $tmp);
        }else{
            $where = '';
        }

        return  DB::fetch_all('SELECT * FROM '.DB::table($this->_table).$where.$order.DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
    }

}
//dis'.'m.tao'.'bao.com
?>