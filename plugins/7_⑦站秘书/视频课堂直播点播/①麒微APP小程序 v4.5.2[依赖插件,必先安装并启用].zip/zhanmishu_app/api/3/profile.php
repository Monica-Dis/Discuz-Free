<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 

if(!defined('IN_MOBILE_API')) {
    exit('Access Denied');
}

$_GET['mod'] = 'space';
$_GET['do'] = 'profile';

include_once 'home.php';


class zhanmishu_app_origin_api{

    function common() {
    }

    function output() {
        global $_G;
        $data = $GLOBALS['space'];
        $data['groupiconid'] = zhanmishu_app_api::usergroupIconId($data['groupid']);
        if($data['group']['type'] == 'member' && $data['group']['groupcreditslower'] != 999999999) {
            $data['upgradecredit'] = $data['group']['creditslower'] - $data['credits'];
            $data['upgradeprogress'] = 100 - ceil($data['upgradecredit'] / ($data['group']['creditslower'] - $data['group']['creditshigher']) * 100);
            $data['upgradeprogress'] = max($data['upgradeprogress'], 2);
        }
        unset($data['password'], $data['email'], $data['regip'], $data['lastip'], $data['regip_loc'], $data['lastip_loc']);

        $data['isTeacher'] = 0;
        if ($data['uid']) {
            $data['avatar'] = avatar($data['uid'], 'middle', true);
            if (is_file(DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/class/zhanmishu_video.php')) {
                include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';
                $videoHander = zhanmishu_video::getInstance();
                if ($videoHander->checkIsTeacher($data['uid'])) {
                    $data['teacherInfo'] = $videoHander->getTeacherInfo($data['uid'], false, false, true);
                    if (!empty($data['teacherInfo'])) {
                        $data['isTeacher'] = 1;
                        $data['recentnote'] = $data['teacherInfo']['teacher_intro'] ? $data['teacherInfo']['teacher_intro'] : $data['recentnote'];

                        $field = array();
                        $field['isdel'] = '0';
                        $field['uid'] = $data['uid'];
                        $data['course_num'] = $videoHander->get_type_course_num($field);
                        $data['course'] = array_values($videoHander->get_type_course_filter_format(0, 10,'desc',$field));
                        
                        if (!class_exists('zhanmishu_video_course_column_controller',false)) {
                            C::import('zhanmishu_video_course_column_controller','plugin/zhanmishu_video/source/class');
                        }
                        $colunmHander = new zhanmishu_video_course_column_controller($videoHander);
                        $data['column_num'] = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch_num_by_field($field);
                        $data['column'] = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch_by_field(0, 10, 'desc', $field);
                        foreach ($data['column'] as $key => $value) {
                            $data['column'][$key] = $colunmHander->_courseColumnFormat($value);
                        }
                        $data['column'] = array_values($data['column']);
                    }
                }
            }
        }

        $data['isfollow'] = 0;
        if ($data['uid'] != $_G['uid']) {
            $flag = C::t('home_follow')->fetch_status_by_uid_followuid($_G['uid'], $data['uid']);
            if (!empty($flag)) {
                $data['isfollow'] = 1;
            }
        }

        $resultData = array(
            'space' => $data,
            'extcredits' => $_G['setting']['extcredits']
        );

        echo zhanmishu_app_api::resultToJson($resultData);
        exit;
    }

}