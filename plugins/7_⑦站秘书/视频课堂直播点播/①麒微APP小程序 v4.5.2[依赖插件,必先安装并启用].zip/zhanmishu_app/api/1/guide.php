<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_MOBILE_API')) {
    exit('Access Denied');
}

$_GET['mod'] = 'guide';
include_once 'forum.php';



class zhanmishu_app_origin_api{

    function common() {
        global $_G;
        $_G['siteurl'] = str_replace('source/plugin/zhanmishu_app/','',$_G['siteurl']);
        $perpage = 15;
        $setting_guide = unserialize($_G['setting']['guide']);
        $setting_guide[$_GET['view'].'dt'] =   $setting_guide[$_GET['view'].'dt'] ? $setting_guide[$_GET['view'].'dt'] * 1000 : 3600*24*365*3;
        $_G['setting']['guide'] = serialize($setting_guide);

        $viewModule = $_GET['view'];
        if ($viewModule == 'video') {
            global $_G;
            $videoHander = new zhanmishu_app_video();
            $attachData = $videoHander->findVideos();
            $threadList =  $videoHander->attachConvertThreadList($attachData['list']);
                
            $data['member']['uid'] = $_G['uid'];
            $data['member']['groupid'] = $_G['groupid'];
            $data['member']['username'] = $_G['username'];
            $data['member']['formhash'] = FORMHASH;
            $data[$viewModule]['threadlist'] = zhanmishu_app_api::getvalues($threadList, array('/^\d+$/'), array('tid', 'author', 'special', 'authorid', 'subject', 'subject', 'dbdateline', 'dateline', 'dblastpost', 'lastpost', 'lastposter', 'attachment', 'replies', 'readperm', 'views', 'digest', 'cover', 'recommend', 'recommend_add', 'reply', 'avatar', 'displayorder', 'coverpath', 'typeid', 'rushreply', 'replycredit', 'price','video'));
            $data[$viewModule]['threadperpage'] = $perpage;
            $data[$viewModule]['threadcount'] = $attachData['count'];
            $data[$viewModule]['threadlist'] = array_values($data[$viewModule]['threadlist']);
            echo zhanmishu_app_api::resultToJson($data);
            exit;
        }

    }

    function output() {
        global $_G ,$data, $perpage;

        $viewModule = $_GET['view'];
        if ($viewModule) {
            if (!empty($data[$viewModule]['threadlist'])) {
                require_once libfile('function/post');
                require_once libfile('function/attachment');

                foreach ($data[$viewModule]['threadlist'] as $key => $thread) {
                    $thread['post'] = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread['tid']);
                    $thread['preview'] = messagecutstr($thread['post']['message'], 120);
                    $attachments = C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid']);
                    $attachs = $imgattachs = array();
                    $thread['is_video'] = 0;
                    foreach(C::t('forum_attachment')->fetch_all_by_id('pid', $thread['post']['pid'], 'aid') as $attach) {
                            $attach = array_merge($attach, $attachments[$attach['aid']]);
                            $attach['filenametitle'] = $attach['filename'];
                            $attach['ext'] = fileext($attach['filename']);


                            getattach_row($attach, $attachs, $imgattachs);

                            foreach ($attachs['used'] as $attach) {
                                if ($attach['ext'] == 'mp4') {
                                    $thread['is_video'] = 1;
                                }
                                if (!$attach['price'] && !$attach['readperm'] && $thread['is_video']) {
                                    $thread['video'] = $attach;
                                }else{
                                    $thread['video'] = array();
                                }
                            }
                    }

                    foreach ($imgattachs['used'] as $imageKey => $imageValue) {
                        if ($imageValue['remote'] < 1) {
                            $imgattachs['used'][$imageKey]['attachment'] = getforumimg($imageValue['aid'], 0, 360, 261);
                            $imgattachs['used'][$imageKey]['url'] = $_G['siteurl'];
                        }else{
                            $appHander = zhanmishu_app::getInstance();
                            $imgattachs['used'][$imageKey]['attachment'] .= $appHander->config['remoteImageAdd'];
                            
                        }
                    }

                    unset($thread['post']['message']);
                    if ($viewModule == 'hot' && count($imgattachs['used']) > 1) {
                        $imgattachs['used'] = array_slice($imgattachs['used'], 0,1);
                        $thread['attachments'] = array_values($imgattachs['used']);
                    }else if (count($imgattachs['used']) > 3) {
                        $imgattachs['used'] = array_slice($imgattachs['used'], 0,3);
                        $thread['attachments'] = array_values($imgattachs['used']);
                    }else if (count($imgattachs['used'])) {
                        $thread['attachments'] = array_values($imgattachs['used']);
                    }else{
                        $thread['attachments'] = array();
                    }
                    // 显示样式
                    if ($viewModule == 'video') {
                        $thread['list_style'] = '10';
                    }else if ($viewModule == 'hot') {
                        if (count($imgattachs['used'])) {
                            $thread['list_style'] = '12';
                        }else{
                            $thread['list_style'] = '7';
                        }
                        
                    }
                    if (!$thread['list_style']) {
                        switch (count($imgattachs['used'])) {
                            case 0:
                                if (mb_strlen($thread['preview']) < 15) {
                                    $thread['list_style'] = '7';
                                }else{
                                    $thread['list_style'] = '6';
                                }
                                break;
                            case 1:
                                if (mb_strlen($thread['preview']) < 15) {
                                    $thread['list_style'] = '1';
                                }else{
                                    $thread['list_style'] = '2';
                                }
                                break;
                            case 2:
                                if (mb_strlen($thread['preview']) < 15) {
                                    $thread['list_style'] = '1';
                                }else{
                                    $thread['list_style'] = '2';
                                }
                                break;
                            default:
                                $thread['list_style'] = '3';
                                break;
                        }
                    }
                    
                    $data['member']['uid'] = $_G['uid'];
                    $data['member']['groupid'] = $_G['groupid'];
                    $data['member']['username'] = $_G['username'];
                    $data['member']['formhash'] = FORMHASH;
                    $data[$viewModule]['threadlist'][$key] = $thread;

                }
                $data[$viewModule]['threadlist'] = array_values($data[$viewModule]['threadlist']);
                $data[$viewModule]['threadperpage'] = $perpage;

                $recommend = array();
                if ($viewModule == 'digest') {
                    $videoFile = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/class/zhanmishu_video.php';
                    if (is_file($videoFile)) {
                        include_once $videoFile;
                        $videoHander = zhanmishu_video::getInstance();
                        $best = $videoHander->get_app_best();
                        foreach ($best as $key => $value) {
                            $recommend[$key]['image'] = $value['image'];
                            $recommend[$key]['description'] = $value['course_intro'];
                            $recommend[$key]['title'] = $value['course_name'];
                            $recommend[$key]['url'] = 'myapp://course?cid='.$value['cid'];
                            $recommend[$key]['cid'] = $value['cid'];
                        }
                        $data['recommend'] = $recommend;
                    }
                }

            }
        }

        echo zhanmishu_app_api::resultToJson($data);
        exit;
    }

}