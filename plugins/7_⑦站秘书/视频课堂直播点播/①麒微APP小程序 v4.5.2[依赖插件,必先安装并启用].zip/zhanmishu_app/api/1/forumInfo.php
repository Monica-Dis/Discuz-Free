<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 
if (!defined('IN_MOBILE_API')) {
    exit('Access Denied');
}

$_GET['mod'] = 'forumdisplay';
include_once 'forum.php';

class zhanmishu_app_origin_api {

    function common() {
    }

    function output() {
        global $_G;
        $resultData = array();

        //帖子类型
        if (!empty($_G['forum']['threadtypes'])) {
            $resultData['threadTypes'] = $_G['forum']['threadtypes'];
        }


        //特殊发帖字段
        if(!empty($_G['forum']['threadsorts'])){
            if(isset($_GET['status']) && $_GET['status'] == 2) {
                $sortsKeyList = array_keys($_G['forum']['threadsorts']['types']);
                $sortsList = array();
                foreach($sortsKeyList as $sortsKey) {
                    $threadSorts = array();
                    $threadSortOptionNew = array();
                    
                    $threadSorts['sortId'] = $sortsKey;
                    $threadSorts['types'] = $_G['forum']['threadsorts']['types'][$sortsKey];
                    $threadSorts['description'] = $_G['forum']['threadsorts']['description'][$sortsKey];

                    $threadSortOption = $_G['cache']['threadsort_option_'.$sortsKey];
                    foreach($threadSortOption as $k=>$v){
                        $threadSortOptionNew[$k]['title'] = $v['title'];
                        $threadSortOptionNew[$k]['identifier'] = $v['identifier'];
                        $threadSortOptionNew[$k]['type'] = $v['type'];
                        $threadSortOptionNew[$k]['description'] = $v['description'];
                        if($v['choices'])$threadSortOptionNew[$k]['choices'] = $v['choices'];
                    }
                    sort($threadSortOptionNew);
                    $sortsList[] = array(
                        'sortId' => $threadSorts['sortId'],
                        'types' => $threadSorts['types'],
                        'description' => $threadSorts['description'],
                        'option' => $threadSortOptionNew
                    );
                }
                $resultData['threadSorts'] = $sortsList;
                $resultData['type'] = 1;
            } else {
            
                $threadSorts = '';
                $threadSortOptionNew = array();

                $sortsKey = array_keys($_G['forum']['threadsorts']['types']);
                $sortsKey = $sortsKey['0'];

                $threadSorts['sortId'] = $sortsKey;
                $threadSorts['types'] = $_G['forum']['threadsorts']['types'][$sortsKey];
                $threadSorts['description'] = $_G['forum']['threadsorts']['description'][$sortsKey];

                $threadSortOption = $_G['cache']['threadsort_option_'.$sortsKey];
                foreach($threadSortOption as $k=>$v){
                    $threadSortOptionNew[$k]['title'] = $v['title'];
                    $threadSortOptionNew[$k]['identifier'] = $v['identifier'];
                    $threadSortOptionNew[$k]['type'] = $v['type'];
                    $threadSortOptionNew[$k]['description'] = $v['description'];
                    if($v['choices'])$threadSortOptionNew[$k]['choices'] = $v['choices'];
                }
                sort($threadSortOptionNew);

                $resultData['threadSorts']['sortId'] = $threadSorts['sortId'];
                $resultData['threadSorts']['types'] = $threadSorts['types'];
                $resultData['threadSorts']['description'] = $threadSorts['description'];
                $resultData['threadSorts']['option'] = $threadSortOptionNew;
                
                $resultData['type'] = 2;
            }
        }

        //权限
        $resultData['forumPerm']['viewperm'] = !$_G['forum']['viewperm'] || forumperm($_G['forum']['viewperm']);
        $resultData['forumPerm']['postperm'] = !$_G['forum']['postperm'] || forumperm($_G['forum']['postperm']);
        $resultData['forumPerm']['replyperm'] =  !$_G['forum']['replyperm'] || forumperm($_G['forum']['replyperm']);
        $resultData['forumPerm']['getattachperm'] =  !$_G['forum']['getattachperm'] || forumperm($_G['forum']['getattachperm']);
        $resultData['forumPerm']['postattachperm'] =  !$_G['forum']['postattachperm'] || forumperm($_G['forum']['postattachperm']);
        $resultData['forumPerm']['postimageperm'] =  !$_G['forum']['postimageperm'] || forumperm($_G['forum']['postimageperm']);

        $resultData['swfconfig'] = getuploadconfig($_G['uid'], $_GET['fid']);

        $resultData['member'] = array(
            'uid'=>$_G['uid'],
            'formhash'=>FORMHASH,
            'username'=>$_G['username'],
            'groupid'=>$_G['groupid'],
            'hash' => md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']),
            'avatar'=>avatar($_G['uid'], 'middle', true),
            'ismoderator' => $_G['forum']['ismoderator'],
            'readaccess' => $_G['group']['readaccess'],
            'notice' => array(
                'newpm' => dintval($_G['member']['newpm']),
                'newprompt' => dintval(($_G['member']['newprompt'] - $_G['member']['category_num']['mypost']) >= 0 ? ($_G['member']['newprompt'] - $_G['member']['category_num']['mypost']) : 0),
                //'newmypost' => dintval($_G['member']['category_num']['mypost']),
                'newmypost' => dintval($_G['member']['newprompt_num']['post']+$_G['member']['newprompt_num']['pcomment']),
            )
        );

        echo zhanmishu_app_api::resultToJson($resultData);
        exit;
    }
}
//dis'.'m.tao'.'bao.com
?>
