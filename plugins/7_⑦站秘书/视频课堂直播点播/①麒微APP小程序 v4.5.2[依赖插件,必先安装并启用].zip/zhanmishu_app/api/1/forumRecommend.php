<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 
if (!defined('IN_MOBILE_API')) {
    exit('Access Denied');
}

if (isset($_GET['pid']) && $_GET['pid']) {
    $_GET['action'] = 'postreview';
    $_GET['do'] = 'support';
}else{
    $_GET['action'] = 'recommend';
    $_GET['do'] = 'add';

}

$_GET['mod'] = 'misc';
include_once 'forum.php';

class zhanmishu_app_origin_api {

    function common() {
    }

    function output(){
        echo zhanmishu_app_api::resultToJson();
        exit;        
    }
}
