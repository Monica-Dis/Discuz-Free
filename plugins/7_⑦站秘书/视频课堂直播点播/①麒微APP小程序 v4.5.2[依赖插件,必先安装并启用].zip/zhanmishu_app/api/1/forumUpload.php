<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 
if (!defined('IN_MOBILE_API')) {
    exit('Access Denied');
}
// error_reporting(0);

// define("REQUEST_METHOD_DOMAIN", 'http://wsq.discuz.com');
zhanmishu_app_origin_api::make_cors($_SERVER['REQUEST_METHOD']);
$_GET['mod'] = 'swfupload';
$_POST['mod'] = 'swfupload';
$_GET['action'] = 'swfupload';
$_GET['operation'] = 'upload';

// $_POST['Upload'] = 'Submit Query';
// $_POST['Filename'] = $_FILES['Filedata']['name'];
// $_POST['filetype'] = '.'.addslashes(strtolower(substr(strrchr($_FILES['Filedata']['name'], '.'), 1, 10)));
include_once 'misc.php';

class zhanmishu_app_origin_api {

    function common() {
        global $_G;
        if ($_G['uid']) {
            $_POST['uid'] = $_G['uid'];
            $_GET['uid'] = $_G['uid'];
        }
    }

    function output() {
        global $upload;
    }
    public static function make_cors($request_method, $origin = '') {

        $origin = $origin ? $origin : '*';

        if ($request_method === 'OPTIONS') {
            header('Access-Control-Allow-Origin:'.$origin);

            header('Access-Control-Allow-Credentials:true');
            header('Access-Control-Allow-Methods:GET, POST, OPTIONS');


            header('Access-Control-Max-Age:1728000');
            header('Content-Type:text/plain charset=UTF-8');
            header("status: 204");
            header('HTTP/1.0 204 No Content');
            header('Content-Length: 0',true);
            flush();
        }

        if ($request_method === 'POST') {

            header('Access-Control-Allow-Origin:'.$origin);
            header('Access-Control-Allow-Credentials:true');
            header('Access-Control-Allow-Methods:GET, POST, OPTIONS');
        }

        if ($request_method === 'GET') {

            header('Access-Control-Allow-Origin:'.$origin);
            header('Access-Control-Allow-Credentials:true');
            header('Access-Control-Allow-Methods:GET, POST, OPTIONS');
        }

    }
}
//dis'.'m.tao'.'bao.com
?>