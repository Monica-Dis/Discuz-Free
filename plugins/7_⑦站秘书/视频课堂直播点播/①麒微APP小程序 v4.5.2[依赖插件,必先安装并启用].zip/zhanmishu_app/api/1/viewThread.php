<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_MOBILE_API')) {
    exit('Access Denied');
}


$_GET['mod'] = 'viewthread';
include_once 'forum.php';

class zhanmishu_app_origin_api {

    function common() {
        global $_G;
        $_G['siteurl'] = str_replace('source/plugin/zhanmishu_app/','',$_G['siteurl']);

    }

    function output() {
        global $_G, $thread, $allowfastpost, $allowpostreply;
        $_G['thread']['isfavorite'] = 0;
        if ($_G['uid']) {
            // 获取关注信息
            $favorite = C::t("home_favorite")->fetch_by_id_idtype($thread['tid'],'tid',$_G['uid']);
            if (!empty($favorite)) {
                $_G['thread']['isfavorite'] = 1;
            }
        }
        if ($GLOBALS['hiddenreplies']) {
            foreach ($GLOBALS['postlist'] as $k => $post) {
                if (!$post['first'] && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$_G['forum']['ismoderator']) {
                    $GLOBALS['postlist'][$k]['message'] = lang('plugin/mobile', 'mobile_post_author_visible');
                    $GLOBALS['postlist'][$k]['attachments'] = array();
                }
            }
        }

        $_G['thread']['avatar'] = avatar($thread['authorid'],'middle',true);
        $_G['thread']['lastpost'] = dgmdate($_G['thread']['lastpost']);
        $_G['thread']['ordertype'] = $GLOBALS['ordertype'];
        $_G['thread']['recommend'] = $_G['uid'] && C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($_G['uid'], $_G['tid']) ? 1 : 0;
        if (!empty($_GET['viewpid'])) {
            $GLOBALS['postlist'][$_GET['viewpid']] = $GLOBALS['post'];
        }
        if ($GLOBALS['rushreply']) {
            $_G['thread']['rushreply'] = $GLOBALS['rushreply'];
            $_G['thread']['rushresult'] = $GLOBALS['rushresult'];
        }
        foreach ($GLOBALS['comments'] as $pid => $comments) {
            $comments = zhanmishu_app_api::getvalues($comments, array('/^\d+$/'), array('id', 'tid', 'pid', 'author', 'authorid', 'dateline', 'comment', 'avatar'));
            foreach ($comments as $k => $c) {
                $comments[$k]['avatar'] = avatar($c['authorid'], 'small', true);
                $comments[$k]['dateline'] = dgmdate($c['dateline'], 'u');
            }
            $GLOBALS['comments'][$pid] = $comments;
        }

        if (is_dir(DISCUZ_ROOT.'source/plugin/zhanmishu_markdown')) {
            include libfile('function/editor');
            foreach($GLOBALS['postlist'] as $k=>$post){
                $pattern= "/\[md\](.*)\[\/md\]/is";
                
                $isMd = preg_match($pattern, $post['message'] , $MarkdownReturn);
                if (!class_exists('zhanmishu_markdown_controller',false)) {
                    C::import('zhanmishu_markdown_controller','plugin/zhanmishu_markdown/source/controller');
                }
                if ($post['message'] && $isMd) {
                    $mdMessage = $MarkdownReturn[1];
                    $mdMessage = strip_tags(htmlspecialchars_decode($mdMessage, ENT_QUOTES));
                    $mdMessage = str_replace('&nbsp;', ' ', $mdMessage);
                    $mdMessage = str_replace('&quot;', '"', $mdMessage);
                    //$replace = '[md]'.$mdMessage.'[/md]';
                    $replace = zhanmishu_markdown_controller::markdownParse($mdMessage);
                    $post['message'] = preg_replace($pattern, $replace, $post['message']);
                    if (!empty($post['attachments'])) {
                        foreach ($post['attachments'] as $attach) {
                            if (strpos($post['message'], $attach['attachment'])) {
                                unset($post['attachments'][$attach['aid']]);
                            }
                        }
                    }

                    $GLOBALS['postlist'][$k] = $post;
                }
            }
        }

        $resultData = array(
            'thread' => $_G['thread'],
            'fid' => $_G['fid'],
            'postlist' => array_values(zhanmishu_app_api::getvalues($GLOBALS['postlist'], array('/^\d+$/'), array('pid', 'tid', 'author', 'first', 'dbdateline', 'dateline', 'username', 'adminid', 'memberstatus', 'authorid', 'username', 'groupid', 'memberstatus', 'status', 'message', 'number', 'memberstatus', 'groupid', 'attachment', 'attachments', 'attachlist', 'imagelist', 'anonymous', 'position', 'rewardfloor', 'replycredit','support', 'recommend_add', 'recommend_sub','favtimes','avatar'))),
            'allowpostcomment' => $_G['setting']['allowpostcomment'], //是否允许点评
            'allowfastpost' => $allowfastpost, //是否允许快速回复
            'allowpostreply' => $allowpostreply, //是否允许快速回复
            'comments' => $GLOBALS['comments'],
            'commentcount' => $GLOBALS['commentcount'],
            'ppp' => $_G['ppp'],
            'replyCount' => $_G['forum_thread']['allreplies'],
            'setting_rewriterule' => $_G['setting']['rewriterule'],
            'setting_rewritestatus' => $_G['setting']['rewritestatus'],
            'forum_threadpay' => $_G['forum_threadpay'],
            'cache_custominfo_postno' => $_G['cache']['custominfo']['postno'],
        );


        if (!empty($GLOBALS['threadsortshow'])) {
            $optionlist = array();
            foreach ($GLOBALS['threadsortshow']['optionlist'] AS $key => $val) {
                $val['optionid'] = $key;
                $optionlist[] = $val;
            }
            if (!empty($optionlist)) {
                $GLOBALS['threadsortshow']['optionlist'] = $optionlist;
                $GLOBALS['threadsortshow']['threadsortname'] = $_G['forum']['threadsorts']['types'][$thread['sortid']];
            }
        }
        $threadsortshow = zhanmishu_app_api::getvalues($GLOBALS['threadsortshow'], array('/^(?!typetemplate).*$/'));
        if (!empty($threadsortshow)) {
            $resultData['threadsortshow'] = $threadsortshow;
        }

        $pids = array();
        foreach ($resultData['postlist'] as $k => $post) {
            $pids[] = $post['pid'];
            if ($post['first'] == '1') {
                $resultData['postlist'][$k]['isfavorite'] = $thread['isfavorite'];
            }
            $resultData['postlist'][$k]['avatar'] = avatar($post['authorid'],'middle',true);

            if (!$_G['forum']['ismoderator'] && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($_G['thread']['digest'] == 0 && ($post['groupid'] == 4 || $post['groupid'] == 5 || $post['memberstatus'] == '-1')))) {
                $message = lang('forum/template', 'message_banned');
            } elseif (!$_G['forum']['ismoderator'] && $post['status'] & 1) {
                $message = lang('forum/template', 'message_single_banned');
            } elseif ($GLOBALS['needhiddenreply']) {
                $message = lang('forum/template', 'message_ishidden_hiddenreplies');
            } elseif ($post['first'] && $_G['forum_threadpay']) {
                $message = lang('forum/template', 'pay_threads') . ' ' . $GLOBALS['thread']['price'] . ' ' . $_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['unit'] . $_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['title'];
            } elseif ($_G['forum_discuzcode']['passwordlock']) {
                $message = lang('forum/template', 'message_password_exists');
            } else {
                $message = '';
            }
            if ($message) {
                $resultData['postlist'][$k]['message'] = $message;
            }
            if ($post['anonymous'] && !$_G['forum']['ismoderator']) {
                $resultData['postlist'][$k]['username'] = $resultData['postlist'][$k]['author'] = $_G['setting']['anonymoustext'];
                $resultData['postlist'][$k]['adminid'] = $resultData['postlist'][$k]['groupid'] = $resultData['postlist'][$k]['authorid'] = 0;
                if ($post['first']) {
                    $resultData['thread']['authorid'] = 0;
                }
            }
            if (strpos($resultData['postlist'][$k]['message'], '[/tthread]') !== FALSE) {
                $matches = array();
                preg_match('/\[tthread=(.+?),(.+?)\](.*?)\[\/tthread\]/', $resultData['postlist'][$k]['message'], $matches);
                $resultData['postlist'][$k]['message'] = preg_replace('/\[tthread=(.+?)\](.*?)\[\/tthread\]/', lang('plugin/qqconnect', 'connect_tthread_message', array('username' => $matches[1], 'nick' => $matches[2])), $resultData['postlist'][$k]['message']);
            }
            $resultData['postlist'][$k]['message'] = preg_replace("/<a\shref=\"([^\"]+?)\"\starget=\"_blank\">\[viewimg\]<\/a>/is", "<img src=\"\\1\" />", $resultData['postlist'][$k]['message']);

            $resultData['postlist'][$k]['message'] = self::_findimg($resultData['postlist'][$k]['message']);
            if ($GLOBALS['aimgs'][$post['pid']]) {
                $imagelist = array();
                foreach ($GLOBALS['aimgs'][$post['pid']] as $aid) {
                    $extra = '';
                    $url = self::_parseimg('', $GLOBALS['postlist'][$post['pid']]['attachments'][$aid]['url'] . $GLOBALS['postlist'][$post['pid']]['attachments'][$aid]['attachment'], '');
                    if ($GLOBALS['postlist'][$post['pid']]['attachments'][$aid]['thumb']) {
                        $extra = 'file="' . $url . '" ';
                        $url .= '.thumb.jpg';
                    }
                    $extra .= 'attach="' . $post['pid'] . '" ';
                    if (strexists($resultData['postlist'][$k]['message'], '[attach]' . $aid . '[/attach]')) {
                    include_once DISCUZ_ROOT.'source/plugin/zhanmishu_app/source/function/discuzcode.func.php';
                        $resultData['postlist'][$k]['message'] = str_replace('[attach]' . $aid . '[/attach]', zhanmishu_app_image($url, $extra), $resultData['postlist'][$k]['message']);
                        unset($resultData['postlist'][$k]['attachments'][$aid]);
                    } elseif (!in_array($aid, $_G['forum_attachtags'][$post['pid']])) {
                        $imagelist[] = $aid;
                    }
                    // 补充部分没有插入的图片
                    if ($resultData['postlist'][$k]['attachments'][$aid]['attachimg'] == '1') {
                        if (!$resultData['postlist'][$k]['attachments'][$aid]['remote']) {
                            $imgUrl = $_G['siteurl'].$resultData['postlist'][$k]['attachments'][$aid]['url'].$resultData['postlist'][$k]['attachments'][$aid]['attachment'];
                        }else{
                            $imgUrl = $resultData['postlist'][$k]['attachments'][$aid]['url'].$resultData['postlist'][$k]['attachments'][$aid]['attachment'];
                        }
                        
                        $resultData['postlist'][$k]['message'] = '<div class="img"><img src="'.$imgUrl.'" attach="'.$aid.'" /></div>'.$resultData['postlist'][$k]['message'];
                        unset($resultData['postlist'][$k]['attachments'][$aid]);
                    } 
                }
            }
            foreach ($resultData['postlist'][$k]['attachments'] as $aid=> $attach) {
                $resultData['postlist'][$k]['attachments'][$aid]['url'] = $_G['siteurl'];
                $resultData['postlist'][$k]['attachments'][$aid]['attachment'] = 'forum.php?mod=attachment&aid=' . aidencode($aid, 0, $attach['tid']);
            }
            
            $resultData['postlist'][$k]['message'] = preg_replace("/\[attach\]\d+\[\/attach\]/i", '', $resultData['postlist'][$k]['message']);
            $resultData['postlist'][$k]['message'] = preg_replace('/(&nbsp;){2,}/', '', $resultData['postlist'][$k]['message']);
            $resultData['postlist'][$k]['dateline'] = strip_tags($post['dateline']);
            $resultData['postlist'][$k]['groupiconid'] = zhanmishu_app_api::usergroupIconId($post['groupid']);
            $resultData['postlist'][$k]['imagelist'] = array_values($imagelist);
            $resultData['postlist'][$k]['attachments'] = array_values($resultData['postlist'][$k]['attachments']);

            

            // 转为array提升前端解码性能

            // if ($_GET['platform']) {
            //     if ($_GET['platform'] == 'app') {
            //         $resultData['postlist'][$k]['message'] = self::strip_html_tags(array('pre','font'), $resultData['postlist'][$k]['message'], '');
            //     }

            //     $html2json=new html2json();
            //     $html = $html2json->html2jsonarr(diconv($resultData['postlist'][$k]['message'], CHARSET, 'UTF-8'));
            //     $html = zhanmishu_app::auto_charset_change($html['children'][0]['children'], 'UTF-8', CHARSET);

            //     $resultData['postlist'][$k]['message'] = $html;
            // }


        }

        if (!empty($pids)) {
            $supports = C::t('forum_hotreply_number')->fetch_all_by_pids($pids);
            $isSupport = DB::fetch_all('SELECT pid FROM %t WHERE tid=%d AND uid=%d', array('forum_hotreply_member ', $thread['tid'], $_G['uid']),'pid');

            foreach ($resultData['postlist'] as $k => $post) {
                if (array_key_exists($post['pid'],$supports)) {
                    $resultData['postlist'][$k]['recommend_add'] = $supports[$post['pid']]['support'];
                }else{
                    $resultData['postlist'][$k]['recommend_add'] = $resultData['postlist'][$k]['recommend_add'] ? $resultData['postlist'][$k]['recommend_add'] : '0'; 
                }
                if (array_key_exists($post['pid'],$isSupport)) {
                    $resultData['postlist'][$k]['isrecommend'] = '1';
                }else{
                    $resultData['postlist'][$k]['isrecommend'] = '0'; 
                }
            }
        }



        if (!empty($GLOBALS['polloptions'])) {
            $resultData['special_poll']['polloptions'] = $GLOBALS['polloptions'];
            $resultData['special_poll']['expirations'] = $GLOBALS['expirations'];
            $resultData['special_poll']['multiple'] = $GLOBALS['multiple'];
            $resultData['special_poll']['maxchoices'] = $GLOBALS['maxchoices'];
            $resultData['special_poll']['voterscount'] = $GLOBALS['voterscount'];
            $resultData['special_poll']['visiblepoll'] = $GLOBALS['visiblepoll'];
            $resultData['special_poll']['allowvote'] = $_G['group']['allowvote'];
            $resultData['special_poll']['remaintime'] = $thread['remaintime'];
        }
        if (!empty($GLOBALS['rewardprice'])) {
            $resultData['special_reward']['rewardprice'] = $GLOBALS['rewardprice'] . ' ' . $_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]]['title'];
            $resultData['special_reward']['bestpost'] = $GLOBALS['bestpost'];
        }
        if (!empty($GLOBALS['trades'])) {
            $resultData['special_trade'] = $GLOBALS['trades'];
        }
        if (!empty($GLOBALS['debate'])) {
            $resultData['special_debate'] = $GLOBALS['debate'];
        }
        if (!empty($GLOBALS['activity'])) {
            $resultData['special_activity'] = $GLOBALS['activity'];
            $resultData['special_activity']['allapplynum'] = $GLOBALS['allapplynum'];
            if ($_G['setting']['activitycredit'] && $GLOBALS['activity']['credit'] && !$GLOBALS['applied']) {
                $resultData['special_activity']['creditcost'] = $GLOBALS['activity']['credit'] . ' ' . $_G['setting']['extcredits'][$_G['setting']['activitycredit']]['title'];
            }
            $setting = array();
            foreach ($GLOBALS['activity']['ufield']['userfield'] as $field) {
                $setting[$field] = $_G['cache']['profilesetting'][$field];
            }
            $resultData['special_activity']['joinfield'] = zhanmishu_app_api::getvalues($setting, array('/./'), array('fieldid', 'formtype', 'available', 'title', 'formtype', 'choices'));
            $resultData['special_activity']['userfield'] = $GLOBALS['ufielddata']['userfield'];
            $resultData['special_activity']['extfield'] = $GLOBALS['ufielddata']['extfield'];
            $resultData['special_activity']['basefield'] = zhanmishu_app_api::getvalues($GLOBALS['applyinfo'], array('message', 'payment'));
            $resultData['special_activity']['closed'] = $GLOBALS['activityclose'];
            if ($GLOBALS['applied'] && $GLOBALS['isverified'] < 2) {
                if (!$GLOBALS['isverified']) {
                    $resultData['special_activity']['status'] = 'wait';
                } else {
                    $resultData['special_activity']['status'] = 'joined';
                }
                if (!$GLOBALS['activityclose']) {
                    $resultData['special_activity']['button'] = 'cancel';
                }
            } elseif (!$GLOBALS['activityclose']) {
                if ($GLOBALS['isverified'] != 2) {
                    $resultData['special_activity']['status'] = 'join';
                } else {
                    $resultData['special_activity']['status'] = 'complete';
                }
                $resultData['special_activity']['button'] = 'join';
            }
        }

        $resultData['forum']['password'] = $resultData['forum']['password'] ? '1' : '0';
        echo zhanmishu_app_api::resultToJson($resultData, '', '', true, false);
        exit;
    }
    // 删除或者替换某指定标签
    function strip_html_tags($tags, $str = '', $replace = ''){
        $html=array();
        foreach ($tags as $key => $tag) {
            $html[]="/(<(?:\/".$tag."|".$tag.")[^>]*>)/i";
        }
        $data=preg_replace($html, $replace, $str);
        return $data;
    }
    function _findimg($string) {
        return preg_replace_callback('/(<img src=\")(.+?)(\".*?\>)/is', array(__CLASS__, 'findimg_callback_parseimg_123'), $string);
    }

    static function findimg_callback_parseimg_123($matches) {
        return self::_parseimg($matches[1], $matches[2], $matches[3]);
    }

    function _parseimg($before, $img, $after) {
        $before = stripslashes($before);
        $after = stripslashes($after);
        if (!in_array(strtolower(substr($img, 0, 6)), array('http:/', 'https:', 'ftp://'))) {
            global $_G;
            $img = $_G['siteurl'] . $img;
        }
        return $before . $img . $after;
    }

}
//dis'.'m.tao'.'bao.com
?>