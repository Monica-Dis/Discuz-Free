<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$appHander = zhanmishu_app::getInstance();

$smsController = new zhanmishu_app_sms_controller($appHander);

if (method_exists($smsController, $_GET['action'])) {
    $action = $_GET['action'] ? $_GET['action'] : 'index';
    $smsController->$action($_GET);
}
