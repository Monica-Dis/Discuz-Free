<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: mypm.php 35183 2015-01-14 07:46:53Z DisM.Taobao.Com $
 */

if(!defined('IN_MOBILE_API')) {
	exit('Access Denied');
}

$_GET['mod'] = 'space';
$_GET['do'] = 'pm';
include_once 'home.php';

class zhanmishu_app_origin_api {

	function common() {
	}

	function output() {
		global $_G;
		foreach($GLOBALS['list'] as $_k => $_v) {
			if($_v['lastdateline']) {
				$GLOBALS['list'][$_k]['vdateline'] = dgmdate($_v['lastdateline'], 'u');
			} elseif($_v['dateline']) {
				$GLOBALS['list'][$_k]['vdateline'] = dgmdate($_v['dateline'], 'u');
			}
		}
		$data = array(
			'list' => zhanmishu_app_api::getvalues($GLOBALS['list'], array('/^\d+$/'), array('plid', 'isnew', 'vdateline', 'subject', 'pmid', 'msgfromid', 'msgfrom', 'message', 'touid', 'tousername')),
			'count' => $GLOBALS['count'],
			'perpage' => $GLOBALS['perpage'],
			'page' => intval($GLOBALS['page']),
		);
		if($_GET['subop']) {
			$data = array_merge($data, array('pmid' => $GLOBALS['pmid']));
		}
		echo zhanmishu_app_api::resultToJson($data);
        exit;
	}

}
//From: Dism��taobao��com
?>