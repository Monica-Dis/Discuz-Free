<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 
if (!defined('IN_MOBILE_API')) {
    exit('Access Denied');
}

$_GET['mod'] = 'post';
$_POST['mod'] = 'post';
$_GET['action'] = 'newthread';
include_once 'forum.php';

class zhanmishu_app_origin_api {

    function common() {
        if ($_GET['platform'] != 'web') {
            // $_GET['subject'] = zhanmishu_app_api::auto_charset_change($_GET['subject'],'UTF-8',CHARSET);
            // $_GET['message'] = zhanmishu_app_api::auto_charset_change($_GET['message'],'UTF-8',CHARSET);
            // $_GET['topicsubmit'] = zhanmishu_app_api::auto_charset_change($_GET['topicsubmit'],'UTF-8',CHARSET);
        }
        
    }

    function post_mobile_message($message, $url_forward, $values, $extraparam, $custom) {
        if($values['tid'] && $values['pid']) {
            global $_G;

            $threadstatus = DB::result_first("SELECT status FROM ".DB::table('forum_thread')." WHERE tid='$values[tid]'");
            if(!empty($_POST['allowsound'])) {
                $setstatus = array(1, 0, 0);
            } elseif(!empty($_POST['allowphoto'])) {
                $setstatus = array(0, 1, 1);
            } elseif(!empty($_POST['allowlocal'])) {
                $setstatus = array(0, 1, 0);
            } else {
                $setstatus = array(0, 0, 1);
            }
            foreach($setstatus as $i => $bit) {
                $threadstatus = setstatus(13 - $i, $bit, $threadstatus);
            }
            C::t('forum_thread')->update($values['tid'], array('status' => $threadstatus));

            $poststatus = DB::result_first("SELECT status FROM ".DB::table('forum_post')." WHERE pid='$values[pid]'");
            $poststatus = setstatus(4, 1, $poststatus);
            if(!empty($_POST['allowlocal'])) {
                $poststatus = setstatus(6, 1, $poststatus);
            }
            if(!empty($_POST['allowsound'])) {
                $poststatus = setstatus(7, 1, $poststatus);
            }
            if(!empty($_POST['mobiletype'])) {
                $mobiletype = base_convert($_POST['mobiletype'], 10, 2);
                $mobiletype = sprintf('%03d', $mobiletype);
                for($i = 0;$i < 3;$i++) {
                    $poststatus = setstatus(10 - $i, $mobiletype{$i}, $poststatus);
                }
            }
            C::t('forum_post')->update(0, $values['pid'], array('status' => $poststatus));

            if($_POST['location']) {
                list($mapx, $mapy, $location) = explode('|', dhtmlspecialchars($_POST['location']));
                C::t('forum_post_location')->insert(array(
                    'pid' => $values['pid'],
                    'tid' => $values['tid'],
                    'uid' => $_G['uid'],
                    'mapx' => $mapx,
                    'mapy' => $mapy,
                    'location' => $location,
                ));
            }
        }

        $resultData = array(
            'tid' => $values['tid'],
            'pid' => $values['pid'],
        );

        if(!empty($_G['forum']['threadtypes'])) {
            $resultData['threadtypes'] = $_G['forum']['threadtypes'];
        }
        $resultData['msg'] = $message;
        $resultData['url_forward'] = $url_forward;
        $resultData['values'] = $values;
        $resultData['extraparam'] = $extraparam;
        $resultData['custom'] = $custom;
        echo zhanmishu_app_api::resultToJson($resultData);
        exit;       
    }

    function output() {
        global $_G;
        $resultData = array(
            'tid' => $GLOBALS['tid'],
            'pid' => $GLOBALS['pid'],
        );
        if(!empty($_G['forum']['threadtypes'])) {
            $resultData['threadtypes'] = $_G['forum']['threadtypes'];
        }

        echo zhanmishu_app_api::resultToJson($resultData);
        exit;
    }

}
//dis'.'m.tao'.'bao.com
?>