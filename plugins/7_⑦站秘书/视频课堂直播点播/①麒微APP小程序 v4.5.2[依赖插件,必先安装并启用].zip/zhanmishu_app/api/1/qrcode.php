<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$_GET = zhanmishu_app_api::auto_charset_change($_GET,'UTF-8',CHARSET);
$appHander =  zhanmishu_app::getInstance();

$typeArray = array('course', 'thread');
if (!in_array($_GET['type'], $typeArray)) {
    $result = array(
        'code'=> -500001,
        'msg'=> 'type_error'
    );
    echo zhanmishu_app_api::resultToJson($result);
    exit;  
}
// 检测微信组件
if(!is_file(DISCUZ_ROOT.'source/plugin/zhanmishu_wechat/source/model/zhanmishu_wechat_model_qrcode.php')){
    $result = array(
        'code'=> -500001,
        'msg'=> 'wechat_qrcode_module_not_exists'
    );
    echo zhanmishu_app_api::resultToJson($result);
    exit;  
}
include_once DISCUZ_ROOT.'source/plugin/zhanmishu_wechat/source/Autoloader.php';
$wechatHander = zhanmishu_wechat_model_qrcode::getInstance();

$data = array();
$data['uid'] = $_G['uid'];
$data['type'] = daddslashes($_GET['type']);

if($_GET['type'] == 'course'){
    $data['cid'] = $_GET['cid'] + 0;
}
if($_GET['type'] == 'thread'){
    $data['tid'] = $_GET['tid'] + 0;
}

$data['url'] = daddslashes($_GET['url']);
$data['title'] = daddslashes($_GET['title']);
$data['image'] = daddslashes($_GET['image']);
$data['description'] = daddslashes($_GET['description']);

$data['page'] = 'pages/CourseDetails/CourseDetails';
// 如果是获取微信公众号带参数关注二维码，注意二维码一般临时有效，有效期30天
if($_GET['platform'] == 'minapp' && $appHander->config['qrcode'] != 'wechat'){
    // 获取小程序二维码
    $qrcode = $wechatHander->getQRCode($data, 'minapp');
}else{
   // 如果是获取小程序二维码
    $qrcode = $wechatHander->getQRCode($data);
}

$result = array(
    'code'=> 0,
    'msg'=> 'success',
    'qrcode'=> $qrcode,
);
echo zhanmishu_app_api::resultToJson($result);
exit;



// 如果是获取普通二维码，弃用，现在统一由前端自行获取二维码

