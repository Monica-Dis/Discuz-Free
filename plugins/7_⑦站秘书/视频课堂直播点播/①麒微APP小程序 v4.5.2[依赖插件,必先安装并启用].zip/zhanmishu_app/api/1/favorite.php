<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_MOBILE_API')) {
    exit('Access Denied');
}

// mod: spacecp
// ac: favorite
// type: forum
// id: 48
// handlekey: favoriteforum
// formhash: 6e8924dc


$_GET['mod'] = 'spacecp';
$_POST['mod'] = 'spacecp';
$_GET['ac'] = 'favorite';
include_once 'home.php';

class zhanmishu_app_origin_api {

    function common() {
        global $_G;
        switch($_GET['type']) {
            case 'thread':
                $idtype = 'tid';
                break;
            case 'forum':
                $idtype = 'fid';
                break;
            case 'blog':
                $idtype = 'blogid';
                break;
            case 'group':
                $idtype = 'gid';
                break;
            case 'album':
                $idtype = 'albumid';
                break;
            case 'space':
                $idtype = 'uid';
                break;
            case 'article':
                $idtype = 'aid';
                break;
            case 'course':
                $idtype = 'cid';
                break;
        }
        if (!$idtype) {
            return ;
        }
        // 收藏课程
        $_GET['id'] = $_GET['id'] ? $_GET['id'] : $_GET['favorite'];
        if (($_GET['favoritesubmit'] || $_GET['delfavorite']) && $idtype == 'cid' && $_GET['id']) {
            $videoFile = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/class/zhanmishu_video.php';
            if (!is_file($videoFile)) {
                showmessage('video_plugin_not_exists', '');
            }
            include_once($videoFile);
            $videoHander = zhanmishu_video::getInstance();
            
            if ($_GET['favoritesubmit']) {
                $return = $videoHander->favoriteCourse($_G['uid'],$_GET['id'] + 0);
                if ($return['favid']) {
                    global $favid ;
                    $favid = $return['favid'];
                }else{
                    showmessage($return['msg'], '');
                }
            }else{
                $return = $videoHander->favoriteCourse($_G['uid'],$_GET['id'] + 0,'del');
                showmessage($return['msg'], '');
            }
        }

        $favorite = C::t("home_favorite")->fetch_by_id_idtype($_GET['favorite'] + 0, daddslashes($idtype),$_G['uid']);
        if (!empty($favorite)) {
            $_GET['favorite'] = array($favorite['favid']);
            $_POST['favorite'] = array($favorite['favid']);
        }
    }

    function output() {
        global $favid;
        $resultData['favid'] = $favid ? $favid : 0;
        $code = $favid ? '0' : '-1';
        $msg = $favid ? 'success' : 'error';

        echo zhanmishu_app_api::resultToJson($resultData,$code,$msg);
        exit;        
    }

}