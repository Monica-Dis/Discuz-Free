<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_app/source/Autoloader.php';

$appHander = zhanmishu_app::getInstance();
$userController = new zhanmishu_app_user_controller($appHander);
$userInfo = $userController->_userInfo('', true);

ob_clean();
header('Content-type:text/html;charset=utf-8');
$navtitle = zhanmishu_app::auto_charset_change($navtitle);
$metakeywords = zhanmishu_app::auto_charset_change($metakeywords);
$metadescription = zhanmishu_app::auto_charset_change($metadescription);

include template("zhanmishu_app:index");