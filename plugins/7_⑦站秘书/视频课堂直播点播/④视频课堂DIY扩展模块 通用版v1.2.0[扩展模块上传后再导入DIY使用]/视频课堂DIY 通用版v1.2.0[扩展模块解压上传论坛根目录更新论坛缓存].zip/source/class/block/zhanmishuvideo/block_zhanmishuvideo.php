<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: block_zhanmishuvideo.php 31313 2012-08-10 03:51:03Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class block_zhanmishuvideo extends discuz_block {

    function name() {
        return '高级自定义';
    }

    function blockclass() {
        return array('zmsvideo', '视频模块');
    }

    function fields() {
        return array(
            'id' => array('name' => '课程cid', 'formtype' => 'text', 'datatype' => 'int'),
            'uid' => array('name' => '老师uid', 'formtype' => 'text', 'datatype' => 'int'),
            'cat_id' => array('name' => '分类ID', 'formtype' => 'text', 'datatype' => 'int'),
            'selltimes' => array('name' => '购买次数', 'formtype' => 'text', 'datatype' => 'int'),
            'course_weight' => array('name' => '推荐权重', 'formtype' => 'text', 'datatype' => 'int'),
            'views' => array('name' => '浏览量', 'formtype' => 'text', 'datatype' => 'int'),
            'learns' => array('name' => '播放量', 'formtype' => 'text', 'datatype' => 'int'),
            'width' => array('name' => '图片宽度', 'formtype' => 'text', 'datatype' => 'int'),
            'height' => array('name' => '图片高度', 'formtype' => 'text', 'datatype' => 'int'),
            'title' => array('name' => '课程名称', 'formtype' => 'text', 'datatype' => 'string'),
            'url' => array('name' => '课程链接', 'formtype' => 'text', 'datatype' => 'string'),
            'clumnnums' => array('name' => '默认一行显示个数', 'formtype' => 'text', 'datatype' => 'int'),
            'course_img' => array('name' => '图片封面', 'formtype' => 'pic', 'datatype' => 'pic'),
            'pic' => array('name' => '图片封面', 'formtype' => 'pic', 'datatype' => 'pic'),
            'course_intro' => array('name' => '课程介绍', 'formtype' => 'textarea', 'datatype' => 'string'),
            'summary' => array('name' => '课程介绍', 'formtype' => 'textarea', 'datatype' => 'string'),
            'course_price' => array('name' => '价格', 'formtype' => 'text', 'datatype' => 'string'),
            'price_tag' => array('name' => '价格标签', 'formtype' => 'text', 'datatype' => 'string'),
            'live_tag' => array('name' => '直播标签', 'formtype' => 'text', 'datatype' => 'string'),
            'dateline' => array('name' => '推荐权重', 'formtype' => 'date', 'datatype' => 'date')
        );
    }


    function getsetting() {
        global $_G;
        $cat_all = $this->get_all_cat();
        $cat = array();
        foreach ($cat_all as $key => $value) {
            $cat[] = array($value['cat_id'],$value['cat_name']);
        }
        $cat = array_merge(array(0=>array(0, '全部分类')), $cat);
        $settings = array(
            'cat_id' => array(
                'title' => '类别',
                'type' => 'mselect',
                'value' => $cat
            ),
            'isvideo' => array(
                'title' => '过滤掉无视频的',
                'type' => 'radio',
                'default' => ''
            ),
            'islive' => array(
                'title' => '过滤掉不含直播的',
                'type' => 'radio',
                'default' => ''
            ),
            'titlelength' => array(
                'title' => '标题字数限制',
                'type' => 'text',
                'default' => 40
            ),
            'summarylength' => array(
                'title' => '简介内容字数限制',
                'type' => 'text',
                'default' => 80
            ),
            'width' => array(
                'title' => '图片宽度',
                'type' => 'text',
                'default' => 200
            ),
            'height' => array(
                'title' => '图片高度',
                'type' => 'text',
                'default' => 200
            ),
            'orderby' => array(
                'title' => '排序',
                'type'=> 'mradio',
                'value' => array(
                    array('dateline', '发布顺序'),
                    array('selltimes', '购买量'),
                    array('views', '流量量'),
                    array('course_weight', '推荐权重'),
                ),
                'default' => 'dateline'
            )
        );

        return $settings;
    }

    function getdata($style, $parameter) { 
        $videoconfig = $this->videoHander()->config;
        $fields = array('isdel'=>'0');
        $fields['issell'] = '1';

        if ($parameter['isvideo']) {
            $fields['course_length']  = array('key'=>'course_length','relation'=>'>','value'=>'0');
        }
        if ($parameter['islive']) {
            $fields['islive']  = array('key'=>'islive','relation'=>'>','value'=>'0');
        }
        if (!empty($parameter['cat_id']) && !in_array('0',$parameter['cat_id'])) {
            $cat_all = $this->get_all_cat();
            
            foreach ($cat_all as $value) {
                if (in_array($value['cat_id'], $parameter['cat_id']) && $value['level'] == '0') {
                    $catson = $this->videoHander()->get_cat_tree($value['cat_id'],'0');
                    $parameter['cat_id'] = array_merge($this->darray_column($catson,'cat_id'),$parameter['cat_id']);
                }
            }
            if (!empty($parameter['cat_id'])) {
                $cat_ids = implode(',', $parameter['cat_id']);
                $fields['cat_id'] = array('key'=>'cat_id','relation'=>'in', 'value'=>' ( '.$cat_ids.' ) ');
            }
        }

        $orderby = array($parameter['orderby']=>'desc');
        $limit = $parameter['items'];
        $startrow   = isset($parameter['startrow']) ? intval($parameter['startrow']) : 0;
        $bannedids = !empty($parameter['bannedids']) ? explode(',', $parameter['bannedids']) : array();
        if ($bannedids) {
            $fields['bannedids'] = array('key'=>'cid','relation'=>' NOT IN ','value'=>'('.dimplode($bannedids).') ');
        }

        $videos = C::t("#zhanmishu_video#zhanmishu_video_course")->get_type_course($startrow,$limit,$orderby,'',$fields);

        $list = array();
        $url = '#';
        if (!empty($videos)) {
            include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/function/common_function.php';
            
            foreach ($videos as $key => $value) {
                if($videoconfig['isrewrite']) {
                    $url = zms_video_rewriteoutput('coursepage',1,'',$value['cid'],'');
                }else{
                    $url = 'plugin.php?id=zhanmishu_video:video&mod=video&cid='.$value['cid'];
                }

                if ($value['course_price'] && $this->videoHander()->config['selltype'] == '1') {
                    $price_tag = '<span class="bd-money">&yen;'.sprintf("%01.2f", $value['course_price'] / 100).'</span>';
                }else if ($value['course_price'] && $this->videoHander()->config['selltype'] == '2') {
                    $group = $this->videoHander()->course_group_toarray($value['course_group']);
                    $groupicons = $this->videoHander()->get_group_icons();

                    if (count($group) > 1) {
                        $option = '';
                        foreach ($group as $key => $v) {
                            $option .= '<option value="">'.$groupicons[$v]['grouptitle'].'</option>';
                        }
                        $price_tag = '<span class="bd-money"><select name="" id=""  class="viptags"  style="border-color:#5fb41b;color:#5fb41b;">'.$option.'</select></span>';
                    }else{
                        $groupItem = current($group);
                        $Color = $groupItem['color'] ? $groupItem['color'] : 'green';
                        $price_tag = '<span class="bd-money" style="border-color:'.$Color.';color:'.$color.'">'.$groupItem['grouptitle'].'</span>';
                    }
                }else{
                    $price_tag = '<span class="bd-free">免费</span>';
                }

                if ($value['islive']) {
                    $liveTag = $this->videoHander()->get_course_tags_bycid($value['cid']);
                    if ($liveTag['livestatus'] == '1') {
                        $live_tag = '<span class="bd-Live"><i class=""><img src="template/zhanmishu_edu/images/liveing.png" alt=""></i>&nbsp;直播中</span>';
                    }else if ($liveTag['livestatus'] == '2') {
                        $live_tag = '<span class="bd-Live"><i class=""><img src="template/zhanmishu_edu/images/liveing.png" alt=""></i>&nbsp;回放</span>';
                    }else{
                        $live_tag = '<span class="bd-Live"><i class=""><img src="template/zhanmishu_edu/images/liveing.png" alt=""></i>&nbsp;未开始</span>';
                    }
                }

                $list[] = array(
                    'id' => $value['cid'],
                    'idtype' => 'cid',
                    'title' => $value['course_name'],
                    'url' => $url,
                    'pic' => $value['course_img'],
                    'picflag' => 0,
                    'summary' => $value['course_intro'],
                    'fields' => array(
                        'learns' => $value['learns'],
                        'views' => $value['views'],
                        'cat_id' => $value['cat_id'],
                        'selltimes' => $value['selltimes'],
                        'clumnnums' => $this->videoHander()->config['clumnnums'],
                        'course_weight' => $value['course_weight'],
                        'course_img' => $value['course_img'],
                        'course_price' => sprintf("%01.2f", $value['course_price'] / 100),
                        'width' => $parameter['width'],
                        'height' => $parameter['height'],
                        'dateline' => $value['dateline'],
                        'price_tag' => $price_tag,
                        'live_tag' => $live_tag
                    )
                );
            }
        }

        return array(
            'html'=>'',
            'data' => $list
        );
    }

    function get_all_cat(){
        return C::t("#zhanmishu_video#zhanmishu_video_cat")->get_type_video_cat(0, 0, '', '',array('isdel'=>'0'));       
    }

    function videoHander() {
        include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';
        $videoHander = new zhanmishu_video();
        return $videoHander;
    }


    /**
     * array_column() // 不支持低版本;
     * 以下方法兼容PHP低版本
     */
    function darray_column($array = array(), $column_key='', $index_key=null){

        if (function_exists('array_column')) {
            return array_column($array, $column_key, $index_key);
        }
        $result = array();
        foreach($array as $arr) {
            if(!is_array($arr)) continue;

            if(is_null($column_key)){
                $value = $arr;
            }else{
                $value = $arr[$column_key];
            }

            if(!is_null($index_key)){
                $key = $arr[$index_key];
                $result[$key] = $value;
            }else{
                $result[] = $value;
            }
        }
        return $result; 
    }
}

?>