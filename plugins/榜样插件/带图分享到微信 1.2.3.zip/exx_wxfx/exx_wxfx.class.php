<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/12/04
 * Time: 14:23
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


class plugin_exx_wxfx{
	public function _checkftp($picurl){
		global $_G;
		$siteurl=$_G['siteurl'];
		if(strpos($picurl, 'http') !== FALSE){
			$siteurl='';
		}
		return $siteurl.$picurl;
	}
	
	public function _getpar(){
		global $_G,$postlist,$content,$article;
		if(CURSCRIPT=='forum' && $_G['tid']){
			if($_G['forum_firstpid']){
				$fpic=$postlist[$_G['forum_firstpid']]['attachments'];
				if(!$fpic){
					preg_match_all('/<img[^>]*src=[\'"]?([^>\'"\s]*)[\'"]?[^>]*>/i', $postlist[$_G['forum_firstpid']]['message'], $out);
					$firstpicdatas=current($out[1]);
				}else{
					$firstpicdata=current($postlist[$_G['forum_firstpid']]['attachments']);
					$firstpicdatas=$firstpicdata['url'].$firstpicdata['attachment'];
				}
			}
			$firstpicdatas=$firstpicdatas?$firstpicdatas:$exx_wxfx['ico'];
			$ret['pic']=$this->_checkftp($firstpicdatas);
			$ret['msg']= str_replace(array("\r\n", "\r", "\n"), '', cutstr(strip_tags(preg_replace('/(<i class=\"pstatus\">.*<\/i>)/is', '', preg_replace('/(<ignore_js_op>.*<\/ignore_js_op>)/is', '', $postlist[$_G['forum_firstpid']]['message'])) ), 50,''));
		}elseif(CURSCRIPT=='portal' && $_GET['aid']){
			preg_match_all('/<img[^>]*src=[\'"]?([^>\'"\s]*)[\'"]?[^>]*>/i', $content['content'], $out);
			$firstpicdata=current($out[1]);
			$ret['pic']=$this->_checkftp($firstpicdata);
			$ret['msg'] = str_replace(array("\r\n", "\r", "\n"), '', cutstr(strip_tags(preg_replace('/(<ignore_js_op>.*<\/ignore_js_op>)/is', '', $content['content'])), 116,''));
		}
		return $ret;
	}
	
	function global_footer(){
		global $_G;
		$exx_wxfx = $_G['cache']['plugin']['exx_wxfx'];
		if((CURSCRIPT=='forum' && $_G['tid']) || (CURSCRIPT=='portal' && $_GET['aid'])){
			$csdata=$this->_getpar();
			$mpic=$this->_checkftp(dhtmlspecialchars($exx_wxfx['ico']));
			$pic=$exx_wxfx['gd']?$mpic:($csdata['pic']?$csdata['pic']:$mpic);
			$ms=$exx_wxfx['gms']?dhtmlspecialchars($exx_wxfx['ms']):($csdata['msg']?$csdata['msg']:dhtmlspecialchars($exx_wxfx['ms']));
			include template('exx_wxfx:inc');
		}
		return $returns;
	}
}


class mobileplugin_exx_wxfx extends plugin_exx_wxfx{
	function global_footer_mobile(){
		return $this->global_footer();
	}
}