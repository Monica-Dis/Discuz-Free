<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	global $_G;
	loadcache('plugin');
	$exx_linkseo = $_G['cache']['plugin']['exx_linkseo'];
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
			$_GET['delete']=daddslashes($_GET['delete']);
			C::t('#exx_linkseo#exx_linkseo')->delete($_GET['delete']);
		}
		cpmsg(lang('plugin/exx_linkseo', 'f01'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=exx_linkseo&pmod=admin&page='.intval($_GET['page']), 'succeed');
	}
	if($_GET['ac']){
		if($_GET['formhash'] != $_G['formhash']) {
			exit('formhash Denied');
		}
		$keyid=intval($_GET['keyid']);
		$dataarr = C::t('#exx_linkseo#exx_linkseo')->fetchfirst_byid($keyid);
		
		if($_GET['ac']=='edit'){
			if (submitcheck("editsubmit")) {
				if(!$_GET['title'] || !$_GET['url']){
					cpmsg(lang('plugin/exx_linkseo', 'f02'), '', 'error');
				}
				$data = array('extid' => 1);
				$picurl=upload_icon_banner($data, $_FILES['spic'],'');
				$pic=$picurl ? $_G['setting']['attachurl'].'common/'.$picurl : $_GET['spic'];
				$arr=array(
					'style'=> editor_safe_replace($_GET['title']),
					'pic'=> daddslashes($pic),
					'url'=> $_GET['url'],
					'title'=> daddslashes(dhtmlspecialchars(strip_tags($_GET['title']))),
				);
				if($dataarr){
					C::t('#exx_linkseo#exx_linkseo')->update($keyid,$arr);
				}else{
					C::t('#exx_linkseo#exx_linkseo')->insert($arr);
				}
				$blank=$exx_linkseo['blank']?'target="_blank"':'';
				$content = C::t('#exx_linkseo#exx_linkseo')->fetchall();
				foreach($content as $k=>$v){
					$alttag=$exx_linkseo['alt']?'alt="'.$v['title'].'"':'';
					$icow=$exx_linkseo['icow']?intval($exx_linkseo['icow']):15;
					$repkey='<a href="'.$v['url'].'" '.$blank.' title="'.$v['title'].'">'.$v['style'].($v['pic']? '<img src="'.$v['pic'].'" '.$alttag.' title="'.$v['title'].'" width="'.$icow.'" style="width:'.$icow.'px !important;height:auto !important"/>':'').'</a>';
					$words['replace'][]=$repkey;
					$words['search'][]=$v['title'];
				}
				require_once libfile('function/cache');
				savecache('exx_linkseo', $words);
				cpmsg(lang('plugin/exx_linkseo', 'f01'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=exx_linkseo&pmod=admin&formhash='.FORMHASH, 'succeed');
			}
			showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin&ac=edit", 'enctype');
			showtableheader(lang('plugin/exx_linkseo', 'f03'));
			showsetting(lang('plugin/exx_linkseo', 'f04'), 'title', $dataarr['style'], 'htmltext');
			showsetting(lang('plugin/exx_linkseo', 'f05'),'url',$dataarr['url'],'text');
			showsetting(lang('plugin/exx_linkseo', 'f06'),'spic',$dataarr['pic'],'filetext');
			echo '<input name="keyid" type="hidden" value="'.$dataarr['id'].'" />';
			showsubmit('editsubmit', 'submit', '');
			showtablefooter(); /*Dism��taobao��com*/
   			showformfooter(); /*Dism_taobao_com*/
			exit();
		}elseif($_GET['ac']=='del'){
			C::t('#exx_linkseo#exx_linkseo')->delete($keyid);
			$blank=$exx_linkseo['blank']?'target="_blank"':'';
			$content = C::t('#exx_linkseo#exx_linkseo')->fetchall();
			foreach($content as $k=>$v){
				$alttag=$exx_linkseo['alt']?'alt="'.$v['title'].'"':'';
				$icow=$exx_linkseo['icow']?intval($exx_linkseo['icow']):15;
				$repkey='<a href="'.$v['url'].'" style="text-decoration: blink;" '.$blank.'>'.$v['style'].($v['pic']? '<img src="'.$v['pic'].'" '.$alttag.' title="'.$v['title'].'" width="'.$icow.'" />':'').'</a>';
				$words['replace'][]=$repkey;
				$words['search'][]=$v['title'];
			}
			require_once libfile('function/cache');
			savecache('exx_linkseo', $words);
			
		}
		cpmsg(lang('plugin/exx_linkseo', 'f01'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=exx_linkseo&pmod=admin', 'succeed');
	}
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin");
	showtableheader(lang('plugin/exx_linkseo', 'f07').' <span style="color:#ccc; margin:0 10px">|</span> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=exx_linkseo&pmod=admin&ac=edit&formhash='.FORMHASH.'"><font color="#FF0000"> + '.lang('plugin/exx_linkseo', 'f03').'</font></a>');
    showsubtitle(array(lang('plugin/exx_linkseo', 'f08').'?',lang('plugin/exx_linkseo', 'f09'),lang('plugin/exx_linkseo', 'f10'), lang('plugin/exx_linkseo', 'f11'),lang('plugin/exx_linkseo', 'f12')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=exx_linkseo&pmod=admin';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$icow=$exx_linkseo['icow']?intval($exx_linkseo['icow']):15;
	$allcount = C::t('#exx_linkseo#exx_linkseo')->count_all();
	if($allcount){
		$query = C::t('#exx_linkseo#exx_linkseo')->fetch_all_by_limit($startlimit,$ppp);
		foreach($query as $val){
			$alttag=$exx_linkseo['alt']?'alt="'.$val['title'].'"':'';
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
			$table[1] = '<a href="'.$val['url'].'" target="_blank">'.$val['title'].'</a>';
			$table[2] = $val['url'];
			$table[3] = $val['style'].' '.($val['pic']? '<img src="'.$val['pic'].'" '.$alttag.' title="'.$val['title'].'" width="'.$icow.'" />':'');
			$table[4] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=exx_linkseo&pmod=admin&ac=edit&keyid='.$val['id'].'&formhash='.FORMHASH.'"">'.lang('plugin/exx_linkseo', 'f13').'</a>  / <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=exx_linkseo&pmod=admin&ac=del&keyid='.$val['id'].'&formhash='.FORMHASH.'"">'.lang('plugin/exx_linkseo', 'f14').'</a>';
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	echo '<input type="hidden" name="page" value="'.intval($_GET['page']).'" />';
	echo $multipage? '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>':'';
	showsubmit('forumset', 'submit', 'del');
    showtablefooter(); /*Dism��taobao��com*/
	showformfooter(); /*Dism_taobao_com*/
function editor_safe_replace($content){
    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}