<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}
class plugin_exx_linkseo{
	function strtr_words($str){
		global $_G;
		$exx_linkseo = $_G['cache']['plugin']['exx_linkseo'];
		$words=array();
		loadcache('exx_linkseo');
		$cacedata=$_G['cache']['exx_linkseo'];
		if(!$cacedata){
			$blank=$exx_linkseo['blank']?'target="_blank"':'';
			$content = C::t('#exx_linkseo#exx_linkseo')->fetchall();
			foreach($content as $k=>$v){
				$alttag=$exx_linkseo['alt']?'alt="'.$v['title'].'"':'';
				$icow=$exx_linkseo['icow']?intval($exx_linkseo['icow']):15;
				$repkey='<a href="'.$v['url'].'" '.$blank.' title="'.$v['title'].'">'.$v['style'].($v['pic']? '<img src="'.$v['pic'].'" '.$alttag.' title="'.$v['title'].'" width="'.$icow.'" style="width:'.$icow.'px !important;height:auto !important" />':'').'</a>';
				$words['replace'][]=$repkey;
				$words['search'][]=$v['title'];
			}
			require_once libfile('function/cache');
			savecache('exx_linkseo', $words);
			$cacedata=$words;
		}
		$cs=$exx_linkseo['cs']?intval($exx_linkseo['cs']):-1;
		if($cacedata){
			return $this->str_replace_limit($cacedata['search'],$cacedata['replace'],$str,$cs);
		}
		return $str;
	}

	function str_replace_limit($search, $replace, $subject, $limit=-1){
		preg_match_all('#<ignore_js_op>(.*)</ignore_js_op>#iUs',$subject,$pregarr);
		foreach($pregarr[0] as $filekey=>$fileval){
			$searcha[$filekey]='[exxfilelink]'.$filekey.'[/exxfilelink]';
			$replacea[$filekey]=$fileval;
			$subject=str_replace($replacea[$filekey],$searcha[$filekey],$subject);
		}
		preg_match_all('#<a href="(.*)" target="_blank">(.*)</a>#iUs',$subject,$pregarra);
		foreach($pregarra[0] as $akey=>$aval){
			$searche[$akey]='[exxalink]'.$akey.'[/exxalink]';
			$replacee[$akey]=$aval;
			$subject=str_replace($replacee[$akey],$searche[$akey],$subject);
		}
		
		if(is_array($search)){  
			foreach($search as $k=>$v){
				$searchs[$k]='/(?!<[^>]*)'.preg_quote($v, '`').'(?![^<]*>)/';
			}  
		}else{  
			$search = '/(?!<[^>]*)'. preg_quote($search, '`'). '(?![^<]*>)/';  
		}
		$msg=preg_replace($searchs, $replace, $subject, $limit);
		$msg=str_replace($searcha, $replacea, $msg);
		$msg=str_replace($searche, $replacee, $msg);
		return $msg;
	}
}

class plugin_exx_linkseo_forum extends plugin_exx_linkseo{
	function viewthread_posttop_output() {
		global $_G,$postlist;
		$exx_linkseo = $_G['cache']['plugin']['exx_linkseo'];
		$infid=in_array($_G['fid'],unserialize($exx_linkseo['bk'])) ? 1 : 0;
		if(($_G['thread']['isgroup'] && !$exx_linkseo['qz']) || (!$_G['thread']['isgroup'] && !$infid)){
			return array();
		}
		
		if($_G['forum_firstpid']){
			$msg=$postlist[$_G['forum_firstpid']]['message'];
			$postlist[$_G['forum_firstpid']]['message']=$this->strtr_words($msg);
		}
		return array();
	}
}

class plugin_exx_linkseo_portal  extends plugin_exx_linkseo{
	function view_article_content_output(){
		global $_G,$content;
		$exx_linkseo = $_G['cache']['plugin']['exx_linkseo'];
		$page=$_GET['page']?intval($_GET['page']):1;
		$aid=intval($_GET['aid']);
		if(!$content){
			$content = C::t('portal_article_content')->fetch_by_aid_page($aid, $page);
		}
		if($exx_linkseo['portal'] && $aid){
			$msg=$content['content'];
			$content['content']=$this->strtr_words($msg);
		}
		return '';
	}
}


class mobileplugin_exx_linkseo extends plugin_exx_linkseo{
	function global_header_mobile(){
		global $_G,$content;
		$exx_linkseo = $_G['cache']['plugin']['exx_linkseo'];
		$aid=intval($_GET['aid']);
		if($aid){
			if(!$content){
				$page=$_GET['page']?intval($_GET['page']):1;
				$content = C::t('portal_article_content')->fetch_by_aid_page($aid, $page);
			}
			if($exx_linkseo['portal'] && $aid){
				$msg=$content['content'];
				$content['content']=$this->strtr_words($msg);
			}
		}
		return '';
	}
}


class plugin_exx_linkseo_group  extends plugin_exx_linkseo_forum{	
}
class mobileplugin_exx_linkseo_forum extends plugin_exx_linkseo_forum{
}
class mobileplugin_exx_linkseo_group extends plugin_exx_linkseo_forum{
}