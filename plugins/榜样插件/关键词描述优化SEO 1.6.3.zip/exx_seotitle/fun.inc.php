<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

function getkw($subjectenc){
		global $_G;
		$exx_seotitle = $_G['cache']['plugin']['exx_seotitle'];	
		$xi=$exx_seotitle['xi'] ? floatval($exx_seotitle['xi']) : '0.8';
		$subject=exx_seotitle_gbk2utf(dhtmlspecialchars($subjectenc));
		$subject=urlencode($subject); 
		$url='http://api.pullword.com/get.php?source='.$subject.'&param1='.$xi.'&param2=0';
		$data=dfsockopen($url);
		if(!$data){
			$data=file_get_contents($url);
		}
		$keyword_list = trim($data);
        $keyword_arr=$keyword_arrs=array();
		if(!($keyword_list=='error')){
        	$keyword_arr = explode("\r\n", $keyword_list);
		}
		$cou=intval($exx_seotitle['kw']);
		if($cou){
			$n=1;
			foreach($keyword_arr as $k=>$v){
				if($n>$cou){break;}
				$keyword_arrs[$k]=$v;
				$n++;
			}
		}else{
			$keyword_arrs=$keyword_arr;
		}
		$keyw=implode(',', $keyword_arrs);
		$keyw=CHARSET=='gbk'?exx_seotitle_utf2gbk($keyw):$keyw;
		if($keyw=='error'){
			$keyw=$subjectenc;
		}
		return $keyw;
}

function getkwbytid($tid,$mods){
	require_once libfile('function/post');
	if($mods){
		$article = C::t('portal_article_title')->fetch($tid);
		$titles=$article['title'];
	}else{
		$thread = DB::fetch_first("SELECT subject,message FROM ".DB::table('forum_post') ." WHERE tid = '".$tid."' AND first=1 limit 1");
		$titles=$thread['subject'];
	}
	$titles=str_replace(array('[',']','.','-','&','(',')','*','(',')','#','$','%','^','@','_'),'',$titles);
	$keyw=getkw($titles);
	return $keyw;
}

function exx_seotitle_utf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return exx_seotitle_gbk2utf($data);
	}
}
function exx_seotitle_gbk2utf($data){
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	return diconv($tmpstr,'gbk','utf-8');
}