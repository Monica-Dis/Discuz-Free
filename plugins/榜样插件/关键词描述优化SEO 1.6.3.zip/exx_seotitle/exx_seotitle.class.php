<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}
class plugin_exx_seotitle_forum{
	function viewthread_posttop_output() {
		global $_G, $navtitle,$metakeywords,$metadescription,$postlist;
		$exx_seotitle = $_G['cache']['plugin']['exx_seotitle'];	
		$kwnb=intval($exx_seotitle['kw']);
		$section = empty($exx_seotitle['bk']) ? array() : unserialize($exx_seotitle['bk']);
		if(!is_array($section)) $section = array();
		if((!(empty($section[0]) || in_array($_G['fid'],$section))) && $_G['tid']){
			return '';
		}
		include_once DISCUZ_ROOT . './source/plugin/exx_seotitle/fun.inc.php';
		if(CURSCRIPT == 'portal'){
			$aidtid=intval($_GET['aid']);
			$curmod=1;
		}else{
			$aidtid=$_G['tid']?intval($_G['tid']):intval($_GET['tid']);
			$curmod=0;
		}
		
		if($aidtid){
			$titledata=DB::fetch_first("select title,keywords,description from ".DB::table('exx_seotitle')." where tid=".$aidtid." AND mods=".$curmod." limit 1");
		}
		if($titledata){
			$navtitle = $titledata['title'] ?  dhtmlspecialchars($titledata['title']): dhtmlspecialchars($navtitle);
			$metakeywords = $titledata['keywords'] ? dhtmlspecialchars($titledata['keywords']) : dhtmlspecialchars($metakeywords);
			$metadescription = $titledata['description'] ? dhtmlspecialchars($titledata['description']) : dhtmlspecialchars($metadescription);
		}elseif(!$titledata && $exx_seotitle['auto']){
			$metakeywords = getkwbytid($aidtid,$curmod);
			if($metakeywords){
				DB::query("insert into ".DB::table('exx_seotitle')."(tid , keywords ,mods) values ('".$aidtid."' , '".$metakeywords."','".$curmod."')");
			}
		}
		return '';
	}
	function viewthread_postbutton_top_output() {
		global $_G,$polloptions;
		$exx_seotitle = $_G['cache']['plugin']['exx_seotitle'];	
		$section = empty($exx_seotitle['bk']) ? array() : unserialize($exx_seotitle['bk']);
		if(!is_array($section)) $section = array();
		if((!(empty($section[0]) || in_array($_G['fid'],$section))) && $_G['tid']){
			return ;
		}
		$isgroup=1;
		$group = empty($exx_seotitle['yhz']) ? array() : unserialize($exx_seotitle['yhz']);
		if(!(empty($group[0]) || in_array($_G['groupid'],$group))){
			$isgroup=0;
		}
		$curmod=0;
		if(CURSCRIPT == 'portal'){
			$curmod=1;
		}
		
		include template('exx_seotitle:btn');
		return $return;
	}
	
	function viewthread_postheader(){
		global $_G,$polloptions;
		$exx_seotitle = $_G['cache']['plugin']['exx_seotitle'];	
		$section = empty($exx_seotitle['bk']) ? array() : unserialize($exx_seotitle['bk']);
		if(!is_array($section)) $section = array();
		if((!(empty($section[0]) || in_array($_G['fid'],$section))) && $_G['tid']){
			return array();
		}
		$isgroup=1;
		$group = empty($exx_seotitle['yhz']) ? array() : unserialize($exx_seotitle['yhz']);
		if(!(empty($group[0]) || in_array($_G['groupid'],$group))){
			$isgroup=0;
		}
		include template('exx_seotitle:btn');
		return array($returns);
	}
	
	
}


class plugin_exx_seotitle_portal extends plugin_exx_seotitle_forum{
	function view_article_top_output(){
		return $this->viewthread_postbutton_top_output().$this->viewthread_posttop_output();
		
	}
}

class plugin_exx_seotitle_group extends plugin_exx_seotitle_portal{
	function viewthread_postbottom(){
		return $this->viewthread_posttop_output();
	}
}




class mobileplugin_exx_seotitle_forum{
	function viewthread_posttop_mobile_output(){
		global $_G, $navtitle,$metakeywords,$metadescription,$postlist;
		$exx_seotitle = $_G['cache']['plugin']['exx_seotitle'];	
		$kwnb=intval($exx_seotitle['kw']);
		$section = empty($exx_seotitle['bk']) ? array() : unserialize($exx_seotitle['bk']);
		if(!is_array($section)) $section = array();
		if((!(empty($section[0]) || in_array($_G['fid'],$section))) && $_G['tid']){
			return array();
		}
		include_once DISCUZ_ROOT . './source/plugin/exx_seotitle/fun.inc.php';
		if(CURSCRIPT == 'portal'){
			$aidtid=intval($_GET['aid']);
			$curmod=1;
		}else{
			$aidtid=$_G['tid']?intval($_G['tid']):intval($_GET['tid']);
			$curmod=0;
		}
		if($aidtid){
			$titledata=DB::fetch_first("select title,keywords,description from ".DB::table('exx_seotitle')." where tid=".$aidtid." AND mods=".$curmod." limit 1");
		}
		if($titledata){
			$navtitle = $titledata['title'] ?  dhtmlspecialchars($titledata['title']): dhtmlspecialchars($navtitle);
			$metakeywords = $titledata['keywords'] ? dhtmlspecialchars($titledata['keywords']) : dhtmlspecialchars($metakeywords);
			$metadescription = $titledata['description'] ? dhtmlspecialchars($titledata['description']) : dhtmlspecialchars($metadescription);
		}elseif(!$titledata && $exx_seotitle['auto']){
			$metakeywords = getkwbytid($aidtid,$curmod);
			if($metakeywords){
				DB::query("insert into ".DB::table('exx_seotitle')."(tid , keywords ,mods) values ('".$aidtid."' , '".$metakeywords."','".$curmod."')");
			}
		}
		if(checkmobile()){
			$group = empty($exx_seotitle['yhz']) ? array() : unserialize($exx_seotitle['yhz']);
			if(in_array($_G['groupid'],$group)){
				$btn='<div><span style="background:#27bc9c; padding:2px 5px;"><a href="plugin.php?id=exx_seotitle:show&tid='.$_G['tid'].'" style="color:#FFF; font-size:12px;">'.lang('plugin/exx_seotitle', 'yhgjc').'</a></span></div>';
			}
			
			foreach($postlist as $k=>$val){
				if($postlist[$k]['first']){
					$postlist[$k]['message']=$btn.$postlist[$k]['message'];
				}
			}
		}
		return array();
	}
}


class mobileplugin_exx_seotitle_group extends mobileplugin_exx_seotitle_forum{
	
}
