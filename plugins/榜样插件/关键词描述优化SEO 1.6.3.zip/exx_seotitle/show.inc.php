<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
    global $_G;
	$var = $_G['cache']['plugin']['exx_seotitle'];
	$group = empty($var['yhz']) ? array() : unserialize($var['yhz']);
	if(!(in_array($_G['groupid'],$group))){
		return;
	}
	$kwnb=intval($var['kw']);
	include_once DISCUZ_ROOT . './source/plugin/exx_seotitle/fun.inc.php';	
	$tid = intval($_GET['tid']);
	$curmod = intval($_GET['curmod']);
	if($curmod){
		$article = C::t('portal_article_title')->fetch($tid);
		$titles=$article['title'];
		$msgs=$thread['message'];
	}else{
		$thread = DB::fetch_first("SELECT subject,message FROM ".DB::table('forum_post') ." WHERE tid = '".$tid."' AND first=1 limit 1");
		$titles=$thread['subject'];
		$msgs=$thread['message'];
	}
	
	$exx_seotitle=DB::fetch_first("select title,keywords,description from ".DB::table('exx_seotitle')." where tid=".$tid." AND mods=".$curmod." limit 1");

	if(submitcheck('btn')) {
		$tid=intval($_GET['tid']);
		$title=daddslashes($_GET['title']);
		$keywords=daddslashes($_GET['keywords']);
		$description=daddslashes($_GET['description']);
		if($exx_seotitle){
			DB::query("update ".DB::table('exx_seotitle')." set title='$title',keywords='$keywords',description='$description',mods='$curmod' where tid=".$tid);
		}else{
			DB::query("insert into ".DB::table('exx_seotitle')."(tid , title , keywords , description,mods) values ('".$tid."' , '".$title."' , '".$keywords."' , '".$description."','".$curmod."')");
		}
		$rurl=$curmod?'portal.php?mod=view&aid='.$tid:'forum.php?mod=viewthread&tid='.$tid;
		showmessage(lang('plugin/exx_seotitle', 'ok'),$rurl,array(''),array('alert'=>'right'));	
	}

	require_once libfile('function/post');
	$message=strip_tags($msgs);
	$desdata=messagecutstr($message, 200);
	$repfind=array("\r", "\n");
	$exxdescription=str_replace($repfind, '', $desdata);
	$exxdescription=$exxdescription?:$titles;
	$keyw=getkw($titles);
	$exxkeywords=$keyw;
	if($exx_seotitle){
		$exxtitle=$exx_seotitle['title']? dhtmlspecialchars($exx_seotitle['title']):$titles;
		$exxkeywords=$exx_seotitle['keywords'] ? dhtmlspecialchars($exx_seotitle['keywords']) : $keyw;
		$exxdescription=$exx_seotitle['description'] ? dhtmlspecialchars($exx_seotitle['description']):$exxdescription;
	}
	include template('exx_seotitle:showwin');