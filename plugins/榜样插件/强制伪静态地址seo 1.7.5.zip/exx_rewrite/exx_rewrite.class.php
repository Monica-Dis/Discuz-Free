<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}
class plugin_exx_rewrite{
	function global_header(){
		global $_G;
		loadcache('plugin');
		$var = $_G['cache']['plugin']['exx_rewrite'];
		if(!$var['wap'] && checkmobile()){
			return '';
		}
		$section = empty($var['yhz']) ? array() : unserialize($var['yhz']);
		if(in_array($_G['groupid'],$section)){
			$url='';
			$urls=$_SERVER['REQUEST_URI']; //liunx
			$urla=$_SERVER["HTTP_X_REWRITE_URL"];//Windows
			if(!$urla){
				$urla=$_SERVER["HTTP_X_ORIGINAL_URL"];
			}
			$_GET['page']= $_GET['page'] ? intval($_GET['page']) : 1;
			$crawler=$this->isCrawler();
			$tagrewritevar = $_G['cache']['plugin']['exx_tagrewrite'];
			$exx_gseo = $_G['cache']['plugin']['exx_gseo'];
			$portalrewrite = $_G['cache']['plugin']['exx_portalrewrite'];
			$exx_typere = $_G['cache']['plugin']['exx_typere'];
            if(((strpos($urls, '.php') !== FALSE || strpos($urls, 'mod=') !== FALSE) && !$urla) || ($urla && (strpos($urla, '.php') !== FALSE || strpos($urls, 'mod=') !== FALSE))) {
				if($_G['tid'] && $_G['fid'] && $_G['mod']=='viewthread' && (in_array('forum_viewthread', $_G['setting']['rewritestatus']))){
					if(($var['enhance'] && $crawler) || (!$_GET['modthreadkey'] && !(strpos($urls, '#pid') !== FALSE) && $var['tnr'] && !$_GET['inajax'] && !$_GET['ajaxtarget'] && !$_GET['do'] && !$_GET['authorid'] && !$_GET['ordertype'] && !$_GET['from'])){
						if($var['tnrgs']){
							$forumkey=$_G['setting']['forumkeys'][$_G['fid']]?$_G['setting']['forumkeys'][$_G['fid']]:$_G['fid'];
							$url=str_replace(array('{tid}','{page}','{fid}'), array($_G['tid'],$_GET['page'],$forumkey), $var['tnrgs']);
						}else{
							$url=rewriteoutput('forum_viewthread', 1, '', $_G['tid'], $_GET['page']);
						}
					}
				}elseif($_G['fid'] && !$_G['tid'] && $_G['mod']=='forumdisplay' && (in_array('forum_forumdisplay', $_G['setting']['rewritestatus']))){
					if(($var['enhance'] && $crawler) || ($var['tlb'] && !$_GET['filter'] && !$_GET['digest'] && !$_GET['dateline'] && !$_GET['modthreadkey'] && !$_GET['typeid'] && !$_GET['sortid'] && !$_GET['sortall'] && !$_GET['inajax'])){		
						if($var['tlbgs']){
							$forumkey=$_G['setting']['forumkeys'][$_G['fid']]?$_G['setting']['forumkeys'][$_G['fid']]:$_G['fid'];
							$url=str_replace(array('{fid}','{page}'), array($forumkey,$_GET['page']), $var['tlbgs']);
						}else{
							$url=rewriteoutput('forum_forumdisplay', 1, '', $_G['fid'], $_GET['page']);
						}
					}elseif($_GET['filter']=='typeid' && $var['typess'] && $_GET['typeid'] && file_exists('source/plugin/exx_typere/exx_typere.class.php') && $exx_typere){
						$rurl=$_GET['page']>1?dhtmlspecialchars($exx_typere['rurla']):dhtmlspecialchars($exx_typere['rurl']);
						$url=str_replace(array('{fid}','{typeid}','{page}'), array($_G['fid'],$_GET['typeid'],$_GET['page']), $rurl);
					}
				}elseif($_GET['aid'] && $_G['catid'] && $_G['mod']=='view' && $var['wnr'] && (in_array('portal_article', $_G['setting']['rewritestatus']))){
					if($var['wnrs']){
						$url=str_replace(array('{aid}','{page}'), array($_G['aid'],$_GET['page']), $var['wnrs']);
					}else{
						$url=rewriteoutput('portal_article', 1, '', $_GET['aid'],$_GET['page']);
					}
				}elseif(!$_G['tid'] && $_G['fid'] && $_G['mod']=='group' && !$_GET['action'] && $var['qlb'] && (in_array('group_group', $_G['setting']['rewritestatus']) && !$_GET['filter'])){
					if($var['qzurl']){
						$url=str_replace(array('{fid}','{page}'), array($_G['fid'],$_GET['page']), $var['qzurl']);
					}else{
						$url=rewriteoutput('group_group', 1, '', $_G['fid'], $_GET['page']);
					}
				}elseif($_G['mod']=='tag' && $var['tags'] && file_exists('source/plugin/exx_tagrewrite/exx_tagrewrite.class.php') && $tagrewritevar){
					if($tagrewritevar){
						if($_GET['id']){
							$url=$tagrewritevar['prefix'].'-'.$_GET['id'].'.html';
						}else{
							if(!$_GET['name'] || ($var['enhance'] && $crawler)){
								$url=$tagrewritevar['prefix'].'.html';
							}
						}
					}
				}elseif($_GET['gid']&& $var['g'] && file_exists('source/plugin/exx_gseo/exx_gseo.class.php') && CURSCRIPT=='forum' && $exx_gseo){
					$gid=intval($_GET['gid']);
					$url=str_replace('{gid}', $gid, $exx_gseo['rurl']);
				}elseif($_GET['mod']=='guide' && $_GET['view'] && !$_GET['rss'] && $var['guide'] && !$_GET['type'] && file_exists('source/plugin/exx_guiderewrite/exx_guiderewrite.class.php')){
					$exx_guiderewrite = $_G['cache']['plugin']['exx_guiderewrite'];
					$url=$_GET['page']>1?str_replace(array('{view}','{page}'), array($_GET['view'],$_GET['page']),$exx_guiderewrite['rurla']): str_replace('{view}', $_GET['view'], $exx_guiderewrite['rurl']);
				}elseif(CURSCRIPT=='portal' && $_GET['mod']=='list' && $_GET['catid'] && $var['portalrewrite'] && file_exists('source/plugin/exx_portalrewrite/exx_portalrewrite.class.php') && $portalrewrite){
					loadcache('portalcategory');
					$catid=intval($_GET['catid']);
					$page=$_GET['page'];
					$fullfoldername=$_G['cache']['portalcategory'][$catid]['fullfoldername'];
					if($fullfoldername){
						$rurl=dhtmlspecialchars($portalrewrite['rurlb']);
					}else{
						$rurl=($page>1)?dhtmlspecialchars($portalrewrite['rurla']):dhtmlspecialchars($portalrewrite['rurl']);
					}
					$url = str_replace(array('{catid}','{foldername}','{page}'), array($catid,$fullfoldername,$page), $rurl);
				}
				
				$exx_gseo = $_G['cache']['plugin']['exx_gseo'];
				if(CURSCRIPT=='forum' && !(strpos($exx_gseo['index'], '.php') !== FALSE) && ((strpos($urls, 'forum.php') !== FALSE) || (strpos($urla, 'forum.php') !== FALSE)) && !$_GET['mod'] && !$_GET['gid'] && $var['g'] && file_exists('source/plugin/exx_gseo/exx_gseo.class.php') && $exx_gseo){
					$url=dhtmlspecialchars($exx_gseo['index']);
				}
				
				if($url){
					Header("HTTP/1.1 301 Moved Permanently");
					Header("Location: ".$_G['siteurl'].$url);
					exit();
				}	
			}
		}
		return '';
	}
	
	function isCrawler() { 
		$agent= strtolower($_SERVER['HTTP_USER_AGENT']);
		$ret='';
		if (!empty($agent)) { 
			$spiderSite= array( 
				'bot',
				'googlebot',
				'mediapartners-google',
				'feedfetcher-Google',
				'ia_archiver',
				'iaarchiver',
				'sqworm',
				'baiduspider',
				'Baiduspider-render/2.0',
				'Baiduspider-image',
				'Baiduspider/2.0',
				'Baiduspiderrender',
				'Baiduspider',
				'Baiduspider-render',
				'msnbot',
				'yodaobot',
				'yahoo! slurp;',
				'yahoo! slurp china;',
				'yahoo',
				'iaskspider',
				'sogou spider',
				'sogou web spider',
				'sogou push spider',
				'sogou orion spider',
				'sogou-test-spider',
				'sogou+head+spider',
				'sohu',
				'sohu-search',
				'Sosospider',
				'Sosoimagespider',
                'haosouspider',
				'JikeSpider',
				'360spider',
				'qihoobot',
				'tomato bot',
				'bingbot',
				'youdaobot',
				'askjeeves/reoma',
				'manbot',
				'robozilla',
				'MJ12bot',
				'HuaweiSymantecSpider',
				'Scooter',
				'Infoseek',
				'ArchitextSpider',
				'Grabber',
				'Fast',
				'ArchitextSpider',
				'Gulliver',
				'Lycos',
				'Baiduspider-render'
			); 
			foreach($spiderSite as $val) { 
				$str = strtolower($val); 
				if (strpos($agent, $str) !== false) { 
					$ret= true; 
				} 
			} 
		} else { 
			$ret= false; 
		}
		return $ret;
	}
	
}

class mobileplugin_exx_rewrite extends plugin_exx_rewrite{
	
}