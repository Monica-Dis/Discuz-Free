<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;
loadcache("plugin");
$exx_gseo = $_G['cache']['plugin']['exx_gseo'];
$urltmp=_setstr_replace($exx_gseo['rurl']);
$indexurltmp=_setstr_replace($exx_gseo['index']);
if(!$urltmp || !$indexurltmp){
	cpmsg(lang('plugin/exx_gseo', 'f07'), 'action=plugins&operation=config&do='.$plugin["pluginid"], 'error');
}
showtips(lang('plugin/exx_gseo', 'f06'));
$strtmp= '<br><h1>'.lang('plugin/exx_gseo', 'f01').'</h1>
<pre class="colorbox">

RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^(.*)/'.$urltmp.'$ $1/forum.php?gid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^(.*)/'.$indexurltmp.'$ $1/forum.php%1
</pre>

<h1>'.lang('plugin/exx_gseo', 'f02').'</h1>
<pre class="colorbox">

RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$urltmp.'$ forum.php?gid=$1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$indexurltmp.'$ forum.php%1
</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">

rewrite ^([^\.]*)/'.$urltmp.'$ $1/forum.php?gid=$2 last;
rewrite ^([^\.]*)/'.$indexurltmp.'$ $1/forum.php last;

</pre>

<h1>'.lang('plugin/exx_gseo', 'f03').'</h1>
<pre class="colorbox">

RewriteRule ^(.*)/'.$urltmp.'(\?(.*))*$ $1/forum\.php\?gid=$2
RewriteRule ^(.*)/'.$indexurltmp.'(\?(.*))*$ $1/forum\.php

</pre>

<h1>'.lang('plugin/exx_gseo', 'f05').'</h1>
<pre class="colorbox">

&lt;rule name="f_gid"&gt;
	&lt;match url="^(.*/)*'._iis_replace($exx_gseo['rurl']).'\?*(.*)$" /&gt;
	&lt;action type="Rewrite" url="{R:1}/forum.php\?gid={R:2}&amp;amp;{R:3}" /&gt;
&lt;/rule&gt;

&lt;rule name="f_index"&gt;
	&lt;match url="^(.*/)*'._iis_replace($exx_gseo['index']).'\?*(.*)$" /&gt;
	&lt;action type="Rewrite" url="{R:1}/forum.php" /&gt;
&lt;/rule&gt;

</pre>';
echo $strtmp;

function _setstr_replace($data){
	return str_replace(array(".","{gid}"),array("\\.","([0-9]+)"),dhtmlspecialchars($data));
}
function _iis_replace($data){
	return str_replace("{gid}","([0-9]+)",dhtmlspecialchars($data));
}