<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}


class plugin_exx_gseo{
	function global_header(){
		global $_G;
		$exx_gseo = $_G['cache']['plugin']['exx_gseo'];
		if($exx_gseo['off']){
			if($exx_gseo['yk'] && $_G['uid']){
				return '';
			}
			$durl='';
			$defaulturl=$_G['setting']['domain']['app']['default'];
			if($defaulturl){
				$schemes=($_SERVER['SERVER_PORT'] == '443' || $_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) != 'off') ? 'https' : 'http';
				$durl = str_replace(array('/','.',':'),array('\/','\.','\:'),$schemes.'://'.$defaulturl.'/');
			}
			if(!$_G['setting']['rewritestatus']){
				$_G['setting']['rewritestatus']=true;	
			}
			if ($_G['setting']['version'] == 'X3.3' || $_G['setting']['version'] == 'X3.4' || $_G['setting']['version'] == 'X3.5' || $_G['setting']['version'] == 'F1.0' || $_G['setting']['version'] == 'L1.0') {
				$_G['setting']['output']['preg']['search']['exx_gseo']='/<a href\\="('.$durl.')?forum.php\?gid\=(\d+)\"([^\>]*)\>/';
				$_G['setting']['output']['preg']['replace']['exx_gseo']='plugin_exx_gseo::rew($matches[2],$matches[3])';
				$_G['setting']['output']['preg']['search']['exx_gseo2']='/<a href\\="('.$durl.')?forum.php\"([^\>]*)\>/';
				$_G['setting']['output']['preg']['replace']['exx_gseo2']='plugin_exx_gseo::rew(\'index\',$matches[2])';
			}else{
				$_G['setting']['output']['preg']['search']['exx_gseo']='/<a href\\="([^\>]*)?forum\\.php\\?gid\\=(\\d+)\\"([^\\>]*)\\>/e';
				$_G['setting']['output']['preg']['replace']['exx_gseo']='plugin_exx_gseo::rew(\'\\2\',\'\\3\')';
				$_G['setting']['output']['preg']['search']['exx_gseo2']='/<a href\\="([^\>]*)?forum\\.php"([^\\>]*)\\>/e';
				$_G['setting']['output']['preg']['replace']['exx_gseo2']='plugin_exx_gseo::rew(\'index\',\'\\2\')';
			}
			
		}
		return '';
	}
	function rew($rewrite) {
		global $_G;
		$exx_gseo = $_G['cache']['plugin']['exx_gseo'];
		list($gid, $extra) = func_get_args();
		$href = ($gid=='index')?$exx_gseo['index']:str_replace('{gid}', $gid, $exx_gseo['rurl']);
		return '<a href="'.$href.'"' .(!empty($extra) ? stripslashes($extra) : '').'>';
	}
}

class mobileplugin_exx_gseo extends plugin_exx_gseo{
}