<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
date_default_timezone_set('Asia/Chongqing');
loadcache('plugin');	
showtableheader(lang('plugin/exx_baiduupdate', '001'));
showsubtitle(array(lang('plugin/exx_baiduupdate', '002'),lang('plugin/exx_baiduupdate', '003'), lang('plugin/exx_baiduupdate', '004'),lang('plugin/exx_baiduupdate', '005')));
$ppp=30;
$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=exx_baiduupdate&pmod=admin';
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$allcount = DB::result_first("select count(1) from ".DB::table('exx_baiduupdate'));
if($allcount){
	$query = DB::fetch_all("select type,msg,url,time,state from ".DB::table('exx_baiduupdate')." order by id desc LIMIT ".$startlimit.",".$ppp);
	foreach($query as $val){
		$type=$state='';
		switch ($val['type']) {
			case 1:$type=lang('plugin/exx_baiduupdate', '006');break;
			case 2:$type=lang('plugin/exx_baiduupdate', '007');break;
			case 3:$type=lang('plugin/exx_baiduupdate', '008');break;
		}
		switch ($val['state']) {
			case 1:$state=lang('plugin/exx_baiduupdate', '009');break;
			case 2:$state=lang('plugin/exx_baiduupdate', '010');break;
			case 3:$state=lang('plugin/exx_baiduupdate', '011');break;
			default:$state=lang('plugin/exx_baiduupdate', '012').$val['msg'];
		}
		$table = array();
		$table[0] = '<a href="'.$val['url'].'" target="_blank">'.$val['url'].'</a>';
		$table[1] = $type;
		$table[2] = $state;
		$table[3] = dgmdate($val['time'], 'Y/m/d H:i:s');
		showtablerow('',array(), $table);
	}
}
$multipage='';
$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
if($multipage)echo '<tr class="hover"><td colspan="4">'.$multipage.'</td></tr>';
showtablefooter();