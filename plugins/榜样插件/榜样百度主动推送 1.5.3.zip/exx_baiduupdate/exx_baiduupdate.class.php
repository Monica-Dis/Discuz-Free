<?php
/**
 * Created by bangyang.
 * User: QQ 2395841575
 * Date: 2017/04/01
 * Time: 22:02
 * UpDate: 2019/02/28
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_exx_baiduupdate{
	function deletethread($param){
		global $_G;
		$var = $_G['cache']['plugin']['exx_baiduupdate'];
		$tid = $param['param'][0][0];
		$section = unserialize($var['bk']);
		if($param['step'] == 'delete' && in_array($_G['fid'],$section) && $tid) {
			$url='forum.php?mod=viewthread&tid='.$tid;
			if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])){
				$url=rewriteoutput('forum_viewthread', 1, '', $tid, 1);
			}
			$this->_updatabaidu($tid,3,$url);
		}
		
	}
	
	function _updatabaidu($tid,$type,$urla){
		global $_G;
		$var = $_G['cache']['plugin']['exx_baiduupdate'];
		if(!$var['token'] || !$var['site']){
			return;
		}
		
		$urlas='forum.php?mod=viewthread&tid='.$tid;
		if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])){
			$urlas=rewriteoutput('forum_viewthread', 1, '', $tid, 1);
		}
		
		$http = ($_SERVER['SERVER_PORT'] == 443 || strpos($_G['siteurl'], 'https://') !== false || ($_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) != 'off')) ? 'https://' : 'http://';
		$posturl=$var['auto']?$_G['siteurl']:$http.$var['site'].'/';
		$urls = array(
			$posturl.($var['sec']?trim($var['sec']):'').$urlas
		);
		$var['site']=$var['auto']?$posturl:$var['site'];
		$api = 'http://data.zz.baidu.com/urls?site='.$var['site'].'&token='.$var['token'].'';
		if(function_exists('curl_init') && function_exists('curl_exec')){
			$ch = curl_init();
			$options =  array(
				CURLOPT_URL => $api,
				CURLOPT_POST => true,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_POSTFIELDS => implode("\n", $urls),
				CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
			);
			curl_setopt_array($ch, $options);
			$result = curl_exec($ch);
			$ret=json_decode($result, true);
		}else{
			$ret['error']=10;
			$msg='curl_error';
		}
		if($ret['error']){
			$state=intval($ret['error']);
			$msg=daddslashes($ret['message']);
		}else{
			if($ret['success']){
				$state=1;
			}else{
				if($ret['not_same_site']){
					$state=2;
					$msg='not_same_site';
				}
				if($ret['not_valid']){
					$state=3;
					$msg='not_valid';
				}
			}
		}
		DB::query("insert into ".DB::table('exx_baiduupdate')."(url , state ,msg, time,type) values ('".implode("\n", $urls)."' , '".$state."' , '".$msg."' , '".$_G['timestamp']."' , '".$type."')");
		return $result;
	}
}


class plugin_exx_baiduupdate_forum extends plugin_exx_baiduupdate{
	function post_message($param) {
		global $_G;
		$var = $_G['cache']['plugin']['exx_baiduupdate'];
		$param = $param['param'];
		$section = unserialize($var['bk']);
		$groups=unserialize($var['yhz']);
		if(in_array($_G['fid'],$section) && in_array($_G['groupid'],$groups)){
			$tid = intval($param[2]['tid']);
			$url=$param[1];
			if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])){
				$url=rewriteoutput('forum_viewthread', 1, '', $tid, 1);
			}
			if(($param[0]=="post_newthread_succeed") && $var['xintie']){
				$this->_updatabaidu($tid,1,$url);
			}elseif($param[0]=="post_edit_succeed" && $var['gengxin']){
				$this->_updatabaidu($tid,1,$url);
			}elseif($param[0]=="post_edit_delete_succeed" && $var['del']){
				$this->_updatabaidu($tid,3,$url);
			}
		}
		return '';
	}
	
	function viewthread_postbottom_output(){
		global $_G;
		$var = $_G['cache']['plugin']['exx_baiduupdate'];
		$section = unserialize($var['bk']);
		$groups=unserialize($var['yhz']);
		
		if(!$_G['forum_thread'] || !$_G['forum'] || $_G['thread']['displayorder']<0){
			return array();
		}
		if(in_array($_G['fid'],$section) && in_array($_G['groupid'],$groups) && $_G['thread']['dateline']>strtotime($var['time'])){
			
			$url='forum.php?mod=viewthread&tid='.$_G['tid'];
			if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])){
				$url=rewriteoutput('forum_viewthread', 1, '', $_G['tid'], 1);
			}
			$http = ($_SERVER['SERVER_PORT'] == 443 || strpos($_G['siteurl'], 'https://') !== false || ($_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) != 'off')) ? 'https://' : 'http://';
			$posturl=$var['auto']?$_G['siteurl']:$http.$var['site'].'/';
			$urls = $posturl.($var['sec']?trim($var['sec']):'').$url;

			$count=DB::result_first("select count(1) from ".DB::table('exx_baiduupdate')." where url='".$urls."' AND state=1 limit 1");
			if(!$count){
				$this->_updatabaidu($_G['tid'],1,$urlss);
			}
		}
		return array();
	}
}

class mobileplugin_exx_baiduupdate_forum extends plugin_exx_baiduupdate_forum{
}