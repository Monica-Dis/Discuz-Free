<?php
 /*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_exx_404seo{
	
	function global_header(){
		global $_G;
		if(CURSCRIPT=='forum' && $_GET['gid'] && empty($_G['forum']['fid'])){
			$this->set404();
		}
	}
	
	function set404(){
		global $_G;
		$exx_404seo = $_G['cache']['plugin']['exx_404seo'];	
		if(!$exx_404seo['off']){
			return;
		}
		$tmpid=intval($exx_404seo['temp']);
		$exx_404seo['jumptime']=intval($exx_404seo['jumptime']);
		$exx_404seo['jumpurl']=$exx_404seo['jumpurl']?dhtmlspecialchars($exx_404seo['jumpurl']):$_G['siteurl'];
		
		if($exx_404seo['referer'] && $_SERVER['HTTP_REFERER']){
			$exx_404seo['jumpurl']=$_SERVER['HTTP_REFERER'];
		}
		
		header('HTTP/1.1 404 Not Found');
		$waptpl=$_G['mobiletpl'][IN_MOBILE];
		$_G['mobiletpl'][IN_MOBILE]='/';
		include template('exx_404seo:'.$tmpid.'/index');
		$_G['mobiletpl'][IN_MOBILE]=$waptpl;
		exit;
	}
}

class plugin_exx_404seo_forum extends plugin_exx_404seo{
	function viewthread_posttop(){
		global $_G;
		if(!$_G['forum_thread'] || !$_G['forum']) {
			$this->set404();
		}
		return array();
	}
	function forumdisplay_thread_output(){
		global $_G, $threadlist;
		if(empty($_G['forum']['fid'])) {
			$this->set404();
		}
		return array();
	}
	
	
}

class plugin_exx_404seo_portal extends plugin_exx_404seo{
	function view_article_content_output(){
		global $_G, $article,$categoryperm;
		if(empty($article) || ($article['status'] > 0 && $article['uid'] != $_G['uid'] && !$_G['group']['allowmanagearticle'] && empty($categoryperm[$article['catid']]['allowmanage']) && $_G['adminid'] != 1 && $_GET['modarticlekey'] != modauthkey($article['aid']))) {
			$this->set404();
		}
	}
}	
	




class mobileplugin_exx_404seo extends plugin_exx_404seo{
}
class mobileplugin_exx_404seo_forum extends plugin_exx_404seo_forum{
}