<?php
/**
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/6/27
 * Time: 23:04
 * UPDate: 2018/7/12
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


class plugin_exx_mzsm{
	function _getmszm($i=''){
		global $_G;
		$exx_mzsm=$_G['cache']['plugin']['exx_mzsm'];
		$section = empty($exx_mzsm['mod']) ? array() : unserialize($exx_mzsm['mod']);
		$ret=$i?'':array();
		if(!is_array($section)) $section = array();
		if(!($section[0]=='all')){
			if(!(in_array(CURSCRIPT,$section))){
				return $ret;
			}
		}	
		
		if(CURSCRIPT=='forum'){
			$se = empty($exx_mzsm['bk']) ? array() : unserialize($exx_mzsm['bk']);
			if(!is_array($se)) $se = array();
			if(!(empty($se[0]) || in_array($_G['fid'],$se))){
				return array();
			}
		}
		
		$title=$this->_mszm_editor_safe_replace($exx_mzsm['title']);
		$txt=$this->_mszm_editor_safe_replace($exx_mzsm['txt']);
		$ys=dhtmlspecialchars($exx_mzsm['ys']);
		$ysa=dhtmlspecialchars($exx_mzsm['wz']);
		$bg=dhtmlspecialchars($exx_mzsm['bg']);
		$fontsize=intval($exx_mzsm['fontsize']);
		include template('exx_mzsm:index');
		if(!$_GET['page'] || $_GET['page']==1){
			$temp[0]=$return;
		}
		if($i==1){
			return $return;
		}else{
			return $temp;
		};
	}
	
	
	
	function _mszm_editor_safe_replace($content){
		$tags = array(
			"'<iframe[^>]*?>.*?</iframe>'is",
			"'<frame[^>]*?>.*?</frame>'is",
			"'<script[^>]*?>.*?</script>'is",
			"'<head[^>]*?>.*?</head>'is",
			"'<title[^>]*?>.*?</title>'is",
			"'<meta[^>]*?>'is",
			"'<link[^>]*?>'is",
		);
		return preg_replace($tags, "", $content);
	}
	
}



class plugin_exx_mzsm_forum extends plugin_exx_mzsm{
	function viewthread_postbottom_output(){
		return $this->_getmszm();
	}
}
class plugin_exx_mzsm_portal extends plugin_exx_mzsm{
	function view_article_content(){
		return $this->_getmszm(1);
	}
}

class plugin_exx_mzsm_group extends plugin_exx_mzsm{
	function viewthread_postbottom(){
		return $this->_getmszm();
	}
}

class mobileplugin_exx_mzsm_forum extends plugin_exx_mzsm{
	function viewthread_postbottom_mobile(){
		return $this->_getmszm();
	}
}
class mobileplugin_exx_mzsm_group extends plugin_exx_mzsm{
	function viewthread_postbottom(){
		return $this->_getmszm();
	}
}