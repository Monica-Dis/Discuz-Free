<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $_G;
loadcache("plugin");
$exx_guiderewrite = $_G['cache']['plugin']['exx_guiderewrite'];

if(!$exx_guiderewrite['rurli'] || !$exx_guiderewrite['rurl'] || !$exx_guiderewrite['rurla']){
	cpmsg(lang('plugin/exx_guiderewrite', 'f07'), 'action=plugins&operation=config&do='.$plugin["pluginid"], 'error');
}

$rurli=formatstr($exx_guiderewrite['rurli']);
$rurl=formatstr($exx_guiderewrite['rurl']);
$rurla=formatstr($exx_guiderewrite['rurla']);

showtips(lang('plugin/exx_guiderewrite', 'f06'));

$strtmp= '<br><h1>'.lang('plugin/exx_guiderewrite', 'f01').'</h1>
<pre class="colorbox">
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^(.*)/'.$rurli.'$ $1/forum.php?mod=guide%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^(.*)/'.$rurl.'$ $1/forum.php?mod=guide&view=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^(.*)/'.$rurla.'$ $1/forum.php?mod=guide&view=$2&page=$3&%1
</pre>

<h1>'.lang('plugin/exx_guiderewrite', 'f02').'</h1>
<pre class="colorbox">

RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$rurli.'$ forum.php?mod=guide%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$rurl.'$ forum.php?mod=guide&view=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$rurla.'$ forum.php?mod=guide&view=$1&page=$2&%1

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">

rewrite ^([^\.]*)/'.$rurli.'$ $1/forum.php?mod=guide last;
rewrite ^([^\.]*)/'.$rurl.'$ $1/forum.php?mod=guide&view=$2 last;
rewrite ^([^\.]*)/'.$rurla.'$ $1/forum.php?mod=guide&view=$1&page=$3 last;

</pre>

<h1>'.lang('plugin/exx_guiderewrite', 'f03').'</h1>
<pre class="colorbox">

RewriteRule ^(.*)/'.$rurli.'(\?(.*))*$ $1/forum.php\?mod=guide
RewriteRule ^(.*)/'.$rurl.'(\?(.*))*$ $1/forum.php\?mod=guide&view=$2
RewriteRule ^(.*)/'.$rurla.'(\?(.*))*$ $1/forum.php\?mod=guide&view=$2&page=$3

</pre>

<h1>'.lang('plugin/exx_guiderewrite', 'f05').'</h1>
<pre class="colorbox">

&lt;rule name="guide_index"&gt;
	&lt;match url="^(.*/)*'.$rurli.'\?*(.*)$" /&gt;
	&lt;action type="Rewrite" url="{R:1}/forum.php\?mod=guide" /&gt;
&lt;/rule&gt;

&lt;rule name="guide_first"&gt;
	&lt;match url="^(.*/)*'.$rurl.'\?*(.*)$" /&gt;
	&lt;action type="Rewrite" url="{R:1}/forum.php\?mod=guide&amp;amp;view={R:2}" /&gt;
&lt;/rule&gt;

&lt;rule name="guide_list"&gt;
	&lt;match url="^(.*/)*'.$rurla.'\?*(.*)$" /&gt;
	&lt;action type="Rewrite" url="{R:1}/forum.php\?mod=guide&amp;amp;view={R:2}&amp;amp;page={R:3}" /&gt;
&lt;/rule&gt;

</pre>

';
exit($strtmp);

function formatstr($str){
	return str_replace(array('{view}','{page}','.'),array('(hot|digest|new|newthread|sofa|my|index)','([0-9]+)','\\.'),dhtmlspecialchars($str));
}