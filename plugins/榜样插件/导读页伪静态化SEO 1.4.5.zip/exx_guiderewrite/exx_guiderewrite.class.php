<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}


class plugin_exx_guiderewrite{
	function global_header(){
		global $_G;
		$exx_guiderewrite = $_G['cache']['plugin']['exx_guiderewrite'];
		if(($exx_guiderewrite['yk'] && $_G['uid']) || !$exx_guiderewrite['off']){
			return '';
		}
		if(!$_G['setting']['rewritestatus']){
			$_G['setting']['rewritestatus']=true;
		}
		if ($_G['setting']['version'] == 'X3.3' || $_G['setting']['version'] == 'X3.4' || $_G['setting']['version'] == 'X3.5' || $_G['setting']['version'] == 'F1.0' || $_G['setting']['version'] == 'L1.0') {
			$_G['setting']['output']['preg']['search']['exx_guiderewrite1']='/<a([^\>]*)?href\=\"([^\>]*)?forum\.php\?mod\=guide(&(amp;)?view\=(\w+)(&(amp;)?page=(\d+))?)?\"([^\>]*)?\>/';
			$_G['setting']['output']['preg']['replace']['exx_guiderewrite1']='plugin_exx_guiderewrite::guiderewrite($matches[1],$matches[5],$matches[8],$matches[9])';
		}else{
			$_G['setting']['output']['preg']['search']['exx_guiderewrite1']='/<a([^\>]*)?href\=\"([^\>]*)?forum\.php\?mod\=guide(&(amp;)?view\=(\w+)(&(amp;)?page=(\d+))?)?\"([^\>]*)?\>/e';
			$_G['setting']['output']['preg']['replace']['exx_guiderewrite1']='plugin_exx_guiderewrite::guiderewrite(\'\1\',\'\5\',\'\8\',\'\9\')';
		}
		return '';
	}
	
	function guiderewrite() {
		global $_G;
		$exx_guiderewrite = $_G['cache']['plugin']['exx_guiderewrite'];
		list($ids,$view,$page,$extra) = func_get_args();
		$href =$view && $view!='index' ?(($page>1)? str_replace(array('{view}','{page}'), array($view,$page), dhtmlspecialchars($exx_guiderewrite['rurla'])):str_replace('{view}', $view, dhtmlspecialchars($exx_guiderewrite['rurl']))):dhtmlspecialchars($exx_guiderewrite['rurli']);
		return '<a '.(!empty($ids)?stripslashes($ids):'').' href="'.$href.'" '.(!empty($extra) ? stripslashes($extra) : '').'>';
	}
}
class mobileplugin_exx_guiderewrite extends plugin_exx_guiderewrite{
}