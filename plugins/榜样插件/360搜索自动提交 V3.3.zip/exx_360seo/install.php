<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/exx_360seo/discuz_plugin_exx_360seo.xml');
@unlink(DISCUZ_ROOT . './source/plugin/exx_360seo/discuz_plugin_exx_360seo_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/exx_360seo/discuz_plugin_exx_360seo_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/exx_360seo/discuz_plugin_exx_360seo_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/exx_360seo/discuz_plugin_exx_360seo_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/exx_360seo/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/exx_360seo/upgrade.php');