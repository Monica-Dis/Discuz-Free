<?php
/**
 * Created by bangyang.
 * User: QQ 2395841575
 * Date: 2016/7/01
 * updata:2018/05/09
 * Time: 14:13
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_exx_360seo {
	function global_header(){
		global $_G;
		$exx_360seo=$_G['cache']['plugin']['exx_360seo'];
		if(!$exx_360seo['off'])return;
		$section = empty($exx_360seo['mod']) ? array() : unserialize($exx_360seo['mod']);
		if(!is_array($section)) $section = array();
		$mods=array('forum','portal','group');
		if(!($section[0]=='all')){
			if(!(in_array(CURSCRIPT,$section))){
				return;
			}
		}elseif(!(in_array(CURSCRIPT,$mods))){
			return;
		}
		if(($exx_360seo['nr'] && CURSCRIPT=='forum' && !$_G['tid']) || ($_GET['mod']=='post' && $_GET['action']=='newthread' && CURSCRIPT=='forum') || ($_GET['mod']=='post' && $_GET['ac']=='reply' && CURSCRIPT=='forum') || ($_GET['mod']=='portalcp' && $_GET['ac']=='article' && CURSCRIPT=='portal') || ($_GET['mod']=='space' && $_GET['do']=='pm') || ($_GET['mod']=='space' && $_GET['do']=='notice')  || ($_GET['mod']=='space' && $_GET['do']=='friend') || $_GET['mod']=='spacecp' || (CURSCRIPT=='search' && $_GET['adv'] && $_GET['mod']) || $_GET['mod']=='stat'){
			return;
		}
		$hash=dhtmlspecialchars($exx_360seo['hash']);
		$js='<script>
		(function(){
		   var src = "https://jspassport.ssl.qhimg.com/11.0.1.js?'.$hash.'";
		   document.write(\'<script src="\' + src + \'" id="sozz"><\/script>\');
		})();
		</script>';
		return $js;
	}	
}

class mobileplugin_exx_360seo extends plugin_exx_360seo {
	function global_header_mobile(){
		return $this->global_header();
	}
}