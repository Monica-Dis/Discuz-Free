<?php
 /*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}
class plugin_exx_wycseo{
	
	function strtr_words($str){
		global $_G;
		$exx_wycseo = $_G['cache']['plugin']['exx_wycseo'];
		$words=array();
		loadcache('exx_wycseo');
		$cacedata=$_G['cache']['exx_wycseo'];
		if(!$cacedata){
			$cacedata=array();
			if($exx_wycseo['ck']){				
				$ciurl= dhtmlspecialchars($exx_wycseo['ciurl']);
				$content = file_get_contents($ciurl);//�ʿ�
				if(CHARSET!='gbk'){
				$content =diconv($content, 'GBK', CHARSET);}
				$content = str_replace( "\r", "",$content); //ȥ�����з�(�Ա����Linux����)
				$content = preg_split('/\n/', $content, -1, PREG_SPLIT_NO_EMPTY);//\n�ָ��ַ�
				foreach($content as $k=>$v){
					if($k!=0){
						$str_data = explode(dhtmlspecialchars($exx_wycseo['fenge']),$v);//�ؼ��ʷָ��
						$words+=array("$str_data[0]"=>"$str_data[1]");
					}
				}
				require_once libfile('function/cache');
				savecache('exx_wycseo', $words);
				$cacedata=$words;
			}
			if($exx_wycseo['fj']){
				$fjarr=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$exx_wycseo['fj']));
				foreach($fjarr as $fjk=>$fjv){
					$fjexplode=explode('=',$fjv);
					$fjdata[$fjexplode[0]]=dhtmlspecialchars($fjexplode[1]);
				}
				$cacedata=array_merge($cacedata,$fjdata);
			}
		}
		return strtr($str,$cacedata);
	}

	function isCrawler() { 
		$agent= strtolower($_SERVER['HTTP_USER_AGENT']); 
		if (!empty($agent)) { 
			$spiderSite= array( 
				'bot',
				'googlebot',
				'mediapartners-google',
				'feedfetcher-Google',
				'ia_archiver',
				'iaarchiver',
				'sqworm',
				'baiduspider',
				'Baiduspider-render/2.0',
				'Baiduspider-image',
				'Baiduspider/2.0',
				'Baiduspiderrender',
				'msnbot',
				'yodaobot',
				'yahoo! slurp;',
				'yahoo! slurp china;',
				'yahoo',
				'iaskspider',
				'sogou spider',
				'sogou web spider',
				'sogou push spider',
				'sogou orion spider',
				'sogou-test-spider',
				'sogou+head+spider',
				'sohu',
				'sohu-search',
				'Sosospider',
				'Sosoimagespider',
				'JikeSpider',
				'360spider',
				'haosouspider',
				'qihoobot',
				'tomato bot',
				'bingbot',
				'youdaobot',
				'yodaobot',
				'askjeeves/reoma',
				'manbot',
				'robozilla',
				'MJ12bot',
				'HuaweiSymantecSpider',
				'Scooter',
				'Infoseek',
				'ArchitextSpider',
				'Grabber',
				'Fast',
				'ArchitextSpider',
				'Gulliver',
				'Lycos',
				'Baiduspider-render',
				'YisouSpider',
				'Bytespider'
			); 
			foreach($spiderSite as $val) { 
				$str = strtolower($val); 
				if (strpos($agent, $str) !== false) { 
					return true; 
				} 
			} 
		} else { 
			return false; 
		} 
	}
}

class plugin_exx_wycseo_forum extends plugin_exx_wycseo{
	function viewthread_posttop_output() {
		global $_G,$postlist;
		$return=array();
		$exx_wycseo = $_G['cache']['plugin']['exx_wycseo'];
		if($exx_wycseo['off'] && !($this->isCrawler())){
			return $return;
		}
		$infid=in_array($_G['fid'],unserialize($exx_wycseo['bk'])) ? true : false;
		if(($_G['thread']['isgroup'] && !$exx_wycseo['qz']) || (!$_G['thread']['isgroup'] && !$infid)){
			return $return;
		}
		if($_G['forum_firstpid']){
			$msg=$postlist[$_G['forum_firstpid']]['message'];
			$postlist[$_G['forum_firstpid']]['message']=$this->strtr_words($msg);
		}
		return $return;
	}
}

class plugin_exx_wycseo_portal  extends plugin_exx_wycseo{
	function view_article_content_output(){
		global $_G,$content;
		$return=array();
		$exx_wycseo = $_G['cache']['plugin']['exx_wycseo'];
		if($exx_wycseo['off'] && !($this->isCrawler())){
			return $return;
		}
		if($exx_wycseo['portal'] && $_GET['aid']){
			$msg=$content['content'];
			$content['content']=$this->strtr_words($msg);
		}
		return $return;
	}
}

class mobileplugin_exx_wycseo_forum  extends plugin_exx_wycseo_forum{
}

class mobileplugin_exx_wycseo  extends plugin_exx_wycseo{
	function global_header_mobile() {
		global $_G,$content;
		$exx_wycseo = $_G['cache']['plugin']['exx_wycseo'];
		if(CURSCRIPT=='portal' && $_GET['aid'] && $exx_wycseo['portal']){
			if($exx_wycseo['off'] && !($this->isCrawler())){
				return $return;
			}
			$msg=$content['content'];
			$content['content']=$this->strtr_words($msg);
		}
		return '';
	}
}

class plugin_exx_wycseo_group  extends plugin_exx_wycseo_forum{
	
}
class mobileplugin_exx_wycseo_group  extends plugin_exx_wycseo_forum{
	
}