<?php
/**
 * Created by bangyang.
 * User: QQ 2395841575
 * Date: 2016/6/21
 * Time: 12:18
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if (!defined('CLOUDADDONS_WEBSITE_URL')) {
	require_once libfile('function/cloudaddons');
}
class plugin_exx_guide {
	function common(){
		global $_G;		
		$exx_guide=$_G['cache']['plugin']['exx_guide'];
		$bks=$exx_guide['bk']?$exx_guide['bk']:1;
		$bk=daddslashes($bks);
		$section = empty($exx_guide['yhz']) ? array() : unserialize($exx_guide['yhz']);
		if((empty($section[0]) || in_array($_G['groupid'],$section)) && !($_G['fid']==$bk) && $_G['uid']>0){
			$tiecount=DB::result_first("select count(1) from ".DB::table('forum_thread')." where fid=".$bk." AND authorid=".$_G['uid']);
			if($exx_guide['lj']==1){
				if($exx_guide['wjt'])$url='forum-'.$bk.'-1.html'; else $url='forum.php?mod=forumdisplay&fid='.$bk;
			}else{
				$url='forum.php?mod=post&action=newthread&fid='.$bk;
			}
			if(empty($tiecount) && ($_GET['mod']=="post" || $_GET['mod']=="viewthread" || $_GET['mod']=="forumdisplay")){
				showmessage(dhtmlspecialchars($exx_guide['tis']),$url);
			}
		}
	}
}
