<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_exx_picseo_forum{
	var $variable=array();
	function viewthread_posttop_output() {
		global $_G,$postlist;
		$exx_picseo = $_G['cache']['plugin']['exx_picseo'];
		$section = empty($exx_picseo['bk']) ? array() : unserialize($exx_picseo['bk']);
		$group = empty($exx_picseo['yhz']) ? array() : unserialize($exx_picseo['yhz']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section)) && !$_G['thread']['isgroup'] && $_G['tid'] || !(empty($group[0]) || in_array($_G['groupid'],$group)) || !$exx_picseo['off']){
			return array();
		}
		$this->variable['tid']=intval($_G['tid']);
		$this->variable['subject']=dhtmlspecialchars($_G['thread']['subject']);
		$this->variable['time']=dgmdate($_G['thread']['dateline'], 'Y-m-d H:i:s');
		if($postlist[$_G['forum_firstpid']]['tags']){
			foreach($postlist[$_G['forum_firstpid']]['tags'] as $tag){
				$tags.=$tag[1].',';
			}
			$tags=substr($tags, 0, -1);
		}
		$this->variable['tag']=$tags;
		foreach ($postlist as $key=>$value) {
			$message=$postlist[$key]['message'];
			$this->variable['pid']=intval($key);
			$this->variable['author']=dhtmlspecialchars($postlist[$key]['author']);
			foreach ($postlist[$key]['attachments'] as $keys=>$values) {
				$postlist[$key]['attachments'][$keys]['imgalt'] = $this->setalttxt();
			}
			$return = preg_replace_callback('/<img[^>]+/', array($this,'combination_seo'), $message);
			$postlist[$key]['message'] = $return;
			
		}
		return array();
	}
	
	function combination_seo($data){
		global $_G;
		$exx_picseo = $_G['cache']['plugin']['exx_picseo'];	
		$data[0] = preg_replace('|([\'"])[/ ]*$|', '\1 /', $data[0]);
        $data[0] = preg_replace('/\s*=\s*/', '=', substr($data[0], 0, strlen($data[0]) - 2));
		$splits = preg_split('/(\w+=)/', $data[0], - 1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
		$alttxt=$this->setalttxt();
		if (in_array('alt=', $splits)) {
			$index = array_search('alt=', $splits);
            $splits[$index+1] = '"'.$alttxt.'" ';
		}else{
            array_push($splits,' alt="'.$alttxt.'"');
        }
		if($exx_picseo['tt']){
			if (in_array('title=', $splits)) {
				$index = array_search('title=', $splits);
				$splits[$index+1] = '"'.$alttxt.'" ';
			}else{
				 array_push($splits,' title="'.$alttxt.'"');
			}
		}
		return implode('', $splits) . ' /';
	}
	function setalttxt(){
		global $_G;
		$exx_picseo = $_G['cache']['plugin']['exx_picseo'];
		$num=mt_rand(0,10000);
		if(CURSCRIPT=='forum'){
			$result=dhtmlspecialchars($exx_picseo['gz']);
			$subjct=$this->variable['subject'];
			$tids=$this->variable['tid'];
			$pids=$this->variable['pid'];
			$author=$this->variable['author'];
			$result=str_ireplace("[tid]",$tids,$result);
			$result=str_ireplace("[tag]",$this->variable['tag'],$result);
			$result=str_ireplace("[pid]",$pids,$result);
			$result=str_ireplace("[aut]",$author,$result);
			$result=str_ireplace("[time]",$this->variable['time'],$result);
		}elseif(CURSCRIPT=='portal'){
			$result=dhtmlspecialchars($exx_picseo['progz']);
			$subjct=$this->protitle['subject'];
			$author=$this->protitle['author'];
			$from=$this->protitle['from'];
			$result=str_ireplace("[aut]",$author,$result);
			$result=str_ireplace("[from]",$from,$result);
			$result=str_ireplace("[time]",$this->protitle['time'],$result);
			$result=str_ireplace("[aid]",intval($_GET['aid']),$result);
		}
		$result=str_ireplace(array('[title]','[num]','[page]'),array($subjct,$num,intval($_GET['page'])),$result);
		return $result;
	}
}

class plugin_exx_picseo_group  extends plugin_exx_picseo_forum{
	
}

class mobileplugin_exx_picseo_group  extends plugin_exx_picseo_forum{
	
}


class mobileplugin_exx_picseo_forum  extends plugin_exx_picseo_forum{
	function viewthread_posttop_mobile_output(){
		global $_G,$postlist;
		$exx_picseo = $_G['cache']['plugin']['exx_picseo'];
		if(!$exx_picseo['wap']){
			return array();
		}
		return $this->viewthread_posttop_output();
	}
}

class plugin_exx_picseo_portal  extends plugin_exx_picseo_forum{
	function view_article_content_output(){
		global $_G,$article,$content;
		$exx_picseo = $_G['cache']['plugin']['exx_picseo'];	
		if(!$exx_picseo['off'] || !$exx_picseo['por']){
			return '';
		}
		if(!$article){
			$article = C::t('portal_article_title')->fetch(intval($_GET['aid']));
		}
		
		if(!$content){
			$page = intval($_GET['page']);
			if(!$page || $page<1) $page = 1;
			$content = C::t('portal_article_content')->fetch_by_aid_page(intval($_GET['aid']), $page);
		}
		$this->protitle['subject']=$article['title'];
		$this->protitle['author']=$article['author'];
		$this->protitle['from']=$article['from'];
		$this->protitle['time']=$article['dateline'];
		$content['content']= preg_replace_callback('/<img[^>]+/', array($this,'combination_seo'), $content['content']);
		return '';
	}
}

class mobileplugin_exx_picseo_portal  extends plugin_exx_picseo_portal{
}