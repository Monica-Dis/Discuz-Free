<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache("plugin");
$exx_typere = $_G['cache']['plugin']['exx_typere'];

$rurl=formatstr($exx_typere['rurl']);
$rurla=formatstr($exx_typere['rurla']);

if(!$rurl || !$rurla){
	cpmsg(lang('plugin/exx_typere', 'f07'), 'action=plugins&operation=config&do='.$plugin["pluginid"], 'error');
}
showtips(lang('plugin/exx_typere', 'f06'));
$strtmp= '<br><h1>'.lang('plugin/exx_typere', 'f01').'</h1>
<pre class="colorbox">

RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^(.*)/'.$rurl.'$ $1/forum.php?mod=forumdisplay&fid=$2&filter=typeid&typeid=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^(.*)/'.$rurla.'$ $1/forum.php?mod=forumdisplay&fid=$2&typeid=$3&filter=typeid&typeid=$3&page=$4&%1

</pre>

<h1>'.lang('plugin/exx_typere', 'f02').'</h1>
<pre class="colorbox">

RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$rurl.'$ forum.php?mod=forumdisplay&fid=$1&filter=typeid&typeid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$rurla.'$ forum.php?mod=forumdisplay&fid=$1&typeid=$2&filter=typeid&typeid=$2&page=$3&%1
</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">

rewrite ^([^\.]*)/'.$rurl.'$ $1/forum.php?mod=forumdisplay&fid=$2&filter=typeid&typeid=$3 last;
rewrite ^([^\.]*)/'.$rurla.'$ $1/forum.php?mod=forumdisplay&fid=$2&typeid=$3&filter=typeid&typeid=$3&page=$4 last;
</pre>

<h1>'.lang('plugin/exx_typere', 'f03').'</h1>
<pre class="colorbox">

RewriteRule ^(.*)/'.$rurl.'(\?(.*))*$ $1/forum.php\?mod=forumdisplay&fid=$2&filter=typeid&typeid=$3
RewriteRule ^(.*)/'.$rurla.'(\?(.*))*$ $1/forum.php\?mod=forumdisplay&fid=$2&typeid=$3&filter=typeid&typeid=$3&page=$4

</pre>

<h1>'.lang('plugin/exx_typere', 'f05').'</h1>
<pre class="colorbox">

&lt;rule name="exx_typere"&gt;
	&lt;match url="^(.*/)*'.toiisstrs($exx_typere['rurl']).'\?*(.*)$" /&gt;
	&lt;action type="Rewrite" url="{R:1}/forum.php\?mod=forumdisplay&amp;amp;fid={R:2}&amp;amp;filter=typeid&amp;amp;typeid={R:3}" /&gt;
&lt;/rule&gt;


&lt;rule name="exx_typere_page"&gt;
	&lt;match url="^(.*/)*'.toiisstrs($exx_typere['rurla']).'\?*(.*)$" /&gt;
	&lt;action type="Rewrite" url="{R:1}/forum.php\?mod=forumdisplay&amp;amp;fid={R:2}&amp;amp;typeid={R:3}&amp;amp;filter=typeid&amp;amp;typeid={R:3}&amp;amp;page={R:4}" /&gt;
&lt;/rule&gt;

</pre>';
echo $strtmp;

function formatstr($str){
	return str_replace(array(".","{fid}","{typeid}","{page}"),array("\\.","(\w+)","([0-9]+)","([0-9]+)"),dhtmlspecialchars($str));
}
function toiisstrs($str){
	return str_replace(array("{fid}","{typeid}","{page}"),array("(\w+)","([0-9]+)","([0-9]+)"),dhtmlspecialchars($str));
}