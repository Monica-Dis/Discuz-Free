<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
 if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_exx_typere{
	function global_header(){
		global $_G;
		$exx_typere = $_G['cache']['plugin']['exx_typere'];
		if(!$exx_typere['off'] || ($exx_typere['yk'] && $_G['uid'])){
			return '';
		}
		if(!$_G['setting']['rewritestatus']){
			$_G['setting']['rewritestatus']=true;
		}
		if ($_G['setting']['version'] == 'X3.3' || $_G['setting']['version'] == 'X3.4' || $_G['setting']['version'] == 'X3.5' || $_G['setting']['version'] == 'F1.0' || $_G['setting']['version'] == 'L1.0') {
			$_G['setting']['output']['preg']['search']['exx_typere1']='/<a([^\>]*)?href\=\"([^\>]*)?forum\.php\?mod\=forumdisplay&(amp;)?fid\=(\d+)(&(amp;)filter=typeid)?&(amp;)?typeid\=(\d+)(&(amp;)?(\w+)\=(\w+)&(amp;)?(\w+)\=(\w+))?(&(amp;)?page\=(\d+))?\"([^\>]*)?\>/';
			$_G['setting']['output']['preg']['replace']['exx_typere1']='plugin_exx_typere::typererewrite(1,$matches[1],$matches[4],$matches[8],$matches[18],$matches[19])';
			if($exx_typere['ty']){
				$_G['setting']['output']['preg']['search']['exx_typere2']='/<a([^\>]*)?href\=\"([^\>]*)?forum\.php\?mod\=viewthread&(amp;)?tid\=(\d+)&amp;extra=page%3D(\d+)%26filter%3Dtypeid%26typeid%3D(\d+)"([^\>]*)?\>/';
				$_G['setting']['output']['preg']['replace']['exx_typere2']='plugin_exx_typere::typererewrite(2,$matches[1],$matches[4],\'\',\'\',$matches[7])';
			}
		}else{
			$_G['setting']['output']['preg']['search']['exx_typere1']='/<a([^\>]*)?href\=\"([^\>]*)?forum\.php\?mod\=forumdisplay&(amp;)?fid\=(\d+)(&(amp;)filter=typeid)?&(amp;)?typeid\=(\d+)(&(amp;)?(\w+)\=(\w+)&(amp;)?(\w+)\=(\w+))?(&(amp;)?page\=(\d+))?\"([^\>]*)?\>/e';
			$_G['setting']['output']['preg']['replace']['exx_typere1']='plugin_exx_typere::typererewrite(\'1\',\'\1\',\'\4\',\'\8\',\'\18\',\'\19\')';
			if($exx_typere['ty']){
				$_G['setting']['output']['preg']['search']['exx_typere2']='/<a([^\>]*)?href\=\"([^\>]*)?forum\.php\?mod\=viewthread&(amp;)?tid\=(\d+)&amp;extra=page%3D(\d+)%26filter%3Dtypeid%26typeid%3D(\d+)"([^\>]*)?\>/e';
				$_G['setting']['output']['preg']['replace']['exx_typere2']='plugin_exx_typere::typererewrite(\'2\',\'\1\',\'\4\',\'\',\'\',\'\7\')';
			}
		}
		return '';
	}
	
	function typererewrite($type) {
		global $_G;
		$exx_typere = $_G['cache']['plugin']['exx_typere'];
		list(,$ids,$fid,$typeid,$page,$extra) = func_get_args();
		if($type==1){
			$rurl=$page>1?dhtmlspecialchars($exx_typere['rurla']):dhtmlspecialchars($exx_typere['rurl']);
			$forumkey=$_G['setting']['forumkeys'][$fid]?$_G['setting']['forumkeys'][$fid]:$fid;
			$href = str_replace(array('{fid}','{typeid}','{page}'), array($forumkey,$typeid,$page), $rurl);
		}elseif($type==2){
			if(!$_G['setting']['rewritestatus']){
				$_G['setting']['rewritestatus']=true;
			}
			$href =rewriteoutput('forum_viewthread', 1, '', $fid, 1);
		}
		return '<a'.(!empty($ids)?stripslashes($ids):'').'href="'.$href.'" '.(!empty($extra) ? stripslashes($extra) : '').'>';
	}
} 
class mobileplugin_exx_typere extends plugin_exx_typere{
}