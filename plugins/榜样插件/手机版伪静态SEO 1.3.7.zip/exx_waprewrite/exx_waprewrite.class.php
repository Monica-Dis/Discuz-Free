<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/7/29
 * Time: 19:15
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class mobileplugin_exx_waprewrite{
	function common(){
	}	
}

class helper_mobile {
	public static function mobileoutput() {
		global $_G;
		$exx_waprewrite = $_G['cache']['plugin']['exx_waprewrite'];
		if(!$exx_waprewrite['on']){
		    exit();
		}
		if(!defined('TPL_DEFAULT')) {
			$content = ob_get_contents();
			if($exx_waprewrite['guize']){
				$guize=helper_mobile::waprewite_replacessa($exx_waprewrite['guize']);
				$guize=explode(',',$guize);
				$content=str_replace($guize,'',$content);
			}
			$content=str_replace(array('&fromguid=hot','&amp;fromguid=hot','&mobile=2','&amp;mobile=2'),'',$content);
			$content = output_replace($content);
			if($_G['setting']['domain']['app']['mobile']){
				$content=str_replace($_G['setting']['domain']['app']['default'],$_G['setting']['domain']['app']['mobile'],$content);
			}
			ob_end_clean();
			ob_start();
			$content = '<?xml version="1.0" encoding="utf-8"?>'.$content;
			if('utf-8' != CHARSET) {
				$content = diconv($content, CHARSET, 'utf-8');
			}
			if(IN_MOBILE === '3') {
				header("Content-type: text/vnd.wap.wml; charset=utf-8");
			} else {
				@header('Content-Type: text/html; charset=utf-8');
			}
			echo $content;
			exit();

		} elseif (defined('TPL_DEFAULT') && !$_G['cookie']['dismobilemessage'] && $_G['mobile']) {
			ob_end_clean();
			ob_start();
			$_G['forcemobilemessage'] = true;
			$query_sting_tmp = str_replace(array('&mobile=yes', 'mobile=yes'), array(''), $_SERVER['QUERY_STRING']);
			$_G['setting']['mobile']['pageurl'] = $_G['siteurl'].substr($_G['PHP_SELF'], 1).($query_sting_tmp ? '?'.$query_sting_tmp.'&mobile=no' : '?mobile=no' );
			unset($query_sting_tmp);
			dsetcookie('dismobilemessage', '1', 3600);
			showmessage('not_in_mobile');
			exit();
		}
	}
	
	static function waprewite_replacessa($content){
		$tags = array(
			"'<iframe[^>]*?>.*?</iframe>'is",
			"'<frame[^>]*?>.*?</frame>'is",
			"'<script[^>]*?>.*?</script>'is",
			"'<head[^>]*?>.*?</head>'is",
			"'<title[^>]*?>.*?</title>'is",
			"'<meta[^>]*?>'is",
			"'<link[^>]*?>'is",
			"'<html[^>]*?>'is"
		);
		return preg_replace($tags, "", $content);
	}
}