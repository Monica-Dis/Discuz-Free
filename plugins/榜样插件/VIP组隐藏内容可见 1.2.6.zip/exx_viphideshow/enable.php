<?php
/**
 * Copyright 2001-2099 DisM!(dism.taobao.com)
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (! defined ('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit ('Access Denied');
}

$addonid = 'exx_viphideshow.plugin';
$array = cloudaddons_getmd5($addonid);
if(cloudaddons_open('&mod=app&ac=validator&ver=2&addonid='.$addonid.($array !== false ? '&rid='.$array['RevisionID'].'&sn='.$array['SN'].'&rd='.$array['RevisionDateline'] : '')) === '0') {
	$val = $operation == 'enable' ? 0 : 1;
	C::t('common_plugin')->update($_GET['pluginid'], array('available' => '1'));
	cpmsg('plugins_'.$operation.'_succeed', 'action=plugins'.(!empty($_GET['system']) ? '&system=1' : ''), 'succeed');
}