<?php
 
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}


class plugin_exx_viphideshow {
	 function discuzcode($param) {
		global $_G;
		$var=$_G['cache']['plugin']['exx_viphideshow'];	
		$ingroup=in_array($_G['groupid'],unserialize($var['group'])) ? 1 : 0;
		$infid=in_array($_G['fid'],unserialize($var['bk'])) ? 1 : 0;
		if(!$ingroup || !$infid || !$var['off']){
			return;
		}
		if ($param['caller'] == 'discuzcode' ) {
			$_G['discuzcodemessage'] = preg_replace_callback('/\s?\[hide(.*?)\](.*?)\[\/hide\]/is', 'exx_hideshow', $_G['discuzcodemessage']);
		}
	}
	
}

function exx_hideshow($m){
	global $_G;
	$var=$_G['cache']['plugin']['exx_viphideshow'];	
	$lowerurl = strtolower($m[2]);
	$style=$_G['mobile']?'<style>.showhide{margin:5px auto; padding:10px; border:1px dashed #FF9A9A}.showhide h4{ margin-bottom:5px; font-size:12px;text-align:center; color:#FF9A9A}</style>':'';
	return $style.'<div class="showhide"><h4>'.dhtmlspecialchars($var['title']).'</h4>'.$m[2].'</div>';
}

class mobileplugin_exx_viphideshow  extends plugin_exx_viphideshow{
}