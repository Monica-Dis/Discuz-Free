<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (! defined ('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit ('Access Denied');
}

  $url=$_G['siteurl'].'plugin.php?id=exx_yiqing';
  $src = dhtmlspecialchars('http://qr.topscan.com/api.php?&bg=ffffff&text='.urlencode($url));
  showtableheader('url');
  echo '<tr class="hover"><td>'.$url.'</td></tr>';
  showtableheader('Qrcode');
  echo '<tr class="hover"><td><img src="'.$src.'" width="250" /></td></tr>';
  showtablefooter();