<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
header("Content-Type: text/html;charset=utf-8");
global $_G;
$var = $_G['cache']['plugin']['exx_yiqing'];
$title=dhtmlspecialchars($var['title']);
$var['provincial']=dhtmlspecialchars($var['provincial']);
$var['city']=dhtmlspecialchars($var['city']);
$share=array(
	'sharetitle'=>dhtmlspecialchars($var['sharetitle']),
	'ms'=>dhtmlspecialchars($var['ms']),
	'ico'=>(strstr($var['ico'], "http")!== false)?$var['ico']:$_G['siteurl'].$var['ico']
);
if(CHARSET=='gbk'){
	$title=diconv($title,'gbk','utf-8');
	$share['sharetitle']=diconv($share['sharetitle'],'gbk','utf-8');
	$share['ms']=diconv($share['ms'],'gbk','utf-8');
	$var['provincial']=diconv($var['provincial'],'gbk','utf-8');
	$var['city']=diconv($var['city'],'gbk','utf-8');
}
if(strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX")!== false){
	$ismagapp=1;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
	$iswx=1;
}
include template('exx_yiqing:index');