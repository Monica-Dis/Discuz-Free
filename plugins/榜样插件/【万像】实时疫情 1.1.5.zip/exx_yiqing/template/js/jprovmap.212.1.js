"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/******/
(function (modules) {
  // webpackBootstrap

  /******/
  // The module cache

  /******/
  var installedModules = {};
  /******/

  /******/
  // The require function

  /******/

  function __webpack_require__(moduleId) {
    /******/

    /******/
    // Check if module is in cache

    /******/
    if (installedModules[moduleId]) {
      /******/
      return installedModules[moduleId].exports;
      /******/
    }
    /******/
    // Create a new module (and put it into the cache)

    /******/


    var module = installedModules[moduleId] = {
      /******/
      i: moduleId,

      /******/
      l: false,

      /******/
      exports: {}
      /******/

    };
    /******/

    /******/
    // Execute the module function

    /******/

    modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    /******/

    /******/
    // Flag the module as loaded

    /******/

    module.l = true;
    /******/

    /******/
    // Return the exports of the module

    /******/

    return module.exports;
    /******/
  }
  /******/

  /******/

  /******/
  // expose the modules object (__webpack_modules__)

  /******/


  __webpack_require__.m = modules;
  /******/

  /******/
  // expose the module cache

  /******/

  __webpack_require__.c = installedModules;
  /******/

  /******/
  // define getter function for harmony exports

  /******/

  __webpack_require__.d = function (exports, name, getter) {
    /******/
    if (!__webpack_require__.o(exports, name)) {
      /******/
      Object.defineProperty(exports, name, {
        /******/
        configurable: false,

        /******/
        enumerable: true,

        /******/
        get: getter
        /******/

      });
      /******/
    }
    /******/

  };
  /******/

  /******/
  // getDefaultExport function for compatibility with non-harmony modules

  /******/


  __webpack_require__.n = function (module) {
    /******/
    var getter = module && module.__esModule ?
    /******/
    function getDefault() {
      return module['default'];
    } :
    /******/
    function getModuleExports() {
      return module;
    };
    /******/

    __webpack_require__.d(getter, 'a', getter);
    /******/


    return getter;
    /******/
  };
  /******/

  /******/
  // Object.prototype.hasOwnProperty.call

  /******/


  __webpack_require__.o = function (object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  /******/

  /******/
  // __webpack_public_path__

  /******/


  __webpack_require__.p = "";
  /******/

  /******/
  // Load entry module and return exports

  /******/

  return __webpack_require__(__webpack_require__.s = 0);
  /******/
})(
/************************************************************************/

/******/
[
/* 0 */

/***/
function (module, __webpack_exports__, __webpack_require__) {
  "use strict";

  Object.defineProperty(__webpack_exports__, "__esModule", {
    value: true
  });
  /* harmony import */

  var __WEBPACK_IMPORTED_MODULE_0__main__ = __webpack_require__(1);
  /* harmony import */


  var __WEBPACK_IMPORTED_MODULE_1__component_parseURL__ = __webpack_require__(6);

  var Enter = function Enter(obj, divID, provNs) {
    _classCallCheck(this, Enter);

    // let firstParam=new ParseURL().params.prov;
    console.log(11111);
    var provName = provNs;

    var getDataByName = function getDataByName(data, name) {
      if (data && _typeof(data) == 'object') {
        for (var key in data) {
          if (data[key].name == name) {
            return data[key];
          }
        }
      }
    };

    var special = obj.special;

    var drawOver = obj.drawOver || function () {};

    var colors = ['#9C0A0D', '#C91014', '#E64B47', '#FE8664', '#FFB880', '#FFD2A0', '#FFEFD7', '#DFDFDF'];

    var getProveData = function getProveData(data) {
      console.log(1, data);
      var cnData = getDataByName(data.areaTree, "中国");
      console.log(2, cnData);
      var areaData = getDataByName(cnData.children, provName);
      console.log(3, areaData);
      var div = document.getElementById(divID); // div.style.height="50%";

      var obj = {
        areaData: areaData,
        div: div,
        colors: colors
      };
      console.log(22222);
      new __WEBPACK_IMPORTED_MODULE_0__main__["a"
      /* default */
      ](obj, special, drawOver, provName);
    };

    getProveData(obj.data);
  };

  window.Enter = Enter;
  /***/
},
/* 1 */

/***/
function (module, __webpack_exports__, __webpack_require__) {
  "use strict";
  /* harmony import */

  var __WEBPACK_IMPORTED_MODULE_0__provNameMap__ = __webpack_require__(2);
  /* harmony import */


  var __WEBPACK_IMPORTED_MODULE_1__offsetLabel__ = __webpack_require__(3);
  /* harmony import */


  var __WEBPACK_IMPORTED_MODULE_2__provCenter__ = __webpack_require__(5);

  var Main = function Main(obj, special, drawOver, provName) {
    _classCallCheck(this, Main);

    var nameMap = new __WEBPACK_IMPORTED_MODULE_0__provNameMap__["a"
    /* default */
    ]();
    var data = obj.areaData;
    var colors = obj.colors;
    var defaultIndex = 0;
    console.log("provName", provName);
    data.znName = nameMap.getNameData(data.name).zn;
    console.log('jared____znname', data); //
	var formhash=$('.formhash').val();
    var path = "plugin.php?id=exx_yiqing:ajax&formhash="+formhash+"&area=";
    var shNs = new __WEBPACK_IMPORTED_MODULE_2__provCenter__["a"
    /* default */
    ]().getCity(provName);
    console.log(shNs);
    var myChart = echarts.init(obj.div);
    var cssAry = [];
    var eJData = data.children;

    for (var i = 0; i < eJData.length; i++) {
      var confirm = eJData[i].total.confirm;
      var suspect = eJData[i].total.suspect;
      var dead = eJData[i].total.dead;
      var heal = eJData[i].total.heal; // console.log(confirm);

      var _obj = {};
      var itemStyle = {
        normal: {
          color: "#e4e8f3"
        }
      };
      _obj.name = eJData[i].name;
      _obj.value = confirm; //
      // if(i==5){
      //     obj.selected=true;
      // }

      if (_obj.name == shNs) {
        defaultIndex = i;
        _obj.selected = true; // console.log('shenghuoi',obj);
      } //


      var label = {
        show: true,
        textStyle: {
          color: '#000000'
        }
      };
      var color = "#e4e8f3";

      if (confirm) {
        if (confirm >= 10000) {
          color = colors[0];
          label.textStyle.color = '#ffffff';
        } else if (confirm >= 1000) {
          color = colors[1];
          label.textStyle.color = '#ffffff';
        } else if (confirm >= 500) {
          color = colors[2];
        } else if (confirm >= 100) {
          color = colors[3];
        } else if (confirm >= 50) {
          color = colors[4];
        } else if (confirm >= 10) {
          color = colors[5];
        } else if (confirm >= 1) {
          color = colors[6];
        } else {
          color = colors[7];
        }
      }

      itemStyle.normal.color = color;
      _obj.itemStyle = itemStyle;
      _obj.label = label;
      cssAry.push(_obj);
    } //


    var option;
    myChart.showLoading('default', {
      text: 'loading',
      color: '#D8D8D8',
      textColor: '#000',
      maskColor: 'rgba(255, 255, 255, 0.8)',
      zlevel: 0
    }); //

    var matchNams = function matchNams(geoJson) {
      var ary = geoJson.features;
      var str;
      var matchStr;
      var curItem;
      var offset = new __WEBPACK_IMPORTED_MODULE_1__offsetLabel__["a"
      /* default */
      ](provName);

      for (var _i = 0; _i < ary.length; _i++) {
        matchStr = '';
        curItem = ary[_i].properties;
        str = ary[_i].properties.name; // str=str.replace('市',"");
        // str=str.replace('地区',"");
        // str=str.replace('自治州',"");

        ary[_i].properties.name = str; // console.log(str);
        // console.log(str);

        if (str == "三沙市") {
          ary.splice(_i, 1);
          console.log('展示海南三沙市小地图');
          special();
          continue;
        }

        for (var j = 0; j < eJData.length; j++) {
          matchStr = eJData[j].name;

          if (str == "齐齐哈尔市") {
            str = "齐齐哈尔";
          } else if (str == "哈尔滨") {
            str = "哈尔滨";
          } else {
            matchStr = matchStr.slice(0, 2);
          }

          if (matchStr == "地区") break;

          if (str.match(matchStr)) {
            ary[_i].properties.name = eJData[j].name;
            break;
          }
        }

        offset.reset(curItem);
      } // console.log(geoJson);

    }; //


    var drawMap = function drawMap(geoJson) {
      matchNams(geoJson);
      myChart.hideLoading();
      echarts.registerMap(data.znName, geoJson);
      console.log("data.znName:", data.znName);
      option = {
        tooltip: {
          show: true,
          borderRadius: 5,
          backgroundColor: "rgba(0,0,0,0.75)",
          backgroundRadio: 10,
          padding: [6, 12, 6, 12],
          textStyle: {
            fontSize: 10
          },
          trigger: 'item',
          triggerOn: 'click',
          formatter: function formatter(params) {
            var res = params.name;
            var myseries = option.series;

            for (var _i2 = 0; _i2 < myseries.length; _i2++) {
              for (var k = 0; k < myseries[_i2].data.length; k++) {
                if (myseries[_i2].data[k].name == params.name) {
                  res += '：' + myseries[_i2].data[k].value + "确诊";
                }
              }
            }

            return res;
          }
        },
        series: [{
          selectedMode: "single",
          name: '1',
          type: 'map',
          map: data.znName,
          animation: true,
          visualMap: [{
            // 第二个 visualMap 组件
            type: 'piecewise' // 定义为分段型 visualMap

          }],
          left: 0,
          right: 0,
          top: 0,
          bottom: 0,
          // showLegendSymbol:true,
          layoutCenter: ["50%", "50%"],
          //设置后left/right/top/bottom等属性无效
          layoutSize: "100%",
          itemStyle: {
            normal: {
              areaColor: "#e4e8f3",
              color: "#000000",
              borderWidth: 0.5,
              borderColor: "rgba(96,96,96,0.7)"
            },
            emphasis: {
              areaColor: "#FFE766",
              borderWidth: 0.5,
              borderColor: "rgba(96,96,96,0.7)",
              label: {
                show: true,
                textStyle: {
                  color: '#000000',
                  fontSize: 7
                }
              }
            }
          },
          label: {
            show: true,
            textStyle: {
              color: '#000000',
              fontSize: 7
            }
          },
          data: cssAry
        }]
      };
      myChart.setOption(option); // myChart.on('click',(e)=>{
      //     console.log(e,e.name);
      // });

      setTimeout(function () {
        // console.log('ok1');
        console.log(myChart);
        myChart.dispatchAction({
          type: 'showTip',
          seriesIndex: 0,
          dataIndex: defaultIndex // selected:true

        });
        drawOver();
      }, 100);
    };

    if (option && _typeof(option) === "object") {
      myChart.setOption(option, true);
    } //


    var loadProvGeo = function loadProvGeo(ns) {
      var url = path + ns;
      console.log(url); // $.get(url, function (geoJson) {
      //     console.log('loaded json:',geoJson);
      //     drawMap(geoJson);
      // });

      $.ajax({
        url: url,
        dataType: 'json',
        scriptCharset: 'UTF-8',
        error: function error(err) {},
        success: function success(res) {
          console.log('geo', res);
          drawMap(res);
        }
      });
    };

    loadProvGeo(data.znName);
  };
  /* harmony export (immutable) */


  __webpack_exports__["a"] = Main;
  /***/
},
/* 2 */

/***/
function (module, __webpack_exports__, __webpack_require__) {
  "use strict";

  var ProvNameMap = function ProvNameMap() {
    _classCallCheck(this, ProvNameMap);

    var ary = [{
      cn: "安徽",
      zn: "anhui"
    }, {
      cn: "澳门",
      zn: "aomen"
    }, {
      cn: "北京",
      zn: "beijing"
    }, {
      cn: "重庆",
      zn: "chongqing"
    }, {
      cn: "福建",
      zn: "fujian"
    }, {
      cn: "甘肃",
      zn: "gansu"
    }, {
      cn: "广东",
      zn: "guangdong"
    }, {
      cn: "广西",
      zn: "guangxi"
    }, {
      cn: "贵州",
      zn: "guizhou"
    }, {
      cn: "海南",
      zn: "hainan"
    }, {
      cn: "河北",
      zn: "hebei"
    }, {
      cn: "黑龙江",
      zn: "heilongjiang"
    }, {
      cn: "河南",
      zn: "henan"
    }, {
      cn: "湖北",
      zn: "hubei"
    }, {
      cn: "湖南",
      zn: "hunan"
    }, {
      cn: "江苏",
      zn: "jiangsu"
    }, {
      cn: "江西",
      zn: "jiangxi"
    }, {
      cn: "吉林",
      zn: "jilin"
    }, {
      cn: "辽宁",
      zn: "liaoning"
    }, {
      cn: "内蒙古",
      zn: "neimenggu"
    }, {
      cn: "宁夏",
      zn: "ningxia"
    }, {
      cn: "青海",
      zn: "qinghai"
    }, {
      cn: "山东",
      zn: "shandong"
    }, {
      cn: "上海",
      zn: "shanghai"
    }, {
      cn: "山西",
      zn: "shanxi"
    }, {
      cn: "陕西",
      zn: "shanxi1"
    }, {
      cn: "四川",
      zn: "sichuan"
    }, {
      cn: "台湾",
      zn: "taiwan"
    }, {
      cn: "香港",
      zn: "xianggang"
    }, {
      cn: "新疆",
      zn: "xinjiang"
    }, {
      cn: "西藏",
      zn: "xizang"
    }, {
      cn: "云南",
      zn: "yunnan"
    }, {
      cn: "浙江",
      zn: "zhejiang"
    }, {
      cn: "天津",
      zn: "tianjin"
    }];

    this.getNameData = function (ns) {
      for (var i = 0; i < ary.length; i++) {
        for (var key in ary[i]) {
          if (ns == ary[i][key]) {
            return ary[i];
          }
        }
      }
    };
  };
  /* harmony export (immutable) */


  __webpack_exports__["a"] = ProvNameMap;
  /***/
},
/* 3 */

/***/
function (module, __webpack_exports__, __webpack_require__) {
  "use strict";
  /* harmony import */

  var __WEBPACK_IMPORTED_MODULE_0__data__ = __webpack_require__(4);
  /* harmony import */


  var __WEBPACK_IMPORTED_MODULE_0__data___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__data__);

  var OffestLabel = function OffestLabel(provName) {
    _classCallCheck(this, OffestLabel);

    // console.log("offset:",provName);
    var data = __WEBPACK_IMPORTED_MODULE_0__data___default.a.offset[provName];

    this.reset = function (item) {
      if (!data) return; // console.log(item);

      if (data[item.name] && item.cp) {
        item.cp[0] += data[item.name][0];
        item.cp[1] += data[item.name][1];
      } //latitude: 23.7743
      //longitude: 121.381


      if (data[item.name] && item.longitude) {
        // console.log(item);
        item.latitude += data[item.name][0];
        item.longitude += data[item.name][1];
      }
    };
  };
  /* harmony export (immutable) */


  __webpack_exports__["a"] = OffestLabel;
  /***/
},
/* 4 */

/***/
function (module, exports) {
  var _;

  module.exports = {
    offset: {
      "湖北": {
        "黄冈": [0.5, 0.2],
        "黄石": [0, -0.23],
        "咸宁": [0, -0.2],
        "荆州": [0.5, -0.4],
        "潜江": [-0.1, -0.1],
        "仙桃": [-0.1, -0.1],
        "孝感": [-0.1, 0],
        "荆门": [0.3, 0],
        "神农架": [-0.2, -0.1],
        "十堰": [-0.2, -0.3]
      },
      "新疆": {
        "和田地区": [0.3, -0.6],
        "喀什地区": [0.5, -2],
        "图木舒克市": [0, -0.8],
        "巴音郭楞蒙古自治州": [1, -2],
        "吐鲁番": [0.5, -0.5],
        "昌吉州": [2.5, 0],
        "乌鲁木齐": [0, -0.5],
        "塔城地区": [2, 0],
        "阿勒泰地区": [1, -1.5],
        "双河市": [0, 1],
        "伊犁州": [0.5, -0.8],
        "可克达拉市": [0.3, 0.3]
      },
      "天津": {
        "东丽区": [0.1, 0.03],
        "西青区": [0, 0],
        "河西区": [0, -0.03],
        "河北区": [0.02, 0.02],
        "河东区": [0.1, 0],
        "南开区": [-0.02, -0.02],
        "和平区": [-0.03, 0]
      },
      "西藏": {
        "日喀则市": [-1, 0],
        "阿里地区": [1, 0],
        "那曲地区": [-2, 0.5],
        "拉萨市": [0, 0.3]
      },
      "宁夏": {
        "石嘴山": [0.1, 0],
        "吴忠": [0.5, -0.7],
        "中卫": [0.4, -0.7],
        "固原": [0, 0],
        "银川": [0, 0]
      },
      "江西": {
        "九江": [-0.2, -0.1],
        "上饶": [0, 0.1],
        "景德镇": [0, 0],
        "南昌": [0, 0],
        "宜春": [0.1, 0.4],
        "新余": [0, 0],
        "抚州": [0.1, -0.2],
        "萍乡": [0, 0],
        "吉安": [0, -0.1],
        "赣州": [0.1, -0.1]
      },
      "陕西": {
        "铜川": [0.1, 0.3],
        "渭南": [0.3, 0.2],
        "西安": [-0.1, -0.2],
        "咸阳": [-0.2, 0.3],
        "商洛": [0, -0.2],
        "汉中": [0, 0],
        "宝鸡": [0, 0],
        "安康": [0, 0],
        "榆林": [0, 0],
        "延安": [0, 0]
      },
      "海南": {
        "三亚": [-0.2, 0.1],
        "五指山市": [0, 0.12],
        "海口": [0.1, -0.2],
        "万宁": [-0.1, 0],
        "儋州市": [-0.2, 0],
        "琼海": [0, 0.02],
        "澄迈县": [0.06, 0],
        "屯昌县": [-0.1, -0.1],
        "临高县": [0.02, -0.15],
        "陵水县": [0, 0],
        "定安县": [0, -0.2],
        "昌江县": [0.1, -0.15],
        "文昌": [0.1, 0.2],
        "保亭县": [-0.05, -0.1],
        "琼中县": [0, 0],
        "乐东": [-0.1, -0.12],
        "东方": [0.15, -0.2]
      },
      "吉林": {
        "白山市": [0.4, 0],
        "四平": [0, 0.3],
        "白城市": [0, -0.3],
        "长春": [0, 0.2],
        "吉林": [0, -0.3]
      },
      "辽宁": {
        "葫芦岛": [-0.5, -0.3],
        "锦州": [0.3, 0.3],
        "抚顺市": [0.3, 0],
        "丹东": [0, 0.5],
        "大连": [0.2, 0.5],
        "营口": [0.2, -0.2],
        "鞍山": [0.1, -0.5],
        "本溪": [0.3, 0]
      },
      "北京": {
        "房山": [-0.2, 0],
        "大兴": [0.1, -0.1],
        "门头沟": [-0.2, 0.1],
        "怀柔": [-0.1, 0.1],
        "密云区": [0.1, 0.2],
        "海淀": [-0.1, 0.1],
        "通州": [0.1, -0.1],
        "丰台": [0, 0],
        "西城": [0, 0.05],
        "东城": [0.05, 0],
        "朝阳": [0.05, 0.05]
      },
      "福建": {
        "南平": [0, 0.8],
        "宁德": [0, 0.5],
        "三明": [0, 0],
        "福州": [0, 0],
        "龙岩": [-0.2, 0.2],
        "莆田": [-0.1, 0.1],
        "泉州": [-0.3, 0.5],
        "漳州": [-0.2, -0.4],
        "厦门": [0, 0.2]
      },
      "四川": {
        "甘孜": [-1, 0],
        "阿坝州": [0.5, 0],
        "绵阳": [0.2, 0.2],
        "广元": [0, -0.2],
        "巴中": [0.1, 0],
        "南充": [0.1, 0.2],
        "成都": [-0.1, 0],
        "资阳": [0, 0.1],
        "内江": [0, 0.1],
        "雅安": [-0.2, 0],
        "乐山": [-0.1, -0.2],
        "泸州": [0.1, -0.3]
      },
      "黑龙江": {
        "大兴安岭": [-0.1, 0],
        "黑河": [-0.2, -1.1],
        "七台河": [0, 0.1],
        "哈尔滨": [0.85, 0.05],
        "大庆": [-0.6, -0.3],
        "绥化": [-0.35, 0.1],
        "伊春": [0.1, 0],
        "鹤岗": [0.2, 0.3],
        "佳木斯": [0, 0],
        "双鸭山": [0.85, -0.2],
        "牡丹江": [0.2, 0],
        "鸡西": [1.0, 0.1]
      },
      "浙江": {
        "湖州": [-0.1, -0.2],
        "嘉兴": [0, -0.2],
        "杭州": [-0.8, -0.5],
        "绍兴": [0, -0.1],
        "舟山": [0, 0.1],
        "衢州": [0, 0],
        "金华": [0.2, 0.1],
        "台州": [-0.2, 0.1],
        "丽水": [-0.3, -0.2],
        "温州": [0, 0]
      },
      "山西": {
        "大同": [0.1, 0],
        "朔州": [0.2, 0],
        "忻州": [-0.1, 0.3],
        "太原": [-0.1, 0.1],
        "晋中": [0.2, -0.3],
        "阳泉": [0, 0.1]
      },
      "澳门": {
        "花地玛堂区": [0, 0],
        "花王堂区": [0, 0],
        "望德堂区": [0.004, 0.001],
        "风顺堂区": [0, 0],
        "大堂区": [0.001, -0.003],
        "嘉模堂区": [0.001, 0.003],
        "路凼填海区": [0, 0.001],
        "圣方济各堂区": [0.01, -0.001]
      },
      "河南": {
        "濮阳": [0.15, 0],
        "安阳": [0, 0],
        "鹤壁": [0, 0],
        "新乡": [0.05, 0],
        "郑州": [-0.05, -0.1],
        "许昌": [0, 0.1],
        "焦作": [0, 0.1],
        "济源示范区": [0, -0.05],
        "三门峡": [-0.25, -0.3],
        "洛阳": [-0.3, -0.4],
        "平顶山": [-0.3, 0.1],
        "漯河": [-0.1, 0],
        "周口": [0.2, 0.05],
        "开封": [0.15, -0.2],
        "商丘": [0, -0.1],
        "驻马店": [0, -0.08],
        "信阳": [0.65, -0.1],
        "南阳": [0, 0]
      },
      "湖南": {
        "张家界": [0, 0.3],
        "湘西自治州": [-0.1, 0.3],
        "常德": [0, 0.1],
        "益阳": [-0.1, -0.1],
        "岳阳": [0.1, -0.1],
        "长沙": [0.2, 0.1],
        "怀化": [0, 0],
        "邵阳": [-0.2, -0.2],
        "娄底": [-0.4, 0],
        "湘潭": [-0.3, -0.1],
        "株洲": [0.2, -0.3],
        "衡阳": [0, -0.1],
        "永州": [0.1, -0.3],
        "郴州": [0, 0]
      },
      "香港": {
        "北区": [0, 0],
        "元朗区": [0, 0],
        "大埔区": [0, 0],
        "屯门区": [0, 0],
        "荃湾区": [-0.003, 0.001],
        "沙田区": [0, 0],
        "西贡区": [0.003, 0],
        "葵青区": [0, -0.002],
        "深水埗区": [0, 0],
        "黄大仙区": [0, 0.001],
        "油尖旺区": [0, 0],
        "九龙城区": [0, 0],
        "观塘区": [0, 0],
        "离岛区": [0, 0],
        "中西区": [0, 0],
        "湾仔区": [0, -0.001],
        "东区": [0, 0],
        "南区": [0.004, -0.002]
      },
      "安徽": {
        "宿州": [0.5, 0],
        "淮北": [0, -0.2],
        "毫州": [0.6, -0.9],
        "阜阳": [0, 0],
        "淮南": [-0.1, -0.2],
        "滁州": [-0.2, 0.3],
        "蚌埠": [0, 0.2],
        "马鞍山": [-0.1, 0],
        "合肥": [0, -0.1],
        "安庆": [-0.6, -0.05],
        "池州": [0, -0.3],
        "黄山": [-0.25, 0.2],
        "宣城": [0, -0.3],
        "芜湖": [-0.1, -0.15],
        "铜陵": [-0.15, 0],
        "六安": [-0.2, -0.1]
      },
      "云南": {
        "迪庆藏族自治州": [-0.2, 0.2],
        "丽江": [0.5, 0.1],
        "邵通": [0.4, 0.3],
        "怒江傈僳族自治州": [-0.3, 1.1],
        "大理": [0, 0],
        "楚雄州": [0.1, 0.2],
        "昆明": [0.1, 0.5],
        "曲靖": [0.1, -0.1],
        "德宏州": [-0.4, 0],
        "保山": [-0.2, -0.2],
        "临沧": [-0.2, 0],
        "普洱": [0, 0.2],
        "玉溪": [-0.1, -0.1],
        "红河": [-0.4, 0],
        "文山州": [0.4, 0.2],
        "西双版纳": [0, -0.1]
      },
      "江苏": {
        "徐州": [0.3, 0.1],
        "连云港": [0, 0],
        "宿迁": [0.1, 0],
        "淮安": [0.1, -0.1],
        "盐城": [0, 0.1],
        "扬州": [0, 0.2],
        "泰州": [0.1, -0.1],
        "南通": [0.2, 0.1],
        "南京": [0, 0],
        "镇江": [0, -0.1],
        "常州": [0, 0],
        "无锡": [0, 0],
        "苏州": [0, 0]
      },
      "内蒙古": {
        "阿拉善盟": [-3, 0.8],
        "巴彦淖尔": [-0.1, 0.8],
        "鄂尔多斯": [-0.2, -0.6],
        "包头": [0.05, 1.6],
        "呼和浩特": [0.1, -0.05],
        "乌兰察布": [0, 0.8],
        "锡林郭勒": [-0.5, 0],
        "赤峰": [0, 0.4],
        "通辽": [-0.1, 0],
        "兴安盟乌兰浩特": [0, 0],
        "呼伦贝尔": [0.4, 0]
      },
      "青海": {
        "海东市": [0.3, -0.2],
        "海北州": [-0.1, 0.5],
        "西宁": [-0.2, 0],
        "海南藏族自治州": [-0.3, -0.5],
        "黄南藏族自治州": [-0.3, -0.5],
        "果洛藏族自治州": [-0.5, -0.5],
        "玉树藏族自治州": [-2, 1],
        "海西蒙古族藏族自治州": [-2, 0]
      },
      "甘肃": {
        "酒泉市": [-3, 0],
        "嘉峪关市": [0, 0],
        "张掖": [0, -0.1],
        "金昌": [0, 0],
        "武威市": [0.35, -0.4],
        "白银": [0.2, 0.25],
        "兰州": [0, 0.1],
        "临夏": [-0.3, 0],
        "甘南州": [0, -0.3],
        "定西": [0, -0.4],
        "天水": [0, 0.1],
        "陇南": [0.15, 0.1],
        "平凉": [0.1, -0.2],
        "庆阳": [0, 0.25]
      },
      "台湾": {
        "新北市": [-3.0, -10],
        "台北市": [-0.5, -0.5],
        "基隆市": [5.0, 2.0],
        "桃园市": [-0.5, 1.0],
        "新竹县": [-0.8, -0.6],
        "新竹市": [-1.0, -0.2],
        "宜兰县": [1.0, 0.1],
        "苗栗县": [-0.8, -0.2],
        "台中市": [-0.2, -0.1],
        "花莲县": [1.0, -0.5],
        "南投县": [-0.2, 0.2],
        "彰化县": [-0.5, 0.2],
        "云林县": [-0.2, 0],
        "嘉义县": [2.0, -1.0],
        "嘉义市": [0, 0.3],
        "台南市": [-0.1, -0.1],
        "高雄市": [0, -0.1],
        "台东市": [0.5, 0.1],
        "屏东县": [0.5, 0.1],
        "澎湖县": [1.0, 0],
        "金门县": [0, 0],
        "连江县": [0, 0],
        "中国属钓鱼岛": [0, 0]
      },
      "贵州": {
        "铜仁": [-0.6, 0],
        "遵义": [0.2, 0.5],
        "毕节": [0.3, -0.35],
        "贵阳": [0, 0.3],
        "黔南州": [0.1, -0.5],
        "黔东南州": [0.4, -0.2],
        "安顺": [0, -0.4],
        "黔西南州": [0.45, 0.2],
        "六盘水": [-0.15, -0.6]
      },
      "广东": {
        "潮州": [0.2, 0.15],
        "梅州": [0, -0.15],
        "揭阳": [-0.25, -0.2],
        "汕头": [0, 0],
        "汕尾": [0.12, 0.3],
        "惠州": [0, 0.15],
        "东莞": [0, -0.15],
        "深圳": [0, 0],
        "广州": [0.15, 0.25],
        "清远": [0, 0.5],
        "韶关": [0, 0],
        "河源": [0.25, 0.4],
        "佛山": [-0.1, 0],
        "云浮": [-0.2, -0.2],
        "肇庆": [-0.2, 0.5],
        "中山": [0, 0],
        "珠海": [-0.1, -0.2],
        "江门": [-0.5, -0.35],
        "茂名": [0, 0.3],
        "阳江": [-0.15, 0.2],
        "湛江": [-0.3, -0.3]
      },
      "重庆": (_ = {
        "巫山县": [0, 0],
        "巫溪县": [-0.3, 0.12],
        "云阳县": [0.05, 0.08],
        "奉节县": [-0.1, -0.2],
        "万州区": [0, -0.1],
        "梁平区": [0, 0],
        "忠县": [-0.15, 0],
        "石柱县": [0.1, 0.07],
        "丰都县": [0.1, 0],
        "长寿区": [0, 0.05],
        "涪陵区": [-0.08, 0],
        "彭水县": [0.1, 0.2],
        "巴南区": [0.15, 0]
      }, _defineProperty(_, "\u5F6D\u6C34\u53BF", [0.07, 0.02]), _defineProperty(_, "武隆区", [-0.07, 0]), _defineProperty(_, "南川区", [-0.1, 0]), _defineProperty(_, "合川区", [-0.1, 0]), _defineProperty(_, "潼南区", [0, 0.1]), _defineProperty(_, "\u5357\u5DDD\u533A", [0.08, 0]), _defineProperty(_, "江津区", [0, -0.2]), _defineProperty(_, "永川区", [0, -0.08]), _defineProperty(_, "綦江区", [0, -0.2]), _defineProperty(_, "渝北区", [0.1, 0.3]), _)
    }
  };
  /***/
},
/* 5 */

/***/
function (module, __webpack_exports__, __webpack_require__) {
  "use strict";

  var GetCenterCity = function GetCenterCity() {
    _classCallCheck(this, GetCenterCity);

    /**
     * 北京  东城区
    天津 滨海新区
    上海 浦东新区
    重庆 渝中区
     */
    var data = {
      '湖北': '武汉',
      '广东': '广州',
      '浙江': '杭州',
      '河南': '郑州',
      '湖南': '长沙',
      '安徽': '合肥',
      '江西': '南昌',
      '江苏': '南京',
      '重庆': '渝中区',
      '山东': '济南',
      '四川': '成都',
      '北京': '东城',
      '黑龙江': '哈尔滨',
      '上海': '浦东',
      '福建': '福州',
      '河北': '石家庄',
      '陕西': '西安',
      '广西': '南宁',
      '云南': '昆明',
      '海南': '海口',
      '山西': '太原',
      '贵州': '贵阳',
      '辽宁': '沈阳',
      '天津': '滨海新区',
      '甘肃': '兰州',
      '吉林': '长春',
      '内蒙古': '呼和浩特',
      '新疆': '乌鲁木齐',
      '宁夏': '银川',
      '香港': '香港',
      '台湾': '台北',
      '青海': '西宁',
      '澳门': '澳门',
      '西藏': '拉萨'
    };

    this.getCity = function (ns) {
      return data[ns];
    };
  };
  /* harmony export (immutable) */


  __webpack_exports__["a"] = GetCenterCity;
  /***/
},
/* 6 */

/***/
function (module, __webpack_exports__, __webpack_require__) {
  "use strict";

  var ParseURL = function ParseURL() {
    _classCallCheck(this, ParseURL);

    var url = window.location.href;
    var a = document.createElement('a');
    a.href = url; // var a = new URL(url);

    return {
      source: url,
      protocol: a.protocol.replace(':', ''),
      host: a.hostname,
      port: a.port,
      query: a.search,
      params: function () {
        var params = {},
            seg = a.search.replace(/^\?/, '').split('&'),
            len = seg.length,
            p;

        for (var i = 0; i < len; i++) {
          if (seg[i]) {
            p = seg[i].split('=');
            params[p[0]] = p[1];
          }
        }

        return params;
      }(),
      hash: a.hash.replace('#', ''),
      path: a.pathname.replace(/^([^\/])/, '/$1')
    };
  };
  /* unused harmony export default */


  ;
  /***/
}
/******/
]);