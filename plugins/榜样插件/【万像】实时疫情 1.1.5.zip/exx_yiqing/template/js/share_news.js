/* eslint-disable */
var MShare = {
  getScript: function(file, callback, charset) {
    var doc = document,
      head = doc.getElementsByTagName('head')[0],
      js = doc.createElement('script');
    charset && js.setAttribute('charset', charset);
    js.setAttribute('src', file);
    head.appendChild(js);
    if (!(/*@cc_on!@*/ 0)) {
      js.onload = function() {
        callback && callback();
      };
    } else {
      js.onreadystatechange = function() {
        if (js.readyState == 'loaded' || js.readyState == 'complete') {
          js.onreadystatechange = null;
          callback && callback();
        }
      };
    }
    return false;
  },
  mqq: function() {
    this.getScript('//pub.idqqimg.com/qqmobile/qqapi.js?_bid=152', function() {
      try {
        window.mqq.data.setShareInfo({
          share_url: shareData.link,
          title: shareData.title,
          desc: shareData.desc,
          image_url: shareData.img
        });
      } catch (e) {}
    });
  },
  qqNews: function() {
    if (window.TencentNews && window.TencentNews.setShareArticleInfo) {
      window.TencentNews.setShareArticleInfo(
        shareData.title,
        shareData.desc,
        shareData.desc,
        shareData.link,
        shareData.img
      );
    }
  },
  WeiXin: function() {
    WeixinJSBridge.on('menu:share:timeline', function(e) {
      var data = {
        img_width: '120',
        img_height: '120',
        img_url: shareData.img,
        link: shareData.link,
        desc: shareData.desc,
        title: shareData.title
      };
      WeixinJSBridge.invoke('shareTimeline', data, function(res) {
        WeixinJSBridge.log(res.err_msg);
      });
    });
    WeixinJSBridge.on('menu:share:weibo', function() {
      WeixinJSBridge.invoke(
        'shareWeibo',
        { content: shareData.desc, url: shareData.link },
        function(res) {
          WeixinJSBridge.log(res.err_msg);
        }
      );
    });
    WeixinJSBridge.on('menu:share:appmessage', function(argv) {
      WeixinJSBridge.invoke(
        'sendAppMessage',
        {
          img_width: '120',
          img_height: '120',
          img_url: shareData.img,
          link: shareData.link,
          desc: shareData.desc,
          title: shareData.title
        },
        function(res) {
          WeixinJSBridge.log(res.err_msg);
        }
      );
    });
    WeixinJSBridge.on('currentMpInfo', function(argv) {
      WeixinJSBridge.invoke(
        'currentMpInfo',
        {
          brandIcon: 'https://mat1.gtimg.com/yslp/testdeploy/favicon.ico' // icon 指品牌地址
        },
        function(res) {
          WeixinJSBridge.log(res.err_msg);
        }
      );
    });
  },
  init: function() {
    var _this = this;
    // _this.mqq();

    document.addEventListener('WeixinJSBridgeReady', function() {
      _this.WeiXin();
    });
  }
};
MShare.init();