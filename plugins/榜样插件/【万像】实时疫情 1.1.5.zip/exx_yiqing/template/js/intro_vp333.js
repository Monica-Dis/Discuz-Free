/* eslint-disable */
$(document).ready(function() {
  if (!isMobile.any) {
    $('body').addClass('pc');
  } else {
    $('body').addClass('mobile');
  }
  // 缩放
  (function() {
    var ww = window.innerWidth;
    var wh = window.innerHeight;
    let scaleX = ww / 750;
    if (scaleX < 1) {
      $('#scaleContainer, .flex-box')
        .css('transform', 'scale(' + scaleX + ')')
        .show();
      $('.pop_qs').css({
        transform: 'scale(' + scaleX + ') translate(-50%, -50%)',
        height: wh / scaleX - 400
      });
      $('.pop_qs_suspect').css({
        transform: 'scale(' + scaleX + ') translate(-50%, -50%)'
      });
      $('.button, .placeNavMove').css({
        transform: 'scale(' + scaleX + ')'
      });
    } else {
      $('#scaleContainer, .flex-box').show();
      $('.button, .placeNavMove').css({
        'margin-left': (ww - 750) / 2
      });
    }
    let scalexPop = (wh * (ww / 472)) / 590;
    if (Math.floor(scalexPop) <= 0) {
      $('.previw-area, .previw').css('transform', `scale(${scalexPop})`);
    }
  })();
  // resize
  (function() {
    window.addEventListener('resize', resizeThrottler, false);
    let resizeTimeout;
    function resizeThrottler() {
      // ignore resize events as long as an actualResizeHandler execution is in the queue
      if (!resizeTimeout) {
        resizeTimeout = setTimeout(function() {
          resizeTimeout = null;
          actualResizeHandler();
          // The actualResizeHandler will execute at a rate of 15fps
        }, 66);
      }
    }
    function actualResizeHandler() {
      // handle the resize event
      var ww = window.innerWidth;
      var wh = window.innerHeight;
      var scaleX = ww / 750;
      if (scaleX < 1) {
        $('#scaleContainer')
          .css('transform', 'scale(' + scaleX + ')')
          .show();
        $('.button, .placeNavMove, .flex-box').css({
          transform: 'scale(' + scaleX + ')'
        });
        $('.pop_qs').css({
          transform: 'scale(' + scaleX + ') translate(-50%, -50%)',
          height: wh / scaleX - 400
        });
        $('.pop_qs_suspect').css({
          transform: 'scale(' + scaleX + ') translate(-50%, -50%)'
        });
      } else {
        $('#scaleContainer').show();
        $('.button, .placeNavMove, .flex-box').css({
          'margin-left': (ww - 750) / 2
        });
      }
      let scalexPop = (wh * (ww / 472)) / 600;
      if (Math.floor(scalexPop) <= 0) {
        $('.previw-area, .previw').css('transform', `scale(${scalexPop})`);
      }
    }
  })();
  //分享绘制 jaredhao

  function getNowTime() {
    var myDate = new Date();
    var d = {
      hour: myDate.getHours(),
      minutes: myDate.getMinutes()
    };
    return d;
  }

  // 传入省信息，展开该省并折叠其它省
  var openArea = function(d) {
    // console.log('------openArea',area)
    $(`.placeItemWrap[area="${d}"]`)
      .addClass('current')
      .siblings('.placeItemWrap')
      .removeClass('current');
  };
  window.openArea = openArea;

  //看这里
  /* ua 4 */
  var UA = function() {
    var userAgent = navigator.userAgent.toLowerCase();
    return {
      ipad: /ipad/.test(userAgent),
      iphone: /iphone/.test(userAgent),
      android: /android/.test(userAgent),
      qqnews: /qqnews/.test(userAgent),
      weixin: /micromessenger/.test(userAgent),
      qqnews_version: userAgent.match(/qqnews/i) == 'qqnews' ? userAgent.split('qqnews/')[1] : ''
    };
  };
  var $areaShare = $('.areaShare');
  var $areaShare_mapdata = $areaShare.find('.dataMap');
  function provClick(data) {
    if (bbo.isTenvideo()) {
      $(window).scrollTop(0);
    }
    $areaShareLoading.show();
    // lockWindowScroll(true);
    setTimeout(() => {
      var __area = data.area;
      // $areaShare.find('.bg').attr('crossorigin', 'anonymous');
      var areaBg = document.querySelector('.areaShare .bg');
      areaBg.crossOrigin = 'Anonymous';
      areaBg.crossOrigin = 'anonymous';
      $areaShare.find('.h1 .area, .h2 .area').text(__area);
      var $area = $(`.placeItemWrap[area="${__area}"]`);
      var __add = $area.find('.placeArea .add').text();
      var __confirm = $area.find('.placeArea .confirm').text();
      var __heal = $area.find('.placeArea .heal').text();
      var __dead = $area.find('.placeArea .dead').text();
      var $areaShare_data = $areaShare.find('.data');
      $('.areaShare .time').html($('.timeNum .d').html());
      $areaShare_data.find('.add').text(__add);
      if (__add == '待更新') {
        $areaShare_data.find('.add').addClass('small');
      } else {
        $areaShare_data.find('.add').removeClass('small');
      }
      $areaShare_data.find('.confirm').text(__confirm);
      $areaShare_data.find('.heal').text(__heal);
      $areaShare_data.find('.dead').text(__dead);
      var $areaShareImg = $('.areaShare .dataMap img');
      var tocanvasHtml = document.querySelector('.areaShare');
      var __canvas = document.createElement('canvas');
      var __width = tocanvasHtml.offsetWidth;
      var __height = tocanvasHtml.offsetHeight;
      var __scale = 1;
      __canvas.width = __width * __scale;
      __canvas.height = __height * __scale;
      __canvas.getContext('2d').scale(__scale, __scale);
      var opts = {
        tainttest: true, //检测每张图片都已经加载完成
        scale: __scale, // 添加的scale 参数
        useCORS: true,
        canvas: __canvas, //自定义 canvas
        logging: true, //日志开关
        width: __width, //dom 原始宽度
        height: __height //dom 原始高度
      };
      if (__area == '海南') {
        $areaShare.find('.chinamapLegend2').show();
      } else {
        $areaShare.find('.chinamapLegend2').hide();
      }
      // 此参数决定是调用全国地图还是省地图
      var isGlobalMap = false;
      var mapCanvas;
      if (isGlobalMap || __area == '香港' || __area == '澳门' || __area == '台湾') {
        $areaShare.find('.chinamapLegend1').show();
        $areaShare.find('.chinamapLegend2').show();
        $areaShare.find('.chlegs').hide();
        $areaShare_mapdata.css('margin-top', '50px');
        mapCanvas = document.querySelector('.chmap canvas').toDataURL('image/png');
        drawImg();
      } else {
        $areaShare.find('.chinamapLegend1').hide();
        $areaShare_mapdata.css('margin-top', 0);
        if (__area != '海南') {
          $areaShare.find('.chinamapLegend2').hide();
        }
        $areaShare.find('.chlegs').show();
        var obj = {
          data: globalData,
          special: () => {},
          drawOver: () => {
            function dw() {
              mapCanvas = document.querySelector('#areaMap canvas').toDataURL('image/png');
              if (mapCanvas.length > 20) {
                drawImg();
              } else {
                setTimeout(function() {
                  dw();
                }, 50);
              }
            }
            dw();
          }
        };
        new Enter(obj, 'areaMap', __area);
      }
      function drawImg() {
        if ($areaShareImg.length > 0) {
          $areaShareImg.attr('src', mapCanvas);
        } else {
          $('.areaShare .dataMap').prepend(`<img src="${mapCanvas}" />`);
        }
        html2canvas(document.querySelector('.areaShare'), opts).then(function(canvas) {
          // console.log(canvas.toDataURL('image/jpeg'));
          var areaStirng = canvas.toDataURL('image/jpeg', 0.7);
          showShareCard(areaStirng);
          // eslint-disable-next-line no-invalid-this
          AppPlatform.Survey.Digg.digg(this, 23311878, 13575399, 27661344);
        });
      }
    }, 100);
    // 上报相关
    // H5内部的分享按钮点击
    bossConfig.ei = 'boss_epidemic_h5_action';
    bossConfig.subType = 'shareBtnClick';
    bossConfig.pageArea = 'mapin';
    bossConfig.openid = bosskv.openid || bosskv.unionid || '';
    bossConfig.omgid = bossConfig.omgid || '';
    bossConfig.chlid = channel_name;
    bossConfig.pageFrom = bbo.isNewsApp() ? 'inapp' : 'outapp';
    reporter(bossConfig, bosskv);
  }

  $('.bj-fixed-area').click(function(e) {
    if (!$(e.target).hasClass('previw-img-area') && !$(e.target).hasClass('show-text-area')) {
      $('.bj-fixed-area').fadeOut();
    }
  });

  // 分享卡片显示方法
  var $previwImgArea = $('.previw-img-area');
  var $bjFixedArea = $('.bj-fixed-area');
  var $areaShareLoading = $('.areaShareLoading');
  function showShareCard(src) {
    if (bbo.isNewsApp()) {
      upload64image(src);
      return 0;
    }
    $previwImgArea.attr('src', src);
    $bjFixedArea.height($(window).height()).fadeIn();
    $areaShareLoading.hide();
  }

  // 顶部全国数据绘制图片
  var $topdataWrap_top = $('.topdataWrap');
  var $topdataWrap_inner = $('#topdataWrap .inner');
  function topDatatoCard() {
    $areaShareLoading.show();
    setTimeout(() => {
      var tocanvasHtml = document.querySelector('#topdataWrap .inner');
      var __canvas = document.createElement('canvas');
      var __width = tocanvasHtml.offsetWidth;
      var __height = tocanvasHtml.offsetHeight;
      var __scale = 2;
      __canvas.width = __width * __scale;
      __canvas.height = __height * __scale;
      __canvas.getContext('2d').scale(__scale, __scale);
      var opts = {
        tainttest: true, //检测每张图片都已经加载完成
        scale: __scale, // 添加的scale 参数
        useCORS: true,
        canvas: __canvas, //自定义 canvas
        logging: true, //日志开关
        width: __width, //dom 原始宽度
        height: __height //dom 原始高度
      };
      html2canvas(document.querySelector('#topdataWrap .inner'), opts).then(function(canvas) {
        // console.log(canvas.toDataURL('image/jpeg'));
        var areaStirng = canvas.toDataURL('image/jpeg');
        // console.log(areaStirng);
        wholeShare(areaStirng);
        if (bbo.isNewsApp()) {
          uoload64image(areaStirng);
        }
        // eslint-disable-next-line no-invalid-this
        AppPlatform.Survey.Digg.digg(this, 23311878, 13575399, 27661344);
      });
    }, 100);
  }

  // console.log('调试跑马灯1------');

  //数据加载完成后进行地图绘制
  function drawMap(provs) {
    // $el.empty();
    // 这里调用绘制地图方法
    let ary = [];
    let data = {};
    //素材数据上线改成https://mat1.gtimg.com/yslp/yyh5/mapview/
    // data.path = '../';
    //本地运行 // ../
    data.path = 'https://mat1.gtimg.com/yslp/yyh5/mapview/';
    //地图上显示的数据
    console.log(provs);
    data.mapList = provs;
    data.div = {
      //页面传递一个容器
      id: 'chmap',
      //宽度
      width: 1500,
      //高度
      height: 1200
    };
    //对应的颜色 1000 100ren 10ren 1+ 0
    data.colors = ['#ED514e', '#FF8f66', '#FFB769', '#FFE6BE'];
    // new Main(data);
    new Main(data, provClick);
    // main.selectProv((res)=>{
    //   console.log(res);
    //   //在这里写执行命令
    //   console.log(11222)
    // });
  }
  //分享绘制
  function wholeShare(topbase64) {
    var mapCanvas = document.querySelector('.chmap canvas');
    let mapImg = new Image();
    mapImg.src = mapCanvas.toDataURL();
    mapImg.onload = () => {
      let topimg = new Image();
      topimg.src = topbase64;
      topimg.onload = () => {
        let shareData = {
          date: '数据截至2020-01-28 18:00',
          map: mapImg,
          top: topimg
        };
        jared.drawShare(shareData, (base64) => {
          console.log('全国数据分享生成的base64 在这里拿');
          showShareCard(base64);
        });
      };
    };
  }

  //较真 jaredhao rebuild 131
  function drawJiaoZhen() {
    // 较真slider
    function jzSlider() {
      $('#rumor').show();
      var swiper = new Swiper('#rumor_slider', {
        loop: true,
        slidesOffsetBefore: 64,
        width: 622,
        spaceBetween: 20,
        autoplay: false,
        speed: 100,
        longSwipes: 0.1,
        pagination: {
          el: '.swiper-pagination',
          bulletClass: 'my-bullet',
          bulletActiveClass: 'my-bullet-active',
          clickable: true
        }
      });
    }
    function createItem(info) {
      let str = `
      <div class="rumor_card">
        <div class="rumor_icon"></div>
        <div class="rumor_title">
          ${info.title}
        </div>
        <div class="rumor_content">
          ${info.content}
        </div>
        <p class="more">查看详情</p>
        <div class="rumor_fake_img"></div>
      </div>
      <a class="rumor_link" href="https://vp.fact.qq.com/home"></a>`;
      let div = document.getElementById('piyaocon');
      let item = document.createElement('div');
      item.className = 'swiper-slide swiper-slide-piyao';
      item.style.width = '622px';
      item.innerHTML = str;
      div.appendChild(item);
    }
    // 获取较真详情
    function getArt(id, i) {
      var obj = {};
      $.ajax({
        // url: 'https://view.inews.qq.com/g2/getOnsInfo?name=wuwei_ww_lie_infos',
        url: `https://vp.fact.qq.com/miniArtData?id=${id}`,
        dataType: 'jsonp',
        scriptCharset: 'UTF-8',
        jsonp: 'callback',
        success: (res) => {
          // console.log(res.content.abstract)
          obj.title = res.content.title;
          obj.content = res.content.abstract[0].content;
          if (obj.title && obj.content) {
            createItem(obj);
            if (i >= addi - 1) {
              jzSlider();
            }
          }
        }
      });
    }
    var addi = 0;
    var ids = [];
    var idsObj = {};
    function getPyList(next) {
      $.ajax({
        // url: 'https://view.inews.qq.com/g2/getOnsInfo?name=wuwei_ww_lie_infos',
        url: 'https://vp.fact.qq.com/loadmore?page=0',
        dataType: 'jsonp',
        scriptCharset: 'UTF-8',
        jsonp: 'callback',
        success: (res) => {
          // let data = JSON.parse(res.data);
          res.content.map((d) => {
            // createItem(d.markstyle);
            if (addi > 5 || d.markstyle !== 'fake') {
              return;
            }
            addi += 1;
            if (!idsObj[d.id]) {
              ids.push(d.id);
              idsObj[d.id] = '';
            }
          });
          if (addi < 6 && next) {
            getPyList(false);
          }
          ids.map((n, i) => {
            setTimeout(function() {
              getArt(n, i);
            }, i * 100);
          });
        }
      });
    }
    getPyList(true);
  }

  setTimeout(function() {
    drawJiaoZhen();
  }, 1500);
  //较真end

  function ininlunbo() {
    var swiperone = new Swiper('#lunbo-one-slider', {
      direction: 'horizontal',
      speed: 500,
      observer: true, //修改swiper自己或子元素的时候，自动初始化swiper
      observeParents: true, //修改swiper的父元素时，自动初始化swiper
      iOSEdgeSwipeDetection: true,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
        type: 'custom',
        autoplayDisableOnInteraction: false,
        renderCustom: function(swiper, current, total) {
          var paginationHtml = ' ';
          var text = '';
          for (var i = 0; i < total; i++) {
            if (i === 0) {
              text = '全国疫情</br>新增趋势';
            } else if (i === 1) {
              text = '累计确诊</br>现有疑似';
            } else if (i === 2) {
              text = '全国累计</br>治愈/死亡';
            } else if (i === 3) {
              text = '治愈率</br>病死率';
            }
            // 判断是不是激活焦点，是的话添加active类，不是就只添加基本样式类
            if (i === current - 1) {
              if (i === 0) {
                paginationHtml += `<span class="swiper-pagination-customs swiper-pagination-customs-active" style="margin: 0;">${text}</span>`;
              } else {
                paginationHtml += `<span class="swiper-pagination-customs swiper-pagination-customs-active">${text}</span>`;
              }
            } else {
              if (i === 0) {
                paginationHtml += `<span class="swiper-pagination-customs" style="margin: 0;">${text}</span>`;
              } else {
                paginationHtml += `<span class="swiper-pagination-customs">${text}</span>`;
              }
            }
          }
          return paginationHtml;
        }
      }
    });
    $('.swiper-pagination-one').on('click', 'span', function() {
      swiperone.slideTo($(this).index(), 500, false); //切换到第一个slide，速度为1秒
    });
    var swipertwo = new Swiper('#lunbo-two-slider', {
      direction: 'horizontal',
      speed: 300,
      observer: true, //修改swiper自己或子元素的时候，自动初始化swiper
      observeParents: true, //修改swiper的父元素时，自动初始化swiper
      iOSEdgeSwipeDetection: true,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
        type: 'custom',
        autoplayDisableOnInteraction: false,
        renderCustom: function(swiper, current, total) {
          var paginationHtml = ' ';
          var text = '';
          for (var i = 0; i < total; i++) {
            if (i === 0) {
              text = '全国累计</br>趋势对比';
            } else if (i === 1) {
              text = '湖北内外</br>新增确诊对比';
            } else if (i === 2) {
              text = '湖北内外</br>病死率对比';
            } else if (i === 3) {
              text = '各省确诊</br>增幅比较';
            }
            // 判断是不是激活焦点，是的话添加active类，不是就只添加基本样式类 第一个切换tab没有左边距
            if (i === current - 1) {
              if (i === 0) {
                paginationHtml += `<span class="swiper-pagination-customs mar10 swiper-pagination-customs-active" style="margin: 0;">${text}</span>`;
              } else {
                paginationHtml += `<span class="swiper-pagination-customs mar10 swiper-pagination-customs-active">${text}</span>`;
              }
            } else {
              if (i === 0) {
                paginationHtml += `<span class="swiper-pagination-customs mar10" style="margin: 0;">${text}</span>`;
              } else {
                paginationHtml += `<span class="swiper-pagination-customs mar10">${text}</span>`;
              }
            }
          }
          return paginationHtml;
        }
      }
    });
    $('.swiper-pagination-two').on('click', 'span', function() {
      swipertwo.slideTo($(this).index(), 300, false); //切换到第一个slide，速度为1秒
    });
  }
  // 初始化轮播折线图
  ininlunbo();

  // 绘制医典信息 暂时注释掉
  var dataInfoYidian;
  function drawYidian() {
    function createItem(info) {
      let contentitem = '';
      let contentitemTwo = '';
      for (let i = 0; i < info.length; i++) {
        if (i < 5) {
          contentitem += `<li class="yidian-li li-one"><a class="yidian-li-a" href="${info[i].h5url}" target="_blank">${info[i].title}</a></li>`;
        } else if (i < 10) {
          contentitemTwo += `<li class="yidian-li li-two"><a class="yidian-li-a" href=${info[i].h5url} target="_blank">${info[i].title}</a></li>`;
        }
      }
      let str = `
      <div class="title sectionTitle titleQg mar8">预防手册
          <div class="yidianIcon"></div>
        </div>
        <div class="yidian-flex-title">
          <div class="tab-one tab-button cur" data-id="0">
            预防指南
          </div>
          <div class="tab-two tab-button" data-id="1">
            检查诊断
          </div>
        </div>
        <div id="yidian_slider" class="yidian_slider">
          <ul class="yidian-ul" c="0"> ${contentitem}</ul>
          <ul class="hide yidian-ul" c="1">${contentitemTwo}</ul>
        </div>
      </div>`;
      let div = document.getElementById('yidian');
      let item = document.createElement('div');
      item.innerHTML = str;
      div.appendChild(item);
      $('.tab-button').click(function() {
        $(this)
          .addClass('cur')
          .siblings('.tab-button')
          .removeClass('cur');
        var target = $(this)[0].dataset.id;
        //根据当前标签获取的m值，在内容标下的所有孩子标签下查找c=target的标签
        //然后删除hide css ，并为其它兄弟标签添加hide css
        $('.yidian_slider')
          .children("[c='" + target + "']")
          .removeClass('hide')
          .siblings()
          .addClass('hide');
      });
    }
    var data;
    function getPyListTwo() {
      $.ajax({
        url:
          'https://h5.baike.qq.com/api/jsonp/GetDocsByTag?callback=success_jsonpCallback&appid=2000000000000050&adtag=txxw.op.fybox&name=94700&offset=0&count=5',
        dataType: 'jsonp',
        jsonp: 'callback',
        jsonpCallback: 'success_jsonpCallback',
        scriptCharset: 'UTF-8',
        timeout: 3000,
        success: (res) => {
          if (res != null && res != '' && res.docs != null && res.docs != '') {
            $('#yidian').show();
            res.docs.forEach(function(element) {
              if (dataInfoYidian != null && dataInfoYidian != '') dataInfoYidian.push(element);
            });
            createItem(dataInfoYidian);
          }
        },
        error(xhr) {
          console.log('失败');
        }
      });
    }
    function getPyList() {
      $.ajax({
        url:
          'https://h5.baike.qq.com/api/jsonp/GetDocsByTag?callback=success_jsonpCallback&appid=2000000000000050&adtag=txxw.op.fybox&name=94699&offset=0&count=5',
        dataType: 'jsonp',
        jsonp: 'callback',
        jsonpCallback: 'success_jsonpCallback',
        scriptCharset: 'UTF-8',
        timeout: 3000,
        success: (res) => {
          if (res != null && res != '' && res.docs != null && res.docs != '') {
            dataInfoYidian = res.docs;
            getPyListTwo();
          }
        },
        error(xhr) {
          console.log('失败');
        }
      });
    }
    getPyList();
  }
  // 绘制医典信息 暂时注释掉
  drawYidian();

  //
  function cloneObj(obj) {
    let newObj = {};
    if (obj instanceof Array) {
      newObj = [];
    }
    for (let key in obj) {
      let val = obj[key];
      //newObj[key] = typeof val === 'object' ? arguments.callee(val) : val; //arguments.callee 在哪一个函数中运行，它就代表哪个函数, 一般用在匿名函数中。
      newObj[key] = typeof val === 'object' ? cloneObj(val) : val;
    }
    return newObj;
  }
  function parseChinaMapData(data) {
    let ary = [];
    let totalData = {};
    let provName;
    data.map(function(d) {
      provName = d.area;
      if (totalData[provName]) {
        totalData[provName].confirm += d.confirm;
      } else {
        totalData[provName] = cloneObj(d);
        ary.push(totalData[provName]);
      }
    });
    let drawover = () => {
      //地图绘制完成
    };
    let gotoProvPage = (res) => {
      //跳转到二级页 res.area
      console.log(res.area);
      area_pool.map((d) => {
        if (d.area == res.area) {
          console.log('gotoProvPage', d.name);
          //window.location.href = `https://news.qq.com/hdh5/feiyanarea.htm#/area/?pool=${d.name}`;
        }
      });
      //
    };
    let initData = {
      provs: ary,
      clickCall: provClick,
      drawover: drawover,
      gotoProvPage: gotoProvPage,
      divId: 'chmap'
    };
    jared.drawMap(initData);
  }
  //绘制注意这个方法已经只绘制曲线图
  function map(dt, dt2, sixSevenLinesData) {
    let _data = dt;
    let _dt2 = dt2;
    // console.log('dt', dt);
    let data = _data.sort((a, b) => {
      const strA = a.date;
      const strB = b.date;
      return strA < strB ? 1 : -1;
    });
    let addData = _dt2.sort((a, b) => {
      const strA = a.date;
      const strB = b.date;
      return strA < strB ? 1 : -1;
    });
    //
    for (let key in data) {
      let obj = data[key];
      let str = obj['date'];
      str = str.slice(1);
      str = str.replace('.', '-');
      // str=str.split(0);
      data[key]['date'] = str;
    }
    let data2 = cloneObj(data);

    for (let key in addData) {
      let obj = addData[key];
      let str = obj['date'];
      str = str.slice(1);
      str = str.replace('.', '-');
      // str=str.split(0);
      addData[key]['date'] = str;
    }
    // 画折线图
    // 累计曲线

    let curData = [];
    data.map((d) => {
      // console.log(d);
      let newObj = {};
      newObj.totalConfirm = d.confirm;
      newObj.date = d.date;
      newObj.curSuspect = d.suspect;
      curData.push(newObj);
    });
    let line1Data = {
      items: ['totalConfirm', 'curSuspect'],
      colorHash: {
        totalConfirm: '#E65561',
        dead: '#66666C',
        curSuspect: '#FFD661',
        //治愈 曲线数据 在这里修改
        heal: '#178B50'
      }
    };
    jared.drawChart($('.china'), curData, line1Data, false, false);
    //新增曲线
    let line2Data = {
      items: ['confirm', 'suspect'],
      colorHash: {
        confirm: '#E65561',
        suspect: '#FFD661',
        dead: '#178B50',
        heal: '#66666C'
      }
    };
    jared.drawChart($('.china2'), addData, line2Data, false, false, '新增');
    //累计治愈/死亡趋势
    let line3Data = {
      items: ['heal', 'dead'],
      colorHash: {
        confirm: '#005DFF',
        suspect: '#F8D4A7',
        dead: '#87878A',
        heal: '#6ABD7F'
      }
    };
    jared.drawChart($('.china3'), data, line3Data, false, false, '累计');
    //治愈率/病死率
    let line4Data = {
      items: ['healRate', 'deadRate'],
      colorHash: {
        deadRate: '#87878A',
        healRate: '#6ABD7F'
      }
    };
    let BF = true;
    let showChina4 = data.filter(function(o) {
      return o.suspect != null;
    });
    jared.drawChart($('.china4'), showChina4, line4Data, BF);
    jared.drawLines($('.china5'), data);
    //湖北 非湖北确诊
    let addHubeiBoHubei6Lines = (dt) => {
      let _data = dt;
      let data = _data.sort((a, b) => {
        const strA = a.date;
        const strB = b.date;
        return strA < strB ? 1 : -1;
      });
      //
      for (let key in data) {
        let obj = data[key];
        let str = obj['date'];
        str = str.slice(1);
        str = str.replace('.', '-');
        data[key]['date'] = str;
      }
      let line6Data = {
        items: ['country', 'hubei', 'notHubei'],
        colorHash: {
          hubei: '#9B0A0E',
          notHubei: '#FF7B7C',
          country: '#FFA655'
        }
      };
      jared.drawChart($('.china6'), data, line6Data);
      // let line7Data = {
      //   items: ['hubeiRate', 'notHubeiRate'],
      //   colorHash: {
      //     hubeiRate: '#2E75B6',
      //     notHubeiRate: '#B0B0B3'
      //   }
      // };
      // jared.drawChart($('.china7'), sixSevenLinesData.dailyDeadRateHistory, line7Data, true);
    };
    addHubeiBoHubei6Lines(sixSevenLinesData.dailyNewAddHistory);
    //
    let addHubeiBoHubei7Lines = (dt) => {
      let _data = dt;
      let data = _data.sort((a, b) => {
        const strA = a.date;
        const strB = b.date;
        return strA < strB ? 1 : -1;
      });
      //
      for (let key in data) {
        let obj = data[key];
        let str = obj['date'];
        str = str.slice(1);
        str = str.replace('.', '-');
        data[key]['date'] = str;
      }
      let line7Data = {
        items: ['hubeiRate', 'notHubeiRate'],
        colorHash: {
          hubeiRate: '#2E75B6',
          notHubeiRate: '#B0B0B3'
        }
      };
      jared.drawChart($('.china7'), data, line7Data, true);
    };
    addHubeiBoHubei7Lines(sixSevenLinesData.dailyDeadRateHistory);
    //end
    // nav
    $('#moveNav').html($('#staticNav').html());
    $('.placeNavMove').html($('#placeNav').clone());
    $('body').on('click', '.navTab', function() {
      var type = $(this).data('id');
      highlightNav(type);
    });
    var $navTabs = $('.navTabs');
    var highlightNav = function(type) {
      $navTabs.find('.navTab').removeClass('active');
      $navTabs.find('.navTab.' + type + 'Tab').addClass('active');
    };
	
	
	
	function gdjz(div,cssname,offset){
		var a,b,c,d;
		d=$(div).offset().top;
		a=eval(d + offset);
		b=$(window).scrollTop(); 
		c=$(window).height();
		if(b+c>a){
			$((div)).addClass((cssname));
			}
		}
		 if (i.intersectionRatio > 0.1) {
              $('#moveNav').hide();
            } else {
              $('#moveNav').show();
            }
	 $('#moveNav').hide();
	$(window).scroll(function(){
		var b,c,d;
			d=$('#staticNav').offset().top;
			b=$(window).scrollTop(); 
			c=$(window).height();
			if (b<d) {
			  $('#moveNav').hide();
			} else {
			  $('#moveNav').show();
			}
	});

    // IntersectionObserver
/*    var io = new IntersectionObserver(
      function(entries) {
        entries.forEach(function(i) {
			
			i.intersectionRatio=1;

			console.log(i.intersectionRatio);

          if (i.target.id === 'staticNav') {
            if (i.intersectionRatio > 0.1) {
              $('#moveNav').hide();
            } else {
              $('#moveNav').show();
            }
          }
        });
      },
      {
        threshold: [0, 0.5, 1]
      }
    );
    io.observe(document.querySelector('#staticNav'));*/

    var io2 = new IntersectionObserver(
      function(entries) {
        entries.forEach(function(i) {
          if (i.target.id === 'charts') {
            if (i.intersectionRatio > 0) {
              highlightNav('charts');
            }
          }
        });
      },
      {
        threshold: [0, 0.1],
        rootMargin: -window.innerHeight / 2.2 + 'px 0px'
      }
    );
    io2.observe(document.querySelector('#charts'));

    var io3 = new IntersectionObserver(
      function(entries) {
        entries.forEach(function(i) {
          if (i.target.id === 'prevent') {
            if (i.intersectionRatio > 0) {
              highlightNav('prevent');
            }
          }
        });
      },
      {
        threshold: [0],
        rootMargin: -window.innerHeight / 2.2 + 'px 0px'
      }
    );
    io3.observe(document.querySelector('#prevent'));

    var io4 = new IntersectionObserver(
      function(entries) {
        entries.forEach(function(i) {
          if (i.target.id === 'news') {
            if (i.intersectionRatio > 0) {
              highlightNav('news');
            }
          }
        });
      },
      {
        threshold: [0],
        rootMargin: -window.innerHeight / 2.2 + 'px 0px'
      }
    );
    io4.observe(document.querySelector('#news'));

    var io5 = new IntersectionObserver(
      function(entries) {
        entries.forEach(function(i) {
          if (i.target.id === 'rumor') {
            if (i.intersectionRatio > 0) {
              highlightNav('rumor');
            }
          }
        });
      },
      {
        threshold: [0],
        rootMargin: -window.innerHeight / 2.2 + 'px 0px'
      }
    );
    io5.observe(document.querySelector('#rumor'));
    var swiperLine = new Swiper('.swiper-lineChart', {
      loop: false,
      slidesOffsetBefore: 0,
      width: 750,
      spaceBetween: 20,
      autoplay: false,
      speed: 100,
      longSwipes: 0.1,
      pagination: {
        el: '.lineChart-pagination',
        bulletClass: 'my-bullet',
        bulletActiveClass: 'my-bullet-active',
        clickable: true
      }
    });
    var swiperLine2 = new Swiper('.swiper-lineChart2', {
      loop: false,
      slidesOffsetBefore: 0,
      width: 750,
      spaceBetween: 20,
      autoplay: false,
      speed: 100,
      longSwipes: 0.1,
      pagination: {
        el: '.lineChart-pagination2',
        bulletClass: 'my-bullet',
        bulletActiveClass: 'my-bullet-active',
        clickable: true
      }
    });
  }

  // 新的绘制省份列表数据的方法
  function drawArea(obj) {
    var __dt = JSON.parse(JSON.stringify(obj.data.total));
    __data = __dt.sort(function(a, b) {
      if (a.confirm !== b.confirm) {
        return parseInt(b.confirm) - parseInt(a.confirm);
      } else {
        return parseInt(b.suspect) - parseInt(a.suspect);
      }
    });
    function __draw() {
      __data.map(function(d) {
        // console.log(d.showHeal, d.area);
        // <p class="share ac_placeItem_sare"></p>
		
		if(d.area == $('.topprovincial').val()){
			$('.Provincialtodayval').html(d.today.confirm)
			$('.Provincialval').html(d.confirm)
			$('.Provincialcure').html((d.showHeal ? d.heal : '-'))
			$('.Provincialdead').html(d.dead)
		}
		
        var _html = $(`
          <div class="placeItemWrap ${d.area == '湖北' ? 'current' : ''}" area="${d.area}">
            <div class="clearfix placeItem placeArea">
              <h2 class="blue">${d.area}</h2>
              <div class="add ac_add ${!d.today.isUpdated ? 'small' : ''}">${
          !d.today.isUpdated ? '-' : d.today.confirm
        }</div>
              <div class="confirm">${d.confirm}</div>
              <div class="heal">${d.showHeal ? d.heal : '-'}</div>
              <div class="dead">${d.dead}</div>
              <div class="swl">
              ${d.showRate && !isNaN(parseFloat(d.deadRate)) ? d.deadRate : '-'}${
          d.showRate && typeof d.deadRate == 'number' ? '%' : ''
        }
              </div>
            </div>
          </div>
        `);
        obj.el.append(_html);
        _html.find('.placeArea').click(function(e) {
          var $this = $(this);
          if ($(e.target).hasClass('ac_placeItem_sare')) {
            // 省分享
            provClick({
              area: d.area
            });
          } else {
            $this.closest('.placeItemWrap').toggleClass('current');
          }
        });
        // console.log('dddddd',d)
        drawCitys(_html, d.children);
      });
      if (select_area && select_area != '') {
        openArea(select_area);
      }
    }
    setTimeout(function() {
      __draw();
      obj.cb();
    }, 100);
  }
  // 新的绘制二级地区列表数据的方法
  function drawCitys($el, data) {
    var __data = JSON.parse(JSON.stringify(data));
    // console.log('drawCitys',__data)
    __data = __data.sort(function(a, b) {
      if (
        b.city == '待确定' ||
        b.city == '待确认' ||
        b.city == '待明确' ||
        b.city == '所属地待确认' ||
        b.city == '地区待确认'
      ) {
        return -1;
      } else if (a.confirm !== b.confirm) {
        return b.confirm - a.confirm;
      } else {
        return b.suspect - a.suspect;
      }
    });
    __data.map(function(dd) {
		
		
		if(dd.city == $('.topcity').val()){
			$('.citytodayval').html(dd.today.confirm)
			$('.cityval').html(dd.confirm)
			$('.citycure').html((dd.showHeal ? dd.heal : '-'))
			$('.citydead').html(dd.dead)
			
		}
      var _innerhtml = `
        <div class="clearfix placeItem placeCity" city="${dd.city}">
          <h2 ${dd.city.length > 5 ? 'class="small"' : ''}>${dd.city}</h2>
          <div class="ac_add ${!dd.today.isUpdated ? 'small' : ''}">${
        !dd.today.isUpdated ? '-' : dd.today.confirm
      }</div>
          <div>${dd.confirm}</div>
          <div>${dd.showHeal ? dd.heal : '-'}</div>
          <div>${dd.dead}</div>
          <div class="swl">
            ${dd.showRate && !isNaN(parseFloat(dd.deadRate)) ? dd.deadRate : '-'}${
        dd.showRate && typeof dd.deadRate == 'number' ? '%' : ''
      }
          </div>
        </div>
      `;
      $el.append(_innerhtml);
    });
  }

  // 绘制海外表格
  function mapOthData($el, data) {
    var __data = data.sort(function(a, b) {
      if (a.confirm !== b.confirm) {
        return b.confirm - a.confirm;
      } else {
        return b.suspect - a.suspect;
      }
    });
    var __hw_confirm = 0;
    var __hw_dead = 0;
    var $hw_confirm = $('.hw_confirm');
    var $hw_dead = $('.hw_dead');
    __data.map(function(d) {
      var _html = '';
      __hw_confirm += parseInt(d.confirm);
      __hw_dead += parseInt(d.dead);
      var _html = `
        <div class="clearfix placeItem placeArea no-sharp abroad" country="${d.country}">
          <h2 class="blue ${d.country.length > 3 ? 'small' : ''}">${d.country}</h2>
          <div>${d.confirm}</div>
          <div>${d.heal}</div>
          <div>${d.dead}</div>
        </div>
      `;
      $el.append(_html);
    });
    $hw_confirm.text(__hw_confirm);
    $hw_dead.text(__hw_dead);
  }

  // 传入省信息，展开该省并折叠其它省
  function openArea(area) {
    console.log(area);
    $(`.placeItemWrap[area="${area}"]`)
      .addClass('current')
      .siblings('.placeItemWrap')
      .removeClass('current');
  }

  // 腾讯公益活动分享数量
  var ua = UA();
  function setGongYiNum() {
    $.ajax({
      url: 'https://ssl.gongyi.qq.com/cgi-bin/gywhd_gcd_qry_drag_cnt',
      dataType: 'jsonp',
      scriptCharset: 'UTF-8',
      jsonp: 'jsoncallback',
      success: (res) => {
        // console.log('腾讯公益活动分享数量',res.data.cnt);
        $('.b_jielong span').text(res.data.cnt);
      }
    });
  }

  if (bbo.isMobile() && bbo.isWeixin()) {
    setGongYiNum();
    $('.b_jielong, .flex-box .ko').fadeIn(600);
  } else if (bbo.ismagapp()) {
	 $('.appshare, .flex-box .ko').fadeIn(600);
  } else if (bbo.isPC()) {
    $('.ko,.btn-share,.plan-box').hide();
    $('.ko-box').height(0);
  } else {
    $('.plan-box, .flex-box .ko')
      .css({ left: '200px' })
      .fadeIn(600);
  }

  var $head_confirm = $('.recentNumber .confirm .number'),
    $head_suspect = $('.recentNumber .suspect .number'),
    $head_cure = $('.recentNumber .cure .number'),
    $head_dead = $('.recentNumber .dead .number'),
    $head_time_d = $('.timeNum .d'),
    $head_confirm_add = $('.recentNumber .confirm .add span'),
    $head_cuspect_add = $('.recentNumber .suspect .add span'),
    $head_cure_add = $('.recentNumber .cure .add span'),
    $head_dead_add = $('.recentNumber .dead .add span');
	
	$head_nowConfirm = $('.recentNumber .nowConfirm .number'),
	$head_nowSevere = $('.recentNumber .nowSevere .number'),
	
	$head_nowConfirm_add = $('.recentNumber .nowConfirm .add span'),
    $head_nowSevere_add = $('.recentNumber .nowSevere .add span');
	
  $head_suspect_add_d = $('.recentNumber .suspect .qs_bottom span');
  // 绘制顶部信息（确诊新增...，截至...，）
  function updateHead(headData, headAddData) {
    if (headData.isShowAdd) {
      $('.recentNumber').addClass('showAdd');
    }
	
	
	console.log(headData);
	
    // console.log(headData);
    // 确诊
    $head_confirm.html(headData.confirm);
    // 疑似
    $head_suspect.html(headData.suspect);
    // 治愈
    $head_cure.html(headData.heal);
    // 死亡
    $head_dead.html(headData.dead);
	
	
	$head_nowConfirm.html(headData.nowConfirm);
	$head_nowSevere.html(headData.nowSevere);
	
    // let duTime = headData.lastUpdateTime.substr(5);
    if (headData.lastNow == '') {
      $head_time_d.html(`统计截至 <span>${headData.lastUpdateTime}</span>`);
    } else {
      $head_time_d.html(
        `统计截至 <span>${headData.lastUpdateTime}</span> <em>更新于${headData.lastNow}前</span></em>`
      );
    }
    $head_confirm_add.html('+' + headAddData.confirm);
    $head_cuspect_add.html('+' + headAddData.suspect_b);
    $head_suspect_add_d.html(
      parseInt(headAddData.suspect) > 0 ? `+${headAddData.suspect}` : headAddData.suspect
    );
    $head_cure_add.html('+' + headAddData.heal);
    $head_dead_add.html('+' + headAddData.dead);
	
	$head_nowConfirm_add.html((parseInt(headAddData.nowConfirm)>0?'+'+headAddData.nowConfirm:headAddData.nowConfirm));
	$head_nowSevere_add.html((parseInt(headAddData.nowSevere)>0?'+'+headAddData.nowSevere:headAddData.nowSevere));
	
    $topdataWrap_inner.html($topdataWrap_top.html());
    $topdataWrap_inner.find('.btn, .qs, .title').remove();
  }

  // 弹出层出现，锁死屏幕滚动 -- 兼容安卓ios
  var body_top = 0;
  var lockWindowScroll = function(islock) {
    if (islock) {
      body_top = $(window).scrollTop();
      $('body').css({
        position: 'fixed',
        left: 0,
        top: -body_top
      });
    } else {
      $('body').css({
        position: '',
        top: ''
      });
      $(window).scrollTop(body_top);
    }
  };
  window.lockWindowScroll = lockWindowScroll;

  // 渲染新闻列表
  var $marquee = $('.marquee .text');
  function drawNewsList(data) {
    let cb = data.sort((a, b) => {
      let strA = a.publish_time;
      let strB = b.publish_time;
      return strA > strB ? -1 : 1;
    });
    // $('.marquee .text').html(`${data[0].title}。${data[1].title}<span>${data[0].title}。${data[1].title}。</span>`);
    let marquee_html = '';
    let html = cb
      .slice(0, 10)
      .map(function(d, i) {
        if (i < 2) {
          marquee_html += `${d.title}。`;
        }
        return (
          `<div class="singleNew">
        <div class="timeIcon"></div>
        <div class="times"><span class="pass">` +
          d.publish_time +
          `</span>` +
          (i === 0 ? '<div class="newest"></div>' : '') +
          `</div><div class="news-box"><div class="title">` +
          d.title +
          `</div>
        <div class="desc">` +
          d.desc +
          `</div>
        <div class="source">来源：` +
          d.media +
          `</div></div></div>`
        );
      })
      .join();
    $('#news')
      .find('.singleNew')
      .remove();
    $('#news').append($(html));
    $marquee.html(`${marquee_html}${marquee_html}`).show();
  }

  // 绑定事件
function addFunction() {
    var $pop_qs = $('.pop_qs');
    var $placeNav = $('#placeNav');
    var placeNavTop = $placeNav.offset().top;
    setTimeout(function() {
      placeNavTop = $placeNav.offset().top;
    }, 3000);
    var $pop_qs_suspect = $('.pop_qs_suspect');
    var $qs_mask = $('.qs_mask');
    // 现有确诊说明
    $('.nowConfirm').click(function() {
      $pop_qs_suspect.show();
      $qs_mask.show();
      lockWindowScroll(true);
    });
    // 弹出数据说明窗口
    $('.ac-dataqs').click(function() {
      $pop_qs.show();
      $qs_mask.show();
      lockWindowScroll(true);
    });
    // 隐藏所有弹出窗口
    $('.ac_qs_close, .ac_qs_mask').click(function() {
      $pop_qs.hide();
      $pop_qs_suspect.hide();
      $qs_mask.hide();
      lockWindowScroll(false);
    });
    // 弹出疑似病例每日新增说明
    var $ac_cuspect_qs = $('.recentNumber.showAdd .suspect');
     $('.recentNumber.showAdd .suspect').click(function() {
       $(this).toggleClass('current');
     });
    // 点击新增说明以外的区域则收起
    $('body').click(function(e) {
      // console.log($(e.target))
      var $e = $(e.target);
      if (!$e.hasClass('ac_suspect_qs') && !$e.closest('.ac_suspect_qs').length > 0) {
        $ac_cuspect_qs.removeClass('current');
      }
    });
    var $placeNavMove = $('.placeNavMove');
    var $window = $(window);
    var $moveNavLast = $('.moveNavLast');
    $window.scroll(function() {
      console.log();
      // console.log($window.scrollTop(), placeNavTop,$moveNavLast.offset().top)
      if ($window.scrollTop() > placeNavTop - 10) {
        if ($moveNavLast.length > 0 && $window.scrollTop() < $moveNavLast.offset().top) {
          $placeNavMove.show();
        }
      } else {
        $placeNavMove.hide();
      }
      if ($moveNavLast.length > 0 && $window.scrollTop() > $moveNavLast.offset().top - 120) {
        $placeNavMove.hide();
      }

      if ($window.scrollTop() < 550 && $window.scrollTop() > 540) {
        statisticsModuleExp();
      }
    });
    $('.areaShare')
      .append($('.chinamapLegend1').clone())
      .append($('.chinamapLegend2').clone());
    $('.tabclose-area').click(function() {
      // lockWindowScroll(false);
      $('.bj-fixed-area')
        .height($(window).height())
        .fadeOut();
    });
    // var ua = UA();
    if (ua.android) {
      $('.areaShare').addClass('android');
    }
    $('.ac_topDataShare').click(function() {
      topDatatoCard();
    });
  }

  //去左右空格;
  function trim(s) {
    return s.replace(/(^\s*)|(\s*$)/g, '');
  }

  function formDate(dateForm) {
    if (dateForm === '') {
      //解决deteForm为空传1970-01-01 00:00:00
      return '';
    } else {
      var dateee = new Date(dateForm).toJSON();
      var date = new Date(+new Date(dateee) + 8 * 3600 * 1000)
        .toISOString()
        .replace(/T/g, ' ')
        .replace(/\.[\d]{3}Z/, '');
      return date;
    }
  }

  // 将分钟转换为年月日-时分
  function transDate(minute, show_date) {
    // console.log(minute)
    if (minute < 0) {
      return '';
    }
    if (minute == 0 || isNaN(minute) || minute == null) {
      return 0;
    }

    if (minute / 60 / 24 / 30 >= 12) {
      show_date += parseInt(minute / 60 / 24 / 30 / 12) + '年';
    }
    if (minute % (60 * 24 * 30 * 12) != 0 && minute / 60 / 24 >= 30) {
      return '';
    }
    if (minute % (60 * 24 * 30) != 0 && minute / 60 >= 24) {
      return '';
    }
    if (minute % (60 * 24) != 0 && minute >= 60) {
      var t = minute / 60;
      if (t > 5) {
        return '';
      }
      if (show_date != '较远') {
        t = t - parseInt(minute / 60 / 24) * 24;
      }
      show_date += '<span>' + parseInt(t) + '小时</span>';
    }
    if (minute % 60 != 0) {
      if (show_date != '较远') {
        minute = minute - parseInt(minute / 60) * 60;
      }
      if (parseInt(Math.floor(minute)) == 0) {
        return '';
      }
      show_date +=
        '<span>' + (parseInt(Math.ceil(minute)) == 0 ? 1 : Math.floor(minute)) + '分钟</span>';
    }

    return show_date;
  }

  // 计算上次更新距离现在时间
  function lastTimeNow(lasttime) {
    var currentDate = new Date();
    currentDate = formDate(currentDate);
    // console.log(currentDate)
    currentDate = currentDate.replace(/-/g, '/');
    var __lasttime = lasttime.replace(/-/g, '/');
    // console.log('时间戳对比------', currentDate, __lasttime);
    var result = parseInt(Date.parse(currentDate) - Date.parse(__lasttime));
    var minuts = result / 1000 / 60;
    return transDate(minuts, '');
  }
  //判断是否是后台预览页面-根据参数test_time
  function checkPreview() {
    var query = window.location.search.substring(1);
    if (query) {
      var vars = query.split('&');
      let variable = 'test_time';
      for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split('=');
        if (pair[0] == variable) {
          let time = pair[1];
          let year = time.substring(0, 4);
          let month = time.substring(4, 6);
          let day = time.substring(6, 8);
          let hour = time.substring(8, 10);
          let start = year + '/' + month + '/' + day + ' ' + hour + ':00:00';
          let date = new Date(time);
          console.log('-date', date);
          //1小时
          let dif = 60 * 60 * 1000;
          if (Date.now() - new Date(start) < dif && Date.now() - new Date(start) >= 0) {
            return true;
          }
          break;
        }
      }
    }
    return false;
  }
  // 获取新接口数据
  // 上线前需要核查
  function getList() {
    var url = 'https://view.inews.qq.com/g2/getOnsInfo?name=disease_h5';
    //判断是否是后台预览页
    if (checkPreview()) {
      url = 'https://view.inews.qq.com/g2/getOnsInfo?name= disease_h5_proview';
    }
    if (bbo.getUrlParam('testname')) {
      url = 'https://view.inews.qq.com/g2/getOnsInfo?name=disease_h5_test';
    }
    // url = 'https://view.inews.qq.com/g2/getOnsInfo?name=disease_h5_test';
    console.log(url);
    $.ajax({
      // url: 'https://view.inews.qq.com/g2/getOnsInfo?name=disease_h5_test',
      url: url,
      dataType: 'jsonp',
      scriptCharset: 'UTF-8',
      jsonp: 'callback',
      success: (res) => {
        var data = JSON.parse(res.data);
        var headData = {};
        var headAddData = {};
        // 所有数据都通过深度拷贝后传递
        console.log('全部数据', data);
		
		
		
        window.globalData = JSON.parse(JSON.stringify(data));
        // return;
        // 顶部全局数据
        headData = JSON.parse(JSON.stringify(data.chinaTotal));
        headData.lastUpdateTime = data.lastUpdateTime;
        headData.isShowAdd = data.isShowAdd;
		
		//console.log(headData);
		
        var _headAddData = JSON.parse(JSON.stringify(data.chinaAdd));
        _headAddData.suspect_b = data.chinaDayAddList[data.chinaDayAddList.length - 1].suspect;

        // 曲线数据
        var lineData = [];
        // console.log('曲线数据：', data.chinaDayList);
        for (var i in data.chinaDayList) {
          lineData.push(data.chinaDayList[i]);
        }
        var addLineData = [];
        for (var key in data.chinaDayAddList) {
          addLineData.push(data.chinaDayAddList[key]);
        }
        //67linedata
        let sixSevenLinesData = {};
        sixSevenLinesData.dailyNewAddHistory = data.dailyNewAddHistory;
        sixSevenLinesData.dailyDeadRateHistory = data.dailyDeadRateHistory;
        // console.log('add曲线数据：', addLineData);
        map(
          JSON.parse(JSON.stringify(lineData)),
          JSON.parse(JSON.stringify(addLineData)),
          sixSevenLinesData
        );

        // 新闻列表数据
        var newsListData = data.articleList ? JSON.parse(JSON.stringify(data.articleList)) : [];
        drawNewsList(newsListData);
        // 国内数据 国外数据
        // var dataCn = [];
        var areaData = {
          total: [],
          today: []
        };
        var cityData = {
          total: [],
          today: [],
          mapTotal: []
        };
        var foreignArray = [];
        for (var i in data.areaTree) {
          var item = data.areaTree[i];
          if (item.name && trim(item.name) == '中国') {
            // console.log('中国')
            headAddData = JSON.parse(JSON.stringify(item.today));
            for (var n in item.children) {
              // console.log('totle_nnnnnn', item.children[n])
              // var __this
              var __total = {};
              var __today = {};
              __total = Object.assign({}, item.children[n].total);
              __total.children = [];
              __today = Object.assign({}, item.children[n].today);
              __total.area = item.children[n].name;
              if (bbo.find(area_pool, { area: item.children[n].name })) {
                __total.pool = bbo.find(area_pool, { area: item.children[n].name }).name;
                __total.url = bbo.find(area_pool, { area: item.children[n].name }).channel_name;
              }
              var __areaMapTotal = Object.assign({}, item.children[n].total);
              __areaMapTotal.area = item.children[n].name;
              __areaMapTotal.country = item.name;
              __areaMapTotal.city = '';
              // console.log('__areaMapTotal',__areaMapTotal, item.children[n])
              cityData.mapTotal.push(__areaMapTotal);
              if (item.children[n].children && item.children[n].children.length > 0) {
                for (var totle_i in item.children[n].children) {
                  // if (item.children[n].name === '四川') {
                  //   console.log(totle_i,item.children[n].children)
                  // };
                  var __citytotal = {};
                  var __cityMapTotal = {};
                  var __citytoday = {};
                  __citytotal = Object.assign({}, item.children[n].children[totle_i].total);
                  __citytoday = Object.assign({}, item.children[n].children[totle_i].today);
                  __citytotal.area = item.children[n].name;
                  __citytotal.country = item.name;
                  __citytotal.city = item.children[n].children[totle_i].name;
                  __cityMapTotal = Object.assign({}, __citytotal);
                  // console.log('__cityMapTotal',__cityMapTotal)
                  // cityData.mapTotal.push(__cityMapTotal);
                  __citytotal.today = __citytoday;
                  // console.log('totle_i', item.children[n].children[totle_i])
                  cityData.total.push(__citytotal);
                  __total.children.push(JSON.parse(JSON.stringify(__citytotal)));
                  // console.log('__citytoday', __citytotal)
                }
              }
              // console.log('__d',__d)
              __total.today = __today;
              areaData.total.push(__total);
            }
          } else {
            var __country = {};
            for (var n in item.total) {
              __country[n] = item.total[n];
              __country[n].doday = item.today;
            }
            // console.log(typeof __country)
            __country.country = item.name;
            __country.city = '';
            __country.area = '';
            foreignArray.push(__country);
            // console.log('forignArry', foreignArray)
          }
        }
        // console.log('areaData', cityData)

        var __lastTimeNow = lastTimeNow(data.lastUpdateTime);
        headData.lastNow = __lastTimeNow;

        // 顶部总数据绘制
        // 今日疑似新增计算
        // var __todaySuspect = parseInt(
        //   data.chinaDayList[data.chinaDayList.length - 1].suspect -
        //     data.chinaDayList[data.chinaDayList.length - 2].suspect
        // );
        updateHead(headData, _headAddData);
		
		
		console.log(headData);
return;
        // areaMap();
        addFunction();
        //
        console.log('开始绘制');
        parseChinaMapData(cityData.mapTotal);
        drawArea({
          el: $('.chianList'),
          data: areaData,
          cb: function() {
            // drawCitys(cityData)
          }
        });
        // drawCitys(cityData);
        if (foreignArray.length > 0) {
          mapOthData($('.abroadList'), foreignArray);
        }
        // 处理地方卡片
        placeCard(areaData, cityData);
      },
      error: (err) => {
        console.log(err);
      }
    });
  }
  getList();
});

//医疗门诊省份接口请求
$.ajax({
  url: 'https://wechat.wecity.qq.com/api/THPneumoniaService/getHospitalProvince',
  type: 'POST',
  contentType: 'application/json;charset=utf-8',
  data: JSON.stringify({
    service: 'THPneumoniaOuterService',
    args: { req: {} },
    func: 'getHospitalProvince',
    context: { channel: 'AAEEviDRbllNrToqonqBmrER' }
  }),
  success: function(res) {
    if (res.args.rsp.result.code == 0) {
      let provincesList = res.args.rsp.provinces;
      mapHealthProvinceData($('.div-hospital'), provincesList);
    }
  }
});
//医疗门诊城市接口请求
function cityRequest($cur, province) {
  $.ajax({
    url: 'https://wechat.wecity.qq.com/api/THPneumoniaService/getHospitalCityByProvince',
    type: 'POST',
    contentType: 'application/json;charset=utf-8',
    data: JSON.stringify({
      service: 'THPneumoniaOuterService',
      args: {
        req: {
          province: province
        }
      },
      func: 'getHospitalCityByProvince',
      context: { channel: 'AAEEviDRbllNrToqonqBmrER' }
    }),
    success: function(res) {
      if (res.args.rsp.result.code == 0) {
        mapHealthCity($cur, res.args.rsp.info.citys);
      }
    }
  });
}
//拼接医疗门诊省份
function mapHealthProvinceData($el, list) {
  $el.empty();
  list.map(function(d) {
    var _html = '';
    var _html = $(`
      <div class="hotelItemWrap" province="${d.provinceName}">
        <div class="hotelProvince" data-province="${d.provinceName}" data-count="${d.cityCnt}">
          <div class="name">${d.provinceName}</div>
          <div class="count"></div>
        </div>
      </div>
    `);
    $el.append(_html);
    _html.find('.hotelProvince').click(function(e) {
      let province = e.currentTarget.dataset.province;
      let count = e.currentTarget.dataset.count;
      let cCount = $(this)
        .parent()
        .children('.hotelCity').length;
      if (cCount == 0 && count != 0) {
        cityRequest($(this), province);
      }
      $(this)
        .closest('.hotelItemWrap')
        .toggleClass('current');
    });
  });
  $el
    .children('.hotelItemWrap')
    .first()
    .children()
    .trigger('click');
}
//拼接医疗门诊城市
function mapHealthCity($el, list) {
  var _html = '';
  list.map(function(d) {
    _html = $(`
        <div class="hotelCity">
          <div class="name">${d.cityName}</div>
          <div class="count">${d.count}家<span>进入查询</span></div>
          <a class="healthlink" href="${d.link.url}"/>
        </div>
    `);
    // console.log(_html)
    $el.parent().append(_html);
    // $el.parent().find('.hotelCity').click(function(){
    //   console.log('----跳转地址',d.link.url);
    //   window.location.href=d.link.url;
    // });
  });
}

// 地方卡片处理

let areaDataCard = [];
let cityDataCard = [];
let channel_name = '';
let getCurrentBackStatus = false;

// 页卡默认数据
function placeCard(area, city) {
  areaDataCard = area.total;
  cityDataCard = city;
  $('#select-area').prepend("<option value='hb'>切换城市</option>");
  bbo.forEach(area.total, function(value, key) {
    $('#select-area').append("<option value='" + value.pool + "'>" + value.area + '</option>');
  });

  // 页卡头部附带参数
  let urlarea = bbo.getUrlParam('pool');
  // 文章链接客户端下发
  let itemarea = bbo.getUrlParam('channelId') || bbo.getUrlParam('channelid');

  if (urlarea) {
    console.log('placeCard-urlarea');
    webcellTofun(urlarea);
  } else if (itemarea) {
    console.log('placeCard-itemarea');
    toItemfun(itemarea);
  } else {
    console.log('placeCard-toLocalfun');
    toLocalfun();
  }
}

// 头部页卡传参定位
function webcellTofun(area) {
  let select = bbo.find(areaDataCard, { pool: area });
  if (select) {
    console.log('**头部页卡传参**', area);
    changePlaceCard(area);
  } else {
    toLocalfun();
  }
}

// 结合客户端定位
function toItemfun(area) {
  let select = bbo.find(local_chllist, { chlid: area });
  console.log(select);
  if (select) {
    console.log('**客户端传参**', area, select.group, select.chlname);
    // changePlaceCard(select.name);
    let itemarea = bbo.find(area_pool, function(o) {
      return bbo.containsWith(o.area, select.group);
    });
    if (bbo.isObject(itemarea)) {
      changePlaceCard(itemarea.name);
    } else {
      toLocalfun();
    }
  } else {
    toLocalfun();
  }
}

window['getCurrentBack'] = {
  onCallback: function(res) {
    getCurrentBackStatus = true;
    console.log('toLocalfun-step1-1-try', res);
    var cb = bbo.toJson(res);
    if (cb.errCode == '0') {
      console.log('定位成功 errCode 0');
      var _city = cb.currentLocationInfo.city.substr(0, 2);
      console.log('toLocalfun-step3');
      if (!bbo.isEmpty(_city) && _city) {
        console.log('toLocalfun-step4');
        let baseCity = bbo.find(local_chllist, function(o) {
          return bbo.containsWith(o.chlname, _city);
        });
        // 查找字典成功
        if (bbo.isObject(baseCity)) {
          console.log('toLocalfun-step5');
          let city = baseCity.group;
          let outCity = bbo.find(area_pool, function(o) {
            return bbo.containsWith(o.area, city);
          });
          if (bbo.isObject(outCity)) {
            console.log('toLocalfun-step5', outCity);
            console.log('客户端地理定位传参**', outCity.name);
            changePlaceCard(outCity.name);
          } else {
            defaultLocal();
          }
        } else {
          defaultLocal();
        }
      } else {
        defaultLocal();
      }
    } else {
      defaultLocal();
      console.log('授权意外');
    }
  }
};

// 结合客户端定位
function toLocalfun() {
  if (isQQNews() && window.TencentNews && window.TencentNews.getCurrentLocationInfo) {
    console.log('toLocalfun-step1');
    try {
      // 超时检查一遍兜底
      setTimeout(() => {
        if (!getCurrentBackStatus) {
          console.log('超时定位，onCallback失败');
          defaultLocal();
        } else {
          console.log('地理回调成功 toLocalfun-step1--1');
        }
      }, 700);
      window.TencentNews.getCurrentLocationInfo(getCurrentBack);
    } catch (e) {
      console.log(e, '捕获接口失败');
      defaultLocal();
    }
  } else {
    defaultLocal();
  }
}

// 降级默认地理定位
function defaultLocal() {
  console.log('**执行默认湖北定位**');
  var areas=$('.defaultarea').val();
  changePlaceCard(areas);
}

// 区域页卡信息
function changePlaceCard(area) {
  // 页卡显示区域
  let $tabox = $('.tab-box');
  let select = bbo.find(areaDataCard, { pool: area });

  $tabox.find('.add').text(select.today.confirm || 0);
  if (select.today.confirm == 0) {
    $tabox.find('.add').text('待更新');
    $tabox.find('.add').addClass('wait');
  } else {
    $tabox.find('.add').removeClass('wait');
  }
  $tabox.find('.confirm').text(select.confirm || 0);
  $tabox.find('.heal').text(select.heal || 0);
  $tabox.find('.dead').text(select.dead || 0);
  $('.tab-name ,.share-tab-name ,.btn-tab-name').text(select.area);
  $('#select-area').val(area);

  if (select.url == 'news_news_antip') {
    $('.btn-tab-name').text('全国');
    $('.tab-click .text-fix').addClass('hide-fix');
  } else {
    $('.tab-click .text-fix').removeClass('hide-fix');
  }

  // 全国地图地位
  // console.log('select.area:', select.area);
  jared.setDefault(select.area);
  // 分省信息展开
  window.select_area = select.area;
  openArea(select.area);

  channel_name = select.url || 'news_news_antip';

  // 页卡数据绘制
  let $taplist = $('.taplist-area');
  let $head_time_d = $('.timeNum .d');
  $taplist.find('.area').text(select.area);
  $taplist.find('.time').text('统计截至 ' + $head_time_d.find('span').html());
  $taplist.find('.add').text(select.today.confirm || '待更新');
  $taplist.find('.confirm').text(select.confirm || 0);
  $taplist.find('.heal').text(select.heal || 0);
  $taplist.find('.dead').text(select.dead || 0);
  showPlaceCardNews(area);
  changeCityCard(area);

  // 端内页卡疫曝光
  bossConfig.ei = 'boss_epidemic_h5_action';
  bossConfig.subType = 'statisticsModuleExp';
  bossConfig.pageFrom = bbo.isNewsApp() ? 'inapp' : 'outapp';

  bossConfig.chlid = channel_name;
  reporter(bossConfig, bosskv);
}

function changeCityCard(city) {
  let cityName = bbo.find(areaDataCard, { pool: city }).area;
  let cityArray = cityDataCard.total.filter(function(x) {
    return x.area == cityName;
  });
  let html = cityArray
    .map(function(d, i) {
      return (
        `<div class="pt-item">` +
        `<div class="t1">` +
        d.city +
        `</div>` +
        `<div class="t2">` +
        (d.today.confirm > 0 ? d.today.confirm : '-') +
        `</div>` +
        `<div class="t2">` +
        d.confirm +
        `</div>` +
        `<div class="t2">` +
        d.heal +
        `</div>` +
        `<div class="t2">` +
        d.dead +
        `</div>` +
        `</div>`
      );
    })
    .join('');
  $('.taplist-area')
    .find('.bt-box')
    .html('');
  $('.bt-box').append($(html));
}

function showPlaceCardNews(area) {
  $.ajax({
    url: 'https://api.dreamreader.qq.com/news/v1/province/news/list?province_code=' + area || 'hb',
    type: 'get',
    scriptCharset: 'UTF-8',
    success: function(res) {
      if (res.data.items) {
        let html = res.data.items
          .map(function(d, i) {
            if (d.news_url.indexOf('https') < 0) {
              d.news_url = d.news_url.replace('http:', 'https:');
            }
            return `<div class="text-item" data-id="` + d.cms_id + `"><i></i>` + d.title + `</div>`;
          })
          .join('');
        $('.city-tab')
          .find('.tab-text')
          .html('');
        $('.tab-text').append($(html));
      } else {
        $('.city-tab')
          .find('.tab-text')
          .html('');
        $('.city-tab')
          .find('.tab-box')
          .css({ 'margin-bottom': '40px' });
      }
    }
  });
}

// 区域要闻3条动态绑定
$('.tab-text').on('click', '.text-item', function() {
  var id = $(this).data('id');
  var url =
    'qqnews://article_9527?nm=' + id + '&from=xiaoai&behavior=checkPush&pagetype=h5epidemic';
  var href = 'https://view.inews.qq.com/w2/' + id;
  if (bbo.isNewsApp()) {
    downapp.run(url);
  } else {
    bbo.open(href);
  }
});

$('#select-area').on('change', function(e) {
  var area = $(this).val();
  changePlaceCard(area);
  bbo.stopPropagation(e);
  // H5页面内点击切换区域
  bossConfig.ei = 'boss_epidemic_h5_action';
  bossConfig.subType = 'changeLocationClick';
  bossConfig.pageFrom = bbo.isNewsApp() ? 'inapp' : 'outapp';
  reporter(bossConfig, bosskv);
});

// 跳转到身省份页
bbo.query('.tab-click').addEventListener('click', function() {
  goToArea();
});
bbo.query('.city-tab .tab-box').addEventListener('click', function() {
  goToArea();
});

function goToArea() {
  var area = $('#select-area').val();
  console.log(channel_name, area);
  if (channel_name != 'news_news_antip') {
    bbo.open(`https://news.qq.com/hdh5/feiyanarea.htm#/area/?pool=${area}`);
  }
}

//区域页卡跳转拉动
bbo.query('.tab-look-btn').addEventListener('click', function() {
  var url =
    'qqnews://article_9500?tab=news_news&channel=' +
    channel_name +
    '&from=xiaoai&pagetype=h5epidemic&force=1&behavior=checkPush&startextras=%7B%22from%22%3A%22weixin%22%2C%22pagetype%22%3A%22h5epidemic%22%2C%22force%22%3A1%7D';
  downappCard.run(url);

  // H5页面内点击切换区域
  bossConfig.ei = 'boss_epidemic_h5_action';
  bossConfig.subType = 'h5ToAppClick';
  bossConfig.pageArea = '3';
  bossConfig.pageFrom = bbo.isNewsApp() ? 'inapp' : 'outapp';
  reporter(bossConfig, bosskv);
});

// 分享某省数据
bbo.query('.tab-share-btn').addEventListener('click', function() {
  if (bbo.isTenvideo()) {
    $(window).scrollTop(0);
  }
  $('.areaShareLoading').show();
  // lockWindowScroll(true);
  var tipsText = $('.tab-text')
    .children()
    .eq(0)
    .text();
  $('.taplist-area')
    .find('.mk-tips i')
    .text(bbo.truncate(tipsText, 33));

  var tocanvasHtml = document.querySelector('.taplist-area');
  var __canvas = document.createElement('canvas');
  var __width = tocanvasHtml.offsetWidth;
  var __height = tocanvasHtml.offsetHeight;
  var __scale = 2;
  __canvas.width = __width * __scale;
  __canvas.height = __height * __scale;
  __canvas.getContext('2d').scale(__scale, __scale);

  var opts = {
    tainttest: true, //检测每张图片都已经加载完成
    scale: __scale, // 添加的scale 参数
    useCORS: true,
    canvas: __canvas, //自定义 canvas
    logging: true, //日志开关
    width: __width, //dom 原始宽度
    height: __height //dom 原始高度
  };
  html2canvas(document.querySelector('.taplist-area'), opts).then(function(canvas) {
    // console.log(canvas.toDataURL('image/jpeg'));
    var areaStirng = canvas.toDataURL('image/jpeg');
    // eslint-disable-next-line no-invalid-this
    AppPlatform.Survey.Digg.digg(this, 23311878, 13575399, 27661344);
    $('.previw-img-area').attr('src', areaStirng);
    if (bbo.isNewsApp()) {
      upload64image(areaStirng);
      return 0;
    }
    $('.areaShareLoading').hide();
    $('.bj-fixed-area')
      .height($(window).height())
      .fadeIn();
  });

  // H5内部的分享按钮点击
  bossConfig.ei = 'boss_epidemic_h5_action';
  bossConfig.subType = 'shareBtnClick';
  bossConfig.pageArea = 'location';
  bossConfig.openid = bosskv.openid || bosskv.unionid || '';
  bossConfig.omgid = bossConfig.omgid || '';
  bossConfig.chlid = channel_name;
  bossConfig.pageFrom = bbo.isNewsApp() ? 'inapp' : 'outapp';
  reporter(bossConfig, bosskv);
});
