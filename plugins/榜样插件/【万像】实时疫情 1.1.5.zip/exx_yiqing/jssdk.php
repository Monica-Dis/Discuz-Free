<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class jssdk{
	public function __construct($url) {
		global $_G;
		$this->exx_yiqing = $_G['cache']['plugin']['exx_yiqing'];
		$this->appId = trim($this->exx_yiqing['appid']);
		$this->appSecret = trim($this->exx_yiqing['appsecret']);
		$this->siteurl=$_G['siteurl'];
		$this->urls=$url;
	  }
	
	public function getSignPackage() {
		$jsapiTicket = $this->getJsApiTicket();
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		$url = $this->urls;
		$timestamp = time();
		$nonceStr = $this->createNonceStr();
		$string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";
		$signature = sha1($string);
		$signPackage = array(
		  "appId"     => $this->appId,
		  "nonceStr"  => $nonceStr,
		  "timestamp" => $timestamp,
		  "url"       => $url,
		  "signature" => $signature,
		  "rawString" => $string
		);
		$returns=$signPackage;
		return $returns; 
	}
	private function createNonceStr($length = 16) {
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$str = "";
		for ($i = 0; $i < $length; $i++) {
		  $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}
	private function getJsApiTicket() {
		global $_G;
		loadcache('Ticket');
		$caches=$_G['cache']['Ticket'];
 		$jsapi_ticket = $caches['jsapi_ticket'];
		$expire_time = $caches['expire_time'];
		if ($expire_time < time()) {
		  $accessToken = $this->getAccessToken();
		  $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=$accessToken";
		  $res = json_decode(dfsockopen($url));
		  $ticket = $res->ticket;
		  if ($ticket) {
			$caches['expire_time'] = time() + 7000;
			$caches['jsapi_ticket'] = $ticket;
			require_once libfile('function/cache');
			savecache('Ticket',$caches);
		  }
		} else {
		  $ticket = $jsapi_ticket;
		}
		if($_GET['debug']==1){
			echo 'getJsApiTicket:';
			print_r($res);
			savecache('Ticket',array());
			exit;
		}
		return $ticket;
	}
	private function getAccessToken() {
		global $_G;
		loadcache('wxtoken');
		$cachea=$_G['cache']['wxtoken'];
 		$access_token = $cachea['access_token'];
		$expire_time = $cachea['expire_time'];
		if ($expire_time < time()) {
		  $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$this->appId&secret=$this->appSecret";
		  $res = json_decode(dfsockopen($url));
		  $access_token = $res->access_token;
		  if ($access_token) {
			$cachea['expire_time'] = time() + 7000;
			$cachea['access_token'] = $access_token;
			require_once libfile('function/cache');
			savecache('wxtoken', $cachea);
		  }
		} else {
		  $access_token = $access_token;
		}
		if($_GET['debug']==2){
			echo 'getAccessToken:';
			print_r($res);
			savecache('wxtoken',array());
			exit;
		}
		return $access_token;
	}
}