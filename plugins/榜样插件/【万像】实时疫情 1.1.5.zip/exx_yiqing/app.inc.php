<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (! defined ('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit ('Access Denied');
}

echo "<script language='javascript'>";
echo "window.location.href='https://addon.dismall.com/?@68502.developer'";
echo "</script>";
exit;