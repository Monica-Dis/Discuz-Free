<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
header("Content-Type: text/html;charset=utf-8");
if($_GET['formhash'] != $_G['formhash']) {
	exit('formhasherr');
}
if($_GET['ac']=='getsdk'){
	require_once "source/plugin/exx_yiqing/jssdk.php";
	$jssdk = new jssdk($_G['siteurl'].'plugin.php?id=exx_yiqing');
	$signPackage = $jssdk->getSignPackage();
	exit(json_encode($signPackage));
}else{
	$json=dfsockopen('https://mat1.gtimg.com/news/feiyanarea/'.dhtmlspecialchars($_GET['area']).'.json');
	exit($json);
}