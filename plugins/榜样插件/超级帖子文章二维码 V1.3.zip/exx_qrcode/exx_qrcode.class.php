<?php
/**
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Date: 2018/11/28
 * Time: 10:48
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_exx_qrcode{
	function _getqrcode(){
		global $_G;
		$exx_qrcode=$_G['cache']['plugin']['exx_qrcode'];
		$exx_qrcode['codesite']=intval($exx_qrcode['codesite']);
		$exx_qrcode['qrcodetxt']=dhtmlspecialchars($exx_qrcode['qrcodetxt']);
		$url=dhtmlspecialchars($this->_currenturl());
		$qrcodeurl='source/plugin/exx_qrcode/qrcode.php?data='.$url;
		include template('exx_qrcode:tmp');
		return $return;	
	}
	
	
	
	function _currenturl($related = 0) {
		global $_G;
        $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
        $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
        return $related ? urlencode($relate_url) : urlencode(substr($_G['siteurl'],0,strlen($_G['siteurl'])-1).$relate_url);
    }
	
}

class plugin_exx_qrcode_forum extends plugin_exx_qrcode{
	function viewthread_modaction_output() {
		global $_G;
		$exx_qrcode=$_G['cache']['plugin']['exx_qrcode'];
		$forums = unserialize($exx_qrcode['forums']);
		if(!(in_array($_G['fid'],$forums))){
			return;
		}
		if($exx_qrcode['forum']){
			$code=$this->_getqrcode();
			return $code;
		}
		return;
	}
}

class plugin_exx_qrcode_portal  extends plugin_exx_qrcode{
	function view_article_content_output(){
		global $_G;
		$exx_qrcode=$_G['cache']['plugin']['exx_qrcode'];
		if($exx_qrcode['portal']){
			$code=$this->_getqrcode();
			return $code;
		}
		return;
	}
}