<?php
/**
 * Created by bangyang.
 * User: QQ 2395841575
 * Date: 2016/6/23
 * UpDate: 2018/09/11
 * Time: 10:06
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_exx_autoseo {
	function global_header(){
		global $_G;
		$exx_autoseo=$_G['cache']['plugin']['exx_autoseo'];
		$ret="";
		if(!$exx_autoseo['off']){
			return $ret;
		}
		$section = empty($exx_autoseo['mod']) ? array() : unserialize($exx_autoseo['mod']);
		if(!is_array($section)) $section = array();
		if(!($section[0]=='all')){
			if(!(in_array(CURSCRIPT,$section))){
				return $ret;
			}
		}
		if(($exx_autoseo['con'] && (!$_GET['aid'] || !$_G['tid'])) || ($_GET['mod']=='post' && $_GET['action']=='newthread' && CURSCRIPT=='forum') || ($_GET['mod']=='post' && $_GET['ac']=='reply' && CURSCRIPT=='forum') || ($_GET['mod']=='portalcp' && $_GET['ac']=='article' && CURSCRIPT=='portal') || $_GET['mod']=='spacecp' || ($_GET['mod']=='space' && $_GET['do']=='pm')  || ($_GET['mod']=='space' && $_GET['do']=='notice') || ($_GET['mod']=='space' && $_GET['do']=='friend') || (CURSCRIPT=='search' && $_GET['adv'] && $_GET['mod']) || $_GET['mod']=='stat' || ($_GET['mod']=='modcp' && $_GET['action']=='home')){
			return $ret;
		}
		$ret="<script>
				(function(){
					var bp = document.createElement('script');
					var curProtocol = window.location.protocol.split(':')[0];
					if (curProtocol === 'https') {
						bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';        
					}
					else {
						bp.src = 'http://push.zhanzhang.baidu.com/push.js';
					}
					var s = document.getElementsByTagName(\"script\")[0];
					s.parentNode.insertBefore(bp, s);
				})();
			</script>";
		return $ret;
	}	
}

class mobileplugin_exx_autoseo extends plugin_exx_autoseo {
	function global_header_mobile(){
		return $this->global_header();
	}
}