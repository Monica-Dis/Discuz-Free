<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
	if(!defined('IN_DISCUZ')) {
		exit('Access Denied');
	}

	function getmode($tid,$pid,$title,$msg){ 
		global $_G;
		$exx_tagseo = $_G['cache']['plugin']['exx_tagseo'];	
		if($exx_tagseo['hq']==2){
			return baiduKeyword($tid,$pid,$title,$msg);
		}else{
			return pullwordKeyword($tid,$pid,$title,$msg);
		}
	}
	
	
	function baiduKeyword($tid,$pid,$title,$msg){ 
		global $_G;
		$exx_tagseo = $_G['cache']['plugin']['exx_tagseo'];	
		if($exx_tagseo['jr']){
			$w=file_get_contents("http://www.baidu.com/s?wd=".urlencode($title));
		}else{
			$w=dfsockopen("http://www.baidu.com/s?wd=".urlencode($title)); 
		}	
		$w=str_replace(array("/r","/n","/t","/s"), '', $w);      
		preg_match('/<div id="rs">(.*?)<\/div>/iU',$w,$con);
		$list=$con[0];
		preg_match_all('/<a(.*?)>(.*?)<\/a>/i',$list,$content); 
		if($exx_tagseo['sl']){$content[2]=array_slice($content[2], 0, $exx_tagseo['sl']);}
		$result=implode(",",$content[2]); 
		if(!(CHARSET=='UTF-8')){$result=diconv($result,'UTF-8' ,CHARSET);}		
		print_r($return);
		$return=settag($tid,$pid,$result);
		if($_GET['debug'])print_r($return);
		return $return;
	}
	
	
	function pullwordKeyword($tid,$pid,$title,$msg){ 
		global $_G;
		$exx_tagseo = $_G['cache']['plugin']['exx_tagseo'];
		$xs=$exx_tagseo['xs']?$exx_tagseo['xs']:0.9;
		$tagarr=array();
		if(!(CHARSET=='UTF-8')){
			$title=diconv($title,CHARSET,'UTF-8');
		}
		$title=dhtmlspecialchars($title);
		$url ='http://api.pullword.com/get.php?source='.urlencode($title).'&param1=0&param2=1&json=1';
		if($exx_tagseo['jr']){
			$w=file_get_contents($url); 
		}else{
			$w=dfsockopen($url); 
		}
		$arr = json_decode($w,true);
		foreach($arr as $val){
			if($val['p']>$xs){
				$tagarr[]=$val['t'];
			}
		}
		$result=implode(",",$tagarr);
		$result=diconv($result,'UTF-8' ,CHARSET);
		$return=settag($tid,$pid,$result);
		return $return;
	
	}


	function settag($tid,$pid,$result){
		$newtagclass = new tag();
		$tags = $newtagclass->add_tag($result, $tid, 'tid');
		if($result) {
			loadcache('censor');
			C::t('forum_post')->update('tid:'.$tid, $pid, array(
			'tags' => $tags,
			));
		}
		if($tags){
			$tagarray = explode("\t", $tags);
			if($tagarray) {
				foreach($tagarray as $v) {
					if($v) {
						$tag = explode(',', $v);
						$ptag_array[] = $tag;
					}
				}
			}
		}
		return $ptag_array;
	}