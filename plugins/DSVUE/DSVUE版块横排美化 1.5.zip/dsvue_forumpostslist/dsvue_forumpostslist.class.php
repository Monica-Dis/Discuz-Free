<?php
//DisM!应用中心：dism.taobao.com
//更多商业插件/模版下载 就在DisM!应用中心
//本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class plugin_dsvue_forumpostslist {
}
class plugin_dsvue_forumpostslist_forum extends plugin_dsvue_forumpostslist {
    //嵌入点插入
    function index_forum_extra_output() {
        global $_G, $catlist, $forumlist, $forum, $cacheop, $odmode, $gid;
        $cfg = array();
        $cfg = $_G['cache']['plugin']['dsvue_forumpostslist']; //缓存插件变量值
        $forumset = $cfg['forums'];
        $forumarr = unserialize($forumset);
		$odmode = $cfg['odmode'];
        $return = array();
        //时间格式
        if ($cfg[rtifomod] == 1) {
            if ($cfg[timemode] == '1') {
                $timemode = "u";
            }
            if ($cfg[timemode] == '2') {
                $timemode = "Y-m-d";
            }
            if ($cfg[timemode] == '3') {
                $timemode = "m-d";
            }
        }
        //下划线模式
        if ($cfg[bordoff] == 1) {
            if ($cfg[bordmod] == 1) {
                $bordmod = "dashed";
            }
            if ($cfg[bordmod] == 2) {
                $bordmod = "dotted";
            }
            if ($cfg[bordmod] == 3) {
                $bordmod = "solid";
            }
        }
        //分割线模式
        if ($cfg[topbordoff] == 1) {
            if ($cfg[topbordmod] == 2) {
                $topbordmod = "dashed";
            }
            if ($cfg[topbordmod] == 3) {
                $topbordmod = "dotted";
            }
            if ($cfg[topbordmod] == 1) {
                $topbordmod = "solid";
            }
        }
        //帖子行距
        if (empty($cfg[tzlh])) {
            $cfg[tzlh] = 20;
        }
        //帖子字号
        if (empty($cfg[tzsize])) {
            $cfg[tzsize] = 12;
        }
		
        @include (DISCUZ_ROOT . './source/language/forum/lang_template.php'); //载入语言包
        $cache_file = DISCUZ_ROOT . './data/sysdata/cache_dsvue_forumpostslist.php';
        //当前时间跟缓存文件的时间差大于系统设定的缓存更新时间则开始更新缓存
        if (($_G['timestamp'] - @filemtime($cache_file)) > $cfg['cctime'] * 60) {
			
			//f start
            foreach ($forumlist as $forum) {
                $cat = $catlist[$forum[fup]];
                if ($catlist[$forum[fup]][forumcolumns] >= 2) {
                    //开启功能的版块开始
                    if (in_array($forum[fid], $forumarr)) {
                        //获取子版块
                        if ($cfg[subforum] == 1) {
                            $ttt = DB::result_first("SELECT group_concat(fid order by fid asc separator ',') FROM " . DB::table('forum_forum') . " WHERE fup=$forum[fid]");
                            if (empty($ttt)) {
                                $fiorumids = $forum[fid];
                            } else {
                                $fiorumids = $forum[fid] . ',' . $ttt;
                            }
                        } else {
                            $fiorumids = $forum[fid];
                        }
                        //获取帖子列表
						   //排序方式
						    if($odmode==1){
								$orderby='dateline';
							}
							elseif($odmode==2){
								$orderby='lastpost';
							}
						   //排序方式完毕
                        if ($cfg[tzlstoff] == 1) {
                            $sql = "SELECT * FROM " . DB::table('forum_thread') . " a LEFT JOIN " . DB::table('forum_post') . " b on b.fid=a.fid and b.tid=a.tid LEFT JOIN " . DB::table('forum_threadclass') . " c on c.fid=a.fid and c.typeid=a.typeid WHERE a.fid in ($fiorumids) and a.displayorder in (0,1,2,3) and a.closed=0 and b.first=1 and b.invisible=0 ORDER BY a.$orderby DESC LIMIT $cfg[threads]";
                            $query = DB::query($sql);
                            $mrcts = array();
                            while ($mrct = DB::fetch($query)) {
                                $mrcts[] = $mrct;
                            }
                        }
                        include template('dsvue_forumpostslist:threadlst');
                        //获取帖子列表结束
                        $return[$forum[fid]] = $lst;
                    }
                    //开启功能的版块结束
                    
                }

            }
			//f end
			
            
            $contents[] = $return;
			
		if($cfg['cctime']!=0){
				require_once libfile('function/cache');
            $cacheArray.= "\$contents=" . arrayeval($contents) . ";\n";
			if($gid==0){
            writetocache('dsvue_forumpostslist', $cacheArray);
			}
		}
		else{
        @unlink(DISCUZ_ROOT.'./data/sysdata/cache_dsvue_forumpostslist.php');
        }
			
            $return = $contents[0];
            return $return;
        } else {
            //读取缓存数据
            include_once DISCUZ_ROOT . './data/sysdata/cache_dsvue_forumpostslist.php';
            $return = $contents[0];
            return $return;
        }
    }
    //嵌入点结束
    
}
//From: Dism·taobao·com
?>