<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_admin_attach Class
 * @package plugin
 * @subpackage ror
 * @category ror_attach_upload
 * @author ror
 * @link
 */
class lib_admin_attach
{
    protected static $table = 'admin_attach';

    protected static $limit = 10;
    protected static $limit_max = 90;
    
    public static function index()
    {
        lib_base::header(lib_base::admin_url('upload_list'));
    }
    
    public static function upload_list()
    {
        global $_G;
        $escape['search'] = lib_base::escape($_GET['search']);
        $escape['field'] = lib_base::escape($_GET['field']);
    
        $page = $_GET['page'] ? intval($_GET['page']) : 1;
        $limit = $_GET['limit'] ? ($_GET['limit'] > self::$limit_max ? self::$limit_max : intval($_GET['limit'])) : self::$limit;
    
        $fields = array('id'=>'id','tid'=>'tid','pid'=>'pid','uid'=>'uid','filename'=>'filename','filesize'=>'filesize','dateline'=>'dateline','attachment'=>'attachment');
        $tool = array(
            '<a class="layui-btn" onclick="Func.window({url:\''.lib_base::admin_url('attachment_list').'\'})">'.lib_base::lang('attachment_manage').'</a>',
            '<a class="layui-btn" onclick="Func.post({url:\''.lib_base::admin_url('upload_delete').'\'})">'.lib_base::lang('batch_delete').'</a>',
        );
        $submit = lib_base::admin_url('upload_list').'&limit='.$limit;
    
        $fields_str = lib_func::field_str($fields);
        $offset = ($page - 1) * $limit;
    
        $where = '';
        if($escape['search'] && $escape['field'] && array_key_exists($escape['field'], $fields)){
            $where .= "WHERE ".$escape['field']."='".$escape['search']."'";
            $submit .= '&search='.$escape['search'].'&field='.$escape['field'];
        }
    
        $list = lib_base::table(self::$table)->upload_list($fields_str, $offset, $limit, $where);
        if($list){
            $host = $_G['siteurl'].'data/attachment/forum/';
            foreach($list as & $value){
                $value['filename'] = '<a href="'.$host.$value['attachment'].'" target="_blank">'.$value['filename'].'</a>';
                $value['filesize'] = number_format(($value['filesize'] / 1024 / 1024), 2).'M';
                unset($value['attachment']);
            }
        }
    
        $count = lib_base::table(self::$table)->upload_count($where);
        $page_count = ceil($count / $limit);
        $paging = lib_func::paging($page_count, $page, $submit.'&page=', $limit, $count);
        $search = lib_func::field_option(array('id'=>'id','tid'=>'tid','pid'=>'pid','uid'=>'uid'), $escape['field']);
    
        $formate['op'] = array(
            array('url'=>lib_base::admin_url('upload_delete'),'name'=>lib_base::lang('delete'),type=>3,'confirm'=>FALSE),
        );
    
        $formate['batch'] = 1;
        $formate['time'] = array('dateline');
        unset($fields['attachment']);
        $fields = lib_func::create_table($list, $fields, $formate);
    
        include lib_base::template('admin');
    }
    
    public static function upload_delete()
    {
        $ids = $_GET['batch'] ? $_GET['batch'] : intval($_GET['ids']);
        
        if(! $ids){
            lib_base::back_text(lib_base::lang('noselect'));
        }
        
        if(! lib_base::table(self::$table)->delete($ids)){
            lib_base::back_text(lib_base::lang('nodelete'));
        }
        
        lib_base::back_json(array('reload'=>1));
    }
    
    public static function attachment_list()
    {
        global $_G;
        
        $escape['search'] = lib_base::escape($_GET['search']);
        $escape['field'] = lib_base::escape($_GET['field']);
    
        $tableid = $_GET['tableid'] ? intval($_GET['tableid']) : 0;
        $page = $_GET['page'] ? intval($_GET['page']) : 1;
        $limit = $_GET['limit'] ? ($_GET['limit'] > self::$limit_max ? self::$limit_max : intval($_GET['limit'])) : self::$limit;
    
        $table_select = '<div class="layui-input-inline"><select lay-filter="tableid" name="tableid" id="tableid">';
        for($i = 0; $i <= 9; $i++){
            $selected = $tableid == $i ? ' selected' : '';
            $table_select .= '<option value="'.$i.'"'.$selected.'>forum_attachment_'.$i.'</option>';
        }
        $table_select .= '</select></div>';
        
        $fields = array('aid'=>'aid','tid'=>'tid','pid'=>'pid','uid'=>'uid','filename'=>'filename','filesize'=>'filesize','attachment'=>'attachment','isimage'=>'isimage','dateline'=>'dateline');
        $tool = array(
            $table_select,
            '<a class="layui-btn" onclick="Func.post({url:\''.lib_base::admin_url('attachment_delete').'\',confirm:1})">'.lib_base::lang('batch_delete').'</a>',
        );
        $submit = lib_base::admin_url('attachment_list').'&limit='.$limit.'&tableid='.$tableid;
    
        $fields_str = lib_func::field_str($fields);
        $offset = ($page - 1) * $limit;
    
        $where = '';
        if($escape['search'] && $escape['field'] && array_key_exists($escape['field'], $fields)){
            $where .= "WHERE ".$escape['field']."='".$escape['search']."'";
            $submit .= '&search='.$escape['search'].'&field='.$escape['field'];
        }
    
        $list = lib_base::table(self::$table)->attachment_list($tableid, $fields_str, $offset, $limit, $where);
        if($list){
            $host = $_G['siteurl'].'data/attachment/forum/';
            foreach($list as & $value){
                $value['filename'] = '<a href="'.$host.$value['attachment'].'" target="_blank">'.$value['filename'].'</a>';
                $value['filesize'] = number_format(($value['filesize'] / 1024 / 1024), 2).'M';
                unset($value['attachment']);
            }
        }
    
        $count = lib_base::table(self::$table)->attachment_count($tableid, $where);
        $page_count = ceil($count / $limit);
        $paging = lib_func::paging($page_count, $page, $submit.'&page=', $limit, $count);
        $search = lib_func::field_option(array('aid'=>'aid','tid'=>'tid','pid'=>'pid','uid'=>'uid','isimage'=>'isimage'), $escape['field']);
    
        $formate['op'] = array(
            array('url'=>lib_base::admin_url('attachment_delete').'&tableid='.$tableid,'name'=>lib_base::lang('delete'),type=>3),
        );
    
        $formate['batch'] = 1;
        $formate['time'] = array('dateline');
        unset($fields['attachment']);
        $fields = lib_func::create_table($list, $fields, $formate);
    
        $hidden = <<<EOT
<script type="text/javascript">
layui.use(['form','jquery'],function(){
    form = layui.form,
    $ = layui.jquery;
	form.on('select(tableid)', function(data){
        $('#form').submit();
    });
});
</script>
EOT;
        include lib_base::template('admin');
    }
    
    public static function attachment_delete()
    {
        global $_G;
        
        $ids = $_GET['batch'] ? $_GET['batch'] : array(intval($_GET['ids']));
        $tableid = intval($_GET['tableid']);
        
        if(! $ids){
            lib_base::back_text(lib_base::lang('noselect'));
        }
        
        $dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
        $dir .= 'forum/';
        
        foreach($ids as $aid)
        {
            $aid = intval($aid);
            
            $detail = lib_base::table(self::$table)->attachment_detail($tableid, $aid);
            if(! $detail){
                continue;
            }
            
            $filename = $dir.$detail['attachment'];

            if(file_exists($filename)){
                unlink($filename);
            }
            $thumb_postfix = '.thumb.jpg';
            if(file_exists($filename.$thumb_postfix)){
                unlink($filename.$thumb_postfix);
            }
            
            C::t('forum_attachment')->delete_by_id('aid', $aid);
            C::t('forum_attachment_n')->delete($tableid, $aid);
        }
 
        lib_base::back_json(array('reload'=>1));
    }
}