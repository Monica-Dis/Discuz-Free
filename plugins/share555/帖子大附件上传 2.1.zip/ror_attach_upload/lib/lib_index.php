<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once libfile('lib/base', 'plugin/'.PLUGIN_NAME);

/**
 * lib_index Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_index
{
    protected static $allow_actions = array(
        'index'=>array('class'=>'lib_index_attach','function'=>'cron_day'),
        
        'cron_day'=>array('class'=>'lib_index_attach','function'=>'cron_day'),
        'attach_upload'=>array('class'=>'lib_index_attach','function'=>'attach_upload'),
        'attach_upload_iframe'=>array('class'=>'lib_index_attach','function'=>'attach_upload_iframe'),
        'attach_uploaded'=>array('class'=>'lib_index_attach','function'=>'attach_uploaded'),
    );

    public function run()
    {
//         ini_set("display_errors", "On");
//         error_reporting(E_ALL);
        
        global $_G;
        
        $action = $_GET['act'] ? $_GET['act'] : 'index';
        if(! isset(self::$allow_actions[$action])) {
            showmessage(lib_base::lang('noaction'));
        }
        
        if(CHARSET == 'gbk' && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $_GET = lib_base::convert_utf8_to_gbk($_GET);
        }
        
        $op = self::$allow_actions[$action];
        
        require_once libfile(str_replace('lib_', 'lib/', $op['class']), 'plugin/'.PLUGIN_NAME);
        
        $class = $op["class"];
        $class = new $class();
        $function = $op["function"];
        $class->$function();
    }
}