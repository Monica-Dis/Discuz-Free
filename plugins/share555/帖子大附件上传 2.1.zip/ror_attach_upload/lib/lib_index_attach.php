<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_index_sitemap Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_index_attach
{
    protected static $table = 'index_attach';
    
    public function __construct()
    {
        set_time_limit(0);
    }
    
    //本地发布
    public static function cron_day()
    {
        global $_G;
        
        //删除临时缓存碎片数据
        $local_path = DISCUZ_ROOT.'data/plugindata/'.PLUGIN_NAME.'/';
        self::removeDir($local_path, 1);
        
        //删除未使用过的附件
        $time_latest = TIMESTAMP - 600;
        $sql = 'SELECT * FROM '.DB::table('plugin_ror_attach_upload').' WHERE tid=0 AND dateline<'.$time_latest;
        $upload_list = DB::fetch_all($sql);
        if($upload_list)
        {
            foreach($upload_list as $attach)
            {
                $upload_file_r = $attach['attachment'];
                $dir = ! getglobal('setting/attachdir') ? (DISCUZ_ROOT.'./data/attachment/') : getglobal('setting/attachdir');
                $from_type = 'forum';
                $dir = $dir.$from_type.'/';
                $upload_file_a = $dir.$upload_file_r;
                
                if(lib_base::table(self::$table)->delete($attach['id'])){
                    unlink($upload_file_a);
                }
            }
        }

        exit('success');
    }
    
    public static function removeDir($dirName, $root)
    {
        global $_G;
    
        if(! is_dir($dirName)){
            return FALSE;
        }
    
        $handle = @opendir($dirName);
        while(($file = @readdir($handle)) !== FALSE)
        {
            if($file != '.' && $file != '..')
            {
                $dir = $dirName.'/'.$file;
                if(is_dir($dir)){
                    self::removeDir($dir, 0);
                }else{
                    @unlink($dir);
                }
            }
        }
    
        closedir($handle);
    
        if($root == 1){
            return TRUE;
        }else{
            rmdir($dirName);
        }
    }
    
    /**
	 * 附件上传页
	 *
	 * @access public
	 * @param
	 * @return
	 */
    public function attach_upload()
    {
    	$tid = intval($_GET['tid']);
    	$pid = intval($_GET['pid']);

    	$settings = lib_base::settings();
    	
    	$url_attach_upload = lib_base::url('attach_upload_iframe').'&tid='.$tid.'&pid='.$pid;
    	
    	$ext = $settings['attach_extensions'] ? $settings['attach_extensions'] : '';
    	    	
        include lib_base::template('attach_upload');
    }
    
    /**
     * 附件上传页
     *
     * @access public
     * @param
     * @return
     */
    public function attach_upload_iframe()
    {
        $tid = intval($_GET['tid']);
        $pid = intval($_GET['pid']);
    
        $lang_title = lib_base::settings('title');
        $lang_desc = lib_base::lang('attach_desc');
        $lang_button = lib_base::lang('attach_button');
        $lang_uploading = lib_base::lang('attach_uploading');
        $lang_complete = lib_base::lang('attach_complete');
        $lang_fail = lib_base::lang('attach_fail');
        
        $submit = lib_base::url('attach_uploaded').'&tid='.$tid.'&pid='.$pid;
    
        include lib_base::template('attach_upload_iframe');
    }
    
    /**
     * 附件上传
     *
     * @access public
     * @param
     * @return
     */
    public function attach_uploaded()
    {
        global $_G;
        
        $tid = intval($_GET['tid']);
        $pid = intval($_GET['pid']);

        if(! $_G['uid']){
            header("HTTP/1.0 404 Not Login");
            exit;
        }
        
//         if(! $tid || ! $pid){
//             header("HTTP/1.0 404 Not param");
//             exit;
//         }
        
        $ext = strtolower(substr(strrchr($_GET['resumableFilename'], '.'), 1));
        $settings = lib_base::settings();
        $ext_limit = $settings['attach_extensions'] ? $settings['attach_extensions'] : '';
        if($ext_limit && strpos($ext_limit, $ext) ===  FALSE){
            header("HTTP/1.0 403 Forbidden");
            exit;
        }

        $path = DISCUZ_ROOT.'data/plugindata/'.PLUGIN_NAME.'/';
        if(! is_dir($path)){
            mkdir($path);
            chmod($path, 0777);
        }
        
        //check if request is GET and the requested chunk exists or not. this makes testChunks work
        if($_SERVER['REQUEST_METHOD'] === 'GET')
        {
            $_GET['resumableIdentifier'] = lib_base::table(self::$table)->upload_file_identifier($_G['uid'], $_GET['resumableFilename']);
            $_GET['resumableFilename'] = lib_base::table(self::$table)->upload_file_rename($_GET['resumableFilename']);
            	
            $temp_dir = $path.$_GET['resumableIdentifier'].'/';
            $chunk_file = $temp_dir.$_GET['resumableFilename'].'.part'.$_GET['resumableChunkNumber'];
            if(file_exists($chunk_file)){
                header("HTTP/1.0 200 Ok");
                exit;
            }else{
                header("HTTP/1.0 404 Not Found");
                exit;
            }
        }
        
        // loop through files and move the chunks to a temporarily created directory
        if(empty($_FILES)){
            lib_base::back_text('fail');
        }
        
        foreach($_FILES as $file)
        {
            // check the error status
            if($file['error'] != 0){
                //_log('error '.$file['error'].' in file '.$_POST['resumableFilename']);
                continue;
            }
             
            // init the destination file (format <filename.ext>.part<#chunk>
            // the file is stored in a temporary directory
            $resumableFilename_bak = $_GET['resumableFilename'];
            $_GET['resumableIdentifier'] = lib_base::table(self::$table)->upload_file_identifier($_G['uid'], $_GET['resumableFilename']);
            $_GET['resumableFilename'] = lib_base::table(self::$table)->upload_file_rename($_GET['resumableFilename']);
        
            $temp_dir = $path.$_GET['resumableIdentifier'];
            $dest_file = $temp_dir.'/'.$_GET['resumableFilename'].'.part'.$_GET['resumableChunkNumber'];
        
            if(! $_GET['resumableFilename']){
                header("HTTP/1.0 404 Not Found");
                exit;
            }
        
            // create the temporary directory
            if(! is_dir($temp_dir)){
                mkdir($temp_dir);
                chmod($temp_dir, 0777);
            }
             
            // move the temporary file
            if(! move_uploaded_file($file['tmp_name'], $dest_file)){
                //_log('Error saving (move_uploaded_file) chunk '.$_POST['resumableChunkNumber'].' for file '.$_POST['resumableFilename']);
            }else{
                
                //文件名转码
                if(CHARSET == 'gbk'){
                     $resumableFilename_bak = lib_base::string_utf8_to_gbk($resumableFilename_bak);
                }
                
                chmod($dest_file, 0777);
                // check if all the parts present, and create the final destination file
                lib_base::table(self::$table)->createFileFromChunks($_G['uid'], $tid, $pid, $temp_dir, $_GET['resumableFilename'], $_GET['resumableChunkSize'], $_GET['resumableTotalSize'], $resumableFilename_bak);
            }
        }
        
        lib_base::back_text('success', 0);
    }
}