<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

class plugin_ror_attach_upload
{
    
}

class plugin_ror_attach_upload_forum extends plugin_ror_attach_upload
{    
    var $plugin_name = 'ror_attach_upload';
    
    function viewthread_postaction_output()
    {
        global $_G, $postlist;

        $manger = array();
        
        $settings = $_G['cache']['plugin'][$this->plugin_name];

        $open_group = unserialize($settings['open_group']);
        $open_forum = unserialize($settings['open_forum']);

        if(! in_array($_G['groupid'], $open_group)){
            return $manger;
        }

        if(! in_array($_G['fid'], $open_forum)){
            return $manger;
        }

        $lang_upload = lang('plugin/'.$this->plugin_name, 'upload_attach');
        $lang_upload_title = lang('plugin/'.$this->plugin_name, 'attach_title');

        $i = 0;
        foreach($postlist as $value){
            $url = 'plugin.php?id=ror_attach_upload&act=attach_upload&tid='.$value['tid'].'&pid='.$value['pid'];
            $manger[$i] = '<a title="'.$lang_upload_title.'" href="javascript:;" onclick="hideWindow(\'mods\');showWindow(\'mods\', \''.$url.'\', \'get\', 0);">'.$lang_upload.'</a>';
            
            $i++;
        }

        return $manger;
    }
    
    function post_editorctrl_left_output()
    {
        global $_G;
        
        $html = '';
        
        $settings = $_G['cache']['plugin'][$this->plugin_name];
        
        $open_group = unserialize($settings['open_group']);
        $open_forum = unserialize($settings['open_forum']);
        
        if(! in_array($_G['groupid'], $open_group)){
            return $html;
        }
        
        if(! in_array($_G['fid'], $open_forum)){
            return $html;
        }
        
        $lang_name = lang('plugin/'.$this->plugin_name, 'attach_name');
        $lang_title = lang('plugin/'.$this->plugin_name, 'attach_title');

        $url = 'plugin.php?id=ror_attach_upload&act=attach_upload&tid=0&pid=0';
        $html = '<a onclick="hideWindow(\'mods\');showWindow(\'mods\', \''.$url.'\', \'get\', 0);" title="'.$lang_title.'" href="javascript:;" style="background:url(/source/plugin/ror_attach_upload/public/images/attach.png) no-repeat center 0;background-size: 80%;">'.$lang_name.'</a>';
        
        return $html;
    }
    
    function viewthread_fastpost_ctrl_extra_output()
    {
        global $_G;
    
        $html = '';
    
        $settings = $_G['cache']['plugin'][$this->plugin_name];
    
        $open_group = unserialize($settings['open_group']);
        $open_forum = unserialize($settings['open_forum']);
    
        if(! in_array($_G['groupid'], $open_group)){
            return $html;
        }
    
        if(! in_array($_G['fid'], $open_forum)){
            return $html;
        }
    
        $lang_name = lang('plugin/'.$this->plugin_name, 'attach_name');
        $lang_title = lang('plugin/'.$this->plugin_name, 'attach_title');
    
        $url = 'plugin.php?id=ror_attach_upload&act=attach_upload&tid=0&pid=0';
        $html = '<a href="javascript:;" style="float:left;display:block;margin-top:3px;width:20px;height:20px;background:url(/source/plugin/ror_attach_upload/public/images/attach.png) no-repeat center 0;background-size: 80%;" title="'.$lang_title.'" class="fat" onclick="hideWindow(\'mods\');showWindow(\'mods\', \''.$url.'\', \'get\', 0);"> </a>';

        return $html;
    }
    
    function post_ror_attach_upload_message($param)
    {
        global $_G;

        $html = '';
        
        $settings = $_G['cache']['plugin'][$this->plugin_name];
        
        $open_group = unserialize($settings['open_group']);
        $open_forum = unserialize($settings['open_forum']);
        
        if(! in_array($_G['groupid'], $open_group)){
            return $html;
        }
        
        if(! in_array($_G['fid'], $open_forum)){
            return $html;
        }
        
        $uid = $_G['uid'];
        $sql = 'SELECT * FROM '.DB::table('plugin_ror_attach_upload').' WHERE uid='.$uid.' AND tid=0';
        $upload_list = DB::fetch_all($sql);
        if(! $upload_list){
            return $html;
        }
   
        $result = $param['param'];
        foreach($upload_list as $value){
            C::t('#'.$this->plugin_name.'#index_attach')->post_attachment_add($uid, $result[2]['tid'], $result[2]['pid'], $value, $settings);
        }
    }
}

class plugin_ror_attach_upload_group extends plugin_ror_attach_upload
{
    var $plugin_name = 'ror_attach_upload';
    
    function viewthread_postaction_output()
    {
        global $_G, $postlist;

        $manger = array();
        
        $settings = $_G['cache']['plugin'][$this->plugin_name];

        $open_group = unserialize($settings['open_group']);
        $open_forum = unserialize($settings['open_forum']);

        if(! in_array($_G['groupid'], $open_group)){
            return $manger;
        }

        if(! in_array($_G['fid'], $open_forum)){
            return $manger;
        }

        $i = 0;
        foreach($postlist as $value){
            $url = 'plugin.php?id=ror_attach_upload&act=attach_upload&tid='.$value['tid'].'&pid='.$value['pid'];
            $manger[$i] = '<a href="javascript:;" onclick="hideWindow(\'mods\');showWindow(\'mods\', \''.$url.'\', \'get\', 0);">'.lang('plugin/'.$this->plugin_name, 'upload_attach').'</a>';
            
            $i++;
        }

        return $manger;
    }
    
    function post_editorctrl_left_output()
    {
        global $_G;
    
        $html = '';
    
        $settings = $_G['cache']['plugin'][$this->plugin_name];
    
        $open_group = unserialize($settings['open_group']);
        $open_forum = unserialize($settings['open_forum']);
    
        if(! in_array($_G['groupid'], $open_group)){
            return $html;
        }
    
        if(! in_array($_G['fid'], $open_forum)){
            return $html;
        }
    
        $url = 'plugin.php?id=ror_attach_upload&act=attach_upload&tid=0&pid=0';
        $html = '<a onclick="hideWindow(\'mods\');showWindow(\'mods\', \''.$url.'\', \'get\', 0);" title="'.lang('plugin/'.$this->plugin_name, 'attach_title').'" href="javascript:;" style="background:url(/source/plugin/ror_attach_upload/public/images/attach.png) no-repeat center 0;background-size: 80%;">'.lang('plugin/'.$this->plugin_name, 'attach_name').'</a>';
    
        return $html;
    }
    
    function post_ror_attach_upload_message($param)
    {
        global $_G;
    
        $html = '';
    
        $settings = $_G['cache']['plugin'][$this->plugin_name];
    
        $open_group = unserialize($settings['open_group']);
        $open_forum = unserialize($settings['open_forum']);
    
        if(! in_array($_G['groupid'], $open_group)){
            return $html;
        }
    
        if(! in_array($_G['fid'], $open_forum)){
            return $html;
        }
    
        $uid = $_G['uid'];
        $sql = 'SELECT * FROM '.DB::table('plugin_ror_attach_upload').' WHERE uid='.$uid.' AND tid=0';
        $upload_list = DB::fetch_all($sql);
        if(! $upload_list){
            return $html;
        }
         
        $result = $param['param'];
        foreach($upload_list as $value){
            C::t('#'.$this->plugin_name.'#index_attach')->post_attachment_add($uid, $result[2]['tid'], $result[2]['pid'], $value, $settings);
        }
    }
}