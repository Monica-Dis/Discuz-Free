<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

define('PLUGIN_NAME', 'ror_attach_upload');

require_once libfile('lib/admin', 'plugin/'.PLUGIN_NAME);

$admin = new lib_admin();

$admin->run();