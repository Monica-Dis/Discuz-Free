<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
    exit('Access denied');
}

$plugin_name = 'ror_attach_upload';

$sql = <<<EOT
    
CREATE TABLE IF NOT EXISTS `pre_plugin_{$plugin_name}` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `tid` int(10) unsigned NOT NULL DEFAULT '0',
 `pid` int(10) unsigned NOT NULL DEFAULT '0',
 `uid` int(10) unsigned NOT NULL DEFAULT '0',
 `dateline` int(10) unsigned NOT NULL DEFAULT '0',
 `filename` varchar(255) NOT NULL DEFAULT '',
 `filesize` int(10) unsigned NOT NULL DEFAULT '0',
 `attachment` varchar(255) NOT NULL DEFAULT '',
 PRIMARY KEY (`id`),
 KEY `tid` (`tid`),
 KEY `uid` (`uid`),
 KEY `pid` (`pid`),
 KEY `uid_tid` (`uid`,`tid`)
) ENGINE=InnoDB;

EOT;

runquery($sql);

$finish = true;