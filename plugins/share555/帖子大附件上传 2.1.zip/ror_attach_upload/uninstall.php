<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access denied');
}

$plugin_name = 'ror_attach_upload';

$sql = <<<EOT

DROP TABLE IF EXISTS pre_plugin_{$plugin_name};

EOT;

runquery($sql);

//删除多余缓存
$local_path = DISCUZ_ROOT.'data/plugindata/'.$plugin_name.'/';
removeDir($local_path);
function removeDir($dirName)
{
    if(! is_dir($dirName)){
        return FALSE;
    }

    $handle = @opendir($dirName);
    while(($file = @readdir($handle)) !== FALSE)
    {
        if($file != '.' && $file != '..'){
            $dir = $dirName.'/'.$file;
            if(is_dir($dir)){
                removeDir($dir);
            }else{
                @unlink($dir);
            }
        }
    }

    closedir($handle);

    rmdir($dirName);
}

$finish = true;