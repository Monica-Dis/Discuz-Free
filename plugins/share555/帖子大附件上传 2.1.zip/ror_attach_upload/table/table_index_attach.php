<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_index_attach extends discuz_table
{
    public function __construct()
    {
        parent::__construct();

        $this->_pk = 'id';
        $this->_table = 'plugin_ror_attach_upload';
    }
    
    var $pic_ext = array('jpg','png','jpeg','gif','bmp');
    
    /**
     * 添加附件
     *
     * @access public
     * @param int, int, int, string, string, string, string
     * @return array
     */
    public function attachment_add($uid, $tid, $pid, $upload_filename, $upload_file_a, $upload_file_r, $upload_fileext)
    {
        global $_G;
        
        $tableid = getattachtableid($tid);
        $attachment = array(
            'tid'=>$tid,
            'pid'=>$pid,
            'uid'=>$uid,
            'tableid'=>$tableid,
            'downloads'=>0
        );
        $aid = DB::insert('forum_attachment', $attachment, true);
        $filesize = filesize($upload_file_a);
        $forum_attachment_n = array(
            'aid'=>$aid,
            'tid'=>$tid,
            'pid'=>$pid,
            'uid'=>$uid,
            'dateline'=>TIMESTAMP,
            'filename'=>$upload_filename,
            'filesize'=>$filesize,
            'attachment'=>$upload_file_r,
            'remote'=>0,
            'readperm'=>0,
            'price'=>0,
            'isimage'=>0,
            'width'=>0,
            'thumb'=>0,
            'picid'=>0
        );
        
        $attachment = 0;
        if(in_array($upload_fileext, $this->pic_ext)){
            $imginfo = getimagesize($upload_file_a);
            if($imginfo !== FALSE) {
                $forum_attachment_n['isimage'] = 1;
                $forum_attachment_n['width'] = $imginfo[0];
            }
            $attachment  = 2;
        }else{
            $attachment  = 1;
        }
        
        C::t('forum_attachment_n')->insert('tid:'.$tid, $forum_attachment_n);
        
        //更新帖子附件状态
        $thread = C::t('forum_thread')->fetch($tid);
        $edit = array(
            'attachment'=>$attachment
        );
        
        if(lib_base::settings('is_add')){
            $post = C::t('forum_post')->fetch($thread['posttableid'], $pid);
            $edit['message'] = $post['message'].'
[attach]'.$aid.'[/attach]';
        }
        
        C::t('forum_post')->update($thread['posttableid'], $pid, $edit);

        //记录上传日志
        $add = array(
            'tid'=>$tid,
            'pid'=>$pid,
            'uid'=>$_G['uid'],
            'dateline'=>TIMESTAMP,
            'filename'=>$upload_filename,
            'filesize'=>$filesize,
            'attachment'=>$upload_file_r
        );
        $this->insert($add);
        
        
        //ftp上传
        $remote = 0;
        $thumb = 0;
        if(getglobal('setting/ftp/on'))
        {
            $from_type  = 'forum';
            $filepath = $upload_file_r;
            if(ftpcmd('upload', $from_type.'/'.$filepath) && (! $thumb || ftpcmd('upload', $from_type.'/'.getimgthumbname($filepath)))) {
                @unlink($_G['setting']['attachdir'].'/'.$from_type.'/'.$filepath);
                $thumb && @unlink($_G['setting']['attachdir'].'/'.$from_type.'/'.getimgthumbname($filepath));
                $remote = 1;
            }
            
            if($remote){
                C::t('forum_attachment_n')->update($tableid, $aid, array('remote'=>$remote));
            }
        }
        
        return TRUE;
    }
    
    /**
     * 添加附件
     *
     * @access public
     * @param int, int, int, string, string, string, string
     * @return array
     */
    public function attachment_add_no_tid($uid, $upload_filename, $upload_file_a, $upload_file_r)
    {
        global $_G;
        
        $filesize = filesize($upload_file_a);
        
        //记录上传日志
        $add = array(
            'tid'=>0,
            'pid'=>0,
            'uid'=>$_G['uid'],
            'dateline'=>TIMESTAMP,
            'filename'=>$upload_filename,
            'filesize'=>$filesize,
            'attachment'=>$upload_file_r
        );
        
        $this->insert($add);
    }
    
    /**
     * 添加附件
     *
     * @access public
     * @param int, int, int, string, string, string, string
     * @return array
     */
    public function post_attachment_add($uid, $tid, $pid, $attach, $settings)
    {
        global $_G;
    
        $upload_filename = $attach['filename'];
        $upload_file_r = $attach['attachment'];
        $upload_fileext = strtolower(substr(strrchr($upload_filename, '.'), 1));
        
        $dir = ! getglobal('setting/attachdir') ? (DISCUZ_ROOT.'./data/attachment/') : getglobal('setting/attachdir');
        $from_type = 'forum';
        $dir = $dir.$from_type.'/';
        $upload_file_a = $dir.$upload_file_r;
        
        $time_latest = TIMESTAMP - 300;
        if($time_latest > $attach['dateline']){
            if($this->delete($attach['id'])){
                unlink($upload_file_a);
            }
            return FALSE;
        }
        
        $tableid = getattachtableid($tid);
        $attachment = array(
            'tid'=>$tid,
            'pid'=>$pid,
            'uid'=>$uid,
            'tableid'=>$tableid,
            'downloads'=>0
        );
        $aid = DB::insert('forum_attachment', $attachment, true);
        $filesize = filesize($upload_file_a);
        $forum_attachment_n = array(
            'aid'=>$aid,
            'tid'=>$tid,
            'pid'=>$pid,
            'uid'=>$uid,
            'dateline'=>TIMESTAMP,
            'filename'=>$upload_filename,
            'filesize'=>$filesize,
            'attachment'=>$upload_file_r,
            'remote'=>0,
            'readperm'=>0,
            'price'=>0,
            'isimage'=>0,
            'width'=>0,
            'thumb'=>0,
            'picid'=>0
        );
    
        $attachment = 0;
        if(in_array($upload_fileext, $this->pic_ext)){
            $imginfo = getimagesize($upload_file_a);
            if($imginfo !== FALSE) {
                $forum_attachment_n['isimage'] = 1;
                $forum_attachment_n['width'] = $imginfo[0];
            }
            $attachment  = 2;
        }else{
            $attachment  = 1;
        }
    
        C::t('forum_attachment_n')->insert('tid:'.$tid, $forum_attachment_n);
    
        //更新帖子附件状态
        $thread = C::t('forum_thread')->fetch($tid);
        $edit = array(
            'attachment'=>$attachment
        );
    
        if($settings['is_add']){
            $post = C::t('forum_post')->fetch($thread['posttableid'], $pid);
            $edit['message'] = $post['message'].'
[attach]'.$aid.'[/attach]';
        }
    
        C::t('forum_post')->update($thread['posttableid'], $pid, $edit);
    
        //更新上传日志
        $edit = array(
            'tid'=>$tid,
            'pid'=>$pid,
        );
        $this->update($attach['id'], $edit);
    
        //ftp上传
        $remote = 0;
        $thumb = 0;
        if(getglobal('setting/ftp/on'))
        {
            $from_type  = 'forum';
            $filepath = $upload_file_r;
            if(ftpcmd('upload', $from_type.'/'.$filepath) && (! $thumb || ftpcmd('upload', $from_type.'/'.getimgthumbname($filepath)))) {
                @unlink($_G['setting']['attachdir'].'/'.$from_type.'/'.$filepath);
                $thumb && @unlink($_G['setting']['attachdir'].'/'.$from_type.'/'.getimgthumbname($filepath));
                $remote = 1;
            }
        
            if($remote){
                C::t('forum_attachment_n')->update($tableid, $aid, array('remote'=>$remote));
            }
        }
        
        return TRUE;
    }
    
    /**
     * 上传文件重命名
     *
     * @access public
     * @param
     * @return
     */
    public function upload_file_rename($file)
    {
        $ext = strtolower(substr(strrchr($file, '.'), 1));
        
        $allow_ext = lib_base::settings('attach_extensions');
        if($allow_ext && strpos($allow_ext, $ext) === FALSE){
            return '';
        }
    
        $file_new = substr(md5($file), 0, 10).'.'.$ext;
        
        return $file_new;
    }
    
    /**
     * 上传文件唯一标识
     *
     * @access public
     * @param
     * @return
     */
    public function upload_file_identifier($uid, $filename)
    {
        return $uid.'-'.substr(md5($filename), 0, 10);
    }
    
    /**
     * Check if all the parts exist, and
     * gather all the parts of the file together
     * @param string $dir - the temporary directory holding all the parts of the file
     * @param string $fileName - the original file name
     * @param string $chunkSize - each chunk size (in bytes)
     * @param string $totalSize - original file size (in bytes)
     */
    public function createFileFromChunks($uid, $tid, $pid, $temp_dir, $fileName, $chunkSize, $totalSize, $fileName_bak)
    {
        // count all the parts of this file
        $total_files = 0;
        foreach(scandir($temp_dir) as $file){
            if(stripos($file, $fileName) !== FALSE){
                $total_files++;
            }
        }

        // check that all the parts are present
        // the size of the last part is between chunkSize and 2*$chunkSize
        if($total_files * $chunkSize <  ($totalSize - $chunkSize + 1)){
            return FALSE;
        }

        $ext = strtolower(substr(strrchr($fileName, '.'), 1));
        $upload_filename = date('His').strtolower(random(16)).'.'.$ext;
        $dir = ! getglobal('setting/attachdir') ? (DISCUZ_ROOT.'./data/attachment/') : getglobal('setting/attachdir');
        $from_type = 'forum';
        $dir = $dir.$from_type;
        list($y, $m, $d) = explode('-', date('Y-m-d', TIMESTAMP));
        if(! is_dir("$dir/$y$m")){
            mkdir("$dir/$y$m");
            chmod("$dir/$y$m", 0777);
        }
        if(! is_dir("$dir/$y$m/$d")){
            mkdir("$dir/$y$m/$d");
            chmod("$dir/$y$m/$d", 0777);
        }
        $savefilename = "$dir/$y$m/$d/";
        $upload_file_a = $savefilename.$upload_filename;
        $upload_file_r = "$y$m/$d/".$upload_filename;

        // create the final destination file
        if(($fp = fopen($upload_file_a, 'w')) !== FALSE){
            for($i=1; $i<=$total_files; $i++){
                if($i == 1){
                    chmod($upload_file_a, 0777);
                }
                fwrite($fp, file_get_contents($temp_dir.'/'.$fileName.'.part'.$i));
                //_log('writing chunk '.$i);
            }
            fclose($fp);
        }else{
            //_log('cannot create the destination file');
            return FALSE;
        }
    
        // rename the temporary directory (to avoid access from other
        // concurrent chunks uploads) and than delete it
//         if(rename($temp_dir, $temp_dir.'_UNUSED')){
//             $this->rrmdir($temp_dir.'_UNUSED');
//         }else{
//             $this->rrmdir($temp_dir);
//         }
        $this->rrmdir($temp_dir);
        
        if($tid && $pid){
            $this->attachment_add($uid, $tid, $pid, $fileName_bak, $upload_file_a, $upload_file_r, $ext);
        }else{
            $this->attachment_add_no_tid($uid, $fileName_bak, $upload_file_a, $upload_file_r);
        }
    }
    
    /**
     * Delete a directory RECURSIVELY
     * @param string $dir - directory path
     * @link http://php.net/manual/en/function.rmdir.php
     */
    public function rrmdir($dir)
    {
        if(is_dir($dir))
        {
            $objects = scandir($dir);
            foreach($objects as $object)
            {
                if($object != '.' && $object != '..'){
                    if(filetype($dir.'/'.$object) == 'dir'){
                        $this->rrmdir($dir.'/'.$object);
                    }else{
                        unlink($dir.'/'.$object);
                    }
                }
            }
    
            reset($objects);
    
            rmdir($dir);
        }
    }
}