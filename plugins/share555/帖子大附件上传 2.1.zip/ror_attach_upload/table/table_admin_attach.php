<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_admin_attach extends discuz_table
{
    public function __construct()
    {
        parent::__construct();

        $this->_pk = 'id';
        $this->_table = 'plugin_ror_attach_upload';
    }
    
    /**
     * 上传列表
     *
     * @access public
     * @param string, int, int, string
     * @return array
     */
    public function upload_list($fields, $offset, $limit, $where = '')
    {
        $sql = 'SELECT '.$fields.' FROM '.DB::table($this->_table).'
               '.$where.'
               ORDER BY id DESC LIMIT '.$offset.','.$limit;

        return DB::fetch_all($sql);
    }
    
    /**
     * 上传统计
     *
     * @access public
     * @param string
     * @return int
     */
    public function upload_count($where = '')
    {
        $sql = 'SELECT COUNT(*) FROM '.DB::table($this->_table).'
    	       '.$where;
    
        return DB::result_first($sql);
    }
    
    /**
     * 附件列表
     *
     * @access public
     * @param int, string, int, int, string
     * @return array
     */
    public function attachment_list($tableid, $fields, $offset, $limit, $where = '')
    {
        $sql = 'SELECT '.$fields.' FROM '.DB::table('forum_attachment_'.$tableid).'
               '.$where.'
               ORDER BY aid DESC LIMIT '.$offset.','.$limit;
    
        return DB::fetch_all($sql);
    }
    
    /**
     * 附件统计
     *
     * @access public
     * @param int, string
     * @return int
     */
    public function attachment_count($tableid, $where = '')
    {
        $sql = 'SELECT COUNT(*) FROM '.DB::table('forum_attachment_'.$tableid).'
    	       '.$where;
    
        return DB::result_first($sql);
    }
    
    /**
     * 附件详情
     *
     * @access public
     * @param int, int
     * @return array
     */
    public function attachment_detail($tableid, $aid)
    {
        $sql = 'SELECT * FROM '.DB::table('forum_attachment_'.$tableid).' WHERE aid='.$aid;
    
        return DB::fetch_first($sql);
    }
}