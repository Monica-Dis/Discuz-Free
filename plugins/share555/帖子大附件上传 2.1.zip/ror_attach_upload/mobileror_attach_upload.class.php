<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_ror_attach_upload
{

}

class mobileplugin_ror_attach_upload_forum extends mobileplugin_ror_attach_upload
{
    var $plugin_name = 'ror_attach_upload';
    
    function post_bottom_mobile()
    {
        global $_G;
        
        $html = '';
        
        $settings = $_G['cache']['plugin'][$this->plugin_name];
        
        $open_group = unserialize($settings['open_group']);
        $open_forum = unserialize($settings['open_forum']);
        
        if(! in_array($_G['groupid'], $open_group)){
            return $html;
        }
        
        if(! in_array($_G['fid'], $open_forum)){
            return $html;
        }
        
        $url_attach_upload = 'plugin.php?id='.$this->plugin_name.'&act=attach_upload_iframe&tid=0&pid=0';
        $html = '<iframe src="'.$url_attach_upload.'" width="100%" height="120" frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes"></iframe>';
       
        return $html;
    }
    
    function post_ror_attach_upload_message($param)
    {
        global $_G;
    
        $html = '';
    
        $settings = $_G['cache']['plugin'][$this->plugin_name];
    
        $open_group = unserialize($settings['open_group']);
        $open_forum = unserialize($settings['open_forum']);
    
        if(! in_array($_G['groupid'], $open_group)){
            return $html;
        }
    
        if(! in_array($_G['fid'], $open_forum)){
            return $html;
        }
    
        $uid = $_G['uid'];
        $sql = 'SELECT * FROM '.DB::table('plugin_ror_attach_upload').' WHERE uid='.$uid.' AND tid=0';
        $upload_list = DB::fetch_all($sql);
        if(! $upload_list){
            return $html;
        }
         
        $result = $param['param'];
        foreach($upload_list as $value){
            C::t('#'.$this->plugin_name.'#index_attach')->post_attachment_add($uid, $result[2]['tid'], $result[2]['pid'], $value, $settings);
        }
    }
}