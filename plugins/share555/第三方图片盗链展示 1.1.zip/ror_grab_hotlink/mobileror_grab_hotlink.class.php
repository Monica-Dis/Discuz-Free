<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

class mobileplugin_ror_grab_hotlink
{
    
}

class mobileplugin_ror_grab_hotlink_forum extends mobileplugin_ror_grab_hotlink
{
    var $plugin_name = 'ror_grab_hotlink';
    
    function viewthread_bottom_mobile_output()
    {
        global $_G, $postlist;

        $js = array();
    
        $is_open_hotlink = $_G['cache']['plugin'][$this->plugin_name]['is_open_hotlink'];
    
        if(! $is_open_hotlink){
            return $js;
        }
    
        foreach($postlist as $key => $post){
            $rule = '/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/i';
            $postlist[$key]['message'] = preg_replace_callback($rule, $this->plugin_name.'_img_hotlink_wap', $post['message']);
        }
    
        return $js;
    }
}

function ror_grab_hotlink_img_hotlink_wap($matches)
{
    global $_G;

    $plugin_name = 'ror_grab_hotlink';
    $host = $_G['siteurl'];
    $url_hotlinking = $host.'plugin.php?id='.$plugin_name.'&act=pic&url=';

    if(stripos($matches[1], 'http') !== FALSE && stripos($matches[1], $host) === FALSE){
        $url = $url_hotlinking.urlencode($matches[1]);
        return str_replace($matches[1], $url, $matches[0]);
    }
    
    return $matches[0];
}