<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

class plugin_ror_grab_hotlink
{

}

class plugin_ror_grab_hotlink_forum extends plugin_ror_grab_hotlink
{    
    var $plugin_name = 'ror_grab_hotlink';
    
    function forumdisplay_thread_output()
    {
        global $_G;
        
        if($_G['forum']['picstyle'] == 0){
            return '';
        }

        $settings = $_G['cache']['plugin'][$this->plugin_name];

        if(! $settings['is_open_hotlink']){
            return '';
        }

        $tids = array();
        foreach($_G['forum_threadlist'] as $value){
            if(! $value['cover']){
                $tids[] = $value['tid'];
            }
        }
        
        if(! $tids){
            return '';
        }

        $sql = 'SELECT tid,message,htmlon FROM '.DB::table('forum_post').' WHERE tid IN('.implode(',', $tids).') AND first=1';
        $post_list = DB::fetch_all($sql);
        if(! $post_list){
            return '';
        }

        $cover_list = array();
        $cover_default = $settings['cover_default'] ? explode("\n", trim($settings['cover_default'])) : '';
        foreach($post_list as $value)
        {
            if($value['htmlon'] == 1){
                $pattern = '/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/i';
                preg_match($pattern, $value['message'], $result);
            }else{
                $pattern = '/\[img.*?\](.*?)\[\/img\]/';
                preg_match($pattern, $value['message'], $result);
            }
            
            if($result[1]){
                $cover_list[$value['tid']] = $result[1];
            }
        }

        $host = $_G['siteurl'];
        $url_hotlinking = $host.'plugin.php?id='.$this->plugin_name.'&act=pic&url=';
   
        foreach($_G['forum_threadlist'] as $key => $value)
        {
            if(! $value['cover'] && ! $value['coverpath']){
                if(isset($cover_list[$value['tid']])){
                    $_G['forum_threadlist'][$key]['cover'] = 1;
                    $_G['forum_threadlist'][$key]['coverpath'] = $url_hotlinking.urlencode($cover_list[$value['tid']]);
                }else if($cover_default){
                    $_G['forum_threadlist'][$key]['cover'] = 1;
                    $_G['forum_threadlist'][$key]['coverpath'] = $cover_default[array_rand($cover_default, 1)];
                }
            }
        }
        
        return '';
    }
    
    function viewthread_bottom_output()
    {
        global $_G, $postlist;
    
        $js = '';
        
        $is_open_hotlink = $_G['cache']['plugin'][$this->plugin_name]['is_open_hotlink'];
 
        if(! $is_open_hotlink){
            return $js;
        }

        if($_G['setting']['lazyload']){
            $rule = '/<img.*?[\s]file=[\'"](.*?)[\'"].*?>/i';
        }else{
            $rule = '/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/i';
        }
        
        foreach($postlist as $key => $post){
            $postlist[$key]['message'] = preg_replace_callback($rule, $this->plugin_name.'_img_hotlink', $post['message']);
        }

        return $js;
    }
}

class plugin_ror_grab_hotlink_portal extends plugin_ror_grab_hotlink
{
    var $plugin_name = 'ror_grab_hotlink';
    
    function view_article_bottom_output()
    {
        global $_G, $content;
    
        $js = '';

        $is_open_hotlink = $_G['cache']['plugin'][$this->plugin_name]['is_open_hotlink'];
        
        if(! $is_open_hotlink){
            return $js;
        }

        $rule = '/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/i';
        $content['content'] = preg_replace_callback($rule, $this->plugin_name.'_img_hotlink', $content['content']);
        
        return $js;
    }
    
    function ad_articlelist($param)
    {
        global $_G, $list;
        
        if($param['params'][2] == 1)
        {
            $settings = $_G['cache']['plugin'][$this->plugin_name];
            
            if(! $settings['is_open_hotlink']){
                return '';
            }
            
            $aids = array();
            foreach($list['list'] as $value){
                if(! $value['pic']){
                    $aids[] = $value['aid'];
                }
            }

            if(! $aids){
                return '';
            }
            
            $sql = 'SELECT aid,content FROM '.DB::table('portal_article_content').' WHERE aid IN('.implode(',', $aids).') AND pageorder=1';
            $article_list = DB::fetch_all($sql);
            if(! $article_list){
                return '';
            }

            $cover_list = array();
            $cover_default = $settings['cover_default'] ? explode("\n", trim($settings['cover_default'])) : '';
            foreach($article_list as $value)
            {
                $pattern = '/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/is';
                preg_match($pattern, $value['content'], $result);
            
                if($result[1]){
                    $cover_list[$value['aid']] = $result[1];
                }
            }

            $host = $_G['siteurl'];
            $url_hotlinking = $host.'plugin.php?id='.$this->plugin_name.'&act=pic&url=';
             
            foreach($list['list'] as $key => $value)
            {
                if(! $value['pic']){
                    if(isset($cover_list[$value['aid']])){
                        $list['list'][$key]['thumb'] = 1;
                        $list['list'][$key]['pic'] = $url_hotlinking.urlencode($cover_list[$value['aid']]);
                    }else if($cover_default){
                        $list['list'][$key]['thumb'] = 1;
                        $list['list'][$key]['pic'] = $cover_default[array_rand($cover_default, 1)];
                    }
                }
            }
        }

        return '';
    }
}

class plugin_ror_grab_hotlink_group extends plugin_ror_grab_hotlink
{
    var $plugin_name = 'ror_grab_hotlink';
    
    function forumdisplay_thread_output()
    {
        global $_G;
    
        if($_G['forum']['picstyle'] == 0){
            return '';
        }
        
        $settings = $_G['cache']['plugin'][$this->plugin_name];
    
        if(! $settings['is_open_hotlink']){
            return '';
        }
    
        $tids = array();
        foreach($_G['forum_threadlist'] as $value){
            if(! $value['cover']){
                $tids[] = $value['tid'];
            }
        }
    
        if(! $tids){
            return '';
        }
        
        $sql = 'SELECT tid,message,htmlon FROM '.DB::table('forum_post').' WHERE tid IN('.implode(',', $tids).') AND first=1';
        $post_list = DB::fetch_all($sql);
        if(! $post_list){
            return '';
        }
    
        $cover_list = array();
        $cover_default = $settings['cover_default'] ? explode("\n", trim($settings['cover_default'])) : '';
        foreach($post_list as $value)
        {
            if($value['htmlon'] == 1){
                $pattern = '/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/i';
                preg_match($pattern, $value['message'], $result);
            }else{
                $pattern = '/\[img.*?\](.*?)\[\/img\]/';
                preg_match($pattern, $value['message'], $result);
            }
    
            if($result[1]){
                $cover_list[$value['tid']] = $result[1];
            }
        }
    
        $host = $_G['siteurl'];
        $url_hotlinking = $host.'plugin.php?id='.$this->plugin_name.'&act=pic&url=';
         
        foreach($_G['forum_threadlist'] as $key => $value)
        {
            if(! $value['cover'] && ! $value['coverpath']){
                if(isset($cover_list[$value['tid']])){
                    $_G['forum_threadlist'][$key]['cover'] = 1;
                    $_G['forum_threadlist'][$key]['coverpath'] = $url_hotlinking.urlencode($cover_list[$value['tid']]);
                }else if($cover_default){
                    $_G['forum_threadlist'][$key]['cover'] = 1;
                    $_G['forum_threadlist'][$key]['coverpath'] = $cover_default[array_rand($cover_default, 1)];
                }
            }
        }
    
        return '';
    }
    
    function viewthread_bottom_output()
    {
        global $_G, $postlist;
    
        $js = '';
        
        $is_open_hotlink = $_G['cache']['plugin'][$this->plugin_name]['is_open_hotlink'];
        
        if(! $is_open_hotlink){
            return $js;
        }
    
        if($_G['setting']['lazyload']){
            $rule = '/<img.*?[\s]file=[\'"](.*?)[\'"].*?>/i';
        }else{
            $rule = '/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/i';
        }
        
        foreach($postlist as $key => $post){
            $postlist[$key]['message'] = preg_replace_callback($rule, $this->plugin_name.'_img_hotlink', $post['message']);
        }
    
        return $js;
    }
}

function ror_grab_hotlink_img_hotlink($matches)
{
    global $_G;

    $plugin_name = 'ror_grab_hotlink';
    $host = $_G['siteurl'];
    $url_hotlinking = $host.'plugin.php?id='.$plugin_name.'&act=pic&url=';

    if(stripos($matches[1], 'http') !== FALSE && stripos($matches[1], $host) === FALSE){
        $url = $url_hotlinking.urlencode($matches[1]);
        return str_replace($matches[1], $url, $matches[0]);
    }
    
    return $matches[0];
}