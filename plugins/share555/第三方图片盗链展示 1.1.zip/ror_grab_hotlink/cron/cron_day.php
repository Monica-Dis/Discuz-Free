<?php

//cronname:ror_grab_hotlink
//week:
//day:
//hour:00
//minute:00

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//您的计划任务脚本内容
$plugin_name = 'ror_grab_hotlink';

$url = $_G['siteurl'].'plugin.php?id='.$plugin_name;

dfsockopen($url);