<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_index_grab Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_index_grab
{
    public function __construct()
    {
        set_time_limit(300);
    }

    //本地发布
    public static function cron_day()
    {
        $local_path_grab = DISCUZ_ROOT.'data/plugindata/'.PLUGIN_NAME.'/';
        if(! self::removeDir($local_path_grab, 1)){
            exit('fail');
        }
        
        exit('success');
    }
    
    public static function removeDir($dirName, $root)
    {
        global $_G;
        
        if(! is_dir($dirName)){
            return FALSE;
        }
        
        loadcache(PLUGIN_NAME);
        $cache_day = $_G['cache'][PLUGIN_NAME]['image_cache_time'] ? $_G['cache'][PLUGIN_NAME]['image_cache_time'] : 10;
        
        $time_week = (int)date('Ymd', strtotime('-'.$cache_day.' day'));

        $handle = @opendir($dirName);
        while(($file = @readdir($handle)) !== FALSE)
        {
            if($file != '.' && $file != '..')
            {
                $dir = $dirName.'/'.$file;
                if(is_dir($dir)){
                    if($time_week > (int)$file){
                        self::removeDir($dir, 0);
                    }
                }else{
                    @unlink($dir);
                }
            }
        }
        
        closedir($handle);
    
        if($root == 1){
            return TRUE;
        }else{
            rmdir($dirName);
        }
    }
}