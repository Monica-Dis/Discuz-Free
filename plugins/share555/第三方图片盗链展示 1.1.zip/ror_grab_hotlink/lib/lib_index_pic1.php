<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_index_pic Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_index_pic
{
    protected static $ext_allow = array('jpg','png','jpeg','gif','bmp');
    protected static $local_filename = '';
    
    public static $timeout = 10;
    
    //referer处理
    public static $referer_list = array(
        'bdimg.com'=>'http://image.baidu.com/',
        'aicdn.com'=>'http://image.baidu.com/',
        'baidu.com'=>'http://image.baidu.com/',
        'mm131.me'=>'http://www.mm131.com/',
    );
    
    public static $headers = array(
        "Accept"=> "image/webp,image/apng,image/*,*/*;q=0.8",
        "Accept-Encoding"=> "gzip, deflate, br",
        "Accept-Language"=> "zh-CN,zh;q=0.9",
        'Cache-Control'=>'no-cache',
        "Connection"=> "keep-alive",
        "Pragma"=> "no-cache",
        "User-Agent"=> 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0 cb) like Gecko',
        //"Cookie"=>'',    
    );
    
    public static $userAgent = array(
        'Mozilla/5.0(Macintosh;U;IntelMacOSX10_6_8;en-us)AppleWebKit/534.50(KHTML,likeGecko)Version/5.1Safari/534.50',
        'Mozilla/5.0(Windows;U;WindowsNT6.1;en-us)AppleWebKit/534.50(KHTML,likeGecko)Version/5.1Safari/534.50',
        'Mozilla/5.0(Macintosh;IntelMacOSX10.6;rv:2.0.1)Gecko/20100101Firefox/4.0.1',
        'Mozilla/5.0(WindowsNT6.1;rv:2.0.1)Gecko/20100101Firefox/4.0.1',
        'Opera/9.80(Macintosh;IntelMacOSX10.6.8;U;en)Presto/2.8.131Version/11.11',
        'Opera/9.80(WindowsNT6.1;U;en)Presto/2.8.131Version/11.11',
        'Mozilla/5.0(Macintosh;IntelMacOSX10_7_0)AppleWebKit/535.11(KHTML,likeGecko)Chrome/17.0.963.56Safari/535.11',
        'Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1;Maxthon2.0)',
        'Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1;TencentTraveler4.0)',
        'Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1)',
        'Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1;TheWorld)',
        'Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1;Trident/4.0;SE2.XMetaSr1.0;SE2.XMetaSr1.0;.NETCLR2.0.50727;SE2.XMetaSr1.0)',
        'Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1;360SE)',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
    );
    
    public static function get_rand_ip()
    {
        $ip_long = array(
            array('607649792', '608174079'), // 36.56.0.0-36.63.255.255
            array('1038614528', '1039007743'), // 61.232.0.0-61.237.255.255
            array('1783627776', '1784676351'), // 106.80.0.0-106.95.255.255
            array('2035023872', '2035154943'), // 121.76.0.0-121.77.255.255
            array('2078801920', '2079064063'), // 123.232.0.0-123.235.255.255
            array('-1950089216', '-1948778497'), // 139.196.0.0-139.215.255.255
            array('-1425539072', '-1425014785'), // 171.8.0.0-171.15.255.255
            array('-1236271104', '-1235419137'), // 182.80.0.0-182.92.255.255
            array('-770113536', '-768606209'), // 210.25.0.0-210.47.255.255
            array('-569376768', '-564133889'), // 222.16.0.0-222.95.255.255
        );
    
        $rand_key = mt_rand(0, 9);
    
        return $ip = long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
    }
    
    public static function index()
    {
        global $_G;
        
        header("Content-type: image/jpeg");
        error_reporting(0);
        set_time_limit(30);
        
        $url = trim($_GET['url']);
        
        if(! $url){
            exit('no url');
        }

        $url = urldecode($url);

        //白名单
        $url_parse = parse_url($url);
        $whitelist = $_G['cache']['plugin'][PLUGIN_NAME]['host_whitelist'];
        if($whitelist){
            $whitelist  = explode("\n", $whitelist);
            foreach($whitelist as $value){
                if(strpos($url_parse['host'], trim($value)) !== FALSE){
                    header('Location:'.$url);
                    exit;
                }
            }
        }
        
        $ext = strtolower(substr($url, strrpos($url, '.') + 1));
   
        ! in_array($ext, self::$ext_allow) && $ext = self::$ext_allow[0];
        
        $local_filename = md5($url).'.'.$ext;
        $today = date('Ymd');
        
        $local_path_grab = DISCUZ_ROOT.'data/plugindata/'.PLUGIN_NAME.'/';
        $local_path_today = $local_path_grab.$today.'/';
        
        self::$local_filename = $local_path_today.$local_filename;
        if(file_exists(self::$local_filename)){
            echo file_get_contents(self::$local_filename);
            flush();
            exit;
        }
        
        if(! is_dir($local_path_grab)){
            mkdir($local_path_grab);
            chmod($local_path_grab, 0777);
        }
        if(! is_dir($local_path_today)){
            mkdir($local_path_today);
            chmod($local_path_today, 0777);
        }
        
        if($url_parse['scheme'] == 'http'){
            $ret = self::img_fsockopen($url);
        }else{
            $ret = self::img_curl($url, $url_parse);
        }

        //$ret = self::img_get($url);
        
        if($ret['success']){
            echo $ret['content'];
            flush();
        }else{
            header('Location:'.$url);
            exit;
        }
    }
    
    public static function img_check($content)
    {
        global $_G;
        
        file_put_contents(self::$local_filename, $content);
        chmod(self::$local_filename, 0777);
    
        $result = getimagesize(self::$local_filename);

        $pic_ext = ($result && $result['mime']) ? str_replace('image/', '', $result['mime']) : '';

        if(! in_array($pic_ext, self::$ext_allow)){
            unlink(self::$local_filename);
            return FALSE;
        }
        
        if(! $_G['cache']['plugin'][PLUGIN_NAME]['image_cache_time']){
            unlink(self::$local_filename);
        }
    
        return TRUE;
    }
    
    public static function img_get($url)
    {
        $url_parse = parse_url($url);
        
        $referer = $url_parse['scheme'].'://'.$url_parse['host'].'/';
        foreach(self::$referer_list as $key => $value){
            if(strpos($url_parse['host'], $key) !== FALSE){
                $referer = $value;
                break;
            }
        }
    
        $ip = self::get_rand_ip();
        
        $options = array(
            'http'=>array(
                'method'=>'GET',
                'timeout'=>self::$timeout,
                'header'=>
                "Accept: */*".
                "Accept-Encoding: gzip,deflate".
                "Accept-Language: en-US,en;q=0.8,zh-TW;q=0.6,zh;q=0.4".
                "Connection: keep-alive".
                "Content-Type: application/x-www-form-urlencoded; charset=UTF-8".
                "User-Agent: ".self::$userAgent[array_rand(self::$userAgent)]."\r\n".
                "Host: ".$url_parse['host']."\r\n".
                "Referer: ".$referer."\r\n".
                "CLIENT-IP: ".$ip."\r\n".
                "X-FORWARDED-FOR: ".$ip."\r\n"
            )
        );

        $content = file_get_contents($url, FALSE, stream_context_create($options));

        $status = self::img_check($content);
    
        return array(
            'success' => $status,
            'headers' => '',
            'content' => $content
        );
    }
    
    public static function img_curl($url, $url_param)
    {
        $referer = $url_param['scheme'].'://'.$url_param['host'].'/';
        foreach(self::$referer_list as $key => $value){
            if(strpos($url_param['host'], $key) !== FALSE){
                $referer = $value;
                break;
            }
        }

        $ip = self::get_rand_ip();
        $header = self::$headers;
        $header = array(
            'User-Agent: '.self::$userAgent[array_rand(self::$userAgent)],
            'CLIENT-IP'=>$ip,
            'X-FORWARDED-FOR'=>$ip
        );

        $ch = curl_init();
         
        curl_setopt($ch, CURLOPT_URL, $url);

        //是否将头文件的信息作为数据流输出(HEADER信息),这里保留报文
        //curl_setopt($ch, CURLOPT_HEADER, TRUE);
        //获取的信息以文件流的形式返回，而不是直接输出。
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE) ;
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, TRUE) ;
        //启用时会将服务器服务器返回的“Location:”放在header中递归的返回给服务器
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        
        curl_setopt ($ch, CURLOPT_REFERER, $referer);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        
        //curl_setopt ($ch, CURLOPT_COOKIE , $cookies);
        
        //设置连接等待时间,0不等待
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, self::$timeout);
        //设置curl允许执行的最长秒数
        curl_setopt($ch, CURLOPT_TIMEOUT, self::$timeout);
         
        if(strpos($url, 'https') !== FALSE){
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        }

        $content = curl_exec($ch);
        $error = curl_errno($ch);
        curl_close($ch);
    
        $status = FALSE;
        if($error == 0){
            $status = self::img_check($content);
        }
    
        if($status === FALSE){
            $content = file_get_contents($url);
            $status = self::img_check($content);
        }
    
        return array(
            'success' => $status,
            'headers' => '',
            'content' => $content
        );
    }
    
    public static function unTomChunked($content)
    {
        $pos = strpos($content, "\x0d\x0a");
        if ($pos > 0 && $pos < 20) {
            $content = substr($content, $pos + 2);
        }
        $content = preg_replace("/\x0d\x0a[0-9a-z]+?\x0d\x0a/is", '', $content);
        if (substr($content, -2) == "\r\n")
            $content = substr($content, 0, strlen($content) - 2);
        $content = str_replace("\r\n2000\r\n", '', $content);
        
        return $content;
    }
    
    public static function unGzip($content)
    {
        $singal = "\x1F\x8B\x08";
        $slen   = strlen($singal);
        if (substr($content, 0, $slen) == $singal) {
            $content = substr($content, 10);
            $content = gzinflate($content);
        }
        return $content;
    }
    
    public static function unChunked($content)
    {
        $pos = strpos($content, "\x0d\x0a");
        if ($pos > 0 && $pos < 20) {
            $content = substr($content, $pos + 2);
        }
        $content = preg_replace("/\x0d\x0a[0-9a-f]+?\x0d\x0a/is", '', $content);
        if (substr($content, -2) == "\r\n")
            $content = substr($content, 0, strlen($content) - 2);
        $content = str_replace("\r\n2000\r\n", '', $content);
        return $content;
    }
    
    public static function img_fsockopen($url, $nesting = false, $skipextchk = false)
    {
        $timeout = 30;
        $allowgz = TRUE;
    
        $arrUrl = parse_url($url);
        $status = false;

        $headers = '';
        if($arrUrl['scheme'] == 'http')
        {
            $strRef = $arrUrl['scheme'].'://'.$arrUrl['host'].'/';
            foreach(self::$referer_list as $key => $value){
                if(strpos($arrUrl['host'], $key)){
                    $strRef = $value;
                    break;
                }
            }
    
            $arrUrl['uri']  = ($arrUrl['path'] ? $arrUrl['path'] : '') . (isset($arrUrl['query']) ? '?' . $arrUrl['query'] : '') . (isset($arrUrl['fragment']) ? '#' . $arrUrl['fragment'] : '');
            $arrUrl['port'] = isset($arrUrl['port']) ? $arrUrl['port'] : '80';
    
            $strRequest = "GET " . $arrUrl['uri'] . " HTTP/1.0\r\n";
            $strRequest .= "Host: " . $arrUrl['host'] . "\r\n";
            $strRequest .= "Accept: */*\r\n";
            if ($allowgz) {
                $strRequest .= "Accept-Encoding: gzip, deflate\r\n";
            }
            if ($strRef != '') {
                $strRequest .= "Referer:$strRef\r\n";
            }
            $strRequest .= "User-Agent: Mozilla/4.0 (compatible; MSIE 4.00; Windows 2000)\r\n";
            $strRequest .= "Pragma: no-cache\r\n";
            $strRequest .= "Cache-Control: no-cache\r\n";
            $strRequest .= "Connection: close\r\n\r\n";
    
            @$fp = fsockopen($arrUrl['host'], $arrUrl['port'], $intError, $strError, $timeout);
            if (!$fp) {
                return false;
            }
            stream_set_timeout($fp, $timeout);
            @fwrite($fp, $strRequest);
            $bolHeader = true;
            $removed   = false;
            while ($block = fgets($fp, 1024)) {
                if ($bolHeader) {
                    if ($block == "\r\n") {
                        $bolHeader = false;
                    }
                    $headers .= $block;
                    if (!$removed && preg_match("/HTTP\/1\.\d?\s+?302\s+?.*?/is", $block)) {
                        $removed = true;
                    }
                } else {
                    break;
                }
            }
            $content = $block;
            if (!$removed) {
                while ($block = fread($fp, 10240)) {
                    $content .= $block;
                }
            }
            fclose($fp);
            $status = true;
        }
        if ((strstr($arrUrl['host'], '.tom.com') || strstr($arrUrl['host'], '.52vcd.com')) && !empty($content)) {
            self::unTomChunked($content);
            $unced = true;
        }
        $header_t = strtolower($headers);
        if ((strstr($header_t, ' chunked') || strstr($header_t, ':chunked')) && !$unced) {
            $content = self::unChunked($content);
        }
        if (strstr($header_t, ' gzip') || strstr($header_t, ':gzip') || substr($content, 0, 3) == "\x1f\x8b\x08") {
            $content = self::unGzip($content);
        }
        if (!$nesting && $removed) {
            if (preg_match("/Location:\s+?(.*?)(?=\r|\n|\s)/is", $headers, $match)) {
                $url = $match[1];
                return self::img_fsockopen($url, true, $skipextchk);
            } else {
                return false;
            }
        }
    
        $status = self::img_check($content);
        if($status === FALSE){
            $content = file_get_contents($url);
            $status = self::img_check($content);
        }

        if ($nesting) {
            return array(
                'url' => $url,
                'success' => $status,
                'headers' => $headers,
                'content' => $content
            );
        } else {
            return array(
                'success' => $status,
                'headers' => $headers,
                'content' => $content
            );
        }
    }
}