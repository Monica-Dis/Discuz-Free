<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_admin_grab Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_admin_grab
{
    public static function index()
    {
        lib_base::header(lib_base::admin_url('grab_auth'));
    }
    
    public static function grab_auth()
    {
        global $_G;

        $post = array(
            'host'=>$_SERVER['HTTP_HOST'],
            'plugin'=>PLUGIN_NAME
        );
        
        $result = lib_func::curl(lib_base::$grab_host.lib_base::$grab_api_auth, $post);
        
        $result = json_decode($result, TRUE);
        
        //转码兼容
        if(CHARSET == 'gbk'){
            $result = lib_base::convert_utf8_to_gbk($result);
        }
        
        if(! isset($result['state']) || $result['state'] != 0){
            lib_base::js_back_show($result['result']);
        }
        
        loadcache(PLUGIN_NAME);
        $cache = $_G['cache'][PLUGIN_NAME];
        $cache['auth'] = $result['result'];
        savecache(PLUGIN_NAME, $cache);
        
        lib_base::js_back_show(lib_base::lang('grab_auth_success'));
    }
}