<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

const PLUGIN_NAME = 'ror_grab_hotlink';

require_once libfile('lib/index', 'plugin/'.PLUGIN_NAME);

$index = new lib_index();

$index->run();