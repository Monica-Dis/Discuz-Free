<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

class plugin_ror_grab_discuz
{
    
}

class plugin_ror_grab_discuz_forum extends plugin_ror_grab_discuz
{    
    var $plugin_name = 'ror_grab_discuz';
    
    function viewthread_top_output()
    {
        global $_G, $page, $postlist;

        $css = '';
        
        $grab_post_css = $_G['cache']['plugin'][$this->plugin_name]['grab_post_css'];
        if($page == 1 && $grab_post_css){
            foreach($postlist as $post){
                $css = str_replace('pid', $post['pid'], $grab_post_css);
                break;
            } 
        }

        return $css;
    }
    
    function viewthread_bottom_output()
    {
        global $_G, $page, $postlist;
    
        $js = '';

        if($page != 1){
            return $js;
        }
        
        $is_open_hotlink = $_G['cache']['plugin'][$this->plugin_name]['is_open_hotlink'];
        if($is_open_hotlink){
            foreach($postlist as $key => $post){
                if(strpos($post, '<img') !== FALSE){
                    $rule = '/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/i';
                    $postlist[$key]['message'] = preg_replace_callback($rule, $this->plugin_name.'_img_hotlink', $post['message']);
                }
                break;
            }
        }
        
        return $js;
    }
}

class plugin_ror_grab_discuz_portal extends plugin_ror_grab_discuz
{
    var $plugin_name = 'ror_grab_discuz';
    
    function view_article_top_output()
    {
        global $_G;

        $css = '';

        if($_G['cache']['plugin'][$this->plugin_name]['grab_portal_css']){
            $css = $_G['cache']['plugin'][$this->plugin_name]['grab_portal_css'];
        }

        return $css;
    }
    
    function view_article_bottom_output()
    {
        global $_G, $content;
    
        $js = '';

        $is_open_hotlink = $_G['cache']['plugin'][$this->plugin_name]['is_open_hotlink'];
        
        if(! $is_open_hotlink){
            return $js;
        }
    
        $rule = '/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/i';
        $content['content'] = preg_replace_callback($rule, $this->plugin_name.'_img_hotlink', $content['content']);
        
        return $js;
    }
}

class plugin_ror_grab_discuz_group extends plugin_ror_grab_discuz
{
    var $plugin_name = 'ror_grab_discuz';
    
    function viewthread_top_output()
    {
        global $_G, $page, $postlist;

        $css = '';
        
        $grab_post_css = $_G['cache']['plugin'][$this->plugin_name]['grab_post_css'];
        if($page == 1 && $grab_post_css){
            foreach($postlist as $post){
                $css = str_replace('pid', $post['pid'], $grab_post_css);
                break;
            } 
        }

        return $css;
    }
    
    function viewthread_bottom_output()
    {
        global $_G, $page, $postlist;
    
        $js = '';
        
        $is_open_hotlink = $_G['cache']['plugin'][$this->plugin_name]['is_open_hotlink'];
        
        if(! $is_open_hotlink || $page != 1){
            return $js;
        }
    
        foreach($postlist as $key => $post){
            $rule = '/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/i';
            $postlist[$key]['message'] = preg_replace_callback($rule, $this->plugin_name.'_img_hotlink', $post['message']);

            break;
        }
    
        return $js;
    }
}

function ror_grab_discuz_img_hotlink($matches)
{
    global $_G;

    $plugin_name = 'ror_grab_discuz';
    $host = rtrim($_G['siteurl'], '/');
    $url_hotlinking = $host.'/plugin.php?id='.$plugin_name.'&act=pic&url=';

    if(stripos($matches[1], 'http') !== FALSE && stripos($matches[1], $host) === FALSE){
        $url = $url_hotlinking.urlencode($matches[1]);
        return str_replace($matches[1], $url, $matches[0]);
    }
    
    return $matches[0];
}
