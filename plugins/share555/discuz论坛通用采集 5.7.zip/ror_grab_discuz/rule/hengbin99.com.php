<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule = array(
	
	'0'=>array(
	
		'list_intercept_start'=>'<div id="content">',
		'list_intercept_filter'=>'<!--.*?-->,,',
		'list_intercept_end'=>'<footer id="footer">',
		'list_list'=>'<div class="girl_image">(.*?)<\/div>',
		'list_title'=>'title="(.*?)"',
		'list_source'=>'href="(.*?)"',
	  
	    'con_intercept_start'=>'<section>',
	    'con_intercept_filter'=>'<!--.*?-->,<article.*?>,</article>,<header>.*?<\/header>,<h3 class="xlt">.*?<\/h3>,<h3 class="com_today_tilte">,</h3>',
	    'con_intercept_end'=>'</section>',
        
        'tags_intercept_start'=>'',
        'tags_intercept_filter'=>'',
        'tags_intercept_end'=>'',
        'tags_list'=>'',
        
        'comment_intercept_start'=>'',
        'comment_intercept_filter'=>'',
        'comment_intercept_end'=>'',
        'comment_list'=>'',
        'comment_content'=>'',
	    
	    'comment_dateline'=>'',
	    
	    'author_list'=>'',
        
        'func'=>array(

        ),
	)
	
);
