<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['list_intercept_start'] = 'id="searchList">';
$rule[0]['list_intercept_filter'] = array();
$rule[0]['list_intercept_end'] = '<div id="litPaginationP"';
$rule[0]['list_list'] = '<dt class="blue3 blueav">(.*?)<\/dt>';
$rule[0]['list_title'] = '<a .*?>(.*?)<\/a>';
$rule[0]['list_source'] = 'href="(.*?)"';

$rule[0]['con_intercept_start'] = 'id="divmc">';
$rule[0]['con_intercept_filter'] = array();
$rule[0]['con_intercept_end'] = '<div class="shop-action';
$rule[0]['con_more_intercept_start'] = '';
$rule[0]['con_more_intercept_filter'] = array();
$rule[0]['con_more_intercept_end'] = '';

$rule[0]['tags_intercept_start'] = '';
$rule[0]['tags_intercept_filter'] = array();
$rule[0]['tags_intercept_end'] = '';
$rule[0]['tags_list'] = '';

$rule[0]['comment_intercept_start'] = '';
$rule[0]['comment_intercept_filter'] = array();
$rule[0]['comment_intercept_end'] = '';
$rule[0]['comment_list'] = '';

$rule[0]['comment_dateline'] = '';
$rule[0]['author_list'] = '';

$rule[0]['func'] = array(
	'page_deal'=>'page_deal_s_114chn_com',
    'detail_deal_more'=>'detail_deal_more_s_114chn_com',
);

if(! function_exists('page_deal_s_114chn_com'))
{
    function page_deal_s_114chn_com($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url = str_replace('.html', '-p'.$page.'.html', $url);
        
        return $url;
    }
}

if(! function_exists('detail_deal_more_s_114chn_com'))
{
    function detail_deal_more_s_114chn_com(& $html, $grab)
    {
        $data = '';

		$host = 'http://s.114chn.com';
  
		preg_match('/<div class="flash">(.*?)<\/div>/is', $html, $result_div);
		if($result_div[1]){
		    preg_match("/src='(.*?)'/is", $result_div[1], $result_src);
		    if($result_src[1]){
		        $data .= '<img src="'.$host.'/'.$result_src[1].'">';
		    }
		}

		$data .= '<table>';
        preg_match_all('/<dl class="clearfix".*?>(.*?)<\/dl>/is', $html, $result_dl);
        if($result_dl[1])
		{
            foreach($result_dl[1] as $value)
			{
                $name = '电话：';
				if(strpos($value, $name) !== FALSE)
				{
					preg_match("/src='(.*?)'/is", $value, $result);
					if($result[1]){
						$data .= '<tr><td>'.$name.'</td><td><img src="'.$host.$result[1].'"></td></tr>';
					}else{
						$data .= '<tr><td>'.$name.'</td><td>暂无</td></tr>';
					}
				}
				
				$name = '营业时间：';
				if(strpos($value, $name) !== FALSE)
				{
					preg_match('/class="center.*?">(.*?)<input/is', $value, $result);
					$data .= '<tr><td>'.$name.'</td><td>'.$result[1].'</td></tr>';
				}

				$name = '所属地区：';
				if(strpos($value, $name) !== FALSE)
				{
					preg_match('/class="center.*?">(.*?)<input/is', $value, $result);
					$data .= '<tr><td>'.$name.'</td><td>'.$result[1].'</td></tr>';
				}

				$name = '地址：';
				if(strpos($value, $name) !== FALSE)
				{
					preg_match('/class="center.*?">(.*?)<input/is', $value, $result);
					$data .= '<tr><td>'.$name.'</td><td>'.$result[1].'</td></tr>';
				}

				$name = '简介：';
				if(strpos($value, $name) !== FALSE)
				{
					preg_match('/class="center.*?">(.*?)<input/is', $value, $result);
					$data .= '<tr><td>'.$name.'</td><td>'.$result[1].'</td></tr>';
				}
            }
        }
        
        $data .= '</table>';

		$data = lib_base::string_utf8_to_gbk($data);

        $html = $data;
    }
}
