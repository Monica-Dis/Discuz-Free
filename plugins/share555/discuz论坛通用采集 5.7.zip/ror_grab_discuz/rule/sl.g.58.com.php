<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['list_intercept_start'] = '<div id="content"';
$rule[0]['list_intercept_filter'] = array('');
$rule[0]['list_intercept_end'] = '<div id="attent-mask"';
$rule[0]['list_list'] = '<a class="info-item"(.*?)<\/a>';
$rule[0]['list_title'] = '<p class="desc.*?>(.*?)<\/p>';
$rule[0]['list_source'] = 'href="(.*?)"';

$rule[0]['con_intercept_start'] = '<div class="detail-main">';
$rule[0]['con_intercept_filter'] = array();
$rule[0]['con_intercept_end'] = '<div id="comment">';
$rule[0]['con_more_intercept_start'] = '';
$rule[0]['con_more_intercept_filter'] = array();
$rule[0]['con_more_intercept_end'] = '';

$rule[0]['tags_intercept_start'] = '';
$rule[0]['tags_intercept_filter'] = array();
$rule[0]['tags_intercept_end'] = '';
$rule[0]['tags_list'] = '';

$rule[0]['comment_intercept_start'] = '';
$rule[0]['comment_intercept_filter'] = array();
$rule[0]['comment_intercept_end'] = '';
$rule[0]['comment_list'] = '';

$rule[0]['comment_dateline'] = '';
$rule[0]['author_list'] = '';

$rule[0]['func'] = array(
    'list_deal'=>'list_deal_gm_58_com',
    'page_deal'=>'page_deal_gm_58_com',
    'detail_deal_more'=>'detail_deal_more_gm_58_com',
    'comment_deal'=>'comment_deal_gm_58_com',
    'thread_data_get'=>'thread_data_get_gm_58_com',
);

if(! function_exists('list_deal_gm_58_com'))
{
    function list_deal_gm_58_com(& $grab)
    {
        foreach($grab['title'] as $key => $title){
            $grab['title'][$key] = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $title);
        }
        
        foreach($grab['source'] as $key => $source){
            if(strpos($source, '?') !== FALSE){
                $url = explode('?', $source);
                $grab['source'][$key] = $url[0];
            }
        }
    }
}

//采集内容处理
if(! function_exists('detail_deal_more_gm_58_com'))
{
    function detail_deal_more_gm_58_com(& $html, $grab)
    {
        $data = '';
        
        preg_match_all('/<textarea id="content-str".*?>(.*?)<\/textarea>/is', $html, $result_textarea);
        if($result_textarea[1]){
            foreach($result_textarea[1] as $value){
                $data .= $value.'<br/>';
            }
        }
        
        preg_match_all('/<img .*?data-src="(.*?)".*?>/is', $html, $result_img);
        if($result_img[1]){
            $result_img[1] = array_unique($result_img[1]);
            foreach($result_img[1] as $value){
                if(strpos($value, 'http') === FALSE){
                    $value = 'https:'.$value;
                }
                $data .= '<img src="'.$value.'"/><br/>';
            }
        }
        
        $data = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $data);
        
        $html = $data;
    }
}

if(! function_exists('page_deal_gm_58_com'))
{
    function page_deal_gm_58_com($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url .= rtrim($url, '/').'/pn'.$page;
        
        return $url;
    }
}

if(! function_exists('comment_deal_gm_58_com'))
{
    function comment_deal_gm_58_com(& $comment, $grab)
    {
        $comment['phone'] = '';
        $comment['weixin'] = '';
        
        $html = $grab['html'];
        
        $pattern = '/<div class="section contact">(.*?)<\/div>/is';
        preg_match($pattern, $html, $result_div);
        if(! $result_div[1]){
            return;
        }
        
        $pattern = '/<p>(.*?)<\/p>/is';
        preg_match_all($pattern, $result_div[1], $result_p);
        if($result_p[1])
        {
            foreach($result_p[1] as $value)
            {
                if(strpos($value, '电话：') !== FALSE){
                    $pattern = '/<\/span>(.*?)<a/is';
                    preg_match($pattern, $value, $result_phone);
                    if($result_phone[1]){
                        $result_phone[1] = str_replace('+7', '8', $result_phone[1]);
                        $result_phone[1] = str_replace('+8', '8', $result_phone[1]);
                        $comment['phone'] = $result_phone[1];
                    }
                }else if(strpos($value, '微信：') !== FALSE){
                    $pattern = '/<\/span>(.*)/is';
                    preg_match($pattern, $value, $result_weixin);
                    if($result_weixin[1]){
                        $comment['weixin'] = $result_weixin[1];
                    }
                }
            }
        }
    }
}

if(! function_exists('thread_data_get_gm_58_com'))
{
    function thread_data_get_gm_58_com($grab)
    {
        $comment = $grab['comment'] ? unserialize($grab['comment']) : '';
        
        $fid = $grab['fid'];
        $tid = $grab['tid'];
        $pid = $grab['pid'];
        $uid = $grab['authorid'];
        
        $dianhua = $comment['phone'] ? $comment['phone'] : '';
        $weixin = $comment['weixin'] ? $comment['weixin'] : '';
        
        //采集分类
        $sortid = 0;
        $sql = 'SELECT threadsorts FROM %t WHERE fid=%d';
        $threadsorts = DB::result_first($sql, array('forum_forumfield', $fid));
        if($threadsorts)
        {
            $threadsorts = unserialize($threadsorts);
            foreach($threadsorts['types'] as $key => $value){
                $sortid = $key;
                break;
            }
            
            $sql = 'Describe %t dianhua';
            $field_is_exist = DB::result_first($sql, array('forum_optionvalue'.$sortid));
            
            $typeoption_array = array();
            if($field_is_exist)
            {
                $add_optionvalue = array(
                    'fid'=>$fid,
                    'tid'=>$tid,
                    'dianhua'=>$dianhua,
                    'weixin'=>$weixin,
                );
                DB::insert('forum_optionvalue'.$sortid, $add_optionvalue);
                $typeoption_array = array('dianhua','weixin');
            }
            else 
            {
                $add_optionvalue = array(
                    'fid'=>$fid,
                    'tid'=>$tid,
                    'dianhua_'.$sortid=>$dianhua,
                    'weixin_'.$sortid=>$weixin,
                );
                DB::insert('forum_optionvalue'.$sortid, $add_optionvalue);
                $typeoption_array = array('dianhua_'.$sortid,'weixin_'.$sortid);
            }
 
            $sql = 'SELECT optionid,identifier FROM %t WHERE identifier IN(%n)';
            $typeoption_list = DB::fetch_all($sql, array('forum_typeoption', $typeoption_array));
            
            foreach($typeoption_list as $value)
            {
                $add_typeoptionvar = array(
                    'sortid'=>$sortid,
                    'tid'=>$tid,
                    'fid'=>$fid,
                    'optionid'=>$value['optionid'],
                    'expiration'=>0,
                    'value'=>$add_optionvalue[$value['identifier']],
                );
                DB::insert('forum_typeoptionvar', $add_typeoptionvar);
            }
            
            if($sortid)
            {
                $edit = array(
                    'sortid'=>$sortid,
                );
 
                DB::update('forum_thread', $edit, array('tid'=>$tid));
            }
        }
    }
}