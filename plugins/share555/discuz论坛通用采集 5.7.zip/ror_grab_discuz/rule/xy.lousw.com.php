<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['list_intercept_start'] = '<table';
$rule[0]['list_intercept_filter'] = array('');
$rule[0]['list_intercept_end'] = '<td align=right';
$rule[0]['list_list'] = '<tr bgcolor="#f0f4ff">(.*?)<\/tr>';
$rule[0]['list_title'] = 'title="(.*?)"';
$rule[0]['list_source'] = "href='(.*?)'";

$rule[0]['con_intercept_start'] = '<body>';
$rule[0]['con_intercept_filter'] = array('');
$rule[0]['con_intercept_end'] = '</body>';
$rule[0]['con_more_intercept_start'] = '';
$rule[0]['con_more_intercept_filter'] = array();
$rule[0]['con_more_intercept_end'] = '';

$rule[0]['tags_intercept_start'] = '';
$rule[0]['tags_intercept_filter'] = array();
$rule[0]['tags_intercept_end'] = '';
$rule[0]['tags_list'] = '';

$rule[0]['comment_intercept_start'] = '';
$rule[0]['comment_intercept_filter'] = array();
$rule[0]['comment_intercept_end'] = '';
$rule[0]['comment_list'] = '';

$rule[0]['comment_dateline'] = '';
$rule[0]['author_list'] = '';

$rule[0]['func'] = array(
    'page_deal'=>'page_deal_xy_lousw_com',
    'detail_deal_more'=>'detail_deal_more_xy_lousw_com',
    'comment_deal'=>'comment_deal_xy_lousw_com',
    'thread_data_get'=>'thread_data_get_xy_lousw_com',
);


if(! function_exists('page_deal_xy_lousw_com'))
{
    function page_deal_xy_lousw_com($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url = str_replace('/1/type/c.html', '/'.$page.'/type/c.html', $url);
        
        return $url;
    }
}


//采集内容处理
if(! function_exists('detail_deal_more_xy_lousw_com'))
{
    function detail_deal_more_xy_lousw_com(& $html, $grab)
    {
        lib_base::$grab_charset = 'UTF-8';
            
        $comment['klp_lou_name'] = $grab['title'][0];
        
        $data = '';
        
        $html = $grab['html'];
        $pattern = '/<td class="text2"><a href=\'(.*?)\'/is';
        preg_match($pattern, $html, $result);
        if($result[1]){
            $host = 'http://xy.lousw.com';
            $html_xuke = lib_func_grab::get($host.$result[1]);
            $pattern = '/<table width="308"(.*?)<\/table>/is';
            preg_match($pattern, $html_xuke, $result_xuke);
            if($result_xuke[0]){
                $result_xuke[0] = str_replace('</a>', '', $result_xuke[0]);
                $result_xuke[0] = preg_replace('/<a .*?>/is', '', $result_xuke[0]);
                $data .= $result_xuke[0].'<br>';
            }
        }
        
        $html = $grab['html'];
        lib_func_grab::html_intercept($html, '（鸟瞰图）', 'start');
        lib_func_grab::html_intercept($html, '</TABLE>', 'end');
        $pattern = '/src="(.*?)"/is';
        preg_match($pattern, $html, $result);
        if($result[1]){
            $data .= $comment['klp_lou_name'].'平面示意图（鸟瞰图）<br>';
            $data .= '<img src="'.$result[1].'"><br>';
        }
        
        $html = $grab['html'];
        lib_func_grab::html_intercept($html, '（鸟瞰图）', 'start');
        $pattern = '/<table width="690"(.*?)<\/table>/is';
        preg_match($pattern, $html, $result);
        if($result[0]){
            lib_func_grab::html_intercept($result[0], '<tr><td colspan="12"', 'end');
            $data .= $result[0].'</table>';
        }
        
        $html = $grab['html'];
        lib_func_grab::html_intercept($html, '<div id="colee_left"', 'start');
        lib_func_grab::html_intercept($html, '<td id="colee_left2"', 'end');
        $pattern = '/src="(.*?)"/is';
        preg_match_all($pattern, $html, $result_src);
        if($result_src[1]){
            $data .= $comment['klp_lou_name'].' 户型图<br>';
            foreach($result_src[1] as $key => $value){
                if(strpos($value, 'http') !== FALSE){
                    $data .= '<img src="'.$value.'"><br>';
                }
            }
        }
        
        $html = $grab['html'];
        lib_func_grab::html_intercept($html, '项目区位图', 'start');
        lib_func_grab::html_intercept($html, '<!--<tr>-->', 'end');
        $html = str_replace('<img src="/themes', '', $html);
        $pattern = '/src="(.*?)"/is';
        preg_match($pattern, $html, $result);
        if($result[1]){
            $data .= $comment['klp_lou_name'].' 项目区位图<br>';
            $data .= '<img src="'.$result[1].'"><br>';
        }
        
        $html = $data;
    }
}

if(! function_exists('comment_deal_xy_lousw_com'))
{
    function comment_deal_xy_lousw_com(& $comment, $grab)
    {
        $comment['klp_lou_name'] = $grab['title'][0];
        $comment['klp_lou_kaifashang'] = '未知';
        $comment['klp_lou_quyu'] = 1;
        $comment['klp_lou_dizhi'] = '未知';
        $comment['klp_lou_tel'] = '13174001741';
        $comment['klp_lou_shoudi'] = '未知';
        
        $comment['klp_fang_pic01'] = '';
        $comment['klp_fang_pic02'] = '';
        $comment['klp_fang_pic03'] = '';
        $comment['klp_fang_pic04'] = '';
        $comment['klp_erweima_fang'] = 'a:2:{s:3:"aid";s:0:"";s:3:"url";s:0:"";}';
        

        //a:2:{s:3:"aid";s:5:"15467";s:3:"url";s:58:"data/attachment/forum/202106/06/162242de1jjc2rntnlenf1.jpg";}
        $html = $grab['html'];
        //$html = lib_base::string_gbk_to_utf8($html);

        $pattern = '/（开发商： (.*?)）/is';
        preg_match($pattern, $html, $result_kaifashang);
        if($result_kaifashang[1]){
            $comment['klp_lou_kaifashang'] = $result_kaifashang[1];
        }
        
        $pattern = '/项目地址：<\/span>(.*?)<\/td>/is';
        preg_match($pattern, $html, $result_dizhi);
        if($result_dizhi[1]){
            $comment['klp_lou_dizhi'] = $result_dizhi[1];
        }
        
//         $pattern = '/<td class="red100">(.*?)<\/td>/is';
//         preg_match($pattern, $html, $result_tel);
//         if($result_tel[1]){
//             $comment['klp_lou_tel'] = $result_tel[1];
//         }
        
        $pattern = '/售楼处：<\/span>(.*?)<\/td>/is';
        preg_match($pattern, $html, $result_shoudi);
        if($result_shoudi[1]){
            $comment['klp_lou_shoudi'] = $result_shoudi[1];
        }
        
        
        $html = $grab['html'];
        lib_func_grab::html_intercept($html, '<!--户型图', 'start');
        lib_func_grab::html_intercept($html, '<td id="colee_left2"', 'end');
        $pattern = '/src="(.*?)"/is';
        preg_match_all($pattern, $html, $result);
        if($result[1]){
            foreach($result[1] as $key => $value){
                if($key <= 3){
                    $comment['klp_fang_pic0'.($key+1)] = $value;
                }
            }
        }
    }
}

if(! function_exists('thread_data_get_xy_lousw_com'))
{
    function thread_data_get_xy_lousw_com($grab)
    {
        $comment = $grab['comment'] ? unserialize($grab['comment']) : '';
        
        $fid = $grab['fid'];
        $tid = $grab['tid'];
        $pid = $grab['pid'];
        $uid = $grab['authorid'];
        
        $klp_lou_name = $comment['klp_lou_name'];
        $klp_lou_kaifashang = $comment['klp_lou_kaifashang'];
        $klp_lou_quyu = $comment['klp_lou_quyu'];
        $klp_lou_dizhi = $comment['klp_lou_dizhi'];
        $klp_lou_tel = $comment['klp_lou_tel'];
        $klp_lou_shoudi = $comment['klp_lou_shoudi'];
        $klp_fang_pic01 = $comment['klp_fang_pic01'];
        $klp_fang_pic02 = $comment['klp_fang_pic02'];
        $klp_fang_pic03 = $comment['klp_fang_pic03'];
        $klp_fang_pic04 = $comment['klp_fang_pic04'];
        $klp_erweima_fang = $comment['klp_erweima_fang'];
        
        if($klp_fang_pic01){
            $klp_fang_pic01 = img_download_xy_lousw_com($klp_fang_pic01, $tid, $pid, $uid);
        }else{
            $klp_fang_pic01 = 'a:2:{s:3:"aid";s:0:"";s:3:"url";s:0:"";}';
        }
        if($klp_fang_pic02){
            $klp_fang_pic02 = img_download_xy_lousw_com($klp_fang_pic02, $tid, $pid, $uid);
        }else{
            $klp_fang_pic02 = 'a:2:{s:3:"aid";s:0:"";s:3:"url";s:0:"";}';
        }
        if($klp_fang_pic03){
            $klp_fang_pic03 = img_download_xy_lousw_com($klp_fang_pic03, $tid, $pid, $uid);
        }else{
            $klp_fang_pic03 = 'a:2:{s:3:"aid";s:0:"";s:3:"url";s:0:"";}';
        }
        if($klp_fang_pic04){
            $klp_fang_pic04 = img_download_xy_lousw_com($klp_fang_pic04, $tid, $pid, $uid);
        }else{
            $klp_fang_pic04 = 'a:2:{s:3:"aid";s:0:"";s:3:"url";s:0:"";}';
        }
        
        //采集分类
        $sortid = 0;
        $sql = 'SELECT threadsorts FROM %t WHERE fid=%d';
        $threadsorts = DB::result_first($sql, array('forum_forumfield', $fid));
        if($threadsorts)
        {
            $threadsorts = unserialize($threadsorts);
            foreach($threadsorts['types'] as $key => $value){
                $sortid = $key;
                break;
            }
            
            $add_optionvalue = array(
                'fid'=>$fid,
                'tid'=>$tid,
                'klp_lou_name'=>$klp_lou_name,
                'klp_lou_kaifashang'=>$klp_lou_kaifashang,
                'klp_lou_quyu'=>$klp_lou_quyu,
                'klp_lou_dizhi'=>$klp_lou_dizhi,
                'klp_lou_tel'=>$klp_lou_tel,
                'klp_lou_shoudi'=>$klp_lou_shoudi,
                'klp_fang_pic01'=>$klp_fang_pic01,
                'klp_fang_pic02'=>$klp_fang_pic02,
                'klp_fang_pic03'=>$klp_fang_pic03,
                'klp_fang_pic04'=>$klp_fang_pic04,
                'klp_erweima_fang'=>$klp_erweima_fang,
            );
            DB::insert('forum_optionvalue'.$sortid, $add_optionvalue);
            $typeoption_array = array('klp_lou_name','klp_lou_kaifashang','klp_lou_quyu','klp_lou_dizhi','klp_lou_tel','klp_lou_shoudi','klp_fang_pic01','klp_fang_pic02','klp_fang_pic03','klp_fang_pic04','klp_erweima_fang');
            
            $sql = 'SELECT optionid,identifier FROM %t WHERE identifier IN(%n)';
            $typeoption_list = DB::fetch_all($sql, array('forum_typeoption', $typeoption_array));
            
            foreach($typeoption_list as $value)
            {
                $add_typeoptionvar = array(
                    'sortid'=>$sortid,
                    'tid'=>$tid,
                    'fid'=>$fid,
                    'optionid'=>$value['optionid'],
                    'expiration'=>0,
                    'value'=>$add_optionvalue[$value['identifier']],
                );
                DB::insert('forum_typeoptionvar', $add_typeoptionvar);
            }
            
            if($sortid)
            {
                $edit = array(
                    'sortid'=>$sortid,
                );
                
                DB::update('forum_thread', $edit, array('tid'=>$tid));
            }
        }
    }
}

if(! function_exists('img_download_xy_lousw_com'))
{
    function img_download_xy_lousw_com($imgurl, $tid, $pid, $uid)
    {
        $from_type = 'forum';
        $filename = date('His').strtolower(random(16));
        $dir = ! getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
        
        $dir = $dir.$from_type;
        list($y, $m, $d) = explode('-', date('Y-m-d', TIMESTAMP));
        ! is_dir("$dir/$y$m") && mkdir("$dir/$y$m", 0777);
        ! is_dir("$dir/$y$m/$d") && mkdir("$dir/$y$m/$d", 0777);
        $savefilename = "$dir/$y$m/$d/";
        
        $ext_allow = array('jpg','png','jpeg','gif','bmp');
        $ext = strtolower(substr($imgurl, (strrpos($imgurl, '.') + 1)));
        ! in_array($ext, $ext_allow) && $ext = $ext_allow[0];
        $filename = $filename.'.'.$ext;
        
        $filepath = "$y$m/$d/$filename";
        $savefilename = $savefilename.$filename;
        
        $imgData = lib_func_grab::attach_get($imgurl);
        if($imgData){
            file_put_contents($savefilename, $imgData);
        }
        
        $imgwidth = $imagesize = 0;
        $imginfo = @getimagesize($savefilename);
        
        $course_cover = array();
        if($imginfo !== FALSE)
        {
            $imgwidth = $imginfo[0];
            $imagesize = @filesize($savefilename);
            
            $attachment = array(
                'tid'=>$tid,
                'pid'=>$pid,
                'uid'=>$uid,
                'tableid'=>getattachtableid($tid),
                'downloads'=>0
            );
            $aid = DB::insert("forum_attachment", $attachment, true);
            $forum_attachment_n = array(
                'aid'=>$aid,
                'tid'=>$tid,
                'pid'=>$pid,
                'uid'=>$uid,
                'dateline'=>TIMESTAMP,
                'filename'=>$filename,
                'filesize'=>$imagesize,
                'attachment'=>$filepath,
                'remote'=>0,
                'readperm'=>0,
                'price'=>0,
                'isimage'=>1,
                'width'=>$imgwidth,
                'thumb'=>0,
                'picid'=>0
            );
            C::t("forum_attachment_n")->insert("tid:" . $tid, $forum_attachment_n);
            
            if($aid){
                $course_cover_array = array(
                    'aid'=>$aid,
                    'url'=>'data/attachment/forum/'.$filepath,
                );
                $course_cover = serialize($course_cover_array);
            }
        }
        else
        {
            $course_cover_array = array(
                'aid'=>0,
                'url'=>'',
            );
            $course_cover = serialize($course_cover_array);
        }
        
        return $course_cover;
    }
}

