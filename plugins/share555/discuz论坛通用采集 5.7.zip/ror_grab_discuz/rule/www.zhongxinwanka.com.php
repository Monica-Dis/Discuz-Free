<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

if(strpos($url, '/news/') !== FALSE || strpos($url, '/article-') !== FALSE)
{
    $rule = array(
    
        '0'=>array(
    
            'list_intercept_start'=>'<div class="deanpiclist top15">',
            'list_intercept_filter'=>'',
            'list_intercept_end'=>'div class="pgs',
            'list_list'=>'<h2>(.*?)<\/h2>',
            'list_title'=>'<a .*?>(.*?)<\/a>',
            'list_source'=>'href="(.*?)"',
             
            'con_intercept_start'=>'class="vwtb">',
            'con_intercept_filter'=>'<tr>,<td .*?>,</td>,</tr>,<a .*?>,</a>,<span style="font-size: 16px;">.*?<\/span>',
            'con_intercept_end'=>'</table>',
    
            'tags_intercept_start'=>'>',
            'tags_intercept_filter'=>'',
            'tags_intercept_end'=>'',
            'tags_list'=>'',
    
            'comment_intercept_start'=>'',
            'comment_intercept_filter'=>'',
            'comment_intercept_end'=>'',
            'comment_list'=>'',
            'comment_content'=>'',
             
            'comment_dateline'=>'<div class="deanxg1">.*?<span',
             
            'author_list'=>'',
    
            'func'=>array(
                'page_deal'=>'page_deal_www_zhongxinwanka_com_news',
            ),
        )
    
    );
}
else 
{
    $rule[$ruleid]['func']['page_deal'] = 'page_deal_www_zhongxinwanka_com_forum';
}


if(! function_exists('page_deal_www_zhongxinwanka_com_news'))
{
    function page_deal_www_zhongxinwanka_com_news($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url .= 'index.php?page='.$page;

        return $url;
    }
}


if(! function_exists('page_deal_www_zhongxinwanka_com_forum'))
{
    function page_deal_www_zhongxinwanka_com_forum($page, $nav)
    {
        $url = $nav['source'];

        if($page == 1){
            return $url;
        }

        $parse_url = parse_url($url);

        $parse_url['path'] = str_replace('.html', '', $parse_url['path']);
        $url_arr = explode('-', $parse_url['path']);

        $url_str = '';
        $url_arr[0] && $url_str .= $url_arr[0].'-';
        $url_arr[1] && $url_str .= $url_arr[1].'-';
        $url_arr[2] && $url_str .= $url_arr[2].'-';
        $url_str .= $page;
        
        $url = str_replace($parse_url['path'], $url_str, $url);

        return $url;
    }
}
