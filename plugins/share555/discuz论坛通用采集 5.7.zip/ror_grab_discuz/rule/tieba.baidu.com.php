<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$rule = array(
    
    '0'=>array(
        
        'list_intercept_start'=>'<ul id="thread_list"',
        'list_intercept_filter'=>array('<i class="icon(.*?)<a'),
        'list_intercept_end'=>'<div class="thread_list_bottom',
        'list_list'=>'<div class="threadlist_title(.*?)<\/div>',
        'list_title'=>'<a .*?>(.*?)<\/a>',
        'list_source'=>'href="(.*?)"',
        
        'con_intercept_start'=>'<div id="post',
        'con_intercept_filter'=>array('_content_.*?>','<span class="apc_src_wrapper">.*?<\/span>'),
        'con_intercept_end'=>'</div>',
        
        'comment_intercept_start'=>'div id="post_content',
        'comment_intercept_filter'=>array(''),
        'comment_intercept_end'=>'<div class="pb_footer">',
        'comment_list'=>'<div id="post_content.*?>(.*?)<\/div>',
        
        'comment_filter'=>'</a></span><span class="tail-info">',
        'comment_dateline'=>'<span class="tail-info">(.*?)<\/span><\/div>',
        
        'author_list'=>'<a data-field=.*?>(.*?)<\/a>',
        
        'func'=>array(
            'page_deal'=>'page_deal_tieba_baidu_com',
            'dateline_start'=>'dateline_start_tieba_baidu_com',
        ),
    )
);

if(! function_exists('page_deal_tieba_baidu_com'))
{
    function page_deal_tieba_baidu_com($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url .= '&pn='.(($page - 1) * 50);
        
        return $url;
    }
}

if(! function_exists('dateline_start_tieba_baidu_com'))
{
    function dateline_start_tieba_baidu_com(& $grab, & $comment)
    {
        $dateline = array();
        
        $html = $grab['html'];
        
        lib_func_grab::content_filter($html, $grab['rule']['comment_filter']);
        
        $pattern = '/'.$grab['rule']['comment_dateline'].'/is';
        preg_match_all($pattern, $html, $result);
        
        if(! $result[1]){
            return $dateline;
        }
        
        $rule = '/\d{4}-\d{1,2}-\d{1,2} (\d{1,2}:\d{1,2}:\d{1,2}|\d{1,2}:\d{1,2})/is';
        foreach($result[1] as $key => $value)
        {
            preg_match($rule, $value, $result_time);
            
            $dateline[$key] =  $result_time[0];
        }
        
        $comment['dateline'] = $dateline;
    }
}
