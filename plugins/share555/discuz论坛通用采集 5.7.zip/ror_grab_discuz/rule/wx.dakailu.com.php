<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$rule = array(
    
    '0'=>array(
        
        'list_intercept_start'=>'',
        'list_intercept_filter'=>array(),
        'list_intercept_end'=>'',
        'list_list'=>'',
        'list_source'=>'',
        'list_title'=>'',
        
        'con_intercept_start'=>'<div class="Tzs03"',
        'con_intercept_filter'=>array(''),
        'con_intercept_end'=>'<ul class="Tzs06">',
        
        'author_list'=>'<h4 class="Tzs01211" .*?>(.*?)<\/h4>',
        
        'func'=>array(
            'list'=>'list_wx_dakailu_com',
            'page_deal'=>'page_deal_wx_dakailu_com',
            'detail_deal_more'=>'detail_deal_more_wx_dakailu_com',
        )
    ),
    
);

if(! function_exists('page_deal_wx_dakailu_com'))
{
    function page_deal_wx_dakailu_com($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url .= '&page='.$page;
        
        return $url;
    }
}

if(!function_exists('list_wx_dakailu_com'))
{
    function list_wx_dakailu_com(& $grab)
    {
        $url = trim($grab['url']);

        $urls = parse_url($url);
        $paths = explode('/', $urls['path']);
        $grab['host'] = $urls['scheme'].'://'.$urls['host'];
        $cookie = $grab['cookie'];
        
		$post = array(
			'page'=>1,
			'cc'=>1,
			's'=>0,
			'h'=>0,
			't'=>0,
			'keyword'=>'',
			'haschild'=>1,
			'webid'=>876,
			'topid'=>876,
			'xiao'=> 0,
			'key'=>'08ca4eebd056240c16596c77956e5f99',
			'showfabu'=>0,
			'showtongbu'=>0,
			'webcode'=>'',
			'fenzhan'=>0,
			'pagename'=>'', 
		);

        $posts = explode('&', $urls['query']);
        foreach($posts as $value){
            list($k, $val) = explode('=', $value);
            $post[$k] = $val;
        }

        if($post['smallid']){
            $post['t'] = $post['smallid'];
            $post['t'] = $post['smallid'];
        }
		$post['t'] = $post['smallid'] ? $post['smallid'] : $post['id'];

// 		$headers = array(
//             'Cookie: ASP.NET_SessionId=r00atzwk2czysmrle3irsygq; bcatsid=9017c9527c98d71a; bcato2ocompanywebid=apnuZkuWgG+KcEronTuPtg==',
//             'X-Requested-With: XMLHttpRequest',
//         );

		$url = 'http://wx.dakailu.com/asyn/infoasynlist/';
        $html = lib_func_grab::get($url, $grab['host'], $urls['host'], $cookie, $post);
        $json = json_decode($html, TRUE);
        if(! $json){
            $notice = '&#21015;&#34920;&#106;&#115;&#111;&#110;&#35299;&#26512;&#26377;&#35823;&#65306;'.$grab['url'];
            lib_base::back_html($notice , 1);
            return;
        }
        if(! $json['html']){
            $notice = '&#26080;&#37319;&#38598;&#25968;&#25454;&#65306;'.$grab['url'];
            lib_base::back_html($notice , 1);
            return;
        }
        
        $json['html'] = str_replace("<a href='tel", '', $json['html']);
        
        $pattern = "/<li class='Tz'(.*?)<\/li>/is";
        preg_match_all($pattern, $json['html'], $result);
        
        $host = 'http://wx.dakailu.com';
        $grab['title'] = array();
        $grab['source'] = array();
        foreach($result[1] as $key => $value)
        {
            $pattern = "/<p class='Tzs032 textload'>(.*?)<\/p>/is";
            preg_match($pattern, $value, $result_title);
            $grab['title'][$key] = strip_tags($result_title[1]);
            
            $pattern = "/href='(.*?)'/is";
            preg_match($pattern, $value, $result_source);
            $grab['source'][$key] = $result_source[1] ? $host.$result_source[1] : '';
        }

        lib_func_grab::$repeat_count = 0;
        foreach($grab['title'] as $key => $value)
        {
            if(! $value){
                continue;
            }
            
            $source = $grab['source'][$key];
            
            $identify = lib_func_grab::save_identify($source);
            
            $sql = 'SELECT COUNT(*) FROM '.DB::table('plugin_'.PLUGIN_NAME)." WHERE identify='".$identify."'";
            $count = DB::result_first($sql);
            if($count)
            {
                $notice = '&#20869;&#23481;&#37319;&#38598;&#37325;&#22797;&#58;'.$source;
                lib_base::back_html($notice, 1);
                lib_func_grab::$repeat_count++;
                
                if(lib_func_grab::$repeat_count >= lib_func_grab::$repeat_limit){
                    $notice = '&#37319;&#38598;&#20869;&#23481;&#37325;&#22797;&#27425;&#25968;&#36229;&#36807; '.lib_func_grab::$repeat_limit.' &#27425;&#65292;&#20013;&#26029;&#37319;&#38598;&#58;'.$source;
                    lib_base::back_html($notice, 1);
                    break;
                }
                
                continue;
            }
            
            lib_func_grab::$grab_new++;
            
            lib_func_grab::grab_detail_local($grab['id'], $grab['title'][$key], $source);
        }
        
        //更新机制
        lib_func_grab::nav_crontime_update($grab['id'], $grab['crontime']);
        
        return TRUE;
    }
}

//采集内容处理
if(! function_exists('detail_deal_more_wx_dakailu_com'))
{
    function detail_deal_more_wx_dakailu_com(& $html, $grab)
    {
        $data = '';

        preg_match('/<p class="Tzs032" .*?>(.*?)<\/p>/is', $html, $result_p);
        if($result_p[1]){
            $data .= trim($result_p[1]);
        }
        
        preg_match_all('/<li>(.*?)<\/li>/is', $html, $result_li);
        if($result_li[1]){
            foreach($result_li[1] as $value){
                $data .= trim($value);
            }
        }

        $html = $data;
    }
}