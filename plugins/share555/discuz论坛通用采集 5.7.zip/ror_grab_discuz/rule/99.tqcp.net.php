<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['con_intercept_filter'] = array('<table cellspacing="0" cellpadding="0"><tr><td class="t_f".*?>','</td></tr></table>','<div class="modact">(.*?)<\/div>','<div class="locked">(.*?)<\/div>','smilieid="(.*?)"','<i class="pstatus">(.*?)<\/i>','<div class="attach_nopermission attach_tips">(.*?)<\/div>','<span class="atips_close"(.*?)<\/span>','<div class="ptg mbm mtn">(.*?)<\/div>','<em onclick="copycode(.*?)<\/em>','<form.*?id="vfastpostform".*?>(.*?)<\/form>','<div class="mag_viewthread">(.*?)<\/div>','<img src="static\/image.*?>');

$rule[0]['author_list'] = '<div class="authi".*?>.*?<a.*?target="_blank" class="xi2">(.*?)<\/a>';

$rule[0]['func']['detail_deal_more'] = 'detail_deal_more_99_tqcp_net';

//采集内容处理
if(! function_exists('detail_deal_more_99_tqcp_net'))
{
   function detail_deal_more_99_tqcp_net(& $html)
   {
		$rule = array(
			'<font class="jammer">.*?<\/font>',
			'<span style="display:none">.*?<\/span>',
			'<table cellspacing="0" class="t_table" style="width:98%"><tbody><tr><td>',
			'<table cellspacing="0" class="t_table" style="width:98%"><tr><td>',
			'<table cellspacing="0" class="t_table" ><tr><td>',
			'<font color="#ffffff"><font style="font-size:10px">.*?<\/font>',
			'</td></tr></table>',
			'<table cellspacing="0" cellpadding="0"><tr><td class="t_f" id="postmessage_516010">',
			'<font color="#ffffff"><font size="3">.*?<\/font>',
			'<font color="#ffffff">.*?<\/font>',
			'<span style="display:none">.*?<\/span>',
            '<script .*?<\/script>',
			'<div class="a_pr".*?>.*?<\/div>',
		);
		
		lib_func_grab::content_filter($html, $rule);
	}
}
