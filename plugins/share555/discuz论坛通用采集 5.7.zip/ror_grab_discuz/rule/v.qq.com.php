<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['list_intercept_start'] = '';
$rule[0]['list_intercept_filter'] = array('');
$rule[0]['list_intercept_end'] = '';
$rule[0]['list_list'] = '';
$rule[0]['list_title'] = '';
$rule[0]['list_source'] = '';

$rule[0]['con_intercept_start'] = '';
$rule[0]['con_intercept_filter'] = array('');
$rule[0]['con_intercept_end'] = '';
$rule[0]['con_more_intercept_start'] = '';
$rule[0]['con_more_intercept_filter'] = array('');
$rule[0]['con_more_intercept_end'] = '';

$rule[0]['tags_intercept_start'] = '';
$rule[0]['tags_intercept_filter'] = array('');
$rule[0]['tags_intercept_end'] = '';
$rule[0]['tags_list'] = '';

$rule[0]['comment_intercept_start'] = '';
$rule[0]['comment_intercept_filter'] = array('');
$rule[0]['comment_intercept_end'] = '';
$rule[0]['comment_list'] = '';

$rule[0]['comment_dateline'] = '';
$rule[0]['author_list'] = '';

$rule[0]['func'] = array(
    'list_start'=>'list_start_v_qq_com',
    'page_deal'=>'page_deal_v_qq_com',
);

if(! function_exists('list_start_v_qq_com'))
{
    function list_start_v_qq_com($grab)
    {
		$url = $grab['url'];

		if(strpos($url, 'vcuid=') !== FALSE)
		{
			$pattern = '/vcuid=(.*?)&/is';
			preg_match($pattern, $url, $result_vcuid);
			$vcuid = $result_vcuid[1];
			
			$url = 'https://v.qq.com/biu/creator/home?vcuid='.$vcuid;

			$urls = parse_url($url);
			$grab['host'] = $urls['scheme'].'://'.$urls['host'];
			$cookie = $grab['cookie'];
			$html = lib_func_grab::get($url, $grab['host'], $urls['host'], $cookie);
			$pattern = '/<div class="textWrap">(.*?)<\/h3>/is';

			preg_match($pattern, $html, $result_author);
			$author = trim(strip_tags($result_author[1]));

			$json = $grab['html'];

			$data = json_decode($json, TRUE);
			
			$grab['title'] = array();
			$grab['source'] = array();
			$grab['content'] = array();
			foreach($data['data']['data']['list'] as $key => $value)
			{
				$grab['title'][$key] = $value['title'];
				$grab['source'][$key] = 'https://v.qq.com/x/page/'.$value['vid'].'.html';
				$grab['content'][$key] = $author.','.$value['vid'];
			}
		}
		else if(strpos($url, '/x/search/') !== FALSE)
		{
			$html = $grab['html'];

			$notice = 'list start fail';
			lib_func_grab::html_intercept($html, 'quickopen"', 'start', $notice);

			$notice = 'list end fail';
			lib_func_grab::html_intercept($html, '<div class="mod_pages', 'end', $notice);

			preg_match_all('/<h2 class="result_title">(.*?)<div class="info_item info_item_desc">/is', $html, $result_li);

			$grab['title'] = array();
			$grab['source'] = array();
			$grab['content'] = array();

			foreach($result_li[1] as $key => $value)
			{
				preg_match('/<a .*?>(.*?)<\/a>/is', $value, $result_title);
				preg_match('/href="(.*?)"/is', $value, $result_source);
				$title = trim(strip_tags($result_title[1]));
				$source = $result_source[1];
				if(strpos($source, '/x/page/') === FALSE){
					continue;
				}

				preg_match('/<a href="javascript.*?>(.*?)<\/span>/is', $value, $result_author);
				$author = trim(strip_tags($result_author[1]));

				$grab['title'][$key] = $title;
				$grab['source'][$key] = $source;
				$grab['content'][$key] = $author.','.basename($source, '.html');
			}
		}

        lib_func_grab::$repeat_count = 0;
        foreach($grab['title'] as $key => $title)
        {
            if(! $value){
                continue;
            }
             
            $source = $grab['source'][$key];
             
            $identify = lib_func_grab::save_identify($source);
             
            $sql = 'SELECT COUNT(*) FROM '.DB::table('plugin_'.PLUGIN_NAME)." WHERE identify='".$identify."'";
            $count = DB::result_first($sql);
            if($count)
            {
                $notice = '&#20869;&#23481;&#37319;&#38598;&#37325;&#22797;&#65306;'.$source;
                lib_base::back_html($notice, 1);
                lib_func_grab::$repeat_count++;

                if(lib_func_grab::$repeat_count >= lib_func_grab::$repeat_limit){
                    $notice = '&#37319;&#38598;&#20869;&#23481;&#37325;&#22797;&#27425;&#25968;&#36229;&#36807;'.lib_func_grab::$repeat_limit.'&#27425;&#65292;&#20013;&#26029;&#37319;&#38598;&#58;'.$source;
                    lib_base::back_html($notice, 1);
                    break;
                }

                continue;
            }
             
            lib_func_grab::$grab_new++;

            lib_func_grab::grab_save($grab, $title, $grab['content'][$key], array(), array(), $source);
        }
         

        //更新机制
        lib_func_grab::nav_crontime_update($grab['id'], $grab['crontime']);

        return TRUE;
    }
}

if(! function_exists('page_deal_v_qq_com'))
{
    function page_deal_v_qq_com($page, $nav)
    {
        $url = $nav['source'];

		if(strpos($url, 'vcuid=') !== FALSE)
		{
			$vcuid_arr = explode('vcuid=', $url);
			$vcuid = $vcuid_arr[1];
			$url = 'https://pbaccess.video.qq.com/trpc.creator_center.header_page.personal_page/GetUserVideoList?vcuid='.$vcuid.'&page_size=30&page='.$page.'&list_type=1';

			return $url;
		}
		else if(strpos($url, '/x/search/') !== FALSE)
		{
			$url .= '&cur='.$page;
		}
        
        return $url;
    }
}