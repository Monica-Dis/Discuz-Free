<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[$ruleid]['func']['detail_deal_more'] = 'detail_deal_more_www_nanhaijie_com';

//采集内容处理
if(! function_exists('detail_deal_more_www_nanhaijie_com'))
{
    function detail_deal_more_www_nanhaijie_com(& $html, $grab)
    {
        $filter = '<span style="display:none">.*?<\/span>,<font class="jammer">.*?<\/font>';
        
        lib_func_grab::content_filter($html, $filter);
    }
}