<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[$ruleid]['list_intercept_end'] = '<div class="pgbtn">';
$rule[$ruleid]['list_list'] = '<div class="nex_forumtit_top">(.*?)<\/div>';
$rule[$ruleid]['tags_intercept_start'] = '';
$rule[$ruleid]['tags_intercept_end'] = '';
$rule[$ruleid]['tags_list'] = '';
$rule[$ruleid]['author_list'] = 'class="xi2">(.*?)<\/a>';

$rule[$ruleid]['func']['detail_deal_more'] = 'detail_deal_more_hulifan_com';

//采集内容处理
if(! function_exists('detail_deal_more_hulifan_com'))
{
    function detail_deal_more_hulifan_com(& $html, $grab)
    {
        $html_all = $grab['html'];
        
        if(strpos($html_all, '<div class="nex_video_content">') === FALSE){
            return;
        }
        
        lib_func_grab::html_intercept($html_all, '<div class="nex_video_content">', 'start');
        lib_func_grab::html_intercept($html_all, "src='", 'start');
        lib_func_grab::html_intercept($html_all, "'", 'end');

        if(! $html_all || strpos($html_all, 'http') === FALSE){
            return;
        }
        
        $html = '[iframe=100%,500px]'.$html_all.'[/iframe]'.$html;
    }
}