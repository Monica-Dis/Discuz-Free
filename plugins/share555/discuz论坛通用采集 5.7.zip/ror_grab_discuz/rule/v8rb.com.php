<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[$ruleid]['list_intercept_start'] = '<section>';
$rule[$ruleid]['list_intercept_filter'] = '';
$rule[$ruleid]['list_intercept_end'] = '</section>';
$rule[$ruleid]['list_list'] = '<article(.*?)<\/article>';
$rule[$ruleid]['list_title'] = '<h2 class="title first"><span>(.*?)<\/span><\/h2> ';
$rule[$ruleid]['list_source'] = 'href="(.*?)"';

$rule[$ruleid]['con_intercept_start'] = '<section>';
$rule[$ruleid]['con_intercept_filter'] = '';
$rule[$ruleid]['con_intercept_end'] = '</section>';
$rule[$ruleid]['con_more_intercept_start'] = '';
$rule[$ruleid]['con_more_intercept_filter'] = '';
$rule[$ruleid]['con_more_intercept_end'] = '';

$rule[$ruleid]['tags_intercept_start'] = '';
$rule[$ruleid]['tags_intercept_filter'] = '';
$rule[$ruleid]['tags_intercept_end'] = '';
$rule[$ruleid]['tags_list'] = '';

$rule[$ruleid]['comment_intercept_start'] = '';
$rule[$ruleid]['comment_intercept_filter'] = '';
$rule[$ruleid]['comment_intercept_end'] = '';
$rule[$ruleid]['comment_list'] = '';

$rule[$ruleid]['comment_dateline'] = '';
$rule[$ruleid]['author_list'] = '';

$rule[$ruleid]['func'] = array(
    'list_deal'=>'list_deal_v8rb_com',
    'detail_deal_more'=>'detail_deal_more_v8rb_com',
);

if(! function_exists('list_deal_v8rb_com'))
{
    function list_deal_v8rb_com(& $grab)
    {
        foreach($grab['title'] as $key => $title){
            $grab['title'][$key] = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $title);
        }
    }
}

//采集内容处理
if(! function_exists('detail_deal_more_v8rb_com'))
{
    function detail_deal_more_v8rb_com(& $html, $grab)
    {
       /*
        $video_html = $html;
        if(strpos($video_html, '<video>')){
            lib_func_grab::html_intercept($video_html, '<video>', 'start');
            lib_func_grab::html_intercept($video_html, '</video>', 'end');

            $pattern = '/src="(.*?)"/is';
            preg_match($pattern, $video_html, $result);

            if($result[1]){
                $content .= '[iframe=700,400]'.$result[1].'[/iframe]';
            }
        }
        */
		
        $html = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $html);
    }
}