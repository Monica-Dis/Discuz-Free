<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule = array(
	
	'0'=>array(
	
		'list_intercept_start'=>'<div class="tiles">',
		'list_intercept_filter'=>'名称：',
		'list_intercept_end'=>'<footer id="footer">',
		'list_list'=>'<article class="style1">(.*?)<\/article>',
		'list_title'=>'<div>(.*?)<\/div>',
		'list_source'=>'href="(.*?)"',
	  
        'con_intercept_start'=>'<div class="container">',
        'con_intercept_filter'=>'',
        'con_intercept_end'=>'<script',
        
        'tags_intercept_start'=>'>',
        'tags_intercept_filter'=>'',
        'tags_intercept_end'=>'',
        'tags_list'=>'',
        
        'comment_intercept_start'=>'',
        'comment_intercept_filter'=>'',
        'comment_intercept_end'=>'',
        'comment_list'=>'',
        'comment_content'=>'',
	    
	    'comment_dateline'=>'',
	    
	    'author_list'=>'',
        
        'func'=>array(

        ),
	)
	
);
