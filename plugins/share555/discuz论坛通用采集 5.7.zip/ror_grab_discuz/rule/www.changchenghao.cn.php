<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[$ruleid]['list_intercept_start'] = '<ul class="post-loop';
$rule[$ruleid]['list_intercept_filter'] = '';
$rule[$ruleid]['list_intercept_end'] = '</ul>';
$rule[$ruleid]['list_list'] = '<h2 class="item-title">(.*?)<\/h2>';
$rule[$ruleid]['list_title'] = '<a .*?>(.*?)<\/a>';
$rule[$ruleid]['list_source'] = 'href="(.*?)"';

$rule[$ruleid]['con_intercept_start'] = '<div class="entry-content text-indent">';
$rule[$ruleid]['con_intercept_filter'] = '<noscript>,</noscript>,<img class="syl-page-img aligncenter j-lazy".*?>,<p>客服微信：.*?<\/p>';
$rule[$ruleid]['con_intercept_end'] = '<script';
$rule[$ruleid]['con_more_intercept_start'] = '';
$rule[$ruleid]['con_more_intercept_filter'] = '';
$rule[$ruleid]['con_more_intercept_end'] = '';

$rule[$ruleid]['tags_intercept_start'] = '';
$rule[$ruleid]['tags_intercept_filter'] = '';
$rule[$ruleid]['tags_intercept_end'] = '';
$rule[$ruleid]['tags_list'] = '';

$rule[$ruleid]['comment_intercept_start'] = '';
$rule[$ruleid]['comment_intercept_filter'] = '';
$rule[$ruleid]['comment_intercept_end'] = '';
$rule[$ruleid]['comment_list'] = '';

$rule[$ruleid]['comment_dateline'] = '';
$rule[$ruleid]['author_list'] = '';

$rule[$ruleid]['func'] = array(
    'page_deal'=>'page_deal_www_changchenghao_cn',
);

if(! function_exists('page_deal_www_changchenghao_cn'))
{
    function page_deal_www_changchenghao_cn($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url = rtrim($url, '/').'/page/'.$page;
        
        return $url;
    }
}