<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule = array(
	
	'0'=>array(
	
		'list_intercept_start'=>'',
		'list_intercept_filter'=>'',
		'list_intercept_end'=>'',
		'list_list'=>'',
		'list_title'=>'',
		'list_source'=>'',
	  
        'con_intercept_start'=>'class="question-name">',
        'con_intercept_filter'=>array('</h1>'),
        'con_intercept_end'=>'<div class="question-bottom">',
        
        'tags_intercept_start'=>'<div class="question-tags">',
        'tags_intercept_filter'=>'',
        'tags_intercept_end'=>'</div>',
        'tags_list'=>'<a.*?>(.*?)<\/a>',
        
        'comment_intercept_start'=>'"ans_list":',
        'comment_intercept_filter'=>array('{!--.*?--}'),
        'comment_intercept_end'=>'},"is_login"',
        'comment_list'=>'',
        'comment_content'=>'',
	    
	    'comment_dateline'=>'<em id="authorposton(.*?)<\/em>',
	    
	    'author_list'=>'<div class="authi"><a.*?class="xw1".*?>(.*?)<\/a>',
        
        'func'=>array(
        	'list_start'=>'list_start_wukong_com',
            'page_deal'=>'page_deal_wukong_com',
            'comment_middle'=>'comment_middle_wukong_com',
            'dateline_start'=>'dateline_start_wukong_com',
            'author_start'=>'author_start_wukong_com',
        ),
	)
	
);


if(! function_exists('list_start_wukong_com'))
{
	function list_start_wukong_com($grab)
	{
		$json = json_decode($grab['html'], TRUE);

		$grab['title'] = array();
		$grab['source'] = array();

		if(! $json || ! $json['data']){
			return false;
		}
		
        $filename = DISCUZ_ROOT.'data/plugindata/'.PLUGIN_NAME.'_cache.log';
		if(strpos($grab['url'], 'search_text=') !== FALSE && $json['data']['feed_question'])
		{
			foreach($json['data']['feed_question'] as $value)
			{
				$grab['source'][] = 'https://www.wukong.com/question/'.$value['question']['qid'].'/';
				$grab['title'][] = $value['question']['title'];
			}
		}
		else
		{
		    $behot_time = 0;
			foreach($json['data'] as $value)
			{
				$grab['source'][] = 'https://www.wukong.com/question/'.$value['question']['qid'].'/';
				$grab['title'][] = $value['question']['title'];
					            
            	$behot_time = $value['behot_time'];
			}
			file_put_contents($filename, $behot_time);
		}

	
		lib_func_grab::$repeat_count = 0;
    
        //采集详细页
        foreach($grab['source'] as $key => $source)
        {
            $identify = lib_func_grab::save_identify($source);

            if(lib_base::table('admin_grab')->grab_is_exist_by_identify($identify))
            {
                $notice = lib_base::lang('func_grab_repeat').$source;
                lib_base::back_html($notice, 1);
                lib_func_grab::$repeat_count++;
                
                if(lib_func_grab::$repeat_count >= lib_func_grab::$repeat_limit){
                    $notice = sprintf(lib_base::lang('func_grab_repeat_number'), lib_func_grab::$repeat_limit).$source;
                    lib_base::back_html($notice, 1);
                    break;
                }
                
                continue;
            }
            
            lib_func_grab::$grab_new++;

            lib_func_grab::grab_detail_local($grab['id'], $grab['title'][$key], $source);
        }

        //更新机制
        lib_func_grab::nav_crontime_update($grab['id'], $grab['crontime']);
        
		return true;
	}
}

if(! function_exists('comment_middle_wukong_com'))
{
    function comment_middle_wukong_com($grab)
    {
        $data = json_decode($grab['html'], TRUE);
        
        $comment = array();
        
        foreach($data as $key => $value)
        {
            $floor = $key + 1;
            $comment[$floor] = trim($value['content']);
        
            //过滤
            lib_func_grab::content_filter_tag($comment[$floor]);
            lib_func_grab::src_deal($comment[$floor], $grab['host']);
            lib_func_grab::iframe_deal($comment[$floor], $grab['host']);
            lib_func_grab::href_deal($comment[$floor], $grab['host']);
        }
        
        return $comment;
    }
}

if(! function_exists('dateline_start_wukong_com'))
{
    function dateline_start_wukong_com($grab)
    {
        $data = json_decode($grab['html'], TRUE);

        $dateline = array();

        foreach($data as $key => $value){
            $floor = $key + 1;
            $dateline[$floor] = $value['create_time'] ? date('Y-m-d H:i:s', $value['create_time']) : '';
            if($key == 0){
                $dateline[0] = $value['create_time'] ? date('Y-m-d H:i:s', $value['create_time'] - mt_rand(60, 3600)) : '';
            }
        }

        return $dateline;
    }
}

if(! function_exists('author_start_wukong_com'))
{
    function author_start_wukong_com($grab)
    {
        $data = json_decode($grab['html'], TRUE);

        $author = array();

        foreach($data as $key => $value){
            $floor = $key + 1;
            $author[$floor] = $value['user']['uname'] ? $value['user']['uname'] : '';
        }

        return $author;
    }
}

if(! function_exists('page_deal_wukong_com'))
{
	function page_deal_wukong_com($page, $nav)
	{
		$url = $nav['source'];
		$title = $nav['title'];

		//搜索关键词生成链接
		if(strpos($url, 'wenda/web') === FALSE){
		    if(CHARSET == 'gbk'){
		        $title = lib_base::string_gbk_to_utf8($title);
		    }
		    $url = 'https://www.wukong.com/wenda/wapshare/search/brow/?search_text='.urlencode($title).'&offset=0';
		}

		$url = preg_replace('/(&t=.*?&)/i', '&t='.(time()*1000).'&', $url);

		if($page == 1){
		    $filename = DISCUZ_ROOT.'data/plugindata/'.PLUGIN_NAME.'_cache.log';
		    file_put_contents($filename, 0);
		}
		
        if($page != 1){
        	if(strpos($url, 'search_text=') !== FALSE){
        		$url = str_replace('/brow/', '/loadmore/', $url);
        		$url = str_replace('offset=0', 'offset='.(($page - 1) * 10), $url);
        	}else{
        	    $filename = DISCUZ_ROOT.'data/plugindata/'.PLUGIN_NAME.'_cache.log';
        	    $max_behot_time = file_get_contents($filename);
        		$max_behot_time && $url .= '&max_behot_time='.$max_behot_time;
        	}
    	}

		return $url;
	}
}