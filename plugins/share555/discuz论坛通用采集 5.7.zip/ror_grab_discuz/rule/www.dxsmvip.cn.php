<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule = array(
	
	'0'=>array(
	
		'list_intercept_start'=>'<main class="site-main">',
		'list_intercept_filter'=>'',
		'list_intercept_end'=>'</main>',
		'list_list'=>'<h2 class="entry-title">(.*?)<\/h2>',
		'list_title'=>'<a.*?>(.*?)<\/a>',
		'list_source'=>'href="(.*?)"',
	  
        'con_intercept_start'=>'<div class="entry-wrapper">',
        'con_intercept_filter'=>array('<span.*?>','</span>','&nbsp;','			','style=".*?"'),
        'con_intercept_end'=>'<div class="article-copyright">',
        
        'tags_intercept_start'=>'',
        'tags_intercept_filter'=>'',
        'tags_intercept_end'=>'',
        'tags_list'=>'',
        
        'comment_intercept_start'=>'',
        'comment_intercept_filter'=>'',
        'comment_intercept_end'=>'',
        'comment_list'=>'',
        'comment_content'=>'',
	    
	    'comment_dateline'=>'',
	    
	    'author_list'=>'',
        
        'func'=>array(
        	'detail_deal_more'=>'detail_deal_more_www_dxsmvip_cn',
            'page_deal'=>'page_deal_www_dxsmvip_cn',
        ),
	)
	
);

//采集内容处理
if(! function_exists('detail_deal_more_www_dxsmvip_cn'))
{
    function detail_deal_more_www_dxsmvip_cn(& $html, $grab)
    {
        $html_all = $grab['html'];
        
        if(strpos($html_all, 'DPlayer') === FALSE){
            return;
        }
        
        lib_func_grab::html_intercept($html_all, "url: '", 'start');
        lib_func_grab::html_intercept($html_all, "'", 'end');

        if(! $html_all || strpos($html_all, 'http') === FALSE){
            return;
        }
        
        $html = '[iframe=100%,500px]'.$html_all.'[/iframe]'.$html;
    }
}

if(! function_exists('page_deal_www_dxsmvip_cn'))
{
    function page_deal_www_dxsmvip_cn($page, $nav)
    {
        $url = $nav['source'];

        if($page == 1){
            return $url;
        }

        $url .= '&PageNo='.$page;
        
        return $url;
    }
}