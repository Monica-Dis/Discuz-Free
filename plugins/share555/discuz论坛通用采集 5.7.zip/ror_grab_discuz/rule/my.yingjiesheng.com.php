<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['list_intercept_start'] = '<ul class="searchResult">';
$rule[0]['list_intercept_filter'] = array('');
$rule[0]['list_intercept_end'] = '</ul>';
$rule[0]['list_list'] = '<h3 class="title">(.*?)<\/h3>';
$rule[0]['list_title'] = '<a .*?>(.*?)<\/a>';
$rule[0]['list_source'] = 'href="(.*?)"';

$rule[0]['con_intercept_start'] = '<div class="ldiv">';
$rule[0]['con_intercept_filter'] = array('<a href="javascript.*?>.*?<\/a>');
$rule[0]['con_intercept_end'] = '<div class="pre_next';
$rule[0]['con_more_intercept_start'] = '';
$rule[0]['con_more_intercept_filter'] = array();
$rule[0]['con_more_intercept_end'] = '';

$rule[0]['tags_intercept_start'] = '';
$rule[0]['tags_intercept_filter'] = array();
$rule[0]['tags_intercept_end'] = '';
$rule[0]['tags_list'] = '';

$rule[0]['comment_intercept_start'] = '';
$rule[0]['comment_intercept_filter'] = array();
$rule[0]['comment_intercept_end'] = '';
$rule[0]['comment_list'] = '';

$rule[0]['comment_dateline'] = '';
$rule[0]['author_list'] = '';

$rule[0]['func'] = array(
    'list_deal'=>'list_deal_yingjiesheng_com',
    'page_deal'=>'page_deal_yingjiesheng_com',
    'detail_deal_more'=>'detail_deal_more_yingjiesheng_com',
    'comment_deal'=>'comment_deal_yingjiesheng_com',
    'thread_data_get'=>'thread_data_get_yingjiesheng_com',
);

if(! function_exists('list_deal_yingjiesheng_com'))
{
    function list_deal_yingjiesheng_com(& $grab)
    {
        foreach($grab['title'] as $key => $title){
            $grab['title'][$key] = strip_tags($title);
        }
    }
}

//采集内容处理
if(! function_exists('detail_deal_more_yingjiesheng_com'))
{
    function detail_deal_more_yingjiesheng_com(& $html, $grab)
    {
        $data = '';
        
        preg_match_all('/<div class="combox">(.*?)<\/div>/is', $html, $result_div);
        if($result_div[1]){
            foreach($result_div[1] as $value){
                $data .= $value.'<br/>';
                break;
            }
        }
        
        preg_match_all('/<div id="wordDiv2" class="combox">(.*?)<\/div>/is', $html, $result_div);
        if($result_div[1]){
            foreach($result_div[1] as $value){
                $data .= $value.'<br/>';
                break;
            }
        }
        
        $html = $data;
    }
}

if(! function_exists('page_deal_yingjiesheng_com'))
{
    function page_deal_yingjiesheng_com($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url .= '&start='.(($page - 1) * 10);
        
        return $url;
    }
}

if(! function_exists('comment_deal_yingjiesheng_com'))
{
    function comment_deal_yingjiesheng_com(& $comment, $grab)
    {
        $comment['gongzuodi'] = '';
        $comment['zhiweileixing'] = '';
        $comment['zhiwei'] = '';
        
        $html = $grab['html'];
        
        $pattern = '/<label class="lab">(.*?)<\/label>/is';
        preg_match_all($pattern, $html, $result_label);
        if($result_label[1])
        {
            foreach($result_label[1] as $value)
            {
                if(strpos($value, lib_base::string_utf8_to_gbk('工作地点：')) !== FALSE){
                    $pattern = '/<span class="i">(.*?)<\/span>/is';
                    preg_match($pattern, $value, $result_span);
                    if($result_span[1]) {
                        $comment['gongzuodi'] = lib_base::string_gbk_to_utf8($result_span[1]);
                    }
                }else if(strpos($value, lib_base::string_utf8_to_gbk('职位类型：')) !== FALSE){
                    $pattern = '/<span class="i">(.*?)<\/span>/is';
                    preg_match($pattern, $value, $result_span);
                    if($result_span[1]) {
                        $comment['zhiweileixing'] = lib_base::string_gbk_to_utf8($result_span[1]);
                    }
                }else if(strpos($value, lib_base::string_utf8_to_gbk('职位：')) !== FALSE){
                    $pattern = '/<b class="i">(.*?)<\/b>/is';
                    preg_match($pattern, $value, $result_b);
                    if($result_b[1]) {
                        $comment['zhiwei'] = lib_base::string_gbk_to_utf8($result_b[1]);
                    }
                }
            }
        }
    }
}

if(! function_exists('thread_data_get_yingjiesheng_com'))
{
    function thread_data_get_yingjiesheng_com($grab)
    {
        $comment = $grab['comment'] ? unserialize($grab['comment']) : '';
        
        $fid = $grab['fid'];
        $tid = $grab['tid'];
        $pid = $grab['pid'];
        $uid = $grab['authorid'];
        
        $gongzuodi = $comment['gongzuodi'] ? $comment['gongzuodi'] : '';
        $zhiweileixing = $comment['zhiweileixing'] ? $comment['zhiweileixing'] : '';
        $zhiwei = $comment['zhiwei'] ? $comment['zhiwei'] : '';
        
        //采集分类
        $sortid = 0;
        $sql = 'SELECT threadsorts FROM %t WHERE fid=%d';
        $threadsorts = DB::result_first($sql, array('forum_forumfield', $fid));
        if($threadsorts)
        {
            $threadsorts = unserialize($threadsorts);
            foreach($threadsorts['types'] as $key => $value){
                $sortid = $key;
                break;
            }
            
            $sql = 'Describe %t zhiweileixing';
            $field_is_exist = DB::result_first($sql, array('forum_optionvalue'.$sortid));
            
            $typeoption_array = array();
            if($field_is_exist)
            {
                $add_optionvalue = array(
                    'fid'=>$fid,
                    'tid'=>$tid,
                    'gongzuodi'=>$gongzuodi,
                    'zhiweileixing'=>$zhiweileixing,
                    'zhiwei'=>$zhiwei,
                );
                DB::insert('forum_optionvalue'.$sortid, $add_optionvalue);
                $typeoption_array = array('gongzuodi','zhiweileixing','zhiwei');
            }
            else
            {
                $sql = 'Describe %t zhiweileixing_'.$sortid;
                $field_is_exist = DB::result_first($sql, array('forum_optionvalue'.$sortid));
                if(! $field_is_exist){
                    return;
                }
                
                $add_optionvalue = array(
                    'fid'=>$fid,
                    'tid'=>$tid,
                    'gongzuodi_'.$sortid=>$gongzuodi,
                    'zhiweileixing_'.$sortid=>$zhiweileixing,
                    'zhiwei_'.$sortid=>$zhiwei,
                );
                DB::insert('forum_optionvalue'.$sortid, $add_optionvalue);
                $typeoption_array = array('gongzuodi_'.$sortid,'zhiweileixing_'.$sortid,'zhiwei_'.$sortid);
            }
            
            $sql = 'SELECT optionid,identifier FROM %t WHERE identifier IN(%n)';
            $typeoption_list = DB::fetch_all($sql, array('forum_typeoption', $typeoption_array));
            
            foreach($typeoption_list as $value)
            {
                $add_typeoptionvar = array(
                    'sortid'=>$sortid,
                    'tid'=>$tid,
                    'fid'=>$fid,
                    'optionid'=>$value['optionid'],
                    'expiration'=>0,
                    'value'=>$add_optionvalue[$value['identifier']],
                );
                DB::insert('forum_typeoptionvar', $add_typeoptionvar);
            }
            
            if($sortid)
            {
                $edit = array(
                    'sortid'=>$sortid,
                );
                
                DB::update('forum_thread', $edit, array('tid'=>$tid));
            }
        }
    }
}