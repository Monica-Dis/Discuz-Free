<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$rule = array(
    
    0=>array(
        
        'list_intercept_start'=>'g_page_config =',
        'list_intercept_filter'=>'',
        'list_intercept_end'=>'g_srp_loadCss',
        'list_list'=>'',
        'list_title'=>'',
        'list_source'=>'',
        'list_cover'=>'',
        'list_summary'=>'',
        
        
        'con_intercept_start'=>'<div id="attributes" class="attributes">',
        'con_intercept_filter'=>'',
        'con_intercept_end'=>'</div>',
        
        'comment_intercept_start'=>'data-listApi = "',
        'comment_intercept_filter'=>'',
        'comment_intercept_end'=>'"',
        'comment_list'=>'',
        'comment_content'=>'',
        
        'con_intercept_start1'=>'<ul id="J_AttrUL">',
        'con_intercept_filter1'=>'',
        'con_intercept_end1'=>'</ul>',
        
        'comment_intercept_start1'=>'w.g_config=',
        'comment_intercept_filter1'=>'',
        'comment_intercept_end1'=>'}',
        'comment_list1'=>'',
        'comment_content1'=>'',
        
        
        'func'=>array(
            'list_middle'=>'list_middle_taobao',
            'detail_start'=>'detail_start_taobao',
            'page_deal'=>'page_deal_taobao',
        ),
    ),
    
);

if(!function_exists('list_middle_taobao'))
{
    function list_middle_taobao($grab)
    {
        $html = rtrim($grab['html'], ' ;');
        $json = json_decode($html, TRUE);
        
        $list = $json['mods']['itemlist']['data']['auctions'];
        if(! $list){
            lib_base::js_back_show('&#26080;&#37319;&#38598;&#25968;&#25454;');
        }
        
        //匹配标题、源链接
        $grab['title']  = array();
        $grab['source'] = array();
        foreach($list as $key => $value){
            if(strpos($value['detail_url'], 'detail.tmall.com') || strpos($value['detail_url'], 'item.taobao.com')){
                $grab['title'][$key] = $value['raw_title'];
                $grab['source'][$key] = 'https:'.$value['detail_url'];
            }
        }
        
        lib_func_grab::$repeat_count = 0;
        
        //采集详细页
        foreach($grab['source'] as $key => $value)
        {
            $identify = lib_func_grab::save_identify($value);
            
            $sql = 'SELECT COUNT(*) FROM '.DB::table('plugin_'.PLUGIN_NAME)." WHERE identify='".$identify."'";
            $count = DB::result_first($sql);
            if($count)
            {
                $notice = '&#20869;&#23481;&#37319;&#38598;&#37325;&#22797;&#65306;'.$value;
                lib_base::back_html($notice, 1);
                lib_func_grab::$repeat_count++;
                
                if(lib_func_grab::$repeat_count >= lib_func_grab::$repeat_limit){
                    $notice = '&#37319;&#38598;&#20869;&#23481;&#37325;&#22797;&#27425;&#25968;&#36229;&#36807; '.lib_func_grab::$repeat_limit.' &#27425;&#65292;&#20013;&#26029;&#37319;&#38598;&#65306;'.$value;
                    lib_base::back_html($notice, 1);
                    break;
                }
                
                continue;
            }
            
            lib_func_grab::$grab_new++;
            
            lib_func_grab::grab_detail_local($grab['id'], $grab['title'][$key], $value);
        }
        
        //更新机制
        lib_func_grab::nav_crontime_update($grab['id'], $grab['crontime']);
        
        return TRUE;
    }
}

if(!function_exists('detail_start_taobao'))
{
    function detail_start_taobao($grab)
    {
        $source = $grab['source'][$grab['key']];
        if(strpos($source, 'item.taobao.com') !== FALSE){
            return detail_grab_taobao($grab);
        }else if(strpos($source, 'detail.tmall.com') !== FALSE){
            return detail_grab_tmall($grab);
        }
        
        return FALSE;
    }
    
    function detail_grab_taobao($grab)
    {
        $title = trim($grab['title'][$grab['key']]);
        $source = $grab['source'][$grab['key']];
        $content = '';
        
        $html_temp = $grab['html'];
        $notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#21830;&#21697;&#23646;&#24615;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$source;
        if(lib_func_grab::html_intercept($html_temp, $grab['rule']['con_intercept_start'], 'start', $notice))
        {
            $notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#21830;&#21697;&#23646;&#24615;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$source;
            if(lib_func_grab::html_intercept($html_temp, $grab['rule']['con_intercept_end'], 'end', $notice))
            {
                $pattern = '/<li.*?>(.*?)<\/li>/';
                preg_match_all($pattern, $html_temp, $result);
                
                if($result[1]){
                    foreach($result[1] as $value){
                        $content .= '<p>'.$value.'</p>';
                    }
                }
            }
        }
        
        $html_temp = $grab['html'];
        $notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#21830;&#21697;&#25551;&#36848;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$source;
        
        if(lib_func_grab::html_intercept($html_temp, 'descUrl', 'start', $notice))
        {
            $notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#21830;&#21697;&#25551;&#36848;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$source;
            if(lib_func_grab::html_intercept($html_temp, ',', 'end', $notice))
            {
                if($html_temp)
                {
                    $url = explode(':', $html_temp);
                    if($url[3])
                    {
                        $desc_url = 'https:'.trim(str_replace("'", '', $url[3]));
                        
                        $urls = parse_url($desc_url);
                        $host = isset($urls['scheme']) ? $urls['scheme'].'://'.$urls['host'] : $urls['host'];
                        
                        $html = lib_func_grab::get($desc_url, $grab['detail_url'], $grab['host'], $grab['cookie']);
                        
                        $html = str_replace(array("var desc='","';","\\"), array(''), $html);
                        
                        
                        //$html =  str_replace(array(' ','   ','  '), array(' '), $html);
                        //$html = html_entity_decode($html);
                        //lib_func_grab::content_filter_tag($html);
                        //lib_func_grab::content_filter($html, array('<title>(.*?)<\/title>'));
                        
                        if(strpos($html, '<img') !== FALSE){
                            $content .= $html;
                        }
                    }
                    
                }
            }
        }
        
        $content = str_replace('sp;', '', $content);
        $content = str_replace('&nb', ' ', $content);
        
        $comment = array(
            'list'=>array(),
            'dateline'=>array(),
            'author'=>array(),
        );
        $html_temp = $grab['html'];
        $notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#21830;&#21697;&#35780;&#35770;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$source;
        if(lib_base::settings('is_grab_comment') && $grab['rule']['comment_intercept_start'] && lib_func_grab::html_intercept($html_temp, $grab['rule']['comment_intercept_start'], 'start', $notice))
        {
            $notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#21830;&#21697;&#35780;&#35770;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$source;
            if(lib_func_grab::html_intercept($html_temp, $grab['rule']['comment_intercept_end'], 'end', $notice))
            {
                $comment_url = 'https:'.$html_temp.htmlspecialchars('&').'currentPageNum=1'.htmlspecialchars('&').'pageSize=20';
                
                $urls = parse_url($comment_url);
                $host = isset($urls['scheme']) ? $urls['scheme'].'://'.$urls['host'] : $urls['host'];
                
                $json = lib_func_grab::get(htmlspecialchars_decode($comment_url), $host, $host, $grab['cookie']);
                $json = trim($json, '()');
                $json = json_decode($json, TRUE);
                if($json)
                {
                    
                    $comment_sort = array();
                    foreach($json['comments'] as $key => $value)
                    {
                        $time = str_replace('年', '-', $value['date']);
                        $time = str_replace('月', '-', $time);
                        $time = str_replace('日', '', $time);
                        $comment_sort[strtotime($time)] = array(
                            'list'=>$value['content'],
                            'author'=>$value['user']['nick'],
                            'dateline'=>$time,
                        );
                    }
                    
                    ksort($comment_sort);
                    $i = 1;
                    foreach($comment_sort as $value)
                    {
                        $comment['list'][$i] = $value['list'];
                        $comment['author'][$i] = $value['author'];
                        $comment['dateline'][$i] = $value['dateline'];
                        if($i == 1){
                            $comment['dateline'][0] = date('Y-m-d H:i:s', strtotime($value['dateline']) - mt_rand(60, 3600));
                        }
                        $i++;
                    }
                }
            }
        }
        
        $comment = lib_base::convert_utf8_to_gbk($comment);
        
        lib_func_grab::grab_save($grab, $title, $content, array(), $comment, $source);
        
        return TRUE;
    }
    
    function detail_grab_tmall($grab)
    {
        $title = trim($grab['title'][$grab['key']]);
        $source = $grab['source'][$grab['key']];
        $content = '';
        
        $html_temp = $grab['html'];
        $notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#21830;&#21697;&#23646;&#24615;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$source;
        if(lib_func_grab::html_intercept($html_temp, $grab['rule']['con_intercept_start1'], 'start', $notice))
        {
            $notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#21830;&#21697;&#23646;&#24615;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$source;
            if(lib_func_grab::html_intercept($html_temp, $grab['rule']['con_intercept_end1'], 'end', $notice))
            {
                $pattern = '/<li.*?>(.*?)<\/li>/';
                preg_match_all($pattern, $html_temp, $result);
                
                if($result[1]){
                    foreach($result[1] as $value){
                        $value = str_replace(' ', '', $value);
                        $content .= '<p>'.$value.'</p>';
                    }
                }
            }
        }
        
        $html_temp = $grab['html'];
        $notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#21830;&#21697;&#25551;&#36848;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$source;
        if(lib_func_grab::html_intercept($html_temp, '"httpsDescUrl":"', 'start', $notice))
        {
            $notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#21830;&#21697;&#25551;&#36848;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$source;
            if(lib_func_grab::html_intercept($html_temp, '"', 'end', $notice))
            {
                if($html_temp)
                {
                    $url = 'https:'.$html_temp;
                    
                    $desc = lib_func_grab::get($url, $grab['detail_url'], $grab['host'], $grab['cookie']);
                    
                    $desc = str_replace(array("var desc='","';","\\"), array(''), $desc);
                    
                    //$desc =  str_replace(' ', ' ', $desc);
                    //$desc = html_entity_decode($desc);
                    //lib_func_grab::content_filter_tag($desc);
                    $desc = str_replace('<p>', '', $desc);
                    $desc = str_replace('</p>', '', $desc);
                    
                    if(strpos($desc, '<img') !== FALSE){
                        $content .= $desc;
                    }
                }
            }
        }
        
        $content = str_replace('sp;', '', $content);
        $content = str_replace('&nb', ' ', $content);
        
        $comment = array(
            'list'=>array(),
            'dateline'=>array(),
            'author'=>array(),
        );
        $html_temp = $grab['html'];
        $notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#21830;&#21697;&#35780;&#35770;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$source;
        if(lib_base::settings('is_grab_comment') && $grab['rule']['comment_intercept_start1'] && lib_func_grab::html_intercept($html_temp, $grab['rule']['comment_intercept_start1'], 'start', $notice))
        {
            $notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#21830;&#21697;&#35780;&#35770;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$source;
            if(lib_func_grab::html_intercept($html_temp, $grab['rule']['comment_intercept_end1'], 'end', $notice))
            {
                preg_match('/itemId:"(.*?)"/', $html_temp, $itemId);
                preg_match('/sellerId:"(.*?)"/', $html_temp, $sellerId);
                
                if($itemId[1] && $sellerId[1])
                {
                    $host = 'https://rate.tmall.com/';
                    $comment_url = 'https://rate.tmall.com/list_detail_rate.htm?itemId='.$itemId[1].'&sellerId='.$sellerId[1].'&order=3&'.'current'.'Page=1';
                    
                    $json = lib_func_grab::get(htmlspecialchars_decode($comment_url), $host, $host, $grab['cookie']);
                    $json = trim(str_replace('jsonp128', '', $json), '()');
                    $json = json_decode($json, TRUE);
                    
                    if($json['rateDetail']['rateList'])
                    {
                        $comment_sort = array();
                        foreach($json['rateDetail']['rateList'] as $key => $value)
                        {
                            $comment_sort[strtotime($value['rateDate'])] = array(
                                'list'=>$value['rateContent'],
                                'author'=>$value['displayUserNick'],
                                'dateline'=>$value['rateDate'],
                            );
                        }
                        
                        ksort($comment_sort);
                        $i = 1;
                        foreach($comment_sort as $value)
                        {
                            $comment['list'][$i] = $value['list'];
                            $comment['author'][$i] = $value['author'];
                            $comment['dateline'][$i] = $value['dateline'];
                            if($i == 1){
                                $comment['dateline'][0] = date('Y-m-d H:i:s', strtotime($value['dateline']) - mt_rand(60, 3600));
                            }
                            $i++;
                        }
                    }
                }
            }
        }
        
        $comment = lib_base::convert_utf8_to_gbk($comment);
        
        lib_func_grab::grab_save($grab, $title, $content, array(), $comment, $source);
        
        return TRUE;
    }
}

if(! function_exists('page_deal_taobao'))
{
    function page_deal_taobao($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url .= '&s='.($page - 1) * 44;
        
        return $url;
    }
}