<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['list_intercept_start'] = "<ul class='list-none";
$rule[0]['list_intercept_filter'] = array();
$rule[0]['list_intercept_end'] = '</ul>';
$rule[0]['list_list'] = '<li (.*?)<\/li>';
$rule[0]['list_title'] = "title='(.*?)'";
$rule[0]['list_source'] = "href='(.*?)'";

$rule[0]['con_intercept_start'] = '<div class="web-right';
$rule[0]['con_intercept_filter'] = array('<div id="nav">.*?<\/div>');
$rule[0]['con_intercept_end'] = '<div id="footer">';
$rule[0]['con_more_intercept_start'] = '';
$rule[0]['con_more_intercept_filter'] = array();
$rule[0]['con_more_intercept_end'] = '';

$rule[0]['tags_intercept_start'] = '';
$rule[0]['tags_intercept_filter'] = array();
$rule[0]['tags_intercept_end'] = '';
$rule[0]['tags_list'] = '';

$rule[0]['comment_intercept_start'] = '';
$rule[0]['comment_intercept_filter'] = array();
$rule[0]['comment_intercept_end'] = '';
$rule[0]['comment_list'] = '';

$rule[0]['comment_dateline'] = '';
$rule[0]['author_list'] = '';

$rule[0]['func'] = array(
    'list_deal'=>'list_deal_yasyoku_net',
    'detail_deal_more'=>'detail_deal_more_yasyoku_net',
);

if(! function_exists('list_deal_yasyoku_net'))
{
    function list_deal_yasyoku_net(& $grab)
    {
        foreach($grab['title'] as $key => $title){
            $grab['title'][$key] = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $title);
        }

		foreach($grab['source'] as $key => $source){
			if(strpos($source, 'yasyoku.net/showproduct.php') !== FALSE){
				$grab['source'][$key] = str_replace('yasyoku.net/showproduct.php', 'yasyoku.net/dddd/showproduct.php', $source);
			}
        }
    }
}

//采集内容处理
if(! function_exists('detail_deal_more_yasyoku_net'))
{
    function detail_deal_more_yasyoku_net(& $html, $grab)
    {
        $data = '';
        
        preg_match_all('/<!--.*?-->/is', $html, $result);
        if($result){
            foreach($result[0] as $value){
                $html = str_replace($value, '', $html);
            }
        }
        
        preg_match_all('/<video .*?src="(.*?)".*?>/is', $html, $result_video);
        if($result_video[1]){
            $result_video[1] = array_unique($result_video[1]);
            foreach($result_video[1] as $key => $value){
                $url = parse_url($value);
                $value = $url['scheme'].'://'.$url['host'].$url['path'];
                $data .= '[media=x,500,375]'.$value.'[/media]<br/>';
            }
        }
        
        preg_match_all("/<img .*?src='(.*?)'.*?>/is", $html, $result_img);
        if($result_img[1]){
            $result_img[1] = array_unique($result_img[1]);
            foreach($result_img[1] as $value){
                $data .= '<img src="'.$value.'"/><br/>';
            }
        }
        
        preg_match('/<ul class="list-none">(.*?)<\/ul>/is', $html, $result_ul);
        if($result_ul[1]){
            preg_match_all('/<li>(.*?)<\/li>/is', $result_ul[1], $result_li);
            if($result_li[1]){
                foreach($result_li[1] as $value){
					$data .= $value.'<br/>';
				}
			}
        }
        
        preg_match('/<h3 class="ctitle">(.*?)<\/h3>/is', $html, $result_h3);
        if($result_h3[1]){
            $data .= $result_h3[1].'<br/>';
        }
        
        $data = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $data);
        
        $html = $data;
    }
}