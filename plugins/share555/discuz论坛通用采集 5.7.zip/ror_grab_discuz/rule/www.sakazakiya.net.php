<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule = array(
    
    '0'=>array(
        
        'list_intercept_start'=>'<div class="list">',
        'list_intercept_filter'=>array(),
        'list_intercept_end'=>'<div class="shopinfo">',
        'list_list'=>'<a (.*?)<\/a>',
        'list_title'=>'<p class="name">(.*?)<\/p>',
		'list_source'=>'href="(.*?)"',
        
        'con_intercept_start'=>'class="main_content">',
        'con_intercept_filter'=>array(''),
        'con_intercept_end'=>'<div class="op">',
        
        'func'=>array(
            'list_deal'=>'list_deal_www_sakazakiya_net',
			'detail_deal_more'=>'detail_deal_more_www_sakazakiya_net',
        )
    ),
    
);

if(! function_exists('list_deal_www_sakazakiya_net'))
{
    function list_deal_www_sakazakiya_net(& $grab)
    {
        foreach($grab['title'] as $key => $title){
            $grab['title'][$key] = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $title);
        }
    }
}

//采集内容处理
if(! function_exists('detail_deal_more_www_sakazakiya_net'))
{
    function detail_deal_more_www_sakazakiya_net(& $html, $grab)
    {
        $data = '';
        
        preg_match_all('/<!--.*?-->/is', $html, $result);
        if($result){
            foreach($result[0] as $value){
                $html = str_replace($value, '', $html);
            }
        }
        
        preg_match_all('/<video .*?src="(.*?)".*?>/is', $html, $result_video);
        if($result_video[1]){
            $result_video[1] = array_unique($result_video[1]);
            foreach($result_video[1] as $key => $value){
                $url = parse_url($value);
                $value = $url['scheme'].'://'.$url['host'].$url['path'];
                $data .= '[media=x,500,375]'.$value.'[/media]<br/>';
            }
        }
        
        preg_match_all('/<img .*?src="(.*?)".*?>/is', $html, $result_img);
        if($result_img[1]){
            $result_img[1] = array_unique($result_img[1]);
            foreach($result_img[1] as $value){
                $data .= '<img src="'.$value.'"/><br/>';
            }
        }
        
        preg_match('/<h3 class=" pulse wow">(.*?)<\/h3>/is', $html, $result_h3);
        if($result_h3[1]){
			$data .= trim($result_h3[1]).'<br/>';
        }

		preg_match('/<p class="size pulse wow">(.*?)<\/p>/is', $html, $result_p);
        if( $result_p[1]){
			$data .= trim($result_p[1]).'<br/>';
        }

        
        $data = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $data);
        
        $html = $data;
    }
}