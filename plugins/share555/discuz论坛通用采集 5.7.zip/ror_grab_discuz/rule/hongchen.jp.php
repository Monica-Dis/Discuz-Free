<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[$ruleid]['list_intercept_start'] = '<div class="bg_fff"';
$rule[$ruleid]['list_intercept_filter'] = array('');
$rule[$ruleid]['list_intercept_end'] = '<script>';
$rule[$ruleid]['list_list'] = '<div class="list_info">(.*?)<div class="list_info_right';
$rule[$ruleid]['list_title'] = '<p class="font_12">(.*?)<\/p>';
$rule[$ruleid]['list_source'] = 'href="(.*?)"';

$rule[$ruleid]['con_intercept_start'] = '<ul class="con_banner" style="position:relative; ">';
$rule[$ruleid]['con_intercept_filter'] = '';
$rule[$ruleid]['con_intercept_end'] = '<div class="btn_blue3';
$rule[$ruleid]['con_more_intercept_start'] = '';
$rule[$ruleid]['con_more_intercept_filter'] = '';
$rule[$ruleid]['con_more_intercept_end'] = '';

$rule[$ruleid]['tags_intercept_start'] = '';
$rule[$ruleid]['tags_intercept_filter'] = '';
$rule[$ruleid]['tags_intercept_end'] = '';
$rule[$ruleid]['tags_list'] = '';

$rule[$ruleid]['comment_intercept_start'] = '';
$rule[$ruleid]['comment_intercept_filter'] = '';
$rule[$ruleid]['comment_intercept_end'] = '';
$rule[$ruleid]['comment_list'] = '';

$rule[$ruleid]['comment_dateline'] = '';
$rule[$ruleid]['author_list'] = '';

$rule[$ruleid]['func'] = array(
    'detail_deal_more'=>'detail_deal_more_hongchen_jp',
);

//采集内容处理
if(! function_exists('detail_deal_more_hongchen_jp'))
{
    function detail_deal_more_hongchen_jp(& $html, $grab)
    {
        $url = $grab['detail_url'];
        
        preg_match('/gid\/(.*?)\.html/', $url, $result);
        
        $id = $result[1];
        
        $pic_url = 'http://hongchen.jp/mobile.php/Index/girl_detailspic/gid/'.$id.'html';
        $video_url = 'http://hongchen.jp/mobile.php/Index/video/id/'.$id.'/url/index.html';

        $pic_html = lib_func_grab::get($pic_url);
        
        $notice = lib_base::lang('func_detail_start_fail').$grab['detail_url'];
        lib_func_grab::html_intercept($pic_html, '<div id="tops">', 'start', $notice);
        
        $notice = lib_base::lang('func_detail_end_fail').$grab['detail_url'];
        lib_func_grab::html_intercept($pic_html, '<div class="nav"', 'end', $notice);

        lib_func_grab::src_deal($pic_html, $grab['host']);
        
        $video_html = '<p>video：<a href="'.$video_url.'" target="_blank">'.$video_url.'</a></p>';

        $html = $html.$pic_html.$video_html;
    }
}