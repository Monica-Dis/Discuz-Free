<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$rule = array(
    
    '0'=>array(
        
        'list_intercept_start'=>'',
        'list_intercept_filter'=>array(),
        'list_intercept_end'=>'',
        'list_list'=>'',
        'list_source'=>'',
        'list_title'=>'',
        
        'con_intercept_start'=>'<div class="LeftPart">',
        'con_intercept_filter'=>array('<br><br><br>',' <div style="padding-right:10px;">.*?<\/div>'),
        'con_intercept_end'=>'<div class="RightPart">',
        
        'func'=>array(
            'list'=>'list_bhlfw_xyz',
            'page_deal'=>'page_deal_bhlfw_xyz',
            'detail_deal_more'=>'detail_deal_more_bhlfw_xyz',
        )
    ),
    
);

if(! function_exists('page_deal_bhlfw_xyz'))
{
    function page_deal_bhlfw_xyz($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url .= '&page='.$page;
        
        return $url;
    }
}

if(!function_exists('list_bhlfw_xyz'))
{
    function list_bhlfw_xyz(& $grab)
    {
        $url = trim($grab['url']);

        $urls = parse_url($url);
        $paths = explode('/', $urls['path']);
        $grab['host'] = $urls['scheme'].'://'.$urls['host'];
        $cookie = $grab['cookie'];
        
        $posts = explode('&', $urls['query']);
        $post = array();
        foreach($posts as $value){
            list($k, $val) = explode('=', $value);
            $post[$k] = $val;
        }

        $html = lib_func_grab::get($grab['url'], $grab['host'], $urls['host'], $cookie, $post);
        $json = json_decode($html, TRUE);
        if(! $json){
            $notice = '&#21015;&#34920;&#106;&#115;&#111;&#110;&#35299;&#26512;&#26377;&#35823;&#65306;'.$grab['url'];
            lib_base::back_html($notice , 1);
            return;
        }
        if(! $json['data']){
            $notice = '&#26080;&#37319;&#38598;&#25968;&#25454;&#65306;'.$grab['url'];
            lib_base::back_html($notice , 1);
            return;
        }
        
        $host = 'https://bhlfw-1.xyz/index/data/show.html?id=';
        $grab['title'] = array();
        $grab['source'] = array();
        foreach($json['data'] as $key => $value)
        {
            $grab['title'][$key] = $value['title'];
            $grab['source'][$key] = $host.$value['id'];
        }
        
        lib_func_grab::$repeat_count = 0;
        foreach($grab['title'] as $key => $value)
        {
            if(! $value){
                continue;
            }
            
            $source = $grab['source'][$key];
            
            $identify = lib_func_grab::save_identify($source);
            
            $sql = 'SELECT COUNT(*) FROM '.DB::table('plugin_'.PLUGIN_NAME)." WHERE identify='".$identify."'";
            $count = DB::result_first($sql);
            if($count)
            {
                $notice = '&#20869;&#23481;&#37319;&#38598;&#37325;&#22797;&#58;'.$source;
                lib_base::back_html($notice, 1);
                lib_func_grab::$repeat_count++;
                
                if(lib_func_grab::$repeat_count >= lib_func_grab::$repeat_limit){
                    $notice = '&#37319;&#38598;&#20869;&#23481;&#37325;&#22797;&#27425;&#25968;&#36229;&#36807; '.lib_func_grab::$repeat_limit.' &#27425;&#65292;&#20013;&#26029;&#37319;&#38598;&#58;'.$source;
                    lib_base::back_html($notice, 1);
                    break;
                }
                
                continue;
            }
            
            lib_func_grab::$grab_new++;
            
            lib_func_grab::grab_detail_local($grab['id'], $grab['title'][$key], $source);
        }
        
        //更新机制
        lib_func_grab::nav_crontime_update($grab['id'], $grab['crontime']);
        
        return TRUE;
    }
}

//采集内容处理
if(! function_exists('detail_deal_more_bhlfw_xyz'))
{
    function detail_deal_more_bhlfw_xyz(& $html, $grab)
    {
        $data = '';
        
        preg_match_all('/<div class="Profile">(.*?)<\/div>/is', $html, $result_div);
        if($result_div[1]){
            foreach($result_div[1] as $value){
                $data .= trim($value).'<br/>';
            }
        }
        
        preg_match_all('/<div class="my-3">(.*?)<\/div>/is', $html, $result_div);
        if($result_div[1]){
            foreach($result_div[1] as $value){
                $data .= str_replace('   ', '', trim($value)).'<br/>';
            }
        }
        
        preg_match_all('/<div class="Picture">(.*?)<\/div>/is', $html, $result_div);
        if($result_div[1]){
            foreach($result_div[1] as $value){
                $data .= trim($value);
            }
        }
        
        preg_match('/<div class="px-3 pb-3 mt-3">(.*?)<\/div>/is', $html, $result_div);
        if($result_div[1]){
            $data .= trim($result_div[1]);
        }

        $html = $data;
    }
}