<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['con_intercept_filter'] = array('style=".*?"','<table cellspacing="0" cellpadding="0"><tr><td class="t_f".*?>','</td></tr></table>','<div class="modact">(.*?)<\/div>','<div class="locked">(.*?)<\/div>','smilieid="(.*?)"','<i class="pstatus">(.*?)<\/i>','<div class="attach_nopermission attach_tips">(.*?)<\/div>','<span class="atips_close"(.*?)<\/span>','<div class="ptg mbm mtn">(.*?)<\/div>','<em onclick="copycode(.*?)<\/em>','<form.*?id="vfastpostform".*?>(.*?)<\/form>','<div class="mag_viewthread">(.*?)<\/div>','<img src="static\/image.*?>','<div class="a_pr".*?>.*?<\/div>');

$rule[0]['comment_intercept_filter'] = array('style=".*?"','<table cellspacing="0" cellpadding="0"><tr><td class="t_f".*?>','</td></tr></table>','<div class="modact">(.*?)<\/div>','<div class="locked">(.*?)<\/div>','smilieid="(.*?)"','<i class="pstatus">(.*?)<\/i>','<div class="attach_nopermission attach_tips">(.*?)<\/div>','<span class="atips_close"(.*?)<\/span>','<em onclick="copycode(.*?)<\/em>','<div class="quote">(.*?)<\/div>','<div class="mag_viewthread">(.*?)<\/div>','<img src="static\/image.*?>','<div class="a_pr".*?>.*?<\/div>');

$rule[0]['func'] = array(
    'detail_deal_more'=>'detail_deal_more_bbs_0550_com',
    'page_deal'=>'page_deal_bbs_0550_com',
);

if(! function_exists('detail_deal_more_bbs_0550_com'))
{
    function detail_deal_more_bbs_0550_com(& $html, $grab)
    {
        preg_match_all('/<img .*?>/is', $html, $result_img);
        if($result_img){
            foreach($result_img[0] as $value){
                if(strpos($value, 'mobilebgtop.jpg') !== FALSE || strpos($value, 'mobilebgbot.jpg') !== FALSE){
                    $html = str_replace($value, '', $html);
                }
            }
        }
    }
}

if(! function_exists('page_deal_bbs_0550_com'))
{
    function page_deal_bbs_0550_com($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }

        $url = str_replace('.html', '-page-'.$page.'.html', $url);
        
        return $url;
    }
}
