<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(strpos($url, 'weixin.sogou.com/weixin') !== FALSE)
{
    $rule = array(
        
        0=>array(
            
            'list_intercept_start'=>'<ul class="news-list">',
            'list_intercept_filter'=>array('<em>','<!--red_beg-->','<!--red_end-->','</em>'),
            'list_intercept_end'=>'/ul>',
            'list_list'=>'<li .*?>(.*?)<\/li>',
            'list_title'=>'<a target="_blank" .*?>(.*?)<\/a>',
            'list_source'=>'href="(.*?)"',
            
            'con_intercept_start'=>'<body',
            'con_intercept_filter'=>array(),
            'con_intercept_end'=>'</body>',
            
            'tags_intercept_start'=>'<div id="meta_content" class="rich_media_meta_list">',
            'tags_intercept_filter'=>'',
            'tags_intercept_end'=>'</div>',
            'tags_list'=>'<a .*?>(.*?)<\/a>',
            
            'title_intercept_start'=>'<meta property="og:title" content="',
            'title_intercept_filter'=>array(),
            'title_intercept_end'=>'"',
            
            'func'=>array(
                'detail_deal_more'=>'detail_deal_more_weixin_sogou_com'
            ),
        ),
        
    );
}
else 
{
    $rule = array(
        
        0=>array(
            
            'list_intercept_start'=>'<li',
            'list_intercept_filter'=>array('<em>','<!--red_beg-->','<!--red_end-->','</em>'),
            'list_intercept_end'=>'',
            'list_list'=>'<h3>(.*?)<\/h3>',
            'list_title'=>'<a .*?>(.*?)<\/a>',
            'list_source'=>'href="(.*?)"',
            
            'con_intercept_start'=>'<body',
            'con_intercept_filter'=>array(),
            'con_intercept_end'=>'</body>',
            
            'tags_intercept_start'=>'<div id="meta_content" class="rich_media_meta_list">',
            'tags_intercept_filter'=>'',
            'tags_intercept_end'=>'</div>',
            'tags_list'=>'<a .*?>(.*?)<\/a>',
            
            'title_intercept_start'=>'<meta property="og:title" content="',
            'title_intercept_filter'=>array(),
            'title_intercept_end'=>'"',
            
            'func'=>array(
                'detail_deal_more'=>'detail_deal_more_weixin_sogou_com'
            ),
        ),
    );
}


//采集内容处理
if(! function_exists('detail_deal_more_weixin_sogou_com'))
{
    function detail_deal_more_weixin_sogou_com(& $html, $grab)
    {
        $data = '';

        if(strpos($html, '<div class="rich_media_content') !== FALSE)
        {
            //数据类型
            lib_func_grab::$grab_type = 1;
            
            $cover = '';
            if(strpos($html, '<div class="rich_media_thumb_wrp"') !== FALSE) {
                preg_match('/var cover = "(.*?)"/is', $html, $result);
                if($result[1]){
                    $cover = '<img src="'.$result[1].'"/><br>';
                }
            }
            
            $pattern = '<div class="rich_media_content "';
            lib_func_grab::html_intercept($html, $pattern, 'start');
            $pattern = array('id="js_content"','style="visibility: hidden;">');
            lib_func_grab::content_filter($html, $pattern);
            $pattern = '</div>';
            lib_func_grab::html_intercept($html, $pattern, 'end');
            
            $html = str_replace('data-src', 'src', $html);
            $html = str_replace('data-path', 'src', $html);
            $html = str_replace('data-w', 'width', $html);
            $html = str_replace('<iframe', '<iframe width="500" height="375"', $html);
            $html = trim($html);
            
            if($cover){
                $html = $cover.$html;
            }

            $data = $html;
        }
        else if(strpos($html, 'video_id.DATA') !== FALSE)
        {
            //数据类型
            lib_func_grab::$grab_type = 4;
            
            preg_match('/<strong class="account_nickname_inner .*?">(.*?)<\/strong>/is', $html, $result);
            if($result[1]){
                $data .= $result[1].',';
            }
            
            preg_match('/video_id\.DATA\'\) : \'(.*?)\'/is', $html, $result);
            if($result[1]){
                $data .= $result[1];
            }
        }
        
        $html = $data;
    }
}
