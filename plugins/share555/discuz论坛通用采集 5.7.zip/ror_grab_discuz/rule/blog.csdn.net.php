<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

lib_func_grab::$is_replace = 0;

if(strpos($url, '/nav/') !== FALSE || $url == 'https://blog.csdn.net/')
{
    $rule = array(
        
        '0'=>array(
            
            'list_intercept_start'=>'<ul class="feedlist_mod',
            'list_intercept_filter'=>'',
            'list_intercept_end'=>'<div class="feed_loading">',
            'list_list'=>'<h2>(.*?)<\/h2>',
            'list_title'=>'<a .*?>(.*?)<\/a>',
            'list_source'=>'href="(.*?)"',
            
            'con_intercept_start'=>'<article class="baidu_pl">',
            'con_intercept_filter'=>array('<link (.*?)>','<blockquote>','</blockquote>'),
            'con_intercept_end'=>'</article>',
            
            'func'=>array(
                'list_deal'=>'list_deal_csdn_net',
                'detail_deal_more'=>'detail_deal_more_csdn_net',
                'thread_data_get'=>'thread_data_get_csdn_net',
            )
        ),
    );
}
else 
{
    $rule = array(
        
        '0'=>array(
            
            'list_intercept_start'=>'<div class="navList"',
            'list_intercept_filter'=>array(''),
            'list_intercept_end'=>'<div class="blink-list-footer"',
            'list_list'=>'<article (.*?)<\/article>',
            'list_title'=>'<h4 .*?>(.*?)<\/h4>',
            'list_source'=>'href="(.*?)"',
            
            'con_intercept_start'=>'<article class="baidu_pl">',
            'con_intercept_filter'=>array('<link (.*?)>','<blockquote>','</blockquote>'),
            'con_intercept_end'=>'</article>',
            
            'func'=>array(
                'list_deal'=>'list_deal_csdn_net',
                'detail_deal_more'=>'detail_deal_more_csdn_net',
                'thread_data_get'=>'thread_data_get_csdn_net',
            )
        ),
    );
}

if(! function_exists('list_deal_csdn_net'))
{
    function list_deal_csdn_net(& $grab)
    {
        foreach($grab['title'] as $key => $title){
            $grab['title'][$key] = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $title);
        }
    }
}

if(! function_exists('page_deal_csdn_net'))
{
    function page_deal_csdn_net($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        if(strpos($url, '/nav/') === FALSE){
            $urls = explode('?', $url);
            $url = $urls[0].'/article/list/'.$page;
        }
        
        
        return $url;
    }
}

//采集内容处理
if(! function_exists('detail_deal_more_csdn_net'))
{
    function detail_deal_more_csdn_net(& $html, $grab)
    {
        $html = preg_replace('/<pre .*?>/is', '[code]', $html);
        
        $html = str_replace('</pre>', '[/code]', $html);
    }
}

if(! function_exists('thread_data_get_csdn_net'))
{
    function thread_data_get_csdn_net($grab)
    {
        $tid = $grab['tid'];
        $pid = $grab['pid'];

        $post = C::t('forum_post')->fetch('tid:'.$tid, $pid);
        
        $pattern = '/\[code\](.*?)\[\/code\]/is';
        preg_match_all($pattern, $post['message'], $message);
        preg_match_all($pattern, $grab['content'], $content);

        $message_temp = $post['message'];

        foreach($message[1] as $key => $value)
        {
            $con = $content[1][$key];
            if(strpos($con, '<code') !== FALSE){
                $con = preg_replace('/<code .*?>/is', '', $con);
                $con = preg_replace('/<span .*?>/is', '', $con);
                $con = str_replace('</span>', '', $con);
                $con = str_replace('</code>', '', $con);
            }
            
            $post['message'] = str_replace($value, trim($con, "\r\n"), $post['message']);
        }
        
        $post['message'] = html_entity_decode($post['message']);
        
        if($message_temp != $post['message']){
            C::t('forum_post')->update('tid:'.$tid, $pid, array('message'=>$post['message']));
        }
    }
}