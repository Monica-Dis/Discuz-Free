<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule = array(
	
	'0'=>array(
	
		'list_intercept_start'=>'<!--listS-->',
		'list_intercept_filter'=>'',
		'list_intercept_end'=>'<!--listE-->',
		'list_list'=>'<td width="70.*?>(.*?)<\/td>',
		'list_title'=>'<a .*?>(.*?)<\/a>',
		'list_source'=>'href="(.*?)"',
	  
        'con_intercept_start'=>'<!--webstart-->',
        'con_intercept_filter'=>array(''),
        'con_intercept_end'=>'<div id="download_share"',
        
        'tags_intercept_start'=>'',
        'tags_intercept_filter'=>'',
        'tags_intercept_end'=>'',
        'tags_list'=>'',
        
        'comment_intercept_start'=>'',
        'comment_intercept_filter'=>'',
        'comment_intercept_end'=>'',
        'comment_list'=>'',
        'comment_content'=>'',
	    
	    'comment_dateline'=>'',
	    
	    'author_list'=>'<a href=".*?userinfo.*?">(.*?)\(',
        
        'func'=>array(
            'attachment_deal'=>'attachment_deal_1159_com_cn',
            'page_deal'=>'page_deal_1159_com_cn',
        ),
	)
	
);

if(! function_exists('attachment_deal_1159_com_cn'))
{
    function attachment_deal_1159_com_cn(& $html, $grab)
    {
        preg_match_all('/<a.*?href="(.*?)".*?>(.*?)<\/a>/is', $html, $result);
        
        if(! $result[0] || ! $result[1] || ! $result[2]){
            return '';
        }
        
        $html = str_replace('<div class="subtitle">', '<br>', $html);
        $html = str_replace('<div class="content">', '<br>', $html);

        foreach($result[0] as $key => $value)
        {
            if(strpos($result[1][$key], 'download/download.aspx') !== FALSE){
                $temp = explode('&amp;n=', $result[1][$key]);
                $href = '<p><a href="'.str_replace('&amp;', '&', $result[1][$key]).'&mod=attachment">'.urldecode($temp[1]).'</a></p>';
                $html = str_replace($value, $href, $html);
            }else{
                $html = str_replace($value, $result[2][$key], $html);
            }
        }
    }
}

if(! function_exists('page_deal_1159_com_cn'))
{
	function page_deal_1159_com_cn($page, $nav)
	{
		$url = $nav['source'];
		
		if($page == 1){
		    return $url;
		}
		
		$url .= '&page='.$page;
		
		return $url;
	}
}