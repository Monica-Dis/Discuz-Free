<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$rule = array(

    '0'=>array(
         
        'list_intercept_start'=>'<ul id="thread_list"',
        'list_intercept_filter'=>array('<i class="icon(.*?)<a'),
        'list_intercept_end'=>'<div class="thread_list_bottom',
        'list_list'=>'<div class="threadlist_title(.*?)<\/div>',
        'list_title'=>'<a .*?>(.*?)<\/a>',
        'list_source'=>'href="(.*?)"',
         
        'con_intercept_start'=>'<div id="post',
        'con_intercept_filter'=>array('_content_.*?>','<span class="apc_src_wrapper">.*?<\/span>'),
        'con_intercept_end'=>'</div>',
         
        'comment_intercept_start'=>'div id="post_content',
        'comment_intercept_filter'=>array(''),
        'comment_intercept_end'=>'<div class="pb_footer">',
        'comment_list'=>'<div id="post_content.*?>(.*?)<\/div>',

        'comment_filter'=>'</a></span><span class="tail-info">',
        'comment_dateline'=>'<span class="tail-info">(.*?)<\/span><\/div>',
        
        'author_list'=>'<a data-field=.*?>(.*?)<\/a>',
         
        'func'=>array(
            'page_deal'=>'page_deal_tieba_baidu_com',
            'thread_data_get'=>'thread_data_get_tieba_baidu_com',
        ),
    )
);

if(! function_exists('page_deal_tieba_baidu_com'))
{
    function page_deal_tieba_baidu_com($page, $nav)
    {
        $url = $nav['source'];

        if($page == 1){
            return $url;
        }

        $url .= '&pn='.(($page - 1) * 50);

        return $url;
    }
}

if(! function_exists('thread_data_get_tieba_baidu_com'))
{
    function thread_data_get_tieba_baidu_com($grab)
    {
        $secret = '8WzkGazT36H2SMGx7WGQwnmjiJbShbzY';
        
        $comment = $grab['comment'] ? unserialize($grab['comment']) : '';
        
        $fid = $grab['fid'];
        $tid = $grab['tid'];
        $pid = $grab['pid'];
        $uid = $grab['authorid'];
        
        $circles = array(
            '60'=>112,
            '59'=>113,
            '62'=>109,
            '61'=>109,
        );
        $circle_id = $circles[$fid];

        if(! $circle_id){
            return;
        }

        $pic_host = 'https://equanyun-1254263622.cos.accelerate.myqcloud.com/forum/';
        $tid = (string)$tid;
        $tableid = dintval($tid{strlen($tid)-1});
        $sql = 'SELECT attachment,width FROM %t WHERE tid=%d AND pid=%d AND isimage=1';
        $attachment_list = DB::fetch_all($sql, array('forum_attachment_'.$tableid, $tid, $pid));
        $pics = array();
        if($attachment_list){
            foreach($attachment_list as $value){
                if($value['width'] < 200){
                    continue;
                }
                $pics[] = $pic_host.$value['attachment'];
            }
        }
        
        $thread_add_url = 'https://qpp.equanyun.com/mag/open/api/showContentAdd';
        $post = array(
            'secret'=>$secret,
            'uid'=>(int)$uid,
            'circle_id'=>(int)$circle_id,
            'title'=>$grab['title'],
            'content'=>mb_substr(strip_tags($grab['content']), 0, 999, 'utf-8'),
            'pics'=>$pics ? implode(',', $pics) : '',
        );
        
        $result = lib_base::curl($thread_add_url, $post);
        $result = json_decode($result, TRUE);
        if(! $result['sharedata']['type_value']){
            return;
        }
        
        $content_id = $result['sharedata']['type_value'];
        $comment_add_url = 'https://qpp.equanyun.com/mag/open/api/showCommentAdd';
        
        if($comment['list'])
        {
            $sql = 'SELECT authorid,message FROM %t WHERE tid=%d AND first=0 ORDER BY pid ASC';
            $post_list = DB::fetch_all($sql, array('forum_post', $tid));

            foreach($post_list as $value)
            {
                $value['message'] = preg_replace('/\[attach\](.*?)\[\/attach\]/is', '', $value['message']);
                
                $post = array(
                    'secret'=>$secret,
                    'uid'=>(int)$value['authorid'],
                    'content_id'=>(int)$content_id,
                    'content'=>mb_substr(strip_tags($value['message']), 0, 999, 'utf-8'),
                );

                $result = lib_base::curl($comment_add_url, $post);
            }
        }
    }
}