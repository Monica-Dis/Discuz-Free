<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['list_intercept_start'] = '<tbody id="threadlist">';
$rule[0]['list_intercept_filter'] = array('');
$rule[0]['list_intercept_end'] = '</table>';
$rule[0]['list_list'] = '<td class="subject"(.*?)<\/td>';
$rule[0]['list_title'] = '<a .*?>(.*?)<\/a>';
$rule[0]['list_source'] = 'href="(.*?)"';

$rule[0]['con_intercept_start'] = '<div class="tpc_content">';
$rule[0]['con_intercept_filter'] = array('<p class="phone">.*?<\/p>','<div class="quoteTips mb10">.*?<\/div>','<blockquote class="blockquote3">.*?<\/blockquote>');
$rule[0]['con_intercept_end'] = '</div>';
$rule[0]['con_more_intercept_start'] = '';
$rule[0]['con_more_intercept_filter'] = array();
$rule[0]['con_more_intercept_end'] = '';

$rule[0]['tags_intercept_start'] = '';
$rule[0]['tags_intercept_filter'] = array();
$rule[0]['tags_intercept_end'] = '';
$rule[0]['tags_list'] = '';

$rule[0]['comment_intercept_start'] = '<div class="tpc_content">';
$rule[0]['comment_intercept_filter'] = array('<p class="phone">.*?<\/p>','<div class="quoteTips mb10">.*?<\/div>','<blockquote class="blockquote3">.*?<\/blockquote>');
$rule[0]['comment_intercept_end'] = '<span class="pages">';
$rule[0]['comment_list'] = '<div class="tpc_content">(.*?)<\/div>';

$rule[0]['comment_dateline'] = '<span class="mr10 gray">(.*?)<\/span>';
$rule[0]['author_list'] = '';

$rule[0]['func'] = array(
    'page_deal'=>'page_deal_bbs_nantaihu_com',
);

if(! function_exists('page_deal_bbs_nantaihu_com'))
{
    function page_deal_bbs_nantaihu_com($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }

        $url = str_replace('.html', '-page-'.$page.'.html', $url);
        
        return $url;
    }
}
