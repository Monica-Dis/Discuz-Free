<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$rule = array(
    
    '0'=>array(
        
        'list_intercept_start'=>'',
        'list_intercept_filter'=>array(),
        'list_intercept_end'=>'',
        'list_list'=>'',
        'list_source'=>'',
        'list_title'=>'',
        
        'con_intercept_start'=>'',
        'con_intercept_filter'=>array(''),
        'con_intercept_end'=>'',
        
        'func'=>array(
            'list'=>'list_5ma_xyz',
            'page_deal'=>'page_deal_5ma_xyz',
            'detail'=>'detail_5ma_xyz',
        )
    ),
    
);

if(! function_exists('page_deal_5ma_xyz'))
{
    function page_deal_5ma_xyz($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url = str_replace('page=1', 'page='.$page, $url);

        return $url;
    }
}

if(!function_exists('list_5ma_xyz'))
{
    function list_5ma_xyz(& $grab)
    {
        $url = trim($grab['url']);

        $urls = parse_url($url);
        $paths = explode('/', $urls['path']);
        $grab['host'] = $urls['scheme'].'://'.$urls['host'];
        $cookie = $grab['cookie'];
        
//         $posts = explode('&', $urls['query']);
//         $post = array();
//         foreach($posts as $value){
//             list($k, $val) = explode('=', $value);
//             $post[$k] = $val;
//         }

        $headers = array(
            'cookie: '.$cookie,
            'pragma: no-cache',
            'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36',
            'x-key: 685075196c8c4f0d474fd4c7df183b88',
            'x-requested-with: XMLHttpRequest',
            'x-time: 1626521248292',
        );
        $html = lib_func_grab::get($grab['url'], $grab['host'], $urls['host'], $cookie, '', $headers);

        $json = json_decode($html, TRUE);
        if(! $json){
            $notice = '&#21015;&#34920;&#106;&#115;&#111;&#110;&#35299;&#26512;&#26377;&#35823;&#65306;'.$grab['url'];
            lib_base::back_html($notice , 1);
            return;
        }
        if(! $json['data']){
            $notice = '&#26080;&#37319;&#38598;&#25968;&#25454;&#65306;'.$grab['url'];
            lib_base::back_html($notice , 1);
            return;
        }

        $host = 'https://5ma.xyz/api/info/get/';
        $grab['title'] = array();
        $grab['source'] = array();
        foreach($json['data'] as $key => $value)
        {
            $grab['title'][$key] = $value['title'];
            $grab['source'][$key] = $host.$value['id'];
        }
        
        lib_func_grab::$repeat_count = 0;
        foreach($grab['title'] as $key => $value)
        {
            if(! $value){
                continue;
            }
            
            $source = $grab['source'][$key];
            
            $identify = lib_func_grab::save_identify($source);
            
            $sql = 'SELECT COUNT(*) FROM '.DB::table('plugin_'.PLUGIN_NAME)." WHERE identify='".$identify."'";
            $count = DB::result_first($sql);
            if($count)
            {
                $notice = '&#20869;&#23481;&#37319;&#38598;&#37325;&#22797;&#58;'.$source;
                lib_base::back_html($notice, 1);
                lib_func_grab::$repeat_count++;
                
                if(lib_func_grab::$repeat_count >= lib_func_grab::$repeat_limit){
                    $notice = '&#37319;&#38598;&#20869;&#23481;&#37325;&#22797;&#27425;&#25968;&#36229;&#36807; '.lib_func_grab::$repeat_limit.' &#27425;&#65292;&#20013;&#26029;&#37319;&#38598;&#58;'.$source;
                    lib_base::back_html($notice, 1);
                    break;
                }
                
                continue;
            }
            
            lib_func_grab::$grab_new++;
            
            lib_func_grab::grab_detail_local($grab['id'], $grab['title'][$key], $source);
        }
        
        //更新机制
        lib_func_grab::nav_crontime_update($grab['id'], $grab['crontime']);
        
        return TRUE;
    }
}


if(! function_exists('detail_5ma_xyz'))
{
    function detail_5ma_xyz($grab)
    {
        $url = $grab['detail_url'];
        
        $url = str_replace('www.toutiao.com', 'm.toutiao.com', $url);
        $url = str_replace('/a', '/i', $url);
        $url .= 'info/';
        
        //获取HOST
        $urls = parse_url($url);
        $host = isset($urls['scheme']) ? $urls['scheme'].'://'.$urls['host'] : $urls['host'];
        $cookie = $grab['cookie'];
        
        $headers = array(
            ':authority: 5ma.xyz',
            ':method: GET',
            ':path: /api/info/get/95032',
            ':scheme: https',
            'accept: application/json, text/plain, */*',
            'accept-encoding: gzip, deflate, br',
            'accept-language: zh-CN,zh;q=0.9',
            'authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczpcL1wvNW1hLnh5elwvYXBpXC9sb2dpbiIsImlhdCI6MTYyNjUyMzYwOSwiZXhwIjoxNjI3MTI4NDA5LCJuYmYiOjE2MjY1MjM2MDksImp0aSI6IjdpcmRBS0VGOVZERHZDSjMiLCJzdWIiOjEyMjA2MSwicHJ2IjoiZjZiNzE1NDlkYjhjMmM0MmI3NTgyN2FhNDRmMDJiN2VlNTI5ZDI0ZCIsImxhc3RfbG9naW4iOjE2MjY1MjM2MDh9.s4Xjle-3l2Q8O58U8qjj-k01EqRD85qe0XiURa_GZeo',
            'cache-control: no-cache',
            'cookie: ai=53111; _ga=GA1.2.1959333548.1626270149; _gid=GA1.2.965981794.1626513852; KHND=1; KAT=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczpcL1wvNW1hLnh5elwvYXBpXC9sb2dpbiIsImlhdCI6MTYyNjUyMzYwOSwiZXhwIjoxNjI3MTI4NDA5LCJuYmYiOjE2MjY1MjM2MDksImp0aSI6IjdpcmRBS0VGOVZERHZDSjMiLCJzdWIiOjEyMjA2MSwicHJ2IjoiZjZiNzE1NDlkYjhjMmM0MmI3NTgyN2FhNDRmMDJiN2VlNTI5ZDI0ZCIsImxhc3RfbG9naW4iOjE2MjY1MjM2MDh9.s4Xjle-3l2Q8O58U8qjj-k01EqRD85qe0XiURa_GZeo',
            'pragma: no-cache',
            'referer: https://5ma.xyz/show?id=95032',
            'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36',
            'x-key: f9391f1d5bfea4718c90816581ca6e9a',
            'x-requested-with: XMLHttpRequest',
            'x-time: 1626527680920',
        );
        
        $json = lib_func_grab::get($url, $grab['host'], $urls['host'], $cookie, '', $headers);
        var_dump($json);exit;
        $title = '';
        $html = '';
        $json = json_decode($json, TRUE);
        
        if($json['data']['title']){
            $title = $json['data']['title'];
            if(CHARSET == 'gbk' && $_GET['act'] != 'grab_articled'){
                $title = lib_base::string_utf8_to_gbk($title);
            }
        }
        if($json['data']['content']){
            $html = $json['data']['content'];
        }
        
        if($json['data']['video_id']){
            $html = '';
        }
        
        if(! $html){
            $notice = '&#33719;&#21462;&#35814;&#24773;&#22833;&#36133;&#65306;'.$url;
            lib_base::back_html($notice, 1);
            return FALSE;
        }
        
        //内容过滤
        $parrent = '<pre class="syl-page-code hljs">.*?<\/pre>,<p><a class="pgc-link".*?<\/a><\/p>';
        lib_func_grab::content_filter($html, $parrent);
        
        //过滤
        lib_func_grab::content_filter_tag($html);
        lib_func_grab::src_deal($html, $host);
        $content = trim($html);
        
        //内容获取评论
        $comment = array(
            'list'=>array(),
            'dateline'=>array(),
            'author'=>array(),
        );
        if(lib_base::settings('is_grab_dateline')){
            $comment['dateline'][0] = date('Y-m-d H:i:s', $json['data']['publish_time']);
        }
        if(lib_base::settings('is_grab_author')){
            $comment['author'][0] = $json['data']['media_user']['screen_name'];
        }
        
        if(lib_base::settings('is_grab_comment')){
            lib_func_grab::comment($grab, $comment);
        }
        
        if(! $title){
            $notice = '&#33719;&#21462;&#26631;&#39064;&#22833;&#36133;&#65306;'.$grab['detail_url'];
            lib_base::back_html($notice, 1);
            return FALSE;
        }
        
        if(! $content){
            $notice = '&#33719;&#21462;&#20869;&#23481;&#22833;&#36133;&#65306;'.$grab['detail_url'];
            lib_base::back_html($notice, 1);
            return FALSE;
        }
        
        lib_func_grab::grab_save($grab, $title, $content, array(), $comment, $grab['source'][$grab['key']]);
    }
}