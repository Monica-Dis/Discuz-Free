<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[$ruleid]['func']['detail_deal_more'] = 'detail_deal_more_gaycn_top';

//采集内容处理
if(! function_exists('detail_deal_more_gaycn_top'))
{
    function detail_deal_more_gaycn_top(& $html, $grab)
    {
        $filter = '<span style="display:none">.*?<\/span>,<font class="jammer">.*?<\/font>,<script .*?>.*?<\/script>';
        lib_func_grab::content_filter($html, $filter);
        
        preg_match_all('/<a .*?href="(.*?)" .*?>(.*?)<\/a>/is', $html, $result);
        
        if(! $result[1]){
            return FALSE;
        }

        foreach($result[0] as $key => $value){
            $temp = '[url='.$result[1][$key].']'.$result[2][$key].'[/url]';
            $html = str_replace($value, $temp, $html);
        }
    }
}

