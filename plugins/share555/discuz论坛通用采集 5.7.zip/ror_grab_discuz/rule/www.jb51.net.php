<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

if(strpos($url, '.html') !== FALSE)
{
    $rule = array(
    
        '0'=>array(
             
            'list_intercept_start'=>'<ul id="lists">',
            'list_intercept_filter'=>'',
            'list_intercept_end'=>'</ul>',
            'list_list'=>'<a class="link title"(.*?)<\/p>',
            'list_title'=>'title="(.*?)"',
            'list_source'=>'href="(.*?)"',
            
            'con_intercept_start'=>'<div id="content">',
            'con_intercept_filter'=>array(''),
            'con_intercept_end'=>'<div class="clearfix">',
    
            'tags_intercept_start'=>'',
            'tags_intercept_filter'=>'',
            'tags_intercept_end'=>'',
            'tags_list'=>'',
    
            'comment_intercept_start'=>'',
            'comment_intercept_filter'=>'',
            'comment_intercept_end'=>'',
            'comment_list'=>'',
            'comment_content'=>'',
             
            'comment_dateline'=>'',
             
            'author_list'=>'',
    
            'func'=>array(
                'detail'=>'detail_www_jb51_net',
                'page_deal'=>'page_deal_www_jb51_net',
                'thread_data_get'=>'thread_data_get_www_jb51_net',
            ),
        )
    
    );
}
else 
{
    $rule = array(
    
        '0'=>array(
             
            'list_intercept_start'=>'<div class="artlist',
            'list_intercept_filter'=>'',
            'list_intercept_end'=>'<div class="dxypage',
            'list_list'=>'<DT>(.*?)<\/DT>',
            'list_title'=>'itle="(.*?)"',
            'list_source'=>'href="(.*?)"',
            
            'con_intercept_start'=>'<div id="content">',
            'con_intercept_filter'=>array(''),
            'con_intercept_end'=>'<div class="art_xg">',
    
            'tags_intercept_start'=>'',
            'tags_intercept_filter'=>'',
            'tags_intercept_end'=>'',
            'tags_list'=>'',
    
            'comment_intercept_start'=>'',
            'comment_intercept_filter'=>'',
            'comment_intercept_end'=>'',
            'comment_list'=>'',
            'comment_content'=>'',
             
            'comment_dateline'=>'',
             
            'author_list'=>'',
    
            'func'=>array(
                'detail'=>'detail_www_jb51_net',
                'page_deal'=>'page_deal_www_jb51_net',
                'thread_data_get'=>'thread_data_get_www_jb51_net',
            ),
        )
    
    );
}

if(! function_exists('thread_data_get_www_jb51_net'))
{
    function thread_data_get_www_jb51_net($grab)
    {   
        $tid = $grab['tid'];
        $pid = $grab['pid'];
        
        $post = C::t('forum_post')->fetch('tid:'.$tid, $pid);
        
        $pattern = '/\[code\](.*?)\[\/code\]/is';
        preg_match_all($pattern, $post['message'], $message);
        preg_match_all($pattern, $grab['content'], $content);
        
        $message_temp = $post['message'];
        
        foreach($message[0] as $key => $value){
            $post['message'] = str_replace($value, $content[0][$key], $post['message']);
        }
        
        if($message_temp != $post['message']){
            C::t('forum_post')->update('tid:'.$tid, $pid, array('message'=>$post['message']));
        }
    }
}


//采集内容处理
if(! function_exists('detail_www_jb51_net'))
{
    function detail_www_jb51_net($grab)
    {
        $url = $grab['detail_url'];
        $urls = parse_url($url);
        
        $html = lib_func_grab::attach_get($url, $grab['host'], $urls['host'], $grab['cookie']);
        $grab['html'] = $html;
 
        if(! $html){
            $notice = lib_base::lang('func_detail_get_fail').$url;
            lib_base::back_html($notice, 1);
            return FALSE;
        }
        
        if(! lib_base::$grab_charset){
            $charset = lib_func_grab::getCharset($grab['html']);
            if(! $charset){
                $notice = 'Unfetched Web Code '.$url;
                lib_base::back_html($notice, 1);
            }
            lib_base::$grab_charset = $charset;
        }

        //单篇文章采集匹配标题
        $title = '';
        if(isset($grab['title'][$grab['key']])){
            $title = trim($grab['title'][$grab['key']]);
        }else{
            $title = lib_func_grab::title($grab);
            $grab['title'][$grab['key']] = $title;
        }

		$notice = lib_base::lang('func_detail_start_fail').$grab['detail_url'];
		if(! lib_func_grab::html_intercept($html, $grab['rule']['con_intercept_start'], 'start', $notice)){
			return FALSE;
		}

		$notice = lib_base::lang('func_detail_end_fail').$grab['detail_url'];
		if(! lib_func_grab::html_intercept($html, $grab['rule']['con_intercept_end'], 'end', $notice)){
			return FALSE;
		}

		//过滤
		lib_func_grab::content_filter_tag($html);
		lib_func_grab::src_deal($html, $grab['host']);
		lib_func_grab::href_deal($html, $grab['host']);
		
		$html = html_entity_decode($html);
		$html = preg_replace('/<pre .*?>/is', '[code]', $html);
		$html = str_replace('</pre>', '[/code]', $html);

		$content = trim($html);
		
		//内容获取评论
		$comment = array(
		    'list'=>array(),
		    'dateline'=>array(),
		    'author'=>array(),
		);
// 		if(lib_base::settings('is_grab_dateline')){
// 		    $comment['dateline'] = lib_func_grab::dateline($grab);
// 		}
// 		if(lib_base::settings('is_grab_author')){
// 		    $comment['author'] = lib_func_grab::author($grab);
// 		}
// 		if(lib_base::settings('is_grab_comment')){
// 		    $comment['list'] = lib_func_grab::comment($grab);
// 		}

		//处理采集无内容
		if(! strip_tags($content) && stripos($content, '<img') === FALSE){
		    $content = '';
		}

		if(! $title){
			$notice = lib_base::lang('func_detail_title_fail').$grab['detail_url'];
			lib_base::back_html($notice, 1);
			return FALSE;
		}
		
		if(! $content){
			$notice = lib_base::lang('func_detail_content_fail').$grab['detail_url'];
			lib_base::back_html($notice, 1);
			return FALSE;
		}

		lib_func_grab::grab_save($grab, $title, $content, array(), $comment, $url);
    }
}

if(! function_exists('page_deal_www_jb51_net'))
{
	function page_deal_www_jb51_net($page, $nav)
	{
		$url = $nav['source'];
		
		if($page == 1){
		    return $url;
		}
		
		if(strpos($url, '1.html') !== FALSE){
		    $url = str_replace('1.html', $page.'.html', $url);
		}else{
		    $url = str_replace('1.htm', $page.'.htm', $url);
		}
		
		return $url;
	}
}