<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$rule = array(
    
    '0'=>array(
        
        'list_intercept_start'=>'<div class="trend_list">',
        'list_intercept_filter'=>array('<!--.*?-->'),
        'list_intercept_end'=>'<div class="page-sep-wrap">',
        'list_list'=>'<h4 .*?>(.*?)<\/h4>',
        'list_title'=>'<a .*?>(.*?)<\/a>',
        'list_source'=>'href="(.*?)"',
        
        'con_intercept_start'=>'<div id="topic_content">',
        'con_intercept_filter'=>array(''),
        'con_intercept_end'=>'</div>',
        
        'tags_intercept_start'=>'<div class="mytags">',
        'tags_intercept_filter'=>array('<div class="tag_note">.*?<\/div>'),
        'tags_intercept_end'=>'</ul>',
        'tags_list'=>'<a .*?>(.*?)<\/a>',
        
        'comment_intercept_start'=>'<div id="reply_content">',
        'comment_intercept_filter'=>array(''),
        'comment_intercept_end'=>'<div class="reply_more_box"',
        'comment_list'=>'<div class="rc_text pdTxtEditorPre">(.*?)<\/div>',
        
        'comment_dateline'=>'<p class="t_info">(.*?)<\/p>',
        
        'author_list'=>'<h3 class="a_name">.*?<a .*?>(.*?)<\/a>',
        
        'func'=>array(
            'page_deal'=>'page_deal_bbs_paidai_com',
            'dateline_start'=>'dateline_start_bbs_paidai_com',
        ),
    )
);

if(! function_exists('page_deal_bbs_paidai_com'))
{
    function page_deal_bbs_paidai_com($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url .= '/'.$page;
        
        return $url;
    }
}

if(! function_exists('dateline_start_bbs_paidai_com'))
{
    function dateline_start_bbs_paidai_com(& $grab, & $comment)
    {
        $dateline = array();
        
        $html = $grab['html'];
        
        lib_func_grab::content_filter($html, $grab['rule']['comment_filter']);
        
        $pattern = '/'.$grab['rule']['comment_dateline'].'/is';
        preg_match($pattern, $html, $result);
        
        if(! $result[1]){
            return $dateline;
        }

        if(strpos($result[1], '月') === FALSE){
            $rule = '/\d{4}-\d{1,2}-\d{1,2} (\d{1,2}:\d{1,2}:\d{1,2}|\d{1,2}:\d{1,2})/is';
            preg_match($rule, $result[1], $result_time);
            if($result_time[0]){
                $dateline[0] = $result_time[0];
            }
        }else{
            $rule = '/\d{1,2}月\d{1,2}日 (\d{1,2}:\d{1,2}:\d{1,2}|\d{1,2}:\d{1,2})/is';
            preg_match($rule, $result[1], $result_time);
            if($result_time[0]){
                $result_time[0] = str_replace(array('月','日'), array('-',''), $result_time[0]);
                $dateline[0] = date('Y').'-'.$result_time[0];
            } 
        }

        $comment['dateline'] = $dateline;
    }
}
