<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['func']['detail_start'] = 'detail_start_www_cgzixue_cn';
$rule[0]['func']['detail_deal_more'] = 'detail_deal_more_www_cgzixue_cn';

if(! function_exists('detail_start_www_cgzixue_cn'))
{       
    function detail_start_www_cgzixue_cn($grab)
    {
        $host = $grab['host'];
        $referer = $grab['detail_url'];
        $cookie = $grab['cookie'];
        $html = $grab['html'];
        $urls = parse_url($referer);

        if(strpos($html, '<div class="locked">') === FALSE){
            lib_base::back_html('no locked', 1);
			unset($grab['rule']['func']['detail_start']);
			lib_func_grab::grab_detail($grab);
			return FALSE;
        }
        
		$rule = '/name="formhash" value="(.*?)"/';
		preg_match($rule, $html, $result);
		$formhash = $result[1];
		$rule = "/fid = parseInt\('(.*?)'\)/";
		preg_match($rule, $html, $result);
		$fid = $result[1];
		$rule = "/tid = parseInt\('(.*?)'\)/";
		preg_match($rule, $html, $result);
		$tid = $result[1];

		if(! $formhash || ! $fid || ! $tid){
			lib_base::back_html('no formhash fid tid', 1);
			return FALSE;
		}
		
		$message = 'forum post test';
		$file_post_message = DISCUZ_ROOT.'source/plugin/'.PLUGIN_NAME.'/rule/'.$urls['host'].'_message.txt';
		if(file_exists($file_post_message)){
			$post_message_arr = explode("\n", trim(file_get_contents($file_post_message), '\r\n'));
			if(is_array($post_message_arr)){
				$message = $post_message_arr[array_rand($post_message_arr)];
			}
		}

		$post_url = $host.'/forum.php?mod=post&action=reply&fid='.$fid.'&tid='.$tid.'&extra=&replysubmit=yes&infloat=yes&handlekey=fastpost&inajax=1';
		$post = array(
			'formhash'=>$formhash,
			'message'=>$message
		);

		$result = lib_func_grab::get($post_url, $referer, $host, $cookie, $post);
		if(strpos($result, 'succeedhandle_fastpost') === FALSE){
			lib_base::back_html('thread reply send fail', 1);

			lib_func_grab::grab_detail_local($grab['id'], $grab['title'][0], $grab['source'][0]);
			return FALSE;
		}

        unset($grab['rule']['func']['detail_start']);
        unset($grab['html']);
        
        lib_func_grab::grab_detail($grab);
        
        return FALSE;
    }
}

if(! function_exists('detail_deal_more_www_cgzixue_cn'))
{
    function detail_deal_more_www_cgzixue_cn(& $html, $grab)
    {
        preg_match_all('/<div class="showhide">(.*?)<\/div>/', $html, $result);
        
        if(! $result[1]){
            return FALSE;
        }
        
        foreach($result[1] as $key => $value){
            $value = preg_replace('/<h4>.*?<\/h4>/', '', $value);
            $value = '[hide]'.$value.'[/hide]';
            $html = str_replace($result[0][$key], $value, $html);
        }
    }
}
