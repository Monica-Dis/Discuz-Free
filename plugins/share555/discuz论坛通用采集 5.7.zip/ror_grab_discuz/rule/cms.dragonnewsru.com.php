<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$rule = array(
    
    '0'=>array(
        
        'list_intercept_start'=>'',
        'list_intercept_filter'=>array(),
        'list_intercept_end'=>'',
        'list_list'=>'<li ><a(.*?)<',
        'list_source'=>"href='(.*?)'",
        'list_title'=>"title='(.*?)'",
        
        'con_intercept_start'=>'class="content">',
        'con_intercept_filter'=>array('<div class="title">.*?<\/div>'),
        'con_intercept_end'=>'<div class="app_code',
        
        'func'=>array(
            'list'=>'list_cms_dragonnewsru_com',
            'page_deal'=>'page_deal_cms_dragonnewsru_com',
        )
    ),
    
);

if(! function_exists('page_deal_cms_dragonnewsru_com'))
{
    function page_deal_cms_dragonnewsru_com($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url = str_replace('pageIndex=1', 'pageIndex='.$page, $url);
        
        return $url;
    }
}

if(!function_exists('list_cms_dragonnewsru_com'))
{
    function list_cms_dragonnewsru_com(& $grab)
    {
        $urls = parse_url(trim($grab['url']));
        $paths = explode('/', $urls['path']);
        $grab['host'] = $urls['scheme'].'://'.$urls['host'];
        $cookie = $grab['cookie'];
        
        $html = lib_func_grab::get($grab['url'], $grab['host'], $urls['host'], $cookie);

        preg_match_all('/'.$grab['rule']['list_list'].'/is', $html, $list);
        if(! $list[1]){
            $notice = '&#21015;&#34920;&#21305;&#37197;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['url'];
            lib_base::back_html($notice, 1);
            
            //失败延长计划任务
            lib_func_grab::nav_crontime_update($grab['id'], $grab['crontime']);
            
            return FALSE;
        }

        $host = 'http://www.dragonnewsru.com';
        $grab['title']  = array();
        $grab['source'] = array();
        foreach($list[1] as $key => $value)
        {
            //匹配标题
            preg_match('/'.$grab['rule']['list_title'].'/is', $value, $temp);
            if($temp){
                $grab['title'][$key] = strip_tags(trim($temp[1]));
            }
            
            //匹配源链接
            preg_match('/'.$grab['rule']['list_source'].'/is', $value, $temp);
            if($temp){
                $grab['source'][$key] = $host.trim($temp[1]);
            }
        }
        
        lib_func_grab::$repeat_count = 0;
        foreach($grab['title'] as $key => $value)
        {
            if(! $value){
                continue;
            }
            
            $source = $grab['source'][$key];
            
            $identify = lib_func_grab::save_identify($source);
            
            $sql = 'SELECT COUNT(*) FROM %t WHERE identify=%s';
            $count = DB::result_first($sql, array('plugin_'.PLUGIN_NAME, $identify));
            if($count)
            {
                $notice = '&#20869;&#23481;&#37319;&#38598;&#37325;&#22797;&#58;'.$source;
                lib_base::back_html($notice, 1);
                lib_func_grab::$repeat_count++;
                
                if(lib_func_grab::$repeat_count >= lib_func_grab::$repeat_limit){
                    $notice = '&#37319;&#38598;&#20869;&#23481;&#37325;&#22797;&#27425;&#25968;&#36229;&#36807; '.lib_func_grab::$repeat_limit.' &#27425;&#65292;&#20013;&#26029;&#37319;&#38598;&#58;'.$source;
                    lib_base::back_html($notice, 1);
                    break;
                }
                
                continue;
            }
            
            lib_func_grab::$grab_new++;
            
            lib_func_grab::grab_detail_local($grab['id'], $grab['title'][$key], $source);
        }
        
        //更新机制
        lib_func_grab::nav_crontime_update($grab['id'], $grab['crontime']);
        
        return TRUE;
    }
}
