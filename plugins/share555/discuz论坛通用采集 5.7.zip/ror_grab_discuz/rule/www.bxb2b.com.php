<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule = array(
	
	'0'=>array(
	
		'list_intercept_start'=>'<ul class="soft-list">',
		'list_intercept_filter'=>'',
		'list_intercept_end'=>'</ul',
		'list_list'=>'<h4 class="soft-title">(.*?)<\/h4>',
		'list_title'=>'<a .*?>(.*?)<\/a>',
		'list_source'=>'href="(.*?)"',
	  
        'con_intercept_start'=>'<div class="scroll-text">',
        'con_intercept_filter'=>array('<strong>.*?www\.bxb2b\.com<\/a><\/span><\/strong>','<span style="color: rgb(0, 255, 0);"><strong>'),
        'con_intercept_end'=>'<div class="membersoft">',
        
        'tags_intercept_start'=>'',
        'tags_intercept_filter'=>'',
        'tags_intercept_end'=>'',
        'tags_list'=>'',
        
        'comment_intercept_start'=>'',
        'comment_intercept_filter'=>'',
        'comment_intercept_end'=>'',
        'comment_list'=>'',
        'comment_content'=>'',
	    
	    'comment_dateline'=>'<ul class="soft-text">(.*?)<\/li>',
	    
	    'author_list'=>'',
        
        'func'=>array(
            'detail_deal'=>'detail_deal_www_bxb2b_com',
            'attachment_deal'=>'attachment_deal_www_bxb2b_com',
            'page_deal'=>'page_deal_www_bxb2b_com',
        ),
	)
	
);

if(! function_exists('detail_deal_www_bxb2b_com'))
{
    function detail_deal_www_bxb2b_com(& $html)
    {
        $html = str_replace('<div>', '<br>', $html);
    }
}

if(! function_exists('attachment_deal_www_bxb2b_com'))
{
    function attachment_deal_www_bxb2b_com(& $html, $grab)
    {
        $html_all = $grab['html'];
        
        lib_func_grab::html_intercept($html_all, '<div class="download-list clearfix">', 'start');
        lib_func_grab::html_intercept($html_all, '</div>', 'end');
        
        preg_match('/href="(.*?)"/is', $html_all, $result);
        if(! $result[1]){
            return '';
        }

        $attach_url = $grab['host'].$result[1];
        
        $attach_html = lib_func_grab::get($attach_url, $grab['$grab'], $grab['host'], $grab['cookie']);
        preg_match('/href="(.*?)"/is', $attach_html, $result);
        if(! $result[1]){
            return '';
        }

        $attach_url1 = $grab['host'].str_replace('&amp;', '&', $result[1]);
        $attach_html = lib_func_grab::get($attach_url1, $attach_url, $grab['host'], $grab['cookie']);
        
        lib_func_grab::html_intercept($attach_html, '<div class="downarea">', 'start');
        lib_func_grab::content_filter($attach_html, '<img .*?>');
        lib_func_grab::html_intercept($attach_html, '</div>', 'end');
        
        $html .= '[hide]'.$attach_html.'[/hide]';
    }
}

if(! function_exists('page_deal_www_bxb2b_com'))
{
	function page_deal_www_bxb2b_com($page, $nav)
	{
		$url = $nav['source'];
		
		if($page == 1){
		    return $url;
		}
		
		$url = str_replace('list_1', 'list_'.$page, $url);
		
		return $url;
	}
}