<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule = array(
	
	'0'=>array(
	
		'list_intercept_start'=>'<tbody id="threadlist">',
		'list_intercept_filter'=>'<tr class="tr3">.*?<tr class="tr4">,<a href="thread.*?>',
		'list_intercept_end'=>'</tbody>',
		'list_list'=>'<td class="subject".*?>(.*?)<\/td>',
		'list_title'=>'<a.*?class="subject_t f12" target="_blank">(.*?)<\/a>',
		'list_source'=>'<a href="(.*?)".*?class="subject_t f12" target="_blank">',
	  
        'con_intercept_start'=>'<div class="tpc_content">',
        'con_intercept_filter'=>array('<a.*?>.*?<\/a>','id=".*?"','onmouseover=".*?"','style=".*?"','onclick=".*?"','\[.*?\]'),
        'con_intercept_end'=>'<div class="mb10 tips">',
        
        'tags_intercept_start'=>'',
        'tags_intercept_filter'=>'',
        'tags_intercept_end'=>'',
        'tags_list'=>'',
        
        'comment_intercept_start'=>'<div class="tpc_content">',
        'comment_intercept_filter'=>'',
        'comment_intercept_end'=>'<span class="pages">',
        'comment_list'=>'<div class="tpc_content">(.*?)<\/div>',
        'comment_content'=>'',
	    
	    'comment_dateline'=>'<div class="tipTop s6">(.*?)<\/div>',
	    
	    'author_list'=>'<div class="readName b"><a.*?>(.*?)<\/a>',
        
        'func'=>array(
            'detail_deal'=>'detail_deal_bbs_fanfann_com',
            'attachment_deal'=>'attachment_deal_bbs_fanfann_com',
            'page_deal'=>'page_deal_bbs_fanfann_com',
        ),
	)
	
);

if(! function_exists('detail_deal_bbs_fanfann_com'))
{
    function detail_deal_bbs_fanfann_com(& $html)
    {
        $html = str_replace('src="', 'src1="', $html);
        $html = str_replace('data-original=', 'src=', $html);
    }
}

if(! function_exists('attachment_deal_bbs_fanfann_com'))
{
    function attachment_deal_bbs_fanfann_com(& $html, $grab)
    {
        $html_all = $grab['html'];
        
        lib_func_grab::html_intercept($html_all, '<td class="floot_bottom">', 'start');
        lib_func_grab::content_filter($html_all, '<div class="c"></div>,onclick=".*?"');
        lib_func_grab::html_intercept($html_all, '</div>', 'end');
        
        preg_match('/<a .*? href="(.*?)" .*?>(.*?)<\/a>/is', $html_all, $result);
        
        if(! $result[1] || ! $result[2]){
            return '';
        }
        
        $html .= '<a href="'.$result[1].'&mod=attachment">'.strip_tags($result[2]).'</a>';
    }
}

if(! function_exists('page_deal_bbs_fanfann_com'))
{
	function page_deal_bbs_fanfann_com($page, $nav)
	{
		$url = $nav['source'];
		
		if($page == 1){
		    return $url;
		}
		
		if(strpos($url, '&type=') !== FALSE){
		    return $url.'&page='.$page;
		}else{
		    return $url.'-'.$page;
		}
	}
}