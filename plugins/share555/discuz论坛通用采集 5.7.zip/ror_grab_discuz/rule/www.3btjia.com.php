<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[$ruleid]['list_intercept_start'] = 'id="threadlist">';
$rule[$ruleid]['list_intercept_filter'] = array('class="subject_link thread-digest-2.*?">.*?<\/a>','class="subject_link thread-digest-3.*?">.*?<\/a>');
$rule[$ruleid]['list_intercept_end'] = '<div class="page"';
$rule[$ruleid]['list_list'] = 'class="subject">(.*?)<\/td>';
$rule[$ruleid]['list_title'] = 'class="subject_link.*?>(.*?)<\/a>';
$rule[$ruleid]['list_source'] = 'href="(.*?)"';

$rule[$ruleid]['con_intercept_start'] = 'class="message">';
$rule[$ruleid]['con_intercept_filter'] = '<div></div>';
$rule[$ruleid]['con_intercept_end'] = '<div class="attachlist">';
$rule[$ruleid]['con_more_intercept_start'] = '<div class="attachlist">';
$rule[$ruleid]['con_more_intercept_filter'] = '';
$rule[$ruleid]['con_more_intercept_end'] = '/div>';

$rule[$ruleid]['tags_intercept_start'] = '';
$rule[$ruleid]['tags_intercept_filter'] = '';
$rule[$ruleid]['tags_intercept_end'] = '';
$rule[$ruleid]['tags_list'] = '';

$rule[$ruleid]['comment_intercept_start'] = '';
$rule[$ruleid]['comment_intercept_filter'] = '';
$rule[$ruleid]['comment_intercept_end'] = '';
$rule[$ruleid]['comment_list'] = '';

$rule[$ruleid]['comment_dateline'] = '';
$rule[$ruleid]['author_list'] = '';

$rule[$ruleid]['func'] = array(
    'detail_deal_more'=>'detail_deal_more_www_2btjia_com',
    'page_deal'=>'page_deal_www_2btjia_com',
);

if(! function_exists('detail_deal_more_www_2btjia_com'))
{
    function detail_deal_more_www_2btjia_com(& $html, $grab)
    {
        $html_more = $grab['html'];

        lib_func_grab::html_intercept($html_more, $grab['rule']['con_more_intercept_start'], 'start');
        lib_func_grab::html_intercept($html_more, $grab['rule']['con_more_intercept_end'], 'end');
        
        $pattern = '/<a href="(.*?)".*?><img.*?>(.*?)<\/a>/is';
        preg_match_all($pattern, $html_more, $result);
        
        $parse_url = parse_url($grab['detail_url']);
        $host = $parse_url['scheme'].'://'.$parse_url['host'].'/';

        $download = '';
        foreach($result[0] as $key => $value)
        {
            if(! $result[1][$key] || ! $result[2][$key]){
                continue;
            }
            
            $hrefs = explode('-', $result[1][$key]);

            $href = $host.'attach-download-fid-'.$hrefs[3].'-aid-'.$hrefs[5].'.htm?mod=attachment';
            $download .= '<p><a href="'.$href.'" target="_blank">'.$result[2][$key].'</a></p>';
        }
        
        $html .= $download;
    }
}

if(! function_exists('page_deal_www_2btjia_com'))
{
    function page_deal_www_2btjia_com($page, $nav)
    {
        $url = $nav['source'];

        if($page == 1){
            return $url;
        }

        $url = str_replace('.htm', '-page-'.$page.'.htm', $url);
        
        return $url;
    }
}