<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$rule = array(

    '0'=>array(
        'list_intercept_start'=>'',
        'list_intercept_filter'=>array(),
        'list_intercept_end'=>'',
        'list_list'=>'',
        'list_title'=>'',
        'list_source'=>'',
        	
        'con_intercept_start'=>'type="application/json">',
        'con_intercept_filter'=>array(),
        'con_intercept_end'=>'</script>',
         
        'tags_intercept_start'=>'',
        'tags_intercept_filter'=>'',
        'tags_intercept_end'=>'',
        'tags_list'=>'',
         
        'comment_intercept_start'=>'"cid":"',
        'comment_intercept_filter'=>array(''),
        'comment_intercept_end'=>'"',
        'comment_list'=>'',
        'comment_content'=>'',
         
        'comment_dateline'=>'pubtime":"(.*?)"',
        
        'author_list'=>'omauthor">.*?<span .*?>(.*?)<\/span>',
        
        'page_intercept_start'=>'',
        'page_intercept_filter'=>'',
        'page_intercept_end'=>'',
        'page_list'=>'',
         
        'func'=>array(
            'list_start'=>'list_start_xwqq',
            'detail_deal'=>'detail_deal_xwqq',
            'comment_middle'=>'comment_middle_xwqq',
            'comment_deal'=>'comment_deal_xwqq',
        ),
    )
);

if(! function_exists('list_start_xwqq'))
{
    function list_start_xwqq($grab)
    {
        $json = json_decode($grab['html'], TRUE);

        $grab['title'] = array();
        $grab['source'] = array();
        $grab['tags'] = array();

        if(isset($json['idlist'][0]['newslist']) && $json['idlist'][0]['newslist'])
        {
            $host = 'https://xw.qq.com/cmsid/';
            foreach($json['idlist'][0]['newslist'] as $key => $value)
            {
                $grab['title'][$key] = $value['title'];
                $grab['source'][$key] = $host.$value['id'];
                $grab['tags'][$key] = array();
                if($value['tag']){
                    $grab['tags'][$key] = $value['tag'];
                }
            }
        }
        else if(isset($json['data']) && $json['data'])
        {
            foreach($json['data'] as $key => $value)
            {
                $grab['title'][$key] = $value['title'];
                $grab['source'][$key] = $value['url'];
                $grab['tags'][$key] = array();
                if($value['tags']){
                    $grab['tags'][$key] = explode(';', $value['tags']);
                }
            }
        }

        lib_func_grab::$repeat_count = 0;
        foreach($grab['title'] as $key => $value)
        {
            if(! $value){
                continue;
            }
            	
            $source = $grab['source'][$key];
            	
            $identify = lib_func_grab::save_identify($source);
             
            $sql = 'SELECT COUNT(*) FROM '.DB::table('plugin_'.PLUGIN_NAME)." WHERE identify='".$identify."'";
            $count = DB::result_first($sql);
            if($count)
            {
                $notice = '内容采集重复，'.$source;
                lib_base::back_html($notice, 1);
                lib_func_grab::$repeat_count++;

                if(lib_func_grab::$repeat_count >= lib_func_grab::$repeat_limit){
                    $notice = '采集内容重复次数超过'.lib_func_grab::$repeat_limit.'次，中断采集:'.$source;
                    lib_base::back_html($notice, 1);
                    break;
                }

                continue;
            }
            	
            lib_func_grab::$grab_new++;
            lib_func_grab::grab_detail_local($grab['id'], $grab['title'][$key], $source, $grab['tags'][$key]);
        }
         

        //更新机制
        lib_func_grab::nav_crontime_update($grab['id'], $grab['crontime']);

        return TRUE;
    }
}

if(! function_exists('detail_deal_xwqq'))
{
    function detail_deal_xwqq(& $html)
    {
        $data = json_decode($html, TRUE);

        $data = $data['props']['pageProps']['data']['data']['json_content'];
        if(! $data){
            return FALSE;
        }

        $temp = '';

        foreach($data as $value)
        {
            if($value['type'] == 2){
                if(strpos($value['value'], 'http') === FALSE){
                    $value['value'] = 'https:'.$value['value'];
                }
                $temp .= '<p><img src="'.$value['value'].'"/></p>';
                if($value['desc']){
                    $temp .= '<p>'.$value['desc'].'</p>';
                }
            }elseif($value['type'] == 3){
                if(strpos($value['value']['img'], 'http') === FALSE){
                    $value['value']['img'] = 'https:'.$value['value']['img'];
                }
                $temp .= '<p><img src="'.$value['value']['img'].'"/></p>';
                if($value['value']['desc']){
                    $temp .= '<p>'.$value['value']['desc'].'</p>';
                }
            }else{
                $temp .= '<p>'.$value['value'].'</p>';
            }
        }

        $html = $temp;
        
        return TRUE;
    }
}

if(! function_exists('comment_middle_xwqq'))
{
    function comment_middle_xwqq(& $grab)
    {
        $url  = 'https://coral.qq.com/article/'.$grab['html'].'/comment/v2?orinum=50';

        $json = lib_func_grab::get($url);
        $json = json_decode($json, TRUE);

        if(! $json || ! $json['data']['oriCommList']){
            return array();
        }

        $comment = array(
            'list'=>array(),
            'dateline'=>array(),
            'author'=>array(),
        );
        
        $user = $json['data']['userList'];
        $comment_sort = array();
        foreach($json['data']['oriCommList'] as $key => $value){
            //$comment[] = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $value['content']);
            $comment_sort[$value['time']] = array(
                'list'=>$value['content'],
                'author'=>$user[$value['userid']]['nick'] ? $user[$value['userid']]['nick'] : '',
                'dateline'=>date('Y-m-d H:i:s', $value['time']),
            );
        }
        ksort($comment_sort);
        $i = 1;
        foreach($comment_sort as $value)
        {
            $comment['list'][$i] = $value['list'];
            $comment['author'][$i] = $value['author'];
            $comment['dateline'][$i] = $value['dateline'];
            $i++;
        }

        $grab['comment'] = $comment;

        return array();
    }
}

if(! function_exists('comment_deal_xwqq'))
{
    function comment_deal_xwqq(& $comment, $grab)
    {
        $comment['list'][0] = $comment['list'][0] ? $comment['list'][0] : '';
        $comment['list'] = array_merge($comment['list'], $grab['comment']['list']);
        $comment['dateline'][0] = $comment['dateline'][0] ? $comment['dateline'][0] : '';
        $comment['dateline'] = array_merge($comment['dateline'], $grab['comment']['dateline']);
        $comment['author'][0] = $comment['author'][0] ? $comment['author'][0] : '';
        $comment['author'] = array_merge($comment['author'], $grab['comment']['author']);
        
        if(! $comment['dateline'][0] && $comment['dateline'][1]){
            $comment['dateline'][0] = date('Y-m-d H:i:s', strtotime($comment['dateline'][1]) - mt_rand(60, 3600));
        }
    }
}
