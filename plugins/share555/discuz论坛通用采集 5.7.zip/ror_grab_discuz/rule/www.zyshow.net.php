<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0] = array(
    'list_intercept_start'=>'event_detail',
    'list_intercept_filter'=>'',
    'list_intercept_end'=>'pagination',
    'list_list'=>'<tr.*?>(.*?)<\/tr>',
    'list_title'=>'<td>(.*?)<\/td>',
    'list_source'=>'href="(.*?)"',
    
    'con_intercept_start'=>'<div class="span12 first post_detail">',
    'con_intercept_filter'=>'',
    'con_intercept_end'=>'<div',
    'con_more_intercept_start'=>'',
    'con_more_intercept_filter'=>'',
    'con_more_intercept_end'=>'',
    
    'func'=>array(
        'list_deal'=>'list_deal_www_zyshow_net',
        'comment_deal'=>'comment_deal_www_zyshow_net',
        'thread_data_get'=>'thread_data_get_www_zyshow_net',
    ),
);

if(! function_exists('list_deal_www_zyshow_net'))
{
    function list_deal_www_zyshow_net(& $grab)
    {
        foreach($grab['source'] as $key => $value){
            $grab['source'][$key] = str_replace('../', '', $value);
        }
    }
}

if(! function_exists('comment_deal_www_zyshow_net'))
{
    function comment_deal_www_zyshow_net(& $comment, $grab)
    {
        $html = $grab['html'];
        lib_func_grab::html_intercept($html, '<h4 id="tagsyr">', 'start');
        lib_func_grab::html_intercept($html, '</div>', 'end');
        $pattern = '/>(.*?)<\/h4>/is';
        preg_match($pattern, $html, $result);
        if($result[1]){
            $comment['visitor'] = strip_tags($result[1]);
        }
        
        $html = $grab['html'];
        lib_func_grab::html_intercept($html, '<ul class="breadcrumb">', 'start');
        lib_func_grab::html_intercept($html, '<div class="tags', 'end');
        $html = str_replace('<a href="/"', '', $html);
        $pattern = '/<a.*?>(.*?)<\/a>/is';
        preg_match($pattern, $html, $result);
        if($result[1]){
            $comment['nav1'] = $result[1];
        }
        $pattern = '/<li class="active">(.*?)<\/li>/is';
        preg_match($pattern, $html, $result);
        if($result[1]){
            $comment['nav2'] = $result[1];
        }
        
        $comment['playtime'] = '';
        if($comment['nav2']){
            $rule = '/\d{4}-\d{1,2}-\d{1,2}/is';
            preg_match($rule, $comment['nav2'], $result);
            if($result[0]){
                $comment['playtime'] = $result[0];
            }
        }
        
        $html = $grab['html'];
        lib_func_grab::html_intercept($html, '<div class="post_meta_detail">', 'start');
        lib_func_grab::html_intercept($html, '<div class="tags pull-right">', 'end');
        $html = str_replace('<a href="#SOHUCS">', '', $html);
        $pattern = '/href="(.*?)"/is';
        preg_match($pattern, $html, $result);
        if($result[1]){
            $comment['download_url'] = $result[1];
        }
        $pattern = '/<b>(.*?)<\/b/is';
        preg_match($pattern, $html, $result);
        if($result[1]){
            $comment['download_password'] = $result[1];
        }
        
        $play_url = array();
        $comment['play_url'] = array();
        
        $html = $grab['html'];
        lib_func_grab::html_intercept($html, '\x72\x6c\x3d', 'start');
        lib_func_grab::html_intercept($html, "\'", 'end');
        $html = trim($html, '\\');
        if($html){
            $play_url[0] = 'http://www.zyshow.net/url='.$html;
        }
   
        $html = $grab['html'];
        lib_func_grab::html_intercept($html, '<div class="play_boxb">', 'start');
        lib_func_grab::html_intercept($html, '<div class="video-list">', 'end');
        $pattern = '/href="(.*?)"/is';
        preg_match_all($pattern, $html, $result);
        if($result[1]){
            $play_url = array_merge($play_url, $result[1]);
        }
        
        foreach($play_url as $key => $value)
        {
            $data = lib_func_grab::get($value, $grab['detail_url'], $grab['host']);
            if($data)
            {
                if(strpos($data, 'var vid = "') !== FALSE){
                    $pattern = '/var vid = "(.*?)"/is';
                    preg_match($pattern, $data, $result);
                    if($result[1]){
                        $comment['play_url'][] = $result[1];
                    }
                }elseif(strpos($data, 'var urls = "') !== FALSE){
                    $pattern = '/var urls = "(.*?)"/is';
                    preg_match($pattern, $data, $result);
                    if($result[1]){
                        $comment['play_url'][] = $result[1];
                    }
                }else{
                    $url_info = lib_func_grab::$curl_info;
                    if($url_info['url']){
                        $comment['play_url'][] = $url_info['url'];
                    }
                }
            }
        }
    }
}

if(! function_exists('thread_data_get_www_zyshow_net'))
{
    function thread_data_get_www_zyshow_net($grab)
    {
        $comment = $grab['comment'] ? unserialize($grab['comment']) : '';

        $fid = $grab['fid'];
        $tid = $grab['tid'];
        $pid = $grab['pid'];
        $uid = $grab['authorid'];
        
        //采集分类
        $sortid = 0;
        $sql = 'SELECT threadsorts FROM %t WHERE fid=%d';
        $threadsorts = DB::result_first($sql, array('forum_forumfield', $fid));
        if($threadsorts)
        {
            $sort = '综艺节目';
            if(CHARSET == 'gbk'){
                $sort = lib_base::string_utf8_to_gbk($sort);
            }
            $threadsorts = unserialize($threadsorts);
            foreach($threadsorts['types'] as $key => $value){
                if($value == $sort){
                    $sortid = $key;
                    break;
                }
            }

            //节目名称
            $jmmc = '';
            //节目主题
            $jmzt = $comment['nav2'];
            //节目来宾
            $jmlb = $comment['visitor'];
            //观看地址1
            $gkdz1 = $comment['play_url'][0] ? $comment['play_url'][0] : '';
            //观看地址2
            $gkdz2 = $comment['play_url'][1] ? $comment['play_url'][1] : '';
            //观看地址3
            $gkdz3 = $comment['play_url'][2] ? $comment['play_url'][2] : '';
            //下载地址
            $xzdz = $comment['download_url'];
            //下载密码
            $xzmmia = $comment['download_password'];
            //播出时间
            $bcshijian = $comment['playtime'];
            //封面图
            $fengmiantu = '';
            
            $sql = 'SELECT * FROM '.DB::table('forum_typeoption')." WHERE identifier IN('jmmc')";
            $typeoption = DB::fetch_all($sql);

            foreach($typeoption as $value)
            {
                if($value['identifier'] == 'jmmc')
                {
                    $rules = unserialize($value['rules']);
                    $list = explode("\n", $rules['choices']);
                    foreach($list as $val){
                        $choices = explode('=', $val);
                        $id = trim($choices[0]);
                        $name = trim($choices[1]);
                        if($comment['nav1'] == $name){
                            $jmmc = $id;
                        }
                    }
                }
            }

            $add_optionvalue = array(
                'fid'=>$fid,
                'tid'=>$tid,
                'jmmc'=>$jmmc,
                'jmzt'=>$jmzt,
                'jmlb'=>$jmlb,
                'gkdz1'=>$gkdz1,
                'gkdz2'=>$gkdz2,
                'gkdz3'=>$gkdz3,
                'xzdz'=>$xzdz,
                'xzmmia'=>$xzmmia,
                'bcshijian'=>$bcshijian,
                'fengmiantu'=>$fengmiantu,
            );
            DB::insert('forum_optionvalue'.$sortid, $add_optionvalue);

            $typeoption_array = array('jmmc','jmzt','jmlb','gkdz1','gkdz2','gkdz3','xzdz','xzmmia','bcshijian','fengmiantu');
            $sql = 'SELECT optionid,identifier FROM %t WHERE identifier IN(%n)';
            $typeoption_list = DB::fetch_all($sql, array('forum_typeoption', $typeoption_array));

            foreach($typeoption_list as $value)
            {
                $add_typeoptionvar = array(
                    'sortid'=>$sortid,
                    'tid'=>$tid,
                    'fid'=>$fid,
                    'optionid'=>$value['optionid'],
                    'expiration'=>0,
                    'value'=>$add_optionvalue[$value['identifier']],
                );
                DB::insert('forum_typeoptionvar', $add_typeoptionvar);
            }

            if($sortid){
                DB::update('forum_thread', array('sortid'=>$sortid), array('tid'=>$tid));
            }
        }
    }
}
