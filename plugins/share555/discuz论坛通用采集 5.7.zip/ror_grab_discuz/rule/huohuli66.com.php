<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['list_intercept_start'] = '<div id="page_content">';
$rule[0]['list_intercept_filter'] = array();
$rule[0]['list_intercept_end'] = '<div id="footer-wrapper">';
$rule[0]['list_list'] = '<h6>(.*?)<\/h6>';
$rule[0]['list_title'] = '<a .*?>(.*?)<\/a>';
$rule[0]['list_source'] = 'href="(.*?)"';

$rule[0]['con_intercept_start'] = '<header class="page-header">';
$rule[0]['con_intercept_filter'] = array('<div class="post-tags">.*?<\/div>','<div class="postmeta">.*?<\/div>');
$rule[0]['con_intercept_end'] = '<div class="post-comment">';
$rule[0]['con_more_intercept_start'] = '';
$rule[0]['con_more_intercept_filter'] = array();
$rule[0]['con_more_intercept_end'] = '';

$rule[0]['tags_intercept_start'] = '';
$rule[0]['tags_intercept_filter'] = array();
$rule[0]['tags_intercept_end'] = '';
$rule[0]['tags_list'] = '';

$rule[0]['comment_intercept_start'] = '';
$rule[0]['comment_intercept_filter'] = array();
$rule[0]['comment_intercept_end'] = '';
$rule[0]['comment_list'] = '';

$rule[0]['comment_dateline'] = '';
$rule[0]['author_list'] = '';

$rule[0]['func'] = array(
    'list_deal'=>'list_deal_huohuli66_com',
    'detail_deal_more'=>'detail_deal_more_huohuli66_com',
);

if(! function_exists('list_deal_huohuli66_com'))
{
    function list_deal_huohuli66_com(& $grab)
    {
        foreach($grab['title'] as $key => $title){
            $grab['title'][$key] = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $title);
        }
    }
}

//采集内容处理
if(! function_exists('detail_deal_more_huohuli66_com'))
{
    function detail_deal_more_huohuli66_com(& $html, $grab)
    {
        $data = '';
        
        preg_match_all('/<!--.*?-->/is', $html, $result);
        if($result){
            foreach($result[0] as $value){
                $html = str_replace($value, '', $html);
            }
        }
        
        preg_match_all('/<video .*?src="(.*?)".*?>/is', $html, $result_video);
        if($result_video[1]){
            $result_video[1] = array_unique($result_video[1]);
            foreach($result_video[1] as $key => $value){
                $url = parse_url($value);
                $value = $url['scheme'].'://'.$url['host'].$url['path'];
                $data .= '[media=x,500,375]'.$value.'[/media]<br/>';
            }
        }
        
        preg_match_all('/<img .*?src="(.*?)".*?>/is', $html, $result_img);
        if($result_img[1]){
            $result_img[1] = array_unique($result_img[1]);
            foreach($result_img[1] as $value){
                $data .= '<img src="'.$value.'"/><br/>';
            }
        }

        preg_match('/<div class="user-file">(.*?)<\/div>/is', $html, $result_div);
        if($result_div[1]){
			 $result_div[1] = str_replace(' ', '', $result_div[1]);
             $data .= $result_div[1];
        }

		$pattern = array('<p class="photo_group">.*?<\/p>');
		lib_func_grab::content_filter($data, $pattern);
        
        $data = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $data);
        
        $html = $data;
    }
}
