<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

//数据类型
lib_func_grab::$grab_type = 1;

$rule = array(
    
    '0'=>array(
        
        'list_intercept_start'=>'<ul class="newslist">',
        'list_intercept_filter'=>array(),
        'list_intercept_end'=>'</ul>',
        'list_list'=>'<li class="title">(.*?)<\/li>',
        'list_source'=>'href="(.*?)"',
        'list_title'=>'<a .*?>(.*?)<\/a>',
        
        'con_intercept_start'=>'<div class="content">',
        'con_intercept_filter'=>array(),
        'con_intercept_end'=>'</div>',
        
        'title_intercept_start'=>'<h1 class="title">',
        'title_intercept_filter'=>array(),
        'title_intercept_end'=>'</h1>',
        
        'func'=>array(
            'page_deal'=>'page_deal_cj_sdahxm_com',
        )
    ),
    
);

if(! function_exists('page_deal_cj_sdahxm_com'))
{
    function page_deal_cj_sdahxm_com($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url .= '&page='.$page;
        
        return $url;
    }
}
