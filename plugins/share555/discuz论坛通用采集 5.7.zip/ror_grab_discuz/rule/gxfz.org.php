<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}


$rule[$ruleid]['list_intercept_start'] = '<h2 class="place';
$rule[$ruleid]['list_intercept_filter'] = array('');
$rule[$ruleid]['list_intercept_end'] = '</ul>';
$rule[$ruleid]['list_list'] = '<h2>(.*?)<\/h2>';
$rule[$ruleid]['list_title'] = '<a.*?>(.*?)<\/a>';
$rule[$ruleid]['list_source'] = 'href="(.*?)"';

$rule[$ruleid]['con_intercept_start'] = 'id="myarticle">';
$rule[$ruleid]['con_intercept_filter'] = '';
$rule[$ruleid]['con_intercept_end'] = '</div>';
$rule[$ruleid]['con_more_intercept_start'] = '<div class="single-credit">';
$rule[$ruleid]['con_more_intercept_filter'] = '';
$rule[$ruleid]['con_more_intercept_end'] = '<p class="tags"';

$rule[$ruleid]['tags_intercept_start'] = '';
$rule[$ruleid]['tags_intercept_filter'] = '';
$rule[$ruleid]['tags_intercept_end'] = '';
$rule[$ruleid]['tags_list'] = '';

$rule[$ruleid]['comment_intercept_start'] = '';
$rule[$ruleid]['comment_intercept_filter'] = '';
$rule[$ruleid]['comment_intercept_end'] = '';
$rule[$ruleid]['comment_list'] = '';

$rule[$ruleid]['comment_dateline'] = '';
$rule[$ruleid]['author_list'] = '';

$rule[$ruleid]['func'] = array(
    'list_deal'=>'list_deal_www_gxfz_org',
    'detail_deal'=>'detail_deal_www_gxfz_org',
    'detail_deal_more'=>'detail_deal_more_www_gxfz_org',
    'page_deal'=>'page_deal_www_gxfz_org',
);

if(! function_exists('list_deal_www_gxfz_org'))
{
    function list_deal_www_gxfz_org(& $grab)
    {
        foreach($grab['source'] as $key => $value){
            $grab['source'][$key] = str_replace('www.', '', $value);
        }
    }
}

if(! function_exists('detail_deal_www_gxfz_org'))
{
    function detail_deal_www_gxfz_org(& $html)
    {
        $html = str_replace('</br>', '<br/>', $html);
        
        if(strpos($html, '<mip-img') === FALSE){
            return;
        }
        
        $html = str_replace('<mip-img', '<img', $html);
        $html = str_replace('"" />', '"/>', $html);
        $html = str_replace('</mip-img>', '', $html);
    }
}

if(! function_exists('detail_deal_more_www_gxfz_org'))
{
    function detail_deal_more_www_gxfz_org(& $html, $grab)
    {
        $html_more = $grab['html'];

        lib_func_grab::html_intercept($html_more, $grab['rule']['con_more_intercept_start'], 'start');
        lib_func_grab::html_intercept($html_more, $grab['rule']['con_more_intercept_end'], 'end');
        
        $pattern = '/<a href="(.*?)".*?class="download_card">/is';
        preg_match($pattern, $html_more, $href);
        
        $pattern = '/<div class="download_card_title".*?>(.*?)<\/div>/is';
        preg_match($pattern, $html_more, $title);
        
        if($href[1] && $title[1]){
            $html .= '<p><a href="'.$href[1].'" target="_blank">'.$title[1].'</a></p>';
        }
        
        $html = str_replace('www.', '', $html);
    }
}

if(! function_exists('page_deal_www_gxfz_org'))
{
    function page_deal_www_gxfz_org($page, $nav)
    {
        $url = $nav['source'];

        if($page == 1){
            return $url;
        }

        $url = explode('-', $url);
        $url[3] = $page.'.html';
        $url = implode('-', $url);

        return $url;
    }
}