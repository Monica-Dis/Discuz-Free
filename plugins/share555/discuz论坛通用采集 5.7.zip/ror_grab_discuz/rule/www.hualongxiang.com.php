<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$filter = '登录/注册后可看大图';
$filter = lib_base::string_utf8_to_gbk($filter);

$rule[0]['list_intercept_start'] = '<tbody id="threadlist">';
$rule[0]['list_intercept_filter'] = array();
$rule[0]['list_intercept_end'] = '</table>';
$rule[0]['list_list'] = '<td class="subject" .*?>.*?<a href=(.*?)<\/td>';
$rule[0]['list_title'] = 'title="(.*?)"';
$rule[0]['list_source'] = 'href="(.*?)"';

$rule[0]['con_intercept_start'] = '<div class="read-content">';
$rule[0]['con_intercept_filter'] = array('<a .*?>','</a>',$filter);
$rule[0]['con_intercept_end'] = '</div>';
$rule[0]['con_more_intercept_start'] = '';
$rule[0]['con_more_intercept_filter'] = array();
$rule[0]['con_more_intercept_end'] = '';

$rule[0]['tags_intercept_start'] = '';
$rule[0]['tags_intercept_filter'] = array();
$rule[0]['tags_intercept_end'] = '';
$rule[0]['tags_list'] = '';

$rule[0]['comment_intercept_start'] = '<div class="read-content">';
$rule[0]['comment_intercept_filter'] = array('<a .*?>','</a>',$filter);
$rule[0]['comment_intercept_end'] = '<div class="page';
$rule[0]['comment_list'] = '<div class="read-content">(.*?)<\/div>';

$rule[0]['comment_dateline'] = '<div class="cont_hd clearfix">(.*?)<\/p>';
$rule[0]['author_list'] = '<span class="b fl">(.*?)<\/span>';

$rule[0]['func'] = array(
    'page_deal'=>'page_deal_www_hualongxiang_com',
);

if(! function_exists('page_deal_www_hualongxiang_com'))
{
    function page_deal_www_hualongxiang_com($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }

        $url = trim($url, '/').'/p'.$page;
        
        return $url;
    }
}
