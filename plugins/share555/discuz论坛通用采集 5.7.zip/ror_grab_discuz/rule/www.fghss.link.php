<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['list_intercept_start'] = '<div class="P-Home">';
$rule[0]['list_intercept_filter'] = array('');
$rule[0]['list_intercept_end'] = '<ul class="pagination">';
$rule[0]['list_list'] = '<div class="InfoItem(.*?)<div class="State">';
$rule[0]['list_title'] = '<div class="Title">(.*?)<\/div>';
$rule[0]['list_source'] = "jump\('(.*?)'\)";

$rule[0]['con_intercept_start'] = '<div class="LeftPart">';
$rule[0]['con_intercept_filter'] = array('');
$rule[0]['con_intercept_end'] = '<div class="RightPart">';
$rule[0]['con_more_intercept_start'] = '';
$rule[0]['con_more_intercept_filter'] = array();
$rule[0]['con_more_intercept_end'] = '';

$rule[0]['tags_intercept_start'] = '';
$rule[0]['tags_intercept_filter'] = array();
$rule[0]['tags_intercept_end'] = '';
$rule[0]['tags_list'] = '';

$rule[0]['comment_intercept_start'] = '';
$rule[0]['comment_intercept_filter'] = array();
$rule[0]['comment_intercept_end'] = '';
$rule[0]['comment_list'] = '';

$rule[0]['comment_dateline'] = '';
$rule[0]['author_list'] = '';

$rule[0]['func'] = array(
    'page_deal'=>'page_deal_www_fghss_top',
    'detail_deal_more'=>'detail_deal_more_www_fghss_top',
);

if(! function_exists('detail_deal_more_www_fghss_top'))
{
    function detail_deal_more_www_fghss_top(& $html, $grab)
    {
        $data = '';
        
        preg_match_all('/<div class="Profile">(.*?)<\/div>/is', $html, $result_div);
        if($result_div[1]){
            foreach($result_div[1] as $value){
                $data .= trim($value).'<br/>';
            }
        }
        
        preg_match_all('/<div class="my-3">(.*?)<\/div>/is', $html, $result_div);
        if($result_div[1]){
            foreach($result_div[1] as $value){
                $data .= trim($value).'<br/>';
            }
        }
        
        preg_match_all('/<p class="mb-2">(.*?)<\/p>/is', $html, $result_p);
        if($result_p[1]){
            foreach($result_p[1] as $value){
                $data .= trim($value).'<br/>';
            }
        }
        
        $html = $data;
    }
}

if(! function_exists('page_deal_www_fghss_top'))
{
    function page_deal_www_fghss_top($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url .= '&page'.$page;
        
        return $url;
    }
}
