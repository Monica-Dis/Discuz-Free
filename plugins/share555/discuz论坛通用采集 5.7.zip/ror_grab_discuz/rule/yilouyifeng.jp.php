<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

$rule[0]['list_intercept_start'] = '<div class="bg_fff';
$rule[0]['list_intercept_filter'] = array();
$rule[0]['list_intercept_end'] = '<script>';
$rule[0]['list_list'] = '<a class="model_link"(.*?)<span class="model_home">';
$rule[0]['list_title'] = '<span class="model_name">(.*?)<\/span>';
$rule[0]['list_source'] = 'href="(.*?)"';

$rule[0]['con_intercept_start'] = '<body';
$rule[0]['con_intercept_filter'] = array();
$rule[0]['con_intercept_end'] = '<script';
$rule[0]['con_more_intercept_start'] = '';
$rule[0]['con_more_intercept_filter'] = array();
$rule[0]['con_more_intercept_end'] = '';

$rule[0]['tags_intercept_start'] = '';
$rule[0]['tags_intercept_filter'] = array();
$rule[0]['tags_intercept_end'] = '';
$rule[0]['tags_list'] = '';

$rule[0]['comment_intercept_start'] = '';
$rule[0]['comment_intercept_filter'] = array();
$rule[0]['comment_intercept_end'] = '';
$rule[0]['comment_list'] = '';

$rule[0]['comment_dateline'] = '';
$rule[0]['author_list'] = '';

$rule[0]['func'] = array(
    'list_deal'=>'list_deal_yilouyifeng_jp',
    'detail_deal_more'=>'detail_deal_more_yilouyifeng_jp',
);

if(! function_exists('list_deal_yilouyifeng_jp'))
{
    function list_deal_yilouyifeng_jp(& $grab)
    {
        foreach($grab['title'] as $key => $title){
            $grab['title'][$key] = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $title);
        }
    }
}

//采集内容处理
if(! function_exists('detail_deal_more_yilouyifeng_jp'))
{
    function detail_deal_more_yilouyifeng_jp(& $html, $grab)
    {
        $data = '';
        
        preg_match_all('/<!--.*?-->/is', $html, $result);
        if($result){
            foreach($result[0] as $value){
                $html = str_replace($value, '', $html);
            }
        }
        
        preg_match_all('/<video .*?src="(.*?)".*?>/is', $html, $result_video);
        if($result_video[1]){
            $result_video[1] = array_unique($result_video[1]);
            foreach($result_video[1] as $key => $value){
                $url = parse_url($value);
                $value = $url['scheme'].'://'.$url['host'].$url['path'];
                $data .= '[media=x,500,375]'.$value.'[/media]<br/>';
            }
        }
        
        preg_match_all('/<img .*?src="(.*?)".*?>/is', $html, $result_img);
        if($result_img[1]){
            $result_img[1] = array_unique($result_img[1]);
            foreach($result_img[1] as $value){
                $data .= '<img src="'.$value.'"/><br/>';
            }
        }
        
        preg_match_all('/<div class="mar_tb5 font_16">(.*?)<\/div>/is', $html, $result_div);
        if($result_div[1]){
            foreach($result_div[1] as $value){
                preg_match('/<span class="font.*?>(.*?)</is', $value, $result_prefix);
                preg_match('/<span class="model.*?>(.*?)</is', $value, $result_postfix);
                if($result_prefix[1] && $result_postfix[1]){
                    $data .= $result_prefix[1].$result_postfix[1].'<br/>';
                }
            }
        }

        preg_match_all('/<span class="model_intro.*?>(.*?)<\/span>/is', $html, $result_span);
        if($result_span[1]){
            foreach($result_span[1] as $value){
                $data .= $value.'<br/>';
            }
        }
        
        $data = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $data);
        
        $html = $data;
    }
}


if(! function_exists('list_start_taohuadao_jp'))
{
    function list_start_taohuadao_jp($grab)
    {
        $html = $grab['html'];
        
        $notice = lib_base::lang('func_detail_start_fail').$grab['detail_url'];
        lib_func_grab::html_intercept($html, '<div class="bg_fff mar_b15 screen">', 'start', $notice);
        
        $notice = lib_base::lang('func_detail_end_fail').$grab['detail_url'];
        lib_func_grab::html_intercept($html, '<div class="nav"', 'end', $notice);
        
        preg_match_all('/<div style="margin-top:15px(.*?)<\/a>-->/is', $html, $result);
        
        $grab['title'] = array();
        $grab['source'] = array();
        $grab['content'] = array();
        
        $host = 'http://yilouyifeng.jp';
        
        foreach($result[1] as $key => $value)
        {
            preg_match('/<span class="model_name">(.*?)<\/span>/is', $value, $title);
            preg_match("/window.location.href = '(.*?)'/is", $value, $source);
            preg_match('/<div class="mar_tb5 font_14">(.*?)<!--/', $value, $content);
            //preg_match('/locahref\(.*?,"(.*?)"/', $value, $video);
            
            $content[1] = str_replace('</div>', '<br>', $content[1]);
            
            lib_func_grab::content_filter_tag($title[1]);
            lib_func_grab::content_filter_tag($content[1]);
            
            $grab['title'][$key] = trim($title[1]);
            $grab['content'][$key] = $content[1];
            $grab['source'][$key] = $source[1];
            
            preg_match('/cloid\/(.*?)\.html/', $grab['source'][$key], $cloids);
            
            $cloid = $cloids[1];
            
            $pic_url = $host.'/mobile.php/Index/girl_detailspic/cloid/'.$cloid.'.html';
            //$video_url = $host.$video[1];
            
            $grab['source'][$key] = $pic_url;
            
            $pic_html = lib_func_grab::get($pic_url);
            
            $notice = lib_base::lang('func_detail_start_fail').$grab['detail_url'];
            lib_func_grab::html_intercept($pic_html, '<div id="tops">', 'start', $notice);
            
            $notice = lib_base::lang('func_detail_end_fail').$grab['detail_url'];
            lib_func_grab::html_intercept($pic_html, '<div class="nav"', 'end', $notice);
            
            lib_func_grab::src_deal($pic_html, $host);
            
            lib_func_grab::content_filter_tag($pic_html);
            
            //$video_html = '<p>video：<a href="'.$video_url.'" target="_blank">'.$video_url.'</a></p>';
            
            $grab['content'][$key] .= $pic_html;
        }
        
        lib_func_grab::$repeat_count = 0;
        foreach($grab['title'] as $key => $title)
        {
            if(! $value){
                continue;
            }
            
            $source = $grab['source'][$key];
            
            $identify = lib_func_grab::save_identify($source);
            
            $sql = 'SELECT COUNT(*) FROM '.DB::table('plugin_'.PLUGIN_NAME)." WHERE identify='".$identify."'";
            $count = DB::result_first($sql);
            if($count)
            {
                $notice = '内容采集重复，'.$source;
                lib_base::back_html($notice, 1);
                lib_func_grab::$repeat_count++;
                
                if(lib_func_grab::$repeat_count >= lib_func_grab::$repeat_limit){
                    $notice = '采集内容重复次数超过'.lib_func_grab::$repeat_limit.'次，中断采集:'.$source;
                    lib_base::back_html($notice, 1);
                    break;
                }
                
                continue;
            }
            
            lib_func_grab::$grab_new++;
            lib_func_grab::grab_save($grab, $title, $grab['content'][$key], array(), array(), $source);
        }
        
        
        //更新机制
        lib_func_grab::nav_crontime_update($grab['id'], $grab['crontime']);
        
        return TRUE;
    }
}
