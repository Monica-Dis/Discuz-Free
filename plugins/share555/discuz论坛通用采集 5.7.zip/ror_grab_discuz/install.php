<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
    exit('Access denied');
}

$plugin_name = 'ror_grab_discuz';

$sql = <<<EOT

CREATE TABLE `pre_plugin_{$plugin_name}` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `navid` int(10) unsigned NOT NULL DEFAULT '0',
 `send_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
 `cid` int(10) unsigned NOT NULL DEFAULT '0',
 `fid` int(10) unsigned NOT NULL DEFAULT '0',
 `typeid` int(10) unsigned NOT NULL DEFAULT '0',
 `tid` int(10) unsigned NOT NULL DEFAULT '0',
 `aid` int(10) unsigned NOT NULL DEFAULT '0',
 `title` varchar(255) NOT NULL DEFAULT '',
 `content` mediumtext NOT NULL,
 `source` varchar(500) NOT NULL DEFAULT '',
 `tags` varchar(255) NOT NULL DEFAULT '',
 `comment` mediumtext NOT NULL,
 `identify` char(32) NOT NULL DEFAULT '',
 `dateline` int(10) unsigned NOT NULL DEFAULT '0',
 `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
 PRIMARY KEY (`id`),
 KEY `status` (`status`),
 KEY `identify` (`identify`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_plugin_{$plugin_name}_local` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `navid` int(10) unsigned NOT NULL DEFAULT '0',
 `title` varchar(255) NOT NULL DEFAULT '',
 `source` varchar(500) NOT NULL DEFAULT '',
 `identify` char(32) NOT NULL DEFAULT '',
 `dateline` int(10) unsigned NOT NULL DEFAULT '0',
 PRIMARY KEY (`id`),
 KEY `identify` (`identify`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_plugin_{$plugin_name}_keyword` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `word1` varchar(30) NOT NULL DEFAULT '',
 `word2` varchar(30) NOT NULL DEFAULT '',
 PRIMARY KEY (`id`),
 UNIQUE KEY `word1` (`word1`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_plugin_{$plugin_name}_site_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `send_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
 `cid` int(10) unsigned NOT NULL DEFAULT '0',
 `fid` int(10) unsigned NOT NULL DEFAULT '0',
 `typeid` int(10) unsigned NOT NULL DEFAULT '0',
 `title` varchar(255) NOT NULL DEFAULT '',
 `ruleid` int(10) unsigned NOT NULL DEFAULT '0',
 `crontime` int(10) unsigned NOT NULL DEFAULT '0',
 `grabtime` int(10) unsigned NOT NULL DEFAULT '0',
 `source` varchar(500) NOT NULL DEFAULT '',
 `cookie` text NOT NULL,
 `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
 PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_plugin_{$plugin_name}_vest` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(10) unsigned NOT NULL DEFAULT '0',
 `username` varchar(255) NOT NULL DEFAULT '',
 `fid` int(10) unsigned NOT NULL DEFAULT '0',
 PRIMARY KEY (`id`),
 UNIQUE KEY `uid` (`uid`,`fid`)
) ENGINE=InnoDB;

EOT;

runquery($sql);

$finish = true;