<?php

//cronname:ror_grab_discuz
//week:
//day:
//hour:
//minute:0,5,10,15,20,25,30,35,40,45,50,55

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//您的计划任务脚本内容
$plugin_name = 'ror_grab_discuz';

$url = rtrim($_G['siteurl'], '/').'/plugin.php?id='.$plugin_name;

dfsockopen($url);