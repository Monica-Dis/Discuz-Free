<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_admin_grab extends discuz_table
{
    public function __construct()
    {
        parent::__construct(); /*dism·taobao·com*/

        $this->_pk = 'id';
        $this->_table = 'plugin_'.PLUGIN_NAME;
    }
    
    var $status = array(
        0=>'&#26410;&#21457;',
        1=>'&#24050;&#21457;',
    );
    var $cookie = array();
    
    /**
     * 采集保存到帖子
     *
     * @access public
     * @param array, array, array
     * @return bool
     */
    public function grab_to_thread($grab, $vest_list, $settings, $vest_post)
    {
        global $_G;
            
        $this->cookie = $grab['cookie'];
    
        //取消回复内容最大限制
        $_G['setting']['maxpostsize'] = 0;
    
        $grabid = $grab['id'];
        $fid = $grab['fid'];
        $typeid = $grab['typeid'];
        $subject = cutstr($grab['title'], 70, '');
        $message = $grab['content'];
        $tags = $grab['tags'];
        $comment = $grab['comment'] ? unserialize($grab['comment']) : '';

        $author = '';
        $authorid = 0;
        if(isset($comment['author'][0]) && $comment['author'][0]){
            $author = $comment['author'][0];
            $user = $this->user_info_by_username($author);
            if($user['uid'] && $user['username']){
                $author = $user['username'];
                $authorid = $user['uid'];
            }else{
                $uid = $this->user_register($author, $grab);
                if($uid){
                    $authorid = $uid;
                }else{
                    $vest = $vest_list[array_rand($vest_list)];
                    $author = $vest['username'];
                    $authorid = $vest['uid'];
                }
            }
        }else{
            $vest = $vest_list[array_rand($vest_list)];
            $author = $vest['username'];
            $authorid = $vest['uid'];
        }
 
        $verify_status = 0;
        if($settings['is_verify']){
            $verify_status = -2;
        }
        
//         $censor = & discuz_censor::instance();
//         $message_censor = $message;
//         $censor->check($message_censor);
//         if($censor->words_found || $message_censor != $message || $settings['is_verify']){
//             $verify_status = -2;
//         }
//         $subject_censor = $subject;
//         $censor->check($subject_censor);
//         if($censor->words_found || $subject_censor != $subject || $settings['is_verify']){
//             $verify_status = -2;
//         }
    
        //替换关键词
        if($settings['keyword_replace_percent']){
            lib_base::table('admin_keyword')->replace($subject, $settings['keyword_replace_percent']);
            lib_base::table('admin_keyword')->replace($message, $settings['keyword_replace_percent']);
        }

        $dateline = TIMESTAMP - 3600;
        if(isset($comment['dateline'][0])){
            $dateline = strtotime($comment['dateline'][0]);
            ! $dateline && $dateline = TIMESTAMP - 3600;
        }else if($settings['send_thread_time']){
            list($min, $max) = explode('-', $settings['send_thread_time']);
            $dateline -= intval(mt_rand(intval($min), intval($max)));
        }
    
        $views = 0;
        if($settings['thread_views']){
            list($min, $max) = explode('-', $settings['thread_views']);
            $views = intval(mt_rand(intval($min), intval($max)));
        }
    
        $settings['grab_source'] && $message .= '<br>'.str_replace('{url}', '<a href="'.$grab['source'].'" target="_blank">'.$grab['source'].'</a>', $settings['grab_source']);
        $settings['grab_declaration'] && $message .= '<br>'.$settings['grab_declaration'];
    
        if($settings['image_algin_center']){
            $this->message_image_formate($message, $_G['forum']['allowhtml']);
        }

        $_G['forum'] = C::t('forum_forum')->fetch($fid);
        if($_G['forum']['allowhtml'] != 1){
            $message = html2bbcode($message);
            $message = htmlspecialchars_decode($message);
        }

        //无内容更新本地资源状态
        if(! $message){
            $this->update($grabid, array('status'=>1));
        }

        if(DISCUZ_VERSION == 'X2.5')
        {
            $newthread = array(
                'fid' => $fid,
                'posttableid' => 0,
                'readperm' => 0,
                'price' => 0,
                'typeid' => $typeid,
                'sortid' => 0,
                'author' => $author,
                'authorid' => $authorid,
                'subject' => $subject,
                'dateline' => $dateline,
                'lastpost' => $dateline,
                'lastposter' =>  $author,
                'displayorder' => 0,
                'digest' => 0,
                'special' => 0,
                'attachment' => 0,
                'moderated' => 0,
                'status' => 0,
                'isgroup' => 0,
                'replycredit' => 0,
                'closed' => 0,
                'views'=>$views
            );
    
            $tid = C::t('forum_thread')->insert($newthread, true);
            	
            $pid = insertpost(array(
                'fid' => $fid,
                'tid' => $tid,
                'first' => 1,
                'author' => $author,
                'authorid' => $authorid,
                'subject' => $subject,
                'dateline' => $dateline,
                'message' => $message,
                'useip' => $_G['clientip'],
                'invisible' => 0,
                'anonymous' => 0,
                'usesig' => 1,
                'htmlon' => 0,
                'bbcodeoff' => -1,
                'smileyoff' => -1,
                'parseurloff' => 0,
                'attachment' => 0,
                'tags' => '',
                'replycredit' => 0,
                'status' => 0
            ));
        }
        else
        {
            $sortid = 0;
            
            $params = array(
                'subject'=>$subject,
                'message'=>$message,
                'typeid'=>$typeid,
                'sortid'=>$sortid,
                'special'=>0,
                'publishdate'=>$dateline,
                'readperm'=>0,
                'allownoticeauthor'=>0,
                'usesig'=>1,
                'replycredit'=>0,
                //'hiddenreplies'=>1
            );

            $modthread = C::m('forum_thread');
            $member = &C::app()->var['member'];
            $uid_bak = $member['uid'];
            $username_bak = $member['username'];
            $member['uid'] = $authorid;
            $member['username'] = $author;
            $modthread->newthread($params);
            $member['uid'] = $uid_bak;
            $member['username'] = $username_bak;
    
            $tid = $modthread->tid;
            $pid = $modthread->pid;
            $modthread->param = array();
        }
    
        if(! $tid || ! $pid){
            return 0;
        }
    
        //发帖成功更新本地资源状态
        $this->update($grabid, array('tid'=>$tid,'status'=>1));
    
        $post_message = $message;
        if($settings['image_to_local']){
            $post_message = $this->forum_image_attachment($tid, $pid, $authorid, $post_message, $_G['forum']['allowhtml']);
        }
        if($settings['attach_to_local']){
            $post_message = $this->forum_attach_attachment($tid, $pid, $authorid, $post_message, $_G['forum']['allowhtml']);
        }
    
        $postData = array(
            'bbcodeoff'=>0,
            'invisible'=>$verify_status
        );
    
        if($post_message != $message){
            $postData['message'] = $post_message;
        }
    
        //是否采集tag
        if($settings['is_grab_tag']){
            $class_tag = new tag();
            $tagstr = $class_tag->add_tag($tags, $tid, 'tid');
            $postData['tags'] = $tagstr;
        }
    
        if($_G['forum']['allowhtml'] == 1) {
            $postData['htmlon'] = 1;
        }
    
        $is_have_attachment = 0;
        if(strpos($post_message, '[attach]') !== false){
            $is_have_attachment = 2;
            $postData['attachment'] = $is_have_attachment;
            $this->setthreadcover($tid, $pid, $authorid);
        }else if(($_G['forum']['allowhtml'] == 1 && strpos($post_message, '<img') !== false) || strpos($post_message, '[img]') !== false){
            $is_have_attachment = 2;
            $postData['attachment'] = $is_have_attachment;
        }
    
        DB::update('forum_post', $postData, 'pid='.$pid);
    
        unset($postData);
        unset($params);
    
        $lastpostArr = array(
            'lastpost'=>$dateline,
            'lastposter'=>$author,
            'views'=>$views,
            'attachment'=>$is_have_attachment,
            'replies'=>0,
            'maxposition'=>0,
            'displayorder'=>$verify_status
        );
    
        //评论发回复
        if($settings['is_grab_comment'] && $comment['list'] && $vest_post){
            $result = $this->grab_to_post($grab, $vest_post, $settings, $_G['forum'], $tid, $dateline);
            if($result){
                $replies = C::t('forum_post')->count_visiblepost_by_tid($tid);
                $replies = intval($replies) - 1;
                $lastpostArr['replies'] = $replies;
                $lastpostArr['maxposition'] = $replies + 1;
            }
        }
    
        if($grab['send_type'] == 3) {
            $lastpostArr['isgroup'] = 1;
            $chkGroupUser = C::t('forum_groupuser')->fetch_all_userinfo($authorid, $fid);
            if($chkGroupUser) {
                C::t('forum_groupuser')->update_counter_for_user($authorid, $fid, 1);
            }else{
                C::t('forum_groupuser')->insert($fid, $authorid, $author, 4, TIMESTAMP, TIMESTAMP);
            }
        }
    
        DB::update('forum_thread', $lastpostArr, 'tid='.$tid);
    
        //进审核
        if($verify_status == -2){
            updatemoderate('tid', $tid);
        }
        
        //删除审核数据
//         if($verify_status == 0){
//             updatemoderate('tid', $tid, 2);
//         }
    
        $lastUserName = $tid."\t".daddslashes($subject)."\t".$dateline."\t".daddslashes($author);
        if(DISCUZ_VERSION == 'X2.5'){
            //更新用户统计
            DB::query('UPDATE '.DB::table('common_member_count').' SET extcredits2=extcredits2+2,threads=threads+1,posts=posts+1 WHERE uid='.$authorid);
            C::t('common_member_count')->clear_cache($authorid);
            DB::query("UPDATE ".DB::table('forum_forum')." SET threads=threads+1,posts=posts+1,lastpost='".$lastUserName."',todayposts=todayposts+1 WHERE fid=".$fid);
        }else{
            DB::query("UPDATE ".DB::table('forum_forum')." SET lastpost='".$lastUserName."' WHERE fid=".$fid);
            C::t('common_member_status')->update($authorid, array('lastip'=>$_G['clientip'],'lastvisit'=>TIMESTAMP,'lastactivity'=>TIMESTAMP));
            $newthread_is_exist = DB::result_first('SELECT COUNT(*) FROM '.DB::table('forum_newthread').' WHERE tid='.$tid);
            if(! $newthread_is_exist) {
                C::t('forum_newthread')->insert(array('tid' => $tid,'fid' => $fid,'dateline'=>TIMESTAMP));
            }
        }
    
        //更新缓存浏览量
        C::t('forum_thread')->increase_cache(array($tid), array('views'=>$views,'replies'=>$replies));

        //更新自定义帖子数据
        $urls = parse_url(trim($grab['source']));
        if($urls['host'])
        {
            $url = $grab['source'];
            $rule_file = DISCUZ_ROOT.'source/plugin/'.PLUGIN_NAME.'/rule/'.$urls['host'].'.php';
            if(file_exists($rule_file))
            {
                include $rule_file;
                $grab['rule'] = $rule[0];
                if(isset($grab['rule']['func']['thread_data_get']) && $grab['rule']['func']['thread_data_get']){
                    if(function_exists($grab['rule']['func']['thread_data_get'])){
                        $grab['tid'] = $tid;
                        $grab['pid'] = $pid;
                        $grab['authorid'] = $authorid;
                        $grab['rule']['func']['thread_data_get']($grab);
                    }
                }
            }
        }
    
        return $tid;
    }
    
    /**
     * 设置封面
     *
     * @access public
     * @param array, array, array
     * @return bool
     */
    public function setthreadcover($tid, $pid, $authorid)
    {
        global $_G;
    
        $temp_uid = $_G['uid'];
        $temp_ismoderator = $_G['forum']['ismoderator'];
        $temp_forumpicstyle = $_G['setting']['forumpicstyle'];
    
        $_G['uid'] = $authorid;
        $_G['forum']['ismoderator'] = 1;
    
        $forumpicstyle = '';
        if($_G['setting']['forumpicstyle']){
            $forumpicstyle = unserialize($_G['setting']['forumpicstyle']);
            if($forumpicstyle['thumbwidth']){
                $_G['setting']['forumpicstyle'] = array(
                    'thumbwidth'=>$forumpicstyle['thumbwidth'],
                    'thumbheight'=>$forumpicstyle['thumbheight'] ? $forumpicstyle['thumbheight'] : 1000
                );
            }else{
                $forumpicstyle = '';
            }
        }
        if(! $forumpicstyle){
            $_G['setting']['forumpicstyle'] = array(
                'thumbwidth'=>203,
                'thumbheight'=>203
            );
        }
    
        setthreadcover($pid, $tid);
    
        $_G['uid'] = $temp_uid;
        $_G['forum']['ismoderator'] = $temp_ismoderator;
        $_G['setting']['forumpicstyle'] = $temp_forumpicstyle;
    }
    
    /**
     * 采集评论保存到帖子
     *
     * @access public
     * @param array, array, array
     * @return bool
     */
    public function grab_to_post($grab, $vest_list, $settings, $forumInfo, $tid, $dateline)
    {
        global $_G;
    
        $comment = unserialize($grab['comment']);
    
        $post_dateline = $comment['dateline'];
        $post_author = $comment['author'];
        $postitem = $comment['list'];
    
        if(! $postitem){
            return FALSE;
        }
    
        $fid = $forumInfo['fid'];
    
        $post_count = count($postitem);
        $time_intval = intval((TIMESTAMP - $dateline) / $post_count);
        $post_cur = $post_count;
    
        foreach($postitem as $post_k => $post_value)
        {
            $post_time_max = ($post_cur - $post_k) * $time_intval;
            $post_time_min = $post_time_max - $time_intval;
            $post_time = TIMESTAMP - intval(mt_rand($post_time_min, $post_time_max));
    
            $post_text = $post_value;
    
            if($forumInfo['allowhtml'] != 1) {
                $post_text = html2bbcode($post_text);
                $post_text = htmlspecialchars_decode($post_text);
            }
    
            $post_text = trim($post_text);
    
            if(! $post_text){
                continue;
            }
    
            $author = '';
            $authorid = 0;
            if(isset($post_author[$post_k]) && $post_author[$post_k]){
                $author = $post_author[$post_k];
                $user = $this->user_info_by_username($author);
                if($user['uid'] && $user['username']){
                    $author = $user['username'];
                    $authorid = $user['uid'];
                }else{
                    $uid = $this->user_register($author, $grab);
                    if($uid){
                        $authorid = $uid;
                    }else{
                        $vest = $vest_list[array_rand($vest_list)];
                        $author = $vest['username'];
                        $authorid = $vest['uid'];
                    }
                }
            }else{
                $vest = $vest_list[array_rand($vest_list)];
                $author = $vest['username'];
                $authorid = $vest['uid'];
            }
    
            if(isset($post_dateline[$post_k])){
                $time = strtotime($post_dateline[$post_k]);
                $time && $post_time = $time;
            }
    
            $add = array(
                'fid'=>$fid,
                'tid'=>$tid,
                'first'=>'0',
                'author'=>$author,
                'authorid'=>$authorid,
                'subject'=>'',
                'dateline'=>$post_time,
                'message'=>$post_text,
                'useip'=>$_G['clientip'],
                'invisible'=>0,
                'anonymous'=>0,
                'usesig'=>1,
                'htmlon'=>0,
                'bbcodeoff'=>0,
                'smileyoff'=>-1,
                'parseurloff'=>0,
                'attachment'=>'0',
                'status' => 0
            );
    
            if(! in_array(DISCUZ_VERSION, array('X2.5','X3'))){
                $add['port'] = $_G['remoteport'];
            }
    
            $pid = insertpost($add);
    
            $postData = array();
    
            $post_message = $post_text;
            if($settings['image_to_local']){
                $post_message = $this->forum_image_attachment($tid, $pid, $authorid, $post_message, $forumInfo['allowhtml']);
            }
            if($settings['attach_to_local']){
                $post_message = $this->forum_attach_attachment($tid, $pid, $authorid, $post_message, $forumInfo['allowhtml']);
            }
    
            if($post_message != $post_text){
                $postData['message'] = $post_message;
            }
    
            if($forumInfo['allowhtml'] == 1) {
                $postData['htmlon'] = 1;
            }
    
            $is_have_attachment = 0;
            if(strpos($post_message, '[attach]') !== false){
                $is_have_attachment = 2;
                $postData['attachment'] = $is_have_attachment;
                //$this->setthreadcover($tid, $pid, $authorid);
            }else if(($forumInfo['allowhtml'] == 1 && strpos($post_message, '<img') !== false) || strpos($post_message, '[img]') !== false){
                $is_have_attachment = 2;
                $postData['attachment'] = $is_have_attachment;
            }
    
            DB::update('forum_post', $postData, 'pid='.$pid);
    
            //updatemembercount($authorid, array('extcredits2'=>1), true, '', 0, '');
            DB::query('UPDATE '.DB::table('common_member_count').' SET extcredits2=extcredits2+1,posts=posts+1 WHERE uid='.$authorid);
    
            C::t('forum_threadpartake')->insert(array('tid'=>$tid,'uid'=>$authorid,'dateline'=>TIMESTAMP));
            if(DISCUZ_VERSION != 'X2.5'){
                C::t('common_member_status')->update($authorid, array('lastip'=>$_G['clientip'],'lastvisit'=>TIMESTAMP,'lastactivity'=>TIMESTAMP));
            }
    
            if($grab['send_type'] == 3){
                $chkGroupUser = C::t('forum_groupuser')->fetch_all_userinfo($authorid, $fid);
                if(empty($chkGroupUser)) {
                    C::t('forum_groupuser')->insert($fid, $authorid, $author, 4, TIMESTAMP, TIMESTAMP);
                } else {
                    C::t('forum_groupuser')->update_counter_for_user($authorid, $fid, 0, 1);
                }
            }
        }
    
        return TRUE;
    }
    
    /**
     * 采集保存到门户
     *
     * @access public
     * @param array, array, array
     * @return bool
     */
    public function grab_to_portal($grab, $vest_list, $settings, $vest_post)
    {
        global $_G;
    
        $this->cookie = $grab['cookie'];
    
        $grabid = $grab['id'];
        $title = cutstr($grab['title'], 255, '');
        $content = $grab['content'];
        $cid = $grab['cid'];
        $comment = $grab['comment'] ? unserialize($grab['comment']) : '';
    
        $author = '';
        $authorid = 0;
        if(isset($comment['author'][0]) && $comment['author'][0]){
            $author = $comment['author'][0];
            $user = $this->user_info_by_username($author);
            if($user['uid'] && $user['username']){
                $author = $user['username'];
                $authorid = $user['uid'];
            }else{
                $uid = $this->user_register($author, $grab);
                if($uid){
                    $authorid = $uid;
                }else{
                    $vest = $vest_list[array_rand($vest_list)];
                    $author = $vest['username'];
                    $authorid = $vest['uid'];
                }
            }
        }else{
            $vest = $vest_list[array_rand($vest_list)];
            $author = $vest['username'];
            $authorid = $vest['uid'];
        }
    
        $dateline = TIMESTAMP - 3600;
        if(isset($comment['dateline'][0])){
            $dateline = strtotime($comment['dateline'][0]);
            ! $dateline && $dateline = TIMESTAMP - 3600;
        }else if($settings['send_thread_time']){
            list($min, $max) = explode('-', $settings['send_thread_time']);
            $dateline -= intval(mt_rand(intval($min), intval($max)));
        }
    
        $views = 0;
        if($settings['thread_views']){
            list($min, $max) = explode('-', $settings['thread_views']);
            $views = intval(mt_rand(intval($min), intval($max)));
        }
    
        //替换关键词
        if($settings['keyword_replace_percent']){
            lib_base::table('admin_keyword')->replace($title, $settings['keyword_replace_percent']);
            lib_base::table('admin_keyword')->replace($content, $settings['keyword_replace_percent']);
        }

        $summary = cutstr(strip_tags($content), 200, '');
        $summary = censor($summary);
        $setarr = array(
            'catid'=>$cid,
            'bid'=>0,
            'uid'=>$authorid,
            'username'=>$author,
            'title'=>$title,
            'highlight'=>'|||',
            'author'=>'',
            'from'=>'',
            'fromurl'=>$settings['grab_source'] ? $grab['source'] : '',
            'url'=>'',
            'summary'=>$summary,
            'pic'=>'',
            'thumb'=>0,
            'remote'=>0,
            'id'=>0,
            'idtype'=>'',
            'contents'=>1,
            'dateline'=>$dateline,
            'allowcomment'=>1
        );
    
        $aid = C::t('portal_article_title')->insert($setarr, 1);
    
        //发帖成功更新本地资源状态
        $this->update($grabid, array('aid'=>$aid,'status'=>1));
    
        if($settings['image_to_local']){
            $content = $this->portal_image_attachment($aid, $authorid, $content);
        }
    
        C::t('portal_category')->increase($cid, array('articles' => 1));
    
        if(DISCUZ_VERSION != 'X2.5'){
            C::t('common_member_status')->update($authorid, array('lastip'=>$_G['clientip'],'lastvisit'=>$dateline,'lastactivity'=>$dateline));
            C::t('portal_category')->update($cid, array('lastpublish'=>$dateline));
        }
    
        C::t('portal_article_count')->insert(array('aid'=>$aid,'catid'=>$cid,'viewnum'=>$views));
    
        $settings['grab_source'] && $content .= '<br>'.str_replace('{url}', '<a href="'.$grab['source'].'" target="_blank">'.$grab['source'].'</a>', $settings['grab_source']);
        $settings['grab_declaration'] && $content .= '<br>'.$settings['grab_declaration'];
    
        //图片居中展示
        if($settings['image_algin_center']){
            $this->message_image_formate($content, 1);
        }
    
        C::t('portal_article_content')->insert(array('aid'=>$aid,'id'=>0,'idtype'=>'','title'=>'','content'=>$content,'pageorder'=>1,'dateline'=>$dateline));
    
        if(DISCUZ_VERSION != 'X2.5'){
            $this->portalcp_article_pre_next($cid, $aid);
        }
    
        //评论发回复
        if($grab['comment'] && $settings['is_grab_comment'] && $vest_post){
            $this->grab_to_portal_comment($grab, $vest_post, $aid, $settings, $dateline);
        }
        
        //更新自定义帖子数据
        $urls = parse_url(trim($grab['source']));
        if($urls['host'])
        {
            $url = $grab['source'];
            $rule_file = DISCUZ_ROOT.'source/plugin/'.PLUGIN_NAME.'/rule/'.$urls['host'].'.php';
            if(file_exists($rule_file))
            {
                include $rule_file;
                $grab['rule'] = $rule[0];
                if(isset($grab['rule']['func']['portal_data_get']) && $grab['rule']['func']['portal_data_get']){
                    if(function_exists($grab['rule']['func']['portal_data_get'])){
                        $grab['aid'] = $aid;
                        $grab['authorid'] = $authorid;
                        $grab['rule']['func']['portal_data_get']($grab);
                    }
                }
            }
        }
    
        return $aid;
    }
    
    /**
     * 采集到门户评论
     *
     * @access public
     * @param array, array, array
     * @return bool
     */
    public function grab_to_portal_comment($grab, $vest_list, $aid, $settings, $dateline)
    {
        global $_G;
    
        $comment = unserialize($grab['comment']);
    
        $post_dateline = $comment['dateline'];
        $post_author = $comment['author'];
        $postitem = $comment['list'];
    
        if(! $postitem){
            return FALSE;
        }
    
        $post_count = count($postitem);
        $time_intval = intval((TIMESTAMP - $dateline) / $post_count);
        $post_cur = $post_count;
    
        foreach($postitem as $post_k => $post_value)
        {
            $post_time_max = ($post_cur - $post_k) * $time_intval;
            $post_time_min = $post_time_max - $time_intval;
            $post_time = TIMESTAMP - intval(mt_rand($post_time_min, $post_time_max));
    
            $post_text = trim(strip_tags($post_value));
    
            if(! $post_text){
                continue;
            }
    
            $author = '';
            $authorid = 0;
            if(isset($post_author[$post_k]) && $post_author[$post_k]){
                $author = $post_author[$post_k];
                $user = $this->user_info_by_username($author);
                if($user['uid'] && $user['username']){
                    $author = $user['username'];
                    $authorid = $user['uid'];
                }else{
                    $uid = $this->user_register($author, $grab);
                    if($uid){
                        $authorid = $uid;
                    }else{
                        $vest = $vest_list[array_rand($vest_list)];
                        $author = $vest['username'];
                        $authorid = $vest['uid'];
                    }
                }
            }else{
                $vest = $vest_list[array_rand($vest_list)];
                $author = $vest['username'];
                $authorid = $vest['uid'];
            }
    
            if(isset($post_dateline[$post_k])){
                $time = strtotime($post_dateline[$post_k]);
                $time && $post_time = $time;
            }
    
            $add = array(
                'uid'=>$authorid,
                'username'=>$author,
                'id'=>$aid,
                'idtype'=>'aid',
                'postip'=>$_G['clientip'],
                'dateline'=>$post_time,
                'status'=>0,
                'message'=>$post_text
            );
    
            if(! in_array(DISCUZ_VERSION, array('X2.5','X3'))){
                $add['port'] = $_G['remoteport'];
            }
    
            $pcid = C::t('portal_comment')->insert($add, true);
            C::t('portal_article_count')->increase($aid, array('commentnum' => 1));
        }
    }
    
    public function portalcp_article_pre_next($catid, $aid)
    {
        $data = array('preaid'=>C::t('portal_article_title')->fetch_preaid_by_catid_aid($catid, $aid),
            'nextaid'=>C::t('portal_article_title')->fetch_nextaid_by_catid_aid($catid, $aid),
        );
    
        if ($data['preaid']){
            C::t('portal_article_title')->update($data['preaid'], array('preaid'=>C::t('portal_article_title')->fetch_preaid_by_catid_aid($catid, $data['preaid']),
            'nextaid'=>C::t('portal_article_title')->fetch_nextaid_by_catid_aid($catid, $data['preaid']),
            )
            );
        }
    
        return $data;
    }
    
    public function forum_image_attachment($tid, $pid, $uid, $message, $allowhtml = 0)
    {
        global $_G;
    
        if($allowhtml == 0) {
            preg_match_all("/(\[img\]|\[img=\d{1,4}[x|\,]\d{1,4}\])\s*([^\[\<\r\n]+?)\s*\[\/img\]/is", $message, $imglist, PREG_SET_ORDER);
        }else{
            preg_match_all('/<img[^<>]*src\s*=\s*([\'"]?)([^\'">]*)\1[^<>]*>/i', $message, $imglist, PREG_SET_ORDER);
        }
    
        $HasForumThreadimage = true;
        if(count($imglist) == 0) {
            return $message;
        }
    
        foreach($imglist as $key => $img)
        {
            $imgUrl = $img[2];
            $imgUrl = htmlspecialchars_decode($imgUrl);
    
            $savefilename = $this->image_to_local($imgUrl, 'forum');
    
            if(! $savefilename){
                continue;
            }
    
            if($imglist[$key][0] && strpos($imglist[$key][0], 'title=') !== FALSE){
                preg_match('/title="(.*?)"/i', $imglist[$key][0], $title);
                if($title[1]){
                    $savefilename['filename'] = $title[1];
                }
            }
    
            if($HasForumThreadimage && $savefilename['imagesize']>900){
                $threadimage = array(
                    'tid'=>$tid,
                    'attachment'=>$savefilename['filepath'],
                    'remote'=>$savefilename['remote'],
                );
                DB::insert("forum_threadimage", $threadimage);
                $HasForumThreadimage=false;
            }
    
            $attachment = array(
                'tid'=>$tid,
                'pid'=>$pid,
                'uid'=>$uid,
                'tableid'=>getattachtableid($tid),
                'downloads'=>0
            );
            $aid = DB::insert("forum_attachment", $attachment, true);
            $forum_attachment_n = array(
                'aid'=>$aid,
                'tid'=>$tid,
                'pid'=>$pid,
                'uid'=>$uid,
                'dateline'=>TIMESTAMP,
                'filename'=>$savefilename['filename'],
                'filesize'=>$savefilename['imagesize'],
                'attachment'=>$savefilename['filepath'],
                'remote'=>$savefilename['remote'],
                'readperm'=>0,
                'price'=>0,
                'isimage'=>1,
                'width'=>$savefilename['imgwidth'],
                'thumb'=>$savefilename['thumb'],
                'picid'=>0
            );
            C::t("forum_attachment_n")->insert("tid:" . $tid, $forum_attachment_n);
    
            $message = $this->str_replace_once($img[0], '[attach]'.$aid.'[/attach]', $message);
        }
    
        return $message;
    }
    
    public function forum_attach_attachment($tid, $pid, $uid, $message, $allowhtml = 0)
    {
        global $_G;
    
        if($allowhtml == 0) {
            preg_match_all('/\[url=(.*?)\](.*?)\[\/url\]/i', $message, $result);
        }else{
            preg_match_all('/<a href="(.*?)".*?>(.*?)<\/a>/i', $message, $result);
        }
    
        if(! $result[0]) {
            return $message;
        }
    
        foreach($result[1] as $key => $value)
        {
            $url = htmlspecialchars_decode($value);
    
            if(strpos($value, 'mod=attachment') === FALSE){
                continue;
            }
    
            $filename = strip_tags($result[2][$key]);
    
            $ext = strtolower(substr($filename, (strrpos($filename, '.') + 1)));
            $savefilename = $this->attach_to_local($value, $ext, 'forum');
    
            if(! $savefilename){
                continue;
            }
    
            $attachment = array(
                'tid'=>$tid,
                'pid'=>$pid,
                'uid'=>$uid,
                'tableid'=>getattachtableid($tid),
                'downloads'=>0
            );
            $aid = DB::insert("forum_attachment", $attachment, true);
            $forum_attachment_n = array(
                'aid'=>$aid,
                'tid'=>$tid,
                'pid'=>$pid,
                'uid'=>$uid,
                'dateline'=>TIMESTAMP,
                'filename'=>$filename,
                'filesize'=>$savefilename['filesize'],
                'attachment'=>$savefilename['filepath'],
                'remote'=>$savefilename['remote'],
                'readperm'=>0,
                'price'=>0,
                'isimage'=>0,
                'width'=>0,
                'thumb'=>0,
                'picid'=>0
            );
            C::t("forum_attachment_n")->insert("tid:" . $tid, $forum_attachment_n);
    
            $message = $this->str_replace_once($result[0][$key], '[attach]'.$aid.'[/attach]', $message);
        }
    
        return $message;
    }
    
    public function portal_image_attachment($aid, $uid, $message)
    {
        global $_G;
    
        if(stripos($message, '<img') === FALSE){
            return $message;
        }
    
        $pattern = '/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/i';
        preg_match_all($pattern, $message, $imglist);
    
        if(! isset($imglist[1][0]) || ! $imglist[1][0]) {
            return $message;
        }
    
        foreach($imglist[1] as $key => $img)
        {
            $img = htmlspecialchars_decode($img);
    
            $savefilename = $this->image_to_local($img, 'portal');
    
            if(! $savefilename){
                continue;
            }
    
            $attach = array(
                'uid'=>$uid,
                'dateline'=>time(),
                'filename'=>$savefilename['filename'],
                'filetype'=>$savefilename['fileext'],
                'filesize'=>$savefilename['imagesize'],
                'attachment'=>$savefilename['filepath'],
                'isimage'=>1,
                'thumb'=>$savefilename['thumb'],
                'remote'=>$savefilename['remote'],
                'aid'=>$aid
            );
    
            $attachid = DB::insert('portal_attachment', $attach, true);
    
            $host = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'portal/';
            $newimageurl = $host.$attach['attachment'];
            $message = str_replace($img, $newimageurl, $message);
    
            //更新封面图
            if($key == 0 && $attach['thumb']){
                C::t('portal_article_title')->update($aid, array('pic'=>'portal/'.$savefilename['filepath'],'thumb'=>1,'remote'=>$savefilename['remote']));
            }
        }
    
        return $message;
    }
    
    public function content_iframe_formate(& $content)
    {
        global $_G;
    
        if(stripos($content, '<iframe') === FALSE){
            return FALSE;
        }
         
        $pattern = '/<iframe.*?[\s]src=[\'"](.*?)[\'"].*?>/i';
        preg_match_all($pattern, $content, $result);
        if(! $result[1]){
            return FALSE;
        }
    
        $result[0] = array_unique($result[0]);
    
        foreach($result[0] as $key => $value){
            $width = '540';
            $height = '360';
            if(strpos($value, 'width=') !== FALSE){
                $pattern = '/width="(.*?)"/i';
                preg_match($pattern, $value, $temp);
                $temp[1] && $width = rtrim($temp[1], 'px');
                $pattern = '/height="(.*?)"/i';
                preg_match($pattern, $value, $temp);
                $temp[1] && $height = rtrim($temp[1], 'px');
            }
    
            $content = str_replace($value, '[iframe='.$width.','.$height.']'.$result[1][$key].'[/iframe]', $content);
        }
    
        $content = str_replace('</iframe>', '', $content);
    
        return TRUE;
    }
    
    public function str_replace_once($needle, $replace, $haystack)
    {
        $pos = strpos($haystack, $needle);
        if ($pos === false) {
            return $haystack;
        }
        return substr_replace($haystack, $replace, $pos, strlen($needle));
    }
    
    public function image_to_local($imgurl, $from_type = 'forum')
    {
        global $_G;
    
        $filename = date('His') . strtolower(random(16));
        $dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
    
        $dir = $dir.$from_type;
        list($y, $m, $d) = explode('-', date('Y-m-d', TIMESTAMP));
        ! is_dir("$dir/$y$m") && mkdir("$dir/$y$m", 0777);
        ! is_dir("$dir/$y$m/$d") && mkdir("$dir/$y$m/$d", 0777);
        $savefilename = "$dir/$y$m/$d/";
    
        $ext_allow = array('jpg','png','jpeg','gif','bmp');
        $ext = strtolower(substr($imgurl, (strrpos($imgurl, '.') + 1)));
        ! in_array($ext, $ext_allow) && $ext = $ext_allow[0];
        $filename = $filename.'.'.$ext;
    
        $filepath = "$y$m/$d/$filename";
        $savefilename = $savefilename . $filename;
    
        include_once libfile('lib/func_grab', 'plugin/'.PLUGIN_NAME);
        $urls = parse_url($imgurl);
        $cookie = $this->cookie;
        $imgData = lib_func_grab::attach_get($imgurl, $urls['scheme'].'://'.$urls['host'], $urls['host'], $cookie);

        if(strlen($imgData) <= 1 || strpos($imgData, '<title>') !== FALSE){
            return FALSE;
        }
    
        file_put_contents($savefilename, $imgData);
    
        $imgwidth = $imagesize = 0;
        $imginfo = @getimagesize($savefilename);

        if($imginfo !== FALSE){
            $imgwidth = $imginfo[0];
            $imagesize = @filesize($savefilename);
        }
        if($imagesize == 0 || is_numeric($imagesize) === false){
            $imagesize = strlen($imgData);
        }
    
        require_once libfile('class/image');
    
        //图片缩略图
        $thumb = 0;
        if($from_type == 'forum')
        {
            if($_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight']) {
                $image = new image();
                $thumb = $image->Thumb($savefilename, '', $_G['setting']['sourcewidth'], $_G['setting']['sourceheight'], 1, 1) ? 1 : 0;
                $imgwidth = $image->imginfo['width'];
                $imagesize = $image->imginfo['size'];
            }
            if($_G['setting']['thumbstatus']) {
                $image = new image();
                $thumb = $image->Thumb($savefilename, '', $_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
                $imgwidth = $image->imginfo['width'];
            }
            if($_G['setting']['thumbsource'] || !$_G['setting']['thumbstatus']) {
                $imgwidth = $imginfo[0];
            }
        }
        if($from_type == 'portal')
        {
            if(empty($_G['setting']['portalarticleimgthumbclosed'])) {
                $image = new image();
                $thumbimgwidth = $_G['setting']['portalarticleimgthumbwidth'] ? $_G['setting']['portalarticleimgthumbwidth'] : 300;
                $thumbimgheight = $_G['setting']['portalarticleimgthumbheight'] ? $_G['setting']['portalarticleimgthumbheight'] : 300;
                $thumb = $image->Thumb($savefilename, '', $thumbimgwidth, $thumbimgheight, 2);
            }
        }
    
        //图片水印处理
        $watermarkstatus = $_G['setting']['watermarkstatus'] ? unserialize($_G['setting']['watermarkstatus']) : '';
        if(($watermarkstatus['forum'] && $from_type == 'forum') || ($watermarkstatus['portal'] && $from_type == 'portal')) {
            $image = new image();
            $image->Watermark($savefilename, '', $from_type);
            $imagesize = $image->imginfo['size'];
        }
    
        //ftp上传
        $remote = 0;
        if(getglobal('setting/ftp/on')) {
            if(ftpcmd('upload', $from_type.'/'.$filepath) && (! $thumb || ftpcmd('upload', $from_type.'/'.getimgthumbname($filepath)))) {
                @unlink($_G['setting']['attachdir'].'/'.$from_type.'/'.$filepath);
                $thumb && @unlink($_G['setting']['attachdir'].'/'.$from_type.'/'.getimgthumbname($filepath));
                $remote = 1;
            }
        }
    
        return array("thumb"=>$thumb,"remote"=>$remote,"target"=>$savefilename,"filepath" => $filepath, "imagesize" => $imagesize, "imgwidth" => $imgwidth, "filename"=>$filename, 'fileext'=>$ext);
    }
    
    public function attach_to_local($url, $ext = '', $from_type = 'forum')
    {
        global $_G;
    
        ! $ext  && $ext = 'attach';
    
        $filename = date('His').strtolower(random(16));
        $dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
    
        $dir = $dir.$from_type;
        list($y, $m, $d) = explode('-', date('Y-m-d', TIMESTAMP));
        ! is_dir("$dir/$y$m") && mkdir("$dir/$y$m", 0777);
        ! is_dir("$dir/$y$m/$d") && mkdir("$dir/$y$m/$d", 0777);
        $savefilename = "$dir/$y$m/$d/";
    
        $filename = $filename.'.'.$ext;
    
        $filepath = "$y$m/$d/$filename";
        $savefilename = $savefilename.$filename;
    
        require_once libfile('lib/func_grab', 'plugin/'.PLUGIN_NAME);
        $urls = parse_url($url);
        $cookie = $this->cookie;
        $data = lib_func_grab::attach_get($url, $urls['scheme'].'://'.$urls['host'], $urls['host'], $cookie);
        if(strlen($data) <= 1) {
            return FALSE;
        }
    
        file_put_contents($savefilename, $data);
    
        $filesize = filesize($savefilename);
    
        //ftp上传
        $remote = 0;
        if(getglobal('setting/ftp/on')) {
            if(ftpcmd('upload', $from_type.'/'.$filepath)) {
                @unlink($_G['setting']['attachdir'].'/'.$from_type.'/'.$filepath);
                $remote = 1;
            }
        }
    
        return array('remote'=>$remote,'target'=>$savefilename,'filepath'=>$filepath,'filesize'=>$filesize,'filename'=>$filename,'fileext'=>$ext);
    }
    
    public function message_image_formate(& $content, $allowhtml = 0)
    {
        if(stripos($content, '<img') === FALSE){
            return FALSE;
        }
    
        if($allowhtml == 1){
            $content = preg_replace('/(<img[^<>]+?>)/i', '<div align="center">$1</div>', $content);
        }else{
            $content = preg_replace('/(<img[^<>]+?>)/i', '[align=center]$1[/align]', $content);
        }
    
        return TRUE;
    }
    
    /**
     * 采集列表
     *
     * @access public
     * @param string, int, int, string
     * @return array
     */
    public function grab_list($fields, $offset, $limit, $where = '')
    {
        $sql = 'SELECT %i FROM %t %i ORDER BY id DESC LIMIT %d,%d';
    
        return DB::fetch_all($sql, array($fields, $this->_table, $where, $offset, $limit));
    }
    
    /**
     * 采集统计
     *
     * @access public
     * @param string
     * @return int
     */
    public function grab_count($where = '')
    {
        $sql = 'SELECT COUNT(*) FROM %t %i';
         
        return DB::result_first($sql, array($this->_table, $where));
    }
    
    /**
     * 板块列表
     *
     * @access public
     * @param
     * @return array
     */
    public function forum_list()
    {
        $sql = 'SELECT fid,name FROM %t';
         
        $list = DB::fetch_all($sql, array('forum_forum'));
    
        $list_formate = array();
        foreach($list as $value){
            $list_formate[$value['fid']] = $value['name'];
        }
    
        return $list_formate;
    }
    
    /**
     * 板块分类列表
     *
     * @access public
     * @param
     * @return array
     */
    public function forum_threadclass_list()
    {
        $sql = 'SELECT typeid,name FROM %t';
         
        $list = DB::fetch_all($sql, array('forum_threadclass'));
    
        $list_formate = array();
        foreach($list as $value){
            $list_formate[$value['typeid']] = $value['name'];
        }
    
        return $list_formate;
    }
    
    /**
     * 门户分类列表
     *
     * @access public
     * @param
     * @return array
     */
    public function portal_category_list()
    {
        $sql = 'SELECT catid,catname FROM %t';
         
        $list = DB::fetch_all($sql, array('portal_category'));
    
        $list_formate = array();
        foreach($list as $value){
            $list_formate[$value['catid']] = $value['catname'];
        }
    
        return $list_formate;
    }
    
    /**
     * 采集详情
     *
     * @access public
     * @param int
     * @return int
     */
    public function grab_detail($grab_id)
    {
        $sql = 'SELECT g.*,n.cookie FROM %t g
                LEFT JOIN %t n ON g.navid=n.id
                WHERE g.id=%d';
         
        return DB::fetch_first($sql, array($this->_table, 'plugin_'.PLUGIN_NAME.'_site_nav', $grab_id));
    }
    
    /**
     * 标题是否存在
     *
     * @access public
     * @param string
     * @return int
     */
    public function title_is_exist($send_type, $subject)
    {
        $subject = lib_base::escape($subject);
    
        if($send_type == 2){
            $sql = 'SELECT COUNT(*) FROM %t WHERE title=%s';
            return DB::result_first($sql, array('portal_article_title', $subject));
        }else{
            $sql = 'SELECT COUNT(*) FROM %t WHERE subject=%s';
            return DB::result_first($sql, array('forum_thread', $subject));
        }
    }
    
    /**
     * 帖子详情
     *
     * @access public
     * @param string
     * @return array
     */
    public function thread_detail_by_subject($subject)
    {
        $subject = lib_base::escape($subject);
    
        $sql = 'SELECT * FROM %t WHERE subject=%s';
            
        return DB::fetch_first($sql, array('forum_thread', $subject));
    }
    
    /**
     * 文章详情
     *
     * @access public
     * @param string
     * @return array
     */
    public function article_detail_by_subject($subject)
    {
        $subject = lib_base::escape($subject);
    
        $sql = 'SELECT * FROM %t WHERE title=%s';
    
        return DB::fetch_first($sql, array('portal_article_title', $subject));
    }
    
    /**
     * 用户信息
     *
     * @access public
     * @param string
     * @return int
     */
    public function user_info_by_username($username)
    {
        $sql = 'SELECT uid,username FROM %t WHERE username=%s';
         
        return DB::fetch_first($sql, array('common_member', $username));
    }
    
    /**
     * 用户注册
     *
     * @access public
     * @param string
     * @return array
     */
    public function user_register($username, & $grab)
    {
        global $_G;
        
        $ip = $this->get_rand_ip();
        $password = substr(md5($username.TIMESTAMP), 0, 10);
        $email = self::get_rand_email();
    
        loaducenter();
        uc_user_register('', '', '', '', '', '');
    
        $uid = $_ENV['user']->add_user($username, $password, $email, 0, '', '', $ip);
        if(! $uid){
            return FALSE;
        }
    
        //获取uc用户信息
        $uc_user = $_ENV['user']->get_user_by_uid($uid);
    
        $setting = $_G['setting'];
        $groupid = $setting['newusergroupid'];
        $password_md5 = md5(md5($password).$uc_user['salt']);
        $init_arr = array(
            'credits'=>explode(',', $setting['initcredits']),
            'emailstatus'=>1
        );
    
        C::t('common_member')->insert($uid, $username, $password_md5, $email, $ip, $groupid, $init_arr);
    
        require_once libfile('cache/userstats', 'function');
        build_cache_userstats();
    
        //更新自定义数据
        $urls = parse_url(trim($grab['source']));
        if($urls['host'])
        {
            $rule_file = DISCUZ_ROOT.'source/plugin/'.PLUGIN_NAME.'/rule/'.$urls['host'].'.php';
            if(file_exists($rule_file))
            {
                include $rule_file;
                if(isset($grab['rule']['func']['user_info_get']) && $grab['rule']['func']['user_info_get']){
                    if(function_exists($grab['rule']['func']['user_info_get'])){
                        $grab['uid'] = $uid;
                        $grab['username'] = $username;
                        $grab['rule']['func']['user_info_get']($grab);
                    }
                }
            }
        }
    
        return $uid;
    }
    
    public function get_rand_ip()
    {
        $ip_long = array(
            array('607649792', '608174079'), // 36.56.0.0-36.63.255.255
            array('1038614528', '1039007743'), // 61.232.0.0-61.237.255.255
            array('1783627776', '1784676351'), // 106.80.0.0-106.95.255.255
            array('2035023872', '2035154943'), // 121.76.0.0-121.77.255.255
            array('2078801920', '2079064063'), // 123.232.0.0-123.235.255.255
            array('-1950089216', '-1948778497'), // 139.196.0.0-139.215.255.255
            array('-1425539072', '-1425014785'), // 171.8.0.0-171.15.255.255
            array('-1236271104', '-1235419137'), // 182.80.0.0-182.92.255.255
            array('-770113536', '-768606209'), // 210.25.0.0-210.47.255.255
            array('-569376768', '-564133889'), // 222.16.0.0-222.95.255.255
        );
    
        $rand_key = mt_rand(0, 9);
    
        return $ip = long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
    }
    
    public function get_rand_email()
    {
        $email = array(
            'gmail.com',
            'yahoo.com',
            'msn.com',
            'hotmail.com',
            'ask.com',
            'live.com',
            'qq.com',
            '0355.net',
            '163.com',
            '163.net',
            '263.net',
            '3721.net',
            'yeah.net',
            'mail.com',
        );
    
        $rand_id = mt_rand(0, count($email) - 1);
        $email_postfix = $email[$rand_id];
        $email_prefix = $this->randomkeys(mt_rand(5, 10));
    
        return $email_prefix.'@'.$email_postfix;
    }
    
    public function randomkeys($length)
    {
        $returnStr = '';
        $pattern = '1234567890abcdefghijklmnopqrstuvwxyz';
         
        for($i = 0; $i < $length; $i ++){
            $returnStr .= $pattern {mt_rand (0, 35)};
        }
         
        return $returnStr;
    }
    
    /**
     * 采集本地是否存在
     *
     * @access public
     * @param string
     * @return int
     */
    public function grab_is_exist_by_identify($identify)
    {
        $sql = 'SELECT COUNT(*) FROM %t WHERE identify=%s';
    
        return DB::result_first($sql, array($this->_table, $identify));
    }
    
    /**
     * 获取本地数据
     *
     * @access public
     * @param int
     * @return array
     */
    public function grab_local_latest($limit = 1)
    {
        if(! $limit){
            return FALSE;
        }
    
        $sql = 'SELECT d.*,n.cookie FROM %t d
                LEFT JOIN %t n ON d.navid=n.id
                WHERE d.status=0 ORDER BY d.id DESC LIMIT %d';
    
        return DB::fetch_all($sql, array($this->_table, 'plugin_'.PLUGIN_NAME.'_site_nav', $limit));
    }
    
    public function removeDir($dirName, $root)
    {
        if(! is_dir($dirName)){
            return FALSE;
        }
    
        $time_week = (int)date('Ymd', strtotime('-7 day'));
    
        $handle = @opendir($dirName);
        while(($file = @readdir($handle)) !== FALSE)
        {
            if($file != '.' && $file != '..')
            {
                $dir = $dirName.'/'.$file;
                if(is_dir($dir)){
                    if($time_week > (int)$file){
                        $this->removeDir($dir, 0);
                    }
                }else{
                    @unlink($dir);
                }
            }
        }
    
        closedir($handle);
    
        if($root == 1){
            return TRUE;
        }else{
            rmdir($dirName);
        }
    }
}