<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_admin_nav Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_admin_nav
{
    protected static $table = 'admin_nav';
    
    protected static $limit = 10;
    protected static $limit_max = 900;
    
    public static function nav_list()
    {
        $escape['search'] = lib_base::escape($_GET['search']);
        $escape['field'] = lib_base::escape($_GET['field']);
    
        $page = $_GET['page'] ? intval($_GET['page']) : 1;
        $limit = $_GET['limit'] ? ($_GET['limit'] > self::$limit_max ? self::$limit_max : intval($_GET['limit'])) : self::$limit;
        $import = $_GET['import'];
        
        $fields = array('n.id'=>'ID','n.send_type'=>'&#25968;&#25454;&#31867;&#22411;','f.name'=>'&#29256;&#22359;&#21517;&#31216;','c.name AS typename'=>'&#29256;&#22359;&#20998;&#31867;','ca.catname'=>'&#38376;&#25143;&#26639;&#30446;','n.title'=>'&#37319;&#38598;&#20851;&#38190;&#35789;','n.source'=>'&#26469;&#28304;&#32593;&#22336;','n.crontime'=>'&#37319;&#38598;&#38388;&#38548;&#20998;&#38047;','n.grabtime'=>'&#19978;&#27425;&#37319;&#38598;&#26102;&#38388;','n.status'=>'&#26159;&#21542;&#33258;&#21160;&#37319;&#38598;');
        $tool = array(
            '<a class="layui-btn" onclick="Func.open({url:\''.lib_base::admin_url('nav_add').'\'})">&#28155;&#21152;</a>',
            '<a class="layui-btn" onclick="Func.post({url:\''.lib_base::admin_url('nav_del').'\'})">&#21024;&#38500;</a>',
            '<a class="layui-btn" onclick="Func.open({url:\''.lib_base::admin_url('nav_cookie').'\'})">cookie</a>',
        );
        $submit = lib_base::admin_url('nav_list').'&limit='.$limit;
    
        $fields_str = lib_func::field_str($fields);
        $offset = ($page - 1) * $limit;
    
        $where = '';
        if($escape['search'] && $escape['field'] && array_key_exists($escape['field'], $fields)){
            $where .= "WHERE ".$escape['field']." LIKE '%".$escape['search']."%'";
            $submit .= '&search='.$escape['search'].'&field='.$escape['field'];
        }
    
        $list = lib_base::table(self::$table)->nav_list($fields_str, $offset, $limit, $where);
        if(! $list && ! $import && ! $escape['search']){
            lib_base::header(lib_base::admin_url('nav_import'));
        }
        
        if($list){
            foreach($list as & $value){
                $value['source'] = '<a href="'.$value['source'].'" target="_blank">'.$value['source'].'</a>';
            }
        }
    
        $count = lib_base::table(self::$table)->nav_count($where);
        $page_count = ceil($count / $limit);
        $paging = lib_func::paging($page_count, $page, $submit.'&page=', $limit, $count);
        $search = lib_func::field_option(array('n.id'=>'ID','f.name'=>'&#29256;&#22359;&#21517;&#31216;','ca.catname'=>'&#38376;&#25143;&#26639;&#30446;','n.title'=>'&#37319;&#38598;&#20851;&#38190;&#35789;'), $escape['field']);
    
        $formate['op'] = array(
            array('url'=>lib_base::admin_url('nav_del'),'name'=>'&#21024;&#38500;',type=>3),
            array('url'=>lib_base::admin_url('nav_edit').'&nav_id=','name'=>'&#32534;&#36753;'),
            array('url'=>lib_base::url('grab_list').'&page=1&nav_id=','name'=>'&#26368;&#26032;&#37319;&#38598;',type=>1),
            array('url'=>lib_base::admin_url('nav_grab_page').'&nav_id=','name'=>'&#20998;&#39029;&#37319;&#38598;'),
        );
    
        $formate['batch'] = 1;
        $formate['time'] = array('grabtime');
        $formate['fi'] = array(
            'send_type'=>lib_base::table(self::$table)->send_type,
            'status'=>lib_base::table(self::$table)->status
        );
        
        $fields = lib_func::create_table($list, $fields, $formate);
    
        $admin_nav = 1;
        
        include lib_base::template('admin');
    }
    
    public static function nav_import()
    {
        $post = array(
            'identify'=>lib_base::$grab_identify
        );
        $result = lib_base::curl(lib_base::$grab_host.lib_base::$grab_api_rule, $post);

        $result = json_decode($result, TRUE);
        if(! isset($result['state']) || $result['state'] != 0){
            lib_base::back_url($result['result'], lib_base::admin_url('nav_list').'&import=1');
        }
        
        if(! $result['nav']){
            lib_base::back_url('&#26080;&#26597;&#35810;&#25968;&#25454;', lib_base::admin_url('nav_list').'&import=1');
        }
        
        //转码兼容
        if(CHARSET == 'gbk'){
            $result['nav'] = lib_base::convert_utf8_to_gbk($result['nav']);
        }
        
        if($result['nav'])
        {
            foreach($result['nav'] as $nav)
            {
                $detail = lib_base::table(self::$table)->fetch($nav['id']);
                if(! $detail)
                {
                    $add = array(
                        'id'=>$nav['id'],
                        'title'=>$nav['title'],
                        'ruleid'=>$nav['ruleid'],
                        'crontime'=>30,
                        'source'=>$nav['source'],
                        'cookie'=>$nav['cookie'],
                    );
                    lib_base::table(self::$table)->insert($add);
                }
                else
                {
                    $edit = array(
                        'source'=>$nav['source'],
                        'cookie'=>$nav['cookie'],
                    );
                    lib_base::table(self::$table)->update($nav['id'], $edit);
                }
            }
        }
        
        lib_base::back_url('&#25805;&#20316;&#25104;&#21151;', lib_base::admin_url('nav_list').'&import=1');
    }
    
    public static function threadclass_list()
    {
        $fid = intval($_GET['fid']);

        $list_formate = array(
            'type'=>array()
        );
        
        if(! $fid){
            lib_base::back_json($list_formate);
        }
        
        $forumfield = lib_base::table(self::$table)->forum_forumfield_detail($fid);

        if($forumfield['threadtypes'])
        {
            $threadtypes = unserialize($forumfield['threadtypes']);
            if(! $threadtypes['required'] && $threadtypes['types']){
                $list_formate['type'][0] = array(
                    'id'=>0,
                    'name'=>'&#36873;&#25321;&#20027;&#39064;&#20998;&#31867;',
                );
            }
            
            foreach($threadtypes['types'] as $key => $value){
                $list_formate['type'][] = array(
                    'id'=>$key,
                    'name'=>$value,
                );
            }
        }
        
        lib_base::back_json($list_formate);
    }
    
    public static function nav_add()
    {
        $submit  = lib_base::admin_url('nav_added');
        
        require_once libfile('function/forumlist');
        require_once libfile('function/portalcp');
        require_once libfile('function/group');

        $grouplist = grouplist('displayorder', array(), 100);
        $grouplist_option = '';
        if($grouplist){
            foreach($grouplist as $value){
                $grouplist_option .= '<option value="'.$value['fid'].'">'.$value['name'].'</option>';
            }
        }
        
        $groupselect = '<select lay-filter="group_id" name="group_id" id="group_id">'.$grouplist_option.'</select>';
        $forumselect = '<select lay-filter="fid" name="fid" id="fid"><option value="0">&#36873;&#25321;&#29256;&#22359;</option>'.forumselect().'</select>';
        $typeselect = '<select name="typeid" id="typeid"><option value="0">&#36873;&#25321;&#20027;&#39064;&#20998;&#31867;</option></select>';
        $portalselect = category_showselect('portal', 'portal_catid');
        $portalselect = str_replace('<select id="portal_catid"', '<select lay-filter="portal_catid" id="portal_catid"', $portalselect);

        $send_type_option = lib_func::select_option(lib_base::table(self::$table)->send_type);
        $send_typeselect = '<select lay-filter="send_type" name="send_type" id="send_type">'.$send_type_option.'</select>';
        
        $select_status = lib_func::select_option(lib_base::table(self::$table)->status);
        
        $formhash = FORMHASH;

        $content = <<<EOT
<div class="layui-card">
    <div class="layui-card-header">&#28155;&#21152;&#37319;&#38598;&#20851;&#38190;&#35789;</div>
    <div class="layui-card-body">
        
        <div class="layui-form-item">
            <label class="layui-form-label">&#37319;&#38598;&#21040;</label>
        	<div class="layui-input-block">
            	<div class="layui-inline">{$send_typeselect}</div>
            	<div class="layui-inline">{$portalselect}</div>
        		<div class="layui-inline">{$groupselect}</div>
            	<div class="layui-inline">{$forumselect}</div>
            	<div class="layui-inline" style="margin-left:-15px;"><input type="text" id="input_id" name="input_id" class="layui-input" style="width:50px;padding-left:5px;" placeholder="fid/aid"></div>
            	<div class="layui-inline">{$typeselect}</div>
        	</div>
        </div>
        
        <div class="layui-form-item">
            <label class="layui-form-label">&#37319;&#38598;&#20851;&#38190;&#35789;</label>
        	<div class="layui-input-block">
        	   <input type="text" name="title" lay-verify="required" class="layui-input" placeholder="&#36755;&#20837;&#24819;&#35201;&#37319;&#38598;&#30340;&#20851;&#38190;&#35789;&#21517;&#31216;" value="">
        	</div>
        </div>
        
        <div class="layui-form-item">
        <label class="layui-form-label">&#26469;&#28304;&#32593;&#22336;</label>
        	<div class="layui-input-block">
        	   <input type="text" name="source" class="layui-input" placeholder="&#36755;&#20837;&#37319;&#38598;&#30340;&#20851;&#38190;&#35789;&#117;&#114;&#108;&#22320;&#22336;" value="">
        	</div>
        </div>
        		    
        <div class="layui-form-item">
            <label class="layui-form-label">&#33258;&#21160;&#37319;&#38598;</label>
        	<div class="layui-input-block">
                <select name="status">{$select_status}</select>
        	</div>
        </div>
        		    
        <div class="layui-form-item">
        	<label class="layui-form-label">cookie</label>
        	<div class="layui-input-block">
                <textarea name="cookie" class="layui-input" style="height:150px;"></textarea>
        	</div>
        </div>
        
        <div class="layui-form-item layui-layout-admin">
            <div class="layui-input-block1">
                <div class="layui-footer" style="left:0;">
                    <button type="button" class="layui-btn" lay-submit onclick="Func.post({})">&#31435;&#21363;&#25552;&#20132;</button>
                    <button type="reset" class="layui-btn layui-btn-primary">&#37325;&#32622;</button>
                </div>
            </div>
        </div>
    </div>
</div>
<input type="hidden" name="formhash" value="{$formhash}"/>
EOT;
		$threadclass_list_url = lib_base::admin_url('threadclass_list');
        $hidden = <<<EOT
<script type="text/javascript">
layui.use(['form','jquery'],function(){
    form = layui.form,
    $ = layui.jquery;
	form.on('select(send_type)', function(data){
        send_type_show(data.value);
    });
	form.on('select(fid)', function(data){
        threadclass_list(data.value, 0);
        $('#input_id').val($('#fid').val());
    });
    form.on('select(portal_catid)', function(data){
        $('#input_id').val($('#portal_catid').val());
    });
    form.on('select(group_id)', function(data){
        $('#input_id').val($('#group_id').val());
    });
    
    $('#group_id').parent().hide();
    $('#portal_catid').parent().hide();
    $('#typeid').parent().hide();
});

function send_type_show(send_type){
    if(send_type == 1){
        $('#fid').parent().show();
        $('#group_id').parent().hide();
        $('#portal_catid').parent().hide();
        $('#fid').find('option:first').attr('selected', true);
        form.render();
        
        $('#input_id').val($('#fid').val());
    }else if(send_type == 2){
        $('#fid').parent().hide();
        $('#typeid').parent().hide();
        $('#group_id').parent().hide();
        $('#portal_catid').parent().show();
        
        $('#input_id').val($('#portal_catid').val());
    }else if(send_type == 3){
        $('#fid').parent().hide();
        $('#typeid').parent().hide();
        $('#group_id').parent().show();
        $('#portal_catid').parent().hide();
        
        $('#input_id').val($('#group_id').val());
    }
}
        
function threadclass_list(fid, typeid){
    $.ajax({
        data    : {fid:fid},
		dataType: 'html',
		type    : 'get',
		url     : '{$threadclass_list_url}',
		success : function(data){
		    data = Func.ajax_json(data);
		    
		    var html = '';
		    if(data.type.length > 0){
		        $('#typeid').parent().show();
    		    for(var i in data.type){
    		        var selected = typeid == data.type[i].id ? ' selected' : '';
                    html += '<option value="'+data.type[i].id+'"'+selected+'>'+data.type[i].name+'</option>';
                }
		    }else{
		        $('#typeid').parent().hide();
            }
		    $('#typeid').html(html);
		    
		    form.render();
        }
	});
}
</script>
EOT;
        
        include lib_base::template('admin');
    }
    
    public static function nav_added()
    {
        $send_type = intval($_GET['send_type']);
        $status = intval($_GET['status']);
        $fid = intval($_GET['fid']);
        $typeid = intval($_GET['typeid']);
        $group_id = intval($_GET['group_id']);
        $portal_catid = intval($_GET['portal_catid']);
        $title = $_GET['title'];
        $source = $_GET['source'];
        $cookie = $_GET['cookie'];
        $input_id = intval($_GET['input_id']);

        if(! $input_id && $send_type == 1 && ! $fid){
            lib_base::back_text('&#35831;&#36873;&#25321;&#35770;&#22363;&#29256;&#22359;');
        }
        if(! $input_id && $send_type == 2 && ! $portal_catid){
            lib_base::back_text('&#35831;&#36873;&#25321;&#38376;&#25143;&#20998;&#31867;');
        }
        if(! $input_id && $send_type == 3 && ! $group_id){
            lib_base::back_text('&#35831;&#36873;&#25321;&#32676;&#32452;&#29256;&#22359;');
        }
        
        $add = array(
            'send_type'=>$send_type,
            'title'=>$title,
            'source'=>$source,
            'cookie'=>$cookie,
            'status'=>$status,
            'crontime'=>30
        );

        if($send_type == 1){
            $add['fid'] = $input_id ? $input_id : $fid;
            $add['typeid'] = $typeid;
        }else if($send_type == 2){
            $add['cid'] = $input_id ? $input_id : $portal_catid;
        }else if($send_type == 3){
            $add['fid'] = $input_id ? $input_id : $group_id;
        }
        
        lib_base::table(self::$table)->insert($add);
    
        lib_base::back_json(array('callreload'=>1));
    }
    
    public static function nav_edit()
    {
        $nav_id = intval($_GET['nav_id']);
        
        $detail = lib_base::table(self::$table)->fetch($nav_id);
        
        $submit  = lib_base::admin_url('nav_edited');
        
        require_once libfile('function/forumlist');
        require_once libfile('function/portalcp');
        require_once libfile('function/group');
        
        $send_type = $detail['send_type'];
        $fid = $detail['fid'];
        $typeid = $detail['typeid'];
        $cid = $detail['cid'];

        $grouplist = grouplist('displayorder', array(), 100);
        $grouplist_option = '';
        if($grouplist){
            foreach($grouplist as $value){
                $selected = $fid == $value['fid'] ? ' selected' : '';
                $grouplist_option .= '<option value="'.$value['fid'].'"'.$selected.'>'.$value['name'].'</option>';
            }
        }
        
        $groupselect = '<select lay-filter="group_id" name="group_id" id="group_id">'.$grouplist_option.'</select>';
        $forumselect = '<select lay-filter="fid" name="fid" id="fid"><option value="0">&#36873;&#25321;&#29256;&#22359;</option>'.forumselect(FALSE, 0, $fid).'</select>';
        $typeselect = '<select name="typeid" id="typeid"><option value="0">&#36873;&#25321;&#20027;&#39064;&#20998;&#31867;</option></select>';
        $portalselect = category_showselect('portal', 'portal_catid', false, $detail['cid']);
        $portalselect = str_replace('<select id="portal_catid"', '<select lay-filter="portal_catid" id="portal_catid"', $portalselect);
        
        $send_type_option = lib_func::select_option(lib_base::table(self::$table)->send_type, $send_type);
        $send_typeselect = '<select lay-filter="send_type" name="send_type" id="send_type">'.$send_type_option.'</select>';
        
        $select_status = lib_func::select_option(lib_base::table(self::$table)->status, $detail['status']);

        $formhash = FORMHASH;
        
        $content = <<<EOT
<div class="layui-card">
    <div class="layui-card-header">&#35774;&#32622;&#37319;&#38598;</div>
    <div class="layui-card-body">
        
        <div class="layui-form-item">
            <label class="layui-form-label">&#37319;&#38598;&#21040;</label>
        	<div class="layui-input-block">
            	<div class="layui-inline">{$send_typeselect}</div>
            	<div class="layui-inline">{$portalselect}</div>
        		<div class="layui-inline">{$groupselect}</div>
            	<div class="layui-inline">{$forumselect}</div>
            	<div class="layui-inline" style="margin-left:-15px;"><input type="text" id="input_id" name="input_id" class="layui-input" style="width:50px;padding-left:5px;" placeholder="fid/aid"></div>
            	<div class="layui-inline">{$typeselect}</div>
        	</div>
        </div>
        
        <div class="layui-form-item">
            <label class="layui-form-label">&#37319;&#38598;&#20851;&#38190;&#35789;</label>
        	<div class="layui-input-block">
        	   <input type="text" name="title" lay-verify="required" class="layui-input" placeholder="&#36755;&#20837;&#24819;&#35201;&#37319;&#38598;&#30340;&#20851;&#38190;&#35789;&#21517;&#31216;" value="{$detail['title']}">
        	</div>
        </div>
        
        <div class="layui-form-item">
            <label class="layui-form-label">&#26469;&#28304;&#32593;&#22336;</label>
        	<div class="layui-input-block">
        	   <input type="text" name="source" class="layui-input" placeholder="&#36755;&#20837;&#37319;&#38598;&#30340;&#20851;&#38190;&#35789;&#117;&#114;&#108;&#22320;&#22336;" value="{$detail['source']}">
        	</div>
        </div>
        
        <div class="layui-form-item">
            <label class="layui-form-label">&#33258;&#21160;&#37319;&#38598;</label>
        	<div class="layui-input-block">
                <select name="status">{$select_status}</select>
        	</div>
        </div>
		
        <div class="layui-form-item">
        	<label class="layui-form-label">cookie</label>
        	<div class="layui-input-block">
                <textarea name="cookie" class="layui-input" style="height:150px;">{$detail['cookie']}</textarea>
        	</div>
        </div>
        
        <div class="layui-form-item layui-layout-admin">
            <div class="layui-input-block1">
                <div class="layui-footer" style="left:0;">
                    <button type="button" class="layui-btn" lay-submit onclick="Func.post({})">&#31435;&#21363;&#25552;&#20132;</button>
                    <button type="reset" class="layui-btn layui-btn-primary">&#37325;&#32622;</button>
                </div>
            </div>
        </div>
    </div>
</div>
<input type="hidden" name="nav_id" value="{$nav_id}"/>
<input type="hidden" name="formhash" value="{$formhash}"/>
EOT;
		$threadclass_list_url = lib_base::admin_url('threadclass_list');
        $hidden = <<<EOT
<script type="text/javascript">
var send_type = {$send_type};
var fid = {$fid};
var typeid = {$typeid};
layui.use(['form','jquery'],function(){
    form = layui.form,
    $ = layui.jquery;
	form.on('select(send_type)', function(data){
        send_type_show(data.value, 0);
    });

    form.on('select(fid)', function(data){
        threadclass_list(data.value, 0);
        $('#input_id').val($('#fid').val());
    });
    form.on('select(portal_catid)', function(data){
        $('#input_id').val($('#portal_catid').val());
    });
    form.on('select(group_id)', function(data){
        $('#input_id').val($('#group_id').val());
    });
    
    $('#group_id').parent().hide();
    $('#portal_catid').parent().hide();
    $('#typeid').parent().hide();
        
    if(send_type > 0){
        send_type_show(send_type, 1);
    }
    if(fid){
        threadclass_list(fid, typeid);
    }
});

function send_type_show(send_type, init){
    if(send_type == 1){
        $('#fid').parent().show();
        $('#group_id').parent().hide();
        $('#portal_catid').parent().hide();
        if(init == 0){
            $('#fid').find('option:first').attr('selected', true);
            form.render();
        }
        
        $('#input_id').val($('#fid').val());
    }else if(send_type == 2){
        $('#fid').parent().hide();
        $('#typeid').parent().hide();
        $('#group_id').parent().hide();
        $('#portal_catid').parent().show();
        
        $('#input_id').val($('#portal_catid').val());
    }else if(send_type == 3){
        $('#fid').parent().hide();
        $('#typeid').parent().hide();
        $('#group_id').parent().show();
        $('#portal_catid').parent().hide();
        
        $('#input_id').val($('#group_id').val());
    }
}
        
function threadclass_list(fid, typeid){
    $.ajax({
        data    : {fid:fid},
		dataType: 'html',
		type    : 'get',
		url     : '{$threadclass_list_url}',
		success : function(data){
		    data = Func.ajax_json(data);
		    
		    var html = '';
		    if(data.type.length > 0){
		        $('#typeid').parent().show();
    		    for(var i in data.type){
    		        var selected = typeid == data.type[i].id ? ' selected' : '';
                    html += '<option value="'+data.type[i].id+'"'+selected+'>'+data.type[i].name+'</option>';
                }
		    }else{
		        $('#typeid').parent().hide();
            }
		    $('#typeid').html(html);
		 
		    form.render();
        }
	});
}
</script>
EOT;
        
        include lib_base::template('admin');
    }
    
    public static function nav_edited()
    {
        $nav_id = intval($_GET['nav_id']);
        $send_type = intval($_GET['send_type']);
        $status = intval($_GET['status']);
        $fid = intval($_GET['fid']);
        $typeid = intval($_GET['typeid']);
        $group_id = intval($_GET['group_id']);
        $portal_catid = intval($_GET['portal_catid']);
        $title = $_GET['title'];
        $source = $_GET['source'];
        $cookie = $_GET['cookie'];
        $input_id = intval($_GET['input_id']);

        if(! $input_id && $send_type == 1 && ! $fid){
            lib_base::back_text('&#35831;&#36873;&#25321;&#35770;&#22363;&#29256;&#22359;');
        }
        if(! $input_id && $send_type == 2 && ! $portal_catid){
            lib_base::back_text('&#35831;&#36873;&#25321;&#38376;&#25143;&#20998;&#31867;');
        }
        if(! $input_id && $send_type == 3 && ! $group_id){
            lib_base::back_text('&#35831;&#36873;&#25321;&#32676;&#32452;&#29256;&#22359;');
        }
        
        $detail = lib_base::table(self::$table)->fetch($nav_id);
        
        $edit = array(
            'title'=>$title,
            'source'=>$source,
            'send_type'=>$send_type,
            'cid'=>0,
            'fid'=>0,
            'typeid'=>0,
            'cookie'=>$cookie,
            'status'=>$status
        );

        if($send_type == 1){
            $edit['fid'] = $input_id ? $input_id : $fid;
            $edit['typeid'] = $typeid;
        }else if($send_type == 2){
            $edit['cid'] = $input_id ? $input_id : $portal_catid;
        }else if($send_type == 3){
            $edit['fid'] = $input_id ? $input_id : $group_id;
        }
        
        lib_base::table(self::$table)->update($nav_id, $edit);
    
        lib_base::back_json(array('callreload'=>1));
    }
    
    public static function nav_del()
    {
        $id = $_GET['batch'] ? $_GET['batch'] : intval($_GET['ids']);
        
        if(! $id){
            lib_base::back_text('&#35831;&#36873;&#25321;&#25805;&#20316;&#25968;&#25454;');
        }
    
        lib_base::table(self::$table)->delete($id);
    
        lib_base::back_json(array('reload'=>1));
    }
    
    public static function nav_grab_page()
    {
        $nav_id = intval($_GET['nav_id']);
    
        $detail = lib_base::table(self::$table)->fetch($nav_id);
        
        $content = <<<EOT
<div class="layui-card">
    <div class="layui-card-header">&#20998;&#39029;&#37319;&#38598;</div>
    <div class="layui-card-body">
    
        <div class="layui-form-item">
            <label class="layui-form-label">&#37319;&#38598;&#39029;&#25968;</label>
        	<div class="layui-input-block">
        	   <input type="text" name="page" id="page" lay-verify="required" class="layui-input" value="" placeholder="&#36755;&#20837;&#38656;&#35201;&#37319;&#38598;&#20851;&#38190;&#35789;&#30340;&#39029;&#25968;&#65292;&#25903;&#25345;&#39029;&#25968;&#33539;&#22260;&#37319;&#38598;&#65292;&#20363;&#22914;&#49;&#48;&#65292;&#53;&#45;&#49;&#48;">
        	</div>
        </div>
    
        <div class="layui-form-item layui-layout-admin">
            <div class="layui-input-block">
                <div class="layui-footer" style="left:0;">
                    <a class="layui-btn" onclick="grab_page()">&#31435;&#21363;&#25552;&#20132;</a>
                    <button type="reset" class="layui-btn layui-btn-primary">&#37325;&#32622;</button>
                </div>
            </div>
        </div>
    
    </div>
</div>
EOT;
        $grab_page_url = lib_base::url('grab_list').'&nav_id='.$nav_id.'&page=';
        $hidden = <<<EOT
<script type="text/javascript"> 
function grab_page(){
    var page = $('#page').val();
    if(! page){
        layer.msg('&#35831;&#36755;&#20837;&#37319;&#38598;&#39029;&#25968;');
        return;
    }
    
    window.open('{$grab_page_url}'+page);
}
</script>
EOT;
    
        include lib_base::template('admin');
    }
    
    public static function nav_cookie()
    {
        $submit  = lib_base::admin_url('nav_cookied');
        $formhash = FORMHASH;
        
        $host = array();
        $nav_list = lib_base::table(self::$table)->nav_all_list();
        foreach($nav_list as $value){
            $url = parse_url($value['source']);
            if($url['host']){
                $host[$url['host']] = $url['host'];
            }
        }
        $host_option = lib_func::select_option($host);

        $content = <<<EOT
<div class="layui-card">
    <div class="layui-card-header">&#25209;&#37327;&#35774;&#32622;&#99;&#111;&#111;&#107;&#105;&#101;&#65306;&#36873;&#25321;&#104;&#111;&#115;&#116;&#65292;&#35774;&#32622;&#21253;&#21547;&#27492;&#104;&#111;&#115;&#116;&#30340;&#25152;&#26377;&#20851;&#38190;&#35789;&#20026;&#32479;&#19968;&#36890;&#29992;&#99;&#111;&#111;&#107;&#105;&#101;&#65292;&#29992;&#20110;&#37319;&#38598;&#38656;&#35201;&#29992;&#25143;&#30331;&#38470;&#35775;&#38382;&#30340;&#31449;&#28857;&#25968;&#25454;</div>
    <div class="layui-card-body">
    
        <div class="layui-form-item">
        	<label class="layui-form-label">host</label>
        	<div class="layui-input-block">
                <select name="host">{$host_option}</select>
        	</div>
        </div>
        
        <div class="layui-form-item" style="display:none1;">
        	<label class="layui-form-label">cookie</label>
        	<div class="layui-input-block">
                <textarea name="cookie" class="layui-input" lay-verify="required" style="height:150px;"></textarea>
        	</div>
        </div>
    
        <div class="layui-form-item layui-layout-admin">
            <div class="layui-input-block1">
                <div class="layui-footer" style="left:0;">
                    <button type="button" class="layui-btn" lay-submit onclick="Func.post({})">&#31435;&#21363;&#25552;&#20132;</button>
                    <button type="reset" class="layui-btn layui-btn-primary">&#37325;&#32622;</button>
                </div>
            </div>
        </div>
    </div>
</div>
<input type="hidden" name="formhash" value="{$formhash}"/>
EOT;
    
        include lib_base::template('admin');
    }
    
    public static function nav_cookied()
    {
        $escape['host'] = lib_base::escape($_GET['host']);

        $cookie = $_GET['cookie'];
    
        lib_base::table(self::$table)->cookie_all_update($escape['host'], $cookie);
    
        lib_base::back_json(array('callreload'=>1));
    }
}