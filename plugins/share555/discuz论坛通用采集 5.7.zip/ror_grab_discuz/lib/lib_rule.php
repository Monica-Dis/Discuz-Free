<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$rule = array(

    '0'=>array(
         
        'list_intercept_start'=>'id="normalthread_',
        'list_intercept_filter'=>array('<a href="javascript:;"','<em>\[<a(.*?)<\/a>\]<\/em>'),
        'list_intercept_end'=>'</table>',
        'list_list'=>'<th .*?>(.*?)<\/th>',
        'list_title'=>'<a href=".*?>(.*?)<\/a>',
        'list_source'=>'<a href="(.*?)"',
        	
        'con_intercept_start'=>'<div class="t_fsz">',
        'con_intercept_filter'=>array('<table cellspacing="0" cellpadding="0"><tr><td class="t_f".*?>','</td></tr></table>','<div class="modact">(.*?)<\/div>','<div class="locked">(.*?)<\/div>','smilieid="(.*?)"','<i class="pstatus">(.*?)<\/i>','<div class="attach_nopermission attach_tips">(.*?)<\/div>','<span class="atips_close"(.*?)<\/span>','<div class="ptg mbm mtn">(.*?)<\/div>','<em onclick="copycode(.*?)<\/em>','<form.*?id="vfastpostform".*?>(.*?)<\/form>','<div class="mag_viewthread">(.*?)<\/div>','<img src="static\/image.*?>','<div class="a_pr".*?>.*?<\/div>'),
        'con_intercept_end'=>'<div id="comment',
         
        'tags_intercept_start'=>'<div class="ptg mbm mtn">',
        'tags_intercept_filter'=>'',
        'tags_intercept_end'=>'</div>',
        'tags_list'=>'<a.*?>(.*?)<\/a>',
         
        'comment_intercept_start'=>'<div class="t_fsz">',
        'comment_intercept_filter'=>array('<table cellspacing="0" cellpadding="0"><tr><td class="t_f".*?>','</td></tr></table>','<div class="modact">(.*?)<\/div>','<div class="locked">(.*?)<\/div>','smilieid="(.*?)"','<i class="pstatus">(.*?)<\/i>','<div class="attach_nopermission attach_tips">(.*?)<\/div>','<span class="atips_close"(.*?)<\/span>','<em onclick="copycode(.*?)<\/em>','<div class="quote">(.*?)<\/div>','<div class="mag_viewthread">(.*?)<\/div>','<img src="static\/image.*?>','<div class="a_pr".*?>.*?<\/div>'),
        'comment_intercept_end'=>'<div class="pgs',
        'comment_list'=>'<div class="t_fsz">(.*?)<div id="comment',
        
        'comment_dateline'=>'<em id="authorposton(.*?)<\/em>',
        
        'author_list'=>'<div class="authi"><a.*?class="xw1".*?>(.*?)<\/a>',
         
        'page_intercept_start'=>'',
        'page_intercept_filter'=>'',
        'page_intercept_end'=>'',
        'page_list'=>'',
         
        'func'=>array(
            'list_deal'=>'list_deal_discuz',
            'detail_deal'=>'detail_deal_discuz',
            'comment_html_deal'=>'detail_deal_discuz',
            'page_deal'=>'page_deal_discuz',
        ),
    )
);

if(! function_exists('list_deal_discuz'))
{
    function list_deal_discuz(& $grab)
    {
        if(strpos($grab['source'][0], '&extra=') === FALSE){
            return FALSE;
        }
        
        foreach($grab['source'] as $key => $value){
            $grab['source'][$key] = substr($value, 0, strpos($value, '&extra='));
        }

        return TRUE;
    }
}

if(! function_exists('detail_deal_discuz'))
{
    function detail_deal_discuz(& $html)
    {
        if(strpos($html, '<ignore_js_op>') !== FALSE)
        {
            $pattern = '/<ignore_js_op>(.*?)<\/ignore_js_op>/is';
            preg_match_all($pattern, $html, $result);
            if(! $result[1]){
                return FALSE;
            }
             
            foreach($result[1] as $key => $value)
            {
                if(strpos($value, 'file=') !== FALSE  || strpos($value, 'zoomfile=') !== FALSE)
                {
            
                    $pattern = '/<img (.*?)>/is';
                    preg_match($pattern, $value, $temp);
                    if(strpos($value, '<p><strong>')){
                        $pattern = '/<p><strong>(.*?)<\/strong>/is';
                        preg_match($pattern, $value, $title);
                    }
                    if($temp[0]){
                        if($title[1]){
                            $temp[0] = str_replace('<img', '<img title="'.$title[1].'"', $temp[0]);
                        }
                        $html = str_replace($result[0][$key], $temp[0], $html);
                    }
                }
                else
                {
                    $pattern = '/<a (.*?)<\/a>/is';
                    preg_match($pattern, $value, $temp);
                    if($temp[0]){
                        $html = str_replace($result[0][$key], $temp[0], $html);
                    }
                }
            }
        }

        if(strpos($html, '<img') !== FALSE)
        {
            $pattern = '/<img(.*?)>/i';
            preg_match_all($pattern, $html, $result);
            if(! $result[0]){
                return FALSE;
            }
             
            $result[0] = array_unique($result[0]);
             
            foreach($result[0] as $value)
            {
                if(strpos($value, 'zoomfile=')){
                    $value_deal = $value;
                    $value_deal = str_replace('src=', 'src1=', $value_deal);
                    $value_deal = str_replace('zoomfile=', 'zoom=', $value_deal);
                    if(strpos($value_deal, 'file=')){
                        $value_deal = str_replace('file=', 'src=', $value_deal);
                    }else{
                        $value_deal = str_replace('zoom=', 'src=', $value_deal);
                    }
                    	
                    $html = str_replace($value, $value_deal, $html);
                }
                else if(strpos($value, 'file='))
                {
                    $value_deal = $value;
                    $value_deal = str_replace('src=', 'src1=', $value_deal);
                    $value_deal = str_replace('file=', 'src=', $value_deal);
    
                    $html = str_replace($value, $value_deal, $html);
                }
            }
        }
    
        return TRUE;
    }
}

if(! function_exists('page_deal_discuz'))
{
    function page_deal_discuz($page, $nav)
    {
        $url = $nav['source'];

        if($page == 1){
            return $url;
        }

        if(strpos($url, 'forumdisplay')){
            $url = $url.'&page='.$page;
        }else{
            $parse_url = parse_url($url);
            $url_arr = explode('-', $parse_url['path']);
            $url_str = $url_arr[0].'-'.$url_arr[1].'-'.$page.'.html';
            $url = str_replace($parse_url['path'], $url_str, $url);
        }

        return $url;
    }
}