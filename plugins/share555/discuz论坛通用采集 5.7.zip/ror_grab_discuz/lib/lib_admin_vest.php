<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_admin_vest Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_admin_vest
{
    protected static $table = 'admin_vest';
    
    protected static $limit = 10;
    protected static $limit_max = 900;
    
    public static function vest_list()
    {
        $escape['search'] = lib_base::escape($_GET['search']);
        $escape['field'] = lib_base::escape($_GET['field']);

        $page = $_GET['page'] ? intval($_GET['page']) : 1;
        $limit = $_GET['limit'] ? ($_GET['limit'] > self::$limit_max ? self::$limit_max : intval($_GET['limit'])) : self::$limit;
    
        $fields = array('v.id'=>'ID','v.uid'=>'&#29992;&#25143;&#117;&#105;&#100;','v.username'=>'&#29992;&#25143;&#21517;&#31216;','f.name'=>'&#29256;&#22359;&#21517;&#31216;');
        $tool = array(
            '<a class="layui-btn" onclick="Func.open({url:\''.lib_base::admin_url('vest_add').'\'})">&#28155;&#21152;</a>',
            '<a class="layui-btn" onclick="Func.post({url:\''.lib_base::admin_url('vest_del').'\'})">&#21024;&#38500;</a>',
            '<a class="layui-btn" onclick="Func.post({url:\''.lib_base::admin_url('vest_empty').'\',confirm:1})">&#28165;&#31354;</a>',
            '<a class="layui-btn" href="https://dism.taobao.com/?@ror_user_vest.plugin" target="_blank">&#39532;&#30002;&#24037;&#20855;</a>'
        );
        $submit = lib_base::admin_url('vest_list').'&limit='.$limit;
    
        $fields_str = lib_func::field_str($fields);
        $offset = ($page - 1) * $limit;
    
        $where = '';
        if($escape['search'] && $escape['field'] && array_key_exists($escape['field'], $fields)){
            $where .= "WHERE ".$escape['field']." = '".$escape['search']."'";
            $submit .= '&search='.$escape['search'].'&field='.$escape['field'];
        }
    
        $list = lib_base::table(self::$table)->vest_list($fields_str, $offset, $limit, $where);

        $count = lib_base::table(self::$table)->vest_count($where);
        $page_count = ceil($count / $limit);
        $paging = lib_func::paging($page_count, $page, $submit.'&page=', $limit, $count);
        $search = lib_func::field_option($fields, $escape['field']);
    
        $formate['op'] = array(
            array('url'=>lib_base::admin_url('vest_del'),'name'=>'&#21024;&#38500;',type=>3,'confirm'=>FALSE),
        );
    
        $formate['batch'] = 1;
        $fields = lib_func::create_table($list, $fields, $formate);
    
        $admin_nav = 1;
        
        include lib_base::template('admin');
    }
    
    public static function vest_add()
    {
        $submit  = lib_base::admin_url('vest_added');

        require_once libfile('function/forumlist');
        $forumselect = forumselect();

        $content = <<<EOT
<div class="layui-card">
    <div class="layui-card-header">&#28155;&#21152;&#39532;&#30002;</div>
    <div class="layui-card-body">
    
        <div class="layui-form-item">
            <label class="layui-form-label">&#36873;&#25321;&#29256;&#22359;</label>
        	<div class="layui-input-block">
        	    <select name="fid"><option value="0">&#36873;&#25321;&#29256;&#22359;</option>{$forumselect}</select>
        	    <span style="color:#FF5722;">&#29256;&#22359;&#20026;&#21487;&#36873;&#39033;&#65292;&#33509;&#36873;&#25321;&#29256;&#22359;&#65292;&#37319;&#38598;&#25968;&#25454;&#21457;&#24086;&#26102;&#30340;&#29992;&#25143;&#20250;&#20174;&#25351;&#23450;&#29256;&#22359;&#30340;&#39532;&#30002;&#117;&#105;&#100;&#37324;&#38543;&#26426;&#65292;&#20854;&#20013;&#38376;&#25143;&#21457;&#24067;&#25991;&#31456;&#21644;&#35770;&#22363;&#21457;&#24067;&#22238;&#22797;&#38656;&#35201;&#28155;&#21152;&#19981;&#36873;&#25321;&#29256;&#22359;&#30340;&#39532;&#30002;&#29992;&#25143;&#65292;&#33509;&#26410;&#21305;&#37197;&#21040;&#39532;&#30002;&#25968;&#25454;&#65292;&#37319;&#38598;&#25968;&#25454;&#21482;&#20250;&#20445;&#23384;&#21040;&#26412;&#22320;&#19981;&#20250;&#21457;&#24086;</span>
        	</div>
        </div>
        
        <div class="layui-form-item">
            <label class="layui-form-label">&#29992;&#25143;&#117;&#105;&#100;</label>
        	<div class="layui-input-block">
        	   <textarea name="uid" class="layui-textarea" lay-verify="required" placeholder="&#19968;&#34892;&#19968;&#26465;&#25968;&#25454;&#25110;&#32773;&#29992;&#33521;&#25991;&#36887;&#21495;&#25340;&#25509;" style="height:280px;"></textarea>
        	</div>
        </div>
      
        <div class="layui-form-item layui-layout-admin">
            <div class="layui-input-block1">
                <div class="layui-footer" style="left:0;">
                    <button type="button" class="layui-btn" lay-submit onclick="Func.post({})">&#31435;&#21363;&#25552;&#20132;</button>
                    <button type="reset" class="layui-btn layui-btn-primary">&#37325;&#32622;</button>
                </div>
            </div>
        </div>
        		    
    </div>
</div>
EOT;
        
        include lib_base::template('admin');
    }
    
    public static function vest_added()
    {
        $fid = intval($_GET['fid']);
        $uid = $_GET['uid'];

        if(! $uid){
            lib_base::back_text('&#32570;&#23569;&#21442;&#25968;&#65292;&#35831;&#37325;&#35797;');
        }
    
        if(strpos($uid, ',') !== FALSE){
            $uids = explode(',', $uid);
        }else{
            $uids = explode("\n", $uid);
        }
        
        foreach($uids as $value)
        {
            $uid = intval($value);
            
            $user = getuserbyuid($uid);
            
            if($user)
            {
                if(lib_base::table(self::$table)->vest_is_exist($uid, $fid)){
                    continue;
                }
                
                $add = array(
                    'uid'=>$user['uid'],
                    'username'=>$user['username'],
                    'fid'=>$fid
                );

                lib_base::table(self::$table)->insert($add);
            }
        }
    
        lib_base::back_json(array('callreload'=>1));
    }
    
    public static function vest_del()
    {
        $id = $_GET['batch'] ? $_GET['batch'] : intval($_GET['ids']);
    
        if(! $id){
            lib_base::back_text('&#35831;&#36873;&#25321;&#25805;&#20316;&#25968;&#25454;');
        }
    
        lib_base::table(self::$table)->delete($id);
    
        lib_base::back_json(array('reload'=>1));
    }
    
    public static function vest_empty()
    {
        lib_base::table(self::$table)->vest_empty();
    
        lib_base::back_json(array('reload'=>1));
    }
}