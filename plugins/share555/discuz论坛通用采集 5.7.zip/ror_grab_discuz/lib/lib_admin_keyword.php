<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_admin_keyword Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_admin_keyword
{
    protected static $table = 'admin_keyword';
    
    protected static $limit = 10;
    protected static $limit_max = 900;
    
    public static function keyword_list()
    {
        $escape['search'] = lib_base::escape($_GET['search']);
        $escape['field'] = lib_base::escape($_GET['field']);
    
        $page = $_GET['page']?intval($_GET['page']):1;
        $limit = $_GET['limit']?($_GET['limit'] > self::$limit_max ? self::$limit_max : intval($_GET['limit'])):self::$limit;
    
        $fields = array('id'=>'ID','word1'=>'&#21407;&#22987;&#35789;&#35821;','word2'=>'&#26367;&#25442;&#35789;&#35821;');
        $tool = array(
            '<a class="layui-btn" onclick="Func.open({url:\''.lib_base::admin_url('keyword_add').'\'})">&#28155;&#21152;</a>',
            '<a class="layui-btn" onclick="Func.post({url:\''.lib_base::admin_url('keyword_del').'\'})">&#21024;&#38500;</a>',
            '<a class="layui-btn" onclick="Func.ajax({url:\''.lib_base::admin_url('keyword_empty').'\',confirm:true})">&#28165;&#31354;</a>',
            '<a class="layui-btn" onclick="Func.open({url:\''.lib_base::admin_url('keyword_import').'\'})">&#23548;&#20837;&#21407;&#22987;&#35789;&#24211;</a>',
            '<a class="layui-btn" href="'.lib_base::admin_url('keyword_export').'" target="_blank">&#23548;&#20986;</a>'
        );
        $submit = lib_base::admin_url('keyword_list').'&limit='.$limit;;
    
        $fields_str = lib_func::field_str($fields);
        $offset = ($page - 1) * $limit;
    
        $where = '';
        if($escape['search'] && $escape['field'] && array_key_exists($escape['field'], $fields)){
            $where .= "WHERE ".$escape['field']." LIKE '%".$escape['search']."%'";
            $submit .= '&search='.$escape['search'].'&field='.$escape['field'];
        }

        $list = lib_base::table(self::$table)->keyword_list($fields_str, $offset, $limit, $where);
    
        $count = lib_base::table(self::$table)->keyword_count($where);
        $page_count = ceil($count / $limit);
        $paging = lib_func::paging($page_count, $page, $submit.'&page=', $limit, $count);
        $search = lib_func::field_option($fields, $escape['field']);
    
        $formate['op'] = array(
            array('url'=>lib_base::admin_url('keyword_del'),'name'=>'&#21024;&#38500;',type=>3,'confirm'=>FALSE),
        );
    
        $formate['batch'] = 1;
        $fields = lib_func::create_table($list, $fields, $formate);
    
        $admin_nav = 1;
        
        include lib_base::template('admin');
    }
    
    public static function keyword_add()
    {
        $submit  = lib_base::admin_url('keyword_added');

        $formhash = FORMHASH;

        $content = <<<EOT
<div class="layui-card">
    <div class="layui-card-header">&#28155;&#21152;&#20851;&#38190;&#35789;&#32452;</div>
    <div class="layui-card-body">
    
        <div class="layui-form-item">
        	<div class="layui-input-block1">
        	<textarea name="keyword" class="layui-textarea" lay-verify="required" placeholder="&#19968;&#34892;&#19968;&#26465;&#25968;&#25454;&#65292;&#26684;&#24335;&#65306;&#21407;&#22987;&#35789;&#35821;&#61;&#26367;&#25442;&#35789;&#35821;" style="height:410px;"></textarea>
        	</div>
        </div>
      
        <div class="layui-form-item layui-layout-admin">
            <div class="layui-input-block1">
                <div class="layui-footer" style="left:0;">
                    <button type="button" class="layui-btn" lay-submit onclick="Func.post({})">&#31435;&#21363;&#25552;&#20132;</button>
                    <button type="reset" class="layui-btn layui-btn-primary">&#37325;&#32622;</button>
                </div>
            </div>
        </div>
        		    
    </div>
</div>
<input type="hidden" name="formhash" value="{$formhash}"/>
EOT;
        
        include lib_base::template('admin');
    }
    
    public static function keyword_added()
    {
        $keyword = $_GET['keyword'];

        if(! $keyword){
            lib_base::back_text('&#32570;&#23569;&#21442;&#25968;&#65292;&#35831;&#37325;&#35797;');
        }

        $keywords = explode("\n", $keyword);

        foreach($keywords as $word)
        {
            list($word1, $word2) = explode('=', $word);
    
            if($word1 && $word2)
            {
                if(lib_base::table(self::$table)->keyword_is_exist($word1)){
                    continue;
                }
                
                $add = array(
                    'word1'=>$word1,
                    'word2'=>$word2
                );
                
                lib_base::table(self::$table)->insert($add);
            }
        }
    
        lib_base::back_json(array('callreload'=>1));
    }
    
    public static function keyword_del()
    {
        $id = $_GET['batch']?$_GET['batch']:intval($_GET['ids']);
    
        if(! $id){
            lib_base::back_text('&#35831;&#36873;&#25321;&#25805;&#20316;&#25968;&#25454;');
        }
    
        lib_base::table(self::$table)->delete($id);
    
        lib_base::back_json(array('reload'=>1));
    }
    
    public static function keyword_empty()
    {
        lib_base::table(self::$table)->keyword_empty();
    
        lib_base::back_json(array('reload'=>1));
    }
    
    public static function keyword_import()
    {
        $submit  = lib_base::admin_url('keyword_imported');
        
        $keyword_source = lib_base::$grab_host.'data/keyword.txt';
        
        $keyword_local = DISCUZ_ROOT.'data/plugindata/keyword.txt';
        
        file_put_contents($keyword_local, file_get_contents($keyword_source));

        $content = <<<EOT
<div class="layui-card">

    <div class="layui-card-body">
        <div class="layui-form-item1">
            <div class="layui-input-block1">
                <fieldset class="layui-elem-field layui-field-title site-title">
                    <legend><a name="quickstart">&#23548;&#20837;&#36827;&#24230;</a></legend>
                </fieldset>
                
                <div class="site-text site-block" style="height:435px;overflow:auto;"></div>
            </div>
        </div>
    </div>
    
</div>

<script type="text/javascript">
layui.use('jquery',function(){
    $ = layui.jquery;
    var line = 1;
    var offset = 0;
    function import_data()
    {
        $.ajax({
    		data    : {offset:offset},
    		dataType: 'html',
    		type    : 'get',
    		url     : '{$submit}',
    		success : function(data)
    		{
    		    data = Func.ajax_json(data);
    		
    			if(data.state != 0){
    			log('&#23548;&#20837;&#35789;&#24211;&#32467;&#26463;');
    		        layer.msg(data.result);
    		        return;
                }
    		    
    		    for(var i in data.list){
    		    var html = (data.list[i].type == 1?'<span style="color:#5FB878;">&#23548;&#20837;&#25104;&#21151;</span>':'<span style="color:#FF5722;">&#37325;&#22797;&#24573;&#30053;</span>')+':';
    		        html += data.list[i].word1+'='+data.list[i].word2;
                    log(html);
                }
    		    
    		    offset = data.offset;
    		    
    		    import_data();
    		}
    	});
    }

    function log(msg){
        var e = $('.site-text');
        e.prepend(msg+'<br/>').scrollTop(0);
        line++;
    } 
    log('&#23548;&#20837;&#35789;&#24211;&#24320;&#22987;');
    import_data();
});
</script>
EOT;
    
        include lib_base::template('admin');
    }
    
    public static function keyword_imported()
    {
        $offset = $_GET['offset']?intval($_GET['offset']):0;
        $limit = 200;
        $offset_count = $offset + $limit;
        
        $keyword_local = DISCUZ_ROOT.'data/plugindata/keyword.txt';
        
        $keyword = file_get_contents($keyword_local);
        if(! $keyword){
            lib_base::back_text('&#26080;&#26597;&#35810;&#25968;&#25454;');
        }
        
        $keywords = explode("\n", $keyword);
        
        if(! $keywords[$offset]){
            lib_base::back_text('&#23548;&#20837;&#35789;&#24211;&#32467;&#26463;');
        }
        
        $list = array();
        for($i = $offset; $i < $offset_count; $i++)
        {
            if(CHARSET == 'gbk'){
                $keywords[$i] = lib_base::string_utf8_to_gbk($keywords[$i]);
            }
            
            list($word1, $word2) = explode('=', $keywords[$i]);
            
            if($word1 && $word2)
            {
                if(lib_base::table(self::$table)->keyword_is_exist($word1)){
                    $list[] = array('word1'=>$word1,'word2'=>$word2,'type'=>2);
                    continue;
                }
            
                $add = array(
                    'word1'=>$word1,
                    'word2'=>$word2
                );
            
                lib_base::table(self::$table)->insert($add);
                
                $list[] = array('word1'=>$word1,'word2'=>$word2,'type'=>1);
            }
        }
        
        lib_base::back_json(array('offset'=>$offset_count,'list'=>$list));
    }
    
    public static function keyword_export()
    {
        $keyword_list = lib_base::table(self::$table)->keyword_all();

        $filename = 'keyword-'.date('Y-m-d-H-i-s', TIMESTAMP).'.txt';;

        Header("Content-type:application/octet-stream");
        Header("Accept-Ranges:bytes");
        header("Content-Disposition:attachment;filename=".$filename);
        header("Expires:0");
        header("Cache-Control:must-revalidate,post-check=0,pre-check=0");
        header("Pragma:public");
        
        foreach($keyword_list as $value)
        {
            if(CHARSET == 'gbk'){
                $value['word1'] = lib_base::string_gbk_to_utf8($value['word1']);
                $value['word2'] = lib_base::string_gbk_to_utf8($value['word2']);
            }
            
            echo $value['word1'].'='.$value['word2']."\r\n";
        }
    }
}