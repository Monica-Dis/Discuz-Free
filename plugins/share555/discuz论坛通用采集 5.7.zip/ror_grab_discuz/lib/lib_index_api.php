<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_index_api Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_index_api
{
    protected static $table = 'admin_grab';
    protected static $table_vest = 'admin_vest';
    
    protected static $auth_key = '537fc2e244053796aaeb13ad38b8test';

    //发布帖子
    public static function api_thread_add()
    {
        global $_G;
        
        $fid = intval($_GET['fid']);
        $typeid = intval($_GET['typeid']);
        $data = $_GET['data'] ? html_entity_decode($_GET['data']) : '';
        $time = $_GET['time'];
        $sign = $_GET['sign'];

        $mysign = md5($fid.$time.$typeid.self::$auth_key);
        
        if($sign != $mysign){
            lib_base::api_back('bad sign');
        }
        
        if(TIMESTAMP - $time > 300){
            lib_base::api_back('bad time');
        }
        
        $list = json_decode($data, TRUE);
        
        if(! $list){
            lib_base::api_back('bad data');
        }
        
        //转码
        if(CHARSET == 'gbk'){
            $list = lib_base::convert_utf8_to_gbk($list);
        }

        require_once libfile('function/forum');
        require_once libfile('function/post');
        require_once libfile('function/editor');
        if(! defined('DISCUZ_VERSION')) {
            require_once './source/discuz_version.php';
        }
        
        require_once libfile('lib/func_grab', 'plugin/'.PLUGIN_NAME);
        
        $settings = lib_base::settings();
        
        //马甲用户
        $vest_all = lib_base::table(self::$table_vest)->vest_list_all();
        if(! $vest_all){
            lib_base::api_back('bad vest');
        }
        $vest = array();
        foreach($vest_all as $value){
            $vest[$value['fid']][] = array(
                'uid'=>$value['uid'],
                'username'=>$value['username']
            );
        }

        $local_list = array();
        foreach($list as $value)
        {
            $comment = array(
                'list'=>array(),
                'dateline'=>array(),
                'author'=>array(),
            );
            
            if($value['authorid']){
                $user = getuserbyuid($value['authorid']);
                if($user){
                    $value['author'] = $user['username'];
                }
            }
            
            $comment['list'][0] = '';
            $comment['author'][0] = $value['author'];
            $comment['dateline'][0] = $value['dateline'];
            
            if($value['post'])
            {
                foreach($value['post'] as $val)
                {
                    if($val['authorid']){
                        $user = getuserbyuid($val['authorid']);
                        if($user){
                            $val['author'] = $user['username'];
                        }
                    }
                    
                    $comment['list'][] = $val['message'];
                    $comment['author'][] = $val['author'];
                    $comment['dateline'][] = $val['dateline'];
                }
            }

            $local_list[] = array(
                'id'=>0,
                'navid'=>0,
                'send_type'=>1,
                'fid'=>$fid,
                'tid'=>$value['tid'] ? $value['tid'] : 0,
                'typeid'=>$typeid,
                'title'=>$value['subject'],
                'content'=>$value['message'],
                'source'=>$value['source'] ? $value['source'] : '',
                'comment'=>serialize($comment),
                'identify'=>$value['source'] ? lib_func_grab::save_identify($value['source']) : '',
                'cookie'=>'',
            );
        }
        
        $tids = array();
        foreach($local_list as $key => $value)
        {
            $tids[$key] = 0;
            
            //标题检测
            if($settings['title_is_exist'] && lib_base::table('admin_grab')->title_is_exist($value['send_type'], $value['title'])){
                continue;
            }
            
            //来源检测
            if($value['identify'] && lib_base::table('admin_grab')->grab_is_exist_by_identify($value['identify'])){
                continue;
            }
            
            $fid = $value['fid'];
            $vest_list = $vest[$fid] ? $vest[$fid] : $vest[0];
            if(! $vest_list){
                continue;
            }
            
            $tid = lib_base::table(self::$table)->grab_to_thread($value, $vest_list, $settings, $vest[0]);
            
            $tids[$key] = intval($tid);
        }
        
        lib_base::api_back('success', $tids);
    }
    
    //发布帖子回复
    public static function api_post_add()
    {
        global $_G;
    
        $data = $_GET['data'] ? html_entity_decode($_GET['data']) : '';
        $time = $_GET['time'];
        $sign = $_GET['sign'];
    
        $mysign = md5($time.self::$auth_key);
    
        if($sign != $mysign){
            lib_base::api_back('bad sign');
        }
    
        if(TIMESTAMP - $time > 300){
            lib_base::api_back('bad time');
        }
    
        $list = json_decode($data, TRUE);
    
        if(! $list){
            lib_base::api_back('bad data');
        }
    
        //转码
        if(CHARSET == 'gbk'){
            $list = lib_base::convert_utf8_to_gbk($list);
        }
    
        require_once libfile('function/forum');
        require_once libfile('function/post');
        require_once libfile('function/editor');
        if(! defined('DISCUZ_VERSION')) {
            require_once './source/discuz_version.php';
        }
    
        $settings = lib_base::settings();
    
        //马甲用户
        $vest_all = lib_base::table(self::$table_vest)->vest_list_all();
        if(! $vest_all){
            lib_base::api_back('bad vest');
        }
        $vest = array();
        foreach($vest_all as $value){
            $vest[$value['fid']][] = array(
                'uid'=>$value['uid'],
                'username'=>$value['username']
            );
        }
    
        foreach($list as $value)
        {
            $comment = array(
                'list'=>array(),
                'dateline'=>array(),
                'author'=>array(),
            );
            
            //帖子查询
            $thread = array();
            if($value['tid']){
                $thread = C::t('forum_thread')->fetch($value['tid']);
            }else if($value['subject']){
                $thread = lib_base::table(self::$table)->thread_detail_by_subject($value['subject']);
            }
            
            if(! $thread || $value['post']){
                continue;
            }

            foreach($value['post'] as $val)
            {
                if($val['authorid']){
                    $user = getuserbyuid($val['authorid']);
                    if($user){
                        $val['author'] = $user['username'];
                    }
                }
            
                $comment['list'][] = $val['message'];
                $comment['author'][] = $val['author'];
                $comment['dateline'][] = $val['dateline'];
            }
            
            $vest_post = $vest[$thread['fid']] ? $vest[$thread['fid']] : $vest[0];
            
            $grab = array(
                'send_type'=>1,
                'comment'=>serialize($comment),
            );
            
            if($comment['list'] && $vest_post)
            {
                $_G['forum'] = C::t('forum_forum')->fetch($thread['fid']);
                $result = lib_base::table(self::$table)->grab_to_post($grab, $vest_post, $settings, $_G['forum'], $thread['tid'], $thread['dateline']);
                if($result){
                    $replies = C::t('forum_post')->count_visiblepost_by_tid($thread['tid']);
                    $replies = intval($replies) - 1;
                    $lastpostArr['replies'] = $replies;
                    $lastpostArr['maxposition'] = $replies + 1;
                    DB::update('forum_thread', $lastpostArr, 'tid='.$thread['tid']);
                }
            }
        }
        
        lib_base::api_back('success');
    }
    
    //发布文章
    public static function api_article_add()
    {
        global $_G;
    
        $cid = intval($_GET['catid']);
        $data = $_GET['data'] ? html_entity_decode($_GET['data']) : '';
        $time = $_GET['time'];
        $sign = $_GET['sign'];
    
        $mysign = md5($cid.$time.self::$auth_key);
    
        if($sign != $mysign){
            lib_base::api_back('bad sign');
        }
    
        if(TIMESTAMP - $time > 300){
            lib_base::api_back('bad time');
        }
    
        $list = json_decode($data, TRUE);
    
        if(! $list){
            lib_base::api_back('bad data');
        }
    
        //转码
        if(CHARSET == 'gbk'){
            $list = lib_base::convert_utf8_to_gbk($list);
        }
    
        require_once libfile('function/forum');
        require_once libfile('function/post');
        require_once libfile('function/editor');
        if(! defined('DISCUZ_VERSION')) {
            require_once './source/discuz_version.php';
        }
        
        require_once libfile('lib/func_grab', 'plugin/'.PLUGIN_NAME);
    
        $settings = lib_base::settings();
    
        //马甲用户
        $vest_all = lib_base::table(self::$table_vest)->vest_list_all();
        if(! $vest_all){
            lib_base::api_back('bad vest');
        }
        $vest = array();
        foreach($vest_all as $value){
            $vest[$value['fid']][] = array(
                'uid'=>$value['uid'],
                'username'=>$value['username']
            );
        }
    
        $local_list = array();
        foreach($list as $value)
        {
            $comment = array(
                'list'=>array(),
                'dateline'=>array(),
                'author'=>array(),
            );
    
            $comment['list'][0] = '';
            $comment['author'][0] = $value['author'];
            $comment['dateline'][0] = $value['dateline'];
    
            if($value['post']){
                foreach($value['post'] as $val){
                    $comment['list'][] = $val['message'];
                    $comment['author'][] = $val['author'];
                    $comment['dateline'][] = $val['dateline'];
                }
            }
    
            $local_list[] = array(
                'id'=>0,
                'navid'=>0,
                'send_type'=>2,
                'cid'=>$cid,
                'fid'=>0,
                'typeid'=>0,
                'title'=>$value['subject'],
                'content'=>$value['message'],
                'source'=>$value['source'] ? $value['source'] : '',
                'comment'=>serialize($comment),
                'identify'=>$value['source'] ? lib_func_grab::save_identify($value['source']) : '',
                'cookie'=>'',
            );
        }

        $aids = array();
        foreach($local_list as $key => $value)
        {
            $aids[$key] = 0;
            
            //标题检测
            if($settings['title_is_exist'] && lib_base::table('admin_grab')->title_is_exist($value['send_type'], $value['title'])){
                continue;
            }
    
            //来源检测
            if($value['identify'] && lib_base::table('admin_grab')->grab_is_exist_by_identify($value['identify'])){
                continue;
            }
            
            $vest_list = $vest[0];
            if(! $vest_list){
                continue;
            }
            
            $aid = lib_base::table(self::$table)->grab_to_portal($value, $vest_list, $settings, $vest[0]);
            
            $aids[$key] = intval($aid);
        }
    
        lib_base::api_back('success', $aids);
    }
    
    //发布文章评论
    public static function api_comment_add()
    {
        global $_G;
    
        $data = $_GET['data'] ? html_entity_decode($_GET['data']) : '';
        $time = $_GET['time'];
        $sign = $_GET['sign'];
    
        $mysign = md5($time.self::$auth_key);
    
        if($sign != $mysign){
            lib_base::api_back('bad sign');
        }
    
        if(TIMESTAMP - $time > 300){
            lib_base::api_back('bad time');
        }
    
        $list = json_decode($data, TRUE);
    
        if(! $list){
            lib_base::api_back('bad data');
        }
    
        //转码
        if(CHARSET == 'gbk'){
            $list = lib_base::convert_utf8_to_gbk($list);
        }
    
        require_once libfile('function/forum');
        require_once libfile('function/post');
        require_once libfile('function/editor');
        if(! defined('DISCUZ_VERSION')) {
            require_once './source/discuz_version.php';
        }
    
        $settings = lib_base::settings();
    
        //马甲用户
        $vest_all = lib_base::table(self::$table_vest)->vest_list_all();
        if(! $vest_all){
            lib_base::api_back('bad vest');
        }
        $vest = array();
        foreach($vest_all as $value){
            $vest[$value['fid']][] = array(
                'uid'=>$value['uid'],
                'username'=>$value['username']
            );
        }
    
        foreach($list as $value)
        {
            $comment = array(
                'list'=>array(),
                'dateline'=>array(),
                'author'=>array(),
            );
    
            //文章查询
            $article = array();
            if($value['aid']){
                $article = C::t('portal_article_title')->fetch($value['aid']);
            }else if($value['subject']){
                $article = lib_base::table(self::$table)->article_detail_by_subject($value['subject']);
            }
    
            if(! $article || $value['post']){
                continue;
            }
    
            foreach($value['post'] as $val)
            {
                if($val['authorid']){
                    $user = getuserbyuid($val['authorid']);
                    if($user){
                        $val['author'] = $user['username'];
                    }
                }
    
                $comment['list'][] = $val['message'];
                $comment['author'][] = $val['author'];
                $comment['dateline'][] = $val['dateline'];
            }
    
            $vest_post = $vest[0];
    
            $grab = array(
                'comment'=>serialize($comment),
            );
    
            //评论发回复
            if($comment['list'] && $vest_post){
                lib_base::table(self::$table)->grab_to_portal_comment($grab, $vest_post, $article['aid'], $settings, $article['dateline']);
            }
        }
    
        lib_base::api_back('success');
    }
    
    //发布文章评论
    public static function api_thread_like()
    {
        global $_G;
    
        $tid = intval($_GET['tid']);
        $uid = intval($_GET['uid']);
        $time = $_GET['time'];
        $sign = $_GET['sign'];
    
        $mysign = md5($tid.$time.$uid.self::$auth_key);
    
        if($sign != $mysign){
            lib_base::api_back('bad sign');
        }
    
        if(TIMESTAMP - $time > 300){
            lib_base::api_back('bad time');
        }
    
        if(! $tid || ! $uid){
            lib_base::api_back('bad param');
        }
        
        $_G['uid'] = $uid;
        
//         if(!$_G['setting']['recommendthread']['status'] || !$_G['group']['allowrecommend']) {
//             showmessage('no_privilege_recommend');
//         }

        //加载版块数据
        require_once libfile('function/forum');
        loadforum();
        $thread = $_G['thread'];
        if(! $thread['tid']){
            lib_base::api_back('bad tid');
        }

        if(C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($uid, $tid)) {
            lib_base::api_back('tid like repeat');
        }
        
//         $recommendcount = C::t('forum_memberrecommend')->count_by_recommenduid_dateline($uid, TIMESTAMP-86400);
//         if($_G['setting']['recommendthread']['daycount'] && $recommendcount >= $_G['setting']['recommendthread']['daycount']) {
//             showmessage('recommend_outoftimes', '', array('recommendc' => $thread['recommends']), array('msgtype' => 3));
//         }
        
        //$_G['group']['allowrecommend'] = intval($_GET['do'] == 'add' ? $_G['group']['allowrecommend'] : -$_G['group']['allowrecommend']);
        $fieldarr = array();
        $fieldarr['recommend_add'] = 1;
        update_threadpartake($tid);
        $fieldarr['heats'] = 0;
        $fieldarr['recommends'] = 1;
        C::t('forum_thread')->increase($tid, $fieldarr);
        
        if(empty($thread['closed'])) {
            C::t('forum_thread')->update($tid, array('lastpost'=>TIMESTAMP));
        }
        C::t('forum_memberrecommend')->insert(array('tid'=>$tid, 'recommenduid'=>$uid, 'dateline'=>TIMESTAMP));

        lib_base::api_back('success');
    }
}