<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_base Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_base 
{    
    public static $grab_host = 'http://share555.com/';
    public static $grab_identify = 'discuz';
    public static $grab_charset = '';
    public static $grab_api_rule = 'api/grab/rule';
    public static $encode_list = array('UTF-8','GBK','GB2312','BIG5','ASCII','EUC-JP','Shift_JIS','CP936','ISO-8859-1','JIS','eucjp-win','sjis-win');

    public static $error_code = array(
        'success'=>array('code'=>'0','msg'=>'success'),
    
        'fail'=>array('code'=>'1000','msg'=>'fail'),
        'noparam'=>array('code'=>'1001','msg'=>'noparam'),
        'notoken'=>array('code'=>'1002','msg'=>'notoken'),
        'nologin'=>array('code'=>'1003','msg'=>'nologin'),
        'nodata'=>array('code'=>'1004','msg'=>'nodata'),
        'nosave'=>array('code'=>'1005','msg'=>'nosave'),
        'noupdate'=>array('code'=>'1006','msg'=>'noupdate'),
        'noaction'=>array('code'=>'1007','msg'=>'noaction'),
        'nonetwork'=>array('code'=>'1008','msg'=>'nonetwork'),
    );
    
    public static function lang($lang)
    {
        return lang('plugin/'.PLUGIN_NAME, $lang);
    }

    public static function lang_message($lang, $onlyString = true)
    {
        return $onlyString ? PLUGIN_NAME.':'.$lang : self::lang($lang);
    }

    public static function table($name)
    {
        return C::t('#'.PLUGIN_NAME.'#'.$name);
    }

    public static function template($name)
    {
        return template(PLUGIN_NAME.':'.$name);
    }

    public static function settings($settingKey = null)
    {
        static $settings = array();
        
        if (! $settings) {
            global $_G;

            loadcache('plugin');
            $settings = $_G['cache']['plugin'][PLUGIN_NAME];
        }

        if ($settingKey !== null) {
            return isset($settings[$settingKey]) ? $settings[$settingKey] : null;
        }

        return $settings;
    }
    
    /**
     * text message,$num = 0,1 1error 0right
     *
     * @access public
     * @param string, int
     * @return json
     */
    public static function back_text($text, $num = 1)
    {
        //header('Content-Type:application/json; charset=utf-8');
        
        $data['state'] = $num;
        $data['result'] = $text;
        
        if(CHARSET == 'gbk'){
            $data = self::url_encode($data);
            echo urldecode(json_encode($data));
        }else{
            echo json_encode($data);
        }
        
        exit;
    }
    
    /**
     * json message,$num = 0,1 1error 0right
     *
     * @access public
     * @param array, int
     * @return json
     */
    public static function back_json($data, $num = 0)
    {
        //header('Content-Type:application/json; charset=utf-8');
        
        $data['state'] = $num;
        
        if(CHARSET == 'gbk'){
            $data = self::url_encode($data);
            echo urldecode(json_encode($data));
        }else{
            echo json_encode($data);
        }
        
        exit;
    }
    
    public static function url_encode($arr)
    {
        foreach($arr as $k=>$v){
            if(is_array($v)){
                $arr[$k] = self::url_encode($v);
            }else{
                $arr[$k] = urlencode($v);
            }
        }
    
        return $arr;
    }
    
    /**
     * array message
     *
     * @access public
     * @param string, int
     * @return json
     */
    public static function back_array($text, $num = 1)
    {
        $data['state'] = $num;
        if(is_array($text)){
            $data = array_merge($data, $text);
        }else{
            $data['result'] = $text;
        }
    
        return $data;
    }
    
    /**
     * string message
     *
     * @access public
     * @param string
     * @return string
     */
    public static function back_echo($text)
    {
        header('Content-type: text/html; charset='.CHARSET);
        echo $text;
        exit;
    }
    
    /**
     * 返回TEXT字符串信息
     *
     * @access public
     * @param string
     * @return string
     */
    public static function api_back($key, $data = array())
    {
        //header('Content-Type:application/json; charset=utf-8');
    
        $error = isset(self::$error_code[$key]) ? self::$error_code[$key] : array();
    
        $result = array('code'=>1000,'msg'=>'server error');
        if($error){
            $result['code'] = $error['code'];
            $result['msg'] = $error['msg'];
            if($data){
                $result['result'] = $data;
            }
        }else{
            $result['msg'] = $key;
        }
    
        if(isset($_GET['callback'])){
            $callback = $_GET['callback'];
            echo $callback.'('.json_encode($result).')';
        }else{
            echo json_encode($result);
        }
    
        exit;
    }
    
    /**
     * 输出html
     *
     * @access private
     * @param string, int
     * @return
     */
    public static function back_html($content, $type = 0)
    {
        $color = array(0=>'#009688', 1=>'#FF5722', 2=>'#FFB800');
    
        $type = isset($color[$type])?$type:0;
    
        echo '<p style="color:'.$color[$type].';">'.$content.'</p>';
    }
    
    /**
     * js back href
     *
     * @access public
     * @param string, string, int
     * @return
     */
    public static function back_url($message, $url, $delay = 3)
    {
        self::js_back_template($message.'<script type="text/javascript">setTimeout("window.location.href=\"'.$url.'\";", '.($delay*1000).');</script>');
    }
    
    /**
     * js back parent window
     *
     * @access public
     * @param string, int, string
     * @return
     */
    public static function js_back_window($message, $delay = 3)
    {
        self::js_back_template($message.'<script type="text/javascript">setTimeout("window.parent.location.reload();", '.($delay*1000).');</script>');
    }
    
    /**
     * js back parent href
     *
     * @access public
     * @param string, string, int, string
     * @return
     */
    public static function js_back_url($message, $url, $delay = 3)
    {
        self::js_back_template($message.'<script type="text/javascript">setTimeout("window.parent.location.href=\"'.$url.'\";", '.($delay*1000).');</script>');
    }
    
    /**
     * js back page
     *
     * @access public
     * @param string, int, string
     * @return
     */
    public static function js_back_page($message, $delay = 3)
    {
        self::js_back_template($message.'<script type="text/javascript">setTimeout("history.back();", '.($delay*1000).');</script>');
    }
    
    /**
     * js back close
     *
     * @access public
     * @param string, int, string
     * @return
     */
    public static function js_back_close($message, $delay = 3)
    {
        self::js_back_template($message.'<script type="text/javascript">setTimeout("window.parent.easyDialog.close();", '.($delay*1000).');</script>');
    }
    
    /**
     * show message
     *
     * @access public
     * @param string, int, string
     * @return
     */
    public static function js_back_show($message = '')
    {
        self::js_back_template($message);
    }
    
    /**
     * message template
     *
     * @access public
     * @param int, string
     * @return
     */
    public static function js_back_template($message)
    {
        include lib_base::template('notice');
        
        exit;
    }
    
     /**
     * url
     *
     * @access public
     * @param string
     * @return string
     */
    public static function url($act)
    {
        return 'plugin.php?id='.PLUGIN_NAME.'&act='.$act;
    }
    
    /**
     * admin url
     *
     * @access public
     * @param string
     * @return string
     */
    public static function admin_url($act)
    {
        //do=1
        return ADMINSCRIPT.'?frame=no&action=plugins&operation=config&identifier='.PLUGIN_NAME.'&pmod=admin&act='.$act.'&myformhash='.FORMHASH;
    }
    
    /**
     * header url
     *
     * @access public
     * @param string
     * @return string
     */
    public static function header($url)
    {
        header('location:'.$url);
        exit;
    }
    
    /**
     * 转义处理
     *
     * @access public
     * @param string
     * @return string
     */
    public static function escape($string)
    {
        if(! $string){
            return '';
        }
        
        $string = addslashes($string);
    
        return $string;
    }
    
    /**
     * 编码转换
     *
     * @access public
     * @param string
     * @return string
     */
    public static function convert_utf8_to_gbk($arr)
    {
        foreach($arr as $k => $v){
            if(is_array($v)){
                $arr[$k] = self::convert_utf8_to_gbk($v);
            }else{
                //$arr[$k] = iconv('UTF-8', 'GBK//IGNORE', $v);
                $arr[$k] = diconv($v, 'UTF-8', 'GBK');
            }
        }
        
        return $arr;
    }
    
    /**
     * 编码转换
     *
     * @access public
     * @param string
     * @return string
     */
    public static function convert_gbk_to_utf8($arr)
    {
        foreach($arr as $k => $v){
            if(is_array($v)){
                $arr[$k] = self::convert_gbk_to_utf8($v);
            }else{
                //$arr[$k] = iconv('GBK', 'UTF-8//IGNORE', $v);
                $arr[$k] = diconv($v, 'GBK', 'UTF-8');
            }
        }
        
        return $arr;
    }
    
    /**
     * 编码转换
     *
     * @access public
     * @param string
     * @return string
     */
    public static function string_utf8_to_gbk($string)
    {
        //$string = iconv('UTF-8', 'GBK//IGNORE', $string);
        $string = diconv($string, 'UTF-8', 'GBK');
        
        return $string;
    }
    
    /**
     * 编码转换
     *
     * @access public
     * @param string
     * @return string
     */
    public static function string_gbk_to_utf8($string)
    {
        //$string = iconv('GBK', 'UTF-8//IGNORE', $string);
        $string = diconv($string, 'GBK', 'UTF-8');
        
        return $string;
    }
    
    /**
     * 请求
     *
     * @access public
     * @param string
     * @return
     */
    public static function curl($url, $post = '')
    {
        $header = array(
            'User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9) Gecko/2008052906 Firefox/3.0'
        );
         
        $ch = curl_init();
         
        curl_setopt($ch,CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
         
        if(strpos($url, 'https') !== FALSE){
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        }
         
        if($post){
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
         
        $data = curl_exec($ch);
        $error = curl_errno($ch);
        curl_close($ch);
    
        if($error != 0){
            return '';
        }
    
        return $data;
    }
}