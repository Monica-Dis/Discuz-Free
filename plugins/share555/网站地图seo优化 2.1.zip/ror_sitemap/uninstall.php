<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access denied');
}

$plugin_name = 'ror_sitemap';

$sql = <<<EOT

DROP TABLE IF EXISTS pre_plugin_{$plugin_name};
DROP TABLE IF EXISTS pre_plugin_{$plugin_name}_thread_push;
DROP TABLE IF EXISTS pre_plugin_{$plugin_name}_portal_push;

EOT;

runquery($sql);

//删除多余缓存
$local_path_grab = DISCUZ_ROOT.'data/plugindata/'.$plugin_name.'/';
removeDir($local_path_grab);
function removeDir($dirName)
{
    if(! is_dir($dirName)){
        return FALSE;
    }
    
    $handle = @opendir($dirName);
    while(($file = @readdir($handle)) !== FALSE)
    {
        if($file != '.' && $file != '..'){
            $dir = $dirName.'/'.$file;
            if(is_dir($dir)){
                removeDir($dir);
            }else{
                @unlink($dir);
            }
        }
    }
    
    closedir($handle);

    rmdir($dirName);
}

$finish = true;