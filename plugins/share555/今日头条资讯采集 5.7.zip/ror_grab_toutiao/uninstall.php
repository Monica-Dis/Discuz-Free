<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access denied');
}

$plugin_name = 'ror_grab_toutiao';

$sql = <<<EOT

DROP TABLE IF EXISTS pre_plugin_{$plugin_name};
DROP TABLE IF EXISTS pre_plugin_{$plugin_name}_local;
DROP TABLE IF EXISTS pre_plugin_{$plugin_name}_keyword;
DROP TABLE IF EXISTS pre_plugin_{$plugin_name}_site_nav;
DROP TABLE IF EXISTS pre_plugin_{$plugin_name}_vest;

EOT;

runquery($sql);

C::t('common_syscache')->delete($plugin_name);

//删除伪原创缓存
$filename = DISCUZ_ROOT.'data/plugindata/keyword.txt';
if(file_exists($filename)){
    unlink($filename);
}
//删除锁文件缓存
$filename = DISCUZ_ROOT.'data/plugindata/'.$plugin_name.'_send_lock.log';
if(file_exists($filename)){
    unlink($filename);
}

//删除多余缓存
$local_path_grab = DISCUZ_ROOT.'data/plugindata/'.$plugin_name.'/';
removeDir($local_path_grab);
function removeDir($dirName)
{
    if(! is_dir($dirName)){
        return FALSE;
    }
    
    $handle = @opendir($dirName);
    while(($file = @readdir($handle)) !== FALSE)
    {
        if($file != '.' && $file != '..'){
            $dir = $dirName.'/'.$file;
            if(is_dir($dir)){
                removeDir($dir);
            }else{
                @unlink($dir);
            }
        }
    }
    
    closedir($handle);

    rmdir($dirName);
}

$finish = true;