<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_admin_keyword extends discuz_table
{
    public function __construct()
    {
        parent::__construct(); //dis'.'m.tao'.'bao.com

        $this->_pk = 'id';
        $this->_table = 'plugin_'.PLUGIN_NAME.'_keyword';
    }
    
    var $keyword_count = 0;
    var $keyword_list = '';
    
    /**
     * 列表
     *
     * @access public
     * @param string, int, int, string
     * @return array
     */
    public function keyword_list($fields, $offset, $limit, $where = '')
    {
        if($this->keyword_list){
            return $this->keyword_list;
        }
        
        $sql = 'SELECT %i FROM %t
               %i
               ORDER BY id DESC LIMIT %d,%d';
         
        $this->keyword_list = DB::fetch_all($sql, array($fields, $this->_table, $where, $offset, $limit));
        
        return $this->keyword_list;
    }
    
    /**
     * 统计
     *
     * @access public
     * @param string
     * @return int
     */
    public function keyword_count($where = '')
    {
        if($this->keyword_count){
            return $this->keyword_count;
        }
        
        $sql = 'SELECT COUNT(*) FROM %t %i';
        
        $this->keyword_count = DB::result_first($sql, array($this->_table, $where));
        
        return $this->keyword_count;
    }
    
    /**
     * 原始关键词是否存在
     *
     * @access public
     * @param string
     * @return int
     */
    public function keyword_is_exist($word1)
    {
        $sql = 'SELECT COUNT(*) FROM %t WHERE word1=%s';
         
        return DB::result_first($sql, array($this->_table, $word1));
    }
    
    /**
     * 全部信息随机排序
     *
     * @access public
     * @param
     * @return array
     */
    public function keyword_all_rand($limit = 0)
    {
        $limit = $limit ? 'LIMIT '.$limit : '';
        
        $sql = 'SELECT word1,word2 FROM %t ORDER BY rand() %i';
         
        return DB::fetch_all($sql, array($this->_table, $limit));
    }
    
    /**
     * 全部信息
     *
     * @access public
     * @param
     * @return array
     */
    public function keyword_all($limit = 0)
    {
        $limit = $limit ? 'LIMIT '.$limit : '';
    
        $sql = 'SELECT word1,word2 FROM %t ORDER BY id ASC %i';
         
        return DB::fetch_all($sql, array($this->_table, $limit));
    }
    
    /**
     * 清空词库
     *
     * @access public
     * @param
     * @return bool
     */
    public function keyword_empty()
    {
        $sql = 'DELETE FROM %t WHERE 1=1';
         
        return DB::query($sql, array($this->_table));
    }
    
    /**
     * 替换
     *
     * @access public
     * @param string
     * @return
     */
    public function replace(& $message, $keyword_replace_percent)
    {
        $i = 0;
        $limitnum = 1000;
        
        $count = $this->keyword_count();
        
        $limit = intval($count * $keyword_replace_percent /100);

        $keyword = $this->keyword_all_rand($limit);

        $find = array();
        $replace = array();
        
        if(! $keyword){
            return FALSE;
        }
        
        foreach($keyword as $value){
            $find[] = $value['word1'];
            $replace[] = $value['word2'];
        }
        
		while($find_words = array_slice($find, $i, $limitnum))
		{
			if(empty($find_words)){
			    break;
			}
			
			$replace_words = array_slice($replace, $i, $limitnum);
			$i += $limitnum;
			
			$message = str_replace($find_words, $replace_words, $message);
		}
		
		return TRUE;
    }
}