<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_admin_vest extends discuz_table
{
    public function __construct()
    {
        parent::__construct(); //dis'.'m.tao'.'bao.com

        $this->_pk = 'id';
        $this->_table = 'plugin_'.PLUGIN_NAME.'_vest';
    }
    
    /**
     * 列表
     *
     * @access public
     * @param string, int, int, string
     * @return array
     */
    public function vest_list($fields, $offset, $limit, $where = '')
    {
         $sql = 'SELECT %i FROM %t v
                 LEFT JOIN %t f ON v.fid=f.fid
                 %i
                 ORDER BY v.id DESC LIMIT %d,%d';
    
        return DB::fetch_all($sql, array($fields, $this->_table, 'forum_forum', $where, $offset, $limit));
    }
    
    /**
     * 统计
     *
     * @access public
     * @param string
     * @return int
     */
    public function vest_count($where = '')
    {
        $sql = 'SELECT COUNT(*) FROM %t v
                LEFT JOIN %t f ON v.fid=f.fid %i';
         
        return DB::result_first($sql, array($this->_table, 'forum_forum', $where));
    }
    
    /**
     * 马甲是否存在
     *
     * @access public
     * @param int, int
     * @return int
     */
    public function vest_is_exist($uid, $fid)
    {
        $sql = 'SELECT COUNT(*) FROM %t WHERE uid=%d AND fid=%d';
         
        return DB::result_first($sql, array($this->_table, $uid, $fid));
    }
    
    /**
     * 列表
     *
     * @access public
     * @param 
     * @return array
     */
    public function vest_list_all()
    {
        $sql = 'SELECT * FROM %t ORDER BY id DESC';
    
        return DB::fetch_all($sql, array($this->_table));
    }
    
    /**
     * 清空数据
     *
     * @access public
     * @param
     * @return bool
     */
    public function vest_empty()
    {
        $sql = 'DELETE FROM %t WHERE 1=1';
    
        return DB::query($sql, array($this->_table));
    }
}