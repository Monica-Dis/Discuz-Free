<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_admin_nav extends discuz_table
{
    public function __construct()
    {
        parent::__construct(); //dis'.'m.tao'.'bao.com

        $this->_pk = 'id';
        $this->_table = 'plugin_'.PLUGIN_NAME.'_site_nav';
    }
    
    var $send_type = array(
        1=>'&#35770;&#22363;',
        2=>'&#38376;&#25143;',
        3=>'&#32676;&#32452;',
    );
    var $status = array(
        0=>'&#24320;&#21551;&#37319;&#38598;',
        1=>'&#20851;&#38381;&#37319;&#38598;',
    );
    
    /**
     * 导航列表
     *
     * @access public
     * @param string, int, int, string
     * @return array
     */
    public function nav_list($fields, $offset, $limit, $where = '')
    {
        $sql = 'SELECT %i FROM %t n
                LEFT JOIN %t f ON n.fid=f.fid
                LEFT JOIN %t c ON n.typeid=c.typeid
                LEFT JOIN %t ca ON n.cid=ca.catid
                %i
                ORDER BY n.id DESC LIMIT %d,%d';
    
        return DB::fetch_all($sql, array($fields, $this->_table, 'forum_forum', 'forum_threadclass', 'portal_category', $where, $offset, $limit));
    }
    
    /**
     * 导航统计
     *
     * @access public
     * @param string
     * @return int
     */
    public function nav_count($where = '')
    {
        $sql = 'SELECT COUNT(*) FROM %t n
                LEFT JOIN %t f ON n.fid=f.fid
                LEFT JOIN %t c ON n.typeid=c.typeid
                LEFT JOIN %t ca ON n.cid=ca.catid
    	        %i';
         
        return DB::result_first($sql, array($this->_table, 'forum_forum', 'forum_threadclass', 'portal_category', $where));
    }
    
    /**
     * 版块详情
     *
     * @access public
     * @param int
     * @return array
     */
    public function forum_forumfield_detail($fid)
    {
        $sql = 'SELECT threadtypes FROM %t WHERE fid=%d';
        
        return DB::fetch_first($sql, array('forum_forumfield', $fid));
    }
    
    /**
     * 网站导航列表
     *
     * @access public
     * @param
     * @return array
     */
    public function nav_grab_list()
    {
        $sql = 'SELECT * FROM %t WHERE status=0 AND send_type>0 ORDER BY grabtime ASC';
    
        return DB::fetch_all($sql, array($this->_table));
    }
    
    /**
     * 网站导航列表
     *
     * @access public
     * @param
     * @return array
     */
    public function nav_all_list()
    {
        $sql = 'SELECT * FROM %t ORDER BY id DESC';
    
        return DB::fetch_all($sql, array($this->_table));
    }
    
    /**
     * 采集导航检测
     *
     * @access public
     * @param array
     * @return array
     */
    public function grab_nav_setting_check($nav)
    {
        if(! $nav['send_type']){
            return lib_base::back_array('&#26410;&#35774;&#32622;&#37319;&#38598;&#29256;&#22359;&#25968;&#25454;&#31867;&#22411;');
        }
    
        if($nav['send_type'] == 1 && ! $nav['fid']){
            return lib_base::back_array('&#35831;&#35774;&#32622;&#37319;&#38598;&#29256;&#22359;&#30340;&#35770;&#22363;&#29256;&#22359;&#105;&#100;');
        }
        if($nav['send_type'] == 2 && ! $nav['cid']){
            return lib_base::back_array('&#35831;&#35774;&#32622;&#37319;&#38598;&#29256;&#22359;&#30340;&#38376;&#25143;&#20998;&#31867;&#105;&#100;');
        }
        if($nav['send_type'] == 3 && ! $nav['fid']){
            return lib_base::back_array('&#35831;&#35774;&#32622;&#37319;&#38598;&#29256;&#22359;&#30340;&#35770;&#22363;&#29256;&#22359;&#105;&#100;');
        }
    
        return lib_base::back_array(lib_base::lang('success'), 0);
    }
    
    /**
     * 更新 host cookie
     *
     * @access public
     * @param string
     * @return bool
     */
    public function cookie_all_update($host, $cookie)
    {
        $sql = "UPDATE ".DB::table($this->_table)." SET cookie='".$cookie."' WHERE source LIKE '%".$host."%'";
    
        return DB::query($sql);
    }
    
    /**
     * 获取采集关键词
     *
     * @access public
     * @param
     * @return array
     */
    public function nav_grab_get()
    {
        $nav_list = $this->nav_grab_list();

        $time = TIMESTAMP;
 
        $nav = array();
    
        foreach($nav_list as $value){
            $grabtime = round(($time - $value['grabtime']) / 60);
            if($grabtime >= $value['crontime']){
                $nav = $value;
                break;
            }
        }

        return $nav;
    }
}