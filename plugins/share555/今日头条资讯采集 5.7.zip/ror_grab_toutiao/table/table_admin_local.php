<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_admin_local extends discuz_table
{
    public function __construct()
    {
        parent::__construct(); //dis'.'m.tao'.'bao.com

        $this->_pk = 'id';
        $this->_table = 'plugin_'.PLUGIN_NAME.'_local';
    }
    
    /**
     * 本地采集列表
     *
     * @access public
     * @param string, int, int, string
     * @return array
     */
    public function grab_grab_list($fields, $offset, $limit, $where = '')
    {
        $sql = 'SELECT %i FROM %t %i ORDER BY id DESC LIMIT %d,%d';
    
        return DB::fetch_all($sql, array($fields, $this->_table, $where, $offset, $limit));
    }
    
    /**
     * 本地采集统计
     *
     * @access public
     * @param string
     * @return int
     */
    public function grab_grab_count($where = '')
    {
        $sql = 'SELECT COUNT(*) FROM %t %i';
         
        return DB::result_first($sql, array($this->_table, $where));
    }
    
    /**
     * 采集本地清空
     *
     * @access public
     * @param int
     * @return array
     */
    public function grab_local_delete_all()
    {
        $sql = 'DELETE FROM %t WHERE 1=1';
    
        return DB::query($sql, array($this->_table));
    }
    
    /**
     * 采集本地是否存在
     *
     * @access public
     * @param int
     * @return int
     */
    public function grab_local_is_exist_by_identify($identify)
    {
        $sql = 'SELECT COUNT(*) FROM %t WHERE identify=%s';
    
        return DB::result_first($sql, array($this->_table, $identify));
    }
    
    /**
     * 采集本地最新数据
     *
     * @access public
     * @param
     * @return array
     */
    public function grab_local_detail_latest()
    {
        $sql = 'SELECT * FROM %t ORDER BY id DESC LIMIT 1';
    
        return DB::fetch_first($sql, array($this->_table));
    }
}