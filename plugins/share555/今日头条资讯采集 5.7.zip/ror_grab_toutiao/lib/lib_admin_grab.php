<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_admin_grab Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_admin_grab
{
    protected static $limit = 10;
    protected static $limit_max = 900;
    protected static $table = 'admin_grab';
    protected static $table_vest = 'admin_vest';
    protected static $table_nav = 'admin_nav';

    public static function index()
    {
        lib_base::header(lib_base::admin_url('grab_list'));
    }
    
    public static function grab_list()
    {
        $escape['search'] = lib_base::escape($_GET['search']);
        $escape['field'] = lib_base::escape($_GET['field']);
        
        $page = $_GET['page'] ? intval($_GET['page']) : 1;
        $limit = $_GET['limit'] ? ($_GET['limit'] > self::$limit_max ? self::$limit_max : intval($_GET['limit'])) : self::$limit;
        
        $fields = array('id'=>'ID','send_type'=>'&#25968;&#25454;&#31867;&#22411;','fid'=>'&#29256;&#22359;&#21517;&#31216;','typeid'=>'&#20998;&#31867;&#21517;&#31216;','cid'=>'&#38376;&#25143;&#26639;&#30446;','tid'=>'&#24086;&#23376;&#105;&#100;','aid'=>'&#25991;&#31456;&#105;&#100;','title'=>'&#26631;&#39064;','source'=>'&#26469;&#28304;','tags'=>'&#26631;&#31614;','dateline'=>'&#37319;&#38598;&#26102;&#38388;','status'=>'&#29366;&#24577;');
        $tool = array(
            '<a class="layui-btn" onclick="Func.post({url:\''.lib_base::admin_url('grab_local_del').'\'})">&#25209;&#37327;&#21024;&#38500;</a>',
        );
        $submit = lib_base::admin_url('grab_list').'&limit='.$limit;

        $fields_str = lib_func::field_str($fields);
        $offset = ($page - 1) * $limit;
        
        $where = 'WHERE status=1';
        if($escape['search'] && $escape['field'] && array_key_exists($escape['field'], $fields)){
            $where .= " AND ".$escape['field']." = '".$escape['search']."'";
            $submit .= '&search='.$escape['search'].'&field='.$escape['field'];
        }
        
        $list = lib_base::table(self::$table)->grab_list($fields_str, $offset, $limit, $where);
        
        $forum_list = lib_base::table(self::$table)->forum_list();
        $forum_threadclass_list = lib_base::table(self::$table)->forum_threadclass_list();
        $portal_category_list = lib_base::table(self::$table)->portal_category_list();
        
        foreach($list as & $value)
        {
            $value['title'] = '<a href="'.$value['source'].'" target="_blank">'.cutstr(strip_tags($value['title']), 50, '').'</a>';
            ! $value['tags'] && $value['tags'] = lib_base::lang('field_nodata');
            $value['fid'] = $value['fid'] && isset($forum_list[$value['fid']]) ? $forum_list[$value['fid']] : lib_base::lang('field_nodata');
            $value['typeid'] = $value['typeid'] && isset($forum_threadclass_list[$value['typeid']]) ? $forum_threadclass_list[$value['typeid']] : lib_base::lang('field_nodata');
            $value['cid'] = $value['cid'] && isset($portal_category_list[$value['cid']]) ? $portal_category_list[$value['cid']] : lib_base::lang('field_nodata');
            unset($value['source']);
        }
        unset($fields['source']);
        
        $count = lib_base::table(self::$table)->grab_count($where);
        $page_count = ceil($count / $limit);
        $paging = lib_func::paging($page_count, $page, $submit.'&page=', $limit, $count);
        $search = lib_func::field_option(array('id'=>'ID','title'=>'&#26631;&#39064;','tid'=>'&#24086;&#23376;&#105;&#100;','aid'=>'&#25991;&#31456;&#105;&#100;'), $escape['field']);
        
        $formate['batch'] = 1;
        $formate['time'] = array('dateline');
        $formate['fi'] = array('status'=>lib_base::table(self::$table)->status,'send_type'=>lib_base::table(self::$table_nav)->send_type);
        $formate['op'] = array(
            array('url'=>lib_base::admin_url('grab_local_del'),'name'=>lib_base::lang('delete'),type=>3,'confirm'=>FALSE),
            array('url'=>lib_base::admin_url('grab_thread_detail').'&grab_id=','name'=>'&#26597;&#30475;','type'=>1)
        );
        
        $fields = lib_func::create_table($list, $fields, $formate);

        $admin_nav = 1;
        
        include lib_base::template('admin');
    }
    
    public static function grab_thread_detail()
    {
        $grab_id = intval($_GET['grab_id']);
        
        $detail = lib_base::table(self::$table)->fetch($grab_id);
        
        if($detail['send_type'] == 1 || $detail['send_type'] == 3){
            lib_base::header('forum.php?mod=viewthread&tid='.$detail['tid']);
        }else if($detail['send_type'] == 2){
            lib_base::header('portal.php?mod=view&aid='.$detail['aid']);
        }
        
        lib_base::js_back_show(lib_base::lang('nodata'));
    }
    
    public static function grab_list_local()
    {
        $escape['search'] = lib_base::escape($_GET['search']);
        $escape['field'] = lib_base::escape($_GET['field']);
    
        $page = $_GET['page'] ? intval($_GET['page']) : 1;
        $limit = $_GET['limit'] ? ($_GET['limit'] > self::$limit_max ? self::$limit_max : intval($_GET['limit'])) : self::$limit;
    
        $fields = array('id'=>'ID','send_type'=>'&#25968;&#25454;&#31867;&#22411;','fid'=>'&#29256;&#22359;&#21517;&#31216;','typeid'=>'&#20998;&#31867;&#21517;&#31216;','cid'=>'&#38376;&#25143;&#26639;&#30446;','title'=>'&#26631;&#39064;','source'=>'&#26469;&#28304;','tags'=>'&#26631;&#31614;','dateline'=>'&#37319;&#38598;&#26102;&#38388;','status'=>'&#29366;&#24577;');
        $tool = array(
            '<a class="layui-btn" onclick="Func.post({url:\''.lib_base::admin_url('grab_local_del').'\'})">&#25209;&#37327;&#21024;&#38500;</a>',
            '<a class="layui-btn" href="'.lib_base::url('thread_send').'&send_all=1" target="_blank">&#20840;&#37096;&#21457;&#24067;</a>',
        );
        $submit = lib_base::admin_url('grab_list_local').'&limit='.$limit;
    
        $fields_str = lib_func::field_str($fields);
        $offset = ($page - 1) * $limit;
    
        $where = 'WHERE status=0';
        if($escape['search'] && $escape['field'] && array_key_exists($escape['field'], $fields)){
            $where .= " AND ".$escape['field']." = '".$escape['search']."'";
            $submit .= '&search='.$escape['search'].'&field='.$escape['field'];
        }
    
        $list = lib_base::table(self::$table)->grab_list($fields_str, $offset, $limit, $where);
    
        $forum_list = lib_base::table(self::$table)->forum_list();
        $forum_threadclass_list = lib_base::table(self::$table)->forum_threadclass_list();
        $portal_category_list = lib_base::table(self::$table)->portal_category_list();
        
        foreach($list as & $value)
        {
            $value['title'] = '<a href="'.$value['source'].'" target="_blank">'.$value['title'].'</a>';
            ! $value['tags'] && $value['tags'] = lib_base::lang('field_nodata');
            $value['fid'] = $value['fid'] && isset($forum_list[$value['fid']]) ? $forum_list[$value['fid']] : lib_base::lang('field_nodata');
            $value['typeid'] = $value['typeid'] && isset($forum_threadclass_list[$value['typeid']]) ? $forum_threadclass_list[$value['typeid']] : lib_base::lang('field_nodata');
            $value['cid'] = $value['cid'] && isset($portal_category_list[$value['cid']]) ? $portal_category_list[$value['cid']] : lib_base::lang('field_nodata');
            unset($value['source']);
        }
        unset($fields['source']);
    
        $count = lib_base::table(self::$table)->grab_count($where);
        $page_count = ceil($count / $limit);
        $paging = lib_func::paging($page_count, $page, $submit.'&page=', $limit, $count);
        $search = lib_func::field_option(array('id'=>'ID','title'=>'&#26631;&#39064;'), $escape['field']);
    
        $formate['batch'] = 1;
        $formate['time'] = array('dateline');
        $formate['fi'] = array('status'=>lib_base::table(self::$table)->status,'send_type'=>lib_base::table(self::$table_nav)->send_type);
        $formate['op'] = array(
            array('url'=>lib_base::admin_url('grab_local_edit').'&grab_id=','name'=>lib_base::lang('edit')),
            array('url'=>lib_base::admin_url('grab_local_del'),'name'=>lib_base::lang('delete'),type=>3,'confirm'=>FALSE),
            array('url'=>lib_base::url('thread_send'),'name'=>'&#21457;&#24067;',type=>3,'confirm'=>FALSE),
            array('url'=>lib_base::admin_url('grab_local_verify').'&grab_id=','name'=>'&#23457;&#26680;')
        );
    
        $fields = lib_func::create_table($list, $fields, $formate);
        
        $admin_nav = 1;
        
        include lib_base::template('admin');
    }
    
    public static function grab_local_del()
    {
        $grab_id = $_GET['batch'] ? $_GET['batch'] : intval($_GET['ids']);
        
        if(! $grab_id){
            lib_base::back_text(lib_base::lang('noselect'));
        }
        
        lib_base::table(self::$table)->delete($grab_id);
        
        lib_base::back_json(array('reload'=>1));
    }
    
    public static function grab_local_verify()
    {
        $grab_id = intval($_GET['grab_id']);
        
        $submit  = lib_base::url('thread_send').'&grab_id='.$grab_id;
    
        $detail = lib_base::table(self::$table)->grab_detail($grab_id);
    
        preg_match_all('/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/i', $detail['content'], $result);

        if($result){
            $url_hotlinking = 'plugin.php?id='.PLUGIN_NAME.'&act=pic&url=';
            foreach($result[1] as $value){
                $url = $url_hotlinking.urlencode($value);
                $detail['content'] = str_replace($value, $url, $detail['content']);
            }
        }

        $grab_local_edit_url = lib_base::admin_url('grab_local_edit').'&grab_id='.$grab_id;
        $content = <<<EOT
<style type="text/css">.layui-card-body img{max-width:700px;display:block;margin:0 auto;}</style> 
<div class="layui-card">
    <div class="layui-card-header" style="display:none;"></div>
    <div class="layui-card-body" style="padding:15px;margin-bottom:65px;">
        <div class="layui-form-item1">
            <div class="layui-input-block1">
                <h3 style="text-align:center;">{$detail['title']}</h3>
                {$detail['content']}
            </div>
        </div>
      
        <div class="layui-form-item1 layui-layout-admin">
            <div class="layui-input-block1">
                <div class="layui-footer" style="left:0;">
                    <button type="button" class="layui-btn" lay-submit onclick="Func.post({})">&#36890;&#36807;&#21457;&#24067;</button>
                    <button type="button" class="layui-btn" lay-submit onclick="parent.Func.open({iframe:true,url:'{$grab_local_edit_url}'})">&#32534;&#36753;</button>
                    <button type="button" class="layui-btn layui-btn-primary" onclick="parent.layer.close(parent.index);">&#21462;&#28040;</button>
                </div>
            </div>
        </div>
    </div>
</div>
EOT;
        
        include lib_base::template('admin');
    }

    public static function grab_local_edit()
    {
        $grab_id = $_GET['grab_id'] ? intval($_GET['grab_id']) : intval($_GET['ids']);
    
        $detail = lib_base::table(self::$table)->grab_detail($grab_id);
        
        require_once libfile('function/forumlist');
        require_once libfile('function/portalcp');
        require_once libfile('function/group');
        
        $send_type = $detail['send_type'];
        $fid = $detail['fid'];
        $typeid = $detail['typeid'];

        $cid = $detail['cid'];
        
        $grouplist = grouplist('displayorder', array(), 100);
        $grouplist_option = '';
        if($grouplist){
            foreach($grouplist as $value){
                $selected = $fid == $value['fid'] ? ' selected' : '';
                $grouplist_option .= '<option value="'.$value['fid'].'"'.$selected.'>'.$value['name'].'</option>';
            }
        }
        
        $groupselect = '<select lay-filter="group_id" name="group_id" id="group_id">'.$grouplist_option.'</select>';
        $forumselect = '<select lay-filter="fid" name="fid" id="fid"><option value="0">&#36873;&#25321;&#29256;&#22359;</option>'.forumselect(FALSE, 0, $fid).'</select>';
        $typeselect = '<select name="typeid" id="typeid"><option value="0">&#36873;&#25321;&#20027;&#39064;&#20998;&#31867;</option></select>';
        $portalselect = category_showselect('portal', 'portal_catid', false, $detail['cid']);
        $portalselect = str_replace('<select id="portal_catid"', '<select lay-filter="portal_catid" id="portal_catid"', $portalselect);
        
        $send_type_option = lib_func::select_option(lib_base::table('admin_nav')->send_type, $send_type);
        $send_typeselect = '<select lay-filter="send_type" name="send_type" id="send_type">'.$send_type_option.'</select>';
        
        $submit  = lib_base::admin_url('grab_local_edited').'&grab_id='.$grab_id.'&formhash='.FORMHASH;
        $submit_verify = lib_base::url('thread_send').'&grab_id='.$grab_id;
        
        $content = <<<EOT
<div class="layui-card">
    <div class="layui-card-body" style="padding:0;">
        <div class="layui-form-item1">
            <div class="layui-input-block1">
               	<div class="layui-input-block1">
                	<div class="layui-inline">{$send_typeselect}</div>
                	<div class="layui-inline">{$portalselect}</div>
            		<div class="layui-inline">{$groupselect}</div>
                	<div class="layui-inline">{$forumselect}</div>
                	<div class="layui-inline" style="margin-left:-15px;"><input type="text" id="input_id" name="input_id" class="layui-input" style="width:50px;padding-left:5px;" placeholder="fid/aid"></div>
                	<div class="layui-inline">{$typeselect}</div>
    	        </div>
                <input type="text" name="title" lay-verify="required" class="layui-input" value="{$detail['title']}" id="title">
                <textarea name="content" lay-verify="required" id="content">{$detail['content']}</textarea>
                <script type="text/javascript">
                var layedit = '';
                var layedit_build = '';
                layui.use(['layedit', 'jquery'], function(){
                    layedit = layui.layedit;
                    layedit_build = layedit.build('content', {
                        tool: [ 'strong','italic','underline','del','|','left','center','right','link','unlink','face'],
                        height:340
                    });
                    var $ = layui.jquery;
                    $('#submit').click(function(){
                        layedit.sync(layedit_build);
                        Func.post({});
                    });
                });
                </script>
            </div>
        </div>
      
        <div class="layui-form-item1 layui-layout-admin">
            <div class="layui-input-block1">
                <div class="layui-footer" style="left:0;">
                    <button type="button" class="layui-btn" lay-submit onclick="send()">&#36890;&#36807;&#21457;&#24067;</button>
                    <button id="submit" type="button" class="layui-btn" lay-submit>&#31435;&#21363;&#25552;&#20132;</button>
                    <button type="button" class="layui-btn layui-btn-primary" onclick="parent.layer.close(parent.index);">&#21462;&#28040;</button>
                </div>
            </div>
        </div>
    </div>
</div>
EOT;
        
    $threadclass_list_url = lib_base::admin_url('threadclass_list');
    $hidden = <<<EOT
<script type="text/javascript">
var send_type = {$send_type};
var fid = {$fid};
var typeid = {$typeid};
layui.use(['form','jquery'],function()
{
    form = layui.form,
    $ = layui.jquery;
	form.on('select(send_type)', function(data){
        send_type_show(data.value, 0);
    });

    form.on('select(fid)', function(data){
        threadclass_list(data.value, 0);
        $('#input_id').val($('#fid').val());
    });
    form.on('select(portal_catid)', function(data){
        $('#input_id').val($('#portal_catid').val());
    });
    form.on('select(group_id)', function(data){
        $('#input_id').val($('#group_id').val());
    });
    
    $('#group_id').parent().hide();
    $('#portal_catid').parent().hide();
    $('#typeid').parent().hide();
        
    if(send_type > 0){
        send_type_show(send_type, 1);
    }
    if(fid){
        threadclass_list(fid, typeid);
    }
});

function send_type_show(send_type, init)
{
    if(send_type == 1){
        $('#fid').parent().show();
        //$('#typeid').parent().show();
        $('#group_id').parent().hide();
        $('#portal_catid').parent().hide();
        if(init == 0){
            $('#fid').find('option:first').attr('selected', true);
            form.render();
        }
        
        $('#input_id').val($('#fid').val());
    }else if(send_type == 2){
        $('#fid').parent().hide();
        $('#typeid').parent().hide();
        $('#group_id').parent().hide();
        $('#portal_catid').parent().show();
        
        $('#input_id').val($('#portal_catid').val());
    }else if(send_type == 3){
        $('#fid').parent().hide();
        $('#typeid').parent().hide();
        $('#group_id').parent().show();
        $('#portal_catid').parent().hide();
        
        $('#input_id').val($('#group_id').val());
    }
}
        
function threadclass_list(fid, typeid)
{
    $.ajax({
        data    : {fid:fid},
		dataType: 'html',
		type    : 'get',
		url     : '{$threadclass_list_url}',
		success : function(data){
		    data = Func.ajax_json(data);
		    
		    var html = '';
		    if(data.type.length > 0){
		        $('#typeid').parent().show();
    		    for(var i in data.type){
    		        var selected = typeid == data.type[i].id ? ' selected' : '';
                    html += '<option value="'+data.type[i].id+'"'+selected+'>'+data.type[i].name+'</option>';
                }
		    }else{
		        $('#typeid').parent().hide();
            }
		    $('#typeid').html(html);
		 
		    form.render();
        }
	});
}
		    
function send()
{
    layedit.sync(layedit_build);
    var form = $('#form');
    var edit_url = form.attr('action');
    var verify_url = '{$submit_verify}';
    $.ajax({
		data    : form.serialize(),
		dataType: 'html',
		type    : 'post',
		url     : edit_url,
		success : function(data){
			data = Func.ajax_json(data);
			if(data.state == 1){
				Func.notice(data.result);
				return;
			}
			
            $('#content').val('');
            form.attr('action', verify_url);
		    Func.post({});
		}
	});
}
</script>
EOT;
        include lib_base::template('admin');
    }
    
    public static function grab_local_edited()
    {
        $grab_id = intval($_GET['grab_id']);
        $send_type = intval($_GET['send_type']);
        $fid = intval($_GET['fid']);
        $typeid = intval($_GET['typeid']);
        $group_id = intval($_GET['group_id']);
        $portal_catid = intval($_GET['portal_catid']);
        $title = $_GET['title'];
        $content = $_GET['content'];
        $input_id = intval($_GET['input_id']);

        if(! $input_id && $send_type == 1 && ! $fid){
            lib_base::back_text('&#35831;&#36873;&#25321;&#35770;&#22363;&#29256;&#22359;');
        }
        if(! $input_id && $send_type == 2 && ! $portal_catid){
            lib_base::back_text('&#35831;&#36873;&#25321;&#38376;&#25143;&#20998;&#31867;');
        }
        if(! $input_id && $send_type == 3 && ! $group_id){
            lib_base::back_text('&#35831;&#36873;&#25321;&#32676;&#32452;&#29256;&#22359;');
        }
      
        $edit = array(
            'title'=>$title,
            'content'=>$content,
            'send_type'=>$send_type,
            'cid'=>0,
            'fid'=>0,
            'typeid'=>0,
        );
        
        if($send_type == 1){
            $edit['fid'] = $input_id ? $input_id : $fid;
            $edit['typeid'] = $typeid;
        }else if($send_type == 2){
            $edit['cid'] = $input_id ? $input_id : $portal_catid;
        }else if($send_type == 3){
            $edit['fid'] = $input_id ? $input_id : $group_id;
        }

        lib_base::table(self::$table)->update($grab_id, $edit);
    
        lib_base::back_json(array('callreload'=>1));
    }
    
    public static function grab_article()
    {
        $submit  = lib_base::admin_url('grab_articled');
    
        require_once libfile('function/forumlist');
        require_once libfile('function/portalcp');
        require_once libfile('function/group');
    
        $grouplist = grouplist('displayorder', array(), 100);
        $grouplist_option = '';
        if($grouplist){
            foreach($grouplist as $value){
                $grouplist_option .= '<option value="'.$value['fid'].'">'.$value['name'].'</option>';
            }
        }
    
        $groupselect = '<select lay-filter="group_id" name="group_id" id="group_id">'.$grouplist_option.'</select>';
        $forumselect = '<select lay-filter="fid" name="fid" id="fid"><option value="0">&#36873;&#25321;&#29256;&#22359;</option>'.forumselect().'</select>';
        $typeselect = '<select name="typeid" id="typeid"><option value="0">&#36873;&#25321;&#20027;&#39064;&#20998;&#31867;</option></select>';
        $portalselect = category_showselect('portal', 'portal_catid');
        $portalselect = str_replace('<select id="portal_catid"', '<select lay-filter="portal_catid" id="portal_catid"', $portalselect);
    
        $send_type_option = lib_func::select_option(lib_base::table(self::$table_nav)->send_type);
        $send_typeselect = '<select lay-filter="send_type" name="send_type" id="send_type">'.$send_type_option.'</select>';

        $formhash = FORMHASH;

        $content = <<<EOT
<div class="layui-card">
<div class="layui-card-header">&#37319;&#38598;&#25991;&#31456;</div>
    <div class="layui-card-body">
    
        <div class="layui-form-item">
            <label class="layui-form-label">&#37319;&#38598;&#21040;</label>
        	<div class="layui-input-block">
            	<div class="layui-inline">{$send_typeselect}</div>
            	<div class="layui-inline">{$portalselect}</div>
        		<div class="layui-inline">{$groupselect}</div>
            	<div class="layui-inline">{$forumselect}</div>
            	<div class="layui-inline" style="margin-left:-15px;"><input type="text" id="input_id" name="input_id" class="layui-input" style="width:50px;padding-left:5px;" placeholder="fid/aid"></div>
            	<div class="layui-inline">{$typeselect}</div>
        	</div>
        </div>
        
        <div class="layui-form-item">
            <label class="layui-form-label">&#25991;&#31456;&#22320;&#22336;</label>
        	<div class="layui-input-block">
        	<textarea name="article_source" class="layui-textarea" lay-verify="required" placeholder="&#19968;&#34892;&#19968;&#26465;&#32;&#117;&#114;&#108;&#32;&#22320;&#22336;&#25968;&#25454;" style="height:300px;"></textarea>
            </div>
        </div>
    
        <div class="layui-form-item">
        	<label class="layui-form-label">cookie</label>
        	<div class="layui-input-block">
                <textarea name="cookie" class="layui-input" style="height:200px;"></textarea>
        	</div>
        </div>
        
        <div class="layui-form-item layui-layout-admin">
            <div class="layui-footer" style="left:0;">
                <button type="submit" class="layui-btn" lay-submit>&#31435;&#21363;&#25552;&#20132;</button>
                <button type="reset" class="layui-btn layui-btn-primary">&#37325;&#32622;</button>
            </div>
        </div>
    </div>
</div>
<input type="hidden" name="formhash" value="{$formhash}"/>
EOT;
            	$threadclass_list_url = lib_base::admin_url('threadclass_list');
            	$hidden = <<<EOT
<script type="text/javascript">
layui.use(['form','jquery'],function(){
    form = layui.form,
    $ = layui.jquery;
	form.on('select(send_type)', function(data){
        send_type_show(data.value);
    });
	form.on('select(fid)', function(data){
        threadclass_list(data.value, 0);
        $('#input_id').val($('#fid').val());
    });
    form.on('select(portal_catid)', function(data){
        $('#input_id').val($('#portal_catid').val());
    });
    form.on('select(group_id)', function(data){
        $('#input_id').val($('#group_id').val());
    });
    
    $('#group_id').parent().hide();
    $('#portal_catid').parent().hide();
    $('#typeid').parent().hide();
});

function send_type_show(send_type){
    if(send_type == 1){
        $('#fid').parent().show();
        //$('#typeid').parent().show();
        $('#group_id').parent().hide();
        $('#portal_catid').parent().hide();
        $('#fid').find('option:first').attr('selected', true);
        form.render();
        
        $('#input_id').val($('#fid').val());
    }else if(send_type == 2){
        $('#fid').parent().hide();
        $('#typeid').parent().hide();
        $('#group_id').parent().hide();
        $('#portal_catid').parent().show();
        
        $('#input_id').val($('#portal_catid').val());
    }else if(send_type == 3){
        $('#fid').parent().hide();
        $('#typeid').parent().hide();
        $('#group_id').parent().show();
        $('#portal_catid').parent().hide();
        
        $('#input_id').val($('#group_id').val());
    }
}
        
function threadclass_list(fid, typeid){
    $.ajax({
        data    : {fid:fid},
		dataType: 'html',
		type    : 'get',
		url     : '{$threadclass_list_url}',
		success : function(data){
		    data = Func.ajax_json(data);
		    
		    var html = '';
		    if(data.type.length > 0){
		        $('#typeid').parent().show();
    		    for(var i in data.type){
    		        var selected = typeid == data.type[i].id ? ' selected' : '';
                    html += '<option value="'+data.type[i].id+'"'+selected+'>'+data.type[i].name+'</option>';
                }
		    }else{
		        $('#typeid').parent().hide();
            }
		    $('#typeid').html(html);
		    
		    form.render();
        }
	});
}
</script>
EOT;
    
    	$admin_nav = 1;
            	
        include lib_base::template('admin');
    }
    
    public static function grab_articled()
    {
        $send_type = intval($_GET['send_type']);
        $fid = intval($_GET['fid']);
        $typeid = intval($_GET['typeid']);
        $group_id = intval($_GET['group_id']);
        $portal_catid = intval($_GET['portal_catid']);
        $article_source = $_GET['article_source'];
        $input_id = intval($_GET['input_id']);
        $cookie = $_GET['cookie'];
        
        if(! $send_type || ! $article_source){
            lib_base::js_back_page(lib_base::lang('noparam'));
        }
        
        if(! $input_id && $send_type == 1 && ! $fid){
            lib_base::js_back_page('&#35831;&#36873;&#25321;&#35770;&#22363;&#29256;&#22359;');
        }
        if(! $input_id && $send_type == 2 && ! $portal_catid){
            lib_base::js_back_page('&#35831;&#36873;&#25321;&#38376;&#25143;&#20998;&#31867;');
        }
        if(! $input_id && $send_type == 3 && ! $group_id){
            lib_base::js_back_page('&#35831;&#36873;&#25321;&#32676;&#32452;&#29256;&#22359;');
        }
    
        if($send_type == 1){
            $portal_catid = 0;
            $input_id && $fid = $input_id;
        }else if($send_type == 2){
            $fid = 0;
            $typeid = 0;
            $input_id && $portal_catid = $input_id;
        }else if($send_type == 3){
            $portal_catid = 0;
            $typeid = 0;
            $fid = $group_id;
            $input_id && $fid = $input_id;
        }
        
        $url = $article_source;
        $ruleid = 0;
        
        require_once libfile('lib/func_grab', 'plugin/'.PLUGIN_NAME);
        require_once libfile('lib/rule', 'plugin/'.PLUGIN_NAME);

        $url_parse = parse_url($url);
        if($url_parse['host']){
            $rule_file = DISCUZ_ROOT.'source/plugin/'.PLUGIN_NAME.'/rule/'.$url_parse['host'].'.php';
            if(file_exists($rule_file)){
                include $rule_file;
            }
        }
        
        $grab = array('rule'=>$rule[$ruleid],'send_type'=>$send_type,'cid'=>$portal_catid,'fid'=>$fid,'typeid'=>$typeid);
        unset($grab['title']);
        
        $cookie && $grab['cookie'] = $cookie;

        $source_list = explode("\n", $article_source);
        foreach($source_list as $source)
        {
            $source = trim($source);
            
            $identify = lib_func_grab::save_identify($source);
    
            if(lib_base::table('admin_grab')->grab_is_exist_by_identify($identify)){
                $notice = '&#20869;&#23481;&#37319;&#38598;&#37325;&#22797;&#65306;'.$source;
                lib_base::back_html($notice, 1);
                continue;
            }
            
            $grab['source'][0] = $source;
            $grab['key'] = 0;
            unset($grab['title']);
            unset($grab['html']);

            lib_func_grab::grab_detail($grab);
        }

        lib_base::js_back_show('<script>setTimeout("history.back()", 2000);</script>');
    }
    
    public static function grab_document()
    {
        $content = <<<EOT
<div class="layui-card">
    <div class="layui-card-header">&#25991;&#26723;&#21644;&#35268;&#21017;</div>
    <div class="layui-card-body">
    
        <div class="layui-form-item">
        	&#25991;&#26723;&#19979;&#36733;&#22320;&#22336;&#65306;<a href="//grab.share555.com/forum.php?mod=viewthread&tid=1" target="_blank">grab.share555.com/forum.php?mod=viewthread&tid=1</a>
        </div>

    	<div class="layui-form-item">
        	&#35268;&#21017;&#19979;&#36733;&#22320;&#22336;&#65306;<a href="//grab.share555.com/forum.php?mod=forumdisplay&fid=2" target="_blank">grab.share555.com/forum.php?mod=forumdisplay&fid=2</a>
        </div>
        	    
    	<div class="layui-form-item">
        	&#25554;&#20214;&#25903;&#25345;&#37319;&#38598;&#20219;&#20309;&#31449;&#28857;&#65292;&#21487;&#20197;&#19979;&#36733;&#35268;&#21017;&#25991;&#20214;&#19978;&#20256;&#21040;&#25554;&#20214;&#114;&#117;&#108;&#101;&#25991;&#20214;&#22841;&#21518;&#37319;&#38598;&#27492;&#31449;&#28857;&#25968;&#25454;&#25110;&#32773;&#32852;&#31995;&#31649;&#29702;&#21592;&#33258;&#23450;&#20041;&#37319;&#38598;&#35268;&#21017;&#25991;&#20214;
        </div>
    
    </div>
</div>
EOT;
    
        $admin_nav = 1;
        
        include lib_base::template('admin');
    }
}