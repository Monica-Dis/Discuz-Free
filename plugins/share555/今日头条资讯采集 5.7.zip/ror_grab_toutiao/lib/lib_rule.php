<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(! $url){
    
    $title = $nav['title'];
    if(CHARSET == 'gbk'){
        $title = lib_base::string_gbk_to_utf8($nav['title']);
    }
    
    $nav['source'] = 'https://so.toutiao.com/search?keyword='.urlencode($title).'&pd=information&source=input&dvpf=pc&page_num=0';
    $url = $nav['source'];
}

if(strpos($url, 'm.toutiao.com/list') !== FALSE || ! $url)
{
    $rule = array(
        
        '0'=>array(
            
            'list_intercept_start'=>'<div class="s-result-list">',
            'list_intercept_filter'=>array(),
            'list_intercept_end'=>'<div class="result-content">',
            'list_list'=>'<div class="result-content"(.*?)<\/div>',
            'list_source'=>'href="(.*?)"',
            'list_title'=>'<a .*?>(.*?)<\/a>',
            
            'con_intercept_start'=>'syl-device-pc">',
            'con_intercept_filter'=>array(),
            'con_intercept_end'=>'</article>',
            
            'func'=>array(
                'list'=>'list_toutiao',
                //'list_deal'=>'list_deal_toutiao',
                //'page_deal'=>'page_deal_toutiao',
                
                'detail'=>'detail_toutiao',
                'detail_deal'=>'detail_deal_toutiao',
                'comment_start'=>'comment_start_toutiao',
            )
        ),
        
    );
}
else 
{
    $rule = array(
        
        '0'=>array(
            
            'list_intercept_start'=>'<div class="s-result-list">',
            'list_intercept_filter'=>array(),
            'list_intercept_end'=>'<div class="result-content">',
            'list_list'=>'<div class="result-content"(.*?)<\/div>',
            'list_source'=>'href="(.*?)"',
            'list_title'=>'<a .*?>(.*?)<\/a>',
            
            'con_intercept_start'=>'syl-device-pc">',
            'con_intercept_filter'=>array(),
            'con_intercept_end'=>'</article>',
            
            'func'=>array(
                //'list'=>'list_toutiao',
                'list_deal'=>'list_deal_toutiao',
                'page_deal'=>'page_deal_toutiao',
                
                'detail'=>'detail_toutiao',
                'detail_deal'=>'detail_deal_toutiao',
                'comment_start'=>'comment_start_toutiao',
            )
        ),
        
    );
}

if(! function_exists('list_deal_toutiao'))
{
    function list_deal_toutiao(& $grab)
    {
        foreach($grab['title'] as $key => $title){
            $grab['title'][$key] = strip_tags($title);
        }
        
        foreach($grab['source'] as $key => $source){
            $source = urldecode($source);
            preg_match('/url=(.*?)\?/is', $source, $result);
            if($result[1] && strpos($result[1], 'www.toutiao.com') !== FALSE){
                $result[1] = str_replace('http://', 'https://', $result[1]);
                $grab['source'][$key] = $result[1];
            }else{
                $grab['source'][$key] = '';
            }
        }
    }
}


if(! function_exists('page_deal_toutiao'))
{
    function page_deal_toutiao($page, $nav)
    {
        $url = $nav['source'];
        
        if($page == 1){
            return $url;
        }
        
        $url = str_replace('page_num=0', 'page_num='.($page - 1), $url);
        
        return $url;
    }
}

if(!function_exists('list_toutiao'))
{
    function list_toutiao(& $grab)
    {
        if(CHARSET == 'gbk'){
            $grab['title'] = lib_base::string_gbk_to_utf8($grab['title']);
        }
        
        //HOST
        if(! $grab['url']){
            $grab['url'] = 'https://www.toutiao.com/api/search/content/?aid=24&app_name=web_search&offset=20&format=json&keyword='.urlencode($grab['title']).'&autoload=true&count=20&en_qc=1&cur_tab=1&from=search_tab&pd=synthesis&timestamp='.TIMESTAMP.mt_rand(100,999);
        }

        $urls = parse_url(trim($grab['url']));
        $paths = explode('/', $urls['path']);
        $grab['host'] = $urls['scheme'].'://'.$urls['host'];
        $cookie = $grab['cookie'];
        
        $html = lib_func_grab::get($grab['url'], $grab['host'], $urls['host'], $cookie);

        $json = json_decode($html, TRUE);
        if(! $json){
            $notice = '&#21015;&#34920;&#106;&#115;&#111;&#110;&#35299;&#26512;&#26377;&#35823;&#65306;'.$grab['url'];
            lib_base::back_html($notice , 1);
            return;
        }
        if(! $json['data']){
            $notice = '&#26080;&#37319;&#38598;&#25968;&#25454;&#65306;'.$grab['url'];
            lib_base::back_html($notice , 1);
            return;
        }
        
        $host = 'https://www.toutiao.com';
        $grab['title'] = array();
        $grab['source'] = array();
        foreach($json['data'] as $key => $value)
        {
            if(isset($value['title']) && isset($value['source_url']) && strpos($value['source_url'], 'group/') !== FALSE){
                $grab['title'][$key] = $value['title'];
                $grab['source'][$key] = str_replace('group/', 'a', $value['source_url']);
                if(strpos($grab['source'][$key], 'http') === FALSE){
                    $grab['source'][$key] = $host.$grab['source'][$key];
                }
            }elseif(isset($value['title']) && isset($value['source_url']) && strpos($value['source_url'], 'item/') !== FALSE){
                $grab['title'][$key] = $value['title'];
                $grab['source'][$key] = str_replace('item/', 'i', $value['source_url']);
                if(strpos($grab['source'][$key], 'http') === FALSE){
                    $grab['source'][$key] = $host.$grab['source'][$key];
                }
            }elseif(isset($value['title']) && isset($value['source_url']) && strpos($value['source_url'], '/i') !== FALSE){
                $grab['title'][$key] = $value['title'];
                $grab['source'][$key] = $value['source_url'];
                if(strpos($grab['source'][$key], 'http') === FALSE){
                    $grab['source'][$key] = $host.$grab['source'][$key];
                }
            }
        }
        
        lib_func_grab::$repeat_count = 0;
        foreach($grab['title'] as $key => $value)
        {
            if(! $value){
                continue;
            }
            
            $source = $grab['source'][$key];
            
            $identify = lib_func_grab::save_identify($source);
            
            $sql = 'SELECT COUNT(*) FROM '.DB::table('plugin_'.PLUGIN_NAME)." WHERE identify='".$identify."'";
            $count = DB::result_first($sql);
            if($count)
            {
                $notice = '&#20869;&#23481;&#37319;&#38598;&#37325;&#22797;&#58;'.$source;
                lib_base::back_html($notice, 1);
                lib_func_grab::$repeat_count++;
                
                if(lib_func_grab::$repeat_count >= lib_func_grab::$repeat_limit){
                    $notice = '&#37319;&#38598;&#20869;&#23481;&#37325;&#22797;&#27425;&#25968;&#36229;&#36807; '.lib_func_grab::$repeat_limit.' &#27425;&#65292;&#20013;&#26029;&#37319;&#38598;&#58;'.$source;
                    lib_base::back_html($notice, 1);
                    break;
                }
                
                continue;
            }
            
            lib_func_grab::$grab_new++;
            
            lib_func_grab::grab_detail_local($grab['id'], $grab['title'][$key], $source);
        }
        
        //更新机制
        lib_func_grab::nav_crontime_update($grab['id'], $grab['crontime']);
        
        return TRUE;
        
    }
    
    function detail_toutiao($grab)
    {
        $url = $grab['detail_url'];
        
        $url = str_replace('www.toutiao.com', 'm.toutiao.com', $url);
        $url = str_replace('/a', '/i', $url);
        $url .= 'info/';
        
        //获取HOST
        $urls = parse_url($url);
        $host = isset($urls['scheme']) ? $urls['scheme'].'://'.$urls['host'] : $urls['host'];
        $cookie = $grab['cookie'];
        
        $json = lib_func_grab::get($url, $grab['host'], $urls['host'], $cookie);
  
        $title = '';
        $html = '';
        $json = json_decode($json, TRUE);

        if($json['data']['title']){
            $title = $json['data']['title'];
            if(CHARSET == 'gbk'){
                $title = lib_base::string_utf8_to_gbk($title);
            }
        }
        if($json['data']['content']){
            $html = $json['data']['content'];
        }
        
        if($json['data']['video_id']){
            $html = '';
        }
        
        if(! $html){
            $notice = '&#33719;&#21462;&#35814;&#24773;&#22833;&#36133;&#65306;'.$url;
            lib_base::back_html($notice, 1);
            return FALSE;
        }
        
        //内容过滤
        $parrent = '<pre class="syl-page-code hljs">.*?<\/pre>,<p><a class="pgc-link".*?<\/a><\/p>';
        lib_func_grab::content_filter($html, $parrent);
        
        //过滤
        lib_func_grab::content_filter_tag($html);
        lib_func_grab::src_deal($html, $host);
        $content = trim($html);
        
        //内容获取评论
        $comment = array(
            'list'=>array(),
            'dateline'=>array(),
            'author'=>array(),
        );
        if(lib_base::settings('is_grab_dateline')){
            $comment['dateline'][0] = date('Y-m-d H:i:s', $json['data']['publish_time']);
        }
        if(lib_base::settings('is_grab_author')){
            $comment['author'][0] = $json['data']['media_user']['screen_name'];
        }
        
        if(lib_base::settings('is_grab_comment')){
            lib_func_grab::comment($grab, $comment);
        }
        
        if(! $title){
            $notice = '&#33719;&#21462;&#26631;&#39064;&#22833;&#36133;&#65306;'.$grab['detail_url'];
            lib_base::back_html($notice, 1);
            return FALSE;
        }
        
        if(! $content){
            $notice = '&#33719;&#21462;&#20869;&#23481;&#22833;&#36133;&#65306;'.$grab['detail_url'];
            lib_base::back_html($notice, 1);
            return FALSE;
        }
        
        lib_func_grab::grab_save($grab, $title, $content, array(), $comment, $grab['source'][$grab['key']]);
    }
    
    function detail_deal_toutiao(& $html)
    {
        $html = html_entity_decode($html);
        
        if(mb_strlen($html) < 200 && strpos($html, '<img') === FALSE){
            $html = '';
        }else if(mb_strlen($html) < 200 && strpos($html, '<img') === FALSE){
            $html = '';
        }else{
            content_filter_toutiao($html);
        }
    }
    
    function content_filter_toutiao(& $html)
    {
        $filter = ' inline="0", img_width=".*?", img_height=".*?"';
        $filter_arr = explode(',', $filter);
        foreach ($filter_arr as $key_f => $value_f)
        {
            if(stripos($value_f, '.*?') !== FALSE)
            {
                $pattern = '/'.$value_f.'/i';
                preg_match_all($pattern, $html, $result);
                if($result){
                    foreach($result[0] as $value){
                        $html = str_replace($value, '', $html);
                    }
                }
            }
            else
            {
                $html = str_replace($value_f, '', $html);
            }
        }
    }
}

if(! function_exists('comment_start_toutiao'))
{
    function comment_start_toutiao($grab, & $comment)
    {
        $author = array();
        $dateline = array();
        $list = array();
        
        $url = $grab['detail_url'];
        if(strpos($url, '/a') !== FALSE){
            $param = explode('/a', $url);
            $id = trim($param[1], '/');
        }else if(strpos($url, '/i') !== FALSE){
            $param = explode('/i', $url);
            $id = trim($param[1], '/');
        }
        
        $comment_url = 'https://www.toutiao.com/api/comment/list/?group_id='.$id.'&item_id='.$id.'&offset=0&count=20';
        
        $json = lib_func_grab::get($comment_url);
        if(! $json){
            return $list;
        }
        
        $comment_list = json_decode($json, TRUE);
        
        if(! $comment_list || ! $comment_list['data']['comments']){
            return $list;
        }
        
        $num = 1;
        foreach($comment_list['data']['comments'] as $value)
        {
            $author[$num] = $value['user']['name'];
            $dateline[$num] = date('Y-m-d H:i:s', $value['create_time']);
            $list[$num] = trim($value['text']);
            
            $num++;
        }
        
        if(lib_base::settings('is_grab_dateline')){
            $comment['dateline'] = array_merge($comment['dateline'], $dateline);
        }
        if(lib_base::settings('is_grab_author')){
            $comment['author'] = array_merge($comment['author'], $author);
        }
        
        $comment['list'] = $list;
    }
}

