<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once libfile('lib/base', 'plugin/'.PLUGIN_NAME);
require_once libfile('lib/func', 'plugin/'.PLUGIN_NAME);

/**
 * lib_admin Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_admin
{
    protected static $allow_actions = array(
        'index'=>array('class'=>'lib_admin_grab','function'=>'index'),
        
        'grab_list'=>array('class'=>'lib_admin_grab','function'=>'grab_list'),
        'grab_thread_detail'=>array('class'=>'lib_admin_grab','function'=>'grab_thread_detail'),
        'grab_list_local'=>array('class'=>'lib_admin_grab','function'=>'grab_list_local'),
        'grab_local_del'=>array('class'=>'lib_admin_grab','function'=>'grab_local_del'),
        'grab_local_verify'=>array('class'=>'lib_admin_grab','function'=>'grab_local_verify'),
        'grab_local_edit'=>array('class'=>'lib_admin_grab','function'=>'grab_local_edit'),
        'grab_local_edited'=>array('class'=>'lib_admin_grab','function'=>'grab_local_edited'),
        'grab_article'=>array('class'=>'lib_admin_grab','function'=>'grab_article'),
        'grab_articled'=>array('class'=>'lib_admin_grab','function'=>'grab_articled'),
        'grab_grab_list'=>array('class'=>'lib_admin_local','function'=>'grab_grab_list'),
        'grab_grab_del'=>array('class'=>'lib_admin_local','function'=>'grab_grab_del'),
        'grab_grab_del_all'=>array('class'=>'lib_admin_local','function'=>'grab_grab_del_all'),
        'grab_document'=>array('class'=>'lib_admin_grab','function'=>'grab_document'),
        
        'nav_list'=>array('class'=>'lib_admin_nav','function'=>'nav_list'),
        'nav_add'=>array('class'=>'lib_admin_nav','function'=>'nav_add'),
        'nav_added'=>array('class'=>'lib_admin_nav','function'=>'nav_added'),
        'nav_edit'=>array('class'=>'lib_admin_nav','function'=>'nav_edit'),
        'nav_edited'=>array('class'=>'lib_admin_nav','function'=>'nav_edited'),
        'nav_grab_page'=>array('class'=>'lib_admin_nav','function'=>'nav_grab_page'),
        'threadclass_list'=>array('class'=>'lib_admin_nav','function'=>'threadclass_list'),
        'nav_del'=>array('class'=>'lib_admin_nav','function'=>'nav_del'),
        'nav_import'=>array('class'=>'lib_admin_nav','function'=>'nav_import'),
        'nav_cookie'=>array('class'=>'lib_admin_nav','function'=>'nav_cookie'),
        'nav_cookied'=>array('class'=>'lib_admin_nav','function'=>'nav_cookied'),

        'vest_list'=>array('class'=>'lib_admin_vest','function'=>'vest_list'),
        'vest_add'=>array('class'=>'lib_admin_vest','function'=>'vest_add'),
        'vest_added'=>array('class'=>'lib_admin_vest','function'=>'vest_added'),
        'vest_del'=>array('class'=>'lib_admin_vest','function'=>'vest_del'),
        'vest_empty'=>array('class'=>'lib_admin_vest','function'=>'vest_empty'),
        
        'keyword_list'=>array('class'=>'lib_admin_keyword','function'=>'keyword_list'),
        'keyword_add'=>array('class'=>'lib_admin_keyword','function'=>'keyword_add'),
        'keyword_added'=>array('class'=>'lib_admin_keyword','function'=>'keyword_added'),
        'keyword_edit'=>array('class'=>'lib_admin_keyword','function'=>'keyword_edit'),
        'keyword_edited'=>array('class'=>'lib_admin_keyword','function'=>'keyword_edited'),
        'keyword_del'=>array('class'=>'lib_admin_keyword','function'=>'keyword_del'),
        'keyword_empty'=>array('class'=>'lib_admin_keyword','function'=>'keyword_empty'),
        'keyword_import'=>array('class'=>'lib_admin_keyword','function'=>'keyword_import'),
        'keyword_imported'=>array('class'=>'lib_admin_keyword','function'=>'keyword_imported'),
        'keyword_export'=>array('class'=>'lib_admin_keyword','function'=>'keyword_export'),
    );
    
    public function run()
    {
//         ini_set("display_errors", "On");
//         error_reporting(E_ALL);
        
        global $_G;
        
        $action = $_GET['act'] ? $_GET['act'] : 'index';

        if(! isset(self::$allow_actions[$action])){
            lib_base::js_back_show(lib_base::lang('noaction'));
        }

//         if(FORMHASH != $_GET['myformhash'] && $action != 'index'){
//             showmessage(lib_base::lang('noformhash'));
//         }

        if(! $_G['adminid']){
            lib_base::js_back_window(lib_base::lang('nopermission'));
        }

        if(CHARSET == 'gbk' && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $_GET = lib_base::convert_utf8_to_gbk($_GET);
        }
        
        $op = self::$allow_actions[$action];

        require_once libfile(str_replace('lib_', 'lib/', $op['class']), 'plugin/'.PLUGIN_NAME);

        $class = $op['class'];
        $class = new $class();
        $function = $op['function'];
        $class->$function();
    }
}