<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_index_grab Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_index_grab
{
    public function __construct()
    {
        set_time_limit(0);
        
        require_once libfile('lib/func_grab', 'plugin/'.PLUGIN_NAME);
    }
    
    public function __destruct()
    {
        if(gettype(self::$fp) == 'resource'){
            flock(self::$fp , LOCK_UN);
            fclose(self::$fp);
        }
    }
    
    protected static $table = 'admin_grab';
    protected static $table_nav = 'admin_nav';
    protected static $table_vest = 'admin_vest';
    protected static $fp = '';

    //本地发布
    public static function cron_minute()
    {
        global $_G;
        
        $settings = lib_base::settings();
        
        loadcache(PLUGIN_NAME);
        
        $result = $_G['cache'][PLUGIN_NAME];

        $time = TIMESTAMP;

        //删除缓存图片
        $cron_pic_del_time = $result['cron_pic_del_time'] ? $time - $result['cron_pic_del_time'] : $time;
        if($cron_pic_del_time >= 86400){
            $result['cron_pic_del_time'] = $time;
            self::pic_cache_delete();
        }

        if($settings['is_auto_send_thread'])
        {            
            //采集列表
            self::grab_list();
            
            //采集详情
            self::grab_detail();

            //发布本地信息
            self::thread_send();
        }
        
        savecache(PLUGIN_NAME, $result);
        
        lib_base::back_html('&#35745;&#21010;&#20219;&#21153;&#25191;&#34892;&#25104;&#21151;');
    }
    
    //帖子发布
    public static function thread_send()
    {
        global $_G;
        
        $grab_id = $_GET['ids'] ? intval($_GET['ids']) : intval($_GET['grab_id']);
        $send_all = intval($_GET['send_all']);
        
        //加锁
        $filename = DISCUZ_ROOT.'data/plugindata/'.PLUGIN_NAME.'_send_lock.log';
        self::$fp = fopen($filename, 'w');
        chmod($filename, 0777);
        if(! flock(self::$fp , LOCK_EX)){
            exit('grab is locked');
        }

        require_once libfile('function/forum');
        require_once libfile('function/post');
        require_once libfile('function/editor');
        if(! defined('DISCUZ_VERSION')) {
            require_once './source/discuz_version.php';
        }
        
        $settings = lib_base::settings();
        
        //马甲用户
        $vest_all = lib_base::table(self::$table_vest)->vest_list_all();
        if(! $vest_all){
            if($grab_id){
                lib_base::back_text('&#26410;&#35774;&#32622;&#39532;&#30002;&#29992;&#25143;');
            }else if($send_all){
                lib_base::js_back_show('&#26410;&#35774;&#32622;&#39532;&#30002;&#29992;&#25143;');
            }else{
                lib_base::back_html('&#26410;&#35774;&#32622;&#39532;&#30002;&#29992;&#25143;');
                return;
            }
        }
        $vest = array();
        foreach($vest_all as $value){
            $vest[$value['fid']][] = array(
                'uid'=>$value['uid'],
                'username'=>$value['username']
            );
        }
        
        $local_list = array();
        if($grab_id){
            $local_list[] = lib_base::table(self::$table)->fetch($grab_id);
        }else{
            $settings['send_thread_limit'] = intval($settings['send_thread_limit']);
            ! $settings['send_thread_limit'] && $settings['send_thread_limit'] = 1;
            $limit = $settings['send_thread_limit'] > 5 ? 5 : $settings['send_thread_limit'];
            $local_list = lib_base::table(self::$table)->grab_local_latest($limit);
        }
        
        if(! $local_list){
            if($grab_id){
                lib_base::back_text('&#24050;&#26080;&#26410;&#21457;&#24067;&#30340;&#26412;&#22320;&#25968;&#25454;');
            }else if($send_all){
                lib_base::js_back_show('&#24050;&#26080;&#26410;&#21457;&#24067;&#30340;&#26412;&#22320;&#25968;&#25454;');
            }else{
                lib_base::back_html('&#24050;&#26080;&#26410;&#21457;&#24067;&#30340;&#26412;&#22320;&#25968;&#25454;');
                return;
            }
        }

        //发帖
        foreach($local_list as $value)
        {
            $fid = $value['fid'];
            $vest_list = $vest[$fid] ? $vest[$fid] : $vest[0];
            if($vest_list){
                if($value['send_type'] == 2){
                    $result = lib_base::table(self::$table)->grab_to_portal($value, $vest_list, $settings, $vest[0]);
                }else{
                    $result = lib_base::table(self::$table)->grab_to_thread($value, $vest_list, $settings, $vest[0]);
                }
            }
        }

        //解锁
        flock(self::$fp , LOCK_UN);
        fclose(self::$fp);
        
        if($grab_id){
            lib_base::back_json(array('callreload'=>1));
        }else if($send_all){
            $back_url = lib_base::url('thread_send').'&send_all=1';
            lib_base::back_url(date('Y-m-d H:i:s').'&#26412;&#22320;&#25968;&#25454;&#21457;&#24067;&#25104;&#21151;&#65292;&#36339;&#36716;&#20013;&#46;&#46;&#46;', $back_url);
        }else{
            lib_base::back_html('&#26412;&#22320;&#25968;&#25454;&#21457;&#24067;&#25104;&#21151;');
        }
    }
    
    //删除缓存图片每
    public static function pic_cache_delete()
    {
        $local_path_grab = DISCUZ_ROOT.'data/plugindata/'.PLUGIN_NAME.'/';
        
        lib_base::table(self::$table)->removeDir($local_path_grab, 1);
        
        lib_base::back_html('&#26412;&#22320;&#22270;&#29255;&#32531;&#23384;&#25968;&#25454;&#28165;&#38500;&#25104;&#21151;');
    }
    
    /**
     * 采集列表
     *
     * @access public
     * @param
     * @return
     */
    public static function grab_list()
    {
        header('Connection:Keep-Alive');
        header('Proxy-Connection:Keep-Alive');

        $nav_id = intval($_GET['nav_id']);
        $page = $nav_id ? $_GET['page'] : 1;
        
        if(! $page){
            lib_base::js_back_show('&#24050;&#26080;&#37319;&#38598;&#20998;&#39029;&#65292;&#32456;&#27490;&#37319;&#38598;');
        }
        
        $pages = array();
        if(strpos($page, '-') !== FALSE){
            $pages = explode('-', $page);
            if($pages[1] < $pages[0]){
                lib_base::js_back_show('&#37319;&#38598;&#32456;&#27490;');
            }
            
            $page = $pages[1];
        }
    
        if($nav_id){
            $nav = lib_base::table(self::$table_nav)->fetch($nav_id);
        }else{
            $nav = lib_base::table(self::$table_nav)->nav_grab_get();
        }

        if(! $nav){
            if($nav_id){
                lib_base::js_back_show('&#33719;&#21462;&#37319;&#38598;&#20851;&#38190;&#35789;&#20449;&#24687;&#22833;&#36133;');
            }else{
                lib_base::back_html('&#26080;&#38656;&#35201;&#37319;&#38598;&#30340;&#20851;&#38190;&#35789;');
                return;
            }
        }

        $result = lib_base::table(self::$table_nav)->grab_nav_setting_check($nav);
        if($result['state'] != 0){
            //检测失败删除采集分类
            lib_base::table(self::$table_nav)->delete($nav['id']);
            if($nav_id){
                lib_base::js_back_show($result['result']);
            }else{
                lib_base::back_html($result['result']);
                return;
            }
        }

        $url = $nav['source'];
        $ruleid = 0;
        
        include libfile('lib/rule', 'plugin/'.PLUGIN_NAME);

        $url_parse = parse_url($url);
        if($url_parse['host']){
            $rule_file = DISCUZ_ROOT.'source/plugin/'.PLUGIN_NAME.'/rule/'.$url_parse['host'].'.php';
            if(file_exists($rule_file)){
                include $rule_file;
            }
        }

        $url = lib_func_grab::page_deal($page, $nav, $rule[$ruleid]['func']['page_deal']);

        lib_base::back_html('&#20998;&#31867;&#37319;&#38598;&#24320;&#22987;'.$page.'&#39029;'.$url);

        $grab = array_merge($nav, array('url'=>$url,'rule'=>$rule[$ruleid]));

        if(! lib_func_grab::grab_list($grab)){
            if($nav_id){
                lib_base::js_back_show('&#37319;&#38598;&#32456;&#27490;');
            }else{
                lib_base::back_html('&#37319;&#38598;&#32456;&#27490;');
                return;
            }
        }
    
        if($nav_id)
        {
            $page--;
            
            if($page <= 0){
                lib_base::js_back_show('&#37319;&#38598;&#32456;&#27490;');
            }
            
            if($pages){
                $page = $pages[0].'-'.$page;
            }
            
            $submit = lib_base::url('grab_list').'&nav_id='.$nav_id.'&page='.$page;
            
            lib_base::back_url('&#37319;&#38598;&#25104;&#21151;&#65292;&#36339;&#36716;&#21040;&#37319;&#38598;&#19979;&#19968;&#39029;', $submit, 10);
        }
    }
    
    /**
     * 采集详情
     *
     * @access public
     * @param
     * @return
     */
    public static function grab_detail()
    {
        $auto = intval($_GET['auto']);
        $local_id = intval($_GET['local_id']);
        
        //加锁
        $filename = DISCUZ_ROOT.'data/plugindata/'.PLUGIN_NAME.'_send_lock.log';
        self::$fp = fopen($filename, 'w');
        chmod($filename, 0777);
        if(! flock(self::$fp , LOCK_EX)){
            exit('grab is locked');
        }
    
        ob_start();
    
        $result = lib_func_grab::grab_detail_save($local_id);
        
        //解锁
        flock(self::$fp , LOCK_UN);
        fclose(self::$fp);
        
        if($result === FALSE){
            return;
        }
    
        $auto && lib_base::back_html('&#37319;&#38598;&#36339;&#36716;&#20013;&#46;&#46;&#46;');
    
        $html = ob_get_contents();
    
        ob_end_clean();

        if($auto){
            $url = lib_base::url('grab_detail').'&auto=1';
            lib_base::js_back_url($html, $url, 5);
        }else if($local_id){
            lib_base::js_back_show($html.'<script>setTimeout("parent.location.reload();", 3000)</script>');
        }else{
            lib_base::back_html($html);
        }
    }
}