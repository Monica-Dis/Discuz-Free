<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_admin_grab Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_admin_local
{
    protected static $limit = 10;
    protected static $limit_max = 900;
    protected static $table = 'admin_local';
    
    public static function grab_grab_list()
    {
        $escape['search'] = lib_base::escape($_GET['search']);
        $escape['field'] = lib_base::escape($_GET['field']);
    
        $page = $_GET['page'] ? intval($_GET['page']) : 1;
        $limit = $_GET['limit'] ? ($_GET['limit'] > self::$limit_max ? self::$limit_max : intval($_GET['limit'])) : self::$limit;
    
        $fields = array('id'=>'ID','title'=>'&#37319;&#38598;&#25991;&#31456;&#26631;&#39064;','source'=>'&#37319;&#38598;&#25991;&#31456;&#38142;&#25509;','dateline'=>'&#37319;&#38598;&#25991;&#31456;&#26102;&#38388;');
        $tool = array(
            '<a class="layui-btn" href="'.lib_base::url('grab_detail').'&auto=1" target="_blank">&#20840;&#37096;&#37319;&#38598;</a>',
            '<a class="layui-btn" onclick="Func.post({url:\''.lib_base::admin_url('grab_grab_del_all').'\',confirm:1})">&#28165;&#31354;&#25968;&#25454;</a>',
            '<a class="layui-btn" onclick="Func.post({url:\''.lib_base::admin_url('grab_grab_del').'\'})">&#25209;&#37327;&#21024;&#38500;</a>',
        );
        $submit = lib_base::admin_url('grab_grab_list').'&limit='.$limit;
    
        $fields_str = lib_func::field_str($fields);
        $offset = ($page - 1) * $limit;
    
        $where = '';
        if($escape['search'] && $escape['field'] && array_key_exists($escape['field'], $fields)){
            $where .= "WHERE ".$escape['field']." = '".$escape['search']."'";
            $submit .= '&search='.$escape['search'].'&field='.$escape['field'];
        }
    
        $list = lib_base::table(self::$table)->grab_grab_list($fields_str, $offset, $limit, $where);
    
        foreach($list as & $value){
            $value['title'] = '<a href="'.$value['source'].'" target="_blank">'.$value['title'].'</a>';
            $value['source'] = '<a href="'.$value['source'].'" target="_blank">'.$value['source'].'</a>';
        }
    
        $count = lib_base::table(self::$table)->grab_grab_count($where);
        $page_count = ceil($count / $limit);
        $paging = lib_func::paging($page_count, $page, $submit.'&page=', $limit, $count);
        $search = lib_func::field_option(array('id'=>'ID','title'=>'&#37319;&#38598;&#25991;&#31456;&#26631;&#39064;','source'=>'&#37319;&#38598;&#25991;&#31456;&#38142;&#25509;'), $escape['field']);
    
        $formate['batch'] = 1;
        $formate['time'] = array('dateline');
        $formate['op'] = array(
            array('url'=>lib_base::admin_url('grab_grab_del'),'name'=>lib_base::lang('delete'),type=>3,'confirm'=>FALSE),
            array('url'=>lib_base::url('grab_detail').'&local_id=','name'=>'&#37319;&#38598;'),
        );
        
        $fields = lib_func::create_table($list, $fields, $formate);
    
        $admin_nav = 1;
        
        include lib_base::template('admin');
    }
    
    public static function grab_grab_del()
    {
        $ids = $_GET['batch'] ? $_GET['batch'] : intval($_GET['ids']);
    
        if(! $ids){
            lib_base::back_text(lib_base::lang('noselect'));
        }
    
        lib_base::table(self::$table)->delete($ids);
    
        lib_base::back_json(array('reload'=>1));
    }
    
    public static function grab_grab_del_all()
    {
        lib_base::table(self::$table)->grab_local_delete_all();
    
        lib_base::back_json(array('reload'=>1));
    }
}