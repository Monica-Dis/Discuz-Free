<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_func_grab Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_func_grab
{   
    //截取规则id
    public static $intercept_rule_id = 0;
    //是否格式化
    public static $is_replace = 1;
    
    //采集重复中断
    public static $repeat_count = 0;
    public static $repeat_limit = 5;
    public static $grab_new = 0;
    
    public static $curl_info = '';
    
    //按月计算
    public static $grab_time_count = 60;
    
    public static $timeout = 10;
    public static $headers = array(
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
        //'Accept-Encoding: gzip, deflate',
        'Accept-Language: zh-CN,zh;q=0.9',
        'Cache-Control: no-cache',
        'Connection: keep-alive',
        'Pragma: no-cache',
        'Upgrade-Insecure-Requests: 1',
     );

    public static $userAgent = array(
        'Mozilla/5.0(Macintosh;U;IntelMacOSX10_6_8;en-us)AppleWebKit/534.50(KHTML,likeGecko)Version/5.1Safari/534.50',
        'Mozilla/5.0(Windows;U;WindowsNT6.1;en-us)AppleWebKit/534.50(KHTML,likeGecko)Version/5.1Safari/534.50',
        'Mozilla/5.0(Macintosh;IntelMacOSX10.6;rv:2.0.1)Gecko/20100101Firefox/4.0.1',
        'Mozilla/5.0(WindowsNT6.1;rv:2.0.1)Gecko/20100101Firefox/4.0.1',
        'Opera/9.80(Macintosh;IntelMacOSX10.6.8;U;en)Presto/2.8.131Version/11.11',
        'Opera/9.80(WindowsNT6.1;U;en)Presto/2.8.131Version/11.11',
        'Mozilla/5.0(Macintosh;IntelMacOSX10_7_0)AppleWebKit/535.11(KHTML,likeGecko)Chrome/17.0.963.56Safari/535.11',
        'Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1;Maxthon2.0)',
        'Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1;TencentTraveler4.0)',
        'Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1)',
        'Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1;TheWorld)',
        'Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1;Trident/4.0;SE2.XMetaSr1.0;SE2.XMetaSr1.0;.NETCLR2.0.50727;SE2.XMetaSr1.0)',
        'Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1;360SE)',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
    );
    
    public static function get_rand_ip()
    {
        $ip_long = array(
            array('607649792', '608174079'), // 36.56.0.0-36.63.255.255
            array('1038614528', '1039007743'), // 61.232.0.0-61.237.255.255
            array('1783627776', '1784676351'), // 106.80.0.0-106.95.255.255
            array('2035023872', '2035154943'), // 121.76.0.0-121.77.255.255
            array('2078801920', '2079064063'), // 123.232.0.0-123.235.255.255
            array('-1950089216', '-1948778497'), // 139.196.0.0-139.215.255.255
            array('-1425539072', '-1425014785'), // 171.8.0.0-171.15.255.255
            array('-1236271104', '-1235419137'), // 182.80.0.0-182.92.255.255
            array('-770113536', '-768606209'), // 210.25.0.0-210.47.255.255
            array('-569376768', '-564133889'), // 222.16.0.0-222.95.255.255
        );
        
        $rand_key = mt_rand(0, 9);
    
        return $ip = long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
    }

    public static function get($url, $referer = '', $host = '', $cookie = '', $post = '', $headers = '', $is_replace = 1)
    {
        if(! function_exists('curl_init')){
            exit('Please install curl extension.');
        }

        $ip = self::get_rand_ip();
    
        $header = array(
            'Accept-Encoding: gzip, deflate',
            'User-Agent: '.self::$userAgent[array_rand(self::$userAgent)],
            'CLIENT-IP: '.$ip,
            'X-FORWARDED-FOR: '.$ip,
        );
        //$referer && $header[] = 'Referer: '.$referer;
        //$cookie && $header[] = 'Cookie: '.$cookie;
        //$host && $header[] = 'Host: '.$host;
        $header = array_merge(self::$headers, $header);
        
        if($headers){
            $header = array_merge($header, $headers);
        }

        $ch = curl_init();
  
        curl_setopt($ch, CURLOPT_URL, $url);
    
        //是否将头文件的信息作为数据流输出(HEADER信息),这里保留报文
        //curl_setopt($ch, CURLOPT_HEADER, TRUE);
        //获取的信息以文件流的形式返回，而不是直接输出。
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE) ;
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, TRUE) ;
        //启用时会将服务器服务器返回的“Location:”放在header中递归的返回给服务器
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    
        curl_setopt($ch, CURLOPT_REFERER, $referer);
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');
    
        //设置连接等待时间,0不等待
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, self::$timeout);
        //设置curl允许执行的最长秒数
        curl_setopt($ch, CURLOPT_TIMEOUT, self::$timeout);
    
        if(strpos($url, 'https') !== FALSE){
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        }
        
        if($post){
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
    
        $data = curl_exec($ch);
        $error = curl_errno($ch);

        self::$curl_info = curl_getinfo($ch);

        curl_close($ch);

        $error != 0 && $data = '';

        if(self::$is_replace == 1){
            $data = preg_replace("'([\r\n\f])+'", '', $data);
        }

        return $data;
    }
    
    public static function get2($url, $referer = '', $host = '', $cookie = '', $post = '')
    {
        $ip = self::get_rand_ip();

        $urls = parse_url($url);

        $post && $post = http_build_query($post);
        
        $host = $urls['host'];
        $urls['scheme'] == 'https' && $host = 'ssl://'.$host;
        $port = $urls['scheme'] == 'https' ? 443 : 80;
        $path = $urls['path'];
        isset($urls['query']) && $path .= '?'.$urls['query'];
        ! isset($urls['query']) && $urls['query'] = '';

        $fp = fsockopen($host, $port, $errno, $errstr, self::$timeout);

        $html = '';
    
        if(! $fp){
            echo "$errstr ($errno)\n";
            exit;
        }

        $end = "\r\n";
        $header = ($post ? 'POST' : 'GET')." $path HTTP/1.0$end";
        $header .= "Accept: text/javascript, text/html, application/xml, text/xml, */*$end";
        $header .= "Accept-Language: zh-CN,zh;q=0.9$end";
        $header .= "User-Agent: ".self::$userAgent[array_rand(self::$userAgent)]."$end";
        $header .= "Referer: $referer$end";
        $header .= "CLIENT-IP: $ip$end";
        $header .= "X-FORWARDED-FOR: $ip$end";
        $header .= "Content-Type: application/x-www-form-urlencoded$end";
        $header .= "Cookie: $cookie$end";
        $header .= "Host: ".$urls['host']."$end";
        $header .= "Content-Length: ".strlen($post)."\r\n";
        $header .= "Connection: close\r\n\r\n";
        $header .= $post."\r\n\r\n";
 
        fwrite($fp, $header);

        //$headers = '';
        while($header = trim(fgets($fp, 4096))){
            if(stripos($header, 'location') !== FALSE){
                $location = trim(substr($header, stripos($header, ':') + 1));
                return self::get($location, $referer, $host, $cookie);
            }
            //$headers .= $header;
        }
    
        $body = '';
        while(! feof($fp)){
            $body .= fgets($fp, 4096);
        }

        fclose($fp);

        if(self::$is_replace == 1){
            $body = preg_replace("'([\r\n\f])+'", '', $body);
        }

        return $body;
    }
    
    public static function get3($url, $referer = '', $host = '', $cookie = '')
    {
        $ip = self::get_rand_ip();
    
        $options = array(
            'http'=>array(
                'method'=>'GET',
                'timeout'=>self::$timeout,
                'header'=>
                "Accept: */*\r\n".
                //"Accept-Encoding: gzip,deflate".
                "Accept-Language: en-US,en;q=0.8,zh-TW;q=0.6,zh;q=0.4\r\n".
                "Connection: keep-alive\r\n".
                "Content-Type: application/x-www-form-urlencoded; charset=UTF-8\r\n".
                "User-Agent: ".self::$userAgent[array_rand(self::$userAgent)]."\r\n".
                "Cookie: ".$cookie."\r\n".
                "Host: ".$host."\r\n".
                "Referer: ".$referer."\r\n".
                "CLIENT-IP: ".$ip."\r\n".
                "X-FORWARDED-FOR: ".$ip."\r\n"
            )
        );
    
        $html = file_get_contents($url, FALSE, stream_context_create($options));

        if(self::$is_replace == 1){
            $html = preg_replace("'([\r\n\f])+'", '', $html);
        }
    
        return $html;
    }
    
    public static function attach_get($url, $referer = '', $host = '', $cookie = '', $post = '', $headers = '')
    {
        if(! function_exists('curl_init')){
            exit('Please install curl extension.');
        }

        $url = urldecode(urldecode(trim($url)));
        $url = str_replace('&amp;', '&', $url);

        $ip = self::get_rand_ip();
        
        $header = array(
            'Accept-Encoding: gzip, deflate',
            'User-Agent: '.self::$userAgent[array_rand(self::$userAgent)],
            'CLIENT-IP: '.$ip,
            'X-FORWARDED-FOR: '.$ip,
        );
        
        //$referer && $header[] = 'Referer: '.$referer;
        //$host && $header[] = 'Host: '.$host;
        //$cookie && $header[] = 'cookie: '.$cookie;
        $header = array_merge(self::$headers, $header);
        
        if($headers){
            $header = array_merge($header, $headers);
        }

        $ch = curl_init();
         
        curl_setopt($ch, CURLOPT_URL, $url);
    
        //是否将头文件的信息作为数据流输出(HEADER信息),这里保留报文
        //curl_setopt($ch, CURLOPT_HEADER, TRUE);
        //获取的信息以文件流的形式返回，而不是直接输出。
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE) ;
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, TRUE) ;
        //启用时会将服务器服务器返回的“Location:”放在header中递归的返回给服务器
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    
        curl_setopt($ch, CURLOPT_REFERER, $referer);
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');
    
        //设置连接等待时间,0不等待
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, self::$timeout * 10);
        //设置curl允许执行的最长秒数
        curl_setopt($ch, CURLOPT_TIMEOUT, self::$timeout * 10);
    
        if(strpos($url, 'https') !== FALSE){
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        }
        
        if($post){
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
    
        $data = curl_exec($ch);
        $error = curl_errno($ch);

        curl_close($ch);
    
        $error != 0 && $data = '';
    
        return $data;
    }
    
    //获取网站编码
    public static function getCharset($html)
    {
        //首先从html获取编码
        preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", $html, $result);

        $charset = $result[1] ? strtoupper($result[1]) : '';
        
        if(in_array($charset, lib_base::$encode_list)){
            return $charset;
        }
        
        $encoded = mb_detect_encoding($html, lib_base::$encode_list);
        if( ! $encoded){
            return false;
        }

        return $encoded;
    }
    
    /**
     * 采集列表页
     *
     * @access public
     * @param
     * @return json
     */
    public static function grab_list(& $grab)
    {
        //嵌入点，此函数可替代采集内容
        if(isset($grab['rule']['func']['list'])){
            if(function_exists($grab['rule']['func']['list'])){
                return $grab['rule']['func']['list']($grab);
            }
        }
        
        //HOST
        $urls = parse_url(trim($grab['url']));
        $grab['host'] = $urls['scheme'].'://'.$urls['host'];

        $cookie = $grab['cookie'];
        
        $html = self::get($grab['url'], $grab['host'], $urls['host'], $cookie);
        $grab['html'] = $html;

        if(! $html){
            $notice = '&#33719;&#21462;&#21015;&#34920;&#22833;&#36133;&#65306;'.$grab['url'];
            lib_base::back_html($notice, 1);

            //失败延长计划任务
            self::nav_crontime_update($grab['id'], $grab['crontime']);
            
            return FALSE;
        }

        $charset = self::getCharset($html);
        if(! $charset){
            $notice = 'Unfetched Web Code '.$grab['url'];
            lib_base::back_html($notice, 1);
        }
        lib_base::$grab_charset = $charset;

        if($urls['host']){
            $rule_file = DISCUZ_ROOT.'source/plugin/'.PLUGIN_NAME.'/rule/'.$urls['host'].'.php';
            if(file_exists($rule_file)){
                include $rule_file;
            }
        }

        //嵌入点,此函数可取代所有采集流程
        if(isset($grab['rule']['func']['list_start']) && $grab['rule']['func']['list_start']){
            if(function_exists($grab['rule']['func']['list_start'])){
                $grab['html'] = $html;
                return $grab['rule']['func']['list_start']($grab);
            }
        }

        $notice = '&#21015;&#34920;&#25130;&#21462;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['url'];
        if(! self::html_intercept($html, $grab['rule']['list_intercept_start'], 'start', $notice)){
            lib_base::back_html($notice, 1);

            //失败延长计划任务
            self::nav_crontime_update($grab['id'], $grab['crontime']);
            
            return FALSE;
        }

        /* 过滤内容  */
        if($grab['rule']['list_intercept_filter']){
            self::content_filter($html, $grab['rule']['list_intercept_filter']);
        }
    
        $notice = '&#21015;&#34920;&#25130;&#21462;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['url'];
        if(! self::html_intercept($html, $grab['rule']['list_intercept_end'], 'end', $notice)){
            lib_base::back_html($notice, 1);

            //失败延长计划任务
            self::nav_crontime_update($grab['id'], $grab['crontime']);
            
            return FALSE;
        }

        //嵌入点,此函数可取代截取后的采集流程
        if(isset($grab['rule']['func']['list_middle']) && $grab['rule']['func']['list_middle']){
            if(function_exists($grab['rule']['func']['list_middle'])){
                $grab['html'] = $html;
                return $grab['rule']['func']['list_middle']($grab);
            }
        }

        //匹配列表元素
        preg_match_all('/'.$grab['rule']['list_list'].'/is', $html, $list);
        if(! $list[1]){
            $notice = '&#21015;&#34920;&#21305;&#37197;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['url'];
            lib_base::back_html($notice, 1);

            //失败延长计划任务
            self::nav_crontime_update($grab['id'], $grab['crontime']);

            return FALSE;
        }

        //匹配标题、源链接
        $grab['title']  = array();
        $grab['source'] = array();
        foreach($list[1] as $key => $value)
        {
            //匹配标题
            preg_match('/'.$grab['rule']['list_title'].'/is', $value, $temp);
            if($temp){
                $grab['title'][$key] = strip_tags(trim($temp[1]));
                if(isset($grab['rule']['list_title_filter'])){
                    self::content_filter($grab['title'][$key], $grab['rule']['list_title_filter']);
                }
            }

            //匹配源链接
            preg_match('/'.$grab['rule']['list_source'].'/is', $value, $temp);
            if($temp){
                $grab['source'][$key] = str_replace('&amp;', '&', trim($temp[1]));
                if($grab['source'][$key] && stripos($grab['source'][$key], 'http') !== 0){
                    if(strpos($grab['source'][$key], '//') === 0){
                        $grab['source'][$key] = $urls['scheme'].':'.$grab['source'][$key];
                    }else{
                        if(strpos($grab['source'][$key], '/') === 0){
                            $grab['source'][$key] = $grab['host'].$grab['source'][$key];
                        }else{
                            $grab['source'][$key] = $grab['host'].'/'.$grab['source'][$key];
                        }
                    }
                }
            }
        }

        if(! $grab['title']){
            $notice = '&#21015;&#34920;&#21305;&#37197;&#26631;&#39064;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['url'];
            lib_base::back_html($notice, 1);

            //失败延长计划任务
            self::nav_crontime_update($grab['id'], $grab['crontime']);

            return FALSE;
        }
        
        if(! $grab['source']){
            $notice = '&#21015;&#34920;&#21305;&#37197;&#26469;&#28304;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['url'];
            lib_base::back_html($notice, 1);

            //失败延长计划任务
            self::nav_crontime_update($grab['id'], $grab['crontime']);

            return FALSE;
        }
    
        //嵌入点,此函数可处理列表信息
        if(isset($grab['rule']['func']['list_deal']) && $grab['rule']['func']['list_deal']){
            if(function_exists($grab['rule']['func']['list_deal'])){
                $grab['rule']['func']['list_deal']($grab);
            }
        }

        //嵌入点,此函数可获取匹配列表信息
        if(isset($grab['rule']['func']['list_end']) && $grab['rule']['func']['list_end']){
            if(function_exists($grab['rule']['func']['list_end'])){
                $grab['html'] = $html;
                return $grab['rule']['func']['list_end']($grab);
            }
        }
    
//         print_r($grab);exit;
    
        self::$repeat_count = 0;
    
        //采集详细页
        foreach($grab['source'] as $key => $source)
        {
            $identify = self::save_identify($source);
            
            //update
            $grab_detail = self::grab_detail_by_identify($identify);
            if($grab_detail && (TIMESTAMP - $grab_detail['dateline'] < 3600))
            {
                $notice = '&#20869;&#23481;&#37319;&#38598;&#37325;&#22797;&#65306;'.$source;
                lib_base::back_html($notice, 1);
                self::$repeat_count++;
                
                if(self::$repeat_count >= self::$repeat_limit){
                    $notice = sprintf('&#37319;&#38598;&#20869;&#23481;&#37325;&#22797;&#27425;&#25968;&#36229;&#36807; %d &#27425;&#65292;&#20013;&#26029;&#37319;&#38598;&#65306;', self::$repeat_limit).$source;
                    lib_base::back_html($notice, 1);
                    break;
                }
                
                continue;
            }

            if(! $grab['title'][$key] || ! $source){
                lib_base::back_html('&#26080;&#37319;&#38598;&#26631;&#39064;&#25110;&#32773;&#26469;&#28304;&#22320;&#22336;', 1);
                continue;
            }
            
            self::$grab_new++;
            
            self::grab_detail_local($grab['id'], $grab['title'][$key], $source);
        }
        
        //update
        self::grab_detail_delete($grab['id'], $grab['source']);
        
        //更新机制
        self::nav_crontime_update($grab['id'], $grab['crontime']);
    
        return TRUE;
    }
    
    /**
     * 采集内容页
     *
     * @access public
     * @param
     * @return
     */
    public static function grab_detail(& $grab)
    {   
        $url = $grab['source'][$grab['key']];

        //url处理
        $url = str_replace('&amp;', '&', $url);
        $grab['detail_url'] = $url;

        //HOST
        $urls = parse_url($url);
        $grab['host'] = isset($urls['scheme']) ? $urls['scheme'].'://'.$urls['host'] : $urls['host'];

        $cookie = $grab['cookie'];

        //随机cookie
        $file_post_cookie = DISCUZ_ROOT.'source/plugin/'.PLUGIN_NAME.'/rule/'.$urls['host'].'_cookie.txt';
        if(file_exists($file_post_cookie)){
            $post_cookie_arr = explode("\n", trim(file_get_contents($file_post_cookie), "\r\n"));
            if(is_array($post_cookie_arr)){
                $cookie = $post_cookie_arr[array_rand($post_cookie_arr)];
                //$grab['cookie'] = $cookie;
            }
        }

        //嵌入点，此函数可替代采集内容
        if(isset($grab['rule']['func']['detail'])){
            if(function_exists($grab['rule']['func']['detail'])){
                return $grab['rule']['func']['detail']($grab);
            }
        }

        $html = self::get($url, $grab['host'], $urls['host'], $cookie);
        $grab['html'] = $html;

        if(! $html){
            $notice = '&#33719;&#21462;&#35814;&#32454;&#39029;&#22833;&#36133;&#65306;'.$url;
            lib_base::back_html($notice, 1);
            return FALSE;
        }
        
        if(! lib_base::$grab_charset){
            $charset = self::getCharset($grab['html']);
            if(! $charset){
                $notice = 'Unfetched Web Code '.$url;
                lib_base::back_html($notice, 1);
            }
            lib_base::$grab_charset = $charset;
        }

        //单篇文章采集匹配标题
        $title = '';
        if(isset($grab['title'][$grab['key']])){
            $title = trim($grab['title'][$grab['key']]);
        }else{
            $title = self::title($grab);
            $grab['title'][$grab['key']] = $title;
        }

        if($urls['host']){
            $rule_file = DISCUZ_ROOT.'source/plugin/'.PLUGIN_NAME.'/rule/'.$urls['host'].'.php';
            if(file_exists($rule_file)){
                include $rule_file;
            }
        }

		//嵌入点，此函数可替代采集内容
		if(isset($grab['rule']['func']['detail_start'])){
			if(function_exists($grab['rule']['func']['detail_start'])){
			    $grab['html'] = $html;
			    return $grab['rule']['func']['detail_start']($grab);
			}
		}

		$notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['detail_url'];
		if(! self::html_intercept($html, $grab['rule']['con_intercept_start'], 'start', $notice)){
			return FALSE;
		}

		//过滤内容
		if($grab['rule']['con_intercept_filter']){
		    self::content_filter($html, $grab['rule']['con_intercept_filter']);
		}

		$notice = '&#35814;&#32454;&#39029;&#25130;&#21462;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['detail_url'];
		if(! self::html_intercept($html, $grab['rule']['con_intercept_end'], 'end', $notice)){
			return FALSE;
		}

		//嵌入点,此函数可处理采集内容
		if(isset($grab['rule']['func']['detail_deal'])){
			if(function_exists($grab['rule']['func']['detail_deal'])){
			    $grab['rule']['func']['detail_deal']($html);
			}
		}

		//嵌入点,此函数可处理采集内容
		if(isset($grab['rule']['func']['detail_deal_more'])){
		    if(function_exists($grab['rule']['func']['detail_deal_more'])){
		        $grab['rule']['func']['detail_deal_more']($html, $grab);
		    }
		}

		//嵌入点,此函数可替代采集内容
		if(isset($grab['rule']['func']['detail_middle'])){
		    if(function_exists($grab['rule']['func']['detail_middle'])){
		        $grab['html'] = $html;
		        return $grab['rule']['func']['detail_middle']($grab);
		    }
		}

		//内容获取标签
		$tags = array();
		if(isset($grab['rule']['tags_intercept_start']) && $grab['rule']['tags_intercept_start']){
		    $tags = self::tags($grab);
		}

		//内容获取评论
		$comment = array(
		    'list'=>array(),
		    'dateline'=>array(),
		    'author'=>array(),
		);
		if(lib_base::settings('is_grab_dateline')){
		    self::dateline($grab, $comment);
		}
		if(lib_base::settings('is_grab_author')){
		    self::author($grab, $comment);
		}
		if(lib_base::settings('is_grab_comment')){
		    self::comment($grab, $comment);
		}

		//嵌入点,此函数可处理采集自定义数据
		if(isset($grab['rule']['func']['comment_deal'])){
		    if(function_exists($grab['rule']['func']['comment_deal'])){
		        $grab['rule']['func']['comment_deal']($comment, $grab);
		    }
		}

		//过滤
		self::content_filter_tag($html);
		self::src_deal($html, $grab['host']);
		self::iframe_deal($html, $grab['host']);
		self::href_deal($html, $grab['host']);

		$content = trim($html);

		//处理采集无内容
		if(! strip_tags($content) && stripos($content, '<img') === FALSE){
		    $content = '';
		}

		if(! $title){
			$notice = '&#26410;&#33719;&#21462;&#26631;&#39064;&#65306;'.$grab['detail_url'];
			lib_base::back_html($notice, 1);
			return FALSE;
		}
		
		if(! $content){
			$notice = '&#26410;&#33719;&#21462;&#20869;&#23481;&#65306;'.$grab['detail_url'];
			lib_base::back_html($notice, 1);
			return FALSE;
		}

		//嵌入点,此函数可输出最终保存的内容
		if(isset($grab['rule']['func']['detail_end'])){
			if(function_exists($grab['rule']['func']['detail_end'])){
			    $grab['html'] = $html;
			    return $grab['rule']['func']['detail_end']($grab);
			}
		}
		
		if(isset($grab['rule']['page_intercept_start']) && $grab['rule']['page_intercept_start']){
		    self::detail_page($content, $grab);
		}

		self::grab_save($grab, $title, $content, $tags, $comment, $grab['source'][$grab['key']]);
    }
    
    /**
     * 获取标题
     *
     * @access public
     * @param array
     * @return string
     */
    public static function title(& $grab)
    {
        $html = $grab['html'];
    
        $title = '';
    
        $notice = '&#35814;&#32454;&#39029;&#26631;&#39064;&#25130;&#21462;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['detail_url'];
        ! isset($grab['rule']['title_intercept_start']) && $grab['rule']['title_intercept_start'] = '<title>';
        if(! self::html_intercept($html, $grab['rule']['title_intercept_start'], 'start', $notice)){
            return $title;
        }
        
        //过滤内容
        if(isset($grab['rule']['title_intercept_filter'])){
            self::content_filter($html, $grab['rule']['title_intercept_filter']);
        }
    
        $notice = '&#39;&#35814;&#32454;&#39029;&#26631;&#39064;&#25130;&#21462;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['detail_url'];
        ! isset($grab['rule']['title_intercept_end']) && $grab['rule']['title_intercept_end'] = '</title>';
        if(! self::html_intercept($html, $grab['rule']['title_intercept_end'], 'end', $notice)){
            return $title;
        }

        //过滤内容
        if(isset($grab['rule']['func']['title_deal'])){
            $grab['rule']['func']['title_deal']($html);
        }
        
        if(strpos($html, '_') !== FALSE){
            $title_explode = explode('_', $html);
            if($title_explode[0]){
                $html = trim($title_explode[0]);
            }
        }
        
        if(strpos($html, '-') !== FALSE){
            $title_explode = explode('-', $html);
            if($title_explode[0]){
                $html = trim($title_explode[0]);
            }
        }

        return $html;
    }
    
    public static function tags(& $grab)
    {
        $html = $grab['html'];

        $tags = array();
        
        $notice = '&#35814;&#32454;&#39029;&#22810;&#26631;&#31614;&#25130;&#21462;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['detail_url'];
        if(! self::html_intercept($html, $grab['rule']['tags_intercept_start'], 'start', $notice)){
            return $tags;
        }

        if($grab['rule']['tags_intercept_filter']){
            self::content_filter($html, $grab['rule']['tags_intercept_filter']);
        }
    
        $notice = '&#35814;&#32454;&#39029;&#22810;&#26631;&#31614;&#25130;&#21462;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['detail_url'];
        if(! self::html_intercept($html, $grab['rule']['tags_intercept_end'], 'end', $notice)){
            return $tags;
        }
         
        if(is_array($grab['rule']['tags_list'])){
            preg_match_all('/'.$grab['rule']['tags_list'][self::$intercept_rule_id].'/', $html, $result);
        }else{
            preg_match_all('/'.$grab['rule']['tags_list'].'/', $html, $result);
        }
         
        if(! isset($result[1]) || ! $result[1] || ! $result[1][0]){
            $notice = '&#35814;&#32454;&#39029;&#22810;&#26631;&#31614;&#21015;&#34920;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['detail_url'];
            lib_base::back_html($notice, 1);
            return $tags;
        }
        
        foreach($result[1] as $tagname){
            $tags[] = $tagname;
        }
         
        return $tags;
    }
    
    /**
     * 获取评论
     *
     * @access public
     * @param array
     * @return array
     */
    public static function comment(& $grab, & $comment)
    {
        $html = $grab['html'];
    
        $list = array();
        
        //嵌入点，此函数可替代采集内容
        if(isset($grab['rule']['func']['comment_start'])){
            if(function_exists($grab['rule']['func']['comment_start'])){
                return $grab['rule']['func']['comment_start']($grab, $comment);
            }
        }
        
        if(! $grab['rule']['comment_intercept_start']){
            return $list;
        }

        $notice = '&#35780;&#35770;&#25130;&#21462;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['detail_url'];
        if(! self::html_intercept($html, $grab['rule']['comment_intercept_start'], 'start', $notice)){
            return $list;
        }
    
        if($grab['rule']['comment_intercept_filter']){
            self::content_filter($html, $grab['rule']['comment_intercept_filter']);
        }
    
        $notice = '&#35814;&#32454;&#39029;&#22810;&#26631;&#31614;&#25130;&#21462;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['detail_url'];
        if(! self::html_intercept($html, $grab['rule']['comment_intercept_end'], 'end', $notice)){
            return $list;
        }

        //嵌入点,此函数可处理采集内容
        if(isset($grab['rule']['func']['detail_deal'])){
            if(function_exists($grab['rule']['func']['detail_deal'])){
                $grab['rule']['func']['detail_deal']($html);
            }
        }
        
        //嵌入点，此函数可替代采集内容
        if(isset($grab['rule']['func']['comment_middle'])){
            if(function_exists($grab['rule']['func']['comment_middle'])){
                $grab['html'] = $html;
                return $grab['rule']['func']['comment_middle']($grab, $comment);
            }
        }

        if(is_array($grab['rule']['comment_list'])){
            preg_match_all('/'.$grab['rule']['comment_list'][self::$intercept_rule_id].'/', $html, $result);
        }else{
            preg_match_all('/'.$grab['rule']['comment_list'].'/', $html, $result);
        }

        if(! isset($result[1][0]) || ! $result[1][0]){
            $notice = '&#35814;&#32454;&#39029;&#26410;&#21305;&#37197;&#21040;&#35780;&#35770;&#20449;&#24687;&#65306;'.$grab['detail_url'];
            lib_base::back_html($notice, 1);
            return $list;
        }

        foreach($result[1] as $key => $value)
        {
            $floor = $key + 1;
            $list[$floor] = trim($value);
            
            //过滤
            self::content_filter_tag($list[$floor]);
            self::src_deal($list[$floor], $grab['host']);
            self::iframe_deal($list[$floor], $grab['host']);
            self::href_deal($list[$floor], $grab['host']);
        }

        $comment['list'] = $list;
    }
    
    /**
     * 获取评论发布时间
     *
     * @access public
     * @param array
     * @return array
     */
    public static function dateline(& $grab, & $comment)
    {
        //嵌入点，此函数可替代采集内容
        if(isset($grab['rule']['func']['dateline_start'])){
            if(function_exists($grab['rule']['func']['dateline_start'])){
                return $grab['rule']['func']['dateline_start']($grab, $comment);
            }
        }

        $dateline = array();
        
        $rule = '/'.$grab['rule']['comment_dateline'].'/is';

        preg_match_all($rule, $grab['html'], $result);

        if(! $result[1]){
            return $dateline;
        }

        $rule = '/\d{4}-\d{1,2}-\d{1,2} (\d{1,2}:\d{1,2}:\d{1,2}|\d{1,2}:\d{1,2})/is';
        foreach($result[1] as $key => $value)
        {
            preg_match($rule, $value, $result_time);

            $dateline[$key] =  $result_time[0];
        }

        $comment['dateline'] = $dateline;
    }
    
    /**
     * 获取评论发布作者
     *
     * @access public
     * @param array
     * @return array
     */
    public static function author(& $grab, & $comment)
    {
        //嵌入点，此函数可替代采集内容
        if(isset($grab['rule']['func']['author_start'])){
            if(function_exists($grab['rule']['func']['author_start'])){
                return $grab['rule']['func']['author_start']($grab, $comment);
            }
        }

        $author = array();
    
        $rule = '/'.$grab['rule']['author_list'].'/is';
        preg_match_all($rule, $grab['html'], $result);

        if(! $result[1]){
            return $author;
        }
    
        foreach($result[1] as $key => $value){
            $temp = strip_tags($value);
            if($temp == $value){
                $author[$key] = lib_base::escape(trim($value));
            }else{
                $author[$key] = '';
            }
        }

        $comment['author'] = $author;
    }
    
    /**
     * 获取评论发布作者头像
     *
     * @access public
     * @param array
     * @return array
     */
    public static function avatar(& $grab)
    {
        //嵌入点，此函数可替代采集内容
        if(isset($grab['rule']['func']['avatar_start'])){
            if(function_exists($grab['rule']['func']['avatar_start'])){
                return $grab['rule']['func']['avatar_start']($grab);
            }
        }
    
        $avatar = array();
    
        $rule = '/'.$grab['rule']['avatar_list'].'/';
    
        preg_match_all($rule, $grab['html'], $result);

        if(! $result[1]){
            return $avatar;
        }
    
        foreach($result[1] as $key => $value){
            $avatar[$key] =  $value;
        }
    
        return $avatar;
    }
    
    public static function avatar_save($uid, $avatar_url)
    {
        global $_G;
    
        //禁止其它插件修改路径
        $_G['setting']['plugins']['func'][HOOKTYPE]['avatar'] = '';
        $avatar_local_big_path = avatar($uid, 'big', TRUE, FALSE, TRUE);
    
        $urls = parse_url($avatar_local_big_path);
    
        $avatar_local_big_path_r = ltrim($urls['path'], '/');
    
        if(strpos($avatar_local_big_path_r, 'uc_server') === FALSE){
            $avatar_local_big_path_r = 'uc_server/'.$avatar_local_big_path_r;
        }
    
        $avatar_local_big_path_a = DISCUZ_ROOT.$avatar_local_big_path_r;
    
        //创建目录
        $avatar_path = DISCUZ_ROOT;
        $paths = explode('/', $avatar_local_big_path_r);
        foreach($paths as $value)
        {
            if(strpos($value, 'avatar_big.jpg') !== FALSE){
                break;
            }
            $avatar_path .= $value.'/';
            if(! is_dir($avatar_path)){
                mkdir($avatar_path);
                chmod($avatar_path, 0777);
            }
        }
    
        $urls = parse_url($avatar_url);
        $avatar_data = lib_func_grab::attach_get($avatar_url, $urls['host'], $urls['host']);

        if($avatar_data && file_put_contents($avatar_local_big_path_a, $avatar_data))
        {
            chmod($avatar_local_big_path_a, 0777);
    
            $avatar_local_middle_path = str_replace('big', 'middle', $avatar_local_big_path_r);
            $avatar_local_small_path = str_replace('big', 'small', $avatar_local_big_path_r);
    
            require_once libfile('class/image');
            $image = new image();
            $_G['setting']['attachdir'] = DISCUZ_ROOT;
            $thumb = $image->Thumb($avatar_local_big_path_a, $avatar_local_middle_path, 120, 120);
            $thumb = $image->Thumb($avatar_local_big_path_a, $avatar_local_small_path, 48, 48);
        }
    }
    
    /**
     * 分页详细内容
     *
     * @access public
     * @param string,array,int,int
     * @return int
     */
    public static function detail_page(& $content, & $grab)
    {
        //最大页码
        $page_count = self::detail_page_count($grab);
        if(! $page_count){
            return FALSE;
        }
    
        $page = 2;
        $detail_url = $grab['source'][$grab['key']];
        while($page <= $page_count)
        {
            $url = self::detail_page_deal($page, $detail_url, $grab['rule']['func']['con_page_deal']);
    
            $html = self::get($url, $grab['host']);

            if(! $html){
                break;
            }
             
            $notice = '&#35814;&#32454;&#39029;&#20998;&#39029;&#25130;&#21462;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$url;
            if(! self::html_intercept($html, $grab['rule']['con_intercept_start'], 'start', $notice)){
                return FALSE;
            }
    
            if($grab['rule']['con_intercept_filter']){
                self::content_filter($html, $grab['rule']['con_intercept_filter']);
            }
    
            $notice = '&#35814;&#32454;&#39029;&#20998;&#39029;&#25130;&#21462;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$url;
            if(! self::html_intercept($html, $grab['rule']['con_intercept_end'], 'end', $notice)){
                return FALSE;
            }
    
            //嵌入点,此函数可处理采集内容
            if(isset($grab['rule']['func']['detail_deal'])){
                if(function_exists($grab['rule']['func']['detail_deal'])){
                    $grab['rule']['func']['detail_deal']($html);
                }
            }
             
            //过滤
            self::content_filter_tag($html);
            self::src_deal($html, $grab['host']);
            self::iframe_deal($html, $grab['host']);

            $html && $content .= $html;
             
            $page++;
        };
    }
    
    public function detail_page_count(& $grab)
    {
        $html = $grab['html'];
    
        $notice = '&#20869;&#23481;&#20998;&#39029;&#25130;&#21462;&#24320;&#22987;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['url'];
        if(! self::html_intercept($html, $grab['rule']['page_intercept_start'], 'start', $notice)){
            return FALSE;
        }
    
        if($grab['rule']['page_intercept_filter']){
            self::content_filter($html, $grab['rule']['page_intercept_filter']);
        }
    
        $notice = '&#20869;&#23481;&#20998;&#39029;&#25130;&#21462;&#32467;&#26463;&#35268;&#21017;&#22833;&#36133;&#65306;'.$grab['url'];
        if(! self::html_intercept($html, $grab['rule']['page_intercept_end'], 'end', $notice)){
            return FALSE;
        }
    
        preg_match_all('/'.$grab['rule']['page_list'].'/', $html, $list);
    
        $page = $list[1];

        if(! $page){
            return FALSE;
        }
    
        foreach($page as $key => $value){
            $page[$key] = intval($value);
        }
    
        rsort($page);

        return $page[0];
    }
    
    /**
     * 保存唯一标识
     *
     * @access public
     * @param string
     * @return string
     */
    public static function save_identify($url)
    {
        return md5($url);
    }
    
    /**
     * 内容截取
     *
     * @access private
     * @param string,string,string
     * @return
     */
    public static function html_intercept(& $html, $rule, $type = 'start', $notice = '')
    {
        $position = FALSE;

        if(is_array($rule))
        {
            if($type == 'start')
            {
                self::$intercept_rule_id = 0;

                foreach($rule as $key => $value)
                {
                    $position = stripos($html, $value);
                    if($position === FALSE){
                        continue;
                    }else{
                        self::$intercept_rule_id = $key;
                        $rule = $value;
                        break;
                    }
                }
            }
            else
            {
                $position = stripos($html, $rule[self::$intercept_rule_id]);
            }
    
            if($position === FALSE){
                lib_base::back_html($notice, 1);
                return FALSE;
            }
        }
        else
        {
            $position = stripos($html, $rule);
            if($position === FALSE){
                lib_base::back_html($notice, 1);
                return FALSE;
            }
        }
    
        $html = ($type=='start' ? substr($html, $position+strlen($rule)) : substr($html, 0, $position));

        return TRUE;
    }
    
    /**
     * 内容过滤
     *
     * @access public
     * @param string, array
     * @return json
     */
    public static function content_filter(& $html, $filter)
    {
        if(! $filter){
            return FALSE;
        }
    
        $filter_arr = is_array($filter) ? $filter : explode(',', $filter);

        foreach ($filter_arr as $key_f => $value_f)
        {
            if(stripos($value_f, '.*?') !== FALSE)
            {
                $pattern = '/'.$value_f.'/is';
                preg_match_all($pattern, $html, $result);
                if($result){
                    foreach($result[0] as $value){
                        $html = str_replace($value, '', $html);
                    }
                }
            }
            else
            {
                $html = str_replace($value_f, '', $html);
            }
        }
    }
    
    /**
     * 内容过滤标签
     *
     * @access public
     * @param string
     * @return
     */
    public static function content_filter_tag(& $html)
    {
        //必须滤掉元素
        $filter_arr = array(
            '<div.*?>',
            '</div>',
            '<!--.*?-->',
            '<style.*?>.*?<\/style>',
            '<script.*?>.*?<\/script>',
        );
        
        if(lib_base::settings('is_grab_href')){
            $filter_arr[] = '<a.*?>';
            $filter_arr[] = '</a>';
        }
    
        foreach ($filter_arr as $key_f => $value_f)
        {
            if(stripos($value_f, '.*?') !== FALSE)
            {
                $pattern = '/'.$value_f.'/is';
                preg_match_all($pattern, $html, $result);
                if($result){
                    foreach($result[0] as $value){
                        $html = str_replace($value, '', $html);
                    }
                }
            }
            else
            {
                $html = str_replace($value_f, '', $html);
            }
        }
    }
    
    /**
     * 内容图片路径处理
     *
     * @access public
     * @param string, string
     * @return
     */
    public static function src_deal(& $html, $host)
    {
        if(! $html){
            return FALSE;
        }
         
        if(stripos($html, '<img') === FALSE){
            return FALSE;
        }
         
        $pattern = '/<img.*?[\s]src=[\'"](.*?)[\'"].*?>/is';
        preg_match_all($pattern, $html, $result);
        if(! $result[1]){
            return FALSE;
        }
        
        $result[1] = array_unique($result[1]);
        
        $url = parse_url($host);
        foreach($result[1] as $key => $value)
        {
            if(stripos($value, 'http') === FALSE)
            {
                if(strpos($value, '//') === 0){
                    $html = str_replace($value, $url['scheme'].':'.$value, $html);
                }else if(strpos($value, '/') === 0){
                    $html = str_replace($value, $host.$value, $html);
                }else{
                    $html = str_replace($value, $host.'/'.$value, $html);
                }
            }
        }
    }
    
    /**
     * 内容超链接处理
     *
     * @access public
     * @param string, string
     * @return
     */
    public static function href_deal(& $html, $host)
    {
        if(! $html){
            return FALSE;
        }
        if(stripos($html, '<a') === FALSE){
            return FALSE;
        }
    
        $pattern = '/<a(.*?)>/is';
        preg_match_all($pattern, $html, $result);
        if(! $result){
            return FALSE;
        }

        //$url = parse_url($host);
        foreach($result[1] as $key => $value)
        {
            $src_deal = '';
            if(stripos($value, 'target') === FALSE){
                $src_deal = str_replace('href', 'target="_blank" href', $value);
            }

            if(! preg_match("/(https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast|ed2k){1}:\/\//i", $value))
            {
                if(stripos($value, 'href="') !== FALSE){
                    if($src_deal){
                        if(stripos($value, 'href="//') !== FALSE){
                            //$src_deal = str_replace('href="', 'href="'.$url['scheme'].':', $src_deal);
                        }else if(stripos($value, 'href="/') === FALSE){
                            $src_deal = str_replace('href="', 'href="'.$host.'/', $src_deal);
                        }else{
                            $src_deal = str_replace('href="', 'href="'.$host, $src_deal);
                        }
                    }else{
                        if(stripos($value, 'href="//') !== FALSE){
                            //$src_deal = str_replace('href="', 'href="'.$url['scheme'].':', $value);
                        }else if(stripos($value, 'href="/') === FALSE){
                            $src_deal = str_replace('href="', 'href="'.$host.'/', $value);
                        }else{
                            $src_deal = str_replace('href="', 'href="'.$host, $value);
                        }
                    }
                }else{
                    if($src_deal){
                        if(stripos($value, "href='//") !== FALSE){
                            //$src_deal = str_replace("href='", "href='".$url['scheme'].':', $src_deal);
                        }else if(stripos($value, "href='/") === FALSE){
                            $src_deal = str_replace("href='", "href='".$host.'/', $src_deal);
                        }else{
                            $src_deal = str_replace("href='", "href='".$host, $src_deal);
                        }
                    }else{
                        if(stripos($value, "href='//") !== FALSE){
                            //$src_deal = str_replace("href='", "href='".$url['scheme'].':', $value);
                        }else if(stripos($value, "href='/") === FALSE){
                            $src_deal = str_replace("href='", "href='".$host.'/', $value);
                        }else{
                            $src_deal = str_replace("href='", "href='".$host, $value);
                        }
                    }
                }
            }
    
            if($src_deal){
                $html  = str_replace($value, $src_deal, $html);
            }
        }
    }
    
    /**
     * 内容iframe路径处理
     *
     * @access public
     * @param string, string
     * @return
     */
    public static function iframe_deal(& $html, $host)
    {
        if(! $html){
            return FALSE;
        }
         
        if(stripos($html, '<iframe') === FALSE){
            return FALSE;
        }
         
        $pattern = '/<iframe.*?[\s]src=[\'"](.*?)[\'"].*?>/is';
        preg_match_all($pattern, $html, $result);
        if(! $result[1]){
            return FALSE;
        }
        
        $result[1] = array_unique($result[1]);
    
        $url = parse_url($host);
        $host = str_replace($url['scheme'].':', '', $host);
        foreach($result[1] as $key=> $value)
        {
            if(stripos($value, 'http') === FALSE)
            {
                if(strpos($value, '//') === 0){
                    //$html = str_replace($value, $url['scheme'].':'.$value, $html);
                }else if(strpos($value, '/') === 0){
                    $html = str_replace($value, $host.$value, $html);
                }else{
                    $html = str_replace($value, $host.'/'.$value, $html);
                }
            }
        }
    }
    
    /**
     * 分页处理
     *
     * @access public
     * @param int, array, string
     * @return json
     */
    public static function page_deal($page, $nav, $action = '')
    {
        if($action && function_exists($action)){
            return $action($page, $nav);
        }
  
        return str_replace('*', $page, $nav['source']);
    }
    
    /**
     * 内容分页处理
     *
     * @access public
     * @param
     * @return json
     */
    public static function detail_page_deal($page, $source, $action = '')
    {
        if($action && function_exists($action)){
            return $action($page, $source);
        }
    
        return $source;
    }
    
    /**
     * 保存
     *
     * @access public
     * @param string,string,int,string
     * @return string
     */
    public static function grab_save($grab, $title, $content, $tags, $comment, $source)
    {
        //html反实体化
        if(lib_base::$grab_charset == 'UTF-8'){
            $content = str_replace('&nbsp;', ' ', $content);
            $content = html_entity_decode($content);
            if($comment['list']){
                foreach($comment['list'] as $key => $value){
                    $value = str_replace('&nbsp;', ' ', $value);
                    $comment['list'][$key] = html_entity_decode($value);
                }
            }
        }else if(lib_base::$grab_charset == 'GBK' || lib_base::$grab_charset == 'GB2312'){
            $content = str_replace('&nbsp;', ' ', $content);
            $content = html_entity_decode($content, NULL, 'GB2312');
            if($comment['list']){
                foreach($comment['list'] as $key => $value){
                    $value = str_replace('&nbsp;', ' ', $value);
                    $comment['list'][$key] = html_entity_decode($value, NULL, 'GB2312');
                }
            }
        }
    
        if(CHARSET != strtolower(lib_base::$grab_charset)){
            if(lib_base::$grab_charset == 'UTF-8'){
                $_GET['act'] == 'grab_articled' && $title = lib_base::string_utf8_to_gbk($title);
                $content = lib_base::string_utf8_to_gbk($content);
                $tags && $tags = lib_base::convert_utf8_to_gbk($tags);
                $comment['list'] && $comment['list'] = lib_base::convert_utf8_to_gbk($comment['list']);
                $comment['author'] && $comment['author'] = lib_base::convert_utf8_to_gbk($comment['author']);
            }elseif(CHARSET == 'utf-8' && (lib_base::$grab_charset == 'GBK' || lib_base::$grab_charset == 'GB2312')){
                $_GET['act'] == 'grab_articled' && $title = lib_base::string_gbk_to_utf8($title);
                $content = lib_base::string_gbk_to_utf8($content);
                $tags && $tags = lib_base::convert_gbk_to_utf8($tags);
                $comment['list'] && $comment['list'] = lib_base::convert_gbk_to_utf8($comment['list']);
                $comment['author'] && $comment['author'] = lib_base::convert_gbk_to_utf8($comment['author']);
            }
        }
    
        if(lib_base::settings('thread_min')){
            $content_length = mb_strlen(strip_tags($content), CHARSET);
            if($content_length < lib_base::settings('thread_min')){
                $notice = '&#20445;&#23384;&#22833;&#36133;&#65306;'.$source;
                lib_base::back_html($notice, 1);
                return FALSE;
            }
        }
    
        $tags = $tags ? implode(',', $tags) : '';
        $comment = $comment ? serialize($comment) : '';
    
        //滤除系统表情
        //$title = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $title);
        //$content = preg_replace_callback('/./u', function (array $match){return strlen($match[0]) >= 4 ? '' : $match[0];}, $content);
    
        //检测标题是否重复
        if(lib_base::settings('title_is_exist') && lib_base::table('admin_grab')->title_is_exist($grab['send_type'], $title)){
            $notice = '&#20445;&#23384;&#22833;&#36133;&#65306;'.$source;
            lib_base::back_html($notice, 1);
            return FALSE;
        }
    
        //update
        $identify = self::save_identify($source);
        $grab_detail = self::grab_detail_by_identify($identify);
    
        if(! $grab_detail)
        {
            $add = array(
                'navid'=>$grab['id'],
                'send_type'=>$grab['send_type'],
                'cid'=>$grab['cid'],
                'fid'=>$grab['fid'],
                'typeid'=>$grab['typeid'],
                'title'=>$title,
                'content'=>$content,
                'source'=>$source,
                'tags'=>$tags,
                'comment'=>$comment,
                'dateline'=>TIMESTAMP,
                'identify'=>self::save_identify($source)
            );
            lib_base::table('admin_grab')->insert($add, TRUE);
        }
        else if($grab_detail['tid'])
        {
            $fid_move = 350;
            
            $thread = C::t('forum_thread')->fetch($grab_detail['tid']);
            if($thread)
            {
                //是否删除的帖子
                if($thread['fid'] == $fid_move){
                    $nav = lib_base::table('admin_nav')->fetch($grab_detail['navid']);
                    if($nav && $nav['fid']){
                        C::t('forum_thread')->update($grab_detail['tid'], array('fid'=>$nav['fid']));
                        DB::update('forum_post', array('fid'=>$nav['fid']), array('tid'=>$grab_detail['tid']));
                    }
                }
                
                if(($grab_detail['title'] != $title || $grab_detail['content'] != $content))
                {
                    $forum = C::t('forum_forum')->fetch($thread['fid']);
                    $post = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread['tid']);
                    
                    $title = cutstr($title, 70, '');
                    C::t('forum_thread')->update($thread['tid'], array('subject'=>$title));
                    
                    require_once libfile('function/editor');
                    $content = html2bbcode($content);
                    $content = htmlspecialchars_decode($content);
                    if($content)
                    {
                        if(lib_base::settings('image_to_local'))
                        {
                            $dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
                            $dir = $dir.'forum/';
                            $attach_list = C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$post['tid'], 'tid', $post['tid']);
                            foreach($attach_list as $value)
                            {
                                $filename = $dir.$value['attachment'];
                                if(file_exists($filename)){
                                    unlink($filename);
                                }
                                C::t('forum_attachment')->delete($value['aid']);
                                C::t('forum_attachment_n')->delete('tid:'.$post['tid'], $value['aid']);
                            }
                            
                            $content = lib_base::table('admin_grab')->forum_image_attachment($post['tid'], $post['pid'], $post['authorid'], $content, $forum['allowhtml']);
                        }
                        
                        C::t('forum_post')->update($thread['posttableid'], $post['pid'], array('message'=>$content));
                        
                        //清除diy缓存
                        DB::update('common_block', array('dateline'=>(TIMESTAMP - 4000)), array('cachetime'=>3600));
                    }
                }
            }
            
            lib_base::table('admin_grab')->update($grab_detail['id'], array('dateline'=>TIMESTAMP));
        }
        else if($grab_detail)
        {
            lib_base::table('admin_grab')->update($grab_detail['id'], array('dateline'=>TIMESTAMP));
        }
    
        $notice = '&#37319;&#38598;&#25104;&#21151;&#65306;'.$source;
        lib_base::back_html($notice);
    }
    
    /**
     * 更新采集时间
     *
     * @access public
     * @param string
     * @return
     */
    public static function nav_crontime_update($id, $crontime)
    {
        $time = 5;

        $type = self::$grab_new ? 0 : 1;

        $crontime = $type == 0 ? ($crontime - $time) : ($crontime + $time);
    
        $crontime <= 30 && $crontime = 30;
        $crontime > self::$grab_time_count && $crontime = self::$grab_time_count;

        lib_base::table('admin_nav')->update($id, array('crontime'=>$crontime, 'grabtime'=>TIMESTAMP));
    }
    
    /**
     * 采集列表保存到本地
     *
     * @access public
     * @param string, string
     * @return
     */
    public static function grab_detail_local($navid, $title, $source)
    {
        $identify = self::save_identify($source);
    
        if(lib_base::table('admin_local')->grab_local_is_exist_by_identify($identify)){
            $notice = '&#20869;&#23481;&#37319;&#38598;&#37325;&#22797;&#65306;'.$source;
            lib_base::back_html($notice, 1);
            return FALSE;
        }

        if(CHARSET != strtolower(lib_base::$grab_charset)){
            if(lib_base::$grab_charset == 'UTF-8'){
                $title = lib_base::string_utf8_to_gbk($title);
            }elseif(CHARSET == 'utf-8' && (lib_base::$grab_charset == 'GBK' || lib_base::$grab_charset == 'GB2312')){
                $title = lib_base::string_gbk_to_utf8($title);
            }
        }

        $add = array(
            'navid'=>$navid,
            'title'=>$title,
            'source'=>$source,
            'identify'=>$identify,
            'dateline'=>TIMESTAMP,
        );

        lib_base::back_html($source);
    
        return lib_base::table('admin_local')->insert($add);
    }
    
    /**
     * 采集内容
     *
     * @access public
     * @param
     * @return
     */
    public static function grab_detail_save($local_id = 0)
    {
        $grab_local = array();
        if($local_id){
            $grab_local = lib_base::table('admin_local')->fetch($local_id);
        }else{
            $grab_local = lib_base::table('admin_local')->grab_local_detail_latest();
        }
    
        if(! $grab_local){
            lib_base::back_html('&#24050;&#26080;&#26410;&#37319;&#38598;&#30340;&#26412;&#22320;&#25968;&#25454;', 1);
            return FALSE;
        }
    
        $nav = lib_base::table('admin_nav')->fetch($grab_local['navid']);
    
        lib_base::table('admin_local')->delete($grab_local['id']);
    
        if(! $nav){
            lib_base::back_html('&#26080;&#37319;&#38598;&#20851;&#38190;&#35789;&#20449;&#24687;', 1);
            return TRUE;
        }
    
        $url = $grab_local['source'];
        $ruleid = 0;
        
        include libfile('lib/rule', 'plugin/'.PLUGIN_NAME);

        $url_parse = parse_url($url);
        if($url_parse['host']){
            $rule_file = DISCUZ_ROOT.'source/plugin/'.PLUGIN_NAME.'/rule/'.$url_parse['host'].'.php';
            if(file_exists($rule_file)){
                include $rule_file;
            }
        }

        $grab = array_merge($nav, array('rule'=>$rule[$ruleid]));
    
        require_once libfile('lib/func_grab', 'plugin/'.PLUGIN_NAME);
    
        $grab['title'] = $grab['source'] = array();
        $grab['title'][0] = $grab_local['title'];
        $grab['source'][0] = $grab_local['source'];
        $grab['key'] = 0;
    
        self::grab_detail($grab);
        
        return TRUE;
    }
    
    
    ///////更新机制
    /**
     * 采集详情
     *
     * @access public
     * @param string
     * @return array
     */
    public static function grab_detail_by_identify($identify)
    {
        $sql = 'SELECT * FROM %t WHERE identify=%s';
    
        return DB::fetch_first($sql, array('plugin_'.PLUGIN_NAME, $identify));
    }
    
    /**
     * 采集详情
     *
     * @access public
     * @param string
     * @return array
     */
    public static function grab_detail_delete($navid, $source_list)
    {
        $fid_move = 350;
        
        $sql = 'SELECT * FROM %t WHERE navid=%d';
        $grab_list = DB::fetch_all($sql, array('plugin_'.PLUGIN_NAME, $navid));
        foreach($grab_list as $value){
            if(! in_array($value['source'], $source_list)){
                //lib_base::table('admin_grab')->delete($value['id']);
                if($value['tid']){
                    //C::t('forum_thread')->update($value['tid'], array('displayorder'=>-1));
                    C::t('forum_thread')->update($value['tid'], array('fid'=>$fid_move));
                    DB::update('forum_post', array('fid'=>$fid_move), array('tid'=>$value['tid']));
                }
            }
        }
    }
}