<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once libfile('lib/base', 'plugin/'.PLUGIN_NAME);

/**
 * lib_index Class
 * @package plugin
 * @subpackage ror
 * @category grab
 * @author ror
 * @link
 */
class lib_index
{
    protected static $allow_actions = array(
        'index'=>array('class'=>'lib_index_grab','function'=>'cron_minute'),
        
        'cron_minute'=>array('class'=>'lib_index_grab','function'=>'cron_minute'),

        'thread_send'=>array('class'=>'lib_index_grab','function'=>'thread_send'),

        'pic_cache_delete'=>array('class'=>'lib_index_grab','function'=>'pic_cache_delete'),
        
        'grab_list'=>array('class'=>'lib_index_grab','function'=>'grab_list'),
        'grab_list_page'=>array('class'=>'lib_index_grab','function'=>'grab_list_page'),
        'grab_detail'=>array('class'=>'lib_index_grab','function'=>'grab_detail'),
        
        'pic'=>array('class'=>'lib_index_pic','function'=>'index'),
        
        'api_thread_add'=>array('class'=>'lib_index_api','function'=>'api_thread_add'),
        'api_post_add'=>array('class'=>'lib_index_api','function'=>'api_post_add'),
        'api_article_add'=>array('class'=>'lib_index_api','function'=>'api_article_add'),
        'api_comment_add'=>array('class'=>'lib_index_api','function'=>'api_comment_add'),
        'api_thread_like'=>array('class'=>'lib_index_api','function'=>'api_thread_like'),
    );

    public function run()
    {
//         ini_set("display_errors", "On");
//         error_reporting(E_ALL);

        global $_G;
        
        $action = $_GET['act'] ? $_GET['act'] : 'index';
        
        if (! isset(self::$allow_actions[$action])) {
            showmessage(lib_base::lang('noaction'));
        }
        
        $op = self::$allow_actions[$action];
        
        require_once libfile(str_replace('lib_', 'lib/', $op['class']), 'plugin/'.PLUGIN_NAME);
        
        $class = $op['class'];
        $class = new $class();
        $function = $op['function'];
        $class->$function();
    }
}