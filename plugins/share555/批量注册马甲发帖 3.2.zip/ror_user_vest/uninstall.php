<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access denied');
}

$plugin_name = 'ror_user_vest';

$sql = <<<EOT

DROP TABLE IF EXISTS pre_plugin_{$plugin_name};

EOT;

runquery($sql);

//删除缓存
$filename = DISCUZ_ROOT.'data/plugindata/ror_user_vest_cache.log';
if(file_exists($filename)){
    unlink($filename);
}

$finish = true;