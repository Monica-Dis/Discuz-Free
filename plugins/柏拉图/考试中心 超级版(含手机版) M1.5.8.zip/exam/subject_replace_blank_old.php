<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if(!defined('IN_DISCUZ')) {
		exit('Access Denied');
	}
	if(!function_exists('hook_match_replace'))
	{
		function hook_match_replace($str1, $str2 , $str3){
			global $hv,$v;
			if($str1){
				$options = explode('|', $str1);
				$string  = '&nbsp;<label><input type="hidden" name="e_'. $v['eid'].'[]" value="'.$hv.'">';
				$string .= '<select class="norcur" onchange="this.parentNode.getElementsByTagName(\'input\')[0].value=this.value" value="'.$hv.'"><option value="">&#x9009;&#x62E9;:</option>';
				foreach($options AS $ov){
					$selected = $ov==$hv ? 'selected' : '';
					$string .= "<option value=\"$ov\" $selected>$ov</option>";
				}
				$string .= "</select></label>&nbsp;";
			}else if($str2 || $str3){
				$string = '&nbsp;<label class="norcur"><input type="text" name="e_'. $v['eid'].'[]" value="'.$hv.'"></label>&nbsp;';
			}
			return $string;
		}
	}
 
	$hvalue = explode("\n", $history[$v['eid']]['user_result']);
	$hvi = 0;
	while(preg_match("/(\{[^|\}]+\|[^\}]+\})|(\_{2,})|(\((\s|&nbsp;)+\))/", $v['subject'])){
		$hv = $hvalue[$hvi++];
		$v['subject'] = preg_replace("/\{([^|\}]+\|[^\}]+)\}|(\_{2,})|(\((\s|&nbsp;)+\))/e",  "hook_match_replace('\\1','\\2','\\3')" , $v['subject'], 1);
	}
//From: Dism��taobao��com
?>