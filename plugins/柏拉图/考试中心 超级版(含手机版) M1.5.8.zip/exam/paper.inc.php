<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if(!defined('IN_DISCUZ')) {
		exit('Access Denied');
	}
 	require_once 'tiny.common.inc.php';
	
	$pid = isset($_GET['cid']) ? intval($_GET['cid']) : (isset($_GET['paper']) ? intval($_GET['paper']) : intval($_GET['test']));
	
	if(checkmobile() && !isset($_GET['mobile'])){
		header('Location: '.$_G['siteurl']."plugin.php?id=exam:m&mobile=no&mobi=yes&paper=$pid"); 
		exit;
	}

	if(!$include_pg){
		header('Location: ./plugin.php?id=exam');
		exit;
	}
 
	$uid = $_G['uid'];

	//δ�ҵ������Ծ�!
	$paper = C::t('#exam#tiny_exam3_paper')->get_paper_info($pid);

	if(empty($paper)){
		showmessage( "&#x672A;&#x627E;&#x5230;&#x8BE5;&#x5957;&#x8BD5;&#x5377;!", "plugin.php?id=exam");
	}
  
	if($_G['adminid']!=1 && $paper['uid']!=$uid && ($paper['status']==0 || $paper['public']==0)){
		showmessage( "&#26080;&#26435;&#38480;!", "plugin.php?id=exam");
	}

	//Ȩ���ж�=================================================================
	$checkPaperStatus = checkPaper($paper, $uid);
	$lid = isset($_GET['replay']) ? intval($_GET['replay']) : 0;
	
	if($checkPaperStatus===true)
	{
		//�Ծ�����Ŀ�б�
		$groups = C::t('#exam#tiny_exam3_paper')->fetch_exam_by_pid($pid);
		
		//���浽�ļ�------------------------------------------------------------------------------------
		/*
		$cache_path = DISCUZ_ROOT . 'data'.DIRECTORY_SEPARATOR.'examcache'.DIRECTORY_SEPARATOR;
		$cacheData = file_get_contents($cache_path . $pid . '.php',  false, null, 58);
		if(!$cacheData || (($groups = unserialize($cacheData)) &&  $groups['cachetime'] != $paper['endtime'])){
			$groups = C::t('#exam#tiny_exam3_paper')->fetch_exam_by_pid($pid);
			$groups['cachetime'] = $paper['endtime'];
			/*DisM-Taobao_Com*/if(!file_exists($cache_path))mkdir($cache_path);
			file_put_contents($cache_path . $pid . '.php', "<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>\n". serialize($groups));
		}
		*/
		//���浽�ļ�------------------------------------------------------------------------------------
		
		$paper['total_score']= C::t('#exam#tiny_exam3_paper')->get_score();
		$paper['twice_did']  = C::t('#exam#tiny_exam3_log')->value('count(*)', $uid, $pid);	//��������
		$paper['twice_left'] = intval(intval($paper['twice'] - $paper['twice_did']));	//ʣ�����
	 
		//�ط�
		if($lid){
			$_log_exam = !$config['log_exam'] ? 'tiny_exam3_log_exam' : ('tiny_exam3_log_exam_'. ($_G['uid'] % 10)); 
			$history = DB::fetch_all("SELECT eid,result AS user_result, score AS user_score FROM %t where lid='$lid' AND uid='$uid'", array($_log_exam), 'eid');
		}
 
		//PVͳ��
		C::t('#exam#tiny_exam3_paper')->set_count($pid);

		//�Ծ���������!
		if(empty($groups))$checkPaperStatus = 'empty';
		
		//������Ϣ
		if($config['userinfo']){
			if($uid){
				$userinfo=DB::result_first("SELECT userinfo FROM %t where uid='$uid' order by lid DESC", array('tiny_exam3_log'));
			}
			$userinfo = empty($userinfo) ? array() : explode("\n", $userinfo);
			$userinfofield = explode(",", $config['userinfo']);
		}
	}
 
	$navtitle		= $paper['title'];
	$metakeywords	= $paper['title'];
	$metadescription= empty($paper['content']) ? $paper['title'] : dhtmlspecialchars(strip_tags(str_replace('"','\'',$paper['content'])));
	
	//����������-----------------------
	$queuelock = false;
	if($config['queue_user'] && $lid==0){
		$queuetime = $_SERVER['REQUEST_TIME'] - 60 * 10;//10����
		$queuenum = DB::result_first("select count(*) from %t where `endtime`>'%d'", array('tiny_exam3_log', $waittime));
		if($queuenum > $config['queue_user']){
			$queuelock = true;
		}
	}
	//����������-----------------------
	//print_r($paper);
	//print_r($groups);

	include template("exam:$template/paper");
