<?php
/**
 * 
 * DisM!出品 必属精品
 * DisM!应用中心所有 https://dism.Taobao.Com
 * 专业Discuz!应用插件、模板正版采购提供代下载服务、技术支持等全方位服务...
 * 我们致力于为站长提供正版Discuz!应用而努力
 * E-mail: dism.taobao@qq.com
 * 工作时间: 周一到周五早上09:00-12:00, 下午13:00-18:00, 晚上19:30-23:30(周六、日休息)
 * DisM!用户交流群: ①群778390776
 * 
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
$uproot = DISCUZ_ROOT . $_G['setting']['attachurl'] .'exam/';

if(isset($_GET['src']) && !empty($_GET['src'])){//删除
		if($_GET['formhash'] != formhash()){
			die('ERROR SUBMIT!');
		}
 
		$src = strtolower($_GET['src']);
		$src = str_replace($_G['setting']['attachurl'] .'exam/', '', $src);
		DB::delete('tiny_exam3_upload',"src='$src'");
		@unlink($uproot.$src);
		echo 1;
} else { //上传
	if(isset($_POST) && !submitcheck('formhash')){
		showmessage('ERROR SUBMIT!');
		exit;
	}
 
	header("Pragma: no-cache");  
	require_once 'tiny.common.inc.php';

	$fileext = strtolower(end(explode('.', $_FILES['upload']['name'])));
	if(in_array($fileext, array('jpg','gif','png','mp3','mp4')))
	{
		$newname = date('ymdhi').random(6,1).'.'.$fileext;
		$cldDir  = date('ym').'/';
	 
		/*DisM-Taobao_Com*/if(!file_exists($uproot.$cldDir)){
			/*DisM-Taobao_Com*/if(!file_exists($uproot))mkdir($uproot);
			mkdir($uproot.$cldDir);
		}
		
		$path= $uproot.$cldDir.$newname;
		
		if($_FILES["upload"]["size"] && @move_uploaded_file(@$_FILES["upload"]["tmp_name"], $path))	{
			$post=array(
				'uid'     => $_G['uid'],
				'src'     => $cldDir.$newname,
				'uptime'  => $_SERVER['REQUEST_TIME'],
				'status'  => 0,
			);
			DB::insert('tiny_exam3_upload',$post);
		}
		die( $_G['setting']['attachurl'].'exam/'.$cldDir.$newname );
	}
	else{
		die( 'error' );
	}
}
//From: Dism_taobao_com
?>