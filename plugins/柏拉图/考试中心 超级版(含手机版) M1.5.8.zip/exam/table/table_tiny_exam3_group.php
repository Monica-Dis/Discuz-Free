<?php
/**
 * 
 * DisM!出品 必属精品
 * DisM!应用中心所有 https://dism.Taobao.Com
 * 专业Discuz!应用插件、模板正版采购提供代下载服务、技术支持等全方位服务...
 * 我们致力于为站长提供正版Discuz!应用而努力
 * E-mail: dism.taobao@qq.com
 * 工作时间: 周一到周五早上09:00-12:00, 下午13:00-18:00, 晚上19:30-23:30(周六、日休息)
 * DisM!用户交流群: ①群778390776
 * 
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_tiny_exam3_group extends discuz_table
{
	private $_field;
	public function __construct() {
		$this->_table = 'tiny_exam3_group';
		$this->_pk    = 'gid';
		$this->_field = '*';
		parent::__construct();/*dism-taobao·com*/
	}
 
	public function get_groups($pid, $bAll = false) 
	{
		$w = $bAll ? '' : "AND `sort`>=0";
		$groups = DB::fetch_all("select %i from %t where `pid`='%d' $w order by `sort`,`gid` asc", array($this->_field, $this->_table, $pid), $this->_pk);
		$new_groups = array();
		foreach($groups AS $gid=>$g){
			if(!$g['assoc']){
				unset($g['assoc']);
				$new_groups[$gid] = $g;
			}
			else{
				$g['assoc'] = str_replace('，', ',', $g['assoc']);
				$ga = explode(',', $g['assoc']);
				unset($g['assoc']);
				$g['pid'] = $pid;
				foreach($ga AS $k){
					$g['gid'] = $k;
					$new_groups[$k] = $g;
				}
			}
		}
		return $new_groups;
	}
	
	public function get_groups2($pid, $bAll = false) 
	{
		$w = $bAll ? '' : "AND `sort`>=0";
		$groups = DB::fetch_all("select %i from %t where `pid`='%d' $w order by `sort`,`gid` asc", array($this->_field, $this->_table, $pid), $this->_pk);
		return $groups;
	}
	
	
	public function field($field) 
	{
		$this->_field = $field;
		return $this;
	}
	
	public function get_group($gid, $fields = '*') 
	{
		$data = DB::fetch_first("select %i from %t where `gid`='%d'",array($fields, $this->_table, $gid));
		return $data;
	}
 
}
//From: Dism·taobao·com
?>