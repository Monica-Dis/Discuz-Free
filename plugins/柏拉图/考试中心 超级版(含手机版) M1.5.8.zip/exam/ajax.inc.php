<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


	require_once "tiny.common.inc.php";
	
	if ($_GET['formhash'] != formhash()) {
		exit('Access Denied');
	}
	
	$action= !isset($_GET['action']) ? '' : $_GET['action'];
	$wu =  $_G['groupid']==1 ? '' : "AND `uid`='".$_G['uid']."'";
 
	if($action=='user_exam_set_display'){
		$eid     = !isset($_GET['eid']) ? 0 : intval($_GET['eid']);
		$display = DB::result_first('select `display` from '.DB::table('tiny_exam3_exam')." where `eid`='$eid' $wu");
		$display = $display ? '0' : '1';
 
		DB::query('update '.DB::table('tiny_exam3_exam')." set `display`='$display' where `eid`='$eid' $wu");
		
		include template('common/header_ajax');
		echo $display;
		include template('common/footer_ajax');
	}
	else if($action=='user_exam_delete'){
		$eid  = !isset($_GET['eid']) ? 0 : intval($_GET['eid']);
		$status = DB::query('delete from '.DB::table('tiny_exam3_exam')." where `eid`='$eid' $wu");
		DB::query("update ".DB::table('tiny_exam3_upload')." SET `eid`='0' where `eid`='$eid' $wu");
		include template('common/header_ajax');
		echo $status=1;
		include template('common/footer_ajax');
	}
	else if($action=='user_show_exam_note'){
		$eid  = !isset($_GET['eid']) ? 0 : intval($_GET['eid']);
		$exam = DB::fetch_first('select `subject`,`note` from '.DB::table('tiny_exam3_exam')." where `eid`='$eid'");
		$exam['note'] =  dzcode($exam['note']);
		include template("exam:$template/common/show_note");
	}
	else if($action=='user_paper_payfor'){
		include template('common/header_ajax');
		$pid  =  intval($_GET['pid']);
		if(!$_G['uid']){
			echo 'nologin';
		}else{
			$pp = DB::fetch_first("SELECT `price`,`long` FROM " .DB::table('tiny_exam3_paper'). " WHERE `pid`='$pid'");
			echo payfor($pid, $_G['uid'], $pp['price'], $pp['long']);
		}
		include template('common/footer_ajax');
	}
	else if($action=='user_paper_payfor_mobi'){
		$pid  =  intval($_GET['pid']);
		if(!$_G['uid']){
			echo 'nologin';
		}else{
			$pp = DB::fetch_first("SELECT `price`,`long` FROM " .DB::table('tiny_exam3_paper'). " WHERE `pid`='$pid'");
			echo payfor($pid, $_G['uid'], $pp['price'], $pp['long']);
		}
	}