<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
list($gp_id)=explode(':', $_GET['id']);
include "global.php";
 
$aid = intval($_GET['aid']);

//ҳ������,��ѯattachment��
$tbMember = DB::table('common_member');
$query = DB::query("SELECT $tbAttach.tid,$tbAttach.pid,$tbAttach.uid,$tbAttach.filename,$tbAttach.filesize,$tbAttach.price,$tbAttach.attachment,$tbAttach.dateline,$tbAttach.isimage,  $tbMember.username
				    FROM $tbAttach,$tbMember WHERE $tbAttach.aid='$aid' and $tbAttach.uid=$tbMember.uid");
if (DB::num_rows($query)==0){
	$tableid =  DB::result_first("select tableid from $tbAttachIndex where aid='$aid'");
	if($tableid===false || $tableid===''){ die( "<script language='javascript' type='text/javascript'> window.location.href='./plugin.php?id=attachcenter'; </script>" ); }
	$tbAttach= $tbAttachIndex .'_'.$tableid;
	$query  = DB::query("SELECT $tbAttach.tid,$tbAttach.pid,$tbAttach.uid,$tbAttach.filename,$tbAttach.filesize,$tbAttach.price,$tbAttach.attachment,$tbAttach.dateline,$tbAttach.isimage,  $tbMember.username
				    FROM $tbAttach,$tbMember WHERE $tbAttach.aid='$aid' and $tbAttach.uid=$tbMember.uid");
	if (DB::num_rows($query)==0){	die( "<script language='javascript' type='text/javascript'> window.location.href='./plugin.php?id=attachcenter'; </script>" );}
}
     
$attach    = DB::fetch($query);	
$attach['filesize'] 	= $attach['filesize'] ? sizecount($attach['filesize']) : 0;
$attach['ext'] 			= strtolower( end ( explode('.' , $attach['filename']) )); 
$attach['open'] 		= $openmode[$attach['ext']];
$attach['dateline'] 	= date('Y-m-d', $attach['dateline']);
$attach['outlink'] 		= $attach['attachment'];
$attach['attachment'] 	= $_G[setting][attachurl] .'forum/'. $attach['attachment'];
$attach['aid'] 			= $_GET[aid];
$attach['icon'] 		= attachtype($attach['ext'] ."\t");
$attach['url'] 			=  "forum.php?mod=attachment&aid=" . aidencode($attach['aid']);
 
if($aid  && !DB::result_first("SELECT count(*) FROM $tbAttachIndex WHERE aid='$aid'") ){ //��������ڵļ�¼
	DB::query("DELETE FROM $tbAttach WHERE aid='$aid'");
	die( 'Attachment is not exist! <a href="./plugin.php?id=attachcenter">Back</a>' );
}

$queryi = DB::query("SELECT downloads from $tbAttachIndex WHERE aid=$aid");	
if (DB::num_rows($queryi)==0 && $attach['filesize']>0){
	DB::query("DELETE FROM $tbAttach WHERE pid='$attach[pid]'");
	$isAttDeleted=1;
}else{
	$isAttDeleted=0;
	$row = DB::fetch($queryi);
	$attach['downloads'] = $row['downloads'];
}
 
//��ȡ���ݿ�ʼ:��������鲻��,���������
$tbForum  = DB::table('forum_forum');//���ڲ��ҷ���
$tbPost   = DB::table('forum_post');
$query    = DB::query("SELECT $tbPost.fid,$tbPost.message,$tbPost.subject,$tbPost.first,$tbForum.fup FROM $tbPost,$tbForum WHERE $tbPost.tid='$attach[tid]' and $tbPost.fid=$tbForum.fid and $tbPost.invisible='0' and $tbPost.status='0' ORDER BY pid"); // and first='1' 
if (DB::num_rows($query)==0){
	loadcache('posttable_info');
	if(!empty($_G['cache']['posttable_info'])) {
		foreach($_G['cache']['posttable_info'] as $key => $value) {
		$tbPost =  ($key == 0) ? DB::table('forum_post') : DB::table('forum_post_'.$key);
		$query = DB::query("SELECT $tbPost.fid,$tbPost.message,$tbPost.subject,$tbPost.first,$tbForum.fup FROM $tbPost,$tbForum WHERE $tbPost.tid='$attach[tid]' and $tbPost.fid=$tbForum.fid and $tbPost.invisible='0' and $tbPost.status='0' ORDER BY pid"); //and first='1'
		if (DB::num_rows($result)>0){ break; }	
		}
	}
}
if($row = DB::fetch($query))
{
	$attach['fid'] 	   =$row['fid'];
	$attach['subject'] =$row['subject'];
	$attach['fup'] 	   =$row['fup'];
	if (preg_match("/^[\w\s-\.]+$/i", $attach['filename'])) { $attach['filename'] = $attach['subject']. ': ' . $attach['filename']; }
	do{
		$message = $row['message'] ;
		if (strlen( $message ) >= $adbox['postlen'] || !$adbox['postlen'] || $row['first'])
		{
			$message = discuzcode($message);
 			if(preg_match_all("/\[attach\](\d+)\[\/attach\]/i", $message, $matchaids)) {
				$attachimgids = implode(',',$matchaids[1]) ;
				$queryImg = DB::query("SELECT aid,attachment,isimage FROM $tbAttach WHERE aid in ($attachimgids) and `isimage`!='0'");
				if(DB::num_rows($queryImg)){
					while($img = DB::fetch($queryImg)) {
						$message = preg_replace("/\[attach\]".$img['aid']."\[\/attach\]/i", '<img src="'.$_G['setting']['attachurl'] .'forum/'. $img['attachment'].'" onload="javascript:if(this.width>600)this.width=600;">', $message);
					} 
				}
				$message = preg_replace("/\[attach\](\d+)\[\/attach\]/i",'',$message);
			}

			$message = preg_replace("/\[hide\](.*)\[\/hide\]/i",'<h4>�������ص�����</h4>',$message);
			$attach['message'][] = $message;
			$_lock = 0;
		}
	} 
	while ($row = DB::fetch($query)); 
}
//��ȡ���ݽ���/
 
//�������⸽��
$attachMoreArr = array();
$query = DB::query("SELECT aid,filename,filesize,attachment,isimage FROM $tbAttach WHERE tid='$attach[tid]'"); // and aid!='$aid'
while($row = DB::fetch($query)) {
	$row['filesize'] = $row['filesize'] ? sizecount($row['filesize']) : 0;
	$ext  = strtolower( end ( explode('.' , $row['filename']) )); 
	$row['ext'] =  $ext;
	$row['icon'] = attachtype($ext."\t");
	$row['attachment'] 	= $_G[setting][attachurl] .'forum/'. $row['attachment'];
	$row['url']	 = $adbox[rewrite] ? "$adbox[page]$row[aid].html" : "plugin.php?id=attachcenter:page&aid=$row[aid]";
	$attachMoreArr[] =  $row;
} 
 
//���ڽ�������
$fup = $attach['fup'];
$fid = $attach['fid'];
 
$navtitle		=$attach['filename'] .'_'. $attach['subject'];
$metakeywords	=$navtitle;
$metadescription=$navtitle;
 
//����,����λ��
$sid = '';
if ($forumsTree[$fid][type]=='sub')
{
	$sid  = $fid;
	$fid  = $fup;
	$fup  = $forumsTree[$fid]['fup'];
}
$position['sub']['name']	 = $forumsTree[$sid]['name'];
$position['group']['name']  = $forumsTree[$fup]['name'];
$position['forum']['name']	 = $forumsTree[$fid]['name'];
if($adbox[rewrite]){
	$position['group']['url']	 = "$adbox[list]$fup.html";
	$position['forum']['url']	 = "$adbox[list]$fid.html";
	$position['sub']['url']	 = "$adbox[list]$sid.html";
}else{
	$position['group']['url']	 = "plugin.php?id=attachcenter:list&fid=$fup";
	$position['forum']['url']	 = "plugin.php?id=attachcenter:list&fid=$fid";
	$position['sub']['url']	 = "plugin.php?id=attachcenter:list&fid=$sid";
}

$url = $adbox[rewrite] ? "$adbox[page]$_GET[aid].html" : "plugin.php?id=attachcenter:page&aid=$_GET[aid]";
$url = 'http://'. $_SERVER['HTTP_HOST'] . '/' . $url ;
$_G['setting']['seohead'] = '<link href="' .$url. '" rel="canonical" />';
 
$_hdtime = $adbox['hotdownday'];
$_hdnum  = $adbox['hotdownnum'];
$_hdtime = time() - $_hdtime*86400;	
$w_hdtime = "AND $tbAttach.dateline>$_hdtime";
 
  $query = DB::query("SELECT $tbAttach.*,$tbAttachIndex.* FROM $tbAttach,$tbAttachIndex,$tbThread WHERE $tbAttach.aid=$tbAttachIndex.aid AND $tbAttach.tid=$tbThread.tid AND $tbThread.fid='$attach[fid]' $w_hdtime ORDER BY $tbAttachIndex.downloads desc LIMIT $_hdnum");
  $HotDown = array();
while ($row = DB::fetch($query)) {
    $row['filesize'] = $row['filesize'] ? sizecount($row['filesize']) : 0;
    $row['url']	 = $adbox['rewrite']? "$adbox[page]$row[aid].html" : "plugin.php?id=attachcenter:page&aid=$row[aid]";
    $HotDown[] = $row ;
}
 
 
include template("attachcenter:page");
?>