<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
 
include_once "config.php";
include_once 'language.'.currentlang().'.php';
include_once DISCUZ_ROOT . "source/function/function_attachment.php"; 
include_once DISCUZ_ROOT . "source/function/function_discuzcode.php";
 
 
//��������-------------------------------------------------------------------------------------------------------------	
$adbox = $_G['cache']['plugin']['attachcenter'];
if ($adbox['list']=='') {$adbox['list']='list-';}
if ($adbox['page']=='') {$adbox['page']='page-';}	
$perpage = $adbox[perpage]== '' ? 20 : $adbox[perpage];
$_forumsfids = unserialize($adbox[forums]);
loadcache(array('forums'));
$_forumsTree = $_G['cache']['forums'];
//---------------------------------------------------------------------------------------------------------------------		
$tbAttach 		= DB::table('forum_attachment_u') ;
$tbThread 		= DB::table('forum_thread');	
$tbAttachIndex 	= DB::table('forum_attachment');
$where_fid = "";
$where_sc  = '';
$where_like = "";
$where_type  = '';

//��ർ��-------------------------------------------------------------------------------------------------------------	
if(count($_forumsfids)<=1){
	$forumsTree = $_forumsTree;
}else{
	$forumsTree = array();
	foreach($_forumsTree as $key => $bforum)
	{
		if( in_array($key  ,$_forumsfids)){ $forumsTree[$key]= $bforum;
			if(!in_array($_forumsTree[$bforum[fup]] ,$forumsTree)){ $forumsTree[$bforum[fup]]=$_forumsTree[$bforum[fup]];}
		}
	}
}
foreach($forumsTree as $key => $bforum)
{
	$bfname = rawurlencode($bforum[name]);
	if($adbox[rewrite]){
		$forumsTree[$key][url]="$adbox[list]$bforum[fid].html";
	}
	else{
		$forumsTree[$key][url]="plugin.php?id=attachcenter:list&fid=$bforum[fid]";
	}
}
 
//plugin.php?id=attachcenter:list ����----------------------------------------------------------------------------------
$AcIndex =  $adbox['rewrite'] ? "down.html" : "plugin.php?id=attachcenter"; 
$AcList  =  $adbox['rewrite'] ? trim($adbox['list'],'-') . ".html" : "plugin.php?id=attachcenter:list"; 

//��������������---------------------------------------------------------------------------------------------------------
$where_sc = "and $tbAttach.filename not regexp 'part[0-9][^1]\.rar|part[1-9]1\.rar|part[^1]\.rar'";
if( !empty($_GET[srchtxt])){
	$srchtxt = $_GET[srchtxt];
	if (!get_magic_quotes_gpc()) { 
		$srchtxt = addslashes($_GET[srchtxt]);
	} 
	$srchtxt = str_replace("_","\_",$srchtxt); 
	$srchtxt = str_replace("%","\%",$srchtxt); 
	$srchtxt=trim($srchtxt);
	$where_fid = '';
	$name=$aclang['search'];
	$where_sc = "and $tbAttach.filename like '%$srchtxt%'";
	$mpurl = "plugin.php?id=attachcenter:list&srchtxt=". rawurldecode($srchtxt);
}
else { $srchtxt = $aclang['sdefault'];}


?>