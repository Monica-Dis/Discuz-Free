<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if(!defined('IN_DISCUZ')) {
		exit('Access Denied');
	}
	list($gp_id)=explode(':', $_GET['id']);
	include "global.php";
 
//---------------------------------------------------------------------------------------------------------------------	
	//���ڲ�����һ���������ӷ���
	function getsubfids($fid, &$subfids){
		global $forumsTree;
		foreach($forumsTree as $key => $bforum){
				if ($key == $fid){
					$subfids[$key] = $key;
				} else if ($bforum['fup'] == $fid){
					$subfids[$key] = $key;
					getsubfids($key, $subfids);
				}
		}
		return $subfids;
	}
 
	//��ȡ����Ҫ���fid
	$fid = intval($_GET['fid']);
	$where_fid='';
	
	$subfids=array();
	if($fid){
		$fup   = $_forumsTree[$fid]['fup'];
		$name  = $_forumsTree[$fid]['name'];
		if( $fup==0) { $fup = $fid; }
		getsubfids($fid, $subfids);
		$fids=implode(",",$subfids);
		if ($fids == '') {$fids = '0';}
		$where_fid = "and $tbThread.fid in($fids)";
	}else{
		$name = $aclang['list'];
		$fup  = 0;
		$fid  = 0;
	}
 
	$sid='';
	$subfids=array();
	getsubfids($fid, $subfids);
	
	if ($forumsTree[$fid][type]=='forum' && count($subfids)>1)
	{
		$sid  = intval($_GET[fid]);
	}
	else if ($forumsTree[$fid][type]=='sub')
	{
		$sid  = $fid;
		$fid  = $fup;
		$fup  = $forumsTree[$fid]['fup'];
	}
	
	//����,����λ��
	$position['sub']['name']	 = $forumsTree[$sid]['name'];
	$position['group']['name']  = $forumsTree[$fup]['name'];
	$position['forum']['name']	 = $forumsTree[$fid]['name'];
	if($adbox[rewrite]){
		$position['group']['url']	 = "$adbox[list]$fup.html";
		$position['forum']['url']	 = "$adbox[list]$fid.html";
		$position['sub']['url']	 = "$adbox[list]$sid.html";
	}else{
		$position['group']['url']	 = "plugin.php?id=attachcenter:list&fid=$fup";
		$position['forum']['url']	 = "plugin.php?id=attachcenter:list&fid=$fid";
		$position['sub']['url']	 = "plugin.php?id=attachcenter:list&fid=$sid";
	}
	//---------------------------------------------------------------------------------------------------------------------	
	//�������
	$types = 1;
	if($types && null===$threadtypes) {
		$threadtypes = array();
		$querytmp = DB::query("SELECT * FROM ".DB::table('forum_threadclass'));
		while($value = DB::fetch($querytmp)) {
			$threadtypes[$value['typeid']] = $value;
		}
	}
	$typesname='';
	if($_GET[typeid]){
		$typeid     = intval($_GET[typeid]);
		$where_type = "and $tbThread.typeid ='$typeid'";
		$typesname  = $threadtypes[$typeid][name];
	}
	if ($typeid ==0){
		$typeid     = '0';
		$where_type = '';
		$typesname  = '';
	}
	//��Ա����-------------------------------------------------------------------------------------------------------------	
	$where_user = '';
	$get_user   = '';
	$uid = intval($_GET['uid']);
	if($adbox[userpage]==0){ $uid = 0; }
	if ($uid>0){
		$where_user = " and $tbAttach.uid ='$uid'";
		$get_user_h ="-".$uid;
		$get_user   ="&uid=".$uid;
		
		$query = DB::query("SELECT username FROM ".DB::table('common_member') ." WHERE uid='$uid'");
		$member = DB::fetch($query);
		$username=$member[username];
	}
 
	//------------------------------------------------------------------------------------------------------------------------------------
	$page = max(1, intval($_GET['page']));
	$start = ($page-1)*$perpage;
	if ($adbox[type])
		$mpurl = ($adbox['rewrite'] && !$uid) ? "$adbox[list]$fid-$typeid-$page.htm" : "plugin.php?id=attachcenter:list&typeid=$typeid=&fid=$fid$get_user";
	else{
		$mpurl = ($adbox['rewrite'] && !$uid) ? "$adbox[list]$fid-$page.html" : "plugin.php?id=attachcenter:list&fid=$fid$get_user";
	}
	if( !empty($_GET[srchtxt])){ $mpurl = "plugin.php?id=attachcenter:list&srchtxt=". rawurldecode($srchtxt); } else { $srchtxt = $aclang['sdefault']; }

	$multipage = '';
	$attach = array();
	$where_like = " and $tbAttach.isimage='0'"; //����ͼƬ
	$count = DB::result_first("SELECT COUNT(*) FROM $tbAttach,$tbThread  WHERE $tbAttach.tid=$tbThread.tid $where_fid $where_sc $where_type $where_like $where_user"); 
	if($count>0) {
		$query = DB::query("SELECT $tbAttach.aid,$tbAttach.filename,$tbAttach.filesize,$tbAttach.dateline,$tbThread.typeid,$tbThread.fid, $tbThread.subject
							FROM $tbAttach,$tbThread WHERE $tbAttach.tid=$tbThread.tid $where_fid $where_sc $where_type $where_like $where_user 
							order by aid desc LIMIT $start,$perpage");	//$tbThread.fid 
		while ($row = DB::fetch($query)) {
			if (empty($_GET['srchtxt'])){ $row['filename'] = preg_replace("/\.part[0-9]*1\.rar/i", ".rar", $row['filename']);}
			$row['filesize'] = $row['filesize'] ? sizecount($row['filesize']) : 0;
			$row['downloads'] =  DB::result_first("SELECT downloads from $tbAttachIndex WHERE  aid=$row[aid]");
			$ext  = strtolower( end ( explode('.' , $row['filename']) )); 
			if (preg_match("/^[\w\s-\.]+$/i", $row['filename'])) { $row['filename'] = $row['subject']. ': ' . $row['filename']; }
			$row['ext'] =  $ext;
			$row['icon'] = attachtype($ext."\t");
			$row['url']	 = $adbox['rewrite']? "$adbox[page]$row[aid].html" : "plugin.php?id=attachcenter:page&aid=$row[aid]";
			$row['type'] = $threadtypes[$row['typeid']]['name'];
			$row['typeurl'] = $adbox['rewrite'] ? "$adbox[list]$row[fid]-$row[typeid].htm" : "plugin.php?id=attachcenter:list&fid=$row[fid]&typeid=$row[typeid]";
			$attach[] = $row;
		}
		$multipage = multi($count, $perpage, $page, $mpurl);
		$multipage = preg_replace("/-[0-9]*(\.htm)(l?)\?page=([0-9]*)/i", "-\$3\$1$2", $multipage);
	}


	$navtitle		=$name;
	$metakeywords	=$name;
	$metadescription=$name;
 
	$srchtxt = stripslashes($srchtxt);
	//���Ÿ���
	$_hdtime = $adbox['hotdownday'];
	$_hdnum  = $adbox['hotdownnum'];
	$_hdtime = time() - $_hdtime*86400;	
	$w_hdtime = "AND $tbAttach.dateline>$_hdtime";

  $query = DB::query("SELECT $tbAttach.*,$tbAttachIndex.* FROM $tbAttach,$tbAttachIndex,$tbThread WHERE $tbAttach.aid=$tbAttachIndex.aid AND $tbAttach.tid=$tbThread.tid $where_fid $w_hdtime ORDER BY $tbAttachIndex.downloads desc LIMIT $_hdnum");
  $HotDown = array();
  while ($row = DB::fetch($query)) {
      $row['filesize'] = $row['filesize'] ? sizecount($row['filesize']) : 0;
      $row['url']	 = $adbox['rewrite']? "$adbox[page]$row[aid].html" : "plugin.php?id=attachcenter:page&aid=$row[aid]";
      $HotDown[] = $row ;
  }
 
  include template("attachcenter:list");
?>