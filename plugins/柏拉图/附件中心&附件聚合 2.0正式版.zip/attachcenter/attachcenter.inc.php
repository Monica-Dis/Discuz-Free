<?php
//����20180601
//���ԴӴ������ų�С���, ��������÷ֺŸ���, �ų��ĵİ���ڴ��������Ÿ���,�ų��İ���ö��Ÿ���
//����:      1;2-10,11,11;3;4;5




	if(!defined('IN_DISCUZ')) {
		exit('Access Denied');
	}

	include "global.php";
    $_G['setting']['mobile']['allowmobile']=0;

	if ($adbox[title]!=''){ $navtitle = $adbox[title]; }
	$metakeywords	=$adbox[keywords];
	$metadescription=$adbox[description];

	$delay_minutes = max(60, $adbox['att_minutes']);
	$lastTime      = DB::result_first("SELECT svalue FROM ".DB::table('common_setting')." WHERE skey='ac_attachment_time'"); 
	$lastaid       = DB::result_first("SELECT svalue FROM ".DB::table('common_setting')." WHERE skey='ac_attachment_aid'");
	$attlastaid    = DB::result_first("SELECT aid FROM  ".DB::table('forum_attachment')." order by aid desc limit 1");
	if($lastaid==0){die('&#x8BF7;&#x5230;&#x9644;&#x4EF6;&#x4E2D;&#x5FC3;&#x540E;&#x53F0;&#x66F4;&#x65B0;&#x9644;&#x4EF6;&#x7F13;&#x5B58;&#x8868;');}
	
	include template("common/header");
	
if((((time()-$lastTime)>=($delay_minutes*60)) && ($lastaid != $attlastaid)) || $lastTime==0)
{
	//���¸���ͬ��
	$successInsert=0;
	for($i=0;$i<10;$i++)
	{
		$forum_attachment_i = 'forum_attachment_'.$i;
		$query    = DB::query("SELECT aid,tid,pid,uid,dateline,filename,filesize,attachment,remote,description,readperm,price,isimage,width,thumb,picid FROM ".DB::table($forum_attachment_i)." WHERE aid >'$lastaid'");
		while($row = DB::fetch($query))
		{
			$row = daddslashes($row);
			$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_attachment_u')." WHERE aid='$row[aid]'");
			if($count==0){
				DB::insert('forum_attachment_u', $row);
				$successInsert=max($row['aid'], $successInsert);
			}
		}
	}
	if($successInsert>0){
		DB::query("REPLACE INTO ".DB::table('common_setting')." (`skey`, `svalue`) VALUES ('ac_attachment_aid', '$successInsert')");	
	}
	//=====================================================================================================================		
	//��ҳ����
	ob_start();
	//---------------------------------------------------------------------------------------------------------------------		
	$numNew = intval($adbox['newnum']) == 0 ? 8 : $adbox['newnum'];
	$numFid = intval($adbox['attnum']) == 0 ? 8 : $adbox['attnum'];
	if ($adbox['index_fid']==''){
		foreach($_forumsTree as $key => $bforum)
		{
			$fidArr[] = $bforum[fid];
		}
	}else{
		$fidArr = explode(';', trim($adbox['index_fid']));
	}
	//---------------------------------------------------------------------------------------------------------------------	
	//�������
	$threadtypes = array();
	if($adbox[type]) {
		$querytmp = DB::query("SELECT * FROM ".DB::table('forum_threadclass'));
		while($value = DB::fetch($querytmp)) {
			$threadtypes[$value['typeid']] = $value;
		}
	}
 
	//����ͼƬ����--------------------------------------------------------------------------------------------------------	

	//��ҳͼƬfid��ȡ
	$imgnum  = intval($adbox[imgnum]);
	$attachImgNew = array();
	if ($imgnum){
		if (isset($adbox['imgfid'])){
			$_imgfids = unserialize($adbox[imgfid]);
			$_imgfids = implode(",",$_imgfids);
			$where_imgfids ="and $tbAttach.tid=$tbThread.tid and $tbThread.fid in( $_imgfids )";
			$where_imgfrom = ",".$tbThread;
		}
		if ($_imgfids ==''){
			$where_imgfids = '';
			$where_imgfrom = '';
		}
		$query = DB::query("SELECT $tbAttach.aid,$tbAttach.filename,$tbAttach.attachment FROM $tbAttach$where_imgfrom where $tbAttach.isimage!='0' $where_imgfids order by aid desc LIMIT $imgnum");
		while ($row = DB::fetch($query)) {
			$row['attachment'] = $_G[setting][attachurl] .'forum/'. $row['attachment'];
			$row['url']	 = $adbox[rewrite]? "$adbox[page]$row[aid].html" : "plugin.php?id=attachcenter:page&aid=$row[aid]";
			$attachImgNew[]  = $row;
		}
	}
 
	//---------------------------------------------------------------------------------------------------------------------	
	//��������
	$query = DB::query("SELECT $tbAttach.aid,$tbAttach.filename,$tbAttach.filesize,$tbAttach.dateline,$tbThread.typeid,$tbThread.fid,$tbThread.subject
						FROM $tbAttach,$tbThread where $tbAttach.tid=$tbThread.tid and $tbAttach.isimage='0' $where_sc order by aid desc LIMIT $numNew");
	while ($row = DB::fetch($query)) {
		if (empty($_GET['srchtxt'])){ $row['filename'] = preg_replace("/\.part[0-9]*1\.rar/i", ".rar", $row['filename']);}
		$row[filesize] = $row[filesize] ? sizecount($row[filesize]) : 0;
		$ext  = strtolower( end ( explode('.' , $row['filename']) )); 
		$row['ext'] =  $ext;
		$row['icon'] = attachtype($ext."\t");	
		$row['url']	 = $adbox[rewrite]? "$adbox[page]$row[aid].html" : "plugin.php?id=attachcenter:page&aid=$row[aid]";
		$row['type'] = $threadtypes[$row['typeid']]['name'];
		$row['typeurl'] = $adbox[rewrite]? "$adbox[list]$row[fid]-$row[typeid].htm" : "plugin.php?id=attachcenter:list&fid=$row[fid]&typeid=$row[typeid]";
		if (preg_match("/^[\w\s-\.]+$/i", $row['filename'])) { $row['filename'] = $row['subject']. ': ' . $row['filename']; }
		$row['_filename'] = cutstr($row[filename], 40 - ($adbox[type] ? strlen($row['type']) + 2 : 0));	
		$attachNew[]  = $row;
	}
	
 	//���ӷ��࿪ʼ
 	$where_like = " and $tbAttach.isimage='0'"; //����ͼƬ

	foreach($fidArr as $fid)
	{
		list($fid, $unfid) = explode('-', $fid);
		if ($_forumsTree[$fid]['type'] == 'group') { 
			//��ȡ����fid
			$rows = array();
			$unfid = explode(',', $unfid);
			foreach($_forumsTree as $key => $bforum){
				if( $bforum['fup'] == $fid && !in_array($key, $unfid)){ $rows[]=$key; }
			}
			$fids=implode(",",$rows);
			$where_fid = "and $tbThread.fid in($fids)";
		}else{
			$where_fid = "and $tbThread.fid ='$fid'";
		}
		//------------------------------------------------------------------------------------------------------------------------------------
		$query = DB::query("SELECT $tbAttach.aid,$tbAttach.filename,$tbAttach.filesize,$tbAttach.dateline,$tbThread.subject
							FROM $tbAttach,$tbThread WHERE $tbAttach.tid=$tbThread.tid $where_fid $where_like $where_sc order by aid desc LIMIT $numFid");
		while ($row = DB::fetch($query)) {
			if (empty($_GET['srchtxt'])){ $row['filename'] = preg_replace("/\.part[0-9]*1\.rar/i", ".rar", $row['filename']);}
			if (preg_match("/^[\w\s-\.]+$/i", $row['filename'])) { $row['filename'] = $row['subject']. ': ' . $row['filename']; }
			$row['_filename'] = cutstr($row[filename], 30);		
			$row['filesize'] = $row[filesize] ? sizecount($row[filesize]) : 0;
			$ext  = strtolower( end ( explode('.' , $row['filename']) )); 
			$row['ext'] =  $ext;
			$row['icon'] = attachtype($ext."\t");	
			$row['url']	 = $adbox[rewrite]? "$adbox[page]$row[aid].html" : "plugin.php?id=attachcenter:page&aid=$row[aid]";
			$furl = $adbox[rewrite] ? "$adbox[list]$fid.html" : $forumsTree[$key][url]="plugin.php?id=attachcenter:list&fid=$fid";
			$attach[$fid][-1]  = array('id' => -1,  'name' => $_forumsTree[$fid][name],'url'=>$furl); //'fid' => $fid, 
			$attach[$fid][]  = $row;
		}
	}
	

	$count_att = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_attachment_u')." WHERE `isimage`!='0'"); 
	$count_max = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_attachment_u')); 
	$count_img = $count_max - $count_att;
	$fizesize_total = DB::result_first("SELECT SUM(filesize) FROM ".DB::table('forum_attachment_u')); 
	//$fizesize_total += 1024 * 1024 * 1024 *1024;
	$fizesize_total = sizecount($fizesize_total);

	//-------------------------------------------------------------------------------------------------------------------------------------------
	include template("attachcenter:index");
	$html_temp=ob_get_contents();
	ob_end_clean();
	$fp=fopen("data/cache/cache_attachcenter_index.htm",w);
	fwrite($fp,$html_temp) or die('&#x7F13;&#x5B58;&#x5931;&#x8D25;');
	fclose($fp);
	DB::query("REPLACE INTO ".DB::table('common_setting')." (`skey`, `svalue`) VALUES ('ac_attachment_time', '".time()."')");	
	echo $html_temp;
}
else{
	$fp = fopen('data/cache/cache_attachcenter_index.htm',"r");
	echo fread($fp,filesize('data/cache/cache_attachcenter_index.htm'));
	fclose($fp);
}



include template("common/footer");

?>