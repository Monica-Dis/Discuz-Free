<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if(!defined('IN_DISCUZ') || $_G['adminid'] != 1) {
	exit('Access Denied');
}

if($_GET['id']!='attachcenter:resetu'){
	echo "<script language='javascript' type='text/javascript'>window.location.href='plugin.php?id=attachcenter:resetu'</script>";
	exit;
}

if ($_GET['perpage']>0 && $_GET['code']==5678 && $_GET['formhash'] == formhash()){
	$tableid = intval($_GET['tableid']);
 	$start   = intval($_GET['start']);
 	$perpage = intval($_GET['perpage']);
 	if($perpage==0){$perpage = 100;}
	
	if($tableid>9){ 
		$endid = DB::result_first("SELECT aid FROM ".DB::table('forum_attachment')." order by aid desc LIMIT 1");
		$count_att = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_attachment_u')." WHERE isimage!='0'"); 
		$count_max = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_attachment_u')); 
		$count_img = $count_max - $count_att;
		
		DB::query("REPLACE INTO ".DB::table('common_setting')." (`skey`, `svalue`) VALUES ('ac_attachment_aid',  '$endid')");	
		DB::query("REPLACE INTO ".DB::table('common_setting')." (`skey`, `svalue`) VALUES ('ac_attachment_time', '0')");	
		exit( "&#x64CD;&#x4F5C;&#x5B8C;&#x6BD5;, &#x9644;&#x4EF6;&#x603B;&#x6570;:$count_max, &#x56FE;&#x7247;&#x603B;&#x6570;: $count_img, &#x975E;&#x56FE;&#x7247;&#x9644;&#x4EF6;:$count_att");
	}
 
	echo "&#x6B63;&#x5728;&#x64CD;&#x4F5C;&#x8868; forum_attachment_{$tableid} , &#x8FDB;&#x5EA6;: $start ...";
 	

 	if($tableid==0 && $start==0) {
		DB::query("DELETE FROM  ".DB::table('forum_attachment_u'));
 	}

	$forum_attachment_i = 'forum_attachment_'.$tableid;
	$query    = DB::query("SELECT aid,tid,pid,uid,dateline,filename,filesize,attachment,remote,description,readperm,price,isimage,width,thumb,picid FROM ".DB::table($forum_attachment_i)." LIMIT $start,$perpage");
	while($row = DB::fetch($query)){
		$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_attachment_u')." WHERE aid='$row[aid]'");
		if($count==0){
			DB::insert('forum_attachment_u', $row);
		}
	}
	if(DB::num_rows($query)==0){
		$tableid++;$start=0;
	}else{
		$start+=$perpage;
	}
	echo "<script language='javascript' type='text/javascript'>window.location.href='plugin.php?id=attachcenter:resetu&code=$_GET[code]&formhash=$_G[formhash]&tableid=$tableid&start=$start&perpage=$perpage'</script>";
	exit;
}elseif(isset($_GET['code'])){
	echo '&#x66F4;&#x65B0;&#x7F13;&#x5B58;&#x9519;&#x8BEF;<br><br>';
}

echo <<<EOT
		<form method="get" action="plugin.php">
		<input name="formhash" type="hidden" value="$_G[formhash]">
		<input name="perpage"  type="hidden" value="100">
		<input name="id"       type="hidden" value="attachcenter:resetu">
		&#x6821;&#x9A8C;&#x7801;: <input name="code" type="text" size=10> 5678 <input type="submit" style="height:20px;margin-left:10px;" value="&#x786E;&#x5B9A;">
		<br><br>
		&#x91CD;&#x5EFA;&#x9644;&#x4EF6;&#x7F13;&#x5B58;&#x8868;&#xFF0C;&#x5728;&#x91CD;&#x5EFA;&#x8FC7;&#x7A0B;&#x4E2D;&#x53EF;&#x80FD;&#x9700;&#x8981;&#x5F88;&#x957F;&#x65F6;&#x95F4;&#xFF0C;&#x5E76;&#x5360;&#x7528;&#x5927;&#x91CF;CPU&#xFF0C;&#x53EF;&#x80FD;&#x5F71;&#x54CD;&#x8BBA;&#x575B;&#x6B63;&#x5E38;&#x8FD0;&#x884C;<br><br>
		
		</form>
</div>
EOT;

?>