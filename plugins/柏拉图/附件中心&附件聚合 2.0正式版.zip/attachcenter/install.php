<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$ac_tb = DB::table('forum_attachment_u');

$sql = <<<EOT

DROP TABLE IF EXISTS `$ac_tb`;

CREATE TABLE `$ac_tb` (
  `aid` mediumint(8) unsigned NOT NULL,
  `tid` mediumint(8) unsigned NOT NULL default '0',
  `pid` int(10) unsigned NOT NULL default '0',
  `uid` mediumint(8) unsigned NOT NULL default '0',
  `dateline` int(10) unsigned NOT NULL default '0',
  `filename` varchar(255) NOT NULL default '',
  `filesize` int(10) unsigned NOT NULL default '0',
  `attachment` varchar(255) NOT NULL default '',
  `remote` tinyint(1) unsigned NOT NULL default '0',
  `description` varchar(255) NOT NULL,
  `readperm` tinyint(3) unsigned NOT NULL default '0',
  `price` smallint(6) unsigned NOT NULL default '0',
  `isimage` tinyint(1) NOT NULL default '0',
  `width` smallint(6) unsigned NOT NULL default '0',
  `thumb` tinyint(1) unsigned NOT NULL default '0',
  `picid` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`aid`),
  KEY `tid` (`tid`),
  KEY `pid` (`pid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;
EOT;

runquery($sql);

$finish = true;
?>