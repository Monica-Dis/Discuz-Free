timer(parseInt($("#L_time_stamp").val()),"clock");
function timer(intDiff,document){
    if($("#L_countdown").val()==1){
        window.setInterval(function(){
            var day=0,
                hour=0,
                minute=0,
                second=0;
            if(intDiff > 0){
                day = Math.floor(intDiff / (60 * 60 * 24));
                hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
            }else{
                window.location.href = "./index.php";
            }
            if (minute <= 9) minute = '0' + minute;
            if (second <= 9) second = '0' + second;
            var html = ' ';
                html+= '<div class="column days">';
                html+= '  <div class="timer" id="days">'+day+'</div>';
                html+= ' <div class="text">'+$("#L_time_day_lang").val()+'</div>';
                html+= ' </div>';

                html+= ' <div class="column">';
                html+= ' <div class="timer" id="hours">'+hour+'</div>';
                html+= ' <div class="text">'+$("#L_time_hours_lang").val()+'</div>';
                html+= ' </div>';

                html+= ' <div class="column">';
                html+= '<div class="timer" id="minutes">'+minute+'</div>';
                html+= ' <div class="text">'+$("#L_time_minutes_lang").val()+'</div>';
                html+= ' </div>';

                html+= '<div class="column">';
                html+= '<div class="timer" id="seconds">'+second+'</div>';
                html+= ' <div class="text">'+$("#L_time_seconds_lang").val()+'</div>';
                html+= '</div>';

            $("."+document).html(html)
            intDiff--;
        }, 1000);
    }
}
