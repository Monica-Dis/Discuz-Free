function IE() {
    "use strict";
     var ms_ie = false;
     var ua = window.navigator.userAgent;
     var old_ie = ua.indexOf('MSIE ');
     var new_ie = ua.indexOf('Trident/');

    if ((old_ie > -1) || (new_ie > -1)) {
        ms_ie = true;
    }

    if (ms_ie) {
         $('svg').css('margin-top','120px');
         // $('body').append("<div class='submarine_bg_ie' ><img src='img/png/submarine.png' width='100%' /></div> <div class='submarine_waves_ie' ><img src='img/png/waves.png' width='100%' /></div>");
    }
}

        $('.spinner').css('display','block');
$(function(){
        $('svg').css('opacity','0');
        $('nav').css('opacity','0');
        $('#Time_Countdown').css('opacity','0');
        $('#Bottom_Copyright').css('opacity','0');
        $('.error').css('opacity','0');

    setTimeout(function(){
        $('nav').css('opacity','1');
        $('svg').css('opacity','1');
        $('.error').css('opacity','1');
        $('.spinner').css('display','none');
        $('#Time_Countdown').css('opacity','1');
        $('#Bottom_Copyright').css('opacity','1');
        IE();
    }, 1200);
});

//倒计时  秒数，元素
timer(parseInt($("#L_time_stamp").val()),"Time_Countdown_text");


