;(function () {
    function timer(intDiff,document){
        if($("#L_countdown").val()==1){
            window.setInterval(function(){
                var day=0,
                    hour=0,
                    minute=0,
                    second=0;
                if(intDiff > 0){
                    day = Math.floor(intDiff / (60 * 60 * 24));
                    hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                    minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                    second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
                }else{
                    window.location.href = "./index.php";
                }
                if (minute <= 9) minute = '0' + minute;
                if (second <= 9) second = '0' + second;
                var html = ' ';
                html+= ' <div class="simply-section simply-days-section">';
                html+= '   <div>';
                html+= '  <span class="simply-amount">'+day+'</span>';
                html+= ' <span class="simply-word">'+$("#L_time_day_lang").val()+'</span></div>';
                html+= ' </div>';
                html+= ' <div class="simply-section simply-hours-section">';
                html+= '  <div>';
                html+= ' <span class="simply-amount">'+hour+'</span>';
                html+= '  <span class="simply-word">'+$("#L_time_hours_lang").val()+'</span></div>';
                html+= ' </div>';
                html+= ' <div class="simply-section simply-minutes-section">';
                html+= '  <div>';
                html+= '  <span class="simply-amount">'+minute+'</span>';
                html+= ' <span class="simply-word">'+$("#L_time_minutes_lang").val()+'</span></div>';
                html+= '   </div>';
                html+= ' <div class="simply-section simply-seconds-section">';
                html+= '  <div>';
                html+= '  <span class="simply-amount">'+second+'</span>';
                html+= '  <span class="simply-word">'+$("#L_time_seconds_lang").val()+'</span></div>';
                html+= '  </div>';
                $("."+document).html(html)
                intDiff--;
            }, 1000);
        }
    }

	var contentWayPoint = function() {
		var i = 0;
		$('.animate-box').waypoint( function( direction ) {

			if( direction === 'down' && !$(this.element).hasClass('animated-fast') ) {

				i++;

				$(this.element).addClass('item-animate');
				setTimeout(function(){

					$('body .animate-box.item-animate').each(function(k){
						var el = $(this);
						setTimeout( function () {
							var effect = el.data('animate-effect');
							if ( effect === 'fadeIn') {
								el.addClass('fadeIn animated-fast');
							} else if ( effect === 'fadeInLeft') {
								el.addClass('fadeInLeft animated-fast');
							} else if ( effect === 'fadeInRight') {
								el.addClass('fadeInRight animated-fast');
							} else {
								el.addClass('fadeInUp animated-fast');
							}

							el.removeClass('item-animate');
						},  k * 200, 'easeInOutExpo' );
					});

				}, 100);

			}

		} , { offset: '85%' } );
	};


	var goToTop = function() {

		$('.js-gotop').on('click', function(event){

			event.preventDefault();

			$('html, body').animate({
				scrollTop: $('html').offset().top
			}, 500, 'easeInOutExpo');

			return false;
		});

		$(window).scroll(function(){

			var $win = $(window);
			if ($win.scrollTop() > 200) {
				$('.js-top').addClass('active');
			} else {
				$('.js-top').removeClass('active');
			}

		});

	};


	// Loading page
	var loaderPage = function() {
		$(".fh5co-loader").fadeOut("slow");
	};


	var counterWayPoint = function() {
		if ($('#fh5co-counter').length > 0 ) {
			$('#fh5co-counter').waypoint( function( direction ) {

				if( direction === 'down' && !$(this.element).hasClass('animated') ) {
					setTimeout( counter , 400);
					$(this.element).addClass('animated');
				}
			} , { offset: '90%' } );
		}
	};

	$(function(){
        timer(parseInt($("#L_time_stamp").val()),"simply-countdown-one");
		contentWayPoint();
		goToTop();
		loaderPage();
		counterWayPoint();
	});

}());