$(window).load(function(){
     $('.preloader').fadeOut('slow');
});


/* =Main INIT Function
-------------------------------------------------------------- */
function initializeSite() {

	"use strict";

	//OUTLINE DIMENSION AND CENTER
	(function() {
	    function centerInit(){

			var sphereContent = $('.sphere'),
				sphereHeight = sphereContent.height(),
				parentHeight = $(window).height(),
				topMargin = (parentHeight - sphereHeight) / 2;

			sphereContent.css({
				"margin-top" : topMargin+"px"
			});

			var heroContent = $('.hero'),
				heroHeight = heroContent.height(),
				heroTopMargin = (parentHeight - heroHeight) / 3;

			heroContent.css({
				"margin-top" : heroTopMargin+"px"
			});

	    }

	    $(document).ready(centerInit);
		$(window).resize(centerInit);
	})();

	// Init effect 
	$('#scene').parallax();

};
/* END ------------------------------------------------------- */

/* =Document Ready Trigger
-------------------------------------------------------------- */
$(window).load(function(){
	initializeSite();
	(function() {
        timer(parseInt($("#L_time_stamp").val()),"countdown");
        $("#Button_like").css("top","70%");
	})();

});
/* END ------------------------------------------------------- */


function timer(intDiff,document){
    if($("#L_countdown").val()==1){
        window.setInterval(function(){
            var day=0,
                hour=0,
                minute=0,
                second=0;
            if(intDiff > 0){
                day = Math.floor(intDiff / (60 * 60 * 24));
                hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
            }else{
                window.location.href = "./index.php";
            }
            if (minute <= 9) minute = '0' + minute;
            if (second <= 9) second = '0' + second;
            var html = ' ';
            html+= day+'<span>'+$("#L_time_day_lang").val()+'</span>';
            html+= hour+'<span>'+$("#L_time_hours_lang").val()+'</span>';
            html+= minute+'<span>'+$("#L_time_minutes_lang").val()+'</span>';
            html+= second+'<span>'+$("#L_time_seconds_lang").val()+'</span>';
            $("."+document).html(html)
            intDiff--;
        }, 1000);
    }
}




