$(document).ready(function(){
    timer(parseInt($("#L_time_stamp").val()));
    //获取开始到结束总用时
    var L_start_stop_time = parseInt($("#L_start_stop_time").val());
    //初始化获取已用时多少秒
    var L_Ys_time = parseInt($("#L_Ys_time").val());
    function timer(intDiff){
        if($("#L_countdown").val()==1){
            window.setInterval(function(){
                var day=0,
                    hour=0,
                    minute=0,
                    second=0;
                if(intDiff > 0){
                    day = Math.floor(intDiff / (60 * 60 * 24));
                    hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                    minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                    second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
                }else{
                    window.location.href = "./index.php";
                }
                if (minute <= 9) minute = '0' + minute;
                if (second <= 9) second = '0' + second;
                $(".days .top,.days .bottom").text(day);
                $(".hours .top,.hours .bottom").text(hour);
                $(".minutes .top,.minutes .bottom").text(minute);
                $(".seconds .top,.seconds .bottom").text(second);
                //计算百分比
                var _This_Number = parseInt((L_Ys_time/L_start_stop_time).toFixed(2)*100);
                if(intDiff>1 && _This_Number==100){
                    $(".progressbars").css('width','99%');
                    $(".progressbars span").text('99%');
                }else{
                    $(".progressbars").css('width',_This_Number+'%');
                    $(".progressbars span").text(_This_Number+'%');
                }
                intDiff--;
                //获取已用时多久
                L_Ys_time++;
            }, 1000);
        }
    }
});
