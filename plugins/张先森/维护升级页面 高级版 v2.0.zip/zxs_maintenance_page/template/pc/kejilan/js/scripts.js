
jQuery(document).ready(function() {
	
    /*
        Fullscreen background
    */
    $.backstretch("source/plugin/zxs_maintenance_page/template/pc/kejilan/images/1.jpg");

    timer(parseInt($("#L_time_stamp").val()),"timer");

	$('.success-message').hide();
	$('.error-message').hide();

    
});

function timer(intDiff,document){
    if($("#L_countdown").val()==1){
        window.setInterval(function(){
            var day=0,
                hour=0,
                minute=0,
                second=0;
            if(intDiff > 0){
                day = Math.floor(intDiff / (60 * 60 * 24));
                hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
            }else{
                window.location.href = "./index.php";
            }
            if (minute <= 9) minute = '0' + minute;
            if (second <= 9) second = '0' + second;
            var html = ' ';
				html+= '<div class="days-wrapper">';
				html+= '<span class="days">'+day+'</span> <br>'+$("#L_time_day_lang").val();
				html+= ' </div>';
				html+= '<span class="slash">/</span>';
				html+= '<div class="hours-wrapper">';
				html+= ' <span class="hours">'+hour+'</span> <br>'+$("#L_time_hours_lang").val();
				html+= '</div>';
				html+= ' <span class="slash">/</span>';
				html+= ' <div class="minutes-wrapper">';
				html+= ' <span class="minutes">'+minute+'</span> <br>'+$("#L_time_minutes_lang").val();
				html+= ' </div>';
				html+= ' <span class="slash">/</span>';
				html+= '<div class="seconds-wrapper">';
				html+= ' <span class="seconds">'+second+'</span> <br>'+$("#L_time_seconds_lang").val();
				html+= '</div>';
                $("."+document).html(html)
            intDiff--;
        }, 1000);
    }
}




