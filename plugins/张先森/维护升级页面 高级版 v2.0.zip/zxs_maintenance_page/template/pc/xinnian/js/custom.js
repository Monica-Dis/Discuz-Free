
// preloader js
$(window).load(function(){
    $('.preloader').delay(1000) .fadeOut("slow"); // set duration in brackets    
});

$(function(){
    var intDiff = parseInt($("#L_time_stamp").val());
    if($("#L_countdown").val()==1){
        window.setInterval(function(){
            var day=0,
                hour=0,
                minute=0,
                second=0;
            if(intDiff > 0){
                day = Math.floor(intDiff / (60 * 60 * 24));
                hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
            }else{
                window.location.href = "./index.php";
            }
            if (minute <= 9) minute = '0' + minute;
            if (second <= 9) second = '0' + second;
            $("#countdown-globe-day").text(day);
            $("#countdown-globe-hours").text(hour);
            $("#countdown-globe-minutes").text(minute);
            $("#countdown-globe-seconds").text(second);
            intDiff--;
        }, 1000);
    }
});
