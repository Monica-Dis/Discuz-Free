<?php
/**
 * Created by PhpStorm.
 * User: zhangzhengpeng
 * Date: 2018\10\17
 * Time: 12:55
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
//如果插件未开启 && 当前用户存在组内 跳转回首页
$app_section = unserialize($_G['cache']['plugin']['zxs_maintenance_page']['L_normal']);
if(in_array($_G['groupid'], $app_section) || $_G['cache']['plugin']['zxs_maintenance_page']['L_switch']!=1){
    header("Location: index.php");
    die;
}

require_once 'source/plugin/zxs_maintenance_page/inc/comment.php';
$G_Phone = G_Phone::G_meat(); //判断当前是手机/电脑

//获取插件数据
$sql = DB::fetch_first('select * from %t where ID=%d',array(
    'plugin_zxs_maintenance_page',1
));
//模板选择
$template_G = $sql['template_name'];

//配置文件
$L_Comment = Array();
$L_Comment['L_title'] = empty($_G['cache']['plugin']['zxs_maintenance_page']['L_title'])?lang('plugin/zxs_maintenance_page', 'L_title_lang'):$_G['cache']['plugin']['zxs_maintenance_page']['L_title']; //网站标题
$L_Comment['L_body'] = empty($_G['cache']['plugin']['zxs_maintenance_page']['L_body'])?lang('plugin/zxs_maintenance_page', 'L_body_lang'):$_G['cache']['plugin']['zxs_maintenance_page']['L_body']; //网站内容
$L_Comment['L_countdown'] = $_G['cache']['plugin']['zxs_maintenance_page']['L_countdown']; //是否启用倒计时
$L_Comment['L_time_stamp'] = strtotime($_G['cache']['plugin']['zxs_maintenance_page']['L_stop_time'])-time(); //倒计时剩余时间
$L_Comment['L_buttom'] = Button_text($_G['cache']['plugin']['zxs_maintenance_page']['L_buttom']); //多按钮
$L_Comment['L_copyright'] = $_G['cache']['plugin']['zxs_maintenance_page']['L_copyright'];//底部版权说明
$L_Comment['L_Z_button'] = $_G['cache']['plugin']['zxs_maintenance_page']['L_Z_button'];//开启自定义背景
$L_Comment['L_banner_img'] = $_G['cache']['plugin']['zxs_maintenance_page']['L_banner_img'];//自定义背景url图片

//获取开始到结束时间
$L_Comment['L_start_stop_time'] = strtotime($_G['cache']['plugin']['zxs_maintenance_page']['L_stop_time']) - strtotime($_G['cache']['plugin']['zxs_maintenance_page']['L_start_time']);
//获取已用时多久
$L_Comment['L_Ys_time'] = time() - strtotime($_G['cache']['plugin']['zxs_maintenance_page']['L_start_time']);
//计算百分比
$L_Comment['percentage'] = floor(round($L_Comment['L_Ys_time']/$L_Comment['L_start_stop_time'],2)*100);



//循环按钮数组
function Button_text($array){
    global $_G;
    $data = explode('|',$array); //截取成数组
    //如果开启了登录提示按钮则只保留两个数组
    if($_G['cache']['plugin']['zxs_maintenance_page']['L_login_button']==1){
        $data = array_slice($data,0,2);
    }else{
        //保留前3个数组
        $data = array_slice($data,0,3);
    }
    $html = "";
    foreach($data as $k=>$v){
        $new_data = explode(',',$v);
        $U_states ="";
        if($new_data['2']==1)$U_states='target="_blank"';
        $html.="<li title='".$new_data['1']."'><a href='".$new_data['0']."' $U_states>".$new_data['1']."</a></li>";
    }
    //添加跳转按钮
    if($_G['cache']['plugin']['zxs_maintenance_page']['L_login_button']==1){
        $This_button = empty($_G['cache']['plugin']['zxs_maintenance_page']['L_login_button_text'])?lang('plugin/zxs_maintenance_page', 'countdown_login_sub'):$_G['cache']['plugin']['zxs_maintenance_page']['L_login_button_text'];
        $html.="<li title='".$This_button."'><a href='/member.php?mod=logging&action=login'>".$This_button."</a></li>";
    }
    return $html;
}

//调用模板页面
if($G_Phone==0){
    include template('zxs_maintenance_page:pc/'.$template_G.'/index');
}else{
    include template('zxs_maintenance_page:touch/'.$template_G);
}




