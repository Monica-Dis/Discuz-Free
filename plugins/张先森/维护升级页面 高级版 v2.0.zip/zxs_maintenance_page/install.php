<?php
/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 25889 2011-11-24 09:52:20Z monkey $
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS pre_plugin_zxs_maintenance_page (
  `ID` tinyint(10) NOT NULL COMMENT 'ID',
  `template_name` varchar(60) NOT NULL COMMENT 'm'
) ENGINE=MyISAM;

INSERT INTO `pre_plugin_zxs_maintenance_page` (`ID`, `template_name`) VALUES('1', 'default');

EOF;

runquery($sql);

$finish = TRUE;
?>