<?php
/**
 * Created by PhpStorm.
 * User: zhangzhengpeng
 * Date: 2018\10\18
 * Time: 12:55
 */


if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP'))
{
    exit('Access Denied');
}

$baseUrl = rawurldecode(cpurl());
$formUrl = ltrim($baseUrl, 'action=');


//安装初始化文件
if(submitcheck('sumbAction')){
    //保存数据到数据库中
    $data = DB::update('plugin_zxs_maintenance_page',array(
        'template_name' => $_GET['template_name']   //模板名称
    ),array(
        'ID' => 1
    ),true,true);
    //返回信息提示
    if($data){
        cpmsg(lang('plugin/zxs_maintenance_page', 'diy_success_lang'), "action=plugins&operation=config&do=" . $do . "&identifier=zxs_maintenance_page&pmod=zxs_maintenance_template", 'succeed');
    }
}
else{
    //获取插件数据
    $sql = DB::fetch_first('select * from %t where ID=%d',array(
        'plugin_zxs_maintenance_page',1
    ));

    showtagheader('div', 'start', true);
    showformheader($formUrl);
    showtableheader(lang('plugin/zxs_maintenance_page', 'H_template_selection_lang'));
/*    echo '<iframe src="http://dc.luqilina.com/zxs_discuz/" width="100%" frameborder="0" scrolling="no"></iframe>';  */
    echo '<style>
        #Template-Body{
           width: 80%; 
           position: absolute;
           top: 120px;
           left: 50px;
        }
        .Template-div{
            width: 150px;
            height: 150px;
            border: 1px solid #bbb;
            border-radius: 6px;
            cursor: pointer;
            position: relative;
            margin: 25px;
            display: inline-block;
        }
        .Template-div img{
            width: 100%;
            height: 100%;
            border-radius: 5px;
        }
        .Template-div.action{
            border: 2px solid red;
        }
        .Template-div.action .Check_the{
            background: url("./source/plugin/zxs_maintenance_page/img/select.png") center no-repeat;
            background-size: 100%;
            width: 50px;
            height: 50px;
            position: absolute; 
            bottom: 5px;
            right: 5px;
            z-index: 9999;  
        }
        .Template-div.action .Check_background{
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #000;
            opacity: 0.3;
            z-index: 999;
        }
        #This_Select_Text{
            position: absolute;
            bottom: -90px;
            left: 30px;
            font-size: 15px;
        }
        #This_Select_Text span{
            font-weight: bold;
        }
        #submit_editsubmit{
            width: 180px;
            height: 40px;
            background-color: #FF5722;
            color: #fff;
            font-size: 16px;
            line-height: 14px;
            text-align: center;
            position: absolute;
            bottom: -180px;
            left: 25px;
            border: 0;
            border-radius: 3px;
            font-weight: bold;
            letter-spacing: 5px;
        }
        #submit_editsubmit:hover{
             opacity: 0.8;
        }
        .Template-title{
            position: absolute;
            top: 170px;
            font-size: 14px;
            width: 150px;
            left: 0;
            font-weight: bold;
            text-align: center;
        }
         .Template-div .Check_skin{
            background: url("./source/plugin/zxs_maintenance_page/img/skin.png") center no-repeat;
            background-size: 100%;
            width: 20px;
            height: 20px;
            position: absolute;
            top: 5px;
            right: 5px;
            z-index: 9999;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0px 1px 5px #888888;
         }
          </style>';
    echo '<div id="Template-Body">
                <input type="hidden" name="template_name" value="'.$sql['template_name'].'" id="template_names">
                <div class="Template-div action" title="'.lang('plugin/zxs_maintenance_page', 'H_template_default_lang').'" click-data="default">
                    <img src="./source/plugin/zxs_maintenance_page/img/default.jpg" title="'.lang('plugin/zxs_maintenance_page', 'H_template_default_lang').'">
                    <span class="Template-title">'.lang('plugin/zxs_maintenance_page', 'H_template_default_lang').'</span>
                    <span class="Check_background"></span>
                    <span class="Check_the"></span>
                </div>
                <div class="Template-div" title="'.lang('plugin/zxs_maintenance_page', 'H_template_kejilan_lang').'" click-data="kejilan">
                    <img src="./source/plugin/zxs_maintenance_page/img/kejilan.jpg" title="'.lang('plugin/zxs_maintenance_page', 'H_template_kejilan_lang').'">
                     <span class="Template-title">'.lang('plugin/zxs_maintenance_page', 'H_template_kejilan_lang').'</span>
                    <span class="Check_background"></span>
                    <span class="Check_the"></span>
                </div>
                
                <div class="Template-div" title="'.lang('plugin/zxs_maintenance_page', 'H_template_xueshan_lang').'" click-data="xueshan">
                    <img src="./source/plugin/zxs_maintenance_page/img/xueshan.jpg" title="'.lang('plugin/zxs_maintenance_page', 'H_template_xueshan_lang').'">
                     <span class="Template-title">'.lang('plugin/zxs_maintenance_page', 'H_template_xueshan_lang').'</span>
                    <span class="Check_background"></span>
                     <span class="Check_skin" title="'.lang('plugin/zxs_maintenance_page', 'skin_background').'"></span>
                    <span class="Check_the"></span>
                </div>
                
                <div class="Template-div" title="'.lang('plugin/zxs_maintenance_page', 'H_template_yudi_lang').'" click-data="yudi">
                    <img src="./source/plugin/zxs_maintenance_page/img/yudi.jpg" title="'.lang('plugin/zxs_maintenance_page', 'H_template_yudi_lang').'">
                     <span class="Template-title">'.lang('plugin/zxs_maintenance_page', 'H_template_yudi_lang').'</span>
                    <span class="Check_background"></span>
                     <span class="Check_skin" title="'.lang('plugin/zxs_maintenance_page', 'skin_background').'"></span>
                    <span class="Check_the"></span>
                </div>
                
                <div class="Template-div" title="'.lang('plugin/zxs_maintenance_page', 'H_template_qingchen_lang').'" click-data="qingchen">
                    <img src="./source/plugin/zxs_maintenance_page/img/qingchen.jpg" title="'.lang('plugin/zxs_maintenance_page', 'H_template_qingchen_lang').'">
                     <span class="Template-title">'.lang('plugin/zxs_maintenance_page', 'H_template_qingchen_lang').'</span>
                    <span class="Check_background"></span>
                     <span class="Check_skin" title="'.lang('plugin/zxs_maintenance_page', 'skin_background').'"></span>
                    <span class="Check_the"></span>
                </div>
                
                <div class="Template-div" title="'.lang('plugin/zxs_maintenance_page', 'H_template_gonglu_lang').'" click-data="gonglu">
                    <img src="./source/plugin/zxs_maintenance_page/img/gonglu.jpg" title="'.lang('plugin/zxs_maintenance_page', 'H_template_gonglu_lang').'">
                     <span class="Template-title">'.lang('plugin/zxs_maintenance_page', 'H_template_gonglu_lang').'</span>
                    <span class="Check_background"></span>
                    <span class="Check_skin" title="'.lang('plugin/zxs_maintenance_page', 'skin_background').'"></span>
                    <span class="Check_the"></span>
                </div>
                
                <div class="Template-div" title="'.lang('plugin/zxs_maintenance_page', 'H_template_gaoduan_lang').'" click-data="gaoduan">
                    <img src="./source/plugin/zxs_maintenance_page/img/gaoduan.jpg" title="'.lang('plugin/zxs_maintenance_page', 'H_template_gaoduan_lang').'">
                     <span class="Template-title">'.lang('plugin/zxs_maintenance_page', 'H_template_gaoduan_lang').'</span>
                    <span class="Check_background"></span>
                      <span class="Check_skin" title="'.lang('plugin/zxs_maintenance_page', 'skin_background').'"></span>
                    <span class="Check_the"></span>
                </div>
                
                <div class="Template-div" title="'.lang('plugin/zxs_maintenance_page', 'H_template_fengjing_lang').'" click-data="fengjing">
                    <img src="./source/plugin/zxs_maintenance_page/img/fengjing.jpg" title="'.lang('plugin/zxs_maintenance_page', 'H_template_fengjing_lang').'">
                     <span class="Template-title">'.lang('plugin/zxs_maintenance_page', 'H_template_fengjing_lang').'</span>
                    <span class="Check_background"></span>
                     <span class="Check_skin" title="'.lang('plugin/zxs_maintenance_page', 'skin_background').'"></span>
                    <span class="Check_the"></span>
                </div>
                
                <div class="Template-div" title="'.lang('plugin/zxs_maintenance_page', 'H_template_shengdanjie_lang').'" click-data="shengdanjie">
                    <img src="./source/plugin/zxs_maintenance_page/img/shengdanjie.jpg" title="'.lang('plugin/zxs_maintenance_page', 'H_template_shengdanjie_lang').'">
                     <span class="Template-title">'.lang('plugin/zxs_maintenance_page', 'H_template_shengdanjie_lang').'</span>
                    <span class="Check_background"></span>
                    <span class="Check_the"></span>
                </div>

                <div class="Template-div" title="'.lang('plugin/zxs_maintenance_page', 'H_template_xinnian_lang').'" click-data="xinnian">
                    <img src="./source/plugin/zxs_maintenance_page/img/xinnian.jpg" title="'.lang('plugin/zxs_maintenance_page', 'H_template_xinnian_lang').'">
                     <span class="Template-title">'.lang('plugin/zxs_maintenance_page', 'H_template_xinnian_lang').'</span>
                    <span class="Check_background"></span>
                    <span class="Check_the"></span>
                </div>                
  
                  <div class="Template-div" title="'.lang('plugin/zxs_maintenance_page', 'H_template_heibai_lang').'" click-data="heibai">
                    <img src="./source/plugin/zxs_maintenance_page/img/heibai.jpg" title="'.lang('plugin/zxs_maintenance_page', 'H_template_heibai_lang').'">
                     <span class="Template-title">'.lang('plugin/zxs_maintenance_page', 'H_template_heibai_lang').'</span>
                    <span class="Check_background"></span>
                    <span class="Check_the"></span>
                </div>   
                              
                    <div id="This_Select_Text">'.lang('plugin/zxs_maintenance_page', 'current_template_lang').'<span></span></div>
                    <input type="submit" class="btn" id="submit_editsubmit" name="sumbAction" title="'.lang('plugin/zxs_maintenance_page', 'time_to_ave_lang').'" value="'.lang('plugin/zxs_maintenance_page', 'save_data_button_lang').'">  
                    <div style="position: absolute;bottom:-300px;height: 100px;width: 100px"></div>
           </div> 
    
           ';

    showtablefooter();/*Dism-taobao_com*/
    showformfooter();
    showtagfooter('div');

    echo ' 
        <script type="text/javascript" src="./source/plugin/zxs_maintenance_page/template/js/jquery.min.js"></script>
        <script>
            //初始化选择模板
            $(document).ready(function () {   
                $(".Template-div[click-data="+$("#template_names").val()+"]").click();
            })
            $(".Template-div").click(function(){
               $(this).siblings().removeClass("action"),$(this).addClass("action");
               $(".Template-title").css("color","#555");
               $(this).find(".Template-title").css("color","red");
               $("#This_Select_Text span").text($(this).attr("title"));
               $("#template_names").val($(this).attr("click-data"));
            })
        </script>
    ';


}


