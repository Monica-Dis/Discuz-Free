<?php
/**
 * Created by PhpStorm.
 * User: zhangzhengpeng
 * Date: 2018\10\18
 * Time: 10:10
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

//手机端入口
class mobileplugin_zxs_maintenance_page {
    function global_header_mobile(){
        global $_G;
        $TIME = time();
        $app_section = unserialize($_G['cache']['plugin']['zxs_maintenance_page']['L_normal']);
        //如果当前用户不在组内 && 插件状态启动 && 当前时间小于结束时间 && 手机版开启
        if (!in_array($_G['groupid'], $app_section) && $_G['cache']['plugin']['zxs_maintenance_page']['L_switch']==1 && $TIME<strtotime($_G['cache']['plugin']['zxs_maintenance_page']['L_stop_time']) && $_G['cache']['plugin']['zxs_maintenance_page']['L_wap']==1 && ($_GET['action'] != "login" && $_GET['mod'] != "register")) {
            //1.如果时间未开始
            if($TIME<strtotime($_G['cache']['plugin']['zxs_maintenance_page']['L_start_time'])) {
                //倒计时结束后自动跳转到页面
                $javaScript =  ' 
                     <script>
                     var G_TIME_START = '.strtotime($_G['cache']['plugin']['zxs_maintenance_page']['L_start_time']).';
                     var G_TIMES = '.$TIME.' , G_NUMBER = G_TIME_START - G_TIMES;
                     window.setInterval(function(){
                        console.log(G_NUMBER)
                        if(G_NUMBER<=0){
                            window.location.href = "./plugin.php?id=zxs_maintenance_page:zxs_maintenance_program";
                        }
                        --G_NUMBER;
                     }, 1000);
                     </script>
                ';
                return $javaScript;
            }
            //2.如果时间已开始
            else{
                header("Location: plugin.php?id=zxs_maintenance_page:zxs_maintenance_program");
                exit;
            }
        }
    }
}
