<?php
/**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Date: 2019\01\30
 * Time: 12:20
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once 'source/plugin/zxs_envelope_red/inc/Template.class.php';

global $_G;
$global_table = $_G['config']['db'][1]['tablepre'];
$global_cha = $_G['charset'] == "gbk" ? true : false;
$GTIME = "?id=" . time();
$Lang = $_G['cache']['plugin']['zxs_envelope_red'];
$urlAct = $_GET['act'];

class UserListGets
{
    /**
     * @param $number
     * @return array
     */
    public function userIntegral($number)
    {
        global $_G;
        $arr = array();
        foreach ($_G['setting']['extcredits'] as $extcreditid => $v) {
            $_G['setting']['extcredits'][$extcreditid]['num'] = getuserprofile('extcredits' . $extcreditid);
        }
        $arr['num'] = $_G['setting']['extcredits'][$number]['num'];
        $arr['title'] = $_G['setting']['extcredits'][$number]['title'];
        return $arr;
    }

    /**
     * @param $array
     * @return array|false|string
     */
    public function userGrounpJudg($array)
    {
        if (empty($array[0]) && count($array) == 1) {
            return "";
        } else {
            if (empty($array[0])) {
                unset($array[0]);
                $array = array_values($array);
            }
            $array = json_encode($array);
            return $array;
        }
    }

    /**
     * @param $fieldname
     * @param $states
     * @return array
     */
    public function userGrounpPermissionsList($fieldname, $states)
    {
        $groupselect = array();
        $sqlList = DB::fetch_first("SELECT $fieldname FROM %t WHERE ID=%d",
            array("plugin_zxs_envelope_permissions", 1));
        $sqlList = json_decode($sqlList[$fieldname]);
        foreach (C::t('common_usergroup')->range_orderby_credit() as $group) {
            $LKmp = "";
            if (!empty($states) && !empty($sqlList)) {
                if (in_array($group['groupid'], $sqlList)) {
                    $LKmp = "selected";
                }
            }
            $groupselect[$group['type']] .= '<option value="' . $group['groupid'] . '"' . $LKmp . '>' . $group['grouptitle'] . '</option>';
        }
        return $groupselect;
    }

    /**
     * @param $name
     * @param $data
     * @return string
     */
    public function Jurisdiction_area($name, $data)
    {
        $html = ' ';
        $html .= '<tr><td colspan="2" class="td27" s="1">' . lang('plugin/zxs_envelope_red',
                'Forbidden_' . $name) . '</td></tr> ';
        $html .= '<tr class="noborder"><td class="vtop rowform">
<select name="Forbidden_' . $name . '[]" size="10" multiple="multiple">
<option value="" selected="">' . lang('plugin/zxs_envelope_red', 'Lng_permissions_null') . '</option>
<optgroup label="' . lang('plugin/zxs_envelope_red', 'Lng_permissions_ex1') . '">' . $data['member'] . '</optgroup>   
<optgroup label="' . lang('plugin/zxs_envelope_red', 'Lng_permissions_ex2') . '">' . $data['special'] . '</optgroup>
<optgroup label="' . lang('plugin/zxs_envelope_red', 'Lng_permissions_ex3') . '">' . $data['system'] . '</optgroup></select></td>
<td class="vtop tips2" s="1">' . lang('plugin/zxs_envelope_red', 'Forbidden_' . $name . '_mes') . '<br>
' . lang('plugin/zxs_envelope_red', 'Forbidden_select_All') . '<br> 
</td></tr>';
        return $html;
    }

    /**
     * @param $groupName
     * @return bool
     */
    public function userJudgeResult($groupName)
    {
        global $_G;
        $sqlList = DB::fetch_first("SELECT $groupName FROM %t WHERE ID=%d",
            array("plugin_zxs_envelope_permissions", 1));
        $sqlList = json_decode($sqlList[$groupName]);
        if (in_array($_G['groupid'], $sqlList)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @return bool
     */
    public function pageControl()
    {
        $php_self = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], '/') + 1);
        return $php_self == "search.php" ? false : true;
    }

    /**
     * @param $userId
     * @return bool
     */
    public function friendFocus($userId)
    {
        global $_G;
        $user_id = $_G['uid'];
        if (!empty($userId)) {
            $User = DB::fetch_first("SELECT * FROM %t WHERE uid=%d and followuid=%d",
                array("home_follow", $user_id, $userId));
            return !empty($User) ? true : false;
        } else {
            return false;
        }
    }

    /**
     * @param $text
     * @param $symbol
     * @return array
     */
    public function Space_information($text, $symbol)
    {
        return explode($symbol, $text);
    }

    /**
     * @param $msg
     * @return false|string
     */
    public function JsonTranscoding($msg)
    {
        global $_G;
        $global_cha = $_G['charset'] == "gbk" ? true : false;
        return $global_cha ? iconv('gb2312', 'utf-8', $msg) : $msg;
    }

    /**
     * @param $arr
     * @return mixed
     */
    public function array_iconv($arr)
    {
        global $_G;
        $global_cha = $_G['charset'] == "gbk" ? true : false;
        return $global_cha ? eval('return ' . iconv('gb2312', 'utf-8', var_export($arr, true) . ';')) : $arr;
    }

    /**
     * @param $msg
     * @return false|string
     */
    public function SqlAddTranscoding($msg)
    {
        global $_G;
        $global_cha = $_G['charset'] == "gbk" ? true : false;
        return $global_cha ? iconv("UTF-8", "GBK//IGNORE", $msg) : $msg;
    }

    /**
     * @param $strContent
     * @return array|false|mixed|string|string[]|null
     */
    public function hongbaoUtftogbk($strContent)
    {
        global $_G;
        $strContent = dhtmlspecialchars($strContent);
        $s1 = iconv('utf-8', 'gbk', $strContent);
        $s0 = iconv('gbk', 'utf-8', $s1);
        if ($s0 == $strContent) {
            $tmpstr = $s1;
        } else {
            $tmpstr = $strContent;
        }
        if ($_G['charset'] == 'gbk') {
            return $tmpstr;
        } else {
            return $this->hongbaoGbktoutf($strContent);
        }
    }

    /**
     * @param $strContent
     * @return false|string
     */
    public function hongbaoGbktoutf($strContent)
    {
        $s1 = iconv('utf-8', 'gbk', $strContent);
        $s0 = iconv('gbk', 'utf-8', $s1);
        if ($s0 == $strContent) {
            $tmpstr = $s1;
        } else {
            $tmpstr = $strContent;
        }

        return iconv('gbk', 'utf-8', $tmpstr);
    }


    /**
     * @param $text
     * @return bool
     */
    public function redPassword($textJs)
    {
        $text = $this->JsonTranscoding($textJs);
        global $_G;
        $whiteList = $_G['cache']['plugin']['zxs_envelope_red']['O_White_list'];
        if ($whiteList && !empty($whiteList)) {
            $whiteListAry = explode("\n", $whiteList);
            $whiteListAry = array_slice($whiteListAry, 0, 100);
            foreach ($whiteListAry as $key => $value) {
                if (strpos($value, $textJs) !== false) {
                    return true;
                }
            }
        }
        $url = 'https://aip.baidubce.com/oauth/2.0/token';
        $post_data['grant_type'] = 'client_credentials';
        $post_data['client_id'] = 'a1clT2rtbriiPFGhrxrlptOv';
        $post_data['client_secret'] = '27QLMTQ8I44eWTmzG8d33K9yz7lnHZdE';
        $o = "&content=" . $text . "&";
        foreach ($post_data as $k => $v) {
            $o .= "$k=" . urlencode($v) . "&";
        }
        $post_data = substr($o, 0, -1);
        $res = $this->request_post($url, $post_data, $text);
        if ($res) {
            $ReviewStatus = $res['result']['spam'];
            if ($ReviewStatus == 0) {
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     * @param string $url
     * @param string $param
     * @param $text
     * @return bool|mixed
     */
    public function request_post($url = '', $param = '', $text)
    {
        if (empty($url) || empty($param)) {
            return false;
        }
        $postUrl = $url;
        $curlPost = $param;
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $postUrl);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $curlPost);
        $data = curl_exec($curl);
        curl_close($curl);
        if ($data && !empty($data)) {
            $dataAry = json_decode($data, true);
            $post_data = array('content' => $text);
            $dataResult = $this->send_post('https://aip.baidubce.com/rest/2.0/antispam/v2/spam?access_token=' . $dataAry['access_token'],
                $post_data);
            if ($dataResult) {
                return $dataResult;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * @param $url
     * @param $post_data
     * @return bool|mixed
     */
    public function send_post($url, $post_data)
    {
        $postdata = http_build_query($post_data);
        $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' => $postdata,
                'timeout' => 15 * 60
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        if ($result && !empty($result)) {
            return json_decode($result, true);
        } else {
            return false;
        }
    }


}


class RedEnvelopeList
{
    private $Uid;

    /**
     * RedEnvelopeList constructor.
     * @param $Uid
     */
    public function __construct($Uid)
    {
        $this->Uid = $Uid;
    }

    /**
     * @return array|bool
     */
    public function RedEnvelopeSql()
    {
        global $_G;
        $In_ID = "";
        $O_redNumber = $_G['cache']['plugin']['zxs_envelope_red']['O_redNumber'] > 20 ? 20 : $_G['cache']['plugin']['zxs_envelope_red']['O_redNumber'];
        $data = DB::fetch_all("select * from %t WHERE (bonus_states=%d OR bonus_states=%d OR bonus_userId=%d) and bonus_last_unit>%d",
            array("plugin_zxs_envelope_red_1", 1, 4, $this->Uid, 0));

        if (!empty($data)) {
            foreach ($data as $key => $value) {
                $In_ID .= $key + 1 == count($data) ? $value['ID'] . "" : $value['ID'] . ",";
            }
            if (!empty($In_ID)) {
                $sql_sa = DB::fetch_all("select Left_ID from %t where Left_ID in($In_ID) and user_id=%d", array(
                    'plugin_zxs_envelope_red_2',
                    $this->Uid
                ));
                if (!empty($sql_sa)) {
                    foreach ($data as $k => $v) {
                        foreach ($sql_sa as $key => $value) {
                            if ($value['Left_ID'] == $v['ID']) {
                                unset($data[$k]);
                            }
                        }
                    }
                }
                $data = array_slice($data, 0, $O_redNumber);
                return array_values($data);
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}


class EnvelopeConfiguratio
{

    /**
     * @return bool|string
     */
    public function redDisplayWindow()
    {
        global $_G;
        $Lang = $_G['cache']['plugin']['zxs_envelope_red'];
        $RedList = new RedEnvelopeList($_G['uid']);
        $USER_PRE = new UserListGets();
        $RedList = $RedList->RedEnvelopeSql();
        $maxRedNumber = $Lang['O_redNumber'] > 20 ? 20 : $Lang['O_redNumber'];
        $O_redNumber = count($RedList) > $maxRedNumber ? $maxRedNumber : count($RedList);
        $O_consumption = empty($Lang['O_consumption']) ? 0 : $Lang['O_consumption'];
        $O_consumption_number = empty($Lang['O_consumption_number']) ? 0 : $Lang['O_consumption_number'];
        $O_consumption_type = empty($Lang['O_consumption_type']) ? 1 : $Lang['O_consumption_type'];
        $O_integral = $USER_PRE->userIntegral(empty($Lang['O_integral']) ? 1 : $Lang['O_integral']);
        if ($O_consumption == 1) {
            $O_integral = $USER_PRE->userIntegral($O_consumption_type);
        }

        $rightStyle = $Lang['O_bottom_right_display'] == 1 ? 'none' : 'block';
        $before_Deduct = $USER_PRE->userJudgeResult("before_Deduct");
        $O_Animation_effects = $Lang['O_Animation_effects'] == 1 ? "action" : "";
        $suspensionCssLocation = (empty($Lang['O_bottom_right_float']) || $Lang['O_bottom_right_float'] == 2) ? "right:" . intval($Lang['O_bottom_right_css_right']) . "px" : "left:" . intval($Lang['O_bottom_right_css_left']) . "px";
        $suspensionCssBottom = "bottom:" . intval($Lang['O_bottom_right_css_bottom']) . "px";
        $suspensionText = (empty($Lang['O_bottom_right_text']) || mb_strlen($Lang['O_bottom_right_text'],
                "utf-8") < 8) ? languageFile('lng_suspension_text_memo') : $Lang['O_bottom_right_text'];
        if (mb_strlen($suspensionText, "utf-8") > 20) {
            $suspensionText = mb_substr($suspensionText, 0, 20, "UTF-8");
        }
        $userDayBonus = DB::fetch_first("SELECT count(*) count FROM " . DB::table('plugin_zxs_envelope_red_2') . " WHERE user_id='" . $_G['uid'] . "' and date_format(from_unixtime(add_time),'%Y-%m-%d')=date_format(now(),'%Y-%m-%d')");

        if ($USER_PRE->pageControl() && (($Lang['O_lq_Max'] == 0) || $userDayBonus['count'] < $Lang['O_lq_Max']) && $_GET['local'] != 'not' && $_GET['mod']!='register' && $this->verifyPopupWindow()) {

            $sqlList = DB::fetch_first("SELECT * FROM %t WHERE ID=%d",
                array("plugin_zxs_envelope_permissions", 1));
            $not_logged = $sqlList['not_logged'];
            $not_logged_text = $sqlList['not_logged_text'];

            if (empty($_COOKIE['zxs_envelope_red_display']) && !$USER_PRE->userJudgeResult("receive_group")) {
                if ($_G['uid']==0 && $not_logged==1) {
                    $RedList = array(
                        array(
                            "bonus_title" => empty($not_logged_text) ? languageFile('not_logged_texts') : $not_logged_text,
                            "uid" => 0,
                            "bonus_number" => 100,
                            "bonus_currency" => 2,
                            "bonus_states" => 3,
                            "bonus_userId" => 0,
                            "bonus_way_op" => 1,
                            "bonus_last_g" => 0,
                            "bonus_Money_Number" => 1,
                            "bonus_Get_conditions" => 1,
                            "bonus_template" => 1,
                            "bonus_last_unit" => 20,
                        )
                    );
                }
                if($RedList){
                    $html_data = '<div id="zxs_envelope_red_ALL">';
                    foreach ($RedList as $key => $value) {
                        $lastStatus = ($key + 1) >= count($RedList);
                        //模板一
                        if ($key != 0) {
                            $html_data .= '<div id="zxs_envelope_red_P_' . ($key + 1) . '" class="zxs_envelope_red_P_' . $value['bonus_template'] . '" style="display: none">';
                        } else {
                            $html_data .= '<div id="zxs_envelope_red_P_' . ($key + 1) . '" class="zxs_envelope_red_P_' . $value['bonus_template'] . '" style="display:' . $rightStyle . '">';
                        }

                        $template = new Templates();
                        $html_data .= $template->setTemplate($O_Animation_effects, $value, $RedList, $key, $O_consumption, $O_consumption_number, $O_integral, $before_Deduct,$value['bonus_template'], $lastStatus);

                        $html_data .= ' </div>';
                    }
                    $html_data .= '<div id="zxs_envelope_red_SlectNew" style="display:' . $rightStyle . '">';
                    $html_data .= ' <div class="zxs_envelope_red_SlectNumber">1' . languageFile('Lng_iop_x') . '<span>' . $O_redNumber . '</span></div>';
                    $html_data .= ' </div>';
                    $html_data .= '</div>';
                    if ($Lang['O_bottom_right_display'] == 1) {
                        $html_data .= '<div class="display-right-display-all" style="' . $suspensionCssLocation . ";" . $suspensionCssBottom . '">';
                        $html_data .= '<span class="display-right-display-close" title="' . languageFile('Lng_button_close') . '"></span>';
                        $html_data .= '<span class="display-right-display-text">' . $suspensionText . '</span>';
                        $html_data .= '<span class="display-right-display-button" title="' . languageFile('Lng_button_lqhb') . '"></span>';
                        $html_data .= '</div>';
                    }
                    return $html_data;
                }

            }
        } else {
            return false;
        }
    }

    /**
     * @param $total_money
     * @param $total_num
     * @return false|string
     */
    public function randomAmount($total_money, $total_num)
    {
        $data = array();
        $total_money = $total_money - $total_num;
        for ($i = $total_num; $i > 0; $i--) {
            $data[$i] = 1;
            $ls_money = 0;
            if ($total_money > 0) {
                if ($i == 1) {
                    $data[$i] += $total_money;
                } else {
                    $max_money = floor($total_money / $i);
                    $ls_money = mt_rand(0, $max_money);
                    $data[$i] += $ls_money;
                }
            }
            $total_money -= $ls_money;
        }
        $data = array_values($data);
        shuffle($data);
        return json_encode($data);
    }

    /**
     * @param $ID
     * @return int
     */
    public function randomDataNumber($ID)
    {
        $lastUint = 0;
        $sql = DB::fetch_first("select * from %t where ID=%d", array(
            'plugin_zxs_envelope_red_1',
            $ID
        ));
        if ($sql['bonus_states'] == 2 || $sql['bonus_states'] == 3) {
            return $sql['bonus_number'];
        } else {
            if ($sql['bonus_way_op'] == 1) {
                $newArray = json_decode($sql['random_amount']);
                $lastUint = $newArray[0];
                return $lastUint;
            } else {
                if ($sql['bonus_way_op'] == 2) {
                    return $sql['bonus_last_g'];
                }
            }
        }
    }

    /**
     * @return bool
     */
    public function verifyPopupWindow()
    {
        global $_G;
        $fixedSection = array();
        $fixedHtml = array();
        $Lang = $_G['cache']['plugin']['zxs_envelope_red'];
        if ($Lang['O_Html_clock'] == 1) {
            if (!empty($Lang['O_fixed_section']) && !empty($_G['forum']['fid'])) {
                preg_match_all('/\"(.*?)\"/', $Lang['O_fixed_section'], $fixedSection);
                if (in_array($_G['forum']['fid'], $fixedSection[1])) {
                    return true;
                }
            }
            if (!empty($Lang['O_fixed_html'])) {
                preg_match_all('/\"(.*?)\"/', $Lang['O_fixed_html'], $fixedHtml);
                $fixedHtml = $this->addressDefinition($fixedHtml[1]);
                if (in_array($_G['PHP_SELF'], $fixedHtml) && empty($_G['forum']['fid']) && $_G['tid'] == 0) {
                    return true;
                }
            }
            return false;
        } else {
            return true;
        }
    }

    /**
     * @param $array
     * @return mixed
     */
    public function addressDefinition($array)
    {
        foreach ($array as $k => $v) {
            switch ($v) {
                case 1 :
                    $array[$k] = "/forum.php";
                    break;
                case 2 :
                    $array[$k] = "/plugin.php";
                    break;
                case 3 :
                    $array[$k] = "/home.php";
                    break;
                default:
                    $array[$k] = "/forum.php";
                    break;
            }
        }
        return $array;
    }

}

/**
 * @param $data
 * @return array|false|string
 */
function gbk2utf8($data)
{
    if (is_array($data)) {
        return array_map('gbk2utf8', $data);
    }
    return iconv('gbk', 'utf-8', $data);
}

/**
 * @param $status
 * @param $msg
 * @param $data
 */
function informationJson($status, $msg, $data = '')
{
    echo json_encode(array(
        'status' => $status,
        'data' => $data,
        'msg' => $msg
    ));
    die;
}

/**
 * @param $str
 * @return mixed|string|null
 */
function languageFile($str)
{
    return lang('plugin/zxs_envelope_red', $str);
}

function G_meat()
{
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    if (preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i', $useragent) || preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',
            substr($useragent, 0, 4))) {
        return false;
    } else {
        return true;
    }
}


