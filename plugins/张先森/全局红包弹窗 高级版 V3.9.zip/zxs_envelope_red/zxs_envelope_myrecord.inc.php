<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018\11\19
 * Time: 18:37
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once 'source/plugin/zxs_envelope_red/inc/Comm.class.php';

if(empty($_G['uid'])){
    showmessage(languageFile('Lng_login_msg'),"member.php?mod=logging&action=login");
}
if(G_meat()){
    include template('zxs_envelope_red:myrecord');
}else{
    include template('zxs_envelope_red:touch/myrecord');
}
