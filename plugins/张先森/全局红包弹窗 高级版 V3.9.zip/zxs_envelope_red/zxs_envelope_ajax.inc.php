<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019\02\13
 * Time: 16:10
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once 'source/plugin/zxs_envelope_red/inc/Comm.class.php';
require_once libfile('function/credit');


if (empty($_G['uid']) && $urlAct != 'userHrob') {
    informationJson('300', $userInfo->JsonTranscoding(languageFile('Lng_login_msg')));
}

else if ($urlAct == 'user_Focus_List') {
    $user_id = $_G['uid'];
    $userInfo = new UserListGets();
    $hours_r = DB::fetch_all('select fuid,fusername from %t where uid=%d', array('home_friend', $user_id));
    foreach ($hours_r as $key => $value) {
        $hours_r[$key]['fusername'] = str_replace(' ', '', $value['fusername']);
    }
    !empty($hours_r) ? informationJson('200', '', $userInfo->array_iconv($hours_r)) : informationJson('300', '');
}

else if ($urlAct == 'bonus_add') {
    $userInfo = new UserListGets();
    $bonus_number = intval($_GET['bonus_number']);
    $bonus_title = $userInfo->hongbaoUtftogbk(str_replace(' ', '', $_GET['bonus_title']));
    $bonus_title_num = $_GET['bonus_title_num'];
    $bonus_states = $_GET['bonus_states'];
    $bonus_userId = $_GET['bonus_userId'];
    $bonus_password = $userInfo->hongbaoUtftogbk(str_replace(' ', '', $_GET['bonus_password']));
    $bonus_userName = $userInfo->hongbaoUtftogbk(str_replace(' ', '', $_GET['bonus_userName']));
    $bonus_way_op = intval($_GET['bonus_way_op']);
    $bonus_last_g = intval($_GET['bonus_last_g']);
    $bonus_Money_Number = intval($_GET['bonus_Money_Number']);
    $bonus_Get_conditions = $_GET['bonus_Get_conditions'];
    $bonus_template = intval($_GET['template_id']);
    $time = time();
    $user_id = $_G['uid'];
    $user_number_s = $userInfo->userIntegral(empty($Lang['O_integral']) ? 1 : $Lang['O_integral']);

    $userDayBonus = DB::fetch_first("SELECT count(*) count FROM " . DB::table('plugin_zxs_envelope_red_1') . " WHERE uid='$user_id' and date_format(from_unixtime(addtime),'%Y-%m-%d')=date_format(now(),'%Y-%m-%d')");

    if ($bonus_states == "3" && !empty($bonus_userName)) {
        $sql_user = C::t('common_member')->fetch_uid_by_username($bonus_userName);
        if (empty($sql_user)) {
            informationJson('300', $userInfo->JsonTranscoding(languageFile('Lng_Not_query_user')));
        } else {
            $bonus_userId = $sql_user;
        }
    }
    //Whether the amount of the user's red envelope exceeds the actual amount of the user's wallet
    if ($bonus_number > $user_number_s['num']) {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('Lng_amount_beyond')));
    }
    //Determines whether the current release exceeds a fixed peak
    else if ((!empty($Lang['O_fb_Max']) || $Lang['O_fb_Max'] != 0) && $userDayBonus['count'] >= $Lang['O_fb_Max']) {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('Lng_O_fb_Max')));
    }
    //If the current user is not allowed to publish a custom title and value=999
    else if (!$userInfo->userJudgeResult("Forbidden_Title") && $bonus_title_num == "999") {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('the_red_envelope')));
    }
    //Verify custom title sensitive terms
    else if ($bonus_title_num == "999" && $Lang['O_title_filter'] == 1) {
        $reviewResults = $userInfo->redPassword($bonus_title);
        if (!$reviewResults) {
            informationJson('300', $userInfo->JsonTranscoding(languageFile('Forbidden_Forbidden_Title_nulls')));
        }
    }
    //If the current user is not allowed to use the skins used
    else if (!$userInfo->userJudgeResult("Red_skin") && $bonus_template != 1) {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('the_pu_envelope')));
    }
    //The amount of the red envelope must not be greater than the amount of the red envelope /20. The amount of the red envelope must not be less than 1
    else if ($bonus_states == 1 && $bonus_way_op == 1 && $bonus_Money_Number > intval($bonus_number / 2)) {
        informationJson('300',
            $userInfo->JsonTranscoding(languageFile('Mes_coun_left') . intval($bonus_number / 2) . languageFile('Mes_coun_right')));
    }
    //If it is a fixed amount, the fixed amount shall not be greater than the total amount of the red envelope
    else if ($bonus_states == 1 && $bonus_way_op == 2 && $bonus_last_g > $bonus_number) {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('Mes_red_maxl')));
    }
    //If the username sent to the user for input is the current user
    else if ($bonus_states == 3 && $bonus_userName == $_G['username']) {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('Mes_username_kiss')));
    }
    //Finally, determine whether the user has the right to create a red envelope
    else if ($userInfo->userJudgeResult("Prohibit_create")) {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('Prohibit_create')));
    }
    //Verify the password length
    else if ($bonus_states == 4 && !empty($bonus_password) && mb_strlen($bonus_password, 'UTF8') >= 20) {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('Forbidden_Prohibit_results_length')));
    }
    //Verify password sensitive words in red packets
    else if ($bonus_states == 4 && !empty($bonus_password) && $Lang['O_password_filter'] == 1) {
        $reviewResults = $userInfo->redPassword($bonus_password);
        if (!$reviewResults) {
            informationJson('300', $userInfo->JsonTranscoding(languageFile('Forbidden_Prohibit_results_null')));
        }
    }

    $EnVode = new EnvelopeConfiguratio();
    $data_numbers_array = $bonus_way_op == 1 ? $EnVode->randomAmount($bonus_number, $bonus_Money_Number) : "";

    $dataOne = DB::insert('plugin_zxs_envelope_red_1', array(
        'bonus_title' => $bonus_title,
        'uid' => $user_id,
        'addtime' => $time,
        'bonus_number' => $bonus_number,
        'bonus_currency' => empty($Lang['O_integral']) ? 1 : $Lang['O_integral'],
        'bonus_states' => $bonus_states,
        'bonus_userId' => $bonus_userId,
        'bonus_way_op' => $bonus_way_op,
        'bonus_last_g' => $bonus_last_g,
        'bonus_Money_Number' => $bonus_Money_Number,
        'bonus_Get_conditions' => $bonus_Get_conditions,
        'bonus_template' => $bonus_template,
        'bonus_last_unit' => $bonus_number,
        'packets_password' => $bonus_password,
        'random_amount' => $data_numbers_array
    ), true, true, true);

    $dataTwo = DB::insert('plugin_zxs_envelope_red_2', array(
        'Left_ID' => DB::insert_id(),
        'user_id' => 0,
        'user_name' => "",
        'add_time' => $time,
        'unit' => 0
    ), true, true);

    updatemembercount($user_id, array(empty($Lang['O_integral']) ? 1 : $Lang['O_integral'] => - $bonus_number), true, '',
        languageFile('Lng_button_states'), languageFile('Lng_envelope_K'), languageFile('Lng_envelope_K'),
        languageFile('Lng_envelope_J') . $bonus_title);

    $HbMesgTis = languageFile('Lng_floabl_b_msg') . $bonus_title . languageFile('Lng_floabl_c_msg');
    notification_add($user_id, "system", $HbMesgTis);

    !empty($dataOne) ? informationJson('200',
        $userInfo->JsonTranscoding(languageFile('Lng_que_like'))) : informationJson('300',
        $userInfo->JsonTranscoding(languageFile('Lng_que_not')));
}

else if ($urlAct == 'userHrob') {
    $time = time();
    $user_id = $_G['uid'];
    $userInfo = new UserListGets();

    if (empty($user_id)) {
        $sqlList = DB::fetch_first("SELECT * FROM %t WHERE ID=%d",
            array("plugin_zxs_envelope_permissions", 1));
        $not_logged = $sqlList['not_logged'];

        if($not_logged==1){
            echo json_encode(array(
                'status' => '900',
                'msg' => $userInfo->JsonTranscoding(languageFile('Lng_login_msg'))
            ));
            die;
        }
    }


    $EnVode = new EnvelopeConfiguratio();
    $ID = $_GET['ID'];
    $passWord = $userInfo->hongbaoUtftogbk($_GET['passWord']);
    $random_amount_new = "";
    $randomDataNumber = $EnVode->randomDataNumber($ID);
    $userDayBonus = DB::fetch_first("SELECT count(*) count FROM " . DB::table('plugin_zxs_envelope_red_2') . " WHERE user_id='$user_id' and date_format(from_unixtime(add_time),'%Y-%m-%d')=date_format(now(),'%Y-%m-%d')");
    //Let's see if the claim condition is paying attention to me
    $sqlOrder = DB::fetch_first("SELECT * FROM %t WHERE ID =%d", array("plugin_zxs_envelope_red_1", $ID));
    $sqlOne = DB::fetch_first("SELECT * FROM %t WHERE user_id=%d and Left_ID =%d", array("plugin_zxs_envelope_red_2", $user_id, $ID));

    if ($sqlOrder['bonus_Get_conditions'] == 1 && $user_id != $sqlOrder['uid']) {
        $sqlOrderNew = $userInfo->friendFocus($sqlOrder['uid']);
        if (!$sqlOrderNew) {
            echo json_encode(array(
                'status' => '3001',
                'uid' => $sqlOrder['uid'],
                'msg' => $userInfo->JsonTranscoding(languageFile('Me_sysadmin_msg_user_6'))
            ));
            die;
        }
    }
    //Deduct the fee before use
    if($_GET['consumption_number']!='0' && $userInfo->userJudgeResult("before_Deduct")){
        $O_consumption_type = empty($Lang['O_consumption_type']) ? 1 : $Lang['O_consumption_type'];
        $userItem = DB::fetch_first("SELECT * FROM %t WHERE uid =%d", array("common_member_count", $user_id));
        $userUnit = $userItem["extcredits".$O_consumption_type];
        if((intval($userUnit) - intval($_GET['consumption_number'])) < 0){
            informationJson('300', $userInfo->JsonTranscoding(languageFile('Lng_amount_beyond')));
        }
        $O_integral = $userInfo->userIntegral($O_consumption_type);
        updatemembercount($user_id, array($O_consumption_type => - $_GET['consumption_number']), true, '', 123,
            languageFile('Me_sysadmin_msg_before_1'), languageFile('Me_sysadmin_msg_before_1'),
            languageFile('Me_sysadmin_msg_before_2') . $sqlOrder['bonus_title']);

        $HbMesgTis = languageFile('Me_sysadmin_msg_before_3') . $sqlOrder['bonus_title'] . languageFile('Me_sysadmin_msg_before_4') . $_GET['consumption_number'] . $O_integral['title'];
        notification_add($user_id, "system", $HbMesgTis);
    }

    //Whether the current user can receive this red envelope
    if ($userInfo->userJudgeResult("receive_group")) {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('Me_sysadmin_title')));
    }
    //Whether the number of red packets received by current users has reached the upper limit
    else if (!empty($Lang['O_lq_Max']) && $Lang['O_lq_Max'] != 0 && $userDayBonus['count'] >= $Lang['O_lq_Max']) {
        informationJson('300',
            $userInfo->JsonTranscoding(languageFile('Me_sysadmin_m_left')) . $Lang['O_lq_Max'] . languageFile('Me_sysadmin_m_right'));
    }
    //Whether the red envelope has been received by the user
    else if (!empty($sqlOne)) {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('Me_sysadmin_m_oppo')));
    }
    //Is there any money in the red envelope
    else if ($sqlOrder['bonus_last_unit'] <= 0) {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('Me_sysadmin_m_laiw')));
    }
    //The current password determines whether the red envelope is empty
    else if ($sqlOrder['bonus_states'] == 4 && empty($passWord)) {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('js_sy_red_password')));
    }
    //Password hongbao verify password
    else if ($sqlOrder['bonus_states'] == 4 && !empty($passWord)) {
        if (mb_strlen($passWord, 'UTF8') >= 20) {
            informationJson('300', $userInfo->JsonTranscoding(languageFile('Forbidden_Prohibit_results_length')));
        } else {
            if ($userInfo->hongbaoUtftogbk($sqlOrder['packets_password']) != $passWord) {
                informationJson('300', $userInfo->JsonTranscoding(languageFile('red_keyword_erro')));
            }
        }
    }

    if ($randomDataNumber > $sqlOrder['bonus_last_unit'] && $sqlOrder['bonus_last_unit'] > 0) {
        $randomDataNumber = $sqlOrder['bonus_last_unit'];
    }
    if ($randomDataNumber <= 0) {
        if ($sqlOrder['bonus_last_unit'] > 0 && $sqlOrder['bonus_states'] == 1 && $sqlOrder['bonus_way_op'] == 1) {
            $data = DB::update('plugin_zxs_envelope_red_1',
                array('bonus_last_unit' => 0),
                array('ID' => $ID),
                true, true);
        }
        informationJson('300', $userInfo->JsonTranscoding(languageFile('Me_sysadmin_msg_user_5')));
    }
    if ($sqlOrder['bonus_last_unit'] <= 0) {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('Me_sysadmin_m_laiw')));
    }
    if ($sqlOrder['bonus_way_op'] == 1) {
        $newArray = json_decode($sqlOrder['random_amount']);
        unset($newArray[0]);
        $newArray = array_values($newArray);
        $random_amount_new = json_encode($newArray);
    }
    $dataOne = DB::query("UPDATE %t SET bonus_last_unit = bonus_last_unit-$randomDataNumber,random_amount='$random_amount_new' WHERE ID = %d",
        array('plugin_zxs_envelope_red_1', $ID)
    );
    $dataTwo = DB::insert('plugin_zxs_envelope_red_2', array(
        'Left_ID' => $ID,
        'user_id' => $user_id,
        'user_name' => $_G['username'],
        'add_time' => $time,
        'unit' => $randomDataNumber
    ), true, true);

    $userInfo = new UserListGets();
    $SetUp['O_integral'] = $userInfo->userIntegral($sqlOrder['bonus_currency']);

    updatemembercount($user_id, array($sqlOrder['bonus_currency'] => $randomDataNumber), true, '', 123,
        languageFile('Me_sysadmin_msg_user_1'), languageFile('Me_sysadmin_msg_user_1'),
        languageFile('Me_sysadmin_msg_user_2') . $sqlOrder['bonus_title']);

    $HbMesgTis = languageFile('Me_sysadmin_msg_user_3') . $sqlOrder['bonus_title'] . languageFile('Me_sysadmin_msg_user_4') . $randomDataNumber . $SetUp['O_integral']['title'];
    notification_add($user_id, "system", $HbMesgTis);

    echo json_encode(array(
        'status' => '200',
        'money' => $randomDataNumber,
        'O_title' => $userInfo->JsonTranscoding($SetUp['O_integral']['title'])
    ));

}

else if ($urlAct == 'record_list_obtain') {
    $page = $_GET['currentPage'] ? intval($_GET['currentPage']) : 1;
    $perPageNums = 10;
    $limit = "limit";
    $offset = ($page - 1) * $perPageNums;
    $states = $_GET['states'];
    $year = $_GET['year'];
    $time = time();
    $user_id = $_G['uid'];
    $where = "";

    if ($states == 1) {
        $where = " where year(from_unixtime(add_time,'%Y-%m-%d'))='$year' and user_id='$user_id'";
        $orDers = " ORDER BY add_time DESC";
    } else {
        $where = " where year(from_unixtime(addtime,'%Y-%m-%d'))='$year' and uid='$user_id'";
        $orDers = " ORDER BY addtime DESC";
    }
    if ($states == 1) {
        $data = DB::fetch_all("select *,from_unixtime(addtime,'%Y-%m-%d %H:%i:%s')AS addtime,
                               from_unixtime(add_time,'%Y-%m-%d %H:%i:%s')AS add_time                               
                               from " . DB::table('plugin_zxs_envelope_red_1') . " as a left JOIN 
                               " . DB::table('plugin_zxs_envelope_red_2') . " as b on a.ID=b.Left_ID left JOIN 
                               " . DB::table('common_member') . " as c on a.uid=c.uid 
                               $where $orDers $limit $offset,$perPageNums"
        );

        $count = DB::fetch_first("SELECT count(*) count FROM " . DB::table('plugin_zxs_envelope_red_1') . " as a 
                                  left JOIN " . DB::table('plugin_zxs_envelope_red_2') . " as b on a.ID=b.Left_ID 
                                  left JOIN " . DB::table('common_member') . " as c on a.uid=c.uid $where");
    } else {
        $data = DB::fetch_all("select *,from_unixtime(addtime,'%Y-%m-%d %H:%i:%s')AS addtime from
            " . DB::table('plugin_zxs_envelope_red_1') . "$where $orDers $limit $offset,$perPageNums");
        $count = DB::fetch_first("select count(*) count from " . DB::table('plugin_zxs_envelope_red_1') . " $where");
    }
    $userInfo = new UserListGets();
    foreach ($data as $key => $value) {
        $bonusCurrency = $userInfo->userIntegral($data[$key]['bonus_currency']);
        $data[$key]['O_integral_title'] = $bonusCurrency['title'];
        $data[$key]['bonus_Get_conditions_t'] = $value['bonus_Get_conditions'] == 1 ? languageFile('record_15') : languageFile('record_16');
        if ($states == 1) {
            $data[$key]['username'] = $userInfo->hongbaoUtftogbk($data[$key]['username']);
        } else {
            $data[$key]['username'] = $_G['username'];
        }
    }
    if (!empty($data)) {
        echo json_encode(array(
            'status' => '200',
            'data' => $userInfo->array_iconv($data),
            'total' => $count['count']
        ));
        die;
    } else {
        informationJson('300', $userInfo->JsonTranscoding(languageFile('Lng_que_not')));
    }
}

else if ($urlAct == 'record_list_obtain_data') {
    $ID = $_GET['ID'];
    $userInfo = new UserListGets();
    $data = DB::fetch_all("select a.*,b.bonus_title,b.bonus_last_unit,b.bonus_states,b.bonus_Money_Number 
                           from " . DB::table('plugin_zxs_envelope_red_2') . " as a 
                           left join " . DB::table('plugin_zxs_envelope_red_1') . " as b on a.Left_ID = b.ID where 
                           Left_ID=%d and user_id!=%d", array($ID, 0));
    if (!empty($data)) {
        foreach ($data as $key => $value) {
            $data[$key]['user_name'] = $userInfo->hongbaoUtftogbk($data[$key]['user_name']);
            $data[$key]['add_time'] = date("Y-m-d H:i:s", $value['add_time']);
        }
        if ($data[0]['bonus_Money_Number'] == 0) {
            $data[0]['bonus_Money_Number'] = 1;
        }
    }
    !empty($data) ? informationJson('200', '',$userInfo->array_iconv($data)) : informationJson('300', $userInfo->JsonTranscoding(languageFile('record_20')));
}

else if ($urlAct == 'focusParty') {
    $userInfo = new UserListGets();
    $user_id = $_G['uid'];
    $id = $_POST['ID'];
    $sql = DB::fetch_first("SELECT * FROM %t WHERE uid =%d", array("common_member", $id));
    $time = time();

    $data = DB::insert('home_follow', array(
        'uid' => $user_id,
        'username'=>$_G['username'],
        'followuid' => $id,
        'bkname' => $sql['username'],
        'dateline'=>$time
    ), true, true);

    !empty($data) ? informationJson('200', $userInfo->JsonTranscoding(languageFile('record_30'))) : informationJson('300', $userInfo->JsonTranscoding(languageFile('record_31')));
}


