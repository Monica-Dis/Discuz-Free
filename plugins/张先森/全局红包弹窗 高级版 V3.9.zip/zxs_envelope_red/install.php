<?php
/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 25889 2011-11-24 09:52:20Z DISM��TAOBAO��COM $
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_plugin_zxs_envelope_advertising` (
  `ID` mediumint(10) NOT NULL AUTO_INCREMENT,
  `gid` int(20) NOT NULL,
  `img` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_plugin_zxs_envelope_permissions` (
  `ID` mediumint(10) NOT NULL AUTO_INCREMENT,
  `receive_group` text NOT NULL,
  `Prohibit_create` text NOT NULL,
  `Forbidden_Title` text NOT NULL,
  `before_Deduct` text NOT NULL,
  `Red_skin` text NOT NULL,
  `not_logged` int(20) NOT NULL,
  `not_logged_text` varchar(80) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_plugin_zxs_envelope_red_1` (
  `ID` mediumint(10) NOT NULL AUTO_INCREMENT,
  `bonus_title` varchar(80) NOT NULL,
  `uid` int(20) NOT NULL,
  `addtime` int(20) NOT NULL,
  `bonus_number` int(20) NOT NULL,
  `bonus_currency` int(20) NOT NULL,
  `bonus_states` int(20) NOT NULL,
  `bonus_userId` int(20) NOT NULL,
  `bonus_way_op` int(20) NOT NULL,
  `bonus_last_g` int(20) NOT NULL,
  `bonus_Money_Number` int(20) NOT NULL,
  `bonus_Get_conditions` int(20) NOT NULL,
  `bonus_template` int(20) NOT NULL,
  `bonus_last_unit` float(20,0) NOT NULL,
  `random_amount` text NOT NULL,
  `packets_password` varchar(50) NOT NULL,
  `expirationTime` int(20) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_plugin_zxs_envelope_red_2` (
  `ID` mediumint(10) NOT NULL AUTO_INCREMENT,
  `Left_ID` int(20) NOT NULL,
  `user_id` int(20) NOT NULL,
  `user_name` varchar(80) NOT NULL,
  `add_time` int(20) NOT NULL,
  `unit` float(20,0) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM;

INSERT INTO `pre_plugin_zxs_envelope_permissions` (`ID`) VALUES('1');
INSERT INTO `pre_plugin_zxs_envelope_advertising` (`gid`) VALUES('1');
EOF;

runquery($sql);

$finish = TRUE;
?>