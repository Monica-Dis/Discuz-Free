<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2018\11\15
 * Time: 13:55
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class mobileplugin_zxs_envelope_red {
    function global_header_mobile()
    {
        require_once 'source/plugin/zxs_envelope_red/inc/Comm.class.php';
        global $_G;
        if($_G['cache']['plugin']['zxs_envelope_red']['O_phone_Open']==1){
            $html = ' ';
            $EvCon = new EnvelopeConfiguratio();
            $ZxsRedStates = $EvCon->redDisplayWindow();
            if(!empty($ZxsRedStates)) {
                include template('zxs_envelope_red:index');
                return  $ZxsRedStates.$html;
            }
        }
    }
}




