<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2018\11\30
 * Time: 11:20
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

cronname:
removeRedEnvelopes;
week:
-1;
day:
-1;
hour:
1;
minute:
10;

require_once 'source/plugin/zxs_envelope_red/inc/Comm.class.php';
loadcache('plugin');
$O_Expiration_time = empty($Lang['O_Expiration_time']) ? 1 : $Lang['O_Expiration_time'];
$expirationTime = time() - (intval($O_Expiration_time) * 86400);
$userInfo = new UserListGets();
$uplateId = "";
$hours_r = DB::fetch_all('select ID,bonus_title,uid,bonus_currency,bonus_last_unit,bonus_title from %t where bonus_last_unit>%d and addtime<=%d',
    array('plugin_zxs_envelope_red_1', 0, $expirationTime));
if (!empty($hours_r)) {
    foreach ($hours_r as $k => $v) {
        $uplateId .= $k + 1 == count($hours_r) ? $v['ID'] . "" : $v['ID'] . ",";
    }
    $dataOne = DB::query("UPDATE %t SET bonus_last_unit =%d,random_amount = %d,expirationTime = %d WHERE ID in($uplateId)",
        array(
            'plugin_zxs_envelope_red_1',
            0,
            "",
            1
        ));
    if (!empty($dataOne)) {
        foreach ($hours_r as $k => $v) {
            $SetUp['O_integral'] = $userInfo->userIntegral($v['bonus_currency']);
            updatemembercount($v['uid'], array($v['bonus_currency'] => $v['bonus_last_unit']), true, '', 123,
                languageFile('Me_sysadmin_msg_user_111'), languageFile('Me_sysadmin_msg_user_111'),
                languageFile('Me_sysadmin_msg_user_122') . $v['bonus_title']);
            $HbMesgTis = languageFile('Me_sysadmin_msg_user_11') . $v['bonus_title'] . languageFile('Me_sysadmin_msg_user_12') . $v['bonus_last_unit'] . $SetUp['O_integral']['title'] . languageFile('Me_sysadmin_msg_user_13');
            notification_add($v['uid'], "system", $HbMesgTis);
        }
    }
}

