<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2018/11/20
 * Time: 11:42
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once 'source/plugin/zxs_envelope_red/inc/Comm.class.php';
$USER_PRE = new UserListGets();

$where = "where ID!='' ";
$allNumber = 10;
$pagesize = intval(empty($_GET['pagesize']) ? 1 : $_GET['pagesize']);

if (isset($_GET["last_s"])) {
    $nextNum = $pagesize - 1;
    $pagesize = $nextNum == 0 ? 1 : $nextNum;
}
if (isset($_GET["last_x"])) {
    $nextNum = $pagesize + 1;
    $pagesize = $nextNum <= intval($_GET['ThisNumber']) ? (intval(empty($_GET['pagesize']) ? 1 : $_GET['pagesize']) + 1) : $nextNum - 1;
}

if (isset($_GET["startline"]) && isset($_GET['endline']) && (isset($_GET['sqlKeywords']) || isset($_GET["last_x"]) || $_GET["last_s"])) {
    $starTime = strtotime($_GET["startline"]);
    $stopTime = strtotime($_GET["endline"]);
    $uid = $_GET['uid'];
    if ($starTime && $stopTime) {
        $where .= " and a.addtime>'$starTime' and a.addtime<$stopTime";
    }
    if (!empty($uid)) {
        $where .= " and a.uid='$uid' ";
    }
}

if (isset($_GET["cancelsubmit"])) {
    $data_delete = $_GET['del'];
    $deleteIdIn = "";
    $userInfo = new UserListGets();
    foreach ($data_delete as $key => $value) {
        $deleteIdIn .= $key + 1 == count($data_delete) ? $value . "" : $value . ",";
    }
    $uid_op = DB::fetch_all("SELECT uid,bonus_title,bonus_currency,bonus_last_unit FROM %t WHERE ID in($deleteIdIn)",
        array('plugin_zxs_envelope_red_1')
    );
    $delete = DB::query("DELETE FROM %t WHERE ID in($deleteIdIn)", array(
        'plugin_zxs_envelope_red_1'
    ));
    if (!empty($delete)) {
        foreach ($uid_op as $k => $v) {
            $SetUp['O_integral'] = $userInfo->userIntegral($v['bonus_currency']);
            updatemembercount($v['uid'], array($v['bonus_currency'] => $v['bonus_last_unit']), true, '', 123,
                languageFile('record_25'), languageFile('record_25'), languageFile('record_26') . $v['bonus_title']);
            $HbMesgTis = languageFile('record_27') . $v['bonus_title'] . languageFile('record_28') . $v['bonus_last_unit'] . $SetUp['O_integral']['title'] . languageFile('record_29');
            notification_add($v['uid'], "system", $HbMesgTis);
        }
    }
}

$pagesizeStar = ($pagesize - 1) * $allNumber;

$hbSql = DB::fetch_all("SELECT a.*,b.username FROM %t as a left join %t as b on a.uid=b.uid $where 
                        ORDER BY a.addtime DESC limit $pagesizeStar,$allNumber",
    array('plugin_zxs_envelope_red_1', 'common_member'));

$userInfo = new UserListGets();
foreach ($hbSql as $key => $value) {
    $hbSql[$key]['bonus_currency'] = $userInfo->userIntegral($value['bonus_currency']);
    $hbSql[$key]['bonus_currency'] = $hbSql[$key]['bonus_currency']['title'];
    $hbSql[$key]['addtime'] = date("Y-m-d H:i:s", $value['addtime']);
}
$hbCount = DB::fetch_first("SELECT count(*) count FROM %t as a left join %t as b  on a.uid=b.uid $where"
    , array('plugin_zxs_envelope_red_1', 'common_member'));

$LastCountPage = intval($hbCount['count'] / $allNumber) == 0 ? 1 : intval($hbCount['count'] / $allNumber) + 1;

!$_GET['startline'] && $_GET['startline'] = date("Y-m-d 00:00", $_G['timestamp'] - (86400 * 365));
!$_GET['endline'] && $_GET['endline'] = date("Y-m-d 23:59", $_G['timestamp']);

include template("zxs_envelope_red:admin");