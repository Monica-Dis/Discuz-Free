<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
loaducenter();
$formhash = FORMHASH;
$tchongbaoConfig = $_G['cache']['plugin']['tom_tchongbao'];
$tchongbaoConfig['hb_lq_type'] = 1;
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowYear = dgmdate($_G['timestamp'], 'Y', $tomSysOffset);
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login_ajax.php';
include DISCUZ_ROOT . './source/plugin/tom_tchongbao/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
$pay_hosts = '';
$tchongbaoConfig['tongcheng_hosts'] = trim($tchongbaoConfig['tongcheng_hosts']);
$tchongbaoConfig['hongbao_hosts'] = trim($tchongbaoConfig['hongbao_hosts']);
if ($tchongbaoConfig['open_only_hosts'] == 1 && !empty($tchongbaoConfig['tongcheng_hosts']) && !empty($tchongbaoConfig['hongbao_hosts'])) {
	if (strpos($_G['siteurl'], $tchongbaoConfig['tongcheng_hosts']) === false && strpos($_G['siteurl'], $tchongbaoConfig['hongbao_hosts']) !== false) {
		$pay_hosts = str_replace($tchongbaoConfig['hongbao_hosts'], $tchongbaoConfig['tongcheng_hosts'], $_G['siteurl']);
		if ($tchongbaoConfig['must_http'] == 1) {
			if (strpos($pay_hosts, 'https') === false) {
				$pay_hosts = str_replace('http', 'https', $pay_hosts);
			}
		}
	}
}
$__ShowTcshop = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcshop/tom_tcshop.inc.php')) {
	$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
	if ($tcshopConfig['open_tcshop'] == 1) {
		$__ShowTcshop = 1;
	}
}
$__ShowTcqianggou = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')) {
	$tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
	if ($tcqianggouConfig['open_tcqianggou'] == 1) {
		$__ShowTcqianggou = 1;
	}
}
if ($_GET['act'] == 'open_hb' && $_GET['formhash'] == FORMHASH) {
	$kouling = isset($_GET['kouling']) ? daddslashes(diconv(urldecode($_GET['kouling']), 'utf-8')) : '';
	$hongbao_id = isset($_GET['hongbao_id']) ? intval($_GET['hongbao_id']) : 0;
	$tongcheng_id = isset($_GET['tongcheng_id']) ? intval($_GET['tongcheng_id']) : 0;
	$tchongbaoInfo = C::t('#tom_tchongbao#tom_tchongbao')->fetch_by_id($hongbao_id);
	if (!$tchongbaoInfo) {
		echo '301';
		exit(0);
	}
	if ($tchongbaoInfo['pay_status'] != 2 || $tchongbaoInfo['status'] != 1 || $tchongbaoInfo['only_show'] != 1) {
		echo '305';
		exit(0);
	}
	if ($tchongbaoInfo['open_kouling'] == 1 && $tchongbaoInfo['kouling'] != $kouling) {
		echo '303';
		exit(0);
	}
	$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tchongbaoInfo['user_id']);
	$tchongbaoLogInfo = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_list(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
	if (is_array($tchongbaoLogInfo) && !empty($tchongbaoLogInfo[0])) {
		echo '304';
		exit(0);
	}
	$tchongbaoLogCount = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_count(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ');
	$tchongbaoLogList = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_list(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ', 'ORDER BY id DESC', 0);
	if ($tchongbaoLogCount >= $tchongbaoInfo['hb_count'] || $tchongbaoInfo['money'] <= 0) {
		$updateData = array();
		$updateData['status'] = 2;
		C::t('#tom_tchongbao#tom_tchongbao')->update($tchongbaoInfo['id'], $updateData);
		echo '305';
		exit(0);
	}
	$randMoney = 0;
	$shengyuHongbaoNum = $tchongbaoInfo['hb_count'] - $tchongbaoLogCount;
	if ($tchongbaoInfo['fenpei_status'] == 1) {
		if ($shengyuHongbaoNum > 1) {
			$randMoney = $tchongbaoInfo['all_money'] / $tchongbaoInfo['hb_count'];
		} else {
			$randMoney = $tchongbaoInfo['money'];
		}
	} else {
		if ($shengyuHongbaoNum > 1) {
			$pjMoney = number_format($tchongbaoInfo['money'] / $shengyuHongbaoNum, 2);
			include DISCUZ_ROOT . './source/plugin/tom_tchongbao/module/hongbaojisuan.php';
		} else {
			$randMoney = $tchongbaoInfo['money'];
		}
	}
	$insertData = array();
	$insertData['hongbao_id'] = $tchongbaoInfo['id'];
	$insertData['user_id'] = $__UserInfo['id'];
	$insertData['nickname'] = $__UserInfo['nickname'];
	$insertData['user_picurl'] = $__UserInfo['picurl'];
	$insertData['money'] = $randMoney;
	$insertData['log_time'] = TIMESTAMP;
	C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->insert($insertData);
	DB::query('UPDATE ' . DB::table('tom_tchongbao') . (' SET money = money - ' . $randMoney . ' WHERE id=\'' . $tchongbaoInfo['id'] . '\''), 'UNBUFFERED');
	$insertData = array();
	$insertData['user_id'] = $__UserInfo['id'];
	$insertData['type_id'] = 4;
	$insertData['change_money'] = $randMoney;
	$insertData['old_money'] = $__UserInfo['money'];
	$insertData['tag'] = lang('plugin/tom_tchongbao', 'db_tag');
	$insertData['beizu'] = lang('plugin/tom_tchongbao', 'db_beizu_1') . $tongcheng_id . lang('plugin/tom_tchongbao', 'db_beizu_2') . $userInfo['nickname'];
	$insertData['log_time'] = TIMESTAMP;
	C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
	DB::query('UPDATE ' . DB::table('tom_tongcheng_user') . (' SET money = money + ' . $randMoney . ' WHERE id=\'' . $__UserInfo['id'] . '\''), 'UNBUFFERED');
	if ($tchongbaoInfo['site_id'] == 1) {
		$sitename = $tongchengConfig['plugin_name'];
	} else {
		$sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tchongbaoInfo['site_id']);
		$sitename = $sitesInfoTmp['name'];
	}
	if ($tchongbaoConfig['open_lq_sms'] == 1) {
		$appid = trim($tongchengConfig['wxpay_appid']);
		$appsecret = trim($tongchengConfig['wxpay_appsecret']);
		include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
		$weixinClass = new weixinClass($appid, $appsecret);
		if (!empty($tchongbaoConfig['template_id'])) {
			$template_id = $tchongbaoConfig['template_id'];
		} else {
			$template_id = $tongchengConfig['template_id'];
		}
		include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/templatesms.class.php';
		$access_token = $weixinClass->get_access_token();
		if ($access_token && !empty($userInfo['openid'])) {
			$hongbao_template_url = tom_link_replace($_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=hbao&xxid=' . $tongcheng_id));
			$templateSmsClass = new templateSms($access_token, $hongbao_template_url);
			$hongbao_template_first = str_replace('{NICKNAME}', $__UserInfo['nickname'], lang('plugin/tom_tchongbao', 'template_sms_fhb_user'));
			$hongbao_template_first = str_replace('{MONEY}', $randMoney, $hongbao_template_first);
			$smsData = array('first' => $hongbao_template_first, 'keyword1' => $sitename, 'keyword2' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s', $tomSysOffset), 'remark' => '');
			@($r = $templateSmsClass->sendSms01($userInfo['openid'], $template_id, $smsData));
		}
	}
	echo '200';
	exit(0);
} else {
	if ($_GET['act'] == 'open_tcshop_hb' && $_GET['formhash'] == FORMHASH) {
		$kouling = isset($_GET['kouling']) ? daddslashes(diconv(urldecode($_GET['kouling']), 'utf-8')) : '';
		$hongbao_id = isset($_GET['hongbao_id']) ? intval($_GET['hongbao_id']) : 0;
		$tcshop_id = isset($_GET['tcshop_id']) ? intval($_GET['tcshop_id']) : 0;
		$tchongbaoInfo = C::t('#tom_tchongbao#tom_tchongbao')->fetch_by_id($hongbao_id);
		if (!$tchongbaoInfo) {
			echo '301';
			exit(0);
		}
		if ($tchongbaoInfo['pay_status'] != 2 || $tchongbaoInfo['status'] != 1 || $tchongbaoInfo['only_show'] != 1) {
			echo '305';
			exit(0);
		}
		if ($tchongbaoInfo['open_kouling'] == 1 && $tchongbaoInfo['kouling'] != $kouling) {
			echo '303';
			exit(0);
		}
		$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tchongbaoInfo['user_id']);
		$tchongbaoLogInfo = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_list(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
		if (is_array($tchongbaoLogInfo) && !empty($tchongbaoLogInfo[0])) {
			echo '304';
			exit(0);
		}
		$tchongbaoLogCount = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_count(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ');
		$tchongbaoLogList = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_list(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ', 'ORDER BY id DESC', 0);
		if ($tchongbaoLogCount >= $tchongbaoInfo['hb_count'] || $tchongbaoInfo['money'] <= 0) {
			$updateData = array();
			$updateData['status'] = 2;
			C::t('#tom_tchongbao#tom_tchongbao')->update($tchongbaoInfo['id'], $updateData);
			echo '305';
			exit(0);
		}
		$randMoney = 0;
		$shengyuHongbaoNum = $tchongbaoInfo['hb_count'] - $tchongbaoLogCount;
		if ($tchongbaoInfo['fenpei_status'] == 1) {
			if ($shengyuHongbaoNum > 1) {
				$randMoney = $tchongbaoInfo['all_money'] / $tchongbaoInfo['hb_count'];
			} else {
				$randMoney = $tchongbaoInfo['money'];
			}
		} else {
			if ($shengyuHongbaoNum > 1) {
				$pjMoney = number_format($tchongbaoInfo['money'] / $shengyuHongbaoNum, 2);
				include DISCUZ_ROOT . './source/plugin/tom_tchongbao/module/hongbaojisuan.php';
			} else {
				$randMoney = $tchongbaoInfo['money'];
			}
		}
		$insertData = array();
		$insertData['hongbao_id'] = $tchongbaoInfo['id'];
		$insertData['user_id'] = $__UserInfo['id'];
		$insertData['nickname'] = $__UserInfo['nickname'];
		$insertData['user_picurl'] = $__UserInfo['picurl'];
		$insertData['money'] = $randMoney;
		$insertData['log_time'] = TIMESTAMP;
		C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->insert($insertData);
		DB::query('UPDATE ' . DB::table('tom_tchongbao') . (' SET money = money - ' . $randMoney . ' WHERE id=\'' . $tchongbaoInfo['id'] . '\''), 'UNBUFFERED');
		$insertData = array();
		$insertData['user_id'] = $__UserInfo['id'];
		$insertData['type_id'] = 4;
		$insertData['change_money'] = $randMoney;
		$insertData['old_money'] = $__UserInfo['money'];
		$insertData['tag'] = lang('plugin/tom_tchongbao', 'db_tag');
		$insertData['beizu'] = lang('plugin/tom_tchongbao', 'shop_beizu_1') . $tcshop_id . lang('plugin/tom_tchongbao', 'shop_beizu_2') . $userInfo['nickname'];
		$insertData['log_time'] = TIMESTAMP;
		C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
		DB::query('UPDATE ' . DB::table('tom_tongcheng_user') . (' SET money = money + ' . $randMoney . ' WHERE id=\'' . $__UserInfo['id'] . '\''), 'UNBUFFERED');
		if ($tchongbaoInfo['site_id'] == 1) {
			$sitename = $tongchengConfig['plugin_name'];
		} else {
			$sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tchongbaoInfo['site_id']);
			$sitename = $sitesInfoTmp['name'];
		}
		if ($tchongbaoConfig['open_lq_sms'] == 1) {
			$appid = trim($tongchengConfig['wxpay_appid']);
			$appsecret = trim($tongchengConfig['wxpay_appsecret']);
			include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
			$weixinClass = new weixinClass($appid, $appsecret);
			if (!empty($tchongbaoConfig['template_id'])) {
				$template_id = $tchongbaoConfig['template_id'];
			} else {
				$template_id = $tongchengConfig['template_id'];
			}
			include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/templatesms.class.php';
			$access_token = $weixinClass->get_access_token();
			if ($access_token && !empty($userInfo['openid'])) {
				$hongbao_template_url = tom_link_replace($_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&dpid=' . $tcshop_id));
				$templateSmsClass = new templateSms($access_token, $hongbao_template_url);
				$hongbao_template_first = str_replace('{NICKNAME}', $__UserInfo['nickname'], lang('plugin/tom_tchongbao', 'template_sms_tcshop_fhb_user'));
				$hongbao_template_first = str_replace('{MONEY}', $randMoney, $hongbao_template_first);
				$smsData = array('first' => $hongbao_template_first, 'keyword1' => $sitename, 'keyword2' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s', $tomSysOffset), 'remark' => '');
				@($r = $templateSmsClass->sendSms01($userInfo['openid'], $template_id, $smsData));
			}
		}
		echo '200';
		exit(0);
	} else {
		if ($_GET['act'] == 'distance' && $_GET['formhash'] == FORMHASH) {
			$latitude = isset($_GET['latitude']) ? daddslashes($_GET['latitude']) : '';
			$longitude = isset($_GET['longitude']) ? daddslashes($_GET['longitude']) : '';
			if ($site_id > 1) {
				$siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
				$district_id = $siteInfo['city_id'];
			} else {
				$cityInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_level1_name($tongchengConfig['city_name']);
				if ($cityInfo) {
					$district_id = $cityInfo['id'];
				} else {
					$district_id = 0;
				}
			}
			$tcDistrictInfo = C::t('#tom_tchongbao#tom_tchongbao_district')->fetch_all_list(' AND district_id = ' . $district_id . ' AND is_show = 1 ', 'ORDER BY id DESC', 0, 1);
			if (is_array($tcDistrictInfo) && !empty($tcDistrictInfo[0]['longitude']) && !empty($tcDistrictInfo[0]['latitude'])) {
				$longitude2 = $tcDistrictInfo[0]['longitude'];
				$latitude2 = $tcDistrictInfo[0]['latitude'];
				$max_distance_km = $tcDistrictInfo[0]['max_distance_km'];
			} else {
				$longitude2 = $tchongbaoConfig['longitude'];
				$latitude2 = $tchongbaoConfig['latitude'];
				$max_distance_km = $tchongbaoConfig['max_distance_km'];
			}
			include DISCUZ_ROOT . './source/plugin/tom_tchongbao/class/function.lbs.php';
			if (!empty($longitude) && !empty($latitude) && !empty($longitude2) && !empty($latitude2)) {
				$distanceApi = 'http://api.map.baidu.com/routematrix/v2/driving?output=json&origins=' . $latitude . ',' . $longitude . '&destinations=' . $latitude2 . ',' . $longitude2 . '&ak=' . $tchongbaoConfig['baidu_ak'];
				$content = lbsGetHtml($distanceApi);
				$return = json_decode($content, true);
				$return = lbs_iconv_recurrence($return);
				if (is_array($return) && $return['status'] == 0 && !empty($return['result'])) {
					$distance_km = $return['result'][0]['distance']['value'];
					$max_distance_km = $max_distance_km * 1000;
					if ($distance_km > $max_distance_km) {
						$hongbaoLocationInfo = C::t('#tom_tchongbao#tom_tchongbao_location')->fetch_by_user_id($__UserInfo['id']);
						if ($hongbaoLocationInfo) {
							$updateData = array();
							$updateData['last_time'] = TIMESTAMP;
							$updateData['location_status'] = 2;
							C::t('#tom_tchongbao#tom_tchongbao_location')->update($hongbaoLocationInfo['id'], $updateData);
						} else {
							$insertData = array();
							$insertData['user_id'] = $__UserInfo['id'];
							$insertData['location_status'] = 2;
							$insertData['last_time'] = TIMESTAMP;
							$insertData['add_time'] = TIMESTAMP;
							C::t('#tom_tchongbao#tom_tchongbao_location')->insert($insertData);
						}
						echo '303';
						exit(0);
					} else {
						$hongbaoLocationInfo = C::t('#tom_tchongbao#tom_tchongbao_location')->fetch_by_user_id($__UserInfo['id']);
						if ($hongbaoLocationInfo) {
							$updateData = array();
							$updateData['last_time'] = TIMESTAMP;
							$updateData['location_status'] = 1;
							C::t('#tom_tchongbao#tom_tchongbao_location')->update($hongbaoLocationInfo['id'], $updateData);
						} else {
							$insertData = array();
							$insertData['user_id'] = $__UserInfo['id'];
							$insertData['location_status'] = 1;
							$insertData['last_time'] = TIMESTAMP;
							$insertData['add_time'] = TIMESTAMP;
							C::t('#tom_tchongbao#tom_tchongbao_location')->insert($insertData);
						}
						echo '200';
						exit(0);
					}
				} else {
					echo '302';
					exit(0);
				}
			} else {
				echo '301';
				exit(0);
			}
		} else {
			if ($_GET['act'] == 'nitice_sms_hb' && $_GET['formhash'] == FORMHASH) {
				$tongcheng_id = isset($_GET['tongcheng_id']) ? intval($_GET['tongcheng_id']) : 0;
				$hongbao_id = isset($_GET['hongbao_id']) ? intval($_GET['hongbao_id']) : 0;
				$templateSmsRunUrl = $_G['siteurl'] . ('plugin.php?id=tom_tchongbao:ajax&act=nitice_sms_hb_run&site=' . $site_id . '&tongcheng_id=' . $tongcheng_id . '&hongbao_id=' . $hongbao_id);
				if ($tchongbaoConfig['http_type'] == 2) {
					$templateSmsRunUrl = str_replace('https', 'http', $templateSmsRunUrl);
				} else {
					if ($tchongbaoConfig['http_type'] == 3) {
						$templateSmsRunUrl = str_replace('http', 'https', $templateSmsRunUrl);
					}
				}
				echo 'start:' . time() . '<br/>';
				if (!isset($_SESSION['tom_tchongbao_hongbao_id' . $hongbao_id]) || $_SESSION['tom_tchongbao_hongbao_id' . $hongbao_id] != 1) {
					$_SESSION['tom_tchongbao_hongbao_id' . $hongbao_id] = 1;
					if ($tchongbaoConfig['open_qunfa_log'] == 1) {
						C::t('#tom_tchongbao#tom_tchongbao_qunfa_log')->delete_by_logtime();
					}
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, $templateSmsRunUrl);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
					curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
					curl_setopt($ch, CURLOPT_TIMEOUT, 4);
					curl_setopt($ch, CURLOPT_HEADER, 0);
					$return = curl_exec($ch);
					var_dump($return);
				}
				echo '<br/>';
				echo 'end:' . time() . '<br/>';
				echo '100';
				exit(0);
			} else {
				if ($_GET['act'] == 'nitice_sms_hb_run') {
					ignore_user_abort(true);
					set_time_limit(0);
					include DISCUZ_ROOT . './source/plugin/tom_tchongbao/class/log.class.php';
					$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
					$tongcheng_id = isset($_GET['tongcheng_id']) ? intval($_GET['tongcheng_id']) : 0;
					$hongbao_id = isset($_GET['hongbao_id']) ? intval($_GET['hongbao_id']) : 0;
					if ($page == 1) {
						Log::DEBUG('[sms]--------------------- new -------------------------');
					} else {
						if ($page == 101) {
							Log::DEBUG('[sms]--------------------- over 101 -------------------------');
							exit(0);
						}
					}
					Log::DEBUG('[sms]hongbao id:' . $hongbao_id);
					Log::DEBUG('[sms]page:' . $page);
					Log::DEBUG('[sms]client IP:' . $_G['clientip']);
					Log::DEBUG('[sms]start:' . time());
					$start_time = time();
					$pagesize = 10;
					$start = ($page - 1) * $pagesize;
					$tchongbaoInfo = C::t('#tom_tchongbao#tom_tchongbao')->fetch_by_id($hongbao_id);
					$userListTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_list(' AND hongbao_tz = 1 AND status = 1 ', 'ORDER BY last_login_time DESC,id DESC', $start, $pagesize);
					if ($page > 1) {
						$tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(' AND tongcheng_id=' . $tongcheng_id . ' AND pay_status = 2  ', 'ORDER BY add_time DESC,id DESC', 0, 1);
					} else {
						$tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(' AND tongcheng_id=' . $tongcheng_id . ' AND pay_status = 2 AND status = 1 ', 'ORDER BY add_time DESC,id DESC', 0, 1);
					}
					$tchongbaoInfo = array();
					if (is_array($tchongbaoInfoTmp) && !empty($tchongbaoInfoTmp)) {
						$tchongbaoInfo = $tchongbaoInfoTmp[0];
						if ($tchongbaoInfo['site_id'] == 1) {
							$sitename = $tongchengConfig['plugin_name'];
						} else {
							$sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tchongbaoInfo['site_id']);
							$sitename = $sitesInfoTmp['name'];
						}
					} else {
						Log::DEBUG('[sms]error:201');
						echo '201';
						exit(0);
					}
					if (!is_array($tchongbaoInfo)) {
						Log::DEBUG('[sms]error:202');
						echo '202';
						exit(0);
					}
					if ($page == 1) {
						if ($tchongbaoInfo['send_status'] == 1) {
							Log::DEBUG('[sms]error:203');
							if ($_GET['do_admin'] != 1) {
								echo '203';
								exit(0);
							}
						}
					}
					if ($tchongbaoInfo['all_money'] < floatval($tchongbaoConfig['open_hb_template_sms'])) {
						Log::DEBUG('[sms]error:204');
						echo '204';
						exit(0);
					}
					$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tchongbaoInfo['user_id']);
					$appid = trim($tongchengConfig['wxpay_appid']);
					$appsecret = trim($tongchengConfig['wxpay_appsecret']);
					if (!empty($tchongbaoConfig['template_id'])) {
						$template_id = $tchongbaoConfig['template_id'];
					} else {
						$template_id = $tongchengConfig['template_id'];
					}
					$updateData = array();
					$updateData['send_status'] = 1;
					C::t('#tom_tchongbao#tom_tchongbao')->update($hongbao_id, $updateData);
					include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
					$weixinClass = new weixinClass($appid, $appsecret);
					include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/templatesms.class.php';
					$all_num = $run_num = $ok_num = $no_num = 0;
					$overStatus = 0;
					if (is_array($userListTmp) && !empty($userListTmp)) {
						foreach ($userListTmp as $key => $value) {
							$access_token = $weixinClass->get_access_token();
							if ($access_token && !empty($value['openid'])) {
								if ($tchongbaoConfig['open_qunfa_log'] == 1) {
									$logCount = C::t('#tom_tchongbao#tom_tchongbao_qunfa_log')->fetch_all_count(' AND hongbao_id = ' . $hongbao_id . ' AND user_id = ' . $value['id'] . ' ');
									if ($logCount > 0) {
										$no_num = $no_num + 1;
										echo $no_num . '-----';
									} else {
										$insertData = array();
										$insertData['hongbao_id'] = $hongbao_id;
										$insertData['user_id'] = $value['id'];
										$insertData['log_time'] = TIMESTAMP;
										if (C::t('#tom_tchongbao#tom_tchongbao_qunfa_log')->insert($insertData)) {
											$hongbao_template_url = tom_link_replace($_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=hbao&xxid=' . $tongcheng_id));
											$templateSmsClass = new templateSms($access_token, $hongbao_template_url);
											$hongbao_tz_template_first = str_replace('{NICKNAME}', $userInfo['nickname'], lang('plugin/tom_tchongbao', 'template_sms'));
											$hongbao_tz_template_first = str_replace('{MONEY}', $tchongbaoInfo['all_money'], $hongbao_tz_template_first);
											$smsData = array('first' => $hongbao_tz_template_first, 'keyword1' => $sitename, 'keyword2' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s', $tomSysOffset), 'remark' => '');
											@($r = $templateSmsClass->sendSms01($value['openid'], $template_id, $smsData));
											if ($r) {
												$ok_num = $ok_num + 1;
											}
										}
									}
								} else {
									$hongbao_template_url = tom_link_replace($_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=hbao&xxid=' . $tongcheng_id));
									$templateSmsClass = new templateSms($access_token, $hongbao_template_url);
									$hongbao_tz_template_first = str_replace('{NICKNAME}', $userInfo['nickname'], lang('plugin/tom_tchongbao', 'template_sms'));
									$hongbao_tz_template_first = str_replace('{MONEY}', $tchongbaoInfo['all_money'], $hongbao_tz_template_first);
									$smsData = array('first' => $hongbao_tz_template_first, 'keyword1' => $sitename, 'keyword2' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s', $tomSysOffset), 'remark' => '');
									@($r = $templateSmsClass->sendSms01($value['openid'], $template_id, $smsData));
									if ($r) {
										$ok_num = $ok_num + 1;
									}
								}
								$run_num = $run_num + 1;
							}
							$all_num = $all_num + 1;
						}
					} else {
						$overStatus = 1;
					}
					$end_time = time();
					$run_time = $end_time - $start_time;
					Log::DEBUG('[sms]all num:' . $all_num);
					Log::DEBUG('[sms]run num:' . $run_num);
					Log::DEBUG('[sms]ok num:' . $ok_num);
					Log::DEBUG('[sms]no num:' . $no_num);
					Log::DEBUG('[sms]run time:' . $run_time);
					Log::DEBUG('[sms]end:' . time());
					if ($overStatus == 0) {
						$page = $page + 1;
						$templateSmsRunUrl = $_G['siteurl'] . ('plugin.php?id=tom_tchongbao:ajax&act=nitice_sms_hb_run&site=' . $site_id . '&tongcheng_id=' . $tongcheng_id . '&hongbao_id=' . $hongbao_id . '&page=' . $page);
						if ($tchongbaoConfig['http_type'] == 2) {
							$templateSmsRunUrl = str_replace('https', 'http', $templateSmsRunUrl);
						} else {
							if ($tchongbaoConfig['http_type'] == 3) {
								$templateSmsRunUrl = str_replace('http', 'https', $templateSmsRunUrl);
							}
						}
						Log::DEBUG('[sms]page:' . $templateSmsRunUrl);
						$ch = curl_init();
						curl_setopt($ch, CURLOPT_URL, $templateSmsRunUrl);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
						curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
						curl_setopt($ch, CURLOPT_TIMEOUT, 5);
						curl_setopt($ch, CURLOPT_HEADER, 0);
						$return = curl_exec($ch);
						var_dump($return);
						if (curl_errno($ch)) {
							echo 'Curl error: ' . curl_error($ch);
						}
					} else {
						Log::DEBUG('[sms]over:' . time());
					}
					echo '1';
					exit(0);
				} else {
					if ($_GET['act'] == 'nitice_sms_tcshop_hb' && $_GET['formhash'] == FORMHASH) {
						$tcshop_id = isset($_GET['tcshop_id']) ? intval($_GET['tcshop_id']) : 0;
						$hongbao_id = isset($_GET['hongbao_id']) ? intval($_GET['hongbao_id']) : 0;
						$templateSmsRunUrl = $_G['siteurl'] . ('plugin.php?id=tom_tchongbao:ajax&act=nitice_sms_tcshop_hb_run&site=' . $site_id . '&tcshop_id=' . $tcshop_id . '&hongbao_id=' . $hongbao_id);
						if ($tchongbaoConfig['http_type'] == 2) {
							$templateSmsRunUrl = str_replace('https', 'http', $templateSmsRunUrl);
						} else {
							if ($tchongbaoConfig['http_type'] == 3) {
								$templateSmsRunUrl = str_replace('http', 'https', $templateSmsRunUrl);
							}
						}
						echo 'start:' . time() . '<br/>';
						if (!isset($_SESSION['tom_tchongbao_hongbao_id' . $hongbao_id]) || $_SESSION['tom_tchongbao_hongbao_id' . $hongbao_id] != 1) {
							$_SESSION['tom_tchongbao_hongbao_id' . $hongbao_id] = 1;
							if ($tchongbaoConfig['open_qunfa_log'] == 1) {
								C::t('#tom_tchongbao#tom_tchongbao_qunfa_log')->delete_by_logtime();
							}
							$ch = curl_init();
							curl_setopt($ch, CURLOPT_URL, $templateSmsRunUrl);
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
							curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
							curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
							curl_setopt($ch, CURLOPT_TIMEOUT, 4);
							curl_setopt($ch, CURLOPT_HEADER, 0);
							$return = curl_exec($ch);
							var_dump($return);
						}
						echo '<br/>';
						echo 'end:' . time() . '<br/>';
						echo '100';
						exit(0);
					} else {
						if ($_GET['act'] == 'nitice_sms_tcshop_hb_run') {
							ignore_user_abort(true);
							set_time_limit(0);
							include DISCUZ_ROOT . './source/plugin/tom_tchongbao/class/log.class.php';
							$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
							$tcshop_id = isset($_GET['tcshop_id']) ? intval($_GET['tcshop_id']) : 0;
							$hongbao_id = isset($_GET['hongbao_id']) ? intval($_GET['hongbao_id']) : 0;
							if ($page == 1) {
								Log::DEBUG('[sms]--------------------- new -------------------------');
							} else {
								if ($page == 101) {
									Log::DEBUG('[sms]--------------------- over 101 -------------------------');
									exit(0);
								}
							}
							Log::DEBUG('[sms]hongbao id:' . $hongbao_id);
							Log::DEBUG('[sms]page:' . $page);
							Log::DEBUG('[sms]client IP:' . $_G['clientip']);
							Log::DEBUG('[sms]start:' . time());
							$start_time = time();
							$pagesize = 10;
							$start = ($page - 1) * $pagesize;
							$tchongbaoInfo = C::t('#tom_tchongbao#tom_tchongbao')->fetch_by_id($hongbao_id);
							$userListTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_list(' AND hongbao_tz = 1 AND status = 1 ', 'ORDER BY last_login_time DESC,id DESC', $start, $pagesize);
							if ($page > 1) {
								$tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(' AND tcshop_id=' . $tcshop_id . ' AND pay_status = 2  ', 'ORDER BY add_time DESC,id DESC', 0, 1);
							} else {
								$tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(' AND tcshop_id=' . $tcshop_id . ' AND pay_status = 2 AND status = 1 ', 'ORDER BY add_time DESC,id DESC', 0, 1);
							}
							$tchongbaoInfo = array();
							if (is_array($tchongbaoInfoTmp) && !empty($tchongbaoInfoTmp)) {
								$tchongbaoInfo = $tchongbaoInfoTmp[0];
								if ($tchongbaoInfo['site_id'] == 1) {
									$sitename = $tongchengConfig['plugin_name'];
								} else {
									$sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tchongbaoInfo['site_id']);
									$sitename = $sitesInfoTmp['name'];
								}
							} else {
								Log::DEBUG('[sms]error:201');
								echo '201';
								exit(0);
							}
							if (!is_array($tchongbaoInfo)) {
								Log::DEBUG('[sms]error:202');
								echo '202';
								exit(0);
							}
							if ($page == 1) {
								if ($tchongbaoInfo['send_status'] == 1) {
									Log::DEBUG('[sms]error:203');
									if ($_GET['do_admin'] != 1) {
										echo '203';
										exit(0);
									}
								}
							}
							if ($tchongbaoInfo['all_money'] < floatval($tchongbaoConfig['open_hb_template_sms'])) {
								Log::DEBUG('[sms]error:204');
								echo '204';
								exit(0);
							}
							$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tchongbaoInfo['user_id']);
							$appid = trim($tongchengConfig['wxpay_appid']);
							$appsecret = trim($tongchengConfig['wxpay_appsecret']);
							if (!empty($tchongbaoConfig['template_id'])) {
								$template_id = $tchongbaoConfig['template_id'];
							} else {
								$template_id = $tongchengConfig['template_id'];
							}
							$updateData = array();
							$updateData['send_status'] = 1;
							C::t('#tom_tchongbao#tom_tchongbao')->update($hongbao_id, $updateData);
							include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
							$weixinClass = new weixinClass($appid, $appsecret);
							include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/templatesms.class.php';
							$all_num = $run_num = $ok_num = $no_num = 0;
							$overStatus = 0;
							if (is_array($userListTmp) && !empty($userListTmp)) {
								foreach ($userListTmp as $key => $value) {
									$access_token = $weixinClass->get_access_token();
									if ($access_token && !empty($value['openid'])) {
										if ($tchongbaoConfig['open_qunfa_log'] == 1) {
											$logCount = C::t('#tom_tchongbao#tom_tchongbao_qunfa_log')->fetch_all_count(' AND hongbao_id = ' . $hongbao_id . ' AND user_id = ' . $value['id'] . ' ');
											if ($logCount > 0) {
												$no_num = $no_num + 1;
												echo $no_num . '-----';
											} else {
												$insertData = array();
												$insertData['hongbao_id'] = $hongbao_id;
												$insertData['user_id'] = $value['id'];
												$insertData['log_time'] = TIMESTAMP;
												if (C::t('#tom_tchongbao#tom_tchongbao_qunfa_log')->insert($insertData)) {
													$hongbao_template_url = tom_link_replace($_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&dpid=' . $tcshop_id));
													$templateSmsClass = new templateSms($access_token, $hongbao_template_url);
													$hongbao_tz_template_first = str_replace('{NICKNAME}', $userInfo['nickname'], lang('plugin/tom_tchongbao', 'template_sms'));
													$hongbao_tz_template_first = str_replace('{MONEY}', $tchongbaoInfo['all_money'], $hongbao_tz_template_first);
													$smsData = array('first' => $hongbao_tz_template_first, 'keyword1' => $sitename, 'keyword2' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s', $tomSysOffset), 'remark' => '');
													@($r = $templateSmsClass->sendSms01($value['openid'], $template_id, $smsData));
													if ($r) {
														$ok_num = $ok_num + 1;
													}
												}
											}
										} else {
											$hongbao_template_url = tom_link_replace($_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&dpid=' . $tcshop_id));
											$templateSmsClass = new templateSms($access_token, $hongbao_template_url);
											$hongbao_tz_template_first = str_replace('{NICKNAME}', $userInfo['nickname'], lang('plugin/tom_tchongbao', 'template_sms'));
											$hongbao_tz_template_first = str_replace('{MONEY}', $tchongbaoInfo['all_money'], $hongbao_tz_template_first);
											$smsData = array('first' => $hongbao_tz_template_first, 'keyword1' => $sitename, 'keyword2' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s', $tomSysOffset), 'remark' => '');
											@($r = $templateSmsClass->sendSms01($value['openid'], $template_id, $smsData));
											if ($r) {
												$ok_num = $ok_num + 1;
											}
										}
										$run_num = $run_num + 1;
									}
									$all_num = $all_num + 1;
								}
							} else {
								$overStatus = 1;
							}
							$end_time = time();
							$run_time = $end_time - $start_time;
							Log::DEBUG('[sms]all num:' . $all_num);
							Log::DEBUG('[sms]run num:' . $run_num);
							Log::DEBUG('[sms]ok num:' . $ok_num);
							Log::DEBUG('[sms]no num:' . $no_num);
							Log::DEBUG('[sms]run time:' . $run_time);
							Log::DEBUG('[sms]end:' . time());
							if ($overStatus == 0) {
								$page = $page + 1;
								$templateSmsRunUrl = $_G['siteurl'] . ('plugin.php?id=tom_tchongbao:ajax&act=nitice_sms_tcshop_hb_run&site=' . $site_id . '&tcshop_id=' . $tcshop_id . '&hongbao_id=' . $hongbao_id . '&page=' . $page);
								if ($tchongbaoConfig['http_type'] == 2) {
									$templateSmsRunUrl = str_replace('https', 'http', $templateSmsRunUrl);
								} else {
									if ($tchongbaoConfig['http_type'] == 3) {
										$templateSmsRunUrl = str_replace('http', 'https', $templateSmsRunUrl);
									}
								}
								Log::DEBUG('[sms]page:' . $templateSmsRunUrl);
								$ch = curl_init();
								curl_setopt($ch, CURLOPT_URL, $templateSmsRunUrl);
								curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
								curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
								curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
								curl_setopt($ch, CURLOPT_TIMEOUT, 5);
								curl_setopt($ch, CURLOPT_HEADER, 0);
								$return = curl_exec($ch);
								var_dump($return);
								if (curl_errno($ch)) {
									echo 'Curl error: ' . curl_error($ch);
								}
							} else {
								Log::DEBUG('[sms]over:' . time());
							}
							echo '1';
							exit(0);
						} else {
							if ($_GET['act'] == 'list' && $_GET['formhash'] == FORMHASH) {
								$outStr = '';
								$status = intval($_GET['status']) > 0 ? intval($_GET['status']) : 0;
								$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
								$pagesize = intval($_GET['pagesize']) > 0 ? intval($_GET['pagesize']) : 6;
								include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
								$where = ' AND tongcheng_id > 0 AND pay_status = 2 AND only_show = 1  AND site_id IN(' . $sql_in_site_ids . ') ';
								if ($status == 1) {
									$where .= ' AND status = 1 ';
								}
								$pagesize = $pagesize;
								$start = ($page - 1) * $pagesize;
								$tchongbaoListTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list($where, 'ORDER BY add_time DESC,id DESC', $start, $pagesize);
								$tchongbaoList = array();
								foreach ($tchongbaoListTmp as $key => $value) {
									$tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($value['tongcheng_id']);
									if ($tongchengInfo['status'] == 1 && $tongchengInfo['shenhe_status'] == 1) {
										$typeInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
										if ($typeInfoTmp['over_time_attr_id'] > 0 && $typeInfoTmp['over_time_do'] > 0) {
											$tongchengAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(' AND tongcheng_id=' . $value['tongcheng_id'] . ' AND attr_id=' . $typeInfoTmp['over_time_attr_id'] . ' ', ' ORDER BY id DESC ', 0, 1);
											if (is_array($tongchengAttrInfoTmp) && !empty($tongchengAttrInfoTmp) && $tongchengAttrInfoTmp[0] && $tongchengAttrInfoTmp[0]['time_value'] > 0) {
												if ($tongchengAttrInfoTmp[0]['time_value'] < TIMESTAMP) {
													if ($typeInfoTmp['over_time_do'] == 1) {
														continue;
													}
													if ($typeInfoTmp['over_time_do'] == 2) {
														$value['finish'] = 1;
													}
												}
											}
										}
										$tchongbaoList[$key] = $value;
										$tchongbaoList[$key]['tongchengInfo'] = $tongchengInfo;
										$tchongbaoList[$key]['tongchengInfo']['content'] = contentFormat($tongchengInfo['content']);
										$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
										$siteInfoTmp = array('id' => 1, 'name' => $tongchengConfig['plugin_name']);
										if ($value['site_id'] > 1) {
											$siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
										}
										$tongchengAttrListTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(' AND tongcheng_id=' . $value['tongcheng_id'] . ' ', ' ORDER BY paixu ASC,id DESC ', 0, 50);
										$tongchengTagListTmp = C::t('#tom_tongcheng#tom_tongcheng_tag')->fetch_all_list(' AND tongcheng_id=' . $value['tongcheng_id'] . ' ', ' ORDER BY id DESC ', 0, 50);
										$tongchengPhotoListTmpTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(' AND tongcheng_id=' . $value['tongcheng_id'] . ' ', ' ORDER BY id ASC ', 0, 50);
										$tongchengPhotoListTmp = array();
										$tongchengAlbumListTmp = array();
										if (is_array($tongchengPhotoListTmpTmp) && !empty($tongchengPhotoListTmpTmp)) {
											foreach ($tongchengPhotoListTmpTmp as $kk => $vv) {
												if ($tongchengConfig['open_yun'] == 2 && !empty($vv['oss_picurl'])) {
													$picurl = $vv['oss_picurl'] . '?x-oss-process=image/resize,m_fill,h_120,w_120';
													$albumurl = $vv['oss_picurl'];
												} else {
													if ($tongchengConfig['open_yun'] == 3 && !empty($vv['qiniu_picurl'])) {
														$picurl = $vv['qiniu_picurl'] . '?imageView2/1/w/120/h/120';
														$albumurl = $vv['qiniu_picurl'];
													} else {
														if (!preg_match('/^http/', $value['picurl'])) {
															if (strpos($vv['picurl'], 'source/plugin/tom_tongcheng/data/') === false) {
																$picurl = $albumurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $vv['picurl'];
															} else {
																$picurl = $albumurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $vv['picurl'];
															}
														} else {
															$picurl = $albumurl = $vv['picurl'];
														}
													}
												}
												$tongchengPhotoListTmp[$kk]['picurl'] = $picurl;
												$tongchengPhotoListTmp[$kk]['albumurl'] = $albumurl;
												$tongchengAlbumListTmp[$kk] = $albumurl;
											}
										}
										$tchongbaoList[$key]['userInfo'] = $userInfoTmp;
										$tchongbaoList[$key]['typeInfo'] = $typeInfoTmp;
										$tchongbaoList[$key]['attrList'] = $tongchengAttrListTmp;
										$tchongbaoList[$key]['tagList'] = $tongchengTagListTmp;
										$tchongbaoList[$key]['photoList'] = $tongchengPhotoListTmp;
										$tchongbaoList[$key]['albumList'] = $tongchengAlbumListTmp;
										$tchongbaoList[$key]['siteInfo'] = $siteInfoTmp;
										$tchongbaoList[$key]['tcshopInfo'] = array();
										if ($__ShowTcshop == 1 && $tongchengInfo['tcshop_id'] > 0) {
											$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tongchengInfo['tcshop_id']);
											if ($tcshopInfo) {
												if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
													if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_tcshop/') === false) {
														$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
													} else {
														$picurl = $tcshopInfo['picurl'];
													}
												} else {
													$picurl = $tcshopInfo['picurl'];
												}
												$tcshopInfo['picurl'] = $picurl;
												$tchongbaoList[$key]['tcshopInfo'] = $tcshopInfo;
											}
										}
									}
								}
								if (is_array($tchongbaoList) && !empty($tchongbaoList)) {
									foreach ($tchongbaoList as $key => $val) {
										if ($tongchengConfig['open_load_list_clicks'] == 1) {
											DB::query('UPDATE ' . DB::table('tom_tongcheng') . (' SET clicks=clicks+1 WHERE id=\'' . $val['tongcheng_id'] . '\' '), 'UNBUFFERED');
										}
										$messageUrl = 'plugin.php?id=tom_tongcheng&site=' . $val['site_id'] . '&mod=message&act=create&tongcheng_id=' . $val['tongcheng_id'] . '&to_user_id=' . $val['userInfo']['id'] . '&formhash=' . FORMHASH;
										$tousuUrl = 'plugin.php?id=tom_tongcheng&site=' . $val['site_id'] . '&mod=tousu&tongcheng_id=' . $val['tongcheng_id'];
										$outStr .= '<div class="tcline-item">';
										$outStr .= '<div class="avatar-label">';
										$outStr .= '<a href="plugin.php?id=tom_tongcheng&site=' . $val['site_id'] . '&mod=home&uid=' . $val['userInfo']['id'] . '"><img src="' . $val['userInfo']['picurl'] . '" class="avatar" /></a>';
										$outStr .= '<a class="hb-label" href="plugin.php?id=tom_tongcheng&site=' . $val['site_id'] . '&mod=hbao&xxid=' . $val['tongcheng_id'] . '">';
										$outStr .= '<img src="source/plugin/tom_tchongbao/images/list-hongbao.png">';
										$outStr .= '</a>';
										$outStr .= '</div>';
										$outStr .= '<div class="tcline-detail" data-id=' . $val['tongcheng_id'] . '>';
										if ($val['tongchengInfo']['topstatus'] == 1) {
											$outStr .= '<span><a style="background-color: #f15555;">' . lang('plugin/tom_tongcheng', 'top') . '</a></span>&nbsp; ';
										}
										$outStr .= '<span class="tc-template__bg"><a class="tc-template__bg" href="plugin.php?id=tom_tongcheng&site=' . $val['site_id'] . '&mod=list&type_id=' . $val['typeInfo']['id'] . '">' . $val['typeInfo']['name'] . '</a></span>&nbsp; ';
										if ($tongchengConfig['open_list_xm'] == 1) {
											$val['tongchengInfo']['xm'] = cutstr($val['tongchengInfo']['xm'], 12, '...');
											$outStr .= '<a class="username" href="plugin.php?id=tom_tongcheng&site=' . $val['site_id'] . '&mod=home&uid=' . $val['userInfo']['id'] . '">' . $val['tongchengInfo']['xm'] . '</a>';
										} else {
											$val['userInfo']['nickname'] = cutstr($val['userInfo']['nickname'], 12, '...');
											$outStr .= '<a class="username" href="plugin.php?id=tom_tongcheng&site=' . $val['site_id'] . '&mod=home&uid=' . $val['userInfo']['id'] . '">' . $val['userInfo']['nickname'] . '</a>';
										}
										$outStr .= '<a href="plugin.php?id=tom_tongcheng&site=' . $val['site_id'] . '&mod=hbao&xxid=' . $val['tongcheng_id'] . '" class="ext-act tchongbao clicks"><i class="tciconfont tcicon-hot"></i> ' . $val['tongchengInfo']['clicks'] . ' </a>';
										$outStr .= '<a href="plugin.php?id=tom_tongcheng&site=' . $val['site_id'] . '&mod=hbao&xxid=' . $val['tongcheng_id'] . '" >';
										if (is_array($val['tagList']) && !empty($val['tagList'])) {
											$outStr .= '<article style="max-height: 90px;">';
										} else {
											$outStr .= '<article>';
										}
										if (is_array($val['tagList']) && !empty($val['tagList'])) {
											$outStr .= '<div class="detail-tags">';
											foreach ($val['tagList'] as $k1 => $v1) {
												$outStr .= '<span class="span' . $k1 . '">' . $v1['tag_name'] . '</span>';
											}
											$outStr .= '<div class="clear"></div>';
											$outStr .= '</div>';
										}
										$outStr .= '<p>' . $val['tongchengInfo']['content'] . '</p>';
										if (is_array($val['attrList']) && !empty($val['attrList'])) {
											foreach ($val['attrList'] as $k2 => $v2) {
												$outStr .= '<p><font class="tc-template__color" color="#F60">' . $v2['attr_name'] . '&nbsp;:&nbsp;</font></b>' . $v2['value'];
												if ($v2['unit']) {
													$outStr .= '/' . $v2['unit'];
												}
												$outStr .= '</p>';
											}
										}
										$outStr .= '</article>';
										$outStr .= '<div class="detail-toggle">' . lang('plugin/tom_tongcheng', 'template_quanwen') . '</div>';
										$outStr .= '</a>';
										if (is_array($val['photoList']) && !empty($val['photoList'])) {
											$outStr .= '<div class="detail-pics clearfix"><input type="hidden" name="photo_list_' . $val['tongcheng_id'] . '" id="photo_list_' . $val['tongcheng_id'] . '" value="' . implode('|', $val['albumList']) . '">';
											foreach ($val['photoList'] as $k3 => $v3) {
												$outStr .= '<a href="javascript:void(0);" onclick="showPic(\'' . $v3['albumurl'] . '\',' . $val['tongcheng_id'] . ');"><img src="' . $v3['picurl'] . '"></a>';
											}
											$outStr .= '</div>';
										}
										if (is_array($val['tcshopInfo']) && !empty($val['tcshopInfo'])) {
											$outStr .= '<a class="detail-link" href="plugin.php?id=tom_tcshop&site=' . $val['tcshopInfo']['site_id'] . '&mod=details&dpid=' . $val['tcshopInfo']['id'] . '" target="_blank"><img src="' . $val['tcshopInfo']['picurl'] . '"><b>' . $val['tcshopInfo']['name'] . '</b><br><img src="source/plugin/tom_tongcheng/images/detail-link-ico.png" style="width: 12px;height: 17px;margin-right: 0px;">&nbsp;&nbsp;' . $val['tcshopInfo']['address'] . '</a>';
										}
										$outStr .= '<div class="detail-time">';
										$outStr .= '<a>';
										$refresh_log_count = C::t('#tom_tongcheng#tom_tongcheng_refresh_log')->fetch_all_count(' AND tongcheng_id=' . $val['tongcheng_id'] . ' ');
										if ($refresh_log_count > 0) {
											$outStr .= '<span>' . lang('plugin/tom_tongcheng', 'template_refresh_title') . dgmdate($val['tongchengInfo']['refresh_time'], 'u', '9999', 'm-d H:i') . '</span>';
										} else {
											$outStr .= '<span>' . dgmdate($val['tongchengInfo']['refresh_time'], 'u', '9999', 'm-d H:i') . '</span>';
										}
										if ($tongchengConfig['show_site_name'] == 1) {
											$outStr .= '<span>&nbsp;' . lang('plugin/tom_tongcheng', 'template_laiyuan') . $val['siteInfo']['name'] . '</span>';
										}
										$outStr .= '</a>';
										$outStr .= '</div>';
										if ($val['finish'] == 1) {
											$outStr .= '<section class="mark-img succ"></section>';
										}
										$outStr .= '<div class="detail-hb-wrap">';
										if ($tchongbaoConfig['open_show_hongbao_price'] == 1) {
											$outStr .= '<div class="hb_price">' . lang('plugin/tom_tchongbao', 'rmb') . '<span class="hb_size">' . $val['all_money'] . '</span>' . lang('plugin/tom_tchongbao', 'yuan');
											if ($val['status'] == 1) {
												$outStr .= '<span class="right">' . lang('plugin/tom_tchongbao', 'index_list_status_1') . '</span>';
											} else {
												if ($val['status'] == 2) {
													$outStr .= '<span class="right">' . lang('plugin/tom_tchongbao', 'index_list_status_2') . '</span>';
												}
											}
										} else {
											$outStr .= '<div class="hb_price">';
											if ($val['status'] == 1) {
												$outStr .= '<span class="">' . lang('plugin/tom_tchongbao', 'index_list_status_1') . '</span>';
											} else {
												if ($val['status'] == 2) {
													$outStr .= '<span class="">' . lang('plugin/tom_tchongbao', 'index_list_status_2') . '</span>';
												}
											}
										}
										$outStr .= '</div>';
										$outStr .= '</div>';
										$outStr .= '</div>';
										$outStr .= '</div>';
									}
								} else {
									$outStr = '205';
								}
								$outStr = tom_link_replace($outStr);
								$outStr = diconv($outStr, CHARSET, 'utf-8');
								echo json_encode($outStr);
								exit(0);
							} else {
								if ($_GET['act'] == 'tcshop_list' && $_GET['formhash'] == FORMHASH) {
									$outStr = '';
									$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
									$pagesize = intval($_GET['pagesize']) > 0 ? intval($_GET['pagesize']) : 10;
									include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
									$tcshopList = array();
									$where = ' AND tcshop_id > 0 AND pay_status = 2 AND only_show = 1  AND site_id IN(' . $sql_in_site_ids . ') ';
									if ($status == 1) {
										$where .= ' AND status = 1 ';
									}
									$pagesize = $pagesize;
									$start = ($page - 1) * $pagesize;
									$tchongbaoListTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list($where, 'ORDER BY status ASC,id DESC', $start, $pagesize);
									$tchongbaoList = array();
									if (is_array($tchongbaoListTmp) && !empty($tchongbaoListTmp)) {
										foreach ($tchongbaoListTmp as $key => $value) {
											$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
											if ($tcshopInfo['status'] == 1 && $tcshopInfo['shenhe_status'] == 1) {
												if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
													if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_tcshop/') === false) {
														$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
													} else {
														$picurl = $tcshopInfo['picurl'];
													}
												} else {
													$picurl = $tcshopInfo['picurl'];
												}
												$tcshopInfo['picurl'] = $picurl;
												$tchongbaoList[$key] = $value;
												$tchongbaoList[$key]['tcshopInfo'] = $tcshopInfo;
											}
										}
									}
									if (is_array($tchongbaoList) && !empty($tchongbaoList)) {
										foreach ($tchongbaoList as $key => $val) {
											$tabsStr = str_replace('    ', ' ', $val['tcshopInfo']['tabs']);
											$tabsStr = str_replace('   ', ' ', $tabsStr);
											$tabsStr = str_replace('  ', ' ', $tabsStr);
											$tabsArrTmp = explode(' ', $tabsStr);
											$tabsArr = array();
											if (is_array($tabsArrTmp) && !empty($tabsArrTmp)) {
												foreach ($tabsArrTmp as $kk => $vv) {
													$vv = trim($vv);
													if (!empty($vv)) {
														$tabsArr[] = $vv;
													}
												}
											}
											if ($val['tcshopInfo']['vip_level'] > 0 && !empty($val['tcshopInfo']['video_url'])) {
												if (strpos($val['tcshopInfo']['video_url'], 'youku.com') !== false) {
													$video_type = 1;
												} else {
													if (strpos($val['tcshopInfo']['video_url'], 'qq.com') !== false) {
														$video_type = 1;
													} else {
														$video_type = 2;
													}
												}
											} else {
												$video_type = 0;
											}
											$outStr .= '<div class="item-box clearfix">';
											$outStr .= '<div class="item-pic" style="width: 65px;height: 65px;"><a href="plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&dpid=' . $val['tcshopInfo']['id'] . '">';
											$outStr .= '<img src="' . $val['tcshopInfo']['picurl'] . '">';
											if ($val['tcshopInfo']['vip_level'] == 1) {
												$outStr .= '<i class="vip"></i>';
											}
											$outStr .= '</a></div>';
											$outStr .= '<div class="item-content">';
											$outStr .= '<div class="content">';
											$outStr .= '<h5><a href="plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&dpid=' . $val['tcshopInfo']['id'] . '">';
											if ($val['tcshopInfo']['topstatus'] == 1) {
												$outStr .= '<span class="icon top"></span>';
											}
											$outStr .= $val['tcshopInfo']['name'];
											if ($video_type == 1) {
												$outStr .= '<span class="icon video"></span>';
											} else {
												if ($video_type == 2) {
													$outStr .= '<span class="icon video_720"></span>';
												}
											}
											$outStr .= '<span class="icon hb">' . lang('plugin/tom_tchongbao', 'tcshop_hb') . '</span>';
											$outStr .= '</a></h5>';
											if (is_array($tabsArr) && !empty($tabsArr)) {
												$outStr .= '<a href="plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&dpid=' . $val['tcshopInfo']['id'] . '"><p class="xinxi shop_list-tags">';
												foreach ($tabsArr as $kt => $vt) {
													$outStr .= '<span class="span' . $kt . '">' . $vt . '</span>';
												}
												$outStr .= '</p></a>';
											} else {
												$outStr .= '<a href="plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&dpid=' . $val['tcshopInfo']['id'] . '"><p class="xinxi tc-template__color" style="color: #FDA233;">' . lang('plugin/tom_tcshop', 'template_list_business_hours_title') . '' . $val['tcshopInfo']['business_hours'] . '</p></a>';
											}
											if ($tcshopConfig['open_list_area'] == 1) {
												$outStr .= '<p class="nr">' . $val['tcshopInfo']['address'] . '</p>';
											} else {
												if ($tcshopConfig['open_list_area'] == 2) {
													$areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($val['tcshopInfo']['area_id']);
													$streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($val['tcshopInfo']['street_id']);
													$outStr .= '<p class="nr">' . $areaInfo['name'] . '&nbsp;' . $streetInfo['name'] . '</p>';
												}
											}
											$outStr .= '</div>';
											$outStr .= '<div class="details">';
											$outStr .= '<div class="tel"><a href="tel:' . $val['tcshopInfo']['tel'] . '"></a></div>';
											if (isset($val['tcshopInfo']['distance'])) {
												$outStr .= '<div class="dist">' . $val['tcshopInfo']['distance'] . '</div>';
											} else {
												$outStr .= '<div class="dist">' . $val['tcshopInfo']['clicks'] . '' . lang('plugin/tom_tcshop', 'template_list_clicks_title') . '</div>';
											}
											$outStr .= '</div>';
											$outStr .= '</div>';
											$outStr .= '</div>';
											$outStr .= '<div class="detail-hb-wrap" style="border-bottom:1px solid #f2f2f2; margin-top:-5px; padding:0 10px 10px; ">';
											if ($tchongbaoConfig['open_show_hongbao_price'] == 1) {
												$outStr .= '<div class="hb_price">' . lang('plugin/tom_tchongbao', 'rmb') . '<span class="hb_size">' . $val['all_money'] . '</span>' . lang('plugin/tom_tchongbao', 'yuan');
												if ($val['status'] == 1) {
													$outStr .= '<span class="right" style="margin-right: 0px;">' . lang('plugin/tom_tchongbao', 'index_list_status_1') . '</span>';
												} else {
													if ($val['status'] == 2) {
														$outStr .= '<span class="right" style="margin-right: 0px;">' . lang('plugin/tom_tchongbao', 'index_list_status_2') . '</span>';
													}
												}
											} else {
												$outStr .= '<div class="hb_price">';
												if ($val['status'] == 1) {
													$outStr .= '<span class="">' . lang('plugin/tom_tchongbao', 'index_list_status_1') . '</span>';
												} else {
													if ($val['status'] == 2) {
														$outStr .= '<span class="">' . lang('plugin/tom_tchongbao', 'index_list_status_2') . '</span>';
													}
												}
											}
											$outStr .= '</div>';
											$outStr .= '</div>';
										}
									} else {
										$outStr = '205';
									}
									$outStr = tom_link_replace($outStr);
									$outStr = diconv($outStr, CHARSET, 'utf-8');
									echo json_encode($outStr);
									exit(0);
								} else {
									if ($_GET['act'] == 'pay_tongcheng_save' && $_GET['formhash'] == FORMHASH) {
										$outArr = array('status' => 1);
										if ('utf-8' != CHARSET) {
											if (!defined('IN_MOBILE')) {
												foreach ($_POST as $pk => $pv) {
													if (!is_numeric($pv)) {
														$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
													}
												}
											}
										}
										$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
										$tongcheng_id = isset($_GET['tongcheng_id']) ? intval($_GET['tongcheng_id']) : 0;
										$all_money = isset($_GET['all_money']) > 0 ? floatval($_GET['all_money']) : 0;
										$hb_count = isset($_GET['hb_count']) > 0 ? intval($_GET['hb_count']) : 0;
										$open_kouling = isset($_GET['open_kouling']) ? intval($_GET['open_kouling']) : 2;
										$kouling = isset($_GET['kouling']) ? daddslashes($_GET['kouling']) : '';
										$kouling_pormpt = isset($_GET['kouling_pormpt']) ? daddslashes($_GET['kouling_pormpt']) : '';
										$fenpei_status = isset($_GET['fenpei_status']) ? intval($_GET['fenpei_status']) : 2;
										$tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
										$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
										if ($all_money / $hb_count < floatval($tchongbaoConfig['hongbao_min_value'])) {
											$hbAllMoney = $hb_count * $tchongbaoConfig['hongbao_min_value'];
											$hbPormpt = '';
											if (!empty($tchongbaoConfig['hongbao_min_value_pormpt'])) {
												$hbPormpt = str_replace('{TOTAL_MONEY}', $hbAllMoney, $tchongbaoConfig['hongbao_min_value_pormpt']);
												$hbPormpt = str_replace('{MIN_MONEY}', $tchongbaoConfig['hongbao_min_value'], $hbPormpt);
												$hbPormpt = str_replace('{HB_COUNT}', $hb_count, $hbPormpt);
												$hbPormpt = diconv($hbPormpt, CHARSET, 'utf-8');
											}
											$outArr = array('status' => 305, 'hbPormpt' => $hbPormpt);
											echo json_encode($outArr);
											exit(0);
										}
										if ($tchongbaoConfig['hongbao_max_count'] > 0) {
											if ($hb_count > $tchongbaoConfig['hongbao_max_count']) {
												$outArr = array('status' => 306);
												echo json_encode($outArr);
												exit(0);
											}
										}
										if ($tchongbaoConfig['hongbao_min_count'] > 0) {
											if ($hb_count < $tchongbaoConfig['hongbao_min_count']) {
												$outArr = array('status' => 307);
												echo json_encode($outArr);
												exit(0);
											}
										}
										if ($hb_count > $all_money * 100) {
											$outArr = array('status' => 304);
											echo json_encode($outArr);
											exit(0);
										}
										$tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(' AND tongcheng_id = ' . $tongcheng_id . ' AND pay_status = 2 AND status = 1 AND only_show = 1', 'ORDER BY id DESC', 0, 1);
										if (is_array($tchongbaoInfoTmp) && !empty($tchongbaoInfoTmp[0])) {
											$outArr = array('status' => 301);
											echo json_encode($outArr);
											exit(0);
										}
										$__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
										if (!empty($__CommonInfo['forbid_word']) && $open_kouling == 1) {
											$forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
											$forbid_word = str_replace(array('\\*'), array('.*'), $forbid_word);
											$forbid_word = '.*(' . $forbid_word . ').*';
											$forbid_word = '/^(' . str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word) . ')$/i';
											if (@preg_match($forbid_word, $kouling_pormpt, $matches)) {
												$i = count($matches) - 1;
												$word = '';
												if (isset($matches[$i]) && !empty($matches[$i])) {
													$word = diconv($matches[$i], CHARSET, 'utf-8');
												}
												$outArr = array('status' => 505, 'word' => $word);
												echo json_encode($outArr);
												exit(0);
											}
										}
										if (!file_exists(DISCUZ_ROOT . './source/plugin/tom_pay/tom_pay.inc.php')) {
											$outArr = array('status' => 302);
											echo json_encode($outArr);
											exit(0);
										}
										if ($tchongbaoConfig['hb_lq_type'] != 1) {
											$open_kouling = 2;
										}
										$sx_money = intval($tchongbaoConfig['hongbao_shouxufei']) * $all_money / 100;
										$money = $all_money;
										$order_no = 'TC' . date('YmdHis') . '-' . mt_rand(111111, 666666);
										$insertData = array();
										$insertData['order_no'] = $order_no;
										$insertData['site_id'] = $tongchengInfo['site_id'];
										$insertData['user_id'] = $user_id;
										$insertData['tongcheng_id'] = $tongcheng_id;
										$insertData['all_money'] = $all_money;
										$insertData['sx_money'] = $sx_money;
										$insertData['money'] = $money;
										$insertData['hb_count'] = $hb_count;
										$insertData['open_kouling'] = $open_kouling;
										$insertData['kouling'] = $kouling;
										$insertData['kouling_pormpt'] = $kouling_pormpt;
										$insertData['status'] = 1;
										$insertData['fenpei_status'] = $fenpei_status;
										$insertData['pay_status'] = 1;
										$insertData['add_time'] = TIMESTAMP;
										if (C::t('#tom_tchongbao#tom_tchongbao')->insert($insertData)) {
											$orderId = C::t('#tom_tchongbao#tom_tchongbao')->insert_id();
											$pay_price = $all_money + $sx_money;
											$insertData = array();
											$insertData['plugin_id'] = 'tom_tchongbao';
											$insertData['order_no'] = $order_no;
											$insertData['goods_id'] = $tongcheng_id;
											$insertData['goods_name'] = lang('plugin/tom_tchongbao', 'index_qiang_hb');
											$insertData['goods_beizu'] = lang('plugin/tom_tchongbao', 'index_qiang_hb');
											$insertData['goods_url'] = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=hbao&xxid=' . $tongcheng_id;
											$insertData['succ_back_url'] = 'plugin.php?id=tom_tchongbao&site=' . $site_id . '&mod=add&tongcheng_id=' . $tongcheng_id . '&send_status=1';
											$insertData['fail_back_url'] = 'plugin.php?id=tom_tchongbao&site=' . $site_id . '&mod=add&tongcheng_id=' . $tongcheng_id;
											$insertData['allow_alipay'] = 1;
											$insertData['pay_price'] = $pay_price;
											$insertData['order_status'] = 1;
											$insertData['add_time'] = TIMESTAMP;
											if (C::t('#tom_pay#tom_pay_order')->insert($insertData)) {
												$outArr = array('status' => 200, 'payurl' => $pay_hosts . 'plugin.php?id=tom_pay&order_no=' . $order_no);
												echo json_encode($outArr);
												exit(0);
											} else {
												$outArr = array('status' => 303);
												echo json_encode($outArr);
												exit(0);
											}
										} else {
											$outArr = array('status' => 404);
											echo json_encode($outArr);
											exit(0);
										}
									} else {
										if ($_GET['act'] == 'pay_tcshop_save' && $_GET['formhash'] == FORMHASH) {
											$outArr = array('status' => 1);
											if ('utf-8' != CHARSET) {
												if (!defined('IN_MOBILE')) {
													foreach ($_POST as $pk => $pv) {
														if (!is_numeric($pv)) {
															$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
														}
													}
												}
											}
											$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
											$tcshop_id = isset($_GET['tcshop_id']) ? intval($_GET['tcshop_id']) : 0;
											$all_money = isset($_GET['all_money']) > 0 ? floatval($_GET['all_money']) : 0;
											$hb_count = isset($_GET['hb_count']) > 0 ? intval($_GET['hb_count']) : 0;
											$open_kouling = isset($_GET['open_kouling']) ? intval($_GET['open_kouling']) : 2;
											$kouling = isset($_GET['kouling']) ? daddslashes($_GET['kouling']) : '';
											$kouling_pormpt = isset($_GET['kouling_pormpt']) ? daddslashes($_GET['kouling_pormpt']) : '';
											$fenpei_status = isset($_GET['fenpei_status']) ? intval($_GET['fenpei_status']) : 2;
											$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
											$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
											if ($all_money / $hb_count < floatval($tchongbaoConfig['hongbao_min_value'])) {
												$hbAllMoney = $hb_count * $tchongbaoConfig['hongbao_min_value'];
												$hbPormpt = '';
												if (!empty($tchongbaoConfig['hongbao_min_value_pormpt'])) {
													$hbPormpt = str_replace('{TOTAL_MONEY}', $hbAllMoney, $tchongbaoConfig['hongbao_min_value_pormpt']);
													$hbPormpt = str_replace('{MIN_MONEY}', $tchongbaoConfig['hongbao_min_value'], $hbPormpt);
													$hbPormpt = str_replace('{HB_COUNT}', $hb_count, $hbPormpt);
													$hbPormpt = diconv($hbPormpt, CHARSET, 'utf-8');
												}
												$outArr = array('status' => 305, 'hbPormpt' => $hbPormpt);
												echo json_encode($outArr);
												exit(0);
											}
											if ($tchongbaoConfig['hongbao_max_count'] > 0) {
												if ($hb_count > $tchongbaoConfig['hongbao_max_count']) {
													$outArr = array('status' => 306);
													echo json_encode($outArr);
													exit(0);
												}
											}
											if ($tchongbaoConfig['hongbao_min_count'] > 0) {
												if ($hb_count < $tchongbaoConfig['hongbao_min_count']) {
													$outArr = array('status' => 307);
													echo json_encode($outArr);
													exit(0);
												}
											}
											if ($hb_count > $all_money * 100) {
												$outArr = array('status' => 304);
												echo json_encode($outArr);
												exit(0);
											}
											$tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(' AND tcshop_id = ' . $tcshop_id . ' AND pay_status = 2 AND status = 1 AND only_show = 1', 'ORDER BY id DESC', 0, 1);
											if (is_array($tchongbaoInfoTmp) && !empty($tchongbaoInfoTmp[0])) {
												$outArr = array('status' => 301);
												echo json_encode($outArr);
												exit(0);
											}
											$__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
											if (!empty($__CommonInfo['forbid_word']) && $open_kouling == 1) {
												$forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
												$forbid_word = str_replace(array('\\*'), array('.*'), $forbid_word);
												$forbid_word = '.*(' . $forbid_word . ').*';
												$forbid_word = '/^(' . str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word) . ')$/i';
												if (@preg_match($forbid_word, $kouling_pormpt, $matches)) {
													$i = count($matches) - 1;
													$word = '';
													if (isset($matches[$i]) && !empty($matches[$i])) {
														$word = diconv($matches[$i], CHARSET, 'utf-8');
													}
													$outArr = array('status' => 505, 'word' => $word);
													echo json_encode($outArr);
													exit(0);
												}
											}
											if (!file_exists(DISCUZ_ROOT . './source/plugin/tom_pay/tom_pay.inc.php')) {
												$outArr = array('status' => 302);
												echo json_encode($outArr);
												exit(0);
											}
											if ($tchongbaoConfig['hb_lq_type'] != 1) {
												$open_kouling = 2;
											}
											$sx_money = intval($tchongbaoConfig['hongbao_shouxufei']) * $all_money / 100;
											$money = $all_money;
											$order_no = 'TC' . date('YmdHis') . '-' . mt_rand(111111, 666666);
											$insertData = array();
											$insertData['order_no'] = $order_no;
											$insertData['site_id'] = $tcshopInfo['site_id'];
											$insertData['user_id'] = $user_id;
											$insertData['tcshop_id'] = $tcshop_id;
											$insertData['all_money'] = $all_money;
											$insertData['sx_money'] = $sx_money;
											$insertData['money'] = $money;
											$insertData['hb_count'] = $hb_count;
											$insertData['open_kouling'] = $open_kouling;
											$insertData['kouling'] = $kouling;
											$insertData['kouling_pormpt'] = $kouling_pormpt;
											$insertData['status'] = 1;
											$insertData['fenpei_status'] = $fenpei_status;
											$insertData['pay_status'] = 1;
											$insertData['add_time'] = TIMESTAMP;
											if (C::t('#tom_tchongbao#tom_tchongbao')->insert($insertData)) {
												$orderId = C::t('#tom_tchongbao#tom_tchongbao')->insert_id();
												$pay_price = $all_money + $sx_money;
												$insertData = array();
												$insertData['plugin_id'] = 'tom_tchongbao';
												$insertData['order_no'] = $order_no;
												$insertData['goods_id'] = $tcshop_id;
												$insertData['goods_name'] = lang('plugin/tom_tchongbao', 'index_qiang_hb');
												$insertData['goods_beizu'] = lang('plugin/tom_tchongbao', 'index_qiang_hb');
												$insertData['goods_url'] = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&dpid=' . $tcshop_id;
												$insertData['succ_back_url'] = 'plugin.php?id=tom_tchongbao&site=' . $site_id . '&mod=add_tcshop_hb&tcshop_id=' . $tcshop_id . '&send_status=1';
												$insertData['fail_back_url'] = 'plugin.php?id=tom_tchongbao&site=' . $site_id . '&mod=add_tcshop_hb&tcshop_id=' . $tcshop_id;
												$insertData['allow_alipay'] = 1;
												$insertData['pay_price'] = $pay_price;
												$insertData['order_status'] = 1;
												$insertData['add_time'] = TIMESTAMP;
												if (C::t('#tom_pay#tom_pay_order')->insert($insertData)) {
													$outArr = array('status' => 200, 'payurl' => $pay_hosts . 'plugin.php?id=tom_pay&order_no=' . $order_no);
													echo json_encode($outArr);
													exit(0);
												} else {
													$outArr = array('status' => 303);
													echo json_encode($outArr);
													exit(0);
												}
											} else {
												$outArr = array('status' => 404);
												echo json_encode($outArr);
												exit(0);
											}
										} else {
											if ($_GET['act'] == 'edit_kouling' && $_GET['formhash'] == FORMHASH) {
												$outArr = array('status' => 1);
												if ('utf-8' != CHARSET) {
													if (!defined('IN_MOBILE')) {
														foreach ($_POST as $pk => $pv) {
															if (!is_numeric($pv)) {
																$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
															}
														}
													}
												}
												$tchongbao_id = isset($_GET['tchongbao_id']) ? intval($_GET['tchongbao_id']) : 0;
												$kouling = isset($_GET['kouling']) ? daddslashes($_GET['kouling']) : '';
												$kouling_pormpt = isset($_GET['kouling_pormpt']) ? daddslashes($_GET['kouling_pormpt']) : '';
												$updateData = array();
												$updateData['kouling'] = $kouling;
												$updateData['kouling_pormpt'] = $kouling_pormpt;
												C::t('#tom_tchongbao#tom_tchongbao')->update($tchongbao_id, $updateData);
												$outArr = array('status' => 200);
												echo json_encode($outArr);
												exit(0);
											} else {
												echo 'error';
												exit(0);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}