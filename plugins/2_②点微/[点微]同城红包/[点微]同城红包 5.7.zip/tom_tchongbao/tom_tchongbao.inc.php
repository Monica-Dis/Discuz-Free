<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tchongbaoConfig = $_G['cache']['plugin']['tom_tchongbao'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = '20180424';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tchongbao/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$tchongbaoConfig['tongcheng_hosts'] = trim($tchongbaoConfig['tongcheng_hosts']);
$tchongbaoConfig['hongbao_hosts'] = trim($tchongbaoConfig['hongbao_hosts']);
$__OnlyHosts = 0;
$__TongchengHost = '';
if ($tchongbaoConfig['open_only_hosts'] == 1 && !empty($tchongbaoConfig['tongcheng_hosts']) && !empty($tchongbaoConfig['hongbao_hosts'])) {
	$__OnlyHosts = 1;
	$urlTmp = $weixinClass->get_url();
	if (strpos($urlTmp, $tchongbaoConfig['hongbao_hosts']) === false && strpos($urlTmp, $tchongbaoConfig['tongcheng_hosts']) !== false) {
		$newUrlTmp = str_replace($tchongbaoConfig['tongcheng_hosts'], $tchongbaoConfig['hongbao_hosts'], $urlTmp);
		if ($tchongbaoConfig['must_http'] == 1) {
			$newUrlTmp = str_replace('https', 'http', $newUrlTmp);
		}
		dheader('location:' . $newUrlTmp);
		exit(0);
	}
	preg_match('#((http|https)://([^?]*)/)([a-z_0-9]*.php)#', $urlTmp, $urlmatches2);
	if (strpos($urlmatches2['0'], $tchongbaoConfig['tongcheng_hosts']) === false && strpos($urlTmp, $tchongbaoConfig['hongbao_hosts']) !== false) {
		$__TongchengHost = str_replace($tchongbaoConfig['hongbao_hosts'], $tchongbaoConfig['tongcheng_hosts'], $urlmatches2['0']);
		$__TongchengHost = rtrim($__TongchengHost, $urlmatches2['4']);
		if ($tchongbaoConfig['must_http'] == 1) {
			if (strpos($__TongchengHost, 'https') === false) {
				$__TongchengHost = str_replace('http', 'https', $__TongchengHost);
			}
		}
	}
}
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tchongbaoConfig['wx_share_title'];
$shareDesc = $tchongbaoConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tchongbao&site=' . $site_id . '&mod=index');
$shareLogo = $tchongbaoConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
$__ShowTcshop = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcshop/tom_tcshop.inc.php')) {
	$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
	if ($tcshopConfig['open_tcshop'] == 1) {
		$__ShowTcshop = 1;
	}
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
if ($_GET['mod'] == 'add') {
	$tongcheng_id = isset($_GET['tongcheng_id']) ? intval($_GET['tongcheng_id']) : 0;
	$send_status = isset($_GET['send_status']) ? intval($_GET['send_status']) : 0;
	$tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
	if (!is_array($tongchengInfo) || $tongchengInfo['user_id'] != $__UserInfo['id']) {
		dheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tchongbao&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(' AND tongcheng_id = ' . $tongcheng_id . ' AND pay_status = 2 AND only_show = 1 ', 'ORDER BY add_time DESC,id DESC', 0, 1);
	$tchongbaoInfo = array();
	$tchongShenyuCount = 0;
	if (is_array($tchongbaoInfoTmp) && !empty($tchongbaoInfoTmp[0])) {
		$tchongbaoInfo = $tchongbaoInfoTmp[0];
		$tchongbaoLogCount = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_count(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ');
		$tchongShenyuCount = $tchongbaoInfo['hb_count'] - $tchongbaoLogCount;
	}
	$add_hb_text = discuzcode($tchongbaoConfig['add_hb_text'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);
	$pay_save = 'pay_tongcheng_save';
	$payUrl = 'plugin.php?id=tom_tchongbao:ajax&site=' . $site_id;
	$backUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=mylist';
	$succLookUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=info&tongcheng_id=' . $tongcheng_id;
	$templateSmsAjaxUrl = 'plugin.php?id=tom_tchongbao:ajax&act=nitice_sms_hb&site=' . $site_id . '&tongcheng_id=' . $tongcheng_id . '&hongbao_id=' . $tchongbaoInfo['id'] . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tchongbao:add');
} else {
	if ($_GET['mod'] == 'add_tcshop_hb') {
		$tcshop_id = isset($_GET['tcshop_id']) ? intval($_GET['tcshop_id']) : 0;
		$send_status = isset($_GET['send_status']) ? intval($_GET['send_status']) : 0;
		$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
		if (!is_array($tcshopInfo) || $tcshopInfo['user_id'] != $__UserInfo['id']) {
			dheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=index'));
			exit(0);
		}
		$tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(' AND tcshop_id = ' . $tcshop_id . ' AND pay_status = 2 AND only_show = 1 ', 'ORDER BY add_time DESC,id DESC', 0, 1);
		$tchongbaoInfo = array();
		$tchongShenyuCount = 0;
		if (is_array($tchongbaoInfoTmp) && !empty($tchongbaoInfoTmp[0])) {
			$tchongbaoInfo = $tchongbaoInfoTmp[0];
			$tchongbaoLogCount = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_count(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ');
			$tchongShenyuCount = $tchongbaoInfo['hb_count'] - $tchongbaoLogCount;
		}
		$add_hb_text = discuzcode($tchongbaoConfig['add_hb_text'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);
		$pay_save = 'pay_tcshop_save';
		$payUrl = 'plugin.php?id=tom_tchongbao:ajax&site=' . $site_id;
		$backUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=mylist';
		$succLookUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&tcshop_id=' . $tcshop_id;
		$templateSmsAjaxUrl = 'plugin.php?id=tom_tchongbao:ajax&act=nitice_sms_tcshop_hb&site=' . $site_id . '&tcshop_id=' . $tcshop_id . '&hongbao_id=' . $tchongbaoInfo['id'] . '&formhash=' . $formhash;
		$isGbk = false;
		if (CHARSET == 'gbk') {
			$isGbk = true;
		}
		include template('tom_tchongbao:add');
	} else {
		if ($_GET['mod'] == 'index') {
			$tab = intval($_GET['tab']) > 0 ? intval($_GET['tab']) : 1;
			if ($tab == 1) {
				$ajaxLoadListUrl = 'plugin.php?id=tom_tchongbao:ajax&site=' . $site_id . '&act=list&status=0&formhash=' . $formhash;
			} else {
				if ($tab == 2) {
					$ajaxLoadListUrl = 'plugin.php?id=tom_tchongbao:ajax&site=' . $site_id . '&act=list&status=1&formhash=' . $formhash;
				} else {
					if ($tab == 3) {
						$ajaxLoadListUrl = 'plugin.php?id=tom_tchongbao:ajax&site=' . $site_id . '&act=tcshop_list&formhash=' . $formhash;
					}
				}
			}
			$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tchongbao/images/index.js';
			$isGbk = false;
			if (CHARSET == 'gbk') {
				$isGbk = true;
			}
			include template('tom_tchongbao:index');
			echo '<script src="source/plugin/tom_tchongbao/images/index.js"></script>';
		} else {
			if ($_GET['mod'] == 'loglist') {
				$hongbao_id = isset($_GET['hongbao_id']) ? intval($_GET['hongbao_id']) : 0;
				$tchongbaoInfo = C::t('#tom_tchongbao#tom_tchongbao')->fetch_by_id($hongbao_id);
				if (!$tchongbaoInfo) {
					dheader('location:' . $_G['siteurl'] . 'plugin.php?id=tom_tongcheng&site=1&mod=index');
					exit(0);
				}
				$hbUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tchongbaoInfo['user_id']);
				$tchongbaoLogCount = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_count(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ');
				if ($tchongbaoLogCount >= $tchongbaoInfo['hb_count'] || $tchongbaoInfo['money'] <= 0) {
					$updateData = array();
					$updateData['status'] = 2;
					C::t('#tom_tchongbao#tom_tchongbao')->update($hongbao_id, $updateData);
					$tchongbaoInfo['status'] = 2;
				}
				$tchongbaoLogInfoTmp = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
				$tchongbaoLogInfo = array();
				$show_my_hb = 0;
				if (is_array($tchongbaoLogInfoTmp) && !empty($tchongbaoLogInfoTmp[0])) {
					$tchongbaoLogInfo = $tchongbaoLogInfoTmp[0];
					$show_my_hb = 1;
				}
				$tchongbaoLogSumMoney = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_sum_money(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ');
				$tchongbaoLogListTmp = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_list(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ', 'ORDER BY id DESC', 0, $tchongbaoLogCount);
				$tchongbaoLogList = array();
				if (is_array($tchongbaoLogListTmp) && !empty($tchongbaoLogListTmp[0])) {
					foreach ($tchongbaoLogListTmp as $key => $value) {
						$tchongbaoLogList[$key] = $value;
					}
				}
				$tchongbaoLastInfoTmp = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_list(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
				$times = 0;
				if (is_array($tchongbaoLastInfoTmp) && !empty($tchongbaoLastInfoTmp[0])) {
					$start_time = $tchongbaoInfo['add_time'];
					$end_time = $tchongbaoLastInfoTmp[0]['log_time'];
					$time = $end_time - $start_time;
					if ($time >= 0 && $time < 3600) {
						$times = ceil($time / 60) . lang('plugin/tom_tchongbao', 'minute');
					} else {
						if ($time >= 3600 && $time < 86400) {
							$times = ceil($time / 60 / 60) . lang('plugin/tom_tchongbao', 'hours');
						} else {
							if ($time >= 86400) {
								$times = ceil($time / 60 / 60 / 24) . lang('plugin/tom_tchongbao', 'day');
							}
						}
					}
				}
				if ($tchongbaoInfo['tongcheng_id'] > 0) {
					$back = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=info&tongcheng_id=' . $tchongbaoInfo['tongcheng_id'];
				} else {
					if ($tchongbaoInfo['tcshop_id'] > 0) {
						$back = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&tcshop_id=' . $tchongbaoInfo['tcshop_id'];
					}
				}
				$isGbk = false;
				if (CHARSET == 'gbk') {
					$isGbk = true;
				}
				include template('tom_tchongbao:loglist');
			} else {
				tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tchongbao&site=' . $site_id . '&mod=index'));
				exit(0);
			}
		}
	}
}
tomoutput();