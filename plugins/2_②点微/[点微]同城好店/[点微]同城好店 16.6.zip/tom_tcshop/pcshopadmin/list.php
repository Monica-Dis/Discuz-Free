<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=list";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if(!empty($act) && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcshop_id = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
    $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
    if($tcshopInfo){
        if($__UserInfo['id'] != $tcshopInfo['user_id']){
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['no_quanxian_error'],CHARSET,'utf-8'),
            );    
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
        );    
        echo json_encode($outArr); exit;
    }
    
    if($act == 'show'){

        $updateData = array();
        $updateData['status']     = 1;
        C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id, $updateData);
        $outArr = array(
            'code'=> 200,
        );    
        echo json_encode($outArr); exit;
    }else if($act == 'hide'){

        $updateData = array();
        $updateData['status']     = 2;
        C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id, $updateData);
        $outArr = array(
            'code'=> 200,
        );    
        echo json_encode($outArr); exit;
    }else if($act == 'edithexiao'){
        
        $hexiao_type    = isset($_GET['hexiao_type'])? intval($_GET['hexiao_type']):0;

        $updateData = array();
        $updateData['hexiao_type'] = $hexiao_type;
        C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id, $updateData);

        $outArr = array(
            'code'=> 200,
        );    
        echo json_encode($outArr); exit;
    }
    
}

$keyword        = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$tcshop_id      = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
$site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
$cate_child_id  = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
$shenhe_status  = isset($_GET['shenhe_status']) ? intval($_GET['shenhe_status']) : 0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['parent_id'] > 0){
            $cateChildList[$value['parent_id']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$where = " AND user_id = {$__UserInfo['id']} AND (pay_status = 0 OR pay_status = 2) ";
if($tcshop_id > 0){
    $where.= " AND id={$tcshop_id} ";
}
if($site_id > 0){
    $where.= " AND site_id={$site_id} ";
}
if($cate_id > 0){
    $where.= " AND cate_id={$cate_id} ";
}
if($cate_child_id > 0){
    $where.= " AND cate_child_id={$cate_child_id} ";
}
if($shenhe_status > 0){
    $where.= " AND shenhe_status = {$shenhe_status} ";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count($where,$keyword);
$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize,$keyword);
$tcshopList = array();
if(!empty($tcshopListTmp)){
    foreach ($tcshopListTmp as $key => $value) {
        $tcshopList[$key] = $value;
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        $cateInfoTmp = $cateList[$value['cate_id']];
        $cateChildInfoTmp = $cateList[$value['cate_id']]['cateChildList'][$value['cate_child_id']];
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
        $vipInfoTmp = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($value['vip_id']);
        
        $tcshopList[$key]['picurl'] = get_file_url($value['picurl']);
        
        $tcshopList[$key]['cateInfo']       = $cateInfoTmp;
        $tcshopList[$key]['cateChildInfo']  = $cateChildInfoTmp;
        $tcshopList[$key]['siteInfo']       = $siteInfoTmp;
        $tcshopList[$key]['areaInfo']       = $areaInfoTmp;
        $tcshopList[$key]['streetInfo']     = $streetInfoTmp;
        $tcshopList[$key]['vipInfo']        = $vipInfoTmp;
        
        $tcshopList[$key]['ruzhu_time']     = dgmdate($value['ruzhu_time'],"Y-m-d H:i",$tomSysOffset);
        $tcshopList[$key]['vip_time']       = dgmdate($value['vip_time'],"Y-m-d H:i",$tomSysOffset);
        $tcshopList[$key]['base_time']      = dgmdate($value['base_time'],"Y-m-d H:i",$tomSysOffset);
        $tcshopList[$key]['toptime']        = dgmdate($value['toptime'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&keyword={$keyword}&shenhe_status={$shenhe_status}&cate_id={$cate_id}&cate_child_id={$cate_child_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:pcshopadmin/list");