<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=pinglunReplay";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('reply_id')){
    $outArr = array(
        'code'=> 1,
    );

    $reply_id = intval($_GET['reply_id'])>0? intval($_GET['reply_id']):0;
    
    if($tongchengConfig['open_fbr_remove_pinglun'] != 1){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['no_quanxian_error'],CHARSET,'utf-8'),
        );    
        echo json_encode($outArr); exit;
    }

    $replyInfo = C::t('#tom_tcshop#tom_tcshop_pinglun_reply')->fetch_by_id($reply_id);
    $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($replyInfo['tcshop_id']);
    if($tcshopInfo['user_id']  != $__UserInfo['id']){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['no_quanxian_error'],CHARSET,'utf-8'),
        );    
        echo json_encode($outArr); exit;
    }
    
    C::t('#tom_tcshop#tom_tcshop_pinglun_reply')->delete($reply_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('reply_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $replyIdsArr = array();
    if(is_array($_GET['reply_ids'])){
        foreach($_GET['reply_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $replyIdsArr[] = $idTmp;
            }
        }
    }
    
    if($tongchengConfig['open_fbr_remove_pinglun'] != 1){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['no_quanxian_error'],CHARSET,'utf-8'),
        );    
        echo json_encode($outArr); exit;
    }
    
    if(!empty($replyIdsArr)){
        foreach ($replyIdsArr as $key => $value){
            
            $replyInfo = C::t("#tom_tcshop#tom_tcshop_pinglun_reply")->fetch_by_id($value);
            $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($replyInfo['tcshop_id']);
            if($tcshopInfo['user_id'] != $__UserInfo['id']){
                $outArr = array(
                    'code'=> 1001,
                    'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
                );
                echo json_encode($outArr); exit;
            }
            
            C::t('#tom_tcshop#tom_tcshop_pinglun_reply')->delete($value);
        }
    }
    
    if(!empty($replyIdsArr)){
        foreach ($replyIdsArr as $key => $value){
            C::t('#tom_tcshop#tom_tcshop_pinglun_reply')->delete($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$tcshop_id  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$pinglun_id = intval($_GET['pinglun_id'])>0? intval($_GET['pinglun_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$tcshopListTmp = C::t("#tom_tcshop#tom_tcshop")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND (pay_status = 0 OR pay_status = 2) ", "ORDER BY id DESC", 0, 1000);
$tcshopList = array();
if(!empty($tcshopListTmp)){
    foreach($tcshopListTmp as $key => $value){
        $tcshopList[$value['id']] = $value;
    }
}

$where = '';
if($tcshop_id > 0){
    $where .= " AND tcshop_id={$tcshop_id} ";
}else{
    $tcshopIdsList = array_keys($tcshopList);
    if(!empty($tcshopIdsList)){
        $tcshopIdsStr = implode(',', $tcshopIdsList);
        $where .= " AND tcshop_id IN({$tcshopIdsStr}) ";
    }else{
        $where .= " AND tcshop_id = 0 ";
    }
}
if($pinglun_id > 0){
    $where .= " AND ping_id={$pinglun_id} ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcshop#tom_tcshop_pinglun_reply')->fetch_all_count($where);
$replyListTmp = C::t('#tom_tcshop#tom_tcshop_pinglun_reply')->fetch_all_list($where,"ORDER BY reply_time DESC",$start,$pagesize);
$replyList = array();
if(!empty($replyListTmp)){
    foreach($replyListTmp as $key => $value){
        $tcshopInfoTmp = $tcshopList[$value['tcshop_id']];
        if(is_array($tcshopInfoTmp) && !empty($tcshopInfoTmp)){
            $replyList[$key] = $value;

            $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['reply_user_id']);
            $pinglunInfoTmp = C::t('#tom_tcshop#tom_tcshop_pinglun')->fetch_by_id($value['ping_id']);

            $pinglunInfoTmp['content'] = cutstr($pinglunInfoTmp['content'],20,"...");

            $replyList[$key]['tcshopInfo']    = $tcshopInfoTmp;
            $replyList[$key]['userInfo']      = $userInfoTmp;
            $replyList[$key]['pinglunInfo']   = $pinglunInfoTmp;
            $replyList[$key]['reply_time']    = dgmdate($value['reply_time'], 'Y-m-d H:i:s',$tomSysOffset);
        }
    }
}

$pageUrl = $modPcadminUrl."&tcshop_id={$tcshop_id}&pinglun_id={$pinglun_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:pcshopadmin/pinglunReplay");