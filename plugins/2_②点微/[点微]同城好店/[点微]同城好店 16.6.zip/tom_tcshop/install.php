<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcshop`;
CREATE TABLE `pre_tom_tcshop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `vip_id` int(11) DEFAULT '0',
  `vip_rank` int(11) DEFAULT '0',
  `vip_status` tinyint(4) DEFAULT '0',
  `hexiao_type` tinyint(4) DEFAULT '0',
  `vip_level` int(11) DEFAULT '0',
  `vip_time` int(11) DEFAULT '0',
  `base_level` int(11) DEFAULT '1',
  `base_time` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `cate_id` int(11) DEFAULT '0',
  `cate_child_id` int(11) DEFAULT '0',
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `street_id` int(11) DEFAULT '0',
  `tabs` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `shopkeeper_tel` varchar(255) DEFAULT NULL,
  `kefu_qrcode` varchar(255) DEFAULT NULL,
  `business_licence` varchar(255) DEFAULT NULL,
  `business_hours` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `admin_edit` int(11) DEFAULT '0',
  `content` mediumtext,
  `haibao_msg` varchar(255) DEFAULT NULL,
  `zan_txt` varchar(255) DEFAULT NULL,
  `gonggao` varchar(255) DEFAULT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  `video_pic` varchar(255) DEFAULT NULL,
  `vr_url` varchar(255) DEFAULT NULL,
  `mp3_url` varchar(255) DEFAULT NULL,
  `zhuanfa` int(11) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `guanzu` int(11) DEFAULT '0',
  `lbs_id` int(11) unsigned DEFAULT '0',
  `lbs_status` int(11) DEFAULT '0',
  `lbs_time` int(11) DEFAULT '0',
  `topstatus` int(11) DEFAULT '0',
  `toptime` int(11) DEFAULT '0',
  `toprand` int(11) DEFAULT '1',
  `refresh_time` int(11) DEFAULT '0',
  `ruzhu_time` int(11) DEFAULT '0',
  `is_ok` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `pay_status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '1',
  `auto_click_time` int(11) DEFAULT '0',
  `auto_zhuanfa_time` int(11) DEFAULT '0',
  `ruzhu_level` int(11) DEFAULT '0',
  `link` varchar(255) DEFAULT NULL,
  `link_name` varchar(255) DEFAULT NULL,
  `edmoney` decimal(10,2) DEFAULT '0.00',
  `dispatch_type` int(11) DEFAULT '0',
  `peisong_type` tinyint(4) DEFAULT '0',
  `open_vip_price_set` tinyint(4) DEFAULT '0',
  `mall_shop_picurl` varchar(255) DEFAULT NULL,
  `huodao_pay` tinyint(4) DEFAULT '0',
  `open_shop_list_cart` tinyint(4) DEFAULT '1',
  `tc114_status` int(11) DEFAULT '0',
  `open_yuyue` tinyint(4) DEFAULT '0',
  `tcyuyue_id` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcshop_cate`;
CREATE TABLE `pre_tom_tcshop_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT '0',
  `youhui_model_name` varchar(255) DEFAULT NULL,
  `youhui_model_id` int(11) DEFAULT '0',
  `youhui_model_ids` varchar(255) DEFAULT NULL,
  `open_upload_proof` tinyint(4) DEFAULT '0',
  `upload_proof_text` varchar(255) DEFAULT NULL,
  `open_tel_price` int(11) DEFAULT '0',
  `tc114_cate_id` int(11) DEFAULT '0',
  `csort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcshop_common`;
CREATE TABLE `pre_tom_tcshop_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `xieyi_txt` text,
  `vip_txt` text,
  `new_vip_txt` text,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcshop_focuspic`;
CREATE TABLE `pre_tom_tcshop_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '1',
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcshop_guanzu`;
CREATE TABLE `pre_tom_tcshop_guanzu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcshop_photo`;
CREATE TABLE `pre_tom_tcshop_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcshop_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '999',
  `oss_picurl` varchar(255) DEFAULT NULL,
  `oss_status` int(11) DEFAULT '0',
  `qiniu_picurl` varchar(255) DEFAULT NULL,
  `qiniu_status` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '1',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcshop_pinglun`;
CREATE TABLE `pre_tom_tcshop_pinglun` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tcshop_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `content` text,
  `ping_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcshop_pinglun_reply`;
CREATE TABLE `pre_tom_tcshop_pinglun_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ping_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `reply_user_id` int(11) DEFAULT '0',
  `reply_user_nickname` varchar(255) DEFAULT NULL,
  `reply_user_avatar` varchar(255) DEFAULT NULL,
  `content` text,
  `reply_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcshop_resou`;
CREATE TABLE `pre_tom_tcshop_resou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `keywords` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '100',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
       
DROP TABLE IF EXISTS `pre_tom_tcshop_topnews`;
CREATE TABLE `pre_tom_tcshop_topnews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcshop_clerk`;
CREATE TABLE `pre_tom_tcshop_clerk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcshop_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcshop_tuwen`;
CREATE TABLE `pre_tom_tcshop_tuwen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcshop_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `txt` text,
  `paixu` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcshop_pinglun_photo`;
CREATE TABLE `pre_tom_tcshop_pinglun_photo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pinglun_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcshop_clicks_log`;
CREATE TABLE `pre_tom_tcshop_clicks_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcshop_id` int(11) DEFAULT '0',
  `ip` int(11) unsigned DEFAULT '0',
  `today_time` int(11) DEFAULT '0',
  `log_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcshop_money_log`;
CREATE TABLE `pre_tom_tcshop_money_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `tixian_id` int(11) DEFAULT '0',
  `change_money` decimal(10,2) DEFAULT '0.00',
  `old_money` decimal(10,2) DEFAULT '0.00',
  `business_id` varchar(255) DEFAULT NULL,
  `business_user_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `order_no` varchar(255) DEFAULT NULL,
  `beizu` text,
  `log_year` int(11) DEFAULT '0',
  `log_month` int(11) DEFAULT '0',
  `log_day` int(11) DEFAULT '0',
  `log_ip` varchar(255) DEFAULT NULL,
  `log_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcshop_money_tixian`;
CREATE TABLE `pre_tom_tcshop_money_tixian` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tx_order_no` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00',
  `alipay_zhanghao` varchar(255) DEFAULT NULL,
  `alipay_truename` varchar(255) DEFAULT NULL,
  `beizu` text,
  `status` int(11) DEFAULT '0',
  `tixian_ip` varchar(255) DEFAULT NULL,
  `tixian_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcshop_mall_cate`;
CREATE TABLE `pre_tom_tcshop_mall_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcshop_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `csort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcshop_vip`;
CREATE TABLE `pre_tom_tcshop_vip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `open_video` tinyint(4) DEFAULT '0',
  `open_vr` tinyint(4) DEFAULT '0',
  `open_mp3` tinyint(4) DEFAULT '0',
  `open_zan` tinyint(4) DEFAULT '0',
  `open_gonggao` tinyint(4) DEFAULT '0',
  `open_xiao_qrcode` tinyint(4) DEFAULT '0',
  `open_tcmall` tinyint(4) DEFAULT '0',
  `open_tcqianggou` tinyint(4) DEFAULT '0',
  `open_coupon` tinyint(4) DEFAULT '0',
  `open_tcptuan` tinyint(4) DEFAULT '0',
  `open_tckjia` tinyint(4) DEFAULT '0',
  `open_tcchoujiang` tinyint(4) DEFAULT '0',
  `open_tchuodong` tinyint(4) DEFAULT '0',
  `open_tctoutiao` tinyint(4) DEFAULT '0',
  `open_tcyikatong` tinyint(4) DEFAULT '0',
  `open_fenlei` tinyint(4) DEFAULT '0',
  `days` int(11) DEFAULT '0',
  `days_msg` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `rank` int(11) DEFAULT '0',
  `fenlei_times` int(11) DEFAULT '0',
  `xiangou_num` int(11) DEFAULT '0',
  `is_base` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `vsort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcshop_vip_code`;
CREATE TABLE `pre_tom_tcshop_vip_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vip_id` int(11) DEFAULT '0',
  `code` varchar(255) DEFAULT NULL,
  `use_status` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `use_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcshop_vip_log`;
CREATE TABLE `pre_tom_tcshop_vip_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `vip_id` int(11) DEFAULT '0',
  `vip_code_id` int(11) DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcshop_express`;
CREATE TABLE `pre_tom_tcshop_express` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcshop_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `issendfree` tinyint(4) DEFAULT '0',
  `default_price` decimal(10,2) DEFAULT '0.00',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcshop_express_item`;
CREATE TABLE `pre_tom_tcshop_express_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcshop_id` int(11) DEFAULT '0',
  `express_id` int(11) DEFAULT '0',
  `province_id` int(11) DEFAULT '0',
  `province_name` varchar(255) DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `city_name` varchar(255) DEFAULT NULL,
  `area_id` int(11) DEFAULT '0',
  `area_name` varchar(255) DEFAULT NULL,
  `issendfree` tinyint(4) DEFAULT '0',
  `express_price` decimal(10,2) DEFAULT '0.00',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcshop_fabu_log`;
CREATE TABLE `pre_tom_tcshop_fabu_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `time_key` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcshop_place`;
CREATE TABLE `pre_tom_tcshop_place` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcshop_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `psort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;