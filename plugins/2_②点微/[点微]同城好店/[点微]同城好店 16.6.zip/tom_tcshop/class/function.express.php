<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function tom_express($express_id, $address_id) {
    $data = array();
    
    if($address_id > 0){
        $addressInfoTmp = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
        if(is_array($addressInfoTmp) && !empty($addressInfoTmp)){ }else{
            return false;
        }
        
        $expressItemInfo = array();
        
        $expressItemInfoTmp = C::t('#tom_tcshop#tom_tcshop_express_item')->fetch_all_list(" AND express_id = {$express_id} AND province_id = {$addressInfoTmp['province_id']} AND city_id = {$addressInfoTmp['city_id']} AND area_id = {$addressInfoTmp['area_id']} ", 'ORDER BY id DESC', 0, 1);
        if(is_array($expressItemInfoTmp) && !empty($expressItemInfoTmp[0])){
            $expressItemInfo = $expressItemInfoTmp[0];
        }
        if(empty($expressItemInfo)){
            $expressItemInfoTmp = C::t('#tom_tcshop#tom_tcshop_express_item')->fetch_all_list(" AND express_id = {$express_id} AND province_id = {$addressInfoTmp['province_id']} AND city_id = {$addressInfoTmp['city_id']} ", 'ORDER BY id DESC', 0, 1);
            if(is_array($expressItemInfoTmp) && !empty($expressItemInfoTmp[0])){
                $expressItemInfo = $expressItemInfoTmp[0];
            }
        }
        if(empty($expressItemInfo)){
            $expressItemInfoTmp = C::t('#tom_tcshop#tom_tcshop_express_item')->fetch_all_list(" AND express_id = {$express_id} AND province_id = {$addressInfoTmp['province_id']} ", 'ORDER BY id DESC', 0, 1);
            if(is_array($expressItemInfoTmp) && !empty($expressItemInfoTmp[0])){
                $expressItemInfo = $expressItemInfoTmp[0];
            }
        }
        
        if(is_array($expressItemInfo) && !empty($expressItemInfo)){
            $data['issendfree']     = $expressItemInfo['issendfree'];
            $data['express_price']  = $expressItemInfo['express_price'];
        }
    }
    
    if(empty($data)){
        $expressInfoTmp = C::t('#tom_tcshop#tom_tcshop_express')->fetch_by_id($express_id);
        if(is_array($expressInfoTmp) && !empty($expressInfoTmp)){
            $data['issendfree']     = $expressInfoTmp['issendfree'];
            $data['express_price']  = $expressInfoTmp['default_price'];
        }
    }
    
    return $data;
}