<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = '20210913';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tcshop/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/qqface.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcshopConfig['wx_share_title'];
$shareDesc = $tcshopConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=index');
$shareLogo = $tcshopConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
$__ShowTcmall = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcmall/tom_tcmall.inc.php')) {
	$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
	if ($tcmallConfig['open_tcmall'] == 1) {
		$__ShowTcmall = 1;
	}
}
$__ShowTcqianggou = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')) {
	$tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
	if ($tcqianggouConfig['open_tcqianggou'] == 1) {
		$__ShowTcqianggou = 1;
	}
}
$__ShowTcptuan = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcptuan/tom_tcptuan.inc.php')) {
	$tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
	if ($tcptuanConfig['open_tcptuan'] == 1) {
		$__ShowTcptuan = 1;
	}
}
$__ShowTckjia = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tckjia/tom_tckjia.inc.php')) {
	$tckjiaConfig = $_G['cache']['plugin']['tom_tckjia'];
	if ($tckjiaConfig['open_tckjia'] == 1) {
		$__ShowTckjia = 1;
	}
}
$__ShowTcyikatong = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')) {
	$tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
	if ($tcyikatongConfig['open_tcyikatong'] == 1) {
		$__ShowTcyikatong = 1;
	}
}
$__ShowTchongbao = 0;
$tchongbaoConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchongbao/tom_tchongbao.inc.php')) {
	$tchongbaoConfig = $_G['cache']['plugin']['tom_tchongbao'];
	$tchongbaoConfig['hb_lq_type'] = 1;
	if ($tchongbaoConfig['open_tcshop_tchongbao'] == 1) {
		$__ShowTchongbao = 1;
	}
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$__ShowTcsign = 0;
$tcsignConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcsign/tom_tcsign.inc.php')) {
	$tcsignConfig = $_G['cache']['plugin']['tom_tcsign'];
	$__ShowTcsign = 1;
}
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')) {
	$tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
	if ($tcchoujiangConfig['open_tcchoujiang'] == 1) {
		$__ShowTcchoujiang = 1;
	}
}
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')) {
	$tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
	if ($tcrenzhengConfig['open_tcrenzheng'] == 1) {
		$__ShowTcrenzheng = 1;
	}
}
$__ShowTctoutiao = 0;
$tctoutiaoConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tctoutiao/tom_tctoutiao.inc.php')) {
	$tctoutiaoConfig = $_G['cache']['plugin']['tom_tctoutiao'];
	if ($tctoutiaoConfig['open_tctoutiao'] == 1) {
		$__ShowTctoutiao = 1;
	}
}
$__ShowTcfangchan = 0;
$tcfangchanConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcfangchan/tom_tcfangchan.inc.php')) {
	$tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
	if ($tcfangchanConfig['open_tcfangchan'] == 1) {
		$__ShowTcfangchan = 1;
	}
}
$__ShowTczhaopin = 0;
$tczhaopinConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')) {
	$tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
	if ($tczhaopinConfig['open_tczhaopin'] == 1) {
		$__ShowTczhaopin = 1;
	}
}
$__ShowTchuodong = 0;
$tchuodongConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchuodong/tom_tchuodong.inc.php')) {
	$tchuodongConfig = $_G['cache']['plugin']['tom_tchuodong'];
	if ($tchuodongConfig['open_tchuodong'] == 1) {
		$__ShowTchuodong = 1;
	}
}
$tcadminConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcadmin/tom_tcadmin.inc.php')) {
	$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
$__ShowVideo = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/video.inc.php')) {
	$__ShowVideo = 1;
}
$__ShowTcqun = 0;
$tcqunConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcqun/tom_tcqun.inc.php')) {
	$tcqunConfig = $_G['cache']['plugin']['tom_tcqun'];
	if ($tcqunConfig['open_tcqun'] == 1) {
		$__ShowTcqun = 1;
	}
}
$__ShowTcyuyue = 0;
$tcyuyueConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcyuyue/tom_tcyuyue.inc.php')) {
	$tcyuyueConfig = $_G['cache']['plugin']['tom_tcyuyue'];
	if ($tcyuyueConfig['open_tcyuyue'] == 1) {
		$__ShowTcyuyue = 1;
	}
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$searchUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=get_search_url';
$searchMallUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=get_search_url';
$searchQianggouUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=get_search_url';
$searchCouponUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=get_coupon_search_url';
$searchPtuanUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=get_search_url';
$ajaxLoadListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
$ajaxAutoClickUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=auto_click&formhash=' . $formhash;
$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
$ajaxUpdateTopstatusUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=updateTopstatus&formhash=' . $formhash;
$ajaxUpdateVipStatusUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=update_vip_status&formhash=' . $formhash;
$ajaxUpdateToprandUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=updateToprand&&formhash=' . $formhash;
$ajaxTongbu114Url = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=tongbu_114&&formhash=' . $formhash;
$ajaxCommonClicksUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=commonClicks&formhash=' . $formhash;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
$footer_nav_content_name = $footer_nav_content_link = $footer_nav_content_ico = '';
if ($tongchengConfig['footer_nav_mod'] == 1) {
	if (!empty($tongchengConfig['footer_nav_content'])) {
		$footer_nav_content = explode('|', $tongchengConfig['footer_nav_content']);
		$footer_nav_content_name = $footer_nav_content[0];
		$footer_nav_content_link = $footer_nav_content[1];
		$footer_nav_content_link = str_replace('{site}', $site_id, $footer_nav_content_link);
		if (isset($footer_nav_content[2]) && !empty($footer_nav_content[2])) {
			$footer_nav_content_ico = $footer_nav_content[2];
		}
	}
}
if ($tongchengConfig['footer_nav_mod'] == 7 && $__IsMiniprogram == 1 && $tctoutiaoConfig['closed_xiao'] == 1) {
	$tongchengConfig['footer_nav_mod'] = 0;
}
if ($_GET['mod'] == 'index') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/site_ibs.php';
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$tab = intval($_GET['tab']) > 0 ? intval($_GET['tab']) : 1;
	$cateListTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list(' AND parent_id=0 ', ' ORDER BY csort ASC,id DESC ', 0, 50);
	$navList = array();
	$cateList = array();
	$i = 1;
	$navCount = 0;
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$navList[$value['id']]['i'] = $i;
			$navList[$value['id']]['title'] = $value['name'];
			$navList[$value['id']]['picurl'] = $picurl;
			$navList[$value['id']]['link'] = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=list&cate_id=' . $value['id'];
			$i++;
			$navCount++;
		}
	}
	$focuspicListTmp = C::t('#tom_tcshop#tom_tcshop_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tcshop#tom_tcshop_focuspic')->fetch_all_list(' AND site_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicTopList = $focuspicZhongList = array();
	foreach ($focuspicListTmp as $key => $value) {
		if (!preg_match('/^http/', $value['picurl'])) {
			if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
				$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
			} else {
				$picurl = $value['picurl'];
			}
		} else {
			$picurl = $value['picurl'];
		}
		$linkTmp = str_replace('{site}', $site_id, $value['link']);
		if ($value['type'] == 1) {
			$focuspicTopList[$key] = $value;
			$focuspicTopList[$key]['picurl'] = $picurl;
			$focuspicTopList[$key]['link'] = $linkTmp;
		} elseif ($value['type'] == 2) {
			$focuspicZhongList[$key] = $value;
			$focuspicZhongList[$key]['picurl'] = $picurl;
			$focuspicZhongList[$key]['link'] = $linkTmp;
		}
	}
	$newTcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND site_id IN(' . $sql_in_site_ids . ') ', ' ORDER BY id DESC ', 0, 10);
	$newTcshopList = array();
	if (is_array($newTcshopListTmp) && !empty($newTcshopListTmp)) {
		foreach ($newTcshopListTmp as $key => $value) {
			$newTcshopList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$avatarInfoTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(' AND tcshop_id=' . $value['id'] . ' AND type_id = 4 ', 'ORDER BY id ASC', 0, 1);
			if (is_array($avatarInfoTmp) && !empty($avatarInfoTmp)) {
				if ($tongchengConfig['open_yun'] == 2 && !empty($avatarInfoTmp[0]['oss_picurl']) && $avatarInfoTmp[0]['oss_status'] == 1) {
					$picurl = $avatarInfoTmp[0]['oss_picurl'];
				} else {
					if ($tongchengConfig['open_yun'] == 3 && !empty($avatarInfoTmp[0]['qiniu_picurl']) && $avatarInfoTmp[0]['qiniu_status'] == 1) {
						$picurl = $avatarInfoTmp[0]['qiniu_picurl'];
					}
				}
			}
			$newTcshopList[$key]['picurl'] = $picurl;
		}
	}
	$ajaxIndexLoadListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
	if ($tab == 1) {
		$ajaxIndexLoadListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
	} elseif ($tab == 2) {
		$ajaxIndexLoadListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=list&ordertype=new&formhash=' . $formhash;
	} elseif ($tab == 3) {
		$ajaxIndexLoadListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=list&ordertype=lbs&formhash=' . $formhash;
	}
	$line4NavList = array();
	if (!empty($tcshopConfig['index_line4_nav'])) {
		$index_line4_str = str_replace("\r\n", '{n}', trim($tcshopConfig['index_line4_nav']));
		$index_line4_str = str_replace("\n", '{n}', $index_line4_str);
		$index_line4_str = str_replace('{site}', $site_id, $index_line4_str);
		$index_line4_arr = explode('{n}', $index_line4_str);
		if (is_array($index_line4_arr) && !empty($index_line4_arr)) {
			foreach ($index_line4_arr as $key => $value) {
				$line4NavList[] = explode('|', $value);
			}
		}
	}
	$line4NavCount = count($line4NavList);
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=index&tab=' . $tab));
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tcshop/images/index.js';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:index');
	echo '<script src="source/plugin/tom_tcshop/images/index.js"></script>';
} elseif ($_GET['mod'] == 'details') {
	if (isset($_GET['dpid'])) {
		$tcshop_id = intval($_GET['dpid']) > 0 ? intval($_GET['dpid']) : 0;
	} else {
		$tcshop_id = intval($_GET['tcshop_id']) > 0 ? intval($_GET['tcshop_id']) : 0;
	}
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
	if ($tcshopInfo['status'] != 1 || $tcshopInfo['shenhe_status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$vipInfo = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($tcshopInfo['vip_id']);
	$cateInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($tcshopInfo['cate_id']);
	$photoListTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(' AND tcshop_id=' . $tcshop_id . ' AND type_id = 1 ', 'ORDER BY paixu ASC,id ASC', 0, 500);
	$photoCount = count($photoListTmp);
	$photoList = $photoSmallList = $focuspicList = array();
	$videoPicurl = $firstPicurl = '';
	$i = 1;
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			if ($tongchengConfig['open_yun'] == 2 && !empty($value['oss_picurl']) && $value['oss_status'] == 1) {
				$picurlTmp = $value['oss_picurl'];
			} else {
				if ($tongchengConfig['open_yun'] == 3 && !empty($value['qiniu_picurl']) && $value['qiniu_status'] == 1) {
					$picurlTmp = $value['qiniu_picurl'];
				} else {
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
				}
			}
			$photoList[$key] = $value;
			$photoList[$key]['picurl'] = $picurlTmp;
			if ($i <= 3) {
				$photoSmallList[$key]['picurl'] = $picurlTmp;
				$focuspicList[$key]['picurl'] = $picurlTmp;
			}
			if ($i == 1) {
				$videoPicurl = $picurlTmp;
				$firstPicurl = $picurlTmp;
			}
			$i++;
		}
	}
	if (!empty($tcshopInfo['video_pic'])) {
		if (!preg_match('/^http/', $tcshopInfo['video_pic'])) {
			if (strpos($tcshopInfo['video_pic'], 'source/plugin/tom_') === false) {
				$videoPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['video_pic'];
			} else {
				$videoPicurl = $tcshopInfo['video_pic'];
			}
		} else {
			$videoPicurl = $tcshopInfo['video_pic'];
		}
	}
	if (!preg_match('/^http/', $vipInfo['picurl'])) {
		if (strpos($vipInfo['picurl'], 'source/plugin/tom_') === false) {
			$vipPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $vipInfo['picurl'];
		} else {
			$vipPicurl = $vipInfo['picurl'];
		}
	} else {
		$vipPicurl = $vipInfo['picurl'];
	}
	$focuspicListTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(' AND tcshop_id=' . $tcshop_id . ' AND type_id = 2 ', 'ORDER BY paixu ASC,id ASC', 0, 20);
	if (is_array($focuspicListTmp) && !empty($focuspicListTmp)) {
		$photoThumbList = array();
		$focuspicList = array();
		$i = 1;
		foreach ($focuspicListTmp as $key => $value) {
			if ($tongchengConfig['open_yun'] == 2 && !empty($value['oss_picurl']) && $value['oss_status'] == 1) {
				$picurlTmp = $value['oss_picurl'];
			} else {
				if ($tongchengConfig['open_yun'] == 3 && !empty($value['qiniu_picurl']) && $value['qiniu_status'] == 1) {
					$picurlTmp = $value['qiniu_picurl'];
				} else {
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
				}
			}
			$focuspicList[$key]['picurl'] = $picurlTmp;
			if ($i == 1) {
				$firstPicurl = $picurlTmp;
			}
			$i++;
		}
	}
	$content = stripslashes($tcshopInfo['content']);
	$contentTmp = strip_tags($content);
	$contentTmp = str_replace("\r\n", '', $contentTmp);
	$contentTmp = str_replace("\n", '', $contentTmp);
	$contentTmp = str_replace("\r", '', $contentTmp);
	if ($tcshopInfo['admin_edit'] == 0) {
		$content = str_replace("\r\n", '<br/>', $content);
		$content = str_replace("\n", '<br/>', $content);
		$content = str_replace("\r", '<br/>', $content);
	}
	$tabsStr = str_replace('    ', ' ', $tcshopInfo['tabs']);
	$tabsStr = str_replace('   ', ' ', $tabsStr);
	$tabsStr = str_replace('  ', ' ', $tabsStr);
	$tabsArrTmp = explode(' ', $tabsStr);
	$tabsArr = array();
	$i = 0;
	if (is_array($tabsArrTmp) && !empty($tabsArrTmp)) {
		foreach ($tabsArrTmp as $kk => $vv) {
			$vv = trim($vv);
			if (!empty($vv)) {
				$tabsArr[$kk]['i'] = $i;
				$tabsArr[$kk]['txt'] = cutstr($vv, 20, '');
				$tabsArr[$kk]['url'] = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=list&tabs=') . urlencode(trim($vv));
				$i++;
			}
		}
	}
	if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
		if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
		} else {
			$picurl = $_G['siteurl'] . $tcshopInfo['picurl'];
		}
	} else {
		$picurl = $tcshopInfo['picurl'];
	}
	if (!preg_match('/^http/', $tcshopInfo['kefu_qrcode'])) {
		if (strpos($tcshopInfo['kefu_qrcode'], 'source/plugin/tom_') === false) {
			$kefu_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['kefu_qrcode'];
		} else {
			$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
		}
	} else {
		$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
	}
	$video_flag = $vr_flag = 0;
	$video_type = '';
	$video_id = '';
	if (strpos($tcshopInfo['video_url'], 'youku.com') !== false) {
		preg_match('#sid/(.*)/v.swf#', $tcshopInfo['video_url'], $matches);
		if (is_array($matches) && !empty($matches['1'])) {
			$video_type = 'youku';
			$video_id = trim($matches['1']);
			$video_flag = 1;
		} else {
			if (strpos($tcshopInfo['video_url'], 'embed') !== false) {
				$video_type = 'youku';
				$video_id = ltrim($tcshopInfo['video_url'], 'https://player.youku.com/embed/');
				$video_flag = 1;
			}
		}
	} elseif (strpos($tcshopInfo['video_url'], '.qq.com') !== false) {
		preg_match('#vid=([0-9a-zA-Z]*)#', $tcshopInfo['video_url'], $matches);
		if (is_array($matches) && !empty($matches['1'])) {
			$video_type = 'qq';
			$video_id = trim($matches['1']);
			$video_flag = 1;
		}
	} elseif (strpos($tcshopInfo['video_url'], '.mp4') !== false) {
		$video_type = 'mp4';
		$video_flag = 1;
	} elseif (strpos($tcshopInfo['video_url'], '.MOV') !== false) {
		$video_type = 'mp4';
		$video_flag = 1;
	} elseif (!empty($tcshopInfo['video_url'])) {
		if (empty($tcshopInfo['vr_url'])) {
			$tcshopInfo['vr_url'] = $tcshopInfo['video_url'];
		}
		$tcshopInfo['video_url'] = '';
	}
	if (!empty($tcshopInfo['vr_url'])) {
		$vr_flag = 1;
	}
	if ($__IsMiniprogram == 1) {
		if ($tcshopConfig['open_xiao_video'] == 0) {
			$video_flag = 0;
		}
		if ($tcshopConfig['open_xiao_vr'] == 0 && $__Ios == 1) {
			$vr_flag = 0;
		}
		if ($tcshopConfig['open_xiao_az_vr'] == 0 && $__Android == 1) {
			$vr_flag = 0;
		}
	}
	$vrShowBox = $videoShowBox = 0;
	if ($vipInfo['open_vr'] == 1 && $vr_flag == 1) {
		$vrShowBox = 1;
		if ($tcshopConfig['always_focuspic'] == 1) {
			$vrShowBox = 2;
		}
	}
	if ($vipInfo['open_video'] == 1 && $video_flag == 1) {
		$videoShowBox = 1;
		if ($tcshopConfig['always_focuspic'] == 1) {
			$videoShowBox = 2;
		}
		if ($vrShowBox == 1) {
			$videoShowBox = 2;
		}
	}
	$focuspicShowBox = 1;
	if ($tcshopConfig['always_focuspic'] == 0) {
		if ($vrShowBox == 1 || $videoShowBox == 1) {
			$focuspicShowBox = 0;
		}
	}
	$open_edit_pinglun = 0;
	if ($tcshopInfo['user_id'] == $__UserInfo['id'] && $tongchengConfig['open_fbr_remove_pinglun'] == 1) {
		$open_edit_pinglun = 1;
	} else {
		if ($__UserInfo['groupid'] == 1 && $site_id == 1) {
			$open_edit_pinglun = 1;
		} else {
			if ($__UserInfo['groupid'] == 2 && $site_id == $__UserInfo['groupsiteid']) {
				$open_edit_pinglun = 1;
			}
		}
	}
	$pinglunCount = C::t('#tom_tcshop#tom_tcshop_pinglun')->fetch_all_count(' AND tcshop_id = ' . $tcshopInfo['id'] . ' ');
	$wxUploadUrl = 'plugin.php?id=tom_tcshop:wxMediaDowmload&site=' . $site_id . '&act=photo&formhash=' . FORMHASH;
	$pinglunPloadUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=upload&act=pinglun_picurl&formhash=' . FORMHASH;
	$addTcshopPinglunUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=pinglun&formhash=' . FORMHASH;
	$checkTcshopPinglunUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=check_pinglun&formhash=' . FORMHASH;
	$addPinglunUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=pinglun&formhash=' . FORMHASH;
	$showPinglunUrl = 'plugin.php?id=tom_tcshop:ajax&act=loadPinglun&tcshop_id=' . $tcshopInfo['id'] . '&formhash=' . FORMHASH;
	$removePinglunUrl = 'plugin.php?id=tom_tcshop:ajax&act=removePinglun&tcshop_id=' . $tcshopInfo['id'] . '&formhash=' . FORMHASH;
	$removeReplyUrl = 'plugin.php?id=tom_tcshop:ajax&act=removeReplyPinglun&tcshop_id=' . $tcshopInfo['id'] . '&formhash=' . FORMHASH;
	$must_phone_projectArr = unserialize($tongchengConfig['must_phone_project']);
	$showMustPhoneBtn = 0;
	if (array_search('2', $must_phone_projectArr) !== false && empty($__UserInfo['tel']) && $__UserInfo['editor'] == 0 && $__UserInfo['is_majia'] == 0) {
		$showMustPhoneBtn = 1;
		$phone_back_url = $weixinClass->get_url();
		$phone_back_url = urlencode($phone_back_url);
		$phoneUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=phone&phone_back=' . $phone_back_url;
	}
	$latitude = getcookie('tom_tongcheng_user_latitude');
	$longitude = getcookie('tom_tongcheng_user_longitude');
	$ajaxDistanceUrl = '';
	if (!empty($latitude) && !empty($longitude)) {
		$ajaxDistanceUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=get_distance&longitude1=' . $longitude . '&latitude1=' . $latitude . '&longitude2=' . $tcshopInfo['longitude'] . '&latitude2=' . $tcshopInfo['latitude'] . '&formhash=' . $formhash;
	}
	$isGuanzu = 0;
	if ($__UserInfo['id'] > 0) {
		$guanzuListTmp = C::t('#tom_tcshop#tom_tcshop_guanzu')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' AND tcshop_id=' . $tcshop_id . ' ', ' ORDER BY id DESC ', 0, 1);
		if (is_array($guanzuListTmp) && !empty($guanzuListTmp)) {
			$isGuanzu = 1;
		} else {
			if ($_GET['guanzu'] == 1) {
				$insertData = array();
				$insertData['user_id'] = $__UserInfo['id'];
				$insertData['tcshop_id'] = $tcshop_id;
				$insertData['add_time'] = TIMESTAMP;
				if (C::t('#tom_tcshop#tom_tcshop_guanzu')->insert($insertData)) {
					$isGuanzu = 1;
					$tcshopInfo['guanzu'] = $tcshopInfo['guanzu'] + 1;
					DB::query('UPDATE ' . DB::table('tom_tcshop') . ' SET guanzu=guanzu+1 WHERE id=\'' . $tcshop_id . '\' ', 'UNBUFFERED');
				}
			}
		}
	}
	if ($__ShowTcyikatong == 1) {
		if (CHARSET == 'gbk') {
			include DISCUZ_ROOT . './source/plugin/tom_tcyikatong/config/config.gbk.php';
		} else {
			include DISCUZ_ROOT . './source/plugin/tom_tcyikatong/config/config.utf8.php';
		}
		$tequanListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND tcshop_id=' . $tcshop_id . ' ', ' ORDER BY id DESC ', 0, 10);
		$tequanList = array();
		if (is_array($tequanListTmp) && !empty($tequanListTmp)) {
			foreach ($tequanListTmp as $key => $value) {
				$weeksArrTmp = $daysArrTmp = array();
				$weeksStrTmp = $daysStrTmp = '';
				if ($value['type'] == 1) {
					$weeksArrTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->fetch_all_list(' AND tequan_id = ' . $value['id'] . ' ', ' ORDER BY week ASC,id DESC ', 0, 10);
					$weeksArrTmpCount = count($weeksArrTmp);
					foreach ($weeksArrTmp as $kw => $vw) {
						if ($weeksArrTmpCount == 1) {
							$weeksStrTmp .= '' . $weeksDateArray[$vw['week']];
						} else {
							$weeksStrTmp .= '' . $weeksDateArray[$vw['week']] . lang('plugin/tom_tcshop', 'details_text_denghao');
						}
					}
					if ($weeksArrTmpCount != 1) {
						$weeksStrTmp = rtrim($weeksStrTmp, lang('plugin/tom_tcshop', 'details_text_denghao'));
					}
				} elseif ($value['type'] == 2) {
					$daysArrTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->fetch_all_list(' AND tequan_id = ' . $value['id'] . ' ', ' ORDER BY day ASC,id DESC ', 0, 10);
					foreach ($daysArrTmp as $kd => $vd) {
						$daysStrTmp .= '' . $vd['day'] . lang('plugin/tom_tcyikatong', 'ajax_list_day') . lang('plugin/tom_tcshop', 'details_text_denghao');
					}
					$daysStrTmp = rtrim($daysStrTmp, lang('plugin/tom_tcshop', 'details_text_denghao'));
				}
				$lingCount = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_ling')->fetch_all_count(' AND tequan_id = ' . $value['id'] . ' ');
				$tequanList[$key] = $value;
				$tequanList[$key]['weeksArr'] = $weeksArr;
				$tequanList[$key]['daysArr'] = $daysArr;
				$tequanList[$key]['weeksStr'] = $weeksStrTmp;
				$tequanList[$key]['daysStr'] = $daysStrTmp;
				$tequanList[$key]['lingCount'] = $lingCount;
			}
		}
	}
	if ($__ShowTcqianggou == 1) {
		$couponListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND tcshop_id=' . $tcshop_id . ' AND type_id IN(2,3,4)', ' ORDER BY paixu ASC,id DESC ', 0, 10);
		$couponList = array();
		if (is_array($couponListTmp) && !empty($couponListTmp)) {
			foreach ($couponListTmp as $key => $value) {
				$couponList[$key] = $value;
				if (!preg_match('/^http/', $value['picurl'])) {
					if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
						$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
					} else {
						$picurlTmp = $value['picurl'];
					}
				} else {
					$picurlTmp = $value['picurl'];
				}
				$couponList[$key]['picurl'] = $picurlTmp;
			}
		}
		$qgGoodsList = array();
		$qgGoodsCount = 0;
		if ($tcshopConfig['details_qg_num'] > 0) {
			$qgGoodsListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND tcshop_id=' . $tcshop_id . ' AND type_id=1', ' ORDER BY paixu ASC,id DESC ', 0, $tcshopConfig['details_qg_num']);
			$qgGoodsCount = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_count(' AND status=1 AND shenhe_status=1 AND tcshop_id=' . $tcshop_id . ' AND type_id=1');
			if (is_array($qgGoodsListTmp) && !empty($qgGoodsListTmp)) {
				foreach ($qgGoodsListTmp as $key => $value) {
					if ($value['open_xubuy'] == 1) {
						$qiangListCountTmp = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(' AND goods_id=' . $value['id'] . ' AND type_id=2 ');
						$value['sale_num'] = $value['sale_num'] + $qiangListCountTmp;
					}
					$qgGoodsList[$key] = $value;
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					if (floatval($value['show_buy_price']) <= 0) {
						$qgGoodsList[$key]['show_buy_price'] = $value['buy_price'];
						$qgGoodsList[$key]['show_vip_price'] = $value['vip_price'];
						$qgGoodsList[$key]['show_market_price'] = $value['market_price'];
						$qgGoodsList[$key]['show_before_price'] = $value['before_price'];
					}
					$qgGoodsList[$key]['picurl'] = $picurlTmp;
				}
			}
		}
	}
	if ($__ShowTcptuan == 1) {
		$ptGoodsList = array();
		$ptGoodsCount = 0;
		if ($tcshopConfig['details_pt_num'] > 0) {
			$ptGoodsListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND tcshop_id=' . $tcshop_id, ' ORDER BY paixu ASC,id DESC ', 0, $tcshopConfig['details_pt_num']);
			$ptGoodsCount = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_count(' AND status=1 AND shenhe_status=1 AND tcshop_id=' . $tcshop_id);
			if (is_array($ptGoodsListTmp) && !empty($ptGoodsListTmp)) {
				foreach ($ptGoodsListTmp as $key => $value) {
					$ptGoodsList[$key] = $value;
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					$ptGoodsList[$key]['picurl'] = $picurlTmp;
					$ptGoodsList[$key]['sale_num'] = $value['sale_num'] + $value['virtual_sale_num'];
					if ($value['show_tuan_price'] <= 0) {
						$ptGoodsList[$key]['show_tuan_price'] = $value['tuan_price'];
					}
				}
			}
		}
	}
	if ($__ShowTckjia == 1) {
		$kjGoodsList = array();
		$kjGoodsCount = 0;
		if ($tcshopConfig['details_kj_num'] > 0) {
			$kjGoodsListTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND tcshop_id=' . $tcshop_id, ' ORDER BY paixu ASC,id DESC ', 0, $tcshopConfig['details_kj_num']);
			$kjGoodsCount = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_count(' AND status=1 AND shenhe_status=1 AND tcshop_id=' . $tcshop_id);
			if (is_array($kjGoodsListTmp) && !empty($kjGoodsListTmp)) {
				foreach ($kjGoodsListTmp as $key => $value) {
					$kjGoodsList[$key] = $value;
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					$kjGoodsList[$key]['picurl'] = $picurlTmp;
				}
			}
		}
	}
	if ($__ShowTcchoujiang == 1) {
		$cjGoodsList = array();
		$cjGoodsCount = 0;
		if ($tcshopConfig['details_cj_num'] > 0) {
			$cjGoodsListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_all_list(' AND tcshop_id=' . $tcshop_id . ' AND type = 2 AND status = 1 AND shenhe_status = 1 ', 'ORDER BY chou_status ASC,paixu ASC,id DESC', 0, $tcshopConfig['details_cj_num']);
			$cjGoodsCount = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_all_count(' AND tcshop_id=' . $tcshop_id . ' AND type = 2 AND status = 1 AND shenhe_status = 1 ');
			if (is_array($cjGoodsListTmp) && !empty($cjGoodsListTmp)) {
				foreach ($cjGoodsListTmp as $key => $value) {
					$cjGoodsList[$key] = $value;
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					$cjUserCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_all_count(' AND tcchoujiang_id = ' . $value['id'] . ' ');
					$cjGoodsList[$key]['picurl'] = $picurlTmp;
					$cjGoodsList[$key]['userCount'] = $cjUserCount + $value['virtual_bmnum'];
					$cjGoodsList[$key]['end_time'] = dgmdate($value['end_time'], 'Y.m.d', $tomSysOffset);
				}
			}
		}
	}
	if ($__ShowTchuodong == 1) {
		$hdGoodsList = array();
		$hdGoodsCount = 0;
		if ($tcshopConfig['details_hd_num'] > 0) {
			$hdGoodsListTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_all_like_list(' AND tcshop_id=' . $tcshop_id . ' AND type = 2 AND status = 1 AND shenhe_status = 1 ', 'ORDER BY huodong_status ASC,is_recommend DESC,paixu ASC,id DESC', 0, $tcshopConfig['details_hd_num']);
			$hdGoodsCount = C::t('#tom_tchuodong#tom_tchuodong')->fetch_all_count(' AND tcshop_id=' . $tcshop_id . ' AND type = 2 AND status = 1 AND shenhe_status = 1 ');
			if (is_array($hdGoodsListTmp) && !empty($hdGoodsListTmp)) {
				foreach ($hdGoodsListTmp as $key => $value) {
					$hdGoodsList[$key] = $value;
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					$huodongorderCount = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_sun_bm_num(' AND tchuodong_id = ' . $value['id'] . ' AND order_status IN(2,3)');
					$hdGoodsList[$key]['bmCount'] = $huodongorderCount + $value['virtual_bmnum'];
					$hdGoodsList[$key]['picurl'] = $picurlTmp;
				}
			}
		}
	}
	if ($__ShowTcmall == 1) {
		$mallGoodsList = array();
		if ($tcshopConfig['details_mall_num'] > 0) {
			$mallGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND tcshop_id=' . $tcshop_id, ' ORDER BY gsort DESC,id DESC ', 0, $tcshopConfig['details_mall_num']);
			if (is_array($mallGoodsListTmp) && !empty($mallGoodsListTmp)) {
				foreach ($mallGoodsListTmp as $key => $value) {
					$mallGoodsList[$key] = $value;
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					$mallGoodsList[$key]['picurl'] = $picurlTmp;
				}
			}
		}
	}
	if ($__ShowTcqun == 1) {
		$qunList = array();
		$qunListTmp = C::t('#tom_tcqun#tom_tcqun')->fetch_all_list(' AND user_id = ' . $tcshopInfo['user_id'] . ' AND tcshop_id=' . $tcshop_id . ' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND expire_status = 1 ', ' ORDER BY sort ASC,id DESC ');
		if (is_array($qunListTmp) && !empty($qunListTmp)) {
			foreach ($qunListTmp as $key => $value) {
				$qunList[$key] = $value;
				if (!preg_match('/^http/', $value['logo'])) {
					if (strpos($value['logo'], 'source/plugin/tom_') === false) {
						$logoTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['logo'];
					} else {
						$logoTmp = $value['logo'];
					}
				} else {
					$logoTmp = $value['logo'];
				}
				$qunList[$key]['logo'] = $logoTmp;
			}
		}
		$qunCount = count($qunList);
	}
	$tczhaopinCount = 0;
	if ($__ShowTczhaopin == 1) {
		$rzCompanyInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_list('AND user_id = ' . $tcshopInfo['user_id'] . ' AND shenhe_status = 1 ', 'ORDER BY id DESC', 0, 1);
		if (is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])) {
			$tczhaopinCount = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count(' AND user_id = ' . $tcshopInfo['user_id'] . ' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ');
			$ajaxZhaopinListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=zhaopinlist&user_id=' . $tcshopInfo['user_id'] . '&formhash=' . $formhash;
		}
	}
	$tcfangchanCount = 0;
	if ($__ShowTcfangchan == 1) {
		$mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_user_id($tcshopInfo['user_id']);
		if (is_array($mendianInfo) && !empty($mendianInfo) && $mendianInfo['shenhe_status'] == 1) {
			$tcfangchanCount = $mendianInfo['house_num'];
			$ajaxFangchanListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=list&mendian_id=' . $mendianInfo['id'] . '&formhash=' . $formhash;
		}
	}
	if ($__ShowTctoutiao == 1) {
		$zuozheInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(' AND user_id = ' . $tcshopInfo['user_id'] . ' AND tcshop_id = ' . $tcshopInfo['id'] . ' AND type = 3 ', 'ORDER BY id DESC', 0, 1);
		$zuozheInfo = array();
		if (is_array($zuozheInfoTmp) && !empty($zuozheInfoTmp)) {
			$zuozheInfo = $zuozheInfoTmp[0];
		}
		$toutiaoWhere = 'AND status=1 AND shenhe_status=1 AND search_tcshop_ids LIKE \'%-' . $tcshopInfo['id'] . '-%\'';
		$tctoutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list($toutiaoWhere, ' ORDER BY is_recom DESC,paixu ASC,add_time DESC,id DESC', 0, 6);
		$tctoutiaoList = array();
		foreach ($tctoutiaoListTmp as $key => $value) {
			$photoListTmp = array();
			if ($value['type'] == 1) {
				$photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(' AND tctoutiao_id = ' . $value['id'] . ' AND type = 1 ', 'ORDER BY psort ASC,id DESC', 0, 1);
			} elseif ($value['type'] == 2) {
				if ($value['tuji_listpic_type'] == 1) {
					$photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(' AND tctoutiao_id = ' . $value['id'] . ' AND type = 2 ', 'ORDER BY psort ASC,id DESC', 0, 1);
				} else {
					$photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(' AND tctoutiao_id = ' . $value['id'] . ' AND type = 1 ', 'ORDER BY psort ASC,id DESC', 0, 1);
				}
			} elseif ($value['type'] == 3) {
				$photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(' AND tctoutiao_id = ' . $value['id'] . ' AND type = 3 ', 'ORDER BY psort ASC, id ASC', 0, 1);
			}
			$picurlTmp = '';
			if (is_array($photoListTmp) && !empty($photoListTmp)) {
				$picurlTmp = $photoListTmp[0]['picurlTmp'];
				$zuozheInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($value['zuozhe_id']);
				if (!preg_match('/^http/', $zuozheInfoTmp['picurl'])) {
					if (strpos($zuozheInfoTmp['picurl'], 'source/plugin/tom_') === false) {
						$zuozhePicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $zuozheInfoTmp['picurl'];
					} else {
						$zuozhePicurl = $zuozheInfoTmp['picurl'];
					}
				} else {
					$zuozhePicurl = $zuozheInfoTmp['picurl'];
				}
				$zuozheInfoTmp['picurl'] = $zuozhePicurl;
				$tctoutiaoList[$key] = $value;
				$tctoutiaoList[$key]['clicks'] = $value['clicks'] + $value['virtual_clicks'];
				$tctoutiaoList[$key]['picurl'] = $picurlTmp;
				$tctoutiaoList[$key]['zuozheInfo'] = $zuozheInfoTmp;
			}
		}
	}
	$openLocaltionDistance = 0;
	$shareHbPrefix = '';
	if ($__ShowTchongbao == 1) {
		$lqHongbaoStatus = 0;
		$tchongbaoInfo = array();
		$tchongbaoLogCount = 0;
		$tchongbaoLogList = array();
		$sendHongbaoUserInfo = array();
		$tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(' AND tcshop_id = ' . $tcshop_id . ' AND pay_status = 2 AND only_show = 1 ', 'ORDER BY add_time DESC,id DESC', 0, 1);
		if (is_array($tchongbaoInfoTmp) && !empty($tchongbaoInfoTmp[0])) {
			$tchongbaoInfo = $tchongbaoInfoTmp[0];
			$sendHongbaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tchongbaoInfo['user_id']);
			$tchongbaoLogCount = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_count(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ');
			$tchongbaoLogListTmp = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_list(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' ', 'ORDER BY log_time DESC,id DESC', 0, 5);
			$lastLogInfo = array();
			if (is_array($tchongbaoLogListTmp) && !empty($tchongbaoLogListTmp[0])) {
				$lastLogInfo = $tchongbaoLogListTmp[0];
				foreach ($tchongbaoLogListTmp as $key => $value) {
					$tchongbaoLogList[$key] = $value;
				}
			}
			if ($tchongbaoInfo['status'] == 1) {
				$shareHbPrefix = $tchongbaoConfig['hongbao_tcshop_prefix'];
			} else {
				$lastLogTime = $lastLogInfo['log_time'] + 86400;
			}
			if ($tchongbaoLogCount >= $tchongbaoInfo['hb_count'] || $tchongbaoInfo['money'] <= 0) {
				$updateData = array();
				$updateData['status'] = 2;
				C::t('#tom_tchongbao#tom_tchongbao')->update($tchongbaoInfo['id'], $updateData);
				$tchongbaoInfo['status'] = 2;
			}
			if ($__UserInfo && !empty($__UserInfo['id'])) {
				$hongbaoLogInfo = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_list(' AND hongbao_id = ' . $tchongbaoInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
				if (is_array($hongbaoLogInfo) && !empty($hongbaoLogInfo[0])) {
					$lqHongbaoStatus = 1;
				}
			}
			if ($__UserInfo['hongbao_tz'] == 0 && $__UserInfo['hongbao_tz_first'] != 1) {
				$updateData = array();
				$updateData['hongbao_tz'] = 1;
				$updateData['hongbao_tz_first'] = 1;
				C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'], $updateData);
			}
			if ($tchongbaoConfig['open_hb_position'] == 1) {
				if (strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') !== false) {
					if (!empty($tchongbaoConfig['baidu_js_ak'])) {
						$openLocaltionDistance = 1;
					} else {
						$openLocaltionDistance = 3;
					}
				} else {
					$openLocaltionDistance = 2;
				}
				$hongbaoLocationInfo = C::t('#tom_tchongbao#tom_tchongbao_location')->fetch_by_user_id($__UserInfo['id']);
				$hongbaoLocationStatus = 0;
				if (is_array($hongbaoLocationInfo) && !empty($hongbaoLocationInfo)) {
					$overTime = $tchongbaoConfig['hongbao_update_location_num'] * 86400 + $hongbaoLocationInfo['last_time'];
					if ($overTime > TIMESTAMP) {
						if ($hongbaoLocationInfo['location_status'] == 1) {
							$hongbaoLocationStatus = 1;
						} else {
							$hongbaoLocationStatus = 2;
						}
					}
				}
			}
			$show_hongbao_button = 1;
			if (!$__UserInfo) {
				$show_hongbao_button = 0;
			} else {
				if ($__IsWeixin != 1 && $tchongbaoConfig['hb_lq_type'] != 1) {
					$show_hongbao_button = 0;
				}
			}
		}
		$ajaxHongbaoUrl = 'plugin.php?id=tom_tchongbao:ajax&formhash=' . FORMHASH;
		$ajaxDistanceHongbaoUrl = 'plugin.php?id=tom_tchongbao:ajax&act=distance&site=' . $site_id . '&formhash=' . FORMHASH;
		$myMoneyUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=money';
		$hongbaoLogListUrl = 'plugin.php?id=tom_tchongbao&mod=loglist&site=' . $site_id . '&hongbao_id=' . $tchongbaoInfo['id'];
		$tcshopIndexUrl = 'plugin.php?id=tom_tcshop&mod=index&site=' . $site_id;
	}
	$baiduMapFromName = lang('plugin/tom_tcshop', 'wodeweizhi');
	$baiduMapFromName = urlencode($baiduMapFromName);
	$baiduMapToName = $tcshopInfo['name'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapRegion = lang('plugin/tom_tcshop', 'china');
	$baiduMapRegion = urlencode($baiduMapRegion);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tcshopInfo['latitude'] . ',' . $tcshopInfo['longitude'] . '&title=' . $baiduMapToName . '&content=&output=html';
	$ajaxDetailsLoadListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=list&no_tcshop_id=' . $tcshopInfo['id'] . '&cate_id=' . $tcshopInfo['cate_id'] . '&ordertype=lbs&formhash=' . $formhash;
	$fabuFlUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=fabu&model_id=';
	$ajaxLoadFlListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&user_id=' . $tcshopInfo['user_id'] . '&act=list&formhash=' . $formhash;
	$ajaxCollectFlUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=collect&formhash=' . $formhash;
	$ajaxCollectUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=collect&&formhash=' . $formhash;
	$ajaxClicksFlUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=clicks&formhash=' . $formhash . '&tongcheng_id=';
	$ajaxGuanzuUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=guanzu&formhash=' . $formhash;
	$ajaxZhuanfaUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=zhuanfa&tcshop_id=' . $tcshop_id . '&formhash=' . FORMHASH;
	$ajaxClicksUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=clicks&tcshop_id=' . $tcshop_id . '&formhash=' . FORMHASH;
	$shareTitle = str_replace('{TITLE}', $tcshopInfo['name'], $tcshopConfig['details_share_title']);
	$shareTitle = $shareHbPrefix . str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	$shareLogo = $picurl;
	$shareDesc = cutstr($contentTmp, 80, '...');
	$shareDesc = str_replace('&nbsp;', '', $shareDesc);
	$shareDesc = str_replace('&quot;', '', $shareDesc);
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&tcshop_id=' . $tcshop_id . '&s=1');
	$guanzuShareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&tcshop_id=') . $tcshop_id . '&guanzu=1';
	$haibaoQrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($shareUrl);
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tcshopConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$__TongchengHost = '';
	if ($__ShowTchongbao == 1) {
		$tchongbaoConfig['tongcheng_hosts'] = trim($tchongbaoConfig['tongcheng_hosts']);
		$tchongbaoConfig['hongbao_hosts'] = trim($tchongbaoConfig['hongbao_hosts']);
		if ($tchongbaoConfig['open_only_hosts'] == 1 && !empty($tchongbaoConfig['tongcheng_hosts']) && !empty($tchongbaoConfig['hongbao_hosts'])) {
			if (strpos($_G['siteurl'], $tchongbaoConfig['tongcheng_hosts']) === false && strpos($_G['siteurl'], $tchongbaoConfig['hongbao_hosts']) !== false) {
				$__TongchengHost = str_replace($tchongbaoConfig['hongbao_hosts'], $tchongbaoConfig['tongcheng_hosts'], $_G['siteurl']);
				if ($tchongbaoConfig['must_http'] == 1) {
					if (strpos($__TongchengHost, 'https') === false) {
						$__TongchengHost = str_replace('http', 'https', $__TongchengHost);
					}
				}
			}
		}
	}
	$payTelUrl = 'plugin.php?id=tom_tcshop:pay&site=' . $site_id . '&act=tel&formhash=' . $formhash;
	$showBuyTelBtn = 0;
	if ($cateInfo['open_tel_price'] == 1) {
		if ($__UserInfo['id'] > 0) {
			$orderListTmp = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_list(' AND tcshop_id=' . $tcshop_id . ' AND user_id=' . $__UserInfo['id'] . ' AND order_type=9 AND order_status=2 ', 'ORDER BY id DESC', 0, 1);
			if (!is_array($orderListTmp) || empty($orderListTmp) || $orderListTmp[0]['id'] <= 0) {
				if ($__UserInfo['editor'] != 1) {
					$showBuyTelBtn = 1;
					$tcshopInfo['tel'] = substr($tcshopInfo['tel'], 0, 3) . '*******';
				}
			}
		} else {
			$showBuyTelBtn = 2;
			$tcshopInfo['tel'] = substr($tcshopInfo['tel'], 0, 3) . '*******';
		}
	}
	$showXiaoQrcode = 0;
	if ($vipInfo['open_xiao_qrcode'] == 1) {
		$showXiaoQrcode = 1;
	}
	$showXiaoQrcodeUrl = 'plugin.php?id=tom_tcshop:xiaoQrcode&site=' . $site_id . '&tcshop_id=' . $tcshop_id . '&formhash=' . FORMHASH;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	if ($__ShowTcsign == 1) {
		include DISCUZ_ROOT . './source/plugin/tom_tcsign/renwu/shop.php';
	}
	$companyRenzhengStatus = $personalRenzhengStatus = $depositStatus = 0;
	if ($__ShowTcrenzheng == 1) {
		$companyInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_user_id($tcshopInfo['user_id']);
		if (is_array($companyInfoTmp) && $companyInfoTmp['shenhe_status'] == 1) {
			$companyRenzhengStatus = 1;
		} else {
			$personalInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_user_id($tcshopInfo['user_id']);
			if (is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1) {
				$personalRenzhengStatus = 1;
			}
		}
		$depositInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->fetch_by_user_id($tcshopInfo['user_id']);
		if (is_array($depositInfoTmp) && $depositInfoTmp['order_status'] == 2) {
			$depositStatus = 1;
		}
	}
	$showEndVipTimeBox = 0;
	if ($tcshopInfo['vip_status'] == 1 && $tcshopInfo['vip_time'] <= TIMESTAMP) {
		$showEndVipTimeBox = 1;
		$updateData = array();
		$updateData['vip_status'] = 2;
		if ($tcshopConfig['tcshop_vip_end_status'] == 1) {
			$updateData['status'] = 2;
		}
		C::t('#tom_tcshop#tom_tcshop')->update($tcshopInfo['id'], $updateData);
	} else {
		if ($tcshopInfo['vip_status'] == 2) {
			$showEndVipTimeBox = 1;
		}
	}
	$back_url = $weixinClass->get_url();
	$back_url = urlencode($back_url);
	if ($__ShowTcyuyue == 1 && $tcshopInfo['open_yuyue'] == 1) {
		$tcyuyueUrl = 'plugin.php?id=tom_tcyuyue&site=' . $site_id . '&mod=info&goods_id=' . $tcshopInfo['id'] . '&yuyue_type=shop&back_url=' . $back_url;
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:details');
} elseif ($_GET['mod'] == 'qglist') {
	$tcshop_id = intval($_GET['tcshop_id']) > 0 ? intval($_GET['tcshop_id']) : 0;
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
	$ajaxQgLoadListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=qglist&tcshop_id=' . $tcshop_id . '&formhash=' . $formhash;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=qglist&tcshop_id=') . $tcshop_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:qglist');
} elseif ($_GET['mod'] == 'ptlist') {
	$tcshop_id = intval($_GET['tcshop_id']) > 0 ? intval($_GET['tcshop_id']) : 0;
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
	$ajaxPtLoadListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=ptlist&tcshop_id=' . $tcshop_id . '&formhash=' . $formhash;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=ptlist&tcshop_id=') . $tcshop_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:ptlist');
} elseif ($_GET['mod'] == 'kjlist') {
	$tcshop_id = intval($_GET['tcshop_id']) > 0 ? intval($_GET['tcshop_id']) : 0;
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
	$ajaxKjLoadListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=kjlist&tcshop_id=' . $tcshop_id . '&formhash=' . $formhash;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=kjlist&tcshop_id=') . $tcshop_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:kjlist');
} elseif ($_GET['mod'] == 'cjlist') {
	$tcshop_id = intval($_GET['tcshop_id']) > 0 ? intval($_GET['tcshop_id']) : 0;
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
	$ajaxCjLoadListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=cjlist&tcshop_id=' . $tcshop_id . '&formhash=' . $formhash;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=cjlist&tcshop_id=') . $tcshop_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:cjlist');
} elseif ($_GET['mod'] == 'hdlist') {
	$tcshop_id = intval($_GET['tcshop_id']) > 0 ? intval($_GET['tcshop_id']) : 0;
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
	$ajaxHdLoadListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=hdlist&tcshop_id=' . $tcshop_id . '&formhash=' . $formhash;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=hdlist&tcshop_id=') . $tcshop_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:hdlist');
} elseif ($_GET['mod'] == 'list') {
	$city_id = intval($_GET['city_id']) > 0 ? intval($_GET['city_id']) : 0;
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$tabs = isset($_GET['tabs']) ? addslashes(urldecode($_GET['tabs'])) : '';
	$ordertype = !empty($_GET['ordertype']) ? addslashes($_GET['ordertype']) : '';
	$areaInfo = array();
	if (!empty($area_id)) {
		$areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
	}
	$streetInfo = array();
	if (!empty($street_id)) {
		$streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
	}
	$cateInfo = array();
	if (!empty($cate_id)) {
		$cateInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($cate_id);
	}
	$cateChildInfo = array();
	if (!empty($cate_child_id)) {
		$cateChildInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($cate_child_id);
	}
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		$areaList = $areaListTmp;
	}
	$cateList = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list(' AND parent_id=0 ', ' ORDER BY csort ASC,id DESC ', 0, 500);
	$ajaxGetStreetUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=list_get_street&&formhash=' . $formhash;
	$ajaxGetCateChildUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=list_get_cate_child&&formhash=' . $formhash;
	if (!empty($cate_id)) {
		$shareTitle = $cateInfo['name'] . '-' . $__SitesInfo['name'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=list&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&tabs=') . urlencode($tabs);
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=list&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&area_id=' . $area_id . '&street_id=' . $street_id . '&keyword=' . $keyword . '&tabs=' . $tabs . '&ordertype=' . $ordertype));
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:list');
} elseif ($_GET['mod'] == 'search') {
	$resouListTmp = C::t('#tom_tcshop#tom_tcshop_resou')->fetch_all_list('', ' ORDER BY paixu ASC,id DESC ', 0, 100);
	$resouList = array();
	if (is_array($resouListTmp) && !empty($resouListTmp)) {
		foreach ($resouListTmp as $key => $value) {
			$resouList[$key] = $value;
			$resouList[$key]['url'] = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=list&keyword=') . urlencode(trim($value['keywords']));
		}
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:search');
} elseif ($_GET['mod'] == 'baidumap') {
	$lat = !empty($_GET['lat']) ? addslashes($_GET['lat']) : '';
	$lng = !empty($_GET['lng']) ? addslashes($_GET['lng']) : '';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:baidumap');
} elseif ($_GET['mod'] == 'mylist') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$tcshop_id = intval($_GET['tcshop_id']) > 0 ? intval($_GET['tcshop_id']) : 0;
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$where = ' AND user_id=' . $__UserInfo['id'] . ' ';
	$order = ' ORDER BY id DESC ';
	if ($tcshop_id > 0) {
		$where .= ' AND id=' . $tcshop_id . ' ';
	}
	if ($type == 1) {
		$where .= ' AND status=1 ';
	}
	if ($type == 2) {
		$where .= ' AND pay_status=1 ';
	}
	if ($type == 4) {
		$where .= ' AND (shenhe_status=2 OR shenhe_status=3) AND (pay_status=0 OR pay_status=2) ';
		$order = ' ORDER BY shenhe_status ASC,id DESC ';
	}
	$count = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count(' ' . $where . ' ');
	$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(' ' . $where . ' ', ' ' . $order . ' ', $start, $pagesize);
	$tcshopList = array();
	if (is_array($tcshopListTmp) && !empty($tcshopListTmp)) {
		foreach ($tcshopListTmp as $key => $value) {
			$tcshopList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$tcshopList[$key]['picurl'] = $picurl;
			$vipInfoTmp = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($value['vip_id']);
			if (!preg_match('/^http/', $vipInfoTmp['picurl'])) {
				if (strpos($vipInfoTmp['picurl'], 'source/plugin/tom_') === false) {
					$vipPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $vipInfoTmp['picurl'];
				} else {
					$vipPicurl = $vipInfoTmp['picurl'];
				}
			} else {
				$vipPicurl = $vipInfoTmp['picurl'];
			}
			$overTime = dgmdate($value['vip_time'], 'Y-m-d', $tomSysOffset);
			$toutiaoStatus = 0;
			if ($__ShowTctoutiao == 1 && $vipInfoTmp['open_tctoutiao'] == 1 && $__UserInfo['id'] != $tongchengConfig['manage_user_id']) {
				$toutiaoStatus = 1;
				$zuozheInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND type = 3 AND tcshop_id = ' . $value['id'] . ' ', 'ORDER BY id DESC', 0, 1);
				if (is_array($zuozheInfoTmp) && !empty($zuozheInfoTmp[0])) {
					$toutiaoStatus = 2;
				}
			}
			$tcshopList[$key]['vipInfo'] = $vipInfoTmp;
			$tcshopList[$key]['vipInfo']['picurl'] = $vipPicurl;
			$tcshopList[$key]['overTime'] = $overTime;
			$tcshopList[$key]['toutiaoStatus'] = $toutiaoStatus;
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=mylist&type=' . $type . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=mylist&type=' . $type . '&page=' . $nextPage;
	$back_url = $weixinClass->get_url();
	$back_url = urlencode($back_url);
	$payUrl = 'plugin.php?id=tom_tcshop:pay&site=' . $site_id . '&act=pay&formhash=' . $formhash;
	$ajaxUpdateStatusUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=updateStatus&&formhash=' . $formhash;
	$ajaxRuzhuToutiaoUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=ruzhuToutiao&&formhash=' . $formhash;
	$ossBatchUrl = 'plugin.php?id=tom_tcshop:ossBatch';
	$qiniuBatchUrl = 'plugin.php?id=tom_tcshop:qiniuBatch';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:mylist');
} elseif ($_GET['mod'] == 'guanzulist') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$where = ' AND user_id=' . $__UserInfo['id'] . ' ';
	$order = ' ORDER BY id DESC ';
	$count = C::t('#tom_tcshop#tom_tcshop_guanzu')->fetch_all_count(' ' . $where . ' ');
	$guanzuListTmp = C::t('#tom_tcshop#tom_tcshop_guanzu')->fetch_all_list(' ' . $where . ' ', ' ' . $order . ' ', $start, $pagesize);
	$guanzuList = array();
	if (is_array($guanzuListTmp) && !empty($guanzuListTmp)) {
		foreach ($guanzuListTmp as $key => $value) {
			$guanzuList[$key] = $value;
			$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
			if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
				if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
				} else {
					$picurl = $tcshopInfo['picurl'];
				}
			} else {
				$picurl = $tcshopInfo['picurl'];
			}
			$guanzuList[$key]['tcshopInfo'] = $tcshopInfo;
			$guanzuList[$key]['tcshopInfo']['picurl'] = $picurl;
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=guanzulist&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=guanzulist&page=' . $nextPage;
	$ajaxUpdateGuanzuUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=guanzu&&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:guanzulist');
} elseif ($_GET['mod'] == 'buy') {
	$act = isset($_GET['act']) ? addslashes($_GET['act']) : 'top';
	$tcshop_id = intval($_GET['tcshop_id']) > 0 ? intval($_GET['tcshop_id']) : 0;
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
	$topList = array();
	if (!empty($tcshopConfig['top_price_list'])) {
		$top_list_str = str_replace("\r\n", '{n}', $tcshopConfig['top_price_list']);
		$top_list_str = str_replace("\n", '{n}', $top_list_str);
		$top_list_arr = explode('{n}', $top_list_str);
		if (is_array($top_list_arr) && !empty($top_list_arr)) {
			foreach ($top_list_arr as $key => $value) {
				$arr = explode('|', $value);
				$topList[$key]['days'] = $arr[0];
				$topList[$key]['price'] = $arr[1];
			}
		}
	}
	$toptime = dgmdate($tcshopInfo['toptime'], 'Y-m-d', $tomSysOffset);
	$day_num = 7;
	$payTopUrl = 'plugin.php?id=tom_tcshop:pay&site=' . $site_id . '&act=top&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:buy');
} elseif ($_GET['mod'] == 'clerk') {
	$tcshop_id = intval($_GET['tcshop_id']) > 0 ? intval($_GET['tcshop_id']) : 0;
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
	if ($__UserInfo['id'] != $tcshopInfo['user_id']) {
		if ($__UserInfo['groupid'] == 1) {
		} elseif ($__UserInfo['groupid'] == 2) {
			if ($tcshopInfo['site_id'] != $__UserInfo['groupsiteid']) {
				dheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=index'));
				exit(0);
			}
		} else {
			dheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=index'));
			exit(0);
		}
	}
	if ($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH) {
		$user_id = intval($_GET['user_id']) > 0 ? intval($_GET['user_id']) : 0;
		$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
		if (!$userInfoTmp) {
			$outArr = array('status' => 404);
			echo json_encode($outArr);
			exit(0);
		}
		$insertData = array();
		$insertData['tcshop_id'] = $tcshop_id;
		$insertData['user_id'] = $user_id;
		$insertData['add_time'] = TIMESTAMP;
		C::t('#tom_tcshop#tom_tcshop_clerk')->insert($insertData);
		$outArr = array('status' => 200);
		echo json_encode($outArr);
		exit(0);
	} elseif ($_GET['act'] == 'del' && $_GET['formhash'] == FORMHASH) {
		$clerk_id = intval($_GET['clerk_id']) > 0 ? intval($_GET['clerk_id']) : 0;
		C::t('#tom_tcshop#tom_tcshop_clerk')->delete_by_id($clerk_id);
		echo 200;
		exit(0);
	}
	$clerkListTmp = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(' AND tcshop_id=' . $tcshopInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 100);
	$clerkList = array();
	if (is_array($clerkListTmp) && !empty($clerkListTmp)) {
		foreach ($clerkListTmp as $key => $value) {
			$clerkList[$key] = $value;
			$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$clerkList[$key]['userInfo'] = $userInfoTmp;
		}
	}
	$saveUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=clerk&act=save&tcshop_id=' . $tcshop_id;
	$delUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=clerk&act=del&tcshop_id=' . $tcshop_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:clerk');
} elseif ($_GET['mod'] == 'photos') {
	$tcshop_id = intval($_GET['tcshop_id']) > 0 ? intval($_GET['tcshop_id']) : 0;
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
	$photoListTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(' AND tcshop_id=' . $tcshop_id . ' AND type_id = 1 ', 'ORDER BY paixu ASC,id ASC', 0, 500);
	$photoList = array();
	$photoAlbum = array();
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			if ($tongchengConfig['open_yun'] == 2 && !empty($value['oss_picurl']) && $value['oss_status'] == 1) {
				$albumTmp = $value['oss_picurl'];
				$picurlTmp = $value['oss_picurl'] . '?x-oss-process=image/resize,m_fill,h_130,w_130';
			} else {
				if ($tongchengConfig['open_yun'] == 3 && !empty($value['qiniu_picurl']) && $value['qiniu_status'] == 1) {
					$albumTmp = $value['qiniu_picurl'];
					$picurlTmp = $value['qiniu_picurl'] . '?imageView2/1/w/130/h/130';
				} else {
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$albumTmp = $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$albumTmp = $picurlTmp = $value['picurl'];
						}
					} else {
						$albumTmp = $picurlTmp = $value['picurl'];
					}
				}
			}
			$photoList[$key] = $picurlTmp;
			$photoAlbum[$key] = $albumTmp;
		}
	}
	$photoListStr = implode('|', $photoAlbum);
	if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
		if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
		} else {
			$picurl = $tcshopInfo['picurl'];
		}
	} else {
		$picurl = $tcshopInfo['picurl'];
	}
	$shareTitle = str_replace('{TITLE}', $tcshopInfo['name'], $tcshopConfig['details_share_title']);
	$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	$shareLogo = $picurl;
	$shareDesc = cutstr($contentTmp, 80, '...');
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=details&tcshop_id=') . $tcshop_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:photos');
} elseif ($_GET['mod'] == 'licence') {
	$tcshop_id = intval($_GET['tcshop_id']) > 0 ? intval($_GET['tcshop_id']) : 0;
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
	$photoListTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(' AND tcshop_id=' . $tcshop_id . ' AND type_id = 3 ', 'ORDER BY paixu ASC,id ASC', 0, 100);
	$photoList = array();
	$photoAlbum = array();
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			if ($tongchengConfig['open_yun'] == 2 && !empty($value['oss_picurl']) && $value['oss_status'] == 1) {
				$albumTmp = $value['oss_picurl'];
				$picurlTmp = $value['oss_picurl'];
			} else {
				if ($tongchengConfig['open_yun'] == 3 && !empty($value['qiniu_picurl']) && $value['qiniu_status'] == 1) {
					$albumTmp = $value['qiniu_picurl'];
					$picurlTmp = $value['qiniu_picurl'];
				} else {
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$albumTmp = $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$albumTmp = $picurlTmp = $value['picurl'];
						}
					} else {
						$albumTmp = $picurlTmp = $value['picurl'];
					}
				}
			}
			$photoList[$key] = $picurlTmp;
			$photoAlbum[$key] = $albumTmp;
		}
	}
	$photoListStr = implode('|', $photoAlbum);
	if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
		if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
		} else {
			$picurl = $tcshopInfo['picurl'];
		}
	} else {
		$picurl = $tcshopInfo['picurl'];
	}
	if (!preg_match('/^http/', $tcshopInfo['business_licence'])) {
		if (strpos($tcshopInfo['business_licence'], 'source/plugin/tom_') === false) {
			$business_licence = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['business_licence'];
		} else {
			$business_licence = $tcshopInfo['business_licence'];
		}
	} else {
		$business_licence = $tcshopInfo['business_licence'];
	}
	if (!empty($tcshopInfo['business_licence']) && !empty($photoListStr)) {
		$photoListStr = $business_licence . '|' . $photoListStr;
	} else {
		if (!empty($tcshopInfo['business_licence'])) {
			$photoListStr = $business_licence;
		}
	}
	$shareTitle = str_replace('{TITLE}', $tcshopInfo['name'], $tcshopConfig['details_share_title']);
	$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	$shareLogo = $picurl;
	$shareDesc = cutstr($contentTmp, 80, '...');
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=licence&tcshop_id=') . $tcshop_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:licence');
} elseif ($_GET['mod'] == 'shop_focuspic') {
	$tcshop_id = intval($_GET['tcshop_id']) > 0 ? intval($_GET['tcshop_id']) : 0;
	$test = intval($_GET['test']) > 0 ? intval($_GET['test']) : 0;
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
	if ($__UserInfo['id'] != $tcshopInfo['user_id']) {
		if ($__UserInfo['groupid'] == 1) {
		} elseif ($__UserInfo['groupid'] == 2) {
			if ($tcshopInfo['site_id'] != $__UserInfo['groupsiteid']) {
				dheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=index'));
				exit(0);
			}
		} else {
			dheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=index'));
			exit(0);
		}
	}
	$tcshopFocuspicCount = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_count(' AND tcshop_id = ' . $tcshop_id . ' AND type_id = 2');
	$tcshopFocuspicInfoTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(' AND tcshop_id = ' . $tcshop_id . ' AND type_id = 2', 'ORDER BY paixu ASC,id ASC', 0, $tcshopFocuspicCount);
	$tcshopFocuspicInfo = array();
	$i = 1;
	if (is_array($tcshopFocuspicInfoTmp) && !empty($tcshopFocuspicInfoTmp)) {
		foreach ($tcshopFocuspicInfoTmp as $key => $value) {
			$tcshopFocuspicInfo[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$tcshopFocuspicInfo[$key]['li_i'] = $i;
			$tcshopFocuspicInfo[$key]['picurl'] = $picurl;
			$i++;
		}
	}
	$saveUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=save_shop_focuspic';
	$uploadUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=upload&act=shop_focuspic&formhash=' . FORMHASH;
	$wxUploadUrl2 = 'plugin.php?id=tom_tcshop:wxMediaDowmload&site=' . $site_id . '&act=photo&formhash=' . FORMHASH;
	$ossBatchUrl = 'plugin.php?id=tom_tcshop:ossBatch';
	$qiniuBatchUrl = 'plugin.php?id=tom_tcshop:qiniuBatch';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:shop_focuspic');
} elseif ($_GET['mod'] == 'store') {
	$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 100);
	if (!is_array($tcshopListTmp) || empty($tcshopListTmp)) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=ruzhu'));
		exit(0);
	}
	$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
	if ($__SitesInfo['id'] > 1) {
		if (!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])) {
			if (strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_') === false) {
				$kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $__SitesInfo['kefu_qrcode'];
			} else {
				$kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
			}
		} else {
			$kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
		}
	}
	$total_money = $__UserInfo['shop_money'] + $__UserInfo['shop_tixian_money'];
	$total_clicks = C::t('#tom_tcshop#tom_tcshop')->fetch_all_sun_clicks(' AND user_id = ' . $__UserInfo['id'] . ' ');
	$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 100, '');
	$tcshopIdsTmp = array();
	if (is_array($tcshopListTmp) && !empty($tcshopListTmp)) {
		foreach ($tcshopListTmp as $key => $value) {
			$tcshopIdsTmp[] = $value['id'];
		}
	}
	$tcshop_ids_str = '999999999';
	if (is_array($tcshopIdsTmp) && !empty($tcshopIdsTmp) && count($tcshopIdsTmp) > 0) {
		$tcshop_ids_str = implode(',', $tcshopIdsTmp);
	}
	$total_handle_orders = $qg_orders_handle_count = $kq_orders_handle_count = $pt_orders_handle_count = $kj_orders_handle_count = $mall_orders_handle_count = $cj_orders_handle_count = 0;
	$total_orders = $qg_orders_count = $pt_orders_count = $kj_orders_count = $mall_orders_count = 0;
	if ($__ShowTcqianggou == 1) {
		$qg_orders_count = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(' AND tcshop_id IN (' . $tcshop_ids_str . ') AND order_status IN(2,3) ');
		$qg_orders_handle_count = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(' AND tcshop_id IN (' . $tcshop_ids_str . ') AND type_id = 1 AND order_status = 2 ');
		$kq_orders_handle_count = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(' AND tcshop_id IN (' . $tcshop_ids_str . ') AND type_id IN(2,3,4) AND order_status = 2 ');
	}
	if ($__ShowTcptuan == 1) {
		$pt_orders_count = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_count(' AND tcshop_id IN (' . $tcshop_ids_str . ') AND order_status IN(2,3,4,5) ');
		$pt_orders_handle_count = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_count(' AND tcshop_id IN (' . $tcshop_ids_str . ') AND order_status IN(2,3,4) AND (tuan_status=3 OR order_type=3) ');
	}
	if ($__ShowTckjia == 1) {
		$kj_orders_count = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(' AND tcshop_id IN (' . $tcshop_ids_str . ') AND order_status IN(2,3) ');
		$kj_orders_handle_count = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(' AND tcshop_id IN (' . $tcshop_ids_str . ') AND order_status = 2 ');
	}
	if ($__ShowTcmall == 1) {
		$mall_orders_count = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(' AND tcshop_id IN (' . $tcshop_ids_str . ') AND order_status IN(2,3,4) ');
		$mall_orders_handle_count = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(' AND tcshop_id IN (' . $tcshop_ids_str . ') AND order_status IN(2,3) ');
	}
	if ($__ShowTcchoujiang == 1) {
		$cj_orders_handle_count = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_count('AND tcshop_id IN(' . $tcshop_ids_str . ') AND order_status = 1');
	}
	$total_handle_orders = $qg_orders_handle_count + $kq_orders_handle_count + $pt_orders_handle_count + $kj_orders_handle_count + $mall_orders_handle_count + $cj_orders_handle_count;
	$total_orders = $qg_orders_count + $pt_orders_count + $kj_orders_count + $mall_orders_count;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:store');
} elseif ($_GET['mod'] == 'money') {
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:money');
} elseif ($_GET['mod'] == 'moneylog') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$type_id = intval($_GET['type_id']) > 0 ? intval($_GET['type_id']) : 0;
	$pagesize = 50;
	$start = ($page - 1) * $pagesize;
	$whereStr = ' AND user_id=' . $__UserInfo['id'] . ' ';
	if ($type_id > 0) {
		$whereStr .= ' AND type_id=' . $type_id . ' ';
	}
	$count = C::t('#tom_tcshop#tom_tcshop_money_log')->fetch_all_count(' ' . $whereStr . ' ');
	$moneylogListTmp = C::t('#tom_tcshop#tom_tcshop_money_log')->fetch_all_list(' ' . $whereStr . ' ', 'ORDER BY id DESC', $start, $pagesize);
	$moneylogList = array();
	if (is_array($moneylogListTmp) && !empty($moneylogListTmp)) {
		foreach ($moneylogListTmp as $key => $value) {
			$moneylogList[$key] = $value;
			$businessUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['business_user_id']);
			$moneylogList[$key]['businessUserInfo'] = $businessUserInfoTmp;
			if ($value['type_id'] == 1) {
				$tixianInfo = C::t('#tom_tcshop#tom_tcshop_money_tixian')->fetch_by_id($value['tixian_id']);
				$moneylogList[$key]['tixianInfo'] = $tixianInfo;
			}
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=moneylog&type_id=' . $type_id . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=moneylog&type_id=' . $type_id . '&page=' . $nextPage;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcshop:moneylog');
} elseif ($_GET['mod'] == 'moneytixian') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/moneytixian.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/edit.php';
} elseif ($_GET['mod'] == 'editContent') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/editContent.php';
} elseif ($_GET['mod'] == 'buyvip') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/buyvip.php';
} elseif ($_GET['mod'] == 'edithexiaotype') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/edithexiaotype.php';
} elseif ($__ShowTcyuyue == 1 && $_GET['mod'] == 'yuyue') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/yuyue.php';
} elseif ($_GET['mod'] == 'ruzhu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/ruzhu.php';
} elseif ($_GET['mod'] == 'mallCate') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/mallCate.php';
} elseif ($_GET['mod'] == 'mallbase') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/mallbase.php';
} elseif ($_GET['mod'] == 'managerList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/managerList.php';
} elseif ($_GET['mod'] == 'express') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/express.php';
} elseif ($_GET['mod'] == 'expressitem') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/expressitem.php';
} elseif ($_GET['mod'] == 'place') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/place.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tcshop/module/upload.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();