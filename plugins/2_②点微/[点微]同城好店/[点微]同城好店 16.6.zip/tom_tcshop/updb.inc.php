<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/plugin');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $sql = '';

    $tom_tcshop_field = C::t('#tom_tcshop#tom_tcshop')->fetch_all_field();
    if (!isset($tom_tcshop_field['ruzhu_level'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `ruzhu_level` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['admin_edit'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `admin_edit` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['city_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `city_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['area_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `area_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['street_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `street_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['tabs'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `tabs` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_field['is_ok'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `is_ok` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['business_licence'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `business_licence` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_field['tj_hehuoren_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `tj_hehuoren_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['link'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `link` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_field['link_name'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `link_name` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_field['base_level'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `base_level` int(11) DEFAULT '1';\n";
    }
    if (!isset($tom_tcshop_field['base_time'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `base_time` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['shopkeeper_tel'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `shopkeeper_tel` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_field['toprand'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `toprand` int(11) DEFAULT '1';\n";
    }
    if (!isset($tom_tcshop_field['refresh_time'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `refresh_time` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['vr_url'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `vr_url` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_field['edmoney'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `edmoney` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcshop_field['dispatch_type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `dispatch_type` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['tc114_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `tc114_status` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['vip_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `vip_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['vip_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `vip_status` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['hexiao_type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `hexiao_type` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['video_pic'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `video_pic` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_field['vip_rank'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `vip_rank` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['peisong_type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `peisong_type` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['open_vip_price_set'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `open_vip_price_set` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['mall_shop_picurl'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `mall_shop_picurl` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_field['huodao_pay'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `huodao_pay` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['open_shop_list_cart'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `open_shop_list_cart` tinyint(4) DEFAULT '1';\n";
    }
    if (!isset($tom_tcshop_field['haibao_msg'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `haibao_msg` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_field['open_yuyue'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `open_yuyue` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_field['tcyuyue_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop` ADD `tcyuyue_id` int(11) DEFAULT '0';\n";
    }
    
    $tom_tcshop_cate_field = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_field();
    if (!isset($tom_tcshop_cate_field['youhui_model_name'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_cate` ADD `youhui_model_name` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_cate_field['youhui_model_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_cate` ADD `youhui_model_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_cate_field['youhui_model_ids'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_cate` ADD `youhui_model_ids` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_cate_field['open_tel_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_cate` ADD `open_tel_price` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_cate_field['open_upload_proof'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_cate` ADD `open_upload_proof` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_cate_field['upload_proof_text'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_cate` ADD `upload_proof_text` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_cate_field['tc114_cate_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_cate` ADD `tc114_cate_id` int(11) DEFAULT '0';\n";
    }
    
    $tom_tcshop_photo_field = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_field();
    if (!isset($tom_tcshop_photo_field['oss_picurl'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_photo` ADD `oss_picurl` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_photo_field['oss_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_photo` ADD `oss_status` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_photo_field['qiniu_picurl'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_photo` ADD `qiniu_picurl` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcshop_photo_field['qiniu_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_photo` ADD `qiniu_status` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_photo_field['type_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_photo` ADD `type_id` int(11) DEFAULT '1';\n";
    }
    if (!isset($tom_tcshop_photo_field['paixu'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_photo` ADD `paixu` int(11) DEFAULT '999';\n";
    }
    
    $tom_tcshop_common_field = C::t('#tom_tcshop#tom_tcshop_common')->fetch_all_field();
    if (!isset($tom_tcshop_common_field['new_vip_txt'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_common` ADD `new_vip_txt` text;\n";
    }
    
    $tom_tcshop_focuspic_field = C::t('#tom_tcshop#tom_tcshop_focuspic')->fetch_all_field();
    if (!isset($tom_tcshop_focuspic_field['type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_focuspic` ADD `type` tinyint(4) DEFAULT '1';\n";
    }

    if (!empty($sql)) {
        runquery($sql);
    }
    
    $sql = <<<EOF
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_clerk` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `tcshop_id` int(11) DEFAULT '0',
      `user_id` int(11) DEFAULT '0',
      `add_time` int(11) DEFAULT '0',
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
            
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_tuwen` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `tcshop_id` int(11) DEFAULT '0',
      `picurl` varchar(255) DEFAULT NULL,
      `txt` text,
      `paixu` int(11) DEFAULT '0',
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
            
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_clicks_log` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `tcshop_id` int(11) DEFAULT '0',
        `ip` int(11) unsigned DEFAULT '0',
        `today_time` int(11) DEFAULT '0',
        `log_time` int(11) DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
            
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_pinglun_photo` (
        `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
        `pinglun_id` int(11) DEFAULT '0',
        `picurl` varchar(255) DEFAULT NULL,
        `add_time` int(11) DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
            
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_money_log` (
      `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
      `user_id` int(11) DEFAULT '0',
      `type_id` int(11) DEFAULT '0',
      `tixian_id` int(11) DEFAULT '0',
      `change_money` decimal(10,2) DEFAULT '0.00',
      `old_money` decimal(10,2) DEFAULT '0.00',
      `business_id` varchar(255) DEFAULT NULL,
      `business_user_id` int(11) DEFAULT '0',
      `title` varchar(255) DEFAULT NULL,
      `order_no` varchar(255) DEFAULT NULL,
      `beizu` text,
      `log_year` int(11) DEFAULT '0',
      `log_month` int(11) DEFAULT '0',
      `log_day` int(11) DEFAULT '0',
      `log_ip` varchar(255) DEFAULT NULL,
      `log_time` int(11) DEFAULT '0',
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT '0',
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
        
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_money_tixian` (
      `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
      `tx_order_no` varchar(255) DEFAULT NULL,
      `user_id` int(11) DEFAULT '0',
      `type_id` int(11) DEFAULT '0',
      `money` decimal(10,2) DEFAULT '0.00',
      `alipay_zhanghao` varchar(255) DEFAULT NULL,
      `alipay_truename` varchar(255) DEFAULT NULL,
      `beizu` text,
      `status` int(11) DEFAULT '0',
      `tixian_ip` varchar(255) DEFAULT NULL,
      `tixian_time` int(11) DEFAULT '0',
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT '0',
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_mall_cate` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `tcshop_id` int(11) DEFAULT '0',
      `name` varchar(255) DEFAULT NULL,
      `csort` int(11) DEFAULT '10',
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_vip` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(255) DEFAULT NULL,
        `picurl` varchar(255) DEFAULT NULL,
        `open_video` tinyint(4) DEFAULT '0',
        `open_vr` tinyint(4) DEFAULT '0',
        `open_mp3` tinyint(4) DEFAULT '0',
        `open_zan` tinyint(4) DEFAULT '0',
        `open_gonggao` tinyint(4) DEFAULT '0',
        `open_xiao_qrcode` tinyint(4) DEFAULT '0',
        `open_tcmall` tinyint(4) DEFAULT '0',
        `open_tcqianggou` tinyint(4) DEFAULT '0',
        `open_coupon` tinyint(4) DEFAULT '0',
        `open_tcptuan` tinyint(4) DEFAULT '0',
        `open_tckjia` tinyint(4) DEFAULT '0',
        `open_tcchoujiang` tinyint(4) DEFAULT '0',
        `open_tchuodong` tinyint(4) DEFAULT '0',
        `open_tctoutiao` tinyint(4) DEFAULT '0',
        `days` int(11) DEFAULT '0',
        `days_msg` varchar(255) DEFAULT NULL,
        `price` decimal(10,2) DEFAULT '0.00',
        `rank` int(11) DEFAULT '0',
        `xiangou_num` int(11) DEFAULT '0',
        `status` tinyint(4) DEFAULT '0',
        `vsort` int(11) DEFAULT '10',
        `add_time` int(11) unsigned DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_vip_code` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `vip_id` int(11) DEFAULT '0',
        `code` varchar(255) DEFAULT NULL,
        `use_status` int(11) DEFAULT '0',
        `user_id` int(11) DEFAULT '0',
        `tcshop_id` int(11) DEFAULT '0',
        `use_time` int(11) unsigned DEFAULT '0',
        `add_time` int(11) unsigned DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_vip_log` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) DEFAULT '0',
        `tcshop_id` int(11) DEFAULT '0',
        `type` tinyint(4) DEFAULT '0',
        `vip_id` int(11) DEFAULT '0',
        `vip_code_id` int(11) DEFAULT '0',
        `log_time` int(11) unsigned DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_express` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `tcshop_id` int(11) DEFAULT '0',
        `title` varchar(255) DEFAULT NULL,
        `issendfree` tinyint(4) DEFAULT '0',
        `default_price` decimal(10,2) DEFAULT '0.00',
        `add_time` int(11) unsigned DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_express_item` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `tcshop_id` int(11) DEFAULT '0',
        `express_id` int(11) DEFAULT '0',
        `province_id` int(11) DEFAULT '0',
        `province_name` varchar(255) DEFAULT NULL,
        `city_id` int(11) DEFAULT '0',
        `city_name` varchar(255) DEFAULT NULL,
        `area_id` int(11) DEFAULT '0',
        `area_name` varchar(255) DEFAULT NULL,
        `issendfree` tinyint(4) DEFAULT '0',
        `express_price` decimal(10,2) DEFAULT '0.00',
        `add_time` int(11) unsigned DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_fabu_log` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) DEFAULT '0',
        `time_key` int(11) DEFAULT '0',
        `add_time` int(11) DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_tom_tcshop_place` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `tcshop_id` int(11) DEFAULT '0',
        `name` varchar(255) DEFAULT NULL,
        `tel` varchar(255) DEFAULT NULL,
        `latitude` varchar(255) DEFAULT NULL,
        `longitude` varchar(255) DEFAULT NULL,
        `address` varchar(255) DEFAULT NULL,
        `status` tinyint(4) DEFAULT '0',
        `psort` int(11) DEFAULT '10',
        `add_time` int(11) unsigned DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

EOF;

    runquery($sql);
    
    $sql = '';

    $tom_tcshop_vip_field = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_all_field();
    if (!isset($tom_tcshop_vip_field['open_tcyikatong'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_vip` ADD `open_tcyikatong` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_vip_field['open_fenlei'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_vip` ADD `open_fenlei` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_vip_field['is_base'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_vip` ADD `is_base` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcshop_vip_field['fenlei_times'])) {
        $sql .= "ALTER TABLE `pre_tom_tcshop_vip` ADD `fenlei_times` int(11) DEFAULT '0';\n";
    }

    if (!empty($sql)) {
        runquery($sql);
    }

    echo 'OK';exit;
    
}else{
    exit('Access Denied');
}