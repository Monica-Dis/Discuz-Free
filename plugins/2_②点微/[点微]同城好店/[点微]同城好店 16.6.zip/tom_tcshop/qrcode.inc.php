<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tcshopConfig       = $_G['cache']['plugin']['tom_tcshop'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

if('utf-8' != CHARSET) {
    if(defined('IN_MOBILE')) {}else{
        foreach($_POST AS $pk => $pv) {
            if(!is_numeric($pv)) {
                $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
            }
        }
    }
}

$share_url		= isset($_GET['share_url'])? daddslashes($_GET['share_url']):'';
$tcshop_id      = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);

$picurl2 = '';
if(!preg_match('/^http/', $tcshopInfo['picurl']) ){
    if(strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl2 = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['picurl'];
    }else{
        $picurl2 = $_G['siteurl'].$tcshopInfo['picurl'];
    }
}else{
    $picurl2 = $tcshopInfo['picurl'];
}

$focuspicListTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(" AND tcshop_id={$tcshop_id} AND type_id IN (1,2) ","ORDER BY type_id DESC,paixu ASC,id ASC",0,1);
if(is_array($focuspicListTmp) && !empty($focuspicListTmp[0]['picurl'])){
    $tcshopInfo['picurl'] = $focuspicListTmp[0]['picurl'];
}

$picurl = '';
if(!preg_match('/^http/', $tcshopInfo['picurl']) ){
    if(strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['picurl'];
    }else{
        $picurl = $_G['siteurl'].$tcshopInfo['picurl'];
    }
}else{
    $picurl = $tcshopInfo['picurl'];
}

$picurlImg   = DISCUZ_ROOT.'./source/plugin/tom_tcshop/data/qrcode/'.md5($share_url).'_picurl.png';
$wxqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tcshop/data/qrcode/'.md5($share_url).'_wxqrcode.png';
$wxqrcodeUrl = 'source/plugin/tom_tcshop/data/qrcode/'.md5($share_url).'_wxqrcode.png';

$tempDir = "/source/plugin/tom_tcshop/data/qrcode/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0777); 
}

if($tcshopConfig['open_wxqrcode'] == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_weixin/tom_weixin.inc.php')){
    
    $qrcodeKey  = "scan_tom_tcshop_id_".$tcshop_id;
    $qrcodeInfo = C::t('#tom_weixin#tom_weixin_fqrcode')->fetch_by_qkey($qrcodeKey);
    $qrcodeId = 0;
    if($qrcodeInfo){
        $qrcodeId = $qrcodeInfo['id'];
        $updateData = array();
        $updateData['title']  = $tcshopInfo['name'];
        $updateData['picurl'] = $picurl;
        $updateData['link']   = $share_url;
        $updateData['desc']   = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        C::t('#tom_weixin#tom_weixin_fqrcode')->update($qrcodeId,$updateData);
    }else{
        $insertData = array();
        $insertData['qkey']         = $qrcodeKey;
        $insertData['title']        = $tcshopInfo['name'];
        $insertData['picurl']       = $picurl;
        $insertData['desc']         = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        $insertData['link']         = $share_url;
        $insertData['extend']       = 'tcshop';
        $insertData['tcshop_id']    = $tcshop_id;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_weixin#tom_weixin_fqrcode')->insert($insertData);
        $qrcodeId = C::t('#tom_weixin#tom_weixin_fqrcode')->insert_id();
    }
    
    if(file_exists($wxqrcodeImg)){
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        $access_token = $weixinClass->get_access_token();

        $dateStr = '{"action_name": "QR_LIMIT_STR_SCENE", "action_info": {"scene": {"scene_str": "'.$qrcodeKey.'"}}}';
        $response   = postDataCurl($dateStr, 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token);
        $returnData = json_decode($response,true);
        if(isset($returnData['ticket']) &&  !empty($returnData['ticket'])){
            $wx_pic_content = getHtml('https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$returnData['ticket']);
            if(false === file_put_contents($wxqrcodeImg,$wx_pic_content)){
            }
        }
    
        $picurlData = file_get_contents($picurl2);
        file_put_contents($picurlImg, $picurlData);
        require_once libfile('class/image');
        $image = new image();
        $image->Thumb($picurlImg, '', 80, 80, 2, 1);

        watermark_img(DISCUZ_ROOT.'./'.$wxqrcodeUrl,$wxqrcodeUrl,$picurlImg);

        @unlink($picurlImg);
    }
    
}else{
    echo 'QR|notomweixin';exit;
}

echo 'OK|'.$wxqrcodeUrl;exit;

function getHtml($url){
    if(function_exists('curl_init')){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $return = curl_exec($ch);
        curl_close($ch); 
        return $return;
    }
    return false;
}

function postDataCurl($data, $url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,FALSE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $return = curl_exec($ch);
    if($return){
        curl_close($ch);
        return $return;
    } else { 
        $error = curl_errno($ch);
        curl_close($ch);
        return false;
    }
}

function watermark_img($source_path,$target_path,$watermark_path){
    
    $source = imagecreatefromstring(file_get_contents($source_path));
    $watermark = imagecreatefromstring(file_get_contents($watermark_path));
    
    list($source_w, $source_h, $source_type) = getimagesize($source_path);
    list($watermark_w, $watermark_h) = getimagesize($watermark_path);
    
    $x = ($source_w - $watermark_w) / 2;
    $y = ($source_h - $watermark_h) / 2; 
    
    imagecopy($source, $watermark, $x, $y, 0, 0, $watermark_w, $watermark_h);
    
    switch ($source_type) {
        case 1:
            imagegif($source,$target_path);
            break;
        case 2:
            imagejpeg($source,$target_path);
            break;
        case 3:
            imagepng($source,$target_path);
            break;
        default:
            break;
    }
    
    imagedestroy($source);
    imagedestroy($watermark);
    
    return $y;
}