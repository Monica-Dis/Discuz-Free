<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=cate'; 
$modListUrl = $adminListUrl.'&tmod=cate';
$modFromUrl = $adminFromUrl.'&tmod=cate';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tcshop#tom_tcshop_cate')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'addchild'){
    $parent_id       = isset($_GET['parent_id'])? intval($_GET['parent_id']):0;
    if(submitcheck('submit')){
        
        $name        = isset($_GET['name'])? addslashes($_GET['name']):'';
        $tc114_cate_id       = isset($_GET['tc114_cate_id'])? intval($_GET['tc114_cate_id']):0;
        $csort       = isset($_GET['csort'])? intval($_GET['csort']):10;
        
        $insertData = array();
        $insertData['name'] = $name;
        $insertData['tc114_cate_id'] = $tc114_cate_id;
        $insertData['csort'] = $csort;
        $insertData['parent_id'] = $parent_id;
        C::t('#tom_tcshop#tom_tcshop_cate')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=addchild&parent_id='.$parent_id,'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['cate_name'],'name'=>'name','value'=>'','msg'=>$Lang['cate_name_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['cate_tc114_cate_id'],'name'=>'tc114_cate_id','value'=>'0','msg'=>$Lang['cate_tc114_cate_id_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['cate_csort'],'name'=>'csort','value'=>10,'msg'=>$Lang['cate_csort_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $cateInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($cateInfo);
        C::t('#tom_tcshop#tom_tcshop_cate')->update($cateInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($cateInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
}else if($_GET['act'] == 'editchild'){
    $cateInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $name        = isset($_GET['name'])? addslashes($_GET['name']):'';
        $tc114_cate_id       = isset($_GET['tc114_cate_id'])? intval($_GET['tc114_cate_id']):0;
        $csort       = isset($_GET['csort'])? intval($_GET['csort']):10;
        
        $updateData = array();
        $updateData['name'] = $name;
        $updateData['tc114_cate_id'] = $tc114_cate_id;
        $updateData['csort'] = $csort;
        C::t('#tom_tcshop#tom_tcshop_cate')->update($cateInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=editchild&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['cate_name'],'name'=>'name','value'=>$cateInfo['name'],'msg'=>$Lang['cate_name_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['cate_tc114_cate_id'],'name'=>'tc114_cate_id','value'=>$cateInfo['tc114_cate_id'],'msg'=>$Lang['cate_tc114_cate_id_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['cate_csort'],'name'=>'csort','value'=>$cateInfo['csort'],'msg'=>$Lang['cate_csort_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'import'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcshop/config/import.data.php';
    
    foreach ($cateArr as $key => $value){
        $insertData = array();
        $insertData['name']     = $value['name'];
        $insertData['picurl']   = $value['picurl'];
        $insertData['csort']    = $key;
        C::t('#tom_tcshop#tom_tcshop_cate')->insert($insertData);
        $parent_id = C::t('#tom_tcshop#tom_tcshop_cate')->insert_id();
        
        foreach ($value['childs'] as $k1 => $v1){
            $insertData = array();
            $insertData['parent_id']     = $parent_id;
            $insertData['name']         = $v1;
            $insertData['csort']        = $k1;
            C::t('#tom_tcshop#tom_tcshop_cate')->insert($insertData);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcshop#tom_tcshop_cate')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['cate_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=import&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['cate_import'].'</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $cateList = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list(" AND parent_id=0 "," ORDER BY csort ASC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['cate_picurl'] . '</th>';
    echo '<th>' . $Lang['cate_name'] . '</th>';
    echo '<th>' . $Lang['cate_open_tel_price'] . '</th>';
    echo '<th>' . $Lang['cate_tc114_cate_id'] . '</th>';
    echo '<th>' . $Lang['cate_csort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($cateList as $key => $value) {
        
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><img src="'.$picurl.'" width="40" /></td>';
        echo '<td>' . $value['name'] . '&nbsp;<font color="#fd0d0d">(ID:' . $value['id'] . ')</font></td>';
        if($value['open_tel_price'] == 1){
            echo '<td><font color="#fd0d0d">' . $Lang['cate_open_tel_price_1'] . '</font></td>';
        }else{
            echo '<td><font color="#8e8e8e">' . $Lang['cate_open_tel_price_0'] . '</font></td>';
        }
        echo '<td>' . $value['tc114_cate_id'] . '</td>';
        echo '<td>' . $value['csort'] . '</td>';
        echo '<td>';
        if($value['parent_id'] == 0){
            echo '<a href="'.$modBaseUrl.'&act=addchild&parent_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['cate_addchild']. '</a>&nbsp;|&nbsp;';
        }
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['cate_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $childCateList = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list(" AND parent_id={$value['id']} "," ORDER BY csort ASC,id DESC ",0,100);
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $k => $v){
                echo '<tr>';
                echo '<td>' . $v['id'] . '</td>';
                echo '<td>&nbsp;</td>';
                echo '<td><img src="source/plugin/tom_tcshop/images/cates_admin_ico.png"/>' . $v['name'] . '&nbsp;<font color="#fd0d0d">(ID:' . $v['id'] . ')</font></td>';
                echo '<td>&nbsp;</td>';
                echo '<td>' . $v['tc114_cate_id'] . '</td>';
                echo '<td>' . $v['csort'] . '</td>';
                echo '<td>';
                echo '<a href="'.$modBaseUrl.'&act=editchild&id='.$v['id'].'&formhash='.FORMHASH.'">' . $Lang['cate_editchild']. '</a>&nbsp;|&nbsp;';
                echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$v['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
                echo '</td>';
                echo '</tr>';
            }
        }
        
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function import_confirm(url){
  var r = confirm("{$Lang['makesure_import_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name        = isset($_GET['name'])? addslashes($_GET['name']):'';
    $csort       = isset($_GET['csort'])? intval($_GET['csort']):10;
    
    $youhui_model_name     = isset($_GET['youhui_model_name'])? addslashes($_GET['youhui_model_name']):'';
    $youhui_model_ids      = isset($_GET['youhui_model_ids'])? addslashes($_GET['youhui_model_ids']):'';
    
    $open_tel_price       = isset($_GET['open_tel_price'])? intval($_GET['open_tel_price']):0;
    $open_upload_proof    = isset($_GET['open_upload_proof'])? intval($_GET['open_upload_proof']):0;
    $upload_proof_text    = isset($_GET['upload_proof_text'])? addslashes($_GET['upload_proof_text']):'';
    
    $tc114_cate_id       = isset($_GET['tc114_cate_id'])? intval($_GET['tc114_cate_id']):0;
    
    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }

    $data['name']               = $name;
    $data['picurl']             = $picurl;
    $data['youhui_model_name']  = $youhui_model_name;
    $data['youhui_model_ids']   = $youhui_model_ids;
    $data['open_tel_price']     = $open_tel_price;
    $data['open_upload_proof']  = $open_upload_proof;
    $data['upload_proof_text']  = $upload_proof_text;
    $data['tc114_cate_id']      = $tc114_cate_id;
    $data['csort']              = $csort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'                  => '',
        'picurl'                => '',
        'youhui_model_name'     => '',
        'youhui_model_ids'      => '',
        'open_tel_price'        => 0,
        'open_upload_proof'     => 0,
        'upload_proof_text'     => '',
        'tc114_cate_id'         => 0,
        'csort'                 => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['cate_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['cate_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['cate_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['cate_picurl_msg']),"file");
    
    tomshowsetting(true,array('title'=>$Lang['cate_youhui_model_name'],'name'=>'youhui_model_name','value'=>$options['youhui_model_name'],'msg'=>$Lang['cate_youhui_model_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['cate_youhui_model_ids'],'name'=>'youhui_model_ids','value'=>$options['youhui_model_ids'],'msg'=>$Lang['cate_youhui_model_ids_msg']),"input");
    
    $open_tel_price_item = array(0=>$Lang['cate_open_tel_price_0'],1=>$Lang['cate_open_tel_price_1']);
    tomshowsetting(true,array('title'=>$Lang['cate_open_tel_price'],'name'=>'open_tel_price','value'=>$options['open_tel_price'],'msg'=>$Lang['cate_open_tel_price_msg'],'item'=>$open_tel_price_item),"radio");
    $open_upload_proof_item = array(0=>$Lang['cate_open_upload_proof_0'],1=>$Lang['cate_open_upload_proof_1']);
    tomshowsetting(true,array('title'=>$Lang['cate_open_upload_proof'],'name'=>'open_upload_proof','value'=>$options['open_upload_proof'],'msg'=>$Lang['cate_open_upload_proof_msg'],'item'=>$open_upload_proof_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['cate_upload_proof_text'],'name'=>'upload_proof_text','value'=>$options['upload_proof_text'],'msg'=>$Lang['cate_upload_proof_text_msg']),"input");
    
    tomshowsetting(true,array('title'=>$Lang['cate_tc114_cate_id'],'name'=>'tc114_cate_id','value'=>$options['tc114_cate_id'],'msg'=>$Lang['cate_tc114_cate_id_msg']),"input");
    
    tomshowsetting(true,array('title'=>$Lang['cate_csort'],'name'=>'csort','value'=>$options['csort'],'msg'=>$Lang['cate_csort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['cate_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['cate_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['cate_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['cate_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['cate_edit'],"",true);
    }else if($_GET['act'] == 'addchild'){
        tomshownavli($Lang['cate_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['cate_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['cate_addchild'],"",true);
    }else if($_GET['act'] == 'editchild'){
        tomshownavli($Lang['cate_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['cate_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['cate_editchild'],"",true);
    }else{
        tomshownavli($Lang['cate_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['cate_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}


