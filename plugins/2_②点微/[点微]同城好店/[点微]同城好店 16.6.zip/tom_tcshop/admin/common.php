<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=common'; 
$modListUrl = $adminListUrl.'&tmod=common';
$modFromUrl = $adminFromUrl.'&tmod=common';

$commonInfo = C::t('#tom_tcshop#tom_tcshop_common')->fetch_by_id(1);
if(!$commonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcshop#tom_tcshop_common')->insert($insertData);
}
if(submitcheck('submit')){
    $updateData = array();
    $updateData = __get_post_data($commonInfo);
    C::t('#tom_tcshop#tom_tcshop_common')->update(1,$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    tomloadcalendarjs();
    loadeditorjs();
    __create_nav_html();
    showformheader($modFromUrl,'enctype');
    showtableheader();
    __create_info_html($commonInfo);
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $xieyi_txt         = isset($_GET['xieyi_txt'])? addslashes($_GET['xieyi_txt']):'';
    $new_vip_txt       = isset($_GET['new_vip_txt'])? addslashes($_GET['new_vip_txt']):'';

    $data['xieyi_txt']   = $xieyi_txt;
    $data['new_vip_txt'] = $new_vip_txt;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'xieyi_txt'        => '',
        'new_vip_txt'         => '',
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['xieyi_title'],'name'=>'xieyi_txt','value'=>$options['xieyi_txt'],'msg'=>$Lang['xieyi_title_msg']),"text");
    tomshowsetting(true,array('title'=>$Lang['new_vip_title'],'name'=>'new_vip_txt','value'=>$options['new_vip_txt'],'msg'=>$Lang['new_vip_title_msg']),"text");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    tomshownavli($Lang['common_title'],"",true);
    tomshownavfooter();
}