<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=vip_code';
$modListUrl = $adminListUrl.'&tmod=vip_code';
$modFromUrl = $adminFromUrl.'&tmod=vip_code';

if($_GET['act'] == 'addzd'){
    if(submitcheck('submit')){
        
        $vip_id = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
        $num    = isset($_GET['num'])? intval($_GET['num']):0;
        
        if($num > 50){
            $num = 50;
        }
        
        $codeInfoTmp = C::t('#tom_tcshop#tom_tcshop_vip_code')->fetch_all_list(" ", " ORDER BY id DESC", 0, 1);
        $min_id = 1111;
        if(is_array($codeInfoTmp) && !empty($codeInfoTmp['0'])){
            $min_id = $codeInfoTmp['0']['id'] + 1;
        }
        
        $id = intval($min_id);
        for($i=0; $i<$num; $i++){
            $code = '';
            $len = strlen($id);
            $inviteCode = tom_random($len, 'qwertyupasdfghjkzxcvbnm');
            $no = strval($id);
            for($j=0;$j<$len;$j++){
                $code.=$inviteCode[$j].$no[$j];
            }
            
            $insertData = array();
            $insertData['id']           = $id++;
            $insertData['vip_id']       = $vip_id;
            $insertData['code']         = $code;
            $insertData['use_status']   = 0;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tcshop#tom_tcshop_vip_code')->insert($insertData);
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=addzd','enctype');
        showtableheader();
        
        $vipList = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_all_list(""," ORDER BY vsort ASC,id DESC ",0,100);
        $vipStr = '<tr class="header"><th>'.$Lang['vip_code_vip'].'</th><th></th></tr>';
        $vipStr.= '<tr><td width="300"><select style="width: 150px;" name="vip_id">';
        foreach ($vipList as $key => $value){
            if($value['id'] == $options['vip_id']){
                $vipStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $vipStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $vipStr.= '</select></td><td>'.$Lang['vip_code_vip_msg'].'</td></tr>';
        echo $vipStr;
        tomshowsetting(true,array('title'=>$Lang['vip_code_num'],'name'=>'num','value'=>'','msg'=>$Lang['vip_code_num_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'addsd'){
    
    if(submitcheck('submit')){
        
        $vip_id     = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
        $text       = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $codeListStr = str_replace("\r\n","{n}",trim($text));
        $codeListStr = str_replace("\n","{n}",$codeListStr);
        $codeListStr = explode("{n}", $codeListStr);
        
        $codeInfoTmp = C::t('#tom_tcshop#tom_tcshop_vip_code')->fetch_all_list(" ", " ORDER BY id DESC", 0, 1);
        $min_id = 1111;
        if(is_array($codeInfoTmp) && !empty($codeInfoTmp['0'])){
            $min_id = $codeInfoTmp['0']['id'] + 1;
        }
        
        foreach($codeListStr as $key => $value){
            $insertData = array();
            $insertData['id']           = $min_id++;
            $insertData['vip_id']       = $vip_id;
            $insertData['code']         = trim($value);
            $insertData['use_status']   = 0;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tcshop#tom_tcshop_vip_code')->insert($insertData);
        }

        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=addsd','enctype');
        showtableheader();
        
        $vipList = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_all_list(""," ORDER BY vsort ASC,id DESC ",0,100);
        $vipStr = '<tr class="header"><th>'.$Lang['vip_code_vip'].'</th><th></th></tr>';
        $vipStr.= '<tr><td width="300"><select style="width: 150px;" name="vip_id">';
        foreach ($vipList as $key => $value){
            if($value['id'] == $options['vip_id']){
                $vipStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $vipStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $vipStr.= '</select></td><td>'.$Lang['vip_code_vip_msg'].'</td></tr>';
        echo $vipStr;
        tomshowsetting(true,array('title'=>$Lang['vip_code_sd_code'],'name'=>'text','value'=>'','msg'=>$Lang['vip_code_sd_code_msg']),"textarea");
        
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcshop#tom_tcshop_vip_code')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{

    $code       = isset($_GET['code'])? addslashes($_GET['code']):'';
    $use_status = intval($_GET['use_status'])>0? intval($_GET['use_status']):0;
    $user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $tcshop_id  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if($use_status > 0){
        if($use_status == 1){
            $where.= " AND use_status = 1 ";
        }else if($use_status == 2){
            $where.= " AND use_status = 0 ";
        }
    }
    if($user_id > 0){
        $where.= " AND user_id = {$user_id} ";
    }
    if($tcshop_id > 0){
        $where.= " AND tcshop_id = {$tcshop_id} ";
    }
    if(!empty($code)){
        $where.= " AND code = '{$code}' ";
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcshop#tom_tcshop_vip_code')->fetch_all_count($where);
    $codeList = C::t('#tom_tcshop#tom_tcshop_vip_code')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&use_status={$use_status}&user_id={$user_id}&tcshop_id={$tcshop_id}&code={$code}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_list'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['vip_code'] . '</b></td><td><input name="code" type="text" value="'.$code.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['vip_code_user_id'] . '</b></td><td><input name="user_id" type="text" value="'.$user_id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['vip_code_tcshop_id'] . '</b></td><td><input name="tcshop_id" type="text" value="'.$tcshop_id.'" size="40" /></td></tr>';
    
    $use_status_1 = $use_status_2 = "";
    if($use_status == 1){ $use_status_1 = "selected";}
    if($use_status == 2){ $use_status_2 = "selected";}
    $overStr = '<tr><td width="100" align="right"><b>'.$Lang['vip_code_use_status'].'</b></td>';
    $overStr.= '<td><select style="width: 260px;" name="use_status" id="use_status">';
    $overStr.=  '<option value="0">'.$Lang['vip_code_use_status_all'].'</option>';
    $overStr.=  '<option value="1" '.$use_status_1.'>'.$Lang['vip_code_use_status_1'].'</option>';
    $overStr.=  '<option value="2" '.$use_status_2.'>'.$Lang['vip_code_use_status_0'].'</option>';
    $overStr.= '</select></td></tr>';
    echo $overStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['vip_code'] . '</th>';
    echo '<th>' . $Lang['vip_code_vip'] . '</th>';
    echo '<th>' . $Lang['vip_code_use_status'] . '</th>';
    echo '<th>' . $Lang['vip_code_user'] . '</th>';
    echo '<th>' . $Lang['vip_code_tcshop_id'] . '</th>';
    echo '<th>' . $Lang['vip_code_use_time'] . '</th>';
    echo '<th>' . $Lang['vip_code_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($codeList as $key => $value) {
        
        $vipInfo = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($value['vip_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);

        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $value['code'] . '</td>';
        if($vipInfo){
            echo '<td>' . $vipInfo['name'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['use_status'] == 1){
            echo '<td><font color="#f00">' . $Lang['vip_code_use_status_1'] . '</font></td>';
        }else{
            echo '<td><font color="#0a9409">' . $Lang['vip_code_use_status_0'] . '</font></td>';
        }
        if($userInfo){
            echo '<td>' . $userInfo['nickname'] .'<font color="#0a9409">(ID:'.$userInfo['id']. ')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        if($tcshopInfo){
            echo '<td>' . $tcshopInfo['name'] .'<font color="#0a9409">(ID:'.$tcshopInfo['id']. ')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['use_time'] > 0){
            echo '<td>' . dgmdate($value['use_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'addzd'){
        tomshownavli($Lang['vip_code_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['vip_code_zdadd'],"",true);
    }else if($_GET['act'] == 'addsd'){
        tomshownavli($Lang['vip_code_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['vip_code_sdadd'],$modBaseUrl."&act=addsd",true);
    }else{
        tomshownavli($Lang['vip_list_title'],$adminBaseUrl."&tmod=vip",false);
        tomshownavli($Lang['vip_code_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['vip_code_zdadd'],$modBaseUrl."&act=addzd",false);
        tomshownavli($Lang['vip_code_sdadd'],$modBaseUrl."&act=addsd",false);
    }
    tomshownavfooter();
}