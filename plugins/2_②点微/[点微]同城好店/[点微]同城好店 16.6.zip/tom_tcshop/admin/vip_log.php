<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=vip_log&tcshop_id='.$_GET['tcshop_id'];
$modListUrl = $adminListUrl.'&tmod=vip_log&tcshop_id='.$_GET['tcshop_id'];
$modFromUrl = $adminFromUrl.'&tmod=vip_log&tcshop_id='.$_GET['tcshop_id'];

$tcshop_id = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);

$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$where = " AND tcshop_id={$tcshop_id} ";
$pagesize = 100;
$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcshop#tom_tcshop_vip_log')->fetch_all_count($where);
$vipLogList = C::t('#tom_tcshop#tom_tcshop_vip_log')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);

showtableheader();
echo '<tr><th colspan="15" class="partition"><font color="#238206">'.$tcshopInfo['name'].'</font>&nbsp;>&nbsp;' .$Lang['viplog_list_title']. '</th></tr>';
showtablefooter(); /*dism��taobao��com*/

showtableheader();
echo '<tr class="header">';
echo '<th> ID </th>';
echo '<th>' . $Lang['viplog_user'] . '</th>';
echo '<th>' . $Lang['viplog_type'] . '</th>';
echo '<th>' . $Lang['viplog_vip'] . '</th>';
echo '<th>' . $Lang['viplog_code'] . '</th>';
echo '<th>' . $Lang['viplog_log_time'] . '</th>';
echo '<th>' . $Lang['handle'] . '</th>';
echo '</tr>';

$i = 1;
foreach ($vipLogList as $key => $value) {
    
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
    $vipInfo = C::t("#tom_tcshop#tom_tcshop_vip")->fetch_by_id($value['vip_id']);
    $vipCodeInfo = C::t("#tom_tcshop#tom_tcshop_vip_code")->fetch_by_id($value['vip_code_id']);
    
    echo '<tr>';
    echo '<td>' . $value['id'] . '</td>';
    echo '<td>' . $userInfo['nickname'] .'<font color="#f00">(ID:'.$value['user_id'].')</font></td>';
    if($value['type'] == 1){
        echo '<td><font color="#0a9409">' . $Lang['viplog_type_1'] . '</font></td>';
        echo '<td>' . $vipInfo['name'] .'<font color="#f00">(ID:'.$value['vip_id'].')</font></td>';
        echo '<td> -- </td>';
    }else if($value['type'] == 2){
        echo '<td><font color="#0a9409">' . $Lang['viplog_type_2'] . '</font></td>';
        echo '<td> -- </td>';
        echo '<td>' . $vipCodeInfo['code'] .'<font color="#f00">(ID:'.$value['vip_code_id'].')</font></td>';
    }else{
        echo '<td> -- </td>';
    }
    echo '<td>' . dgmdate($value['log_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
    echo '<td> -- </td>';
    echo '</tr>';
    $i++;
}
showtablefooter(); /*dism��taobao��com*/
$multi = multi($count, $pagesize, $page, $modBaseUrl);	
showsubmit('', '', '', '', $multi, false);