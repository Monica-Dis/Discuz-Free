<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=vip';
$modListUrl = $adminListUrl.'&tmod=vip';
$modFromUrl = $adminFromUrl.'&tmod=vip';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcshop#tom_tcshop_vip')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $vipInfo = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($vipInfo);
        if(C::t('#tom_tcshop#tom_tcshop_vip')->update($vipInfo['id'],$updateData)){
            $vipInfo = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($vipInfo['id']);
            DB::query("UPDATE ".DB::table('tom_tcshop')." SET vip_rank={$vipInfo['rank']} WHERE vip_id={$vipInfo['id']} AND vip_status = 1 ", 'UNBUFFERED');
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($vipInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $tcshopCount = C::t("#tom_tcshop#tom_tcshop")->fetch_all_count(" AND vip_id = {$_GET['id']} ");
    if($tcshopCount > 0){
        cpmsg($Lang['vip_no_remove_error'], $modListUrl, 'error');exit;
    }
    
    C::t('#tom_tcshop#tom_tcshop_vip')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'update_level_0_tcshop'){
    
    if(submitcheck('submit')){
        
        $vip_id = intval($_GET['vip_id'])>0 ? intval($_GET['vip_id']):0;
        $status = intval($_GET['status'])>0 ? intval($_GET['status']):0;
        $time   = isset($_GET['time'])? addslashes($_GET['time']):'';
        $time   = strtotime($time);
        
        $vipInfo = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($vip_id);
        
        if($status == 1){
            DB::query("UPDATE ".DB::table('tom_tcshop')." SET vip_id={$vip_id},vip_rank={$vipInfo['rank']},vip_status=1,vip_time=base_time WHERE vip_level = 0 AND base_level = 2  ", 'UNBUFFERED');
        }else if($status == 2){
            if($time > TIMESTAMP){
                DB::query("UPDATE ".DB::table('tom_tcshop')." SET vip_id={$vip_id},vip_rank={$vipInfo['rank']},vip_status=1,vip_time={$time} WHERE vip_level = 0 AND base_level = 1  ", 'UNBUFFERED');
            }else{
                DB::query("UPDATE ".DB::table('tom_tcshop')." SET vip_id={$vip_id},vip_rank={$vipInfo['rank']},vip_status=2,vip_time={$time} WHERE vip_level = 0 AND base_level = 1  ", 'UNBUFFERED');
            }
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=update_level_0_tcshop','enctype');
        showtableheader();
        
        $vipList = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_all_list(""," ORDER BY vsort ASC,id DESC ",0,100);
        $vipStr = '<tr class="header"><th>'.$Lang['vip_select_viplevel_0'].'</th><th></th></tr>';
        $vipStr.= '<tr><td width="300"><select style="width: 260px;" name="vip_id" id="vip_id">';
        foreach ($vipList as $key => $value){
            $vipStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
        $vipStr.= '</select></td><td>'.$Lang['vip_select_viplevel_0_msg'].'</td></tr>';
        echo $vipStr;
        $vip_select_status_item = array(1=>$Lang['vip_select_status_1'],2=>$Lang['vip_select_status_2']);
        tomshowsetting(true,array('title'=>$Lang['vip_select_status'],'name'=>'status','value'=>1,'msg'=>$Lang['vip_select_status_msg'],'item'=>$vip_select_status_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['vip_select_time'],'name'=>'time','value'=>'','msg'=>$Lang['vip_select_time_msg']),"calendar");
        
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'update_level_1_tcshop'){
    
    if(submitcheck('submit')){
        
        $vip_id = intval($_GET['vip_id'])>0 ? intval($_GET['vip_id']):0;
        
        $vipInfo = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($vip_id);
        
        DB::query("UPDATE ".DB::table('tom_tcshop')." SET vip_id={$vip_id},vip_rank={$vipInfo['rank']},vip_status=1 WHERE vip_level = 1 AND vip_id = 0 ", 'UNBUFFERED');
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=update_level_1_tcshop','enctype');
        showtableheader();
        
        $vipList = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_all_list(""," ORDER BY vsort ASC,id DESC ",0,100);
        $vipStr = '<tr class="header"><th>'.$Lang['vip_select_viplevel_1'].'</th><th></th></tr>';
        $vipStr.= '<tr><td width="300"><select style="width: 260px;" name="vip_id" id="vip_id">';
        foreach ($vipList as $key => $value){
            $vipStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
        $vipStr.= '</select></td><td>'.$Lang['vip_select_viplevel_1_msg'].'</td></tr>';
        echo $vipStr;
        
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'import'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcshop/config/import.data.php';
    
    foreach ($vipArr as $key => $value){
        $insertData = array();
        $insertData = $value;
        $insertData['vsort']    = $key;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcshop#tom_tcshop_vip')->insert($insertData);
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'update_status'){
    
    $updateData = array();
    $updateData['status'] = $_GET['status'];
    C::t('#tom_tcshop#tom_tcshop_vip')->update($_GET['id'], $updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
    
}else{
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['vip_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=import&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['vip_import'].'</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $vipList = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_all_list(""," ORDER BY vsort ASC,id DESC ",$start,$pagesize);
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['vip_picurl'] . '</th>';
    echo '<th>' . $Lang['vip_name'] . '</th>';
    echo '<th>' . $Lang['vip_days'] . '</th>';
    echo '<th>' . $Lang['vip_days_msg'] . '</th>';
    echo '<th>' . $Lang['vip_price'] . '</th>';
    echo '<th width="270px">' . $Lang['vip_tequan'] . '</th>';
    echo '<th>' . $Lang['vip_xiangou_num'] . '</th>';
    echo '<th>' . $Lang['vip_fenlei_times'] . '</th>';
    echo '<th>' . $Lang['vip_rank'] . '</th>';
    echo '<th>' . $Lang['vip_is_base'] . '</th>';
    echo '<th>' . $Lang['vip_status'] . '</th>';
    echo '<th>' . $Lang['vip_vsort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($vipList as $key => $value) {
        
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><img src="'.$picurl.'" width="40" /></td>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['days'] . '</td>';
        echo '<td>' . $value['days_msg'] . '</td>';
        echo '<td><font color="#fd0d0d">' . $value['price'] . '</font></td>';
        echo '<td>';
        if($value['open_zan'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_zan'] . '</span>';
        }
        if($value['open_gonggao'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_gonggao'] . '</span>';
        }
        if($value['open_video'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_video'] . '</span>';
        }
        if($value['open_vr'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_vr'] . '</span>';
        }
        if($value['open_mp3'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_mp3'] . '</span>';
        }
        if($value['open_xiao_qrcode'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_xiao_qrcode'] . '</span>';
        }
        if($value['open_tcmall'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_tcmall'] . '</span>';
        }
        if($value['open_tcqianggou'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_tcqianggou'] . '</span>';
        }
        if($value['open_coupon'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_coupon'] . '</span>';
        }
        if($value['open_tcptuan'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_tcptuan'] . '</span>';
        }
        if($value['open_tckjia'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_tckjia'] . '</span>';
        }
        if($value['open_tcchoujiang'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_tcchoujiang'] . '</span>';
        }
        if($value['open_tchuodong'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_tchuodong'] . '</span>';
        }
        if($value['open_tctoutiao'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_tctoutiao']. '</span>';
        }
        if($value['open_tcyikatong'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_tcyikatong']. '</span>';
        }
        if($value['open_fenlei'] == 1){
            echo  '<span style="display:inline-block; width:90px; line-height:20px;"><img width="15px" style="vertical-align:-4px; margin-right:3px;" src="source/plugin/tom_tcshop/images/icon_selected.png">'.$Lang['vip_tequan_fenlei']. '</span>';
        }
        echo '</td>';
        if($value['xiangou_num'] > 0){
            echo '<td>' . $value['xiangou_num'] . '</td>';
        }else{
            echo '<td><font color="#0a9409">' . $Lang['vip_xiangou_num_0'] . '</font></td>';
        }
        echo '<td>' . $value['fenlei_times'] . '</td>';
        echo '<td>' . $value['rank'] . '</td>';
        if($value['is_base'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['vip_is_base_1'] . '</font></td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['vip_is_base_0'] . '</font></td>';
        }
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['vip_status_1'] . '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=update_status&status=0&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['vip_status_0']. '</a>)</td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['vip_status_0'] . '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=update_status&status=1&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['vip_status_1']. '</a>)</td>';
        }
        echo '<td>' . $value['vsort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}

function import_confirm(url){
  var r = confirm("{$Lang['makesure_import_vip_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $days           = intval($_GET['days'])>0? intval($_GET['days']):0;
    $days_msg       = isset($_GET['days_msg'])? addslashes($_GET['days_msg']):'';
    $price          = floatval($_GET['price'])>0? floatval($_GET['price']):0.00;
    $rank           = intval($_GET['rank'])>0? intval($_GET['rank']):0;
    $fenlei_times   = intval($_GET['fenlei_times'])>0? intval($_GET['fenlei_times']):0;
    $xiangou_num    = intval($_GET['xiangou_num'])>0? intval($_GET['xiangou_num']):0;
    $is_base        = intval($_GET['is_base'])>0? intval($_GET['is_base']):0;
    $vsort          = intval($_GET['vsort'])>0? intval($_GET['vsort']):10;

    $tequanArr = array();
    if(is_array($_GET['tequan']) && !empty($_GET['tequan'])){
        foreach($_GET['tequan'] as $key => $value){
            $tequanArr[] = addslashes($value);
        }
    }
    
    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    $data['name']           = $name;
    $data['picurl']         = $picurl;
    $data['days']           = $days;
    $data['days_msg']       = $days_msg;
    $data['price']          = $price;
    $data['rank']           = $rank;
    $data['fenlei_times']   = $fenlei_times;
    $data['xiangou_num']    = $xiangou_num;
    $data['is_base']        = $is_base;
    $data['vsort']          = $vsort;
    
    if(in_array('video', $tequanArr)){
        $data['open_video']         = 1;
    }else{
        $data['open_video']         = 0;
    }
    if(in_array('vr', $tequanArr)){
        $data['open_vr']            = 1;
    }else{
        $data['open_vr']            = 0;
    }
    if(in_array('mp3', $tequanArr)){
        $data['open_mp3']           = 1;
    }else{
        $data['open_mp3']           = 0;
    }
    if(in_array('zan', $tequanArr)){
        $data['open_zan']           = 1;
    }else{
        $data['open_zan']           = 0;
    }
    if(in_array('gonggao', $tequanArr)){
        $data['open_gonggao']       = 1;
    }else{
        $data['open_gonggao']       = 0;
    }
    if(in_array('xiao_qrcode', $tequanArr)){
        $data['open_xiao_qrcode']   = 1;
    }else{
        $data['open_xiao_qrcode']   = 0;
    }     
    if(in_array('tcmall', $tequanArr)){
        $data['open_tcmall']        = 1;
    }else{
        $data['open_tcmall']        = 0;
    }
    if(in_array('tcqianggou', $tequanArr)){
        $data['open_tcqianggou']    = 1;
    }else{
        $data['open_tcqianggou']    = 0;
    }
    if(in_array('coupon', $tequanArr)){
        $data['open_coupon']        = 1;
    }else{
        $data['open_coupon']        = 0;
    }
    if(in_array('tcptuan', $tequanArr)){
        $data['open_tcptuan']       = 1;
    }else{
        $data['open_tcptuan']       = 0;
    }
    if(in_array('tckjia', $tequanArr)){
        $data['open_tckjia']        = 1;
    }else{
        $data['open_tckjia']        = 0;
    }
    if(in_array('tcchoujiang', $tequanArr)){
        $data['open_tcchoujiang']   = 1;
    }else{
        $data['open_tcchoujiang']   = 0;
    }
    if(in_array('tchuodong', $tequanArr)){
        $data['open_tchuodong']     = 1;
    }else{
        $data['open_tchuodong']     = 0;
    }
    if(in_array('tctoutiao', $tequanArr)){
        $data['open_tctoutiao']     = 1;
    }else{
        $data['open_tctoutiao']     = 0;
    }
    if(in_array('tcyikatong', $tequanArr)){
        $data['open_tcyikatong']     = 1;
    }else{
        $data['open_tcyikatong']     = 0;
    }
    if(in_array('fenlei', $tequanArr)){
        $data['open_fenlei']     = 1;
    }else{
        $data['open_fenlei']     = 0;
    }
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'              => '',
        'picurl'            => '',
        'open_video'        => 0,
        'open_vr'           => 0,
        'open_mp3'          => 0,
        'open_zan'          => 0,
        'open_gonggao'      => 0,
        'open_xiao_qrcode'  => 0,
        'open_tcmall'       => 0,
        'open_tcqianggou'   => 0,
        'open_coupon'       => 0,
        'open_tcptuan'      => 0,
        'open_tckjia'       => 0,
        'open_tcchoujiang'  => 0,
        'open_tchuodong'    => 0,
        'open_tctoutiao'    => 0,
        'open_tcyikatong'   => 0,
        'open_fenlei'       => 0,
        'days'              => 0,
        'days_msg'          => '',
        'price'             => 0.00,
        'rank'              => 0,
        'fenlei_times'      => 0,
        'xiangou_num'       => 0,
        'is_base'           => 0,
        'vsort'             => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['vip_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['vip_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['vip_picurl_msg']),"file");
    
    $tequanStr = '<tr class="header"><th>'.$Lang['vip_tequan_select'].'</th><th></th></tr>';
    $tequanStr.= '<tr><td width="300">';
    if($options['open_zan'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="zan" checked>'.$Lang['vip_tequan_zan'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="zan">'.$Lang['vip_tequan_zan'].'</label>';
    }
    if($options['open_gonggao'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="gonggao" checked>'.$Lang['vip_tequan_gonggao'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="gonggao">'.$Lang['vip_tequan_gonggao'].'</label>';
    }
    if($options['open_video'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="video" checked>'.$Lang['vip_tequan_video'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="video">'.$Lang['vip_tequan_video'].'</label>';
    }
    if($options['open_vr'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="vr" checked>'.$Lang['vip_tequan_vr'].'</label><br/>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="vr">'.$Lang['vip_tequan_vr'].'</label><br/>';
    }
    if($options['open_mp3'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="mp3" checked>'.$Lang['vip_tequan_mp3'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="mp3">'.$Lang['vip_tequan_mp3'].'</label>';
    }
    if($options['open_xiao_qrcode'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="xiao_qrcode" checked>'.$Lang['vip_tequan_xiao_qrcode'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="xiao_qrcode">'.$Lang['vip_tequan_xiao_qrcode'].'</label>';
    }
    if($options['open_tcmall'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tcmall" checked>'.$Lang['vip_tequan_tcmall'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tcmall">'.$Lang['vip_tequan_tcmall'].'</label>';
    }
    if($options['open_tcqianggou'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tcqianggou" checked>'.$Lang['vip_tequan_tcqianggou'].'</label><br/>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tcqianggou">'.$Lang['vip_tequan_tcqianggou'].'</label><br/>';
    }
    if($options['open_coupon'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="coupon" checked>'.$Lang['vip_tequan_coupon'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="coupon">'.$Lang['vip_tequan_coupon'].'</label>';
    }
    if($options['open_tcptuan'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tcptuan" checked>'.$Lang['vip_tequan_tcptuan'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tcptuan">'.$Lang['vip_tequan_tcptuan'].'</label>';
    }
    if($options['open_tckjia'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tckjia" checked>'.$Lang['vip_tequan_tckjia'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tckjia">'.$Lang['vip_tequan_tckjia'].'</label>';
    }
    if($options['open_tcchoujiang'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tcchoujiang" checked>'.$Lang['vip_tequan_tcchoujiang'].'</label><br/>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tcchoujiang">'.$Lang['vip_tequan_tcchoujiang'].'</label><br/>';
    }
    if($options['open_tchuodong'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tchuodong" checked>'.$Lang['vip_tequan_tchuodong'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tchuodong">'.$Lang['vip_tequan_tchuodong'].'</label>';
    }
    if($options['open_tctoutiao'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tctoutiao" checked>'.$Lang['vip_tequan_tctoutiao'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tctoutiao">'.$Lang['vip_tequan_tctoutiao'].'</label>';
    }
    if($options['open_tcyikatong'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tcyikatong" checked>'.$Lang['vip_tequan_tcyikatong'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="tcyikatong">'.$Lang['vip_tequan_tcyikatong'].'</label>';
    }
    if($options['open_fenlei'] == 1){
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="fenlei" checked>'.$Lang['vip_tequan_fenlei'].'</label>';
    }else{
        $tequanStr.=  '<label style="white-space: nowrap;"><input type="checkbox" name="tequan[]" value="fenlei">'.$Lang['vip_tequan_fenlei'].'</label>';
    }
    $tequanStr.= '</td><td></td></tr>';
    echo $tequanStr;
    
    tomshowsetting(true,array('title'=>$Lang['vip_days'],'name'=>'days','value'=>$options['days'],'msg'=>$Lang['vip_days_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_days_msg'],'name'=>'days_msg','value'=>$options['days_msg'],'msg'=>$Lang['vip_days_msg_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_price'],'name'=>'price','value'=>$options['price'],'msg'=>$Lang['vip_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_rank'],'name'=>'rank','value'=>$options['rank'],'msg'=>$Lang['vip_rank_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_fenlei_times'],'name'=>'fenlei_times','value'=>$options['fenlei_times'],'msg'=>$Lang['vip_fenlei_times_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_xiangou_num'],'name'=>'xiangou_num','value'=>$options['xiangou_num'],'msg'=>$Lang['vip_xiangou_num_msg']),"input");
    $is_base_item = array(0=>$Lang['vip_is_base_0'],1=>$Lang['vip_is_base_1']);
    tomshowsetting(true,array('title'=>$Lang['vip_is_base'],'name'=>'is_base','value'=>$options['is_base'],'msg'=>$Lang['vip_is_base_msg'],'item'=>$is_base_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['vip_vsort'],'name'=>'vsort','value'=>$options['vsort'],'msg'=>$Lang['vip_vsort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['vip_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['vip_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['vip_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['vip_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['vip_edit'],"",true);
    }else if($_GET['act'] == 'update_level_0_tcshop'){
        tomshownavli($Lang['vip_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['vip_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['vip_update_viplevel_0_tcshop'],$modBaseUrl."&act=update_level_0_tcshop",true);
        tomshownavli($Lang['vip_update_viplevel_1_tcshop'],$modBaseUrl."&act=update_level_1_tcshop",false);
    }else if($_GET['act'] == 'update_level_1_tcshop'){
        tomshownavli($Lang['vip_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['vip_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['vip_update_viplevel_0_tcshop'],$modBaseUrl."&act=update_level_0_tcshop",false);
        tomshownavli($Lang['vip_update_viplevel_1_tcshop'],$modBaseUrl."&act=update_level_1_tcshop",true);
    }else{
        tomshownavli($Lang['vip_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['vip_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['vip_code_title'],$adminBaseUrl."&tmod=vip_code",false);
        tomshownavli($Lang['vip_update_viplevel_0_tcshop'],$modBaseUrl."&act=update_level_0_tcshop",false);
        tomshownavli($Lang['vip_update_viplevel_1_tcshop'],$modBaseUrl."&act=update_level_1_tcshop",false);
    }
    tomshownavfooter();
}