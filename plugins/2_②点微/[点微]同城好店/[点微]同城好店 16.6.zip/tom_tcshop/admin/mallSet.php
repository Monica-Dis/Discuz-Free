<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=mallSet&tcshop_id='.$_GET['tcshop_id'];
$modListUrl = $adminListUrl.'&tmod=mallSet&tcshop_id='.$_GET['tcshop_id'];
$modFromUrl = $adminFromUrl.'&tmod=mallSet&tcshop_id='.$_GET['tcshop_id'];

$tcshop_id = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tcshop#tom_tcshop_mall_cate')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $mallCateInfo = C::t('#tom_tcshop#tom_tcshop_mall_cate')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($mallCateInfo);
        C::t('#tom_tcshop#tom_tcshop_mall_cate')->update($mallCateInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($mallCateInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcshop#tom_tcshop_mall_cate')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'editgoods'){
    
    if(submitcheck('submit')){
        
        $edmoney            = isset($_GET['edmoney'])? floatval($_GET['edmoney']):0.00;
        $dispatch_type      = isset($_GET['dispatch_type'])? intval($_GET['dispatch_type']):0;
        $peisong_type       = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):0;
        $open_vip_price_set = isset($_GET['open_vip_price_set'])? intval($_GET['open_vip_price_set']):0;
        $huodao_pay         = isset($_GET['huodao_pay'])? intval($_GET['huodao_pay']):0;
        $open_shop_list_cart = isset($_GET['open_shop_list_cart'])? intval($_GET['open_shop_list_cart']):0;
    
        $mall_shop_picurl = tomuploadFile("mall_shop_picurl",$tcshopInfo['mall_shop_picurl']);
        
        $updateData = array();
        $updateData['edmoney']              = $edmoney;
        $updateData['dispatch_type']        = $dispatch_type;
        $updateData['open_vip_price_set']   = $open_vip_price_set;
        $updateData['peisong_type']         = $peisong_type;
        $updateData['mall_shop_picurl']     = $mall_shop_picurl;
        $updateData['huodao_pay']           = $huodao_pay;
        $updateData['open_shop_list_cart']  = $open_shop_list_cart;
        C::t('#tom_tcshop#tom_tcshop')->update($tcshopInfo['id'], $updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }
    
}else{
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $tcshopInfo['name'] .'&nbsp;&nbsp;&gt;&nbsp;&nbsp;'.$Lang['mallSet_list_title']. '</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    tomloadcalendarjs();
    showformheader($modFromUrl.'&act=editgoods&formhash='.FORMHASH, 'enctype');
    showtableheader();
    
    tomshowsetting(true,array('title'=>$Lang['tcshop_edmoney'],'name'=>'edmoney','value'=>$tcshopInfo['edmoney'],'msg'=>$Lang['tcshop_edmoney_msg']),"input");
    $dispatch_type_item = array(0=>$Lang['tcshop_dispatch_type_0'],1=>$Lang['tcshop_dispatch_type_1']);
    tomshowsetting(true,array('title'=>$Lang['tcshop_dispatch_type'],'name'=>'dispatch_type','value'=>$tcshopInfo['dispatch_type'],'msg'=>$Lang['tcshop_dispatch_type_msg'],'item'=>$dispatch_type_item),"radio");
    $peisong_type_item = array(1=>$Lang['tcshop_peisong_type_1'],2=>$Lang['tcshop_peisong_type_2'],3=>$Lang['tcshop_peisong_type_3'],4=>$Lang['tcshop_peisong_type_4'],5=>$Lang['tcshop_peisong_type_5'],6=>$Lang['tcshop_peisong_type_6']);
    tomshowsetting(true,array('title'=>$Lang['tcshop_peisong_type'],'name'=>'peisong_type','value'=>$tcshopInfo['peisong_type'],'msg'=>$Lang['tcshop_peisong_type_msg'],'item'=>$peisong_type_item),"radio");
    $open_vip_price_set_item = array(0=>$Lang['tcshop_open_vip_price_set_0'],1=>$Lang['tcshop_open_vip_price_set_1']);
    tomshowsetting(true,array('title'=>$Lang['tcshop_open_vip_price_set'],'name'=>'open_vip_price_set','value'=>$tcshopInfo['open_vip_price_set'],'msg'=>$Lang['tcshop_open_vip_price_set_msg'],'item'=>$open_vip_price_set_item),"radio");
    $open_huodao_pay_item = array(0=>$Lang['tcshop_huodao_pay_0'],1=>$Lang['tcshop_huodao_pay_1']);
    tomshowsetting(true,array('title'=>$Lang['tcshop_huodao_pay'],'name'=>'huodao_pay','value'=>$tcshopInfo['huodao_pay'],'msg'=>$Lang['tcshop_huodao_pay_msg'],'item'=>$open_huodao_pay_item),"radio");
    $open_shop_list_cart_item = array(0=>$Lang['tcshop_open_shop_list_cart_0'],1=>$Lang['tcshop_open_shop_list_cart_1']);
    tomshowsetting(true,array('title'=>$Lang['tcshop_open_shop_list_cart'],'name'=>'open_shop_list_cart','value'=>$tcshopInfo['open_shop_list_cart'],'msg'=>$Lang['tcshop_open_shop_list_cart_msg'],'item'=>$open_shop_list_cart_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['tcshop_mall_shop_picurl'],'name'=>'mall_shop_picurl','value'=>$tcshopInfo['mall_shop_picurl'],'msg'=>$Lang['tcshop_mall_shop_picurl_msg']),"file");
    
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = " AND tcshop_id={$tcshop_id} ";
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $mallCateList = C::t('#tom_tcshop#tom_tcshop_mall_cate')->fetch_all_list("{$where}"," ORDER BY csort ASC,id DESC ",$start,$pagesize);
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['mallSet_name'] . '</th>';
    echo '<th>' . $Lang['mallSet_csort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($mallCateList as $key => $value) {
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['csort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['mallSet_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name       = isset($_GET['name'])? addslashes($_GET['name']):'';
    $csort       = isset($_GET['csort'])? intval($_GET['csort']):10;
    
    $data['tcshop_id'] = $_GET['tcshop_id'];
    $data['name']      = $name;
    $data['csort']     = $csort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'          => '',
        'csort'          => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['mallSet_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['mallSet_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['mallSet_csort'],'name'=>'csort','value'=>$options['csort'],'msg'=>$Lang['mallSet_csort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['mallSet_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['mallSet_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['mallSet_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['mallSet_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['mallSet_edit'],"",true);
    }else{
        tomshownavli($Lang['mallSet_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['mallSet_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}