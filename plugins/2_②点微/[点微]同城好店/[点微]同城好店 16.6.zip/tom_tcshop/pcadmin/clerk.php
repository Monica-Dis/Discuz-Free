<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
if(empty($tcshopInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($tcshopInfo['user_id'] != $__UserInfo['id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=clerk&tcshop_id={$tcshop_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'clerklist' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $page       = intval($_GET['page'])>0 ? intval($_GET['page']) :1;
    $pagesize   = intval($_GET['pagesize'])>0 ? intval($_GET['pagesize']) :10;
    
    $where = " AND tcshop_id={$tcshop_id} ";
    
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_count($where);
    $clerkListTmp = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    $clerkList = array();
    if(!empty($clerkListTmp)){
        foreach($clerkListTmp as $key => $value){
            $clerkList[$key] = $value;
            
            $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
            
            $clerkList[$key]['userInfo'] = $userInfoTmp;
        }
    }
    
    $clerkList = iconv_to_utf8($clerkList);
    
    $outArr = array(
        'code'  => 0,
        'msg'   => '',
        'count' => $count,
        'data'  => $clerkList,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('clerk_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $clerk_id = intval($_GET['clerk_id'])>0 ? intval($_GET['clerk_id']) :0;
    
    $clerkInfo = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_by_id($clerk_id);
    if($clerkInfo['tcshop_id'] != $tcshop_id){
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
    
    C::t('#tom_tcshop#tom_tcshop_clerk')->delete_by_id($clerk_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'add' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id        = intval($_GET['user_id'])>0 ? intval($_GET['user_id']) :0;
    
    $clerkInfoTmp = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(" AND tcshop_id = {$tcshop_id} AND user_id = {$user_id} ");
    if(!empty($clerkInfoTmp[0])){
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $insertData = array();
    $insertData['tcshop_id']    = $tcshop_id;
    $insertData['user_id']      = $user_id;
    $insertData['add_time']     = TIMESTAMP;
    C::t('#tom_tcshop#tom_tcshop_clerk')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && submitcheck('clerk_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $clerk_id       = intval($_GET['clerk_id'])>0 ? intval($_GET['clerk_id']) :0;
    $user_id        = intval($_GET['user_id'])>0 ? intval($_GET['user_id']) :0;
    
    $clerkInfoTmp = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(" AND tcshop_id = {$tcshop_id} AND user_id = {$user_id} ");
    if(!empty($clerkInfoTmp[0])){
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $clerkInfo = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_by_id($clerk_id);
    if($clerkInfo['tcshop_id'] != $tcshop_id){
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['user_id'] = $user_id;
    C::t('#tom_tcshop#tom_tcshop_clerk')->update($clerk_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:pcadmin/clerk");