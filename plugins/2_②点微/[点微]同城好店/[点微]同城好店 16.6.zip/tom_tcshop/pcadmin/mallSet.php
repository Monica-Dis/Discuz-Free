<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
if(empty($tcshopInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($tcshopInfo['user_id'] != $__UserInfo['id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=mallSet&tcshop_id={$tcshop_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $edmoney                = isset($_GET['edmoney'])? floatval($_GET['edmoney']):0.00;
    $dispatch_type          = isset($_GET['dispatch_type'])? intval($_GET['dispatch_type']):0;
    $peisong_type           = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):0;
    $open_vip_price_set     = isset($_GET['open_vip_price_set'])? intval($_GET['open_vip_price_set']):0;
    $huodao_pay             = isset($_GET['huodao_pay'])? intval($_GET['huodao_pay']):0;
    $open_shop_list_cart    = isset($_GET['open_shop_list_cart'])? intval($_GET['open_shop_list_cart']):0;
    $mall_shop_picurl       = isset($_GET['mall_shop_picurl'])? addslashes($_GET['mall_shop_picurl']):'';

    $updateData = array();
    $updateData['edmoney']              = $edmoney;
    $updateData['dispatch_type']        = $dispatch_type;
    if($__Admin['admin'] == 'admin'){
        $updateData['open_vip_price_set']   = $open_vip_price_set;
    }
    $updateData['peisong_type']         = $peisong_type;
    $updateData['mall_shop_picurl']     = $mall_shop_picurl;
    if($tcmallConfig['open_tcshop_huodao_pay'] == 1 || $__Admin['admin'] == 'admin'){
        $updateData['huodao_pay']           = $huodao_pay;
    }
    $updateData['open_shop_list_cart']  = $open_shop_list_cart;
    $updateData['part1']                = TIMESTAMP;
    C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id, $updateData);
        
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'catelist' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $page       = intval($_GET['page'])>0 ? intval($_GET['page']) :1;
    $pagesize   = intval($_GET['pagesize'])>0 ? intval($_GET['pagesize']) :10;
    
    $where = " AND tcshop_id={$tcshop_id} ";
    
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcshop#tom_tcshop_mall_cate')->fetch_all_count($where);
    $mallCateListTmp = C::t('#tom_tcshop#tom_tcshop_mall_cate')->fetch_all_list($where," ORDER BY csort ASC,id DESC ",$start,$pagesize);
    $mallCateList = array();
    if(!empty($mallCateListTmp)){
        foreach($mallCateListTmp as $key => $value){
            $mallCateList[$key] = $value;
        }
    }
    
    $mallCateList = iconv_to_utf8($mallCateList);
    
    $outArr = array(
        'code'  => 0,
        'msg'   => '',
        'count' => $count,
        'data'  => $mallCateList,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('mall_cate_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $mall_cate_id = intval($_GET['mall_cate_id'])>0 ? intval($_GET['mall_cate_id']) :0;
    
    $mallCateInfo = C::t('#tom_tcshop#tom_tcshop_mall_cate')->fetch_by_id($mall_cate_id);
    if($mallCateInfo['tcshop_id'] != $tcshop_id){
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
    
    C::t('#tom_tcshop#tom_tcshop_mall_cate')->delete_by_id($mall_cate_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'add' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $csort          = intval($_GET['csort'])>0 ? intval($_GET['csort']) :0;
    
    $insertData = array();
    $insertData['tcshop_id']    = $tcshop_id;
    $insertData['name']         = $name;
    $insertData['csort']        = $csort;
    C::t('#tom_tcshop#tom_tcshop_mall_cate')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && submitcheck('mall_cate_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $mall_cate_id   = intval($_GET['mall_cate_id'])>0 ? intval($_GET['mall_cate_id']) :0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $csort          = intval($_GET['csort'])>0 ? intval($_GET['csort']) :0;
    
    $mallCateInfo = C::t('#tom_tcshop#tom_tcshop_mall_cate')->fetch_by_id($mall_cate_id);
    if($mallCateInfo['tcshop_id'] != $tcshop_id){
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['name']     = $name;
    $updateData['csort']    = $csort;
    C::t('#tom_tcshop#tom_tcshop_mall_cate')->update($mall_cate_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$mall_shop_picurl = get_file_url($tcshopInfo['mall_shop_picurl']);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:pcadmin/mallSet");