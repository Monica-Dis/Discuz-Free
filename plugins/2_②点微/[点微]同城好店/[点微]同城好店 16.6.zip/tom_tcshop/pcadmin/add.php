<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=add";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $longitude          = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $latitude           = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $shopkeeper_tel     = isset($_GET['shopkeeper_tel'])? addslashes($_GET['shopkeeper_tel']):'';
    $business_hours     = isset($_GET['business_hours'])? addslashes($_GET['business_hours']):'';
    $tabs               = isset($_GET['tabs'])? addslashes($_GET['tabs']):'';
    $zan_txt            = isset($_GET['zan_txt'])? addslashes($_GET['zan_txt']):'';
    $gonggao            = isset($_GET['gonggao'])? addslashes($_GET['gonggao']):'';
    $mp3_url            = isset($_GET['mp3_url'])? addslashes($_GET['mp3_url']):'';
    $vr_url             = isset($_GET['vr_url'])? addslashes($_GET['vr_url']):'';
    $haibao_msg         = isset($_GET['haibao_msg'])? addslashes($_GET['haibao_msg']):'';
    $clicks             = isset($_GET['clicks'])? intval($_GET['clicks']):0;
    $video_pic          = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_url          = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $kefu_qrcode        = isset($_GET['kefu_qrcode'])? addslashes($_GET['kefu_qrcode']):'';
    $business_licence   = isset($_GET['business_licence'])? addslashes($_GET['business_licence']):'';
    $link_name          = isset($_GET['link_name'])? addslashes($_GET['link_name']):'';
    $link               = isset($_GET['link'])? addslashes($_GET['link']):'';
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photothumb_") !== false){
            $kk = intval(ltrim($key, "photothumb_"));
            $photoArr[$kk]['thumb'] = addslashes($value);
        }
        if(strpos($key, "photosort_") !== false){
            $kk = intval(ltrim($key, "photosort_"));
            $photoArr[$kk]['sort'] = addslashes($value);
        }
    }
    
    $focuspicArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "focuspic_") !== false){
            $kk = intval(ltrim($key, "focuspic_"));
            $focuspicArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "focuspicthumb_") !== false){
            $kk = intval(ltrim($key, "focuspicthumb_"));
            $focuspicArr[$kk]['thumb'] = addslashes($value);
        }
    }
    
    $proofArr = array();
    if(isset($_GET['proof']) && !empty($_GET['proof'])){
        foreach($_GET['proof'] as $key => $value){
            $value = addslashes($value);
            if(!empty($value)){
                $proofArr[] = $value;
            }
        }
    }
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['user_id']          = $user_id;
    $insertData['name']             = $name;
    $insertData['cate_id']          = $cate_id;
    $insertData['cate_child_id']    = $cate_child_id;
    $insertData['city_id']          = $city_id;
    $insertData['area_id']          = $area_id;
    $insertData['street_id']        = $street_id;
    $insertData['longitude']        = $longitude;
    $insertData['latitude']         = $latitude;
    $insertData['address']          = $address;
    $insertData['tel']              = $tel;
    $insertData['shopkeeper_tel']   = $shopkeeper_tel;
    $insertData['business_hours']   = $business_hours;
    $insertData['tabs']             = $tabs;
    $insertData['zan_txt']          = $zan_txt;
    $insertData['gonggao']          = $gonggao;
    $insertData['mp3_url']          = $mp3_url;
    $insertData['vr_url']           = $vr_url;
    $insertData['haibao_msg']       = $haibao_msg;
    $insertData['clicks']           = $clicks;
    $insertData['video_pic']        = $video_pic;
    $insertData['video_url']        = $video_url;
    $insertData['admin_edit']       = $admin_edit;
    $insertData['content']          = $content;
    $insertData['picurl']           = $picurl;
    $insertData['kefu_qrcode']      = $kefu_qrcode;
    $insertData['business_licence'] = $business_licence;
    $insertData['link_name']        = $link_name;
    $insertData['link']             = $link;
    $insertData['is_ok']            = 1;
    $insertData['shenhe_status']    = 1;
    $insertData['status']           = 2;
    $insertData['ruzhu_time']       = TIMESTAMP;
    $tcshop_id = C::t('#tom_tcshop#tom_tcshop')->insert($insertData, true);
    if($tcshop_id > 0){
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['tcshop_id'] = $tcshop_id;
                $insertData['picurl']    = $value['picurl'];
                $insertData['thumb']     = $value['thumb'];
                $insertData['paixu']     = $value['sort'];
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcshop#tom_tcshop_photo')->insert($insertData);
            }
        }
        
        if(!empty($picurl)){
            $insertData = array();
            $insertData['tcshop_id'] = $tcshop_id;
            $insertData['picurl']    = $picurl;
            $insertData['type_id']   = 4;
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcshop#tom_tcshop_photo')->insert($insertData);
        }
        
        if(is_array($proofArr) && !empty($proofArr)){
            
            $cateInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($cate_id);
            
            if($cateInfo['open_upload_proof'] == 1){
                foreach ($proofArr as $key => $value){
                    $insertData = array();
                    $insertData['tcshop_id'] = $tcshop_id;
                    $insertData['type_id']   = 3;
                    $insertData['picurl']    = $value;
                    $insertData['add_time']  = TIMESTAMP;
                    C::t('#tom_tcshop#tom_tcshop_photo')->insert($insertData);
                }
            }
        }
        
        if(is_array($focuspicArr) && !empty($focuspicArr)){
            foreach ($focuspicArr as $key => $value){
                $insertData = array();
                $insertData['tcshop_id'] = $tcshop_id;
                $insertData['type_id']   = 2;
                $insertData['picurl']    = $value['picurl'];
                $insertData['thumb']     = $value['thumb'];
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcshop#tom_tcshop_photo')->insert($insertData);
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['parent_id'] > 0){
            $cateChildList[$value['parent_id']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$__CityInfo = array();
if(!empty($tongchengConfig['city_id'])){
    $__CityInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);

$addUrl = $modPcadminUrl."&act=add";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:pcadmin/add");