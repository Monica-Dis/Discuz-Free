<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$express_id = intval($_GET['express_id'])>0 ? intval($_GET['express_id']):0;
$expressInfo = C::t("#tom_tcshop#tom_tcshop_express")->fetch_by_id($express_id);
if(empty($expressInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($expressInfo['tcshop_id']);
if($__Admin['admin'] == 'shopadmin'){
    if($tcshopInfo['user_id'] != $__UserInfo['id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=expressitem&express_id={$express_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('province_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $province_id    = intval($_GET['province_id'])>0 ? intval($_GET['province_id']):0;
    $city_id        = intval($_GET['city_id'])>0 ? intval($_GET['city_id']):0;
    $area_id        = intval($_GET['area_id'])>0 ? intval($_GET['area_id']):0;
    $issendfree     = intval($_GET['issendfree'])>0 ? intval($_GET['issendfree']):0;
    $express_price  = floatval($_GET['express_price'])>0 ? floatval($_GET['express_price']):0;
    
    $provinceInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($province_id);
    $cityInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($city_id);
    $areaInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($area_id);
    
    $insertData = array();
    $insertData['tcshop_id']        = $expressInfo['tcshop_id'];
    $insertData['express_id']       = $express_id;
    $insertData['province_id']      = $province_id;
    $insertData['province_name']    = $provinceInfo['name'];
    $insertData['city_id']          = $city_id;
    $insertData['city_name']        = $cityInfo['name'];
    $insertData['area_id']          = $area_id;
    $insertData['area_name']        = $areaInfo['name'];
    $insertData['issendfree']       = $issendfree;
    $insertData['express_price']    = $express_price;
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tcshop#tom_tcshop_express_item')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && submitcheck('province_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $express_item_id    = intval($_GET['express_item_id'])>0 ? intval($_GET['express_item_id']):0;
    $province_id        = intval($_GET['province_id'])>0 ? intval($_GET['province_id']):0;
    $city_id            = intval($_GET['city_id'])>0 ? intval($_GET['city_id']):0;
    $area_id            = intval($_GET['area_id'])>0 ? intval($_GET['area_id']):0;
    $issendfree         = intval($_GET['issendfree'])>0 ? intval($_GET['issendfree']):0;
    $express_price      = floatval($_GET['express_price'])>0 ? floatval($_GET['express_price']):0;
    
    $provinceInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($province_id);
    $cityInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($city_id);
    $areaInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($area_id);
    
    $expressItemInfo = C::t('#tom_tcshop#tom_tcshop_express_item')->fetch_by_id($express_item_id);
    if($__Admin['admin'] == 'shopadmin'){
        if($expressInfo['id'] != $expressItemInfo['express_id']){
            $outArr = array(
                'code'=> 1001,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $updateData = array();
    $updateData['province_id']      = $province_id;
    $updateData['province_name']    = $provinceInfo['name'];
    $updateData['city_id']          = $city_id;
    $updateData['city_name']        = $cityInfo['name'];
    $insertData['area_id']          = $area_id;
    $insertData['area_name']        = $areaInfo['name'];
    $updateData['issendfree']       = $issendfree;
    $updateData['express_price']    = $express_price;
    C::t('#tom_tcshop#tom_tcshop_express_item')->update($express_item_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('express_item_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $express_item_id = intval($_GET['express_item_id'])>0 ? intval($_GET['express_item_id']):0; 
    
    $expressItemInfo = C::t('#tom_tcshop#tom_tcshop_express_item')->fetch_by_id($express_item_id);
    if($__Admin['admin'] == 'shopadmin'){
        if($expressInfo['id'] != $expressItemInfo['express_id']){
            $outArr = array(
                'code'=> 1001,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    C::t('#tom_tcshop#tom_tcshop_express_item')->delete_by_id($express_item_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('express_item_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $express_item_id = intval($_GET['express_item_id'])>0? intval($_GET['express_item_id']):0;
    
    $expressItemInfo = C::t('#tom_tcshop#tom_tcshop_express_item')->fetch_by_id($express_item_id);
    if($__Admin['admin'] == 'shopadmin'){
        if($expressInfo['id'] != $expressItemInfo['express_id']){
            $outArr = array(
                'code'=> 1001,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $list = iconv_to_utf8($expressItemInfo);
    $outArr = array(
        'code'  => 200,
        "data"  => $list
    );
    echo json_encode($outArr); exit;
}

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$provinceListTmp = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_level(1);
$provinceList = array();
if(is_array($provinceListTmp) && !empty($provinceListTmp)){
    foreach($provinceListTmp as $key => $value){
        $provinceList[$key] = $value;
    }
}

$where = " AND express_id = {$express_id} ";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcshop#tom_tcshop_express_item')->fetch_all_count($where);
$expressItemListTmp = C::t('#tom_tcshop#tom_tcshop_express_item')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$expressItemList = array();
if(is_array($expressItemListTmp) && !empty($expressItemListTmp)){
    foreach($expressItemListTmp as $key => $value) {
        $expressItemList[$key] = $value;
        
        $expressItemList[$key]['add_time']      = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:pcadmin/expressitem");