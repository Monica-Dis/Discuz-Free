<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=pinglun";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('pinglun_id')){
    $outArr = array(
        'code'=> 1,
    );

    $pinglun_id = intval($_GET['pinglun_id'])>0? intval($_GET['pinglun_id']):0;

    C::t('#tom_tcshop#tom_tcshop_pinglun')->delete($pinglun_id);
    C::t('#tom_tcshop#tom_tcshop_pinglun_reply')->delete_pinglun_id($pinglun_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('pinglun_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $pinglunIdsArr = array();
    if(is_array($_GET['pinglun_ids'])){
        foreach($_GET['pinglun_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $pinglunIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($pinglunIdsArr)){
        foreach ($pinglunIdsArr as $key => $value){
            C::t('#tom_tcshop#tom_tcshop_pinglun')->delete($value);
            C::t('#tom_tcshop#tom_tcshop_pinglun_reply')->delete_pinglun_id($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$tcshop_id  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = '';
if($user_id > 0){
    $where .= " AND user_id={$user_id} ";
}
if($tcshop_id > 0){
    $where .= " AND tcshop_id={$tcshop_id} ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcshop#tom_tcshop_pinglun')->fetch_all_count($where);
$pinglunListTmp = C::t('#tom_tcshop#tom_tcshop_pinglun')->fetch_all_list($where,"ORDER BY ping_time DESC",$start,$pagesize);
$pinglunList = array();
if(!empty($pinglunListTmp)){
    foreach($pinglunListTmp as $key => $value){
        $pinglunList[$key] = $value;
        
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $pinglunList[$key]['tcshopInfo']    = $tcshopInfoTmp;
        $pinglunList[$key]['userInfo']      = $userInfoTmp;
        $pinglunList[$key]['ping_time']     = dgmdate($value['ping_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&tcshop_id={$tcshop_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:pcadmin/pinglun");