<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']) : 0;

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
if(empty($tcshopInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($tcshopInfo['user_id'] != $__UserInfo['id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$vipInfo = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($tcshopInfo['vip_id']);

$modPcadminUrl = $pcadminUrl."&tmod=edit&tcshop_id={$tcshop_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $longitude          = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $latitude           = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $shopkeeper_tel     = isset($_GET['shopkeeper_tel'])? addslashes($_GET['shopkeeper_tel']):'';
    $business_hours     = isset($_GET['business_hours'])? addslashes($_GET['business_hours']):'';
    $tabs               = isset($_GET['tabs'])? addslashes($_GET['tabs']):'';
    $zan_txt            = isset($_GET['zan_txt'])? addslashes($_GET['zan_txt']):'';
    $gonggao            = isset($_GET['gonggao'])? addslashes($_GET['gonggao']):'';
    $mp3_url            = isset($_GET['mp3_url'])? addslashes($_GET['mp3_url']):'';
    $vr_url             = isset($_GET['vr_url'])? addslashes($_GET['vr_url']):'';
    $haibao_msg         = isset($_GET['haibao_msg'])? addslashes($_GET['haibao_msg']):'';
    $clicks             = isset($_GET['clicks'])? intval($_GET['clicks']):0;
    $video_pic          = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_url          = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $kefu_qrcode        = isset($_GET['kefu_qrcode'])? addslashes($_GET['kefu_qrcode']):'';
    $business_licence   = isset($_GET['business_licence'])? addslashes($_GET['business_licence']):'';
    
    $link_name          = isset($_GET['link_name'])? addslashes($_GET['link_name']):'';
    $link               = isset($_GET['link'])? addslashes($_GET['link']):'';
    $open_yuyue         = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $tcyuyue_id         = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
    
    if($__Admin['admin'] == 'shopadmin'){
        $site_id = $tcshopInfo['site_id'];
    }
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photothumb_") !== false){
            $kk = intval(ltrim($key, "photothumb_"));
            $photoArr[$kk]['thumb'] = addslashes($value);
        }
        if(strpos($key, "photosort_") !== false){
            $kk = intval(ltrim($key, "photosort_"));
            $photoArr[$kk]['sort'] = addslashes($value);
        }
    }
    
    $focuspicArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "focuspic_") !== false){
            $kk = intval(ltrim($key, "focuspic_"));
            $focuspicArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "focuspicthumb_") !== false){
            $kk = intval(ltrim($key, "focuspicthumb_"));
            $focuspicArr[$kk]['thumb'] = addslashes($value);
        }
    }
    
    $proofArr = array();
    if(isset($_GET['proof']) && !empty($_GET['proof'])){
        foreach($_GET['proof'] as $key => $value){
            $value = addslashes($value);
            if(!empty($value)){
                $proofArr[] = $value;
            }
        }
    }
    
    $updateData = array();
    if($__Admin['admin'] == 'admin'){
        $updateData['site_id']          = $site_id;
        $updateData['user_id']          = $user_id;
        $updateData['clicks']           = $clicks;
    }
    $updateData['name']             = $name;
    $updateData['cate_id']          = $cate_id;
    $updateData['cate_child_id']    = $cate_child_id;
    $updateData['city_id']          = $city_id;
    $updateData['area_id']          = $area_id;
    $updateData['street_id']        = $street_id;
    $updateData['longitude']        = $longitude;
    $updateData['latitude']         = $latitude;
    $updateData['address']          = $address;
    $updateData['tel']              = $tel;
    $updateData['shopkeeper_tel']   = $shopkeeper_tel;
    $updateData['business_hours']   = $business_hours;
    $updateData['tabs']             = $tabs;
    $updateData['haibao_msg']       = $haibao_msg;
    $updateData['open_yuyue']       = $open_yuyue;
    $updateData['tcyuyue_id']       = $tcyuyue_id;
    if($vipInfo['open_zan'] == 1 || $__Admin['admin'] == 'admin'){
        $updateData['zan_txt']          = $zan_txt;
    }
    if($vipInfo['open_gonggao'] == 1 || $__Admin['admin'] == 'admin'){
        $updateData['gonggao']          = $gonggao;
    }
    if($vipInfo['open_mp3'] == 1 || $__Admin['admin'] == 'admin'){
        $updateData['mp3_url']          = $mp3_url;
    }
    if($vipInfo['open_vr'] == 1 || $__Admin['admin'] == 'admin'){
        $updateData['vr_url']           = $vr_url;
    }
    if($vipInfo['open_video'] == 1 || $__Admin['admin'] == 'admin'){
        $updateData['video_pic']        = $video_pic;
        $updateData['video_url']        = $video_url;
    }
    $updateData['admin_edit']       = $admin_edit;
    $updateData['content']          = $content;
    $updateData['picurl']           = $picurl;
    $updateData['kefu_qrcode']      = $kefu_qrcode;
    $updateData['business_licence'] = $business_licence;
    
    if($__Admin['admin'] == 'admin'){
        $updateData['link_name']        = $link_name;
        $updateData['link']             = $link;
    }
    
    if($tcshopInfo['lbs_status'] == 1){
        $updateData['lbs_status']       = 2;
    }
    
    if($__Admin['admin'] == 'shopadmin' && $tcshopConfig['must_shenhe'] == 1){
        $insertData['shenhe_status']       = 2;
    }else{
        $insertData['shenhe_status']       = 1;
    }
    
    $updateData['part1']            = TIMESTAMP;
    C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id, $updateData);
        
    C::t('#tom_tcshop#tom_tcshop_photo')->delete_by_tcshop_id($tcshop_id);
    if(is_array($photoArr) && !empty($photoArr)){
        foreach ($photoArr as $key => $value){
            $insertData = array();
            $insertData['tcshop_id'] = $tcshop_id;
            $insertData['picurl']    = $value['picurl'];
            $insertData['thumb']     = $value['thumb'];
            $insertData['paixu']     = $value['sort'];
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcshop#tom_tcshop_photo')->insert($insertData);
        }
    }

    C::t('#tom_tcshop#tom_tcshop_photo')->delete_by_tcshop_id_avatar($tcshop_id);
    if(!empty($picurl)){
        $insertData = array();
        $insertData['tcshop_id'] = $tcshop_id;
        $insertData['picurl']    = $picurl;
        $insertData['type_id']   = 4;
        $insertData['add_time']  = TIMESTAMP;
        C::t('#tom_tcshop#tom_tcshop_photo')->insert($insertData);
    }

    $proofListTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(" AND tcshop_id={$tcshopInfo['id']} AND type_id = 3 "," ORDER BY paixu ASC,id ASC ",0,50);
    if($tcshopConfig['open_not_edit_proof'] == 1 && count($proofListTmp) > 0 && $tcshopInfo['shenhe_status'] == 1){
    }else{
        C::t('#tom_tcshop#tom_tcshop_photo')->delete_by_tcshop_id_proof($tcshop_id);
        if(is_array($proofArr) && !empty($proofArr)){
            $cateInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($cate_id);
            if($cateInfo['open_upload_proof'] == 1){
                foreach ($proofArr as $key => $value){
                    $insertData = array();
                    $insertData['tcshop_id'] = $tcshop_id;
                    $insertData['type_id']   = 3;
                    $insertData['picurl']    = $value;
                    $insertData['add_time']  = TIMESTAMP;
                    C::t('#tom_tcshop#tom_tcshop_photo')->insert($insertData);
                }
            }
        }
    }

    C::t('#tom_tcshop#tom_tcshop_photo')->delete_by_tcshop_id_focuspic($tcshop_id);
    if(is_array($focuspicArr) && !empty($focuspicArr)){
        foreach ($focuspicArr as $key => $value){
            $insertData = array();
            $insertData['tcshop_id'] = $tcshop_id;
            $insertData['type_id']   = 2;
            $insertData['picurl']    = $value['picurl'];
            $insertData['thumb']     = $value['thumb'];
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcshop#tom_tcshop_photo')->insert($insertData);
        }
    }

    if($__Admin['admin'] == 'shopadmin' && $tcshopConfig['must_shenhe'] == 1){
        
        if($tcshopInfo['site_id'] > 1){
            $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcshopInfo['site_id']);
            $manage_user_id = $siteInfo['manage_user_id'];
            $site_name = $siteInfo['name'];
        }else{
            $manage_user_id = $tongchengConfig['manage_user_id'];
            $site_name = $tongchengConfig['plugin_name'];
        }

        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($manage_user_id);

        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($toUser['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcshop&site={$tcshopInfo['site_id']}&mod=index");
            $shenhe_template_edit = $Lang['shenhe_template_edit'];
            $shenhe_template_edit = str_replace("{SHOPNAME}",$tcshopInfo['name'],$shenhe_template_edit);
            $smsData = array(
                'first'         => $shenhe_template_edit,
                'keyword1'      => $site_name,
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );
            @$r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
        }
    }

    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
        
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['parent_id'] > 0){
            $cateChildList[$value['parent_id']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$tcshopInfo['content'] = stripcslashes($tcshopInfo['content']);

$city_id = 0;
if($tcshopInfo['site_id'] > 1){
    $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcshopInfo['site_id']);
    if($sitesInfoTmp){
        if(!empty($sitesInfoTmp['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
            if($cityInfoTmp){
                $city_id = $cityInfoTmp['id'];
            }
        }
    }
}else if($tcshopInfo['site_id'] == 1){
    $cityInfoTmp = array();
    if(!empty($tongchengConfig['city_id'])){
        $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
    }
    if(!empty($cityInfoTmp)){
        $city_id = $cityInfoTmp['id'];
    }
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($city_id);
$areaList = array();
if(!empty($areaListTmp)){
    foreach($areaListTmp as $key => $value){
        $areaList[$value['id']] = $value;
    }
}

$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($tcshopInfo['area_id']);
$streetList = array();
if(!empty($streetListTmp)){
    foreach($streetListTmp as $key => $value){
        $streetList[$value['id']] = $value;
    }
}

if($__ShowTcyuyue == 1){
    $tcyuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list(" AND tcshop_id = {$tcshopInfo['id']} AND type = 1 AND status = 1 AND shenhe_status = 1 ");
    $tcyuyueList = array();
    if(is_array($tcyuyueListTmp) && !empty($tcyuyueListTmp)){
        foreach($tcyuyueListTmp as $key => $value){
            $tcyuyueList[$key] = $value;
        }
    }
}


$picurl = get_file_url($tcshopInfo['picurl']);
$kefu_qrcode = get_file_url($tcshopInfo['kefu_qrcode']);
$business_licence = get_file_url($tcshopInfo['business_licence']);
$video_pic = get_file_url($tcshopInfo['video_pic']);

$tcshopPhotoListTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(" AND tcshop_id={$tcshopInfo['id']} AND type_id IN(1,2,3) "," ORDER BY paixu ASC,id ASC ",0,100);
$tcshopPhotoList = $focupicList = $proofList = array();
$photoCount = 0;
if(is_array($tcshopPhotoListTmp) && !empty($tcshopPhotoListTmp)){
    foreach ($tcshopPhotoListTmp as $kk => $vv){
        $photoCount++;
        
        $picurlTmp = get_file_url($vv['picurl']);
        if($vv['type_id'] == 1){
            $tcshopPhotoList[$kk] = $vv;
            $tcshopPhotoList[$kk]['src'] = $picurlTmp;
            $tcshopPhotoList[$kk]['li_i'] = $photoCount;
        }else if($vv['type_id'] == 2){
            $focupicList[$kk] = $vv;
            $focupicList[$kk]['src'] = $picurlTmp;
            $focupicList[$kk]['li_i'] = $photoCount;
        }else if($vv['type_id'] == 3){
            $proofList[$kk] = $vv;
            $proofList[$kk]['src'] = $picurlTmp;
            $proofList[$kk]['li_i'] = $photoCount;
        }
    }
}
$proofCount = count($proofList);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:pcadmin/edit");