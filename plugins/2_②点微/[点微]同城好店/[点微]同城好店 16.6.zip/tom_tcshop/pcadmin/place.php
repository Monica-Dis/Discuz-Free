<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
$tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
if(empty($tcshopInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($tcshopInfo['user_id'] != $__UserInfo['id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=place&tcshop_id={$tcshop_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $longitude      = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $latitude       = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address        = isset($_GET['address'])? addslashes($_GET['address']):'';
    $status         = intval($_GET['status'])>0 ? intval($_GET['status']):0;
    $psort          = intval($_GET['psort'])>0 ? intval($_GET['psort']):10;
    
    $insertData = array();
    $insertData['tcshop_id']        = $tcshop_id;
    $insertData['name']             = $name;
    $insertData['tel']              = $tel;
    $insertData['longitude']        = $longitude;
    $insertData['latitude']         = $latitude;
    $insertData['address']          = $address;
    $insertData['status']           = $status;
    $insertData['psort']            = $psort;
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tcshop#tom_tcshop_place')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && submitcheck('place_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $place_id       = intval($_GET['place_id'])>0 ? intval($_GET['place_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $longitude      = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $latitude       = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address        = isset($_GET['address'])? addslashes($_GET['address']):'';
    $status         = intval($_GET['status'])>0 ? intval($_GET['status']):0;
    $psort          = intval($_GET['psort'])>0 ? intval($_GET['psort']):10;
    
    $placeInfo = C::t('#tom_tcshop#tom_tcshop_place')->fetch_by_id($place_id);
    if($__Admin['admin'] == 'shopadmin'){
        if($tcshopInfo['id'] != $placeInfo['tcshop_id']){
            $outArr = array(
                'code'=> 1001,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $updateData = array();
    $updateData['name']             = $name;
    $updateData['tel']              = $tel;
    $updateData['longitude']        = $longitude;
    $updateData['latitude']         = $latitude;
    $updateData['address']          = $address;
    $updateData['status']           = $status;
    $updateData['psort']            = $psort;
    $updateData['add_time']         = TIMESTAMP;
    C::t('#tom_tcshop#tom_tcshop_place')->update($place_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('place_id')){
    $outArr = array(
        'code'=> 1,
    );

    $place_id = intval($_GET['place_id'])>0 ? intval($_GET['place_id']):0;
    
    $placeInfo = C::t('#tom_tcshop#tom_tcshop_place')->fetch_by_id($place_id);
    if($__Admin['admin'] == 'shopadmin'){
        if($tcshopInfo['id'] != $placeInfo['tcshop_id']){
            $outArr = array(
                'code'=> 1001,
            );
            echo json_encode($outArr); exit;
        }
    }

    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcshop#tom_tcshop_place')->update($place_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('place_id')){
    $outArr = array(
        'code'=> 1,
    );

    $place_id = intval($_GET['place_id'])>0 ? intval($_GET['place_id']):0;
    
    $placeInfo = C::t('#tom_tcshop#tom_tcshop_place')->fetch_by_id($place_id);
    if($__Admin['admin'] == 'shopadmin'){
        if($tcshopInfo['id'] != $placeInfo['tcshop_id']){
            $outArr = array(
                'code'=> 1001,
            );
            echo json_encode($outArr); exit;
        }
    }

    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcshop#tom_tcshop_place')->update($place_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('place_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $place_id = intval($_GET['place_id'])>0 ? intval($_GET['place_id']):0;
    
    $placeInfo = C::t('#tom_tcshop#tom_tcshop_place')->fetch_by_id($place_id);
    if($__Admin['admin'] == 'shopadmin'){
        if($tcshopInfo['id'] != $placeInfo['tcshop_id']){
            $outArr = array(
                'code'=> 1001,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    C::t('#tom_tcshop#tom_tcshop_place')->delete_by_id($place_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('place_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $place_id = intval($_GET['place_id'])>0? intval($_GET['place_id']):0;
    
    $placeInfo = C::t('#tom_tcshop#tom_tcshop_place')->fetch_by_id($place_id);
    if($__Admin['admin'] == 'shopadmin'){
        if($tcshopInfo['id'] != $placeInfo['tcshop_id']){
            $outArr = array(
                'code'=> 1001,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $list = iconv_to_utf8($placeInfo);
    $outArr = array(
        'code'  => 200,
        "data"  => $list
    );
    echo json_encode($outArr); exit;
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = " AND tcshop_id = {$tcshop_id} ";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcshop#tom_tcshop_place')->fetch_all_count($where);
$placeListTmp = C::t('#tom_tcshop#tom_tcshop_place')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$placeList = array();
if(is_array($placeListTmp) && !empty($placeListTmp)){
    foreach($placeListTmp as $key => $value) {
        $placeList[$key] = $value;
        
        $placeList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:pcadmin/place");