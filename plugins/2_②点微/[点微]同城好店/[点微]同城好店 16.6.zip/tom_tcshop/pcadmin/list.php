<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=list";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'show' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcshop_id = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;

    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcshop_id = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;

    $updateData = array();
    $updateData['status']     = 2;
    C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'edit_pay_status' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcshop_id  = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
    $pay_status = intval($_GET['pay_status'])>0 ? intval($_GET['pay_status']):0;

    $updateData = array();
    $updateData['pay_status']     = $pay_status;
    C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'shenhe' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcshop_id      = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcshopInfo['user_id']);
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status']     = 1;
        C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id,$updateData);

        $shenhe = str_replace('{SHOPNAME}', $tcshopInfo['name'], $Lang['template_tcshop_shenhe_ok']);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcshop&site={$tcshopInfo['site_id']}&mod=details&tcshop_id=".$tcshopInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcshopConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }

        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcshopConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcshop#tom_tcshop')->update($tcshopInfo['id'],$updateData);
        
        $shenhe = str_replace('{SHOPNAME}', $tcshopInfo['name'], $Lang['template_tcshop_shenhe_no']);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcshop&site={$tcshopInfo['site_id']}&mod=edit&tcshop_id=".$tcshopInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcshopConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcshopConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tcshop_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}else if($act == 'editvip' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcshop_id      = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0; 
    $vip_id         = intval($_GET['vip_id'])>0? intval($_GET['vip_id']):0;
    $vip_time       = isset($_GET['vip_time'])? addslashes($_GET['vip_time']):'';
    $vip_time       = strtotime($vip_time);
    
    $vipInfo = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($vip_id);

    $updateData = array();
    if($vip_time > TIMESTAMP){
        $updateData['vip_status'] = 1;
        $updateData['vip_rank']   = $vipInfo['rank'];
    }else{
        $updateData['vip_status'] = 2;
        $updateData['vip_rank']   = 0;
    }
    $updateData['vip_id']   = $vip_id;
    $updateData['vip_time'] = $vip_time;
    C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'edittop' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcshop_id      = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0; 
    $toptime        = isset($_GET['toptime'])? addslashes($_GET['toptime']):'';
    $toptime        = strtotime($toptime);
    
    $updateData = array();
    if($toptime < TIMESTAMP){
        $updateData['topstatus']    = 0;
        $updateData['toprand']      = 1;
        $updateData['refresh_time'] = 0;
    }else{
        $updateData['topstatus']    = 1;
        $updateData['toprand']      = 10000;
        $updateData['refresh_time'] = TIMESTAMP;
    }
    $updateData['toptime'] = $toptime;
    C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'edithexiao' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcshop_id      = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0; 
    $hexiao_type    = isset($_GET['hexiao_type'])? intval($_GET['hexiao_type']):0;
    
    $updateData = array();
    $updateData['hexiao_type'] = $hexiao_type;
    C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcshop_id      = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0; 
    
    C::t('#tom_tcshop#tom_tcshop')->delete_by_id($tcshop_id);
    C::t('#tom_tcshop#tom_tcshop_photo')->delete_all_tcshop_id($tcshop_id);
    C::t('#tom_tcshop#tom_tcshop_express')->delete_all_tcshop_id($tcshop_id);
    C::t('#tom_tcshop#tom_tcshop_express_item')->delete_all_tcshop_id($tcshop_id);
    C::t('#tom_tcshop#tom_tcshop_place')->delete_all_tcshop_id($tcshop_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$keyword        = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$tcshop_id      = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
$site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
$cate_child_id  = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
$shenhe_status  = isset($_GET['shenhe_status']) ? intval($_GET['shenhe_status']) : 0;
$topstatus      = isset($_GET['topstatus']) ? intval($_GET['topstatus']) : 0;
$over_status    = isset($_GET['over_status']) ? intval($_GET['over_status']) : 0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['parent_id'] > 0){
            $cateChildList[$value['parent_id']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$whereStr = '';
if($site_id > 0){
    $where.= " AND site_id={$site_id} ";
}
if($tcshop_id > 0){
    $where.= " AND id={$tcshop_id} ";
}
if($user_id > 0){
    $where.= " AND user_id={$user_id} ";
}
if($cate_id > 0){
    $where.= " AND cate_id={$cate_id} ";
}
if($cate_child_id > 0){
    $where.= " AND cate_child_id={$cate_child_id} ";
}
if($shenhe_status > 0){
    $where.= " AND shenhe_status = {$shenhe_status} ";
}
if($topstatus > 0){
    $where.= " AND topstatus = {$topstatus} ";
}
if($over_status > 0){
    $where.= " AND shenhe_status = 1 AND is_ok = 1 ";
    if($over_status == 1){
        $where.= " AND vip_status = 2 ";
    }
    $over_time = TIMESTAMP + 86400*30;
    if($over_status == 2){
        $where.= " AND vip_status = 1 AND vip_time < {$over_time} ";
    }
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count($where,$keyword);
$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize,$keyword);
$tcshopList = array();
if(!empty($tcshopListTmp)){
    foreach ($tcshopListTmp as $key => $value) {
        $tcshopList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $siteInfoTmp = $sitesList[$value['site_id']];
        $cateInfoTmp = $cateList[$value['cate_id']];
        $cateChildInfoTmp = $cateList[$value['cate_id']]['cateChildList'][$value['cate_child_id']];
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
        $vipInfoTmp = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($value['vip_id']);
        
        if($value['tj_hehuoren_id'] && $__ShowTchehuoren == 1){
            $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($value['tj_hehuoren_id']);
            $tjUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tchehuorenInfoTmp['user_id']); 
            //$tjHehuoren = '<font color="#0a9409">'.$tjUserInfoTmp['nickname'].'('.$tchehuorenInfoTmp['id'].')</font>';
        }
        
        $tcshopList[$key]['picurl'] = get_file_url($value['picurl']);
        if(!empty($value['business_licence'])){
            $tcshopList[$key]['business_licence'] = get_file_url($value['business_licence']);
        }else{
            $tcshopList[$key]['business_licence'] = 'source/plugin/tom_tcshop/images/business_licence.png';
        }
        
        $proofListTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(" AND tcshop_id={$value['id']} AND type_id = 3 "," ORDER BY paixu ASC,id ASC ",0,50);
        $proofList = array();
        if(is_array($proofListTmp) && !empty($proofListTmp)){
            foreach ($proofListTmp as $kk => $vv){
                $proofList[$kk]['picurl'] = get_file_url($vv['picurl']);
            }
        }
        
        $tcshopList[$key]['userInfo']       = $userInfoTmp;
        $tcshopList[$key]['cateInfo']       = $cateInfoTmp;
        $tcshopList[$key]['cateChildInfo']  = $cateChildInfoTmp;
        $tcshopList[$key]['siteInfo']       = $siteInfoTmp;
        $tcshopList[$key]['areaInfo']       = $areaInfoTmp;
        $tcshopList[$key]['streetInfo']     = $streetInfoTmp;
        $tcshopList[$key]['vipInfo']        = $vipInfoTmp;
        $tcshopList[$key]['proofList']      = $proofList;
        
        if($value['tj_hehuoren_id'] && $__ShowTchehuoren == 1){
            $tcshopList[$key]['tjUserInfo']     = $tjUserInfoTmp;
        }else{
            $tcshopList[$key]['tj_hehuoren_id'] = 0;
        }
        
        $tcshopList[$key]['ruzhu_time']     = dgmdate($value['ruzhu_time'],"Y-m-d H:i",$tomSysOffset);
        $tcshopList[$key]['vip_time']       = dgmdate($value['vip_time'],"Y-m-d H:i",$tomSysOffset);
        $tcshopList[$key]['base_time']      = dgmdate($value['base_time'],"Y-m-d H:i",$tomSysOffset);
        $tcshopList[$key]['toptime']        = dgmdate($value['toptime'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&user_id={$user_id}&keyword={$keyword}&shenhe_status={$shenhe_status}&over_status={$over_status}&cate_id={$cate_id}&cate_child_id={$cate_child_id}&topstatus={$topstatus}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:pcadmin/list");