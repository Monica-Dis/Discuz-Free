<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
$tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
if(empty($tcshopInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($tcshopInfo['user_id'] != $__UserInfo['id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=express&tcshop_id={$tcshop_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('title')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $issendfree     = intval($_GET['issendfree'])>0 ? intval($_GET['issendfree']):0;
    $default_price  = floatval($_GET['default_price'])>0 ? floatval($_GET['default_price']):0;
    
    $insertData = array();
    $insertData['tcshop_id']        = $tcshop_id;
    $insertData['title']            = $title;
    $insertData['issendfree']       = $issendfree;
    $insertData['default_price']    = $default_price;
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tcshop#tom_tcshop_express')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && submitcheck('title')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $express_id     = intval($_GET['express_id'])>0 ? intval($_GET['express_id']):0;
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $issendfree     = intval($_GET['issendfree'])>0 ? intval($_GET['issendfree']):0;
    $default_price  = floatval($_GET['default_price'])>0 ? floatval($_GET['default_price']):0;
    
    $expressInfo = C::t('#tom_tcshop#tom_tcshop_express')->fetch_by_id($express_id);
    if($__Admin['admin'] == 'shopadmin'){
        if($tcshopInfo['id'] != $expressInfo['tcshop_id']){
            $outArr = array(
                'code'=> 1001,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $updateData = array();
    $updateData['title']            = $title;
    $updateData['issendfree']       = $issendfree;
    $updateData['default_price']    = $default_price;
    C::t('#tom_tcshop#tom_tcshop_express')->update($express_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('express_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $express_id = intval($_GET['express_id'])>0 ? intval($_GET['express_id']):0; 
    
    $expressInfo = C::t('#tom_tcshop#tom_tcshop_express')->fetch_by_id($express_id);
    if($__Admin['admin'] == 'shopadmin'){
        if($tcshopInfo['id'] != $expressInfo['tcshop_id']){
            $outArr = array(
                'code'=> 1001,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    C::t('#tom_tcshop#tom_tcshop_express')->delete_by_id($express_id);
    C::t('#tom_tcshop#tom_tcshop_express_item')->delete_by_express_id($express_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('express_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $express_id = intval($_GET['express_id'])>0? intval($_GET['express_id']):0;
    
    $expressInfo = C::t('#tom_tcshop#tom_tcshop_express')->fetch_by_id($express_id);
    if($__Admin['admin'] == 'shopadmin'){
        if($tcshopInfo['id'] != $expressInfo['tcshop_id']){
            $outArr = array(
                'code'=> 1001,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $list = iconv_to_utf8($expressInfo);
    $outArr = array(
        'code'  => 200,
        "data"  => $list
    );
    echo json_encode($outArr); exit;
}

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = " AND tcshop_id = {$tcshop_id} ";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcshop#tom_tcshop_express')->fetch_all_count($where);
$expressListTmp = C::t('#tom_tcshop#tom_tcshop_express')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$expressList = array();
if(is_array($expressListTmp) && !empty($expressListTmp)){
    foreach($expressListTmp as $key => $value) {
        $expressList[$key] = $value;
        
        $expressList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:pcadmin/express");