<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20201029";

$pcadminUrl = 'plugin.php?id=tom_tcshop:pcadmin';
$ajaxUrl = 'plugin.php?id=tom_admin:ajax';
$uploadUrl = 'plugin.php?id=tom_admin:upload';
$baidumapUrl = 'plugin.php?id=tom_admin:baidumap';

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcshop/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcshop/config/pcadmin.lang.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

$Lang = $pcadminLang;

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcmall start
$__ShowTcmall = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcmall/tom_tcmall.inc.php')){
    $tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
    if($tcmallConfig['open_tcmall'] == 1){
        $__ShowTcmall = 1;
    }
}
## tcmall end
## tcyuyue start
$__ShowTcyuyue = 0;
$tcyuyueConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/tom_tcyuyue.inc.php')){
    $tcyuyueConfig = $_G['cache']['plugin']['tom_tcyuyue'];
    if($tcyuyueConfig['open_tcyuyue'] == 1){
        $__ShowTcyuyue = 1;
    }
}
## tcyuyue end

include DISCUZ_ROOT.'./source/plugin/tom_admin/login_check.php';

if($__Admin['admin'] == 'shopadmin'){
    
    if($_GET['tmod'] == 'list'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcshopadmin/list.php';
    }else if($_GET['tmod'] == 'edit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/edit.php';
    }else if($_GET['tmod'] == 'mallSet' && $__ShowTcmall == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/mallSet.php';
    }else if($_GET['tmod'] == 'clerk'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/clerk.php';
    }else if($_GET['tmod'] == 'pinglun'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcshopadmin/pinglun.php';
    }else if($_GET['tmod'] == 'pinglunReplay'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcshopadmin/pinglunReplay.php';
    }else if($_GET['tmod'] == 'express'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/express.php';
    }else if($_GET['tmod'] == 'expressitem'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/expressitem.php';
    }else if($_GET['tmod'] == 'place'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/place.php';
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcshopadmin/list.php';
    }
    
}else if($__Admin['admin'] == 'admin'){
    
    if($_GET['tmod'] == 'list'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/list.php';
    }else if($_GET['tmod'] == 'viplog'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/viplog.php';
    }else if($_GET['tmod'] == 'add'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/add.php';
    }else if($_GET['tmod'] == 'edit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/edit.php';
    }else if($_GET['tmod'] == 'clerk'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/clerk.php';
    }else if($_GET['tmod'] == 'pinglun'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/pinglun.php';
    }else if($_GET['tmod'] == 'pinglunReplay'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/pinglunReplay.php';
    }else if($_GET['tmod'] == 'mallSet' && $__ShowTcmall == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/mallSet.php';
    }else if($_GET['tmod'] == 'focuspic'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/focuspic.php';
    }else if($_GET['tmod'] == 'focuspicadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/focuspicadd.php';
    }else if($_GET['tmod'] == 'focuspicedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/focuspicedit.php';
    }else if($_GET['tmod'] == 'express'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/express.php';
    }else if($_GET['tmod'] == 'expressitem'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/expressitem.php';
    }else if($_GET['tmod'] == 'place'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/place.php';
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/pcadmin/list.php';
    }
}