<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
 * 
 * hexiao_type   0 ������   1 ��Ա����   2 �������
 * 
 * peisong_type   1 ������ȡ  2 �ͻ�����   3 ����ͻ�   4 ��ȡ+���   5 ��ȡ+�ͻ�   6 ��ȡ+�ͻ�+���
 * 
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tcshop extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dism �� taobao �� com*/
		$this->_table = 'tom_tcshop';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
    
    public function fetch_all_user_ids($condition) {
        $data = DB::fetch_all("SELECT user_id FROM %t WHERE 1 %i",array($this->_table,$condition));
        return $data;
    }
    
    public function fetch_by_name($name,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE name=%s", array($this->_table, $name));
	}
	
    public function fetch_all_list($condition,$orders = '',$start = 0,$limit = 10,$name = '',$address = '',$tabs = '') {
        if(!empty($name)){
            $name = str_replace(array('%', '_'),'',$name);
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i AND (name LIKE %s OR content LIKE %s OR tabs LIKE %s) $orders LIMIT $start,$limit",array($this->_table,$condition,'%'.$name.'%','%'.$name.'%','%'.$name.'%'));
        }else if(!empty($address)){
            $address = str_replace(array('%', '_'),'',$address);
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i AND address LIKE %s $orders LIMIT $start,$limit",array($this->_table,$condition,'%'.$address.'%'));
        }else if(!empty($tabs)){
            $tabs = str_replace(array('%', '_'),'',$tabs);
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i AND tabs LIKE %s $orders LIMIT $start,$limit",array($this->_table,$condition,'%'.$tabs.'%'));
        }else{
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        }
		return $data;
	}
    
    public function fetch_all_nearby_list($condition,$start = 0,$limit = 10,$lat='',$lng='') {
        $data = DB::fetch_all("SELECT *,acos(cos($lat*pi()/180 )*cos(latitude*pi()/180)*cos($lng*pi()/180 -longitude*pi()/180)+sin($lat*pi()/180 )*sin(latitude*pi()/180))*6370996.81/1000  as distance FROM %t WHERE 1 %i ORDER BY distance ASC,id DESC  LIMIT $start,$limit",array($this->_table,$condition));
		return $data;
	}
    
    public function fetch_all_list_and_cate($condition,$orders = '',$start = 0,$limit = 10) {
        $data = DB::fetch_all('SELECT s.*, c.name AS cate_name,c.tc114_cate_id AS cate_tc114_cate_id FROM '.DB::table('tom_tcshop').' s LEFT JOIN '.DB::table('tom_tcshop_cate')." c ON s.cate_id = c.id  WHERE 1 %i $orders LIMIT $start,$limit",array($condition));
        return $data;
    }
    
    public function fetch_all_list_by_vip($condition,$orders = '',$start = 0,$limit = 10) {
        $data = DB::fetch_all('SELECT s.*,v.fenlei_times AS vip_fenlei_times,v.open_fenlei AS vip_open_fenlei  FROM '.DB::table('tom_tcshop').' s LEFT JOIN '.DB::table('tom_tcshop_vip')." v ON s.vip_id = v.id  WHERE 1 %i $orders LIMIT $start,$limit",array($condition));
        return $data;
    }
    
    public function fetch_all_field_list($condition,$field = '*') {
        $data = DB::fetch_all("SELECT $field FROM %t WHERE 1 %i ",array($this->_table,$condition));
		return $data;
	}
	
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition,$name = '',$address = '',$tabs = '') {
        if(!empty($name)){
            $name = str_replace(array('%', '_'),'',$name);
            $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i AND name LIKE %s ",array($this->_table,$condition,'%'.$name.'%'));
        }else if(!empty($address)){
            $address = str_replace(array('%', '_'),'',$address);
            $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i AND address LIKE %s ",array($this->_table,$condition,'%'.$address.'%'));
        }else if(!empty($tabs)){
            $tabs = str_replace(array('%', '_'),'',$tabs);
            $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i AND tabs LIKE %s ",array($this->_table,$condition,'%'.$tabs.'%'));
        }else{
            $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i ",array($this->_table,$condition));
        }
		return $return['num'];
	}
    
    public function fetch_all_sun_clicks($condition) {
        $return = DB::fetch_first("SELECT SUM(clicks) AS sun_clicks FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['sun_clicks'];
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

}