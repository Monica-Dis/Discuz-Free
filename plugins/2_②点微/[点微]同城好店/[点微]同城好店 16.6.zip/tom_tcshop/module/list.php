<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';
    
$user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$no_tcshop_id   = intval($_GET['no_tcshop_id'])>0? intval($_GET['no_tcshop_id']):0;
$area_id        = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id      = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$cate_id        = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$cate_child_id  = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
$keyword        = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$tabs           = isset($_GET['tabs'])? daddslashes(diconv(urldecode($_GET['tabs']),'utf-8')):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;
$ordertype      = !empty($_GET['ordertype'])? addslashes($_GET['ordertype']):'';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$searchAddress = '';
if($tcshopConfig['open_ruzhu_area'] == 0){
    if(!empty($street_id)){
        $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
        $searchAddress = $streetInfo['name'];
    }else if(!empty($area_id)){
        $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
        $searchAddress = $areaInfo['name'];
    }
}

$whereStr = ' AND status=1 AND shenhe_status=1 ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($no_tcshop_id)){
    $whereStr.= " AND id != {$no_tcshop_id} ";
}
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}
if(!empty($cate_id)){
    $whereStr.= " AND cate_id={$cate_id} ";
}
if(!empty($cate_child_id)){
    $whereStr.= " AND cate_child_id={$cate_child_id} ";
}
if(!empty($area_id)){
    $whereStr.= " AND area_id={$area_id} ";
}
if(!empty($street_id)){
    $whereStr.= " AND street_id={$street_id} ";
}

$orderStr = " ORDER BY topstatus DESC, toprand DESC,vip_rank DESC,clicks DESC,id DESC ";
if($ordertype == 'new'){
    $orderStr = " ORDER BY id DESC ";
}

$pagesize       = $pagesize;
$start          = ($page - 1)*$pagesize;
if($ordertype == 'lbs' && !empty($latitude) && !empty($longitude)){
    $tcshopListTmp  = C::t('#tom_tcshop#tom_tcshop')->fetch_all_nearby_list($whereStr,$start,$pagesize,$latitude,$longitude);
}else{
    $tcshopListTmp  = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list($whereStr,$orderStr,$start,$pagesize,$keyword,$searchAddress,$tabs);
}
$tcshopList = array();
foreach ($tcshopListTmp as $key => $value){
    $tcshopList[$key] = $value;
    if(!preg_match('/^http/', $value['picurl']) ){
        if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
            $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $picurlTmp = $value['picurl'];
        }
    }else{
        $picurlTmp = $value['picurl'];
    }
    
    $avatarInfoTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(" AND tcshop_id={$value['id']} AND type_id = 4 ","ORDER BY id ASC",0,1);
    if(is_array($avatarInfoTmp) && !empty($avatarInfoTmp)){
        if($tongchengConfig['open_yun'] == 2 && !empty($avatarInfoTmp[0]['oss_picurl']) && $avatarInfoTmp[0]['oss_status'] == 1){
            $picurlTmp = $avatarInfoTmp[0]['oss_picurl'];
        }else if($tongchengConfig['open_yun'] == 3 && !empty($avatarInfoTmp[0]['qiniu_picurl'])  && $avatarInfoTmp[0]['qiniu_status'] == 1){
            $picurlTmp = $avatarInfoTmp[0]['qiniu_picurl'];
        }
    }
    
    $tcshopList[$key]['picurl'] = $picurlTmp;
}

if(is_array($tcshopList) && !empty($tcshopList)){
    foreach ($tcshopList as $key => $val){

        $cateInfoTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($val['cate_id']);
        $cateChildInfoTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($val['cate_child_id']);
        $vipInfoTmp = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($val['vip_id']);
        
        if(!preg_match('/^http/', $vipInfoTmp['picurl']) ){
            if(strpos($vipInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                $vipPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vipInfoTmp['picurl'];
            }else{
                $vipPicurl = $vipInfoTmp['picurl'];
            }
        }else{
            $vipPicurl = $vipInfoTmp['picurl'];
        }
        
        $tabsStr = str_replace("    "," ",$val['tabs']);
        $tabsStr = str_replace("   "," ",$tabsStr);
        $tabsStr = str_replace("  "," ",$tabsStr);
        $tabsArrTmp = explode(' ', $tabsStr);
        $tabsArr = array();
        if(is_array($tabsArrTmp) && !empty($tabsArrTmp)){
            foreach ($tabsArrTmp as $kk => $vv){
                $vv = trim($vv);
                if(!empty($vv)){
                    $vv = cutstr($vv, 12, '');
                    $tabsArr[] = $vv;
                }
            }
        }

        if(empty($tabsArr)){
            $tabsArr[] = $cateInfoTmp['name'];
            $tabsArr[] = $cateChildInfoTmp['name'];
        }

        $video_flag = $vr_flag = 0;
        if($vipInfoTmp['open_video'] == 1 && !empty($val['video_url'])){
            if(strpos($val['video_url'], 'youku.com') !== FALSE){
                $video_flag = 1;
            }else if(strpos($val['video_url'], 'qq.com') !== FALSE){
                $video_flag = 1;
            }else if(strpos($val['video_url'], '.mp4') !== FALSE){
                $video_flag = 1;
            }else if(strpos($val['video_url'], '.MOV') !== FALSE){
                $video_flag = 1;
            }
        }
        if($vipInfoTmp['open_vr'] == 1 && !empty($val['vr_url'])){
            $vr_flag = 1;
        }
        
        $tchongbaoInfo = array();
        if($__ShowTchongbao == 1){
            $tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(" AND tcshop_id = {$val['id']} AND pay_status = 2 AND only_show = 1 ", 'ORDER BY add_time DESC,id DESC', 0, 1);
            if(is_array($tchongbaoInfoTmp) && !empty($tchongbaoInfoTmp[0])){
                $tchongbaoInfo = $tchongbaoInfoTmp[0];
            }
        }
        $detailsHost = "";
        if(is_array($tchongbaoInfo) && !empty($tchongbaoInfo)){
            $detailsHost = $__TchongbaoHost;
        }

        $companyRenzhengStatus = $depositStatus = 0;
        if($__ShowTcrenzheng == 1){
            $companyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($val['user_id']);
            if(is_array($companyInfoTmp) && $companyInfoTmp['shenhe_status'] == 1){
                $companyRenzhengStatus = 1;
            }
            $depositInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_by_user_id($val['user_id']);
            if(is_array($depositInfoTmp) && $depositInfoTmp['order_status'] == 2 && $depositInfoTmp['type'] == 2){
                $depositStatus = 1;
            }
        }

        $outStr.= '<div class="item-box clearfix">';
            $outStr.= '<div class="item-pic"><a href="'.$detailsHost.'plugin.php?id=tom_tcshop&site='.$site_id.'&mod=details&dpid='.$val['id'].'">';
                $outStr.= '<img src="'.$val['picurl'].'">';
            $outStr.= '</a></div>';
            $outStr.= '<div class="item-content">';
                $outStr.= '<div class="content">';
                    $outStr.= '<h5><a href="'.$detailsHost.'plugin.php?id=tom_tcshop&site='.$site_id.'&mod=details&dpid='.$val['id'].'">';
                    if($val['topstatus'] == 1){
                        $outStr.= '<span class="icon top"></span>';
                    }
                    $outStr.= $val['name'].'&nbsp;';
                    if(!empty($vipInfoTmp['picurl'])){
                        $outStr.= '<span class="icon vip" style="background:url('.$vipPicurl.') no-repeat; background-size: 90%;"></span>';
                    }
                    if($companyRenzhengStatus == 1){
                        $outStr.= '<i class="tciconfont tcicon-renzheng_company" style="color: #0592f7;margin-right: 3px;font-size: 1.1em;"></i>';
                    }
                    if($depositStatus == 1){
                        $outStr.= '<i class="tciconfont tcicon-renzheng_deposit" style="color: #f9542f;margin-right: 3px;"></i>';
                    }
                    if(is_array($tchongbaoInfo) && $tchongbaoInfo['status'] == 1){
                        $outStr.= '<i class="tciconfont tcicon-hongbao_icon" style="margin-right: 2px;"></i>';
                    }
                    if($video_flag == 1){
                        $outStr.= '<i class="tciconfont tcicon-video" style="margin-right: 3px;"></i>';
                    }
                    if($vr_flag == 1){
                        $outStr.= '<i class="tciconfont tcicon-720_quanjing" style="font-size: 0.9em;margin-left: 2px;margin-right: 3px;"></i>';
                    }
                    $outStr.= '</a></h5>';
                    $outStr.= '<a href="'.$detailsHost.'plugin.php?id=tom_tcshop&site='.$site_id.'&mod=details&dpid='.$val['id'].'"><p class="xinxi" style="color: #dea44e;"><i class="tciconfont tcicon-business-hours" style="margin-right: 3px;"></i>'.$val['business_hours'].'</p></a>';
                    if(is_array($tabsArr) && !empty($tabsArr)){
                        $outStr.= '<a href="'.$detailsHost.'plugin.php?id=tom_tcshop&site='.$site_id.'&mod=details&dpid='.$val['id'].'"><p class="xinxi shop_list-tags">';
                        foreach ($tabsArr as $kt => $vt){
                            $outStr.= '<span class="span'.$kt.'">'.$vt.'</span>';
                        }
                        $outStr.= '</p></a>';
                    }
                    if($tcshopConfig['open_list_area'] == 1){
                        $outStr.= '<p class="address">'.$val['address'].'</p>';
                    }else if($tcshopConfig['open_list_area'] == 2){
                        $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($val['area_id']);
                        $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($val['street_id']);
                        $outStr.= '<p class="address">'.$areaInfo['name'].'&nbsp;'.$streetInfo['name'].'</p>';
                    }
                    if($vipInfoTmp['open_zan'] > 0 && !empty($val['zan_txt'])){
                        $outStr.= '<p class="nr"><span class="zan"></span>'.$val['zan_txt'].'</p>';
                    }
                    if($__ShowTcqianggou == 1){
                        $couponListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND tcshop_id={$val['id']} AND type_id IN(2,3,4)"," ORDER BY id DESC ",0,1);
                        $goodsListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND tcshop_id={$val['id']} AND type_id=1 AND qiang_status=1 "," ORDER BY id DESC ",0,1);
                        if(is_array($couponListTmp) && !empty($couponListTmp[0])){
                            $outStr.= '<a href="plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=coupon&goods_id='.$couponListTmp[0]['id'].'"><p class="nr"><span class="juan"></span>'.$couponListTmp[0]['title'].'</p></a>';
                        }
                        if(is_array($goodsListTmp) && !empty($goodsListTmp[0])){
                            $outStr.= '<a href="plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=details&goods_id='.$goodsListTmp[0]['id'].'"><p class="nr"><span class="qiang"></span>'.$goodsListTmp[0]['title'].'</p></a>';
                        }
                    }
                    if($__ShowTcptuan == 1){
                        $ptGoodsInfoTmp  = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND tcshop_id={$val['id']}"," ORDER BY paixu ASC,id DESC ",0,1);
                        if(is_array($ptGoodsInfoTmp) && !empty($ptGoodsInfoTmp[0])){
                            $outStr.= '<a href="plugin.php?id=tom_tcptuan&site='.$site_id.'&mod=goodsinfo&goods_id='.$ptGoodsInfoTmp[0]['id'].'"><p class="nr"><span class="ptuan"></span>'.$ptGoodsInfoTmp[0]['name'].'</p></a>';
                        }
                    }
                    if($__ShowTckjia == 1){
                        $kjGoodsInfoTmp  = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND tcshop_id={$val['id']}"," ORDER BY paixu ASC,id DESC ",0,1);
                        if(is_array($kjGoodsInfoTmp) && !empty($kjGoodsInfoTmp[0])){
                            $outStr.= '<a href="plugin.php?id=tom_tckjia&site='.$site_id.'&mod=details&goods_id='.$kjGoodsInfoTmp[0]['id'].'"><p class="nr"><span class="kjia"></span>'.$kjGoodsInfoTmp[0]['title'].'</p></a>';
                        }
                    }
                    if($__ShowTcchoujiang == 1){
                        $choujiangInfoTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_all_list(" AND tcshop_id={$val['id']} AND type = 2 AND status = 1 AND shenhe_status = 1 ","ORDER BY chou_status ASC,paixu ASC,id DESC",0,1);
                        if(is_array($choujiangInfoTmp) && !empty($choujiangInfoTmp[0])){
                            $outStr.= '<a href="plugin.php?id=tom_tcchoujiang&site='.$site_id.'&mod=details&cjid='.$choujiangInfoTmp[0]['id'].'"><p class="nr"><span class="choujiang"></span>'.$choujiangInfoTmp[0]['title'].'</p></a>';
                        }
                    }
                    if($__ShowTchuodong == 1){
                        $huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_all_like_list(" AND tcshop_id={$val['id']} AND type = 2 AND status = 1 AND shenhe_status = 1 ","ORDER BY huodong_status ASC,is_recommend DESC,paixu ASC,id DESC",0,1);
                        if(is_array($huodongInfoTmp) && !empty($huodongInfoTmp[0])){
                            $outStr.= '<a href="plugin.php?id=tom_tchuodong&site='.$site_id.'&mod=details&tchuodong_id='.$huodongInfoTmp[0]['id'].'"><p class="nr"><span class="huodong"></span>'.$huodongInfoTmp[0]['title'].'</p></a>';
                        }
                    }
                $outStr.= '</div>';
                $outStr.= '<div class="details">';
                    if($cateInfoTmp['open_tel_price'] == 1){
                        $outStr.= '<div class="tel"><a href="'.$detailsHost.'plugin.php?id=tom_tcshop&site='.$site_id.'&mod=details&dpid='.$val['id'].'"></a></div>';
                    }else if($val['vip_status'] == 1 && $val['vip_time'] > TIMESTAMP){
                        $outStr.= '<div class="tel"><a href="tel:'.$val['tel'].'"></a></div>';
                    }
                    if(isset($val['distance'])){
                        $juli = tomGetDistance($longitude, $latitude, $val['longitude'], $val['latitude']);
                        $outStr.= '<div class="dist">'.$juli.'km</div>';
                    }else{
                        $outStr.= '<div class="dist">'.$val['clicks'].''.lang('plugin/tom_tcshop','template_list_clicks_title').'</div>';
                    }
                $outStr.= '</div>';
            $outStr.= '</div>';
        $outStr.= '</div>';
    }
}else{
    $outStr = '205';
}
$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;