<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
if($__UserInfo['id'] != $tcshopInfo['user_id']){
    dheader('location:'.$back_url);exit;
}

if($_GET['act'] == 'add'){
    
    $express_back_url = isset($_GET['express_back_url'])? addslashes($_GET['express_back_url']):'';
    
    $saveUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=express&act=save&tcshop_id=".$tcshop_id;
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcshop:expressadd");
    exit;
    
}else if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){

    $title          = isset($_GET['title'])? daddslashes(diconv(urldecode($_GET['title']),'utf-8')):'';
    $issendfree     = intval($_GET['issendfree'])>0? intval($_GET['issendfree']):0;
    $default_price  = floatval($_GET['default_price'])>0? floatval($_GET['default_price']):0;
    
    $insertData = array();
    $insertData['tcshop_id']        = $tcshop_id;
    $insertData['title']            = $title;
    $insertData['issendfree']       = $issendfree;
    $insertData['default_price']    = $default_price;
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tcshop#tom_tcshop_express')->insert($insertData);

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'edit'){
    
    $express_id         = intval($_GET['express_id'])>0 ? intval($_GET['express_id']):0;
    $express_back_url   = isset($_GET['express_back_url'])? addslashes($_GET['express_back_url']):'';
    
    $expressInfo = C::t('#tom_tcshop#tom_tcshop_express')->fetch_by_id($express_id);
    if($expressInfo['tcshop_id'] != $tcshop_id){
        dheader('location:'.$express_back_url);exit;
    }
    
    $saveUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=express&act=editsave&tcshop_id={$tcshop_id}&express_id={$express_id}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcshop:expressedit");
    exit;

}else if($_GET['act'] == 'editsave' && $_GET['formhash'] == FORMHASH){

    $express_id     = intval($_GET['express_id'])>0 ? intval($_GET['express_id']):0;
    $title          = isset($_GET['title'])? daddslashes(diconv(urldecode($_GET['title']),'utf-8')):'';
    $issendfree     = intval($_GET['issendfree'])>0 ? intval($_GET['issendfree']):0;
    $default_price  = floatval($_GET['default_price'])>0 ? floatval($_GET['default_price']):0;
    
    $expressInfo = C::t('#tom_tcshop#tom_tcshop_express')->fetch_by_id($express_id);
    if($expressInfo['tcshop_id'] != $tcshop_id){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['title']            = $title;
    $updateData['issendfree']       = $issendfree;
    $updateData['default_price']    = $default_price;
    C::t('#tom_tcshop#tom_tcshop_express')->update($express_id, $updateData);

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'del' && $_GET['formhash'] == FORMHASH){

    $express_id = intval($_GET['express_id'])>0? intval($_GET['express_id']):0;
    
    $expressInfo = C::t('#tom_tcshop#tom_tcshop_express')->fetch_by_id($express_id);
    if($expressInfo['tcshop_id'] != $tcshop_id){
        echo 404; exit;
    }
    
    C::t('#tom_tcshop#tom_tcshop_express')->delete_by_id($express_id);
    C::t('#tom_tcshop#tom_tcshop_express_item')->delete_by_express_id($express_id);

    echo 200; exit;
}

$expressListTmp  = C::t('#tom_tcshop#tom_tcshop_express')->fetch_all_list(" AND tcshop_id={$tcshopInfo['id']} "," ORDER BY id DESC ");
$expressList = array();
if(is_array($expressListTmp) && !empty($expressListTmp)){
    foreach ($expressListTmp as $key => $value){

        $expressList[$key] = $value;
        $expressList[$key]['default_price'] = $value['default_price'];
    }
}

$delUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=express&act=del&tcshop_id=".$tcshop_id.'&formhash='.$formhash;

$express_back_url = $weixinClass->get_url();
$express_back_url = urlencode($express_back_url);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:express");