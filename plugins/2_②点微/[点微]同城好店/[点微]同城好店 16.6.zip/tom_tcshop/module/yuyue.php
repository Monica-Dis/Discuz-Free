<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);

if($tcshopInfo['pay_status'] == 1){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=mylist");exit;
}

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    if($__UserInfo['groupid'] == 1){
    }else if($__UserInfo['groupid'] == 2){
        if($tcshopInfo['site_id'] == $__UserInfo['groupsiteid']){
        }else{
            dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=index");exit;
        }
    }else{
        dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=index");exit;
    }
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $open_yuyue     = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $tcyuyue_id     = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
    
    $updateData = array();
    $updateData['open_yuyue']   = $open_yuyue;
    if($open_yuyue == 1){
        $updateData['tcyuyue_id']   = $tcyuyue_id;
    }else{
        $updateData['tcyuyue_id']   = 0;
    }
    $updateData['part1']        = TIMESTAMP;
    if(C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id,$updateData)){
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$tcyuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list(" AND tcshop_id = {$tcshopInfo['id']} AND type = 1 AND status = 1 AND shenhe_status = 1 ");
$tcyuyueList = array();
if(is_array($tcyuyueListTmp) && !empty($tcyuyueListTmp)){
    foreach($tcyuyueListTmp as $key => $value){
        $tcyuyueList[$key] = $value;
    }
}

$saveUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=yuyue&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:yuyue");