<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $edmoney            = floatval($_GET['edmoney'])>0? floatval($_GET['edmoney']):0;
    $dispatch_type      = floatval($_GET['dispatch_type'])>0? floatval($_GET['dispatch_type']):0;
    $peisong_type       = intval($_GET['peisong_type'])>0? intval($_GET['peisong_type']):0;
    $huodao_pay         = intval($_GET['huodao_pay'])>0? intval($_GET['huodao_pay']):0;
    $open_shop_list_cart = intval($_GET['open_shop_list_cart'])>0? intval($_GET['open_shop_list_cart']):0;
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    
    if($__UserInfo['id'] != $tcshopInfo['user_id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['edmoney']              = $edmoney;
    $updateData['dispatch_type']        = $dispatch_type;
    $updateData['peisong_type']         = $peisong_type;
    $updateData['open_shop_list_cart']  = $open_shop_list_cart;
    if($tcmallConfig['open_tcshop_huodao_pay'] == 1){
        $updateData['huodao_pay']       = $huodao_pay;
    }
    $updateData['mall_shop_picurl']     = $picurl;
    $updateData['part1']                = TIMESTAMP;
    if(C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id,$updateData)){
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

if(!preg_match('/^http/', $tcshopInfo['mall_shop_picurl']) ){
    if(strpos($tcshopInfo['mall_shop_picurl'], 'source/plugin/tom_') === FALSE){
        $mallShopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['mall_shop_picurl'];
    }else{
        $mallShopPicurl = $tcshopInfo['mall_shop_picurl'];
    }
}else{
    $mallShopPicurl = $tcshopInfo['mall_shop_picurl'];
}

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list("AND user_id={$__UserInfo['id']} AND status=1 AND shenhe_status=1 "," ORDER BY id DESC ",0,100);
$tcshopList = array();
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach($tcshopListTmp as $key => $value){
        $tcshopList[$key] = $value;
    }
}

$uploadUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=upload&act=mall_bgpic&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tcshop:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;
$saveUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=mallbase&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:mallbase");