<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$express_id         = intval($_GET['express_id'])>0 ? intval($_GET['express_id']):0;
$express_back_url   = isset($_GET['express_back_url'])? addslashes($_GET['express_back_url']):'';

$expressInfo = C::t('#tom_tcshop#tom_tcshop_express')->fetch_by_id($express_id);
if($expressInfo['id'] > 0){ }else{
    dheader('location:'.$express_back_url);exit;
}

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($expressInfo['tcshop_id']);
if($__UserInfo['id'] != $tcshopInfo['user_id']){
    dheader('location:'.$express_back_url);exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 1,
    );
    
    $express_item_id    = intval($_GET['express_item_id'])>0 ? intval($_GET['express_item_id']):0;
    $province_id        = intval($_GET['province_id'])>0 ? intval($_GET['province_id']):0;
    $city_id            = intval($_GET['city_id'])>0 ? intval($_GET['city_id']):0;
    $area_id            = intval($_GET['area_id'])>0 ? intval($_GET['area_id']):0;
    $issendfree         = intval($_GET['issendfree'])>0 ? intval($_GET['issendfree']):0;
    $express_price      = floatval($_GET['express_price'])>0 ? floatval($_GET['express_price']):0;
    
    $provinceInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($province_id);
    $cityInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($city_id);
    $areaInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($area_id);
    
    if($express_item_id > 0){
        
        $expressItemInfo = C::t('#tom_tcshop#tom_tcshop_express_item')->fetch_by_id($express_item_id);
        if($expressItemInfo['express_id'] != $expressInfo['id']){
            $outArr = array(
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }
        
        $updateData = array();
        $updateData['province_id']      = $province_id;
        $updateData['province_name']    = $provinceInfo['name'];
        $updateData['city_id']          = $city_id;
        $updateData['city_name']        = $cityInfo['name'];
        $updateData['area_id']          = $area_id;
        $updateData['area_name']        = $areaInfo['name'];
        $updateData['issendfree']       = $issendfree;
        $updateData['express_price']    = $express_price;
        C::t('#tom_tcshop#tom_tcshop_express_item')->update($express_item_id, $updateData);
    }else{
        $insertData = array();
        $insertData['tcshop_id']        = $expressInfo['tcshop_id'];
        $insertData['express_id']       = $express_id;
        $insertData['province_id']      = $province_id;
        $insertData['province_name']    = $provinceInfo['name'];
        $insertData['city_id']          = $city_id;
        $insertData['city_name']        = $cityInfo['name'];
        $insertData['area_id']          = $area_id;
        $insertData['area_name']        = $areaInfo['name'];
        $insertData['issendfree']       = $issendfree;
        $insertData['express_price']    = $express_price;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcshop#tom_tcshop_express_item')->insert($insertData);
    }
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'del' && $_GET['formhash'] == FORMHASH){

    $express_item_id = intval($_GET['express_item_id'])>0 ? intval($_GET['express_item_id']):0;
    
    $expressItemInfo = C::t('#tom_tcshop#tom_tcshop_express_item')->fetch_by_id($express_item_id);
    if($expressItemInfo['express_id'] != $expressInfo['id']){
        echo 404; exit;
    }
        
    C::t('#tom_tcshop#tom_tcshop_express_item')->delete_by_id($express_item_id);

    echo 200; exit;

}else if($_GET['act'] == 'info' && $_GET['formhash'] == FORMHASH){

    $outArr = array(
        'status'=> 1,
    );
    
    $express_item_id = intval($_GET['express_item_id'])>0? intval($_GET['express_item_id']):0;
    
    $expressItemInfo = C::t('#tom_tcshop#tom_tcshop_express_item')->fetch_by_id($express_item_id);
    if($expressItemInfo['express_id'] != $expressInfo['id']){
        $outArr = array(
            'status'    => 404
        );
        echo json_encode($outArr); exit;
    }
    
    $expressItemInfo['name']            = diconv($expressItemInfo['name'], CHARSET, 'utf-8');
    $expressItemInfo['province_name']   = diconv($expressItemInfo['province_name'], CHARSET, 'utf-8');
    $expressItemInfo['city_name']       = diconv($expressItemInfo['city_name'], CHARSET, 'utf-8');
    $expressItemInfo['area_name']       = diconv($expressItemInfo['area_name'], CHARSET, 'utf-8');
    
    $outArr = array(
        'status'    => 200,
        "data"      => $expressItemInfo
    );
    echo json_encode($outArr); exit;
}

$expressItemListTmp = C::t('#tom_tcshop#tom_tcshop_express_item')->fetch_all_list(" AND express_id={$express_id} "," ORDER BY id DESC ");
$expressItemList = array();
if(is_array($expressItemListTmp) && !empty($expressItemListTmp)){
    foreach ($expressItemListTmp as $key => $value){
        
        $expressItemList[$key] = $value;
        $expressItemList[$key]['express_price'] = $value['express_price'];
    }
}

$districtListTmp = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid(0);
$districtList = array();
if(is_array($districtListTmp) && !empty($districtListTmp)){
    foreach($districtListTmp as $key => $value){
        $districtList[$key] = $value;
    }
}

$saveUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=expressitem&act=save&express_id=".$express_id;
$expressItemInfoUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=expressitem&act=info&express_id={$express_id}&formhash={$formhash}";
$delUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=expressitem&act=del&express_id=".$express_id.'&formhash='.$formhash;

$expressitem_back_url = $weixinClass->get_url();
$expressitem_back_url = urlencode($expressitem_back_url);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:expressitem");