<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    if($__UserInfo['groupid'] == 1){
    }else if($__UserInfo['groupid'] == 2){
        if($tcshopInfo['site_id'] == $__UserInfo['groupsiteid']){
        }else{
            dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=index");exit;
        }
    }else{
        dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=index");exit;
    }
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $content = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $updateData = array();
    $updateData['content']          = $content;
    $updateData['admin_edit']       = 0;
    $updateData['part1']            = TIMESTAMP;
    if(C::t('#tom_tcshop#tom_tcshop')->update($tcshop_id,$updateData)){
        
        C::t('#tom_tcshop#tom_tcshop_tuwen')->delete_by_tcshop_id($tcshop_id);
        
        $outArr = array(
            'status'=> 200,
            'tcshop_id'=> $tcshopId,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$tcshopTuwenListTmp = C::t('#tom_tcshop#tom_tcshop_tuwen')->fetch_all_list(" AND tcshop_id={$tcshopInfo['id']} "," ORDER BY paixu ASC,id ASC ",0,50);
$tcshopTuwenList = array();
if(is_array($tcshopTuwenListTmp) && !empty($tcshopTuwenListTmp)){
    foreach ($tcshopTuwenListTmp as $kk => $vv){
        $tcshopTuwenList[$kk] = $vv;
        if(!preg_match('/^http/', $vv['picurl']) ){
            if(strpos($vv['picurl'], 'source/plugin/tom_') === FALSE){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
            }else{
                $picurlTmp = $vv['picurl'];
            }
        }else{
            $picurlTmp = $vv['picurl'];
        }
        
        $tcshopInfo['content'] .= '<p><img src="'.$picurlTmp.'"></p>'.$vv['txt'];
        
    }
}
$tuwenCount = count($tcshopTuwenList);
$tcshopInfo['content'] = stripslashes($tcshopInfo['content']);

$saveUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=editContent&act=save";
$uploadUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=upload&act=content_picurl&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tcshop:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:editContent");