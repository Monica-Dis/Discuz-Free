<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);

if(!empty($tcshopConfig['score_yuan'])){
    $score_yuan = $tcshopConfig['score_yuan'];
}else{
    $score_yuan = $tongchengConfig['score_yuan'];
}
$vipName = '';
$where = "AND status = 1 ";
if($tcshopInfo['vip_time'] > TIMESTAMP){
    $vipInfo = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($tcshopInfo['vip_id']);
    if($vipInfo['is_base'] == 0){
        $where .= "AND is_base = 0";
    }
}
$vipListTmp = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_all_list($where, 'ORDER BY vsort ASC, id DESC');
$vipList = $vipArr = array();
if(is_array($vipListTmp) && !empty($vipListTmp)){
    foreach($vipListTmp as $key => $value){
        
        if($value['xiangou_num'] > 0){
            $vipLogCount = C::t('#tom_tcshop#tom_tcshop_vip_log')->fetch_all_count(" AND vip_id = {$value['id']} AND user_id = {$__UserInfo['id']} AND type = 1 ");
            if($vipLogCount >= $value['xiangou_num']){
                continue;
            }
        }
        
        $vipArr[] = $value;
        $vipList[$key] = $value;
        $vipList[$key]['price'] = floatval($value['price']);
        
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurlTmp = $value['picurl'];
            }
        }else{
            $picurlTmp = $value['picurl'];
        }
        
        $scoreTmp = $value['price'] * $score_yuan;
        if($scoreTmp < 1){
            $scoreTmp = 1;
        }
        $vipList[$key]['score'] = $scoreTmp;
        $vipList[$key]['picurl'] = $picurlTmp;
        
        if($tcshopInfo['vip_id'] == $value['id']){
            $vipName = $value['name'];
        }
    }
}

$viptime = dgmdate($tcshopInfo['vip_time'],"Y-m-d",$tomSysOffset);

$vipCount = count($vipArr);

$columnArr = array(
    0 => 'open_zan',
    1 => 'open_gonggao',
    2 => 'open_video',
    3 => 'open_vr',
    4 => 'open_mp3',
    5 => 'open_xiao_qrcode',
);
if($__ShowTcmall == 1){
    $columnArr[] = 'open_tcmall';
}
if($__ShowTcqianggou == 1){
    $columnArr[] = 'open_tcqianggou';
    $columnArr[] = 'open_coupon';
}
if($__ShowTcptuan == 1){
    $columnArr[] = 'open_tcptuan';
}
if($__ShowTckjia == 1){
    $columnArr[] = 'open_tckjia';
}
if($__ShowTcchoujiang == 1){
    $columnArr[] = 'open_tcchoujiang';
}
if($__ShowTchuodong == 1){
    $columnArr[] = 'open_tchuodong';
}
if($__ShowTctoutiao == 1){
    $columnArr[] = 'open_tctoutiao';
}
if($__ShowTcyikatong == 1){
    $columnArr[] = 'open_tcyikatong';
}
$columnArr[] = 'open_fenlei';
$columnArr[] = 'fenlei_times';
$columnArr[] = 'rank';

$vipTequanList = array();
if(is_array($vipArr) && !empty($vipArr)){
    $viplength = count($vipArr);
    $columnlength = count($columnArr);
    for ($i = 0; $i < $columnlength; $i++) {
        $value = array();
        for ($j = 0; $j < $viplength; $j++) {
            $value[] = $vipArr[$j][$columnArr[$i]];
        }
        $vipTequanList[$columnArr[$i]] = $value;
    }
}

$commonInfo = C::t('#tom_tcshop#tom_tcshop_common')->fetch_by_id(1);
if(!$commonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcshop#tom_tcshop_common')->insert($insertData);
}
$new_vip_txt = stripslashes($commonInfo['new_vip_txt']);

$payVipUrl = "plugin.php?id=tom_tcshop:pay&site={$site_id}&act=vip&back_url=".urlencode($back_url)."&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:buyvip");