<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
if($__UserInfo['id'] != $tcshopInfo['user_id']){
    dheader('location:'.$back_url);exit;
}

if($_GET['act'] == 'add'){
    
    $place_back_url = isset($_GET['place_back_url'])? addslashes($_GET['place_back_url']):'';
    
    $saveUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=place&act=save&tcshop_id=".$tcshop_id;
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcshop:placeadd");
    exit;
    
}else if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){

    $name           = isset($_GET['name'])? daddslashes(diconv(urldecode($_GET['name']),'utf-8')):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $lng            = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat            = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address        = isset($_GET['address'])? daddslashes(diconv(urldecode($_GET['address']),'utf-8')):'';
    $status         = intval($_GET['status'])>0? intval($_GET['status']):0;
    $psort          = intval($_GET['psort'])>0? intval($_GET['psort']):10;
    
    $insertData = array();
    $insertData['tcshop_id']        = $tcshop_id;
    $insertData['name']             = $name;
    $insertData['tel']              = $tel;
    $insertData['longitude']        = $lng;
    $insertData['latitude']         = $lat;
    $insertData['address']          = $address;
    $insertData['status']           = $status;
    $insertData['psort']            = $psort;
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tcshop#tom_tcshop_place')->insert($insertData);

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'edit'){
    
    $place_id         = intval($_GET['place_id'])>0 ? intval($_GET['place_id']):0;
    $place_back_url   = isset($_GET['place_back_url'])? addslashes($_GET['place_back_url']):'';
    
    $placeInfo = C::t('#tom_tcshop#tom_tcshop_place')->fetch_by_id($place_id);
    if($placeInfo['tcshop_id'] != $tcshop_id){
        dheader('location:'.$place_back_url);exit;
    }
    
    $saveUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=place&act=editsave&tcshop_id={$tcshop_id}&place_id={$place_id}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcshop:placeedit");
    exit;

}else if($_GET['act'] == 'editsave' && $_GET['formhash'] == FORMHASH){

    $place_id       = intval($_GET['place_id'])>0 ? intval($_GET['place_id']):0;
    $name           = isset($_GET['name'])? daddslashes(diconv(urldecode($_GET['name']),'utf-8')):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $lng            = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat            = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address        = isset($_GET['address'])? daddslashes(diconv(urldecode($_GET['address']),'utf-8')):'';
    $status         = intval($_GET['status'])>0? intval($_GET['status']):0;
    $psort          = intval($_GET['psort'])>0? intval($_GET['psort']):10;
    
    $placeInfo = C::t('#tom_tcshop#tom_tcshop_place')->fetch_by_id($place_id);
    if($placeInfo['tcshop_id'] != $tcshop_id){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['name']             = $name;
    $updateData['tel']              = $tel;
    $updateData['longitude']        = $lng;
    $updateData['latitude']         = $lat;
    $updateData['address']          = $address;
    $updateData['status']           = $status;
    $updateData['psort']            = $psort;
    C::t('#tom_tcshop#tom_tcshop_place')->update($place_id, $updateData);

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'del' && $_GET['formhash'] == FORMHASH){

    $place_id = intval($_GET['place_id'])>0? intval($_GET['place_id']):0;
    
    $placeInfo = C::t('#tom_tcshop#tom_tcshop_place')->fetch_by_id($place_id);
    if($placeInfo['tcshop_id'] != $tcshop_id){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }

    C::t('#tom_tcshop#tom_tcshop_place')->delete_by_id($place_id);

    echo 200; exit;

}

$placeListTmp  = C::t('#tom_tcshop#tom_tcshop_place')->fetch_all_list(" AND tcshop_id={$tcshopInfo['id']} "," ORDER BY id DESC ");
$placeList = array();
if(is_array($placeListTmp) && !empty($placeListTmp)){
    foreach ($placeListTmp as $key => $value){

        $placeList[$key] = $value;
    }
}

$delUrl = "plugin.php?id=tom_tcshop&site={$site_id}&mod=place&act=del&tcshop_id=".$tcshop_id.'&formhash='.$formhash;
$ajaxUpdateStatusUrl = "plugin.php?id=tom_tcshop:ajax&site={$site_id}&act=updatePlaceStatus&&formhash=".$formhash;

$place_back_url = $weixinClass->get_url();
$place_back_url = urlencode($place_back_url);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcshop:place");