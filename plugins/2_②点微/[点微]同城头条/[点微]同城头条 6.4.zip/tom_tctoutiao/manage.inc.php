<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
loaducenter();
define('TPL_DEFAULT', true);
$tctoutiaoConfig = $_G['cache']['plugin']['tom_tctoutiao'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$Lang = $scriptlang['tom_tctoutiao'];
$formhash = FORMHASH;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$cssJsVersion = "201810211";

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

if(empty($_G['uid'])){
    showmessage('to_login', 'member.php?mod=logging&action=login', array(), array('showmsg' => true, 'login' => 1));
}

$__IsManager = 0;
if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    $__IsManager = 1;
}
if($__IsManager == 0){
    $zuozheCount = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_count(" AND bbs_uid = {$_G['uid']} ");
    if($zuozheCount > 0){}else{
        dheader('location:'.$_G['siteurl']);exit;
    }
}

## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tcqianggou start
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
    $tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
    if($tcqianggouConfig['open_tcqianggou'] == 1){
        $__ShowTcqianggou = 1;
    }
}
## tcqianggou end
## tcmall start
$__ShowTcmall = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcmall/tom_tcmall.inc.php')){
    $tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
    if($tcmallConfig['open_tcmall'] == 1){
        $__ShowTcmall = 1;
    }
}
## tcmall end

$__Ueditor = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_ueditor/addon.inc.php')){
    $__Ueditor = 1;
}

if($_GET['mod'] == 'fabu'){

    include DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/manage/fabu.php';

}else if($_GET['mod'] == 'edit'){

    include DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/manage/edit.php';

}else if($_GET['mod'] == 'import'){

    include DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/manage/import.php';

}else if($_GET['mod'] == 'zuozhe'){

    include DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/manage/zuozhe.php';

}else if($_GET['mod'] == 'order'){

    include DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/manage/order.php';

}else if($_GET['mod'] == 'pinglun'){

    include DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/manage/pinglun.php';

}else if($_GET['mod'] == 'list'){

    include DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/manage/list.php';

}else if($_GET['mod'] == 'upload'){

    include DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/manage/upload.php';

}else{
    
    $_GET['mod'] = 'zuozhe';
    include DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/manage/zuozhe.php';

}