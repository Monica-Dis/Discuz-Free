<?php

/*
   ������ҵ���/ģ������ ����DisM!Ӧ������
   ���²����http://t.cn/Aiux1Jx1
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tctoutiaoConfig    = $_G['cache']['plugin']['tom_tctoutiao'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset       = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass        = new weixinClass($appid,$appsecret);

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcadmin start
$__ShowTcadmin = 0;
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
    if($tcadminConfig['open_fc'] == 1){
        $__ShowTcadmin = 1;
    }
}
## tcadmin end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

$orderInfo = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_by_order_no($order_no);
if($orderInfo && $orderInfo['order_status'] == 1){
    
    $updateData = array();
    $updateData['order_status'] = 2;
    $updateData['pay_time'] = TIMESTAMP;
    C::t('#tom_tctoutiao#tom_tctoutiao_order')->update($orderInfo['id'],$updateData);

    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($orderInfo['order_no'])));

    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
    $tctoutiaoInfo = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_by_id($orderInfo['tctoutiao_id']); 
    $zuozheInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($tctoutiaoInfo['zuozhe_id']); 
    $zuozheUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['zuozhe_user_id']);
    
    if($tctoutiaoConfig['open_back_score'] == 1){
        
        $score_yuan = $tongchengConfig['score_yuan'];
        if(!empty($tctoutiaoConfig['score_yuan'])){
            $score_yuan = $tctoutiaoConfig['score_yuan'];
        }
        
        $score = ceil($orderInfo['pay_price']*$score_yuan);
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] + $score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $score;
        $insertData['old_value']        = $userInfo['score'];
        if($orderInfo['order_type'] == 1){
            $insertData['log_type']         = 19;
        }else if($orderInfo['order_type'] == 2){
            $insertData['log_type']         = 20;
        }
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    }
    
    # fc start
    $pt_money       = 0;
    $zuozhe_money   = 0;
    
    $sendTemplateReward = false;
    if($orderInfo['order_type'] == 1 && $orderInfo['pay_price'] > 0 && $zuozheInfo['reward_fc_scale'] > 0 && $zuozheUserInfo['id'] > 0){
        $sendTemplateReward = true;
        
        $reward_fc_scale = $zuozheInfo['reward_fc_scale'];
        
        $zuozhe_money = $orderInfo['pay_price']*($reward_fc_scale/100);
        $zuozhe_money = number_format($zuozhe_money,2, '.', '');
        
        $insertData = array();
        $insertData['user_id']          = $zuozheUserInfo['id'];
        $insertData['type_id']          = 2;
        $insertData['change_money']     = $zuozhe_money;
        $insertData['old_money']        = $zuozheUserInfo['money'];
        $insertData['tag']              = lang('plugin/tom_tctoutiao', 'paynotify_reward');
        $insertData['beizu']            = lang('plugin/tom_tctoutiao', 'paynotify_beizu_1') . $orderInfo['tctoutiao_id'] . lang('plugin/tom_tctoutiao', 'paynotify_beizu_2') . $zuozheUserInfo['nickname'];
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
        DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$zuozhe_money} WHERE id='{$zuozheUserInfo['id']}'", 'UNBUFFERED');
        
        $updateData = array();
        $updateData['zuozhe_shouyi_price'] = $zuozhe_money;
        C::t('#tom_tctoutiao#tom_tctoutiao_order')->update($orderInfo['id'],$updateData);
    }
    
    $sendTemplatePayreading = false;
    if($orderInfo['order_type'] == 2 && $orderInfo['pay_price'] > 0 && $zuozheInfo['reading_fc_scale'] > 0  && $zuozheUserInfo['id'] > 0){
        $sendTemplatePayreading = true;
        
        $reading_fc_scale = $zuozheInfo['reading_fc_scale'];
        
        $zuozhe_money = $orderInfo['pay_price']*($reading_fc_scale/100);
        $zuozhe_money = number_format($zuozhe_money,2, '.', '');
        
        $insertData = array();
        $insertData['user_id']          = $zuozheUserInfo['id'];
        $insertData['type_id']          = 2;
        $insertData['change_money']     = $zuozhe_money;
        $insertData['old_money']        = $zuozheUserInfo['money'];
        $insertData['tag']              = lang('plugin/tom_tctoutiao', 'paynotify_reading');
        $insertData['beizu']            = lang('plugin/tom_tctoutiao', 'paynotify_beizu_1') . $orderInfo['tctoutiao_id'] . lang('plugin/tom_tctoutiao', 'paynotify_beizu_2') . $zuozheUserInfo['nickname'];
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
        DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$zuozhe_money} WHERE id='{$zuozheUserInfo['id']}'", 'UNBUFFERED');
        
        $updateData = array();
        $updateData['zuozhe_shouyi_price'] = $zuozhe_money;
        C::t('#tom_tctoutiao#tom_tctoutiao_order')->update($orderInfo['id'],$updateData);
    }
    
    $pt_money = $orderInfo['pay_price'] - $zuozhe_money;
    
    if($pt_money >= 0.1){
        $adminFc = false;
        if($__ShowTchehuoren == 1 && $userInfo['tj_hehuoren_id'] > 0 && false){

            $shenyu_money = $pt_money;
            $child_site_fc_money = $tchehuoren_fc_money = $tctchehuorenParent_fc_money = 0;

            $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($userInfo['tj_hehuoren_id']);
            if($tchehuorenInfo){
                $tchehuorenDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
                $tchehuorenUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tchehuorenInfo['openid']);
            }

            $tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
            if($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1){
                $tctchehuorenParentInfo = C::t("#tom_tchehuoren#tom_tchehuoren")->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
                $tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
                $tctchehuorenParentUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tctchehuorenParentInfo['openid']);
            }

            if($tchehuorenInfo && $tchehuorenInfo['status'] == 1 && $tchehuorenDengji['tt_fc_open'] == 1){
                if($orderInfo['site_id'] > 1  && $tctoutiaoConfig['zizhandi_fc'] == 1){
                    $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                    $sitename = $sitesInfo['name'];
                    if($__ShowTcadmin && $sitesInfo['hehuoren_fc_open'] == 1){

                        $tchehuoren_fc_money = $pt_money * ($tchehuorenDengji['tt_fc_scale']/100);
                        $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2);

                        $fc_scale = $tcadminConfig['fc_scale'];
                        if($sitesInfo['tt_fc_scale'] > 0){
                            $fc_scale = $sitesInfo['tt_fc_scale'];
                        }
                        $child_site_fc_money = $pt_money * ($fc_scale/100);
                        $child_site_fc_money = number_format($child_site_fc_money,2);
                        $child_site_fc_money = $child_site_fc_money - $tchehuoren_fc_money;

                        if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                            $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                            $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2);
                            if($tchehuorenConfig['subordinate_moneytype'] == 1){
                                $child_site_fc_money   = $child_site_fc_money - $tctchehuorenParent_fc_money;
                            }else{
                                $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                            }
                        }

                        $shenyu_money = $shenyu_money - $child_site_fc_money - $tchehuoren_fc_money;

                    }else{
                        if($__ShowTcadmin == 1 && $tctoutiaoConfig['zizhandi_fc'] == 1){
                            $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                            $fc_scale = $tcadminConfig['fc_scale'];
                            if($sitesInfo['tt_fc_scale'] > 0){
                                $fc_scale = $sitesInfo['tt_fc_scale'];
                            }
                            $child_site_fc_money = $pt_money * ($fc_scale/100);
                            $child_site_fc_money = number_format($child_site_fc_money,2);
                        }

                        $shenyu_money = $shenyu_money - $child_site_fc_money;

                    }

                }else{
                    $sitename = $tongchengConfig['plugin_name'];
                    $tchehuoren_fc_money = $pt_money * ($tchehuorenDengji['tt_fc_scale']/100);
                    $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2);

                    if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                        $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2);
                        if($tchehuorenConfig['subordinate_moneytype'] == 1){
                        }else{
                            $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                        }
                    }

                    $shenyu_money = $shenyu_money - $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                }

                if($pt_money >= ($child_site_fc_money +  $tchehuoren_fc_money + $tctchehuorenParent_fc_money)){  

                    if($child_site_fc_money > 0){
                        $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);

                        $old_money = 0;
                        if($walletInfo){
                            $old_money = $walletInfo['account_balance'];

                            $updateData = array();
                            $updateData['account_balance']   = $walletInfo['account_balance'] + $child_site_fc_money;
                            $updateData['total_income']   = $walletInfo['total_income'] + $child_site_fc_money;
                            C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
                        }else{
                            $insertData = array();
                            $insertData['site_id']              = $orderInfo['site_id'];
                            $insertData['account_balance']      = $child_site_fc_money;
                            $insertData['total_income']         = $child_site_fc_money;
                            $insertData['add_time']             = TIMESTAMP;
                            C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
                        }

                        $insertData = array();
                        $insertData['site_id']      = $orderInfo['site_id'];
                        $insertData['log_type']     = 1;
                        $insertData['change_money'] = $child_site_fc_money;
                        $insertData['old_money']    = $old_money;
                        $insertData['beizu']        = lang('plugin/tom_tctoutiao', 'beizu_wallet_log');
                        $insertData['order_no']     = $orderInfo['order_no'];
                        $insertData['order_type']   = $orderInfo['order_type'];
                        $insertData['log_ip']       = $_G['clientip'];
                        $insertData['log_time']     = TIMESTAMP;
                        C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData); 
                    }

                    $type = '';
                    if($orderInfo['order_type'] == 1){
                        $type = lang('plugin/tom_tctoutiao', 'paynotify_reward');
                    }else if($orderInfo['order_type'] == 2){
                        $type = lang('plugin/tom_tctoutiao', 'paynotify_reading');
                    }

                    $sendTemplateTchehuoren = false;
                    if($tchehuoren_fc_money > 0){
                        $sendTemplateTchehuoren = true;

                        $insertData = array();
                        $insertData['order_no']         = $orderInfo['order_no'];
                        $insertData['hehuoren_id']      = $tchehuorenInfo['id'];
                        $insertData['ly_user_id']       = $userInfo['id'];
                        $insertData['child_hehuoren_id'] = 0;
                        $insertData['today_time']       = $nowDayTime;
                        $insertData['week_time']        = $nowWeekTime;
                        $insertData['month_time']       = $nowMonthTime;
                        $insertData['type']             = $type;
                        $insertData['shouyi_price']     = $tchehuoren_fc_money;
                        $insertData['content']          = lang('plugin/tom_tongcheng', 'hehuoren_beizu_1') . $tongchengInfo['id'] . lang('plugin/tom_tongcheng', 'hehuoren_beizu_2') . $userInfo['nickname'];
                        $insertData['shouyi_status']    = 1;
                        $insertData['add_time']         = TIMESTAMP;
                        C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                    }

                    $sendTemplateTchehuorenParent = false;
                    if($tctchehuorenParent_fc_money > 0){
                        $sendTemplateTchehuorenParent = true;

                        $insertData = array();
                        $insertData['order_no']         = $orderInfo['order_no'];
                        $insertData['hehuoren_id']      = $tctchehuorenParentInfo['id'];
                        $insertData['ly_user_id']       = $userInfo['id'];
                        $insertData['child_hehuoren_id'] = $tchehuorenInfo['id'];
                        $insertData['today_time']       = $nowDayTime;
                        $insertData['week_time']        = $nowWeekTime;
                        $insertData['month_time']       = $nowMonthTime;
                        $insertData['type']             = $type;
                        $insertData['shouyi_price']     = $tctchehuorenParent_fc_money;
                        $insertData['content']          = lang('plugin/tom_tongcheng', 'hehuoren_beizu_1') . $tongchengInfo['id'] . lang('plugin/tom_tongcheng', 'hehuoren_beizu_2') . $userInfo['nickname'];
                        $insertData['shouyi_status']    = 1;
                        $insertData['add_time']         = TIMESTAMP;
                        C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                    }

                    if($sendTemplateTchehuoren == true){
                        $access_token = $weixinClass->get_access_token();
                        if($access_token && !empty($tchehuorenInfo['openid'])){
                            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                            $shouyiText = str_replace("{NICKNAME}",$userInfo['nickname'], lang('plugin/tom_tongcheng', 'paynotify_hehuoren_template'));
                            $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                            $shouyiText = str_replace("{TYPE}",$type, $shouyiText);
                            $shouyiText = str_replace("{MONEY}",$tchehuoren_fc_money, $shouyiText);
                            $smsData = array(
                                'first'         => $shouyiText,
                                'keyword1'      => $tchehuorenConfig['plugin_name'],
                                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                                'remark'        => ''
                            );
                            if(!empty($tchehuorenConfig['template_id'])){
                                $template_id = $tchehuorenConfig['template_id'];
                            }else{
                                $template_id = $tongchengConfig['template_id'];
                            }
                            @$r = $templateSmsClass->sendSms01($tchehuorenInfo['openid'], $template_id, $smsData);
                        }
                    }

                    if($sendTemplateTchehuorenParent == true){

                        $access_token = $weixinClass->get_access_token();
                        if($access_token && !empty($tctchehuorenParentInfo['openid'])){
                            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                            $shouyiText = str_replace("{TCHEHUOREN}",$tchehuorenInfo['xm'], lang('plugin/tom_tongcheng', 'paynotify_hehuorenparent_template'));
                            $shouyiText = str_replace("{NICKNAME}",$userInfo['nickname'], $shouyiText);
                            $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                            $shouyiText = str_replace("{TYPE}",$type, $shouyiText);
                            $shouyiText = str_replace("{MONEY}",$tctchehuorenParent_fc_money, $shouyiText);
                            $smsData = array(
                                'first'         => $shouyiText,
                                'keyword1'      => $tchehuorenConfig['plugin_name'],
                                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                                'remark'        => ''
                            );
                            if(!empty($tchehuorenConfig['template_id'])){
                                $template_id = $tchehuorenConfig['template_id'];
                            }else{
                                $template_id = $tongchengConfig['template_id'];
                            }
                            @$r = $templateSmsClass->sendSms01($tctchehuorenParentInfo['openid'], $template_id, $smsData);
                        }
                    }
                }

            }else{
                $adminFc = true;
            }
        }else{
            $adminFc = true;
        }

        if($__ShowTcadmin == 1 && $adminFc && $tctoutiaoConfig['zizhandi_fc'] == 1){

            $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
            $fc_scale = $tcadminConfig['fc_scale'];
            if($sitesInfo['tt_fc_scale'] > 0){
                $fc_scale = $sitesInfo['tt_fc_scale'];
            }
            $fc_money = $pt_money*($fc_scale/100);
            $fc_money = number_format($fc_money,2);

            $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);

            $old_money = 0;
            if($walletInfo){
                $old_money = $walletInfo['account_balance'];

                $updateData = array();
                $updateData['account_balance']   = $walletInfo['account_balance'] + $fc_money;
                $updateData['total_income']   = $walletInfo['total_income'] + $fc_money;
                C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
            }else{
                $insertData = array();
                $insertData['site_id']              = $orderInfo['site_id'];
                $insertData['account_balance']      = $fc_money;
                $insertData['total_income']         = $fc_money;
                $insertData['add_time']             = TIMESTAMP;
                C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
            }

            $insertData = array();
            $insertData['site_id']      = $orderInfo['site_id'];
            $insertData['log_type']     = 1;
            $insertData['change_money'] = $fc_money;
            $insertData['old_money']    = $old_money;
            $insertData['beizu']        = lang('plugin/tom_tctoutiao', 'beizu_wallet_log');
            $insertData['order_no']     = $orderInfo['order_no'];
            $insertData['order_type']   = $orderInfo['order_type'];
            $insertData['log_ip']       = $_G['clientip'];
            $insertData['log_time']     = TIMESTAMP;
            C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData);Log::DEBUG("update fc_end:" . $fc_money);
        }
    }
    
    # fc end
    
    if($sendTemplateReward == true){
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($zuozheUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$orderInfo['site_id']}&mod=info&aid={$orderInfo['tctoutiao_id']}");
            
            $rewardText = str_replace("{NICKNAME}",$userInfo['nickname'], lang('plugin/tom_tctoutiao', 'paynotify_reward_template'));
            $smsData = array(
                'first'         => $rewardText,
                'keyword1'      => $tctoutiaoConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $tctoutiaoInfo['title']
            );
            
            $template_id = $tongchengConfig['template_id'];
            @$r = $templateSmsClass->sendSms01($zuozheUserInfo['openid'], $template_id, $smsData);
        }
    }
    
    if($sendTemplatePayreading == true){
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($zuozheUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$orderInfo['site_id']}&mod=info&aid={$orderInfo['tctoutiao_id']}");
            
            $rewardText = str_replace("{NICKNAME}",$userInfo['nickname'], lang('plugin/tom_tctoutiao', 'paynotify_reading_template'));
            $smsData = array(
                'first'         => $rewardText,
                'keyword1'      => $tctoutiaoConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $tctoutiaoInfo['title']
            );
            
            $template_id = $tongchengConfig['template_id'];
            @$r = $templateSmsClass->sendSms01($zuozheUserInfo['openid'], $template_id, $smsData);
        }
    }
    
}