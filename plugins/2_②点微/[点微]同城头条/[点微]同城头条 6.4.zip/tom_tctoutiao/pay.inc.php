<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$tctoutiaoConfig      = $_G['cache']['plugin']['tom_tctoutiao'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$act = isset($_GET['act'])? addslashes($_GET['act']):"";

if($act == "reward" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $money         = floatval($_GET['money'])>0? floatval($_GET['money']):0.00;
    $tctoutiao_id  = intval($_GET['tctoutiao_id'])>0? intval($_GET['tctoutiao_id']):0;
    $user_id       = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    $tctoutiaoInfo = C::t("#tom_tctoutiao#tom_tctoutiao")->fetch_by_id($tctoutiao_id);
    
    if(!$userInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!$tctoutiaoInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($money <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $zuozheInfo = C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe")->fetch_by_id($tctoutiaoInfo['zuozhe_id']);
    
    $pay_price = $money;
    $openid = $userInfo['openid'];
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

    $insertData = array();
    if($tctoutiaoInfo['site_id'] == 99){
        $insertData['site_id']      = $site_id;
    }else{
        $insertData['site_id']      = $tctoutiaoInfo['site_id'];
    }
    $insertData['order_no']         = $order_no;
    $insertData['order_type']       = 1;
    $insertData['user_id']          = $userInfo['id'];
    $insertData['openid']           = $userInfo['openid'];
    $insertData['tctoutiao_id']     = $tctoutiaoInfo['id'];
    $insertData['zuozhe_id']        = $zuozheInfo['id'];
    if($tctoutiaoInfo['tougao_user_id'] > 0){
        $insertData['zuozhe_user_id']   = $tctoutiaoInfo['tougao_user_id'];
    }else{
        $insertData['zuozhe_user_id']   = $zuozheInfo['user_id'];
    }
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tctoutiao#tom_tctoutiao_order')->insert($insertData)){
        $order_id = C::t('#tom_tctoutiao#tom_tctoutiao_order')->insert_id();
        
        $insertData = array();
        $insertData['plugin_id']       = 'tom_tctoutiao';          
        $insertData['order_no']        = $order_no;                 
        $insertData['goods_id']        = $tctoutiaoInfo['id'];         
        $insertData['goods_name']      = $tctoutiaoInfo['title'];      
        $insertData['goods_beizu']     = '';
        $insertData['goods_url']       = 'plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=info&aid='.$tctoutiaoInfo['id'];
        $insertData['succ_back_url']   = 'plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=info&aid='.$tctoutiaoInfo['id'];
        $insertData['fail_back_url']   = "plugin.php?id=tom_tctoutiao&site={$site_id}&mod=info&aid=".$tctoutiaoInfo['id'];
        $insertData['allow_alipay']    = 1;    
        $insertData['pay_price']       = $pay_price;
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'    => 200,
                'payurl' => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }

}else if($act == "payreading" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tctoutiao_id  = intval($_GET['tctoutiao_id'])>0? intval($_GET['tctoutiao_id']):0;
    $user_id       = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    $tctoutiaoInfo = C::t("#tom_tctoutiao#tom_tctoutiao")->fetch_by_id($tctoutiao_id);
    
    if(!$userInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!$tctoutiaoInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    if($tctoutiaoInfo['pay_reading_price'] <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $zuozheInfo = C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe")->fetch_by_id($tctoutiaoInfo['zuozhe_id']);
    
    $pay_price = $tctoutiaoInfo['pay_reading_price'];
    $openid = $userInfo['openid'];
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

    $insertData = array();
    if($tctoutiaoInfo['site_id'] == 99){
        $insertData['site_id']      = $site_id;
    }else{
        $insertData['site_id']      = $tctoutiaoInfo['site_id'];
    }
    $insertData['order_no']         = $order_no;
    $insertData['order_type']       = 2;
    $insertData['user_id']          = $userInfo['id'];
    $insertData['openid']           = $userInfo['openid'];
    $insertData['tctoutiao_id']     = $tctoutiaoInfo['id'];
    $insertData['zuozhe_id']        = $zuozheInfo['id'];
    if($tctoutiaoInfo['tougao_user_id'] > 0){
        $insertData['zuozhe_user_id']   = $tctoutiaoInfo['tougao_user_id'];
    }else{
        $insertData['zuozhe_user_id']   = $zuozheInfo['user_id'];
    }
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tctoutiao#tom_tctoutiao_order')->insert($insertData)){
        $order_id = C::t('#tom_tctoutiao#tom_tctoutiao_order')->insert_id();
        
        $insertData = array();
        $insertData['plugin_id']       = 'tom_tctoutiao';          
        $insertData['order_no']        = $order_no;                 
        $insertData['goods_id']        = $tctoutiaoInfo['id'];         
        $insertData['goods_name']      = $tctoutiaoInfo['title'];      
        $insertData['goods_beizu']     = '';
        $insertData['goods_url']       = 'plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=info&aid='.$tctoutiaoInfo['id'];
        $insertData['succ_back_url']   = 'plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=info&aid='.$tctoutiaoInfo['id'];
        $insertData['fail_back_url']   = "plugin.php?id=tom_tctoutiao&site={$site_id}&mod=info&aid=".$tctoutiaoInfo['id'];
        $insertData['allow_alipay']    = 1;    
        $insertData['pay_price']       = $pay_price;
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'    => 200,
                'payurl' => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}