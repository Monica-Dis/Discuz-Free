<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tctoutiaoConfig = $_G['cache']['plugin']['tom_tctoutiao'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = '20191204';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tctoutiaoConfig['wx_share_title'];
$shareDesc = $tctoutiaoConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tctoutiao&site=' . $site_id . '&mod=index');
$shareLogo = $tctoutiaoConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
$tcadminConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcadmin/tom_tcadmin.inc.php')) {
	$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
$__ShowTcshop = 0;
$tcshopConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcshop/tom_tcshop.inc.php')) {
	$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
	if ($tcshopConfig['open_tcshop'] == 1) {
		$__ShowTcshop = 1;
	}
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')) {
	$tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
	if ($tcqianggouConfig['open_tcqianggou'] == 1) {
		$__ShowTcqianggou = 1;
	}
}
$__ShowTcmall = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcmall/tom_tcmall.inc.php')) {
	$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
	if ($tcmallConfig['open_tcmall'] == 1) {
		$__ShowTcmall = 1;
	}
}
$__ShowLove = 0;
$jyConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_love/tom_love.inc.php')) {
	$jyConfig = $_G['cache']['plugin']['tom_love'];
	if ($jyConfig['open_tongcheng'] == 1) {
		$__ShowLove = 1;
	}
}
$__ShowTcsign = 0;
$tcsignConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcsign/tom_tcsign.inc.php')) {
	$tcsignConfig = $_G['cache']['plugin']['tom_tcsign'];
	$__ShowTcsign = 1;
}
$__ShowVideo = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/video.inc.php')) {
	$__ShowVideo = 1;
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$ajaxLoadListUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
$ajaxCheckSubscribeUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=check_subscribe&formhash=' . $formhash;
$ajaxCloseSubscribeUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=close_subscribe&formhash=' . $formhash;
$footer_nav_content_name = $footer_nav_content_link = $footer_nav_content_ico = '';
if ($tongchengConfig['footer_nav_mod'] == 1) {
	if (!empty($tongchengConfig['footer_nav_content'])) {
		$footer_nav_content = explode('|', $tongchengConfig['footer_nav_content']);
		$footer_nav_content_name = $footer_nav_content[0];
		$footer_nav_content_link = $footer_nav_content[1];
		$footer_nav_content_link = str_replace('{site}', $site_id, $footer_nav_content_link);
		if (isset($footer_nav_content[2]) && !empty($footer_nav_content[2])) {
			$footer_nav_content_ico = $footer_nav_content[2];
		}
	}
}
if ($_GET['mod'] == 'index') {
	$cate_id = intval($_GET['cate_id']) ? intval($_GET['cate_id']) : 0;
	$label_id = intval($_GET['label_id']) ? intval($_GET['label_id']) : 0;
	if ($site_id == 1 && $tcadminConfig['open_memory'] == 1 && $__UserInfo['id'] > 0 && $__UserInfo['site_id'] > 1) {
		$memorySitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($__UserInfo['site_id']);
		if ($memorySitesInfoTmp['status'] == 1 && $memorySitesInfoTmp['open_sites'] == 1) {
			tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tctoutiao&site=' . $__UserInfo['site_id'] . '&mod=index'));
			exit(0);
		}
	}
	$focuspicListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' AND type = 1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_focuspic')->fetch_all_list(' AND site_id=1 AND type = 1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	if (is_array($focuspicListTmp) && !empty($focuspicListTmp)) {
		foreach ($focuspicListTmp as $key => $value) {
			$focuspicList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$focuspicList[$key]['picurl'] = $picurl;
		}
	}
	$cateListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_cate')->fetch_all_list(' AND is_show = 1 ', 'ORDER BY csort ASC, id DESC', 0, 100);
	$cateList = array();
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
		}
	}
	$guanzuCount = 0;
	$guanzuList = array();
	if ($__UserInfo['id'] > 0) {
		$guanzuCount = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_guanzu')->fetch_all_count('AND user_id = ' . $__UserInfo['id'] . ' ');
		$guanzuListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_guanzu')->fetch_all_list('AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 500);
		if (is_array($guanzuListTmp) && !empty($guanzuListTmp)) {
			foreach ($guanzuListTmp as $key => $value) {
				$guanzuList[$key] = $value;
				$zuozheInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($value['zuozhe_id']);
				$guanzuList[$key]['zuozhe'] = $zuozheInfoTmp;
				if (!preg_match('/^http/', $zuozheInfoTmp['picurl'])) {
					if (strpos($zuozheInfoTmp['picurl'], 'source/plugin/tom_') === false) {
						$guanzuList[$key]['zuozhe']['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $zuozheInfoTmp['picurl'];
					} else {
						$guanzuList[$key]['zuozhe']['picurl'] = $zuozheInfoTmp['picurl'];
					}
				} else {
					$guanzuList[$key]['zuozhe']['picurl'] = $zuozheInfoTmp['picurl'];
				}
			}
		}
	}
	if ($guanzuCount == 0) {
		$zuozheListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(' ', 'ORDER BY id DESC', 0, 500);
		$zuozheList = $tcshopZuozheList = array();
		if (is_array($zuozheListTmp) && !empty($zuozheListTmp)) {
			foreach ($zuozheListTmp as $key => $value) {
				if (!preg_match('/^http/', $value['picurl'])) {
					if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
						$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
					} else {
						$picurlTmp = $value['picurl'];
					}
				} else {
					$picurlTmp = $value['picurl'];
				}
				if ($value['type'] == 3) {
					$tcshopZuozheList[$key] = $value;
					$tcshopZuozheList[$key]['picurl'] = $picurlTmp;
				} else {
					$zuozheList[$key] = $value;
					$zuozheList[$key]['picurl'] = $picurlTmp;
				}
			}
		}
	}
	$showMyfabuBtn = 0;
	if ($__UserInfo['id'] > 0) {
		$zuozheCount = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_count(' AND user_id = ' . $__UserInfo['id'] . ' AND type IN(1,2) ');
		if ($zuozheCount > 0) {
			$showMyfabuBtn = 1;
		}
		if ($__UserInfo['id'] == $tongchengConfig['manage_user_id']) {
			$showMyfabuBtn = 1;
		}
	}
	$back_url = $weixinClass->get_url();
	$back_url = urlencode($back_url);
	$tougaoUrl = 'plugin.php?id=tom_tctoutiao&site=' . $site_id . '&mod=tougao&back_url=' . $back_url;
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tctoutiao&site=' . $site_id . '&mod=index&cate_id=' . $cate_id . '&label_id=' . $label_id));
	$ajaxGuanzuUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&user_id=' . $__UserInfo['id'] . '&act=guanzu&formhash=' . $formhash;
	$title = $tctoutiaoConfig['plugin_name'] . ' - ' . $__SitesInfo['name'];
	if ($cate_id > 0) {
		$cateInfo = C::t('#tom_tctoutiao#tom_tctoutiao_cate')->fetch_by_id($cate_id);
		if ($cateInfo['id'] > 0) {
			$shareTitle = $cateInfo['name'] . '-' . $tctoutiaoConfig['plugin_name'];
			$title = $cateInfo['name'] . '-' . $tctoutiaoConfig['plugin_name'];
		}
	} else {
		if ($label_id > 0) {
			$labelInfo = C::t('#tom_tctoutiao#tom_tctoutiao_label')->fetch_by_id($cate_id);
			if ($labelInfo['id'] > 0) {
				$shareTitle = $labelInfo['name'] . '-' . $tctoutiaoConfig['plugin_name'];
				$title = $labelInfo['name'] . '-' . $tctoutiaoConfig['plugin_name'];
			}
		}
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tctoutiao&site=' . $site_id . '&mod=index&cate_id=' . $cate_id . '&label_id=' . $label_id);
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tctoutiao/images/index.js';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tctoutiao:index');
	echo '<script src="source/plugin/tom_tctoutiao/images/index.js"></script>';
} elseif ($_GET['mod'] == 'search') {
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$hotSearchStr = str_replace("\r\n", '{n}', $tctoutiaoConfig['hot_search_str']);
	$hotSearchStr = str_replace("\n", '{n}', $hotSearchStr);
	$hotSearchStr = str_replace("\r", '{n}', $hotSearchStr);
	$hotSearchArr = explode('{n}', $hotSearchStr);
	$hotSearchList = array();
	if (is_array($hotSearchArr) && !empty($hotSearchArr)) {
		foreach ($hotSearchArr as $key => $value) {
			if (!empty($value)) {
				$hotSearchList[$key]['title'] = $value;
				$hotSearchList[$key]['keyword'] = urldecode($value);
			}
		}
	}
	$hotSearchCount = count($hotSearchList);
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tctoutiao&site=' . $site_id . '&mod=search&keyword=' . $keyword));
	$searchUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=get_search_url';
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tctoutiao&site=' . $site_id . '&mod=search&keyword=') . urlencode($_GET['keyword']);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tctoutiao:search');
} elseif ($_GET['mod'] == 'info') {
	$tctoutiao_id = intval($_GET['tctoutiao_id']) ? intval($_GET['tctoutiao_id']) : 0;
	$aid = intval($_GET['aid']) ? intval($_GET['aid']) : 0;
	if ($aid > 0) {
		$tctoutiao_id = $aid;
	}
	$tctoutiaoInfo = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_by_id($tctoutiao_id);
	if ($tctoutiaoInfo['id'] <= 0 || $tctoutiaoInfo['status'] != 1 || $tctoutiaoInfo['shenhe_status'] != 1) {
		$isGbk = false;
		if (CHARSET == 'gbk') {
			$isGbk = true;
		}
		include template('tom_tctoutiao:404');
		tomoutput();
		exit(0);
	}
	$zuozheInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($tctoutiaoInfo['zuozhe_id']);
	if (!preg_match('/^http/', $zuozheInfo['picurl'])) {
		if (strpos($zuozheInfo['picurl'], 'source/plugin/tom_') === false) {
			$zuozheLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $zuozheInfo['picurl'];
		} else {
			$zuozheLogo = $_G['siteurl'] . $zuozheInfo['picurl'];
		}
	} else {
		$zuozheLogo = $zuozheInfo['picurl'];
	}
	$guanzuStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$guanzuInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_guanzu')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND zuozhe_id = ' . $tctoutiaoInfo['zuozhe_id'] . '  ', 'ORDER BY id DESC', 0, 1);
		if ($guanzuInfo[0]['id'] > 0) {
			$guanzuStatus = 1;
		}
	}
	$tctoutiaoInfo['clicks'] = $tctoutiaoInfo['clicks'] + $tctoutiaoInfo['virtual_clicks'];
	$pinglunCount = C::t('#tom_tctoutiao#tom_tctoutiao_pinglun')->fetch_all_count(' AND tctoutiao_id = ' . $tctoutiaoInfo['id'] . ' ');
	$showFufeiTemplate = 0;
	if ($tctoutiaoInfo['type'] == 1 || $tctoutiaoInfo['type'] == 3) {
		if ($tctoutiaoConfig['open_pay_reading'] == 1 && $tctoutiaoInfo['open_pay_reading'] == 1) {
			$showFufeiTemplate = 1;
			$tctoutiaoInfo['app_read'] = 0;
			$payReadingCount = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_count('AND tctoutiao_id = ' . $tctoutiao_id . ' AND order_type = 2 AND order_status = 2');
			$payReadingListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_list('AND tctoutiao_id = ' . $tctoutiao_id . ' AND order_type = 2 AND order_status = 2', 'ORDER BY order_time DESC,id DESC', 0, 5);
			$payReadingList = array();
			if (is_array($payReadingListTmp) && !empty($payReadingListTmp)) {
				foreach ($payReadingListTmp as $key => $value) {
					$payReadingList[$key] = $value;
					$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
					$payReadingList[$key]['userInfo'] = $userInfoTmp;
				}
			}
			$payReadingStatus = 0;
			if ($__UserInfo['id'] > 0) {
				$payReadingInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_list('AND tctoutiao_id = ' . $tctoutiao_id . ' AND user_id = ' . $__UserInfo['id'] . ' AND order_type = 2 AND order_status = 2', 'ORDER BY id DESC', 0, 1);
				if (is_array($payReadingInfoTmp) && !empty($payReadingInfoTmp[0])) {
					$payReadingStatus = 1;
				}
			}
			if ($payReadingStatus == 0) {
				if ($tctoutiaoInfo['type'] == 1) {
					$tctoutiaoInfo['content'] = $tctoutiaoInfo['nopay_content'];
				}
				if ($tctoutiaoInfo['type'] == 3) {
					$tctoutiaoInfo['video_link'] = $tctoutiaoInfo['nopay_video_link'];
				}
			}
		} else {
			if ($tctoutiaoConfig['open_reward'] == 1) {
				$showFufeiTemplate = 2;
				$rewardCount = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_count('AND tctoutiao_id = ' . $tctoutiao_id . ' AND order_type = 1 AND order_status = 2');
				$rewardListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_list('AND tctoutiao_id = ' . $tctoutiao_id . ' AND order_type = 1 AND order_status = 2', 'ORDER BY id DESC', 0, 50);
				$rewardList = array();
				if (is_array($rewardListTmp) && !empty($rewardListTmp)) {
					foreach ($rewardListTmp as $key => $value) {
						$rewardList[$key] = $value;
						$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
						$rewardList[$key]['userInfo'] = $userInfoTmp;
					}
				}
				$rewardMoneyStr = str_replace("\r\n", '{n}', $tctoutiaoConfig['reward_money']);
				$rewardMoneyStr = str_replace("\n", '{n}', $rewardMoneyStr);
				$rewardMoneyStr = str_replace("\r", '{n}', $rewardMoneyStr);
				$rewardMoneyArr = explode('{n}', $rewardMoneyStr);
				$rewardMoneyList = array();
				$i = 1;
				if (is_array($rewardMoneyArr) && !empty($rewardMoneyArr)) {
					foreach ($rewardMoneyArr as $key => $value) {
						if (!empty($value)) {
							$rewardMoneyList[$i] = floatval($value);
							$i = $i + 1;
						}
					}
				}
			}
		}
		$content = stripslashes($tctoutiaoInfo['content']);
		if ($tongchengConfig['open_yun'] == 2 || $tongchengConfig['open_yun'] == 3) {
			$photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(' AND tctoutiao_id = ' . $tctoutiao_id . ' AND type = 5 ', 'ORDER BY psort ASC,id DESC', 0, 100);
			if (is_array($photoListTmp) && !empty($photoListTmp)) {
				foreach ($photoListTmp as $key => $value) {
					if ($value['is_yun_pic'] == 1) {
						$content = str_replace($value['picurl'], $value['picurlTmp'], $content);
					}
				}
			}
		}
	}
	if ($tctoutiaoInfo['type'] == 2) {
		$photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(' AND tctoutiao_id = ' . $tctoutiao_id . ' AND type = 2 ', 'ORDER BY psort ASC,id DESC', 0, 100);
		$photoList = array();
		$i = 0;
		if (is_array($photoListTmp) && !empty($photoListTmp)) {
			foreach ($photoListTmp as $key => $value) {
				$i = $i + 1;
				$photoList[$key] = $value;
				$photoList[$key]['i'] = $i;
			}
		}
	}
	if ($tctoutiaoInfo['type'] == 3) {
		$video_type = '';
		$video_id = '';
		if (strpos($tctoutiaoInfo['video_link'], 'youku.com') !== false) {
			preg_match('#embed/(.*)#', $tctoutiaoInfo['video_link'], $matches);
			if (is_array($matches) && !empty($matches['1'])) {
				$video_type = 'youku';
				$video_id = trim($matches['1']);
			}
		} elseif (strpos($tctoutiaoInfo['video_link'], 'qq.com') !== false) {
			preg_match('#vid=([0-9a-zA-Z]*)#', $tctoutiaoInfo['video_link'], $matches);
			if (is_array($matches) && !empty($matches['1'])) {
				$video_type = 'qq';
				$video_id = trim($matches['1']);
			}
		} elseif (strpos($tctoutiaoInfo['video_link'], '.mp4') !== false || strpos($tctoutiaoInfo['video_link'], '.MP4') !== false) {
			$video_type = 'video';
		} elseif (strpos($tctoutiaoInfo['video_link'], '.MOV') !== false || strpos($tctoutiaoInfo['video_link'], '.mov') !== false) {
			$video_type = 'video';
		} else {
			$video_type = 'other';
		}
	}
	$tcqianggouList = array();
	$tcqianggouCount = 0;
	$tcqianggouLength = 10;
	if ($tctoutiaoInfo['type'] != 2 && (!empty($tctoutiaoInfo['tcqianggou_ids']) || $zuozheInfo['type'] == 3) && $__ShowTcqianggou == 1) {
		$qgWhere = ' AND status=1 AND shenhe_status=1 AND type_id=1 ';
		if ($zuozheInfo['type'] == 3) {
			$tcqianggouLength = 2;
			$qgWhere .= ' AND tcshop_id = ' . $zuozheInfo['tcshop_id'] . ' ';
		} else {
			$tcqianggou_ids_arr = explode('|', $tctoutiaoInfo['tcqianggou_ids']);
			$tcqianggouIdsArr = array();
			if (is_array($tcqianggou_ids_arr) && !empty($tcqianggou_ids_arr)) {
				foreach ($tcqianggou_ids_arr as $key => $value) {
					$value = (int) $value;
					if (!empty($value)) {
						$tcqianggouIdsArr[] = $value;
					}
				}
			}
			if (!empty($tcqianggouIdsArr)) {
				$tcqianggouIdsStr = implode(',', $tcqianggouIdsArr);
				$qgWhere .= ' AND id IN(' . $tcqianggouIdsStr . ')  ';
			} else {
				$qgWhere = '';
			}
		}
		if (!empty($qgWhere)) {
			$tcqianggouListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list($qgWhere, ' ORDER BY paixu ASC,id DESC ', 0, $tcqianggouLength);
			if (is_array($tcqianggouListTmp) && !empty($tcqianggouListTmp)) {
				foreach ($tcqianggouListTmp as $key => $value) {
					$tcqianggouList[$key] = $value;
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					$tcqianggouList[$key]['picurl'] = $picurlTmp;
					if (floatval($value['show_buy_price']) <= 0) {
						$tcqianggouList[$key]['show_buy_price'] = $value['buy_price'];
						$tcqianggouList[$key]['show_vip_price'] = $value['vip_price'];
						$tcqianggouList[$key]['show_market_price'] = $value['market_price'];
						$tcqianggouList[$key]['show_before_price'] = $value['before_price'];
					}
				}
			}
		}
		$tcqianggouCount = count($tcqianggouList);
	}
	$tcmallList = array();
	$tcmallCount = 0;
	$tcmallLength = 10;
	if ($tctoutiaoInfo['type'] != 2 && (!empty($tctoutiaoInfo['tcmall_ids']) || $zuozheInfo['type'] == 3) && $__ShowTcmall == 1) {
		$mallWhere = ' AND status=1 AND shenhe_status=1 ';
		if ($zuozheInfo['type'] == 3) {
			$tcmallLength = 2;
			$mallWhere .= ' AND tcshop_id = ' . $zuozheInfo['tcshop_id'] . ' ';
		} else {
			$tcmall_ids_arr = explode('|', $tctoutiaoInfo['tcmall_ids']);
			$tcmallIdsArr = array();
			if (is_array($tcmall_ids_arr) && !empty($tcmall_ids_arr)) {
				foreach ($tcmall_ids_arr as $key => $value) {
					$value = (int) $value;
					if (!empty($value)) {
						$tcmallIdsArr[] = $value;
					}
				}
			}
			if (!empty($tcmallIdsArr)) {
				$tcmallIdsStr = implode(',', $tcmallIdsArr);
				$mallWhere .= ' AND id IN(' . $tcmallIdsStr . ') ';
			} else {
				$mallWhere = '';
			}
		}
		if (!empty($mallWhere)) {
			$mallGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list($mallWhere, ' ORDER BY gsort ASC,id DESC ', 0, $tcmallLength);
			if (is_array($mallGoodsListTmp) && !empty($mallGoodsListTmp)) {
				foreach ($mallGoodsListTmp as $key => $value) {
					$tcmallList[$key] = $value;
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					$tcmallList[$key]['picurl'] = $picurlTmp;
				}
			}
		}
		$tcmallCount = count($tcmallList);
	}
	$tcshopList = array();
	$tcshopCount = 0;
	if (!empty($tctoutiaoInfo['tcshop_ids']) && $__ShowTcshop == 1) {
		$tcshop_ids_arr = explode('|', $tctoutiaoInfo['tcshop_ids']);
		$tcshopIdsArr = array();
		if (is_array($tcshop_ids_arr) && !empty($tcshop_ids_arr)) {
			foreach ($tcshop_ids_arr as $key => $value) {
				$value = (int) $value;
				if (!empty($value)) {
					$tcshopIdsArr[] = $value;
				}
			}
		}
		if (!empty($tcshopIdsArr)) {
			$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND id IN(' . implode(',', $tcshopIdsArr) . ') ', 'ORDER BY id DESC', 0, 10);
			if (is_array($tcshopListTmp) && !empty($tcshopListTmp)) {
				foreach ($tcshopListTmp as $key => $value) {
					$tcshopList[$key] = $value;
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					$tcshopList[$key]['picurl'] = $picurlTmp;
				}
			}
		}
		$tcshopCount = count($tcshopList);
	}
	$focuspicListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' AND type = 2 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_focuspic')->fetch_all_list(' AND site_id=1 AND type = 2 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	if (is_array($focuspicListTmp) && !empty($focuspicListTmp)) {
		foreach ($focuspicListTmp as $key => $value) {
			$focuspicList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$focuspicList[$key]['picurl'] = $picurl;
		}
	}
	$open_edit_pinglun = 0;
	if ($zuozheInfo['user_id'] == $__UserInfo['id'] && $tongchengConfig['open_fbr_remove_pinglun'] == 1) {
		$open_edit_pinglun = 1;
	} else {
		if ($__UserInfo['groupid'] == 1 && $site_id == 1) {
			$open_edit_pinglun = 1;
		} else {
			if ($__UserInfo['groupid'] == 2 && $site_id == $__UserInfo['groupsiteid']) {
				$open_edit_pinglun = 1;
			}
		}
	}
	$must_phone_projectArr = unserialize($tongchengConfig['must_phone_project']);
	$showMustPhoneBtn = 0;
	if (array_search('2', $must_phone_projectArr) !== false && empty($__UserInfo['tel']) && $__UserInfo['editor'] == 0 && $__UserInfo['is_majia'] == 0) {
		$showMustPhoneBtn = 1;
		$phone_back_url = $weixinClass->get_url();
		$phone_back_url = urlencode($phone_back_url);
		$phoneUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=phone&phone_back=' . $phone_back_url;
	}
	if ($__IsQianfan == 1 || $__IsXiaoyun == 1 || $__IsMagapp == 1 || $__IsMocuzapp == 1 || $__IsApp == 1) {
		$tctoutiaoInfo['app_read'] = 0;
	}
	$shareTitle = $tctoutiaoInfo['title'];
	if (!empty($tctoutiaoInfo['share_title'])) {
		$shareTitle = $tctoutiaoInfo['share_title'];
	}
	if (!empty($content)) {
		$contentTmp = strip_tags($content);
		$contentTmp = str_replace("\r\n", '', $contentTmp);
		$contentTmp = str_replace("\n", '', $contentTmp);
		$contentTmp = str_replace("\r", '', $contentTmp);
		$shareDesc = cutstr($contentTmp, 100, '...');
	} else {
		$shareDesc = $tctoutiaoInfo['title'];
	}
	if (!empty($tctoutiaoInfo['share_desc'])) {
		$shareDesc = $tctoutiaoInfo['share_desc'];
	}
	$shareLogo = $zuozheLogo;
	if (!empty($tctoutiaoInfo['share_pic'])) {
		if (!preg_match('/^http/', $tctoutiaoInfo['share_pic'])) {
			if (strpos($tctoutiaoInfo['share_pic'], 'source/plugin/tom_') === false) {
				$shareLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tctoutiaoInfo['share_pic'];
			} else {
				$shareLogo = $_G['siteurl'] . $tctoutiaoInfo['share_pic'];
			}
		} else {
			$shareLogo = $tctoutiaoInfo['share_pic'];
		}
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tctoutiao&site=' . $site_id . '&mod=info&aid=' . $tctoutiao_id);
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$haibaoPic = $video_pic = '';
	if ($tctoutiaoInfo['type'] == 1) {
		$photoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(' AND tctoutiao_id = ' . $tctoutiaoInfo['id'] . ' AND type = 1 ', 'ORDER BY psort ASC,id DESC', 0, 1);
		if (!empty($photoInfoTmp[0]['picurlTmp'])) {
			$haibaoPic = $photoInfoTmp[0]['picurlTmp'];
		}
	} elseif ($tctoutiaoInfo['type'] == 3) {
		$photoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(' AND tctoutiao_id = ' . $tctoutiaoInfo['id'] . ' AND type = 3 ', 'ORDER BY psort ASC,id DESC', 0, 1);
		if (!empty($photoInfoTmp[0]['picurlTmp'])) {
			$haibaoPic = $photoInfoTmp[0]['picurlTmp'];
			$video_pic = $photoInfoTmp[0]['picurlTmp'];
		}
	}
	$haibaoPic = str_replace($_G['siteurl'], '', $haibaoPic);
	$haibaoPic = ltrim($haibaoPic, '/');
	$haibaoZuozhePic = str_replace($_G['siteurl'], '', $zuozheLogo);
	$haibaoZuozhePic = ltrim($haibaoZuozhePic, '/');
	if ($__ShowTcsign == 1) {
		include DISCUZ_ROOT . './source/plugin/tom_tcsign/renwu/toutiao.php';
	}
	$ajaxTuiDoTzUrl = '';
	if ($__ShowTchehuoren == 1 && file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tui_do.php')) {
		include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tui_do.php';
	}
	$back_url = $weixinClass->get_url();
	$back_url = urlencode($back_url);
	$tougaoUrl = 'plugin.php?id=tom_tctoutiao&site=' . $site_id . '&mod=tougao&back_url=' . $back_url;
	$ajaxLoadMoreUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=info_load_more&tctoutiao_id=' . $tctoutiao_id . '&zuozhe_id=' . $tctoutiaoInfo['zuozhe_id'] . '&cate_id=' . $tctoutiaoInfo['cate_id'] . '&formhash=' . FORMHASH;
	$ajaxLoadFenleiUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=load_fenlei&formhash=' . FORMHASH;
	$zanAjaxUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=zan&tctoutiao_id=' . $tctoutiao_id . '&formhash=' . FORMHASH;
	$addPinglunUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=pinglun&tctoutiao_id=' . $tctoutiao_id . '&formhash=' . FORMHASH;
	$showPinglunUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=loadPinglun&tctoutiao_id=' . $tctoutiao_id . '&formhash=' . FORMHASH;
	$removePinglunUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=removePinglun&tctoutiao_id=' . $tctoutiao_id . '&formhash=' . FORMHASH;
	$ajaxGuanzuUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&user_id=' . $__UserInfo['id'] . '&zuozhe_id=' . $zuozheInfo['id'] . '&act=guanzu&formhash=' . $formhash;
	$ajaxCollectUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&user_id=' . $__UserInfo['id'] . '&tctoutiao_id=' . $tctoutiao_id . '&act=collect&formhash=' . $formhash;
	$ajaxClicksUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=clicks&tctoutiao_id=' . $tctoutiao_id . '&formhash=' . $formhash;
	$rewardPayUrl = 'plugin.php?id=tom_tctoutiao:pay&site=' . $site_id . '&act=reward&tctoutiao_id=' . $tctoutiao_id . '&user_id=' . $__UserInfo['id'] . '&formhash=' . $formhash;
	$payreadingUrl = 'plugin.php?id=tom_tctoutiao:pay&site=' . $site_id . '&act=payreading&tctoutiao_id=' . $tctoutiao_id . '&user_id=' . $__UserInfo['id'] . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	if ($tctoutiaoInfo['type'] == 2) {
		include template('tom_tctoutiao:slideinfo');
	} else {
		include template('tom_tctoutiao:info');
	}
} elseif ($_GET['mod'] == 'guan') {
	$zuozheListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(' ', 'ORDER BY id DESC', 0, 500);
	$zuozheList = $tcshopZuozheList = array();
	if (is_array($zuozheListTmp) && !empty($zuozheListTmp)) {
		foreach ($zuozheListTmp as $key => $value) {
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$guanzuCountTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_guanzu')->fetch_all_count('AND user_id = ' . $__UserInfo['id'] . ' AND zuozhe_id =  ' . $value['id'] . ' ');
			if ($guanzuCountTmp > 0) {
				$value['on'] = 1;
			} else {
				$value['on'] = 0;
			}
			if ($value['type'] == 3) {
				$tcshopZuozheList[$key] = $value;
				$tcshopZuozheList[$key]['picurl'] = $picurlTmp;
			} else {
				$zuozheList[$key] = $value;
				$zuozheList[$key]['picurl'] = $picurlTmp;
			}
		}
	}
	$ajaxGuanzuUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&user_id=' . $__UserInfo['id'] . '&act=guanzu&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tctoutiao:guanzu');
} elseif ($_GET['mod'] == 'zuozheinfo') {
	$zuozhe_id = intval($_GET['zuozhe_id']) > 0 ? intval($_GET['zuozhe_id']) : 0;
	$zuozheInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($zuozhe_id);
	$guanzuCount = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_guanzu')->fetch_all_count(' AND zuozhe_id = ' . $zuozhe_id . ' ');
	if (!preg_match('/^http/', $zuozheInfo['picurl'])) {
		if (strpos($zuozheInfo['picurl'], 'source/plugin/tom_') === false) {
			$zuozheLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $zuozheInfo['picurl'];
		} else {
			$zuozheLogo = $_G['siteurl'] . $zuozheInfo['picurl'];
		}
	} else {
		$zuozheLogo = $zuozheInfo['picurl'];
	}
	if (!preg_match('/^http/', $zuozheInfo['bgpic'])) {
		if (strpos($zuozheInfo['bgpic'], 'source/plugin/tom_') === false) {
			$zuozheBgpic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $zuozheInfo['bgpic'];
		} else {
			$zuozheBgpic = $_G['siteurl'] . $zuozheInfo['bgpic'];
		}
	} else {
		$zuozheBgpic = $zuozheInfo['bgpic'];
	}
	$guanzuStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$guanzuInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_guanzu')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND zuozhe_id = ' . $zuozhe_id . '  ', 'ORDER BY id DESC', 0, 1);
		if ($guanzuInfo[0]['id'] > 0) {
			$guanzuStatus = 1;
		}
	}
	$shareTitle = $zuozheInfo['name'];
	$shareLogo = $zuozheLogo;
	$zuozheInfo['content'] = str_replace("\r\n", '', $zuozheInfo['content']);
	$zuozheInfo['content'] = str_replace("\n", '', $zuozheInfo['content']);
	$zuozheInfo['content'] = str_replace("\r", '', $zuozheInfo['content']);
	$shareDesc = $zuozheInfo['content'];
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tctoutiao&site=' . $site_id . '&mod=zuozheinfo&zuozhe_id=' . $zuozhe_id);
	$ajaxGuanzuUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&user_id=' . $__UserInfo['id'] . '&zuozhe_id=' . $zuozhe_id . '&act=guanzu&formhash=' . $formhash;
	$ajaxLoadListUrl .= '&zuozhe_id=' . $zuozhe_id;
	$messageUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&&to_user_id=' . $zuozheInfo['user_id'] . '&formhash=' . FORMHASH;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$back_url = $weixinClass->get_url();
	$back_url = urlencode($back_url);
	$tougaoUrl = 'plugin.php?id=tom_tctoutiao&site=' . $site_id . '&mod=tougao&back_url=' . $back_url;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tctoutiao:zuozheinfo');
} elseif ($_GET['mod'] == 'pinglunlist') {
	$tctoutiao_id = intval($_GET['tctoutiao_id']) > 0 ? intval($_GET['tctoutiao_id']) : 0;
	$back_url = isset($_GET['back_url']) ? addslashes($_GET['back_url']) : '';
	$tctoutiaoInfo = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_by_id($tctoutiao_id);
	$zuozheInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($tctoutiaoInfo['zuozhe_id']);
	$open_edit_pinglun = 0;
	if ($zuozheInfo['user_id'] == $__UserInfo['id'] && $tongchengConfig['open_fbr_remove_pinglun'] == 1) {
		$open_edit_pinglun = 1;
	} else {
		if ($__UserInfo['groupid'] == 1 && $site_id == 1) {
			$open_edit_pinglun = 1;
		} else {
			if ($__UserInfo['groupid'] == 2 && $site_id == $__UserInfo['groupsiteid']) {
				$open_edit_pinglun = 1;
			}
		}
	}
	$must_phone_projectArr = unserialize($tongchengConfig['must_phone_project']);
	$showMustPhoneBtn = 0;
	if (array_search('2', $must_phone_projectArr) !== false && empty($__UserInfo['tel']) && $__UserInfo['editor'] == 0 && $__UserInfo['is_majia'] == 0) {
		$showMustPhoneBtn = 1;
		$phone_back_url = $weixinClass->get_url();
		$phone_back_url = urlencode($phone_back_url);
		$phoneUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=phone&phone_back=' . $phone_back_url;
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tctoutiao&site=' . $site_id . '&mod=pinglunlist&tctoutiao_id=' . $tctoutiao_id);
	$addPinglunUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=pinglun&tctoutiao_id=' . $tctoutiao_id . '&formhash=' . FORMHASH;
	$showPinglunUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=loadPinglun&tctoutiao_id=' . $tctoutiao_id . '&formhash=' . FORMHASH;
	$removePinglunUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=removePinglun&tctoutiao_id=' . $tctoutiao_id . '&formhash=' . FORMHASH;
	$ajaxClicksUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=clicks&tctoutiao_id=' . $tctoutiao_id . '&formhash=' . $formhash;
	$zanAjaxUrl = 'plugin.php?id=tom_tctoutiao:ajax&site=' . $site_id . '&act=zan&tctoutiao_id=' . $tctoutiao_id . '&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tctoutiao:pinglunlist');
} elseif ($_GET['mod'] == 'ruzhu') {
	include DISCUZ_ROOT . './source/plugin/tom_tctoutiao/module/ruzhu.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tctoutiao/module/upload.php';
} elseif ($_GET['mod'] == 'fabu') {
	include DISCUZ_ROOT . './source/plugin/tom_tctoutiao/module/fabu.php';
} elseif ($_GET['mod'] == 'myfabu') {
	include DISCUZ_ROOT . './source/plugin/tom_tctoutiao/module/myfabu.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tctoutiao/module/edit.php';
} elseif ($_GET['mod'] == 'zuozheedit') {
	include DISCUZ_ROOT . './source/plugin/tom_tctoutiao/module/zuozheedit.php';
} elseif ($_GET['mod'] == 'tougao') {
	include DISCUZ_ROOT . './source/plugin/tom_tctoutiao/module/tougao.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tctoutiao&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();