<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tctoutiao`;
CREATE TABLE `pre_tom_tctoutiao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `zuozhe_id` int(11) DEFAULT '0',
  `tcshop_ids` varchar(255) DEFAULT '0',
  `search_tcshop_ids` varchar(255) DEFAULT NULL,
  `tcqianggou_ids` varchar(255) DEFAULT '0',
  `tcmall_ids` varchar(255) DEFAULT '0',
  `cate_id` int(11) DEFAULT '0',
  `label_id` int(11) DEFAULT '0',
  `label_name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `open_pay_reading` int(11) DEFAULT '0',
  `pay_reading_price` decimal(10,2) DEFAULT '0.00',
  `app_read` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `virtual_clicks` int(11) DEFAULT '0',
  `nopay_video_link` varchar(255) DEFAULT NULL,
  `video_link` varchar(255) DEFAULT NULL,
  `list_bigpic` tinyint(4) DEFAULT '1',
  `tuji_listpic_type` tinyint(4) DEFAULT '0',
  `is_recom` tinyint(4) DEFAULT '0',
  `nopay_content` text,
  `content` mediumtext,
  `share_title` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `share_pic` varchar(255) DEFAULT NULL,
  `tougao_user_id` int(11) DEFAULT '0',
  `tougao_laiyuan` varchar(255) DEFAULT NULL,
  `mobile_status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `index_show` tinyint(4) DEFAULT '1',
  `paixu` int(11) DEFAULT '666666',
  `search_text` text,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_zuozhe_id` (`zuozhe_id`),
  KEY `idx_cate_id` (`cate_id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_paixu` (`paixu`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_cate`;
CREATE TABLE `pre_tom_tctoutiao_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `is_show` int(11) DEFAULT '1',
  `add_time` int(11) DEFAULT '0',
  `csort` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_collect`;
CREATE TABLE `pre_tom_tctoutiao_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tctoutiao_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_focuspic`;
CREATE TABLE `pre_tom_tctoutiao_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_label`;
CREATE TABLE `pre_tom_tctoutiao_label` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_order`;
CREATE TABLE `pre_tom_tctoutiao_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `order_no` varchar(255) DEFAULT NULL,
  `order_type` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `tctoutiao_id` int(11) DEFAULT '0',
  `zuozhe_id` int(11) DEFAULT '0',
  `zuozhe_user_id` int(11) DEFAULT '0',
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `zuozhe_shouyi_price` decimal(10,2) DEFAULT '0.00',
  `order_time` int(11) DEFAULT '0',
  `pay_time` int(11) DEFAULT '0',
  `order_status` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_photo`;
CREATE TABLE `pre_tom_tctoutiao_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tctoutiao_id` int(11) DEFAULT '0',
  `type` tinyint(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `oss_picurl` varchar(255) DEFAULT NULL,
  `oss_status` int(11) DEFAULT '0',
  `qiniu_picurl` varchar(255) DEFAULT NULL,
  `qiniu_status` int(11) DEFAULT '0',
  `content` varchar(255) DEFAULT NULL,
  `psort` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_pinglun`;
CREATE TABLE `pre_tom_tctoutiao_pinglun` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tctoutiao_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `content` text,
  `pinglun_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_pinglun_reply`;
CREATE TABLE `pre_tom_tctoutiao_pinglun_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tctoutiao_id` int(11) DEFAULT '0',
  `pinglun_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `user_nickname` varchar(255) DEFAULT NULL,
  `user_avatar` varchar(255) DEFAULT NULL,
  `content` text,
  `reply_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_pinglun_zan`;
CREATE TABLE `pre_tom_tctoutiao_pinglun_zan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tctoutiao_id` int(11) DEFAULT '0',
  `pinglun_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `zan_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_zuozhe`;
CREATE TABLE `pre_tom_tctoutiao_zuozhe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bbs_uid` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '1',
  `shenhe_type` tinyint(4) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `bgpic` varchar(255) DEFAULT NULL,
  `reading_fc_scale` int(11) DEFAULT '0',
  `reward_fc_scale` int(11) DEFAULT '0',
  `content` text,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_zuozhe_guanzu`;
CREATE TABLE `pre_tom_tctoutiao_zuozhe_guanzu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `zuozhe_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_zuozhe_shenqing`;
CREATE TABLE `pre_tom_tctoutiao_zuozhe_shenqing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `wx` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `zuozhe_name` varchar(255) DEFAULT NULL,
  `zuozhe_logo` varchar(255) DEFAULT NULL,
  `beizu` text,
  `shenhe_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctoutiao_cache`;
CREATE TABLE `pre_tom_tctoutiao_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` mediumtext,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;