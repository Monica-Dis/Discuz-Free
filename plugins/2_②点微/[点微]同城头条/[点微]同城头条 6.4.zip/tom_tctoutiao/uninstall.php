<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS pre_tom_tctoutiao;
DROP TABLE IF EXISTS pre_tom_tctoutiao_cate;
DROP TABLE IF EXISTS pre_tom_tctoutiao_collect;
DROP TABLE IF EXISTS pre_tom_tctoutiao_focuspic;
DROP TABLE IF EXISTS pre_tom_tctoutiao_label;
DROP TABLE IF EXISTS pre_tom_tctoutiao_order;
DROP TABLE IF EXISTS pre_tom_tctoutiao_photo;
DROP TABLE IF EXISTS pre_tom_tctoutiao_pinglun;
DROP TABLE IF EXISTS pre_tom_tctoutiao_pinglun_reply;
DROP TABLE IF EXISTS pre_tom_tctoutiao_pinglun_zan;
DROP TABLE IF EXISTS pre_tom_tctoutiao_zuozhe;
DROP TABLE IF EXISTS pre_tom_tctoutiao_zuozhe_guanzu;
DROP TABLE IF EXISTS pre_tom_tctoutiao_zuozhe_shenqing;
DROP TABLE IF EXISTS pre_tom_tctoutiao_cache;


EOF;

runquery($sql);

$finish = TRUE;