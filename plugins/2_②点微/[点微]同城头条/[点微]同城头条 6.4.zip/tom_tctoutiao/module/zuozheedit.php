<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
if($tcshopInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$site_id}&mod=myfabu");exit;
}
$zuozheInfoTmp = C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND tcshop_id = {$tcshop_id} AND type = 3 ", 'ORDER BY id DESC', 0 ,1);
$zuozheInfo = array();
if(is_array($zuozheInfoTmp) && !empty($zuozheInfoTmp[0])){
    $zuozheInfo = $zuozheInfoTmp[0];
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$site_id}&mod=myfabu");exit;
}

if($_GET['act'] == 'save' && submitcheck('tcshop_id')){

    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $name       = isset($_GET['name'])? addslashes($_GET['name']):'';
    $picurl     = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $bgpic      = isset($_GET['bgpic'])? addslashes($_GET['bgpic']):'';
    $content    = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $updateData = array();
    $updateData['name']     = $name;
    $updateData['picurl']   = $picurl;
    $updateData['bgpic']    = $bgpic;
    $updateData['content']  = $content;
    $updateData['part1']    = TIMESTAMP;
    if(C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe")->update($zuozheInfo['id'], $updateData)){
        echo 200;exit;
    }else{
        echo 1;exit;
    }
}


if(!preg_match('/^http/', $zuozheInfo['picurl']) ){
    if(strpos($zuozheInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$zuozheInfo['picurl'];
    }else{
        $picurl = $zuozheInfo['picurl'];
    }
}else{
    $picurl = $zuozheInfo['picurl'];
}
if(!preg_match('/^http/', $zuozheInfo['bgpic']) ){
    if(strpos($zuozheInfo['bgpic'], 'source/plugin/tom_') === FALSE){
        $bgpic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$zuozheInfo['bgpic'];
    }else{
        $bgpic = $zuozheInfo['bgpic'];
    }
}else{
    $bgpic = $zuozheInfo['bgpic'];
}

$saveUrl = "plugin.php?id=tom_tctoutiao&mod=zuozheedit&formhash={$formhash}";
$uploadUrl1 = "plugin.php?id=tom_tctoutiao&site={$site_id}&mod=upload&act=fabu_picurl&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tctoutiao:wxMediaDowmload&site={$site_id}&act=fabu_picurl&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tctoutiao:zuozheedit");