<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tctoutiao_id   = isset($_GET['tctoutiao_id'])? intval($_GET['tctoutiao_id']):0;
$back_url       = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$tctoutiaoInfo  = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_by_id($tctoutiao_id);
$zuozheInfo     = C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe")->fetch_by_id($tctoutiaoInfo['zuozhe_id']);
if($zuozheInfo['type'] == 3){
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($zuozheInfo['tcshop_id']);
}

if($__UserInfo['id'] == $tongchengConfig['manage_user_id']){
}else{
    if($__UserInfo['id'] != $zuozheInfo['user_id']){
        dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$site_id}&mod=index");exit;
    }
}

if($__Ios == 0 && $__Android == 0){
    $tongchengConfig['open_many_pic_upload'] = 0;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $edit_site_id       = intval($_GET['edit_site_id'])>0? intval($_GET['edit_site_id']):1;
    $cate_id            = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $video_link         = isset($_GET['video_link'])? addslashes($_GET['video_link']):'';
    $video_pic          = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    
    $picListArr = array();
    if(isset($_GET['picurl']) && is_array($_GET['picurl']) && !empty($_GET['picurl'])){
        foreach($_GET['picurl'] as $key => $value){
            $picListArr[] = addslashes($value);
        }
    }
    
    $imgArr = array();
    if($__IsWeixin == 1 && $tongchengConfig['open_many_pic_upload'] == 1){
        $pattern='#src="source/plugin/tom_tctoutiao/data/photo/[^"]+"#i';
    }else{
        $pattern='#src="data/attachment/tomwx/[^"]+"#i';
    }
    preg_match_all($pattern,stripslashes($content),$imgArr);
    $contentImgArr = array();
    if(is_array($imgArr) && !empty($imgArr[0])){
        foreach($imgArr[0] as $key => $value){
            $value = str_replace('src=', '', $value);
            $value = trim($value, '"');
            $contentImgArr[] = $value;
        }
    }
    
    $cateInfo = C::t("#tom_tctoutiao#tom_tctoutiao_cate")->fetch_by_id($cate_id);
    
    $search_text = $title.'|+++++|'.$zuozheInfo['name'].'|+++++|'.$cateInfo['name'].'|+++++|'.$zuozheInfo['label_name'].'|+++++|'.$zuozheInfo['share_title'].'|+++++|'.$zuozheInfo['share_desc'];
    
    $updateData = array();
    if($zuozheInfo['type'] == 3){
    }else{
        $updateData['site_id']              = $edit_site_id;
    }
    $updateData['cate_id']              = $cate_id;
    $updateData['title']                = $title;
    $updateData['type']                 = 1;
    $updateData['content']              = $content;
    $updateData['video_link']           = $video_link;
    if(!empty($video_link)){
        $updateData['type']                 = 3;
    }else{
        $updateData['type']                 = 1;
    }
    $updateData['share_pic']            = $picListArr[0];
    if($zuozheInfo['type'] == 1 && $zuozheInfo['shenhe_type'] == 1){
        $updateData['shenhe_status']    = 2;
    }else{
        $updateData['shenhe_status']    = 1;
    }
    $updateData['status']               = 1;
    $updateData['search_text']          = $search_text;
    $updateData['add_time']             = TIMESTAMP;
    
    if(C::t("#tom_tctoutiao#tom_tctoutiao")->update($tctoutiao_id, $updateData)){
        
        C::t("#tom_tctoutiao#tom_tctoutiao_photo")->delete_by_tctoutiao_id($tctoutiao_id);
        
        if(is_array($picListArr) && !empty($picListArr)){
            foreach($picListArr as $key => $value){
                $insertData = array();
                $insertData['tctoutiao_id'] = $tctoutiao_id;
                $insertData['type']         = 1;
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t("#tom_tctoutiao#tom_tctoutiao_photo")->insert($insertData);
            }
        }
        
        if(!empty($video_pic)){
            $insertData = array();
            $insertData['tctoutiao_id'] = $tctoutiao_id;
            $insertData['type']         = 3;
            $insertData['picurl']       = $video_pic;
            $insertData['qiniu_picurl'] = $video_pic;
            $insertData['qiniu_status'] = 1;
            $insertData['oss_picurl']   = $video_pic;
            $insertData['oss_status']   = 1;
            $insertData['add_time']     = TIMESTAMP;
            C::t("#tom_tctoutiao#tom_tctoutiao_photo")->insert($insertData);
        }
        
        if(is_array($contentImgArr) && !empty($contentImgArr)){
            foreach($contentImgArr as $key => $value){
                $insertData = array();
                $insertData['tctoutiao_id'] = $tctoutiao_id;
                $insertData['type']         = 5;
                $insertData['picurl']       = $value;
                $insertData['psort']        = 100000;
                $insertData['add_time']     = TIMESTAMP;
                C::t("#tom_tctoutiao#tom_tctoutiao_photo")->insert($insertData);
            }
        }
        
        if($zuozheInfo['type'] == 1 && $zuozheInfo['shenhe_type'] == 1){
            
            $toUser = array();
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $toUser = $toUserTmp;
            }
            
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();

            if($access_token && !empty($toUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$zuozheInfo['site_id']}&mod=index");
                $smsData = array(
                    'first'         => '['.$zuozheInfo['name'].']'.lang('plugin/tom_tctoutiao','edit_shenhe_template_first'),
                    'keyword1'      => $tctoutiaoConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }
        }
        
        echo 200; exit;
        
    }else{
        echo 404; exit;
    
    }    
}

$photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(" AND tctoutiao_id = {$tctoutiaoInfo['id']} AND type IN(1,3) ", 'ORDER BY psort ASC, id ASC', 0, 500);
$photoList = $coverList = array();
$video_pic = '';
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        if($value['type'] == 1){
            $coverList[$key]['picurl'] = $value['picurl'];
            $coverList[$key]['picurlTmp'] = $value['picurlTmp'];
        }else if($value['type'] == 3){
            $video_pic = $value['picurlTmp'];
        }
    }
}

$content = stripslashes($tctoutiaoInfo['content']);
$coverCount = count($coverList);

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$key] = $value;
    }
}

if($zuozheInfo['type'] != 3){
    $zuozheListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(" AND user_id = {$__UserInfo['id']} ", 'ORDER BY id DESC');
    $zuozheList = array();
    if(is_array($zuozheListTmp) && !empty($zuozheListTmp)){
        foreach($zuozheListTmp as $key => $value){
            $zuozheList[$key] = $value;
        }
    }
}

$cateListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_cate')->fetch_all_list(" AND is_show = 1 ", "ORDER BY csort ASC, id DESC", 0, 100);
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$key] = $value;
    }
}

$ossBatchUrl = 'plugin.php?id=tom_tctoutiao:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tctoutiao:qiniuBatch';

$saveUrl = "plugin.php?id=tom_tctoutiao&site={$site_id}&mod=edit&act=save&formhash=".FORMHASH;
$uploadUrl1 = "plugin.php?id=tom_tctoutiao&site={$site_id}&mod=upload&act=fabu_picurl&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tctoutiao:wxMediaDowmload&site={$site_id}&act=fabu_picurl&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tctoutiao:edit");