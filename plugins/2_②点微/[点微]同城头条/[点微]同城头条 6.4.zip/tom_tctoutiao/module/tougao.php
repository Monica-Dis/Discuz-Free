<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$back_url = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$zuozheInfo = C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe")->fetch_by_id($tctoutiaoConfig['youke_zuozhe_id']);

if($zuozheInfo && $zuozheInfo['id']>0){}else{
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$site_id}&mod=index");exit;
}

if($__Ios == 0 && $__Android == 0){
    $tongchengConfig['open_many_pic_upload'] = 0;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $cate_id            = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $tougao_laiyuan     = isset($_GET['tougao_laiyuan'])? addslashes($_GET['tougao_laiyuan']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $video_link         = isset($_GET['video_link'])? addslashes($_GET['video_link']):'';
    $video_pic          = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';

    $picListArr = array();
    if(isset($_GET['picurl']) && is_array($_GET['picurl']) && !empty($_GET['picurl'])){
        foreach($_GET['picurl'] as $key => $value){
            $picListArr[] = addslashes($value);
        }
    }
    
    $imgArr = array();
    if($__IsWeixin == 1 && $tongchengConfig['open_many_pic_upload'] == 1){
        $pattern='#src="source/plugin/tom_tctoutiao/data/photo/[^"]+"#i';
    }else{
        $pattern='#src="data/attachment/tomwx/[^"]+"#i';
    }
    preg_match_all($pattern,stripslashes($content),$imgArr);
    $contentImgArr = array();
    if(is_array($imgArr) && !empty($imgArr[0])){
        foreach($imgArr[0] as $key => $value){
            $value = str_replace('src=', '', $value);
            $value = trim($value, '"');
            $contentImgArr[] = $value;
        }
    }
   
    $insertData = array();
    $insertData['site_id']              = $site_id;
    $insertData['zuozhe_id']            = $zuozheInfo['id'];
    $insertData['cate_id']              = $cate_id;
    $insertData['title']                = $title;
    $insertData['content']              = $content;
    if(!empty($video_link)){
        $insertData['video_link']           = $video_link;
        $insertData['type']                 = 3;
    }else{
        $insertData['type']                 = 1;
    }
    $insertData['shenhe_status']        = 2;
    $insertData['status']               = 1;
    $insertData['tougao_user_id']       = $__UserInfo['id'];
    $insertData['tougao_laiyuan']       = $tougao_laiyuan;
    $insertData['mobile_status']        = 1;
    $insertData['add_time']             = TIMESTAMP;
    if(C::t("#tom_tctoutiao#tom_tctoutiao")->insert($insertData)){
        $tctoutiao_id = C::t("#tom_tctoutiao#tom_tctoutiao")->insert_id();
        
        if(is_array($picListArr) && !empty($picListArr)){
            foreach($picListArr as $key => $value){
                $insertData = array();
                $insertData['tctoutiao_id'] = $tctoutiao_id;
                $insertData['type']         = 1;
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t("#tom_tctoutiao#tom_tctoutiao_photo")->insert($insertData);
            }
        }
        
        if(!empty($video_pic)){
            $insertData = array();
            $insertData['tctoutiao_id'] = $tctoutiao_id;
            $insertData['type']         = 3;
            $insertData['picurl']       = $video_pic;
            $insertData['qiniu_picurl'] = $video_pic;
            $insertData['qiniu_status'] = 1;
            $insertData['oss_picurl']   = $video_pic;
            $insertData['oss_status']   = 1;
            $insertData['add_time']     = TIMESTAMP;
            C::t("#tom_tctoutiao#tom_tctoutiao_photo")->insert($insertData);
        }
        
        if(is_array($contentImgArr) && !empty($contentImgArr)){
            foreach($contentImgArr as $key => $value){
                $insertData = array();
                $insertData['tctoutiao_id'] = $tctoutiao_id;
                $insertData['type']         = 5;
                $insertData['picurl']       = $value;
                $insertData['psort']        = 100000;
                $insertData['add_time']     = TIMESTAMP;
                C::t("#tom_tctoutiao#tom_tctoutiao_photo")->insert($insertData);
            }
        }
        
        $toUser = array();
        $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
        if($toUserTmp && !empty($toUserTmp['openid'])){
            $toUser = $toUserTmp;
        }

        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();

        if($access_token && !empty($toUser['openid'])  ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$site_id}&mod=index");
            $smsData = array(
                'first'         => '['.$__UserInfo['nickname'].']'.lang('plugin/tom_tctoutiao','tougao_shenhe_template_first'),
                'keyword1'      => $tctoutiaoConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
        }
        
        echo 200; exit;
        
    }else{
        echo 404; exit;
    }
}

$cateListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_cate')->fetch_all_list(" AND is_show = 1 ", "ORDER BY csort ASC, id DESC", 0, 100);
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$key] = $value;
    }
}

$tougao_qrcode_msg = discuzcode($tctoutiaoConfig['tougao_qrcode_msg'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);

$showMustPhoneBtn = 0;
if($tctoutiaoConfig['tougao_must_tel'] == 1 && empty($__UserInfo['tel'])){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}


$saveUrl    = "plugin.php?id=tom_tctoutiao&site={$site_id}&mod=tougao&act=save&formhash=".FORMHASH;
$uploadUrl1 = "plugin.php?id=tom_tctoutiao&site={$site_id}&mod=upload&act=fabu_picurl&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tctoutiao:wxMediaDowmload&site={$site_id}&act=fabu_picurl&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tctoutiao:tougao");