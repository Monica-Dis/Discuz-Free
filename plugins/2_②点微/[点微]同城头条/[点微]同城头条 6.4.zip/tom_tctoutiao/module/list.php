<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword        = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$listtype       = isset($_GET['listtype'])? daddslashes($_GET['listtype']):'';
$cate_id        = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$label_id       = intval($_GET['label_id'])>0? intval($_GET['label_id']):0;
$zuozhe_id      = intval($_GET['zuozhe_id'])>0? intval($_GET['zuozhe_id']):0;
$type           = intval($_GET['type'])>0? intval($_GET['type']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):20;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND status=1 AND shenhe_status=1 ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids},99) ";
}
if($cate_id > 0){
    $whereStr.= " AND cate_id={$cate_id} ";
}
if($label_id > 0){
    $whereStr.= " AND label_id={$label_id} ";
}
if($zuozhe_id > 0){
    $whereStr.= " AND zuozhe_id={$zuozhe_id} ";
}else{
    
    $whereStr.= " AND index_show = 1 ";
    
    if($listtype == 'guanzu' && $__UserInfo['id'] > 0){
        $guanzuListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_guanzu')->fetch_all_list("AND user_id = {$__UserInfo['id']} ", 'ORDER BY id DESC', 0, 1000);
        $zuozheIdArr = array();
        foreach($guanzuListTmp as $key => $value){
            $zuozheIdArr[] = $value['zuozhe_id'];
        }
        if(is_array($zuozheIdArr) && !empty($zuozheIdArr)){
            $zuozheIdStr = implode(',', $zuozheIdArr);
            $whereStr.= " AND zuozhe_id IN({$zuozheIdStr}) ";
        }
    }
}
if($type > 0){
    $whereStr.= " AND type={$type} ";
}
$orderStr = " ORDER BY is_recom DESC,paixu ASC,add_time DESC,id DESC ";

$start = ($page - 1)*$pagesize;
$tctoutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list($whereStr,$orderStr,$start,$pagesize,$keyword);
$tctoutiaoList = array();
foreach ($tctoutiaoListTmp as $key => $value) {
    $coverArr = array();
    if($value['type'] == 1){
        $photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(" AND tctoutiao_id = {$value['id']} AND type = 1 ",'ORDER BY psort ASC,id DESC', 0, 3);
        if(is_array($photoListTmp) && !empty($photoListTmp)){
            $photoListArr = array();
            if(count($photoListTmp) < 3){
                $photoListArr[] = $photoListTmp[0];
            }else{
                $photoListArr = $photoListTmp;
            }

            foreach($photoListArr as $pk => $pv){
                $coverArr[] = $pv['picurlTmp'];
            }
        }

    }else if($value['type'] == 2){
        if($value['tuji_listpic_type'] == 1){
            $photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(" AND tctoutiao_id = {$value['id']} AND type = 2 ",'ORDER BY psort ASC,id DESC', 0, 3);
            if(is_array($photoListTmp) && !empty($photoListTmp)){
                $photoListArr = array();
                if(count($photoListTmp) < 3){
                    $photoListArr[] = $photoListTmp[0];
                }else{
                    $photoListArr = $photoListTmp;
                }

                foreach($photoListArr as $tk => $tv){
                    $coverArr[] = $tv['picurlTmp'];
                }
            }

        }else{
            $photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(" AND tctoutiao_id = {$value['id']} AND type = 1 ",'ORDER BY psort ASC,id DESC', 0, 3);
            if(is_array($photoListTmp) && !empty($photoListTmp)){
                $photoListArr = array();
                if(count($photoListTmp) < 3){
                    $photoListArr[] = $photoListTmp[0];
                }else{
                    $photoListArr = $photoListTmp;
                }

                foreach($photoListArr as $pk => $pv){
                    $coverArr[] = $pv['picurlTmp'];
                }
            }
        }

    }else if($value['type'] == 3){
        $photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(" AND tctoutiao_id = {$value['id']} AND type = 3 ", 'ORDER BY psort ASC, id ASC', 0, 1);
        if(!empty($photoListTmp[0])){
            $videoPicInfoTmp = $photoListTmp[0];
            if(!empty($videoPicInfoTmp)){
               $coverArr[] = $videoPicInfoTmp['picurlTmp'];
            }
        }

    }

    $template_type = 0;
    if(count($coverArr) == 0){
        $template_type = 4;
    }else if(count($coverArr) == 1){
        $template_type = 2;
    }else if(count($coverArr) == 3){
        $template_type = 3;
    }

    if($value['type'] == 1){
        if($template_type == 2){
            if($value['list_bigpic'] == 1){
                $template_type = 1;
            }else{
                $template_type = 2;
            }
        }
    }

    $zuozheInfo = C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe")->fetch_by_id($value['zuozhe_id']);
    $photoCount = 0;
    if($value['type'] == 2){
        $photoCount = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_count(" AND tctoutiao_id = {$value['id']} AND type = 2 ");
    }

    $tctoutiaoList[$key] = $value;
    $tctoutiaoList[$key]['clicks']          = $value['clicks'] + $value['virtual_clicks'];
    $tctoutiaoList[$key]['template_type']   = $template_type;
    $tctoutiaoList[$key]['coverList']       = $coverArr;
    $tctoutiaoList[$key]['zuozheInfo']      = $zuozheInfo;
    $tctoutiaoList[$key]['photoCount']      = $photoCount;
}

if(is_array($tctoutiaoList) && !empty($tctoutiaoList)){
    foreach ($tctoutiaoList as $key => $val){

        if($val['template_type'] == 1){
            $outStr .= '<div class="toutiao-list__item tuotiao-list__type2 clearfix">';
                $outStr .= '<div class="toutiao-item__content">';
                    $outStr .= '<a class="title" href="plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=info&aid='.$val['id'].'">'.$val['title'].'</a>';
                    $outStr .= '<div class="xinxi">';
                        if($zuozhe_id > 0){
                            $outStr .= '<span><i class="tciconfont tcicon-toutiao_yanjing"></i>'.$val['clicks'].lang('plugin/tom_tctoutiao', 'ajax_list_people_look').'</span>';
                            $outStr .= '<span>'.dgmdate($val['add_time'], 'u','9999','m-d').'</span>';
                        }else{
                            if($val['is_recom'] == 1){
                                $outStr .= '<span class="label tc-template__color tc-template__border">'.lang('plugin/tom_tctoutiao', 'ajax_list_recom_title').'</span>';
                            }else{
                                if(!empty($val['label_name'])){
                                    $outStr .= '<a href="plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=index&label_id='.$val['label_id'].'" class="label tc-template__color tc-template__border">'.$val['label_name'].'</a>';
                                }
                            }
                            $outStr .= '<span>'.$val['zuozheInfo']['name'].'</span>';
                            $outStr .= '<span><i class="tciconfont tcicon-toutiao_yanjing"></i>'.$val['clicks'].lang('plugin/tom_tctoutiao', 'ajax_list_people_look').'</span>';
                            $outStr .= '<span>'.dgmdate($val['add_time'], 'u','9999','m-d').'</span>';
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
                $outStr .= '<a class="toutiao-item__pic" href="plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=info&aid='.$val['id'].'">';
                    foreach($val['coverList'] as $ck => $cv){
                        $outStr .= '<img src="'.$cv.'">';
                    }
                $outStr .= '</a>';
            $outStr .= '</div>';
        }else if($val['template_type'] == 2){
            $outStr .= '<div class="toutiao-list__item tuotiao-list__type1">';
                $outStr .= '<a class="toutiao-item__title" href="plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=info&aid='.$val['id'].'">'.$val['title'].'</a>';
                $outStr .= '<a class="toutiao-item__pic toutiao-item__picnum display" href="plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=info&aid='.$val['id'].'">';
                    foreach($val['coverList'] as $ck => $cv){
                        $outStr .= '<img src="'.$cv.'">';
                    }
                    if($val['type'] == 3){
                         $outStr .= '<div class="bofang"><i class="bofang_btn"><img src="source/plugin/tom_tctoutiao/images/icon_play.png"></i></div>';
                    }
                    if($val['type'] == 2 && $val['photoCount'] > 0){
                        $outStr .= '<div class="picnum"><i class="tciconfont tcicon-tupian"><span>'.$val['photoCount'].lang('plugin/tom_tctoutiao', 'ajax_list_tunum').'</span></i></div>';
                    }
                $outStr .= '</a>';
                $outStr .= '<div class="toutiao-item__xx">';
                    if($zuozhe_id > 0){
                        $outStr .= '<span><i class="tciconfont tcicon-toutiao_yanjing"></i>'.$val['clicks'].lang('plugin/tom_tctoutiao', 'ajax_list_people_look').'</span>';
                        $outStr .= '<span>'.dgmdate($val['add_time'], 'u','9999','m-d').'</span>';
                    }else{
                        if($val['is_recom'] == 1){
                            $outStr .= '<span class="label tc-template__color tc-template__border">'.lang('plugin/tom_tctoutiao', 'ajax_list_recom_title').'</span>';
                        }else{
                            if(!empty($val['label_name'])){
                                $outStr .= '<a href="plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=index&label_id='.$val['label_id'].'" class="label tc-template__color tc-template__border">'.$val['label_name'].'</a>';
                            }
                        }
                        $outStr .= '<span>'.$val['zuozheInfo']['name'].'</span>';
                        $outStr .= '<span><i class="tciconfont tcicon-toutiao_yanjing"></i>'.$val['clicks'].lang('plugin/tom_tctoutiao', 'ajax_list_people_look').'</span>';
                        $outStr .= '<span>'.dgmdate($val['add_time'], 'u','9999','m-d').'</span>';
                    }
                $outStr .= '</div>';
            $outStr .= '</div>';

        }else if($val['template_type'] == 3){
            $outStr .= '<div class="toutiao-list__item tuotiao-list__type1">';
                $outStr .= '<a class="toutiao-item__title" href="plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=info&aid='.$val['id'].'">'.$val['title'].'</a>';
                $outStr .= '<a class="toutiao-item__pic2 dislay-flex toutiao-item__picnum" href="plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=info&aid='.$val['id'].'">';
                    foreach($val['coverList'] as $ck => $cv){
                        $outStr .= '<div class="pic-item flex"><img src="'.$cv.'"></div>';
                    }
                    if($val['type'] == 2 && $val['photoCount'] > 0){

                        $outStr .= '<div class="picnum"><i class="tciconfont tcicon-tupian"><span>'.$val['photoCount'].lang('plugin/tom_tctoutiao', 'ajax_list_tunum').'</span></i></div>';
                    }
                $outStr .= '</a>';
                $outStr .= '<div class="toutiao-item__xx">';
                    if($zuozhe_id > 0){
                        $outStr .= '<span><i class="tciconfont tcicon-toutiao_yanjing"></i>'.$val['clicks'].lang('plugin/tom_tctoutiao', 'ajax_list_people_look').'</span>';
                        $outStr .= '<span>'.dgmdate($val['add_time'], 'u','9999','m-d').'</span>';
                    }else{
                        if($val['is_recom'] == 1){
                            $outStr .= '<span class="label tc-template__color tc-template__border">'.lang('plugin/tom_tctoutiao', 'ajax_list_recom_title').'</span>';
                        }else{
                            if(!empty($val['label_name'])){
                                $outStr .= '<a href="plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=index&label_id='.$val['label_id'].'" class="label tc-template__color tc-template__border">'.$val['label_name'].'</a>';
                            }
                        }
                        $outStr .= '<span>'.$val['zuozheInfo']['name'].'</span>';
                        $outStr .= '<span><i class="tciconfont tcicon-toutiao_yanjing"></i>'.$val['clicks'].lang('plugin/tom_tctoutiao', 'ajax_list_people_look').'</span>';
                        $outStr .= '<span>'.dgmdate($val['add_time'], 'u','9999','m-d').'</span>';
                    }
                $outStr .= '</div>';
            $outStr .= '</div>';
        }else if($val['template_type'] == 4){
            $outStr .= '<div class="toutiao-list__item tuotiao-list__type4 clearfix">';
                $outStr .= '<div class="toutiao-item__content">';
                    $outStr .= '<a class="title" href="plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=info&aid='.$val['id'].'">'.$val['title'].'</a>';
                    $outStr .= '<div class="xinxi">';
                        if($zuozhe_id > 0){
                            $outStr .= '<span><i class="tciconfont tcicon-toutiao_yanjing"></i>'.$val['clicks'].lang('plugin/tom_tctoutiao', 'ajax_list_people_look').'</span>';
                            $outStr .= '<span>'.dgmdate($val['add_time'], 'u','9999','m-d').'</span>';
                        }else{
                            if($val['is_recom'] == 1){
                                $outStr .= '<span class="label tc-template__color tc-template__border">'.lang('plugin/tom_tctoutiao', 'ajax_list_recom_title').'</span>';
                            }else{
                                if(!empty($val['label_name'])){
                                    $outStr .= '<a href="plugin.php?id=tom_tctoutiao&site='.$site_id.'&mod=index&label_id='.$val['label_id'].'" class="label tc-template__color tc-template__border">'.$val['label_name'].'</a>';
                                }
                            }
                            $outStr .= '<span>'.$val['zuozheInfo']['name'].'</span>';
                            $outStr .= '<span><i class="tciconfont tcicon-toutiao_yanjing"></i>'.$val['clicks'].lang('plugin/tom_tctoutiao', 'ajax_list_people_look').'</span>';
                            $outStr .= '<span>'.dgmdate($val['add_time'], 'u','9999','m-d').'</span>';
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
            $outStr .= '</div>';
        }
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;