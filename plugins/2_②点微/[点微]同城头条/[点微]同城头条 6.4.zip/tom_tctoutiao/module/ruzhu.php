<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($tctoutiaoConfig['open_zuohe_shenqing'] != 1){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash']  == FORMHASH){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $shenqing_id        = isset($_GET['shenqing_id'])? intval($_GET['shenqing_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $wx                 = isset($_GET['wx'])? addslashes($_GET['wx']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $zuozhe_name        = isset($_GET['zuozhe_name'])? addslashes($_GET['zuozhe_name']):'';
    $zuozhe_logo        = isset($_GET['zuozhe_logo'])? addslashes($_GET['zuozhe_logo']):'';
    $beizu              = isset($_GET['beizu'])? addslashes($_GET['beizu']):'';
    
    if($__UserInfo['id'] > 0){
        
        if($shenqing_id > 0){
            $updateData = array();
            $updateData['user_id']          = $__UserInfo['id'];
            $updateData['name']             = $name;
            $updateData['wx']               = $wx;
            $updateData['tel']              = $tel;
            $updateData['zuozhe_name']      = $zuozhe_name;
            $updateData['zuozhe_logo']      = $zuozhe_logo;
            $updateData['beizu']            = $beizu;
            $updateData['shenhe_status']    = 2;
            $updateData['add_time']         = TIMESTAMP;
            C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe_shenqing")->update($shenqing_id, $updateData);
        }else{
            $insertData = array();
            $insertData['user_id']          = $__UserInfo['id'];
            $insertData['name']             = $name;
            $insertData['wx']               = $wx;
            $insertData['tel']              = $tel;
            $insertData['zuozhe_name']      = $zuozhe_name;
            $insertData['zuozhe_logo']      = $zuozhe_logo;
            $insertData['beizu']            = $beizu;
            $insertData['shenhe_status']    = 2;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe_shenqing")->insert($insertData);
        }
        
        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);

        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();

        if($access_token && !empty($toUser['openid'])  ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$site_id}&mod=index");
            $smsData = array(
                'first'         => '['.$name.']'.lang('plugin/tom_tctoutiao','ruzhu_template_first'),
                'keyword1'      => $tongchengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
        }
        
        $outArr = array(
            'status'=> 200,
        );
    }else{
        $outArr = array(
            'status'=> 404,
        );
    }
    echo json_encode($outArr); exit;
}

$shenqingInfoTmp = C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe_shenqing")->fetch_all_list("AND user_id = {$__UserInfo['id']}", 'ORDER BY id DESC', 0, 1);
$shenqingInfo = array();
if(is_array($shenqingInfoTmp) && !empty($shenqingInfoTmp)){
    $shenqingInfo = $shenqingInfoTmp[0];
    
    if(!preg_match('/^http/', $shenqingInfo['zuozhe_logo']) ){
        if(strpos($shenqingInfo['zuozhe_logo'], 'source/plugin/tom_') === FALSE){
            $zuozhe_logo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$shenqingInfo['zuozhe_logo'];
        }else{
            $zuozhe_logo = $shenqingInfo['zuozhe_logo'];
        }
    }else{
        $zuozhe_logo = $shenqingInfo['zuozhe_logo'];
    }
}

$showMustPhoneBtn = 0;
if($tctoutiaoConfig['zuozhe_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$tctoutiaoConfig['shenqing_msg'] = discuzcode($tctoutiaoConfig['shenqing_msg'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$site_id}&mod=ruzhu";
$saveUrl = "plugin.php?id=tom_tctoutiao&site={$site_id}&mod=ruzhu";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tctoutiao:ruzhu");