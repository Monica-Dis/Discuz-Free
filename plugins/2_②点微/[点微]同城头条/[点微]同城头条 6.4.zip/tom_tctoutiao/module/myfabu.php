<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$keyword   = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';

$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$tcshop_id  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$page       = intval($_GET['page'])>1? intval($_GET['page']):1;

if($tcshop_id > 0){
    $lifeTime = 600;
    dsetcookie('tom_tctoutiao_zuozhe_tcshop_id',$tcshop_id, $lifeTime);
}else{
    $cookie_tcshop_id = getcookie('tom_tctoutiao_zuozhe_tcshop_id');
    if($cookie_tcshop_id > 0){
        $tcshop_id = $cookie_tcshop_id;
    }
}

$where   = "";

if($__UserInfo['id'] == $tongchengConfig['manage_user_id']){
    $zuozheListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(" ", 'ORDER BY id DESC',0,100);
}else{
    
    if($tcshop_id > 0){
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
        $zuozheListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND tcshop_id = {$tcshop_id} AND type = 3 ", 'ORDER BY id DESC', 0, 1);
    }else{
        $zuozheListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(" AND user_id = {$__UserInfo['id']}  AND type IN (1,2) ", 'ORDER BY id DESC');
    }
}
$zuozheList = $zuozheListIds = array();
if(is_array($zuozheListTmp) && !empty($zuozheListTmp)){
    foreach($zuozheListTmp as $key => $value){
        $zuozheList[$key] = $value;
        $zuozheListIds[] = $value['id'];
    }
}
$zuozheListIdsStr = '99999999999';
if(is_array($zuozheListIds) && !empty($zuozheListIds)){
    $zuozheListIdsStr = implode(',', $zuozheListIds);
}
$where  = " AND zuozhe_id IN({$zuozheListIdsStr}) ";

if($type == 1){
    $where .= ' AND shenhe_status = 1 AND status = 1 ';
}
if($type == 2){
    $where .= ' AND shenhe_status = 2 ';
}
if($type == 3){
    $where .= ' AND shenhe_status = 3 ';
}

$order   = " ORDER BY id DESC ";

$pagesize   = 8;
$start      = ($page - 1)*$pagesize;
$count = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_count($where,$keyword);

$tctoutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list($where, $order, $start, $pagesize,$keyword);
if(!empty($tctoutiaoListTmp) && !empty($tctoutiaoListTmp)){
    foreach($tctoutiaoListTmp as $key => $value){
        $tctoutiaoList[$key] = $value;
        $tczuozheInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($value['zuozhe_id']);
        $pinglunCount    = C::t('#tom_tctoutiao#tom_tctoutiao_pinglun')->fetch_all_count("AND tctoutiao_id = {$value['id']}");
        $coverPic = '';
        if($value['type'] == 1){
            $photoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(" AND tctoutiao_id = {$value['id']} AND type = 1 ",'ORDER BY psort ASC,id DESC', 0, 1);
            if(!empty($photoInfoTmp[0]['picurlTmp'])){
                $coverPic = $photoInfoTmp[0]['picurlTmp'];
            }
            
        }else if($value['type'] == 2){
            if($value['tuji_listpic_type'] == 1){
                $photoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(" AND tctoutiao_id = {$value['id']} AND type = 2 ",'ORDER BY psort ASC,id DESC', 0, 1);
                if(!empty($photoInfoTmp[0]['picurlTmp'])){
                    $coverPic = $photoInfoTmp[0]['picurlTmp'];
                }

            }else{
                $photoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(" AND tctoutiao_id = {$value['id']} AND type = 1 ",'ORDER BY psort ASC,id DESC', 0, 1);
                if(!empty($photoInfoTmp[0]['picurlTmp'])){
                    $coverPic = $photoInfoTmp[0]['picurlTmp'];
                }
            }
        }else if($value['type'] == 3){
            $photoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(" AND tctoutiao_id = {$value['id']} AND type = 3 ",'ORDER BY psort ASC,id DESC', 0, 1);
            if(!empty($photoInfoTmp[0]['picurlTmp'])){
                $coverPic = $photoInfoTmp[0]['picurlTmp'];
            }

        }
        
        $tougaoUserInfo = array();
        if($value['tougao_user_id'] > 0){
            $tougaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['tougao_user_id']);
            $tougaoUserInfo['nickname'] = cutstr($tougaoUserInfo['nickname'],10,"...");
        }
        
        $tctoutiaoList[$key]['coverPic']        = $coverPic;
        $tctoutiaoList[$key]['pinglunCount']    = $pinglunCount;
        $tctoutiaoList[$key]['zuozhe']          = $tczuozheInfoTmp;
        $tctoutiaoList[$key]['tougaoUserInfo']  = $tougaoUserInfo;
        $tctoutiaoList[$key]['link']            = 'plugin.php?id=tom_tctoutiao&site='.$value['site_id'].'&mod=info&aid='.$value['id'];
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum  = ceil($count/$pagesize);
$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tctoutiao&site={$site_id}&mod=myfabu&type={$type}&page={$prePage}&tcshop_id={$tcshop_id}";
$nextPageUrl = "plugin.php?id=tom_tctoutiao&site={$site_id}&mod=myfabu&type={$type}&page={$nextPage}&tcshop_id={$tcshop_id}";

$back_url = $weixinClass->get_url();
$back_url = urlencode($back_url);

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tctoutiao:ajax&site={$site_id}&act=updateStatus&&formhash=".$formhash;
$ajaxUpdateShenheUrl = "plugin.php?id=tom_tctoutiao:ajax&site={$site_id}&act=updateShenhe&&formhash=".$formhash;
$ajaxUpdateShowUrl = "plugin.php?id=tom_tctoutiao:ajax&site={$site_id}&act=updateIndexShow&&formhash=".$formhash;
$searchUrl           = "plugin.php?id=tom_tctoutiao:ajax&site={$site_id}&act=get_myfabu_search_url&tcshop_id={$tcshop_id}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tctoutiao:myfabu");