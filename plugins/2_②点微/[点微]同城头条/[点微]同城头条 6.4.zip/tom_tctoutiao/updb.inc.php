<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/plugin');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $sql = '';
    
    $tom_tctoutiao_field = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_field();
    if (!isset($tom_tctoutiao_field['tcqianggou_ids'])) {
        $sql .= "ALTER TABLE `pre_tom_tctoutiao` ADD `tcqianggou_ids` varchar(255) DEFAULT '0';\n";
    }
    if (!isset($tom_tctoutiao_field['tcmall_ids'])) {
        $sql .= "ALTER TABLE `pre_tom_tctoutiao` ADD `tcmall_ids` varchar(255) DEFAULT '0';\n";
    }
    if (!isset($tom_tctoutiao_field['tougao_user_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tctoutiao` ADD `tougao_user_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tctoutiao_field['tougao_laiyuan'])) {
        $sql .= "ALTER TABLE `pre_tom_tctoutiao` ADD `tougao_laiyuan` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tctoutiao_field['mobile_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tctoutiao` ADD `mobile_status` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tctoutiao_field['search_text'])) {
        $sql .= "ALTER TABLE `pre_tom_tctoutiao` ADD `search_text` text;\n";
    }
    if (!isset($tom_tctoutiao_field['search_tcshop_ids'])) {
        $sql .= "ALTER TABLE `pre_tom_tctoutiao` ADD `search_tcshop_ids` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tctoutiao_field['index_show'])) {
        $sql .= "ALTER TABLE `pre_tom_tctoutiao` ADD `index_show` tinyint(4) DEFAULT '1';\n";
    }
    
    $tom_tctoutiao_cate_field = C::t('#tom_tctoutiao#tom_tctoutiao_cate')->fetch_all_field();
    if (!isset($tom_tctoutiao_cate_field['is_show'])) {
        $sql .= "ALTER TABLE `pre_tom_tctoutiao_cate` ADD `is_show` int(11) DEFAULT '1';\n";
    }
    
    $tom_tctoutiao_zuozhe_field = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_field();
    if (!isset($tom_tctoutiao_zuozhe_field['bgpic'])) {
        $sql .= "ALTER TABLE `pre_tom_tctoutiao_zuozhe` ADD `bgpic` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tctoutiao_zuozhe_field['tcshop_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tctoutiao_zuozhe` ADD `tcshop_id` int(11) DEFAULT '0';\n";
    }
    
    if (!empty($sql)) {
        runquery($sql);
    }
    
    $sql = <<<EOF
    CREATE TABLE IF NOT EXISTS `pre_tom_tctoutiao_cache` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `title` varchar(255) DEFAULT NULL,
      `content` mediumtext,
      `add_time` int(11) DEFAULT '0',
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
EOF;

    runquery($sql);

    echo 'OK';exit;
    
}else{
    exit('Access Denied');
}