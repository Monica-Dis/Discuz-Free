<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=zuozhe';
$modListUrl = $adminListUrl.'&tmod=zuozhe';
$modFromUrl = $adminFromUrl.'&tmod=zuozhe';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao_com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $zuozheInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($zuozheInfo);
        C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->update($zuozheInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($zuozheInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao_com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->delete_by_id($_GET['id']);
    C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_guanzu')->delete_by_zuozhe_id($_GET['id']);
    $tctoutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list(" AND zuozhe_id = {$_GET['id']} ", 'ORDER BY id DESC', 0, 10000);
    if(is_array($tctoutiaoListTmp) && !empty($tctoutiaoListTmp)){
        foreach($tctoutiaoListTmp as $key => $value){
            C::t('#tom_tctoutiao#tom_tctoutiao_collect')->delete_by_tctoutiao_id($value['id']);
            C::t('#tom_tctoutiao#tom_tctoutiao_photo')->delete_by_tctoutiao_id($value['id']);
        }
        C::t('#tom_tctoutiao#tom_tctoutiao')->delete_by_zuozhe_id($_GET['id']);
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_count(" ");
    $zuozheList = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(" "," ORDER BY id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['zuozhe_bbs_uid'] . '</th>';
    echo '<th>' . $Lang['zuozhe_user_id'] . '</th>';
    echo '<th>' . $Lang['zuozhe_type'] . '</th>';
    echo '<th>' . $Lang['zuozhe_tcshop'] . '</th>';
    echo '<th>' . $Lang['zuozhe_shenhe_type'] . '</th>';
    echo '<th>' . $Lang['zuozhe_picurl'] . '</th>';
    echo '<th>' . $Lang['zuozhe_name'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($zuozheList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
            $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        }
        
        echo '<tr>';
        echo '<td><font color="#fd0d0d">' . $value['id'] . '</font></td>';
        echo '<td><font color="#fd0d0d">' . $value['bbs_uid'] . '</font></td>';
        if($userInfo['id'] > 0){
            echo '<td>'.$userInfo['nickname'].'<font color="#fd0d0d">(UID:' . $userInfo['id'] . ')</font></td>';
        }else{
            echo '<td><font color="#fd0d0d"> -- </font></td>';
        }
        if($value['type'] == 1){
            echo '<td>' . $Lang['zuozhe_type_1'] . '</td>';
            echo '<td> -- </td>';
            if($value['shenhe_type'] == 1){
                echo '<td><font color="#fd0303">' . $Lang['zuozhe_shenhe_type_1'] . '</font></td>';
            }else if($value['shenhe_type'] == 2){
                echo '<td><font color="#1e9203">' . $Lang['zuozhe_shenhe_type_2'] . '</font></td>';
            }else{
                echo '<td> -- </td>';
            }
        }else if($value['type'] == 2){
            echo '<td>' . $Lang['zuozhe_type_2'] . '</td>';
            echo '<td> -- </td>';
            echo '<td><font color="#1e9203">' . $Lang['zuozhe_shenhe_type_2'] . '</font></td>';
        }else if($value['type'] == 3){
            echo '<td>' . $Lang['zuozhe_type_3'] . '</td>';
            echo '<td>'.$tcshopInfo['name'].'<font color="#fd0d0d">(UID:' . $value['tcshop_id'] . ')</font></td>';
            if($value['shenhe_type'] == 1){
                echo '<td><font color="#fd0303">' . $Lang['zuozhe_shenhe_type_1'] . '</font></td>';
            }else if($value['shenhe_type'] == 2){
                echo '<td><font color="#1e9203">' . $Lang['zuozhe_shenhe_type_2'] . '</font></td>';
            }else{
                echo '<td> -- </td>';
            }
        }else{
            echo '<td> -- </td>';
            echo '<td> -- </td>';
        }
        echo '<td><img src="'.tomgetfileurl($value['picurl']).'" width="40" /></td>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter();/*Dism_taobao_com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $bbs_uid            = isset($_GET['bbs_uid'])? intval($_GET['bbs_uid']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $shenhe_type        = isset($_GET['shenhe_type'])? intval($_GET['shenhe_type']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $reading_fc_scale   = isset($_GET['reading_fc_scale'])? intval($_GET['reading_fc_scale']):0;
    $reward_fc_scale    = isset($_GET['reward_fc_scale'])? intval($_GET['reward_fc_scale']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';

    $picurl = $bgpic = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
        $bgpic         = tomuploadFile("bgpic");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
        $bgpic         = tomuploadFile("bgpic",$infoArr['bgpic']);
    }
    
    $data['bbs_uid']                = $bbs_uid;
    $data['user_id']                = $user_id;
    $data['type']                   = $type;
    if($type == 3){
        $data['tcshop_id']              = $tcshop_id;
    }
    $data['shenhe_type']            = $shenhe_type;
    $data['name']                   = $name;
    $data['picurl']                 = $picurl;
    $data['bgpic']                  = $bgpic;
    $data['reading_fc_scale']       = $reading_fc_scale;
    $data['reward_fc_scale']        = $reward_fc_scale;
    $data['content']                = $content;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'bbs_uid'           => 0,
        'user_id'           => 0,
        'type'              => 1,
        'tcshop_id'         => 0,
        'shenhe_type'       => 1,
        'name'              => '',
        'picurl'            => '',
        'bgpic'             => '',
        'reading_fc_scale'  => 0,
        'reward_fc_scale'   => 0,
        'content'            => '',
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['zuozhe_bbs_uid'],'name'=>'bbs_uid','value'=>$options['bbs_uid'],'msg'=>$Lang['zuozhe_bbs_uid_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['zuozhe_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['zuozhe_user_id_msg']),"input");
    $item_type = array(1 => $Lang['zuozhe_type_1'], 2 => $Lang['zuozhe_type_2'], 3 => $Lang['zuozhe_type_3']);
    tomshowsetting(true,array('title'=>$Lang['zuozhe_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['zuozhe_type_msg'],'item'=>$item_type),"radio");
    tomshowsetting(true,array('title'=>$Lang['zuozhe_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['zuozhe_tcshop_id_msg']),"input");
    $item_shenhe_type = array(1 => $Lang['zuozhe_shenhe_type_1'], 2 => $Lang['zuozhe_shenhe_type_2']);
    tomshowsetting(true,array('title'=>$Lang['zuozhe_shenhe_type'],'name'=>'shenhe_type','value'=>$options['shenhe_type'],'msg'=>$Lang['zuozhe_shenhe_type_msg'],'item'=>$item_shenhe_type),"radio");
    tomshowsetting(true,array('title'=>$Lang['zuozhe_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['zuozhe_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['zuozhe_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['zuozhe_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['zuozhe_bgpic'],'name'=>'bgpic','value'=>$options['bgpic'],'msg'=>$Lang['zuozhe_bgpic_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['zuozhe_reading_fc_scale'],'name'=>'reading_fc_scale','value'=>$options['reading_fc_scale'],'msg'=>$Lang['zuozhe_reading_fc_scale_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['zuozhe_reward_fc_scale'],'name'=>'reward_fc_scale','value'=>$options['reward_fc_scale'],'msg'=>$Lang['zuozhe_reward_fc_scale_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['zuozhe_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['zuozhe_content_msg']),"textarea");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['zuozhe_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['zuozhe_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['zuozhe_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['zuozhe_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['zuozhe_edit'],"",true);
    }else{
        tomshownavli($Lang['zuozhe_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['zuozhe_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}