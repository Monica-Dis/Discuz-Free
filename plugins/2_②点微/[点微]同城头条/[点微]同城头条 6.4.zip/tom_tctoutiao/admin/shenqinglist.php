<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=shenqinglist';
$modListUrl = $adminListUrl.'&tmod=shenqinglist';
$modFromUrl = $adminFromUrl.'&tmod=shenqinglist';

$get_list_url_value = get_list_url("tom_tctoutiao_admin_shenqing_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $shenqingInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_shenqing')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($shenqingInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status'] = 1;
        C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_shenqing')->update($_GET['id'],$updateData);
        
        $shenhe = str_replace('{TITLE}', $tctoutiaoConfig['plugin_name'], $Lang['shenqinglist_template_shenhe_ok']);
        $cpmsg = $Lang['tctoutiao_shenhe_tz_succ'];
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$tctoutiaoInfo['site_id']}&mod=index");
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tctoutiaoConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tctoutiao_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tctoutiao_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tctoutiaoConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_ok&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['shenhe_succ_title'],'name'=>'text','value'=>'','msg'=>''),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao_com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $shenqingInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_shenqing')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($shenqingInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status'] = 3;
        C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_shenqing')->update($_GET['id'],$updateData);
        
        $shenhe = str_replace('{TITLE}', $tctoutiaoConfig['plugin_name'], $Lang['shenqinglist_template_shenhe_no']);
        $cpmsg = $Lang['tctoutiao_shenhe_tz_succ'];
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$tctoutiaoInfo['site_id']}&mod=ruzhu");
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tctoutiaoConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tctoutiao_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tctoutiao_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tctoutiaoConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tctoutiao_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tctoutiao_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao_com*/
        showformfooter();
    }
    
}else{
    
    set_list_url("tom_tctoutiao_admin_shenqing_list");
    
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }else{
        $where.= " AND shenhe_status IN (1,2) ";
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_shenqing')->fetch_all_count("{$where}");
    $shenqingList  = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe_shenqing')->fetch_all_list("{$where}"," ORDER BY id DESC",$start,$pagesize);

    $modBasePageUrl = $modBaseUrl."&shenhe_status={$shenhe_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    $status_shenhe_1 = $status_shenhe_2 = $status_shenhe_3 = '';
    if($shenhe_status == 1){
        $status_shenhe_1 = 'selected';
    }else if($shenhe_status == 2){
        $status_shenhe_2 = 'selected';
    }else if($shenhe_status == 3){
        $status_shenhe_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['index_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$status_shenhe_1.'>'.$Lang['index_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$status_shenhe_2.'>'.$Lang['index_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$status_shenhe_3.'>'.$Lang['index_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism_taobao_com*/
    showformfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 100px;">' . $Lang['shenqinglist_user_id'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['shenqinglist_name'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['shenqinglist_zuozhe_logo'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['shenqinglist_wx'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['shenqinglist_tel'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['shenqinglist_zuozhe_name'] . '</th>';
    echo '<th >' . $Lang['shenqinglist_beizu'] . '</th>';
    echo '<th >' . $Lang['index_shenhe_status'] . '</th>';
    echo '<th >' . $Lang['shenqinglist_add_time'] . '</th>';
    echo '<th >' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($shenqingList as $key => $value) {
        if(!preg_match('/^http/', $value['zuozhe_logo']) ){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['zuozhe_logo'];
        }else{
            $picurl = $value['zuozhe_logo'];
        }
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        echo '<tr>';
        echo '<td>' . $userInfo['nickname'] . '<font color="#fd0d0d">(UID:' . $userInfo['id'] . ')</font></td>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td><a href="'.$picurl.'" target="_blank"><img src="'.$picurl.'" width="40" /></a></td>';
        echo '<td>' . $value['wx'] . '</td>';
        echo '<td>' . $value['tel'] . '</td>';
        echo '<td>' . $value['zuozhe_name'] . '</td>';
        echo '<td>' . $value['beizu'] . '</td>';
        
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shenhe_btn_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shenhe_btn_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['index_shenhe_status_1']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 2 ){
            echo '<td><font color="#f70404">' . $Lang['index_shenhe_status_2']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 3 ){
            echo '<td><font color="#f70404">' . $Lang['index_shenhe_status_3']. '</font>'.$sheheBtnStr.'</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset) .'</td>';
        echo '<td>';
        echo '--';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism_taobao_com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    tomshownavli($Lang['shenqinglist_list_title'],$modBaseUrl,true);
    tomshownavfooter();
}