<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_tctoutiao_admin_index_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status']     = 1;
    C::t('#tom_tctoutiao#tom_tctoutiao')->update($_GET['id'],$updateData);
    
    $tctoutiaoInfo = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_by_id($_GET['id']);
    $zuozheInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($tctoutiaoInfo['zuozhe_id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($zuozheInfo['user_id']);

    $shenhe = str_replace('{TITLE}', $tctoutiaoInfo['title'], $Lang['index_template_tctoutiao_shenhe_ok']);

    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$tctoutiaoInfo['site_id']}&mod=info&tctoutiao_id=".$tctoutiaoInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tctoutiaoConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['tctoutiao_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['tctoutiao_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tctoutiaoConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $tctoutiaoInfo = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $zuozheInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($tctoutiaoInfo['zuozhe_id']);
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($zuozheInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tctoutiao#tom_tctoutiao')->update($_GET['id'],$updateData);
        
        $shenhe = str_replace('{TITLE}', $tctoutiaoInfo['title'], $Lang['index_template_tctoutiao_shenhe_no']);
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$tctoutiaoInfo['site_id']}&mod=edit&tctoutiao_id=".$tctoutiaoInfo['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tctoutiaoConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tctoutiao_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tctoutiao_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tctoutiaoConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tctoutiao_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tctoutiao_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tctoutiao_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao_com*/
        showformfooter();
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'recom_ok'){

    $updateData = array();
    $updateData['is_recom'] = 1;
    C::t('#tom_tctoutiao#tom_tctoutiao')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'recom_no'){

    $updateData = array();
    $updateData['is_recom'] = 0;
    C::t('#tom_tctoutiao#tom_tctoutiao')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'update_index_show'){
    
    $index_show = intval($_GET['index_show'])>0 ? intval($_GET['index_show']):0;
    
    $updateData = array();
    $updateData['index_show'] = $index_show;
    C::t('#tom_tctoutiao#tom_tctoutiao')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tctoutiao#tom_tctoutiao')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tctoutiao#tom_tctoutiao')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tctoutiao#tom_tctoutiao')->delete_by_id($_GET['id']);
    C::t('#tom_tctoutiao#tom_tctoutiao_collect')->delete_by_tctoutiao_id($_GET['id']);
    C::t('#tom_tctoutiao#tom_tctoutiao_photo')->delete_by_tctoutiao_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'upload_search_text'){
    
    $tctoutiaoListTmp = C::t("#tom_tctoutiao#tom_tctoutiao")->fetch_all_search_text_list(" AND (search_text IS NULL OR search_text = '') ");
    if(is_array($tctoutiaoListTmp) && !empty($tctoutiaoListTmp)){
        foreach($tctoutiaoListTmp as $key => $value){
            $zuozheInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($value['zuozhe_id']);
            $cateInfo = C::t("#tom_tctoutiao#tom_tctoutiao_cate")->fetch_by_id($value['cate_id']);
            
            $search_text = $value['title'].'|+++++|'.$zuozheInfo['name'].'|+++++|'.$cateInfo['name'].'|+++++|'.$value['label_name'].'|+++++|'.$value['share_title'].'|+++++|'.$value['share_desc'];
            DB::query("UPDATE ".DB::table('tom_tctoutiao')." SET search_text='{$search_text}' WHERE id={$value['id']}", 'UNBUFFERED');
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_tctoutiao_admin_index_list");
    
    $search             = intval($_GET['search'])>0? intval($_GET['search']):0;
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $keyword            = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
    $is_recom           = isset($_GET['is_recom'])? intval($_GET['is_recom']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;

    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($is_recom)){
        if($is_recom == 1){
            $where.= " AND is_recom=1";
        }else{
            $where.= " AND is_recom=0";
        }
    }
    if(!empty($cate_id)){
        $where.= " AND cate_id={$cate_id} ";
    }
    if(!empty($status)){
        if($status == 1){
            $where.= " AND status=1 ";
        }else if($status == 2){
            $where.= " AND status != 1 ";
        }
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    
    $order = "ORDER BY add_time DESC,id DESC";
    if($sort_type == 1){
        $order = 'ORDER BY changyong_status DESC, sort ASC,id DESC';
    }
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_count("{$where}",$keyword);
    $tctoutiaoList  = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list("{$where}",$order,$start,$pagesize,$keyword);

    showtableheader();
    $Lang['index_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_1']);
    $Lang['index_help_2']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_2']);
    $Lang['index_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_3']);
    $Lang['index_help_4']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_4']);
    $Lang['index_help_5']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_5']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_1'] . '</li>';
    echo '<li>' . $Lang['index_help_2'] . '</li>';
    echo '<li>' . $Lang['index_help_3'] . '</li>';
    if($tongchengConfig['open_yun'] == 2){
        echo '<li>' . $Lang['index_help_4'] . '</li>';
    }
    if($tongchengConfig['open_yun'] == 3){
        echo '<li>' . $Lang['index_help_5'] . '</li>';
    }
    echo '<li>' . $Lang['index_help_6_1']. '<a href="'.$modBaseUrl.'&act=upload_search_text&formhash='.FORMHASH.'">' . $Lang['index_help_6_2']. '</a></li>';
    echo '</ul></td></tr>';
    showtablefooter();/*Dism_taobao_com*/

    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&status={$status}&shenhe_status={$shenhe_status}&keyword={$keyword}&is_recom={$is_recom}&cate_id={$cate_id}&search={$search}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    $site_1 = '';
    if($site_id == 1){
        $site_1 = 'selected';
    }
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '(<a href="'.$modBaseUrl.'&search=1"><font color="#F90B0B">' . $Lang['index_gaoji_search'] . '</font></a>)</th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    echo '<input type="hidden" name="search" value="'.$search.'">';
    $keywordStr = '<tr><td width="100" align="right"><b>'.$Lang['index_search_keyword'].'</b></td>';
    $keywordStr.= '<td><input style="width:260px" type="text" value="'.$keyword.'" name="keyword"></td></tr>';
    echo $keywordStr;

    if($search == 1){
        
        $is_recom_selected_1 = $is_recom_selected_2 = '';
        if($is_recom == 1){
            $is_recom_selected_1 = 'selected';
        }else if($is_recom == 2){
            $is_recom_selected_2 = 'selected';
        }
        $recomStr = '<tr><td width="100" align="right"><b>'.$Lang['index_search_recommend'].'</b></td>';
        $recomStr.= '<td ><select style="width: 260px;" name="is_recom" id="is_recom">';
        $recomStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
        $recomStr.=  '<option value="1" '.$is_recom_selected_1.'>'.$Lang['index_search_recommend_1'].'</option>';
        $recomStr.=  '<option value="2" '.$is_recom_selected_2.'>'.$Lang['index_search_recommend_2'].'</option>';
        $recomStr.= '</select></td></tr>';
        echo $recomStr;
        
        $cateList   = C::t('#tom_tctoutiao#tom_tctoutiao_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,200);
        $cateStr = '<tr><td width="100" align="right"><b>'.$Lang['index_search_cate'].'</b></td>';
        $cateStr.= '<td ><select style="width: 100px;" name="cate_id" id="cate_id">';
        $cateStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
        foreach ($cateList as $key => $value){
            if($cate_id == $value['id']){
                $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $cateStr.= '</select></td></tr>';
        echo $cateStr;
        
        $status_1 = $status_2 = '';
        if($status == 1){
            $status_1 = 'selected';
        }else if($status == 2){
            $status_2 = 'selected';
        }
        $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_status'].'</b></td>';
        $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
        $statusStr.=  '<option value="0">'.$Lang['index_status'].'</option>';
        $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['index_status_1'].'</option>';
        $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['index_status_2'].'</option>';
        $statusStr.= '</select></td></tr>';
        echo $statusStr;
    }
    
    $status_shenhe_1 = $status_shenhe_2 = $status_shenhe_3 = '';
    if($shenhe_status == 1){
        $status_shenhe_1 = 'selected';
    }else if($shenhe_status == 2){
        $status_shenhe_2 = 'selected';
    }else if($shenhe_status == 3){
        $status_shenhe_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['index_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$status_shenhe_1.'>'.$Lang['index_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$status_shenhe_2.'>'.$Lang['index_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$status_shenhe_3.'>'.$Lang['index_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism_taobao_com*/
    showformfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 60px;"> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['index_zuozhe_id'] . '</th>';
    echo '<th style="width: 150px;">' . $Lang['index_toutiao_title'] . '</th>';
    echo '<th >' . $Lang['index_toutiao_type'] . '</th>';
    echo '<th >' . $Lang['index_tougao_user_id'] . '</th>';
    echo '<th >' . $Lang['index_toutiao_index_show'] . '</th>';
    echo '<th >' . $Lang['index_toutiao_is_recom'] . '</th>';
    echo '<th >' . $Lang['index_shenhe_status'] . '</th>';
    echo '<th >' . $Lang['index_status'] . '</th>';
    echo '<th >' . $Lang['index_toutiao_paixu'] . '</th>';
    echo '<th >' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tctoutiaoList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $zuozheInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($value['zuozhe_id']);
        $tcshopInfo = array();
        if($value['tcshop_id'] > 0){
            $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
            if($tcshopInfoTmp){
                $tcshopInfo = $tcshopInfoTmp;
            }
        }
        
        $tougaoUserInfo = array();
        if($value['tougao_user_id'] > 0){
            $tougaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['tougao_user_id']);
        }
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 0){
            if($value['site_id'] > 99){
                echo '<td>' . $siteInfo['name'] . '</td>';
            }else if($value['site_id'] == 99){
                echo '<td>' . $Lang['sites_all'] . '</td>';
            }else{
                echo '<td>' . $Lang['sites_one'] . '</td>';
            }
        }else{
            echo '<td> -- </td>';
        }
        if($zuozheInfo){
            echo '<td>' . $zuozheInfo['name'] . '<font color="#fd0d0d">(ID:' . $zuozheInfo['id'] . ')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $value['title'] . '</td>';
        if($value['type'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['index_toutiao_type_1'] . '</font></td>';
        }else if($value['type'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['index_toutiao_type_2'] . '</font></td>';
        }else if($value['type'] == 3){
            echo '<td><font color="#0a9409">' . $Lang['index_toutiao_type_3'] . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        if($tougaoUserInfo['id'] > 0){
            echo '<td>'.$tougaoUserInfo['nickname'].'<font color="#fd0d0d">(UID:' . $tougaoUserInfo['id'] . ')</font><br/><font color="#0894fb">' . $Lang['index_tougao_laiyuan'] . $value['tougao_laiyuan'] . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        $indexShowBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=update_index_show&index_show=1&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_toutiao_index_show_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=update_index_show&index_show=0&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_toutiao_index_show_0']. '</a>)';
        if($value['index_show'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['index_toutiao_index_show_1']. '</font>'.$indexShowBtnStr.'</td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['index_toutiao_index_show_0']. '</font>'.$indexShowBtnStr.'</td>';
        }
        
        $recomBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=recom_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_toutiao_is_recom_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=recom_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_toutiao_is_recom_0']. '</a>)';
        if($value['is_recom'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['index_toutiao_is_recom_1']. '</font>'.$recomBtnStr.'</td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['index_toutiao_is_recom_0']. '</font>'.$recomBtnStr.'</td>';
        }
        
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shenhe_btn_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shenhe_btn_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['index_shenhe_status_1']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 2 ){
            echo '<td><font color="#f70404">' . $Lang['index_shenhe_status_2']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 3 ){
            echo '<td><font color="#f70404">' . $Lang['index_shenhe_status_3']. '</font>'.$sheheBtnStr.'</td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">'.$Lang['index_status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#f70404">(' . $Lang['index_status_2']. ')</font></a></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['index_status_2'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#0a9409">(' . $Lang['index_status_1']. ')</font></a></td>';
        }
        echo '<td>' . $value['paixu'] . '</td>';
        echo '<td>';
        echo '<a href="plugin.php?id=tom_tctoutiao:manage&mod=edit&tctoutiao_id='.$value['id'].'&from=admin" target="_blank">' . $Lang['edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a><br/>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism_taobao_com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
    //tomshownavli($Lang['index_add'],"plugin.php?id=tom_tctoutiao:manage&mod=fabu",false);
    tomshownavfooter();
}