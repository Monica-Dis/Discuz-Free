<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=order';
$modListUrl = $adminListUrl.'&tmod=order';
$modFromUrl = $adminFromUrl.'&tmod=order';

$get_list_url_value = get_list_url("tom_tctoutiao_admin_order_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tctoutiao#tom_tctoutiao_order')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_tctoutiao_admin_order_list");
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;
    $order_type     = isset($_GET['order_type'])? intval($_GET['order_type']):0;
    $tctoutiao_id   = isset($_GET['tctoutiao_id'])? intval($_GET['tctoutiao_id']):0;
    $zuozhe_id      = isset($_GET['zuozhe_id'])? intval($_GET['zuozhe_id']):0;
    
    $where = "";
    if(!empty($order_status)){
        $where.=" AND order_status={$order_status} ";
    }
    if(!empty($order_type)){
        $where.=" AND order_type={$order_type} ";
    }
    if(!empty($tctoutiao_id)){
        $where.=" AND tctoutiao_id={$tctoutiao_id} ";
    }
    if(!empty($zuozhe_id)){
        $where.=" AND zuozhe_id={$zuozhe_id} ";
    }
    
    $modBasePageUrl = $modBaseUrl."&order_status={$order_status}&order_type={$order_type}&tctoutiao_id={$tctoutiao_id}&zuozhe_id={$zuozhe_id}";
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_count($where);
    $orderList = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_list($where,"ORDER BY order_time DESC",$start,$pagesize);
    $fenghao = $Lang['fenghao'];
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_search_list'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_tctoutiao_id'] . '</b></td><td><input name="tctoutiao_id" type="text" value="'.$tctoutiao_id.'" size="40" /><font color="#fd0d0d">' . $Lang['order_tctoutiao_id_msg'] . '</font></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_zuozhe_id'] . '</b></td><td><input name="zuozhe_id" type="text" value="'.$zuozhe_id.'" size="40" /><font color="#fd0d0d">' . $Lang['order_zuozhe_id_msg'] . '</font></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_order_status'] . '</b></td><td><select name="order_status" >';
    
    $order_status_1 = $order_status_2 = '';
    if($order_status == 1){
        $order_status_1 = 'selected';
    }else if($order_status == 2){
        $order_status_2 = 'selected';
    }
    echo '<option value="0">'.$Lang['order_order_status'].'</option>';
        echo '<option value="1" '.$order_status_1.'>'.$Lang['order_order_status_1'].'</option>';
        echo '<option value="2" '.$order_status_2.'>'.$Lang['order_order_status_2'].'</option>';
    echo '</select></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_order_type'] . '</b></td><td><select name="order_type" >';
    
    $order_type_1 = $order_type_2 = '';
    if($order_type == 1){
        $order_type_1 = 'selected';
    }else if($order_type == 2){
        $order_type_2 = 'selected';
    }
    echo '<option value="0">'.$Lang['order_order_type'].'</option>';
        echo '<option value="1" '.$order_type_1.'>'.$Lang['order_order_type_1'].'</option>';
        echo '<option value="2" '.$order_type_2.'>'.$Lang['order_order_type_2'].'</option>';
    echo '</select></td></tr>';
    
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism_taobao_com*/
    showformfooter();
    
    if($tctoutiao_id > 0 || $zuozhe_id > 0){
        
        $numWhere = '';
        if($tctoutiao_id > 0){
            $numWhere .= " AND tctoutiao_id = {$tctoutiao_id} ";
        }
        if($zuozhe_id > 0){
            $numWhere .= " AND zuozhe_id = {$zuozhe_id} ";
        }
        
        $countOrderStatus1 = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_count(" {$numWhere} AND order_status=1 ");
        $countOrderStatus2 = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_count(" {$numWhere} AND order_status=2 ");
        echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
        echo $Lang['order_order_status_1'].'<font color="#fd0d0d">('.$countOrderStatus1.')</font>&nbsp;&nbsp;';
        echo $Lang['order_order_status_2'].'<font color="#fd0d0d">('.$countOrderStatus2.')</font>&nbsp;&nbsp;';
        echo '</div>';
        if(!empty($order_status)){
            echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
            echo '<b>'.$Lang['order_search_count_msg1'].'</b>'.$Lang['order_search_count_msg2'].'<font color="#fd0d0d">('.$count.')</font>';
            echo '</div>';
        }
    }
    
    $todayPayPrice = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_sun_pay_price(" AND pay_time > $nowDayTime AND order_status=2 ");
    $monthPayPrice = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_sun_pay_price(" AND pay_time > $nowMonthTime AND order_status=2 ");
    $allPayPrice = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_sun_pay_price(" AND order_status=2 ");
    echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
    echo $Lang['today_pay_price_title'].'<font color="#fd0d0d">('.$todayPayPrice.')</font>&nbsp;&nbsp;';
    echo $Lang['month_pay_price_title'].'<font color="#fd0d0d">('.$monthPayPrice.')</font>&nbsp;&nbsp;';
    echo $Lang['all_pay_price_title'].'<font color="#fd0d0d">('.$allPayPrice.')</font>&nbsp;&nbsp;';
    echo '</div>';
    
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return order_form();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />'.
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['order_order_no'] . '</th>';
    echo '<th width="200">' . $Lang['order_tctoutiao_name'] . '</th>';
    echo '<th>' . $Lang['order_pay_price'] . '</th>';
    echo '<th>' . $Lang['order_user_nickname'] . '</th>';
    echo '<th>' . $Lang['order_order_type'] . '</th>';
    echo '<th>' . $Lang['order_order_status'] . '</th>';
    echo '<th>' . $Lang['order_order_time'] . '</th>';
    echo '<th width="120">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($orderList as $key => $value){
        
        $tctoutiaoInfo = C::t("#tom_tctoutiao#tom_tctoutiao")->fetch_by_id($value['tctoutiao_id']);
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        
        echo '<tr style="height:60px;">';
        echo '<td>' . $value['order_no'] .'</td>';
        echo '<td>' . $tctoutiaoInfo['title'] .'(ID:' . $value['tctoutiao_id'] . ')</td>';
        echo '<td><font color="#009900">' . $value['pay_price'] . '</font></td>';
        echo '<td>' . $userInfo['nickname'] . '(UID:'.$value['user_id'].')</td>';
        if($value['order_type'] == 1){
            echo '<td><b><font color="#fd0303">' . $Lang['order_order_type_1'] . '</font></b></td>';
        }else if($value['order_type'] == 2){
            echo '<td><b><font color="#1e9203">' . $Lang['order_order_type_2'] . '</font></b></td>';
        }
        if($value['order_status'] == 1){
            echo '<td><b><font color="#fd0303">' . $Lang['order_order_status_1'] . '</font></b></td>';
        }else if($value['order_status'] == 2){
            echo '<td><b><font color="#1e9203">' . $Lang['order_order_status_2'] . '</font></b></td>';
        }
        echo '<td>' . dgmdate($value['order_time'], 'Y-m-d H:i:s',$tomSysOffset) .'</td>';
        echo '<td style="line-height: 30px;">';
        echo '--';
        //echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    
    $formstr = <<<EOF
        <script type="text/javascript">
        function del_confirm(url){
            var r = confirm("{$Lang['makesure_del_msg']}")
            if (r == true){
              window.location = url;
            }else{
              return false;
            }
          }
        </script>
EOF;
    
    echo $formstr;
    showtablefooter();/*Dism_taobao_com*/
    showformfooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
}