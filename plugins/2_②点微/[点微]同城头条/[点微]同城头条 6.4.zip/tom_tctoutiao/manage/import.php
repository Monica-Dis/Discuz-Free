<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(3600);

$zuozhe_id  = intval($_GET['zuozhe_id'])>0 ?intval($_GET['zuozhe_id']):0;

$zuozheInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($zuozhe_id);

if($__IsManager != 1 && $zuozheInfo['bbs_uid'] != $_G['uid']){
    dheader('location:'.$_G['siteurl']);exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/class/simple_html_dom.php';

if($_GET['act'] == 'do' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $import_url   = isset($_GET['import_url'])? addslashes($_GET['import_url']):'';
    
    $html = tom_get_html($import_url);
    if($html){}else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $dom = str_get_html($html);

    $title = $content = '';
    foreach ($dom->find('#activity-name') as $value){
        $title = $value->innertext;
    }
    foreach ($dom->find('#js_content') as $value){
        $content = $value->innertext;
    }
    
    if(empty($title) || empty($content)){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $content = str_replace('data-src="https://mmbiz.qpic.cn','src="https://mmbiz.qpic.cn',$content);
    $content = str_replace('data-src="http://mmbiz.qpic.cn','src="http://mmbiz.qpic.cn',$content);
    $content = str_replace('/640.jpeg?','/640?',$content);
    
    preg_match_all('#(https|http)://mmbiz.qpic.cn/(sz_|)mmbiz[_a-z]*/[a-zA-Z0-9]*/(640|0)#i',$content,$matchImgs);
    $wxImgList = array();
    if(is_array($matchImgs) && !empty($matchImgs) && is_array($matchImgs[0]) && !empty($matchImgs[0])){
        foreach ($matchImgs[0] as $key => $value){
            $wxImgList[$key]['src'] = $value;
            $wxImgList[$key]['type'] = 'png';
            if(strpos($value, 'mmbiz_jpg') !== false){
                $wxImgList[$key]['type'] = 'jpg';
            }else if(strpos($value, 'sz_mmbiz_jpg') !== false){
                $wxImgList[$key]['type'] = 'jpg';
            }else if(strpos($value, 'mmbiz_png') !== false){
                $wxImgList[$key]['type'] = 'png';
            }else if(strpos($value, 'sz_mmbiz_png') !== false){
                $wxImgList[$key]['type'] = 'png';
            }else if(strpos($value, 'mmbiz_gif') !== false){
                $wxImgList[$key]['type'] = 'gif';
            }else if(strpos($value, 'sz_mmbiz_gif') !== false){
                $wxImgList[$key]['type'] = 'gif';
            }
        }
    }

    if(is_array($wxImgList) && !empty($wxImgList)){
        foreach ($wxImgList as $key => $value){
            $imageData = tom_get_html($value['src']);
            if($imageData){
                
                $imageDir = "/source/plugin/tom_ueditor/upload/image/wx/".date("Ymd")."/";
                $imageName = "source/plugin/tom_ueditor/upload/image/wx/".date("Ymd")."/".md5($value['src']).'.'.$value['type'];
                
                $tomDir = DISCUZ_ROOT.'.'.$imageDir;
                if(!is_dir($tomDir)){
                    mkdir($tomDir, 0777,true);
                }else{
                    chmod($tomDir, 0777); 
                }
                
                $upload =  file_put_contents(DISCUZ_ROOT.'./'.$imageName, $imageData);
                if($upload){
                    $content = str_replace($value['src'],$imageName,$content);
                }else{
                    $outArr = array(
                        'status'=> 303,
                    );
                    echo json_encode($outArr); exit;
                }

            }
        }
    }
    
    preg_match_all('#(https|http)://v.qq.com/iframe/preview.html?[^"]*vid=([a-zA-Z0-9]*)#i',$content,$matchVideos);
    if(is_array($matchVideos) && !empty($matchVideos)  && is_array($matchVideos[0]) && !empty($matchVideos[0])){
        foreach ($matchVideos[0] as $key => $value){
            $content = str_replace('data-src="'.$value, ' width="100%" style="height: calc(100vw*0.56);max-height: 420px;" src="https://v.qq.com/iframe/preview.html?&auto=0&vid='.$matchVideos[2][$key],$content);
        }
    }
//    preg_match_all('#(https|http)://mp.weixin.qq.com/mp/[^"]*t=pages/video_player_tmpl[^"]*vid=([a-z_A-Z0-9]*)#i',$content,$matchVideos);
//    if(is_array($matchVideos) && !empty($matchVideos)  && is_array($matchVideos[0]) && !empty($matchVideos[0])){
//        foreach ($matchVideos[0] as $key => $value){
//            $content = str_replace('data-src="'.$value,' width="100%" style="height: calc(100vw*0.56);max-height: 420px;" src="https://mp.weixin.qq.com/mp/readtemplate?t=pages/video_player_tmpl&action=mpvideo&auto=0&vid='.$matchVideos[2][$key],$content);
//        }
//    }
    
    if (CHARSET != 'utf-8') {
        $title   = diconv($title,'utf-8');
        $content = diconv($content,'utf-8');
    }
    
    $insertData = array();
    $insertData['title']        = trim($title);
    $insertData['content']      = $content;
    $insertData['add_time']     = TIMESTAMP;
    if(C::t("#tom_tctoutiao#tom_tctoutiao_cache")->insert($insertData)){
        $cache_id = C::t("#tom_tctoutiao#tom_tctoutiao_cache")->insert_id();
        $outArr = array(
            'cache_id'=> $cache_id,
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    
    echo json_encode($outArr); exit;
}


$saveUrl = "plugin.php?id=tom_tctoutiao:manage&mod=import&act=do&zuozhe_id={$zuozhe_id}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tctoutiao:manage/import");