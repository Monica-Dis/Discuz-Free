<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page           = intval($_GET['page'])>1? intval($_GET['page']):1;
$zuozhe_id      = intval($_GET['zuozhe_id'])>0? intval($_GET['zuozhe_id']):0;
$tctoutiao_id   = intval($_GET['tctoutiao_id'])>0? intval($_GET['tctoutiao_id']):0;

if($_GET['act'] == 'remove' && $_GET['formhash'] == FORMHASH){
    
    $pinglun_id = isset($_GET['pinglun_id'])? intval($_GET['pinglun_id']): 0;
    $reply_id = isset($_GET['reply_id'])? intval($_GET['reply_id']): 0;
    
    if($pinglun_id > 0){
        C::t('#tom_tctoutiao#tom_tctoutiao_pinglun')->delete_by_id($pinglun_id);
        C::t('#tom_tctoutiao#tom_tctoutiao_pinglun_reply')->delete_by_pinglun_id($pinglun_id);
    }
    if($reply_id > 0){
        C::t('#tom_tctoutiao#tom_tctoutiao_pinglun_reply')->delete_by_id($reply_id);
    }
    echo 200;exit;

}

if($__IsManager == 1){
    $zuozheListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(" ", 'ORDER BY id DESC', 0, 1000);
}else{
    $zuozheListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(" AND bbs_uid = {$_G['uid']} ", 'ORDER BY id DESC', 0, 100);
}
$zuozheList = $zuozheIdArr = array();
if(is_array($zuozheListTmp) && !empty($zuozheListTmp)){
    foreach($zuozheListTmp as $key => $value){
        $zuozheList[$key] = $value;
        $zuozheIdArr[] = $value['id'];
    }
}
$zuozheIdStr = '';
if(!empty($zuozheIdArr)){
    $zuozheIdStr = implode(',', $zuozheIdArr);
}

$zuozheWhere = '';
if($zuozhe_id > 0){
    $zuozheWhere .= " AND zuozhe_id = {$zuozhe_id} ";
}else if(!empty($zuozheIdStr)){
    $zuozheWhere .= " AND zuozhe_id IN({$zuozheIdStr}) ";
}

$toutiaoIdsArr = array();
$toutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list($zuozheWhere, 'ORDER BY id DESC', 0, 1000);
if(is_array($toutiaoListTmp) && !empty($toutiaoListTmp)){
    foreach($toutiaoListTmp as $key => $value){
        $toutiaoIdsArr[] = $value['id'];
    }
} 

$toutiaoIdsStr = '';
if(!empty($toutiaoIdsArr)){
    $toutiaoIdsStr = implode(',', $toutiaoIdsArr);
}

$where = " AND tctoutiao_id = 999999999 ";
if($tctoutiao_id > 0){
    $where = " AND tctoutiao_id = {$tctoutiao_id} ";
}else if(!empty($toutiaoIdsStr)){
    $where = " AND tctoutiao_id IN({$toutiaoIdsStr}) ";
}

$pagesize = 30;
$start = ($page - 1) * $pagesize;

$count = C::t('#tom_tctoutiao#tom_tctoutiao_pinglun')->fetch_all_count($where);
$pinglunListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_pinglun')->fetch_all_list($where, 'ORDER BY id DESC', $start, $pagesize);
$pinglunList = array();
if(!empty($pinglunListTmp) && !empty($pinglunListTmp)){
    foreach($pinglunListTmp as $key => $value){
        $pinglunList[$key] = $value;

        $replyListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_pinglun_reply')->fetch_all_list(" AND pinglun_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $tctoutiaoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_by_id($value['tctoutiao_id']);

        $pinglunList[$key]['userInfo'] = $userInfoTmp;
        $pinglunList[$key]['replyList'] = $replyListTmp;
        $pinglunList[$key]['tctoutiaoInfo'] = $tctoutiaoInfoTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=pinglun&tctoutiao_id={$tctoutiao_id}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=pinglun&tctoutiao_id={$tctoutiao_id}&page={$nextPage}";
$firstPageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=pinglun&tctoutiao_id={$tctoutiao_id}&page=1";
$lastPageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=pinglun&tctoutiao_id={$tctoutiao_id}&page={$allPageNum}";

$ajaxRemovePinglunUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=pinglun&act=remove&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tctoutiao:manage/pinglun");