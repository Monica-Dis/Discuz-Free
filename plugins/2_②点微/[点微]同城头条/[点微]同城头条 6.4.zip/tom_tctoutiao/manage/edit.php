<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tctoutiao_id   = intval($_GET['tctoutiao_id'])>0? intval($_GET['tctoutiao_id']):0;
$zuozhe_id      = intval($_GET['zuozhe_id'])>0 ?intval($_GET['zuozhe_id']):0;

$tctoutiaoInfo  = C::t("#tom_tctoutiao#tom_tctoutiao")->fetch_by_id($tctoutiao_id);
$zuozheInfo     = C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe")->fetch_by_id($tctoutiaoInfo['zuozhe_id']);

if($__IsManager != 1 && $zuozheInfo['bbs_uid'] != $_G['uid']){
    dheader('location:'.$_G['siteurl']);exit;
}

$allow_edit_clicks = $allow_edit_paixu = 0;
if($__IsManager == 1 || $zuozheInfo['type'] == 2){
    $allow_edit_clicks = 1;
    $allow_edit_paixu = 1;
}else{
    if($tctoutiaoConfig['open_edit_clicks'] == 1){
        $allow_edit_clicks = 1;
    }
    if($tctoutiaoConfig['open_edit_paixu'] == 1){
        $allow_edit_paixu = 1;
    }
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){

    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $site_id            = intval($_GET['site_id'])>0? intval($_GET['site_id']):0;
    $cate_id            = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
    $label_id           = intval($_GET['label_id'])>0? intval($_GET['label_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $tcshop_ids         = isset($_GET['tcshop_ids'])? addslashes($_GET['tcshop_ids']):'';
    $tcqianggou_ids     = isset($_GET['tcqianggou_ids'])? addslashes($_GET['tcqianggou_ids']):'';
    $tcmall_ids         = isset($_GET['tcmall_ids'])? addslashes($_GET['tcmall_ids']):'';
    $virtual_clicks     = intval($_GET['virtual_clicks'])>0? intval($_GET['virtual_clicks']):0;
    $open_pay_reading   = intval($_GET['open_pay_reading'])>0? intval($_GET['open_pay_reading']):0;
    $pay_reading_price  = floatval($_GET['pay_reading_price'])>0? floatval($_GET['pay_reading_price']):0.00;
    $app_read           = intval($_GET['app_read'])>0? intval($_GET['app_read']):0;
    $tuji_listpic_type  = intval($_GET['tuji_listpic_type'])>0? intval($_GET['tuji_listpic_type']):0;
    $list_bigpic        = intval($_GET['list_bigpic'])>0? intval($_GET['list_bigpic']):1;
    $video_picurl       = isset($_GET['video_picurl'])? addslashes($_GET['video_picurl']):'';
    $nopay_video_link   = isset($_GET['nopay_video_link'])? addslashes($_GET['nopay_video_link']):'';
    $video_link         = isset($_GET['video_link'])? addslashes($_GET['video_link']):'';
    $nopay_content      = isset($_GET['nopay_content'])? addslashes($_GET['nopay_content']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $share_title        = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc         = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $share_pic          = isset($_GET['share_pic'])? addslashes($_GET['share_pic']):'';
    $paixu              = intval($_GET['paixu'])>0? intval($_GET['paixu']):666666;
    
    $picListArr = array();
    if(isset($_GET['picurl']) && is_array($_GET['picurl']) && !empty($_GET['picurl'])){
        foreach($_GET['picurl'] as $key => $value){
            $picListArr[] = addslashes($value);
        }
    }
    
    $imgArr = array();
    $pattern='#src="source/plugin/tom_ueditor/upload/image/[^"]+"#i';
    preg_match_all($pattern,stripslashes($content),$imgArr);
    $contentImgArr = array();
    if(is_array($imgArr) && !empty($imgArr[0])){
        foreach($imgArr[0] as $key => $value){
            $value = str_replace('src=', '', $value);
            $value = trim($value, '"');
            $contentImgArr[] = $value;
        }
    }
    $imgArr2 = array();
    preg_match_all('#src="source/plugin/tom_tctoutiao/data/photo/[^"]+"#i',stripslashes($content),$imgArr2);
    if(is_array($imgArr2) && !empty($imgArr2[0])){
        foreach($imgArr2[0] as $key => $value){
            $value = str_replace('src=', '', $value);
            $value = trim($value, '"');
            $contentImgArr[] = $value;
        }
    }
    $imgArr3 = array();
    preg_match_all('#src="data/attachment/tomwx/[^"]+"#i',stripslashes($content),$imgArr3);
    if(is_array($imgArr3) && !empty($imgArr3[0])){
        foreach($imgArr3[0] as $key => $value){
            $value = str_replace('src=', '', $value);
            $value = trim($value, '"');
            $contentImgArr[] = $value;
        }
    }
    
    $photoArr = array();
    for($i=1; $i< 100; $i++){
        if(isset($_GET['tuji_pic_'.$i]) && !empty($_GET['tuji_pic_'.$i])){
            $lineArr = array();
            $lineArr['picurl']  = addslashes($_GET['tuji_pic_'.$i]);
            $lineArr['content'] = addslashes($_GET['tuji_content_'.$i]);
            $lineArr['psort']   = addslashes($_GET['tuji_sort_'.$i]);
            $photoArr[] = $lineArr;
        }
    }
    
    if($zuozheInfo['type'] == 3){
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($zuozheInfo['tcshop_id']);
    }
    $labelInfo = C::t("#tom_tctoutiao#tom_tctoutiao_label")->fetch_by_id($label_id);
    $cateInfo = C::t("#tom_tctoutiao#tom_tctoutiao_cate")->fetch_by_id($cate_id);
    
    $search_tcshop_ids = '';
    if(!empty($tcshop_ids)){
        $search_tcshop_ids = str_replace("|",'-', $tcshop_ids);
        $search_tcshop_ids = '-'.$search_tcshop_ids.'-';
    }
    
    $search_text = $title.'|+++++|'.$zuozheInfo['name'].'|+++++|'.$cateInfo['name'].'|+++++|'.$labelInfo['name'].'|+++++|'.$share_title.'|+++++|'.$share_desc;
    
    $updateData = array();
    if($zuozheInfo['type'] == 3){
        $updateData['site_id']              = $tcshopInfo['site_id'];
        $updateData['tcshop_ids']           = $zuozheInfo['tcshop_id'];
        $updateData['search_tcshop_ids']    = '-'.$zuozheInfo['tcshop_id'].'-';
    }else{
        $updateData['site_id']              = $site_id;
        $updateData['tcshop_ids']           = $tcshop_ids;
        $updateData['search_tcshop_ids']    = $search_tcshop_ids;
    }
    $updateData['cate_id']              = $cate_id;
    $updateData['label_id']             = $label_id;
    $updateData['label_name']           = $labelInfo['name'];
    $updateData['tcqianggou_ids']       = $tcqianggou_ids;
    $updateData['tcmall_ids']           = $tcmall_ids;
    $updateData['title']                = $title;
    $updateData['virtual_clicks']       = $virtual_clicks;
    $updateData['open_pay_reading']     = $open_pay_reading;
    $updateData['pay_reading_price']    = $pay_reading_price;
    $updateData['app_read']             = $app_read;
    $updateData['tuji_listpic_type']    = $tuji_listpic_type;
    $updateData['list_bigpic']          = $list_bigpic;
    $updateData['nopay_video_link']     = $nopay_video_link;
    $updateData['video_link']           = $video_link;
    $updateData['nopay_content']        = $nopay_content;
    $updateData['content']              = $content;
    $updateData['share_title']          = $share_title;
    $updateData['share_desc']           = $share_desc;
    $updateData['share_pic']            = $share_pic;
    $updateData['mobile_status']        = 0;
    if($__IsManager == 1){
        $updateData['paixu']                = $paixu;
    }
    if($zuozheInfo['type'] == 1 && $zuozheInfo['shenhe_type'] == 1){
        $updateData['shenhe_status']    = 2;
    }
    $updateData['search_text']          = $search_text;
    $updateData['part1']                = TIMESTAMP;
    if(C::t("#tom_tctoutiao#tom_tctoutiao")->update($tctoutiao_id, $updateData)){
        
        C::t("#tom_tctoutiao#tom_tctoutiao_photo")->delete_by_tctoutiao_id($tctoutiao_id);
        
        if($tctoutiaoInfo['type'] == 1 || $tctoutiaoInfo['type'] == 2){
            if(is_array($picListArr) && !empty($picListArr)){
                foreach($picListArr as $key => $value){
                    $insertData = array();
                    $insertData['tctoutiao_id'] = $tctoutiao_id;
                    $insertData['type']         = 1;
                    $insertData['picurl']       = $value;
                    $insertData['add_time']     = TIMESTAMP;
                    C::t("#tom_tctoutiao#tom_tctoutiao_photo")->insert($insertData);
                }
            }
        }
        if($tctoutiaoInfo['type'] == 2){
            if(is_array($photoArr) && !empty($photoArr)){
                foreach($photoArr as $key => $value){
                    $insertData = array();
                    $insertData['tctoutiao_id'] = $tctoutiao_id;
                    $insertData['type']         = 2;
                    $insertData['picurl']       = $value['picurl'];
                    $insertData['content']      = $value['content'];
                    $insertData['psort']        = $value['psort'];
                    $insertData['add_time']     = TIMESTAMP;
                    C::t("#tom_tctoutiao#tom_tctoutiao_photo")->insert($insertData);
                }
            }
        }
        if($tctoutiaoInfo['type'] == 1 || $tctoutiaoInfo['type'] == 3){
            if(is_array($contentImgArr) && !empty($contentImgArr)){
                foreach($contentImgArr as $key => $value){
                    $insertData = array();
                    $insertData['tctoutiao_id'] = $tctoutiao_id;
                    $insertData['type']         = 5;
                    $insertData['picurl']       = $value;
                    $insertData['psort']        = 100000;
                    $insertData['add_time']     = TIMESTAMP;
                    C::t("#tom_tctoutiao#tom_tctoutiao_photo")->insert($insertData);
                }
            }
        }
        if($tctoutiaoInfo['type'] == 3){
            $insertData = array();
            $insertData['tctoutiao_id'] = $tctoutiao_id;
            $insertData['type']         = 3;
            $insertData['picurl']       = $video_picurl;
            $insertData['psort']        = 100000;
            $insertData['add_time']     = TIMESTAMP;
            C::t("#tom_tctoutiao#tom_tctoutiao_photo")->insert($insertData);
        }
        
        if($zuozheInfo['type'] == 1 && $zuozheInfo['shenhe_type'] == 1){
            
            $toUser = array();
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $toUser = $toUserTmp;
            }
            
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
            $weixinClass = new weixinClass($appid,$appsecret);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();

            if($access_token && !empty($toUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$zuozheInfo['site_id']}&mod=index");
                $smsData = array(
                    'first'         => '['.$zuozheInfo['name'].']'.lang('plugin/tom_tctoutiao','edit_shenhe_template_first'),
                    'keyword1'      => $tctoutiaoConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
        );
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
    
    }    
    echo json_encode($outArr); exit;
    
}

if($zuozheInfo['type'] == 3){
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($zuozheInfo['tcshop_id']);
    if($tcshopInfo['site_id'] > 1){
        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcshopInfo['site_id']);
    }
}else{
    $sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesList = array();
    if(is_array($sitesListTmp) && !empty($sitesListTmp)){
        foreach($sitesListTmp as $key => $value){
            $sitesList[$key] = $value;
        }
    }
}

$cateListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_cate')->fetch_all_list(" ", 'ORDER BY csort ASC, id DESC', 0, 500);
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$key] = $value;
    }
}
$cateCount = count($cateList);

$labelListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_label')->fetch_all_list(" ", 'ORDER BY id DESC', 0, 500);
$labelList = array();
if(is_array($labelListTmp) && !empty($labelListTmp)){
    foreach($labelListTmp as $key => $value){
        $labelList[$key] = $value;
    }
}
$labelCount = count($labelList);

$photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(" AND tctoutiao_id = {$tctoutiaoInfo['id']} ", 'ORDER BY psort ASC, id ASC', 0, 500);
$photoList = $coverList = $videoInfo = array();
$i = 1;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        
        if($value['type'] == 1){
            $coverList[$key]['picurl'] = $value['picurl'];
            $coverList[$key]['picurlTmp'] = $value['picurlTmp'];
        }else if($value['type'] == 2){
            $photoList[$key] = $value;
            $photoList[$key]['picurlTmp'] = $value['picurlTmp'];
            $photoList[$key]['i'] = $i;
            $i++;
        }else if($value['type'] == 3){
            $videoInfo['picurl'] = $value['picurl'];
            $videoInfo['picurlTmp'] = $value['picurlTmp'];
        }
    }
}
$photoCount = count($photoList);
$coverCount = count($coverList);

$content = stripslashes($tctoutiaoInfo['content']);
$nopay_content = stripslashes($tctoutiaoInfo['nopay_content']);

if(!preg_match('/^http/', $tctoutiaoInfo['share_pic']) ){
    if(strpos($tctoutiaoInfo['share_pic'], 'source/plugin/tom_') === FALSE){
        $share_pic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tctoutiaoInfo['share_pic'];
    }else{
        $share_pic = $tctoutiaoInfo['share_pic'];
    }
}else{
    $share_pic = $tctoutiaoInfo['share_pic'];
}

$saveUrl = "plugin.php?id=tom_tctoutiao:manage&mod=edit&formhash={$formhash}";
$ossBatchUrl = 'plugin.php?id=tom_tctoutiao:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tctoutiao:qiniuBatch';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
if($tctoutiaoInfo['type'] == 1){
    include template("tom_tctoutiao:manage/edit");
}else if($tctoutiaoInfo['type'] == 2){
    include template("tom_tctoutiao:manage/edit_tuji");
}else if($tctoutiaoInfo['type'] == 3){
    include template("tom_tctoutiao:manage/edit_video");
}