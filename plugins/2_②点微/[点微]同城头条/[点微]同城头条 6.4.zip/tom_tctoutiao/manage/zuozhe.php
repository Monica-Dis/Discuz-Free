<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page       = intval($_GET['page'])>1? intval($_GET['page']):1;

$pagesize = 10;
$start = ($page - 1) * $pagesize;
if($__IsManager == 1){
    $count = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_count(" ");
    $zuozheListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list("  ", 'ORDER BY id DESC', $start, $pagesize);
}else{
    $count = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_count(" AND bbs_uid = {$_G['uid']} ");
    $zuozheListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(" AND bbs_uid = {$_G['uid']} ", 'ORDER BY id DESC', $start, $pagesize);
}
$zuozheList = array();
if(is_array($zuozheListTmp) && !empty($zuozheListTmp)){
    foreach($zuozheListTmp as $key => $value){
        $zuozheList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        $tctoutiaoCount = C::t("#tom_tctoutiao#tom_tctoutiao")->fetch_all_count(" AND zuozhe_id = {$value['id']} ");
        $guanzuCount    = C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe_guanzu")->fetch_all_count(" AND zuozhe_id = {$value['id']} ");
        $clicksCount    = C::t("#tom_tctoutiao#tom_tctoutiao")->fetch_clicks_sum(" AND zuozhe_id = {$value['id']} ");
        
        $zuozheList[$key]['picurl']         = $picurl;
        $zuozheList[$key]['tctoutiaoCount'] = intval($tctoutiaoCount);
        $zuozheList[$key]['guanzuCount']    = intval($guanzuCount);
        $zuozheList[$key]['clicksCount']    = intval($clicksCount);
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=zuozhe&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=zuozhe&page={$nextPage}";
$firstPageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=zuozhe&page=1";
$lastPageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=zuozhe&page={$allPageNum}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tctoutiao:manage/zuozhe");