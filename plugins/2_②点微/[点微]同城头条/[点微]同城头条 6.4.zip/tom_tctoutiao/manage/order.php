<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page           = intval($_GET['page'])>1? intval($_GET['page']):1;
$order_type     = intval($_GET['order_type'])>0? intval($_GET['order_type']):0;
$zuozhe_id      = intval($_GET['zuozhe_id'])>0? intval($_GET['zuozhe_id']):0;
$tctoutiao_id   = intval($_GET['tctoutiao_id'])>0? intval($_GET['tctoutiao_id']):0;

$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

if($__IsManager == 1){
    $zuozheListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(" ", 'ORDER BY id DESC', 0, 1000);
}else{
    $zuozheListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(" AND bbs_uid = {$_G['uid']} ", 'ORDER BY id DESC', 0, 100);
}
$zuozheList = $zuozheIdArr = array();
if(is_array($zuozheListTmp) && !empty($zuozheListTmp)){
    foreach($zuozheListTmp as $key => $value){
        $zuozheList[$key] = $value;
        $zuozheIdArr[] = $value['id'];
    }
}
$zuozheIdStr = '';
if(!empty($zuozheIdArr)){
    $zuozheIdStr = implode(',', $zuozheIdArr);
}

$pagesize = 30;
$start = ($page - 1) * $pagesize;

$where = '';
if($zuozhe_id > 0){
    $where .= " AND zuozhe_id = {$zuozhe_id} ";
}else if(!empty($zuozheIdStr)){
    $where .= " AND zuozhe_id IN({$zuozheIdStr}) ";
}
if($tctoutiao_id > 0){
    $where .= " AND tctoutiao_id = {$tctoutiao_id} ";
}
if($order_type > 0){
    $where .= " AND order_type = {$order_type} ";
}
$count          = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_count($where);
$orderListTmp   = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_list($where, 'ORDER BY id DESC', $start, $pagesize);
$todayPayPrice  = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_sun_zuozhe_shouyi_price($where." AND pay_time > $nowDayTime AND order_status=2 ");
$monthPayPrice  = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_sun_zuozhe_shouyi_price($where." AND pay_time > $nowMonthTime AND order_status=2 ");
$allPayPrice    = C::t('#tom_tctoutiao#tom_tctoutiao_order')->fetch_all_sun_zuozhe_shouyi_price($where." AND order_status=2 ");
$orderList      = array();
if(!empty($orderListTmp) && !empty($orderListTmp)){
    foreach($orderListTmp as $key => $value){
        $orderList[$key] = $value;
        $tctoutiaoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_by_id($value['tctoutiao_id']);
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $orderList[$key]['userInfo'] = $userInfoTmp;
        $orderList[$key]['tctoutiaoInfo'] = $tctoutiaoInfoTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=order&tctoutiao_id={$tctoutiao_id}&order_type={$order_type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=order&tctoutiao_id={$tctoutiao_id}&order_type={$order_type}&page={$nextPage}";
$firstPageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=order&tctoutiao_id={$tctoutiao_id}&order_type={$order_type}&page=1";
$lastPageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=order&tctoutiao_id={$tctoutiao_id}&order_type={$order_type}&page={$allPageNum}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tctoutiao:manage/order");