<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$zuozhe_id = intval($_GET['zuozhe_id'])> 0? intval($_GET['zuozhe_id']):0;
$keyword   = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';

$zuozheInfo = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($zuozhe_id);

if($__IsManager != 1 && $zuozheInfo['bbs_uid'] != $_G['uid']){
    dheader('location:'.$_G['siteurl']);exit;
}

if($_GET['act'] == 'update_status' && $_GET['formhash'] == FORMHASH){

    $tctoutiao_id = intval($_GET['tctoutiao_id'])>0? intval($_GET['tctoutiao_id']):0;
    
    if($_GET['status'] == 1){
        $updateData = array();
        $updateData['status'] = 1;
        C::t('#tom_tctoutiao#tom_tctoutiao')->update($tctoutiao_id,$updateData);
    }else{
        $updateData = array();
        $updateData['status'] = 0;
        C::t('#tom_tctoutiao#tom_tctoutiao')->update($tctoutiao_id,$updateData);
    }
    
    echo 200;exit;
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    $url = $_G['siteurl']."plugin.php?id=tom_tctoutiao:manage&mod=list&zuozhe_id={$zuozhe_id}&keyword=".urlencode(trim($keyword));
    echo $url;exit;
    
}

$page       = intval($_GET['page'])>1? intval($_GET['page']):1;
$type       = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = '';
if($zuozhe_id > 0){
    $where .= " AND zuozhe_id = {$zuozhe_id} ";
}
if($type == 1){
    $where .= ' AND shenhe_status = 1 AND status = 1 ';
}
if($type == 2){
    $where .= ' AND shenhe_status = 2 ';
}
if($type == 3){
    $where .= ' AND shenhe_status = 3 ';
}

$pagesize = 10;
$start = ($page - 1) * $pagesize;
$count = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_count($where,$keyword);
$tctoutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list($where, 'ORDER BY id DESC', $start, $pagesize,$keyword);
if(!empty($tctoutiaoListTmp) && !empty($tctoutiaoListTmp)){
    foreach($tctoutiaoListTmp as $key => $value){
        $tctoutiaoList[$key] = $value;

        $coverPic = '';
        if($value['type'] == 1){
            $photoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(" AND tctoutiao_id = {$value['id']} AND type = 1 ",'ORDER BY psort ASC,id DESC', 0, 1);
            if(!empty($photoInfoTmp[0]['picurlTmp'])){
                $coverPic = $photoInfoTmp[0]['picurlTmp'];
            }
            
        }else if($value['type'] == 2){
            if($value['tuji_listpic_type'] == 1){
                $photoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(" AND tctoutiao_id = {$value['id']} AND type = 2 ",'ORDER BY psort ASC,id DESC', 0, 1);
                if(!empty($photoInfoTmp[0]['picurlTmp'])){
                    $coverPic = $photoInfoTmp[0]['picurlTmp'];
                }

            }else{
                $photoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(" AND tctoutiao_id = {$value['id']} AND type = 1 ",'ORDER BY psort ASC,id DESC', 0, 1);
                if(!empty($photoInfoTmp[0]['picurlTmp'])){
                    $coverPic = $photoInfoTmp[0]['picurlTmp'];
                }
            }
        }else if($value['type'] == 3){
            $photoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(" AND tctoutiao_id = {$value['id']} AND type = 3 ",'ORDER BY psort ASC,id DESC', 0, 1);
            if(!empty($photoInfoTmp[0]['picurlTmp'])){
                $coverPic = $photoInfoTmp[0]['picurlTmp'];
            }

        }

        $collectCount  = C::t('#tom_tctoutiao#tom_tctoutiao_collect')->fetch_all_count(" AND tctoutiao_id = {$value['id']} ");
        $zuozheInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_by_id($value['zuozhe_id']);

        $shenhe_type = 0;
        if($zuozheInfoTmp['type'] == 1){
            $shenhe_type = 1;
            if($value['shenhe_status'] == 2){
                $shenhe_type = 0;
            }
        }
        
        $tougaoUserInfo = array();
        if($value['tougao_user_id'] > 0){
            $tougaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['tougao_user_id']);
        }

        $tctoutiaoList[$key]['coverPic'] = $coverPic;
        $tctoutiaoList[$key]['collectCount'] = $collectCount;
        $tctoutiaoList[$key]['zuozheInfo'] = $zuozheInfoTmp;
        $tctoutiaoList[$key]['shenhe_type'] = $shenhe_type;
        $tctoutiaoList[$key]['tougaoUserInfo'] = $tougaoUserInfo;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=list&type={$type}&zuozhe_id={$zuozhe_id}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=list&type={$type}&zuozhe_id={$zuozhe_id}&page={$nextPage}&keyword=".$_GET['keyword'];
$firstPageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=list&type={$type}&zuozhe_id={$zuozhe_id}&page=1&keyword=".$_GET['keyword'];
$lastPageUrl = "plugin.php?id=tom_tctoutiao:manage&site={$site_id}&mod=list&type={$type}&zuozhe_id={$zuozhe_id}&page={$allPageNum}&keyword=".$_GET['keyword'];

$updateStatusUrl    = "plugin.php?id=tom_tctoutiao:manage&mod=list&act=update_status&zuozhe_id={$zuozhe_id}&formhash={$formhash}";

$searchUrl          = "plugin.php?id=tom_tctoutiao:manage&mod=list&act=get_search_url&zuozhe_id={$zuozhe_id}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tctoutiao:manage/list");