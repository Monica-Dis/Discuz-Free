<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$hostsConfig = $_G['cache']['plugin']['tom_hosts'];

if(isset($_GET['debug'])){
    $hostsConfig['open_debug'] = 0;
}

$hostsShowList = C::t('#tom_hosts#tom_hosts_show')->fetch_all_list(" AND status=1 ","ORDER BY id DESC",0,1);
$hostsShareList = C::t('#tom_hosts#tom_hosts_share')->fetch_all_list(" AND status=1 ","ORDER BY id DESC",0,50);

if(is_array($hostsShowList) && !empty($hostsShowList[0]) && is_array($hostsShareList) && !empty($hostsShareList)){
    
    $showDomain = $hostsShowList[0]['domains'];
    
    $shareDomainArr = array();
    foreach ($hostsShareList as $key => $value){
        $shareDomainArr[$key] = $value['domains'];
    }

    $visitDomain = trim($_G['siteurl']);
    $visitUrl = get_new_url($visitDomain,$_GET);
    
    $jumpUrl = '';
    $showJumpUrl = '';
    foreach ($shareDomainArr as $key => $value){
        if(strpos($visitDomain,$value) !== false){
            $showUrlTmp = str_replace($value, $showDomain, $visitDomain);
            $jumpUrl = get_new_url($showUrlTmp,$_GET);
            if($hostsConfig['open_debug'] == 1 && isset($_GET['from'])){
                $showJumpUrl = $jumpUrl."&debug=1";
            }else{
                dheader('location:'.$jumpUrl);exit;
            }
        }
    }
    
    if(strpos($visitDomain,$showDomain) !== false){
        $randKey = array_rand($shareDomainArr,1);
        $_G['siteshareurl'] = str_replace($showDomain, $shareDomainArr[$randKey], $_G['siteurl']);
    }
    
    if($hostsConfig['open_debug'] == 1 && isset($_GET['from'])){
        $isGbk = false;
        if (CHARSET == 'gbk') $isGbk = true;
        include template("tom_hosts:hosts");
        exit;
    }
    
}

function get_new_url($domain = '',$get = array()){
    
    $urlStr = $domain.'plugin.php?';
    if(is_array($get) && !empty($get)){
        foreach ($get as $key => $value){
            $urlStr.= "$key=$value&";
        }
    }
    $urlStr = rtrim($urlStr, "&");
    
    if(defined('TOM_LINK_BIAOSHI') && file_exists(DISCUZ_ROOT."./source/plugin/tom_link/data/rule.php")){
        $tom_link_rule = include DISCUZ_ROOT."./source/plugin/tom_link/data/rule.php";
        $biaoshiStr = TOM_LINK_BIAOSHI;
        $urlStr = str_replace("plugin.php?id=".$biaoshiStr, $tom_link_rule[$biaoshiStr]['rk']."?id=".$tom_link_rule[$biaoshiStr]['bs'], $urlStr);
    }
    
    return $urlStr;
}