<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

if($_GET['act'] == 'addShow'){
    if(submitcheck('submit')){
        $domains            = isset($_GET['domains'])? addslashes($_GET['domains']):'';
        $insertData = array();
        $insertData['domains'] = trim($domains);
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_hosts#tom_hosts_show')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }
}else if($_GET['act'] == 'addShare'){
    if(submitcheck('submit')){
        $domains            = isset($_GET['domains'])? addslashes($_GET['domains']):'';
        $insertData = array();
        $insertData['domains'] = trim($domains);
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_hosts#tom_hosts_share')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'openShow'){
    
    $hostsShowListTmp = C::t('#tom_hosts#tom_hosts_show')->fetch_all_list(" AND status=1 ","ORDER BY id DESC",0,1);
    
    $updateData = array();
    $updateData['status']     = 0;
    C::t('#tom_hosts#tom_hosts_show')->update($hostsShowListTmp[0]['id'],$updateData);
    if($hostsConfig['admin_allow_save'] == 1){
        $updateData = array();
        $updateData['status']     = 1;
        C::t('#tom_hosts#tom_hosts_show')->update($_GET['id'],$updateData);
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'closeShow'){
    $updateData = array();
    $updateData['status']     = 0;
    C::t('#tom_hosts#tom_hosts_show')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'openShare'){
    if($hostsConfig['admin_allow_save'] == 1){
        $updateData = array();
        $updateData['status']     = 1;
        C::t('#tom_hosts#tom_hosts_share')->update($_GET['id'],$updateData);
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'closeShare'){
    $updateData = array();
    $updateData['status']     = 0;
    C::t('#tom_hosts#tom_hosts_share')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delShow'){
    C::t('#tom_hosts#tom_hosts_show')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delShare'){
    C::t('#tom_hosts#tom_hosts_share')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['hosts_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['hosts_help_1_a'] . '<a target="_blank" href="http://www.tomwx.cn/index.php?m=help&t=plugin&pluginid=tom_hosts"><font color="#FF0000">' . $Lang['hosts_help_1_b'] . '</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*Dism��taobao��com*/
    
    tomshownavheader();
    tomshownavli($Lang['hosts_show_list_title'],"",true);
    tomshownavfooter();
    $hostsShowList = C::t('#tom_hosts#tom_hosts_show')->fetch_all_list(" ","ORDER BY id DESC",0,50);
    echo '<form name="cpform1" id="cpform1" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&act=addShow&formhash='.FORMHASH.'">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />'.
		'<input type="hidden" id="formscrolltop" name="scrolltop" value="" />'.
		'<input type="hidden" name="anchor" value="" />';
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['hosts_domains'] . '</th>';
    echo '<th>' . $Lang['status'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '<th width="40%">&nbsp;</th>';
    echo '</tr>';
    foreach ($hostsShowList as $key => $value) {
        echo '<tr>';
        echo '<td>' . $value['domains'] . '</td>';
        if($value['status'] == 1){
            echo '<td><font color="#009900">' . $Lang['hosts_status_1'] . '</font></td>';
        }else{
            echo '<td><font color="#aba3a3">' . $Lang['hosts_status_0'] . '</font></td>';
        }
        echo '<td>';
        if($value['status'] == 1){
            echo '<a href="'.$modBaseUrl.'&act=closeShow&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['hosts_status_0'] . '</a>&nbsp;|&nbsp;';
        }else{
            echo '<a href="'.$modBaseUrl.'&act=openShow&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['hosts_status_1'] . '</a>&nbsp;|&nbsp;';
        }
        echo '<a href="'.$modBaseUrl.'&act=delShow&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    echo '<tr>';
    echo '<td><input name="domains" type="text" value="" size="40" /></td>';
    echo '<td>';
    echo '<input type="submit" class="btn" id="submit_submit" name="submit" value="' . $Lang['hosts_domains_submit'] . '">';
    echo '</td>';
    echo '</tr>';
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/
    
    tomshownavheader();
    tomshownavli($Lang['hosts_share_list_title'],"",true);
    tomshownavfooter();
    $hostsShareList = C::t('#tom_hosts#tom_hosts_share')->fetch_all_list(" ","ORDER BY id DESC",0,50);
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&act=addShare&formhash='.FORMHASH.'">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />'.
		'<input type="hidden" id="formscrolltop" name="scrolltop" value="" />'.
		'<input type="hidden" name="anchor" value="" />';
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['hosts_domains'] . '</th>';
    echo '<th>' . $Lang['status'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '<th width="40%">&nbsp;</th>';
    echo '</tr>';
    foreach ($hostsShareList as $key => $value) {
        echo '<tr>';
        echo '<td>' . $value['domains'] . '</td>';
        if($value['status'] == 1){
            echo '<td><font color="#009900">' . $Lang['hosts_status_1'] . '</font></td>';
        }else{
            echo '<td><font color="#aba3a3">' . $Lang['hosts_status_0'] . '</font></td>';
        }
        echo '<td>';
        if($value['status'] == 1){
            echo '<a href="'.$modBaseUrl.'&act=closeShare&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['hosts_status_0'] . '</a>&nbsp;|&nbsp;';
        }else{
            echo '<a href="'.$modBaseUrl.'&act=openShare&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['hosts_status_1'] . '</a>&nbsp;|&nbsp;';
        }
        echo '<a href="'.$modBaseUrl.'&act=delShare&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    echo '<tr>';
    echo '<td><input name="domains" type="text" value="" size="40" /></td>';
    echo '<td>';
    echo '<input type="submit" class="btn" id="submit_submit" name="submit" value="' . $Lang['hosts_domains_submit'] . '">';
    echo '</td>';
    echo '</tr>';
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/
}


