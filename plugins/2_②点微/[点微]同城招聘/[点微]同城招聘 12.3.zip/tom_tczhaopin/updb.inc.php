<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/plugin');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $sql = '';
    
    $tom_tczhaopin_field = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_field();
    if (!isset($tom_tczhaopin_field['auto_click_time'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `auto_click_time` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_field['jianzhi_work_salary'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `jianzhi_work_salary` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_field['jianzhi_work_salary_unit'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `jianzhi_work_salary_unit` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_field['jianzhi_jiesuan_fangshi'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `jianzhi_jiesuan_fangshi` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_field['video_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `video_status` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_field['video_url'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `video_url` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tczhaopin_field['video_pic'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `video_pic` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tczhaopin_field['expire_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `expire_status` int(11) DEFAULT '3';\n";
    }
    if (!isset($tom_tczhaopin_field['expire_time'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `expire_time` int(11) unsigned DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_field['jianzhi_cate_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `jianzhi_cate_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_field['work_salary_min'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `work_salary_min` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_field['work_salary_max'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `work_salary_max` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_field['over_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `over_status` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_field['client_ip_port'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin` ADD `client_ip_port` varchar(255) DEFAULT NULL;\n";
    }
    
    $tom_tczhaopin_order_field = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_all_field();
    if (!isset($tom_tczhaopin_order_field['fabu_days'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_order` ADD `fabu_days` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_order_field['fabu_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_order` ADD `fabu_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tczhaopin_order_field['meeting_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_order` ADD `meeting_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_order_field['meeting_company_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_order` ADD `meeting_company_id` int(11) DEFAULT '0';\n";
    }
    
    $tom_tczhaopin_resume_field = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_field();
    if (!isset($tom_tczhaopin_resume_field['auto_click_time'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_resume` ADD `auto_click_time` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_resume_field['video_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_resume` ADD `video_status` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_resume_field['video_url'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_resume` ADD `video_url` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tczhaopin_resume_field['video_pic'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_resume` ADD `video_pic` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tczhaopin_resume_field['type'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_resume` ADD `type` tinyint(11) DEFAULT '1';\n";
    }
    if (!isset($tom_tczhaopin_resume_field['work_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_resume` ADD `work_status` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_resume_field['client_ip_port'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_resume` ADD `client_ip_port` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tczhaopin_resume_field['shenqing_num'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_resume` ADD `shenqing_num` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_resume_field['deleted'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_resume` ADD `deleted` tinyint(4) DEFAULT '0';\n";
    }
    
    $tom_tczhaopin_focuspic_field = C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->fetch_all_field();
    if (!isset($tom_tczhaopin_focuspic_field['type'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_focuspic` ADD `type` tinyint(4) DEFAULT '1';\n";
    }
    
    $tom_tczhaopin_vip_field = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_all_field();
    if (!isset($tom_tczhaopin_vip_field['max_num'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_vip` ADD `max_num` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_vip_field['top_zhekou'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_vip` ADD `top_zhekou` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tczhaopin_vip_field['market_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_vip` ADD `market_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tczhaopin_vip_field['beizu'])) {
        $sql .= "ALTER TABLE `pre_tom_tczhaopin_vip` ADD `beizu` varchar(255) DEFAULT NULL;\n";
    }
    
    if (!empty($sql)) {
        runquery($sql);
    }
    
    $sql = <<<EOF
    CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_collect` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `user_id` int(11) DEFAULT '0',
    `tczhaopin_id` int(11) DEFAULT '0',
    `add_time` int(11) unsigned DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_resume_collect` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `user_id` int(11) DEFAULT '0',
    `resume_id` int(11) DEFAULT '0',
    `add_time` int(11) unsigned DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_meeting` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `site_id` int(11) DEFAULT '1',
    `title` varchar(255) DEFAULT NULL,
    `type` tinyint(4) DEFAULT '0',
    `open_pay` tinyint(4) DEFAULT '0',
    `pay_price` decimal(10,2) DEFAULT '0.00',
    `picurl` varchar(255) DEFAULT NULL,
    `theme_picurl` varchar(255) DEFAULT NULL,
    `theme_color` varchar(255) DEFAULT NULL,
    `organizer` varchar(255) DEFAULT NULL,
    `max_num` int(11) DEFAULT '0',
    `address` varchar(255) DEFAULT NULL,
    `latitude` varchar(255) DEFAULT NULL,
    `longitude` varchar(255) DEFAULT NULL,
    `haibao_picurl` varchar(255) DEFAULT NULL,
    `qrcode_location` tinyint(4) DEFAULT '1',
    `content` text,
    `start_time` int(11) unsigned DEFAULT '0',
    `bmend_time` int(11) unsigned DEFAULT '0',
    `end_time` int(11) unsigned DEFAULT '0',
    `share_title` varchar(255) DEFAULT NULL,
    `share_desc` varchar(255) DEFAULT NULL,
    `virtual_clicks` int(11) DEFAULT '0',
    `clicks` int(11) DEFAULT '0',
    `status` tinyint(4) DEFAULT '0',
    `msort` int(11) DEFAULT '10',
    `add_time` int(11) unsigned DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_meeting_company` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `meeting_id` int(11) DEFAULT '0',
    `user_id` int(11) DEFAULT '0',
    `company_id` int(11) DEFAULT '0',
    `tczhaopin_ids` text,
    `tczhaopin_num` int(11) DEFAULT '0',
    `is_recommend` tinyint(4) DEFAULT '0',
    `csort` int(11) DEFAULT '10',
    `status` tinyint(4) DEFAULT '0',
    `pay_status` tinyint(4) DEFAULT '0',
    `add_time` int(11) unsigned DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_jianzhi_cate` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `name` varchar(255) DEFAULT NULL,
    `is_hot` int(11) DEFAULT '0',
    `csort` int(11) DEFAULT '100',
    `add_time` int(11) unsigned DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_photo` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `tczhaopin_id` int(11) DEFAULT '0',
    `picurl` varchar(255) DEFAULT NULL,
    `oss_picurl` varchar(255) DEFAULT NULL,
    `oss_status` int(11) DEFAULT '0',
    `qiniu_picurl` varchar(255) DEFAULT NULL,
    `qiniu_status` int(11) DEFAULT '0',
    `psort` int(11) DEFAULT '10',
    `add_time` int(11) unsigned DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_tczhaopin_id` (`tczhaopin_id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_common` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `site_id` int(11) DEFAULT '1',
    `clicks` int(11) unsigned DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_vip_code` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `vip_id` int(11) DEFAULT '0',
    `code` varchar(255) DEFAULT NULL,
    `use_status` int(11) DEFAULT '0',
    `user_id` int(11) DEFAULT '0',
    `use_time` int(11) unsigned DEFAULT '0',
    `add_time` int(11) unsigned DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
        
    CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_mianshi` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `user_id` int(11) DEFAULT '0',
    `yaoqing_user_id` int(11) DEFAULT '0',
    `tczhaopin_id` int(11) DEFAULT '0',
    `resume_id` int(11) DEFAULT '0',
    `xm` varchar(255) DEFAULT NULL,
    `tel` varchar(255) DEFAULT NULL,
    `address` varchar(255) DEFAULT NULL,
    `latitude` varchar(255) DEFAULT NULL,
    `longitude` varchar(255) DEFAULT NULL,
    `beizu` text,
    `status` int(11) DEFAULT '0',
    `add_time` int(11) unsigned DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
            
    CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_popup` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `site_ids` text,
    `link` varchar(255) DEFAULT NULL,
    `clicks` int(11) DEFAULT '0',
    `status` int(11) DEFAULT '0',
    `add_time` int(11) DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    `picurl` varchar(255) DEFAULT NULL,
    `show_num` int(11) unsigned DEFAULT '0',
    PRIMARY KEY (`id`)
  ) ENGINE=MyISAM;
          
    CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_popup_log` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `popup_id` int(11) DEFAULT '0',
    `user_id` int(11) DEFAULT '0',
    `num` int(11) DEFAULT '0',
    `log_time` int(11) DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_setting` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `open_rz_back_vip` tinyint(4) DEFAULT '1',
    `open_resume_match` tinyint(4) DEFAULT '1',
    `resume_match_cate_child` tinyint(4) DEFAULT '0',
    `resume_match_area` tinyint(4) DEFAULT '0',
    `zhaopinlist_top_bgcolor` varchar(255) DEFAULT '#fff8eb',
    PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tczhaopin_wxqun` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `site_id` int(11) DEFAULT '0',
    `name` varchar(255) DEFAULT NULL,
    `logo` varchar(255) DEFAULT NULL,
    `qrcode` varchar(255) DEFAULT NULL,
    `desc` varchar(255) DEFAULT NULL,
    `tishi_msg` varchar(255) DEFAULT NULL,
    `status` tinyint(4) DEFAULT '0',
    `add_time` int(11) unsigned DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;

    runquery($sql);
    
    $sql = '';

$tom_tczhaopin_meeting_field = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_all_field();
if (!isset($tom_tczhaopin_meeting_field['canhui_txt'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_meeting` ADD `canhui_txt` text;\n";
}
if (!isset($tom_tczhaopin_meeting_field['open_search'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_meeting` ADD `open_search` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tczhaopin_meeting_field['zhaopin_list_type'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_meeting` ADD `zhaopin_list_type` tinyint(4) DEFAULT '1';\n";
}
if (!isset($tom_tczhaopin_meeting_field['list_template'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_meeting` ADD `list_template` tinyint(4) DEFAULT '1';\n";
}

$tom_tczhaopin_meeting_company_field = C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->fetch_all_field();
if (isset($tom_tczhaopin_meeting_company_field['tczhaopin_ids']) && $tom_tczhaopin_meeting_company_field['tczhaopin_ids']['Type'] == 'varchar(255)') {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_meeting_company` CHANGE `tczhaopin_ids` `tczhaopin_ids` text;\n";
}

$tom_tczhaopin_setting_field = C::t('#tom_tczhaopin#tom_tczhaopin_setting')->fetch_all_field();
if (!isset($tom_tczhaopin_setting_field['zhaopininfo_tel_btncolor'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_setting` ADD `zhaopininfo_tel_btncolor` varchar(255) DEFAULT '#23B4DC';\n";
}
if (!isset($tom_tczhaopin_setting_field['free_fabu_resume_num'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_setting` ADD `free_fabu_resume_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tczhaopin_setting_field['everyday_shenqing_num'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_setting` ADD `everyday_shenqing_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tczhaopin_setting_field['open_zhaopin_copy'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_setting` ADD `open_zhaopin_copy` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tczhaopin_setting_field['zhaopin_copy_template'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_setting` ADD `zhaopin_copy_template` text;\n";
}
if (!isset($tom_tczhaopin_setting_field['zhaopin_copy_shorturl'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_setting` ADD `zhaopin_copy_shorturl` varchar(255) DEFAULT NULL;\n";
}

if (!isset($tom_tczhaopin_setting_field['open_zhaopin_match'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_setting` ADD `open_zhaopin_match` tinyint(4) DEFAULT '1';\n";
}
if (!isset($tom_tczhaopin_setting_field['zhaopin_match_cate_child'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_setting` ADD `zhaopin_match_cate_child` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tczhaopin_setting_field['zhaopin_match_area'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_setting` ADD `zhaopin_match_area` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tczhaopin_setting_field['fabu_top_style'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_setting` ADD `fabu_top_style` tinyint(4) DEFAULT '2';\n";
}
if (!isset($tom_tczhaopin_setting_field['index_diy_html'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_setting` ADD `index_diy_html` mediumtext;\n";
}
if (!isset($tom_tczhaopin_setting_field['open_must_zhaopin_quyu'])) {
    $sql .= "ALTER TABLE `pre_tom_tczhaopin_setting` ADD `open_must_zhaopin_quyu` tinyint(4) DEFAULT '0';\n";
}

if (!empty($sql)) {
	runquery($sql);
}
    
    echo 'OK';exit;
    
}else{
    exit('Access Denied');
}