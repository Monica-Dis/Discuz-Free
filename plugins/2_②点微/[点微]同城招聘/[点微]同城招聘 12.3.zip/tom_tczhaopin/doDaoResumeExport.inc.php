<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
$tomSysOffset = getglobal('setting/timeoffset');

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.utf.php';
}
$welfareArray = array();
$welfare_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['welfare_list']); 
$welfare_list_str = str_replace("\n","{n}",$welfare_list_str);
$welfare_list_arr = explode("{n}", $welfare_list_str);
if(is_array($welfare_list_arr) && !empty($welfare_list_arr)){
    foreach ($welfare_list_arr as $key => $value){
        $welfare_list_item = explode("|", $value);
        $welfare_list_item_id = intval($welfare_list_item[0]);
        $welfare_list_item_name = trim($welfare_list_item[1]);
        if($welfare_list_item_id > 0 && !empty($welfare_list_item_name)){
            $welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
        }
    }
}

$workStatusArray = array();
$work_status_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['work_status_list']); 
$work_status_list_str = str_replace("\n","{n}",$work_status_list_str);
$work_status_list_arr = explode("{n}", $work_status_list_str);
if(is_array($work_status_list_arr) && !empty($work_status_list_arr)){
    foreach ($work_status_list_arr as $key => $value){
        $work_status_list_item = explode("|", $value);
        $work_status_list_item_id = intval($work_status_list_item[0]);
        $work_status_list_item_name = trim($work_status_list_item[1]);
        if($work_status_list_item_id > 0 && !empty($work_status_list_item_name)){
            $workStatusArray[$work_status_list_item_id] = $work_status_list_item_name;
        }
    }
}

$resume_default_avatar = explode("|", $tczhaopinConfig['resume_default_avatar']);
$man_resume_avatar = "source/plugin/tom_tczhaopin/images/resume_avatar/".$resume_default_avatar[0];
$woman_resume_avatar = "source/plugin/tom_tczhaopin/images/resume_avatar/".$resume_default_avatar[1];

$page        = isset($_GET['page'])? intval($_GET['page']):1;
$type        = isset($_GET['type'])? intval($_GET['type']):0;
$from        = isset($_GET['from'])? addslashes($_GET['from']):'';

$where = " AND shenhe_status = 1 AND status = 1 AND deleted = 0 ";

$order = " ORDER BY top_status DESC,refresh_time DESC,id DESC ";

$daoQuanXianStatus = 0;
if($from == 'rencailist'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';
    
    if($__UserInfo['id'] > 0){
        $daoQuanXianStatus = 1;
        
        $rencauWhere = " AND user_id = {$__UserInfo['id']} ";
        if($type > 0){
           $rencauWhere .= "AND type = {$type}";
        }
        
        $resumeIdsStr = '0';
        $rencaiListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_rencai")->fetch_all_list($rencauWhere, 'ORDER BY id DESC', 0, 10000);
        $resumeIdsArr = array();
        if(is_array($rencaiListTmp) && !empty($rencaiListTmp)){
            foreach($rencaiListTmp as $key => $value){
                $resumeIdsArr[] = $value['resume_id'];
            }
            $resumeIdsStr = implode(',', $resumeIdsArr);
        }
        $where.= " AND id IN ({$resumeIdsStr}) ";
    }

}

$pagesize = 1000;
$start = ($page-1)*$pagesize;
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

if($daoQuanXianStatus == 1){
    
    $resumeListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_list($where,$order,$start,$pagesize);
    $resumeList = array();
    foreach ($resumeListTmp as $key => $value) {
        
        $resumeList[$key] = $value;
        
        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($value['cate_id']);
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
        
        $resumeList[$key]['name'] = $value['name'];
        
        if(!empty($value['avatar'])){
            if(!preg_match('/^http/', $value['avatar'])){
                if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                    $avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
                }else{
                    $avatar = $_G['siteurl'].$value['avatar'];
                }
            }else{
                $avatar = $value['avatar'];
            }
        }else{
            if($value['sex'] == 1){
                $avatar = $man_resume_avatar;
            }else if($value['sex'] == 2){
                $avatar = $woman_resume_avatar;
            }
        }
        
        $resumeList[$key]['avatar'] = $avatar;
        
        if($value['work_salary'] > 1){
            $resumeList[$key]['work_salary'] = $workSalaryArray[$value['work_salary']].lang('plugin/tom_tczhaopin', 'doDao_yuan');
        }else{
            $resumeList[$key]['work_salary'] = $workSalaryArray[$value['work_salary']];
        }
        $resumeList[$key]['work_jingyan']   = $workJingyanArray[$value['work_jingyan']];
        $resumeList[$key]['resume_cate']    = $cateInfo['name'].'/'.$value['cate_child_str'];
        $resumeList[$key]['age']            = dgmdate(TIMESTAMP,"Y",$tomSysOffset) - $value['birth_year'];
        $resumeList[$key]['xueli']          = $xueliArray[$value['xueli']];
        if($value['type'] == 1){
            $resumeList[$key]['type']           = lang('plugin/tom_tczhaopin', 'resume_type_1');
        }else if($value['type'] == 2){
            $resumeList[$key]['type']           = lang('plugin/tom_tczhaopin', 'resume_type_2');
        }
        $resumeList[$key]['work_status']  = $workStatusArray[$value['work_status']];
        $resumeList[$key]['marital']        = lang('plugin/tom_tczhaopin', 'doDao_resume_marital_'.$value['marital']);
        if($value['area_id'] > 0 && $value['street_id'] > 0){
            $resumeList[$key]['resume_location']    = $areaInfoTmp['name'].'-'.$streetInfoTmp['name'];
        }else{
            $resumeList[$key]['resume_location']    = $areaInfoTmp['name'];
        }
    }
    
    $name               = lang('plugin/tom_tczhaopin','doDao_name');
    $avatar             = lang('plugin/tom_tczhaopin','doDao_avatar');
    $age                = lang('plugin/tom_tczhaopin','doDao_resume_age');
    $marital            = lang('plugin/tom_tczhaopin','doDao_resume_marital');
    $xueli              = lang('plugin/tom_tczhaopin','doDao_resume_xueli');
    $resume_type        = lang('plugin/tom_tczhaopin','doDao_resume_type');
    $work_status      = lang('plugin/tom_tczhaopin','doDao_resume_work_status');
    $resume_cate        = lang('plugin/tom_tczhaopin','doDao_resume_cate');
    $resume_location    = lang('plugin/tom_tczhaopin','doDao_resume_location');
    $work_salary        = lang('plugin/tom_tczhaopin','doDao_resume_salary');
    $tel                = lang('plugin/tom_tczhaopin','doDao_resume_tel');
    $work_jingyan       = lang('plugin/tom_tczhaopin','doDao_resume_jinyan');
    $work_jingli        = lang('plugin/tom_tczhaopin','doDao_resume_work_jingli');
    $edu_jingli         = lang('plugin/tom_tczhaopin','doDao_resume_edu_jingli');
    $describe           = lang('plugin/tom_tczhaopin','doDao_resume_describe');
    $video_url          = lang('plugin/tom_tczhaopin','doDao_resume_video_url');
    
    
    $listData[] = array(
        $name,
        $avatar,
        $age,
        $marital,
        $xueli,
        $resume_type,
        $work_status,
        $resume_cate,
        $resume_location,
        $work_salary,
        $tel,
        $work_jingyan,
        $work_jingli,
        $edu_jingli,
        $describe,
        $video_url
    ); 
    foreach ($resumeList as $v){
        
        $v['work_jingli'] = str_replace("\r\n","",$v['work_jingli']);
        $v['work_jingli'] = str_replace("\n","",$v['work_jingli']);
        $v['work_jingli'] = str_replace("\r","",$v['work_jingli']);
        
        $v['edu_jingli'] = str_replace("\r\n","",$v['edu_jingli']);
        $v['edu_jingli'] = str_replace("\n","",$v['edu_jingli']);
        $v['edu_jingli'] = str_replace("\r","",$v['edu_jingli']);
        
        $v['describe'] = str_replace("\r\n","",$v['describe']);
        $v['describe'] = str_replace("\n","",$v['describe']);
        $v['describe'] = str_replace("\r","",$v['describe']);
        
        $lineData = array();
        $lineData[] = $v['name'];
        $lineData[] = $v['avatar'];
        $lineData[] = $v['age'];
        $lineData[] = $v['marital'];
        $lineData[] = $v['xueli'];
        $lineData[] = $v['type'];
        $lineData[] = $v['work_status'];
        $lineData[] = $v['resume_cate'];
        $lineData[] = $v['resume_location'];
        $lineData[] = $v['work_salary'];
        $lineData[] = $v['tel'].',';
        $lineData[] = $v['work_jingyan'];
        $lineData[] = $v['work_jingli'];
        $lineData[] = $v['edu_jingli'];
        $lineData[] = $v['describe'];
        $lineData[] = $v['video_url'];
        
        $listData[] = $lineData;
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=resumeExportRencai.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}