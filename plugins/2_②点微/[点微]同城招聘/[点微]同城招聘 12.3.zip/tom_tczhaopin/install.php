<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tczhaopin`;
CREATE TABLE `pre_tom_tczhaopin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `type` tinyint(11) DEFAULT '0',
  `cate_id` int(11) DEFAULT '0',
  `cate_child_id` int(11) DEFAULT '0',
  `jianzhi_cate_id` int(11) DEFAULT '0',
  `jianzhi_work_salary` int(11) DEFAULT '0',
  `jianzhi_work_salary_unit` int(11) DEFAULT '0',
  `jianzhi_jiesuan_fangshi` int(11) DEFAULT '0',
  `work_salary` int(11) DEFAULT '0',
  `work_salary_min` int(11) DEFAULT '0',
  `work_salary_max` int(11) DEFAULT '0',
  `renshu` int(11) DEFAULT '0',
  `work_welfare` varchar(255) DEFAULT NULL,
  `demand_sex` int(11) DEFAULT '0',
  `demand_ages` int(11) DEFAULT '0',
  `demand_xueli` int(11) DEFAULT '0',
  `demand_jingyan` int(11) DEFAULT '0',
  `demand_desc` text,
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `street_id` int(11) DEFAULT '0',
  `company_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `company_nature_id` int(11) DEFAULT '0',
  `company_industry_id` int(11) DEFAULT '0',
  `company_scale_id` int(11) DEFAULT '0',
  `company_introduce` text,
  `video_status` int(11) DEFAULT '0',
  `video_url` varchar(255) DEFAULT NULL,
  `video_pic` varchar(255) DEFAULT NULL,
  `expire_status` int(11) DEFAULT '3',
  `expire_time` int(11) unsigned DEFAULT '0',
  `top_status` int(11) DEFAULT '0',
  `top_time` int(11) unsigned DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `over_status` tinyint(4) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `auto_click_time` int(11) DEFAULT '0',
  `pay_status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `qunfa_status` int(11) DEFAULT '0',
  `refresh_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `search_text` text,
  `client_ip_port` varchar(255) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_pay_status` (`pay_status`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_top_status` (`top_status`),
  KEY `idx_refresh_time` (`refresh_time`),
  KEY `idx_cate_id` (`cate_id`),
  KEY `idx_cate_child_id` (`cate_child_id`),
  KEY `idx_area_id` (`area_id`),
  KEY `idx_street_id` (`street_id`),
  KEY `idx_type` (`type`),
  KEY `idx_demand_xueli` (`demand_xueli`),
  KEY `idx_work_salary` (`work_salary`),
  KEY `idx_demand_jingyan` (`demand_jingyan`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_history`;
CREATE TABLE `pre_tom_tczhaopin_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `resume_id` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_jianzhi_cate`;
CREATE TABLE `pre_tom_tczhaopin_jianzhi_cate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `is_hot` int(11) DEFAULT '0',
  `csort` int(11) DEFAULT '100',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_cate`;
CREATE TABLE `pre_tom_tczhaopin_cate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `is_hot` int(11) DEFAULT '0',
  `csort` int(11) DEFAULT '100',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_company`;
CREATE TABLE `pre_tom_tczhaopin_company` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `renzheng_company_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `num` int(11) DEFAULT '0',
  `show_status` tinyint(4) DEFAULT '0',
  `tuijian_status` tinyint(4) DEFAULT '0',
  `top_status` int(11) DEFAULT '0',
  `top_time` int(11) unsigned DEFAULT '0',
  `csort` int(11) DEFAULT '100',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_rencai`;
CREATE TABLE `pre_tom_tczhaopin_rencai` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `resume_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_dingyue`;
CREATE TABLE `pre_tom_tczhaopin_dingyue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `cate_id` int(11) DEFAULT '0',
  `cate_child_id` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_qunfa_log`;
CREATE TABLE `pre_tom_tczhaopin_qunfa_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tczhaopin_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_focuspic`;
CREATE TABLE `pre_tom_tczhaopin_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '1',
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_jubao`;
CREATE TABLE `pre_tom_tczhaopin_jubao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tczhaopin_id` int(11) DEFAULT '0',
  `contact_type` int(11) DEFAULT '0',
  `falsity` varchar(255) DEFAULT NULL,
  `illegality` varchar(255) DEFAULT NULL,
  `content` text,
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_jubao_photo`;
CREATE TABLE `pre_tom_tczhaopin_jubao_photo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jubao_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_order`;
CREATE TABLE `pre_tom_tczhaopin_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tczhaopin_id` int(11) DEFAULT '0',
  `resume_id` int(11) DEFAULT '0',
  `vip_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `meeting_id` int(11) DEFAULT '0',
  `meeting_company_id` int(11) DEFAULT '0',
  `type` tinyint(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `order_no` varchar(255) DEFAULT NULL,
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `pay_time` int(11) DEFAULT '0',
  `fabu_days` int(11) DEFAULT '0',
  `fabu_price` decimal(10,2) DEFAULT '0.00',
  `top_days` int(11) DEFAULT '0',
  `top_price` decimal(10,2) DEFAULT '0.00',
  `order_status` tinyint(4) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_photo`;
CREATE TABLE `pre_tom_tczhaopin_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tczhaopin_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `oss_picurl` varchar(255) DEFAULT NULL,
  `oss_status` int(11) DEFAULT '0',
  `qiniu_picurl` varchar(255) DEFAULT NULL,
  `qiniu_status` int(11) DEFAULT '0',
  `psort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tczhaopin_id` (`tczhaopin_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_resume`;
CREATE TABLE `pre_tom_tczhaopin_resume` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `type` tinyint(11) DEFAULT '1',
  `name` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `cate_id` int(11) DEFAULT '0',
  `cate_child_ids` varchar(255) DEFAULT NULL,
  `cate_child_str` varchar(255) DEFAULT NULL,
  `cate_child_search` varchar(255) DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `street_id` int(11) DEFAULT '0',
  `work_jingyan` int(11) DEFAULT '0',
  `work_salary` int(11) DEFAULT '0',
  `work_status` int(11) DEFAULT '0',
  `sex` int(11) DEFAULT '0',
  `marital` int(11) DEFAULT '0',
  `birth_year` int(11) DEFAULT '0',
  `xueli` int(11) DEFAULT '0',
  `tel` varchar(255) DEFAULT NULL,
  `work_jingli` text,
  `edu_jingli` text,
  `describe` text,
  `gongkai_status` int(11) DEFAULT '0',
  `video_status` int(11) DEFAULT '0',
  `video_url` varchar(255) DEFAULT NULL,
  `video_pic` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `top_status` int(11) DEFAULT '0',
  `top_time` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `deleted` tinyint(4) DEFAULT '0',
  `refresh_time` int(11) unsigned DEFAULT '0',
  `shenqing_num` int(11) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `auto_click_time` int(11) DEFAULT '0',
  `search_text` text,
  `client_ip_port` varchar(255) DEFAULT NULL,
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_gongkai_status` (`gongkai_status`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_cate_id` (`cate_id`),
  KEY `idx_area_id` (`area_id`),
  KEY `idx_street_id` (`street_id`),
  KEY `idx_sex` (`sex`),
  KEY `idx_xueli` (`xueli`),
  KEY `idx_work_jingyan` (`work_jingyan`),
  KEY `idx_top_status` (`top_status`),
  KEY `idx_refresh_time` (`refresh_time`),
  KEY `idx_cate_child_search` (`cate_child_search`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_shenqing`;
CREATE TABLE `pre_tom_tczhaopin_shenqing` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tczhaopin_id` int(11) DEFAULT '0',
  `resume_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_vip`;
CREATE TABLE `pre_tom_tczhaopin_vip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `days` int(11) DEFAULT '0',
  `max_num` int(11) DEFAULT '0',
  `auto_refresh` tinyint(4) DEFAULT '0',
  `fabu_num` int(11) DEFAULT '0',
  `resume_num` int(11) DEFAULT '0',
  `refresh_num` int(11) DEFAULT '0',
  `top_zhekou` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `market_price` decimal(10,2) DEFAULT '0.00',
  `beizu` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `tsort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_vip_code`;
CREATE TABLE `pre_tom_tczhaopin_vip_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vip_id` int(11) DEFAULT '0',
  `code` varchar(255) DEFAULT NULL,
  `use_status` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `use_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_user_vip`;
CREATE TABLE `pre_tom_tczhaopin_user_vip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `vip_id` int(11) DEFAULT '0',
  `expire_time` int(11) DEFAULT '0',
  `expire_status` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_log`;
CREATE TABLE `pre_tom_tczhaopin_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `resume_id` int(11) DEFAULT '0',
  `tczhaopin_id` int(11) DEFAULT '0',
  `deduct_type` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `today_time` int(11) DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_collect`;
CREATE TABLE `pre_tom_tczhaopin_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tczhaopin_id` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_resume_collect`;
CREATE TABLE `pre_tom_tczhaopin_resume_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `resume_id` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_meeting`;
CREATE TABLE `pre_tom_tczhaopin_meeting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '0',
  `open_pay` tinyint(4) DEFAULT '0',
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `zhaopin_list_type` tinyint(4) DEFAULT '1',
  `picurl` varchar(255) DEFAULT NULL,
  `theme_picurl` varchar(255) DEFAULT NULL,
  `theme_color` varchar(255) DEFAULT NULL,
  `organizer` varchar(255) DEFAULT NULL,
  `max_num` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `haibao_picurl` varchar(255) DEFAULT NULL,
  `qrcode_location` tinyint(4) DEFAULT '1',
  `canhui_txt` text,
  `content` text,
  `start_time` int(11) unsigned DEFAULT '0',
  `bmend_time` int(11) unsigned DEFAULT '0',
  `end_time` int(11) unsigned DEFAULT '0',
  `share_title` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `virtual_clicks` int(11) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `msort` int(11) DEFAULT '10',
  `open_search` tinyint(4) DEFAULT '0',
  `list_template` tinyint(4) DEFAULT '1',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_meeting_company`;
CREATE TABLE `pre_tom_tczhaopin_meeting_company` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meeting_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `tczhaopin_ids` text,
  `tczhaopin_num` int(11) DEFAULT '0',
  `is_recommend` tinyint(4) DEFAULT '0',
  `csort` int(11) DEFAULT '10',
  `status` tinyint(4) DEFAULT '0',
  `pay_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_common`;
CREATE TABLE `pre_tom_tczhaopin_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `clicks` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tczhaopin_mianshi`;
CREATE TABLE `pre_tom_tczhaopin_mianshi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `yaoqing_user_id` int(11) DEFAULT '0',
  `tczhaopin_id` int(11) DEFAULT '0',
  `resume_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `beizu` text,
  `status` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_popup`;
CREATE TABLE `pre_tom_tczhaopin_popup` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `site_ids` text,
    `link` varchar(255) DEFAULT NULL,
    `clicks` int(11) DEFAULT '0',
    `status` int(11) DEFAULT '0',
    `add_time` int(11) DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    `picurl` varchar(255) DEFAULT NULL,
    `show_num` int(11) unsigned DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE=MyISAM;
   
DROP TABLE IF EXISTS `pre_tom_tczhaopin_popup_log`;
CREATE TABLE `pre_tom_tczhaopin_popup_log` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `popup_id` int(11) DEFAULT '0',
    `user_id` int(11) DEFAULT '0',
    `num` int(11) DEFAULT '0',
    `log_time` int(11) DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_setting`;
CREATE TABLE `pre_tom_tczhaopin_setting` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `open_rz_back_vip` tinyint(4) DEFAULT '1',
    `open_resume_match` tinyint(4) DEFAULT '1',
    `resume_match_cate_child` tinyint(4) DEFAULT '0',
    `resume_match_area` tinyint(4) DEFAULT '0',
    `zhaopinlist_top_bgcolor` varchar(255) DEFAULT '#fff8eb',
    `zhaopininfo_tel_btncolor` varchar(255) DEFAULT '#23B4DC',
    `free_fabu_resume_num` int(11) DEFAULT '0',
    `everyday_shenqing_num` int(11) DEFAULT '0',
    `open_zhaopin_copy` tinyint(4) DEFAULT '0',
    `zhaopin_copy_template` text,
    `zhaopin_copy_shorturl` varchar(255) DEFAULT NULL,
    `open_zhaopin_match` tinyint(4) DEFAULT '1',
    `zhaopin_match_cate_child` tinyint(4) DEFAULT '0',
    `zhaopin_match_area` tinyint(4) DEFAULT '0',
    `fabu_top_style` tinyint(4) DEFAULT '2',
    `index_diy_html` mediumtext,
    `open_must_zhaopin_quyu` tinyint(4) DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tczhaopin_wxqun`;
CREATE TABLE `pre_tom_tczhaopin_wxqun` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `site_id` int(11) DEFAULT '0',
    `name` varchar(255) DEFAULT NULL,
    `logo` varchar(255) DEFAULT NULL,
    `qrcode` varchar(255) DEFAULT NULL,
    `desc` varchar(255) DEFAULT NULL,
    `tishi_msg` varchar(255) DEFAULT NULL,
    `status` tinyint(4) DEFAULT '0',
    `add_time` int(11) unsigned DEFAULT '0',
    `part1` varchar(255) DEFAULT NULL,
    `part2` varchar(255) DEFAULT NULL,
    `part3` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;