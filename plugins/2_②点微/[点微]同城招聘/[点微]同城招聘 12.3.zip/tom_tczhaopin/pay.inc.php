<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$tczhaopinConfig    = $_G['cache']['plugin']['tom_tczhaopin'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

$zhaopinSetting = C::t('#tom_tczhaopin#tom_tczhaopin_setting')->fetch_by_id(1);
if($zhaopinSetting && $zhaopinSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin_setting')->insert($insertData);
    $zhaopinSetting = C::t('#tom_tczhaopin#tom_tczhaopin_setting')->fetch_by_id(1);
}

## tcrenzheng start
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')){
    $tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
    if($tcrenzhengConfig['open_tcrenzheng'] == 1){
        $__ShowTcrenzheng = 1;
    }
}
## tcrenzheng end
## xiaofenlei start
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')){
    $xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
    $__ShowXiaofenlei = 1;
}
## xiaofenlei end

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.utf.php';
}
$welfareArray = array();
$welfare_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['welfare_list']); 
$welfare_list_str = str_replace("\n","{n}",$welfare_list_str);
$welfare_list_arr = explode("{n}", $welfare_list_str);
if(is_array($welfare_list_arr) && !empty($welfare_list_arr)){
    foreach ($welfare_list_arr as $key => $value){
        $welfare_list_item = explode("|", $value);
        $welfare_list_item_id = intval($welfare_list_item[0]);
        $welfare_list_item_name = trim($welfare_list_item[1]);
        if($welfare_list_item_id > 0 && !empty($welfare_list_item_name)){
            $welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
        }
    }
}

$agesArray = array();
$ages_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['zhaopin_ages_list']); 
$ages_list_str = str_replace("\n","{n}",$ages_list_str);
$ages_list_arr = explode("{n}", $ages_list_str);
if(is_array($ages_list_arr) && !empty($ages_list_arr)){
    foreach ($ages_list_arr as $key => $value){
        $ages_list_item = explode("|", $value);
        $ages_list_item_id = intval($ages_list_item[0]);
        $ages_list_item_name = trim($ages_list_item[1]);
        if($ages_list_item_id > 0 && !empty($ages_list_item_name)){
            $agesArray[$ages_list_item_id] = $ages_list_item_name;
        }
    }
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/class/function.core.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

$act = isset($_GET['act'])? addslashes($_GET['act']):"zhaopin";

if($act == "zhaopin" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $title                      = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title                      = dhtmlspecialchars($title);
    $type                       = intval($_GET['type'])>0? intval($_GET['type']):0;
    $cate_id                    = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
    $cate_child_id              = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
    $jianzhi_cate_id            = intval($_GET['jianzhi_cate_id'])>0? intval($_GET['jianzhi_cate_id']):0;
    $work_salary                = intval($_GET['work_salary'])>0? intval($_GET['work_salary']):0;
    $work_salary_min            = intval($_GET['work_salary_min'])>0? intval($_GET['work_salary_min']):0;
    $work_salary_max            = intval($_GET['work_salary_max'])>0? intval($_GET['work_salary_max']):0;
    $jianzhi_work_salary        = intval($_GET['jianzhi_work_salary'])>0? intval($_GET['jianzhi_work_salary']):0;
    $jianzhi_work_salary_unit   = intval($_GET['jianzhi_work_salary_unit'])>0? intval($_GET['jianzhi_work_salary_unit']):0;
    $jianzhi_jiesuan_fangshi    = intval($_GET['jianzhi_jiesuan_fangshi'])>0? intval($_GET['jianzhi_jiesuan_fangshi']):0;
    $renshu                     = intval($_GET['renshu'])>0? intval($_GET['renshu']):0;
    $company_name               = isset($_GET['company_name'])? addslashes($_GET['company_name']):'';
    $company_name               = dhtmlspecialchars($company_name);
    $city_id                    = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id                    = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id                  = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $address                    = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address                    = dhtmlspecialchars($address);
    $latitude                   = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude                  = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $xm                         = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $xm                         = dhtmlspecialchars($xm);
    $tel                        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                        = dhtmlspecialchars($tel);
    $demand_sex                 = intval($_GET['demand_sex'])>0? intval($_GET['demand_sex']):0;
    $demand_ages                = intval($_GET['demand_ages'])>0? intval($_GET['demand_ages']):0;
    $demand_xueli               = intval($_GET['demand_xueli'])>0? intval($_GET['demand_xueli']):0;
    $demand_jingyan             = intval($_GET['demand_jingyan'])>0? intval($_GET['demand_jingyan']):0;
    $demand_desc                = isset($_GET['demand_desc'])? addslashes($_GET['demand_desc']):'';
    $demand_desc                = dhtmlspecialchars($demand_desc);
    $user_id                    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $fabu_days                  = intval($_GET['fabu_days'])>0? intval($_GET['fabu_days']):0;
    $top_days                   = intval($_GET['top_days'])>0? intval($_GET['top_days']):0;
    $video_url                  = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_url                  = dhtmlspecialchars($video_url);
    $video_pic                  = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic                  = dhtmlspecialchars($video_pic);
    
    $workWelfareArr = array();
    if(is_array($_GET['work_welfare']) && !empty($_GET['work_welfare'])){
        foreach($_GET['work_welfare'] as $key => $value){
            $workWelfareArr[$key] = intval($value);
        }
    }
    $workWelfareIds = '-'.implode('-', $workWelfareArr).'-';
    
    $photolist = array();
    if(is_array($_GET['photolist']) && !empty($_GET['photolist'])){
        foreach($_GET['photolist'] as $key => $value){
            if(!empty($value)){
                $photolist[] = addslashes($value);
            }
        }
    }
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    if(!$userInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
    if(!empty($__CommonInfo['forbid_word'])){
        $forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
        $forbid_word = str_replace(array("\\*"), array('.*'), $forbid_word);
        $forbid_word = '.*('.$forbid_word.').*';
        $forbid_word = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word).')$/i';
        $contentTmpTmp = $title.$company_name.$demand_desc;
        $contentTmpTmp = str_replace("\r\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\r","",$contentTmpTmp);
        if(@preg_match($forbid_word, $contentTmpTmp,$matches)) {
            $i = count($matches)-1;
            $word = '';
            if(isset($matches[$i]) && !empty($matches[$i])){
                $word = diconv($matches[$i],CHARSET,'utf-8');
            }
            if($tongchengConfig['safe_words_do'] == 1){
                $tczhaopinConfig['zhaopin_must_shenhe'] = 1;
            }else{
                $outArr = array(
                    'status'=> 505,
                    'word'=> $word,
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    if($__ShowXiaofenlei == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php';
        if($xiaofenleiConfig['open_msgseccheck'] == 1){
            @$s_m_r = wx_msgSecCheck($title.$company_name.$demand_desc);
            if($s_m_r['code'] == 100){
                $tczhaopinConfig['zhaopin_must_shenhe'] = 1;
            }
            if($s_m_r['code'] == 500){
                $outArr = array(
                    'status'=> 505,
                    'word'=> $s_m_r['word'],
                );
                echo json_encode($outArr); exit;
            }
        }
        $imgseccheck_listArr = unserialize($xiaofenleiConfig['imgseccheck_list']);
        if(array_search('2',$imgseccheck_listArr) !== false && $xiaofenleiConfig['open_imgseccheck'] == 1){
            if(is_array($photolist) && !empty($photolist)){
                foreach ($photolist as $kk => $vv){
                    if(!preg_match('/^http/', $vv['picurl']) ){
                        if(strpos($vv['picurl'], 'source/plugin/tom_') === false){    
                            $check_picurl_tmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                        }else{
                            $check_picurl_tmp = $_G['siteurl'].$vv['picurl'];
                        }
                    }else{
                        $check_picurl_tmp = $vv['picurl'];
                    }
                    @$s_i_r = wx_imgSecCheck($check_picurl_tmp);
                    if($s_i_r['code'] == 500){
                        $tczhaopinConfig['zhaopin_must_shenhe'] = 1;
                    }
                }
            }
        }
    }
    
    $renzhengStatus = $companyRenzhengStatus = 0;
    $renzhengInfo = array();
    $renzhengInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$user_id} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($renzhengInfoTmp) && !empty($renzhengInfoTmp[0])){
        $renzhengInfo = $renzhengInfoTmp[0];
        $companyRenzhengStatus = 1;
        $renzhengStatus = 1;
    }
    if($renzhengStatus == 0 && $tczhaopinConfig['open_shenhe_status_2_fabu'] == 1){
        $renzheng2InfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$user_id} AND shenhe_status = 2 ", 'ORDER BY id DESC', 0, 1);
        if(is_array($renzheng2InfoTmp) && !empty($renzheng2InfoTmp[0])){
            $renzhengStatus = 2;
        }
    }
    
    if($tczhaopinConfig['open_must_renzheng'] == 1){
        if($renzhengStatus == 0){
            if($tczhaopinConfig['close_personal_renzheng'] == 0){
                $personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_user_id($user_id);
                if(is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1){
                    $renzhengStatus = 1;
                }
                if(is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 2 && $tczhaopinConfig['open_shenhe_status_2_fabu'] == 1){
                    $renzhengStatus = 2;
                }
            }
            
            if($renzhengStatus == 0){
                $outArr = array(
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    
    $vipInfo = array();
    $userVipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($user_id);
    if($userVipInfoTmp['vip_id'] > 0 && $userVipInfoTmp['expire_status'] == 1 && $userVipInfoTmp['expire_time'] > TIMESTAMP){
        $vipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfoTmp['vip_id']);
        if($vipInfoTmp && $vipInfoTmp > 0){
            $vipInfo = $vipInfoTmp;
        }
    }
    
    $firstFabuDaysStatus = $fabu_pay_price = 0;
    if($fabu_days > 0){
        $zhaopin_show_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['shoufei_zhaopin_price_list']); 
        $zhaopin_show_list_str = str_replace("\n","{n}",$zhaopin_show_list_str);
        $zhaopin_show_list_arr = explode("{n}", $zhaopin_show_list_str);
        $i = 1;
        if(is_array($zhaopin_show_list_arr) && !empty($zhaopin_show_list_arr)){
            foreach ($zhaopin_show_list_arr as $key => $value){
                $zhaopinShowInfoTmp = array();
                $zhaopinShowInfoTmp = explode("|", $value);
                
                if($zhaopinShowInfoTmp[0] == $fabu_days){
                    $fabu_pay_price = $zhaopinShowInfoTmp[1];
                    
                    if($i == 1){
                        $firstFabuDaysStatus = 1;
                    }
                }
                $i++;
            }
        }
        
        if($fabu_pay_price > 0){}else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($top_days > 0){
        $top_pay_price = $top_pay_score = 0;
        $zhaopin_top_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['zhaopin_top_list']); 
        $zhaopin_top_list_str = str_replace("\n","{n}",$zhaopin_top_list_str);
        $zhaopin_top_list_arr = explode("{n}", $zhaopin_top_list_str);
        if(is_array($zhaopin_top_list_arr) && !empty($zhaopin_top_list_arr)){
            foreach ($zhaopin_top_list_arr as $key => $value){
                $zhaopinTopInfoTmp = array();
                $zhaopinTopInfoTmp = explode("|", $value);
                
                if($zhaopinTopInfoTmp[0] == $top_days){
                    $top_pay_price = $zhaopinTopInfoTmp[1];
                    
                    if($vipInfo && $vipInfo['id'] > 0 && $vipInfo['top_zhekou'] > 0){
                        $top_zhekou = $vipInfo['top_zhekou'] / 100;
                        $top_pay_price = $top_pay_price * $top_zhekou;
                        $top_pay_price = round($top_pay_price, 2);
                        if($top_pay_price <= 0){
                            $top_pay_price = 0.01;
                        }
                    }

                    if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                        $top_pay_score = ceil($top_pay_price * $tongchengConfig['pay_score_yuan']);
                    }
                }
            }
        }
        
        if($top_pay_price > 0){}else{
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($companyRenzhengStatus == 1){
        $company_name = $renzhengInfo['name'];
    }
    
    $search_text = '';
    if($type == 1){
        $cateInfo =  C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($cate_id);
        $cateChildInfo =  C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($cate_child_id);
        $search_text = $title.'-'.$cateInfo['name'].'-'.$cateChildInfo['name'].'-'.$company_name;
    }else if($type == 2){
        $jianzhiCateInfo =  C::t("#tom_tczhaopin#tom_tczhaopin_jianzhi_cate")->fetch_by_id($jianzhi_cate_id);
        $search_text = $title.'-'.$jianzhiCateInfo['name'].'-'.$company_name;
    }
    
    $fabuPayStatus = 1;
    if($fabuPayStatus == 1){
        $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$userInfo['id']} AND type = 1 AND deduct_type = 1 ");
        if($companyRenzhengStatus == 1){
            $freeFabuNum = $tczhaopinConfig['company_free_fabu_num'];
        }else{
            $freeFabuNum = $tczhaopinConfig['personal_free_fabu_num'];
        }
        if($freeFabuNum > $userLogCount && $firstFabuDaysStatus == 1){
            $fabuPayStatus = 2;
        }
    }

    if($fabuPayStatus == 1){
        if($vipInfo && $vipInfo['id'] > 0){
            $vipFabuNum = $vipInfo['fabu_num'];
            $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$userInfo['id']} AND expire_status = 3");
            if($vipFabuNum > $userVipLogCount){
                $fabuPayStatus = 3;
            }
        }
    }

    if($fabuPayStatus == 1 && $tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
        $zhaopinScorePayNum = ceil($fabu_pay_price * $tongchengConfig['pay_score_yuan']);
        if($userInfo['score'] > $zhaopinScorePayNum){
            $fabuPayStatus = 4;
        }
    }

    $topPayStatus = 0;
    if($top_days > 0){
        $topPayStatus = 1;
        
        if($fabuPayStatus == 4){
            $all_pay_score = $top_pay_score + $zhaopinScorePayNum;
        }else{
            $all_pay_score = $top_pay_score;
        }
        if($userInfo['score'] > $all_pay_score && $top_pay_score > 0){
            $topPayStatus = 2;
        }
    }

    $pay_price = 0;
    if($fabuPayStatus == 1){
        $pay_price = $fabu_pay_price;
    }
    if($topPayStatus == 1){
        $pay_price = $pay_price + $top_pay_price;
    }
    
    $pay_score = 0;
    if($fabuPayStatus == 4){
        $pay_score = $zhaopinScorePayNum;
    }
    if($topPayStatus == 2){
        $pay_score = $pay_score + $top_pay_score;
    }

    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($userInfo['id']);
    
    $insertData = array();
    $insertData['site_id']              = $site_id;
    $insertData['company_id']           = $companyInfo['id'];
    $insertData['user_id']              = $userInfo['id'];
    $insertData['title']                = $title;
    $insertData['type']                 = $type;
    if($type == 1){
        $insertData['cate_id']              = $cate_id;
        $insertData['cate_child_id']        = $cate_child_id;
    }else if($type == 2){
        $insertData['jianzhi_cate_id']      = $jianzhi_cate_id;
    }
    if($type == 1){
        $insertData['work_salary']          = $work_salary;
        $insertData['work_salary_min']      = $work_salary_min;
        $insertData['work_salary_max']      = $work_salary_max;
        $insertData['work_welfare']         = $workWelfareIds;
    }else if($type == 2){
        $insertData['jianzhi_work_salary']       = $jianzhi_work_salary;
        $insertData['jianzhi_work_salary_unit']  = $jianzhi_work_salary_unit;
        $insertData['jianzhi_jiesuan_fangshi']   = $jianzhi_jiesuan_fangshi;
    }
    $insertData['renshu']               = $renshu;
    $insertData['demand_sex']           = $demand_sex;
    $insertData['demand_ages']          = $demand_ages;
    $insertData['demand_xueli']         = $demand_xueli;
    $insertData['demand_jingyan']       = $demand_jingyan;
    $insertData['demand_desc']          = $demand_desc;
    $insertData['city_id']              = $city_id;
    $insertData['area_id']              = $area_id;
    $insertData['street_id']            = $street_id;
    $insertData['address']              = $address;
    $insertData['latitude']             = $latitude;
    $insertData['longitude']            = $longitude;
    $insertData['xm']                   = $xm;
    $insertData['tel']                  = $tel;
    if($companyRenzhengStatus == 1){
        $insertData['company_name']            = $renzhengInfo['name'];
        $insertData['company_nature_id']       = $renzhengInfo['nature_id'];
        $insertData['company_industry_id']     = $renzhengInfo['industry_id'];
        $insertData['company_scale_id']        = $renzhengInfo['scale_id'];
    }else{
        $insertData['company_name']            = $company_name;
    }
    if(!empty($video_url)){
        $insertData['video_status']            = 1;
        $insertData['video_url']               = $video_url;
        $insertData['video_pic']               = $video_pic;
    }
    if($tczhaopinConfig['zhaopin_must_shenhe'] == 1){
        $insertData['shenhe_status']    = 2;
        $insertData['status']           = 1;
    }else{
        $insertData['shenhe_status']    = 1;
        $insertData['status']           = 1;
    }
    
    $insertData['expire_status']    = 2;
    $insertData['status']           = 0;
    
    if($fabuPayStatus == 1){
        $insertData['pay_status']       = 1;
    }else{
        $insertData['pay_status']       = 0;
    }
    $insertData['search_text']          = $search_text;
    $insertData['client_ip_port']       = $_G['clientip'].'|'.$_SERVER['REMOTE_PORT'];
    $insertData['refresh_time']         = TIMESTAMP;
    $insertData['add_time']             = TIMESTAMP;
    if(C::t("#tom_tczhaopin#tom_tczhaopin")->insert($insertData)){
        $tczhaopin_id = C::t("#tom_tczhaopin#tom_tczhaopin")->insert_id();
        
        if(is_array($photolist) && !empty($photolist)){
            foreach($photolist as $key => $value){
                $insertData = array();
                $insertData['tczhaopin_id']     = $tczhaopin_id;
                $insertData['picurl']           = $value;
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tczhaopin#tom_tczhaopin_photo")->insert($insertData);
            }
        }
        
        if($fabuPayStatus == 2){
            
            $insertData = array();
            $insertData['user_id']              = $userInfo['id'];
            $insertData['tczhaopin_id']         = $tczhaopin_id;
            $insertData['deduct_type']          = 1;
            $insertData['type']                 = 1;
            $insertData['today_time']           = $nowDayTime;
            $insertData['log_time']             = TIMESTAMP;
            C::t("#tom_tczhaopin#tom_tczhaopin_log")->insert($insertData);
            
            $fabu_time = $fabu_days * 86400 + TIMESTAMP;
            
            $updateData = array();
            $updateData['expire_status']        = 1;
            $updateData['expire_time']          = $fabu_time;
            $updateData['status']               = 1;
            C::t("#tom_tczhaopin#tom_tczhaopin")->update($tczhaopin_id, $updateData);
        }
        
        if($fabuPayStatus == 3){
            
            $insertData = array();
            $insertData['user_id']              = $userInfo['id'];
            $insertData['tczhaopin_id']         = $tczhaopin_id;
            $insertData['deduct_type']          = 2;
            $insertData['type']                 = 1;
            $insertData['today_time']           = $nowDayTime;
            $insertData['log_time']             = TIMESTAMP;
            C::t("#tom_tczhaopin#tom_tczhaopin_log")->insert($insertData);
            
            $updateData = array();
            $updateData['expire_status']    = 3;
            $updateData['status']           = 1;
            C::t("#tom_tczhaopin#tom_tczhaopin")->update($tczhaopin_id, $updateData);
        }
        
        if($pay_score > 0){
            
            $updateData = array();
            $updateData['score'] = $userInfo['score'] - $pay_score;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
            
            if($fabuPayStatus == 4){
                $fabu_time = $fabu_days * 86400 + TIMESTAMP;
            
                $updateData = array();
                $updateData['expire_status']        = 1;
                $updateData['expire_time']          = $fabu_time;
                $updateData['status']               = 1;
                C::t("#tom_tczhaopin#tom_tczhaopin")->update($tczhaopin_id, $updateData);
            }
            
            if($topPayStatus == 2){
                $top_time = $top_days * 86400 + TIMESTAMP;

                $updateData = array();
                $updateData['top_status']   = 1;
                $updateData['top_time']     = $top_time;
                C::t('#tom_tczhaopin#tom_tczhaopin')->update($tczhaopin_id,$updateData);
            }
            
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['score_value']      = $pay_score;
            $insertData['old_value']        = $userInfo['score'];
            $insertData['log_type']         = 44;
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        }
        
        if($pay_price > 0){
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'status'=> 301,
                );
                echo json_encode($outArr); exit;
            }

            $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['tczhaopin_id']     = $tczhaopin_id;
            $insertData['type']             = 1;
            $insertData['user_id']          = $userInfo['id'];
            $insertData['openid']           = $userInfo['openid'];
            $insertData['order_no']         = $order_no;
            if($fabuPayStatus == 1){
                $insertData['fabu_days']      = $fabu_days;
                $insertData['fabu_price']     = $fabu_pay_price;
            }
            if($topPayStatus == 1){
                $insertData['top_days']       = $top_days;
                $insertData['top_price']      = $top_pay_price;
            }
            $insertData['pay_price']        = $pay_price;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
                $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

                $insertData = array();
                $insertData['plugin_id']       = 'tom_tczhaopin';          
                $insertData['order_no']        = $order_no;                 
                $insertData['goods_id']        = $order_id;         
                $insertData['goods_name']      = $title;
                $insertData['goods_beizu']     = '';
                $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$tczhaopin_id;
                $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=myzhaopinlist';
                $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist"; 
                $insertData['allow_alipay']    = 1;
                $insertData['pay_price']       = $pay_price;
                $insertData['order_status']    = 1;
                $insertData['add_time']        = TIMESTAMP;
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    $outArr = array(
                        'status'        => 200,
                        'pay_status'    => 1,
                        'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                    );
                    echo json_encode($outArr); exit;
                }else{
                    $outArr = array(
                        'status'=> 306,
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
        }else{
            update_zhaopin_tongcheng($tczhaopin_id);
            update_company_status($companyInfo);
            if(!empty($tongchengConfig['template_id']) && $tczhaopinConfig['zhaopin_must_shenhe'] == 1){
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
                $weixinClass = new weixinClass($appid,$appsecret);

                $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($manageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_fabuzhaopin_shenhe_msg'),
                        'keyword1'      => $tczhaopinConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }

                $zpmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinConfig['zpmanage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($zpmanageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_fabuzhaopin_shenhe_msg'),
                        'keyword1'      => $tczhaopinConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($zpmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }
            $outArr = array(
                'status'=> 200,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }

}else if($act == "resume" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $avatar             = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $type               = intval($_GET['type'])>0? intval($_GET['type']):1;
    $cate_id            = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
    $cate_child_ids     = isset($_GET['cate_child_ids'])? addslashes($_GET['cate_child_ids']):'';
    $cate_child_str     = isset($_GET['cate_child_str'])? addslashes($_GET['cate_child_str']):'';
    $city_id            = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $work_jingyan       = intval($_GET['work_jingyan'])>0? intval($_GET['work_jingyan']):0;
    $work_salary        = intval($_GET['work_salary'])>0? intval($_GET['work_salary']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name               = dhtmlspecialchars($name);
    $sex                = intval($_GET['sex'])>0? intval($_GET['sex']):0;
    $marital            = intval($_GET['marital'])>0? intval($_GET['marital']):0;
    $birth_year         = intval($_GET['birth_year'])>0? intval($_GET['birth_year']):0;
    $xueli              = intval($_GET['xueli'])>0? intval($_GET['xueli']):0;
    $work_status        = intval($_GET['work_status'])>0? intval($_GET['work_status']):0;
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                = dhtmlspecialchars($tel);
    $gongkai_status     = intval($_GET['gongkai_status'])>0? intval($_GET['gongkai_status']):0;
    $work_jingli        = isset($_GET['work_jingli'])? addslashes($_GET['work_jingli']):'';
    $work_jingli        = dhtmlspecialchars($work_jingli);
    $edu_jingli         = isset($_GET['edu_jingli'])? addslashes($_GET['edu_jingli']):'';
    $edu_jingli         = dhtmlspecialchars($edu_jingli);
    $describe           = isset($_GET['describe'])? addslashes($_GET['describe']):'';
    $describe           = dhtmlspecialchars($describe);
    $user_id            = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $top_days           = intval($_GET['top_days'])>0? intval($_GET['top_days']):0;
    $video_url          = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_url          = dhtmlspecialchars($video_url);
    $video_pic          = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic          = dhtmlspecialchars($video_pic);
    
    $shenqing_tczhaopin_id = intval($_GET['shenqing_tczhaopin_id'])>0 ? intval($_GET['shenqing_tczhaopin_id']):0;

    if($user_id > 0 && $user_id == $__UserInfo['id']){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $myResumeCount = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count(" AND user_id={$user_id} ");
    if($zhaopinSetting['free_fabu_resume_num'] > 0 && $myResumeCount >= $zhaopinSetting['free_fabu_resume_num']){
        $outArr = array(
            'status'=> 501,
        );
        echo json_encode($outArr); exit;
    }
    
    if($top_days > 0){

        $top_pay_price = $top_pay_score = 0;
        $top_pay_price_msg = '';
        $resume_top_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['resume_top_list']); 
        $resume_top_list_str = str_replace("\n","{n}",$resume_top_list_str);
        $resume_top_list_arr = explode("{n}", $resume_top_list_str);
        if(is_array($resume_top_list_arr) && !empty($resume_top_list_arr)){
            foreach ($resume_top_list_arr as $key => $value){
                $resumeTopInfoTmp = array();
                $resumeTopInfoTmp = explode("|", $value);
                if($resumeTopInfoTmp[0] == $top_days){
                    $top_pay_price = $resumeTopInfoTmp[1];
                    $top_pay_price_msg = $resumeTopInfoTmp[2];

                    if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                        $top_pay_score = ceil($top_pay_price * $tongchengConfig['pay_score_yuan']);
                    }
                }
            }
        }
        
        if($top_pay_price > 0){ }else{
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }
            
    }
    
    $cateInfo =  C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($cate_id);
    
    $cate_child_id_arr = explode(',', $cate_child_ids);
    $cate_child_search = '-'.implode('-', $cate_child_id_arr).'-';
    
    $search_text = $cateInfo['name'].'-'.$cate_child_str.'-'.$name.'-'.$work_jingli;
    
    $insertData = array();
    $insertData['site_id']              = $site_id;
    $insertData['user_id']              = $user_id;
    $insertData['name']                 = $name;
    $insertData['type']                 = $type;
    $insertData['avatar']               = $avatar;
    $insertData['cate_id']              = $cate_id;
    $insertData['cate_child_ids']       = $cate_child_ids;
    if($tczhaopinConfig['open_resume_cate_child'] == 1){
        $insertData['cate_child_str']       = $cate_child_str;
    }else{
        $insertData['cate_child_str']       = $cateInfo['name'];
    }
    $insertData['cate_child_search']    = $cate_child_search;
    $insertData['city_id']              = $city_id;
    $insertData['area_id']              = $area_id;
    $insertData['street_id']            = $street_id;
    $insertData['work_jingyan']         = $work_jingyan;
    $insertData['work_salary']          = $work_salary;
    $insertData['sex']                  = $sex;
    $insertData['marital']              = $marital;
    $insertData['birth_year']           = $birth_year;
    $insertData['xueli']                = $xueli;
    $insertData['work_status']          = $work_status;
    $insertData['tel']                  = $tel;
    $insertData['gongkai_status']       = $gongkai_status;
    $insertData['work_jingli']          = $work_jingli;
    $insertData['edu_jingli']           = $edu_jingli;
    $insertData['describe']             = $describe;
    if(!empty($video_url)){
        $insertData['video_status']         = 1;
        $insertData['video_url']            = $video_url;
        $insertData['video_pic']            = $video_pic;
    }
    if($tczhaopinConfig['resume_must_shenhe'] == 1){
        $insertData['shenhe_status']    = 2;
        $insertData['status']           = 1;
    }else{
        $insertData['shenhe_status']    = 1;
        $insertData['status']           = 1;
    }
    $insertData['search_text']          = $search_text;
    $insertData['client_ip_port']       = $_G['clientip'].'|'.$_SERVER['REMOTE_PORT'];
    $insertData['refresh_time']         = TIMESTAMP;
    $insertData['add_time']             = TIMESTAMP;
    if(C::t('#tom_tczhaopin#tom_tczhaopin_resume')->insert($insertData)){
        $resume_id = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->insert_id();
        
        if($top_days > 0){
            
            $resumeInfo = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_by_id($resume_id);
            $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($resumeInfo['user_id']);
        
            if($userInfo['score'] >= $top_pay_score && $top_pay_score > 0){  
                $pay_score = $top_pay_score;
                
                $updateData = array();
                $updateData['score'] = $userInfo['score'] - $pay_score;
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

                $insertData = array();
                $insertData['user_id']          = $userInfo['id'];
                $insertData['score_value']      = $pay_score;
                $insertData['old_value']        = $userInfo['score'];
                $insertData['log_type']         = 45;
                $insertData['log_time']         = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);

                $top_time = $top_days * 86400 + TIMESTAMP;

                $updateData = array();
                $updateData['top_status']   = 1;
                $updateData['top_time']     = $top_time;
                C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resume_id,$updateData);
                
            }else{
                $pay_price = $top_pay_price;
                
                if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                    $outArr = array(
                        'status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }

                $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

                $insertData = array();
                $insertData['site_id']          = $site_id;
                $insertData['resume_id']        = $resume_id;
                $insertData['type']             = 4;
                $insertData['user_id']          = $userInfo['id'];
                $insertData['openid']           = $userInfo['openid'];
                $insertData['order_no']         = $order_no;
                $insertData['pay_price']        = $pay_price;
                $insertData['top_days']         = $top_days;
                $insertData['top_price']        = $top_pay_price;
                $insertData['order_status']     = 1;
                $insertData['order_time']       = TIMESTAMP;
                if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
                    $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

                    $insertData = array();
                    $insertData['plugin_id']       = 'tom_tczhaopin';          
                    $insertData['order_no']        = $order_no;
                    $insertData['goods_id']        = $order_id;         
                    $insertData['goods_name']      = lang('plugin/tom_tczhaopin', 'fabu_resume_top');
                    $insertData['goods_beizu']     = lang('plugin/tom_tczhaopin','resume_top').$top_pay_price_msg;
                    $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=resumeinfo&resume_id='.$resume_id;
                    if($shenqing_tczhaopin_id > 0){
                        $insertData['succ_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=zhaopininfo&tczhaopin_id={$shenqing_tczhaopin_id}";
                    }else{
                        $insertData['succ_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myresumelist";
                    }
                    $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myresumelist";
                    $insertData['allow_alipay']    = 1;
                    $insertData['pay_price']       = $pay_price;
                    $insertData['order_status']    = 1;
                    $insertData['add_time']        = TIMESTAMP;
                    if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                        $outArr = array(
                            'status'        => 200,
                            'pay_status'    => 1,
                            'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                        );
                        echo json_encode($outArr); exit;
                    }else{
                        $outArr = array(
                            'status'=> 306,
                        );
                        echo json_encode($outArr); exit;
                    }
                }else{
                    $outArr = array(
                        'status'=> 305,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        
        if(!empty($tongchengConfig['template_id']) && $tczhaopinConfig['resume_must_shenhe'] == 1){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
            $weixinClass = new weixinClass($appid,$appsecret);
                
            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerResumeList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_faburesume_shenhe_msg'),
                    'keyword1'      => $tczhaopinConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
            
            $zpmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinConfig['zpmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($zpmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerResumeList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_faburesume_shenhe_msg'),
                    'keyword1'      => $tczhaopinConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($zpmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        
        update_resume_tongcheng($resume_id);
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }

}else if($act == "zhaopin_pay" && submitcheck('tczhaopin_id')){

    $outArr = array(
        'status'=> 1,
    );
    
    $tczhaopin_id  = intval($_GET['tczhaopin_id'])>0 ? intval($_GET['tczhaopin_id']):0;
    $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($tczhaopin_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinInfo['user_id']);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($tczhaopinInfo) && $tczhaopinInfo['pay_status'] == 1){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $orderInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_order")->fetch_all_list(" AND tczhaopin_id = {$tczhaopin_id} AND type = 1 ", 'ORDER BY id DESC', 0, 1);
    $orderInfo = array();
    if(is_array($orderInfoTmp) && !empty($orderInfoTmp[0]) && $orderInfoTmp[0]['order_status'] == 1 && $orderInfoTmp[0]['fabu_days'] > 0){
        $orderInfo = $orderInfoTmp[0];
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    $pay_price = $orderInfo['pay_price'];
    if($pay_price <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['tczhaopin_id']     = $tczhaopin_id;
    $insertData['type']             = 1;
    $insertData['user_id']          = $userInfo['id'];
    $insertData['openid']           = $userInfo['openid'];
    $insertData['order_no']         = $order_no;
    $insertData['fabu_days']        = $orderInfo['fabu_days'];
    $insertData['fabu_price']       = $orderInfo['fabu_price'];
    $insertData['top_days']         = $orderInfo['top_days'];
    $insertData['top_price']        = $orderInfo['top_price'];
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
        $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tczhaopin';          
        $insertData['order_no']        = $order_no;                 
        $insertData['goods_id']        = $order_id;         
        $insertData['goods_name']      = $tczhaopinInfo['title'];
        $insertData['goods_beizu']     = '';
        $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$tczhaopin_id;
        $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=myzhaopinlist';
        $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist"; 
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $pay_price;
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'        => 200,
                'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }

    
}else if($act == "zhaopin_xufei_pay" && submitcheck('tczhaopin_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $tczhaopin_id   = intval($_GET['tczhaopin_id'])>0 ? intval($_GET['tczhaopin_id']):0;
    $fabu_days      = intval($_GET['fabu_days'])>0 ? intval($_GET['fabu_days']):0;
    
    $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($tczhaopin_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinInfo['user_id']);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    $fabuPayStatus = 1;
    $shenyuVipFabuNum = 0;
    $userVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($userInfo['id']);
    if($userVipInfo['vip_id'] > 0 && $userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
        $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
        $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$userInfo['id']} AND expire_status = 3 ");
        if($vipInfo['fabu_num'] > $userVipLogCount){
            $shenyuVipFabuNum = $vipInfo['fabu_num'] - $userVipLogCount;
            $fabuPayStatus = 2;
        }
    }
    
    if($shenyuVipFabuNum == 0){
        $fabu_pay_price = $fabu_pay_score = 0;
        $fabu_pay_price_msg = '';
        $zhaopin_show_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['shoufei_zhaopin_price_list']); 
        $zhaopin_show_list_str = str_replace("\n","{n}",$zhaopin_show_list_str);
        $zhaopin_show_list_arr = explode("{n}", $zhaopin_show_list_str);
        if(is_array($zhaopin_show_list_arr) && !empty($zhaopin_show_list_arr)){
            foreach ($zhaopin_show_list_arr as $key => $value){
                $zhaopinShowInfoTmp = array();
                $zhaopinShowInfoTmp = explode("|", $value);
                if($zhaopinShowInfoTmp[0] == $fabu_days){
                    $fabu_pay_price = $zhaopinShowInfoTmp[1];
                    $fabu_pay_price_msg = $zhaopinShowInfoTmp[2];
                    if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                        $fabu_pay_score = ceil($fabu_pay_price * $tongchengConfig['pay_score_yuan']);
                    }
                }
            }
        }

        if($fabu_pay_price <= 0){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
        
        if($userInfo['score'] >= $fabu_pay_score && $fabu_pay_score > 0){
            $fabuPayStatus = 3;
        }
    }
    
    
    if($fabuPayStatus == 2){
        
        $insertData = array();
        $insertData['user_id']              = $userInfo['id'];
        $insertData['tczhaopin_id']         = $tczhaopin_id;
        $insertData['deduct_type']          = 2;
        $insertData['type']                 = 1;
        $insertData['today_time']           = $nowDayTime;
        $insertData['log_time']             = TIMESTAMP;
        C::t("#tom_tczhaopin#tom_tczhaopin_log")->insert($insertData);

        $updateData = array();
        $updateData['expire_status']    = 3;
        $updateData['pay_status']       = 0;
        $updateData['refresh_time']     = TIMESTAMP;
        $updateData['add_time']         = TIMESTAMP;
        $updateData['status']           = 1;
        C::t("#tom_tczhaopin#tom_tczhaopin")->update($tczhaopin_id, $updateData);
        
        update_zhaopin_tongcheng($tczhaopin_id);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else if($fabuPayStatus == 3){
        $pay_score = $fabu_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 46;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        if($tczhaopinInfo['expire_time'] > TIMESTAMP){
            $fabu_time = $fabu_days * 86400 + $tczhaopinInfo['expire_time'];
        }else{
            $fabu_time = $fabu_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['expire_status']   = 1;
        $updateData['expire_time']     = $fabu_time;
        $updateData['pay_status']      = 2;
        $updateData['refresh_time']    = TIMESTAMP;
        $updateData['add_time']         = TIMESTAMP;
        $updateData['status']          = 1;
        C::t('#tom_tczhaopin#tom_tczhaopin')->update($tczhaopin_id, $updateData);
        
        update_zhaopin_tongcheng($tczhaopin_id);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        
        $pay_price = $fabu_pay_price;

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['tczhaopin_id']     = $tczhaopin_id;
        $insertData['type']             = 8;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['fabu_days']        = $fabu_days;
        $insertData['fabu_price']       = $fabu_pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
            $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tczhaopin';          
            $insertData['order_no']        = $order_no;                 
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = $tczhaopinInfo['title'];
            $insertData['goods_beizu']     = '';
            $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$tczhaopin_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=myzhaopinlist';
            $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist"; 
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
        
    }

}else if($act == "zhaopin_top_pay" && submitcheck('tczhaopin_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $tczhaopin_id   = intval($_GET['tczhaopin_id'])>0 ? intval($_GET['tczhaopin_id']):0;
    $top_days       = intval($_GET['top_days'])>0 ? intval($_GET['top_days']):0;
    
    $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($tczhaopin_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinInfo['user_id']);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($tczhaopinInfo) && $tczhaopinInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $vipInfo = array();
    $userVipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($tczhaopinInfo['user_id']);
    if($userVipInfoTmp['vip_id'] > 0 && $userVipInfoTmp['expire_status'] == 1 && $userVipInfoTmp['expire_time'] > TIMESTAMP){
        $vipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfoTmp['vip_id']);
        if($vipInfoTmp && $vipInfoTmp > 0){
            $vipInfo = $vipInfoTmp;
        }
    }
    
    $top_pay_price = $top_pay_score = 0;
    $top_pay_price_msg = '';
    $zhaopin_top_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['zhaopin_top_list']); 
    $zhaopin_top_list_str = str_replace("\n","{n}",$zhaopin_top_list_str);
    $zhaopin_top_list_arr = explode("{n}", $zhaopin_top_list_str);
    if(is_array($zhaopin_top_list_arr) && !empty($zhaopin_top_list_arr)){
        foreach ($zhaopin_top_list_arr as $key => $value){
            $zhaopinTopInfoTmp = array();
            $zhaopinTopInfoTmp = explode("|", $value);
            if($zhaopinTopInfoTmp[0] == $top_days){
                $top_pay_price = $zhaopinTopInfoTmp[1];
                $top_pay_price_msg = $zhaopinTopInfoTmp[2];
                
                if($vipInfo && $vipInfo['id'] > 0 && $vipInfo['top_zhekou'] > 0){
                    $top_zhekou = $vipInfo['top_zhekou'] / 100;
                    $top_pay_price = $top_pay_price * $top_zhekou;
                    $top_pay_price = round($top_pay_price, 2);
                    if($top_pay_price <= 0){
                        $top_pay_price = 0.01;
                    }
                }
                
                if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                    $top_pay_score = ceil($top_pay_price * $tongchengConfig['pay_score_yuan']);
                }
            }
        }
    }
    
    if($top_pay_price <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['score'] >= $top_pay_score && $top_pay_score > 0){
        $pay_score = $top_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 47;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($tczhaopin_id);
        if($tczhaopinInfo['top_time'] > TIMESTAMP){
            $top_time = $top_days * 86400 + $tczhaopinInfo['top_time'];
        }else{
            $top_time = $top_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        $updateData['pay_status']   = 2;
        C::t('#tom_tczhaopin#tom_tczhaopin')->update($tczhaopin_id, $updateData);
        
        update_zhaopin_tongcheng($tczhaopin_id);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $pay_price = $top_pay_price;
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['tczhaopin_id']     = $tczhaopin_id;
        $insertData['type']             = 2;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['top_days']         = $top_days;
        $insertData['top_price']        = $top_pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
            $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tczhaopin';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = $tczhaopinInfo['title'];
            $insertData['goods_beizu']     = lang('plugin/tom_tczhaopin','zhaopin_top').$top_pay_price_msg;
            $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$tczhaopin_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=myzhaopinlist';
            $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist";
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }

}else if($act == "resume_top_pay" && submitcheck('resume_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $resume_id      = intval($_GET['resume_id'])>0 ? intval($_GET['resume_id']):0;
    $top_days       = intval($_GET['top_days'])>0 ? intval($_GET['top_days']):0;
    
    $resumeInfo = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_by_id($resume_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($resumeInfo['user_id']);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($resumeInfo) && $resumeInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $top_pay_price = $top_pay_score = 0;
    $top_pay_price_msg = '';
    $resume_top_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['resume_top_list']); 
    $resume_top_list_str = str_replace("\n","{n}",$resume_top_list_str);
    $resume_top_list_arr = explode("{n}", $resume_top_list_str);
    if(is_array($resume_top_list_arr) && !empty($resume_top_list_arr)){
        foreach ($resume_top_list_arr as $key => $value){
            $resumeTopInfoTmp = array();
            $resumeTopInfoTmp = explode("|", $value);
            if($resumeTopInfoTmp[0] == $top_days){
                $top_pay_price = $resumeTopInfoTmp[1];
                $top_pay_price_msg = $resumeTopInfoTmp[2];
                
                if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                    $top_pay_score = ceil($top_pay_price * $tongchengConfig['pay_score_yuan']);
                    
                }
            }
        }
    }
    
    if($top_pay_price <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['score'] >= $top_pay_score && $top_pay_score > 0){
        $pay_score = $top_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 45;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        $resumeInfo = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_by_id($resume_id);
        if($resumeInfo['top_time'] > TIMESTAMP){
            $top_time = $top_days * 86400 + $resumeInfo['top_time'];
        }else{
            $top_time = $top_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resume_id,$updateData);
        
        update_resume_tongcheng($resume_id);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $pay_price = $top_pay_price;

        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['resume_id']        = $resume_id;
        $insertData['type']             = 4;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['top_days']         = $top_days;
        $insertData['top_price']        = $top_pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
            $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tczhaopin';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = lang('plugin/tom_tczhaopin', 'fabu_resume_top');
            $insertData['goods_beizu']     = lang('plugin/tom_tczhaopin','resume_top').$top_pay_price_msg;
            $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=resumeinfo&resume_id='.$resume_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=myresumelist';
            $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myresumelist";
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }

}else if($act == "pay_vip" && submitcheck('vip_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $vip_id  = intval($_GET['vip_id'])>0 ? intval($_GET['vip_id']):0;
    $user_id    = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    
    $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($vip_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    if($userInfo['id'] > 0 && $vipInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $useVipCount = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_all_count(" AND user_id = {$user_id} AND vip_id = {$vip_id} AND type = 6 AND order_status = 2 ");
    if($vipInfo['max_num'] > 0){
        if($useVipCount >= $vipInfo['max_num']){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    $pay_price = $vipInfo['price'];
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['vip_id']           = $vip_id;
    $insertData['type']             = 6;
    $insertData['user_id']          = $userInfo['id'];
    $insertData['openid']           = $userInfo['openid'];
    $insertData['order_no']         = $order_no;
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
        $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tczhaopin';          
        $insertData['order_no']        = $order_no;                 
        $insertData['goods_id']        = $order_id;         
        $insertData['goods_name']      = $vipInfo['title'];
        $insertData['goods_beizu']     = '';
        $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=vip';
        $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=vip';
        $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=vip"; 
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $pay_price;
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'        => 200,
                'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }

}else if($act == "pay_refresh" && submitcheck('tczhaopin_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $tczhaopin_id   = intval($_GET['tczhaopin_id'])>0 ? intval($_GET['tczhaopin_id']):0;
    $user_id        = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    
    $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($tczhaopin_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    if($userInfo['id'] > 0 && $tczhaopinInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $companyRenzhengStatus = 0;
    $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$userInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
        $companyRenzhengStatus = 1;
    }
    
    $refreshPayStatus = 1;
    if($refreshPayStatus == 1){
        $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$userInfo['id']} AND type = 2 AND today_time = {$nowDayTime} AND deduct_type = 1 ");
        if($companyRenzhengStatus == 1){
            $freeRefreshNum = $tczhaopinConfig['company_free_refresh_num'];
        }else{
            $freeRefreshNum = $tczhaopinConfig['personal_free_refresh_num'];
        }
        if($freeRefreshNum > $userLogCount){
            $refreshPayStatus = 2;
        }
    }
    if($refreshPayStatus == 1){
        $userVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($userInfo['id']);
        if($userVipInfo['vip_id'] > 0 && $userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
            $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
            
            $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$userInfo['id']} AND type = 2 AND today_time = {$nowDayTime} AND deduct_type = 2 ");
            if($vipInfo['refresh_num'] > $userLogCount){
                $refreshPayStatus = 3;
            }
        }
    }
    
    if($refreshPayStatus == 1){
        if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $scorePayNum = ceil(floatval($tczhaopinConfig['shoufei_zhaopin_refresh_price']) * $tongchengConfig['pay_score_yuan']);
            if($userInfo['score'] >= $scorePayNum){
                $refreshPayStatus = 4;
            }
        }
    }
    
    if($refreshPayStatus == 2 || $refreshPayStatus == 3){
        
        $insertData = array();
        $insertData['user_id']              = $userInfo['id'];
        $insertData['tczhaopin_id']         = $tczhaopin_id;
        if($refreshPayStatus == 2){
            $insertData['deduct_type']          = 1;
        }else if($refreshPayStatus == 3){
            $insertData['deduct_type']          = 2;
        }
        $insertData['type']                 = 2;
        $insertData['today_time']           = $nowDayTime;
        $insertData['log_time']             = TIMESTAMP;
        C::t("#tom_tczhaopin#tom_tczhaopin_log")->insert($insertData);
        
    }
    
    if($refreshPayStatus == 4){
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $scorePayNum;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $scorePayNum;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 48;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    }
    
    if($refreshPayStatus != 1){

        $companyRenzhengStatus = 0;
        $renzhengInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$userInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
        $renzhengInfo = array();
        if(is_array($renzhengInfoTmp) && !empty($renzhengInfoTmp)){
            $renzhengInfo = $renzhengInfoTmp[0];
            $companyRenzhengStatus = 1;
        }
        
        $updateData = array();
        if($companyRenzhengStatus == 1){
            $updateData['company_name']            = $renzhengInfo['name'];
            $updateData['company_nature_id']       = $renzhengInfo['nature_id'];
            $updateData['company_industry_id']     = $renzhengInfo['industry_id'];
            $updateData['company_scale_id']        = $renzhengInfo['scale_id'];
        }
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin')->update($tczhaopin_id,$updateData);
    }
    
    if($refreshPayStatus == 1){
        
        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        $pay_price = $tczhaopinConfig['shoufei_zhaopin_refresh_price'];

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['tczhaopin_id']     = $tczhaopin_id;
        $insertData['type']             = 3;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
            $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tczhaopin';          
            $insertData['order_no']        = $order_no;                 
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = $tczhaopinInfo['title'];
            $insertData['goods_beizu']     = lang('plugin/tom_tczhaopin', 'pay_refresh_beizu');
            $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=myzhaopinlist';
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=myzhaopinlist';
            $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist"; 
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    update_zhaopin_tongcheng($tczhaopin_id);
    
    $outArr = array(
        'status'        => 200,
        'pay_status'    => 0,
    );
    echo json_encode($outArr); exit;

}else if($act == "pay_look_resume" && submitcheck('resume_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $resume_id      = intval($_GET['resume_id'])>0 ? intval($_GET['resume_id']):0;
    $user_id        = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    
    $resumeInfo = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_by_id($resume_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);

    if($userInfo['id'] > 0 && $resumeInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['id'] == $resumeInfo['user_id']){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    $rencaiInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_rencai")->fetch_all_list(" AND user_id = {$userInfo['id']} AND resume_id = {$resume_id} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($rencaiInfoTmp) && $rencaiInfoTmp[0]['id'] > 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $companyRenzhengStatus = 0;
    $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$user_id} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
        $companyRenzhengStatus = 1;
    }
    
    $resumePayStatus = 1;
    if($resumePayStatus == 1){
        $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$userInfo['id']} AND type = 3 AND deduct_type = 1 ");
        if($companyRenzhengStatus == 1){
            $freeResumeNum = $tczhaopinConfig['company_free_resume_num'];
        }else{
            $freeResumeNum = $tczhaopinConfig['personal_free_resume_num'];
        }
        if($freeResumeNum > $userLogCount){
            $resumePayStatus = 2;
        }
    }

    if($resumePayStatus == 1){
        $userVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($userInfo['id']);
        if($userVipInfo['vip_id'] > 0 && $userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
            $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
            $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$userInfo['id']} AND type = 3 AND deduct_type = 2");
            if($vipInfo['resume_num'] > $userVipLogCount){
                $resumePayStatus = 3;
            }
        }
    }
    
    if($resumePayStatus == 1){
        if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $scorePayNum = ceil(floatval($tczhaopinConfig['shoufei_resume_price']) * $tongchengConfig['pay_score_yuan']);
            if($userInfo['score'] >= $scorePayNum){
                $resumePayStatus = 4;
            }
        }
    }

    if($resumePayStatus == 2 || $resumePayStatus == 3){

        $insertData = array();
        $insertData['user_id']              = $userInfo['id'];
        $insertData['resume_id']            = $resume_id;
        if($resumePayStatus == 2){
            $insertData['deduct_type']          = 1;
        }else if($resumePayStatus == 3){
            $insertData['deduct_type']          = 2;
        }
        $insertData['type']                 = 3;
        $insertData['today_time']           = $nowDayTime;
        $insertData['log_time']             = TIMESTAMP;
        C::t("#tom_tczhaopin#tom_tczhaopin_log")->insert($insertData);
    }
    if($resumePayStatus == 4){
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $scorePayNum;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $scorePayNum;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 49;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    }

    if($resumePayStatus != 1){
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['resume_id']    = $resume_id;
        $insertData['type']         = 2;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->insert($insertData);
    }
    
    if($resumePayStatus == 1){
        
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        $pay_price = $tczhaopinConfig['shoufei_resume_price'];

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['resume_id']        = $resume_id;
        $insertData['type']             = 5;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
            $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tczhaopin';
            $insertData['order_no']        = $order_no;                 
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = lang('plugin/tom_tczhaopin', 'pay_look_resume_title');
            $insertData['goods_beizu']     = lang('plugin/tom_tczhaopin', 'pay_look_resume_title');
            $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=resumeinfo&resume_id='.$resume_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=resumeinfo&resume_id='.$resume_id;
            $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=resumeinfo&resume_id=".$resume_id; 
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if(!empty($tongchengConfig['template_id'])){
        
        $toUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($resumeInfo['user_id']);

        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass  = new weixinClass($appid,$appsecret);

        $access_token = $weixinClass->get_access_token();
        
        $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($userInfo['id']);

        $renzhengCompanyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($userInfo['id']);
        if(is_array($renzhengCompanyInfo) && !empty($renzhengCompanyInfo)){
            $name = $renzhengCompanyInfo['name'];
        }else{
            $name = $userInfo['nickname'];
        }

        if($access_token && !empty($toUserInfo['openid'])){
            $template_sms = lang('plugin/tom_tczhaopin', 'ajax_look_resume_template');
            $template_sms = str_replace("{NAME}", $name, $template_sms);

            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            if(is_array($companyInfo) && !empty($companyInfo) && $companyInfo['show_status'] == 1){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=companyinfo&company_id={$companyInfo['id']}");
            }else{
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=index");
            }
            $smsData = array(
                'first'         => $template_sms,
                'keyword1'      => $tczhaopinConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($toUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
        
    $outArr = array(
        'status'        => 200,
        'pay_status'    => 0,
    );
    echo json_encode($outArr); exit;

}else if($act == "company_top_pay" && submitcheck('company_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $company_id     = intval($_GET['company_id'])>0 ? intval($_GET['company_id']):0;
    $top_days       = intval($_GET['top_days'])>0 ? intval($_GET['top_days']):0;
    $user_id        = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    
    $companyInfo = C::t("#tom_tczhaopin#tom_tczhaopin_company")->fetch_by_id($company_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($companyInfo) && $companyInfo['user_id'] == $userInfo['id']){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $vipInfo = array();
    $userVipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($user_id);
    if($userVipInfoTmp['vip_id'] > 0 && $userVipInfoTmp['expire_status'] == 1 && $userVipInfoTmp['expire_time'] > TIMESTAMP){
        $vipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfoTmp['vip_id']);
        if($vipInfoTmp && $vipInfoTmp > 0){
            $vipInfo = $vipInfoTmp;
        }
    }
    
    $top_pay_price = $top_pay_score = 0;
    $top_pay_price_msg = '';
    $company_top_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['company_top_list']); 
    $company_top_list_str = str_replace("\n","{n}",$company_top_list_str);
    $company_top_list_arr = explode("{n}", $company_top_list_str);
    if(is_array($company_top_list_arr) && !empty($company_top_list_arr)){
        foreach ($company_top_list_arr as $key => $value){
            $companyTopInfoTmp = array();
            $companyTopInfoTmp = explode("|", $value);
            if($companyTopInfoTmp[0] == $top_days){
                $top_pay_price = $companyTopInfoTmp[1];
                $top_pay_price_msg = $companyTopInfoTmp[2];
                
                if($vipInfo && $vipInfo['id'] > 0 && $vipInfo['top_zhekou'] > 0){
                    $top_zhekou = $vipInfo['top_zhekou'] / 100;
                    $top_pay_price = $top_pay_price * $top_zhekou;
                    $top_pay_price = round($top_pay_price, 2);
                    if($top_pay_price <= 0){
                        $top_pay_price = 0.01;
                    }
                }
                
                if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                    $top_pay_score = ceil($top_pay_price * $tongchengConfig['pay_score_yuan']);
                }
            }
        }
    }
    
    if($top_pay_price <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['score'] >= $top_pay_score && $top_pay_score > 0){
        $pay_score = $top_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 50;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        $companyInfo = C::t("#tom_tczhaopin#tom_tczhaopin_company")->fetch_by_id($company_id);
        if($companyInfo['top_time'] > TIMESTAMP){
            $top_time = $top_days * 86400 + $companyInfo['top_time'];
        }else{
            $top_time = $top_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tczhaopin#tom_tczhaopin_company')->update($company_id,$updateData);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $pay_price = $top_pay_price;

        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['company_id']       = $company_id;
        $insertData['type']             = 7;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['top_days']         = $top_days;
        $insertData['top_price']        = $top_pay_score;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
            $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tczhaopin';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = lang('plugin/tom_tczhaopin', 'fabu_company_top');
            $insertData['goods_beizu']     = lang('plugin/tom_tczhaopin','company_top').$top_pay_price_msg;
            $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=companyinfo&company_id='.$company_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=my';
            $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=my";
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }

}else if($act == "canhui_pay" && submitcheck('meeting_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $meeting_id     = intval($_GET['meeting_id'])>0 ? intval($_GET['meeting_id']):0;
    $user_id        = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    
    $meetingInfo = C::t("#tom_tczhaopin#tom_tczhaopin_meeting")->fetch_by_id($meeting_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($meetingInfo) && !empty($meetingInfo) && is_array($userInfo) && !empty($userInfo)){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(TIMESTAMP > $meetingInfo['bmend_time']){ 
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    if($meetingInfo['open_pay'] == 1 && $meetingInfo['pay_price'] > 0){ }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($user_id);
    if(is_array($companyInfo) && !empty($companyInfo)){
        update_company_status($companyInfo);
    }else{
        $insertData = array();
        $insertData['site_id']              = $site_id;
        $insertData['user_id']              = $user_id;
        $insertData['add_time']             = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_company')->insert($insertData)){
            $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($user_id);
            update_company_status($companyInfo);
        }
    }
    
    $meetingCompanyInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_meeting_company")->fetch_all_list(" AND user_id = {$user_id} AND meeting_id = {$meeting_id}", 'ORDER BY id DESC', 0, 1);
    $meetingCompanyInfo = array();
    if(is_array($meetingCompanyInfoTmp) && !empty($meetingCompanyInfoTmp[0])){ 
        $meetingCompanyInfo = $meetingCompanyInfoTmp[0];
        
        if($meetingCompanyInfo['pay_status'] != 1){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }else{
            $meeting_company_id = $meetingCompanyInfo['id'];
        }
    }else{
        $insertData = array();
        $insertData['meeting_id']   = $meeting_id;
        $insertData['user_id']      = $user_id;
        $insertData['company_id']   = $companyInfo['id'];
        $insertData['pay_status']   = 1;
        if($meetingInfo['zhaopin_list_type'] == 2){
            $insertData['status']   = 1;
        }
        $insertData['add_time']     = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->insert($insertData)){
            $meeting_company_id = C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->insert_id();
        }
    }
    
    if($meeting_company_id > 0){
    
        $pay_price = $meetingInfo['pay_price'];

        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['meeting_id']       = $meeting_id;
        $insertData['meeting_company_id'] = $meeting_company_id;
        $insertData['type']             = 9;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
            $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tczhaopin';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = $meetingInfo['title'];
            $insertData['goods_beizu']     = $meetingInfo['title'];
            $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=meetinginfo&meeting_id='.$meeting_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=meetinginfo&meeting_id='.$meeting_id;
            $insertData['fail_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=meetinginfo&meeting_id='.$meeting_id;
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $outArr = array(
        'status'=> 404,
    );
    echo json_encode($outArr); exit;
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}