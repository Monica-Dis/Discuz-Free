<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function update_company_status($companyInfo = array()){
    
    $company_status = 0;
    
    $renzhengCompanyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($companyInfo['user_id']);
    if(is_array($renzhengCompanyInfo) && !empty($renzhengCompanyInfo) && $renzhengCompanyInfo['shenhe_status'] == 1){
        $company_status = 1;
    }

    $zhaopinCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$companyInfo['user_id']}  AND shenhe_status = 1 AND status = 1 AND (pay_status = 0 OR pay_status = 2) ");
    if($zhaopinCount <= 0){
        $company_status = 2;
    }
    
    $updateData = array();
    if($company_status == 1 && $companyInfo['renzheng_company_id'] != $renzhengCompanyInfo['id']){
        $updateData['renzheng_company_id']  = $renzhengCompanyInfo['id'];
        $companyInfo['renzheng_company_id'] = $renzhengCompanyInfo['id'];
    }
    if($company_status == 1 && $companyInfo['show_status'] == 0){
        $updateData['show_status']  = 1;
        $companyInfo['show_status'] = 1;
    }
    if($company_status == 2 && $companyInfo['show_status'] == 1){
        $updateData['show_status']  = 0;
        $companyInfo['show_status'] = 0;
    }
    if($zhaopinCount != $companyInfo['num']){
        $updateData['num']  = $zhaopinCount;
        $companyInfo['num'] = $zhaopinCount;
    }
    
    if(is_array($updateData) && !empty($updateData)){
        C::t('#tom_tczhaopin#tom_tczhaopin_company')->update($companyInfo['id'],$updateData);
    }
    
    return $companyInfo;
}

function update_zhaopin_tongcheng($tczhaopin_id,$paramArr = array()){
    
    if(is_array($paramArr) && !empty($paramArr)){
        $tczhaopinConfig    = $paramArr['tczhaopinConfig'];
        $tongchengConfig    = $paramArr['tongchengConfig'];
        $welfareArray       = $paramArr['welfareArray'];
        $workSalaryArray    = $paramArr['workSalaryArray'];
        $jianzhiJieSuanUnitArray    = $paramArr['jianzhiJieSuanUnitArray'];
        $agesArray          = $paramArr['agesArray'];
        $xueliArray         = $paramArr['xueliArray'];
        $workJingyanArray   = $paramArr['workJingyanArray'];
    }else{
        global $tczhaopinConfig,$tongchengConfig,$welfareArray,$workSalaryArray,$jianzhiJieSuanUnitArray,$agesArray,$xueliArray,$workJingyanArray;
    }
    
    if($tczhaopinConfig['open_tongbu_tongcheng'] == 1 && $tczhaopinConfig['tc_zhaopin_type_id'] > 0){}else{
        return false;
    }
    
    $tongchengTypeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tczhaopinConfig['tc_zhaopin_type_id']);
    if($tongchengTypeInfo && $tongchengTypeInfo['id'] > 0){}else{
        return false;
    }
    
    $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($tczhaopin_id);
    if($tczhaopinInfo && $tczhaopinInfo['id'] > 0){}else{
        return false;
    }
    
    $photoListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_photo')->fetch_all_list(" AND tczhaopin_id={$tczhaopin_id} "," ORDER BY psort ASC,id ASC ");
    $photoList = array();
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach($photoListTmp as $key => $value){
            $photoList[] = $value['picurl'];
        }
    }
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_tczhaopin_id($tczhaopinInfo['id']);
    
    $attrArr = array();
    $attrArr[0]['name'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_title");
    if($tczhaopinInfo['type'] == 2 && $tczhaopinInfo['jianzhi_cate_id'] > 0){
        $jianzhiCateInfo = C::t("#tom_tczhaopin#tom_tczhaopin_jianzhi_cate")->fetch_by_id($tczhaopinInfo['jianzhi_cate_id']);
        $attrArr[0]['value'] = $jianzhiCateInfo['name'];
    }else{
        if($tczhaopinConfig['open_zhaopin_cate_child'] == 1){
            $cateInfo = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($tczhaopinInfo['cate_child_id']);
        }else{
            $cateInfo = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($tczhaopinInfo['cate_id']);
        }
        $attrArr[0]['value'] = $cateInfo['name'];
    }
    $attrArr[0]['unit'] = '';
    
    $attrArr[1]['name'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_work_salary");
    if($tczhaopinInfo['type'] == 2 && $tczhaopinInfo['jianzhi_work_salary'] > 0){
        $attrArr[1]['value'] = $tczhaopinInfo['jianzhi_work_salary'];
        $attrArr[1]['unit'] = $jianzhiJieSuanUnitArray[$tczhaopinInfo['jianzhi_work_salary_unit']];
    }else{
        if($tczhaopinInfo['work_salary'] == 999){
            if($tczhaopinInfo['work_salary_min'] == $tczhaopinInfo['work_salary_max']){
                $attrArr[1]['value'] = $tczhaopinInfo['work_salary_min'];
            }else{
                $attrArr[1]['value'] = $tczhaopinInfo['work_salary_min'].'-'.$tczhaopinInfo['work_salary_max'];
            }
            $attrArr[1]['unit'] = lang('plugin/tom_tczhaopin', 'zhaopinlist_yuan_month');
        }else{
            $attrArr[1]['value'] = $workSalaryArray[$tczhaopinInfo['work_salary']];
            $attrArr[1]['unit'] = '';
            if($tczhaopinInfo['work_salary'] > 1){
                $attrArr[1]['unit'] = lang('plugin/tom_tczhaopin', 'zhaopinlist_yuan_month');
            }
        }
        
    }
    
    $attrArr[2]['name'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_company_name");
    $attrArr[2]['value'] = $tczhaopinInfo['company_name'];
    $attrArr[2]['unit'] = '';
    
    $attrArr[3]['name'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_renshu");
    if($tczhaopinInfo['renshu'] == 0){
        $attrArr[3]['value'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_renshu_ruogan");
        $attrArr[3]['unit'] = '';
    }else{
        $attrArr[3]['value'] = $tczhaopinInfo['renshu'];
        $attrArr[3]['unit'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_renshu_unit");
    }
    
    $attrArr[4]['name'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_demand_sex");
    if($tczhaopinInfo['demand_sex'] == 1){
        $attrArr[4]['value'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_demand_sex_1");
    }else if($tczhaopinInfo['demand_sex'] == 2){
        $attrArr[4]['value'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_demand_sex_2");
    }else{
        $attrArr[4]['value'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_demand_sex_0");
    }
    $attrArr[4]['unit'] = '';
    
    $attrArr[5]['name'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_demand_ages");
    if($tczhaopinInfo['demand_ages'] > 0){
        $attrArr[5]['value'] = $agesArray[$tczhaopinInfo['demand_ages']];
    }else{
        $attrArr[5]['value'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_demand_ages_0");
    }
    $attrArr[5]['unit'] = '';
    
    $attrArr[6]['name'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_demand_xueli");
    if($tczhaopinInfo['demand_xueli'] > 0){
        $attrArr[6]['value'] = $xueliArray[$tczhaopinInfo['demand_xueli']];
    }else{
        $attrArr[6]['value'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_demand_xueli_0");
    }
    $attrArr[6]['unit'] = '';
    
    $attrArr[7]['name'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_demand_jingyan");
    if($tczhaopinInfo['demand_jingyan'] > 0){
        $attrArr[7]['value'] = $workJingyanArray[$tczhaopinInfo['demand_jingyan']];
    }else{
        $attrArr[7]['value'] = lang("plugin/tom_tczhaopin", "tongbu_zhaopin_demand_jingyan_0");
    }
    $attrArr[7]['unit'] = '';
    
    $workWelfareArr = explode('-', trim($tczhaopinInfo['work_welfare'], '-'));
    $tagArr = array();
    if(is_array($welfareArray) && !empty($welfareArray)){
        foreach($welfareArray as $k => $v){
            if(in_array($k,$workWelfareArr)){
                $tagArr[$k]['name'] = $v;
            }
        }
    }
    
    if($tongchengInfo && $tongchengInfo['id'] > 0){
        
        $updateData = array();
        $updateData['site_id']      = $tczhaopinInfo['site_id'];
        $updateData['user_id']      = $tczhaopinInfo['user_id'];
        $updateData['model_id']     = $tongchengTypeInfo['model_id'];
        $updateData['type_id']      = $tongchengTypeInfo['id'];
        $updateData['tczhaopin_id'] = $tczhaopinInfo['id'];
        $updateData['area_id']      = $tczhaopinInfo['area_id'];
        $updateData['street_id']    = $tczhaopinInfo['street_id'];
        $updateData['title']        = $tczhaopinInfo['title'];
        $updateData['xm']           = $tczhaopinInfo['xm'];
        $updateData['tel']          = $tczhaopinInfo['tel'];
        $updateData['video_url']    = $tczhaopinInfo['video_url'];
        $updateData['video_pic']    = $tczhaopinInfo['video_pic'];
        $updateData['content']      = $tczhaopinInfo['demand_desc'].'|+|+|+|+|+|+|+|+|+|'.'-'.$tczhaopinInfo['search_text'].'-'.  mt_rand(111111, 666666);
        if($tongchengTypeInfo['open_dingwei'] == 1){
            $updateData['is_dingwei']       = 1;
            $updateData['latitude']         = $tczhaopinInfo['latitude'];
            $updateData['longitude']        = $tczhaopinInfo['longitude'];
            $updateData['address']          = $tczhaopinInfo['address'];
        }else{
            $updateData['is_dingwei']       = 0;
        }
        if($tczhaopinConfig['open_tongbu_top'] == 1 && $tczhaopinInfo['top_status'] == 1){
            $updateData['topstatus']            = $tczhaopinInfo['top_status'];
            $updateData['toprand']              = 1;
            $updateData['toptime']              = $tczhaopinInfo['top_time'];
        }else{
            $updateData['topstatus']            = 0;
            $updateData['toprand']              = 1;
            $updateData['toptime']              = 0;
        }
        if($tczhaopinInfo['status'] == 1 && ($tczhaopinInfo['expire_status'] == 3 || ($tczhaopinInfo['expire_status'] == 1 && $tczhaopinInfo['expire_time'] > TIMESTAMP))){
            $updateData['status']               = 1;
        }else if($tczhaopinInfo['top_status'] == 0){
            $updateData['status']               = 0;
        }
        $updateData['finish']               = 0;
        $updateData['pay_status']           = $tczhaopinInfo['pay_status'];
        $updateData['shenhe_status']        = $tczhaopinInfo['shenhe_status'];
        $updateData['refresh_time']         = $tczhaopinInfo['refresh_time'];
        $updateData['add_time']             = $tczhaopinInfo['add_time'];
        $updateData['part1']                = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongchengInfo['id'],$updateData);
        
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_tag')->delete_by_tongcheng_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_photo')->delete_by_tongcheng_id($tongchengInfo['id']);
        
        if(is_array($attrArr) && !empty($attrArr)){
            foreach ($attrArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengInfo['id'];
                $insertData['attr_id']      = 0;
                $insertData['attr_name']    = $value['name'];
                $insertData['value']        = $value['value'];
                $insertData['unit']         = $value['unit'];
                $insertData['paixu']        = $key;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
        
        $i = 1;
        if(is_array($tagArr) && !empty($tagArr)){
            foreach ($tagArr as $key => $value){
                if($i > 5) break;
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengInfo['id'];
                $insertData['tag_id']       = 0;
                $insertData['tag_name']     = $value['name'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_tag')->insert($insertData);
                $i++;
            }
        }
        
        if(is_array($photoList) && !empty($photoList)){
            foreach($photoList as $key => $value){
                $insertData = array();
                $insertData['tongcheng_id'] = $tongchengInfo['id'];
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_photo')->insert($insertData);
            }
        }
        
    }else if($tczhaopinInfo && $tczhaopinInfo['status'] == 1 && $tczhaopinInfo['shenhe_status'] == 1 && ($tczhaopinInfo['pay_status'] == 0 || $tczhaopinInfo['pay_status'] == 2)){
        
        $insertData = array();
        $insertData['site_id']      = $tczhaopinInfo['site_id'];
        $insertData['user_id']      = $tczhaopinInfo['user_id'];
        $insertData['model_id']     = $tongchengTypeInfo['model_id'];
        $insertData['type_id']      = $tongchengTypeInfo['id'];
        $insertData['tczhaopin_id'] = $tczhaopinInfo['id'];
        $insertData['area_id']      = $tczhaopinInfo['area_id'];
        $insertData['street_id']    = $tczhaopinInfo['street_id'];
        $insertData['title']        = $tczhaopinInfo['title'];
        $insertData['xm']           = $tczhaopinInfo['xm'];
        $insertData['tel']          = $tczhaopinInfo['tel'];
        $insertData['video_url']    = $tczhaopinInfo['video_url'];
        $insertData['video_pic']    = $tczhaopinInfo['video_pic'];
        $insertData['content']      = $tczhaopinInfo['demand_desc'].'|+|+|+|+|+|+|+|+|+|'.'-'.$tczhaopinInfo['search_text'].'-'.  mt_rand(111111, 666666);
        if($tongchengTypeInfo['open_dingwei'] == 1){
            $insertData['is_dingwei']       = 1;
            $insertData['latitude']         = $tczhaopinInfo['latitude'];
            $insertData['longitude']        = $tczhaopinInfo['longitude'];
            $insertData['address']          = $tczhaopinInfo['address'];
        }else{
            $insertData['is_dingwei']       = 0;
        }
        if($tczhaopinConfig['open_tongbu_top'] == 1 && $tczhaopinInfo['top_status'] == 1){
            $insertData['topstatus']            = $tczhaopinInfo['top_status'];
            $insertData['toprand']              = 1;
            $insertData['toptime']              = $tczhaopinInfo['top_time'];
        }else{
            $insertData['topstatus']            = 0;
            $insertData['toprand']              = 1;
            $insertData['toptime']              = 0;
        }
        if($tczhaopinInfo['status'] == 1 && ($tczhaopinInfo['expire_status'] == 3 || ($tczhaopinInfo['expire_status'] == 1 && $tczhaopinInfo['expire_time'] > TIMESTAMP))){
            $insertData['status']               = 1;
        }else{
            $insertData['status']               = 0;
        }
        $insertData['pay_status']           = $tczhaopinInfo['pay_status'];
        $insertData['shenhe_status']        = $tczhaopinInfo['shenhe_status'];
        $insertData['refresh_time']         = $tczhaopinInfo['refresh_time'];
        $insertData['add_time']             = $tczhaopinInfo['add_time'];
        $insertData['client_ip_port']       = $tczhaopinInfo['client_ip_port'];
        C::t('#tom_tongcheng#tom_tongcheng')->insert($insertData);
        $tongchengId = C::t('#tom_tongcheng#tom_tongcheng')->insert_id();
        
        if(is_array($attrArr) && !empty($attrArr)){
            foreach ($attrArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['attr_id']      = 0;
                $insertData['attr_name']    = $value['name'];
                $insertData['value']        = $value['value'];
                $insertData['unit']         = $value['unit'];
                $insertData['paixu']        = $key;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
        
        $i = 1;
        if(is_array($tagArr) && !empty($tagArr)){
            foreach ($tagArr as $key => $value){
                if($i > 5) break;
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['tag_id']       = 0;
                $insertData['tag_name']     = $value['name'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_tag')->insert($insertData);
                $i++;
            }
        }
        
        if(is_array($photoList) && !empty($photoList)){
            foreach($photoList as $key => $value){
                $insertData = array();
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_photo')->insert($insertData);
            }
        }
    }
    
    return true;
}

function update_resume_tongcheng($resume_id,$paramArr = array()){
    
    if(is_array($paramArr) && !empty($paramArr)){
        $tczhaopinConfig    = $paramArr['tczhaopinConfig'];
        $tongchengConfig    = $paramArr['tongchengConfig'];
        $welfareArray       = $paramArr['welfareArray'];
        $workSalaryArray    = $paramArr['workSalaryArray'];
        $workJingyanArray   = $paramArr['workJingyanArray'];
        $tomSysOffset       = $paramArr['tomSysOffset'];
        $xueliArray         = $paramArr['xueliArray'];
    }else{
        global $tczhaopinConfig,$tongchengConfig,$welfareArray,$workSalaryArray,$workJingyanArray,$tomSysOffset,$xueliArray;
    }
    
    if($tczhaopinConfig['open_tongbu_tongcheng'] == 1 && $tczhaopinConfig['tc_resume_type_id'] > 0){}else{
        return false;
    }
    
    $tongchengTypeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tczhaopinConfig['tc_resume_type_id']);
    if($tongchengTypeInfo && $tongchengTypeInfo['id'] > 0){}else{
        return false;
    }
    
    $resumeInfo = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_by_id($resume_id);
    if($resumeInfo && $resumeInfo['id'] > 0){}else{
        return false;
    }
    
    if($resumeInfo['deleted'] == 1){
        return false;
    }
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_tczhaopin_resume_id($resumeInfo['id']);
    
    $attrArr = array();
    $attrArr[0]['name'] = lang("plugin/tom_tczhaopin", "tongbu_resume_title");
    $attrArr[0]['value'] = $resumeInfo['cate_child_str'];
    $attrArr[0]['unit'] = '';
    
    $attrArr[1]['name'] = lang("plugin/tom_tczhaopin", "tongbu_resume_work_jingyan");
    $attrArr[1]['value'] = $workJingyanArray[$resumeInfo['work_jingyan']];
    $attrArr[1]['unit'] = '';
    
    $attrArr[2]['name'] = lang("plugin/tom_tczhaopin", "tongbu_resume_work_salary");
    $attrArr[2]['value'] = $workSalaryArray[$resumeInfo['work_salary']];
    $attrArr[2]['unit'] = '';
    if($resumeInfo['work_salary'] > 1){
        $attrArr[2]['unit'] = lang('plugin/tom_tczhaopin', 'zhaopinlist_yuan_month');
    }
    
    $attrArr[3]['name'] = lang("plugin/tom_tczhaopin", "tongbu_resume_xueli");
    $attrArr[3]['value'] =  $xueliArray[$resumeInfo['demand_xueli']];
    $attrArr[3]['unit'] = '';
    
    $sex_call = '';
    if($resumeInfo['sex'] == 1){
        $sex_call = lang('plugin/tom_tczhaopin', 'resumelist_sex_1_call');
    }else if($resumeInfo['sex'] == 2){
        $sex_call = lang('plugin/tom_tczhaopin', 'resumelist_sex_2_call');
    }
    $resumeInfo['name'] = cutstr($resumeInfo['name'], 2,'').$sex_call;
    
    if($tongchengInfo && $tongchengInfo['id'] > 0){
        $updateData = array();
        $updateData['site_id']      = $resumeInfo['site_id'];
        $updateData['user_id']      = $resumeInfo['user_id'];
        $updateData['model_id']     = $tongchengTypeInfo['model_id'];
        $updateData['type_id']      = $tongchengTypeInfo['id'];
        $updateData['tczhaopin_resume_id'] = $resumeInfo['id'];
        $updateData['area_id']      = $resumeInfo['area_id'];
        $updateData['street_id']    = $resumeInfo['street_id'];
        $updateData['title']        = $resumeInfo['cate_child_str'];
        $updateData['xm']           = $resumeInfo['name'];
        $updateData['tel']          = $resumeInfo['tel'];
        $updateData['video_url']    = $resumeInfo['video_url'];
        $updateData['video_pic']    = $resumeInfo['video_pic'];
        $updateData['content']      = $resumeInfo['work_jingli'].'|+|+|+|+|+|+|+|+|+|'.'-'.$resumeInfo['search_text'].'-'.  mt_rand(111111, 666666);
        if($tczhaopinConfig['open_tongbu_top'] == 1 && $resumeInfo['top_status'] == 1){
            $updateData['topstatus']            = $resumeInfo['top_status'];
            $updateData['toprand']              = 1;
            $updateData['toptime']              = $resumeInfo['top_time'];
        }else{
            $updateData['topstatus']            = 0;
            $updateData['toprand']              = 1;
            $updateData['toptime']              = 0;
        }
        if($resumeInfo['gongkai_status'] == 1){
            $updateData['status']               = $resumeInfo['status'];
        }else{
            $updateData['status']               = 0;
        }
        $updateData['finish']               = 0;
        $updateData['shenhe_status']        = $resumeInfo['shenhe_status'];
        $updateData['refresh_time']         = $resumeInfo['refresh_time'];
        $updateData['add_time']             = $resumeInfo['add_time'];
        $updateData['part1']                = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongchengInfo['id'],$updateData);
        
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongchengInfo['id']);
        
        if(is_array($attrArr) && !empty($attrArr)){
            foreach ($attrArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengInfo['id'];
                $insertData['attr_id']      = 0;
                $insertData['attr_name']    = $value['name'];
                $insertData['value']        = $value['value'];
                $insertData['unit']         = $value['unit'];
                $insertData['paixu']        = $key;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
        
    }else if($resumeInfo && $resumeInfo['status'] == 1 && $resumeInfo['shenhe_status'] == 1 && $resumeInfo['gongkai_status'] == 1){
        
        $insertData = array();
        $insertData['site_id']      = $resumeInfo['site_id'];
        $insertData['user_id']      = $resumeInfo['user_id'];
        $insertData['model_id']     = $tongchengTypeInfo['model_id'];
        $insertData['type_id']      = $tongchengTypeInfo['id'];
        $insertData['tczhaopin_resume_id'] = $resumeInfo['id'];
        $insertData['area_id']      = $resumeInfo['area_id'];
        $insertData['street_id']    = $resumeInfo['street_id'];
        $insertData['title']        = $resumeInfo['cate_child_str'];
        $insertData['xm']           = $resumeInfo['name'];
        $insertData['tel']          = $resumeInfo['tel'];
        $insertData['video_url']    = $resumeInfo['video_url'];
        $insertData['video_pic']    = $resumeInfo['video_pic'];
        $insertData['content']      = $resumeInfo['work_jingli'].'|+|+|+|+|+|+|+|+|+|'.'-'.$resumeInfo['search_text'].'-'.  mt_rand(111111, 666666);
        if($tczhaopinConfig['open_tongbu_top'] == 1 && $resumeInfo['top_status'] == 1){
            $insertData['topstatus']            = $resumeInfo['top_status'];
            $insertData['toprand']              = 1;
            $insertData['toptime']              = $resumeInfo['top_time'];
        }else{
            $insertData['topstatus']            = 0;
            $insertData['toprand']              = 1;
            $insertData['toptime']              = 0;
        }
        $insertData['status']               = $resumeInfo['status'];
        $insertData['shenhe_status']        = $resumeInfo['shenhe_status'];
        $insertData['refresh_time']         = $resumeInfo['refresh_time'];
        $insertData['add_time']             = $resumeInfo['add_time'];
        $insertData['client_ip_port']       = $resumeInfo['client_ip_port'];
        C::t('#tom_tongcheng#tom_tongcheng')->insert($insertData);
        
        $tongchengId = C::t('#tom_tongcheng#tom_tongcheng')->insert_id();
        
        if(is_array($attrArr) && !empty($attrArr)){
            foreach ($attrArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['attr_id']      = 0;
                $insertData['attr_name']    = $value['name'];
                $insertData['value']        = $value['value'];
                $insertData['unit']         = $value['unit'];
                $insertData['paixu']        = $key;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
        
    }
    
    return true;
    
}

function delete_zhaopin_tongcheng($tczhaopin_id){
    global $tczhaopinConfig,$tongchengConfig;
    
    if($tczhaopinConfig['open_tongbu_tongcheng'] == 1){}else{
        return false;
    }
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_tczhaopin_id($tczhaopin_id);
    if($tongchengInfo){
        C::t('#tom_tongcheng#tom_tongcheng')->delete_by_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_tag')->delete_by_tongcheng_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_photo')->delete_by_tongcheng_id($tongchengInfo['id']);
    }
    return true;
}

function delete_resume_tongcheng($resume_id){
    global $tczhaopinConfig,$tongchengConfig;
    
    if($tczhaopinConfig['open_tongbu_tongcheng'] == 1){}else{
        return false;
    }
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_tczhaopin_resume_id($resume_id);
    if($tongchengInfo){
        C::t('#tom_tongcheng#tom_tongcheng')->delete_by_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongchengInfo['id']);
    }
    return true;
}

function tom_random($length, $chars = '') {
	$hash = '';
	$max = strlen($chars) - 1;
	for($i = 0; $i < $length; $i++) {
		$hash .= $chars[mt_rand(0, $max)];
	}
	return $hash;
} 