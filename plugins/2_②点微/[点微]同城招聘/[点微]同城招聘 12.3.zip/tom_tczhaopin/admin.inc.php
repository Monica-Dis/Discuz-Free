<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tczhaopin'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tczhaopin&pmod=admin';
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tczhaopin&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tczhaopin&pmod=admin';

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/class/function.a.php';
include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
$tczhaopinConfig = get_plugin_config($pluginid);
$Lang = formatLang($Lang);

$zhaopinSetting = C::t('#tom_tczhaopin#tom_tczhaopin_setting')->fetch_by_id(1);
if($zhaopinSetting && $zhaopinSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin_setting')->insert($insertData);
    $zhaopinSetting = C::t('#tom_tczhaopin#tom_tczhaopin_setting')->fetch_by_id(1);
}

$tongchengPlugin = C::t('#tom_tczhaopin#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.utf.php';
}
$welfareArray = array();
$welfare_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['welfare_list']); 
$welfare_list_str = str_replace("\n","{n}",$welfare_list_str);
$welfare_list_arr = explode("{n}", $welfare_list_str);
if(is_array($welfare_list_arr) && !empty($welfare_list_arr)){
    foreach ($welfare_list_arr as $key => $value){
        $welfare_list_item = explode("|", $value);
        $welfare_list_item_id = intval($welfare_list_item[0]);
        $welfare_list_item_name = trim($welfare_list_item[1]);
        if($welfare_list_item_id > 0 && !empty($welfare_list_item_name)){
            $welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
        }
    }
}

$agesArray = array();
$ages_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['zhaopin_ages_list']); 
$ages_list_str = str_replace("\n","{n}",$ages_list_str);
$ages_list_arr = explode("{n}", $ages_list_str);
if(is_array($ages_list_arr) && !empty($ages_list_arr)){
    foreach ($ages_list_arr as $key => $value){
        $ages_list_item = explode("|", $value);
        $ages_list_item_id = intval($ages_list_item[0]);
        $ages_list_item_name = trim($ages_list_item[1]);
        if($ages_list_item_id > 0 && !empty($ages_list_item_name)){
            $agesArray[$ages_list_item_id] = $ages_list_item_name;
        }
    }
}

$workStatusArray = array();
$work_status_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['work_status_list']); 
$work_status_list_str = str_replace("\n","{n}",$work_status_list_str);
$work_status_list_arr = explode("{n}", $work_status_list_str);
if(is_array($work_status_list_arr) && !empty($work_status_list_arr)){
    foreach ($work_status_list_arr as $key => $value){
        $work_status_list_item = explode("|", $value);
        $work_status_list_item_id = intval($work_status_list_item[0]);
        $work_status_list_item_name = trim($work_status_list_item[1]);
        if($work_status_list_item_id > 0 && !empty($work_status_list_item_name)){
            $workStatusArray[$work_status_list_item_id] = $work_status_list_item_name;
        }
    }
}

$resume_default_avatar = explode("|", $tczhaopinConfig['resume_default_avatar']);
$man_resume_avatar = "source/plugin/tom_tczhaopin/images/resume_avatar/".$resume_default_avatar[0];
$woman_resume_avatar = "source/plugin/tom_tczhaopin/images/resume_avatar/".$resume_default_avatar[1];

if($_GET['tmod'] == 'index'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/index.php';
}else if($_GET['tmod'] == 'resume'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/resume.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/order.php';
}else if($_GET['tmod'] == 'cate'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/cate.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/focuspic.php';
}else if($_GET['tmod'] == 'vip'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/vip.php';
}else if($_GET['tmod'] == 'company'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/company.php';
}else if($_GET['tmod'] == 'doDaoZhaopin'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/doDaoZhaopin.php';
}else if($_GET['tmod'] == 'doDaoResume'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/doDaoResume.php';
}else if($_GET['tmod'] == 'jubao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/jubao.php';
}else if($_GET['tmod'] == 'uservip'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/uservip.php';
}else if($_GET['tmod'] == 'meeting'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/meeting.php';
}else if($_GET['tmod'] == 'jianzhi_cate'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/jianzhi_cate.php';
}else if($_GET['tmod'] == 'shenqing'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/shenqing.php';
}else if($_GET['tmod'] == 'vip_code'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/vip_code.php';
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/addon.php';
}else if($_GET['tmod'] == 'popup'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/popup.php';
}else if($_GET['tmod'] == 'setting'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/setting.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/admin/index.php';
}