<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/class/function.core.php';

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.utf.php';
}
$welfareArray = array();
$welfare_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['welfare_list']); 
$welfare_list_str = str_replace("\n","{n}",$welfare_list_str);
$welfare_list_arr = explode("{n}", $welfare_list_str);
if(is_array($welfare_list_arr) && !empty($welfare_list_arr)){
    foreach ($welfare_list_arr as $key => $value){
        $welfare_list_item = explode("|", $value);
        $welfare_list_item_id = intval($welfare_list_item[0]);
        $welfare_list_item_name = trim($welfare_list_item[1]);
        if($welfare_list_item_id > 0 && !empty($welfare_list_item_name)){
            $welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
        }
    }
}

if($_GET['act'] == 'qunfa' && submitcheck('tczhaopin_id')){

    $tczhaopin_id = isset($_GET['tczhaopin_id'])? intval($_GET['tczhaopin_id']): 0;
    
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);
    
    $templateSmsRunUrl = $_G['siteurl']."plugin.php?id=tom_tczhaopin:qunfa&site={$site_id}&act=qunfa_run&tczhaopin_id={$tczhaopin_id}";
    
    if(isset($_SESSION['tom_tczhaopin_tczhaopin_id'.$tczhaopin_id]) && $_SESSION['tom_tczhaopin_tczhaopin_id'.$tczhaopin_id] == 1){
    }else{
        $_SESSION['tom_tczhaopin_tczhaopin_id'.$tczhaopin_id] = 1;
    }
    
    $dingyueListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_dingyue')->fetch_all_list(" AND cate_id = {$tczhaopinInfo['cate_id']} ", 'ORDER BY id DESC', 0, 1000);
    if(is_array($dingyueListTmp) && !empty($dingyueListTmp)){
        foreach($dingyueListTmp as $key => $value){
            $qunfaLogInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_qunfa_log')->fetch_all_list(" AND user_id = {$value['user_id']} AND tczhaopin_id = {$tczhaopin_id} ");
            if($qunfaLogInfoTmp && $qunfaLogInfoTmp['0']['id'] > 0){ }else{
                
                $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
                
                $insertData = array();
                $insertData['tczhaopin_id'] = $tczhaopin_id;
                $insertData['user_id']      = $value['user_id'];
                $insertData['openid']       = $userInfoTmp['openid'];
                $insertData['status']       = 0;
                C::t('#tom_tczhaopin#tom_tczhaopin_qunfa_log')->insert($insertData);
            }
        }
    }
    
    DB::query("UPDATE ".DB::table('tom_tczhaopin')." SET qunfa_status=1 WHERE id='{$tczhaopin_id}'", 'UNBUFFERED');
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $templateSmsRunUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    $return = curl_exec($ch);
    
    echo '200';exit;
    
}else if($_GET['act'] == 'admin_qunfa'){
    
    if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){}else{
        echo 'no uid';exit;
    }

    $tczhaopin_id = isset($_GET['tczhaopin_id'])? intval($_GET['tczhaopin_id']): 0;
    
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);
    
    $templateSmsRunUrl = $_G['siteurl']."plugin.php?id=tom_tczhaopin:qunfa&site={$site_id}&act=qunfa_run&tczhaopin_id={$tczhaopin_id}";
    
    if(isset($_SESSION['tom_tczhaopin_tczhaopin_id'.$tczhaopin_id]) && $_SESSION['tom_tczhaopin_tczhaopin_id'.$tczhaopin_id] == 1){
    }else{
        $_SESSION['tom_tczhaopin_tczhaopin_id'.$tczhaopin_id] = 1;
    }
    
    $dingyueListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_dingyue')->fetch_all_list(" AND cate_id = {$tczhaopinInfo['cate_id']} ", 'ORDER BY id DESC', 0, 1000);
    if(is_array($dingyueListTmp) && !empty($dingyueListTmp)){
        foreach($dingyueListTmp as $key => $value){
            $qunfaLogInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_qunfa_log')->fetch_all_list(" AND user_id = {$value['user_id']} AND tczhaopin_id = {$tczhaopin_id} ");
            if($qunfaLogInfoTmp && $qunfaLogInfoTmp['0']['id'] > 0){ }else{
                
                $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
                
                $insertData = array();
                $insertData['tczhaopin_id'] = $tczhaopin_id;
                $insertData['user_id']      = $value['user_id'];
                $insertData['openid']       = $userInfoTmp['openid'];
                $insertData['status']       = 0;
                C::t('#tom_tczhaopin#tom_tczhaopin_qunfa_log')->insert($insertData);
            }
        }
    }
    
    DB::query("UPDATE ".DB::table('tom_tczhaopin')." SET qunfa_status=1 WHERE id='{$tczhaopin_id}'", 'UNBUFFERED');
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $templateSmsRunUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    $return = curl_exec($ch);
    
    if($return){
        echo $return;exit;
    }else{
        var_dump($return);exit;
    }
    
}else if($_GET['act'] == 'qunfa_run'){

    ignore_user_abort(true);
    set_time_limit(0);

    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/class/log.class.php';

    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $tczhaopin_id = isset($_GET['tczhaopin_id'])? intval($_GET['tczhaopin_id']): 0;
    
    if($page == 1){
        Log::DEBUG("[sms]--------------------- new -------------------------");
    }else if($page == 101){
        Log::DEBUG("[sms]--------------------- over 101 -------------------------");
        exit;
    }
    Log::DEBUG("[sms]tczhaopin_id id:" .$tczhaopin_id);
    Log::DEBUG("[sms]page:" .$page);
    Log::DEBUG("[sms]client IP:" .$_G['clientip']);
    Log::DEBUG("[sms]start:" .time());
    $start_time = time();

    $pagesize = 10;
    $start = ($page-1)*$pagesize;
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);
    $dingyueLogListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_qunfa_log')->fetch_all_list(" AND tczhaopin_id = {$tczhaopin_id} ", 'ORDER BY id DESC', $start, $pagesize); 
    
    $appid = trim($tongchengConfig['wxpay_appid']);  
    $appsecret = trim($tongchengConfig['wxpay_appsecret']);
    
    if(!empty($tczhaopinConfig['template_id'])){
        $template_id = $tczhaopinConfig['template_id'];
    }else{
        $template_id = $tongchengConfig['template_id'];
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $weixinClass = new weixinClass($appid,$appsecret);

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $all_num = $run_num = $ok_num = $no_num = 0;
    $overStatus = 0;
    if(is_array($dingyueLogListTmp) && !empty($dingyueLogListTmp)){
        foreach($dingyueLogListTmp as $key => $value){
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($value['openid']) && $value['status'] == 0){
                
                $tczhaopin_template_url     = tom_link_replace($_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=zhaopininfo&tczhaopin_id={$tczhaopin_id}");
                $templateSmsClass           = new templateSms($access_token, $tczhaopin_template_url);
                $zhaopin_tz_template_first  = str_replace("{TITLE}",$tczhaopinInfo['title'], lang('plugin/tom_tczhaopin', 'qunfa_template_sms'));

                $smsData = array(
                    'first'         => $zhaopin_tz_template_first,
                    'keyword1'      => $tczhaopinConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                    'remark'        => lang('plugin/tom_tczhaopin', 'qunfa_template_remark')
                );
                @$r = $templateSmsClass->sendSms01($value['openid'], $template_id,$smsData);
                if($r){
                    $ok_num ++;
                    $updateData = array();
                    $updateData['status']   = 1;
                    $updateData['log_time'] = TIMESTAMP;
                    C::t('#tom_tczhaopin#tom_tczhaopin_qunfa_log')->update($value['id'], $updateData);
                }else{
                    $updateData = array();
                    $updateData['status']   = 2;
                    $updateData['log_time'] = TIMESTAMP;
                    C::t('#tom_tczhaopin#tom_tczhaopin_qunfa_log')->update($value['id'], $updateData);
                }
                
                $run_num ++;
            }
            $all_num++;
        }
    }else{
        $overStatus = 1;
    }
    
    $end_time = time();
    $run_time = $end_time - $start_time;
    
    Log::DEBUG("[sms]all num:" .$all_num);
    Log::DEBUG("[sms]run num:" .$run_num);
    Log::DEBUG("[sms]ok num:" .$ok_num);
    Log::DEBUG("[sms]no num:" .$no_num);
    Log::DEBUG("[sms]run time:" .$run_time);
    Log::DEBUG("[sms]end:" .time());
    
    if($overStatus == 0){
        $page++;
        $templateSmsRunUrl = $_G['siteurl']."plugin.php?id=tom_tczhaopin:qunfa&site={$site_id}&act=qunfa_run&tczhaopin_id={$tczhaopin_id}&page={$page}";

        Log::DEBUG("[sms]page:" .$templateSmsRunUrl);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $templateSmsRunUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $return = curl_exec($ch);
        var_dump($return);
        if(curl_errno($ch)){
            echo 'Curl error: ' . curl_error($ch);
        }
    }else{
        Log::DEBUG("[sms]over:" .time());
    }
    
    echo '1';exit;
}