<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=jubao'; 
$modListUrl = $adminListUrl.'&tmod=jubao';
$modFromUrl = $adminFromUrl.'&tmod=jubao';

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tczhaopin#tom_tczhaopin_jubao')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $page         = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tczhaopin#tom_tczhaopin_jubao')->fetch_all_count('');
    $jubaoList = C::t('#tom_tczhaopin#tom_tczhaopin_jubao')->fetch_all_list(""," ORDER BY id DESC ",$start,$pagesize);

    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['jubao_user'] . '</th>';
    echo '<th>' . $Lang['jubao_zhaopin'] . '</th>';
    echo '<th>' . $Lang['jubao_contact_type'] . '</th>';
    echo '<th>' . $Lang['jubao_falsity'] . '</th>';
    echo '<th>' . $Lang['jubao_illegality'] . '</th>';
    echo '<th>' . $Lang['jubao_content'] . '</th>';
    echo '<th>' . $Lang['jubao_photo'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';

    $i = 1;
    foreach ($jubaoList as $key => $value) {
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($value['tczhaopin_id']);
        $photoList = C::t('#tom_tczhaopin#tom_tczhaopin_jubao_photo')->fetch_all_list(" AND jubao_id = {$value['id']} "," ORDER BY id ASC ",0,5);
        
        $falsityArr = explode(',', $value['falsity']);
        $illegalityArr = explode(',', $value['illegality']);

        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f00">(ID:'.$value['user_id']. ')</font></td>';
        echo '<td>' . $tczhaopinInfo['title'] .'<font color="#f00">(ID:'.$value['tczhaopin_id']. ')</font></td>';
        if($value['contact_type'] == 1){
            echo '<td>' . $Lang['jubao_contact_type_1'] .'</td>';
        }else if($value['contact_type'] == 2){
            echo '<td>' . $Lang['jubao_contact_type_2'] .'</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>';
        foreach($falsityArr as $kf => $vf){
            echo $falsityArray[$vf].'&nbsp;&nbsp;';
        }
        echo '</td>';
        echo '<td>';
        foreach($illegalityArr as $ki => $vi){
            echo $illegalityArray[$vi].'&nbsp;&nbsp;';
        }
        echo '</td>';
        echo '<td>' . $value['content'] .'</td>';

        echo '<td>';
        foreach($photoList as $kp => $vp){
            echo '<a href="'.tomgetfileurl($vp['picurl']).'" target="_blank"><img src="'.tomgetfileurl($vp['picurl']).'" width="40px" height="40px"></a>&nbsp;';
        }
        echo '</td>';

        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);

    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    
    tomshownavli($Lang['jubao_list_title'],$modBaseUrl,true);
    
    tomshownavfooter();
}