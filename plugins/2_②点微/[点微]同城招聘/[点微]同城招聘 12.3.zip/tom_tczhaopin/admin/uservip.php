<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=uservip'; 
$modListUrl = $adminListUrl.'&tmod=uservip';
$modFromUrl = $adminFromUrl.'&tmod=uservip';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $uservipInfo = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($uservipInfo);
        C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->update($uservipInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($uservipInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $uservipInfo = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_by_id($_GET['id']);
    
    C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->delete_by_id($_GET['id']);
    
    C::t("#tom_tczhaopin#tom_tczhaopin_log")->delete_vip_look_resume_by_user_id($uservipInfo['user_id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'use_list'){
    
    $id     = isset($_GET['id'])? intval($_GET['id']):0;
    $page   = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $uservipInfo = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_by_id($id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($uservipInfo['user_id']);
    
    $pagesize = 1000;
    $start = ($page-1)*$pagesize;
    $logList = C::t('#tom_tczhaopin#tom_tczhaopin_log')->fetch_all_list(" AND user_id = {$uservipInfo['user_id']} "," ORDER BY id DESC ",$start,$pagesize);
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' .$userInfo['nickname'].'&nbsp;&gt;&gt;&nbsp;'. $Lang['uservip_uselist'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['uselist_deduct_type'] . '</th>';
    echo '<th>' . $Lang['uselist_type'] . '</th>';
    echo '<th>' . $Lang['uselist_log_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($logList as $key => $value) {
        
        echo '<tr>';
        echo '<td> '.$value['id'].' </td>';
        if($value['deduct_type'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['uselist_deduct_type_1'] . '</font></td>';
        }else if($value['deduct_type'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['uselist_deduct_type_2'] . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if($value['type'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['uselist_type_1'] . '(ID:' .$value['tczhaopin_id']. ')</font></td>';
        }else if($value['type'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['uselist_type_2'] . '(ID:' .$value['tczhaopin_id']. ')</font></td>';
        }else if($value['type'] == 3){
            echo '<td><font color="#0a9409">' . $Lang['uselist_type_3'] . '(ID:' .$value['resume_id']. ')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . dgmdate($value['log_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td> -- </td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['act'] == 'pay_list'){
    
    $id     = isset($_GET['id'])? intval($_GET['id']):0;
    $page   = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $uservipInfo = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_by_id($id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($uservipInfo['user_id']);
    
    $pagesize = 30;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_all_count(" AND user_id = {$uservipInfo['user_id']} AND type = 6 AND order_status = 2 ");
    $orderList = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_all_list(" AND user_id = {$uservipInfo['user_id']} AND type = 6 AND order_status = 2 "," ORDER BY id DESC ",$start,$pagesize);
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' .$userInfo['nickname'].'&nbsp;&gt;&gt;&nbsp;'. $Lang['uservip_paylist'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['order_no'] . '</th>';
    echo '<th>' . $Lang['paylist_vip'] . '</th>';
    echo '<th>' . $Lang['order_pay_price'] . '</th>';
    echo '<th>' . $Lang['order_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($orderList as $key => $value) {
        
        $vipInfo = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_by_id($value['vip_id']);
        
        echo '<tr>';
        echo '<td> '.$value['id'].' </td>';
        echo '<td> '.$value['order_no'].' </td>';
        echo '<td> '.$vipInfo['title'].'(ID:'.$value['vip_id'].') </td>';
        echo '<td> '.$value['pay_price'].' </td>';
        echo '<td>' . dgmdate($value['order_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td> -- </td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl.'&act=pay_list&id='.$id);	
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    $site_id      = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $page         = intval($_GET['page'])>0? intval($_GET['page']):1;
    $user_id      = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if($user_id > 0){
        $where.= " AND user_id={$user_id} ";
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_all_count($where);
    $uservipList = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';
    echo $userStr;
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['uservip_user'] . '</th>';
    echo '<th>' . $Lang['uservip_vip'] . '</th>';
    echo '<th>' . $Lang['uservip_expire_status'] . '</th>';
    echo '<th>' . $Lang['uservip_expire_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($uservipList as $key => $value) {
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $vipInfo = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_by_id($value['vip_id']);
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f00">(ID:' .$value['user_id']. ')</font></td>';
        echo '<td>' . $vipInfo['title'] .'<font color="#f00">(ID:' .$value['vip_id']. ')</font></td>';
        if($value['expire_status'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['uservip_expire_status_1']. '</font></td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['uservip_expire_status_0']. '</font></td>';
        }
        echo '<td>' . dgmdate($value['expire_time'], 'Y-m-d H:i:s',$tomSysOffset). '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=use_list&id='.$value['id'].'">' . $Lang['uservip_uselist']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=pay_list&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['uservip_paylist']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $vip_id         = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $expire_status  = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
    $expire_time    = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time    = strtotime($expire_time);
    

    $data['user_id']        = $user_id;
    $data['vip_id']         = $vip_id;
    $data['expire_status']  = $expire_status;
    $data['expire_time']    = $expire_time;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'user_id'           => '',
        'vip_id'            => 0,
        'expire_time'       => 0,
        'expire_status'     => 0,
    );
    
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['uservip_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['uservip_user_id_msg']),"input");
    
    $vipList = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_all_list(" "," ORDER BY tsort ASC,id DESC ",0,100);
    $vipStr = '<tr class="header"><th>'.$Lang['uservip_vip'].'</th><th></th></tr>';
    $vipStr.= '<tr><td width="300"><select style="width: 150px;" name="vip_id" id="vip_id" >';
    $vipStr.=  '<option value="0">'.$Lang['uservip_vip_all'].'</option>';
    foreach ($vipList as $key => $value){
        if($value['id'] == $options['vip_id']){
            $vipStr.=  '<option value="'.$value['id'].'" selected>'.$value['title'].'</option>';
        }else{
            $vipStr.=  '<option value="'.$value['id'].'">'.$value['title'].'</option>';
        }
    }
    $vipStr.= '</select></td><td>'.$Lang['uservip_vip_msg'].'</td></tr>';
    echo $vipStr;
    
    $expire_status_item = array(1=>$Lang['uservip_expire_status_1'],0=>$Lang['uservip_expire_status_0']);
    tomshowsetting(true,array('title'=>$Lang['uservip_expire_status'],'name'=>'expire_status','value'=>$options['expire_status'],'msg'=>$Lang['uservip_expire_status_msg'],'item'=>$expire_status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['uservip_expire_time'],'name'=>'expire_time','value'=>$options['expire_time'],'msg'=>$Lang['uservip_expire_time_msg']),"calendar");
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['uservip_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['uservip_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['uservip_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['uservip_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['uservip_edit'],"",true);
    }else{
        tomshownavli($Lang['uservip_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['uservip_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}