<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=vip';
$modListUrl = $adminListUrl.'&tmod=vip';
$modFromUrl = $adminFromUrl.'&tmod=vip';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tczhaopin#tom_tczhaopin_vip')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $vipInfo = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($vipInfo);
        C::t('#tom_tczhaopin#tom_tczhaopin_vip')->update($vipInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($vipInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tczhaopin#tom_tczhaopin_vip')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $vipList = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_all_list(""," ORDER BY tsort ASC,id DESC ",$start,$pagesize);
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['vip_title'] . '</th>';
    echo '<th>' . $Lang['vip_days'] . '</th>';
    echo '<th>' . $Lang['vip_fabu_num'] . '</th>';
    echo '<th>' . $Lang['vip_resume_num'] . '</th>';
    echo '<th>' . $Lang['vip_refresh_num'] . '</th>';
    echo '<th>' . $Lang['vip_top_zhekou'] . '</th>';
    echo '<th>' . $Lang['vip_auto_refresh'] . '</th>';
    echo '<th>' . $Lang['vip_price'] . '</th>';
    echo '<th>' . $Lang['vip_max_num'] . '</th>';
    echo '<th>' . $Lang['vip_status'] . '</th>';
    echo '<th>' . $Lang['paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($vipList as $key => $value) {
        
        $top_zhekou = $value['top_zhekou'] / 10;
        if($top_zhekou < 100){
            $top_zhekou = trim($top_zhekou, '.0');
        }
        
        echo '<tr>';
        echo '<td>' . $value['title'] . '</td>';
        echo '<td>' . $value['days'] . '</td>';
        echo '<td>' . $value['fabu_num'] . '</td>';
        echo '<td>' . $value['resume_num'] . '</td>';
        echo '<td>' . $value['refresh_num'] . '</td>';
        if($value['top_zhekou'] > 0){
            echo '<td>' . $top_zhekou .$Lang['zhe']. '</td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['auto_refresh'] == 1){
            echo '<td><font color="#0a9409">' .$Lang['vip_auto_refresh_1']. '</font></td>';
        }else{
            echo '<td><font color="#f70404"">' .$Lang['vip_auto_refresh_0']. '</font></td>';
        }
        echo '<td><font color="#f00">' . $value['price'] . '</font></td>';
        if($value['max_num'] > 0){
            echo '<td>' . $value['max_num'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['status'] == 1){
            echo '<td><font color="#0a9409">' .$Lang['vip_status_1']. '</font></td>';
        }else{
            echo '<td><font color="#f70404"">' .$Lang['vip_status_0']. '</font></td>';
        }
        echo '<td>' . $value['tsort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $days               = isset($_GET['days'])? intval($_GET['days']):0;
    $auto_refresh       = isset($_GET['auto_refresh'])? intval($_GET['auto_refresh']):0;
    $fabu_num           = isset($_GET['fabu_num'])? intval($_GET['fabu_num']):0;
    $resume_num         = isset($_GET['resume_num'])? intval($_GET['resume_num']):0;
    $refresh_num        = isset($_GET['refresh_num'])? intval($_GET['refresh_num']):0;
    $top_zhekou         = isset($_GET['top_zhekou'])? intval($_GET['top_zhekou']):0;
    $price              = isset($_GET['price'])? floatval($_GET['price']):0.00;
    $market_price       = isset($_GET['market_price'])? floatval($_GET['market_price']):0.00;
    $max_num            = isset($_GET['max_num'])? intval($_GET['max_num']):0;
    $beizu              = isset($_GET['beizu'])? addslashes($_GET['beizu']):'';
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $tsort              = isset($_GET['tsort'])? intval($_GET['tsort']):10;
    
    if($top_zhekou < 10 || $top_zhekou > 100){
        $top_zhekou = 0;
    }
    
    $data['title']              = $title;
    $data['days']               = $days;
    $data['auto_refresh']       = $auto_refresh;
    $data['fabu_num']           = $fabu_num;
    $data['resume_num']         = $resume_num;
    $data['refresh_num']        = $refresh_num;
    $data['top_zhekou']         = $top_zhekou;
    $data['price']              = $price;
    $data['market_price']       = $market_price;
    $data['max_num']            = $max_num;
    $data['beizu']              = $beizu;
    $data['status']             = $status;
    $data['tsort']              = $tsort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'title'             => '',
        'days'              => 0,
        'auto_refresh'      => 0,
        'fabu_num'          => 0,
        'resume_num'        => 0,
        'refresh_num'       => 0,
        'top_zhekou'        => 0,
        'price'             => '',
        'market_price'      => '',
        'max_num'           => 0,
        'beizu'             => '',
        'status'            => 1,
        'tsort'             => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['vip_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['vip_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_days'],'name'=>'days','value'=>$options['days'],'msg'=>$Lang['vip_days_msg']),"input");
    
    $auto_refresh_item = array(0=>$Lang['vip_auto_refresh_0'],1=>$Lang['vip_auto_refresh_1']);
    tomshowsetting(true,array('title'=>$Lang['vip_auto_refresh'],'name'=>'auto_refresh','value'=>$options['auto_refresh'],'msg'=>$Lang['vip_auto_refresh_msg'],'item'=>$auto_refresh_item),"radio");
    
    tomshowsetting(true,array('title'=>$Lang['vip_fabu_num'],'name'=>'fabu_num','value'=>$options['fabu_num'],'msg'=>$Lang['vip_fabu_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_resume_num'],'name'=>'resume_num','value'=>$options['resume_num'],'msg'=>$Lang['vip_resume_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_refresh_num'],'name'=>'refresh_num','value'=>$options['refresh_num'],'msg'=>$Lang['vip_refresh_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_top_zhekou'],'name'=>'top_zhekou','value'=>$options['top_zhekou'],'msg'=>$Lang['vip_top_zhekou_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_price'],'name'=>'price','value'=>$options['price'],'msg'=>$Lang['vip_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_market_price'],'name'=>'market_price','value'=>$options['market_price'],'msg'=>$Lang['vip_market_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_max_num'],'name'=>'max_num','value'=>$options['max_num'],'msg'=>$Lang['vip_max_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_beizu'],'name'=>'beizu','value'=>$options['beizu'],'msg'=>$Lang['vip_beizu_msg']),"textarea");
    
    $status_item = array(0=>$Lang['vip_status_0'],1=>$Lang['vip_status_1']);
    tomshowsetting(true,array('title'=>$Lang['vip_status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['vip_status_msg'],'item'=>$status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['paixu'],'name'=>'tsort','value'=>$options['tsort'],'msg'=>$Lang['vip_tsort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['vip_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['vip_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['vip_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['vip_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['vip_edit'],"",true);
    }else{
        tomshownavli($Lang['vip_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['vip_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['code_list_title'],$adminBaseUrl."&tmod=vip_code",false);
    }
    tomshownavfooter();
}