<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=shenqing';
$modListUrl = $adminListUrl.'&tmod=shenqing';
$modFromUrl = $adminFromUrl.'&tmod=shenqing';

if($_GET['act'] == 'add'){
    
}else{
    
    $tczhaopin_id   = isset($_GET['tczhaopin_id'])? intval($_GET['tczhaopin_id']):0;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;
	
	$where = '';
	if($tczhaopin_id > 0){
		$where .= "AND tczhaopin_id = {$tczhaopin_id}";
	}
    if($status > 0){
        if($status == 1){
            $where .= " AND status = 1"; 
        }else if($status == 2){
            $where .= " AND status = 0";
        }
    }

    $count = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_count($where);
    $shenqingList = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    
	$modBasePageUrl = $modBaseUrl."&tczhaopin_id={$tczhaopin_id}&status={$status}";

    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['shenqing_tczhaopin_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="tczhaopin_id" value="'.$tczhaopin_id.'"></td></tr>';
    
    $status_1 = $status_2 = '';
    if($status == 1){
        $status_1 = 'selected';
    }else if($status == 2){
        $status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['shenqing_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['shenqing_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['shenqing_status_0'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    tomshownavheader();
    tomshownavli($Lang['shenqing_title'],$adminBaseUrl.'&tmod=shenqing',true);
    tomshownavfooter();
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th> '.$Lang['shenqing_tczhaopin'].' </th>';
    echo '<th> '.$Lang['shenqing_resume'].' </th>';
    echo '<th> '.$Lang['shenqing_status'].' </th>';
    echo '<th> '.$Lang['shenqing_add_time'].' </th>';
    echo '</tr>';
   
    $i = 1;
	foreach ($shenqingList as $key => $value) {

        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $zhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($value['tczhaopin_id']);
        $resumeInfo = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($value['resume_id']);
        
        echo '<tr>';
        echo '<td> '.$value['id'].' </td>';
        echo '<td><a href="'.$adminBaseUrl.'&tmod=index&tczhaopin_id='.$zhaopinInfo['id'].'" target="_blank">'.$zhaopinInfo['title'].'(ID:' .$value['tczhaopin_id']. ')</a></td>';
        echo '<td><a href="'.$adminBaseUrl.'&tmod=resume&resume_id='.$value['resume_id'].'" target="_blank">'.$resumeInfo['name'].'(ID:' .$value['resume_id']. ')</a></td>';

        if($value['status'] == 1){
            echo '<td><font color="#0a9409"> '.$Lang['shenqing_status_1'].' </font></td>';
        }else{
            echo '<td><font color="#f70404"> '.$Lang['shenqing_status_0'].' </font></td>';
        }
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '</tr>';
        $i++;
    }

    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}