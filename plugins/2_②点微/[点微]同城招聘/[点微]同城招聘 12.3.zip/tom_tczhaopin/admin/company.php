<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=company'; 
$modListUrl = $adminListUrl.'&tmod=company';
$modFromUrl = $adminFromUrl.'&tmod=company';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $insertData = array();
        $insertData = __get_post_data();
        
        $renzhengCompanyInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_user_id($insertData['user_id']);
        if(is_array($renzhengCompanyInfo) && !empty($renzhengCompanyInfo)){
            $insertData['renzheng_company_id'] = $renzhengCompanyInfo['id'];
        }
        
        $insertData['add_time'] = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_company')->insert($insertData)){
            $company_id = C::t('#tom_tczhaopin#tom_tczhaopin_company')->insert_id();
            $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($company_id);
            update_company_status($companyInfo);
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($companyInfo);
        if(C::t('#tom_tczhaopin#tom_tczhaopin_company')->update($companyInfo['id'],$updateData)){
            $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($companyInfo['id']);
            update_company_status($companyInfo);
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($companyInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tczhaopin#tom_tczhaopin_company')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'edittop'){
    $info = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $top_time     = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
        $top_time     = strtotime($top_time);
        $updateData = array();
        if($top_time <= TIMESTAMP){
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
        }else{
            $updateData['top_status']   = 1;
            $updateData['top_time']     = $top_time;
        }
        C::t('#tom_tczhaopin#tom_tczhaopin_company')->update($_GET['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edittop&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_top_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_top_time'],'name'=>'top_time','value'=>$info['top_time'],'msg'=>$Lang['edit_top_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'edituser'){
    $info = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
        
        if($info['user_id'] == $user_id){
            cpmsg($Lang['company_edituser_error1'], $modListUrl, 'error');exit;
        }
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
        if($userInfo && $userInfo['id'] > 0){}else{
            cpmsg($Lang['company_edituser_error2'], $modListUrl, 'error');exit;
        }
        $isHaveCompany = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($user_id);
        if($isHaveCompany && $isHaveCompany['id'] > 0 && $isHaveCompany['renzheng_company_id'] > 0){
            cpmsg($Lang['company_edituser_error3'], $modListUrl, 'error');exit;
        }else{
            if($isHaveCompany && $isHaveCompany['id'] > 0){
                C::t('#tom_tczhaopin#tom_tczhaopin_company')->delete_by_id($isHaveCompany['id']);
            }
        }
        $renzhengCompanyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($user_id);
        if($renzhengCompanyInfo && $renzhengCompanyInfo['id'] > 0 && $renzhengCompanyInfo['shenhe_status'] == 1){
            cpmsg($Lang['company_edituser_error4'], $modListUrl, 'error');exit;
        }else{
            if($renzhengCompanyInfo && $renzhengCompanyInfo['id'] > 0){
                C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->delete_by_id($renzhengCompanyInfo['id']);
                C::t('#tom_tcrenzheng#tom_tcrenzheng_company_photo')->delete_by_company_id($renzhengCompanyInfo['id']);
            }
        }
        
        DB::query("UPDATE ".DB::table('tom_tcrenzheng_company')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        
        DB::query("UPDATE ".DB::table('tom_tczhaopin')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tczhaopin_company')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tczhaopin_history')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tczhaopin_log')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tczhaopin_order')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tczhaopin_rencai')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tczhaopin_meeting_company')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tczhaopin_mianshi')." SET yaoqing_user_id={$user_id} WHERE yaoqing_user_id='{$info['user_id']}'", 'UNBUFFERED');
        
        $userVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($user_id);
        if($userVipInfo && $userVipInfo['id'] > 0 && $userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
        }else{
            if($userVipInfo && $userVipInfo['id'] > 0){
                C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->delete_by_id($userVipInfo['id']);
            }
            DB::query("UPDATE ".DB::table('tom_tczhaopin_user_vip')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edituser&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['company_edituser_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['company_edituser'],'name'=>'user_id','value'=>$info['user_id'],'msg'=>$Lang['company_edituser_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else{
    
    $company_name   = isset($_GET['company_name'])? addslashes($_GET['company_name']):'';
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $show_status    = isset($_GET['show_status'])? intval($_GET['show_status']):0;
    $tuijian_status = isset($_GET['tuijian_status'])? intval($_GET['tuijian_status']):0;
    $top_status     = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "AND renzheng_company_id > 0";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if($user_id > 0){
        $where.= " AND user_id={$user_id} ";
    }
    if(!empty($company_name)){
        $companyListTmp  = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_list("","ORDER BY id DESC",0,100,$company_name);
        $companyListIds = array();
        if(is_array($companyListTmp) && !empty($companyListTmp)){
            foreach ($companyListTmp as $key => $value){
                $companyListIds[] = $value['id'];
            }
            $where.= " AND renzheng_company_id IN (".  implode(',', $companyListIds).") ";
        }else{
            $where.= " AND renzheng_company_id = 99999999999 ";
        }
    }
    if($show_status > 0){
        if($show_status == 1){
            $where.= " AND show_status = 1 ";
        }else if($show_status == 2){
            $where.= " AND show_status = 0 ";
        }
    }
    if($tuijian_status > 0){
        if($tuijian_status == 1){
            $where.= " AND tuijian_status = 1 ";
        }else if($tuijian_status == 2){
            $where.= " AND tuijian_status = 0 ";
        }
    }
    if($top_status > 0){
        if($top_status == 1){
            $where.= " AND top_status = 1 ";
        }else if($top_status == 2){
            $where.= " AND top_status = 0 ";
        }
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_all_count($where);
    $companyList = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_all_list($where," ORDER BY csort ASC,id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&user_id={$user_id}&show_status={$show_status}&tuijian_status={$tuijian_status}&top_status={$top_status}";
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['company_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><font color="#fd0d0d"><b>'.$Lang['company_help_1'].'</b></font></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    $site_1 = '';
    if($site_id == 1){
        $site_1 = 'selected';
    }
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['company_name'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="company_name" value="'.$company_name.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $status_1 = $status_2 = '';
    if($show_status == 1){
        $status_1 = 'selected';
    }else if($show_status == 2){
        $status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="show_status" id="show_status">';
    $statusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['index_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['index_status_0'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    $tuijian_status_1 = $tuijian_status_0 = '';
    if($tuijian_status == 1){
        $tuijian_status_1 = 'selected';
    }else if($tuijian_status == 2){
        $tuijian_status_0 = 'selected';
    }
    $tuijianStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['company_tuijian_status'].'</b></td>';
    $tuijianStatusStr.= '<td><select style="width: 260px;" name="tuijian_status" id="tuijian_status">';
    $tuijianStatusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $tuijianStatusStr.=  '<option value="1" '.$tuijian_status_1.'>'.$Lang['company_tuijian_status_1'].'</option>';
    $tuijianStatusStr.=  '<option value="2" '.$tuijian_status_0.'>'.$Lang['company_tuijian_status_0'].'</option>';
    $tuijianStatusStr.= '</select></td></tr>';
    echo $tuijianStatusStr;
    
    $top_status_1 = $top_status_0 = '';
    if($top_status == 1){
        $top_status_1 = 'selected';
    }else if($top_status == 2){
        $top_status_0 = 'selected';
    }
    $topStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['top_status'].'</b></td>';
    $topStatusStr.= '<td><select style="width: 260px;" name="top_status" id="top_status">';
    $topStatusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $topStatusStr.=  '<option value="1" '.$top_status_1.'>'.$Lang['top_status_1'].'</option>';
    $topStatusStr.=  '<option value="2" '.$top_status_0.'>'.$Lang['top_status_0'].'</option>';
    $topStatusStr.= '</select></td></tr>';
    echo $topStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['company_user'] . '</th>';
    echo '<th>' . $Lang['company_name'] . '</th>';
    echo '<th>' . $Lang['company_num'] . '</th>';
    echo '<th>' . $Lang['company_show_status'] . '</th>';
    echo '<th>' . $Lang['company_tuijian_status'] . '</th>';
    echo '<th>' . $Lang['company_top_status'] . '</th>';
    echo '<th>' . $Lang['company_csort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($companyList as $key => $value) {
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $renzhengCompanyInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($value['renzheng_company_id']);
        $zhaopinCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$value['user_id']} ");
        
        update_company_status($value);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $userInfo['nickname'] .'<font color="#f00">(ID:' .$value['user_id']. ')</font>&nbsp;<a href="'.$modBaseUrl.'&act=edituser&id='.$value['id'].'&formhash='.FORMHASH.'">(' . $Lang['company_edituser_title']. ')</a></td>';
        if($renzhengCompanyInfo['id'] > 0){
            echo '<td>' . $renzhengCompanyInfo['name'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td> '.$value['num'].' </td>';
        if($value['show_status'] == 1){
            echo '<td><font color="#0a9409">' .$Lang['company_show_status_1']. '</font></td>';
        }else{
            echo '<td><font color="#f70404"">' .$Lang['company_show_status_0']. '</font></td>';
        }
        if($value['tuijian_status'] == 1){
            echo '<td><font color="#0a9409">' .$Lang['company_tuijian_status_1']. '</font></td>';
        }else{
            echo '<td><font color="#f70404"">' .$Lang['company_tuijian_status_0']. '</font></td>';
        }
        
        if($value['top_status'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['company_top_status_1'].'</font> <font color="#f70404">('.dgmdate($value['top_time'], 'Y-m-d H:i:s',$tomSysOffset).')</font></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['company_top_status_0'].'</font></td>';
        }
        echo '<td>' . $value['csort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$adminBaseUrl.'&tmod=index&act=add&company_id='.$value['id'].'&formhash='.FORMHASH.'" target="_blank">' . $Lang['index_add']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edittop&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_top_title']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['company_edit']. '</a>';
        if(intval($zhaopinCount) == 0){
            echo '&nbsp;|&nbsp;<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        }
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id       = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    //$user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $tuijian_status = isset($_GET['tuijian_status'])? intval($_GET['tuijian_status']):0;
    $csort          = isset($_GET['csort'])? intval($_GET['csort']):100;
    
    $data['site_id']    = $site_id;
    //$data['user_id']        = $user_id;
    $data['tuijian_status'] = $tuijian_status;
    $data['csort']          = $csort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'site_id'           => 1,
        'user_id'           => '',
        'tuijian_status'    => 0,
        'csort'             => 100,
    );
    
    $options = array_merge($options, $infoArr);
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    //tomshowsetting(true,array('title'=>$Lang['company_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['company_user_id_msg']),"input");
    $tuijian_status_item = array(0=>$Lang['company_tuijian_status_0'],1=>$Lang['company_tuijian_status_1']);
    tomshowsetting(true,array('title'=>$Lang['company_tuijian_status'],'name'=>'tuijian_status','value'=>$options['tuijian_status'],'msg'=>$Lang['company_tuijian_status_msg'],'item'=>$tuijian_status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['company_csort'],'name'=>'csort','value'=>$options['csort'],'msg'=>$Lang['company_csort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['company_list_title'],$modBaseUrl,false);
        //tomshownavli($Lang['company_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['company_list_title'],$modBaseUrl,false);
        //tomshownavli($Lang['company_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['company_edit'],"",true);
    }else{
        tomshownavli($Lang['company_list_title'],$modBaseUrl,true);
        //tomshownavli($Lang['company_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}