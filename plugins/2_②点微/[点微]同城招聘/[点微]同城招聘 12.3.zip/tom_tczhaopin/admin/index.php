<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_tczhaopin_admin_index_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'info'){
    
    $info = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($_GET['id']);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($info['user_id']);
    $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($info['cate_id']);
    $cateChildInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($info['cate_child_id']);
    $jianzhiCateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_by_id($info['jianzhi_cate_id']);
    $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($info['area_id']);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($info['street_id']);
    $natureInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_nature')->fetch_by_id($info['company_nature_id']);
    $industryInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_by_id($info['company_industry_id']);
    $scaleInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_scale')->fetch_by_id($info['company_scale_id']);
    $photoList = C::t('#tom_tczhaopin#tom_tczhaopin_photo')->fetch_all_list(" AND tczhaopin_id = {$_GET['id']} "," ORDER BY psort ASC,id ASC ",$start,$pagesize);
    
    $workWelfareArr = explode('-', trim($info['work_welfare'], '-'));
    $welfareList = array();
    if(is_array($welfareArray) && !empty($welfareArray)){
        foreach($welfareArray as $key => $value){
            if(in_array($key,$workWelfareArr)){
                $welfareList[$key]['name'] = $value;
            }
        }
    }
    
    $fenghao = $Lang['fenghao'];
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['info'] . '</th></tr>';
    echo '<tr><td style="width: 120px;" align="right"><b>'.$Lang['index_info_title'].$fenghao.'</b></td><td>'.$info['title'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_info_user'].$fenghao.'</b></td><td>'.$userInfo['nickname'].' <font color="#f00">(ID:'.$info['user_id'].')</font></td></tr>';
    if($info['type'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_type'].$fenghao.'</b></td><td>'.$Lang['index_type_1'].'</td></tr>';
    }else if($info['type'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['index_type'].$fenghao.'</b></td><td>'.$Lang['index_type_2'].'</td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['index_type'].$fenghao.'</b></td><td> -- </td></tr>';
    }
    if($info['type'] == 2 && $info['jianzhi_cate_id'] > 0){
        echo '<tr><td align="right"><b>'.$Lang['index_info_cate'].$fenghao.'</b></td><td>'.$jianzhiCateInfo['name'].'</td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['index_info_cate'].$fenghao.'</b></td><td>'.$cateInfo['name'].'-'.$cateChildInfo['name'].'</td></tr>';
    }
    if($info['type'] == 2 && $info['jianzhi_work_salary'] > 0){
        echo '<tr><td align="right"><b>'.$Lang['index_info_work_salary'].$fenghao.'</b></td><td>'.$info['jianzhi_work_salary'].$jianzhiJieSuanUnitArray[$info['jianzhi_work_salary_unit']].'('.$jianzhiJieSuanFangshiArray[$info['jianzhi_jiesuan_fangshi']].')</td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['index_info_work_salary'].$fenghao.'</b></td><td>'.$workSalaryArray[$info['work_salary']].'</td></tr>';
    }
    echo '<tr><td align="right"><b>'.$Lang['index_info_renshu'].$fenghao.'</b></td><td>'.$info['renshu'].'</td></tr>';
    if($info['type'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_info_work_welfare'].$fenghao.'</b></td><td>';
        if(is_array($welfareList) && !empty($welfareList)){
            foreach($welfareList as $key => $value){
                echo '<span style="display:inline-block; margin-right:10px; line-height:20px; padding:0 10px; border:1px solid #f5833b; color:#f5833b">'.$value['name'].'</span>';
            }
        }
        echo '</td></tr>';
    }
    if($info['shenhe_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_shenhe_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['index_shenhe_status_1'].'</font></td></tr>';
    }else if($info['shenhe_status'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['index_shenhe_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['index_shenhe_status_2'].'</font></td></tr>';
    }else if($info['shenhe_status'] == 3){
        echo '<tr><td align="right"><b>'.$Lang['index_shenhe_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['index_shenhe_status_3'].'</font></td></tr>';
    }
     
    if($info['pay_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_pay_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['index_pay_status_1'].'</font></td></tr>';
    }else if($info['pay_status'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['index_pay_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['index_pay_status_2'].'</font></td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['index_pay_status'].$fenghao.'</b></td><td>-</td></tr>';
    }
    
    if($info['expire_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_expire_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['index_expire_status_1'].'('.dgmdate($info['expire_time'], 'Y-m-d H:i:s',$tomSysOffset).')</font></td></tr>';
    }else if($info['expire_status'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['index_expire_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['index_expire_status_2'].'</font></td></tr>';
    }else if($info['expire_status'] == 3){
        echo '<tr><td align="right"><b>'.$Lang['index_expire_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['index_expire_status_3'].'</font></td></tr>';
    }
    
    if($info['top_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['top_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['top_status_1'].'('.dgmdate($info['top_time'], 'Y-m-d H:i:s',$tomSysOffset).')</font></td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['top_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['top_status_0'].'</font></td></tr>';
    }
    
    echo '<tr><td align="right"><b>'.$Lang['index_info_refresh_time'].$fenghao.'</b></td><td>'.dgmdate($info['refresh_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_info_add_time'].$fenghao.'</b></td><td>'.dgmdate($info['add_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
    
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_demand_title'] . '</th></tr>';
    if($info['demand_sex'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['order_info_demand_sex'].$fenghao.'</b></td><td>'.$Lang['order_info_demand_sex_1'].'</td></tr>';
    }else if($info['demand_sex'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['order_info_demand_sex'].$fenghao.'</b></td><td>'.$Lang['order_info_demand_sex_2'].'</td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['order_info_demand_sex'].$fenghao.'</b></td><td>'.$Lang['order_info_buxian'].'</td></tr>';
    }
    if($info['demand_xueli'] > 0){
        echo '<tr><td align="right"><b>'.$Lang['order_info_demand_xueli'].$fenghao.'</b></td><td>'.$xueliArray[$info['demand_xueli']].'</td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['order_info_demand_xueli'].$fenghao.'</b></td><td>'.$Lang['order_info_buxian'].'</td></tr>';
    }
    if($info['demand_jingyan'] > 0){
        echo '<tr><td align="right"><b>'.$Lang['order_info_demand_jingyan'].$fenghao.'</b></td><td>'.$workJingyanArray[$info['demand_jingyan']].'</td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['order_info_demand_jingyan'].$fenghao.'</b></td><td>'.$Lang['order_info_buxian'].'</td></tr>';
    }
    if($info['demand_ages'] > 0){
        echo '<tr><td align="right"><b>'.$Lang['order_info_demand_ages'].$fenghao.'</b></td><td>'.$agesArray[$info['demand_ages']].'</td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['order_info_demand_ages'].$fenghao.'</b></td><td>'.$Lang['order_info_buxian'].'</td></tr>';
    }
    echo '<tr><td align="right"><b>'.$Lang['order_info_demand_desc'].$fenghao.'</b></td><td>'.$info['demand_desc'].'</td></tr>';
    if($info['video_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_video_url'].$fenghao.'</b></td><td><a href="'.$info['video_url'].'" target="_blank">'.$info['video_url'].'</a></td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['index_video_pic'].$fenghao.'</b></td><td><a href="'.tomgetfileurl($info['video_pic']).'" target="_blank"><img height="120" src="'.tomgetfileurl($info['video_pic']).'"></a></td></tr>';
    }
    
    if(is_array($photoList) && !empty($photoList)){
        echo '<tr><td align="right"><b>'.$Lang['index_photo'].$fenghao.'</b></td><td>';
        foreach($photoList as $key => $value){
            echo '<a href="'.$value['picurlTmp'].'" target="_blank"><img height="80" src="'.$value['picurlTmp'].'"></a>&nbsp;&nbsp;';
        }
        echo '</td></tr>';
    }
    
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_company_title'] . '</th></tr>';
    echo '<tr><td align="right"><b>'.$Lang['order_info_company_name'].$fenghao.'</b></td><td>'.$info['company_name'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['order_info_company_quyu'].$fenghao.'</b></td><td>'.$areaInfo['name'].'-'.$streetInfo['name'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['order_info_address'].$fenghao.'</b></td><td>'.$info['address'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['order_info_xm'].$fenghao.'</b></td><td>'.$info['xm'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['order_info_tel'].$fenghao.'</b></td><td>'.$info['tel'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['order_info_company_nature'].$fenghao.'</b></td><td>'.$natureInfo['name'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['order_info_company_industry'].$fenghao.'</b></td><td>'.$industryInfo['name'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['order_info_company_scale'].$fenghao.'</b></td><td>'.$scaleInfo['name'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['order_info_company_introduce'].$fenghao.'</b></td><td>'.$info['company_introduce'].'</td></tr>';
    showtablefooter(); /*dism��taobao��com*/

}else if($_GET['act'] == 'add'){
    $company_id = intval($_GET['company_id'])>0 ? intval($_GET['company_id']):0;
    
    if(submitcheck('submit')){
        $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
        $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
        $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
        $expire_status  = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
        $expire_time    = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
        $expire_time    = strtotime($expire_time);
        
        $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($user_id);
        if(is_array($companyInfo) && !empty($companyInfo)){ 
            update_company_status($companyInfo);
        }else{
            $insertData = array();
            $insertData['site_id']              = $site_id;
            $insertData['user_id']              = $user_id;
            $insertData['add_time']             = TIMESTAMP;
            if(C::t('#tom_tczhaopin#tom_tczhaopin_company')->insert($insertData)){
                $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($user_id);
                update_company_status($companyInfo);
            }
        }
        
        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['user_id']          = $user_id;
        $insertData['company_id']       = $companyInfo['id'];
        $insertData['title']            = $title;
        if($expire_status == 3){
            $insertData['expire_status']        = $expire_status;
        }else{
            if($expire_time < TIMESTAMP){
                $insertData['expire_status']    = 2;
                $insertData['expire_time']      = 0;
            }else{
                $insertData['expire_status']    = 1;
                $insertData['expire_time']      = $expire_time;
            }
        }
        
        $insertData['shenhe_status']    = 2;
        $insertData['status']           = 0;
        $insertData['refresh_time']     = TIMESTAMP;
        $insertData['add_time']         = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin')->insert($insertData)){
           $tczhaopin_id = C::t('#tom_tczhaopin#tom_tczhaopin')->insert_id();
            cpmsg($Lang['act_success'], $modListUrl.'&act=edit&id='.$tczhaopin_id, 'succeed');
        }else{
            cpmsg($Lang['index_add_error'], $modListUrl.'&act=add', 'error');
        }
        
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add&company_id='.$company_id,'enctype');
        showtableheader();
        
        $user_id = 0;
        if($company_id > 0){
            $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($company_id);
            $user_id = $companyInfo['user_id'];
        }
        
        $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
        $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
        $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id">';
        $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
        foreach ($sitesList as $key => $value){
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
        $sitesStr.= '</select></td><td></td></tr>';
        echo $sitesStr;
        
        tomshowsetting(true,array('title'=>$Lang['index_user'],'name'=>'user_id','value'=>$user_id,'msg'=>$Lang['index_user_msg']),"input");
        if($company_id > 0){
            tomshowsetting(true,array('title'=>$Lang['index_company_id'],'name'=>'company_id','value'=>$company_id,'msg'=>$Lang['index_company_id_msg']),"input");
        }
        tomshowsetting(true,array('title'=>$Lang['index_title'],'name'=>'title','value'=>'','msg'=>$Lang['index_title_msg']),"input");
        $expire_status_item = array(1=>$Lang['index_expire_status_1'], 2=>$Lang['index_expire_status_2'], 3=>$Lang['index_expire_status_3']);
        tomshowsetting(true,array('title'=>$Lang['index_expire_status'],'name'=>'expire_status','value'=>1,'msg'=>$Lang['index_expire_status_msg'],'item'=>$expire_status_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['expire_time'],'name'=>'expire_time','value'=>TIMESTAMP,'msg'=>$Lang['expire_time_msg']),"calendar");
        
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($tczhaopinInfo);
        $updateData['shenhe_status']    = 1;
        $updateData['status']           = 1;
        C::t('#tom_tczhaopin#tom_tczhaopin')->update($tczhaopinInfo['id'],$updateData);
        update_zhaopin_tongcheng($tczhaopinInfo['id']);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($tczhaopinInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status']     = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin')->update($_GET['id'],$updateData);
    
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tczhaopinInfo['user_id']);

    $shenhe = str_replace('{TITLE}', $tczhaopinInfo['title'], $Lang['index_template_tczhaopin_shenhe_ok']);
    $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tczhaopin&site='.$tczhaopinInfo['site_id'].'&mod=zhaopininfo&tczhaopin_id='.$tczhaopinInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$tczhaopinInfo['site_id']}&mod=zhaopininfo&tczhaopin_id=".$tczhaopinInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tczhaopinConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['tczhaopin_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['tczhaopin_shenhe_tz_fail'];
        }
    }
    
    update_zhaopin_tongcheng($tczhaopinInfo['id']);

    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
    update_company_status($companyInfo);
    
    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tczhaopinConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tczhaopinInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tczhaopin#tom_tczhaopin')->update($_GET['id'],$updateData);
        
        update_zhaopin_tongcheng($tczhaopinInfo['id']);
        
        $shenhe = str_replace('{TITLE}', $tczhaopinInfo['title'], $Lang['index_template_tczhaopin_shenhe_no']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tczhaopin&site='.$tczhaopinInfo['site_id'].'&mod=editzhaopin&tczhaopin_id='.$tczhaopinInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$tczhaopinInfo['site_id']}&mod=editzhaopin&tczhaopin_id=".$tczhaopinInfo['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tczhaopinConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tczhaopin_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tczhaopin_shenhe_tz_fail'];
            }
        }
        
        $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
        update_company_status($companyInfo);
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tczhaopinConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.$Lang['tczhaopin_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tczhaopin_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tczhaopin_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin')->update($_GET['id'],$updateData);
    
    update_zhaopin_tongcheng($tczhaopinInfo['id']);
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
    update_company_status($companyInfo);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tczhaopin#tom_tczhaopin')->update($_GET['id'],$updateData);
    
    update_zhaopin_tongcheng($tczhaopinInfo['id']);
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
    update_company_status($companyInfo);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'pay_ok'){
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['pay_status'] = 2;
    C::t('#tom_tczhaopin#tom_tczhaopin')->update($_GET['id'],$updateData);
    
    update_zhaopin_tongcheng($tczhaopinInfo['id']);
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
    update_company_status($companyInfo);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'pay_no'){
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['pay_status'] = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin')->update($_GET['id'],$updateData);
    
    update_zhaopin_tongcheng($tczhaopinInfo['id']);
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
    update_company_status($companyInfo);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){

    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($_GET['id']);
    
    C::t('#tom_tczhaopin#tom_tczhaopin')->delete_by_id($_GET['id']);
    C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->delete_by_tczhaopin_id($_GET['id']);
    
    delete_zhaopin_tongcheng($tczhaopinInfo['id']);
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
    update_company_status($companyInfo);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editexpire'){
    $info = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $expire_status  = intval($_GET['expire_status'])>0? intval($_GET['expire_status']):0;
        $expire_time    = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
        $expire_time    = strtotime($expire_time);
        
        $updateData = array();
        if($expire_status == 3){
            $updateData['expire_status']        = $expire_status;
        }else{
            if($expire_time < TIMESTAMP){
                $updateData['expire_status']    = 2;
                $updateData['expire_time']      = 0;
                if($tczhaopinConfig['expire_do_type'] == 1){
                    $updateData['status']       = 0;
                }
            }else{
                $updateData['expire_status']    = 1;
                $updateData['expire_time']      = $expire_time;
            }
        }
        $updateData['refresh_time']     = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin')->update($_GET['id'],$updateData);
        
        update_zhaopin_tongcheng($_GET['id']);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editexpire&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['expire_time_title'] .'</th></tr>';
        $expire_status_item = array(1=>$Lang['index_expire_status_1'], 2=>$Lang['index_expire_status_2'], 3=>$Lang['index_expire_status_3']);
        tomshowsetting(true,array('title'=>$Lang['index_expire_status'],'name'=>'expire_status','value'=>$info['expire_status'],'msg'=>$Lang['index_expire_status_msg'],'item'=>$expire_status_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['expire_time'],'name'=>'expire_time','value'=>$info['expire_time'],'msg'=>$Lang['expire_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'edittop'){
    $info = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $top_time     = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
        $top_time     = strtotime($top_time);
        $updateData = array();
        if($top_time < TIMESTAMP){
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
        }else{
            $updateData['top_status']   = 1;
            $updateData['refresh_time'] = TIMESTAMP;
            $updateData['top_time']     = $top_time;
        }
        C::t('#tom_tczhaopin#tom_tczhaopin')->update($_GET['id'],$updateData);
        
        update_zhaopin_tongcheng($_GET['id']);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edittop&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_top_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_top_time'],'name'=>'top_time','value'=>$info['top_time'],'msg'=>$Lang['edit_top_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refresh'){
    
    $updateData = array();
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tczhaopin#tom_tczhaopin')->update($_GET['id'],$updateData);
    
    update_zhaopin_tongcheng($_GET['id']);
    
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($_GET['id']);
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
    update_company_status($companyInfo);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_refresh'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['refresh_time']     = TIMESTAMP;
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value,$updateData);
            update_zhaopin_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_shenhe1'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['shenhe_status']     = 1;
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value,$updateData);
            update_zhaopin_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_shenhe3'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['shenhe_status']     = 3;
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value,$updateData);
            update_zhaopin_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_del'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            C::t('#tom_tczhaopin#tom_tczhaopin')->delete_by_id($value);
            C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->delete_by_tczhaopin_id($value);
            delete_zhaopin_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_show'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value,$updateData);
            update_zhaopin_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_hide'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['status'] = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value,$updateData);
            update_zhaopin_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'qunfa_list'){
    
    $tczhaopin_id = isset($_GET['tczhaopin_id'])? intval($_GET['tczhaopin_id']):0;
    $page         = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);
    
    $pagesize = 1000;
    $start = ($page-1)*$pagesize;
    $qunfaLogList = C::t('#tom_tczhaopin#tom_tczhaopin_qunfa_log')->fetch_all_list(" AND tczhaopin_id = {$tczhaopin_id} "," ORDER BY id DESC ",$start,$pagesize);
    
    showtableheader();
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><a href="'.$modBaseUrl.'&act=del_qunfa_log&tczhaopin_id='.$tczhaopin_id.'&formhash='.FORMHASH.'" class="addtr" ><font color="#F60">'.$Lang['index_qunfalog_del'].'</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' .$tczhaopinInfo['title'].'&nbsp;&gt;&gt;&nbsp;'. $Lang['index_send_qunfa_log'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['index_qunfalog_user'] . '</th>';
    echo '<th>' . $Lang['index_qunfalog_status'] . '</th>';
    echo '<th>' . $Lang['index_qunfalog_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($qunfaLogList as $key => $value) {
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        echo '<tr>';
        echo '<td>' . $userInfo['nickname'] .'(UID:' .$value['user_id']. ')</td>';
        if($value['status'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['index_qunfalog_status_1'] . '</font></td>';
        }else if($value['status'] == 2){
            echo '<td><font color="#f70404">' . $Lang['index_qunfalog_status_2'] . '</font></td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['index_qunfalog_status_0'] . '</font></td>';
        }
        echo '<td>' . dgmdate($value['log_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td> -- </td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del_qunfa_log'){

    C::t('#tom_tczhaopin#tom_tczhaopin_qunfa_log')->delete_by_tczhaopin_id($_GET['tczhaopin_id']);
    
    cpmsg($Lang['act_success'], $modListUrl.'&act=qunfa_list&tczhaopin_id='.$_GET['tczhaopin_id'], 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'update_vip_zhaopin_status'){
    
    $vipUserIdsList = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_all_user_id_list(" AND expire_status = 0 ", 'ORDER BY id DESC');
    $vipUserIdsArr = array();
    if(is_array($vipUserIdsList) && !empty($vipUserIdsList)){
        foreach($vipUserIdsList as $key => $value){
            $vipUserIdsArr[] = $value['user_id'];
        }
    }
    if(is_array($vipUserIdsArr) && !empty($vipUserIdsArr)){
        $vipUserIdsStr = implode(',', $vipUserIdsArr);
        if($tczhaopinConfig['expire_do_type'] == 1){
            DB::query("UPDATE ".DB::table('tom_tczhaopin')." SET expire_status=2,expire_time=0,status=0 WHERE user_id IN({$vipUserIdsStr}) AND expire_status = 3 ", 'UNBUFFERED');
        }else{
            DB::query("UPDATE ".DB::table('tom_tczhaopin')." SET expire_status=2,expire_time=0 WHERE user_id IN({$vipUserIdsStr}) AND expire_status = 3 ", 'UNBUFFERED');
        }
    }
    
    $vipUserAllIdsList = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_all_user_id_list(" ", 'ORDER BY id DESC');
    $vipUserAllIdsArr = array();
    if(is_array($vipUserAllIdsList) && !empty($vipUserAllIdsList)){
        foreach($vipUserAllIdsList as $key => $value){
            $vipUserAllIdsArr[] = $value['user_id'];
        }
    }
    if(is_array($vipUserAllIdsArr) && !empty($vipUserAllIdsArr)){
        $vipUserAllIdsStr = implode(',', $vipUserAllIdsArr);
        $expire_time = 30 * 86400 + TIMESTAMP;
        DB::query("UPDATE ".DB::table('tom_tczhaopin')." SET expire_status=1,expire_time={$expire_time} WHERE user_id NOT IN({$vipUserAllIdsStr}) AND expire_status = 3 ", 'UNBUFFERED');
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tczhaopin#tom_tczhaopin_photo')->delete_by_id($_GET['id']);
    update_zhaopin_tongcheng($_GET['tczhaopin_id']);
    
    cpmsg($Lang['act_success'], $modListUrl.'&act=photo&id='.$_GET['tczhaopin_id'], 'succeed');
    
}else if($_GET['act'] == 'photo'){
    
    if(submitcheck('submit')){
        
        $id             = isset($_GET['id'])? intval($_GET['id']):0;
        $psort          = isset($_GET['psort'])? intval($_GET['psort']):10;
        $picurl         = tomuploadFile("picurl");
        
        $insertData = array();
        $insertData['tczhaopin_id']     = $id;
        $insertData['picurl']           = $picurl;
        $insertData['psort']            = $psort;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_photo')->insert($insertData);
        update_zhaopin_tongcheng($id);
        cpmsg($Lang['act_success'], $modListUrl.'&act=photo&id='.$id, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        tomshownavheader();
        tomshownavli($Lang['index_photo_add'],'',true);
        tomshownavfooter();
        showformheader($modFromUrl.'&act=photo&id='.$_GET['id'],'enctype');
        showtableheader();
        
        tomshowsetting(true,array('title'=>$Lang['index_photo'],'name'=>'picurl','value'=>'','msg'=>$Lang['index_photo_msg']),"file");
        tomshowsetting(true,array('title'=>$Lang['paixu'],'name'=>'psort','value'=>10,'msg'=>$Lang['index_paixu_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $id         = intval($_GET['id'])>0? intval($_GET['id']):0;
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($id);
    $count = C::t('#tom_tczhaopin#tom_tczhaopin_photo')->fetch_all_count(" AND tczhaopin_id = {$id} ");
    $photoList = C::t('#tom_tczhaopin#tom_tczhaopin_photo')->fetch_all_list(" AND tczhaopin_id = {$id} "," ORDER BY psort ASC,id ASC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&act=photo&site_id={$site_id}";
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' .$tczhaopinInfo['title'].'&gt;'. $Lang['index_photo_title'] . '</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['index_photo'] . '</th>';
    echo '<th>' . $Lang['index_paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($photoList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a href="' . $value['picurlTmp'] . '" target="_blank"><img height="40" src="' . $value['picurlTmp'] . '"></a></td>';
        echo '<td>' . $value['psort'] . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&tczhaopin_id='.$id.'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}else{
    
    set_list_url("tom_tczhaopin_admin_index_list");
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $tczhaopin_id       = isset($_GET['tczhaopin_id'])? intval($_GET['tczhaopin_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $expire_status      = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    $keyword            = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($tczhaopin_id)){
        $where.= " AND id={$tczhaopin_id} ";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    if(!empty($tel)){
        $where.= " AND tel='{$tel}' ";
    }
    if(!empty($cate_id)){
        $where.= " AND cate_id={$cate_id} ";
    }
    if(!empty($cate_child_id)){
        $where.= " AND cate_child_id={$cate_child_id} ";
    }
    if(!empty($status)){
        if($status == 1){
            $where.= " AND status=1 ";
        }else if($status == 2){
            $where.= " AND status != 1 ";
        }
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    if($top_status > 0){
        if($top_status == 1){
            $where.= " AND top_status = 1 ";
        }else if($top_status == 2){
            $where.= " AND top_status = 0 ";
        }
    }
    
    if($expire_status > 0){
        if($expire_status == 1){
            $where.= " AND (pay_status = 0 OR pay_status = 2) AND expire_status = 1 AND expire_time > ".TIMESTAMP;
        }else if($expire_status == 2){
            $where.= " AND (pay_status = 1 OR expire_status = 2) ";
        }else if($expire_status == 3){
            $where.= " AND (pay_status = 0 OR pay_status = 2) AND expire_status = 3 ";
        }
    }
    
    $order = "ORDER BY add_time DESC,id DESC";
    
    if(!empty($keyword)){
        $pagesize = 100;
    }else{
        $pagesize = 50;
    }
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count("{$where}",$keyword);
    $tczhaopinList  = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list("{$where}",$order,$start,$pagesize,$keyword);

    showtableheader();
    $Lang['index_help_0']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_0']);
    $Lang['index_help_2']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_2']);
    $Lang['index_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_3']);
    $Lang['index_help_4']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_4']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_0'] . '</li>';
    echo '<li>' . $Lang['index_help_1'] . '</li>';
    echo '<li>' . $Lang['index_help_2'] . '</li>';
    if($tongchengConfig['open_yun'] == 2){
        echo '<li>' . $Lang['index_help_3'] . '</li>';
    }
    if($tongchengConfig['open_yun'] == 3){
        echo '<li>' . $Lang['index_help_4'] . '</li>';
    }
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/

    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&user_id={$user_id}&status={$status}&shenhe_status={$shenhe_status}&cate_id={$cate_id}&cate_child_id={$cate_child_id}&top_status={$top_status}&expire_status={$expire_status}&tel={$tel}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    $site_1 = '';
    if($site_id == 1){
        $site_1 = 'selected';
    }
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['index_search_keyword'] . '</b></td><td><input name="keyword" type="text" value="'.$keyword.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['index_search_tel'] . '</b></td><td><input name="tel" type="text" value="'.$tel.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $cateList   = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid = 0 "," ORDER BY csort ASC,id DESC ",0,200);
    $cateStr = '<tr><td width="100" align="right"><b>'.$Lang['index_search_cate'].'</b></td>';
    $cateStr.= '<td ><select style="width: 100px;" name="cate_id" id="cate_id" onChange="getChild();">';
    $cateStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    foreach ($cateList as $key => $value){
        if($cate_id == $value['id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select>';
    
    $cateChildList   = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list("  AND pid = {$cate_id}  "," ORDER BY csort ASC,id DESC ",0,200);
    $cateStr.= '<select style="width: 100px;" name="cate_child_id" id="cate_child_id">';
    $cateStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    foreach ($cateChildList as $key => $value){
        if($cate_child_id == $value['id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select></td></tr>';
    echo $cateStr;
    
    $status_1 = $status_2 = '';
    if($status == 1){
        $status_1 = 'selected';
    }else if($status == 2){
        $status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['index_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['index_status_0'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    $status_shenhe_1 = $status_shenhe_2 = $status_shenhe_3 = '';
    if($shenhe_status == 1){
        $status_shenhe_1 = 'selected';
    }else if($shenhe_status == 2){
        $status_shenhe_2 = 'selected';
    }else if($shenhe_status == 3){
        $status_shenhe_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$status_shenhe_1.'>'.$Lang['index_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$status_shenhe_2.'>'.$Lang['index_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$status_shenhe_3.'>'.$Lang['index_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    $top_status_1 = $top_status_0 = '';
    if($top_status == 1){
        $top_status_1 = 'selected';
    }else if($top_status == 2){
        $top_status_0 = 'selected';
    }
    $topStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['top_status'].'</b></td>';
    $topStatusStr.= '<td><select style="width: 260px;" name="top_status" id="top_status">';
    $topStatusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $topStatusStr.=  '<option value="1" '.$top_status_1.'>'.$Lang['top_status_1'].'</option>';
    $topStatusStr.=  '<option value="2" '.$top_status_0.'>'.$Lang['top_status_0'].'</option>';
    $topStatusStr.= '</select></td></tr>';
    echo $topStatusStr;
    
    $expire_status_1 = $expire_status_2 = $expire_status_3 = '';
    if($expire_status == 1){
        $expire_status_1 = 'selected';
    }else if($expire_status == 2){
        $expire_status_2 = 'selected';
    }else if($expire_status == 3){
        $expire_status_3 = 'selected';
    }
    $topStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_expire_status'].'</b></td>';
    $topStatusStr.= '<td><select style="width: 260px;" name="expire_status" id="expire_status">';
    $topStatusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $topStatusStr.=  '<option value="1" '.$expire_status_1.'>'.$Lang['index_expire_status_1'].'</option>';
    $topStatusStr.=  '<option value="2" '.$expire_status_2.'>'.$Lang['index_expire_status_2'].'</option>';
    $topStatusStr.=  '<option value="3" '.$expire_status_3.'>'.$Lang['index_expire_status_3'].'</option>';
    $topStatusStr.= '</select></td></tr>';
    echo $topStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    __create_nav_html();
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return batch_do();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />';
    tomshownavheader();
    echo '<li><a style="color: #FA6A03;margin-left: 10px;border-radius: 5px;border: 1px solid #FA6A03;" onclick="_confirm(\''.$modBaseUrl.'&act=update_vip_zhaopin_status&formhash='.FORMHASH.'\',\''.$Lang['index_update_zhaopin_msg'].'\');" href="javascript:void(0);"><span>'.$Lang['index_update_zhaopin_title'].'</span></a></li>';
    tomshownavfooter();
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 60px;"> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['index_user'] . '</th>';
    echo '<th>' . $Lang['index_title'] . '</th>';
    echo '<th>' . $Lang['index_cate_id'] . '</th>';
    echo '<th>' . $Lang['index_type'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['index_company_name'] . '</th>';
    echo '<th >' . $Lang['top_status'] . '</th>';
    echo '<th >' . $Lang['index_shenhe_status'] . '</th>';
    echo '<th >' . $Lang['index_pay_status'] . '</th>';
    echo '<th >' . $Lang['index_expire_status'] . '</th>';
    echo '<th >' . $Lang['index_status'] . '</th>';
    echo '<th >' . $Lang['index_qunfa_status'] . '</th>';
    echo '<th >' . $Lang['index_refresh_time'] . '</th>';
    echo '<th style="width: 150px;">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tczhaopinList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($value['cate_id']);
        $cateChildInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($value['cate_child_id']);
        $jianzhiCateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_by_id($value['jianzhi_cate_id']);
        
        echo '<tr>';
        echo '<td><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" >' . $value['id'] . '</td>';
        if($value['site_id'] > 0){
            if($value['site_id'] > 1){
                echo '<td>' . $siteInfo['name'] . '</td>';
            }else{
                echo '<td>' . $Lang['sites_one'] . '</td>';
            }
        }else{
            echo '<td> -- </td>';
        }
        echo '<td><font color="#0a9409">' . $userInfo['nickname'] . '</font><font color="#f70404">(ID:'.$value['user_id'].')</font></td>';
        echo '<td>' . $value['title'] . '</td>';
        if($value['type'] == 2 && $value['jianzhi_cate_id'] > 0){
            echo '<td>' .$jianzhiCateInfo['name'] . '</td>';
        }else{
            echo '<td>' . $cateInfo['name'].'/'.$cateChildInfo['name'] . '</td>';
        }
        
        if($value['type'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['index_type_1'] . '</font></td>';
        }else if($value['type'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['index_type_2'] . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        echo '<td>' . $value['company_name'] . '</td>';
        
        if($value['top_status'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['top_status_1'].'</font><br/><font color="#f70404">('.dgmdate($value['top_time'], 'Y-m-d H:i',$tomSysOffset).')</font></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['top_status_0'].'</font></td>';
        }
        
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shenhe_status_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shenhe_status_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['index_shenhe_status_1']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 2 ){
            echo '<td><font color="#f70404">' . $Lang['index_shenhe_status_2']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 3 ){
            echo '<td><font color="#f70404">' . $Lang['index_shenhe_status_3']. '</font>'.$sheheBtnStr.'</td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if($value['pay_status'] == 1){
            echo '<td><font color="#f70404">'.$Lang['index_pay_status_1'].'</font>(&nbsp;<a href="'.$modBaseUrl.'&act=pay_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_pay_status_2']. '</a>)</td>';
        }else if($value['pay_status'] == 2){
            echo '<td><font color="#0a9409">'.$Lang['index_pay_status_2'].'</font>(&nbsp;<a href="'.$modBaseUrl.'&act=pay_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_pay_status_1']. '</a>)</td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if($value['pay_status'] == 1 || $value['expire_status'] == 2){
            echo '<td><font color="#f70404">'.$Lang['index_expire_status_2'].'</font></td>';
        }else if($value['expire_status'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['index_expire_status_1'].'</font><br/><font color="#f70404">('.dgmdate($value['expire_time'], 'Y-m-d H:i',$tomSysOffset).')</font></td>';
        }else if($value['expire_status'] == 3){
            echo '<td><font color="#0a9409">'.$Lang['index_expire_status_3'].'</font></td>';
        }
        
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">'.$Lang['index_status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#f70404">(' . $Lang['index_status_0']. ')</font></a></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['index_status_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#0a9409">(' . $Lang['index_status_1']. ')</font></a></td>';
        }
        if($value['qunfa_status'] == 1){
            echo '<td><font color="#f70404">'.$Lang['index_qunfa_status_1'].'</font>';
        }else{
            echo '<td><font color="#0a9409">'.$Lang['index_qunfa_status_0'].'</font>';
        }
        echo '<td>' . dgmdate($value['refresh_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=refresh&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['refresh']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'" target="_blank">' . $Lang['edit']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edittop&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_top_title']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=editexpire&id='.$value['id'].'&formhash='.FORMHASH.'" target="_blank">' . $Lang['expire_time_title']. '</a><br/>';
        //echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'&formhash='.FORMHASH.'" target="_blank">' . $Lang['info']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=photo&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_photo_title']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        if($value['shenhe_status'] == 1 && ($value['pay_status'] == 2 || $value['pay_status'] == 0)){
            echo '<a href="'.$_G['siteurl'].'plugin.php?id=tom_tczhaopin:qunfa&act=admin_qunfa&tczhaopin_id='.$value['id'].'" target="_blank">' . $Lang['index_send_template'] . '</a><br/>';
            echo '<a href="'.$modBaseUrl.'&act=qunfa_list&tczhaopin_id='.$value['id'].'&formhash='.FORMHASH.'" target="_blank">' . $Lang['index_send_qunfa_log']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        }
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a><br/>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $formstr = <<<EOF
        <tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="batch_refresh">{$Lang['batch_refresh']}</option>
                    <option value="batch_shenhe1">{$Lang['batch_shenhe1']}</option>
                    <option value="batch_shenhe3">{$Lang['batch_shenhe3']}</option>
                    <option value="batch_del">{$Lang['batch_del']}</option>
                    <option value="batch_show">{$Lang['batch_show']}</option>
                    <option value="batch_hide">{$Lang['batch_hide']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>
        <script type="text/javascript">
        function batch_do(){
          var r = confirm("{$Lang['batch_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        </script>
EOF;
    echo $formstr;
    showformfooter();
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id                    = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $title                      = isset($_GET['title'])? addslashes($_GET['title']):'';
    $type                       = isset($_GET['type'])? intval($_GET['type']):0;
    $cate_id                    = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id              = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $jianzhi_cate_id            = isset($_GET['jianzhi_cate_id'])? intval($_GET['jianzhi_cate_id']):0;
    $work_salary                = isset($_GET['work_salary'])? intval($_GET['work_salary']):0;
    $work_salary_min            = intval($_GET['work_salary_min'])>0? intval($_GET['work_salary_min']):0;
    $work_salary_max            = intval($_GET['work_salary_max'])>0? intval($_GET['work_salary_max']):0;
    $jianzhi_work_salary        = isset($_GET['jianzhi_work_salary'])? intval($_GET['jianzhi_work_salary']):0;
    $jianzhi_work_salary_unit   = isset($_GET['jianzhi_work_salary_unit'])? intval($_GET['jianzhi_work_salary_unit']):0;
    $jianzhi_jiesuan_fangshi    = isset($_GET['jianzhi_jiesuan_fangshi'])? intval($_GET['jianzhi_jiesuan_fangshi']):0;
    $renshu                     = isset($_GET['renshu'])? intval($_GET['renshu']):0;
    $demand_sex                 = isset($_GET['demand_sex'])? intval($_GET['demand_sex']):0;
    $demand_ages                = isset($_GET['demand_ages'])? intval($_GET['demand_ages']):0;
    $demand_xueli               = isset($_GET['demand_xueli'])? intval($_GET['demand_xueli']):0;
    $demand_jingyan             = isset($_GET['demand_jingyan'])? intval($_GET['demand_jingyan']):0;
    $demand_desc                = isset($_GET['demand_desc'])? addslashes($_GET['demand_desc']):'';
    $city_id                    = isset($_GET['city_id'])? intval($_GET['city_id']):0;
    $area_id                    = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id                  = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $address                    = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude                   = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude                  = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $xm                         = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $company_name               = isset($_GET['company_name'])? addslashes($_GET['company_name']):'';
    $video_url                  = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    
    $workWelfareArr = array();
    if(is_array($_GET['work_welfare']) && !empty($_GET['work_welfare'])){
        foreach($_GET['work_welfare'] as $key => $value){
            $workWelfareArr[] = intval($value);
        }
    }
    $work_welfare = '-'.implode('-', $workWelfareArr).'-';
    
    
    $video_pic = "";
    if($_GET['act'] == 'add'){
        $video_pic        = tomuploadFile("video_pic");
    }else if($_GET['act'] == 'edit'){
        $video_pic        = tomuploadFile("video_pic",$infoArr['video_pic']);
    }
    
    $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$infoArr['user_id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    $companyRenzhengStatus = 0;
    $rzCompanyInfo = array();
    if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
        $companyRenzhengStatus = 1;
        $rzCompanyInfo = $rzCompanyInfoTmp[0];
    }
    
    if($companyRenzhengStatus == 1){
        $company_name = $rzCompanyInfo['name'];
    }

    $search_text = '';
    if($type == 1){
        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_id);
        $cateChildInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_child_id);
        $search_text = $title.'-'.$cateInfo['name'].'-'.$cateChildInfo['name'].'-'.$company_name;
    }else if($type == 2){
        $jianzhiCateInfo =  C::t("#tom_tczhaopin#tom_tczhaopin_jianzhi_cate")->fetch_by_id($jianzhi_cate_id);
        $search_text = $title.'-'.$jianzhiCateInfo['name'].'-'.$company_name;
    }
    
    $data['site_id']            = $site_id;
    $data['title']              = $title;
    $data['type']               = $type;
    if($type == 1){
        $data['cate_id']            = $cate_id;
        $data['cate_child_id']      = $cate_child_id;
    }else if($type == 2){
        $data['jianzhi_cate_id']    = $jianzhi_cate_id;
    }
    if($type == 1){
        $data['work_salary']          = $work_salary;
        $data['work_salary_min']      = $work_salary_min;
        $data['work_salary_max']      = $work_salary_max;
        $data['work_welfare']         = $work_welfare;
    }else if($type == 2){
        $data['jianzhi_work_salary']       = $jianzhi_work_salary;
        $data['jianzhi_work_salary_unit']  = $jianzhi_work_salary_unit;
        $data['jianzhi_jiesuan_fangshi']   = $jianzhi_jiesuan_fangshi;
    }
    $data['renshu']             = $renshu;
    $data['demand_sex']         = $demand_sex;
    $data['demand_ages']        = $demand_ages;
    $data['demand_xueli']       = $demand_xueli;
    $data['demand_jingyan']     = $demand_jingyan;
    $data['demand_desc']        = $demand_desc;
    $data['city_id']            = $city_id;
    $data['area_id']            = $area_id;
    $data['street_id']          = $street_id;
    $data['address']            = $address;
    $data['latitude']           = $latitude;
    $data['longitude']          = $longitude;
    $data['xm']                 = $xm;
    $data['tel']                = $tel;
    if($companyRenzhengStatus == 1){
        $data['company_name']            = $rzCompanyInfo['name'];
        $data['company_nature_id']       = $rzCompanyInfo['nature_id'];
        $data['company_industry_id']     = $rzCompanyInfo['industry_id'];
        $data['company_scale_id']        = $rzCompanyInfo['scale_id'];
    }else{
        $data['company_name']            = $company_name;
    }
    if(!empty($video_url)){
        $data['video_status']       = 1;
    }else{
        $data['video_status']       = 0;
    }
    $data['video_url']          = $video_url;
    $data['video_pic']          = $video_pic;
    $data['search_text']        = $search_text;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$tongchengConfig,$workSalaryArray,$welfareArray,$jianzhiJieSuanUnitArray,$jianzhiJieSuanFangshiArray,$workJingyanArray,$agesArray,$xueliArray;
    $options = array(
        'site_id'                   => 1,
        'company_id'                => 0,
        'title'                     => '',
        'type'                      => 1,
        'cate_id'                   => 0,
        'cate_child_id'             => 0,
        'jianzhi_cate_id'           => 0,
        'work_salary'               => 0,
        'work_welfare'              => '',
        'work_salary_min'           => '',
        'work_salary_max'           => '',
        'jianzhi_work_salary'       => 0,
        'jianzhi_work_salary_unit'  => 0,
        'jianzhi_jiesuan_fangshi'   => 0,
        'renshu'                    => 0,
        'demand_sex'                => 0,
        'demand_ages'               => 0,
        'demand_xueli'              => 0,
        'demand_jingyan'            => 0,
        'demand_desc'               => '',
        'city_id'                   => 0,
        'area_id'                   => 0,
        'street_id'                 => 0,
        'address'                   => '',
        'latitude'                  => '',
        'longitude'                 => '',
        'xm'                        => '',
        'tel'                       => '',
        'company_name'              => '',
        'video_url'                 => '',
        'video_pic'                 => '',
    );
    $options = array_merge($options, $infoArr);
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($options['company_id']);
    
    $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$options['user_id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    $companyRenzhengStatus = 0;
    if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
        $companyRenzhengStatus = 1;
    }
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    
    tomshowsetting(true,array('title'=>$Lang['index_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['index_title_msg']),"input");
    $index_type_item = array(1=>$Lang['index_type_1'], 2=>$Lang['index_type_2']);
    tomshowsetting(true,array('title'=>$Lang['index_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['index_type_msg'],'item'=>$index_type_item),"radio");
    
    $cateList   = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid = 0 "," ORDER BY csort ASC,id DESC ",0,200);
    $cateStr = '<tr><td width="100"><b>'.$Lang['index_search_cate'].'</b></td></tr>';
    $cateStr.= '<tr><td ><select style="width: 100px;" name="cate_id" id="cate_id" onChange="getChild();">';
    $cateStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    foreach ($cateList as $key => $value){
        if($options['cate_id'] == $value['id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select>';
    $cateChildList = array();
    if($options['cate_id'] > 0){
        $cateChildList = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list("  AND pid = {$options['cate_id']}  "," ORDER BY csort ASC,id DESC ",0,200);
    }
    $cateStr.= '<select style="width: 100px;" name="cate_child_id" id="cate_child_id">';
    $cateStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    foreach ($cateChildList as $key => $value){
        if($options['cate_child_id'] == $value['id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select></td></tr>';
    echo $cateStr;
    
    $workSalaryStr = '<tr><td width="100"><b>'.$Lang['quanzhi'].$Lang['index_info_work_salary'].'</b></td></tr>';
    $workSalaryStr.= '<tr><td ><select name="work_salary" id="work_salary">';
    foreach ($workSalaryArray as $key => $value){
        if($options['work_salary'] == $key){
            $workSalaryStr.=  '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            $workSalaryStr.=  '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    if($options['work_salary'] == 999){
        $workSalaryStr.=  '<option value="999" selected>'.$Lang['index_info_work_salary_999'].'</option>';
    }else{
        $workSalaryStr.=  '<option value="999">'.$Lang['index_info_work_salary_999'].'</option>';
    }
    $workSalaryStr.= '</select></td><td>'.$Lang['index_info_work_salary_msg'].'</td></tr>';
    echo $workSalaryStr;
    
    tomshowsetting(true,array('title'=>$Lang['index_info_work_salary_min'],'name'=>'work_salary_min','value'=>$options['work_salary_min'],'msg'=>$Lang['index_info_work_salary_min_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_info_work_salary_max'],'name'=>'work_salary_max','value'=>$options['work_salary_max'],'msg'=>$Lang['index_info_work_salary_max_msg']),"input");
    
    $workWelfareArr = explode('-', trim($options['work_welfare'],'-'));
    $workWelfareStr = '<tr class="header"><th>'.$Lang['quanzhi'].$Lang['index_info_work_welfare'].'</th><th></th></tr>';
    $workWelfareStr.= '<tr><td width="300">';
    foreach ($welfareArray as $key => $value){
        if(in_array($key, $workWelfareArr)){
            $workWelfareStr.=  '<label><input type="checkbox" name="work_welfare[]" value="'.$key.'" checked>'.$value.'</label>&nbsp;&nbsp;';
        }else{
            $workWelfareStr.=  '<label><input type="checkbox" name="work_welfare[]" value="'.$key.'">'.$value.'</label>&nbsp;&nbsp;';
        }
    }
    $workWelfareStr.= '</select></td><td>'.$Lang['index_info_work_welfare_msg'].'</td></tr>';
    echo $workWelfareStr;
    
    $jianzhiCateList = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ");
    $jianzhiCateStr = '<tr class="header"><th>'.$Lang['jianzhi'].$Lang['index_search_cate'].'</th><th></th></tr>';
    $jianzhiCateStr.= '<tr><td width="300"><select style="width: 260px;" name="jianzhi_cate_id" id="jianzhi_cate_id">';
    $jianzhiCateStr.=  '<option value="1">'.$Lang['index_search_all'].'</option>';
    foreach ($jianzhiCateList as $key => $value){
        if($value['id'] == $options['jianzhi_cate_id']){
            $jianzhiCateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $jianzhiCateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $jianzhiCateStr.= '</select></td><td></td></tr>';
    echo $jianzhiCateStr;
    
    $jianzhiWorkSalaryStr = '<tr><td width="100"><b>'.$Lang['jianzhi'].$Lang['index_jianzhi_work_salary'].'</b></td></tr>';
    $jianzhiWorkSalaryStr.= '<tr><td ><input type="number" style="width: 100px;" name="jianzhi_work_salary" id="jianzhi_work_salary" value="'.$options['jianzhi_work_salary'].'">';
    $jianzhiWorkSalaryStr.= '<select style="width: 100px;" name="jianzhi_work_salary_unit" id="jianzhi_work_salary_unit">';
    foreach ($jianzhiJieSuanUnitArray as $key => $value){
        if($options['jianzhi_work_salary_unit'] == $key){
            $jianzhiWorkSalaryStr.=  '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            $jianzhiWorkSalaryStr.=  '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    $jianzhiWorkSalaryStr.= '</select></td><td>'.$Lang['index_jianzhi_work_salary_msg'].'</td></tr>';
    echo $jianzhiWorkSalaryStr;
    
    $jianzhiJieSuanFangshiStr = '<tr><td width="100"><b>'.$Lang['jianzhi'].$Lang['index_jianzhi_jiesuan_fangshi'].'</b></td></tr>';
    $jianzhiJieSuanFangshiStr.= '<tr><td ><select name="jianzhi_jiesuan_fangshi" id="jianzhi_jiesuan_fangshi">';
    foreach ($jianzhiJieSuanFangshiArray as $key => $value){
        if($options['jianzhi_jiesuan_fangshi'] == $key){
            $jianzhiJieSuanFangshiStr.=  '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            $jianzhiJieSuanFangshiStr.=  '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    $jianzhiJieSuanFangshiStr.= '</select></td><td>'.$Lang['index_jianzhi_jiesuan_fangshi_msg'].'</td></tr>';
    echo $jianzhiJieSuanFangshiStr;
    
    tomshowsetting(true,array('title'=>$Lang['index_info_renshu'],'name'=>'renshu','value'=>$options['renshu'],'msg'=>$Lang['index_info_renshu_msg']),"input");
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($options['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($options['site_id']);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
        }
    }else if($options['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
    $areaStr.= '<tr><td width="100" ><b>'.$Lang['order_info_company_quyu'].'</b></td></tr>';
    $areaStr.= '<tr><td ><select style="width: 130px;" name="area_id" id="area_id" onChange="getStreet();">';
    $areaStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    foreach ($areaList as $key => $value){
        if($options['area_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select>';

    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($options['area_id']);
    $areaStr.= '<select style="width: 130px;" name="street_id" id="street_id">';
    $areaStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    foreach ($streetList as $key => $value){
        if($options['street_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select><input type="hidden" name="city_id" value="'.$__CityInfo['id'].'"></td></tr>';
    echo $areaStr;
    
    tomshowsetting(true,array('title'=>$Lang['order_info_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['order_info_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_latitude'],'name'=>'latitude','value'=>$options['latitude'],'msg'=>$Lang['index_latitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_longitude'],'name'=>'longitude','value'=>$options['longitude'],'msg'=>$Lang['index_longitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['order_info_xm'],'name'=>'xm','value'=>$options['xm'],'msg'=>$Lang['order_info_xm_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['order_info_tel'],'name'=>'tel','value'=>$options['tel'],'msg'=>$Lang['order_info_tel_msg']),"input");
    
    if($companyRenzhengStatus == 0){
        tomshowsetting(true,array('title'=>$Lang['order_info_company_name'],'name'=>'company_name','value'=>$options['company_name'],'msg'=>$Lang['order_info_company_name_msg']),"input");
    }
    
    $demand_sex_item = array(0=>$Lang['order_info_buxian'],1=>$Lang['order_info_demand_sex_1'], 2=>$Lang['order_info_demand_sex_2']);
    tomshowsetting(true,array('title'=>$Lang['order_info_demand_sex'],'name'=>'demand_sex','value'=>$options['demand_sex'],'msg'=>$Lang['order_info_demand_sex_msg'],'item'=>$demand_sex_item),"radio");
    
    $demandAgesStr = '<tr><td width="100"><b>'.$Lang['order_info_demand_ages'].'</b></td></tr>';
    $demandAgesStr.= '<tr><td ><select name="demand_ages" id="demand_ages">';
    $demandAgesStr.=  '<option value="0" selected>'.$Lang['order_info_buxian'].'</option>';
    foreach ($agesArray as $key => $value){
        if($options['demand_ages'] == $key){
            $demandAgesStr.=  '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            $demandAgesStr.=  '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    $demandAgesStr.= '</select></td><td>'.$Lang['order_info_demand_ages_msg'].'</td></tr>';
    echo $demandAgesStr;
    
    $xueliStr = '<tr><td width="100"><b>'.$Lang['order_info_demand_xueli'].'</b></td></tr>';
    $xueliStr.= '<tr><td ><select name="demand_xueli" id="demand_xueli">';
    $xueliStr.=  '<option value="0" selected>'.$Lang['order_info_buxian'].'</option>';
    foreach ($xueliArray as $key => $value){
        if($options['demand_xueli'] == $key){
            $xueliStr.=  '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            $xueliStr.=  '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    $xueliStr.= '</select></td><td>'.$Lang['order_info_demand_xueli_msg'].'</td></tr>';
    echo $xueliStr;
    
    $workJingyanStr = '<tr><td width="100"><b>'.$Lang['order_info_demand_jingyan'].'</b></td></tr>';
    $workJingyanStr.= '<tr><td ><select name="demand_jingyan" id="demand_jingyan">';
    $workJingyanStr.=  '<option value="0" selected>'.$Lang['order_info_buxian'].'</option>';
    foreach ($workJingyanArray as $key => $value){
        if($options['demand_jingyan'] == $key){
            $workJingyanStr.=  '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            $workJingyanStr.=  '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    $workJingyanStr.= '</select></td><td>'.$Lang['order_info_demand_jingyan_msg'].'</td></tr>';
    echo $workJingyanStr;
    
    tomshowsetting(true,array('title'=>$Lang['order_info_demand_desc'],'name'=>'demand_desc','value'=>$options['demand_desc'],'msg'=>$Lang['order_info_demand_desc_msg']),"textarea");
    tomshowsetting(true,array('title'=>$Lang['index_video_url'],'name'=>'video_url','value'=>$options['video_url'],'msg'=>$Lang['index_video_url_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_video_pic'],'name'=>'video_pic','value'=>$options['video_pic'],'msg'=>$Lang['index_video_pic_msg']),"file");
    
    return;
}

$jsstr = <<<EOF
<script type="text/javascript">
function _confirm(url, msg){
  var r = confirm(msg)
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
  
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}

function send_confirm(url){
  var r = confirm("{$Lang['index_send_dingyue_template_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}

function getChild(){
  var cate_id = jq("#cate_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tczhaopin:ajax",
        data: "act=childcates&pid="+cate_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var cateChildHtml = '<option value="0">{$Lang['index_search_all']}</option>';
            jq.each(json,function(k,v){
                cateChildHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#cate_child_id").html(cateChildHtml);
            jq("#cate_child_id").show();
        }
    });
}

function getCity(){
  var site_id = jq("#site_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tczhaopin:ajax",
        data: "act=admin_area&site="+site_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var areaHtml = '<option value="0">{$Lang['index_search_all']}</option>';
            jq.each(json,function(k,v){
                areaHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#area_id").html(areaHtml);
            jq("#area_id").show();
        }
    });
}
function getStreet(){
  var area_id = jq("#area_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tczhaopin:ajax",
        data: "act=admin_street&area_id="+area_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var streetHtml = '<option value="0">{$Lang['index_search_all']}</option>';
            jq.each(json,function(k,v){
                streetHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            console.log(streetHtml);
            jq("#street_id").html(streetHtml);
            jq("#street_id").show();
        }
    });
}
</script>
EOF;
echo $jsstr;

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['edit'],"",true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',false);
        tomshownavli($Lang['shenqing_title'],$adminBaseUrl.'&tmod=shenqing',false);
        tomshownavli($Lang['doDao_title_1'],$adminBaseUrl.'&tmod=doDaoZhaopin&type=1',false);
        tomshownavli($Lang['doDao_title_2'],$adminBaseUrl.'&tmod=doDaoZhaopin&type=2',false);
    }
    
    tomshownavfooter();
}