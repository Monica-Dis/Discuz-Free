<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=setting';
$modListUrl = $adminListUrl.'&tmod=setting';
$modFromUrl = $adminFromUrl.'&tmod=setting';

if(submitcheck('submit')){
    $updateData = array();
    $updateData = __get_post_data($zhaopinSetting);
    C::t('#tom_tczhaopin#tom_tczhaopin_setting')->update(1,$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['setting_title'] . '</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    tomloadcalendarjs();
    loadeditorjs();
    showformheader($modFromUrl,'enctype');
    showtableheader();
    __create_info_html($zhaopinSetting);
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $open_rz_back_vip           = isset($_GET['open_rz_back_vip'])? intval($_GET['open_rz_back_vip']):0;
    $open_resume_match          = isset($_GET['open_resume_match'])? intval($_GET['open_resume_match']):0;
    $resume_match_cate_child    = isset($_GET['resume_match_cate_child'])? intval($_GET['resume_match_cate_child']):0;
    $resume_match_area          = isset($_GET['resume_match_area'])? intval($_GET['resume_match_area']):0;
    $zhaopinlist_top_bgcolor    = isset($_GET['zhaopinlist_top_bgcolor'])? addslashes($_GET['zhaopinlist_top_bgcolor']):'';
    $zhaopininfo_tel_btncolor   = isset($_GET['zhaopininfo_tel_btncolor'])? addslashes($_GET['zhaopininfo_tel_btncolor']):'#23B4DC';
    
    $free_fabu_resume_num       = isset($_GET['free_fabu_resume_num'])? intval($_GET['free_fabu_resume_num']):0;
    $everyday_shenqing_num      = isset($_GET['everyday_shenqing_num'])? intval($_GET['everyday_shenqing_num']):0;
    
    $open_zhaopin_copy          = isset($_GET['open_zhaopin_copy'])? intval($_GET['open_zhaopin_copy']):0;
    $zhaopin_copy_template      = isset($_GET['zhaopin_copy_template'])? addslashes($_GET['zhaopin_copy_template']):'';
    $zhaopin_copy_shorturl      = isset($_GET['zhaopin_copy_shorturl'])? addslashes($_GET['zhaopin_copy_shorturl']):'';
    
    $open_zhaopin_match         = isset($_GET['open_zhaopin_match'])? intval($_GET['open_zhaopin_match']):0;
    $zhaopin_match_cate_child   = isset($_GET['zhaopin_match_cate_child'])? intval($_GET['zhaopin_match_cate_child']):0;
    $zhaopin_match_area         = isset($_GET['zhaopin_match_area'])? intval($_GET['zhaopin_match_area']):0;
    
    $fabu_top_style             = isset($_GET['fabu_top_style'])? intval($_GET['fabu_top_style']):0;
    $index_diy_html             = isset($_GET['index_diy_html'])? addslashes($_GET['index_diy_html']):'';
    $open_must_zhaopin_quyu     = isset($_GET['open_must_zhaopin_quyu'])? intval($_GET['open_must_zhaopin_quyu']):0;
    
    $data['open_rz_back_vip']           = $open_rz_back_vip;
    $data['open_resume_match']          = $open_resume_match;
    $data['resume_match_cate_child']    = $resume_match_cate_child;
    $data['resume_match_area']          = $resume_match_area;
    $data['zhaopinlist_top_bgcolor']    = $zhaopinlist_top_bgcolor;
    $data['zhaopininfo_tel_btncolor']   = $zhaopininfo_tel_btncolor;
    
    $data['free_fabu_resume_num']       = $free_fabu_resume_num;
    $data['everyday_shenqing_num']      = $everyday_shenqing_num;
    
    $data['open_zhaopin_copy']          = $open_zhaopin_copy;
    $data['zhaopin_copy_template']      = $zhaopin_copy_template;
    $data['zhaopin_copy_shorturl']      = $zhaopin_copy_shorturl;
    
    $data['open_zhaopin_match']         = $open_zhaopin_match;
    $data['zhaopin_match_cate_child']   = $zhaopin_match_cate_child;
    $data['zhaopin_match_area']         = $zhaopin_match_area;
    
    $data['fabu_top_style']             = $fabu_top_style;
    $data['index_diy_html']             = trim($index_diy_html);
    $data['open_must_zhaopin_quyu']     = $open_must_zhaopin_quyu;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'open_rz_back_vip'          => 1,
        'open_resume_match'         => 1,
        'resume_match_cate_child'   => 0,
        'resume_match_area'         => 0,
        'zhaopinlist_top_bgcolor'   => '#fff8eb',
        'zhaopininfo_tel_btncolor'  => '#23B4DC',
        'free_fabu_resume_num'      => 0,
        'everyday_shenqing_num'     => 0,
        
        'open_zhaopin_copy'         => 0,
        'zhaopin_copy_template'     => '',
        'zhaopin_copy_shorturl'     => '',
        
        'open_zhaopin_match'        => 1,
        'zhaopin_match_cate_child'  => '',
        'zhaopin_match_area'        => '',
        
        'fabu_top_style'            => 2,
        'index_diy_html'            => '',
        'open_must_zhaopin_quyu'    => 0,
        
    );
    $options = array_merge($options, $infoArr);
    
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/setting.lang.php';
    
    $open_item = array(1=>$Lang['open'],0=>$Lang['close']);
    
    tomshowsetting(true,array('title'=>$settingLang['free_fabu_resume_num'],'name'=>'free_fabu_resume_num','value'=>$options['free_fabu_resume_num'],'msg'=>$settingLang['free_fabu_resume_num_msg']),"input");
    tomshowsetting(true,array('title'=>$settingLang['everyday_shenqing_num'],'name'=>'everyday_shenqing_num','value'=>$options['everyday_shenqing_num'],'msg'=>$settingLang['everyday_shenqing_num_msg']),"input");
    
    //tomshowsetting(true,array('title'=>$settingLang['open_rz_back_vip'],'name'=>'open_rz_back_vip','value'=>$options['open_rz_back_vip'],'msg'=>$settingLang['open_rz_back_vip_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['open_resume_match'],'name'=>'open_resume_match','value'=>$options['open_resume_match'],'msg'=>$settingLang['open_resume_match_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['resume_match_cate_child'],'name'=>'resume_match_cate_child','value'=>$options['resume_match_cate_child'],'msg'=>$settingLang['resume_match_cate_child_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['resume_match_area'],'name'=>'resume_match_area','value'=>$options['resume_match_area'],'msg'=>$settingLang['resume_match_area_msg'],'item'=>$open_item),"radio");
    
    tomshowsetting(true,array('title'=>$settingLang['open_zhaopin_match'],'name'=>'open_zhaopin_match','value'=>$options['open_zhaopin_match'],'msg'=>$settingLang['open_zhaopin_match_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['zhaopin_match_cate_child'],'name'=>'zhaopin_match_cate_child','value'=>$options['zhaopin_match_cate_child'],'msg'=>$settingLang['zhaopin_match_cate_child_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['zhaopin_match_area'],'name'=>'zhaopin_match_area','value'=>$options['zhaopin_match_area'],'msg'=>$settingLang['zhaopin_match_area_msg'],'item'=>$open_item),"radio");
    
    tomshowsetting(true,array('title'=>$settingLang['zhaopinlist_top_bgcolor'],'name'=>'zhaopinlist_top_bgcolor','value'=>$options['zhaopinlist_top_bgcolor'],'msg'=>$settingLang['zhaopinlist_top_bgcolor_msg']),"input");
    tomshowsetting(true,array('title'=>$settingLang['zhaopininfo_tel_btncolor'],'name'=>'zhaopininfo_tel_btncolor','value'=>$options['zhaopininfo_tel_btncolor'],'msg'=>$settingLang['zhaopininfo_tel_btncolor_msg']),"input");
    
    tomshowsetting(true,array('title'=>$settingLang['open_zhaopin_copy'],'name'=>'open_zhaopin_copy','value'=>$options['open_zhaopin_copy'],'msg'=>$settingLang['open_zhaopin_copy_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['zhaopin_copy_template'],'name'=>'zhaopin_copy_template','value'=>$options['zhaopin_copy_template'],'msg'=>$settingLang['zhaopin_copy_template_msg']),"textarea");
    tomshowsetting(true,array('title'=>$settingLang['zhaopin_copy_shorturl'],'name'=>'zhaopin_copy_shorturl','value'=>$options['zhaopin_copy_shorturl'],'msg'=>$settingLang['zhaopin_copy_shorturl_msg']),"input");
    
    $fabu_top_style_item = array(1=>$settingLang['fabu_top_style_1'],2=>$settingLang['fabu_top_style_2']);
    tomshowsetting(true,array('title'=>$settingLang['fabu_top_style'],'name'=>'fabu_top_style','value'=>$options['fabu_top_style'],'msg'=>$settingLang['fabu_top_style_msg'],'item'=>$fabu_top_style_item),"radio");
    $options['index_diy_html'] = stripslashes($options['index_diy_html']);
    tomshowsetting(true,array('title'=>$settingLang['index_diy_html'],'name'=>'index_diy_html','value'=>$options['index_diy_html'],'msg'=>$settingLang['index_diy_html_msg']),"textarea");
    tomshowsetting(true,array('title'=>$settingLang['open_must_zhaopin_quyu'],'name'=>'open_must_zhaopin_quyu','value'=>$options['open_must_zhaopin_quyu'],'msg'=>$settingLang['open_must_zhaopin_quyu_msg'],'item'=>$open_item),"radio");
    
    return;
}