<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=meeting';
$modListUrl = $adminListUrl.'&tmod=meeting';
$modFromUrl = $adminFromUrl.'&tmod=meeting';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $meetingInfo = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($meetingInfo);
        $updateData['part1'] = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->update($meetingInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($meetingInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $meetingInfo = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $meetingInfo = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'search_close'){
    
    $meetingInfo = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['open_search'] = 0;
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'search_open'){
    
    $meetingInfo = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['open_search'] = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->delete_by_id($_GET['id']);
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->delete_by_meeting_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['act'] == 'add_company'){

    if(submitcheck('submit')){
        
        $meeting_id     = intval($_GET['meeting_id'])>0 ? intval($_GET['meeting_id']):0;
        $company_id     = intval($_GET['company_id'])>0 ? intval($_GET['company_id']):0;
        $is_recommend   = intval($_GET['is_recommend'])>0 ? intval($_GET['is_recommend']):0;
        $csort          = intval($_GET['csort'])>0 ? intval($_GET['csort']):10;
        
        $meetingInfo = C::t("#tom_tczhaopin#tom_tczhaopin_meeting")->fetch_by_id($meeting_id);
        $companyInfo = C::t("#tom_tczhaopin#tom_tczhaopin_company")->fetch_by_id($company_id);
        
        $insertData = array();
        $insertData['meeting_id']   = $meeting_id;
        $insertData['user_id']      = $companyInfo['user_id'];
        $insertData['company_id']   = $company_id;
        $insertData['csort']        = $csort;
        if($meetingInfo['zhaopin_list_type'] == 2){
            $insertData['status']   = 1;
        }
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl.'&act=company_list&meeting_id='.$meeting_id, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        
        showformheader($modFromUrl.'&act=add_company&meeting_id='.$_GET['meeting_id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['meeting_company_name'],'name'=>'company_id','value'=>'','msg'=>$Lang['meeting_company_name_msg']),"input");
        $is_recommend_item = array(1=>$Lang['meeting_is_recommend_1'], 0=>$Lang['meeting_is_recommend_0']);
        tomshowsetting(true,array('title'=>$Lang['meeting_is_recommend'],'name'=>'is_recommend','value'=>'','msg'=>$Lang['meeting_is_recommend_msg'],'item'=>$is_recommend_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['meeting_msort'],'name'=>'csort','value'=>10,'msg'=>$Lang['meeting_msort_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }

}else if($_GET['act'] == 'edit_company'){
    
    $meetingCompanyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->fetch_by_id($_GET['id']);
    $meetingInfo = C::t("#tom_tczhaopin#tom_tczhaopin_meeting")->fetch_by_id($meetingCompanyInfo['meeting_id']);
    if(submitcheck('submit')){
        
        $is_recommend   = intval($_GET['is_recommend'])>0 ? intval($_GET['is_recommend']):0;
        $csort          = intval($_GET['csort'])>0 ? intval($_GET['csort']):10;
        
        $tczhaopinIdsArr = array();
        if(is_array($_GET['tczhaopin_ids']) && !empty($_GET['tczhaopin_ids'])){
            foreach($_GET['tczhaopin_ids'] as $key => $value){
                if(!empty($value) && intval($value) > 0){
                    $tczhaopinIdsArr[$key] = intval($value);
                }
            }
        }
        
        $tczhaopinIdsStr = '';
        $tczhaopinIdsNum = 0;
        if(is_array($tczhaopinIdsArr) && !empty($tczhaopinIdsArr)){
            $tczhaopinIdsStr = implode(',', $tczhaopinIdsArr);
            $tczhaopinIdsNum = count($tczhaopinIdsArr);
        }
        
        $updateData = array();
        if($meetingInfo['zhaopin_list_type'] == 1){
            $updateData['tczhaopin_ids']    = $tczhaopinIdsStr;
            $updateData['tczhaopin_num']    = $tczhaopinIdsNum;
            if(!empty($tczhaopinIdsStr)){
                $updateData['status']            = 1;
            }else{
                $updateData['status']            = 0;
            }
        }else{
            $updateData['status']            = 1;
        }
        $updateData['is_recommend']     = $is_recommend;
        $updateData['csort']            = $csort;
        $updateData['part1']            = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->update($meetingCompanyInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl.'&act=company_list&meeting_id='.$_GET['meeting_id'], 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        
        $tczhaopinIdsArr = explode(',', $meetingCompanyInfo['tczhaopin_ids']);
        
        showformheader($modFromUrl.'&act=edit_company&meeting_id='.$_GET['meeting_id'].'&id='.$_GET['id'],'enctype');
        showtableheader();
        
        $userStr = '<tr class="header"><th>'.$Lang['index_user_id'].'</th><th></th></tr>';
        $userStr.= '<tr><td width="300"><input name="user_id" type="text" value="'.$meetingCompanyInfo['user_id'].'" size="40" readonly="readonly" /></td><td>'.$Lang['meeting_company_name_msg1'].'</td></tr>';
        echo $userStr;
        $companyStr = '<tr class="header"><th>'.$Lang['meeting_company_name'].'</th><th></th></tr>';
        $companyStr.= '<tr><td width="300"><input name="company_id" type="text" value="'.$meetingCompanyInfo['company_id'].'" size="40" readonly="readonly" /></td><td>'.$Lang['meeting_company_name_msg1'].'</td></tr>';
        echo $companyStr;
        if($meetingInfo['zhaopin_list_type'] == 1){
            $tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list(" AND type = 1 AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND user_id = {$meetingCompanyInfo['user_id']} ",'ORDER BY top_status DESC,refresh_time DESC,id DESC',0,100);
            $tczhaopinIdsStr = '<tr class="header"><th>'.$Lang['meeting_tczhaopin_ids'].'</th><th></th></tr>';
            $tczhaopinIdsStr.= '<tr><td width="300">';
            if(is_array($tczhaopinListTmp) && !empty($tczhaopinListTmp)){
                foreach($tczhaopinListTmp as $key => $value){
                    if(in_array($value['id'], $tczhaopinIdsArr)){
                        $tczhaopinIdsStr.=  '<label><input type="checkbox" name="tczhaopin_ids[]" value="'.$value['id'].'" checked>'.$value['title'].'</label><br/>';
                    }else{
                        $tczhaopinIdsStr.=  '<label><input type="checkbox" name="tczhaopin_ids[]" value="'.$value['id'].'">'.$value['title'].'</label><br/>';
                    }
                }
            }
            $tczhaopinIdsStr.= '</td><td></td></tr>';
            echo $tczhaopinIdsStr;
        }
        
        $is_recommend_item = array(1=>$Lang['meeting_is_recommend_1'], 0=>$Lang['meeting_is_recommend_0']);
        tomshowsetting(true,array('title'=>$Lang['meeting_is_recommend'],'name'=>'is_recommend','value'=>$meetingCompanyInfo['is_recommend'],'msg'=>$Lang['meeting_is_recommend_msg'],'item'=>$is_recommend_item),"radio");
        
        tomshowsetting(true,array('title'=>$Lang['meeting_msort'],'name'=>'csort','value'=>$meetingCompanyInfo['csort'],'msg'=>$Lang['meeting_msort_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del_company'){
    
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl.'&act=company_list&meeting_id='.$_GET['meeting_id'], 'succeed');
    
}else if($_GET['act'] == 'company_list'){
    
    $meeting_id = isset($_GET['meeting_id'])? intval($_GET['meeting_id']):0;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $meetingInfo = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_by_id($meeting_id);
    
    $where = " AND meeting_id={$meeting_id} ";
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->fetch_all_count($where);
    $meetingCompanyList = C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->fetch_all_list($where," ORDER BY is_recommend DESC, csort ASC,id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&act=company_list&meeting_id={$meeting_id}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $meetingInfo['title'] . '</th></tr>';
    showformfooter();
    
    tomshownavheader();
    tomshownavli($Lang['meeting_add_company'],$modBaseUrl."&act=add_company&meeting_id={$meeting_id}",false);
    tomshownavfooter();
    
    showtableheader();
    echo '<tr class="header">';
    //echo '<th> ID </th>';
    echo '<th>' . $Lang['meeting_user'] . '</th>';
    echo '<th>' . $Lang['meeting_company_name'] . '</th>';
    if($meetingInfo['zhaopin_list_type'] == 1){
        echo '<th>' . $Lang['meeting_tczhaopin_ids'] . '</th>';
    }
    echo '<th>' . $Lang['index_pay_status'] . '</th>';
    echo '<th>' . $Lang['meeting_status'] . '</th>';
    echo '<th>' . $Lang['meeting_is_recommend'] . '</th>';
    echo '<th>' . $Lang['meeting_msort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($meetingCompanyList as $key => $value) {
        
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $companyInfo = C::t("#tom_tczhaopin#tom_tczhaopin_company")->fetch_by_id($value['company_id']);
        $renzhengCompanyInfo = array();
        if($companyInfo['renzheng_company_id'] > 0){
            $renzhengCompanyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_id($companyInfo['renzheng_company_id']);
        }
        $tczhaopinListTmp = array();
        if(!empty($value['tczhaopin_ids'])){
            $tczhaopinListTmp = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_list(" AND id IN({$value['tczhaopin_ids']}) AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ", 'ORDER BY top_status DESC,refresh_time DESC,id DESC', 0, 100);
        }
        
        echo '<tr>';
        //echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] . '<font color="#f00">(ID:'.$userInfo['id'].')</font></td>';
        if($renzhengCompanyInfo['id'] > 0){
            if($renzhengCompanyInfo['shenhe_status'] == 1){
                echo '<td>' . $renzhengCompanyInfo['name'] . '<font color="#f00">(ID:'.$value['company_id'].')</font></td>';
            }else{
                echo '<td>' . $renzhengCompanyInfo['name'] . '<font color="#f00">(ID:'.$value['company_id'].')('.$Lang['meeting_no_shenhe_renzheng'].')</font></td>';
            }
        }else{
            echo '<td><font color="#f00">'.$Lang['meeting_no_renzheng'].'</font></td>';
        }
        if($meetingInfo['zhaopin_list_type'] == 1){
            if(!empty($value['tczhaopin_ids'])){
                echo '<td>';
                if(is_array($tczhaopinListTmp) && !empty($tczhaopinListTmp)){
                    foreach ($tczhaopinListTmp as $kk => $vv){
                        echo $vv['title'].'&nbsp;&nbsp;';
                    }
                }
                echo '</td>';
            }else{
                echo '<td> -- </td>';
            }
        }
        if($value['pay_status'] == 1){
            echo '<td><font color="#f70404">'.$Lang['index_pay_status_1'].'</font></td>';
        }else if($value['pay_status'] == 2){
            echo '<td><font color="#0a9409">'.$Lang['index_pay_status_2'].'</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">'.$Lang['meeting_status_1'].'</font></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['meeting_status_0'].'</font></td>';
        }
        if($value['is_recommend'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['meeting_is_recommend_1'].'</font></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['meeting_is_recommend_0'].'</font></td>';
        }
        echo '<td>' . $value['csort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit_company&meeting_id='.$meeting_id.'&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del_company&meeting_id='.$meeting_id.'&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}else{
    
    $site_id      = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_all_count($where);
    $meetingList = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_all_list($where," ORDER BY site_id ASC,msort ASC,id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['meeting_title'] . '</th>';
    echo '<th>' . $Lang['meeting_type'] . '</th>';
    echo '<th>' . $Lang['meeting_picurl'] . '</th>';
    echo '<th>' . $Lang['meeting_open_pay'] . '</th>';
    echo '<th>' . $Lang['meeting_zhaopin_list_type'] . '</th>';
    echo '<th>' . $Lang['meeting_clicks'] . '</th>';
    echo '<th>' . $Lang['meeting_start_time'] . '</th>';
    echo '<th>' . $Lang['meeting_end_time'] . '</th>';
    echo '<th>' . $Lang['meeting_bmend_time'] . '</th>';
    echo '<th>' . $Lang['meeting_status'] . '</th>';
    echo '<th>' . $Lang['meeting_open_search'] . '</th>';    
    echo '<th>' . $Lang['meeting_list_template'] . '</th>'; 
    echo '<th>' . $Lang['meeting_msort'] . '</th>';
    echo '<th width="200px">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($meetingList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        echo '<tr>';
        echo '<td> ' . $value['id'] . ' </td>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $value['title'] . '</td>';
        if($value['type'] == 1){
            echo '<td><font color="#0894fb">'.$Lang['meeting_type_1'].'</font></td>';
        }else if($value['type'] == 2){
            echo '<td><font color="#238206">'.$Lang['meeting_type_2'].'</font></td>';
        }
        echo '<td><a href="'.tomgetfileurl($value['picurl']).'" target="_blank"><img src="'.tomgetfileurl($value['picurl']).'" width="40" /></a></td>';
        if($value['open_pay'] == 1 ){
            echo '<td><font color="#f00">'.$value['pay_price'].'</font></td>';
        }else{
            echo '<td><font color="#238206">'.$Lang['meeting_open_pay_0'].'</font></td>';
        }
        if($value['zhaopin_list_type'] == 1){
            echo '<td>'.$Lang['meeting_zhaopin_list_type_1'].'</td>';
        }else if($value['zhaopin_list_type'] == 2){
            echo '<td>'.$Lang['meeting_zhaopin_list_type_2'].'</td>';
        }
        echo '<td>' . $value['clicks'] . '</td>';
        echo '<td>' . dgmdate($value['start_time'], 'Y-m-d H:i',$tomSysOffset) . '</td>';
        echo '<td>' . dgmdate($value['end_time'], 'Y-m-d H:i',$tomSysOffset) . '</td>';
        echo '<td>' . dgmdate($value['bmend_time'], 'Y-m-d H:i',$tomSysOffset) . '</td>';
        
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">'.$Lang['meeting_status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#f70404">(' . $Lang['meeting_status_0']. ')</font></a></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['meeting_status_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#0a9409">(' . $Lang['meeting_status_1']. ')</font></a></td>';
        }
        if($value['open_search'] == 1 ){
            echo '<td><font color="#0a9409">'.$Lang['meeting_open_search_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=search_close&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#f70404">(' . $Lang['meeting_open_search_0']. ')</font></a></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['meeting_open_search_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=search_open&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#0a9409">(' . $Lang['meeting_open_search_1']. ')</font></a></td>';
        }
        if($value['list_template'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['meeting_list_template_1'].'</font></td>';
        }else if($value['list_template'] == 2){
            echo '<td><font color="#0a9409">'.$Lang['meeting_list_template_2'].'</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $value['msort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=company_list&meeting_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['meeting_company_list']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $type           = isset($_GET['type'])? intval($_GET['type']):1;
    $open_pay       = isset($_GET['open_pay'])? intval($_GET['open_pay']):0;
    $pay_price      = isset($_GET['pay_price'])? floatval($_GET['pay_price']):0;
    $theme_color    = isset($_GET['theme_color'])? addslashes($_GET['theme_color']):'';
    $max_num        = isset($_GET['max_num'])? intval($_GET['max_num']):0;
    $organizer      = isset($_GET['organizer'])? addslashes($_GET['organizer']):'';
    $address        = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude       = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude      = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $qrcode_location = isset($_GET['qrcode_location'])? intval($_GET['qrcode_location']):1;
    $canhui_txt     = isset($_GET['canhui_txt'])? addslashes($_GET['canhui_txt']):'';
    $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
    $start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time     = strtotime($start_time);
    $end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time       = strtotime($end_time);
    $bmend_time     = isset($_GET['bmend_time'])? addslashes($_GET['bmend_time']):'';
    $bmend_time     = strtotime($bmend_time);
    $share_title    = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc     = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $virtual_clicks = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $open_search    = isset($_GET['open_search'])? intval($_GET['open_search']):0;
    $list_template  = isset($_GET['list_template'])? intval($_GET['list_template']):1;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $msort          = isset($_GET['msort'])? intval($_GET['msort']):10;
    
    $zhaopin_list_type       = isset($_GET['zhaopin_list_type'])? intval($_GET['zhaopin_list_type']):1;
    
    $picurl = $theme_picurl = $haibao_picurl = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
        $theme_picurl  = tomuploadFile("theme_picurl");
        $haibao_picurl = tomuploadFile("haibao_picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
        $theme_picurl  = tomuploadFile("theme_picurl",$infoArr['theme_picurl']);
        $haibao_picurl = tomuploadFile("haibao_picurl",$infoArr['haibao_picurl']);
    }
    
    $data['site_id']        = $site_id;
    $data['title']          = $title;
    $data['type']           = $type;
    $data['open_pay']       = $open_pay;
    $data['pay_price']      = $pay_price;
    $data['zhaopin_list_type']    = $zhaopin_list_type;
    $data['theme_color']    = $theme_color;
    $data['max_num']        = $max_num;
    $data['organizer']      = $organizer;
    $data['address']        = $address;
    $data['latitude']       = $latitude;
    $data['longitude']      = $longitude;
    $data['qrcode_location'] = $qrcode_location;
    $data['haibao_picurl']  = $haibao_picurl;
    $data['canhui_txt']     = $canhui_txt;
    $data['content']        = $content;
    $data['start_time']     = $start_time;
    $data['end_time']       = $end_time;
    $data['bmend_time']     = $bmend_time;
    $data['share_title']    = $share_title;
    $data['share_desc']     = $share_desc;
    $data['virtual_clicks'] = $virtual_clicks;
    $data['open_search']    = $open_search;
    $data['list_template']  = $list_template;
    $data['status']         = $status;
    $data['msort']          = $msort;
    $data['picurl']         = $picurl;
    $data['theme_picurl']   = $theme_picurl;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'site_id'        => 1,
        'title'          => '',
        'type'           => 1,
        'open_pay'       => 0,
        'pay_price'      => 0.00,
        'zhaopin_list_type'       => 1,
        'picurl'         => '',
        'theme_picurl'   => '',
        'theme_color'    => '',
        'max_num'        => '',
        'organizer'      => '',
        'address'        => '',
        'latitude'       => '',
        'longitude'      => '',
        'haibao_picurl'  => '',
        'qrcode_location' => 1,
        'canhui_txt'     => '',
        'content'        => '',
        'start_time'     => time(),
        'end_time'       => time(),
        'bmend_time'     => time(),
        'share_title'    => '',
        'share_desc'     => '',
        'virtual_clicks' => 0,
        'status'         => 1,
        'open_search'    => 0,
        'list_template'  => 1,
        'msort'          => 10,
    );
    $options = array_merge($options, $infoArr);
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    tomshowsetting(true,array('title'=>$Lang['meeting_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['meeting_title_msg']),"input");
    
    $list_template_item = array(1=>$Lang['meeting_list_template_1'], 2=>$Lang['meeting_list_template_2']);
    tomshowsetting(true,array('title'=>$Lang['meeting_list_template'],'name'=>'list_template','value'=>$options['list_template'],'msg'=>$Lang['meeting_list_template_msg'],'item'=>$list_template_item),"radio");
    
    $zhaopin_list_type_item = array(1=>$Lang['meeting_zhaopin_list_type_1'], 2=>$Lang['meeting_zhaopin_list_type_2']);
    tomshowsetting(true,array('title'=>$Lang['meeting_zhaopin_list_type'],'name'=>'zhaopin_list_type','value'=>$options['zhaopin_list_type'],'msg'=>$Lang['meeting_zhaopin_list_type_msg'],'item'=>$zhaopin_list_type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['meeting_max_num'],'name'=>'max_num','value'=>$options['max_num'],'msg'=>$Lang['meeting_max_num_msg']),"input");
    
    $type_item = array(1=>$Lang['meeting_type_1'], 2=>$Lang['meeting_type_2']);
    tomshowsetting(true,array('title'=>$Lang['meeting_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['meeting_type_msg'],'item'=>$type_item),"radio");
    
    $open_pay_item = array(1=>$Lang['meeting_open_pay_1'], 0=>$Lang['meeting_open_pay_0']);
    tomshowsetting(true,array('title'=>$Lang['meeting_open_pay'],'name'=>'open_pay','value'=>$options['open_pay'],'msg'=>$Lang['meeting_open_pay_msg'],'item'=>$open_pay_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['meeting_pay_price'],'name'=>'pay_price','value'=>$options['pay_price'],'msg'=>$Lang['meeting_pay_price_msg']),"input");
    
    tomshowsetting(true,array('title'=>$Lang['meeting_virtual_clicks'],'name'=>'virtual_clicks','value'=>$options['virtual_clicks'],'msg'=>$Lang['meeting_virtual_clicks_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['meeting_theme_color'],'name'=>'theme_color','value'=>$options['theme_color'],'msg'=>$Lang['meeting_theme_color_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['meeting_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['meeting_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['meeting_theme_picurl'],'name'=>'theme_picurl','value'=>$options['theme_picurl'],'msg'=>$Lang['meeting_theme_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['meeting_organizer'],'name'=>'organizer','value'=>$options['organizer'],'msg'=>$Lang['meeting_organizer_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['meeting_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['meeting_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['meeting_latitude'],'name'=>'latitude','value'=>$options['latitude'],'msg'=>$Lang['meeting_latitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['meeting_longitude'],'name'=>'longitude','value'=>$options['longitude'],'msg'=>$Lang['meeting_longitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['meeting_start_time'],'name'=>'start_time','value'=>$options['start_time'],'msg'=>$Lang['meeting_start_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['meeting_end_time'],'name'=>'end_time','value'=>$options['end_time'],'msg'=>$Lang['meeting_end_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['meeting_bmend_time'],'name'=>'bmend_time','value'=>$options['bmend_time'],'msg'=>$Lang['meeting_bmend_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['meeting_haibao_picurl'],'name'=>'haibao_picurl','value'=>$options['haibao_picurl'],'msg'=>$Lang['meeting_haibao_picurl_msg']),"file");
    $qrcode_location_item = array(1=>$Lang['meeting_qrcode_location_1'], 2=>$Lang['meeting_qrcode_location_2']);
    tomshowsetting(true,array('title'=>$Lang['meeting_qrcode_location'],'name'=>'qrcode_location','value'=>$options['qrcode_location'],'msg'=>$Lang['meeting_qrcode_location_msg'],'item'=>$qrcode_location_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['meeting_share_title'],'name'=>'share_title','value'=>$options['share_title'],'msg'=>$Lang['meeting_share_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['meeting_share_desc'],'name'=>'share_desc','value'=>$options['share_desc'],'msg'=>$Lang['meeting_share_desc_msg']),"input");
    $status_item = array(1=>$Lang['meeting_status_1'], 0=>$Lang['meeting_status_0']);
    tomshowsetting(true,array('title'=>$Lang['meeting_status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['meeting_ostatus_msg'],'item'=>$status_item),"radio");
    $open_search_item = array(1=>$Lang['meeting_open_search_1'], 0=>$Lang['meeting_open_search_0']);
    tomshowsetting(true,array('title'=>$Lang['meeting_open_search'],'name'=>'open_search','value'=>$options['open_search'],'msg'=>$Lang['meeting_open_search_msg'],'item'=>$open_search_item),"radio");
    
    tomshowsetting(true,array('title'=>$Lang['meeting_msort'],'name'=>'msort','value'=>$options['msort'],'msg'=>$Lang['meeting_msort_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['meeting_canhui_txt'],'name'=>'canhui_txt','value'=>$options['canhui_txt'],'msg'=>$Lang['meeting_canhui_txt_msg']),"text");
    tomshowsetting(true,array('title'=>$Lang['meeting_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['meeting_content_msg']),"text");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['meeting_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['meeting_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['meeting_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['meeting_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['meeting_edit'],"",true);
    }else{
        tomshownavli($Lang['meeting_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['meeting_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}