<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=jianzhi_cate'; 
$modListUrl = $adminListUrl.'&tmod=jianzhi_cate';
$modFromUrl = $adminFromUrl.'&tmod=jianzhi_cate';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($cateInfo);
        C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->update($cateInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($cateInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'import'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/import.data.php';
    
    foreach ($jianzhiCateArr as $key => $value){
        $insertData = array();
        $insertData['name']     = $value;
        $insertData['csort']    = $key;
        C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->insert($insertData);
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $site_id      = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $page         = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_all_count(" ");
    $cateList = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",$start,$pagesize);
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['cate_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=import&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['jianzhi_cate_import'].'</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['cate_name'] . '</th>';
    echo '<th>' . $Lang['cate_csort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($cateList as $key => $value) {
        echo '<tr>';
        echo '<td>' . $value['id'] .'</td>';
        echo '<td>' . $value['name'] .'</td>';
        echo '<td>' . $value['csort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function import_confirm(url){
  var r = confirm("{$Lang['makesure_import_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $csort          = isset($_GET['csort'])? intval($_GET['csort']):100;

    $data['name']       = $name;
    $data['csort']      = $csort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'          => '',
        'csort'         => 100,
    );
    
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['cate_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['cate_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['cate_csort'],'name'=>'csort','value'=>$options['csort'],'msg'=>$Lang['cate_csort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['jianzhi_cate_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['jianzhi_cate_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['jianzhi_cate_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['jianzhi_cate_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['jianzhi_cate_edit'],"",true);
    }else{
        tomshownavli($Lang['jianzhi_cate_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['jianzhi_cate_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}