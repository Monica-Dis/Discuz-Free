<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=resume';
$modListUrl = $adminListUrl.'&tmod=resume';
$modFromUrl = $adminFromUrl.'&tmod=resume';

$get_list_url_value = get_list_url("tom_tczhaopin_admin_resume_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'info'){
    
    $info = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($_GET['id']);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($info['user_id']);
    $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($info['cate_id']);
    $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($info['area_id']);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($info['street_id']);
    
    $age = dgmdate(TIMESTAMP,"Y",$tomSysOffset) - $info['birth_year'];
    
    $fenghao = $Lang['fenghao'];
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['info'] . '</th></tr>';
    if(!empty($info['avatar'])){
        echo '<tr><td style="width: 120px;" align="right"><b>'.$Lang['resume_avatar'].$fenghao.'</b></td><td><a href="'.tomgetfileurl($info['avatar']).'" target="_blank"><img width="40" height="40" src="'.tomgetfileurl($info['avatar']).'"></a></td></tr>';
    }else{
        if($info['sex'] == 1){
            echo '<tr><td style="width: 120px;" align="right"><b>'.$Lang['resume_avatar'].$fenghao.'</b></td><td><img width="40" height="40" src="'.$man_resume_avatar.'"></td></tr>';
        }else if($info['sex'] == 2){
            echo '<tr><td style="width: 120px;" align="right"><b>'.$Lang['resume_avatar'].$fenghao.'</b></td><td><img width="40" height="40" src="'.$woman_resume_avatar.'"></td></tr>';
        }
    }
    echo '<tr><td align="right"><b>'.$Lang['index_info_user'].$fenghao.'</b></td><td>'.$userInfo['nickname'].' <font color="#f00">(ID:'.$info['user_id'].')</font></td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['resume_name'].$fenghao.'</b></td><td>'.$info['name'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['resume_cate'].$fenghao.'</b></td><td><font color="#238206">'.$cateInfo['name'].'/</font>'.$info['cate_child_str'].'</td></tr>';
    if($info['type'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['resume_type'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['resume_type_1'].'</font></td></tr>';
    }else if($info['type'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['resume_type'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['resume_type_2'].'</font></td></tr>';
    }
    echo '<tr><td align="right"><b>'.$Lang['resume_quyu'].$fenghao.'</b></td><td>';
    if($areaInfo['id'] > 0){
        echo $areaInfo['name'];
        if($streetInfo['id'] > 0){
            echo '-'.$streetInfo['name'];
        }
    }else{
        echo $Lang['resume_quancheng'];
    }
    echo '</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['resume_work_jingyan'].$fenghao.'</b></td><td> '.$workJingyanArray[$info['work_jingyan']].' </td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['resume_work_salary'].$fenghao.'</b></td><td> '.$workSalaryArray[$info['work_salary']].' </td></tr>';
    if($info['sex'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['resume_sex'].$fenghao.'</b></td><td> '.$Lang['resume_sex_1'].' </td></tr>';
    }else if($info['sex'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['resume_sex'].$fenghao.'</b></td><td> '.$Lang['resume_sex_2'].' </td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['resume_sex'].$fenghao.'</b></td><td> - </td></tr>';
    }
    if($info['marital'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['resume_marital'].$fenghao.'</b></td><td> '.$Lang['resume_marital_1'].' </td></tr>';
    }else if($info['marital'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['resume_marital'].$fenghao.'</b></td><td> '.$Lang['resume_marital_2'].' </td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['resume_marital'].$fenghao.'</b></td><td> - </td></tr>';
    }
    echo '<tr><td align="right"><b>'.$Lang['resume_age'].$fenghao.'</b></td><td> '.$age.' </td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['resume_xueli'].$fenghao.'</b></td><td> '.$xueliArray[$info['xueli']].' </td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['resume_work_status'].$fenghao.'</b></td><td> '.$workStatusArray[$info['work_status']].' </td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['resume_tel'].$fenghao.'</b></td><td> '.$info['tel'].' </td></tr>';
    
    if($info['gongkai_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['resume_gongkai_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['resume_gongkai_status_1'].'</font></td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['resume_gongkai_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['resume_gongkai_status_0'].'</font></td></tr>';
    }
    
    if($info['shenhe_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_shenhe_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['index_shenhe_status_1'].'</font></td></tr>';
    }else if($info['shenhe_status'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['index_shenhe_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['index_shenhe_status_2'].'</font></td></tr>';
    }else if($info['shenhe_status'] == 3){
        echo '<tr><td align="right"><b>'.$Lang['index_shenhe_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['index_shenhe_status_3'].'</font></td></tr>';
    }
    
    if($info['top_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['top_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['top_status_1'].'('.dgmdate($info['top_time'], 'Y-m-d H:i:s',$tomSysOffset).')</font></td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['top_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['top_status_0'].'</font></td></tr>';
    }
    
    echo '<tr><td align="right"><b>'.$Lang['index_info_refresh_time'].$fenghao.'</b></td><td>'.dgmdate($info['refresh_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_info_add_time'].$fenghao.'</b></td><td>'.dgmdate($info['add_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['resume_work_jingli'].$fenghao.'</b></td><td> '.$info['work_jingli'].' </td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['resume_edu_jingli'].$fenghao.'</b></td><td> '.$info['edu_jingli'].' </td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['resume_describe'].$fenghao.'</b></td><td> '.$info['describe'].' </td></tr>';
    if($info['video_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_video_url'].$fenghao.'</b></td><td><a href="'.$info['video_url'].'" target="_blank">'.$info['video_url'].'</a></td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['index_video_pic'].$fenghao.'</b></td><td><a href="'.tomgetfileurl($info['video_pic']).'" target="_blank"><img height="120" src="'.tomgetfileurl($info['video_pic']).'"></a></td></tr>';
    }
    showtablefooter(); /*dism��taobao��com*/
    
}else if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['shenhe_status']    = 1;
        $insertData['status']           = 0;
        $insertData['refresh_time']     = TIMESTAMP;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_resume')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    
    $resumeInfo = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($resumeInfo);
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resumeInfo['id'],$updateData);
        
        update_resume_tongcheng($resumeInfo['id']);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($resumeInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status']     = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($_GET['id'],$updateData);
    
    $resumeInfo = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($resumeInfo['user_id']);
    $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($resumeInfo['cate_id']);

    $shenhe = str_replace("{CATE}", $cateInfo['name'], $Lang['resume_template_tczhaopin_shenhe_ok']);

    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$resumeInfo['site_id']}&mod=resumeinfo&resume_id=".$resumeInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tczhaopinConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['tczhaopin_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['tczhaopin_shenhe_tz_fail'];
        }
    }
    
    update_resume_tongcheng($resumeInfo['id']);

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tczhaopinConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $resumeInfo = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($resumeInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($_GET['id'],$updateData);
        
        update_resume_tongcheng($resumeInfo['id']);
        
        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($resumeInfo['cate_id']);

        $shenhe = str_replace("{CATE}", $cateInfo['name'], $Lang['resume_template_tczhaopin_shenhe_no']);
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$resumeInfo['site_id']}&mod=editresume&resume_id=".$resumeInfo['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tczhaopinConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tczhaopin_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tczhaopin_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tczhaopinConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tczhaopin_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tczhaopin_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tczhaopin_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($_GET['id'],$updateData);
    
    update_resume_tongcheng($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($_GET['id'],$updateData);
    
    update_resume_tongcheng($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){

    C::t('#tom_tczhaopin#tom_tczhaopin_resume')->delete_by_id($_GET['id']);
    C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->delete_by_resume_id($_GET['id']);
    C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->delete_by_resume_id($_GET['id']);
    C::t('#tom_tczhaopin#tom_tczhaopin_history')->delete_by_resume_id($_GET['id']);
    
    delete_resume_tongcheng($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'edittop'){
    $info = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $top_time     = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
        $top_time     = strtotime($top_time);
        $updateData = array();
        if($top_time < TIMESTAMP){
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
        }else{
            $updateData['top_status']   = 1;
            $updateData['refresh_time'] = TIMESTAMP;
            $updateData['top_time']     = $top_time;
        }
        C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($_GET['id'],$updateData);
        
        update_resume_tongcheng($_GET['id']);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edittop&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_top_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_top_time'],'name'=>'top_time','value'=>$info['top_time'],'msg'=>$Lang['edit_top_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refresh'){
    
    $updateData = array();
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($_GET['id'],$updateData);
    
    update_resume_tongcheng($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_refresh'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['refresh_time']     = TIMESTAMP;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value,$updateData);
            update_resume_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_shenhe1'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['shenhe_status']     = 1;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value,$updateData);
            update_resume_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_shenhe3'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['shenhe_status']     = 3;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value,$updateData);
            update_resume_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_del'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->delete_by_id($value);
            C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->delete_by_resume_id($value);
            C::t('#tom_tczhaopin#tom_tczhaopin_history')->delete_by_resume_id($value);
            delete_resume_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_show'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value,$updateData);
            update_resume_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_hide'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['status'] = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value,$updateData);
            update_resume_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_tczhaopin_admin_resume_list");
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $resume_id          = isset($_GET['resume_id'])? intval($_GET['resume_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    
    $cate_child_search = '';
    if($cate_child_id > 0){
        $cate_child_search = '-'.$cate_child_id.'-';
    }
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($resume_id)){
        $where.= " AND id={$resume_id} ";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    if(!empty($tel)){
        $where.= " AND tel='{$tel}' ";
    }
    if(!empty($cate_id)){
        $where.= " AND cate_id={$cate_id} ";
    }
    if(!empty($status)){
        if($status == 1){
            $where.= " AND status=1 ";
        }else if($status == 2){
            $where.= " AND status != 1 ";
        }
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    if($top_status > 0){
        if($top_status == 1){
            $where.= " AND top_status = 1 ";
        }else if($top_status == 2){
            $where.= " AND top_status = 0 ";
        }
    }
    
    $order = "ORDER BY add_time DESC,id DESC";
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count($where,$cate_child_search);
    $resumeList  = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_list($where,$order,$start,$pagesize,$cate_child_search);

    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&user_id={$user_id}&status={$status}&shenhe_status={$shenhe_status}&cate_id={$cate_id}&cate_child_id={$cate_child_id}&top_status={$top_status}&tel={$tel}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    $site_1 = '';
    if($site_id == 1){
        $site_1 = 'selected';
    }
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['index_search_tel'] . '</b></td><td><input name="tel" type="text" value="'.$tel.'" style="width: 260px;" /></td></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $cateList   = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid = 0 "," ORDER BY csort ASC,id DESC ",0,200);
    $cateStr = '<tr><td width="100" align="right"><b>'.$Lang['index_search_cate'].'</b></td>';
    $cateStr.= '<td ><select style="width: 100px;" name="cate_id" id="cate_id" onchange="getChild();">';
    $cateStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    foreach ($cateList as $key => $value){
        if($cate_id == $value['id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select>';
    
    $cateChildList   = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list("  AND pid = {$cate_id}  "," ORDER BY csort ASC,id DESC ",0,200);
    $cateStr.= '<select style="width: 100px;" name="cate_child_id" id="cate_child_id">';
    $cateStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    foreach ($cateChildList as $key => $value){
        if($cate_child_id == $value['id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select></td></tr>';
    echo $cateStr;
    
    $status_1 = $status_2 = '';
    if($status == 1){
        $status_1 = 'selected';
    }else if($status == 2){
        $status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['index_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['index_status_0'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    $status_shenhe_1 = $status_shenhe_2 = $status_shenhe_3 = '';
    if($shenhe_status == 1){
        $status_shenhe_1 = 'selected';
    }else if($shenhe_status == 2){
        $status_shenhe_2 = 'selected';
    }else if($shenhe_status == 3){
        $status_shenhe_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$status_shenhe_1.'>'.$Lang['index_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$status_shenhe_2.'>'.$Lang['index_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$status_shenhe_3.'>'.$Lang['index_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    $top_status_1 = $top_status_0 = '';
    if($top_status == 1){
        $top_status_1 = 'selected';
    }else if($top_status == 2){
        $top_status_0 = 'selected';
    }
    $topStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['top_status'].'</b></td>';
    $topStatusStr.= '<td><select style="width: 260px;" name="top_status" id="top_status">';
    $topStatusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $topStatusStr.=  '<option value="1" '.$top_status_1.'>'.$Lang['top_status_1'].'</option>';
    $topStatusStr.=  '<option value="2" '.$top_status_0.'>'.$Lang['top_status_0'].'</option>';
    $topStatusStr.= '</select></td></tr>';
    echo $topStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    __create_nav_html();
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return batch_do();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />';
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 60px;"> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['resume_user'] . '</th>';
    echo '<th>' . $Lang['resume_name'] . '</th>';
    echo '<th >' . $Lang['resume_avatar'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['resume_cate'] . '</th>';
    echo '<th >' . $Lang['resume_type'] . '</th>';
    echo '<th >' . $Lang['resume_gongkai_status'] . '</th>';
    echo '<th >' . $Lang['top_status'] . '</th>';
    echo '<th >' . $Lang['resume_shenhe_status'] . '</th>';
    echo '<th >' . $Lang['resume_status'] . '</th>';
    echo '<th >' . $Lang['resume_deleted'] . '</th>';
    echo '<th >' . $Lang['index_refresh_time'] . '</th>';
    echo '<th >' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($resumeList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($value['cate_id']);
        
        echo '<tr>';
        echo '<td><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" >' . $value['id'] . '</td>';
        if($value['site_id'] > 0){
            if($value['site_id'] > 1){
                echo '<td>' . $siteInfo['name'] . '</td>';
            }else{
                echo '<td>' . $Lang['sites_one'] . '</td>';
            }
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $userInfo['nickname'] . '<font color="#fd0d0d">(ID:' . $value['user_id'] . ')</font></td>';
        echo '<td>' . $value['name'] . '</td>';
        if(!empty($value['avatar'])){
            echo '<td><a href="'.tomgetfileurl($value['avatar']).'" target="_blank"><img width="40px" height="40px" src="' . tomgetfileurl($value['avatar']) . '" /></a></td>';
        }else{
            if($value['sex'] == 1){
                echo '<td><img width="40px" height="40px" src="' . $man_resume_avatar . '" /></td>';
            }else if($value['sex'] == 2){
                echo '<td><img width="40px" height="40px" src="' . $woman_resume_avatar . '" /></td>';
            }
        }
        echo '<td><font color="#238206">' . $cateInfo['name'].'/</font>'.$value['cate_child_str'] . '</td>';
        if($value['type'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['resume_type_1'].'</font></td>';
        }else if($value['type'] == 2){
            echo '<td><font color="#0a9409">'.$Lang['resume_type_2'].'</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['gongkai_status'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['resume_gongkai_status_1'] . '</font></td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['resume_gongkai_status_0'] . '</font></td>';
        }
        
        if($value['top_status'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['top_status_1'].'</font> <font color="#f70404">('.dgmdate($value['top_time'], 'Y-m-d H:i:s',$tomSysOffset).')</font></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['top_status_0'].'</font></td>';
        }
        
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['resume_shenhe_status_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['resume_shenhe_status_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['resume_shenhe_status_1']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 2 ){
            echo '<td><font color="#f70404">' . $Lang['resume_shenhe_status_2']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 3 ){
            echo '<td><font color="#f70404">' . $Lang['resume_shenhe_status_3']. '</font>'.$sheheBtnStr.'</td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">'.$Lang['resume_status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#f70404">(' . $Lang['resume_status_0']. ')</font></a></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['resume_status_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#0a9409">(' . $Lang['resume_status_1']. ')</font></a></td>';
        }
        if($value['deleted'] == 1 ){
            echo '<td><font color="#fd0d0d">'.$Lang['resume_deleted_1'].'</font></td>';
        }else{
            echo '<td><font color="#238206">'.$Lang['resume_deleted_0'].'</font></td>';
        }
        echo '<td>' . dgmdate($value['refresh_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td style="line-height: 20px;">';
        echo '<a href="'.$modBaseUrl.'&act=refresh&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['refresh']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edittop&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_top_title']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'&formhash='.FORMHASH.'" target="_blank">' . $Lang['info']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a><br/>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}

function getChild(){
  var cate_id = jq("#cate_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tczhaopin:ajax",
        data: "act=childcates&pid="+cate_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var cateChildHtml = '<option value="0">{$Lang['index_search_all']}</option>';
            jq.each(json,function(k,v){
                cateChildHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#cate_child_id").html(cateChildHtml);
            jq("#cate_child_id").show();
        }
    });
}
</script>
EOF;
    echo $jsstr;
    
    $formstr = <<<EOF
        <tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="batch_refresh">{$Lang['batch_refresh']}</option>
                    <option value="batch_shenhe1">{$Lang['batch_shenhe1']}</option>
                    <option value="batch_shenhe3">{$Lang['batch_shenhe3']}</option>
                    <option value="batch_del">{$Lang['batch_del']}</option>
                    <option value="batch_show">{$Lang['batch_show']}</option>
                    <option value="batch_hide">{$Lang['batch_hide']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>
        <script type="text/javascript">
        function batch_do(){
          var r = confirm("{$Lang['batch_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        </script>
EOF;
    echo $formstr;
    showformfooter();
    
}

function __get_post_data($infoArr = array()){
    global $tongchengConfig;
    
    $data = array();
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $type           = isset($_GET['type'])? intval($_GET['type']):0;
    $cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $area_id        = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id      = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $work_jingyan   = isset($_GET['work_jingyan'])? intval($_GET['work_jingyan']):0;
    $work_salary    = isset($_GET['work_salary'])? intval($_GET['work_salary']):0;
    $sex            = isset($_GET['sex'])? intval($_GET['sex']):0;
    $marital        = isset($_GET['marital'])? intval($_GET['marital']):0;
    $birth_year     = isset($_GET['birth_year'])? intval($_GET['birth_year']):0;
    $xueli          = isset($_GET['xueli'])? intval($_GET['xueli']):0;
    $work_status    = isset($_GET['work_status'])? intval($_GET['work_status']):0;
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $gongkai_status = isset($_GET['gongkai_status'])? intval($_GET['gongkai_status']):0;
    $work_jingli    = isset($_GET['work_jingli'])? addslashes($_GET['work_jingli']):'';
    $edu_jingli     = isset($_GET['edu_jingli'])? addslashes($_GET['edu_jingli']):'';
    $describe       = isset($_GET['describe'])? addslashes($_GET['describe']):'';
    $video_url      = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    
    $avatar = $video_pic = "";
    if($_GET['act'] == 'add'){
        $avatar        = tomuploadFile("avatar");
        $video_pic     = tomuploadFile("video_pic");
    }else if($_GET['act'] == 'edit'){
        $avatar        = tomuploadFile("avatar",$infoArr['avatar']);
        $video_pic     = tomuploadFile("video_pic",$infoArr['video_pic']);
    }
    
    $cateChildIdsArr = array();
    if(is_array($_GET['cate_child_ids']) && !empty($_GET['cate_child_ids'])){
        foreach($_GET['cate_child_ids'] as $key => $value){
            $cateChildIdsArr[] = intval($value);
        }
    }
    
    $cate_child_ids = $cate_child_str = $cate_child_search = '';
    if(is_array($cateChildIdsArr) && !empty($cateChildIdsArr)){
        $cateChildIdsStr = implode(',', $cateChildIdsArr);
        $cate_child_search = '-'.implode('-', $cateChildIdsArr).'-';
        $cateChildList = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_all_list(" AND pid = {$cate_id} AND id IN({$cateChildIdsStr}) ", 'ORDER BY csort ASC,id DESC ', 0, 1000);
        $cateChildNameArr = array();
        if(is_array($cateChildList) && !empty($cateChildList)){
            $cate_child_ids = $cateChildIdsStr;
            foreach($cateChildList as $key => $value){
                $cateChildNameArr[] = $value['name'];
            }
        }
        $cate_child_str = implode(',', $cateChildNameArr);
    }
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $city_id = $__SitesInfo['city_id'];
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $city_id = $tongchengConfig['city_id'];
        }
    }
    
    $search_text = $cateInfo['name'].'-'.$cate_child_str.'-'.$name;
    
    $data['site_id']            = $site_id;
    $data['user_id']            = $user_id;
    $data['name']               = $name;
    $data['type']               = $type;
    $data['avatar']             = $avatar;
    $data['cate_id']            = $cate_id;
    $data['cate_child_ids']     = $cate_child_ids;
    $data['cate_child_str']     = $cate_child_str;
    $data['cate_child_search']  = $cate_child_search;
    $data['city_id']            = $city_id;
    $data['area_id']            = $area_id;
    $data['street_id']          = $street_id;
    $data['work_jingyan']       = $work_jingyan;
    $data['work_salary']        = $work_salary;
    $data['sex']                = $sex;
    $data['marital']            = $marital;
    $data['birth_year']         = $birth_year;
    $data['xueli']              = $xueli;
    $data['work_status']        = $work_status;
    $data['tel']                = $tel;
    $data['gongkai_status']     = $gongkai_status;
    $data['work_jingli']        = $work_jingli;
    $data['edu_jingli']         = $edu_jingli;
    $data['describe']           = $describe;
    if(!empty($video_url)){
        $data['video_status']         = 1;
        $data['video_url']            = $video_url;
        $data['video_pic']            = $video_pic;
    }
    $data['search_text']        = $search_text;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$workJingyanArray,$workSalaryArray,$tomSysOffset,$xueliArray,$workStatusArray,$tczhaopinConfig,$tongchengConfig;
    $options = array(
        'site_id'           => 1,
        'user_id'           => '',
        'name'              => '',
        'type'              => 1,
        'avatar'            => 'source/plugin/tom_tczhaopin/images/touxiang.png',
        'cate_id'           => 0,
        'cate_child_ids'    => '',
        'city_id'           => 0,
        'area_id'           => 0,
        'street_id'         => 0,
        'work_jingyan'      => 0,
        'work_salary'       => 0,
        'sex'               => 0,
        'marital'           => 0,
        'birth_year'        => 0,
        'xueli'             => 0,
        'work_status'     => 0,
        'tel'               => '',
        'gongkai_status'    => 1,
        'work_jingli'       => '',
        'edu_jingli'        => '',
        'describe'          => '',
        'video_url'         => '',
        'video_pic'         => '',
    );
    $options = array_merge($options, $infoArr);
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id" onChange="getCity();">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    
    tomshowsetting(true,array('title'=>$Lang['resume_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['resume_user_id_msg']),"input");
    $resume_type_item = array(1=>$Lang['resume_type_1'], 2=>$Lang['resume_type_2']);
    tomshowsetting(true,array('title'=>$Lang['resume_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['resume_type_msg'],'item'=>$resume_type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['resume_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['resume_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['resume_avatar'],'name'=>'avatar','value'=>$options['avatar'],'msg'=>$Lang['resume_avatar_msg']),"file");
    
    $cateList   = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid = 0 "," ORDER BY csort ASC,id DESC ",0,200);
    $cateStr = '<tr><td width="100"><b>'.$Lang['index_search_cate'].'</b></td></tr>';
    $cateStr.= '<tr><td ><select name="cate_id" id="cate_id" onChange="getChild2();">';
    $cateStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    foreach ($cateList as $key => $value){
        if($options['cate_id'] == $value['id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select></td></tr>';
    echo $cateStr;
    
    $cateChildIdsArr = explode(',', $options['cate_child_ids']);
    $cateChildList = array();
    if($options['cate_id'] > 0){
        $cateChildList = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list("  AND pid = {$options['cate_id']}  "," ORDER BY csort ASC,id DESC ",0,200);
    }
    $cateStr = '<tr><td width="100"><b>'.$Lang['index_cate_child_id'].'</b></td></tr>';
    $cateStr.= '<tr><td id="cate_child_id">';
    foreach ($cateChildList as $key => $value){
        if(in_array($value['id'], $cateChildIdsArr)){
            $cateStr.=  '<label><input type="checkbox" name="cate_child_ids[]" value="'.$value['id'].'" checked>'.$value['name'].'</option></label>';
        }else{
            $cateStr.=  '<label><input type="checkbox" name="cate_child_ids[]" value="'.$value['id'].'">'.$value['name'].'</option></label>';
        }
    }
    $cateStr.= '</td><td>'.$Lang['index_cate_child_id_msg'].'</td></tr>';
    echo $cateStr;
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($options['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($options['site_id']);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
        }
    }else if($options['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    
    $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
    $areaStr.= '<tr><td width="100" ><b>'.$Lang['order_info_company_quyu'].'</b></td></tr>';
    $areaStr.= '<tr><td ><select style="width: 130px;" name="area_id" id="area_id" onChange="getStreet();">';
    $areaStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    foreach ($areaList as $key => $value){
        if($options['area_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select>';

    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($options['area_id']);
    $areaStr.= '<select style="width: 130px;" name="street_id" id="street_id">';
    $areaStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    foreach ($streetList as $key => $value){
        if($options['street_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select><input type="hidden" name="city_id" value="'.$__CityInfo['id'].'"></td></tr>';
    echo $areaStr;
    
    tomshowsetting(true,array('title'=>$Lang['resume_work_jingyan'],'name'=>'work_jingyan','value'=>$options['work_jingyan'],'msg'=>$Lang['resume_work_jingyan_msg'],'item'=>$workJingyanArray),"select");
    tomshowsetting(true,array('title'=>$Lang['resume_work_salary'],'name'=>'work_salary','value'=>$options['work_salary'],'msg'=>$Lang['resume_work_salary_msg'],'item'=>$workSalaryArray),"select");
    $resume_sex_item = array(1=>$Lang['resume_sex_1'], 2=>$Lang['resume_sex_2']);
    tomshowsetting(true,array('title'=>$Lang['resume_sex'],'name'=>'sex','value'=>$options['sex'],'msg'=>$Lang['resume_sex_msg'],'item'=>$resume_sex_item),"radio");
    $resume_marital_item = array(0=>$Lang['resume_marital_0'],1=>$Lang['resume_marital_1'], 2=>$Lang['resume_marital_2']);
    tomshowsetting(true,array('title'=>$Lang['resume_marital'],'name'=>'marital','value'=>$options['marital'],'msg'=>$Lang['resume_marital_msg'],'item'=>$resume_marital_item),"radio");
    
    $nowYear = dgmdate(TIMESTAMP,"Y",$tomSysOffset);
    $birthYearArr = array();
    $maxBirthYear = $nowYear - 60;
    $minBirthYear = $nowYear - 18;
    for($maxBirthYear; $maxBirthYear <= $minBirthYear; $maxBirthYear++){
        $birthYearArr[$maxBirthYear] = $maxBirthYear;
    }
    tomshowsetting(true,array('title'=>$Lang['resume_birth_year'],'name'=>'birth_year','value'=>$options['birth_year'],'msg'=>$Lang['resume_birth_year_msg'],'item'=>$birthYearArr),"select");
    tomshowsetting(true,array('title'=>$Lang['resume_xueli'],'name'=>'xueli','value'=>$options['xueli'],'msg'=>$Lang['resume_xueli_msg'],'item'=>$xueliArray),"select");
    tomshowsetting(true,array('title'=>$Lang['resume_work_status'],'name'=>'work_status','value'=>$options['work_status'],'msg'=>$Lang['resume_work_status_msg'],'item'=>$workStatusArray),"select");
    tomshowsetting(true,array('title'=>$Lang['resume_tel'],'name'=>'tel','value'=>$options['tel'],'msg'=>$Lang['resume_tel_msg']),"input");
    $resume_gongkai_status_item = array(0=>$Lang['resume_gongkai_status_0'],1=>$Lang['resume_gongkai_status_1']);
    tomshowsetting(true,array('title'=>$Lang['resume_gongkai_status'],'name'=>'gongkai_status','value'=>$options['gongkai_status'],'msg'=>$Lang['resume_gongkai_status_msg'],'item'=>$resume_gongkai_status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['resume_work_jingli'],'name'=>'work_jingli','value'=>$options['work_jingli'],'msg'=>$Lang['resume_work_jingli_msg']),"textarea");
    tomshowsetting(true,array('title'=>$Lang['resume_edu_jingli'],'name'=>'edu_jingli','value'=>$options['edu_jingli'],'msg'=>$Lang['resume_edu_jingli_msg']),"textarea");
    tomshowsetting(true,array('title'=>$Lang['resume_describe'],'name'=>'describe','value'=>$options['describe'],'msg'=>$Lang['resume_describe_msg']),"textarea");
    
    if($tczhaopinConfig['open_resume_video'] == 1){
        tomshowsetting(true,array('title'=>$Lang['index_video_url'],'name'=>'video_url','value'=>$options['video_url'],'msg'=>$Lang['index_video_url_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_video_pic'],'name'=>'video_pic','value'=>$options['video_pic'],'msg'=>$Lang['index_video_pic_msg']),"file");
    }
    
    return;
}

$jsstr = <<<EOF
<script type="text/javascript">
function getChild2(){
  var cate_id = jq("#cate_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tczhaopin:ajax",
        data: "act=childcates&pid="+cate_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var cateChildHtml = '';
            jq.each(json,function(k,v){
                cateChildHtml+= '<label><input type="checkbox" name="cate_child_ids[]" value="'+v.id+'">'+v.name+'</option></label>';
            })
            jq("#cate_child_id").html(cateChildHtml);
            jq("#cate_child_id").show();
        }
    });
}

function getCity(){
  var site_id = jq("#site_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tczhaopin:ajax",
        data: "act=admin_area&site="+site_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var areaHtml = '<option value="0">{$Lang['index_search_all']}</option>';
            jq.each(json,function(k,v){
                areaHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#area_id").html(areaHtml);
            jq("#area_id").show();
        }
    });
}
function getStreet(){
  var area_id = jq("#area_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tczhaopin:ajax",
        data: "act=admin_street&area_id="+area_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var streetHtml = '<option value="0">{$Lang['index_search_all']}</option>';
            jq.each(json,function(k,v){
                streetHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            console.log(streetHtml);
            jq("#street_id").html(streetHtml);
            jq("#street_id").show();
        }
    });
}
</script>
EOF;
echo $jsstr;

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['resume_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['resume_add'],$modBaseUrl.'&act=add',true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['resume_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['resume_add'],$modBaseUrl.'&act=add',false);
        tomshownavli($Lang['edit'],'',true);
    }else{
        tomshownavli($Lang['resume_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['resume_add'],$modBaseUrl.'&act=add',false);
        tomshownavli($Lang['doDao_title_1'],$adminBaseUrl.'&tmod=doDaoResume&type=1',false);
        tomshownavli($Lang['doDao_title_2'],$adminBaseUrl.'&tmod=doDaoResume&type=2',false);
    }
    tomshownavfooter();
}