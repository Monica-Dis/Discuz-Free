<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=order';
$modListUrl = $adminListUrl.'&tmod=order';
$modFromUrl = $adminFromUrl.'&tmod=order';

$get_list_url_value = get_list_url("tom_tczhaopin_admin_order_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'info'){
    
}else{
    
    set_list_url("tom_tczhaopin_admin_order_list");
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):0;
    $order_status       = isset($_GET['order_status'])? intval($_GET['order_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    if($type > 0){
        $where.= " AND type={$type} ";
    }
    if($order_status > 0){
        $where.= " AND order_status={$order_status} ";
    }
    
    $order = "ORDER BY order_time DESC,id DESC";
    
    $pagesize = 30;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_all_count($where);
    $orderList  = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_all_list($where,$order,$start,$pagesize);

    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&user_id={$user_id}&order_status={$order_status}&type={$type}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    $site_1 = '';
    if($site_id == 1){
        $site_1 = 'selected';
    }
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $order_type_1 = $order_type_2 = $order_type_3 = $order_type_4 = $order_type_5 = $order_type_6 = $order_type_7 = $order_type_8 = $order_type_9 = '';
    if($type == 1){
        $order_type_1 = 'selected';
    }else if($type == 2){
        $order_type_2 = 'selected';
    }else if($type == 3){
        $order_type_3 = 'selected';
    }else if($type == 4){
        $order_type_4 = 'selected';
    }else if($type == 5){
        $order_type_5 = 'selected';
    }else if($type == 6){
        $order_type_6 = 'selected';
    }else if($type == 7){
        $order_type_7 = 'selected';
    }else if($type == 8){
        $order_type_8 = 'selected';
    }else if($type == 9){
        $order_type_9 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['order_type'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="type">';
    $statusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $statusStr.=  '<option value="1" '.$order_type_1.'>'.$Lang['order_type_1'].'</option>';
    $statusStr.=  '<option value="8" '.$order_type_8.'>'.$Lang['order_type_8'].'</option>';
    $statusStr.=  '<option value="2" '.$order_type_2.'>'.$Lang['order_type_2'].'</option>';
    $statusStr.=  '<option value="3" '.$order_type_3.'>'.$Lang['order_type_3'].'</option>';
    $statusStr.=  '<option value="4" '.$order_type_4.'>'.$Lang['order_type_4'].'</option>';
    $statusStr.=  '<option value="5" '.$order_type_5.'>'.$Lang['order_type_5'].'</option>';
    $statusStr.=  '<option value="6" '.$order_type_6.'>'.$Lang['order_type_6'].'</option>';
    $statusStr.=  '<option value="7" '.$order_type_7.'>'.$Lang['order_type_7'].'</option>';
    $statusStr.=  '<option value="7" '.$order_type_9.'>'.$Lang['order_type_9'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    $order_status_1 = $order_status_2 = '';
    if($order_status == 1){
        $order_status_1 = 'selected';
    }else if($order_status == 2){
        $order_status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['order_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="order_status">';
    $statusStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
    $statusStr.=  '<option value="1" '.$order_status_1.'>'.$Lang['order_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$order_status_2.'>'.$Lang['order_status_2'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    $todayPayPrice = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_all_sun_pay_price(" AND pay_time > $nowDayTime AND order_status=2 ");
    $monthPayPrice = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_all_sun_pay_price(" AND pay_time > $nowMonthTime AND order_status=2 ");
    $allPayPrice = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_all_sun_pay_price(" AND order_status=2 ");
    echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
    echo $Lang['today_pay_price_title'].'<font color="#fd0d0d">('.$todayPayPrice.')</font>&nbsp;&nbsp;';
    echo $Lang['month_pay_price_title'].'<font color="#fd0d0d">('.$monthPayPrice.')</font>&nbsp;&nbsp;';
    echo $Lang['all_pay_price_title'].'<font color="#fd0d0d">('.$allPayPrice.')</font>&nbsp;&nbsp;';
    echo '</div>';
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['order_no'] . '</th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['resume_user'] . '</th>';
    echo '<th>' . $Lang['order_type'] . '</th>';
    echo '<th>' . $Lang['order_info'] . '</th>';
    echo '<th>' . $Lang['order_fabu_days'] . '</th>';
    echo '<th>' . $Lang['order_fabu_price'] . '</th>';
    echo '<th>' . $Lang['order_top_days'] . '</th>';
    echo '<th>' . $Lang['order_top_price'] . '</th>';
    echo '<th>' . $Lang['order_pay_price'] . '</th>';
    echo '<th>' . $Lang['order_status'] . '</th>';
    echo '<th>' . $Lang['order_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($orderList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($value['tczhaopin_id']);
        $resumeInfo = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($value['resume_id']);
        $vipInfo = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_by_id($value['vip_id']);
        $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($value['company_id']);
        $meetingInfo = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_by_id($value['meeting_id']);
        
        echo '<tr>';
        echo '<td>' . $value['order_no'] . '</td>';
        if($value['site_id'] > 0){
            if($value['site_id'] > 1){
                echo '<td>' . $siteInfo['name'] . '</td>';
            }else{
                echo '<td>' . $Lang['sites_one'] . '</td>';
            }
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $userInfo['nickname'] . '<font color="#fd0d0d">(ID:' . $value['user_id'] . ')</font></td>';
        if($value['type'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['order_type_1']. '</font></td>';
            echo '<td>' . $tczhaopinInfo['title'] . '<font color="#fd0d0d">(ID:' . $value['tczhaopin_id'] . ')</font></td>';
        }else if($value['type'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['order_type_2']. '</font></td>';
            echo '<td>' . $tczhaopinInfo['title'] . '<font color="#fd0d0d">(ID:' . $value['tczhaopin_id'] . ')</font></td>';
        }else if($value['type'] == 3){
            echo '<td><font color="#0a9409">' . $Lang['order_type_3']. '</font></td>';
            echo '<td>' . $tczhaopinInfo['title'] . '<font color="#fd0d0d">(ID:' . $value['tczhaopin_id'] . ')</font></td>';
        }else if($value['type'] == 4){
            echo '<td><font color="#0a9409">' . $Lang['order_type_4']. '</font></td>';
            echo '<td>' . $resumeInfo['name'] . '<font color="#fd0d0d">(ID:' . $value['resume_id'] . ')</font></td>';
        }else if($value['type'] == 5){
            echo '<td><font color="#0a9409">' . $Lang['order_type_5']. '</font></td>';
            echo '<td>' . $resumeInfo['name'] . '<font color="#fd0d0d">(ID:' . $value['resume_id'] . ')</font></td>';
        }else if($value['type'] == 6){
            echo '<td><font color="#0a9409">' . $Lang['order_type_6']. '</font></td>';
            echo '<td>' . $vipInfo['title'] . '<font color="#fd0d0d">(ID:' . $value['vip_id'] . ')</font></td>';
        }else if($value['type'] == 7){
            $renzhengCompanyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_id($companyInfo['renzheng_company_id']);
            echo '<td><font color="#0a9409">' . $Lang['order_type_7']. '</font></td>';
            echo '<td>' . $renzhengCompanyInfo['name'] . '<font color="#fd0d0d">(ID:' . $value['company_id'] . ')</font></td>';
        }else if($value['type'] == 8){
            echo '<td><font color="#0a9409">' . $Lang['order_type_8']. '</font></td>';
            echo '<td>' . $tczhaopinInfo['title'] . '<font color="#fd0d0d">(ID:' . $value['tczhaopin_id'] . ')</font></td>';
        }else if($value['type'] == 9){
            echo '<td><font color="#0a9409">' . $Lang['order_type_9']. '</font></td>';
            echo '<td>' . $meetingInfo['title'] . '<font color="#fd0d0d">(ID:' . $value['meeting_id'] . ')('.$Lang['order_meeting_company'].$value['meeting_company_id'].')</font></td>';
        }
        
        if($value['fabu_days'] > 0){
            echo '<td><font color="#fd0d0d">' . $value['fabu_days'].'</font></td>';
            echo '<td><font color="#fd0d0d">' . $value['fabu_price'].'</font></td>';
        }else{
            echo '<td> -- </td>';
            echo '<td> -- </td>';
        }
        
        if($value['top_days'] > 0){
            echo '<td><font color="#fd0d0d">' . $value['top_days'].'</font></td>';
            echo '<td><font color="#fd0d0d">' . $value['top_price'].'</font></td>';
        }else{
            echo '<td> -- </td>';
            echo '<td> -- </td>';
        }
        echo '<td><font color="#fd0d0d">' . $value['pay_price']. '</font></td>';
        if($value['order_status'] == 1 ){
            echo '<td><font color="#f00">'.$Lang['order_status_1'].'</font></td>';
        }else if($value['order_status'] == 2 ){
            echo '<td><font color="#0a9409">'.$Lang['order_status_2'].'</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        echo '<td>' . dgmdate($value['order_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td> -- </td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    tomshownavli($Lang['resume_list_title'],$modBaseUrl,true);
    tomshownavfooter();
}