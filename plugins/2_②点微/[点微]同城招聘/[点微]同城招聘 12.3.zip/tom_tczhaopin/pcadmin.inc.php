<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20201022";

$zhaopinSetting = C::t('#tom_tczhaopin#tom_tczhaopin_setting')->fetch_by_id(1);
if($zhaopinSetting && $zhaopinSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin_setting')->insert($insertData);
    $zhaopinSetting = C::t('#tom_tczhaopin#tom_tczhaopin_setting')->fetch_by_id(1);
}

$pcadminUrl = 'plugin.php?id=tom_tczhaopin:pcadmin';
$ajaxUrl = 'plugin.php?id=tom_admin:ajax';
$uploadUrl = 'plugin.php?id=tom_admin:upload';
$baidumapUrl = 'plugin.php?id=tom_admin:baidumap';

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/pcadmin.lang.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.utf.php';
}

$welfareArray = array();
$welfare_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['welfare_list']); 
$welfare_list_str = str_replace("\n","{n}",$welfare_list_str);
$welfare_list_arr = explode("{n}", $welfare_list_str);
if(is_array($welfare_list_arr) && !empty($welfare_list_arr)){
    foreach ($welfare_list_arr as $key => $value){
        $welfare_list_item = explode("|", $value);
        $welfare_list_item_id = intval($welfare_list_item[0]);
        $welfare_list_item_name = trim($welfare_list_item[1]);
        if($welfare_list_item_id > 0 && !empty($welfare_list_item_name)){
            $welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
        }
    }
}

$agesArray = array();
$ages_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['zhaopin_ages_list']); 
$ages_list_str = str_replace("\n","{n}",$ages_list_str);
$ages_list_arr = explode("{n}", $ages_list_str);
if(is_array($ages_list_arr) && !empty($ages_list_arr)){
    foreach ($ages_list_arr as $key => $value){
        $ages_list_item = explode("|", $value);
        $ages_list_item_id = intval($ages_list_item[0]);
        $ages_list_item_name = trim($ages_list_item[1]);
        if($ages_list_item_id > 0 && !empty($ages_list_item_name)){
            $agesArray[$ages_list_item_id] = $ages_list_item_name;
        }
    }
}

$workStatusArray = array();
$work_status_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['work_status_list']); 
$work_status_list_str = str_replace("\n","{n}",$work_status_list_str);
$work_status_list_arr = explode("{n}", $work_status_list_str);
if(is_array($work_status_list_arr) && !empty($work_status_list_arr)){
    foreach ($work_status_list_arr as $key => $value){
        $work_status_list_item = explode("|", $value);
        $work_status_list_item_id = intval($work_status_list_item[0]);
        $work_status_list_item_name = trim($work_status_list_item[1]);
        if($work_status_list_item_id > 0 && !empty($work_status_list_item_name)){
            $workStatusArray[$work_status_list_item_id] = $work_status_list_item_name;
        }
    }
}

$Lang = $pcadminLang;

include DISCUZ_ROOT.'./source/plugin/tom_admin/login_check.php';

if($_GET['tmod'] == 'list'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/list.php';
}else if($_GET['tmod'] == 'add'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/add.php';
}else if($_GET['tmod'] == 'edit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/edit.php';
}else if($_GET['tmod'] == 'doDaoZhaopin'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/doDaoZhaopin.php';
}else if($_GET['tmod'] == 'shenqing'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/shenqing.php';
}else if($_GET['tmod'] == 'resume'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/resume.php';
}else if($_GET['tmod'] == 'doDaoResume'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/doDaoResume.php';
}else if($_GET['tmod'] == 'resumeadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/resumeadd.php';
}else if($_GET['tmod'] == 'resumeedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/resumeedit.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/order.php';
}else if($_GET['tmod'] == 'company'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/company.php';
}else if($_GET['tmod'] == 'meeting_companylist'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/meeting_companylist.php';
}else if($_GET['tmod'] == 'meeting'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/meeting.php';
}else if($_GET['tmod'] == 'meetingadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/meetingadd.php';
}else if($_GET['tmod'] == 'meetingedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/meetingedit.php';
}else if($_GET['tmod'] == 'uservip'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/uservip.php';
}else if($_GET['tmod'] == 'uselist'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/uselist.php';
}else if($_GET['tmod'] == 'paylist'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/paylist.php';
}else if($_GET['tmod'] == 'jubao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/jubao.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/focuspic.php';
}else if($_GET['tmod'] == 'focuspicadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/focuspicadd.php';
}else if($_GET['tmod'] == 'focuspicedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/focuspicedit.php';
}else if($_GET['tmod'] == 'popup'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/popup.php';
}else if($_GET['tmod'] == 'popupadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/popupadd.php';
}else if($_GET['tmod'] == 'popupedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/popupedit.php';
}else if($_GET['tmod'] == 'wxqun'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/wxqun.php';
}else if($_GET['tmod'] == 'wxqunadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/wxqunadd.php';
}else if($_GET['tmod'] == 'wxqunedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/wxqunedit.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/pcadmin/list.php';
}