<?php

/**
   Copyright 2001-2099 DisM!Ӧ������.
   This is NOT a freeware, use is subject to license terms
   Ӧ�ø���֧�֣�https://dism.taobao.com
   ���²����http://t.cn/Aiux1Jx1
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tczhaopinConfig    = $_G['cache']['plugin']['tom_tczhaopin'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset       = getglobal('setting/timeoffset');
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass        = new weixinClass($appid,$appsecret);

$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);

$zhaopinSetting = C::t('#tom_tczhaopin#tom_tczhaopin_setting')->fetch_by_id(1);
if($zhaopinSetting && $zhaopinSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin_setting')->insert($insertData);
    $zhaopinSetting = C::t('#tom_tczhaopin#tom_tczhaopin_setting')->fetch_by_id(1);
}

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcadmin start
$__ShowTcadmin = 0;
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
    if($tcadminConfig['open_fc'] == 1){
        $__ShowTcadmin = 1;
    }
}
## tcadmin end

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.utf.php';
}
$welfareArray = array();
$welfare_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['welfare_list']); 
$welfare_list_str = str_replace("\n","{n}",$welfare_list_str);
$welfare_list_arr = explode("{n}", $welfare_list_str);
if(is_array($welfare_list_arr) && !empty($welfare_list_arr)){
    foreach ($welfare_list_arr as $key => $value){
        $welfare_list_item = explode("|", $value);
        $welfare_list_item_id = intval($welfare_list_item[0]);
        $welfare_list_item_name = trim($welfare_list_item[1]);
        if($welfare_list_item_id > 0 && !empty($welfare_list_item_name)){
            $welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
        }
    }
}

$agesArray = array();
$ages_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['zhaopin_ages_list']); 
$ages_list_str = str_replace("\n","{n}",$ages_list_str);
$ages_list_arr = explode("{n}", $ages_list_str);
if(is_array($ages_list_arr) && !empty($ages_list_arr)){
    foreach ($ages_list_arr as $key => $value){
        $ages_list_item = explode("|", $value);
        $ages_list_item_id = intval($ages_list_item[0]);
        $ages_list_item_name = trim($ages_list_item[1]);
        if($ages_list_item_id > 0 && !empty($ages_list_item_name)){
            $agesArray[$ages_list_item_id] = $ages_list_item_name;
        }
    }
}

$tongbuParamArr = array();
$tongbuParamArr['tczhaopinConfig']  = $tczhaopinConfig;
$tongbuParamArr['tongchengConfig']  = $tongchengConfig;
$tongbuParamArr['welfareArray']     = $welfareArray;
$tongbuParamArr['workSalaryArray']  = $workSalaryArray;
$tongbuParamArr['jianzhiJieSuanUnitArray']  = $jianzhiJieSuanUnitArray;
$tongbuParamArr['agesArray']        = $agesArray;
$tongbuParamArr['xueliArray']       = $xueliArray;
$tongbuParamArr['workJingyanArray'] = $workJingyanArray;
$tongbuParamArr['tomSysOffset']     = $tomSysOffset;

include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

$orderInfo = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_by_order_no($order_no);
if($orderInfo && $orderInfo['order_status'] == 1){
    
    $updateData = array();
    $updateData['order_status'] = 2;
    $updateData['pay_time'] = TIMESTAMP;
    C::t('#tom_tczhaopin#tom_tczhaopin_order')->update($orderInfo['id'],$updateData);
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
    
    if($orderInfo['type'] == 1){
        
        $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($orderInfo['tczhaopin_id']);
        
        $updateData = array();
        if($orderInfo['top_days'] > 0){
            
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
            
            $updateData['top_status']   = 1;
            $updateData['top_time']     = $top_time;
        }
        if($orderInfo['fabu_days'] > 0){
            $fabu_time = $orderInfo['fabu_days'] * 86400 + TIMESTAMP;
            
            $updateData['expire_status']    = 1;
            $updateData['expire_time']      = $fabu_time;
            $updateData['pay_status']       = 2;
        }
        $updateData['status']           = 1;
        C::t('#tom_tczhaopin#tom_tczhaopin')->update($orderInfo['tczhaopin_id'],$updateData);
        
        update_zhaopin_tongcheng($orderInfo['tczhaopin_id'],$tongbuParamArr);
        
        $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($orderInfo['user_id']);
        update_company_status($companyInfo);
    }
    if($orderInfo['type'] == 2){
        
        $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($orderInfo['tczhaopin_id']);
        if($tczhaopinInfo['top_time'] > TIMESTAMP){
            $top_time = $orderInfo['top_days'] * 86400 + $tczhaopinInfo['top_time'];
        }else{
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin')->update($orderInfo['tczhaopin_id'],$updateData);
        
        update_zhaopin_tongcheng($orderInfo['tczhaopin_id'],$tongbuParamArr);
        
    }
    if($orderInfo['type'] == 3){
        $renzhengStatus = 0;
        $renzhengInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$orderInfo['user_id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
        $renzhengInfo = array();
        if(is_array($renzhengInfoTmp) && !empty($renzhengInfoTmp)){
            $renzhengInfo = $renzhengInfoTmp[0];
            $renzhengStatus = 1;
        }

        $updateData = array();
        if($renzhengStatus == 1){
            $updateData['company_name']            = $renzhengInfo['name'];
            $updateData['company_nature_id']       = $renzhengInfo['nature_id'];
            $updateData['company_industry_id']     = $renzhengInfo['industry_id'];
            $updateData['company_scale_id']        = $renzhengInfo['scale_id'];
        }
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin')->update($orderInfo['tczhaopin_id'],$updateData);
        
        update_zhaopin_tongcheng($orderInfo['tczhaopin_id'],$tongbuParamArr);
        
    }
    if($orderInfo['type'] == 4){
        
        $resumeInfo = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_by_id($orderInfo['resume_id']);
        if($resumeInfo['top_time'] > TIMESTAMP){
            $top_time = $orderInfo['top_days'] * 86400 + $resumeInfo['top_time'];
        }else{
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($orderInfo['resume_id'],$updateData);
        
        update_resume_tongcheng($orderInfo['resume_id'],$tongbuParamArr);
        
    }
    if($orderInfo['type'] == 5){

        $insertData = array();
        $insertData['user_id']      = $orderInfo['user_id'];
        $insertData['resume_id']    = $orderInfo['resume_id'];
        $insertData['type']         = 2;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->insert($insertData);
    }
    if($orderInfo['type'] == 6){
        $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($orderInfo['vip_id']);
        $expire_time = $vipInfo['days'] * 86400;

        $userVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($orderInfo['user_id']);
        if($userVipInfo['id'] > 0){ 
            
            if($userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
                $updateData = array();
                $updateData['vip_id']           = $orderInfo['vip_id'];
                $updateData['expire_time']      = $userVipInfo['expire_time'] + $expire_time;
                $updateData['expire_status']    = 1;
                C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->update($userVipInfo['id'], $updateData);
            }else{
                $updateData = array();
                $updateData['vip_id']           = $orderInfo['vip_id'];
                $updateData['expire_time']      = $expire_time + TIMESTAMP;
                $updateData['expire_status']    = 1;
                C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->update($userVipInfo['id'], $updateData);
            }
            
            C::t("#tom_tczhaopin#tom_tczhaopin_log")->delete_vip_look_resume_by_user_id($orderInfo['user_id']);
            
        }else{
            $insertData = array();
            $insertData['user_id']          = $orderInfo['user_id'];
            $insertData['vip_id']           = $orderInfo['vip_id'];
            $insertData['expire_time']      = $expire_time + TIMESTAMP;
            $insertData['expire_status']    = 1;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->insert($insertData);

        }
    }
    if($orderInfo['type'] == 7){
        
        $companyInfo = C::t("#tom_tczhaopin#tom_tczhaopin_company")->fetch_by_id($orderInfo['company_id']);
        if($companyInfo['top_time'] > TIMESTAMP){
            $top_time = $orderInfo['top_days'] * 86400 + $companyInfo['top_time'];
        }else{
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tczhaopin#tom_tczhaopin_company')->update($orderInfo['company_id'],$updateData);
    }
    if($orderInfo['type'] == 8){
        
        $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($orderInfo['tczhaopin_id']);
        
        if($tczhaopinInfo['expire_time'] > TIMESTAMP){
            $fabu_time = $orderInfo['fabu_days'] * 86400 + $tczhaopinInfo['expire_time'];
        }else{
            $fabu_time = $orderInfo['fabu_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['expire_status']    = 1;
        $updateData['expire_time']      = $fabu_time;
        $updateData['pay_status']       = 2;
        $updateData['refresh_time']     = TIMESTAMP;
        $updateData['add_time']         = TIMESTAMP;
        $updateData['status']           = 1;
        C::t('#tom_tczhaopin#tom_tczhaopin')->update($orderInfo['tczhaopin_id'],$updateData);
        
        update_zhaopin_tongcheng($orderInfo['tczhaopin_id'],$tongbuParamArr);
        
        $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($orderInfo['user_id']);
        update_company_status($companyInfo);
    }
    if($orderInfo['type'] == 9){
        
        $meetingCompanyInfo = C::t("#tom_tczhaopin#tom_tczhaopin_meeting_company")->fetch_by_id($orderInfo['meeting_company_id']);
        
        $updateData = array();
        $updateData['pay_status']       = 2;
        C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->update($meetingCompanyInfo['id'],$updateData);
    }

    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($orderInfo['order_no'])));

    if($tczhaopinConfig['open_back_score'] == 1){
        
        $score_yuan = $tongchengConfig['score_yuan'];
        if(!empty($tczhaopinConfig['score_yuan'])){
            $score_yuan = $tczhaopinConfig['score_yuan'];
        }
        
        $score = ceil($orderInfo['pay_price']*$score_yuan);
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] + $score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 28;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    }
    
    # fc start
    $adminFc = false;
    if($__ShowTchehuoren == 1 && $userInfo['tj_hehuoren_id'] > 0){

        $shenyu_money = $orderInfo['pay_price'];
        $child_site_fc_money = $tchehuoren_fc_money = $tctchehuorenParent_fc_money = 0;
        
        $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($userInfo['tj_hehuoren_id']);
        if($tchehuorenInfo){
            $tchehuorenDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
            $tchehuorenUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tchehuorenInfo['openid']);
        }
        
        $tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
        if($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1){
            $tctchehuorenParentInfo = C::t("#tom_tchehuoren#tom_tchehuoren")->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
            $tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
            $tctchehuorenParentUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tctchehuorenParentInfo['openid']);
        }
        
        if($tchehuorenInfo && $tchehuorenInfo['status'] == 1 && $tchehuorenDengji['zp_fc_open'] == 1){
            if($orderInfo['site_id'] > 1 && $tczhaopinConfig['zizhandi_fc'] == 1){
                $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                $sitename = $sitesInfo['name'];
                if($__ShowTcadmin == 1 && $sitesInfo['hehuoren_fc_open'] == 1){
                    
                    $tchehuoren_fc_money = $orderInfo['pay_price'] * ($tchehuorenDengji['zp_fc_scale']/100);
                    $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2, '.', '');
                    
                    $fc_scale = $tcadminConfig['fc_scale'];
                    if($sitesInfo['zp_fc_scale'] > 0){
                        $fc_scale = $sitesInfo['zp_fc_scale'];
                    }
                    $child_site_fc_money = $orderInfo['pay_price'] * ($fc_scale/100);
                    $child_site_fc_money = number_format($child_site_fc_money,2, '.', '');
                    $child_site_fc_money = $child_site_fc_money - $tchehuoren_fc_money;
                    
                    if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                        $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                        if($tchehuorenConfig['subordinate_moneytype'] == 1){
                            $child_site_fc_money   = $child_site_fc_money - $tctchehuorenParent_fc_money;
                        }else{
                            $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                        }
                    }
                    
                    $shenyu_money = $shenyu_money - $child_site_fc_money - $tchehuoren_fc_money;

                }else{
                    if($__ShowTcadmin == 1 && $tczhaopinConfig['zizhandi_fc'] == 1){
                        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                        $fc_scale = $tcadminConfig['fc_scale'];
                        if($sitesInfo['zp_fc_scale'] > 0){
                            $fc_scale = $sitesInfo['zp_fc_scale'];
                        }
                        $child_site_fc_money = $orderInfo['pay_price'] * ($fc_scale/100);
                        $child_site_fc_money = number_format($child_site_fc_money,2, '.', '');
                    }
                    
                    $shenyu_money = $shenyu_money - $child_site_fc_money;
                    
                }
                
            }else{
                $sitename = $tczhaopinConfig['plugin_name'];
                $tchehuoren_fc_money = $orderInfo['pay_price'] * ($tchehuorenDengji['zp_fc_scale']/100);
                $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2, '.', '');
                
                if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                    $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                    $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                    if($tchehuorenConfig['subordinate_moneytype'] == 1){
                    }else{
                        $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                    }
                }
                
                $shenyu_money = $shenyu_money - $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
            }
            
            Log::DEBUG("update shenyu_money:" . $shenyu_money);
            Log::DEBUG("update child_site_fc_money:" . $child_site_fc_money);
            Log::DEBUG("update tchehuoren_fc_money:" . $tchehuoren_fc_money);
            Log::DEBUG("update TCtchehuoren_fc_money:" . $tctchehuorenParent_fc_money);
            
            if($orderInfo['pay_price'] >= ($child_site_fc_money +  $tchehuoren_fc_money + $tctchehuorenParent_fc_money)){  
                
                $content = '';
                if($orderInfo['type'] == 1 || $orderInfo['type'] == 2 || $orderInfo['type'] == 3){
                    $content = '['.$tczhaopinConfig['plugin_name'].']'.lang('plugin/tom_tczhaopin', 'paynotify_zhaopin_hehuoren_beizu_1') . $orderInfo['tczhaopin_id'] . lang('plugin/tom_tczhaopin', 'paynotify_hehuoren_beizu_2') . $userInfo['nickname'];
                }else if($orderInfo['type'] == 4 || $orderInfo['type'] == 5){
                    $content = '['.$tczhaopinConfig['plugin_name'].']'.lang('plugin/tom_tczhaopin', 'paynotify_resume_hehuoren_beizu_1') . $orderInfo['resume_id'] . lang('plugin/tom_tczhaopin', 'paynotify_hehuoren_beizu_2') . $userInfo['nickname'];
                }else if($orderInfo['type'] == 6){
                    $content = '['.$tczhaopinConfig['plugin_name'].']'.lang('plugin/tom_tczhaopin', 'paynotify_type_6');
                }else if($orderInfo['type'] == 7){
                    $content = '['.$tczhaopinConfig['plugin_name'].']'.lang('plugin/tom_tczhaopin', 'paynotify_type_7');
                }
                
                if($child_site_fc_money > 0){
                    $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);
                    
                    $old_money = 0;
                    if($walletInfo){
                        $old_money = $walletInfo['account_balance'];

                        $updateData = array();
                        $updateData['account_balance']  = $walletInfo['account_balance'] + $child_site_fc_money;
                        $updateData['total_income']     = $walletInfo['total_income'] + $child_site_fc_money;
                        C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
                    }else{
                        $insertData = array();
                        $insertData['site_id']              = $orderInfo['site_id'];
                        $insertData['account_balance']      = $child_site_fc_money;
                        $insertData['total_income']         = $child_site_fc_money;
                        $insertData['add_time']             = TIMESTAMP;
                        C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
                    }

                    $insertData = array();
                    $insertData['site_id']      = $orderInfo['site_id'];
                    $insertData['log_type']     = 1;
                    $insertData['change_money'] = $child_site_fc_money;
                    $insertData['old_money']    = $old_money;
                    $insertData['beizu']        = $content;
                    $insertData['order_no']     = $orderInfo['order_no'];
                    $insertData['order_type']   = 0;
                    $insertData['log_ip']       = $_G['clientip'];
                    $insertData['log_time']     = TIMESTAMP;
                    C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData); 
                }
                
                $type = '';
                if($orderInfo['type'] == 1){
                    $type = lang('plugin/tom_tczhaopin', 'paynotify_type_1');
                }else if($orderInfo['type'] == 2){
                    $type = lang('plugin/tom_tczhaopin', 'paynotify_type_2');
                }else if($orderInfo['type'] == 3){
                    $type = lang('plugin/tom_tczhaopin', 'paynotify_type_3');
                }else if($orderInfo['type'] == 4){
                    $type = lang('plugin/tom_tczhaopin', 'paynotify_type_4');
                }else if($orderInfo['type'] == 5){
                    $type = lang('plugin/tom_tczhaopin', 'paynotify_type_5');
                }else if($orderInfo['type'] == 6){
                    $type = lang('plugin/tom_tczhaopin', 'paynotify_type_6');
                }else if($orderInfo['type'] == 7){
                    $type = lang('plugin/tom_tczhaopin', 'paynotify_type_7');
                }
                
                $sendTemplateTchehuoren = false;
                if($tchehuoren_fc_money > 0){
                    $sendTemplateTchehuoren = true;
                    
                    $insertData = array();
                    $insertData['order_no']         = $orderInfo['order_no'];
                    $insertData['hehuoren_id']      = $tchehuorenInfo['id'];
                    $insertData['ly_user_id']       = $userInfo['id'];
                    $insertData['child_hehuoren_id'] = 0;
                    $insertData['today_time']       = $nowDayTime;
                    $insertData['week_time']        = $nowWeekTime;
                    $insertData['month_time']       = $nowMonthTime;
                    $insertData['type']             = $type;
                    $insertData['shouyi_price']     = $tchehuoren_fc_money;
                    $insertData['content']          = $content;
                    $insertData['shouyi_status']    = 1;
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                }
                
                $sendTemplateTchehuorenParent = false;
                if($tctchehuorenParent_fc_money > 0){
                    $sendTemplateTchehuorenParent = true;
                    
                    $insertData = array();
                    $insertData['order_no']         = $orderInfo['order_no'];
                    $insertData['hehuoren_id']      = $tctchehuorenParentInfo['id'];
                    $insertData['ly_user_id']       = $userInfo['id'];
                    $insertData['child_hehuoren_id'] = $tchehuorenInfo['id'];
                    $insertData['today_time']       = $nowDayTime;
                    $insertData['week_time']        = $nowWeekTime;
                    $insertData['month_time']       = $nowMonthTime;
                    $insertData['type']             = $type;
                    $insertData['shouyi_price']     = $tctchehuorenParent_fc_money;
                    $insertData['content']          = $content;
                    $insertData['shouyi_status']    = 1;
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                }
                
                if($sendTemplateTchehuoren == true){
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($tchehuorenInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                        $shouyiText = str_replace("{NICKNAME}",$userInfo['nickname'], lang('plugin/tom_tongcheng', 'paynotify_hehuoren_template'));
                        $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                        $shouyiText = str_replace("{TYPE}",$type, $shouyiText);
                        $shouyiText = str_replace("{MONEY}",$tchehuoren_fc_money, $shouyiText);
                        $smsData = array(
                            'first'         => $shouyiText,
                            'keyword1'      => $tchehuorenConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );
                        if(!empty($tchehuorenConfig['template_id'])){
                            $template_id = $tchehuorenConfig['template_id'];
                        }else{
                            $template_id = $tongchengConfig['template_id'];
                        }
                        @$r = $templateSmsClass->sendSms01($tchehuorenInfo['openid'], $template_id, $smsData);
                    }
                }
                
                if($sendTemplateTchehuorenParent == true){
                    
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($tctchehuorenParentInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                        $shouyiText = str_replace("{TCHEHUOREN}",$tchehuorenInfo['xm'], lang('plugin/tom_tongcheng', 'paynotify_hehuorenparent_template'));
                        $shouyiText = str_replace("{NICKNAME}",$userInfo['nickname'], $shouyiText);
                        $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                        $shouyiText = str_replace("{TYPE}",$type, $shouyiText);
                        $shouyiText = str_replace("{MONEY}",$tctchehuorenParent_fc_money, $shouyiText);
                        $smsData = array(
                            'first'         => $shouyiText,
                            'keyword1'      => $tchehuorenConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );
                        if(!empty($tchehuorenConfig['template_id'])){
                            $template_id = $tchehuorenConfig['template_id'];
                        }else{
                            $template_id = $tongchengConfig['template_id'];
                        }
                        @$r = $templateSmsClass->sendSms01($tctchehuorenParentInfo['openid'], $template_id, $smsData);
                    }
                }
            }
            
        }else{
            $adminFc = true;
        }
    }else{
        $adminFc = true;
    }
    
    if($__ShowTcadmin == 1 && $adminFc && $tczhaopinConfig['zizhandi_fc'] == 1){

        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
        $fc_scale = $tcadminConfig['fc_scale'];
        if($sitesInfo['zp_fc_scale'] > 0){
            $fc_scale = $sitesInfo['zp_fc_scale'];
        }
        $fc_money = $orderInfo['pay_price']*($fc_scale/100);
        $fc_money = number_format($fc_money,2, '.', '');

        Log::DEBUG("update fc_money:" . $fc_money);

        $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);

        $old_money = 0;
        if($walletInfo){
            $old_money = $walletInfo['account_balance'];

            $updateData = array();
            $updateData['account_balance']   = $walletInfo['account_balance'] + $fc_money;
            $updateData['total_income']   = $walletInfo['total_income'] + $fc_money;
            C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
        }else{
            $insertData = array();
            $insertData['site_id']              = $orderInfo['site_id'];
            $insertData['account_balance']      = $fc_money;
            $insertData['total_income']         = $fc_money;
            $insertData['add_time']             = TIMESTAMP;
            C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
        }
        
        $beizu = '';
        if($orderInfo['type'] == 1 || $orderInfo['type'] == 2 || $orderInfo['type'] == 3){
            $beizu = '['.$tczhaopinConfig['plugin_name'].']'.lang('plugin/tom_tczhaopin', 'paynotify_zhaopin_hehuoren_beizu_1') . $orderInfo['tczhaopin_id'] . lang('plugin/tom_tczhaopin', 'paynotify_hehuoren_beizu_2') . $userInfo['nickname'];
        }else if($orderInfo['type'] == 4 || $orderInfo['type'] == 5){
            $beizu = '['.$tczhaopinConfig['plugin_name'].']'.lang('plugin/tom_tczhaopin', 'paynotify_resume_hehuoren_beizu_1') . $orderInfo['resume_id'] . lang('plugin/tom_tczhaopin', 'paynotify_hehuoren_beizu_2') . $userInfo['nickname'];
        }else if($orderInfo['type'] == 6){
            $beizu = '['.$tczhaopinConfig['plugin_name'].']'.lang('plugin/tom_tczhaopin', 'paynotify_type_6');
        }else if($orderInfo['type'] == 7){
            $beizu = '['.$tczhaopinConfig['plugin_name'].']'.lang('plugin/tom_tczhaopin', 'paynotify_type_7');
        }

        $insertData = array();
        $insertData['site_id']      = $orderInfo['site_id'];
        $insertData['log_type']     = 1;
        $insertData['change_money'] = $fc_money;
        $insertData['old_money']    = $old_money;
        $insertData['beizu']        = $beizu;
        $insertData['order_no']     = $orderInfo['order_no'];
        $insertData['order_type']   = 0;
        $insertData['log_ip']       = $_G['clientip'];
        $insertData['log_time']     = TIMESTAMP;
        C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData);
        Log::DEBUG("update fc_end:" . $fc_money);
    }
    # fc end
    
    if(!empty($tongchengConfig['template_id']) && $tczhaopinInfo['shenhe_status'] == 2 && $orderInfo['type'] == 1){
        
        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($manageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$orderInfo['site_id']}&mod=managerList");
            $smsData = array(
                'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_fabuzhaopin_shenhe_msg'),
                'keyword1'      => $tczhaopinConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
        
        $zpmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinConfig['zpmanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($zpmanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$orderInfo['site_id']}&mod=managerList");
            $smsData = array(
                'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_fabuzhaopin_shenhe_msg'),
                'keyword1'      => $tczhaopinConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($zpmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
    if($orderInfo['type'] == 4 && !empty($tongchengConfig['template_id']) && $tczhaopinConfig['resume_must_shenhe'] == 1){
        if($resumeInfo['shenhe_status'] != 1){
            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$orderInfo['site_id']}&mod=managerResumeList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_faburesume_shenhe_msg'),
                    'keyword1'      => $tczhaopinConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
            
            $zpmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinConfig['zpmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($zpmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$orderInfo['site_id']}&mod=managerResumeList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_faburesume_shenhe_msg'),
                    'keyword1'      => $tczhaopinConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($zpmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
    }
    
    if($orderInfo['type'] == 5 && !empty($tongchengConfig['template_id'])){
        
        $resumeInfo = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_by_id($orderInfo['resume_id']);
        
        $toUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($resumeInfo['user_id']);

        $access_token = $weixinClass->get_access_token();
        
        $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($userInfo['id']);

        $renzhengCompanyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($userInfo['id']);
        if(is_array($renzhengCompanyInfo) && !empty($renzhengCompanyInfo)){
            $name = $renzhengCompanyInfo['name'];
        }else{
            $name = $userInfo['nickname'];
        }

        if($access_token && !empty($toUserInfo['openid'])){
            $template_sms = lang('plugin/tom_tczhaopin', 'ajax_look_resume_template');
            $template_sms = str_replace("{NAME}", $name, $template_sms);

            if(is_array($companyInfo) && !empty($companyInfo) && $companyInfo['show_status'] == 1){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=companyinfo&company_id={$companyInfo['id']}");
            }else{
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=index");
            }
            $smsData = array(
                'first'         => $template_sms,
                'keyword1'      => $tczhaopinConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($toUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
        
    }
    
    if($orderInfo['type'] == 6 && !empty($tongchengConfig['template_id'])){
        
        $template_first = str_replace("{NAME}",$userInfo['nickname'], lang('plugin/tom_tczhaopin','pay_vip_template_first'));
        $template_first = str_replace("{MONEY}",$orderInfo['pay_price'],$template_first);
        $template_first = str_replace("{VIPNAME}",$vipInfo['title'],$template_first);
        
        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($manageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$orderInfo['site_id']}&mod=index");
            $smsData = array(
                'first'         => $template_first,
                'keyword1'      => $tczhaopinConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }

        $zpmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinConfig['zpmanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($zpmanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$orderInfo['site_id']}&mod=index");
            $smsData = array(
                'first'         => $template_first,
                'keyword1'      => $tczhaopinConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($zpmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    if($orderInfo['type'] == 9 && !empty($tongchengConfig['template_id'])){
        
        Log::DEBUG("update type:" . $orderInfo['type']);
        
        $meetingInfo = C::t("#tom_tczhaopin#tom_tczhaopin_meeting")->fetch_by_id($orderInfo['meeting_id']);
        
        $template_first = str_replace("{USER}",$userInfo['nickname'], lang('plugin/tom_tczhaopin','ajax_template_pay_canhui_succ'));
        $template_first = str_replace("{PRICE}",$orderInfo['pay_price'],$template_first);
        $template_first = str_replace("{MEETING}",$meetingInfo['title'],$template_first);
        
        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
        $access_token = $weixinClass->get_access_token();
        Log::DEBUG("update typeacc:" . $access_token);
        if($access_token && !empty($manageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$orderInfo['site_id']}&mod=meetinginfo&meeting_id={$meetingInfo['id']}");
            $smsData = array(
                'first'         => $template_first,
                'keyword1'      => $tczhaopinConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }

        $zpmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinConfig['zpmanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($zpmanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$orderInfo['site_id']}&mod=meetinginfo&meeting_id={$meetingInfo['id']}");
            $smsData = array(
                'first'         => $template_first,
                'keyword1'      => $tczhaopinConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($zpmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
}