<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND user_id={$__UserInfo['id']}";
$order = " ORDER BY id DESC ";
$count = C::t('#tom_tczhaopin#tom_tczhaopin_collect')->fetch_all_count($where);
$collectListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_collect')->fetch_all_list($where, $order, $start, $pagesize);
$collectList = array();
if(is_array($collectListTmp) && !empty($collectListTmp)){
    foreach ($collectListTmp as $key => $value){
        
        $tczhaopinInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($value['tczhaopin_id']);
        if($tczhaopinInfoTmp['id'] > 0){
        }else{
            continue;
        }
        
        $collectList[$key] = $value;
        
        $cateChildInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($tczhaopinInfoTmp['cate_child_id']);
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tczhaopinInfoTmp['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tczhaopinInfoTmp['street_id']);

        $workWelfareArr = explode('-', trim($tczhaopinInfoTmp['work_welfare'], '-'));
        $welfareList = array();
        if(is_array($welfareArray) && !empty($welfareArray)){
            foreach($welfareArray as $k => $v){
                if(in_array($k,$workWelfareArr)){
                    $welfareList[$k]['name'] = $v;
                }
            }
        }
        
        $tczhaopinList[$key]['companyRenzheng']     = 0;
        $rzConpanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list(" AND user_id = {$tczhaopinInfoTmp['user_id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
        if(is_array($rzConpanyInfoTmp) && !empty($rzConpanyInfoTmp[0]) && $rzConpanyInfoTmp[0]['id'] > 0){
            $collectList[$key]['companyRenzheng']     = 1;
        }

        $collectList[$key]['tczhaopinInfo']   = $tczhaopinInfoTmp;
        $collectList[$key]['cateChildInfo']   = $cateChildInfoTmp;
        $collectList[$key]['welfareList']     = $welfareList;
        $collectList[$key]['areaInfo']        = $areaInfoTmp;
        $collectList[$key]['streetInfo']      = $streetInfoTmp;
        
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=zhaopincollect&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=zhaopincollect&page={$nextPage}";

$ajaxDelZhaopinCollectUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=del_zhaopin_collect&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:zhaopincollect");