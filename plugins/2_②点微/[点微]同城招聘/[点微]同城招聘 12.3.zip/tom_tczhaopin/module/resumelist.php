<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
    
$outStr = '';

$keyword                    = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$cate_id                    = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$cate_child_id              = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
$area_id                    = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id                  = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$sex                        = intval($_GET['sex'])>0? intval($_GET['sex']):0;
$type                       = intval($_GET['type'])>0? intval($_GET['type']):0;
$work_status                = intval($_GET['work_status'])>0? intval($_GET['work_status']):0;
$xueli                      = intval($_GET['xueli'])>0? intval($_GET['xueli']):0;
$jingyan                    = intval($_GET['jingyan'])>0? intval($_GET['jingyan']):0;
$refresh_type               = intval($_GET['refresh_type'])>0? intval($_GET['refresh_type']):0;
$page                       = intval($_GET['page'])>0? intval($_GET['page']):0;
$pagesize                   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$cate_child_search = '';
if($cate_child_id > 0){
    $cate_child_search = '-'.$cate_child_id.'-';
}

$whereStr = ' AND status=1 AND shenhe_status=1 AND gongkai_status = 1 AND deleted = 0 ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if($cate_id > 0){
    $whereStr.= " AND cate_id={$cate_id} ";
}
if($area_id > 0){
    $whereStr.= " AND area_id={$area_id} ";
}
if($street_id > 0){
    $whereStr.= " AND street_id={$street_id} ";
}
if($sex > 0){
    $whereStr.= " AND sex={$sex} ";
}
if($type > 0){
    $whereStr.= " AND type={$type} ";
}
if($work_status > 0){
    $whereStr.= " AND work_status={$work_status} ";
}
if($xueli > 0){
    $whereStr.= " AND xueli={$xueli} ";
}
if($jingyan > 0){
    $whereStr.= " AND work_jingyan={$jingyan} ";
}

if($refresh_type > 0){
    $min_refresh_time = TIMESTAMP;
    if($refresh_type == 1){
        $min_refresh_time = $min_refresh_time - (1 * 86400);
    }else if($refresh_type == 2){
        $min_refresh_time = $min_refresh_time - (7 * 86400);
    }else if($refresh_type == 3){
        $min_refresh_time = $min_refresh_time - (14 * 86400);
    }else if($refresh_type == 4){
        $min_refresh_time = $min_refresh_time - (30 * 86400);
    }
    $whereStr.= " AND refresh_time >= {$min_refresh_time} ";
}

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
$resumeListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_list($whereStr," ORDER BY top_status DESC,refresh_time DESC,id DESC ",$start,$pagesize,$cate_child_search,$keyword);
$resumeList = array();
if(is_array($resumeListTmp) && !empty($resumeListTmp)){
    foreach ($resumeListTmp as $key => $value) {
        $resumeList[$key] = $value;

        if(!empty($value['avatar'])){
            if(!preg_match('/^http/', $value['avatar'])){
                if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                    $avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
                }else{
                    $avatar = $value['avatar'];
                }
            }else{
                $avatar = $value['avatar'];
            }
        }else{
            if($value['sex'] == 1){
                $avatar = $man_resume_avatar;
            }else if($value['sex'] == 2){
                $avatar = $woman_resume_avatar;
            }
        }

        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($value['cate_id']);
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);

        $nowYear = dgmdate(TIMESTAMP,"Y",$tomSysOffset);

        $resumeList[$key]['age'] = $nowYear - $value['birth_year'];
        $resumeList[$key]['avatar'] = $avatar;
        $resumeList[$key]['cateInfo'] = $cateInfo;
        $resumeList[$key]['areaInfo'] = $areaInfoTmp;
        $resumeList[$key]['streetInfo'] = $streetInfoTmp;
    }
}

if(is_array($resumeList) && !empty($resumeList)){
    foreach($resumeList as $key => $val){
        $outStr .= '<a class="resume-list__item" href="plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=resumeinfo&resume_id='.$val['id'].'">';
            $outStr .= '<div class="resume-item__hd dislay-flex">';
                $outStr .= '<div class="item-hd__lt">';
                    $outStr .= '<img src="'.$val['avatar'].'">';
                    $sex_call = '';
                    if($val['sex'] == 1){
                        $sex_call = lang('plugin/tom_tczhaopin', 'resumelist_sex_1_call');
                        $outStr .= '<span class="sex"><i class="tciconfont tcicon-nan"></i></span>';
                    }else if($val['sex'] == 2){
                        $sex_call = lang('plugin/tom_tczhaopin', 'resumelist_sex_2_call');
                        $outStr .= '<span class="sex"><i class="tciconfont tcicon-nv"></i></span>';
                    }
                $outStr .= '</div>';
                $outStr .= '<div class="item-hd__main ">';
                    $outStr .= '<div class="main-title">';
                        if($val['type'] == 2){
                            $outStr .= '<span class="top" style="background: #18a200;">'.lang('plugin/tom_tczhaopin', 'resume_type_2').'</span>';
                        }
                        $nowTime = TIMESTAMP;
                        if($val['top_status'] == 1 && $val['top_time'] > $nowTime){
                            $outStr .= '<span class="top">'.lang('plugin/tom_tczhaopin', 'top').'</span>';
                        }
                        if($val['video_status'] == 1){
                            $outStr .= '<i class="tciconfont tcicon-video"></i>';
                        }
                        $name = cutstr($val['name'], 2,'');
                        $outStr .= '<span class="name">'.$name.$sex_call.'</span>';
                        $outStr .= '<span class="worker">('.$val['cate_child_str'].')</span>';
                    $outStr .= '</div>';
                    $outStr .= '<div class="main-xinxi clearfix">';
                        $outStr .= '<span class="main-xinxi__itme">'.$workJingyanArray[$val['work_jingyan']].lang('plugin/tom_tczhaopin', 'resumelist_work_jingyan').'</span>';
                        $outStr .= '<span class="main-xinxi__itme">'.$val['age'].lang('plugin/tom_tczhaopin', 'resumelist_suei').'</span>';
                        $outStr .= '<span class="main-xinxi__itme">'.$xueliArray[$val['xueli']].'</span>';
                    $outStr .= '</div>';
                    $outStr .= '<div class="main-jingli">'.$val['work_jingli'].'</div>';
                $outStr .= '</div>';
                $outStr .= '<div class="item-hd__rt">';
                    if($val['work_salary'] > 1){
                        $outStr .= '<div class="salary">'.$workSalaryArray[$val['work_salary']].'<span class="xinzi">'.lang('plugin/tom_tczhaopin', 'zhaopinlist_yuan_month').'</span></div>';
                    }else{
                        $outStr .= '<div class="salary">'.$workSalaryArray[$val['work_salary']].'</div>';
                    }
                    $month = dgmdate($val['refresh_time'],"n",$tomSysOffset);
                    $day = dgmdate($val['refresh_time'],"j",$tomSysOffset);
                    if($val['refresh_time'] > $nowDayTime){
                        $outStr .= '<div class="time">'.lang('plugin/tom_tczhaopin', 'today').'</div>';
                    }else{
                        $outStr .= '<div class="time">'.dgmdate($val['refresh_time'],"Y/m/d",$tomSysOffset).'</div>';
                    }
                    if($val['areaInfo']['id'] > 0){
                        if($val['streetInfo']['id'] > 0){
                            $outStr .= '<div class="diqu">'.$val['streetInfo']['name'].'</div>';
                        }else{
                            $outStr .= '<div class="diqu">'.$val['areaInfo']['name'].'</div>';
                        }
                    }else{
                        $outStr .= '<div class="diqu">'.lang('plugin/tom_tczhaopin', 'resumelist_quancheng').'</div>';
                    }
                    //$outStr .= '<div class="yaowei_btn">'.lang('plugin/tom_tczhaopin', 'resumelist_yaoyue_btn').'</div>';
                $outStr .= '</div>';
            $outStr .= '</div>';
        $outStr .= '</a>';

    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;