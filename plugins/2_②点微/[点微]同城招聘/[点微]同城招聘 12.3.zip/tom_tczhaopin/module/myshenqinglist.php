<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND t.user_id = {$__UserInfo['id']} AND z.shenhe_status = 1 AND r.shenhe_status = 1  ";

$order = " ORDER BY t.add_time DESC,t.id DESC ";
$count = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_count($where);
$shenqingListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_list($where,$order,$start,$pagesize);
$shenqingList = array();
if(is_array($shenqingListTmp) && !empty($shenqingListTmp)){
    foreach ($shenqingListTmp as $key => $value){
        $shenqingList[$key] = $value;
        
        $cateChildInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($value['cate_child_id']);
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);

        $workWelfareArr = explode('-', trim($value['work_welfare'], '-'));
        $welfareList = array();
        if(is_array($welfareArray) && !empty($welfareArray)){
            foreach($welfareArray as $k => $v){
                if(in_array($k,$workWelfareArr)){
                    $welfareList[$k]['name'] = $v;
                }
            }
        }
        
        $tczhaopinList[$key]['companyRenzheng']     = 0;
        $rzConpanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list(" AND user_id = {$value['z_user_id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
        if(is_array($rzConpanyInfoTmp) && !empty($rzConpanyInfoTmp[0]) && $rzConpanyInfoTmp[0]['id'] > 0){
            $shenqingList[$key]['companyRenzheng']     = 1;
        }

        $shenqingList[$key]['cateChildInfo']   = $cateChildInfoTmp;
        $shenqingList[$key]['welfareList']     = $welfareList;
        $shenqingList[$key]['areaInfo']        = $areaInfoTmp;
        $shenqingList[$key]['streetInfo']      = $streetInfoTmp;
        
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myshenqinglist&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myshenqinglist&page={$nextPage}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:myshenqinglist");