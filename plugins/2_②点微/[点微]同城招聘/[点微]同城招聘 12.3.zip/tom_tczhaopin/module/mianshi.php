<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$resume_id  = intval($_GET['resume_id'])>0? intval($_GET['resume_id']):0;

$resumeInfo = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_by_id($resume_id);

$rencaiInfo  = C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->fetch_all_list("AND resume_id = {$resume_id} AND user_id = {$__UserInfo['id']}","",0,1);

if(is_array($rencaiInfo) && !empty($rencaiInfo)){
}else{
    $shenqingcount = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_count(" AND z.user_id = {$__UserInfo['id']} AND t.resume_id = {$resume_id}  ");
    if($shenqingcount > 0){
    }else{
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=index");exit;
    }
}

if($_GET['act'] == 'save' && submitcheck('user_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $tczhaopin_id   = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):0;
    $address        = isset($_GET['address'])? addslashes($_GET['address']):'';
    $xm             = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $latitude       = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude      = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $beizu          = isset($_GET['beizu'])? addslashes($_GET['beizu']):'';
    
    $mianshiInfo = C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->fetch_all_list("AND tczhaopin_id = {$tczhaopin_id} AND resume_id = {$resume_id}","",0,1);
    if(is_array($mianshiInfo) && !empty($mianshiInfo)){
        $updateData = array();
        $updateData['xm']           = $xm;
        $updateData['tel']          = $tel;
        $updateData['address']      = $address;
        $updateData['latitude']     = $latitude;
        $updateData['longitude']    = $longitude;
        $updateData['beizu']        = $beizu;
        $updateData['status']       = 0;
        $updateData['add_time']     = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->update($mianshiInfo[0]['id'],$updateData);
        
        $mianshi_id = $mianshiInfo[0]['id'];
        
    }else{
        $insertData = array();
        $insertData['user_id']           = $resumeInfo['user_id'];
        $insertData['yaoqing_user_id']   = $__UserInfo['id'];
        $insertData['tczhaopin_id']      = $tczhaopin_id;
        $insertData['resume_id']         = $resume_id;
        $insertData['xm']                = $xm;
        $insertData['tel']               = $tel;
        $insertData['address']           = $address;
        $insertData['latitude']          = $latitude;
        $insertData['longitude']         = $longitude;
        $insertData['beizu']             = $beizu;
        $insertData['add_time']          = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->insert($insertData);
        
        $mianshi_id = C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->insert_id();
    }

    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($resumeInfo['user_id']);

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

    $access_token = $weixinClass->get_access_token();

    if($access_token && !empty($toUser['openid'])){
       
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$toUser['site_id']}&mod=mianshilist&mianshi_id={$mianshi_id}&type=1");
        $template_first =  lang('plugin/tom_tczhaopin','mianshi_resume_template');

        $smsData = array(
            'first'         => $template_first,
            'keyword1'      => $tczhaopinConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);

    }
    
    echo 200;exit;
}

$zhaopinListTmp = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ", 'ORDER BY id DESC', 0, 100);
$zhaopinList = array();
if(is_array($zhaopinListTmp) && !empty($zhaopinListTmp)){
    foreach($zhaopinListTmp as $key => $value){
        $zhaopinList[$key] = $value;
    }
}

$address = $xm = $tel = $beizu = $latitude = $longitude = '';
$mianshiInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->fetch_all_list("AND yaoqing_user_id = {$__UserInfo['id']}", " ORDER BY add_time DESC,id DESC ",0,1);
if(is_array($mianshiInfoTmp) && !empty($mianshiInfoTmp)){
    $address = $mianshiInfoTmp[0]['address'];
    $latitude = $mianshiInfoTmp[0]['latitude'];
    $longitude = $mianshiInfoTmp[0]['longitude'];
    $xm  = $mianshiInfoTmp[0]['xm'];
    $tel = $mianshiInfoTmp[0]['tel'];
    $beizu = $mianshiInfoTmp[0]['beizu'];
}else{
    $zhaopinInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ", "ORDER BY refresh_time DESC,id DESC ",0,1);
    if(is_array($zhaopinInfoTmp) && !empty($zhaopinInfoTmp)){
        $address = $zhaopinInfoTmp[0]['address'];
        $latitude = $zhaopinInfoTmp[0]['latitude'];
        $longitude = $zhaopinInfoTmp[0]['longitude'];
        $xm      = $zhaopinInfoTmp[0]['xm'];
        $tel     = $zhaopinInfoTmp[0]['tel'];
    }
}

$saveUrl       = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=mianshi&resume_id={$resume_id}act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:mianshi");