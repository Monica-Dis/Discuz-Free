<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
    
$outStr = '';

$industry_id                = intval($_GET['industry_id'])>0? intval($_GET['industry_id']):0;
$page                       = intval($_GET['page'])>0? intval($_GET['page']):0;
$pagesize                   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):15;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;

$whereStr = ' AND c.show_status=1 AND r.shenhe_status = 1 ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND c.site_id IN({$sql_in_site_ids}) ";
}
if($industry_id > 0){
    $whereStr .= "  AND r.industry_id = {$industry_id} ";
}

$companyListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_company")->fetch_all_company_rzcompany_list($whereStr, 'ORDER BY c.top_status DESC,c.csort ASC, c.id DESC', $start, $pagesize);
$companyList = array();
if(is_array($companyListTmp) && !empty($companyListTmp)){
    foreach ($companyListTmp as $key => $value) {

        $companyList[$key] = $value;

        $renzhengNatureInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_nature")->fetch_by_id($value['nature_id']);
        $renzhengScaleInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_scale")->fetch_by_id($value['scale_id']);
        $renzhengIndustryInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_industry")->fetch_by_id($value['industry_id']);

        if(!preg_match('/^http/', $value['logo']) ){
            if(strpos($value['logo'], 'source/plugin/tom_') === FALSE){
                $renzhengCompanyLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['logo'];
            }else{
                $renzhengCompanyLogo = $value['logo'];
            }
        }else{
            $renzhengCompanyLogo = $value['logo'];
        }
        $companyList[$key]['logo']                  = $renzhengCompanyLogo;
        $companyList[$key]['renzhengScaleInfo']     = $renzhengScaleInfo;
        $companyList[$key]['renzhengIndustryInfo']  = $renzhengIndustryInfo;

    }
}

if(is_array($companyList) && !empty($companyList)){
    foreach($companyList as $key => $val){
        $outStr .= '<a class="companylist-list__item dislay-flex" href="plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=companyinfo&company_id='.$val['id'].'">';
            $outStr .= '<div class="company-item__lt">';
                $outStr .= '<img src="'.$val['logo'].'">';
            $outStr .= '</div>';
            $outStr .= '<div class="company-item__rt">';
                $outStr .= '<div class="company-rt__title">';
                    $nowTime = TIMESTAMP;
                    if($val['top_status'] == 1 && $val['top_time'] > $nowTime){
                        $outStr .= '<span class="top">'.lang('plugin/tom_tczhaopin', 'top').'</span>';
                    }
                    $outStr .= ''.$val['name'];
                $outStr .= '</div>';
                $outStr .= '<div class="company-rt__info dislay-flex"><span class="lt flex"><span>'.$val['renzhengScaleInfo']['name'].''.lang('plugin/tom_tczhaopin','ajax_companylist_ren').'</span><span>'.$val['renzhengIndustryInfo']['name'].'</span></span><span class="rt">'.$val['num'].'<span>'.lang('plugin/tom_tczhaopin','ajax_companylist_zhaopin_num').'</span></span></div>';
                $outStr .= '<div class="company-rt__address"><i class="tciconfont tcicon-dingwei"></i>'.$val['address'].'</div>';
            $outStr .= '</div>';
        $outStr .= '</a>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;