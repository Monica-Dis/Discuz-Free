<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$focuspicListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->fetch_all_list(" AND site_id={$site_id} AND type = 2 "," ORDER BY fsort ASC,id DESC ",0,10);
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
}else{
    $focuspicListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->fetch_all_list(" AND site_id=1 AND type = 2 "," ORDER BY fsort ASC,id DESC ",0,10);
}
$focuspicList = array();
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
    foreach($focuspicListTmp as $key => $value){
        $focuspicList[$key] = $value;

        $focuspicList[$key]['link'] = str_replace("{site}",$site_id, $focuspicList[$key]['link']);

        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }

        $focuspicList[$key]['picurl'] = $picurl;
    }
}

$md5HostUrl = md5($_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=meeting");

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=meeting";
if($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0){
    if($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1){
        $shareUrl   = $shareUrl."&tjid={$tchehuorenInfoTmp['id']}";
    }
}
$ajaxListUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=meetinglist&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:meeting");