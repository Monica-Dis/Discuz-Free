<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$zhaopinSetting['zhaopinlist_top_bgcolor'] = trim($zhaopinSetting['zhaopinlist_top_bgcolor']);
    
$outStr = '';

$keyword                    = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$user_id                    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$area_id                    = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id                  = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$cate_id                    = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$cate_child_id              = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
$cate_child_ids             = !empty($_GET['cate_child_ids'])? addslashes($_GET['cate_child_ids']):'';
$type                       = intval($_GET['type'])>0? intval($_GET['type']):0;
$xueli                      = intval($_GET['xueli'])>0? intval($_GET['xueli']):0;
$salary                     = intval($_GET['salary'])>0? intval($_GET['salary']):0;
$jingyan                    = intval($_GET['jingyan'])>0? intval($_GET['jingyan']):0;
$refresh_type               = intval($_GET['refresh_type'])>0? intval($_GET['refresh_type']):0;
$scale_id                   = intval($_GET['scale_id'])>0? intval($_GET['scale_id']):0;
$nature_id                  = intval($_GET['nature_id'])>0? intval($_GET['nature_id']):0;
$company_renzheng_status    = intval($_GET['company_renzheng_status'])>0? intval($_GET['company_renzheng_status']):0;
$company_id                 = intval($_GET['company_id'])>0? intval($_GET['company_id']):0;
$meeting_id                 = intval($_GET['meeting_id'])>0? intval($_GET['meeting_id']):0;
$page                       = intval($_GET['page'])>0? intval($_GET['page']):0;
$pagesize                   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;
$ordertype                  = !empty($_GET['ordertype'])? addslashes($_GET['ordertype']):'';
$jianzhi_cate_id            = intval($_GET['jianzhi_cate_id'])>0? intval($_GET['jianzhi_cate_id']):0;
$jianzhi_jiesuan_fangshi    = intval($_GET['jianzhi_jiesuan_fangshi'])>0? intval($_GET['jianzhi_jiesuan_fangshi']):0;

$meeting_click_id           = intval($_GET['meeting_click_id'])>0? intval($_GET['meeting_click_id']):0;

$no_tczhaopin_id            = intval($_GET['no_tczhaopin_id'])>0? intval($_GET['no_tczhaopin_id']):0;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$cate_child_ids_arr_tmp = explode(',', $cate_child_ids);
$cate_child_ids = '';
$cate_child_ids_arr = array();
if(is_array($cate_child_ids_arr_tmp) && !empty($cate_child_ids_arr_tmp)){
    foreach ($cate_child_ids_arr_tmp as $key => $value){
        $value_tmp = intval($value);
        if($value_tmp > 0){
            $cate_child_ids_arr[] = $value_tmp;
        }
    }
    if(!empty($cate_child_ids_arr)){
        $cate_child_ids = implode(',', $cate_child_ids_arr);
    }
}

$whereStr = ' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if($no_tczhaopin_id > 0){
    $whereStr.= " AND id != {$no_tczhaopin_id} ";
}
if($user_id > 0){
    $whereStr.= " AND user_id={$user_id} ";
}
if($area_id > 0){
    $whereStr.= " AND area_id={$area_id} ";
}
if($street_id > 0){
    $whereStr.= " AND street_id={$street_id} ";
}
if($cate_id > 0){
    $whereStr.= " AND cate_id={$cate_id} ";
}
if(!empty($cate_child_ids)){
    $whereStr.= " AND cate_child_id IN ({$cate_child_ids}) ";
}else{
    if($cate_child_id > 0){
        $whereStr.= " AND cate_child_id={$cate_child_id} ";
    }
}
if($jianzhi_cate_id > 0){
    $whereStr.= " AND jianzhi_cate_id={$jianzhi_cate_id} ";
}
if($type > 0){
    $whereStr.= " AND type={$type} ";
}
if($xueli > 0){
    $whereStr.= " AND demand_xueli={$xueli} ";
}
if($salary > 0){
    if($salary == 2){
        $whereStr.= " AND (work_salary = {$salary} OR work_salary_min < 1000) ";
    }else if($salary == 3){
        $whereStr.= " AND (work_salary = {$salary} OR (work_salary_max < 2000 AND work_salary_max > 1000)) ";
    }else if($salary == 4){
        $whereStr.= " AND (work_salary = {$salary} OR (work_salary_max < 3000 AND work_salary_max > 2000)) ";
    }else if($salary == 5){
        $whereStr.= " AND (work_salary = {$salary} OR (work_salary_max < 4000 AND work_salary_max > 3000)) ";
    }else if($salary == 6){
        $whereStr.= " AND (work_salary = {$salary} OR (work_salary_max < 5000 AND work_salary_max > 4000)) ";
    }else if($salary == 7){
        $whereStr.= " AND (work_salary = {$salary} OR (work_salary_max < 8000 AND work_salary_max > 5000)) ";
    }else if($salary == 8){
        $whereStr.= " AND (work_salary = {$salary} OR (work_salary_max < 12000 AND work_salary_max > 8000)) ";
    }else if($salary == 9){
        $whereStr.= " AND (work_salary = {$salary} OR (work_salary_max < 20000 AND work_salary_max > 12000)) ";
    }else if($salary == 10){
        $whereStr.= " AND (work_salary = {$salary} OR work_salary_max > 20000) ";
    }else{
        $whereStr.= " AND work_salary = {$salary} ";
    }
}
if($jingyan > 0){
    $whereStr.= " AND demand_jingyan={$jingyan} ";
}
if($jianzhi_jiesuan_fangshi > 0){
    $whereStr.= " AND jianzhi_jiesuan_fangshi={$jianzhi_jiesuan_fangshi} ";
}

if($refresh_type > 0){
    $min_refresh_time = TIMESTAMP;
    if($refresh_type == 1){
        $min_refresh_time = $min_refresh_time - (1 * 86400);
    }else if($refresh_type == 2){
        $min_refresh_time = $min_refresh_time - (7 * 86400);
    }else if($refresh_type == 3){
        $min_refresh_time = $min_refresh_time - (14 * 86400);
    }else if($refresh_type == 4){
        $min_refresh_time = $min_refresh_time - (30 * 86400);
    }
    $whereStr.= " AND refresh_time >= {$min_refresh_time} ";
}

if($scale_id > 0){
    $whereStr.= " AND company_scale_id={$scale_id} ";
}
if($nature_id > 0){
    $whereStr.= " AND company_nature_id={$nature_id} ";
}
if($company_id > 0){
    $whereStr.= " AND company_id={$company_id} ";
}

if($meeting_id > 0){
    
    $meetingInfo = C::t("#tom_tczhaopin#tom_tczhaopin_meeting")->fetch_by_id($meeting_id);
    
    $companyWhereStr = " AND meeting_id = {$meeting_id} AND status = 1 AND (pay_status = 0 OR pay_status = 2) ";
    $meetingCompanyListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_meeting_company")->fetch_all_list($companyWhereStr, 'ORDER BY is_recommend DESC, csort ASC, id DESC', 0, 1000);
    if($meetingInfo['zhaopin_list_type'] == 1){
        $tczhaopinIdsStr = '0';
        $tczhaopinIds = array();
        if(is_array($meetingCompanyListTmp) && !empty($meetingCompanyListTmp)){
            foreach($meetingCompanyListTmp as $key => $value){
                $tczhaopinIds[] = $value['tczhaopin_ids'];
            }
            $tczhaopinIdsStr = implode(',', $tczhaopinIds);
        }
        $whereStr.= " AND id IN ({$tczhaopinIdsStr}) ";
    }else{
        $tczhaopinCompanyIdsStr = '0';
        $tczhaopinCompanyIds = array();
        if(is_array($meetingCompanyListTmp) && !empty($meetingCompanyListTmp)){
            foreach($meetingCompanyListTmp as $key => $value){
                $tczhaopinCompanyIds[] = $value['company_id'];
            }
            $tczhaopinCompanyIdsStr = implode(',', $tczhaopinCompanyIds);
        }
        $whereStr.= " AND company_id IN ({$tczhaopinCompanyIdsStr}) ";
    }
}

if($company_renzheng_status == 1){
    $renzhengListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list(" AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1000);
    $renzhengUserIdsArr = array();
    if(is_array($renzhengListTmp) && !empty($renzhengListTmp)){
        foreach($renzhengListTmp as $key => $value){
            $renzhengUserIdsArr[] = $value['user_id'];
        }
    }
    $renzhengUserIds = implode(',', $renzhengUserIdsArr);
    if(!empty($renzhengUserIds)){
        $whereStr.= " AND user_id IN({$renzhengUserIds}) ";
    }
}

$orderByWhere = "ORDER BY top_status DESC,over_status ASC,refresh_time DESC,id DESC";
if($ordertype == 'hot'){
    $orderByWhere = "ORDER BY top_status DESC,over_status ASC,clicks DESC,refresh_time DESC,id DESC";
}
if($ordertype == 'new'){
    $orderByWhere = "ORDER BY over_status ASC,refresh_time DESC,id DESC";
}

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
$tczhaopinList = array();
if($ordertype == 'nearby' && !empty($latitude) && !empty($longitude)){
    
    $whereStr.= " AND over_status = 0 ";
    
    $tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_nearby_list($whereStr,$start,$pagesize,$latitude,$longitude,$keyword);
}else{
    $tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list($whereStr,$orderByWhere,$start,$pagesize,$keyword);
}
if(is_array($tczhaopinListTmp) && !empty($tczhaopinListTmp)){
    foreach ($tczhaopinListTmp as $key => $value) {
        $tczhaopinList[$key] = $value;

        $workWelfareArr = explode('-', trim($value['work_welfare'], '-'));
        $welfareList = array();
        if(is_array($welfareArray) && !empty($welfareArray)){
            foreach($welfareArray as $k => $v){
                if(in_array($k,$workWelfareArr)){
                    $welfareList[$k]['name'] = $v;
                }
            }
        }

        $shenqingStatus = 0;
        if($__UserInfo['id'] > 0){
            $shenqingInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_list("AND tczhaopin_id = {$value['id']} AND user_id = {$__UserInfo['id']} "," ORDER BY id DESC ",0,1);
            if(is_array($shenqingInfoTmp) && !empty($shenqingInfoTmp['0'])){
                $shenqingStatus = 1;
            }
        }

        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($value['cate_child_id']);
        $areaInfoTmp = $streetInfoTmp = array();
        if($value['area_id'] > 0){
            $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
            $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
        }
        
        $tczhaopinList[$key]['companyRenzheng']     = 0;
        $rzConpanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list(" AND user_id = {$value['user_id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
        if(is_array($rzConpanyInfoTmp) && !empty($rzConpanyInfoTmp[0]) && $rzConpanyInfoTmp[0]['id'] > 0){
            $tczhaopinList[$key]['companyRenzheng']     = 1;
        }

        $tczhaopinList[$key]['welfareList']     = $welfareList;
        $tczhaopinList[$key]['shenqingStatus']  = $shenqingStatus;
        $tczhaopinList[$key]['cateInfo']        = $cateInfo;
        $tczhaopinList[$key]['areaInfo']        = $areaInfoTmp;
        $tczhaopinList[$key]['streetInfo']      = $streetInfoTmp;
    }
}

if(is_array($tczhaopinList) && !empty($tczhaopinList)){
    foreach($tczhaopinList as $key => $val){
        
        $topbgcolor = '';
       if(!empty($zhaopinSetting['zhaopinlist_top_bgcolor']) && $val['top_status'] == 1 && $val['top_time'] > $nowTime){
           $topbgcolor = 'style="background: '.$zhaopinSetting['zhaopinlist_top_bgcolor'].';"';
       }
        
        if($meeting_click_id > 0){
            $outStr .= '<a class="zhaopin-list__item dislay-flex" '.$topbgcolor.' href="plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$val['id'].'&meeting_click_id='.$meeting_click_id.'">';
        }else{
            $outStr .= '<a class="zhaopin-list__item dislay-flex" '.$topbgcolor.' href="plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$val['id'].'">';
        }
            $outStr .= '<div class="zp-item__lt flex">';
                $outStr .= '<div class="zp-lt__title">';
                $nowTime = TIMESTAMP;
                if($val['top_status'] == 1 && $val['top_time'] > $nowTime){
                    $outStr .= '<span class="top">'.lang('plugin/tom_tczhaopin', 'top').'</span>';
                }
                if($val['type'] == 2){
                    $outStr .= '<span class="top" style="background: #18a200;">'.lang('plugin/tom_tczhaopin', 'zhaopinlist_type_2').'</span>';
                }
                $outStr .= $val['title'].'';
                if($val['companyRenzheng'] == 1){
                    $outStr.= '<i class="tciconfont tcicon-renzheng"></i>';
                }
                if($val['video_status'] == 1){
                    $outStr.= '<i class="tciconfont tcicon-video"></i>';
                }
                $outStr .= '</div>';
                $outStr .= '<div class="zp-lt__xinzi dislay-flex">';
                    if($val['type'] == 1){
                        if($val['demand_jingyan'] > 0){
                            $outStr .= '<span class="work">'.$workJingyanArray[$val['demand_jingyan']].lang('plugin/tom_tczhaopin', 'zhaopinlist_demand_jingyan').'</span>&nbsp;&nbsp;|&nbsp;&nbsp;';
                        }else{
                            $outStr .= '<span class="work">'.lang('plugin/tom_tczhaopin', 'zhaopinlist_demand_jingyan_0').'</span>&nbsp;&nbsp;|&nbsp;&nbsp;';
                        }
                    }else if($val['jianzhi_jiesuan_fangshi'] > 0){
                        $outStr .= '<span class="work">'.$jianzhiJieSuanFangshiArray[$val['jianzhi_jiesuan_fangshi']].'</span>&nbsp;&nbsp;|&nbsp;&nbsp;';
                    }
                    if($val['renshu'] == 0){
                        $outStr .= '<span class="work">'.lang('plugin/tom_tczhaopin', 'zhaopinlist_zp_ruogan').'</span>';
                    }else{
                        $outStr .= '<span class="work">'.lang('plugin/tom_tczhaopin', 'zhaopinlist_zp_1').$val['renshu'].lang('plugin/tom_tczhaopin', 'zhaopinlist_zp_2').'</span>';
                    }
                    if($val['area_id'] > 0){
                        if($val['street_id'] > 0){
                            $outStr .= '&nbsp;&nbsp;|&nbsp;&nbsp;<div class="work">'.$val['areaInfo']['name'].'-'.$val['streetInfo']['name'].'</div>';
                        }else{
                            $outStr .= '&nbsp;&nbsp;|&nbsp;&nbsp;<span class="work">'.$val['areaInfo']['name'].'</span>';
                        }
                    }
                $outStr .= '</div>';
                if($val['type'] == 1){
                    $outStr .= '<div class="zp-lt__fuli dislay-flex">';
                        if(is_array($val['welfareList']) && !empty($val['welfareList'])){
                            foreach($val['welfareList'] as $k => $v){
                                $outStr .= '<span class="fuli">'.$v['name'].'</span>';
                            }
                        }else{
                            $outStr .= '<span class="fuli">'.lang('plugin/tom_tczhaopin', 'zhaopinlist_fuli_qita').'</span>';
                        }
                    $outStr .= '</div>';
                }
                $outStr .= '<div class="zp-lt__company dislay-flex">';
                    $outStr .= '<span class="gongsi">'.lang('plugin/tom_tczhaopin', 'zhaopinlist_campany').'</span>';
                    $outStr .= '<span class="name">'.$val['company_name'].'</span>';
                $outStr .= '</div>';
            $outStr .= '</div>';
            $outStr .= '<div class="zp-item__rt">';
                if($val['type'] == 2 && $val['jianzhi_work_salary'] > 0){
                    $outStr .= '<div class="price">'.$val['jianzhi_work_salary'].'<span class="xinzi">'.$jianzhiJieSuanUnitArray[$val['jianzhi_work_salary_unit']].'</span></div>';
                }else{
                    if($val['work_salary'] > 1){
                        if($val['work_salary'] == 999 ){
                            if($val['work_salary_min'] == $val['work_salary_max']){
                                $outStr .= '<div class="price">'.$val['work_salary_min'].''.lang('plugin/tom_tczhaopin', 'zhaopinlist_yuan_month').'/'.lang('plugin/tom_tczhaopin', 'month').'</div>';
                            }else{
                                $outStr .= '<div class="price">'.$val['work_salary_min'].'-'.$val['work_salary_max'].'</div>';
                            }
                        }else{
                            $outStr .= '<div class="price">'.$workSalaryArray[$val['work_salary']].'</div>';
                        }
                    }else{
                        $outStr .= '<div class="price">'.$workSalaryArray[$val['work_salary']].'</div>';
                    }
                }
                $month = dgmdate($val['refresh_time'],"n",$tomSysOffset);
                $day = dgmdate($val['refresh_time'],"j",$tomSysOffset);
                if($val['refresh_time'] > $nowDayTime){
                    $outStr .= '<div class="time"><span>'.lang('plugin/tom_tczhaopin', 'today').'</span></div>';
                }else{
                    $outStr .= '<div class="time"><span>'.$month.lang('plugin/tom_tczhaopin', 'month').$day.lang('plugin/tom_tczhaopin', 'day').'</span></div>';
                }
                if($val['expire_status'] == 2){
                    $outStr .= '<div class="button button2">'.lang('plugin/tom_tczhaopin', 'zhaopinlist_over_btn').'</div>';
                }else{
                    if($val['shenqingStatus'] == 1){
                        $outStr .= '<div class="button button2">'.lang('plugin/tom_tczhaopin', 'zhaopinlist_shengqing_btn2').'</div>';
                    }else{
                        $outStr .= '<div class="button tc-template__bg">'.lang('plugin/tom_tczhaopin', 'zhaopinlist_shengqing_btn').'</div>';
                    }
                }
                
                if($ordertype == 'nearby' && !empty($latitude) && !empty($longitude)){
                    $juli = tomGetDistance($longitude, $latitude, $val['longitude'], $val['latitude']);
                    $outStr .= '<div class="weizhi"><span>'.$juli.'km</span></div>';
                }
            $outStr .= '</div>';
        $outStr .= '</a>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;