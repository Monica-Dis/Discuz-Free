<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND t.user_id={$__UserInfo['id']} AND r.status = 1 AND r.gongkai_status = 1 AND r.shenhe_status = 1 ";
$order = " ORDER BY t.id DESC ";
$count = C::t('#tom_tczhaopin#tom_tczhaopin_history')->fetch_all_history_resume_count($where);
$historyListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_history')->fetch_all_history_resume_list($where, $order, $start, $pagesize);
$historyList = array();
if(is_array($historyListTmp) && !empty($historyListTmp)){
    foreach ($historyListTmp as $key => $value){
        $historyList[$key] = $value;

        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);

        if(!empty($value['avatar'])){
            if(!preg_match('/^http/', $value['avatar'])){
                if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                    $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
                }else{
                    $avatarTmp = $value['avatar'];
                }
            }else{
                $avatarTmp = $value['avatar'];
            }
        }else{
            if($value['sex'] == 1){
                $avatarTmp = $man_resume_avatar;
            }else if($value['sex'] == 2){
                $avatarTmp = $woman_resume_avatar;
            }
        }
        
        $historyList[$key]['avatar']            = $avatarTmp;
        $historyList[$key]['age']               = dgmdate(TIMESTAMP,"Y",$tomSysOffset) - $value['birth_year'];
        $historyList[$key]['areaInfo']          = $areaInfoTmp;
        $historyList[$key]['streetInfo']        = $streetInfoTmp;

        if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['tom_time']     = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value['resume_id'], $updateData);
        }
        
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=historylist&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=historylist&page={$nextPage}";

$ajaxDelHistoryUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=del_history&&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:historylist");