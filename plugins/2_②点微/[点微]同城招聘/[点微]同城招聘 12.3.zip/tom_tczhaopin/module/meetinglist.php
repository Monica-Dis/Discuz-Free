<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
    
$outStr = '';

$page                       = intval($_GET['page'])>0? intval($_GET['page']):0;
$pagesize                   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):15;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;

$whereStr = ' AND status = 1 ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}

$meetingListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_meeting")->fetch_all_list($whereStr, 'ORDER BY msort ASC, id DESC', $start, $pagesize);
$meetingList = array();
if(is_array($meetingListTmp) && !empty($meetingListTmp)){
    foreach ($meetingListTmp as $key => $value) {

        $meetingList[$key] = $value;

        $companyCount = C::t("#tom_tczhaopin#tom_tczhaopin_meeting_company")->fetch_all_count(" AND meeting_id = {$value['id']} AND status = 1 AND (pay_status = 0 OR pay_status = 2 ) ");
        
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        $meetingShowType = 1;
        if($value['start_time'] > TIMESTAMP){
            $meetingShowType = 2;
        }
        if($value['end_time'] <= TIMESTAMP){
            $meetingShowType = 3;
        }
        
        $meetingList[$key]['companyCount']      = $companyCount;
        $meetingList[$key]['picurl']            = $picurl;
        $meetingList[$key]['meetingShowType']   = $meetingShowType;

    }
}

if(is_array($meetingList) && !empty($meetingList)){
    foreach($meetingList as $key => $val){
        
        $outStr .= '<a class="meeting-list__item dislay-flex" href="plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=meetinginfo&meeting_id='.$val['id'].'">';
            $outStr .= '<div class="meeting-item__lt">';
                $outStr .= '<img src="'.$val['picurl'].'">';
                if($val['meetingShowType'] == 1){
                    $outStr .= '<span class="icon icon-yes">'.lang('plugin/tom_tczhaopin', 'meetinglist_show_type_1').'</span>';
                }else if($val['meetingShowType'] == 2){
                    $outStr .= '<span class="icon icon-yes">'.lang('plugin/tom_tczhaopin', 'meetinglist_show_type_2').'</span>';
                }else if($val['meetingShowType'] == 3){
                    $outStr .= '<span class="icon icon-no">'.lang('plugin/tom_tczhaopin', 'meetinglist_show_type_3').'</span>';
                }
            $outStr .= '</div>';
            $outStr .= '<div class="meeting-item__rt">';
                $outStr .= '<div class="item-rt__title">'.$val['title'].'</div>';
                $outStr .= '<div class="item-rt__time"><i class="tciconfont tcicon-shijian"></i>'.dgmdate($val['start_time'], 'Y/n/j',$tomSysOffset).' ~ '.dgmdate($val['end_time'], 'Y/n/j',$tomSysOffset).'</div>';
                $outStr .= '<div class="item-rt__btn dislay-flex">';
                    $outStr .= '<div class="num flex">'.lang('plugin/tom_tczhaopin', 'meetinglist_meeting_company_1').'<span>'.$val['companyCount'].'</span>'.lang('plugin/tom_tczhaopin', 'meetinglist_meeting_company_2').'</div>';
                    $outStr .= '<div class="btn">';
                        $outStr .= '<div class="go-btn tc-template__bg">'.lang('plugin/tom_tczhaopin', 'meetinglist_go_btn').'</div>';
                    $outStr .= '</div>';
                $outStr .= '</div>';
            $outStr .= '</div>';
        $outStr .= '</a>';
    
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;