<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$renzhengStatus = $personalRenzhengStatus = $companyRenzhengStatus = 0;
$renzhengCompanyInfo = array();
$renzhengCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($__UserInfo['id']);
if($renzhengCompanyInfoTmp['id'] > 0){
    $renzhengStatus = 1;
    $companyRenzhengStatus = 1;
    $renzhengCompanyInfo = $renzhengCompanyInfoTmp;
}
$personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_user_id($__UserInfo['id']);
if(is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1){
    $renzhengStatus = 1;
    $personalRenzhengStatus = 1;
}

$vipInfo        = array();
$shengyuDays    = 0;
$userVipInfo    = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($__UserInfo['id']);
if($userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
    $shengyuDays    = ceil(($userVipInfo['expire_time'] - TIMESTAMP)/86400);
    $vipInfo        = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
    $vipInfo['title'] = cutstr($vipInfo['title'], 16 ,'...');
}

$tczhaopinAllCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id = {$__UserInfo['id']} ");
$tczhaopinCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND shenhe_status = 1 AND status = 1 AND user_id = {$__UserInfo['id']} ");
$resumeCount = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_all_count(" AND user_id={$__UserInfo['id']} ");
$shenqingCount = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_count(" AND z.user_id = {$__UserInfo['id']} AND z.shenhe_status = 1 AND r.shenhe_status = 1 ");
$noReadShenqingCount = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_count(" AND z.user_id = {$__UserInfo['id']} AND z.shenhe_status = 1  AND t.status = 0 AND r.shenhe_status = 1 ");
$noReadMianshiCount = C::t("#tom_tczhaopin#tom_tczhaopin_mianshi")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND status = 0 ");

$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
if($__SitesInfo['id'] > 1){
    if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])){
        if(strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_tongcheng/') === FALSE){
            $kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
        }else{
            $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
        }
    }else{
        $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
    }
}

$tczhaopinConfig['kefu_qrcode'] = trim($tczhaopinConfig['kefu_qrcode']);
if(!empty($tczhaopinConfig['kefu_qrcode'])){
    $kefuQrcodeSrc = $tczhaopinConfig['kefu_qrcode'];
}

if($tczhaopinAllCount > 0){
    if(!isset($_GET['to'])){
        $_GET['to'] = 'zp';
    }
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($__UserInfo['id']);
    if(is_array($companyInfo) && !empty($companyInfo)){
        update_company_status($companyInfo);
    }else{
        $insertData = array();
        $insertData['site_id']              = $site_id;
        $insertData['user_id']              = $__UserInfo['id'];
        $insertData['add_time']             = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_company')->insert($insertData)){
            $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($__UserInfo['id']);
            update_company_status($companyInfo);
        }
    }
}

$pchr_url = '';
if($__ShowZppc == 1){
    $pchr_url = $_G['siteurl']."plugin.php?id=tom_zppc:hr";
    $zppcConfig['zhaopin_hosts']    = trim($zppcConfig['zhaopin_hosts']);
    if(!empty($zppcConfig['zhaopin_hosts'])){
        $pchr_url = $zppcConfig['zhaopin_hosts']."plugin.php?id=tom_zppc:hr";
    }
}

$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=my";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:my");