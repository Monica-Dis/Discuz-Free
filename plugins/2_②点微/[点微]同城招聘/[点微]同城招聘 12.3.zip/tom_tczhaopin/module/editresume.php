<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$test = intval($_GET['test'])>0 ? intval($_GET['test']):0;
$resume_id = intval($_GET['resume_id'])>0? intval($_GET['resume_id']):0;
$resumeInfo = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_by_id($resume_id);

# check start
if($resumeInfo['user_id'] != $__UserInfo['id']){
    
    if($__UserInfo['id'] == $tczhaopinConfig['zpmanage_user_id']){
    }else{
        if($__UserInfo['groupid'] == 1){
        }else if($__UserInfo['groupid'] == 2){
            if($resumeInfo['site_id'] == $__UserInfo['groupsiteid']){
            }else{
                tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=index");exit;
            }
        }else{
            tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=index");exit;
        }
    }
}
# check end

if($_GET['act'] == 'save' && submitcheck('resume_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $avatar             = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $type               = intval($_GET['type'])>0? intval($_GET['type']):1;
    $cate_id            = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
    $cate_child_ids     = isset($_GET['cate_child_ids'])? addslashes($_GET['cate_child_ids']):'';
    $cate_child_str     = isset($_GET['cate_child_str'])? addslashes($_GET['cate_child_str']):'';
    $city_id            = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $work_jingyan       = intval($_GET['work_jingyan'])>0? intval($_GET['work_jingyan']):0;
    $work_salary        = intval($_GET['work_salary'])>0? intval($_GET['work_salary']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name               = dhtmlspecialchars($name);
    $sex                = intval($_GET['sex'])>0? intval($_GET['sex']):0;
    $marital            = intval($_GET['marital'])>0? intval($_GET['marital']):0;
    $birth_year         = intval($_GET['birth_year'])>0? intval($_GET['birth_year']):0;
    $xueli              = intval($_GET['xueli'])>0? intval($_GET['xueli']):0;
    $work_status        = intval($_GET['work_status'])>0? intval($_GET['work_status']):0;
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                = dhtmlspecialchars($tel);
    $gongkai_status     = intval($_GET['gongkai_status'])>0? intval($_GET['gongkai_status']):0;
    $work_jingli        = isset($_GET['work_jingli'])? addslashes($_GET['work_jingli']):'';
    $work_jingli        = dhtmlspecialchars($work_jingli);
    $edu_jingli         = isset($_GET['edu_jingli'])? addslashes($_GET['edu_jingli']):'';
    $edu_jingli         = dhtmlspecialchars($edu_jingli);
    $describe           = isset($_GET['describe'])? addslashes($_GET['describe']):'';
    $describe           = dhtmlspecialchars($describe);
    $video_url          = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_url          = dhtmlspecialchars($video_url);
    $video_pic          = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic          = dhtmlspecialchars($video_pic);
    
    $cateInfo =  C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($cate_id);
    
    $cate_child_id_arr = explode(',', $cate_child_ids);
    $cate_child_search = '-'.implode('-', $cate_child_id_arr).'-';
    
    $search_text = $cateInfo['name'].'-'.$cate_child_str.'-'.$name.'-'.$work_jingli;
    
    $updateData = array();
    $updateData['name']                 = $name;
    $updateData['avatar']               = $avatar;
    $updateData['type']                 = $type;
    $updateData['cate_id']              = $cate_id;
    $updateData['cate_child_ids']       = $cate_child_ids;
    if($tczhaopinConfig['open_resume_cate_child'] == 1){
        $updateData['cate_child_str']       = $cate_child_str;
    }else{
        $updateData['cate_child_str']       = $cateInfo['name'];
    }
    $updateData['cate_child_search']    = $cate_child_search;
    $updateData['city_id']              = $city_id;
    $updateData['area_id']              = $area_id;
    $updateData['street_id']            = $street_id;
    $updateData['work_jingyan']         = $work_jingyan;
    $updateData['work_salary']          = $work_salary;
    $updateData['sex']                  = $sex;
    $updateData['marital']              = $marital;
    $updateData['birth_year']           = $birth_year;
    $updateData['xueli']                = $xueli;
    $updateData['work_status']          = $work_status;
    $updateData['tel']                  = $tel;
    $updateData['gongkai_status']       = $gongkai_status;
    $updateData['work_jingli']          = $work_jingli;
    $updateData['edu_jingli']           = $edu_jingli;
    $updateData['describe']             = $describe;
    if(!empty($video_url)){
        $updateData['video_status']         = 1;
    }else{
        $updateData['video_status']         = 0;
    }
    $updateData['video_url']            = $video_url;
    $updateData['video_pic']            = $video_pic;
    if($tczhaopinConfig['resume_must_shenhe'] == 1){
        $updateData['shenhe_status']       = 2;
    }else{
        $updateData['shenhe_status']       = 1;
    }
    $updateData['search_text']          = $search_text;
    $updateData['refresh_time']         = TIMESTAMP;
    if(C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resume_id,$updateData)){
        
        update_resume_tongcheng($resume_id);
        
        if(!empty($tongchengConfig['template_id']) && $tczhaopinConfig['resume_must_shenhe'] == 1){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                
            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerResumeList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_faburesume_shenhe_msg'),
                    'keyword1'      => $tczhaopinConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
            
            $zpmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinConfig['zpmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($zpmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerResumeList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_faburesume_shenhe_msg'),
                    'keyword1'      => $tczhaopinConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($zpmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}

if($tczhaopinConfig['resume_must_phone'] == 1 && $tczhaopinConfig['resume_phone_not_edit'] == 1 && !empty($__UserInfo['tel']) && $resumeInfo['user_id'] == $__UserInfo['id'] && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    if($__UserInfo['tel'] != $resumeInfo['tel'] ){
        $updateData = array();
        $updateData['tel'] = $__UserInfo['tel'];
        C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resumeInfo['id'],$updateData);
    }
}

if(!preg_match('/^http/', $resumeInfo['avatar']) ){
    if(strpos($resumeInfo['avatar'], 'source/plugin/tom_') === FALSE){
        $avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$resumeInfo['avatar'];
    }else{
        $avatar = $resumeInfo['avatar'];
    }
}else{
    $avatar = $resumeInfo['avatar'];
}

$cateInfo = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($resumeInfo['cate_id']);
$cateChildInfo = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($resumeInfo['cate_child_id']);

$areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($resumeInfo['area_id']);
$streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($resumeInfo['street_id']);

$cateArr = array();
$cateList = array();
$cateListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_all_list(" AND pid = 0 ", 'ORDER BY csort ASC,id DESC', 0, 100);
$i = 0;
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach ($cateListTmp as $key => $value){
        $cateList[$i]['i'] = $i;
        $cateList[$i]['id'] = $value['id'];
        $cateList[$i]['name'] = $value['name'];
        $cateArr[$i]['i'] = $i;
        $cateArr[$i]['id'] = $value['id'];
        $childCateList = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid={$value['id']} "," ORDER BY csort ASC,id DESC ",0,100);
        $j = 0;
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $kk => $vv){
                $cateArr[$i]['sub'][$j]['value'] = $vv['id'];
                $cateArr[$i]['sub'][$j]['title'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cateData = urlencode(json_encode($cateArr));

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$cityList = array();
$cityList[0]['id'] = 0;
$cityList[0]['name'] = diconv(lang('plugin/tom_tczhaopin', 'buxian'),CHARSET,'utf-8');
$cityList[0]['sub'][0]['id'] = 0;
$cityList[0]['sub'][0]['name'] = diconv(lang('plugin/tom_tczhaopin', 'buxian'),CHARSET,'utf-8');
$i = 1;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        $cityList[$i]['sub'][$j]['id'] = 0;
        $cityList[$i]['sub'][$j]['name'] = diconv(lang('plugin/tom_tczhaopin', 'buxian'),CHARSET,'utf-8');
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $j++;
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$nowYear = dgmdate(TIMESTAMP,"Y",$tomSysOffset);
$birthYearArr = array();
$maxBirthYear = $nowYear - 60;
$minBirthYear = $nowYear - 18;
for($maxBirthYear; $maxBirthYear <= $minBirthYear; $maxBirthYear++){
    $birthYearArr[] = $maxBirthYear;
}

$phone_back_url = $weixinClass->get_url();
$phone_back_url = urlencode($phone_back_url);
$phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";

if(!preg_match('/^http/', $resumeInfo['video_pic']) ){
    if(strpos($resumeInfo['video_pic'], 'source/plugin/tom_') === FALSE){
        $video_pic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$resumeInfo['video_pic'];
    }else{
        $video_pic = $resumeInfo['video_pic'];
    }
}else{
    $video_pic = $resumeInfo['video_pic'];
}

$wxUploadUrl = "plugin.php?id=tom_tczhaopin:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;
$uploadUrl = $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=upload&act=resume_avatar&formhash={$formhash}&suffix=";
$shareUrl = $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=faburesume";
$saveUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=editresume&act=save";
$jumpUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myresumelist";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:editresume");