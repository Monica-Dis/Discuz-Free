<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$mianshi_id = intval($_GET['mianshi_id'])>0? intval($_GET['mianshi_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$type       = intval($_GET['type'])>0? intval($_GET['type']):1;
$status     = intval($_GET['status'])>0? intval($_GET['status']):0;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

if($type == 1){
    $where = " AND user_id = {$__UserInfo['id']} ";
}else if($type == 2){
    $where = " AND yaoqing_user_id = {$__UserInfo['id']} ";
}else{
    $where = " AND user_id = {$__UserInfo['id']} ";
}

if($mianshi_id > 0){
    $where .= " AND id={$mianshi_id} ";
}
if($status > 0){
    $where .= " AND status={$status} ";
}

$order = " ORDER BY status ASC, add_time DESC ";
$count = C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->fetch_all_count($where);
$mianshiListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->fetch_all_list($where, $order, $start, $pagesize);
$mianshiList = array();
if(is_array($mianshiListTmp) && !empty($mianshiListTmp)){
    foreach ($mianshiListTmp as $key => $value){
        
        $zhaopinInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($value['tczhaopin_id']);
        $resumeInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($value['resume_id']);
        
        if($zhaopinInfoTmp['id'] > 0 && $resumeInfoTmp['id'] > 0){
        }else{
            continue;
        }
        
        $mianshiList[$key] = $value;
        
        if($type == 1){
            $rzConpanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list(" AND user_id = {$zhaopinInfoTmp['user_id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
            $rzConpanyInfo = array();
            if(is_array($rzConpanyInfoTmp) && !empty($rzConpanyInfoTmp[0])){
                $rzConpanyInfo = $rzConpanyInfoTmp[0];
                if(!preg_match('/^http/', $rzConpanyInfo['logo']) ){
                    if(strpos($rzConpanyInfo['logo'], 'source/plugin/tom_') === FALSE){
                        $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$rzConpanyInfo['logo'];
                    }else{
                        $avatarTmp = $_G['siteurl'].$rzConpanyInfo['logo'];
                    }
                }else{
                    $avatarTmp = $rzConpanyInfo['logo'];
                }
            }else{
                $avatarTmp = $__UserInfo['picurl'];
            }
        }
        
        if($type == 2){
            if(!empty($resumeInfoTmp['avatar'])){
                if(!preg_match('/^http/', $resumeInfoTmp['avatar'])){
                    if(strpos($resumeInfoTmp['avatar'], 'source/plugin/tom_') === FALSE){
                        $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$resumeInfoTmp['avatar'];
                    }else{
                        $avatarTmp = $resumeInfoTmp['avatar'];
                    }
                }else{
                    $avatarTmp = $resumeInfoTmp['avatar'];
                }
            }else{
                if($resumeInfoTmp['sex'] == 1){
                    $avatarTmp = $man_resume_avatar;
                }else if($resumeInfoTmp['sex'] == 2){
                    $avatarTmp = $woman_resume_avatar;
                }
            }
        }
        
        $baiduMapToName = $value['xm'];
        $baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
        $baiduMapToName = urlencode($baiduMapToName);
        $baiduMapToAddress = $value['address'];
        $baiduMapToAddress = diconv($baiduMapToAddress, CHARSET, 'utf-8');
        $baiduMapToAddress = urlencode($baiduMapToAddress);
        $baiduMapUrl = "http://api.map.baidu.com/marker?location={$value['latitude']},{$value['longitude']}&title={$baiduMapToName}&content={$baiduMapToAddress}&output=html";
        
        $mianshiList[$key]['zhaopinInfo']    = $zhaopinInfoTmp;
        $mianshiList[$key]['resumeInfo']     = $resumeInfoTmp;
        $mianshiList[$key]['avatar']         = $avatarTmp;
        $mianshiList[$key]['add_time']       = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $mianshiList[$key]['baiduMapUrl']    = $baiduMapUrl;
        
        if($type == 1 && $value['status'] == 0){
            DB::query("UPDATE ".DB::table('tom_tczhaopin_mianshi')." SET status=1 WHERE id='{$value['id']}'", 'UNBUFFERED');
        }
        
    }
}

$open_wx_map = 0;
if($__IsWeixin == 1 && $tczhaopinConfig['open_wx_map'] == 1){
    $open_wx_map = 1;
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=mianshilist&type={$type}&status={$status}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=mianshilist&type={$type}&status={$status}&page={$nextPage}";

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=updateMianshiStatus&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:mianshilist");