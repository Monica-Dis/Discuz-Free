<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
    
$outStr = '';

$meeting_id  = intval($_GET['meeting_id'])>0? intval($_GET['meeting_id']):0;
$page        = intval($_GET['page'])>0? intval($_GET['page']):0;
$pagesize    = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):15;

$meetingInfo = C::t("#tom_tczhaopin#tom_tczhaopin_meeting")->fetch_by_id($meeting_id);

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;

$whereStr = " AND meeting_id = {$meeting_id} AND status = 1 AND (pay_status = 0 OR pay_status = 2) ";

$meetingCompanyListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_meeting_company")->fetch_all_list($whereStr, 'ORDER BY is_recommend DESC, csort ASC, id DESC', $start, $pagesize);
$meetingCompanyList = array();
if(is_array($meetingCompanyListTmp) && !empty($meetingCompanyListTmp)){
    foreach ($meetingCompanyListTmp as $key => $value) {
        
        $companyInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_company")->fetch_by_id($value['company_id']);
        $renzhengCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_id($companyInfoTmp['renzheng_company_id']);

        if($companyInfoTmp['id'] > 0 && $renzhengCompanyInfoTmp['id'] > 0){
            $meetingCompanyList[$key] = $value;
        
            if(!preg_match('/^http/', $renzhengCompanyInfoTmp['logo']) ){
                if(strpos($renzhengCompanyInfoTmp['logo'], 'source/plugin/tom_') === FALSE){
                    $logo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$renzhengCompanyInfoTmp['logo'];
                }else{
                    $logo = $renzhengCompanyInfoTmp['logo'];
                }
            }else{
                $logo = $renzhengCompanyInfoTmp['logo'];
            }

            $tczhaopinListTmp = array();
            $tczhaopinCount = 0;
            if($meetingInfo['zhaopin_list_type'] == 1){
                $tczhaopinCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND id IN({$value['tczhaopin_ids']}) AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ");
                $tczhaopinListTmpTmp = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_list(" AND id IN({$value['tczhaopin_ids']}) AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ", 'ORDER BY top_status DESC,refresh_time DESC,id DESC', 0, 100);
            }else{
                $tczhaopinCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND company_id = {$value['company_id']}  AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ");
                $tczhaopinListTmpTmp = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_list(" AND company_id = {$value['company_id']}  AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ", 'ORDER BY top_status DESC,refresh_time DESC,id DESC', 0, 10);
            }
            if(is_array($tczhaopinListTmpTmp) && !empty($tczhaopinListTmpTmp)){
                foreach($tczhaopinListTmpTmp as $k => $v){
                    $tczhaopinListTmp[$k] = $v;
                    
                    $cateInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($v['cate_id']);
                    $cateChildInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($v['cate_child_id']);
                    
                    $tczhaopinListTmp[$k]['cate_name'] = $cateInfoTmp['name'];
                    $tczhaopinListTmp[$k]['cate_child_name'] = $cateChildInfoTmp['name'];
                }
            }
            
            $renzhengCompanyInfoTmp['content'] = strip_tags($renzhengCompanyInfoTmp['content']);

            $meetingCompanyList[$key]['logo']               = $logo;
            $meetingCompanyList[$key]['company_name']       = $renzhengCompanyInfoTmp['name'];
            $meetingCompanyList[$key]['company_address']    = $renzhengCompanyInfoTmp['address'];
            $meetingCompanyList[$key]['tczhaopinList']      = $tczhaopinListTmp;
            $meetingCompanyList[$key]['tczhaopinCount']     = $tczhaopinCount;
            $meetingCompanyList[$key]['company_content']    = cutstr($renzhengCompanyInfoTmp['content'], '116', '...');
        }
        
    }
}

if(is_array($meetingCompanyList) && !empty($meetingCompanyList)){
    foreach($meetingCompanyList as $key => $val){
        if($meetingInfo['list_template'] == 1){
            $outStr .= '<div class="meeting-main__company">';
                $outStr .= '<a class="company-hd" href="plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=companyinfo&company_id='.$val['company_id'].'&meeting_click_id='.$meeting_id.'">';
                    $outStr .= '<div class="company-xq dislay-flex">';
                        $outStr .= '<div class="company-pic">';
                            $outStr .= '<img src="'.$val['logo'].'">';
                        $outStr .= '</div>';
                        $outStr .= '<div class="company-content">';
                            if($val['is_recommend'] == 1){
                                $outStr .= '<div class="company-content__title"><i class="tciconfont tcicon-tuijian"></i>'.$val['company_name'].'</div>';
                            }else{
                                $outStr .= '<div class="company-content__title">'.$val['company_name'].'</div>';
                            }
                            $outStr .= '<div class="company-content__address"><i class="tciconfont tcicon-dingwei"></i>'.$val['company_address'].'</div>';
                        $outStr .= '</div>';
                    $outStr .= '</div>';
                    $outStr .= '<div class="company-desc">'.$val['company_content'].'<span>'.lang('plugin/tom_tczhaopin', 'meetingcompanylist_more').'</span></div>';
                $outStr .= '</a>';
                $outStr .= '<div class="company-bd">';
                    foreach($val['tczhaopinList'] as $k => $v){
                        $outStr .= '<a class="company-zhiwei__item dislay-flex" href="plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$v['id'].'&meeting_click_id='.$meeting_id.'">';
                            $outStr .= '<span class="lt flex">'.$v['title'].'</span>';
                            
                            if($v['type'] == 2 && $v['jianzhi_work_salary'] > 0){
                                $outStr .= '<span class="rt">'.$v['jianzhi_work_salary'].$jianzhiJieSuanUnitArray[$v['jianzhi_work_salary_unit']].'&nbsp;<font color="#ccc">|</font>&nbsp;'.$jianzhiJieSuanFangshiArray[$v['jianzhi_jiesuan_fangshi']].'</span>';
                            }else{
                                if($v['work_salary'] == 1){
                                    $outStr .= '<span class="rt">'.$workSalaryArray[$v['work_salary']].'</span>';
                                }else{
                                    if($v['work_salary'] == 999){
                                        if($v['work_salary_min'] == $v['work_salary_max']){
                                            $outStr .= '<span class="rt">'.$v['work_salary_min'].lang('plugin/tom_tczhaopin', 'zhaopinlist_yuan_month').'</span>';
                                        }else{
                                            $outStr .= '<span class="rt">'.$v['work_salary_min'].'-'.$v['work_salary_max'].lang('plugin/tom_tczhaopin', 'zhaopinlist_yuan_month').'</span>';
                                        }
                                    }else{
                                        $outStr .= '<span class="rt">'.$workSalaryArray[$v['work_salary']].lang('plugin/tom_tczhaopin', 'zhaopinlist_yuan_month').'</span>';
                                    }
                                }
                            }
                            
                        $outStr .= '</a>';
                    }
                $outStr .= '</div>';
            $outStr .= '</div>';
        }else if($meetingInfo['list_template'] == 2){
            
            $outStr .= '<div class="newcompany-item">';
                $outStr .= '<div class="newitem-pic">';
                    $outStr .= '<img src="'.$val['logo'].'">';
                $outStr .= '</div>';
                if($val['is_recommend'] == 1){
                    $outStr .= '<div class="newitem-title"><i class="tciconfont tcicon-tuijian"></i>'.$val['company_name'].'</div>';
                }else{
                    $outStr .= '<div class="newitem-title">'.$val['company_name'].'</div>';
                }
                
                $outStr .= '<div class="newitem-zp">';
                    $i = 1;
                    foreach($val['tczhaopinList'] as $k => $v){
                        if($i <= 2){
                            $outStr .= '<a class="zp dislay-flex" href="plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$v['id'].'&meeting_click_id='.$meeting_id.'">';
                                $outStr .= '<div class="zp-zhiwei flex">'.$v['cate_child_name'].'</div>';
                                if($v['type'] == 2 && $v['jianzhi_work_salary'] > 0){
                                    $outStr .= '<div class="zp-gz">'.$v['jianzhi_work_salary'].$jianzhiJieSuanUnitArray[$v['jianzhi_work_salary_unit']].'&nbsp;<font color="#ccc">|</font>&nbsp;'.$jianzhiJieSuanFangshiArray[$v['jianzhi_jiesuan_fangshi']].'</div>';
                                }else{
                                    if($v['work_salary'] == 1){
                                        $outStr .= '<div class="zp-gz">'.$workSalaryArray[$v['work_salary']].'</div>';
                                    }else{
                                        if($v['work_salary'] == 999){
                                            if($v['work_salary_min'] == $v['work_salary_max']){
                                                $outStr .= '<div class="zp-gz">'.$v['work_salary_min'].lang('plugin/tom_tczhaopin', 'zhaopinlist_yuan_month').'</div>';
                                            }else{
                                                $outStr .= '<div class="zp-gz">'.$v['work_salary_min'].'-'.$v['work_salary_max'].lang('plugin/tom_tczhaopin', 'zhaopinlist_yuan_month').'</div>';
                                            }
                                        }else{
                                            $outStr .= '<div class="zp-gz">'.$workSalaryArray[$v['work_salary']].lang('plugin/tom_tczhaopin', 'zhaopinlist_yuan_month').'</div>';
                                        }
                                    }
                                }
                                
                            $outStr .= '</a>';
                        }
                        $i++;
                    }
                    
                $outStr .= '</div>';
                $outStr .= '<div class="newitem-count">'.lang('plugin/tom_tczhaopin', 'ajax_companylist_zp_num_1').$val['tczhaopinCount'].lang('plugin/tom_tczhaopin', 'ajax_companylist_zp_num_2').'</div>';
                $outStr .= '<a class="newitem-btn" href="plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=companyinfo&company_id='.$val['company_id'].'&morezhaopin=1&meeting_click_id='.$meeting_id.'">'.lang('plugin/tom_tczhaopin', 'ajax_companylist_chakan').'</a>';
            $outStr .= '</div>';
        }
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;