<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tczhaopin_id = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):0;
$tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($tczhaopin_id);

$cateInfo = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($tczhaopinInfo['cate_id']);
$cateChildInfo = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($tczhaopinInfo['cate_child_id']);
$jianzhiCateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_by_id($tczhaopinInfo['jianzhi_cate_id']);

if($tczhaopinInfo['top_status'] == 1 && $tczhaopinInfo['top_time'] <= TIMESTAMP){
    $updateData = array();
    $updateData['top_status']   = 0;
    $updateData['top_time']     = 0;
    C::t("#tom_tczhaopin#tom_tczhaopin")->update($tczhaopin_id, $updateData);
    $tczhaopinInfo['top_status'] = 0;
}

$vipInfo = array();
$userVipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($__UserInfo['id']);
if($userVipInfoTmp['vip_id'] > 0 && $userVipInfoTmp['expire_status'] == 1 && $userVipInfoTmp['expire_time'] > TIMESTAMP){
    $vipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfoTmp['vip_id']);
    if($vipInfoTmp && $vipInfoTmp > 0){
        $vipInfo = $vipInfoTmp;
    }
}

$zhaopinTopList = array();
$zhaopin_top_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['zhaopin_top_list']); 
$zhaopin_top_list_str = str_replace("\n","{n}",$zhaopin_top_list_str);
$zhaopin_top_list_arr = explode("{n}", $zhaopin_top_list_str);
if(is_array($zhaopin_top_list_arr) && !empty($zhaopin_top_list_arr)){
    foreach ($zhaopin_top_list_arr as $key => $value){
        
        $arr = explode("|", $value);
        
        if($vipInfo && $vipInfo['id'] > 0 && $vipInfo['top_zhekou'] > 0){
            $top_zhekou = $vipInfo['top_zhekou'] / 100;
            $arr[1] = $arr[1] * $top_zhekou;
            $arr[1] = round($arr[1], 2);
            if($arr[1] <= 0){
                $arr[1] = 0.01;
            }
        }
        
        $zhaopinTopList[$key] = $arr;
        $zhaopinTopList[$key]['score_pay'] = 0;
        $zhaopinTopList[$key]['score'] = 0;
        
        if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $scorePayNum = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($scorePayNum > 0 && $__UserInfo['score'] >= $scorePayNum){
                $zhaopinTopList[$key]['score'] = $scorePayNum;
                $zhaopinTopList[$key]['score_pay'] = 1;
            }
        }
    }
}

$payTopUrl = "plugin.php?id=tom_tczhaopin:pay&site={$site_id}&act=zhaopin_top_pay&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:buyzhaopin");