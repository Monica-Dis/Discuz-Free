<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$keyword    = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$meeting_id = intval($_GET['meeting_id'])>0? intval($_GET['meeting_id']):0;

$meetingInfo = C::t("#tom_tczhaopin#tom_tczhaopin_meeting")->fetch_by_id($meeting_id);
if(is_array($meetingInfo) && !empty($meetingInfo) && $meetingInfo['status'] == 1){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=index");exit;
}
if(!preg_match('/^http/', $meetingInfo['picurl']) ){
    if(strpos($meetingInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $shareLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$meetingInfo['picurl'];
    }else{
        $shareLogo = $_G['siteurl'].$meetingInfo['picurl'];
    }
}else{
    $shareLogo = $meetingInfo['picurl'];
}

if(!preg_match('/^http/', $meetingInfo['theme_picurl']) ){
    if(strpos($meetingInfo['theme_picurl'], 'source/plugin/tom_') === FALSE){
        $themePicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$meetingInfo['theme_picurl'];
    }else{
        $themePicurl = $_G['siteurl'].$meetingInfo['theme_picurl'];
    }
}else{
    $themePicurl = $meetingInfo['theme_picurl'];
}

if(!preg_match('/^http/', $meetingInfo['haibao_picurl']) ){
    if(strpos($meetingInfo['haibao_picurl'], 'source/plugin/tom_') === FALSE){
        $haibao_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$meetingInfo['haibao_picurl'];
    }else{
        $haibao_picurl = $meetingInfo['haibao_picurl'];
    }
}else{
    $haibao_picurl = $meetingInfo['haibao_picurl'];
}

$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
if($__SitesInfo['id'] > 1){
    if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])){
        if(strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_tongcheng/') === FALSE){
            $kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
        }else{
            $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
        }
    }else{
        $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
    }
}

$tczhaopinConfig['kefu_qrcode'] = trim($tczhaopinConfig['kefu_qrcode']);
if(!empty($tczhaopinConfig['kefu_qrcode'])){
    $kefuQrcodeSrc = $tczhaopinConfig['kefu_qrcode'];
}

if(!empty($meetingInfo['share_title'])){
    $shareTitle = $meetingInfo['share_title'];
}

if(!empty($meetingInfo['share_desc'])){
    $shareDesc = $meetingInfo['share_desc'];
}

$md5HostUrl = md5($_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=meetinginfosearchlist&meeting_id={$meeting_id}&keyword={$keyword}");

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=meetinginfo&meeting_id={$meeting_id}";
if($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0){
    if($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1){
        $shareUrl   = $shareUrl."&tjid={$tchehuorenInfoTmp['id']}";
    }
}

$ajaxListUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=zhaopinlist&meeting_id={$meeting_id}&meeting_click_id={$meeting_id}&formhash=".$formhash;
$ajaxClicksUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=meetinginfo_clicks&meeting_id={$meeting_id}&formhash=".$formhash;
$ajaxSearchUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=get_meetinginfo_search_url&meeting_id={$meeting_id}&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:meetinginfosearchlist");