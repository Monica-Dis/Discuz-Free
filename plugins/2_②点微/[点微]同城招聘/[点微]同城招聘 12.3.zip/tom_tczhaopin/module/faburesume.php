<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$shenqing_tczhaopin_id = intval($_GET['shenqing_tczhaopin_id'])>0 ? intval($_GET['shenqing_tczhaopin_id']):0;
$test                  = intval($_GET['test'])>0 ? intval($_GET['test']):0;

$cateArr = array();
$cateList = array();
$cateListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_all_list(" AND pid = 0 ", 'ORDER BY csort ASC,id DESC', 0, 100);
$i = 0;
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach ($cateListTmp as $key => $value){
        $cateList[$i]['i'] = $i;
        $cateList[$i]['id'] = $value['id'];
        $cateList[$i]['name'] = $value['name'];
        $cateArr[$i]['i'] = $i;
        $cateArr[$i]['id'] = $value['id'];
        $childCateList = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid={$value['id']} "," ORDER BY csort ASC,id DESC ",0,100);
        $j = 0;
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $kk => $vv){
                $cateArr[$i]['sub'][$j]['value'] = $vv['id'];
                $cateArr[$i]['sub'][$j]['title'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cateData = urlencode(json_encode($cateArr));

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$cityList = array();
$cityList[0]['id'] = 0;
$cityList[0]['name'] = diconv(lang('plugin/tom_tczhaopin', 'buxian'),CHARSET,'utf-8');
$cityList[0]['sub'][0]['id'] = 0;
$cityList[0]['sub'][0]['name'] = diconv(lang('plugin/tom_tczhaopin', 'buxian'),CHARSET,'utf-8');
$i = 1;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        $cityList[$i]['sub'][$j]['id'] = 0;
        $cityList[$i]['sub'][$j]['name'] = diconv(lang('plugin/tom_tczhaopin', 'buxian'),CHARSET,'utf-8');
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $j++;
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$resumeTopList = array();
$resume_top_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['resume_top_list']); 
$resume_top_list_str = str_replace("\n","{n}",$resume_top_list_str);
$resume_top_list_str = explode("{n}", $resume_top_list_str);
if(is_array($resume_top_list_str) && !empty($resume_top_list_str)){
    foreach ($resume_top_list_str as $key => $value){
        $resumeTopList[$key] = explode("|", $value);
    }
}

$nowYear = dgmdate(TIMESTAMP,"Y",$tomSysOffset);
$birthYearArr = array();
$maxBirthYear = $nowYear - 60;
$minBirthYear = $nowYear - 18;
for($maxBirthYear; $maxBirthYear <= $minBirthYear; $maxBirthYear++){
    $birthYearArr[] = $maxBirthYear;
}

$phone_back_url = $weixinClass->get_url();
$phone_back_url = urlencode($phone_back_url);
$phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";

$showMustPhoneBtn = 0;
if($tczhaopinConfig['resume_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
}

$resumeGonggao = discuzcode($tczhaopinConfig['resume_gonggao'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);
$resumeGonggaoTxt = strip_tags(cutstr(stripslashes($resumeGonggao), 100 ,'...'));

$subscribeFlag = 0;
$access_token = $weixinClass->get_access_token();
if($tczhaopinConfig['open_faburesume_guanzu']==1 && $__UserInfo['id'] > 0 && !empty($__UserInfo['openid']) && !empty($access_token)){
    $get_user_info_url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token={$access_token}&openid={$__UserInfo['openid']}&lang=zh_CN";
    $return = get_html($get_user_info_url);
    if(!empty($return)){
        $tcContent = json_decode($return,true);
        if(is_array($tcContent) && !empty($tcContent) && isset($tcContent['subscribe'])){
            if($tcContent['subscribe'] == 1){
                $subscribeFlag = 1;
            }else{
                $subscribeFlag = 2;
            }
        }
    }
}

$wxUploadUrl = "plugin.php?id=tom_tczhaopin:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;
$uploadUrl = $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=upload&act=resume_avatar&formhash={$formhash}&suffix=";
$shareUrl = $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=faburesume";
$saveUrl = "plugin.php?id=tom_tczhaopin:pay&site={$site_id}";
if($shenqing_tczhaopin_id > 0){
    $jumpUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=zhaopininfo&tczhaopin_id={$shenqing_tczhaopin_id}";
}else{
    $jumpUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myresumelist";
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:faburesume");