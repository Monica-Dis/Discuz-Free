<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    if($__UserInfo['id'] != $tczhaopinConfig['zpmanage_user_id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=index");exit;
    }
}
# check end

if($_GET['act'] == 'shenhe' && submitcheck('tczhaopin_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $tczhaopin_id = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):0;
    $shenhe_status = intval($_GET['shenhe_status'])>0? intval($_GET['shenhe_status']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);
    
    $updateData = array();
    $updateData['shenhe_status'] = $shenhe_status;
    C::t('#tom_tczhaopin#tom_tczhaopin')->update($tczhaopin_id,$updateData);
    
    update_zhaopin_tongcheng($tczhaopin_id);
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
    update_company_status($companyInfo);
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tczhaopinInfo['user_id']);
    
    if($tczhaopinInfo){
        
        if($shenhe_status == 1){
            $shenhe = str_replace('{TITLE}', $tczhaopinInfo['title'], lang('plugin/tom_tczhaopin', 'index_template_tczhaopin_shenhe_ok'));
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$tczhaopinInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }else if($shenhe_status == 3){
            $shenhe = str_replace('{TITLE}', $tczhaopinInfo['title'], lang('plugin/tom_tczhaopin', 'index_template_tczhaopin_shenhe_no'));
            $tzShenhe = $shenhe.'<br/><font color="#8e8e8e">'.$content.'</font><br/><a href="plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=editzhaopin&tczhaopin_id='.$tczhaopinInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }
        
        $insertData = array();
        $insertData['user_id']      = $toUser['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tczhaopinConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    
    $nextSmsTime = $toUser['last_smstp_time'] + 0;
    if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime ){
        if($shenhe_status == 1){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$tczhaopinInfo['site_id']}&mod=zhaopininfo&tczhaopin_id=".$tczhaopinInfo['id']);
        }else if($shenhe_status == 3){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$tczhaopinInfo['site_id']}&mod=editzhaopin&tczhaopin_id=".$tczhaopinInfo['id']);
        }
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tczhaopinConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $updateData = array();
            $updateData['last_smstp_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList&keyword=".urlencode(trim($keyword));
    
    echo $url;exit;
    
}else if($_GET['act'] == 'del' && submitcheck('tczhaopin_id')){
    
    $tczhaopin_id = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):0;
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);
    
    C::t('#tom_tczhaopin#tom_tczhaopin')->delete_by_id($tczhaopin_id);
    C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->delete_by_tczhaopin_id($tczhaopin_id);
    
    delete_zhaopin_tongcheng($tczhaopin_id);
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
    update_company_status($companyInfo);
    echo 200;exit;

}else if($_GET['act'] == 'shenhe_show'){
    
    $tczhaopin_id   = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):0;
    $fromtype       = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage       = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);

    $zhaopin_shenhe_fail_str = str_replace("\r\n","{n}",$tczhaopinConfig['zhaopin_shenhe_fail_text']); 
    $zhaopin_shenhe_fail_str = str_replace("\n","{n}",$zhaopin_shenhe_fail_str);
    $zhaopinShenheFailArray = explode("{n}", $zhaopin_shenhe_fail_str);
    
    $ajaxShenheUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList&act=shenhe&";
    $backUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList&type={$fromtype}&page={$frompage}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tczhaopin:managerShenhe");exit;
    
}else if($_GET['act'] == 'fenghao' && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $fenghao_time   = intval($_GET['fenghao_time'])>0? intval($_GET['fenghao_time']):0;
    $fenghao_msg    = isset($_GET['fenghao_msg'])? daddslashes($_GET['fenghao_msg']):'';
    
    $fenghaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id); 
    
    if($fenghaoUserInfo){
        
        $fenghao_end_time = 999;
        if($fenghao_time == 2){
            $fenghao_end_time = TIMESTAMP + 86400*7;
        }else if($fenghao_time == 3){
            $fenghao_end_time = TIMESTAMP + 86400*30;
        }else if($fenghao_time == 4){
            $fenghao_end_time = TIMESTAMP + 86400*90;
        }
        
        $updateData = array();
        $updateData['status']           = 2;
        $updateData['fenghao_time']     = $fenghao_end_time;
        $updateData['fenghao_msg']      = $fenghao_msg;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($fenghaoUserInfo['id'],$updateData);

        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2 WHERE user_id='{$fenghaoUserInfo['id']}' ", 'UNBUFFERED');
        
        DB::query("UPDATE ".DB::table('tom_tczhaopin')." SET status=0 WHERE user_id='{$fenghaoUserInfo['id']}' ", 'UNBUFFERED');
        
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'fenghao_show'){
    
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $fromtype       = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage       = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $fenghaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id); 
    
    $ajaxFenghaoUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList&act=fenghao";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tczhaopin:managerFenghao");exit;
    
}

$keyword  = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page  = intval($_GET['page'])>0? intval($_GET['page']):1;
$type  = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = " AND pay_status!=1 ";
if($type == 1){
    $where.= " AND shenhe_status=2 ";
}
if($type == 2){
    $where.= " AND shenhe_status=3 ";
}
if($__UserInfo['groupid'] == 2){
    $where.= " AND site_id={$site_id} ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count(" {$where} ",$keyword);
$tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list(" {$where} "," ORDER BY refresh_time DESC,id DESC ",$start,$pagesize,$keyword);
$tczhaopinList = array();
foreach ($tczhaopinListTmp as $key => $value) {
    $tczhaopinList[$key] = $value;
    
    $workWelfareArr = explode('-', trim($value['work_welfare'], '-'));
    $welfareList = array();
    if(is_array($welfareArray) && !empty($welfareArray)){
        foreach($welfareArray as $k => $v){
            if(in_array($k,$workWelfareArr)){
                $welfareList[$k]['name'] = $v;
            }
        }
    }

    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($value['cate_id']);
    $dingyueCount = C::t('#tom_tczhaopin#tom_tczhaopin_dingyue')->fetch_all_count(" AND cate_id = {$value['cate_id']} ");
    $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
    $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
    
    $tczhaopinList[$key]['welfareList']     = $welfareList;
    $tczhaopinList[$key]['userInfo']        = $userInfoTmp;
    $tczhaopinList[$key]['cateInfo']        = $cateInfo;
    $tczhaopinList[$key]['dingyueCount']    = $dingyueCount;
    $tczhaopinList[$key]['areaInfo']        = $areaInfoTmp;
    $tczhaopinList[$key]['streetInfo']      = $streetInfoTmp;
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];

$ajaxShenheUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList&act=shenhe&&formhash=".$formhash;
$ajaxDelUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList&act=del&&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList&act=get_search_url";
$ajaxQunfaUrl = "plugin.php?id=tom_tczhaopin:qunfa&site={$site_id}&act=qunfa&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:managerList");