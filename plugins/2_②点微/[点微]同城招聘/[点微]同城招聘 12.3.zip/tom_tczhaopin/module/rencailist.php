<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page = intval($_GET['page'])>0? intval($_GET['page']):1;
$type = intval($_GET['type'])>0? intval($_GET['type']):0;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND t.user_id={$__UserInfo['id']} AND r.status = 1 AND r.shenhe_status = 1 AND r.deleted = 0 ";
if($type > 0){
    $where .= " AND t.type = {$type} ";
}
$order = " ORDER BY t.id DESC ";
$count = C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->fetch_all_rencai_resume_count($where);
$rencaiListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->fetch_all_rencai_resume_list($where, $order, $start, $pagesize);
$rencaiList = array();
if(is_array($rencaiListTmp) && !empty($rencaiListTmp)){
    foreach ($rencaiListTmp as $key => $value){
        $rencaiList[$key] = $value;

        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);

        if(!empty($value['avatar'])){
            if(!preg_match('/^http/', $value['avatar'])){
                if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                    $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
                }else{
                    $avatarTmp = $value['avatar'];
                }
            }else{
                $avatarTmp = $value['avatar'];
            }
        }else{
            if($value['sex'] == 1){
                $avatarTmp = $man_resume_avatar;
            }else if($value['sex'] == 2){
                $avatarTmp = $woman_resume_avatar;
            }
        }

        $rencaiList[$key]['avatar']         = $avatarTmp;
        $rencaiList[$key]['age']            = dgmdate(TIMESTAMP,"Y",$tomSysOffset) - $value['birth_year'];
        $rencaiList[$key]['areaInfo']       = $areaInfoTmp;
        $rencaiList[$key]['streetInfo']     = $streetInfoTmp;

        if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value['resume_id'], $updateData);
        }
        
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=rencailist&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=rencailist&type={$type}&page={$nextPage}";

$ajaxDelResumeUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=del_rencai&&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:rencailist");