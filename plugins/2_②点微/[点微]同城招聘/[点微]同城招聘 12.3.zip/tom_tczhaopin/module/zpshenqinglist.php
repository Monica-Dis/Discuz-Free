<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type           = intval($_GET['type'])>0? intval($_GET['type']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$tczhaopin_id   = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):0;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND z.user_id = {$__UserInfo['id']} AND z.shenhe_status = 1 AND r.shenhe_status = 1 AND r.deleted = 0 ";
if($type == 1){
    $where .= " AND t.status = 1 ";
}else if($type == 2){
    $where .= " AND t.status = 0 ";
}

if($tczhaopin_id > 0){
    $where .= " AND t.tczhaopin_id={$tczhaopin_id}";
}

$order = " ORDER BY t.add_time DESC,t.id DESC ";
$count = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_count($where);
$shenqingListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_list($where," {$order} ",$start,$pagesize);
$shenqingList = array();
if(is_array($shenqingListTmp) && !empty($shenqingListTmp)){
    foreach ($shenqingListTmp as $key => $value){
        $shenqingList[$key] = $value;

        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['r_area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['r_street_id']);

        if(!empty($value['r_avatar'])){
            if(!preg_match('/^http/', $value['r_avatar'])){
                if(strpos($value['r_avatar'], 'source/plugin/tom_') === FALSE){
                    $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['r_avatar'];
                }else{
                    $avatarTmp = $value['r_avatar'];
                }
            }else{
                $avatarTmp = $value['r_avatar'];
            }
        }else{
            if($value['r_sex'] == 1){
                $avatarTmp = $man_resume_avatar;
            }else if($value['r_sex'] == 2){
                $avatarTmp = $woman_resume_avatar;
            }
        }

        $shenqingList[$key]['r_avatar']           = $avatarTmp;
        $shenqingList[$key]['r_name']             = cutstr($value['r_name'], 2,'');
        $shenqingList[$key]['r_age']              = dgmdate(TIMESTAMP,"Y",$tomSysOffset) - $value['r_birth_year'];
        $shenqingList[$key]['r_areaInfo']         = $areaInfoTmp;
        $shenqingList[$key]['r_streetInfo']       = $streetInfoTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=zpshenqinglist&page={$prePage}&tczhaopin_id={$tczhaopin_id}";
$nextPageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=zpshenqinglist&page={$nextPage}&tczhaopin_id={$tczhaopin_id}";

$ajaxDeleteUrl = 'plugin.php?id=tom_tczhaopin:ajax&site='.$site_id.'&act=delete_shixiao_shenqing&formhash='.$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:zpshenqinglist");