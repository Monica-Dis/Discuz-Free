<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$companyInfo = C::t("#tom_tczhaopin#tom_tczhaopin_company")->fetch_by_user_id($__UserInfo['id']);

if($companyInfo['top_status'] == 1 && $companyInfo['top_time'] <= TIMESTAMP){
    $updateData = array();
    $updateData['top_status']   = 0;
    $updateData['top_time']     = 0;
    C::t("#tom_tczhaopin#tom_tczhaopin_company")->update($companyInfo['id'], $updateData);
    $companyInfo['top_status'] = 0;
}

$vipInfo = array();
$userVipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($__UserInfo['id']);
if($userVipInfoTmp['vip_id'] > 0 && $userVipInfoTmp['expire_status'] == 1 && $userVipInfoTmp['expire_time'] > TIMESTAMP){
    $vipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfoTmp['vip_id']);
    if($vipInfoTmp && $vipInfoTmp > 0){
        $vipInfo = $vipInfoTmp;
    }
}

$companyTopList = array();
$company_top_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['company_top_list']); 
$company_top_list_str = str_replace("\n","{n}",$company_top_list_str);
$company_top_list_arr = explode("{n}", $company_top_list_str);
if(is_array($company_top_list_arr) && !empty($company_top_list_arr)){
    foreach ($company_top_list_arr as $key => $value){
        
        $arr = explode("|", $value);
        
        if($vipInfo && $vipInfo['id'] > 0 && $vipInfo['top_zhekou'] > 0){
            $top_zhekou = $vipInfo['top_zhekou'] / 100;
            $arr[1] = $arr[1] * $top_zhekou;
            $arr[1] = round($arr[1], 2);
            if($arr[1] <= 0){
                $arr[1] = 0.01;
            }
        }
        
        $companyTopList[$key] = $arr;
        $companyTopList[$key]['score_pay'] = 0;
        $companyTopList[$key]['score'] = 0;

        if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $scorePayNum = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($scorePayNum > 0 && $__UserInfo['score'] >= $scorePayNum){
                $companyTopList[$key]['score'] = $scorePayNum;
                $companyTopList[$key]['score_pay'] = 1;
            }
        }

    }
}

$payTopUrl = "plugin.php?id=tom_tczhaopin:pay&site={$site_id}&act=company_top_pay&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:buycompany");