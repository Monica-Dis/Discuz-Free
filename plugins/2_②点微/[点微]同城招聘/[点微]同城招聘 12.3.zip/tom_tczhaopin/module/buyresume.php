<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$resume_id = intval($_GET['resume_id'])>0? intval($_GET['resume_id']):0;
$resumeInfo = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_by_id($resume_id);

$cateInfo = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($resumeInfo['cate_id']);
$cateChildInfo = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($resumeInfo['cate_child_id']);

if($resumeInfo['top_status'] == 1 && $resumeInfo['top_time'] <= TIMESTAMP){
    $updateData = array();
    $updateData['top_status']   = 0;
    $updateData['top_time']     = 0;
    C::t("#tom_tczhaopin#tom_tczhaopin_resume")->update($resume_id, $updateData);
    $resumeInfo['top_status'] = 0;
}

$resumeTopList = array();
$resume_top_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['resume_top_list']); 
$resume_top_list_str = str_replace("\n","{n}",$resume_top_list_str);
$resume_top_list_arr = explode("{n}", $resume_top_list_str);
if(is_array($resume_top_list_arr) && !empty($resume_top_list_arr)){
    foreach ($resume_top_list_arr as $key => $value){
        $arr = array();
        $resumeTopList[$key] = $arr = explode("|", $value);
        $resumeTopList[$key]['score_pay'] = 0;
        $resumeTopList[$key]['score'] = 0;

        if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $scorePayNum = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($scorePayNum > 0 && $__UserInfo['score'] >= $scorePayNum){
                $resumeTopList[$key]['score'] = $scorePayNum;
                $resumeTopList[$key]['score_pay'] = 1;
            }
        }

    }
}

$payTopUrl = "plugin.php?id=tom_tczhaopin:pay&site={$site_id}&act=resume_top_pay&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:buyresume");