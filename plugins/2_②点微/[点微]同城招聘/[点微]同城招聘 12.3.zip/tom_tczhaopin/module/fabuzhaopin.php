<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$cateArr = array();
$cateList = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_all_list(" AND pid = 0 ", 'ORDER BY csort ASC,id DESC', 0, 100);
$i = 0;
if(is_array($cateList) && !empty($cateList)){
    foreach ($cateList as $key => $value){
        $cateArr[$i]['id'] = $value['id'];
        $cateArr[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $childCateList = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid={$value['id']} "," ORDER BY csort ASC,id DESC ",0,100);
        $j = 0;
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $kk => $vv){
                $cateArr[$i]['sub'][$j]['id'] = $vv['id'];
                $cateArr[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cateData = urlencode(json_encode($cateArr));

$jianzhiCateListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_jianzhi_cate")->fetch_all_list(" ", 'ORDER BY csort ASC,id DESC');
$jianzhiCateList = array();
if(is_array($jianzhiCateListTmp) && !empty($jianzhiCateListTmp)){
    foreach ($jianzhiCateListTmp as $key => $value){
        $jianzhiCateList[$key] = $value;
    }
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$cityList = array();
$cityList[0]['id'] = 0;
$cityList[0]['name'] = diconv(lang('plugin/tom_tczhaopin', 'buxuan'),CHARSET,'utf-8');
$cityList[0]['sub'][0]['id'] = 0;
$cityList[0]['sub'][0]['name'] = '';
$i = 1;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$renzhengStatus = $companyRenzhengStatus = 0;
$natureList = $industryList = $scaleList = $rzCompanyInfo = $rz2CompanyInfo = array();
$rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$__UserInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
    $companyRenzhengStatus = 1;
    $renzhengStatus = 1;
    $rzCompanyInfo = $rzCompanyInfoTmp[0];
}
if($renzhengStatus == 0 && $tczhaopinConfig['open_shenhe_status_2_fabu'] == 1){
    $rz2CompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$__UserInfo['id']} AND shenhe_status = 2 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($rz2CompanyInfoTmp) && !empty($rz2CompanyInfoTmp[0])){
        $renzhengStatus = 2;
        $rz2CompanyInfo = $rz2CompanyInfoTmp[0];
    }
}
if($tczhaopinConfig['close_personal_renzheng'] == 0){
    $personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_user_id($__UserInfo['id']);
    if(is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1){
        $renzhengStatus = 1;
    }
    if(is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 2 && $tczhaopinConfig['open_shenhe_status_2_fabu'] == 1){
        $renzhengStatus = 2;
    }
}
$natureListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_nature")->fetch_all_list("", 'ORDER BY nsort ASC,id DESC', 0, 1000);
if(is_array($natureListTmp) && !empty($natureListTmp)){
    foreach($natureListTmp as $key => $value){
        $natureList[$key] = $value;
    }
}
$industryListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_industry")->fetch_all_list("", 'ORDER BY isort ASC,id DESC', 0, 1000);
if(is_array($industryListTmp) && !empty($industryListTmp)){
    foreach($industryListTmp as $key => $value){
        $industryList[$key] = $value;
    }
}
$scaleListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_scale")->fetch_all_list("", 'ORDER BY ssort ASC,id DESC', 0, 1000);
if(is_array($scaleListTmp) && !empty($scaleListTmp)){
    foreach($scaleListTmp as $key => $value){
        $scaleList[$key] = $value;
    }
}

$vipInfo = array();
$userVipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($__UserInfo['id']);
if($userVipInfoTmp['vip_id'] > 0 && $userVipInfoTmp['expire_status'] == 1 && $userVipInfoTmp['expire_time'] > TIMESTAMP){
    $vipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfoTmp['vip_id']);
    if($vipInfoTmp && $vipInfoTmp > 0){
        $vipInfo = $vipInfoTmp;
    }
}

$zhaopinFabuList = array();
$shenyuFabuNum = $shenyuVipFabuNum = 0;
$fabuPayStatus = 1;
if($fabuPayStatus == 1){
    $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND type = 1 AND deduct_type = 1 ");
    if($companyRenzhengStatus == 1){
        $freeFabuNum = $tczhaopinConfig['company_free_fabu_num'];
    }else{
        $freeFabuNum = $tczhaopinConfig['personal_free_fabu_num'];
    }
    if($freeFabuNum > $userLogCount){
        $shenyuFabuNum = $freeFabuNum - $userLogCount;
    }
}

if($fabuPayStatus == 1){
    if($vipInfo && $vipInfo['id'] > 0){
        $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND expire_status = 3 ");
        if($vipInfo['fabu_num'] > $userVipLogCount){
            $shenyuVipFabuNum = $vipInfo['fabu_num'] - $userVipLogCount;
        }
    }
}

$zhaopin_fabu_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['shoufei_zhaopin_price_list']);
$zhaopin_fabu_list_str = str_replace("\n","{n}",$zhaopin_fabu_list_str);
$zhaopin_fabu_list_arr = explode("{n}", $zhaopin_fabu_list_str);
$i = 0;
if(is_array($zhaopin_fabu_list_arr) && !empty($zhaopin_fabu_list_arr)){
    foreach ($zhaopin_fabu_list_arr as $key => $value){
        $arr = explode("|", $value);

        $zhaopinFabuList[$key]['days']             = $arr[0];
        $zhaopinFabuList[$key]['price']            = $arr[1];
        $zhaopinFabuList[$key]['desc']             = $arr[2];
        $zhaopinFabuList[$key]['pay_score_status'] = 0;
        $zhaopinFabuList[$key]['pay_score']        = 0;
        $zhaopinFabuList[$key]['free_status']      = 0;

        if($i == 0 && $shenyuFabuNum > 0){
            $zhaopinFabuList[$key]['free_status'] = 1;
        }

        if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $fabu_pay_score = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($fabu_pay_score > 0 && $__UserInfo['score'] > $fabu_pay_score){
                $zhaopinFabuList[$key]['pay_score_status'] = 1;
                $zhaopinFabuList[$key]['pay_score'] = $fabu_pay_score;
            }
        }
        $i++;
    }
}

$zhaopinTopList = array();
$zhaopin_top_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['zhaopin_top_list']); 
$zhaopin_top_list_str = str_replace("\n","{n}",$zhaopin_top_list_str);
$zhaopin_top_list_arr = explode("{n}", $zhaopin_top_list_str);
if(is_array($zhaopin_top_list_arr) && !empty($zhaopin_top_list_arr)){
    foreach ($zhaopin_top_list_arr as $key => $value){
        $arr = explode("|", $value);
        
        $top_price = $arr[1];
        if($vipInfo && $vipInfo['id'] > 0 && $vipInfo['top_zhekou'] > 0){
            $top_zhekou = $vipInfo['top_zhekou'] / 100;
            $top_price = $arr[1] * $top_zhekou;
            $top_price = round($top_price, 2);
            if($top_price <= 0){
                $top_price = 0.01;
            }
            $arr[2] = str_replace($arr[1], $top_price, $arr[2]);
        }

        $zhaopinTopList[$key]['days']             = $arr[0];
        $zhaopinTopList[$key]['price']            = $top_price;
        $zhaopinTopList[$key]['desc']             = $arr[2];

    }
}

$companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($__UserInfo['id']);
if(is_array($companyInfo) && !empty($companyInfo)){
    update_company_status($companyInfo);
}else{
    $insertData = array();
    $insertData['site_id']              = $site_id;
    $insertData['user_id']              = $__UserInfo['id'];
    $insertData['add_time']             = TIMESTAMP;
    if(C::t('#tom_tczhaopin#tom_tczhaopin_company')->insert($insertData)){
        $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($__UserInfo['id']);
        update_company_status($companyInfo);
    }
}

$auto_lbs = 1;
$old_area_id = $old_street_id = 0;
$old_company_name = $old_address = $old_xm = $old_tel = $old_latitude = $old_longitude = '';
$tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list(" AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,1);
if(is_array($tczhaopinListTmp) && !empty($tczhaopinListTmp) && $tczhaopinListTmp[0]['id'] > 0){
    $auto_lbs           = 0;
    $old_area_id        = $tczhaopinListTmp[0]['area_id'];
    $old_street_id      = $tczhaopinListTmp[0]['street_id'];
    $old_company_name   = $tczhaopinListTmp[0]['company_name'];
    $old_address        = $tczhaopinListTmp[0]['address'];
    $old_xm             = $tczhaopinListTmp[0]['xm'];
    $old_tel            = $tczhaopinListTmp[0]['tel'];
    $old_latitude       = $tczhaopinListTmp[0]['latitude'];
    $old_longitude      = $tczhaopinListTmp[0]['longitude'];
    if($old_area_id > 0){
        $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($old_area_id);
        $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($old_street_id);
    }
}else if($rzCompanyInfo){
    $old_xm  = $rzCompanyInfo['rz_name'];
    $old_tel = $rzCompanyInfo['tel'];
}else if($rz2CompanyInfo){
    $old_company_name   = $rz2CompanyInfo['name'];
    $old_xm             = $rz2CompanyInfo['rz_name'];
    $old_tel            = $rz2CompanyInfo['tel'];
}

$showMustPhoneBtn = 0;
if($tczhaopinConfig['zhaopin_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$zhaopinGonggao = discuzcode($tczhaopinConfig['zhaopin_gonggao'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);
$zhaopinGonggaoTxt = strip_tags(cutstr(stripslashes($zhaopinGonggao), 100 ,'...'));

$subscribeFlag = 0;
$access_token = $weixinClass->get_access_token();
if($tczhaopinConfig['open_fabuzp_guanzu']==1 && $__UserInfo['id'] > 0 && !empty($__UserInfo['openid']) && !empty($access_token)){
    $get_user_info_url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token={$access_token}&openid={$__UserInfo['openid']}&lang=zh_CN";
    $return = get_html($get_user_info_url);
    if(!empty($return)){
        $tcContent = json_decode($return,true);
        if(is_array($tcContent) && !empty($tcContent) && isset($tcContent['subscribe'])){
            if($tcContent['subscribe'] == 1){
                $subscribeFlag = 1;
            }else{
                $subscribeFlag = 2;
            }
        }
    }
}

$ossBatchUrl = 'plugin.php?id=tom_tczhaopin:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tczhaopin:qiniuBatch';
$wxUploadUrl = "plugin.php?id=tom_tczhaopin:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$uploadUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=upload&act=photo&formhash={$formhash}&suffix=";
$shareUrl = $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=fabuzhaopin";
$payUrl = "plugin.php?id=tom_tczhaopin:pay&site={$site_id}";
$jumpUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:fabuzhaopin");