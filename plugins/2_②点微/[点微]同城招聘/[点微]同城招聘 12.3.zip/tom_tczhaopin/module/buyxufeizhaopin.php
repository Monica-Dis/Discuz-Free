<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tczhaopin_id = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):0;
$tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($tczhaopin_id);

$cateInfo = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($tczhaopinInfo['cate_id']);
$cateChildInfo = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($tczhaopinInfo['cate_child_id']);
$jianzhiCateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_by_id($tczhaopinInfo['jianzhi_cate_id']);

if($tczhaopinInfo['expire_status'] == 1 && $tczhaopinInfo['expire_time'] <= TIMESTAMP && $tczhaopinInfo['top_status'] == 0){
    $updateData = array();
    $updateData['expire_status']   = 2;
    $updateData['expire_time']     = 0;
    if($tczhaopinConfig['expire_do_type'] == 1){
        $updateData['status']      = 0;
    }
    C::t("#tom_tczhaopin#tom_tczhaopin")->update($tczhaopin_id, $updateData);
    update_zhaopin_tongcheng($tczhaopin_id);
    $companyInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
    update_company_status($companyInfoTmp);
    $tczhaopinInfo['expire_status'] = 2;
}

$shenyuVipFabuNum = 0;
$userVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($__UserInfo['id']);
if($userVipInfo['vip_id'] > 0 && $userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
    $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
    $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND expire_status = 3 ");
    if($vipInfo['fabu_num'] > $userVipLogCount){
        $shenyuVipFabuNum = $vipInfo['fabu_num'] - $userVipLogCount;
    }
}
    
$zhaopinFabuList = array();
$zhaopin_fabu_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['shoufei_zhaopin_price_list']);
$zhaopin_fabu_list_str = str_replace("\n","{n}",$zhaopin_fabu_list_str);
$zhaopin_fabu_list_arr = explode("{n}", $zhaopin_fabu_list_str);
if(is_array($zhaopin_fabu_list_arr) && !empty($zhaopin_fabu_list_arr)){
    foreach ($zhaopin_fabu_list_arr as $key => $value){
        $arr = explode("|", $value);

        $zhaopinFabuList[$key]['days']             = $arr[0];
        $zhaopinFabuList[$key]['price']            = $arr[1];
        $zhaopinFabuList[$key]['desc']             = $arr[2];
        $zhaopinFabuList[$key]['pay_score_status'] = 0;
        $zhaopinFabuList[$key]['pay_score']        = 0;
        $zhaopinFabuList[$key]['free_status']      = 0;

        if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $fabu_pay_score = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($fabu_pay_score > 0 && $__UserInfo['score'] >= $fabu_pay_score){
                $zhaopinFabuList[$key]['pay_score_status'] = 1;
                $zhaopinFabuList[$key]['pay_score'] = $fabu_pay_score;
            }
        }
    }
}

$backUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist";
$payXufeiUrl = "plugin.php?id=tom_tczhaopin:pay&site={$site_id}&act=zhaopin_xufei_pay&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:buyxufeizhaopin");