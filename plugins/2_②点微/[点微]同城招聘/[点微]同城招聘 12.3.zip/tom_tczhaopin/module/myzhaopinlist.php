<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$page  = intval($_GET['page'])>0? intval($_GET['page']):1;
$type  = intval($_GET['type'])>0? intval($_GET['type']):0;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND user_id={$__UserInfo['id']} ";
$order = " ORDER BY refresh_time DESC,id DESC ";
if($type == 1){
    $where.= " AND status=1 ";
}
if($type == 2){
    $where.= " AND (pay_status=1 OR expire_status = 2) ";
}
if($type == 3){
    $where.= " AND (shenhe_status=2 OR shenhe_status=3) ";
    $order = " ORDER BY shenhe_status ASC,id DESC ";
}

$count = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count(" {$where} ");
$tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list(" {$where} "," {$order} ",$start,$pagesize);
$tczhaopinList = array();
if(is_array($tczhaopinListTmp) && !empty($tczhaopinListTmp)){
    foreach ($tczhaopinListTmp as $key => $value){
        $tczhaopinList[$key] = $value;

        $workWelfareArr = explode('-', trim($value['work_welfare'], '-'));
        $welfareList = array();
        if(is_array($welfareArray) && !empty($welfareArray)){
            foreach($welfareArray as $k => $v){
                if(in_array($k,$workWelfareArr)){
                    $welfareList[$k]['name'] = $v;
                }
            }
        }

        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($value['cate_child_id']);    
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);

        $tczhaopinList[$key]['welfareList']     = $welfareList;
        $tczhaopinList[$key]['cateInfo']        = $cateInfo;
        $tczhaopinList[$key]['areaInfo']        = $areaInfoTmp;
        $tczhaopinList[$key]['streetInfo']      = $streetInfoTmp;

        if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value['id'], $updateData);
        }
        
        if($value['pay_status'] == 1 && $value['expire_status'] == 3){
            $updateData['expire_status']   = 2;
            $updateData['expire_time']     = 0;
            $updateData['status']          = 0;
            $updateData['pay_status']      = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value['id'], $updateData);
            $tczhaopinList[$key]['expire_status'] = 2;
        }
        
        if($value['expire_status'] == 1 && $value['expire_time'] <= TIMESTAMP && $value['top_status'] == 0){
            $updateData = array();
            $updateData['expire_status']   = 2;
            $updateData['expire_time']     = 0;
            if($tczhaopinConfig['expire_do_type'] == 1){
                $updateData['status']      = 0;
            }
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value['id'], $updateData);
            update_zhaopin_tongcheng($value['id']);
            $companyInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($value['company_id']);
            update_company_status($companyInfoTmp);
            $tczhaopinList[$key]['expire_status'] = 2;
        }
        
        $tczhaopinList[$key]['match_resume_num'] = 0;
        $tczhaopinList[$key]['match_resume_url'] = '';
        if($zhaopinSetting['open_resume_match'] == 1 && $value['shenhe_status'] == 1 && $value['cate_id'] > 0){
            $whereStrTmp            = " AND status=1 AND shenhe_status=1 AND gongkai_status = 1 AND cate_id = {$value['cate_id']} ";
            $match_resume_url_tmp   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=resumelist&cate_id={$value['cate_id']}";
            if(!empty($sql_in_site_ids)){
                $whereStrTmp.= " AND site_id IN({$sql_in_site_ids}) ";
            }
            $cate_child_search_tmp = '';
            if($zhaopinSetting['resume_match_cate_child'] == 1){
                if($value['cate_child_id'] > 0){
                    $cate_child_search_tmp = '-'.$value['cate_child_id'].'-';
                    $match_resume_url_tmp.="&cate_child_id={$value['cate_child_id']}";
                }
            }
            if($zhaopinSetting['resume_match_area'] == 1){
                if($value['area_id'] > 0){
                    $whereStrTmp.= " AND area_id={$value['area_id']} ";
                    $match_resume_url_tmp.="&area_id={$value['area_id']}";
                }
                if($value['street_id'] > 0){
                    $whereStrTmp.= " AND street_id={$value['street_id']} ";
                    $match_resume_url_tmp.="&street_id={$value['street_id']}";
                }
            }
            $tczhaopinList[$key]['match_resume_num'] = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count($whereStrTmp,$cate_child_search_tmp);
            $tczhaopinList[$key]['match_resume_url'] = $match_resume_url_tmp;
        }
        
        
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist&type={$type}&page={$nextPage}";

$companyRenzhengStatus = 0;
$rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$__UserInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
    $companyRenzhengStatus = 1;
}

$refreshPayStatus = 1;
$shenyuVipRefreshNum = 0;
if($refreshPayStatus == 1){
    $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND type = 2 AND today_time = {$nowDayTime} AND deduct_type = 1 ");
    if($companyRenzhengStatus == 1){
        $freeRefreshNum = $tczhaopinConfig['company_free_refresh_num'];
    }else{
        $freeRefreshNum = $tczhaopinConfig['personal_free_refresh_num'];
    }
    if($freeRefreshNum > $userLogCount){
        $refreshPayStatus = 2;
    }
}

$userVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($__UserInfo['id']);
$vipInfo = array();
$nowTime = TIMESTAMP;
if($userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > $nowTime){
    $shengyuDays = ceil(($userVipInfo['expire_time'] - $nowTime)/86400);
    $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
    
    $userVipFabuLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND expire_status = 3 ");
    $shengyuFabu = $vipInfo['fabu_num'] - $userVipFabuLogCount;
    if($shengyuFabu <= 0){
        $shengyuFabu = 0;
    }
}else if($userVipInfo['id'] > 0 && $userVipInfo['expire_status'] == 0){
    $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
}

if($refreshPayStatus == 1){
    if($userVipInfo['vip_id'] > 0 && $userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
        $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND type = 2 AND today_time = {$nowDayTime} AND deduct_type = 2 ");
        if($vipInfo['refresh_num'] > $userVipLogCount){
            $refreshPayStatus = 3;
            $shenyuVipRefreshNum = $vipInfo['refresh_num'] - $userVipLogCount;
        }
    }
}

if($refreshPayStatus == 1){
    if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
        $scorePayNum = ceil(floatval($tczhaopinConfig['shoufei_zhaopin_refresh_price']) * $tongchengConfig['pay_score_yuan']);
        if($__UserInfo['score'] >= $scorePayNum){
            $refreshPayStatus = 4;
        }
    }
}

$payUrl = "plugin.php?id=tom_tczhaopin:pay&site={$site_id}&act=zhaopin_pay&formhash=".$formhash;
$ajaxUpdateStatusUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=updateZhaopinStatus&formhash=".$formhash;
$payRefreshUrl = "plugin.php?id=tom_tczhaopin:pay&site={$site_id}&user_id={$__UserInfo['id']}&act=pay_refresh&&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:myzhaopinlist");