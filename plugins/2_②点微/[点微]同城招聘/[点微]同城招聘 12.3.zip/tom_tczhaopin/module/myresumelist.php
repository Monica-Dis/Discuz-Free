<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$page = intval($_GET['page'])>0? intval($_GET['page']):1;
$type  = intval($_GET['type'])>0? intval($_GET['type']):0;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND user_id={$__UserInfo['id']} AND deleted = 0 ";
if($type == 1){
    $where.= " AND status=1 ";
}
if($type == 2){
    $where.= " AND gongkai_status=0 ";
}
if($type == 3){
    $where.= " AND (shenhe_status=2 OR shenhe_status=3) ";
    $order = " ORDER BY shenhe_status ASC,id DESC ";
}

$order = " ORDER BY refresh_time DESC,id DESC ";
$count = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count(" {$where} ");
$resumeListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_list(" {$where} "," {$order} ",$start,$pagesize);
$resumeList = array();
if(is_array($resumeListTmp) && !empty($resumeListTmp)){
    foreach ($resumeListTmp as $key => $value){
        $resumeList[$key] = $value;
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);

        if(!empty($value['avatar'])){
            if(!preg_match('/^http/', $value['avatar'])){
                if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                    $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
                }else{
                    $avatarTmp = $value['avatar'];
                }
            }else{
                $avatarTmp = $value['avatar'];
            }
        }else{
            if($value['sex'] == 1){
                $avatarTmp = $man_resume_avatar;
            }else if($value['sex'] == 2){
                $avatarTmp = $woman_resume_avatar;
            }
        }

        $clicks = $value['clicks'];
        if($value['clicks'] > 1000000){
            $clicks = number_format($value['clicks']/1000000, 0).lang('plugin/tom_tczhaopin', 'baiwan');
        }else if($value['clicks'] > 10000){
            $clicks = number_format($value['clicks']/10000, 2).lang('plugin/tom_tczhaopin', 'wan');
        }

        $resumeList[$key]['age']            = dgmdate(TIMESTAMP,"Y",$tomSysOffset) - $value['birth_year'];
        $resumeList[$key]['clicks']         = $clicks;
        $resumeList[$key]['areaInfo']       = $areaInfoTmp;
        $resumeList[$key]['streetInfo']     = $streetInfoTmp;
        $resumeList[$key]['avatar']         = $avatarTmp;

        if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value['id'], $updateData);
        }
        
        $resumeList[$key]['match_zhaopin_num'] = 0;
        $resumeList[$key]['match_zhaopin_url'] = '';
        if($zhaopinSetting['open_zhaopin_match'] == 1 && $value['shenhe_status'] == 1 && $value['cate_id'] > 0){
            
            $whereStrTmp            = " AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND type=1 AND cate_id={$value['cate_id']}  ";
            $match_zhaopin_url_tmp  = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=zhaopinlist&cate_id={$value['cate_id']}";
            if(!empty($sql_in_site_ids)){
                $whereStrTmp.= " AND site_id IN({$sql_in_site_ids}) ";
            }
            if($zhaopinSetting['zhaopin_match_cate_child'] == 1){
                if(!empty($value['cate_child_ids'])){
                    $whereStrTmp.= " AND cate_child_id IN({$value['cate_child_ids']}) ";
                    $match_zhaopin_url_tmp.="&cate_child_ids={$value['cate_child_ids']}";
                }
            }
            if($zhaopinSetting['zhaopin_match_area'] == 1){
                if($value['area_id'] > 0){
                    $whereStrTmp.= " AND area_id={$value['area_id']} ";
                    $match_zhaopin_url_tmp.="&area_id={$value['area_id']}";
                }
                if($value['street_id'] > 0){
                    $whereStrTmp.= " AND street_id={$value['street_id']} ";
                    $match_zhaopin_url_tmp.="&street_id={$value['street_id']}";
                }
            }
            $resumeList[$key]['match_zhaopin_num'] = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count($whereStrTmp);
            $resumeList[$key]['match_zhaopin_url'] = $match_zhaopin_url_tmp;
            
        }
        
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myresumelist&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myresumelist&page={$nextPage}";

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=updateResumeStatus&&formhash=".$formhash;
$ajaxRefreshUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=refreshResume&&formhash=".$formhash;
$ajaxDeleteUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=deleteResume&&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:myresumelist");