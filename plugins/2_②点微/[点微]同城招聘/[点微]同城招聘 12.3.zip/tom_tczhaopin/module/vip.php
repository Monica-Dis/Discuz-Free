<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$nowTime        = TIMESTAMP;
$shengyuDays    = 0;
$vipDays        = 0 ;
$shengyuFabu    = 0;
$shenyuVipResumeNum = 0;
$top_zhekou     = 0;
$vipInfo        = array();
$userVipInfo    = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($__UserInfo['id']);
if($userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > $nowTime){
    $shengyuDays = ceil(($userVipInfo['expire_time'] - $nowTime)/86400);
    $vipInfo        = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
    $vipDays        = $vipInfo['days'];
    
    $userVipFabuLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND expire_status = 3 ");
    if($vipInfo['fabu_num'] > $userVipFabuLogCount){
        $shengyuFabu = $vipInfo['fabu_num'] - $userVipFabuLogCount;
    }
    
    $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND type = 3 AND deduct_type = 2");
    if($vipInfo['resume_num'] > $userVipLogCount){
        $shenyuVipResumeNum = $vipInfo['resume_num'] - $userVipLogCount;
    }
    
    if($vipInfo['top_zhekou'] > 0){
        $top_zhekou = $vipInfo['top_zhekou'] / 10;
        $top_zhekou = trim($top_zhekou, '.0');
    }
    
}else if($userVipInfo['id'] > 0 && $userVipInfo['expire_status'] == 0){
    $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
}

$vipListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_all_list(" AND status = 1 ", 'ORDER BY tsort ASC,id DESC', 0, 100);
$vipList = array();
if(is_array($vipListTmp) && !empty($vipListTmp)){
    foreach($vipListTmp as $key => $value){  
        
        $value['beizu'] = trim($value['beizu']);
        
        if($value['top_zhekou'] > 0){
            $value['top_zhekou'] = $value['top_zhekou'] / 10;
            $value['top_zhekou'] = trim($value['top_zhekou'], '.0');
        }
        
        if($value['max_num'] > 0){
            $useVipCount = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND vip_id = {$value['id']} AND type = 6 AND order_status = 2 ");
            if($useVipCount >= $value['max_num']){
                continue;
            }
        }
        if($value['days'] >=  $vipDays){
            $vipList[$key] = $value;
            $day_money = number_format($value['price']/$value['days'],2, '.', '');
            $vipList[$key]['day_money'] = floatval($day_money);
        }
    }
}

$payUrl = "plugin.php?id=tom_tczhaopin:pay&site={$site_id}&act=pay_vip&user_id={$__UserInfo['id']}&formhash={$formhash}";
$ajaxCodeUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=vip_code&formhash={$formhash}";

$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=vip";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:vip");