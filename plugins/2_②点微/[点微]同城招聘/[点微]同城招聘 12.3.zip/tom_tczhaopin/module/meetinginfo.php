<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$s = intval($_GET['s']) >0 ? intval($_GET['s']):0;

$meeting_id = intval($_GET['meeting_id'])>0 ? intval($_GET['meeting_id']):0;
$meetingInfo = C::t("#tom_tczhaopin#tom_tczhaopin_meeting")->fetch_by_id($meeting_id);
if(is_array($meetingInfo) && !empty($meetingInfo) && $meetingInfo['status'] == 1){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=index");exit;
}

if(!preg_match('/^http/', $meetingInfo['picurl']) ){
    if(strpos($meetingInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $shareLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$meetingInfo['picurl'];
    }else{
        $shareLogo = $_G['siteurl'].$meetingInfo['picurl'];
    }
}else{
    $shareLogo = $meetingInfo['picurl'];
}

if(!preg_match('/^http/', $meetingInfo['theme_picurl']) ){
    if(strpos($meetingInfo['theme_picurl'], 'source/plugin/tom_') === FALSE){
        $themePicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$meetingInfo['theme_picurl'];
    }else{
        $themePicurl = $_G['siteurl'].$meetingInfo['theme_picurl'];
    }
}else{
    $themePicurl = $meetingInfo['theme_picurl'];
}

if(!preg_match('/^http/', $meetingInfo['haibao_picurl']) ){
    if(strpos($meetingInfo['haibao_picurl'], 'source/plugin/tom_') === FALSE){
        $haibao_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$meetingInfo['haibao_picurl'];
    }else{
        $haibao_picurl = $meetingInfo['haibao_picurl'];
    }
}else{
    $haibao_picurl = $meetingInfo['haibao_picurl'];
}

$meetingCompanyListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_meeting_company")->fetch_all_list(" AND meeting_id = {$meeting_id} AND status = 1 AND (pay_status = 0 OR pay_status = 2) ", 'ORDER BY is_recommend DESC, csort ASC, id DESC', 0, 10000);
$tczhaopinCount = 0;
if($meetingInfo['zhaopin_list_type'] == 1){
    $tczhaopinIdsArr = array();
    if(is_array($meetingCompanyListTmp) && !empty($meetingCompanyListTmp)){
        foreach ($meetingCompanyListTmp as $key => $value) {
            if(!empty($value['tczhaopin_ids'])){
                $tczhaopinIdsArr[] = $value['tczhaopin_ids'];
            }
        }
    }
    if(is_array($tczhaopinIdsArr) && !empty($tczhaopinIdsArr)){
        $tczhaopinIdsStr = implode(',', $tczhaopinIdsArr);
        $tczhaopinCount =  C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND id IN({$tczhaopinIdsStr}) AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ");
    }
}else{
    $tczhaopinCompanyIdsArr = array();
    if(is_array($meetingCompanyListTmp) && !empty($meetingCompanyListTmp)){
        foreach ($meetingCompanyListTmp as $key => $value) {
            if(!empty($value['company_id'])){
                $tczhaopinCompanyIdsArr[] = $value['company_id'];
            }
        }
    }
    if(is_array($tczhaopinCompanyIdsArr) && !empty($tczhaopinCompanyIdsArr)){
        $tczhaopinCompanyIdsStr = implode(',', $tczhaopinCompanyIdsArr);
        $tczhaopinCount =  C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND company_id IN({$tczhaopinCompanyIdsStr}) AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ");
    }
}

$clicks = $meetingInfo['clicks'] + $meetingInfo['virtual_clicks'];

$campanyCount = C::t("#tom_tczhaopin#tom_tczhaopin_meeting_company")->fetch_all_count(" AND meeting_id = {$meeting_id} AND status = 1 AND (pay_status = 0 OR pay_status = 2 )");

$canhui_txt = stripslashes($meetingInfo['canhui_txt']);
$content = stripslashes($meetingInfo['content']);

$renzhengCompanyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($__UserInfo['id']);
$renzhengCompanyStatus = 0;
if(is_array($renzhengCompanyInfo) && !empty($renzhengCompanyInfo)){
    $renzhengCompanyStatus = 1;
    if($renzhengCompanyInfo['shenhe_status'] == 1){
        $renzhengCompanyStatus = 2;
    }
}

$meetingCompanyInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_meeting_company")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND meeting_id = {$meeting_id} AND (pay_status = 0 OR pay_status = 2) ", 'ORDER BY id DESC', 0, 1);
$meetingCompanyInfo = array();
$companyCanhuiStatus = 0;
if(is_array($meetingCompanyInfoTmp) && !empty($meetingCompanyInfoTmp[0])){
    $meetingCompanyInfo = $meetingCompanyInfoTmp[0];
    $companyCanhuiStatus = 1;

    if($renzhengCompanyStatus == 2){
        $companyCanhuiStatus = 2;

        $tczhaopinIdsArr = explode(',', $meetingCompanyInfo['tczhaopin_ids']);

        $tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND user_id = {$__UserInfo['id']} ",'ORDER BY top_status DESC,refresh_time DESC,id DESC',0,100);
        $tczhaopinList = array();
        if(is_array($tczhaopinListTmp) && !empty($tczhaopinListTmp)){
            foreach($tczhaopinListTmp as $key => $value){
                $tczhaopinList[$key] = $value;
                if(in_array($value['id'], $tczhaopinIdsArr)){
                    $tczhaopinList[$key]['checked'] = 1;
                }else{
                    $tczhaopinList[$key]['checked'] = 0;
                }

                $cateInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($value['cate_child_id']);
                $tczhaopinList[$key]['cateInfo'] = $cateInfoTmp;
            }
        }
        $selectTczhaopinCount = count($tczhaopinList);
    }
}

$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
if($__SitesInfo['id'] > 1){
    if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])){
        if(strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_tongcheng/') === FALSE){
            $kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
        }else{
            $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
        }
    }else{
        $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
    }
}

$tczhaopinConfig['kefu_qrcode'] = trim($tczhaopinConfig['kefu_qrcode']);
if(!empty($tczhaopinConfig['kefu_qrcode'])){
    $kefuQrcodeSrc = $tczhaopinConfig['kefu_qrcode'];
}

if(!empty($meetingInfo['share_title'])){
    $shareTitle = $meetingInfo['share_title'];
}

if(!empty($meetingInfo['share_desc'])){
    $shareDesc = $meetingInfo['share_desc'];
}

$baiduMapToName = $meetingInfo['title'];
$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
$baiduMapToName = urlencode($baiduMapToName);
$baiduMapUrl = "http://api.map.baidu.com/marker?location={$meetingInfo['latitude']},{$meetingInfo['longitude']}&title={$baiduMapToName}&content=&output=html";

$md5HostUrl = md5($_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=meetinginfo&meeting_id={$meeting_id}");

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=meetinginfo&meeting_id={$meeting_id}";
if($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0){
    if($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1){
        $shareUrl = $shareUrl."&tjid={$tchehuorenInfoTmp['id']}";
    }
}
$haibaoQrcodeImg = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($shareUrl);

$ajaxListUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=meetingcompanylist&meeting_id={$meeting_id}&formhash=".$formhash;
$ajaxCanhuiUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=canhui&meeting_id={$meeting_id}&formhash=".$formhash;
$ajaxSelectUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=selectZhaopin&formhash=".$formhash;
$ajaxClicksUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=meetinginfo_clicks&meeting_id={$meeting_id}&formhash=".$formhash;
$payUrl = "plugin.php?id=tom_tczhaopin:pay&site={$site_id}&act=canhui_pay&meeting_id={$meeting_id}&user_id={$__UserInfo['id']}&formhash=".$formhash;
$ajaxSearchUrl = "plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=get_meetinginfo_search_url&meeting_id={$meeting_id}&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:meetinginfo");