<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
$tomSysOffset = getglobal('setting/timeoffset');

$showQrcode = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
    $showQrcode = 1;
    include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
}

$tempDir = "/source/plugin/tom_tczhaopin/data/infoqrcode/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0755); 
}

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.utf.php';
}
$welfareArray = array();
$welfare_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['welfare_list']); 
$welfare_list_str = str_replace("\n","{n}",$welfare_list_str);
$welfare_list_arr = explode("{n}", $welfare_list_str);
if(is_array($welfare_list_arr) && !empty($welfare_list_arr)){
    foreach ($welfare_list_arr as $key => $value){
        $welfare_list_item = explode("|", $value);
        $welfare_list_item_id = intval($welfare_list_item[0]);
        $welfare_list_item_name = trim($welfare_list_item[1]);
        if($welfare_list_item_id > 0 && !empty($welfare_list_item_name)){
            $welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
        }
    }
}

$colorArr = array();
$colorArr[1] = 'rgb(236, 75, 10)';
$colorArr[2] = 'rgb(234, 186, 0)';
$colorArr[3] = 'rgb(31, 199, 3)';
$colorArr[4] = 'rgb(3, 199, 137)';
$colorArr[5] = 'rgb(3, 143, 199)';

$page        = isset($_GET['page'])? intval($_GET['page']):1;
$type        = isset($_GET['type'])? intval($_GET['type']):0;
$day_type    = isset($_GET['day_type'])? intval($_GET['day_type']):1;
$days        = isset($_GET['days'])? intval($_GET['days']):0;
$hidetel     = isset($_GET['hidetel'])? intval($_GET['hidetel']):0;
$from        = isset($_GET['from'])? addslashes($_GET['from']):'';

$site_ids   = isset($_GET['site_ids'])? addslashes($_GET['site_ids']):'';
$site_ids_tmp = explode('_', $site_ids);
$site_ids_arr = array();
if(is_array($site_ids_tmp) && !empty($site_ids_tmp)){
    foreach ($site_ids_tmp as $key => $value){
        $value = intval($value);
        if($value > 0){
            $site_ids_arr[] = $value;
        }
    }
}

$cate_ids   = isset($_GET['cate_ids'])? addslashes($_GET['cate_ids']):'';
$cate_ids_tmp = explode('_', $cate_ids);
$cate_ids_arr = array();
if(is_array($cate_ids_tmp) && !empty($cate_ids_tmp)){
    foreach ($cate_ids_tmp as $key => $value){
        $value = intval($value);
        if($value > 0){
            $cate_ids_arr[] = $value;
        }
    }
}

$where = " AND shenhe_status = 1 AND status = 1 ";

if(!empty($site_ids_arr)){
    $where.= " AND site_id IN (".implode(',',$site_ids_arr).") ";
}else if($site_id){
    $where.= " AND site_id = {$site_id} ";
}
if(!empty($cate_ids_arr)){
    $where.= " AND cate_id IN (".implode(',',$cate_ids_arr).") ";
}
if($type > 0){
    $where.= " AND type = {$type} ";
}

if($days > 0){
    $minTime = TIMESTAMP - $days * 86400;
    if($day_type == 1){
        $where.= " AND (refresh_time > {$minTime} OR top_status = 1 ) ";
    }else{
        $where.= " AND (add_time > {$minTime} OR top_status = 1 ) ";
    }
}

$order = " ORDER BY top_status DESC,refresh_time DESC,id DESC ";
if($day_type == 2){
    $order = " ORDER BY top_status DESC,add_time DESC,id DESC ";
}

$pagesize = 1000;
$start = ($page-1)*$pagesize;
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$quanXianStatus = false;
if($from == 'tom_admin'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_pc.php';
    $adminConfig = $_G['cache']['plugin']['tom_admin'];
    if(!empty($adminConfig['manage_user_id']) && $adminConfig['manage_user_id'] == $__UserInfo['id']){
        $quanXianStatus = true;
    }else{
        $addminManagerInfo = C::t("#tom_admin#tom_admin_manager")->fetch_by_user_id($__UserInfo['id']);
        if(empty($addminManagerInfo)){
            include template("tom_admin:error");exit;
        }
        
        $powerListTmp = C::t("#tom_admin#tom_admin_role_power")->fetch_all_list(" AND plugin_id = 'zhaopin' AND role_id={$addminManagerInfo['role_id']} ", "ORDER BY id ASC");
        if(!empty($powerListTmp)){
            foreach($powerListTmp as $key => $value){
                $powerList[] = $value['type'];
            }
        }
        
        if(in_array('resume', $powerList)){
            $quanXianStatus = true;
        }
        
    }
}else{
    if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
        $quanXianStatus = true;
    }
}

if($quanXianStatus === true){
    
    $resumeListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_list($where,$order,$start,$pagesize);
    $topList = array();
    $resumeList = array();
    foreach ($resumeListTmp as $key => $value) {
        
        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($value['cate_id']);
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
        
        $sex_call = '';
        if($value['sex'] == 1){
            $sex_call = lang('plugin/tom_tczhaopin', 'resumelist_sex_1_call');
        }else if($value['sex'] == 2){
            $sex_call = lang('plugin/tom_tczhaopin', 'resumelist_sex_2_call');
        }
        
        $name = lang('plugin/tom_tongcheng', 'doDao_left').cutstr($value['name'], 2,'').$sex_call.lang('plugin/tom_tongcheng', 'doDao_right');
        
        if($value['work_salary'] > 1){
            $content = lang('plugin/tom_tczhaopin', 'doDao_resume_salary').'<span style="font-size: 20px;color: rgb(255, 84, 0);">'.$workSalaryArray[$value['work_salary']] .lang('plugin/tom_tczhaopin', 'doDao_yuan').'</span>&nbsp;&nbsp;';
        }else{
            $content = lang('plugin/tom_tczhaopin', 'doDao_resume_salary').'<span style="font-size: 20px;color: rgb(255, 84, 0);">'.$workSalaryArray[$value['work_salary']] .'</span>&nbsp;&nbsp;';
        }
        
        $content .= lang('plugin/tom_tczhaopin', 'doDao_resume_jinyan').'<span style="color: rgb(3, 140, 21);">'.$workJingyanArray[$value['work_jingyan']] .'</span>&nbsp;&nbsp;';
        
        $content .= lang('plugin/tom_tczhaopin', 'doDao_resume_cate').$cateInfo['name'].'/'.$value['cate_child_str'].'&nbsp;&nbsp;';
        
        $age = dgmdate(TIMESTAMP,"Y",$tomSysOffset) - $value['birth_year'];
        //$content .= lang('plugin/tom_tczhaopin', 'doDao_resume_age').$age .'&nbsp;&nbsp;';
        
       //$content .= lang('plugin/tom_tczhaopin', 'doDao_resume_xueli').$xueliArray[$value['xueli']] .'&nbsp;&nbsp;';
        
        if($value['marital'] == 1){
            //$content .= lang('plugin/tom_tczhaopin', 'doDao_resume_marital').lang('plugin/tom_tczhaopin', 'doDao_resume_marital_1') .'&nbsp;&nbsp;';
        }else if($value['marital'] == 2){
            //$content .= lang('plugin/tom_tczhaopin', 'doDao_resume_marital').lang('plugin/tom_tczhaopin', 'doDao_resume_marital_2') .'&nbsp;&nbsp;';
        }
        
        if($value['area_id'] > 0 && $value['street_id'] > 0){
            //$content .= lang('plugin/tom_tczhaopin', 'doDao_resume_location').$areaInfoTmp['name'].'-'.$streetInfoTmp['name'] .'&nbsp;&nbsp;';
        }else{
            //$content .= lang('plugin/tom_tczhaopin', 'doDao_resume_location').$areaInfoTmp['name'].'&nbsp;&nbsp;';
        }
        
        $content .= lang('plugin/tom_tczhaopin', 'doDao_resume_work_jingli').$value['work_jingli'] .'&nbsp;&nbsp;';
        
        if($hidetel == 1){
            $value['tel'] = substr($value['tel'], 0, 3)."*******";
        }
        
        $infoqrcodeUrl = '';
        if($showQrcode == 1){
            $infoUrlTmp = $_G['siteurl'].'plugin.php?id=tom_tczhaopin&site='.$value['site_id'].'&mod=resumeinfo&resume_id='.$value['id'];
            $infoqrcodeUrl = 'source/plugin/tom_tczhaopin/data/infoqrcode/'.md5($infoUrlTmp).'.png';
            $infoqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/data/infoqrcode/'.md5($infoUrlTmp).'.png';
            if(file_exists($infoqrcodeImg)){
            }else{
                QRcode::png($infoUrlTmp,$infoqrcodeImg,'H',5,2);
            }
        }
        
        if($value['top_status'] == 1){
            $topList[$key]['name'] = $name;
            $topList[$key]['content'] = $content;
            $topList[$key]['tel'] = $value['tel'];
            $topList[$key]['qrcode'] = $infoqrcodeUrl;
        }else{
            $resumeList[$cateInfo['id']]['name'] = $cateInfo['name'];
            $resumeList[$cateInfo['id']]['data'][$key]['name'] = $name;
            $resumeList[$cateInfo['id']]['data'][$key]['content'] = $content;
            $resumeList[$cateInfo['id']]['data'][$key]['tel'] = $value['tel'];
            $resumeList[$cateInfo['id']]['data'][$key]['qrcode'] = $infoqrcodeUrl;
        }
    }
    
    $newList = array();
    if(is_array($cate_ids_arr) && !empty($cate_ids_arr)){
        foreach ($cate_ids_arr as $key => $value){
            if(isset($resumeList[$value])){
                $newList[$value] = $resumeList[$value];
            }
        }
    }
    
    if (CHARSET == 'gbk'){
        $outStr = '<meta charset="gbk" /> ';
    }else{
        $outStr = '<meta charset="utf-8" /> ';
    }
    $outStr.= '<section style="font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px;">';
         $outStr.= '<p style="white-space: normal;"><br /></p> ';
         $outStr.= '<p style="max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);">';
           $outStr.= '<span style="max-width: 100%; color: rgb(255, 255, 255); box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(236, 101, 5);">'.lang('plugin/tom_tongcheng', 'doDao_msg1').'</span>';
         $outStr.= '</p> ';
         $outStr.= '<p style="max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);"> ';
           $outStr.= '<span style="max-width: 100%; color: rgb(255, 255, 255); box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(236, 101, 5);">'.lang('plugin/tom_tongcheng', 'doDao_msg2').'</span> ';
         $outStr.= '</p> ';
         $outStr.= '<p style="max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);">'; 
           $outStr.= '<span style="max-width: 100%; color: rgb(236, 101, 5); font-size: 12px; line-height: 19.2px; box-sizing: border-box !important; word-wrap: break-word !important;">'.lang('plugin/tom_tongcheng', 'doDao_jian').'</span> ';
         $outStr.= '</p> ';
         $outStr.= '<p style="margin: 0px;max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);">';
           $outStr.= '<img style="max-width: 60%;" src="'.$tongchengConfig['fwh_qrcode'].'"/>';
         $outStr.= '</p> <br /> ';
    $outStr.= '</section> ';
    
    if(is_array($topList) && !empty($topList)){
        $outStr.= '<section style="margin: 2em 0em; padding: 0.5em 0.8em; white-space: normal; border: 1px solid '.$colorArr[1].';border-radius: 6px; font-size: 1em; font-family: inherit; font-weight: inherit; text-decoration: inherit; color: rgb(166, 166, 166); background-color: rgb(255, 255, 255);"> ';
            $outStr.= '<section style="margin-top: -1.4em; text-align: center; border: none; line-height: 1.4;"> ';
               $outStr.= '<section style="padding-right: 24px; padding-left: 24px; color: '.$colorArr[1].'; font-size: 30px; font-family: inherit; text-decoration: inherit; border-color: rgb(255, 255, 255); display: inline-block; background-color: rgb(254, 255, 255); "> ';
                  $outStr.= '<section>'.lang('plugin/tom_tongcheng', 'doDao_top_title').'</section> ';
               $outStr.= '</section> ';
            $outStr.= '</section> ';
            $outStr.= '<section style="padding: 16px 0px; color: rgb(32, 32, 32); line-height: 2; font-family: inherit;"> ';
            foreach ($topList as $kk => $vv){
                $outStr.= '<p style="word-break:break-all;word-wrap:break-word;margin: 5px 0px;padding-bottom: 5px;"> ';
                    $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 1.5; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;"><span style="color: '.$colorArr[1].';">'.lang('plugin/tom_tongcheng', 'doDao_jian').$vv['name'].'</span>'.$vv['content'].'<b style="color:#222">'.lang('plugin/tom_tongcheng', 'doDao_msg_lianxi_1').$vv['tel'].lang('plugin/tom_tongcheng', 'doDao_msg_lianxi_2').'</b></span> ';
                $outStr.= '</p> ';
                if(!empty($vv['qrcode'])){
                    $outStr.= '<span style="display: block;text-align: center;"><img style="width:120px;" src="'.$vv['qrcode'].'"/></span> ';
                    $outStr.= '<span style="display: block;text-align: center;color:#999;font-size: 12px;">'.lang('plugin/tom_tongcheng', 'doDao_qrcode_msg').'</span> ';
                }
            }
            $outStr.= '</section>';
        $outStr.= '</section>';
    }
    
    $color_i = 2;
    if(is_array($newList) && !empty($newList)){
        foreach ($newList as $key => $value){
            $outStr.= '<section style="margin: 2em 0em; padding: 0.5em 0.8em; white-space: normal; border: 1px solid '.$colorArr[$color_i].';border-radius: 6px; font-size: 1em; font-family: inherit; font-weight: inherit; text-decoration: inherit; color: rgb(166, 166, 166); background-color: rgb(255, 255, 255);"> ';
               $outStr.= '<section style="margin-top: -1.4em; text-align: center; border: none; line-height: 1.4;"> ';
                  $outStr.= '<section style="padding-right: 24px; padding-left: 24px; color: '.$colorArr[$color_i].'; font-size: 30px; font-family: inherit; text-decoration: inherit; border-color: rgb(255, 255, 255); display: inline-block; background-color: rgb(254, 255, 255); "> ';
                     $outStr.= '<section>'.$value['name'].'</section> ';
                  $outStr.= '</section> ';
               $outStr.= '</section> ';
               $outStr.= '<section style="padding: 16px 0px; color: rgb(32, 32, 32); line-height: 2; font-family: inherit;"> ';
               foreach ($value['data'] as $kk => $vv){
                    $outStr.= '<p style="word-break:break-all;word-wrap:break-word;margin: 5px 0px;padding-bottom: 5px;"> ';
                        $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 1.5; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;"><span style="color: '.$colorArr[$color_i].';">'.lang('plugin/tom_tongcheng', 'doDao_jian').$vv['name'].'</span>'.$vv['content'].'<b style="color:#222">'.lang('plugin/tom_tongcheng', 'doDao_msg_lianxi_1').$vv['tel'].lang('plugin/tom_tongcheng', 'doDao_msg_lianxi_2').'</b></span> ';
                    $outStr.= '</p> ';
                    if(!empty($vv['qrcode'])){
                        $outStr.= '<span style="display: block;text-align: center;"><img style="width:120px;" src="'.$vv['qrcode'].'"/></span> ';
                        $outStr.= '<span style="display: block;text-align: center;color:#999;font-size: 12px;">'.lang('plugin/tom_tongcheng', 'doDao_qrcode_msg').'</span> ';
                    }
               }
               $outStr.= '</section>';
            $outStr.= '</section>';
            $color_i++;
            if($color_i == 6){
                $color_i = 1;
            }
        }
    }
    
    $doDao_msg3 = lang('plugin/tom_tongcheng', 'doDao_msg3');
    $doDao_msg3 = str_replace('{SITENAME}', $tongchengConfig['plugin_name'], $doDao_msg3);
    $outStr.= '<span style="color:#999;font-size: 14px;"><span style="color:red"> '.lang('plugin/tom_tongcheng', 'doDao_msg_mz').'</span><br /> '.$doDao_msg3.'</span><br /><br />';
    
    echo $outStr;
    exit;
}else{
    exit('Access Denied');
}