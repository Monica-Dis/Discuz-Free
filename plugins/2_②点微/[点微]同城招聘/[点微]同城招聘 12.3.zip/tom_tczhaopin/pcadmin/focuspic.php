<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=focuspic";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('focuspic_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $focuspic_id = intval($_GET['focuspic_id'])>0 ? intval($_GET['focuspic_id']):0;
    
    C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->delete_by_id($focuspic_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;
$site_id    = intval($_GET['site_id'])>0? intval($_GET['site_id']):0;
$type       = intval($_GET['type'])>0? intval($_GET['type']):0;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = "";
if($site_id > 0){
    $where .= " AND site_id={$site_id} ";
}
if($type > 0){
    $where .= " AND type={$type} ";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->fetch_all_count($where);
$focuspicListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$focuspicList = array();
if(!empty($focuspicListTmp)){
    foreach ($focuspicListTmp as $key => $value) {
        $focuspicList[$key] = $value;
        
        $focuspicList[$key]['picurlTmp']   = get_file_url($value['picurl']);
        $focuspicList[$key]['siteInfo']    = $sitesList[$value['site_id']];
        $focuspicList[$key]['add_time']    = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&type={$type}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/focuspic");