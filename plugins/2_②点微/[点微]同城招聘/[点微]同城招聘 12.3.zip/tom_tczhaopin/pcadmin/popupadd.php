<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=popupadd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('picurl')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $show_num       = isset($_GET['show_num'])? intval($_GET['show_num']):0;
    $link           = isset($_GET['link'])? addslashes($_GET['link']):'';
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $status         = isset($_GET['status'])? intval($_GET['status']):1;
    
    $siteIdsArr = array();
    if(is_array($_GET['sites']) && !empty($_GET['sites'])){
        foreach($_GET['sites'] as $key => $value){
            $value = intval($value);
            if($value > 0){
                $siteIdsArr[] = '['.$value.']';
            }
        }
    }
    $siteIdsStr = implode(',', $siteIdsArr);
    
    $insertData = array();
    $insertData['site_ids']     = $siteIdsStr;
    $insertData['show_num']     = $show_num;
    $insertData['link']         = $link;
    $insertData['picurl']       = $picurl;
    $insertData['status']       = $status;
    $insertData['add_time']     = TIMESTAMP;
    if(C::t('#tom_tczhaopin#tom_tczhaopin_popup')->insert($insertData)){
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/popupadd");