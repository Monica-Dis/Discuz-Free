<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$meeting_id = intval($_GET['meeting_id'])>0? intval($_GET['meeting_id']):0;

$meetingInfo = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_by_id($meeting_id);
if(empty($meetingInfo)){
    dheader('location:'.$pcadminUrl."&tmod=meeting");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=meeting_companylist&meeting_id={$meeting_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add_company' && submitcheck('meeting_id')){
    $outArr = array(
        'code'=> 1,
    );

    $company_id     = intval($_GET['company_id'])>0 ? intval($_GET['company_id']):0;
    $is_recommend   = intval($_GET['is_recommend'])>0 ? intval($_GET['is_recommend']):0;
    $csort          = intval($_GET['csort'])>0 ? intval($_GET['csort']):10;
    
    $tczhaopinIdsArr = array();
    if(is_array($_GET['tczhaopin_ids']) && !empty($_GET['tczhaopin_ids'])){
        foreach($_GET['tczhaopin_ids'] as $key => $value){
            if(!empty($value) && intval($value) > 0){
                $tczhaopinIdsArr[$key] = intval($value);
            }
        }
    }
    
    $tczhaopinIdsStr = '';
    $tczhaopinIdsNum = 0;
    if(is_array($tczhaopinIdsArr) && !empty($tczhaopinIdsArr)){
        $tczhaopinIdsStr = implode(',', $tczhaopinIdsArr);
        $tczhaopinIdsNum = count($tczhaopinIdsArr);
    }

    $companyInfo = C::t("#tom_tczhaopin#tom_tczhaopin_company")->fetch_by_id($company_id);
    if(is_array($companyInfo) && !empty($companyInfo)){}else{
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['meeting_companylist_add_company_error'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    
    $meetingCompanyInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_meeting_company")->fetch_all_list("AND meeting_id = {$meeting_id} AND company_id = {$company_id}","",0,1);
    if(is_array($meetingCompanyInfoTmp) && !empty($meetingCompanyInfoTmp)){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['meeting_companylist_add_company_error_1'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
  
    $insertData = array();
    $insertData['meeting_id']   = $meeting_id;
    $insertData['user_id']      = $companyInfo['user_id'];
    $insertData['company_id']   = $company_id;
    if($meetingInfo['zhaopin_list_type'] == 1){
        $insertData['tczhaopin_ids']    = $tczhaopinIdsStr;
        $insertData['tczhaopin_num']    = $tczhaopinIdsNum;
        if(!empty($tczhaopinIdsStr)){
            $insertData['status']       = 1;
        }else{
            $insertData['status']       = 0;
        }
    }else{
        $updateData['status']           = 1;
    }
    $insertData['csort']        = $csort;
    $insertData['add_time']     = TIMESTAMP;
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'edit_company' && submitcheck('meeting_company_id')){
    $outArr = array(
        'code'=> 1,
    );

    $meeting_company_id = intval($_GET['meeting_company_id'])>0 ? intval($_GET['meeting_company_id']):0;
    $is_recommend       = intval($_GET['is_recommend'])>0 ? intval($_GET['is_recommend']):0;
    $csort              = intval($_GET['csort'])>0 ? intval($_GET['csort']):10;

    $tczhaopinIdsArr = array();
    if(is_array($_GET['tczhaopin_ids']) && !empty($_GET['tczhaopin_ids'])){
        foreach($_GET['tczhaopin_ids'] as $key => $value){
            if(!empty($value) && intval($value) > 0){
                $tczhaopinIdsArr[$key] = intval($value);
            }
        }
    }

    $tczhaopinIdsStr = '';
    $tczhaopinIdsNum = 0;
    if(is_array($tczhaopinIdsArr) && !empty($tczhaopinIdsArr)){
        $tczhaopinIdsStr = implode(',', $tczhaopinIdsArr);
        $tczhaopinIdsNum = count($tczhaopinIdsArr);
    }

    $updateData = array();
    if($meetingInfo['zhaopin_list_type'] == 1){
        $updateData['tczhaopin_ids']    = $tczhaopinIdsStr;
        $updateData['tczhaopin_num']    = $tczhaopinIdsNum;
        if(!empty($tczhaopinIdsStr)){
            $updateData['status']       = 1;
        }else{
            $updateData['status']       = 0;
        }
    }else{
        $updateData['status']       = 1;
    }
    $updateData['is_recommend']     = $is_recommend;
    $updateData['csort']            = $csort;
    $updateData['part1']            = TIMESTAMP;
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->update($meeting_company_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'del' && submitcheck('meeting_company_id')){
    $outArr = array(
        'code'=> 1,
    );

    $meeting_company_id = intval($_GET['meeting_company_id'])>0 ? intval($_GET['meeting_company_id']):0;
    
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->delete_by_id($meeting_company_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'tczhaopin_list' && $_GET['formhash'] == FORMHASH ){
    $outArr = array(
        'code'=> 1,
    );
    
    $meeting_company_id  = intval($_GET['meeting_company_id'])>0 ? intval($_GET['meeting_company_id']):0;
    $company_id  = intval($_GET['company_id'])>0 ? intval($_GET['company_id']):0;
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($company_id);
    
    if($meeting_company_id > 0){
        $meetingCompanyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->fetch_by_id($meeting_company_id);
        $tczhaopinIdsArr = explode(',', $meetingCompanyInfo['tczhaopin_ids']);
    }
    
    if(is_array($companyInfo) && !empty($companyInfo)){
        $tczhaopinList = array();
        $tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list(" AND type = 1 AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND user_id = {$companyInfo['user_id']} ",'ORDER BY top_status DESC,refresh_time DESC,id DESC',0,100);
        if(!empty($tczhaopinListTmp)){
            foreach($tczhaopinListTmp as $key => $value){
                $tczhaopinList[$key] = $value;
                if($meeting_company_id > 0){
                    if(in_array($value['id'],$tczhaopinIdsArr)){
                        $tczhaopinList[$key]['status'] = 1;
                    }else{
                        $tczhaopinList[$key]['status'] = 0;
                    }
                }
            }
        }
        $tczhaopinList = iconv_to_utf8($tczhaopinList);
    }
    
    if($meeting_company_id > 0){
        $outArr = array(
            'code'  => 200,
            'tczhaopinList'  => $tczhaopinList,
        );
    }else{
        $count = count($tczhaopinList);
        $outArr = array(
            'code'  => 200,
            'count' => $count,
            'tczhaopinList'  => $tczhaopinList,
        );
    }
    
    echo json_encode($outArr); exit;
    
}

$page       = intval($_GET['page'])>0 ? intval($_GET['page']) :1;
$pagesize   = intval($_GET['pagesize'])>0 ? intval($_GET['pagesize']) :10;

$where = " AND meeting_id={$meeting_id} ";

$start = ($page-1)*$pagesize;

$count = C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->fetch_all_count($where);
$meetingCompanyListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->fetch_all_list($where," ORDER BY is_recommend DESC, csort ASC,id DESC ",$start,$pagesize);
$meetingCompanyList = array();
if(!empty($meetingCompanyListTmp)){
    foreach($meetingCompanyListTmp as $key => $value){
        $meetingCompanyList[$key] = $value;

        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $companyInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_company")->fetch_by_id($value['company_id']);
        $renzhengCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_id($companyInfoTmp['renzheng_company_id']);

        if(!empty($value['tczhaopin_ids'])){
            $tczhaopinListTmp = array();
            $tczhaopinListTmpTmp = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_list(" AND id IN({$value['tczhaopin_ids']}) AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ", 'ORDER BY top_status DESC,refresh_time DESC,id DESC', 0, 100);
            if(is_array($tczhaopinListTmpTmp) && !empty($tczhaopinListTmpTmp)){
                foreach($tczhaopinListTmpTmp as $k => $v){
                    $tczhaopinListTmp[$k] = $v;
                }
            }
            $meetingCompanyList[$key]['tczhaopinList'] = $tczhaopinListTmp;
        }
        $meetingCompanyList[$key]['userInfo']    = $userInfoTmp;
        $meetingCompanyList[$key]['companyInfo'] = $companyInfoTmp;
        $meetingCompanyList[$key]['renzhengCompanyInfo'] = $renzhengCompanyInfoTmp;

    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/meeting_companylist");