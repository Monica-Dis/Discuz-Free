<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=wxqun";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'hide' && submitcheck('wxqun_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $wxqun_id = intval($_GET['wxqun_id'])>0 ? intval($_GET['wxqun_id']):0;
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tczhaopin#tom_tczhaopin_wxqun')->update($wxqun_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('wxqun_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $wxqun_id = intval($_GET['wxqun_id'])>0 ? intval($_GET['wxqun_id']):0;
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin_wxqun')->update($wxqun_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('wxqun_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $wxqun_id = intval($_GET['wxqun_id'])>0 ? intval($_GET['wxqun_id']):0;
    
    C::t('#tom_tczhaopin#tom_tczhaopin_wxqun')->delete_by_id($wxqun_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = "";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tczhaopin#tom_tczhaopin_wxqun')->fetch_all_count($where);
$wxqunListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_wxqun')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$wxqunList = array();
if(!empty($wxqunListTmp)){
    foreach ($wxqunListTmp as $key => $value) {
        $wxqunList[$key] = $value;
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        
        $wxqunList[$key]['logoTmp']    = get_file_url($value['logo']);
        $wxqunList[$key]['qrcodeTmp']  = get_file_url($value['qrcode']);
        $wxqunList[$key]['siteInfo']   = $siteInfoTmp;
        $wxqunList[$key]['add_time']   = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/wxqun");