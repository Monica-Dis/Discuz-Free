<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$resume_id = intval($_GET['resume_id'])>0? intval($_GET['resume_id']):0;
$resumeInfo = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($resume_id);

if(empty($resumeInfo)){
    tomheader('location:'.$_G['siteurl']."{$pcadminUrl}&tmod=resume");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=resumeedit&resume_id={$resume_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($_GET['act'] == 'save' && submitcheck('resume_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name           = dhtmlspecialchars($name);
    $type           = isset($_GET['type'])? intval($_GET['type']):0;
    $cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $area_id        = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id      = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $work_jingyan   = isset($_GET['work_jingyan'])? intval($_GET['work_jingyan']):0;
    $work_salary    = isset($_GET['work_salary'])? intval($_GET['work_salary']):0;
    $sex            = isset($_GET['sex'])? intval($_GET['sex']):0;
    $marital        = isset($_GET['marital'])? intval($_GET['marital']):0;
    $birth_year     = isset($_GET['birth_year'])? intval($_GET['birth_year']):0;
    $xueli          = isset($_GET['xueli'])? intval($_GET['xueli']):0;
    $work_status    = isset($_GET['work_status'])? intval($_GET['work_status']):0;
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $gongkai_status = isset($_GET['gongkai_status'])? intval($_GET['gongkai_status']):0;
    $work_jingli    = isset($_GET['work_jingli'])? addslashes($_GET['work_jingli']):'';
    $work_jingli    = dhtmlspecialchars($work_jingli);
    $edu_jingli     = isset($_GET['edu_jingli'])? addslashes($_GET['edu_jingli']):'';
    $edu_jingli     = dhtmlspecialchars($edu_jingli);
    $describe       = isset($_GET['describe'])? addslashes($_GET['describe']):'';
    $describe       = dhtmlspecialchars($describe);
    $avatar         = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $avatar         = dhtmlspecialchars($avatar);
    $video_url      = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_pic      = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic      = dhtmlspecialchars($video_pic);
    
    $cateChildIdsArr = array();
    if(is_array($_GET['cate_child_ids']) && !empty($_GET['cate_child_ids'])){
        foreach($_GET['cate_child_ids'] as $key => $value){
            $cateChildIdsArr[] = intval($value);
        }
    }
    
    $cate_child_ids = $cate_child_str = $cate_child_search = '';
    if(is_array($cateChildIdsArr) && !empty($cateChildIdsArr)){
        $cateChildIdsStr = implode(',', $cateChildIdsArr);
        $cate_child_search = '-'.implode('-', $cateChildIdsArr).'-';
        $cateChildList = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_all_list(" AND pid = {$cate_id} AND id IN({$cateChildIdsStr}) ", 'ORDER BY csort ASC,id DESC ', 0, 1000);
        $cateChildNameArr = array();
        if(is_array($cateChildList) && !empty($cateChildList)){
            $cate_child_ids = $cateChildIdsStr;
            foreach($cateChildList as $key => $value){
                $cateChildNameArr[] = $value['name'];
            }
        }
        $cate_child_str = implode(',', $cateChildNameArr);
    }
    
    $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_id);
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $city_id = $__SitesInfo['city_id'];
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $city_id = $tongchengConfig['city_id'];
        }
    }
    
    $search_text = $cateInfo['name'].'-'.$cate_child_str.'-'.$name.'-'.$work_jingli;
    
    $updateData = array();
    $updateData['site_id']            = $site_id;
    $updateData['user_id']            = $user_id;
    $updateData['name']               = $name;
    $updateData['type']               = $type;
    $updateData['avatar']             = $avatar;
    $updateData['cate_id']            = $cate_id;
    $updateData['cate_child_ids']     = $cate_child_ids;
    $updateData['cate_child_str']     = $cate_child_str;
    $updateData['cate_child_search']  = $cate_child_search;
    $updateData['city_id']            = $city_id;
    $updateData['area_id']            = $area_id;
    $updateData['street_id']          = $street_id;
    $updateData['work_jingyan']       = $work_jingyan;
    $updateData['work_salary']        = $work_salary;
    $updateData['sex']                = $sex;
    $updateData['marital']            = $marital;
    $updateData['birth_year']         = $birth_year;
    $updateData['xueli']              = $xueli;
    $updateData['work_status']        = $work_status;
    $updateData['tel']                = $tel;
    $updateData['gongkai_status']     = $gongkai_status;
    $updateData['work_jingli']        = $work_jingli;
    $updateData['edu_jingli']         = $edu_jingli;
    $updateData['describe']           = $describe;
    if(!empty($video_url)){
        $updateData['video_status']         = 1;
        $updateData['video_url']            = $video_url;
        $updateData['video_pic']            = $video_pic;
    }
    $updateData['search_text']        = $search_text;
    $updateData['shenhe_status']    = 1;
    $updateData['refresh_time']     = TIMESTAMP;
    C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resume_id,$updateData);
    if($resume_id > 0){
        
        update_resume_tongcheng($resume_id);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    } 
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(""," ORDER BY paixu ASC,id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,5000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$avatar    = get_file_url($resumeInfo['avatar']);
$video_pic = get_file_url($resumeInfo['video_pic']);

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($resumeInfo['city_id']);
$areaList = array();
if(!empty($areaListTmp)){
    foreach ($areaListTmp as $key => $value){
        $areaList[$value['id']] = $value;
    }
}

$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($resumeInfo['area_id']);
$streetList = array();
if(!empty($streetListTmp)){
    foreach ($streetListTmp as $key => $value){
        $streetList[$value['id']] = $value;
    }
}

$nowYear = dgmdate(TIMESTAMP,"Y",$tomSysOffset);
$birthYearArr = array();
$maxBirthYear = $nowYear - 60;
$minBirthYear = $nowYear - 18;
for($maxBirthYear; $maxBirthYear <= $minBirthYear; $maxBirthYear++){
    $birthYearArr[$maxBirthYear] = $maxBirthYear;
}

$cateChildIdsArr = explode(',', $resumeInfo['cate_child_ids']);
$cateChildLists = array();
if($resumeInfo['cate_id'] > 0){
    $cateChildLists = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list("  AND pid = {$resumeInfo['cate_id']}  "," ORDER BY csort ASC,id DESC ",0,200);
    foreach($cateChildLists as $key => $value){
        if(in_array($value['id'], $cateChildIdsArr)){
            $cateChildLists[$key]['status'] = 1;
        }else{
            $cateChildLists[$key]['status'] = 0;
        }
    }
}

$editUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/resumeedit");