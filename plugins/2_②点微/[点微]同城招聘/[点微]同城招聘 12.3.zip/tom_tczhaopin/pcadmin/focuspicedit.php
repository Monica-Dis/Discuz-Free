<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$focuspic_id = intval($_GET['focuspic_id'])>0 ? intval($_GET['focuspic_id']):0;
$focuspicInfo = C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->fetch_by_id($focuspic_id);
if(empty($focuspicInfo)){
    dheader('location:'.$pcadminUrl."&tmod=focuspic");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=focuspicedit&focuspic_id={$focuspic_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $type           = isset($_GET['type'])? intval($_GET['type']):1;
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title          = dhtmlspecialchars($title);
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $link           = isset($_GET['link'])? addslashes($_GET['link']):'';
    $fsort          = isset($_GET['fsort'])? intval($_GET['fsort']):10;
    
    $updateData = array();
    $updateData['site_id']      = $site_id;
    $updateData['type']         = $type;
    $updateData['title']        = $title;
    $updateData['picurl']       = $picurl;
    $updateData['link']         = $link;
    $updateData['fsort']        = $fsort;
    if(C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->update($focuspic_id, $updateData)){
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$picurl = get_file_url($focuspicInfo['picurl']);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/focuspicedit");