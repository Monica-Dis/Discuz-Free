<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=shenqing";

$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):'';
$tczhaopin_id       = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):'';
$resume_id          = intval($_GET['resume_id'])>0? intval($_GET['resume_id']):'';
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = " AND z.shenhe_status = 1 AND r.shenhe_status = 1 ";

if($user_id > 0){
    $where .= " AND z.user_id = {$user_id} ";
}
if($tczhaopin_id > 0){
    $where .= "  AND t.tczhaopin_id = {$tczhaopin_id} ";
}
if($resume_id > 0){
    $where .= "  AND t.resume_id = {$resume_id} ";
}

$order = " ORDER BY t.add_time DESC,t.id DESC ";

$start        = ($page - 1)*$pagesize;
$count        = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_count($where);
$logListTmp   = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_list($where,$order,$start,$pagesize);
$logList = array();
if(!empty($logListTmp)){
    foreach ($logListTmp as $key => $value) {
        $logList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $tczhaopinInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($value['tczhaopin_id']);
        $resumeInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($value['resume_id']);

        $logList[$key]['userInfo']      = $userInfoTmp;
        $logList[$key]['tczhaopinInfo'] = $tczhaopinInfoTmp;
        $logList[$key]['resumeInfo']    = $resumeInfoTmp;
        $logList[$key]['add_time']      = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&tczhaopin_id={$tczhaopin_id}&resume_id={$resume_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/shenqing");