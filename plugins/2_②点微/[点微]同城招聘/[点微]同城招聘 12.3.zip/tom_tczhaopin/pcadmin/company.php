<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=company";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'edittop' && submitcheck('company_id')){
    $outArr = array(
        'code'=> 1,
    );

    $company_id      = intval($_GET['company_id'])>0 ? intval($_GET['company_id']):0;
    $top_time        = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
    $top_time        = strtotime($top_time);
        
    $updateData = array();
    if($top_time <= TIMESTAMP){
        $updateData['top_status']   = 0;
        $updateData['top_time']     = 0;
    }else{
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
    }
    
    C::t('#tom_tczhaopin#tom_tczhaopin_company')->update($company_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'edit_company' && submitcheck('company_id')){
    $outArr = array(
        'code'=> 1,
    );

    $company_id     = intval($_GET['company_id'])>0 ? intval($_GET['company_id']):0;
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $tuijian_status = isset($_GET['tuijian_status'])? intval($_GET['tuijian_status']):0;
    $csort          = isset($_GET['csort'])? intval($_GET['csort']):100;
       
    $updateData = array();
    $updateData['site_id']         = $site_id;
    $updateData['tuijian_status']  = $tuijian_status;
    $updateData['csort']           = $csort;
    
    if(C::t('#tom_tczhaopin#tom_tczhaopin_company')->update($company_id,$updateData)){
        $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($company_id);
        update_company_status($companyInfo);
    }
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'edituser' && submitcheck('company_id')){
    $outArr = array(
        'code'=> 1,
    );

    $company_id     = intval($_GET['company_id'])>0 ? intval($_GET['company_id']):0;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($company_id);
    
    if($companyInfo['user_id'] == $user_id){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['company_edituser_error1'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    if($userInfo && $userInfo['id'] > 0){}else{
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['company_edituser_error2'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    $isHaveCompany = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($user_id);
    if($isHaveCompany && $isHaveCompany['id'] > 0 && $isHaveCompany['renzheng_company_id'] > 0){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['company_edituser_error3'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }else{
        if($isHaveCompany && $isHaveCompany['id'] > 0){
            C::t('#tom_tczhaopin#tom_tczhaopin_company')->delete_by_id($isHaveCompany['id']);
        }
    }
    $renzhengCompanyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($user_id);
    if($renzhengCompanyInfo && $renzhengCompanyInfo['id'] > 0 && $renzhengCompanyInfo['shenhe_status'] == 1){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['company_edituser_error4'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }else{
        if($renzhengCompanyInfo && $renzhengCompanyInfo['id'] > 0){
            C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->delete_by_id($renzhengCompanyInfo['id']);
            C::t('#tom_tcrenzheng#tom_tcrenzheng_company_photo')->delete_by_company_id($renzhengCompanyInfo['id']);
        }
    }

    DB::query("UPDATE ".DB::table('tom_tcrenzheng_company')." SET user_id={$user_id} WHERE user_id='{$companyInfo['user_id']}'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tczhaopin')." SET user_id={$user_id} WHERE user_id='{$companyInfo['user_id']}'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tczhaopin_company')." SET user_id={$user_id} WHERE user_id='{$companyInfo['user_id']}'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tczhaopin_history')." SET user_id={$user_id} WHERE user_id='{$companyInfo['user_id']}'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tczhaopin_log')." SET user_id={$user_id} WHERE user_id='{$companyInfo['user_id']}'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tczhaopin_order')." SET user_id={$user_id} WHERE user_id='{$companyInfo['user_id']}'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tczhaopin_rencai')." SET user_id={$user_id} WHERE user_id='{$companyInfo['user_id']}'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tczhaopin_meeting_company')." SET user_id={$user_id} WHERE user_id='{$companyInfo['user_id']}'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tczhaopin_mianshi')." SET yaoqing_user_id={$user_id} WHERE yaoqing_user_id='{$companyInfo['user_id']}'", 'UNBUFFERED');

    $userVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($user_id);
    if($userVipInfo && $userVipInfo['id'] > 0 && $userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
    }else{
        if($userVipInfo && $userVipInfo['id'] > 0){
            C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->delete_by_id($userVipInfo['id']);
        }
        DB::query("UPDATE ".DB::table('tom_tczhaopin_user_vip')." SET user_id={$user_id} WHERE user_id='{$companyInfo['user_id']}'", 'UNBUFFERED');
    }
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}

$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$company_name       = isset($_GET['company_name'])? addslashes($_GET['company_name']):'';
$show_status        = isset($_GET['show_status'])? intval($_GET['show_status']):0;
$tuijian_status     = isset($_GET['tuijian_status'])? intval($_GET['tuijian_status']):0;
$top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$whereStr = "AND renzheng_company_id > 0";
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}

if($top_status > 0){
    if($top_status == 1){
        $whereStr.= " AND top_status = 1 ";
    }else if($top_status == 2){
        $whereStr.= " AND top_status = 0 ";
    }
}
if($show_status > 0){
    if($show_status == 1){
        $whereStr.= " AND show_status = 1 ";
    }else if($show_status == 2){
        $whereStr.= " AND show_status = 0 ";
    }
}
if($tuijian_status > 0){
    if($tuijian_status == 1){
        $whereStr.= " AND tuijian_status = 1 ";
    }else if($tuijian_status == 2){
        $whereStr.= " AND tuijian_status = 0 ";
    }
}
if($top_status > 0){
    if($top_status == 1){
        $whereStr.= " AND top_status = 1 ";
    }else if($top_status == 2){
        $whereStr.= " AND top_status = 0 ";
    }
}

if(!empty($company_name)){
    $companyListTmpTmp  = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_list("","ORDER BY id DESC",0,100,$company_name);
    $companyListIds = array();
    if(is_array($companyListTmpTmp) && !empty($companyListTmpTmp)){
        foreach ($companyListTmpTmp as $key => $value){
            $companyListIds[] = $value['id'];
        }
        $whereStr.= " AND renzheng_company_id IN (".  implode(',', $companyListIds).") ";
    }else{
        $whereStr.= " AND renzheng_company_id = 99999999999 ";
    }
}

$order = " ORDER BY csort ASC,id DESC ";

$start           = ($page - 1)*$pagesize;
$count           = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_all_count($whereStr);
$companyListTmp  = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_all_list($whereStr,$order,$start,$pagesize);
$companyList = array();
if(!empty($companyListTmp)){
    foreach ($companyListTmp as $key => $value) {
        $companyList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        $renzhengCompanyInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($value['renzheng_company_id']);
        $siteInfoTmp = $sitesList[$value['site_id']];
        
        $companyList[$key]['userInfo']              = $userInfoTmp;
        $companyList[$key]['renzhengCompanyInfo']   = $renzhengCompanyInfoTmp;
        $companyList[$key]['siteInfo']              = $siteInfoTmp;
        $companyList[$key]['top_time']              = dgmdate($value['top_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&site_id={$site_id}&show_status={$show_status}&top_status={$top_status}&tuijian_status={$tuijian_status}&company_name={$company_name}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/company");