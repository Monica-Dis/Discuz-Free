<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=meeting";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'hide' && submitcheck('meeting_id')){
    $outArr = array(
        'code'=> 1,
    );

    $meeting_id = intval($_GET['meeting_id'])>0 ? intval($_GET['meeting_id']):0;

    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->update($meeting_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('meeting_id')){
    $outArr = array(
        'code'=> 1,
    );

    $meeting_id = intval($_GET['meeting_id'])>0 ? intval($_GET['meeting_id']):0;

    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->update($meeting_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('meeting_id')){
    $outArr = array(
        'code'=> 1,
    );

    $meeting_id = intval($_GET['meeting_id'])>0 ? intval($_GET['meeting_id']):0;

    C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->delete_by_id($meeting_id);
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting_company')->delete_by_meeting_id($meeting_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$whereStr = '';
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}

$order = "ORDER BY id DESC";

$start           = ($page - 1)*$pagesize;
$count           = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_all_count($whereStr);
$meetingListTmp  = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_all_list($whereStr,$order,$start,$pagesize);
$meetingList = array();
if(!empty($meetingListTmp)){
    foreach ($meetingListTmp as $key => $value) {
        $meetingList[$key] = $value;
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        
        $meetingList[$key]['picurl']         = get_file_url($value['picurl']);
        $meetingList[$key]['siteInfo']       = $siteInfoTmp;
        $meetingList[$key]['start_time']     = dgmdate($value['start_time'],"Y-m-d H:i",$tomSysOffset);
        $meetingList[$key]['end_time']       = dgmdate($value['end_time'],"Y-m-d H:i",$tomSysOffset);
        $meetingList[$key]['bmend_time']     = dgmdate($value['bmend_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/meeting");