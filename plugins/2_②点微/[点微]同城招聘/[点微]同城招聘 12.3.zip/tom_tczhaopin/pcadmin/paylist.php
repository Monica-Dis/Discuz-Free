<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$uservip_id = intval($_GET['uservip_id'])>0? intval($_GET['uservip_id']):0;

$uservipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_id($uservip_id);

$modPcadminUrl = $pcadminUrl."&tmod=paylist&uservip_id={$uservip_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'list' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $page       = intval($_GET['page'])>0 ? intval($_GET['page']) :1;
    $pagesize   = intval($_GET['pagesize'])>0 ? intval($_GET['pagesize']) :10;
    
    $where = " AND user_id = {$uservipInfo['user_id']} AND type = 6 AND order_status = 2  ";
    
    $start = ($page-1)*$pagesize;
    
    $count = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_all_count($where);
    $orderListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_order')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    $orderList = array();
    if(!empty($orderListTmp)){
        foreach($orderListTmp as $key => $value){
            $orderList[$key] = $value;
            
            $vipInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_by_id($value['vip_id']);
            
            $orderList[$key]['vipInfo'] = $vipInfoTmp;
            $orderList[$key]['order_time'] = dgmdate($value['order_time'],"Y-m-d H:i",$tomSysOffset);
        }
    }

    $list = iconv_to_utf8($orderList);
    
    $outArr = array(
        'code'  => 0,
        'msg'   => '',
        'count' => $count,
        'data'  => $list,
    );
    echo json_encode($outArr); exit;
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/paylist");