<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=popup";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'hide' && submitcheck('popup_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $popup_id = intval($_GET['popup_id'])>0 ? intval($_GET['popup_id']):0; 
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tczhaopin#tom_tczhaopin_popup')->update($popup_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('popup_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $popup_id = intval($_GET['popup_id'])>0 ? intval($_GET['popup_id']):0; 
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin_popup')->update($popup_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('popup_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $popup_id = intval($_GET['popup_id'])>0 ? intval($_GET['popup_id']):0; 
    
    C::t('#tom_tczhaopin#tom_tczhaopin_popup')->delete_by_id($popup_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = "";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tczhaopin#tom_tczhaopin_popup')->fetch_all_count($where);
$popupListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_popup')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$popupList = array();
if(!empty($popupListTmp)){
    foreach ($popupListTmp as $key => $value) {
        $popupList[$key] = $value;
        
        $popupList[$key]['picurlTmp']   = get_file_url($value['picurl']);
        $popupList[$key]['add_time']    = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/popup");