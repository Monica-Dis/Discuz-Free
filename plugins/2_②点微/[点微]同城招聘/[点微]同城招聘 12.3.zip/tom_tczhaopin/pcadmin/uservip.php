<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=uservip";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add_uservip' && submitcheck('vip_id')){
    $outArr = array(
        'code'=> 1,
    );

    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $vip_id         = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $expire_status  = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
    $expire_time    = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time    = strtotime($expire_time);
       
    $insertData = array();
    $insertData['user_id']         = $user_id;
    $insertData['vip_id']          = $vip_id;
    $insertData['expire_status']   = $expire_status;
    $insertData['expire_time']     = $expire_time;
    
    C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'edit_uservip' && submitcheck('uservip_id')){
    $outArr = array(
        'code'=> 1,
    );

    $uservip_id     = intval($_GET['uservip_id'])>0 ? intval($_GET['uservip_id']):0;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $vip_id         = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $expire_status  = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
    $expire_time    = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time    = strtotime($expire_time);
       
    $updateData = array();
    $updateData['user_id']         = $user_id;
    $updateData['vip_id']          = $vip_id;
    $updateData['expire_status']   = $expire_status;
    $updateData['expire_time']     = $expire_time;
    
    C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->update($uservip_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'del' && submitcheck('uservip_id')){
    $outArr = array(
        'code'=> 1,
    );

    $uservip_id = intval($_GET['uservip_id'])>0 ? intval($_GET['uservip_id']):0;
    
    $uservipInfo = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_by_id($uservip_id);

    C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->delete_by_id($uservip_id);
    C::t("#tom_tczhaopin#tom_tczhaopin_log")->delete_vip_look_resume_by_user_id($uservipInfo['user_id']);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = '';

if($user_id > 0){
    $whereStr.= " AND user_id={$user_id} ";
}

$order = " ORDER BY id DESC";

$start           = ($page - 1)*$pagesize;
$count           = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_all_count($whereStr);
$uservipListTmp  = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_all_list($whereStr,$order,$start,$pagesize);
$uservipList = array();
if(!empty($uservipListTmp)){
    foreach ($uservipListTmp as $key => $value) {
        $uservipList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $vipInfoTmp  = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_by_id($value['vip_id']);
        $uservipList[$key]['userInfo']             = $userInfoTmp;
        $uservipList[$key]['vipInfo']              = $vipInfoTmp;
        $uservipList[$key]['expire_time']          = dgmdate($value['expire_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$vipListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_all_list(" "," ORDER BY tsort ASC,id DESC ",0,100);
$vipList = array();
if(!empty($vipListTmp)){
    foreach ($vipListTmp as $key => $value) {
        $vipList[$key] = $value;
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/uservip");