<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$meeting_id = intval($_GET['meeting_id'])>0? intval($_GET['meeting_id']):0;
$meetingInfo = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_by_id($meeting_id);

if(empty($meetingInfo)){
    tomheader('location:'.$_G['siteurl']."{$pcadminUrl}&tmod=meeting");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=meetingedit&meeting_id={$meeting_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($_GET['act'] == 'save' && submitcheck('meeting_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title          = dhtmlspecialchars($title);
    $type           = isset($_GET['type'])? intval($_GET['type']):1;
    $open_pay       = isset($_GET['open_pay'])? intval($_GET['open_pay']):0;
    $pay_price      = isset($_GET['pay_price'])? floatval($_GET['pay_price']):0;
    $theme_color    = isset($_GET['theme_color'])? addslashes($_GET['theme_color']):'';
    $max_num        = isset($_GET['max_num'])? intval($_GET['max_num']):0;
    $organizer      = isset($_GET['organizer'])? addslashes($_GET['organizer']):'';
    $address        = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address        = dhtmlspecialchars($address);
    $lng            = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat            = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $qrcode_location = isset($_GET['qrcode_location'])? intval($_GET['qrcode_location']):1;
    $canhui_txt     = isset($_GET['canhui_txt'])? addslashes($_GET['canhui_txt']):'';
    $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
    $start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time     = strtotime($start_time);
    $end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time       = strtotime($end_time);
    $bmend_time     = isset($_GET['bmend_time'])? addslashes($_GET['bmend_time']):'';
    $bmend_time     = strtotime($bmend_time);
    $share_title    = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc     = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $virtual_clicks = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $open_search    = isset($_GET['open_search'])? intval($_GET['open_search']):0;
    $list_template  = isset($_GET['list_template'])? intval($_GET['list_template']):1;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $msort          = isset($_GET['msort'])? intval($_GET['msort']):10;
    $zhaopin_list_type       = isset($_GET['zhaopin_list_type'])? intval($_GET['zhaopin_list_type']):1;
    $picurl                  = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $picurl                  = dhtmlspecialchars($picurl);
    $theme_picurl            = isset($_GET['theme_picurl'])? addslashes($_GET['theme_picurl']):'';
    $theme_picurl            = dhtmlspecialchars($theme_picurl);
    $haibao_picurl           = isset($_GET['haibao_picurl'])? addslashes($_GET['haibao_picurl']):'';
    $haibao_picurl           = dhtmlspecialchars($haibao_picurl);
    
    $updateData = array();
    $updateData['site_id']        = $site_id;
    $updateData['title']          = $title;
    $updateData['type']           = $type;
    $updateData['open_pay']       = $open_pay;
    $updateData['pay_price']      = $pay_price;
    $updateData['zhaopin_list_type']   = $zhaopin_list_type;
    $updateData['theme_color']    = $theme_color;
    $updateData['max_num']        = $max_num;
    $updateData['organizer']      = $organizer;
    $updateData['address']        = $address;
    $updateData['latitude']       = $lat;
    $updateData['longitude']      = $lng;
    $updateData['qrcode_location'] = $qrcode_location;
    $updateData['haibao_picurl']  = $haibao_picurl;
    $updateData['canhui_txt']     = $canhui_txt;
    $updateData['content']        = $content;
    $updateData['start_time']     = $start_time;
    $updateData['end_time']       = $end_time;
    $updateData['bmend_time']     = $bmend_time;
    $updateData['share_title']    = $share_title;
    $updateData['share_desc']     = $share_desc;
    $updateData['virtual_clicks'] = $virtual_clicks;
    $updateData['open_search']    = $open_search;
    $updateData['list_template']  = $list_template;
    $updateData['status']         = $status;
    $updateData['msort']          = $msort;
    $updateData['picurl']         = $picurl;
    $updateData['theme_picurl']   = $theme_picurl;
    $updateData['part1']          = TIMESTAMP;
    C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->update($meeting_id,$updateData);
    if($meeting_id > 0){
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    } 
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(""," ORDER BY paixu ASC,id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$picurl        = get_file_url($meetingInfo['picurl']);
$haibao_picurl = get_file_url($meetingInfo['haibao_picurl']);
$theme_picurl  = get_file_url($meetingInfo['theme_picurl']);

$meetingInfo['content']    = stripcslashes($meetingInfo['content']);
$meetingInfo['canhui_txt'] = stripcslashes($meetingInfo['canhui_txt']);

$start_time = dgmdate($meetingInfo['start_time'],"Y-m-d H:i",$tomSysOffset);
$end_time   = dgmdate($meetingInfo['end_time'],"Y-m-d H:i",$tomSysOffset);
$bmend_time = dgmdate($meetingInfo['bmend_time'],"Y-m-d H:i",$tomSysOffset);

$editUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/meetingedit");