<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tczhaopin_id = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):0;
$tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);

if(empty($tczhaopinInfo)){
    tomheader('location:'.$_G['siteurl']."{$pcadminUrl}&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=edit&tczhaopin_id={$tczhaopin_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($_GET['act'] == 'save' && submitcheck('tczhaopin_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
        
    $user_id                    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $site_id                    = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $title                      = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title                      = dhtmlspecialchars($title);
    $type                       = isset($_GET['type'])? intval($_GET['type']):0;
    $cate_id                    = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id              = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $jianzhi_cate_id            = isset($_GET['jianzhi_cate_id'])? intval($_GET['jianzhi_cate_id']):0;
    $work_salary                = isset($_GET['work_salary'])? intval($_GET['work_salary']):0;
    $work_salary_min            = intval($_GET['work_salary_min'])>0? intval($_GET['work_salary_min']):0;
    $work_salary_max            = intval($_GET['work_salary_max'])>0? intval($_GET['work_salary_max']):0;
    $jianzhi_work_salary        = isset($_GET['jianzhi_work_salary'])? intval($_GET['jianzhi_work_salary']):0;
    $jianzhi_work_salary_unit   = isset($_GET['jianzhi_work_salary_unit'])? intval($_GET['jianzhi_work_salary_unit']):0;
    $jianzhi_jiesuan_fangshi    = isset($_GET['jianzhi_jiesuan_fangshi'])? intval($_GET['jianzhi_jiesuan_fangshi']):0;
    $renshu                     = isset($_GET['renshu'])? intval($_GET['renshu']):0;
    $demand_sex                 = isset($_GET['demand_sex'])? intval($_GET['demand_sex']):0;
    $demand_ages                = isset($_GET['demand_ages'])? intval($_GET['demand_ages']):0;
    $demand_xueli               = isset($_GET['demand_xueli'])? intval($_GET['demand_xueli']):0;
    $demand_jingyan             = isset($_GET['demand_jingyan'])? intval($_GET['demand_jingyan']):0;
    $demand_desc                = isset($_GET['demand_desc'])? addslashes($_GET['demand_desc']):'';
    $demand_desc                = dhtmlspecialchars($demand_desc);
    $area_id                    = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id                  = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $lng                        = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                        = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address                    = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address                    = dhtmlspecialchars($address);
    $xm                         = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $company_name               = isset($_GET['company_name'])? addslashes($_GET['company_name']):'';
    $video_url                  = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_pic                  = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic                  = dhtmlspecialchars($video_pic);
    $expire_status              = intval($_GET['expire_status'])>0? intval($_GET['expire_status']):1;
    $expire_time                = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time                = strtotime($expire_time);
    
    $old_user_id = $tczhaopinInfo['user_id'];
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photosort_") !== false){
            $kk = intval(ltrim($key, "photosort_"));
            $photoArr[$kk]['sort'] = addslashes($value);
        }
    }
   
    $workWelfareArr = array();
    if(is_array($_GET['work_welfare']) && !empty($_GET['work_welfare'])){
        foreach($_GET['work_welfare'] as $key => $value){
            $workWelfareArr[] = intval($value);
        }
    }
    $work_welfare = '-'.implode('-', $workWelfareArr).'-';
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$user_id} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    $companyRenzhengStatus = 0;
    $rzCompanyInfo = array();
    if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
        $companyRenzhengStatus = 1;
        $rzCompanyInfo = $rzCompanyInfoTmp[0];
    }
    
    if($companyRenzhengStatus == 1){
        $company_name = $rzCompanyInfo['name'];
    }

    $search_text = '';
    if($type == 1){
        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_id);
        $cateChildInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_child_id);
        $search_text = $title.'-'.$cateInfo['name'].'-'.$cateChildInfo['name'].'-'.$company_name;
    }else if($type == 2){
        $jianzhiCateInfo =  C::t("#tom_tczhaopin#tom_tczhaopin_jianzhi_cate")->fetch_by_id($jianzhi_cate_id);
        $search_text = $title.'-'.$jianzhiCateInfo['name'].'-'.$company_name;
    }
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($user_id);
    if(is_array($companyInfo) && !empty($companyInfo)){ 
        update_company_status($companyInfo);
    }else{
        $insertData = array();
        $insertData['site_id']              = $site_id;
        $insertData['user_id']              = $user_id;
        $insertData['add_time']             = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_company')->insert($insertData)){
            $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($user_id);
            update_company_status($companyInfo);
        }
    }
    
    $updateData = array();
    $updateData['site_id']            = $site_id;
    $updateData['user_id']            = $user_id;
    $updateData['company_id']         = $companyInfo['id'];
    $updateData['title']              = $title;
    $updateData['type']               = $type;
    if($type == 1){
        $updateData['cate_id']            = $cate_id;
        $updateData['cate_child_id']      = $cate_child_id;
    }else if($type == 2){
        $updateData['jianzhi_cate_id']    = $jianzhi_cate_id;
    }
    if($type == 1){
        $updateData['work_salary']          = $work_salary;
        $updateData['work_salary_min']      = $work_salary_min;
        $updateData['work_salary_max']      = $work_salary_max;
        $updateData['work_welfare']         = $work_welfare;
    }else if($type == 2){
        $updateData['jianzhi_work_salary']       = $jianzhi_work_salary;
        $updateData['jianzhi_work_salary_unit']  = $jianzhi_work_salary_unit;
        $updateData['jianzhi_jiesuan_fangshi']   = $jianzhi_jiesuan_fangshi;
    }
    $updateData['renshu']             = $renshu;
    $updateData['demand_sex']         = $demand_sex;
    $updateData['demand_ages']        = $demand_ages;
    $updateData['demand_xueli']       = $demand_xueli;
    $updateData['demand_jingyan']     = $demand_jingyan;
    $updateData['demand_desc']        = $demand_desc;
    $updateData['city_id']            = $city_id;
    $updateData['area_id']            = $area_id;
    $updateData['street_id']          = $street_id;
    $updateData['address']            = $address;
    $updateData['latitude']           = $lat;
    $updateData['longitude']          = $lng;
    $updateData['xm']                 = $xm;
    $updateData['tel']                = $tel;
    if($companyRenzhengStatus == 1){
        $updateData['company_name']            = $rzCompanyInfo['name'];
        $updateData['company_nature_id']       = $rzCompanyInfo['nature_id'];
        $updateData['company_industry_id']     = $rzCompanyInfo['industry_id'];
        $updateData['company_scale_id']        = $rzCompanyInfo['scale_id'];
    }else{
        $updateData['company_name']            = $company_name;
    }
    if(!empty($video_url)){
        $updateData['video_status']       = 1;
    }else{
        $updateData['video_status']       = 0;
    }
    $updateData['video_url']          = $video_url;
    $updateData['video_pic']          = $video_pic;
    $updateData['search_text']        = $search_text;
    
    if($old_user_id != $user_id ){
        if($expire_status == 3){
            $updateData['expire_status']  = $expire_status;
        }else{
            if($expire_time < TIMESTAMP){
                $updateData['expire_status']    = 2;
                $updateData['expire_time']      = 0;
            }else{
                $updateData['expire_status']    = 1;
                $updateData['expire_time']      = $expire_time;
            }
        }
    }
    
    C::t('#tom_tczhaopin#tom_tczhaopin')->update($tczhaopin_id,$updateData);
    if($tczhaopin_id > 0){
        C::t("#tom_tczhaopin#tom_tczhaopin_photo")->delete_by_tczhaopin_id($tczhaopin_id);
        
        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['tczhaopin_id'] = $tczhaopin_id;
                $insertData['picurl']       = $value['picurl'];
                $insertData['psort']        = $value['sort'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tczhaopin#tom_tczhaopin_photo')->insert($insertData);
            }
        }
        update_company_status($companyInfo);
        update_zhaopin_tongcheng($tczhaopin_id);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    } 
}else if($act == 'check_user_id' && $_GET['formhash'] == FORMHASH ){
    $outArr = array(
        'code'=> 1,
    );
    
    $user_id = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    
    $uservipInfo   = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_by_user_id($user_id);
    $vipInfo       = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_by_id($uservipInfo['vip_id']);

    $vip_status = 0;
    if($vipInfo && $vipInfo['id'] > 0){
        $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$user_id} AND expire_status = 3");
        if($uservipInfo['vip_id'] > 0 && $uservipInfo['expire_time'] > TIMESTAMP && $uservipInfo['expire_status'] == 1 && $vipInfo['fabu_num'] > $userVipLogCount){
            $vip_status = 1;
        }
    }
    
    $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$user_id} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    
    $companyRenzhengStatus = 0;
    if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
        $companyRenzhengStatus = 1;
    }
    $company_name = $rzCompanyInfoTmp[0]['name'];
    $company_name = iconv_to_utf8($company_name);

    $outArr = array(
        'code'  => 200,
        'vip_status'  => $vip_status,
        'companyRenzhengStatus'  => $companyRenzhengStatus,
        'company_name'    => $company_name,
    );
    
    echo json_encode($outArr); exit;
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(""," ORDER BY paixu ASC,id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$jianzhiCateList = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,5000);

$cateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,5000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$workWelfareArr = explode('-', '-'.$tczhaopinInfo['work_welfare'].'-');
$checkedWelfareList = array();
if(is_array($welfareArray) && !empty($welfareArray)){
    foreach($welfareArray as $key => $value){
        $checkedWelfareList[$key]['name'] = $value;
        if(in_array($key,$workWelfareArr)){
            $checkedWelfareList[$key]['status'] = 1;
        }else{
            $checkedWelfareList[$key]['status'] = 0;
        }
    }
}

$rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$tczhaopinInfo['user_id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
$companyRenzhengStatus = 0;
if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
    $companyRenzhengStatus = 1;
    $company_name = $rzCompanyInfoTmp[0]['name'];
}else{
    $company_name = $tczhaopinInfo['company_name'];
}

$video_pic = get_file_url($tczhaopinInfo['video_pic']);

$photoListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_photo')->fetch_all_list(" AND tczhaopin_id={$tczhaopin_id} ", 'ORDER BY psort ASC,id ASC',0, 100);
$photoList = array();
$i = 1;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $photoList[$key] = $value;
        
        $photoList[$key]['pic_url'] = $value['picurlTmp'];
        $photoList[$key]['i'] = $i;
        $i++;
    }
}
$photoCount = Count($photoList);

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($tczhaopinInfo['city_id']);
$areaList = array();
if(!empty($areaListTmp)){
    foreach ($areaListTmp as $key => $value){
        $areaList[$value['id']] = $value;
    }
}

$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($tczhaopinInfo['area_id']);
$streetList = array();
if(!empty($streetListTmp)){
    foreach ($streetListTmp as $key => $value){
        $streetList[$value['id']] = $value;
    }
}

$editUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/edit");