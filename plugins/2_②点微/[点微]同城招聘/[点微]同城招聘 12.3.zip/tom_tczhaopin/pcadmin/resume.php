<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=resume";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'refresh' && submitcheck('resume_id')){
    $outArr = array(
        'code'=> 1,
    );

    $resume_id = intval($_GET['resume_id'])>0 ? intval($_GET['resume_id']):0;

    $updateData = array();
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resume_id, $updateData);
    update_resume_tongcheng($resume_id);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('resume_id')){
    $outArr = array(
        'code'=> 1,
    );

    $resume_id = intval($_GET['resume_id'])>0 ? intval($_GET['resume_id']):0;

    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resume_id,$updateData);
    
    update_resume_tongcheng($resume_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('resume_id')){
    $outArr = array(
        'code'=> 1,
    );

    $resume_id = intval($_GET['resume_id'])>0 ? intval($_GET['resume_id']):0;
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resume_id,$updateData);
    
    update_resume_tongcheng($resume_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'edittop' && submitcheck('resume_id')){
    $outArr = array(
        'code'=> 1,
    );

    $resume_id       = intval($_GET['resume_id'])>0 ? intval($_GET['resume_id']):0;
    $top_time        = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
    $top_time        = strtotime($top_time);
        
    $updateData = array();
    
    if($top_time <= TIMESTAMP){
        $updateData['top_status']   = 0;
        $updateData['top_time']     = 0;
    }else{
        $updateData['top_status']   = 1;
        $updateData['refresh_time'] = TIMESTAMP;
        $updateData['top_time']     = $top_time;
    }
    
    C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resume_id, $updateData);
    
    update_resume_tongcheng($resume_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'del' && submitcheck('resume_id')){
    $outArr = array(
        'code'=> 1,
    );

    $resume_id = intval($_GET['resume_id'])>0 ? intval($_GET['resume_id']):0;
    
    C::t('#tom_tczhaopin#tom_tczhaopin_resume')->delete_by_id($resume_id);
    C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->delete_by_resume_id($resume_id);
    C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->delete_by_resume_id($resume_id);
    C::t('#tom_tczhaopin#tom_tczhaopin_history')->delete_by_resume_id($resume_id);
    
    delete_resume_tongcheng($resume_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'shenhe' && submitcheck('resume_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $resume_id      = intval($_GET['resume_id'])>0 ? intval($_GET['resume_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $resumeInfo = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($resume_id);
    $cateInfo   = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($resumeInfo['cate_id']);
    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($resumeInfo['user_id']);
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status']    = 1;
        C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resume_id,$updateData);
        
        $shenhe = str_replace("{CATE}", $cateInfo['name'], $Lang['resume_template_tczhaopin_shenhe_ok']);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$resumeInfo['site_id']}&mod=resumeinfo&resume_id=".$resumeInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tczhaopinConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }

        update_resume_tongcheng($resumeInfo['id']);

        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tczhaopinConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resume_id,$updateData);
        
        update_resume_tongcheng($resumeInfo['id']);
        
        $shenhe = str_replace("{CATE}", $cateInfo['name'], $Lang['resume_template_tczhaopin_shenhe_no']);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$resumeInfo['site_id']}&mod=editresume&resume_id=".$resumeInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tczhaopinConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tczhaopinConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tczhaopin_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}else if($act == 'batch_refresh' && submitcheck('resume_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $resumeIdsArr = array();
    if(is_array($_GET['resume_ids'])){
        foreach($_GET['resume_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $resumeIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($resumeIdsArr)){
        foreach($resumeIdsArr as $key => $value){
            $updateData = array();
            $updateData['refresh_time'] = TIMESTAMP;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value, $updateData);
            update_resume_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'batch_shenhe1' && submitcheck('resume_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $resumeIdsArr = array();
    if(is_array($_GET['resume_ids'])){
        foreach($_GET['resume_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $resumeIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($resumeIdsArr)){
        $resumeIdsStr = implode(',', $resumeIdsArr);
        $resumeListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_all_list(" AND id IN({$resumeIdsStr}) ", 'ORDER BY id DESC', 0, 100);
        $userIdsArr = array();
        foreach($resumeListTmp as $key => $value){
            
            $userIdsArr[] = $value['user_id'];
            
            $updateData = array();
            $updateData['shenhe_status'] = 1;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value['id'], $updateData);
            
            update_resume_tongcheng($value['id']);
        }
        
        if(!empty($tongchengConfig['template_id'])){
            $userIdsStr = implode(',', $userIdsArr);
            $userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            foreach($userListTmp as $key => $value){
                
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($value['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myresumelist");
                    $smsData = array(
                        'first'         => $Lang['resume_shenhe_succ_msg'],
                        'keyword1'      => $tczhaopinConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($value['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_shenhe3' && submitcheck('resume_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $resumeIdsArr = array();
    if(is_array($_GET['resume_ids'])){
        foreach($_GET['resume_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $resumeIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($resumeIdsArr)){
        $resumeIdsStr = implode(',', $resumeIdsArr);
        $resumeListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_all_list(" AND id IN({$resumeIdsStr}) ", 'ORDER BY id DESC', 0, 100);
        $userIdsArr = array();
        foreach($resumeListTmp as $key => $value){
            
            $userIdsArr[] = $value['user_id'];
            
            $updateData = array();
            $updateData['shenhe_status'] = 3;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value['id'], $updateData);
            
            update_resume_tongcheng($value['id']);
        }
        
        if(!empty($tongchengConfig['template_id'])){
            $userIdsStr = implode(',', $userIdsArr);
            $userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            foreach($userListTmp as $key => $value){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($value['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myresumelist");
                    $smsData = array(
                        'first'         => $Lang['resume_shenhe_fail_msg'],
                        'keyword1'      => $tczhaopinConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($value['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('resume_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $resumeIdsArr = array();
    if(is_array($_GET['resume_ids'])){
        foreach($_GET['resume_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $resumeIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($resumeIdsArr)){
        foreach($resumeIdsArr as $key => $value){
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->delete_by_id($value);
            C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->delete_by_resume_id($value);
            C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->delete_by_resume_id($value);
            C::t('#tom_tczhaopin#tom_tczhaopin_history')->delete_by_resume_id($value);
            delete_resume_tongcheng($value);
        }
    }
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_show' && submitcheck('resume_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $resumeIdsArr = array();
    if(is_array($_GET['resume_ids'])){
        foreach($_GET['resume_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $resumeIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($resumeIdsArr)){
        foreach($resumeIdsArr as $key => $value){
            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value,$updateData);
            update_resume_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_hide' && submitcheck('resume_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $resumeIdsArr = array();
    if(is_array($_GET['resume_ids'])){
        foreach($_GET['resume_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $resumeIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($resumeIdsArr)){
        foreach($resumeIdsArr as $key => $value){
            $updateData = array();
            $updateData['status'] = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value,$updateData);
            update_resume_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('resume_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $resume_id = intval($_GET['resume_id'])>0? intval($_GET['resume_id']):0;
    
    $resumeInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($resume_id);
    $resumeInfo = array();
    if(!empty($resumeInfoTmp)){
        
        $resumeInfo = $resumeInfoTmp;

        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($resumeInfo['user_id']);
        $cateInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($resumeInfo['cate_id']);
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($resumeInfo['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($resumeInfo['street_id']);
        
        $work_jingyan = $workJingyanArray[$resumeInfo['work_jingyan']];
        $work_salary = $workSalaryArray[$resumeInfo['work_salary']];
        $xueli = $xueliArray[$resumeInfo['xueli']];
        $work_status = $workStatusArray[$resumeInfo['work_status']];
        $age = dgmdate(TIMESTAMP,"Y",$tomSysOffset) - $resumeInfo['birth_year'];
        $video_pic = get_file_url($resumeInfo['video_pic']);
        
        $resumeInfo['userInfo']           = $userInfoTmp;
        $resumeInfo['video_pic']          = $video_pic;
        $resumeInfo['work_jingyan']       = $work_jingyan;
        $resumeInfo['work_salary']        = $work_salary;
        $resumeInfo['age']                = $age;
        $resumeInfo['xueli']              = $xueli;
        $resumeInfo['work_status']        = $work_status;
        $resumeInfo['cateInfo']           = $cateInfoTmp;
        $resumeInfo['areaInfo']           = $areaInfoTmp;
        $resumeInfo['streetInfo']         = $streetInfoTmp;
        
    }
    
    $resumeInfo = iconv_to_utf8($resumeInfo);
    $outArr = array(
        'code'  => 200,
        "msg"   => "",
        "data"  => $resumeInfo
    );
    echo json_encode($outArr); exit;
}

$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$resume_id          = isset($_GET['resume_id'])? intval($_GET['resume_id']):0;
$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
$cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
$status             = isset($_GET['status'])? intval($_GET['status']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
$tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
$deleted            = isset($_GET['deleted'])? intval($_GET['deleted']):0;
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$cate_child_search = '';
if($cate_child_id > 0){
    $cate_child_search = '-'.$cate_child_id.'-';
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$whereStr = '';
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}
if(!empty($resume_id)){
    $whereStr.= " AND id={$resume_id} ";
}
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}
if(!empty($tel)){
    $whereStr.= " AND tel='{$tel}' ";
}
if(!empty($cate_id)){
    $whereStr.= " AND cate_id={$cate_id} ";
}
if(!empty($status)){
    if($status == 1){
        $whereStr.= " AND status=1 ";
    }else if($status == 2){
        $whereStr.= " AND status != 1 ";
    }
}
if(!empty($shenhe_status)){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}
if($top_status > 0){
    if($top_status == 1){
        $whereStr.= " AND top_status = 1 ";
    }else if($top_status == 2){
        $whereStr.= " AND top_status = 0 ";
    }
}
if($deleted > 0){
    if($deleted == 1){
        $whereStr.= " AND deleted = 0 ";
    }else if($deleted == 2){
        $whereStr.= " AND deleted = 1 ";
    }
}

$order = "ORDER BY add_time DESC,id DESC";
if($paixu_type == 1){
    $order = "ORDER BY shenqing_num DESC,id DESC";
}

$start          = ($page - 1)*$pagesize;
$count          = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count($whereStr,$cate_child_search);
$resumeListTmp  = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_list($whereStr,$order,$start,$pagesize,$cate_child_search);
$resumeList = array();
if(!empty($resumeListTmp)){
    foreach ($resumeListTmp as $key => $value) {
        $resumeList[$key] = $value;
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        $cateInfoTmp = $cateList[$value['cate_id']];
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        
        if(!empty($value['avatar'])){
            $resumeList[$key]['avatar'] = get_file_url($value['avatar']);
        }else{
            if($value['sex'] == 1){
                $resumeList[$key]['avatar'] = 'source/plugin/tom_tczhaopin/images/resume_avatar/man.png';
            }elseif($value['sex'] == 2){
                $resumeList[$key]['avatar'] = 'source/plugin/tom_tczhaopin/images/resume_avatar/woman.png';
            }
        }
        
        $resumeList[$key]['userInfo']              = $userInfoTmp;
        $resumeList[$key]['cateInfo']              = $cateInfoTmp;
        $resumeList[$key]['siteInfo']              = $siteInfoTmp;
        $resumeList[$key]['top_time']              = dgmdate($value['top_time'],"Y-m-d H:i",$tomSysOffset);
        $resumeList[$key]['refresh_time']          = dgmdate($value['refresh_time'],"Y-m-d H:i",$tomSysOffset);
        $resumeList[$key]['add_time']              = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);

    }
}

$pageUrl = $modPcadminUrl."&cate_id={$cate_id}&cate_child_id={$cate_child_id}&user_id={$user_id}&site_id={$site_id}&status={$status}&shenhe_status={$shenhe_status}&top_status={$top_status}&deleted={$deleted}&paixu_type={$paixu_type}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/resume");