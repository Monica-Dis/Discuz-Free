<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=add";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id                    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $site_id                    = intval($_GET['site_id'])>0? intval($_GET['site_id']):1;
    $title                      = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title                      = dhtmlspecialchars($title);
    $type                       = isset($_GET['type'])? intval($_GET['type']):0;
    $cate_id                    = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id              = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $jianzhi_cate_id            = isset($_GET['jianzhi_cate_id'])? intval($_GET['jianzhi_cate_id']):0;
    $work_salary                = isset($_GET['work_salary'])? intval($_GET['work_salary']):0;
    $work_salary_min            = intval($_GET['work_salary_min'])>0? intval($_GET['work_salary_min']):0;
    $work_salary_max            = intval($_GET['work_salary_max'])>0? intval($_GET['work_salary_max']):0;
    $jianzhi_work_salary        = isset($_GET['jianzhi_work_salary'])? intval($_GET['jianzhi_work_salary']):0;
    $jianzhi_work_salary_unit   = isset($_GET['jianzhi_work_salary_unit'])? intval($_GET['jianzhi_work_salary_unit']):0;
    $jianzhi_jiesuan_fangshi    = isset($_GET['jianzhi_jiesuan_fangshi'])? intval($_GET['jianzhi_jiesuan_fangshi']):0;
    $renshu                     = isset($_GET['renshu'])? intval($_GET['renshu']):0;
    $demand_sex                 = isset($_GET['demand_sex'])? intval($_GET['demand_sex']):0;
    $demand_ages                = isset($_GET['demand_ages'])? intval($_GET['demand_ages']):0;
    $demand_xueli               = isset($_GET['demand_xueli'])? intval($_GET['demand_xueli']):0;
    $demand_jingyan             = isset($_GET['demand_jingyan'])? intval($_GET['demand_jingyan']):0;
    $demand_desc                = isset($_GET['demand_desc'])? addslashes($_GET['demand_desc']):'';
    $demand_desc                = dhtmlspecialchars($demand_desc);
    $area_id                    = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id                  = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $lng                        = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                        = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address                    = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address                    = dhtmlspecialchars($address);
    $xm                         = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $company_name               = isset($_GET['company_name'])? addslashes($_GET['company_name']):'';
    $video_url                  = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_pic                  = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic                  = dhtmlspecialchars($video_pic);
    $expire_status              = intval($_GET['expire_status'])>0? intval($_GET['expire_status']):1;
    $expire_time                = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time                = strtotime($expire_time);
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photopsort_") !== false){
            $kk = intval(ltrim($key, "photopsort_"));
            $photoArr[$kk]['psort'] = addslashes($value);
        }
    }
    
    $workWelfareArr = array();
    if(is_array($_GET['work_welfare']) && !empty($_GET['work_welfare'])){
        foreach($_GET['work_welfare'] as $key => $value){
            $workWelfareArr[] = intval($value);
        }
    }
    $work_welfare = '-'.implode('-', $workWelfareArr).'-';
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$user_id} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    $companyRenzhengStatus = 0;
    $rzCompanyInfo = array();
    if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
        $companyRenzhengStatus = 1;
        $rzCompanyInfo = $rzCompanyInfoTmp[0];
    }
    
    if($companyRenzhengStatus == 1){
        $company_name = $rzCompanyInfo['name'];
    }

    $search_text = '';
    if($type == 1){
        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_id);
        $cateChildInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_child_id);
        $search_text = $title.'-'.$cateInfo['name'].'-'.$cateChildInfo['name'].'-'.$company_name;
    }else if($type == 2){
        $jianzhiCateInfo =  C::t("#tom_tczhaopin#tom_tczhaopin_jianzhi_cate")->fetch_by_id($jianzhi_cate_id);
        $search_text = $title.'-'.$jianzhiCateInfo['name'].'-'.$company_name;
    }
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($user_id);
    if(is_array($companyInfo) && !empty($companyInfo)){ 
        update_company_status($companyInfo);
    }else{
        $insertData = array();
        $insertData['site_id']              = $site_id;
        $insertData['user_id']              = $user_id;
        $insertData['add_time']             = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_company')->insert($insertData)){
            $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($user_id);
            update_company_status($companyInfo);
        }
    }
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['user_id']          = $user_id;
    $insertData['company_id']       = $companyInfo['id'];
    $insertData['title']            = $title;
    $insertData['type']             = $type;
    if($type == 1){
        $insertData['cate_id']            = $cate_id;
        $insertData['cate_child_id']      = $cate_child_id;
    }else if($type == 2){
        $insertData['jianzhi_cate_id']    = $jianzhi_cate_id;
    }
    if($type == 1){
        $insertData['work_salary']          = $work_salary;
        $insertData['work_salary_min']      = $work_salary_min;
        $insertData['work_salary_max']      = $work_salary_max;
        $insertData['work_welfare']         = $work_welfare;
    }else if($type == 2){
        $insertData['jianzhi_work_salary']       = $jianzhi_work_salary;
        $insertData['jianzhi_work_salary_unit']  = $jianzhi_work_salary_unit;
        $insertData['jianzhi_jiesuan_fangshi']   = $jianzhi_jiesuan_fangshi;
    }
    $insertData['renshu']             = $renshu;
    $insertData['demand_sex']         = $demand_sex;
    $insertData['demand_ages']        = $demand_ages;
    $insertData['demand_xueli']       = $demand_xueli;
    $insertData['demand_jingyan']     = $demand_jingyan;
    $insertData['demand_desc']        = $demand_desc;
    $insertData['city_id']            = $city_id;
    $insertData['area_id']            = $area_id;
    $insertData['street_id']          = $street_id;
    $insertData['address']            = $address;
    $insertData['latitude']           = $lat;
    $insertData['longitude']          = $lng;
    $insertData['xm']                 = $xm;
    $insertData['tel']                = $tel;
    if($companyRenzhengStatus == 1){
        $insertData['company_name']            = $rzCompanyInfo['name'];
        $insertData['company_nature_id']       = $rzCompanyInfo['nature_id'];
        $insertData['company_industry_id']     = $rzCompanyInfo['industry_id'];
        $insertData['company_scale_id']        = $rzCompanyInfo['scale_id'];
    }else{
        $insertData['company_name']            = $company_name;
    }
    if(!empty($video_url)){
        $insertData['video_status']       = 1;
    }else{
        $insertData['video_status']       = 0;
    }
    $insertData['video_url']          = $video_url;
    $insertData['video_pic']          = $video_pic;
    $insertData['search_text']        = $search_text;
    if($expire_status == 3){
        $insertData['expire_status']  = $expire_status;
    }else{
        if($expire_time < TIMESTAMP){
            $insertData['expire_status']    = 2;
            $insertData['expire_time']      = 0;
        }else{
            $insertData['expire_status']    = 1;
            $insertData['expire_time']      = $expire_time;
        }
    }
    $insertData['shenhe_status']    = 1;
    $insertData['status']           = 0;
    $insertData['refresh_time']     = TIMESTAMP;
    $insertData['add_time']         = TIMESTAMP;
    
    $tczhaopin_id = C::t("#tom_tczhaopin#tom_tczhaopin")->insert($insertData, true);
    
    if(!empty($photoArr)){
        foreach($photoArr as $key => $value){
            $insertData = array();
            $insertData['tczhaopin_id'] = $tczhaopin_id;
            $insertData['picurl']       = $value['picurl'];
            $insertData['psort']        = $value['psort'];
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tczhaopin#tom_tczhaopin_photo')->insert($insertData);
        }
    }
    update_company_status($companyInfo);
    update_zhaopin_tongcheng($tczhaopin_id);
        
    if($tczhaopin_id > 0){
        $outArr = array(
            'code'=> 200,
            'id'=> $tczhaopin_id,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}else if($act == 'check_user_id' && $_GET['formhash'] == FORMHASH ){
    $outArr = array(
        'code'=> 1,
    );
    
    $user_id = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    
    $uservipInfo   = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_by_user_id($user_id);
    $vipInfo       = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_by_id($uservipInfo['vip_id']);
    
    $vip_status = 0;
    if($vipInfo && $vipInfo['id'] > 0){
        $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$user_id} AND expire_status = 3");
        if($uservipInfo['vip_id'] > 0 && $uservipInfo['expire_time'] > TIMESTAMP && $uservipInfo['expire_status'] == 1 && $vipInfo['fabu_num'] > $userVipLogCount){
            $vip_status = 1;
        }
    }
    
    $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$user_id} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    $companyRenzhengStatus = 0;
    if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
        $companyRenzhengStatus = 1;
    }
    $company_name = $rzCompanyInfoTmp[0]['name'];
    $company_name = iconv_to_utf8($company_name);
    
    $outArr = array(
        'code'  => 200,
        'vip_status'  => $vip_status,
        'companyRenzhengStatus'  => $companyRenzhengStatus,
        'company_name'    => $company_name,
    );
    
    echo json_encode($outArr); exit;
    
}

$company_id    = intval($_GET['company_id'])>0? intval($_GET['company_id']):0;

$defaultVipstatus = 0;
$defaultUserID = $defaultCompanyName = '';
if($company_id > 0){
    $companyInfo   = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($company_id);
    $rzCompanyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_id($companyInfo['renzheng_company_id']);
    
    $uservipInfo   = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_by_user_id($companyInfo['user_id']);
    $vipInfo       = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_by_id($uservipInfo['vip_id']);
    
    if($vipInfo && $vipInfo['id'] > 0){
        $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$companyInfo['user_id']} AND expire_status = 3");
        if($uservipInfo['vip_id'] > 0 && $uservipInfo['expire_time'] > TIMESTAMP && $uservipInfo['expire_status'] == 1 && $vipInfo['fabu_num'] > $userVipLogCount){
            $defaultVipstatus = 1;
        }
    }
    
    $defaultUserID = $companyInfo['user_id'];
    $defaultCompanyName = $rzCompanyInfo['name'];
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$__CityInfo = array();
if(!empty($tongchengConfig['city_id'])){
    $__CityInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);

$jianzhiCateList = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,5000);

$cateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,5000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$addUrl = $modPcadminUrl."&act=add";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tczhaopin:pcadmin/add");