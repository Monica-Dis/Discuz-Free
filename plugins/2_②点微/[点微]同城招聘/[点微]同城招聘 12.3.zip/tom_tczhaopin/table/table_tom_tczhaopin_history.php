<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tczhaopin_history extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dism_ taobao_ com*/
		$this->_table = 'tom_tczhaopin_history';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
    public function fetch_all_list($condition='',$orders = '',$start = 0,$limit = 10) {
        $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        return $data;
	}
    
    public function fetch_all_history_resume_list($condition='',$orders = '',$start = 0,$limit = 10) {
        $data = DB::fetch_all("SELECT t.*,r.site_id,r.name,r.avatar,r.cate_id,r.cate_child_ids,r.cate_child_str,r.area_id,r.street_id,r.work_jingyan,r.work_salary,r.sex,r.birth_year,r.xueli,r.work_jingli,r.top_status,r.top_time,r.shenhe_status,r.status,r.refresh_time,r.video_status FROM %t t LEFT JOIN ".DB::table("tom_tczhaopin_resume")." r on r.id=t.resume_id  WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_history_resume_count($condition='') {
        $return = DB::fetch_first("SELECT count(*) AS num FROM %t t LEFT JOIN ".DB::table("tom_tczhaopin_resume")." r on r.id=t.resume_id  WHERE 1 %i ",array($this->_table,$condition));
		return $return['num'];
	}
    
    public function fetch_all_count($condition='') {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_resume_id($resume_id) {
		return DB::query("DELETE FROM %t WHERE resume_id=%d", array($this->_table, $resume_id));
	}

}