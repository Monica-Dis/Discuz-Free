<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tczhaopin extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dism_ taobao_ com*/
		$this->_table = 'tom_tczhaopin';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
    public function fetch_all_nearby_list($condition='',$start = 0,$limit = 10,$lat='',$lng='',$keyword='') {
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $data = DB::fetch_all("SELECT *,acos(cos($lat*pi()/180 )*cos(latitude*pi()/180)*cos($lng*pi()/180 - longitude*pi()/180)+sin($lat*pi()/180 )*sin(latitude*pi()/180))*6370996.81/1000 as distance FROM %t WHERE latitude IS NOT NULL AND longitude IS NOT NULL %i AND search_text LIKE %s ORDER BY distance ASC,id DESC LIMIT $start,$limit",array($this->_table,$condition,'%'.$keyword.'%'));
        }else{
            $data = DB::fetch_all("SELECT *,acos(cos($lat*pi()/180 )*cos(latitude*pi()/180)*cos($lng*pi()/180 - longitude*pi()/180)+sin($lat*pi()/180 )*sin(latitude*pi()/180))*6370996.81/1000 as distance FROM %t WHERE latitude IS NOT NULL AND longitude IS NOT NULL %i ORDER BY distance ASC,id DESC LIMIT $start,$limit",array($this->_table,$condition));
        }
        return $data;
	}
    
    public function fetch_all_list($condition='',$orders = '',$start = 0,$limit = 10,$keyword='') {
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i AND search_text LIKE %s $orders LIMIT $start,$limit",array($this->_table,$condition,'%'.$keyword.'%'));
        }else{
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        }
        return $data;
	}
    
    public function fetch_all_list_ids($condition='',$orders = '',$start = 0,$limit = 10,$keyword='') {
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $data = DB::fetch_all("SELECT id FROM %t WHERE 1 %i AND search_text LIKE %s $orders LIMIT $start,$limit",array($this->_table,$condition,'%'.$keyword.'%'));
        }else{
            $data = DB::fetch_all("SELECT id FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        }
        return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition='',$keyword='') {
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition AND search_text LIKE '%{$keyword}%' ");
        }else{
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
        }
        if($return['num'] > 0){
            return $return['num'];
        }else{
            return 0;
        }
	}
    
    public function fetch_sum_clicks($condition='',$keyword='') {
        $return = DB::fetch_first("SELECT SUM(clicks) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
    
    public function fetch_all_auto_refresh_ids($nowDayTime) {
        $data = DB::fetch_all("SELECT z.id FROM %t z LEFT JOIN ".DB::table("tom_tczhaopin_user_vip")." u on z.user_id=u.user_id LEFT JOIN ".DB::table("tom_tczhaopin_vip")." v on u.vip_id=v.id  WHERE z.status=1 AND z.shenhe_status=1 AND z.pay_status IN(0,2) AND z.refresh_time < $nowDayTime AND u.expire_status=1 AND v.auto_refresh=1 ORDER BY z.refresh_time ASC,z.id DESC LIMIT 0,1000",array($this->_table));
        return $data;
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

}