<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tczhaopin_shenqing extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dism_ taobao_ com*/
		$this->_table = 'tom_tczhaopin_shenqing';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
    public function fetch_all_list($condition='',$orders = '',$start = 0,$limit = 10) {
        $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        return $data;
	}
    
    public function fetch_all_shenqing_zhaopin_resume_list($condition='',$orders = '',$start = 0,$limit = 10) {
        $data = DB::fetch_all("SELECT t.*,z.site_id AS site_id,z.title AS tczhaopin_title,z.type,z.user_id AS z_user_id,z.company_id,z.expire_status,z.status AS z_status,z.expire_time,z.video_status,z.shenhe_status, z.area_id,z.cate_id,z.cate_child_id,z.street_id,z.work_welfare,z.renshu,z.company_name,z.work_salary,z.work_salary_min,z.work_salary_max,z.jianzhi_work_salary,z.jianzhi_work_salary_unit,z.jianzhi_jiesuan_fangshi,r.name AS r_name,r.avatar AS r_avatar,r.cate_id AS r_cate_id,r.cate_child_ids AS r_cate_child_ids,r.cate_child_str AS r_cate_child_str,r.area_id AS r_area_id,r.street_id AS r_street_id,r.work_jingyan AS r_work_jingyan,r.work_salary AS r_work_salary,r.sex AS r_sex,r.birth_year AS r_birth_year,r.xueli AS r_xueli,r.work_jingli AS r_work_jingli,r.video_status AS r_video_status FROM %t t LEFT JOIN ".DB::table("tom_tczhaopin")." z on z.id=t.tczhaopin_id LEFT JOIN ".DB::table("tom_tczhaopin_resume")." r on r.id=t.resume_id  WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_shenqing_zhaopin_resume_count($condition='') {
        $return = DB::fetch_first("SELECT count(*) AS num FROM %t t LEFT JOIN ".DB::table("tom_tczhaopin")." z on z.id=t.tczhaopin_id LEFT JOIN ".DB::table("tom_tczhaopin_resume")." r on r.id=t.resume_id  WHERE 1 %i ",array($this->_table,$condition));
		return $return['num'];
	}
    
    public function fetch_all_count($condition='') {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_tczhaopin_id($tczhaopin_id) {
		return DB::query("DELETE FROM %t WHERE tczhaopin_id=%d", array($this->_table, $tczhaopin_id));
	}
	
	public function delete_by_resume_id($resume_id) {
		return DB::query("DELETE FROM %t WHERE resume_id=%d", array($this->_table, $resume_id));
	}

}