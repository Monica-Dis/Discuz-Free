<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = '20210812';
$zhaopinSetting = C::t('#tom_tczhaopin#tom_tczhaopin_setting')->fetch_by_id(1);
if (!$zhaopinSetting || $zhaopinSetting['id'] <= 0) {
	$insertData = array();
	$insertData['id'] = 1;
	C::t('#tom_tczhaopin#tom_tczhaopin_setting')->insert($insertData);
	$zhaopinSetting = C::t('#tom_tczhaopin#tom_tczhaopin_setting')->fetch_by_id(1);
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/class/function.core.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tczhaopinConfig['wx_share_title'];
$shareDesc = $tczhaopinConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=index');
$shareLogo = $tczhaopinConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
$tcadminConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcadmin/tom_tcadmin.inc.php')) {
	$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$__ShowTcsign = 0;
$tcsignConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcsign/tom_tcsign.inc.php')) {
	$tcsignConfig = $_G['cache']['plugin']['tom_tcsign'];
	if ($tcsignConfig['open_tcsign'] == 1) {
		$__ShowTcsign = 1;
	}
}
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')) {
	$tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
	if ($tcrenzhengConfig['open_tcrenzheng'] == 1) {
		$__ShowTcrenzheng = 1;
	}
}
if ($__ShowTcrenzheng == 0) {
	echo lang('plugin/tom_tczhaopin', 'install_renzheng_ts');
	exit(0);
}
$__ShowVideo = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/video.inc.php')) {
	$__ShowVideo = 1;
}
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')) {
	$xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
	$__ShowXiaofenlei = 1;
}
$__ShowZppc = 0;
$zppcConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_zppc/tom_zppc.inc.php')) {
	$zppcConfig = $_G['cache']['plugin']['tom_zppc'];
	if ($zppcConfig['open_zppc'] == 1) {
		$__ShowZppc = 1;
	}
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
if (CHARSET == 'gbk') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/config/config.gbk.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/config/config.utf.php';
}
$welfareArray = array();
$welfare_list_str = str_replace("\r\n", '{n}', $tczhaopinConfig['welfare_list']);
$welfare_list_str = str_replace("\n", '{n}', $welfare_list_str);
$welfare_list_arr = explode('{n}', $welfare_list_str);
if (is_array($welfare_list_arr) && !empty($welfare_list_arr)) {
	foreach ($welfare_list_arr as $key => $value) {
		$welfare_list_item = explode('|', $value);
		$welfare_list_item_id = intval($welfare_list_item[0]);
		$welfare_list_item_name = trim($welfare_list_item[1]);
		if ($welfare_list_item_id > 0 && !empty($welfare_list_item_name)) {
			$welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
		}
	}
}
$agesArray = array();
$ages_list_str = str_replace("\r\n", '{n}', $tczhaopinConfig['zhaopin_ages_list']);
$ages_list_str = str_replace("\n", '{n}', $ages_list_str);
$ages_list_arr = explode('{n}', $ages_list_str);
if (is_array($ages_list_arr) && !empty($ages_list_arr)) {
	foreach ($ages_list_arr as $key => $value) {
		$ages_list_item = explode('|', $value);
		$ages_list_item_id = intval($ages_list_item[0]);
		$ages_list_item_name = trim($ages_list_item[1]);
		if ($ages_list_item_id > 0 && !empty($ages_list_item_name)) {
			$agesArray[$ages_list_item_id] = $ages_list_item_name;
		}
	}
}
$workStatusArray = array();
$work_status_list_str = str_replace("\r\n", '{n}', $tczhaopinConfig['work_status_list']);
$work_status_list_str = str_replace("\n", '{n}', $work_status_list_str);
$work_status_list_arr = explode('{n}', $work_status_list_str);
if (is_array($work_status_list_arr) && !empty($work_status_list_arr)) {
	foreach ($work_status_list_arr as $key => $value) {
		$work_status_list_item = explode('|', $value);
		$work_status_list_item_id = intval($work_status_list_item[0]);
		$work_status_list_item_name = trim($work_status_list_item[1]);
		if ($work_status_list_item_id > 0 && !empty($work_status_list_item_name)) {
			$workStatusArray[$work_status_list_item_id] = $work_status_list_item_name;
		}
	}
}
if ($__UserInfo['id'] > 0) {
	if ($__ShowTchehuoren == 1) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
}
$__CommonInfo = C::t('#tom_tczhaopin#tom_tczhaopin_common')->fetch_by_site_id($site_id);
if (!$__CommonInfo) {
	$insertData = array();
	$insertData['site_id'] = $site_id;
	C::t('#tom_tczhaopin#tom_tczhaopin_common')->insert($insertData);
}
$renzheng_back_url = $weixinClass->get_url();
$renzheng_back_url = urlencode($renzheng_back_url);
$personalRenzhengUrl = 'plugin.php?id=tom_tcrenzheng&site=' . $site_id . '&mod=personal&renzheng_plugin=zhaopin&renzheng_back=' . $renzheng_back_url;
$companyRenzhengUrl = 'plugin.php?id=tom_tcrenzheng&site=' . $site_id . '&mod=company&renzheng_plugin=zhaopin&renzheng_back=' . $renzheng_back_url;
$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
$ajaxUpdateToprandUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=update_topstatus&formhash=' . $formhash;
$ajaxUpdateExpirestatusUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=update_expirestatus&formhash=' . $formhash;
$ajaxUpdateCompanyStatusUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=update_company_status&formhash=' . $formhash;
$ajaxAutoRefreshUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=auto_refresh&formhash=' . $formhash;
$ajaxZpAutoClickUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=zp_auto_click&formhash=' . $formhash;
$ajaxQzAutoClickUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=qz_auto_click&formhash=' . $formhash;
$ajaxCheckSubscribeUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=check_subscribe&formhash=' . $formhash;
$ajaxCloseSubscribeUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=close_subscribe&formhash=' . $formhash;
$ajaxCommonClicksUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=commonClicks&formhash=' . $formhash;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
$ajaxAutoRefreshResumeUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=auto_refresh_resume&formhash=' . $formhash;
$show_app_download = 0;
$app_download_content = array();
$tongchengConfig['app_download'] = trim($tongchengConfig['app_download']);
if (!empty($tongchengConfig['app_download'])) {
	$show_app_download = 1;
	$app_download_content = explode('|', $tongchengConfig['app_download']);
}
$resume_default_avatar = explode('|', $tczhaopinConfig['resume_default_avatar']);
$man_resume_avatar = 'source/plugin/tom_tczhaopin/images/resume_avatar/' . $resume_default_avatar[0];
$woman_resume_avatar = 'source/plugin/tom_tczhaopin/images/resume_avatar/' . $resume_default_avatar[1];
if ($_GET['mod'] == 'index') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/site_ibs.php';
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$focuspicListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' AND type = 1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->fetch_all_list(' AND site_id=1 AND type = 1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	if (is_array($focuspicListTmp) && !empty($focuspicListTmp)) {
		foreach ($focuspicListTmp as $key => $value) {
			$focuspicList[$key] = $value;
			$focuspicList[$key]['link'] = str_replace('{site}', $site_id, $focuspicList[$key]['link']);
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$focuspicList[$key]['picurl'] = $picurl;
		}
	}
	$commonClicks = C::t('#tom_tczhaopin#tom_tczhaopin_common')->fetch_all_sun_clicks(' AND site_id IN(' . $sql_in_site_ids . ') ');
	$clicksNum = $commonClicks + $tczhaopinConfig['virtual_clicks'];
	$clicksNumTxt = $clicksNum;
	if ($clicksNum > 10000) {
		$clicksNumTmp = $clicksNum / 10000;
		$clicksNumTxt = number_format($clicksNumTmp, 2, '.', '');
	}
	$companyNum = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_all_count(' AND site_id IN(' . $sql_in_site_ids . ') AND show_status=1  ');
	$companyNum = $companyNum + $tczhaopinConfig['virtual_company_num'];
	$companyNumTxt = $companyNum;
	if ($companyNum > 10000) {
		$companyNumTmp = $companyNum / 10000;
		$companyNumTxt = number_format($companyNumTmp, 2);
	}
	$zhaopinNum = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count(' AND site_id IN(' . $sql_in_site_ids . ')');
	$zhaopinNum = $zhaopinNum + $tczhaopinConfig['virtual_zhaopin_num'];
	$zhaopinNumTxt = $zhaopinNum;
	if ($zhaopinNum > 10000) {
		$zhaopinNumTmp = $zhaopinNum / 10000;
		$zhaopinNumTxt = number_format($zhaopinNumTmp, 2);
	}
	$resumeNum = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count(' AND site_id IN(' . $sql_in_site_ids . ')');
	$resumeNum = $resumeNum + $tczhaopinConfig['virtual_resume_num'];
	$resumeNumTxt = $resumeNum;
	if ($resumeNum > 10000) {
		$resumeNumTmp = $resumeNum / 10000;
		$resumeNumTxt = number_format($resumeNumTmp, 2);
	}
	$index_diy_html = trim($zhaopinSetting['index_diy_html']);
	if (!empty($index_diy_html)) {
		$index_diy_html = str_replace('{site}', $site_id, $index_diy_html);
		$index_diy_html = stripslashes($index_diy_html);
	}
	$newCompanyListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_all_company_rzcompany_list(' AND c.show_status = 1 AND r.shenhe_status = 1 AND c.site_id IN(' . $sql_in_site_ids . ')  ', 'ORDER BY c.id DESC', 0, 3);
	$newCompanyList = array();
	if (is_array($newCompanyListTmp) && !empty($newCompanyListTmp)) {
		foreach ($newCompanyListTmp as $key => $value) {
			$newCompanyList[$key] = $value;
		}
	}
	$newCompanyCount = count($newCompanyList);
	$newTczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list(' AND site_id IN(' . $sql_in_site_ids . ') AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ', ' ORDER BY id DESC ', 0, 5);
	$newTczhaopinList = array();
	if (is_array($newTczhaopinListTmp) && !empty($newTczhaopinListTmp)) {
		foreach ($newTczhaopinListTmp as $key => $value) {
			$newTczhaopinList[$key] = $value;
		}
	}
	$newTczhaopinCount = count($newTczhaopinList);
	$newCount = $newCompanyCount + $newTczhaopinCount;
	$str_replace_search_array = array('{FUJING}', '{COMPANY}', '{MEETING}', '{RESUME}', '{ZHAOPIN}', '{JIANZHI}');
	$str_replace_search_replace = array('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=zhaopinlist&ordertype=nearby', 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=companylist', 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=meeting', 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=resumelist', 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=zhaopinlist', 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=jianzhilist');
	$menuList = array();
	$i = 1;
	if (!empty($tczhaopinConfig['index_nav'])) {
		$index_menu_str = str_replace($str_replace_search_array, $str_replace_search_replace, $tczhaopinConfig['index_nav']);
		$index_menu_str = str_replace('{site}', $site_id, $index_menu_str);
		$index_menu_str = str_replace("\r\n", '{n}', $index_menu_str);
		$index_menu_str = str_replace("\n", '{n}', $index_menu_str);
		$index_menu_arr = explode('{n}', $index_menu_str);
		if (is_array($index_menu_arr) && !empty($index_menu_arr)) {
			foreach ($index_menu_arr as $key => $value) {
				$menuList[$i] = explode('|', $value);
				$i++;
			}
		}
	}
	$menuCount = count($menuList);
	$companyListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_all_company_rzcompany_list(' AND c.show_status = 1 AND r.shenhe_status = 1 AND c.site_id IN(' . $sql_in_site_ids . ') ', 'ORDER BY c.tuijian_status DESC,c.top_status DESC,c.csort ASC, c.id DESC', 0, 10);
	$companyList = array();
	if (is_array($companyListTmp) && !empty($companyListTmp)) {
		foreach ($companyListTmp as $key => $value) {
			$companyInfoTmp = update_company_status($value);
			$companyList[$key] = $companyInfoTmp;
			if (!preg_match('/^http/', $value['logo'])) {
				if (strpos($value['logo'], 'source/plugin/tom_') === false) {
					$renzhengCompanyLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['logo'];
				} else {
					$renzhengCompanyLogo = $value['logo'];
				}
			} else {
				$renzhengCompanyLogo = $value['logo'];
			}
			$companyList[$key]['logo'] = $renzhengCompanyLogo;
		}
	}
	$companyCount = count($companyList);
	$hotCateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(' AND is_hot = 1 AND pid = 0 ', 'ORDER BY csort ASC, id DESC', 0, 100);
	$hotCateList = array();
	if (is_array($hotCateListTmp) && !empty($hotCateListTmp)) {
		foreach ($hotCateListTmp as $key => $value) {
			$hotCateList[$key] = $value;
		}
	}
	$hotCateCount = count($hotCateList);
	$popupTmp = C::t('#tom_tczhaopin#tom_tczhaopin_popup')->fetch_all_by_site_ids(' AND status=1', ' ORDER BY id DESC ', 0, 1, '[' . $site_id . ']');
	if ($popupTmp && !empty($popupTmp[0])) {
		$ajaxLoadPopupUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=load_popup&formhash=' . $formhash;
		$ajaxClosePopupUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=close_popup&formhash=' . $formhash;
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=index'));
	$searchUrl = 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=zhaopinsearch&';
	$ajaxZhaopinListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=zhaopinlist&formhash=' . $formhash;
	$ajaxResumeListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=resumelist&formhash=' . $formhash;
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tczhaopin/images/index.js';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tczhaopin:index');
	echo '<script src="source/plugin/tom_tczhaopin/images/index.js"></script>';
} elseif ($_GET['mod'] == 'zhaopinlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$cate_child_ids = !empty($_GET['cate_child_ids']) ? addslashes($_GET['cate_child_ids']) : '';
	$xueli = intval($_GET['xueli']) > 0 ? intval($_GET['xueli']) : 0;
	$salary = intval($_GET['salary']) > 0 ? intval($_GET['salary']) : 0;
	$jingyan = intval($_GET['jingyan']) > 0 ? intval($_GET['jingyan']) : 0;
	$refresh_type = intval($_GET['refresh_type']) > 0 ? intval($_GET['refresh_type']) : 0;
	$scale_id = intval($_GET['scale_id']) > 0 ? intval($_GET['scale_id']) : 0;
	$nature_id = intval($_GET['nature_id']) > 0 ? intval($_GET['nature_id']) : 0;
	$company_renzheng_status = intval($_GET['company_renzheng_status']) > 0 ? intval($_GET['company_renzheng_status']) : 0;
	$ordertype = !empty($_GET['ordertype']) ? addslashes($_GET['ordertype']) : '';
	$type = 1;
	$cate_child_ids_arr_tmp = explode(',', $cate_child_ids);
	$cate_child_ids = '';
	$cate_child_ids_arr = array();
	if (is_array($cate_child_ids_arr_tmp) && !empty($cate_child_ids_arr_tmp)) {
		foreach ($cate_child_ids_arr_tmp as $key => $value) {
			$value_tmp = intval($value);
			if ($value_tmp > 0) {
				$cate_child_ids_arr[] = $value_tmp;
			}
		}
		if (!empty($cate_child_ids_arr)) {
			$cate_child_ids = implode(',', $cate_child_ids_arr);
		}
	}
	$cateName = '';
	$cateList = array();
	$cateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(' AND pid = 0 ', 'ORDER BY csort ASC,id DESC', 0, 100);
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			if ($cate_id == $value['id']) {
				$cateName = $value['name'];
			}
		}
	}
	if ($cate_child_id > 0) {
		$cateChildInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_child_id);
		if ($cateChildInfo['id'] > 0) {
			$cate_id = $cateChildInfo['pid'];
		}
	}
	if ($cate_id > 0) {
		$cateChildListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(' AND pid = ' . $cate_id . ' ', 'ORDER BY csort ASC,id DESC', 0, 100);
		$cateChildList = array();
		if (is_array($cateChildListTmp) && !empty($cateChildListTmp)) {
			foreach ($cateChildListTmp as $key => $value) {
				$cateChildList[$key] = $value;
				if ($cate_child_id == $value['id']) {
					$cateName = $value['name'];
				}
			}
		}
	}
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$areaList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$workWelfareArr = explode('|', $welfare);
	$checkedWelfareList = array();
	if (is_array($welfareArray) && !empty($welfareArray)) {
		foreach ($welfareArray as $key => $value) {
			$checkedWelfareList[$key]['name'] = $value;
			if (in_array($key, $workWelfareArr)) {
				$checkedWelfareList[$key]['status'] = 1;
			} else {
				$checkedWelfareList[$key]['status'] = 0;
			}
		}
	}
	$scaleListTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_scale')->fetch_all_list('', 'ORDER BY ssort ASC, id DESC', 0, 1000);
	$scaleList = array();
	if (is_array($scaleListTmp) && !empty($scaleListTmp)) {
		foreach ($scaleListTmp as $key => $value) {
			$scaleList[$key] = $value;
		}
	}
	$natureList = array();
	$natureListTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_nature')->fetch_all_list('', 'ORDER BY nsort ASC, id DESC', 0, 1000);
	if (is_array($natureListTmp) && !empty($natureListTmp)) {
		foreach ($natureListTmp as $key => $value) {
			$natureList[$key] = $value;
		}
	}
	$showDingyueStatus = 0;
	if ($__UserInfo['id'] > 0 && $cate_id > 0 && $tczhaopinConfig['open_dingyue'] == 1) {
		$dingyueInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_dingyue')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND cate_id = ' . $cate_id . ' ', 'ORDER BY id DESC', 0, 1);
		if (!$dingyueInfoTmp || $dingyueInfoTmp[0]['id'] <= 0) {
			if ($_GET['wxqrcode'] == 1) {
				$showDingyueStatus = 2;
				$insertData = array();
				$insertData['user_id'] = $__UserInfo['id'];
				$insertData['cate_id'] = $cate_id;
				$insertData['add_time'] = TIMESTAMP;
				C::t('#tom_tczhaopin#tom_tczhaopin_dingyue')->insert($insertData);
			} else {
				$cookiesCateId = getcookie('tom_tczhaopin_dingyue_close' . $__UserInfo['id'] . '-' . $cate_id);
				if ($cookiesCateId != $cate_id) {
					$showDingyueStatus = 1;
					$dingyueCateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_id);
				}
			}
		}
	}
	$whereStr = ' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND type=1 ';
	if (!empty($sql_in_site_ids)) {
		$whereStr .= ' AND site_id IN(' . $sql_in_site_ids . ') ';
	}
	if ($cate_id > 0) {
		$whereStr .= ' AND cate_id = ' . $cate_id . ' ';
	}
	if (!empty($cate_child_ids)) {
		$whereStr .= ' AND cate_child_id IN (' . $cate_child_ids . ') ';
	} else {
		if ($cate_child_id > 0) {
			$whereStr .= ' AND cate_child_id = ' . $cate_child_id . ' ';
		}
	}
	$tczhaopinCount = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count($whereStr);
	$list_cate_name = $tczhaopinConfig['zhaopin_list_cate_name'];
	if ($cate_id > 0) {
		$list_cate_name = $cateName;
	}
	if (!empty($tczhaopinConfig['zhaopin_list_share_title'])) {
		$shareTitle = $tczhaopinConfig['zhaopin_list_share_title'];
		$shareTitle = str_replace('{CATENAME}', $list_cate_name, $shareTitle);
		$shareTitle = str_replace('{NUM}', $tczhaopinCount, $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tczhaopinConfig['zhaopin_list_share_desc'])) {
		$shareDesc = $tczhaopinConfig['zhaopin_list_share_desc'];
		$shareDesc = str_replace('{CATENAME}', $list_cate_name, $shareDesc);
		$shareDesc = str_replace('{NUM}', $tczhaopinCount, $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	if (!empty($tczhaopinConfig['zhaopin_share_pic'])) {
		$shareLogo = $tczhaopinConfig['zhaopin_share_pic'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=zhaopinlist&area_id=' . $area_id . '&street_id=' . $street_id . '&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&keyword=') . urlencode(trim($keyword));
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$wxqrcodeUrl = $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=zhaopinlist&cate_id=' . $cate_id);
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=zhaopinlist&keyword=' . $keyword . '&area_id=' . $area_id . '&street_id=' . $street_id . '&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&cate_child_ids=' . $cate_child_ids . '&type=' . $type . '&xueli=' . $xueli . '&salary=' . $salary . '&jingyan=' . $jingyan . '&refresh_type=' . $refresh_type . '&scale_id=' . $scale_id . '&nature_id=' . $nature_id . '&company_renzheng_status=' . $company_renzheng_status . '&ordertype=' . $ordertype));
	$searchUrl = 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=zhaopinsearch&';
	$zhaopinlistUrl = 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=zhaopinlist&';
	$ajaxListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=zhaopinlist&formhash=' . $formhash;
	$ajaxDingyueUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&user_id=' . $__UserInfo['id'] . '&cate_id=' . $cate_id . '&formhash=' . $formhash;
	$ajaxLoadCateListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=load_cate_list&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tczhaopin:zhaopinlist');
} elseif ($_GET['mod'] == 'zhaopinsearch') {
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$xueli = intval($_GET['xueli']) > 0 ? intval($_GET['xueli']) : 0;
	$salary = intval($_GET['salary']) > 0 ? intval($_GET['salary']) : 0;
	$jingyan = intval($_GET['jingyan']) > 0 ? intval($_GET['jingyan']) : 0;
	$scale_id = intval($_GET['scale_id']) > 0 ? intval($_GET['scale_id']) : 0;
	$nature_id = intval($_GET['nature_id']) > 0 ? intval($_GET['nature_id']) : 0;
	$company_renzheng_status = intval($_GET['company_renzheng_status']) > 0 ? intval($_GET['company_renzheng_status']) : 0;
	$sex = intval($_GET['sex']) > 0 ? intval($_GET['sex']) : 0;
	$xueli = intval($_GET['xueli']) > 0 ? intval($_GET['xueli']) : 0;
	$searchArr = array();
	$zhaopinSearchArr = explode('|', $tczhaopinConfig['zhaopin_search_str']);
	if (is_array($zhaopinSearchArr) && !empty($zhaopinSearchArr)) {
		foreach ($zhaopinSearchArr as $key => $value) {
			$searchArr[] = daddslashes($value);
		}
	}
	$searchCount = count($searchArr);
	$ajaxSearchUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=get_zhaopin_search_url&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tczhaopin:zhaopinsearch');
} elseif ($_GET['mod'] == 'jianzhilist') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$jianzhi_cate_id = intval($_GET['jianzhi_cate_id']) > 0 ? intval($_GET['jianzhi_cate_id']) : 0;
	$jianzhi_jiesuan_fangshi = intval($_GET['jianzhi_jiesuan_fangshi']) > 0 ? intval($_GET['jianzhi_jiesuan_fangshi']) : 0;
	$ordertype = !empty($_GET['ordertype']) ? addslashes($_GET['ordertype']) : '';
	$type = 2;
	$cateName = '';
	$jianzhiCateList = array();
	$jianzhiCateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_all_list(' ', 'ORDER BY csort ASC,id DESC');
	if (is_array($jianzhiCateListTmp) && !empty($jianzhiCateListTmp)) {
		foreach ($jianzhiCateListTmp as $key => $value) {
			$jianzhiCateList[$key] = $value;
			if ($jianzhi_cate_id == $value['id']) {
				$cateName = $value['name'];
			}
		}
	}
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$areaList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$whereStr = ' AND type = 2 AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ';
	if (!empty($sql_in_site_ids)) {
		$whereStr .= ' AND site_id IN(' . $sql_in_site_ids . ') ';
	}
	if ($jianzhi_cate_id > 0) {
		$whereStr .= ' AND jianzhi_cate_id = ' . $jianzhi_cate_id . ' ';
	}
	if ($jianzhi_jiesuan_fangshi > 0) {
		$whereStr .= ' AND jianzhi_jiesuan_fangshi = ' . $jianzhi_jiesuan_fangshi . ' ';
	}
	$tczhaopinCount = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count($whereStr);
	$list_cate_name = $tczhaopinConfig['jianzhi_list_cate_name'];
	if ($jianzhi_cate_id > 0) {
		$list_cate_name = $cateName;
	}
	if (!empty($tczhaopinConfig['jianzhi_list_share_title'])) {
		$shareTitle = $tczhaopinConfig['jianzhi_list_share_title'];
		$shareTitle = str_replace('{CATENAME}', $list_cate_name, $shareTitle);
		$shareTitle = str_replace('{NUM}', $tczhaopinCount, $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tczhaopinConfig['jianzhi_list_share_desc'])) {
		$shareDesc = $tczhaopinConfig['jianzhi_list_share_desc'];
		$shareDesc = str_replace('{CATENAME}', $list_cate_name, $shareDesc);
		$shareDesc = str_replace('{NUM}', $tczhaopinCount, $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	if (!empty($tczhaopinConfig['zhaopin_share_pic'])) {
		$shareLogo = $tczhaopinConfig['zhaopin_share_pic'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=jianzhilist&area_id=' . $area_id . '&street_id=' . $street_id . '&jianzhi_cate_id=' . $jianzhi_cate_id . '&keyword=') . urlencode(trim($keyword));
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=jianzhilist&keyword=' . $keyword . '&area_id=' . $area_id . '&street_id=' . $street_id . '&jianzhi_cate_id=' . $jianzhi_cate_id . '&type=' . $type . '&jianzhi_jiesuan_fangshi=' . $jianzhi_jiesuan_fangshi . '&ordertype=' . $ordertype));
	$searchUrl = 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=jianzhisearch&';
	$jianzhilistUrl = 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=jianzhilist&';
	$ajaxListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=zhaopinlist&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tczhaopin:jianzhilist');
} elseif ($_GET['mod'] == 'jianzhisearch') {
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$jianzhi_cate_id = intval($_GET['jianzhi_cate_id']) > 0 ? intval($_GET['jianzhi_cate_id']) : 0;
	$jianzhi_jiesuan_fangshi = intval($_GET['jianzhi_jiesuan_fangshi']) > 0 ? intval($_GET['jianzhi_jiesuan_fangshi']) : 0;
	$ordertype = !empty($_GET['ordertype']) ? addslashes($_GET['ordertype']) : '';
	$searchArr = array();
	$zhaopinSearchArr = explode('|', $tczhaopinConfig['jianzhi_zhaopin_search_str']);
	if (is_array($zhaopinSearchArr) && !empty($zhaopinSearchArr)) {
		foreach ($zhaopinSearchArr as $key => $value) {
			$searchArr[] = daddslashes($value);
		}
	}
	$searchCount = count($searchArr);
	$ajaxSearchUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=get_jianzhi_search_url&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tczhaopin:jianzhisearch');
} elseif ($_GET['mod'] == 'zhaopininfo') {
	$tczhaopin_id = intval($_GET['tczhaopin_id']) > 0 ? intval($_GET['tczhaopin_id']) : 0;
	$meeting_click_id = intval($_GET['meeting_click_id']) > 0 ? intval($_GET['meeting_click_id']) : 0;
	$tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);
	if (!is_array($tczhaopinInfo) || empty($tczhaopinInfo) || $tczhaopinInfo['status'] != 1 || $tczhaopinInfo['shenhe_status'] != 1) {
		if ($tczhaopinInfo['id'] <= 0 || $__UserInfo['groupid'] != 1 && $__UserInfo['groupid'] != 2 && $__UserInfo['id'] != $tczhaopinConfig['zpmanage_user_id']) {
			tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=index'));
			exit(0);
		}
	}
	if ($tczhaopinInfo['type'] == 2 && $tczhaopinInfo['jianzhi_cate_id'] > 0) {
		$jianzhiCateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_by_id($tczhaopinInfo['jianzhi_cate_id']);
	} else {
		$cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($tczhaopinInfo['cate_id']);
		$cateChildInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($tczhaopinInfo['cate_child_id']);
	}
	$shenqingCount = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_count(' AND tczhaopin_id = ' . $tczhaopin_id . ' ');
	$zhaopininfo_desc = dhtmlspecialchars($tczhaopinConfig['zhaopininfo_desc']);
	if ($tczhaopinInfo['area_id'] > 0) {
		$areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tczhaopinInfo['area_id']);
		$streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tczhaopinInfo['street_id']);
	}
	$demand_desc = str_replace("\r\n", '<br/>', $tczhaopinInfo['demand_desc']);
	$demand_desc = str_replace("\n", '<br/>', $demand_desc);
	$demand_desc = str_replace("\r", '<br/>', $demand_desc);
	if ($tczhaopinConfig['hide_demand_desc_tel'] == 1) {
		$demand_desc = preg_replace('/\\d{7}/', '*****', $demand_desc);
	}
	$tczhaopinInfo['xm'] = preg_replace('/\\d{7}/', '*****', $tczhaopinInfo['xm']);
	$workWelfareArr = explode('-', trim($tczhaopinInfo['work_welfare'], '-'));
	$welfareList = array();
	if (is_array($welfareArray) && !empty($welfareArray)) {
		foreach ($welfareArray as $key => $value) {
			if (in_array($key, $workWelfareArr)) {
				$welfareList[$key]['name'] = $value;
			}
		}
	}
	if ($tczhaopinInfo['video_status'] == 1) {
		$video_pic = '';
		if (!preg_match('/^http/', $tczhaopinInfo['video_pic'])) {
			if (strpos($tczhaopinInfo['video_pic'], 'source/plugin/tom_') === false) {
				$video_pic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tczhaopinInfo['video_pic'];
			} else {
				$video_pic = $tczhaopinInfo['video_pic'];
			}
		} else {
			$video_pic = $tczhaopinInfo['video_pic'];
		}
	}
	$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tczhaopinInfo['user_id']);
	if (strpos($userInfo['picurl'], 'data/attachment/tomwx') !== false) {
		$firstLogoUrl = $_G['siteurl'] . $userInfo['picurl'];
	} elseif (strpos($userInfo['picurl'], 'uc_server/') !== false) {
		$firstLogoUrl = $_G['siteurl'] . $userInfo['picurl'];
	} else {
		$firstLogoUrl = $userInfo['picurl'];
	}
	$zhaopinPhoto = '';
	$photoListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_photo')->fetch_all_list(' AND tczhaopin_id = ' . $tczhaopinInfo['id'] . ' ', ' ORDER BY psort ASC,id ASC ');
	$photoList = array();
	$i = 1;
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			$picurlTmp = $value['picurlTmp'];
			if ($i == 1) {
				$zhaopinPhoto = $picurlTmp;
			}
			$photoList[] = $picurlTmp;
			$i++;
		}
	}
	$photoCount = count($photoList);
	$photoListStr = implode('|', $photoList);
	$companyRenzhengStatus = $personalRenzhengStatus = 0;
	$rzConpanyInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_list(' AND user_id = ' . $tczhaopinInfo['user_id'] . ' AND shenhe_status = 1 ', 'ORDER BY id DESC', 0, 1);
	$rzConpanyInfo = array();
	if (is_array($rzConpanyInfoTmp) && !empty($rzConpanyInfoTmp[0])) {
		$rzConpanyInfo = $rzConpanyInfoTmp[0];
		$companyRenzhengStatus = 1;
		$tczhaopinInfo['company_nature_id'] = $rzConpanyInfo['nature_id'];
		$tczhaopinInfo['company_industry_id'] = $rzConpanyInfo['industry_id'];
		$tczhaopinInfo['company_scale_id'] = $rzConpanyInfo['scale_id'];
		$tczhaopinInfo['company_introduce'] = $rzConpanyInfo['introduce'];
		if (!preg_match('/^http/', $rzConpanyInfo['logo'])) {
			if (strpos($rzConpanyInfo['logo'], 'source/plugin/tom_') === false) {
				$firstLogoUrl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $rzConpanyInfo['logo'];
			} else {
				$firstLogoUrl = $_G['siteurl'] . $rzConpanyInfo['logo'];
			}
		} else {
			$firstLogoUrl = $rzConpanyInfo['logo'];
		}
	}
	$rzPersonalInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_all_list(' AND user_id = ' . $tczhaopinInfo['user_id'] . ' AND shenhe_status = 1 ', 'ORDER BY id DESC', 0, 1);
	if (is_array($rzPersonalInfoTmp) && !empty($rzPersonalInfoTmp[0])) {
		$personalRenzhengStatus = 1;
	}
	$natureInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_nature')->fetch_by_id($tczhaopinInfo['company_nature_id']);
	$industryInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_by_id($tczhaopinInfo['company_industry_id']);
	$scaleInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_scale')->fetch_by_id($tczhaopinInfo['company_scale_id']);
	$wxqunInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_wxqun')->fetch_by(' AND site_id = ' . $site_id . ' AND status = 1 ');
	if (!is_array($wxqunInfoTmp) || empty($wxqunInfoTmp)) {
		if ($site_id != 1) {
			$wxqunInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_wxqun')->fetch_by(' AND site_id = 1 AND status = 1 ');
		}
	}
	$wxqunInfo = array();
	if (is_array($wxqunInfoTmp) && !empty($wxqunInfoTmp)) {
		$wxqunInfo = $wxqunInfoTmp;
		if (!preg_match('/^http/', $wxqunInfoTmp['logo'])) {
			if (strpos($wxqunInfoTmp['logo'], 'source/plugin/tom_') === false) {
				$wxqunInfo['logo'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $wxqunInfoTmp['logo'];
			} else {
				$wxqunInfo['logo'] = $wxqunInfoTmp['logo'];
			}
		} else {
			$wxqunInfo['logo'] = $wxqunInfoTmp['logo'];
		}
		if (!preg_match('/^http/', $wxqunInfoTmp['qrcode'])) {
			if (strpos($wxqunInfoTmp['qrcode'], 'source/plugin/tom_') === false) {
				$wxqunInfo['qrcode'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $wxqunInfoTmp['qrcode'];
			} else {
				$wxqunInfo['qrcode'] = $wxqunInfoTmp['qrcode'];
			}
		} else {
			$wxqunInfo['qrcode'] = $wxqunInfoTmp['qrcode'];
		}
	}
	$focuspicListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' AND type = 3 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->fetch_all_list(' AND site_id=1 AND type = 3 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	if (is_array($focuspicListTmp) && !empty($focuspicListTmp)) {
		foreach ($focuspicListTmp as $key => $value) {
			$focuspicList[$key] = $value;
			$focuspicList[$key]['link'] = str_replace('{site}', $site_id, $focuspicList[$key]['link']);
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$focuspicList[$key]['picurl'] = $picurl;
		}
	}
	$showShenqingStatus = $showCollectStatus = 1;
	$myResumeCount = $myResumeShenheCount = 0;
	if ($__UserInfo['id'] > 0) {
		$showShenqingStatus = 2;
		$resumeListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND shenhe_status = 1 AND deleted = 0 ', 'ORDER BY id DESC', 0, 100);
		$resumeList = array();
		if (is_array($resumeListTmp) && !empty($resumeListTmp)) {
			$showShenqingStatus = 3;
			$i = 1;
			foreach ($resumeListTmp as $key => $value) {
				$resumeList[$key] = $value;
				if ($i == 1) {
					$resumeList[$key]['checked'] = 1;
				}
				$i++;
			}
		}
		$shenqingInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_list('AND tczhaopin_id = ' . $tczhaopinInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 1);
		if (is_array($shenqingInfoTmp) && !empty($shenqingInfoTmp['0'])) {
			$showShenqingStatus = 4;
		}
		$myResumeShenheCount = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count(' AND user_id=' . $__UserInfo['id'] . ' AND (shenhe_status = 2 OR shenhe_status = 3) AND deleted = 0 ');
		if ($showShenqingStatus == 2 && $myResumeShenheCount > 0) {
			$showShenqingStatus = 5;
		}
		$myResumeCount = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count(' AND user_id=' . $__UserInfo['id'] . ' AND shenhe_status = 1 AND deleted = 0 ');
		$collectInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_collect')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' AND tczhaopin_id = ' . $tczhaopinInfo['id']);
		if (is_array($collectInfoTmp) && !empty($collectInfoTmp[0])) {
			$showCollectStatus = 2;
		}
	}
	$allowTel = 1;
	if ($tczhaopinConfig['must_tel_resume'] == 1 && $myResumeCount == 0) {
		$allowTel = 2;
	}
	if ($allowTel == 2 && $myResumeShenheCount > 0) {
		$allowTel = 3;
	}
	if ($allowTel == 1 && $tczhaopinConfig['must_tel_sq_resume'] == 1 && $showShenqingStatus != 4) {
		$allowTel = 4;
	}
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tczhaopinConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$baiduMapToName = $tczhaopinInfo['company_name'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapToAddress = $tczhaopinInfo['address'];
	$baiduMapToAddress = diconv($baiduMapToAddress, CHARSET, 'utf-8');
	$baiduMapToAddress = urlencode($baiduMapToAddress);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tczhaopinInfo['latitude'] . ',' . $tczhaopinInfo['longitude'] . '&title=' . $baiduMapToName . '&content=' . $baiduMapToAddress . '&output=html';
	$shareTitle = $tczhaopinInfo['title'];
	if (!empty($tczhaopinConfig['zhaopin_info_share_title'])) {
		$shareTitle = $tczhaopinConfig['zhaopin_info_share_title'];
		$shareTitle = str_replace('{TITLE}', $tczhaopinInfo['title'], $shareTitle);
		if ($tczhaopinInfo['type'] == 2 && $tczhaopinInfo['jianzhi_work_salary'] > 0) {
			$shareTitle = str_replace('{SALARY}', $tczhaopinInfo['jianzhi_work_salary'] . $jianzhiJieSuanUnitArray[$tczhaopinInfo['jianzhi_work_salary_unit']], $shareTitle);
		} else {
			if ($tczhaopinInfo['work_salary'] == 999) {
				if ($tczhaopinInfo['work_salary_min'] == $tczhaopinInfo['work_salary_max']) {
					$shareTitle = str_replace('{SALARY}', $tczhaopinInfo['work_salary_min'], $shareTitle);
				} else {
					$shareTitle = str_replace('{SALARY}', $tczhaopinInfo['work_salary_min'] . '-' . $tczhaopinInfo['work_salary_max'], $shareTitle);
				}
			} else {
				$shareTitle = str_replace('{SALARY}', $workSalaryArray[$tczhaopinInfo['work_salary']], $shareTitle);
			}
		}
		if ($tczhaopinInfo['renshu'] > 0) {
			$shareTitle = str_replace('{RENSHU}', $tczhaopinInfo['renshu'], $shareTitle);
		} else {
			$shareTitle = str_replace('{RENSHU}', lang('plugin/tom_tczhaopin', 'ruogan'), $shareTitle);
		}
		$shareTitle = str_replace('{COMPANY}', $tczhaopinInfo['company_name'], $shareTitle);
		$shareTitle = str_replace('{AREANAME}', $areaInfo['name'], $shareTitle);
		$shareTitle = str_replace('{STREETNAME}', $streetInfo['name'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	$shareDesc = str_replace("\r\n", '', $tczhaopinInfo['demand_desc']);
	$shareDesc = str_replace("\n", '', $shareDesc);
	$shareDesc = str_replace("\r", '', $shareDesc);
	if (!empty($tczhaopinConfig['zhaopin_info_share_desc'])) {
		$shareDesc = $tczhaopinConfig['zhaopin_info_share_desc'];
		$shareDesc = str_replace('{TITLE}', $tczhaopinInfo['title'], $shareDesc);
		if ($tczhaopinInfo['type'] == 2 && $tczhaopinInfo['jianzhi_work_salary'] > 0) {
			$shareDesc = str_replace('{SALARY}', $tczhaopinInfo['jianzhi_work_salary'] . $jianzhiJieSuanUnitArray[$tczhaopinInfo['jianzhi_work_salary_unit']], $shareDesc);
		} else {
			if ($tczhaopinInfo['work_salary'] == 999) {
				if ($tczhaopinInfo['work_salary_min'] == $tczhaopinInfo['work_salary_max']) {
					$shareDesc = str_replace('{SALARY}', $tczhaopinInfo['work_salary_min'], $shareDesc);
				} else {
					$shareDesc = str_replace('{SALARY}', $tczhaopinInfo['work_salary_min'] . '-' . $tczhaopinInfo['work_salary_max'], $shareDesc);
				}
			} else {
				$shareDesc = str_replace('{SALARY}', $workSalaryArray[$tczhaopinInfo['work_salary']], $shareDesc);
			}
		}
		if ($tczhaopinInfo['renshu'] > 0) {
			$shareDesc = str_replace('{RENSHU}', $tczhaopinInfo['renshu'], $shareDesc);
		} else {
			$shareDesc = str_replace('{RENSHU}', lang('plugin/tom_tczhaopin', 'ruogan'), $shareDesc);
		}
		$shareDesc = str_replace('{COMPANY}', $tczhaopinInfo['company_name'], $shareDesc);
		$shareDesc = str_replace('{AREANAME}', $areaInfo['name'], $shareDesc);
		$shareDesc = str_replace('{STREETNAME}', $streetInfo['name'], $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	if (!empty($tczhaopinConfig['zhaopin_share_pic'])) {
		$shareLogo = $tczhaopinConfig['zhaopin_share_pic'];
	}
	if (!empty($zhaopinPhoto)) {
		$shareLogo = $zhaopinPhoto;
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=zhaopininfo&tczhaopin_id=' . $tczhaopin_id);
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$zhaopin_copy_text = '';
	$zhaopinSetting['zhaopin_copy_template'] = trim($zhaopinSetting['zhaopin_copy_template']);
	$zhaopinSetting['zhaopin_copy_shorturl'] = trim($zhaopinSetting['zhaopin_copy_shorturl']);
	if ($zhaopinSetting['open_zhaopin_copy'] == 1 && !empty($zhaopinSetting['zhaopin_copy_template'])) {
		$zhaopin_copy_text = $zhaopinSetting['zhaopin_copy_template'];
		$zhaopin_copy_text = str_replace("\r\n", '', $zhaopin_copy_text);
		$zhaopin_copy_text = str_replace("\n", '', $zhaopin_copy_text);
		$zhaopin_copy_text = str_replace('[N]', "\n", $zhaopin_copy_text);
		$zhaopin_copy_text = str_replace('{TITLE}', $tczhaopinInfo['title'], $zhaopin_copy_text);
		if ($tczhaopinInfo['type'] == 2 && $tczhaopinInfo['jianzhi_work_salary'] > 0) {
			$zhaopin_copy_text = str_replace('{SALARY}', $tczhaopinInfo['jianzhi_work_salary'] . $jianzhiJieSuanUnitArray[$tczhaopinInfo['jianzhi_work_salary_unit']], $zhaopin_copy_text);
		} else {
			if ($tczhaopinInfo['work_salary'] == 999) {
				if ($tczhaopinInfo['work_salary_min'] == $tczhaopinInfo['work_salary_max']) {
					$zhaopin_copy_text = str_replace('{SALARY}', $tczhaopinInfo['work_salary_min'], $zhaopin_copy_text);
				} else {
					$zhaopin_copy_text = str_replace('{SALARY}', $tczhaopinInfo['work_salary_min'] . '-' . $tczhaopinInfo['work_salary_max'], $zhaopin_copy_text);
				}
			} else {
				$zhaopin_copy_text = str_replace('{SALARY}', $workSalaryArray[$tczhaopinInfo['work_salary']], $zhaopin_copy_text);
			}
		}
		if ($tczhaopinInfo['renshu'] > 0) {
			$zhaopin_copy_text = str_replace('{RENSHU}', $tczhaopinInfo['renshu'], $zhaopin_copy_text);
		} else {
			$zhaopin_copy_text = str_replace('{RENSHU}', lang('plugin/tom_tczhaopin', 'ruogan'), $zhaopin_copy_text);
		}
		$zhaopin_copy_text = str_replace('{COMPANY}', $tczhaopinInfo['company_name'], $zhaopin_copy_text);
		$zhaopin_copy_text = str_replace('{ADDRESS}', $tczhaopinInfo['address'], $zhaopin_copy_text);
		$copyUrl = $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=zhaopininfo&tczhaopin_id=' . $tczhaopin_id);
		if (!empty($zhaopinSetting['zhaopin_copy_shorturl'])) {
			$copyUrl = $_G['siteurl'] . $zhaopinSetting['zhaopin_copy_shorturl'] . ('?s=' . $site_id . '&i=' . $tczhaopin_id);
		}
		$zhaopin_copy_text = str_replace('{LINK}', $copyUrl, $zhaopin_copy_text);
	}
	$messageUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&to_user_id=' . $tczhaopinInfo['user_id'] . '&formhash=' . FORMHASH . '&tczhaopin_id=' . $tczhaopin_id;
	$logoUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=personal';
	$zhaopinClicksUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=zhaopinClicks&tczhaopin_id=' . $tczhaopin_id . '&formhash=' . $formhash;
	$shenqingAjaxUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=shenqingZhaopin&tczhaopin_id=' . $tczhaopin_id . '&user_id=' . $__UserInfo['id'] . '&formhash=' . $formhash;
	$collectAjaxUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=collectZhaopin&tczhaopin_id=' . $tczhaopin_id . '&user_id=' . $__UserInfo['id'] . '&formhash=' . $formhash;
	$ajaxMeetingClicksUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=meetinginfo_clicks&meeting_id=' . $meeting_click_id . '&formhash=' . $formhash;
	if ($tczhaopinConfig['zhaopininfo_tuijian_type'] == 1) {
		$ajaxListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=zhaopinlist&no_tczhaopin_id=' . $tczhaopinInfo['id'] . '&cate_id=' . $tczhaopinInfo['cate_id'] . '&formhash=' . $formhash;
	} elseif ($tczhaopinConfig['zhaopininfo_tuijian_type'] == 2) {
		$ajaxListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=zhaopinlist&no_tczhaopin_id=' . $tczhaopinInfo['id'] . '&cate_id=' . $tczhaopinInfo['cate_id'] . '&cate_child_id=' . $tczhaopinInfo['cate_child_id'] . '&formhash=' . $formhash;
	} elseif ($tczhaopinConfig['zhaopininfo_tuijian_type'] == 3) {
		$ajaxListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=zhaopinlist&no_tczhaopin_id=' . $tczhaopinInfo['id'] . '&user_id=' . $tczhaopinInfo['user_id'] . '&formhash=' . $formhash;
	}
	$ajaxTuiDoTzUrl = '';
	if ($__ShowTchehuoren == 1 && file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tui_do.php')) {
		include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tui_do.php';
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tczhaopin:zhaopininfo');
} elseif ($_GET['mod'] == 'zhaopinjubao') {
	$tczhaopin_id = intval($_GET['tczhaopin_id']) > 0 ? intval($_GET['tczhaopin_id']) : 0;
	$tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);
	$areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tczhaopinInfo['area_id']);
	$streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tczhaopinInfo['street_id']);
	$uploadUrl = 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=upload&act=jubao_picurl&formhash=' . $formhash;
	$ajaxSaveUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=jubao_save&formhash=' . $formhash;
	$jumpUrl = 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&act=zhaopininfo&tczhaopin_id=' . $tczhaopin_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tczhaopin:zhaopinjubao');
} elseif ($_GET['mod'] == 'resumelist') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$sex = intval($_GET['sex']) > 0 ? intval($_GET['sex']) : 0;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$work_status = intval($_GET['work_status']) > 0 ? intval($_GET['work_status']) : 0;
	$xueli = intval($_GET['xueli']) > 0 ? intval($_GET['xueli']) : 0;
	$refresh_type = intval($_GET['refresh_type']) > 0 ? intval($_GET['refresh_type']) : 0;
	$jingyan = intval($_GET['jingyan']) > 0 ? intval($_GET['jingyan']) : 0;
	$cateName = '';
	$cateList = array();
	$cateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(' AND pid = 0 ', 'ORDER BY csort ASC,id DESC', 0, 100);
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			if ($cate_id == $value['id']) {
				$cateName = $value['name'];
			}
		}
	}
	if ($cate_child_id > 0) {
		$cateChildInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_child_id);
		if ($cateChildInfo['id'] > 0) {
			$cate_id = $cateChildInfo['pid'];
		}
	}
	if ($cate_id > 0) {
		$cateChildListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(' AND pid = ' . $cate_id . ' ', 'ORDER BY csort ASC,id DESC', 0, 100);
		$cateChildList = array();
		if (is_array($cateChildListTmp) && !empty($cateChildListTmp)) {
			foreach ($cateChildListTmp as $key => $value) {
				$cateChildList[$key] = $value;
				if ($cate_child_id == $value['id']) {
					$cateName = $value['name'];
				}
			}
		}
	}
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$areaList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$whereStr = ' AND status=1 AND shenhe_status=1 AND gongkai_status = 1 ';
	if (!empty($sql_in_site_ids)) {
		$whereStr .= ' AND site_id IN(' . $sql_in_site_ids . ') ';
	}
	if ($cate_id > 0) {
		$whereStr .= ' AND cate_id = ' . $cate_id . ' ';
	}
	$cate_child_search = '';
	if ($cate_child_id > 0) {
		$cate_child_search = '-' . $cate_child_id . '-';
	}
	$resumeCount = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count($whereStr, $cate_child_search);
	$list_cate_name = $tczhaopinConfig['resume_list_cate_name'];
	if ($cate_id > 0) {
		$list_cate_name = $cateName;
	}
	if (!empty($tczhaopinConfig['resume_list_share_title'])) {
		$shareTitle = $tczhaopinConfig['resume_list_share_title'];
		$shareTitle = str_replace('{CATENAME}', $list_cate_name, $shareTitle);
		$shareTitle = str_replace('{NUM}', $resumeCount, $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tczhaopinConfig['resume_list_share_desc'])) {
		$shareDesc = $tczhaopinConfig['resume_list_share_desc'];
		$shareDesc = str_replace('{CATENAME}', $list_cate_name, $shareDesc);
		$shareDesc = str_replace('{NUM}', $resumeCount, $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	if (!empty($tczhaopinConfig['resume_share_pic'])) {
		$shareLogo = $tczhaopinConfig['resume_share_pic'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=resumelist&area_id=' . $area_id . '&street_id=' . $street_id . '&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&keyword=') . urlencode(trim($keyword));
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=resumelist&keyword=' . $keyword . '&area_id=' . $area_id . '&street_id=' . $street_id . '&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&sex=' . $sex . '&type=' . $type . '&work_status=' . $work_status . '&xueli=' . $xueli . '&refresh_type=' . $refresh_type . '&jingyan=' . $jingyan));
	$searchUrl = 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=resumesearch&';
	$resumelistUrl = 'plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=resumelist&';
	$ajaxLoadCateListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=load_cate_list&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$ajaxListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=resumelist&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tczhaopin:resumelist');
} elseif ($_GET['mod'] == 'resumesearch') {
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$salary = intval($_GET['salary']) > 0 ? intval($_GET['salary']) : 0;
	$welfare = isset($_GET['welfare']) ? daddslashes($_GET['welfare']) : '';
	$jingyan = intval($_GET['jingyan']) > 0 ? intval($_GET['jingyan']) : 0;
	$scale_id = intval($_GET['scale_id']) > 0 ? intval($_GET['scale_id']) : 0;
	$nature_id = intval($_GET['nature_id']) > 0 ? intval($_GET['nature_id']) : 0;
	$company_renzheng_status = intval($_GET['company_renzheng_status']) > 0 ? intval($_GET['company_renzheng_status']) : 0;
	$sex = intval($_GET['sex']) > 0 ? intval($_GET['sex']) : 0;
	$xueli = intval($_GET['xueli']) > 0 ? intval($_GET['xueli']) : 0;
	$searchArr = array();
	$resumeSearchArr = explode('|', $tczhaopinConfig['resume_search_str']);
	if (is_array($resumeSearchArr) && !empty($resumeSearchArr)) {
		foreach ($resumeSearchArr as $key => $value) {
			$searchArr[] = daddslashes($value);
		}
	}
	$searchCount = count($searchArr);
	$ajaxSearchUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=get_resume_search_url&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tczhaopin:resumesearch');
} elseif ($_GET['mod'] == 'resumeinfo') {
	$resume_id = intval($_GET['resume_id']) > 0 ? intval($_GET['resume_id']) : 0;
	$sq_tczhaopin_id = intval($_GET['sq_tczhaopin_id']) > 0 ? intval($_GET['sq_tczhaopin_id']) : 0;
	$resumeInfo = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($resume_id);
	if (!is_array($resumeInfo) || empty($resumeInfo) || $resumeInfo['shenhe_status'] != 1 || $resumeInfo['deleted'] != 0) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($resumeInfo['cate_id']);
	$areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($resumeInfo['area_id']);
	$streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($resumeInfo['street_id']);
	if (!empty($resumeInfo['avatar'])) {
		if (!preg_match('/^http/', $resumeInfo['avatar'])) {
			if (strpos($resumeInfo['avatar'], 'source/plugin/tom_') === false) {
				$avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $resumeInfo['avatar'];
			} else {
				$avatar = $_G['siteurl'] . $resumeInfo['avatar'];
			}
		} else {
			$avatar = $resumeInfo['avatar'];
		}
	} else {
		if ($resumeInfo['sex'] == 1) {
			$avatar = $_G['siteurl'] . $man_resume_avatar;
		} elseif ($resumeInfo['sex'] == 2) {
			$avatar = $_G['siteurl'] . $woman_resume_avatar;
		}
	}
	if ($resumeInfo['video_status'] == 1) {
		$video_pic = '';
		if (!preg_match('/^http/', $resumeInfo['video_pic'])) {
			if (strpos($resumeInfo['video_pic'], 'source/plugin/tom_') === false) {
				$video_pic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $resumeInfo['video_pic'];
			} else {
				$video_pic = $resumeInfo['video_pic'];
			}
		} else {
			$video_pic = $resumeInfo['video_pic'];
		}
	}
	$shortname = cutstr($resumeInfo['name'], 2, '');
	$age = dgmdate(TIMESTAMP, 'Y', $tomSysOffset) - $resumeInfo['birth_year'];
	$resumeInfo['cate_child_str'] = str_replace(',', lang('plugin/tom_tczhaopin', 'resumeinfo_dian'), $resumeInfo['cate_child_str']);
	$work_jingli = str_replace("\r\n", '<br/>', $resumeInfo['work_jingli']);
	$work_jingli = str_replace("\n", '<br/>', $work_jingli);
	$work_jingli = str_replace("\r", '<br/>', $work_jingli);
	$work_jingli = preg_replace('/\\d{7}/', '*****', $work_jingli);
	$edu_jingli = str_replace("\r\n", '<br/>', $resumeInfo['edu_jingli']);
	$edu_jingli = str_replace("\n", '<br/>', $edu_jingli);
	$edu_jingli = str_replace("\r", '<br/>', $edu_jingli);
	$edu_jingli = preg_replace('/\\d{7}/', '*****', $edu_jingli);
	$describe = str_replace("\r\n", '<br/>', $resumeInfo['describe']);
	$describe = str_replace("\n", '<br/>', $describe);
	$describe = str_replace("\r", '<br/>', $describe);
	$describe = preg_replace('/\\d{7}/', '*****', $describe);
	$lastMonthTime = TIMESTAMP - 30 * 86400;
	$toudiCount = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_count(' AND resume_id = ' . $resume_id . ' AND add_time > ' . $lastMonthTime . ' ');
	$personalRenzhengStatus = 0;
	$renzhengPersonalInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_all_list(' AND user_id = ' . $resumeInfo['user_id'] . ' AND shenhe_status = 1 ', 'ORDER BY id DESC', 0, 1);
	if (is_array($renzhengPersonalInfoTmp) && !empty($renzhengPersonalInfoTmp[0])) {
		$personalRenzhengStatus = 1;
	}
	$companyRenzhengStatus = 0;
	$resumePayStatus = $showCollectStatus = 1;
	$shenyuVipResumeNum = 0;
	if ($__UserInfo['id'] > 0) {
		if ($resumeInfo['user_id'] != $__UserInfo['id']) {
			$rzCompanyInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_list('AND user_id = ' . $__UserInfo['id'] . ' AND shenhe_status = 1 ', 'ORDER BY id DESC', 0, 1);
			if (is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])) {
				$companyRenzhengStatus = 1;
			}
			if ($resumePayStatus == 1) {
				$userLogCount = C::t('#tom_tczhaopin#tom_tczhaopin_log')->fetch_all_count(' AND user_id=' . $__UserInfo['id'] . ' AND type = 3 AND deduct_type = 1 ');
				if ($companyRenzhengStatus == 1) {
					$freeResumeNum = $tczhaopinConfig['company_free_resume_num'];
				} else {
					$freeResumeNum = $tczhaopinConfig['personal_free_resume_num'];
				}
				if ($freeResumeNum > $userLogCount) {
					$resumePayStatus = 2;
				}
			}
			if ($resumePayStatus == 1) {
				$userVipInfo = C::t('#tom_tczhaopin#tom_tczhaopin_user_vip')->fetch_by_user_id($__UserInfo['id']);
				if ($userVipInfo['vip_id'] > 0 && $userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP) {
					$vipInfo = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_by_id($userVipInfo['vip_id']);
					$userVipLogCount = C::t('#tom_tczhaopin#tom_tczhaopin_log')->fetch_all_count(' AND user_id=' . $__UserInfo['id'] . ' AND type = 3 AND deduct_type = 2');
					if ($vipInfo['resume_num'] > $userVipLogCount) {
						$resumePayStatus = 3;
						$shenyuVipResumeNum = $vipInfo['resume_num'] - $userVipLogCount;
					}
				}
			}
			if ($resumePayStatus == 1 && $tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0) {
				$scorePayNum = ceil(floatval($tczhaopinConfig['shoufei_resume_price']) * $tongchengConfig['pay_score_yuan']);
				if ($__UserInfo['score'] >= $scorePayNum) {
					$resumePayStatus = 4;
				}
			}
			if ($tczhaopinConfig['show_resume_must_fabu'] == 1) {
				$fabuZhaopinCount = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count(' AND shenhe_status = 1 AND status = 1 AND expire_status != 2 AND user_id = ' . $__UserInfo['id'] . ' ');
				if ($fabuZhaopinCount == 0) {
					$resumePayStatus = 5;
					$fabuZhaopinCount = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count(' AND user_id = ' . $__UserInfo['id'] . ' AND expire_status != 2 ');
					if ($fabuZhaopinCount > 0) {
						$resumePayStatus = 6;
					}
				}
			}
			$rencaiInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND resume_id = ' . $resume_id . ' ', 'ORDER BY id DESC', 0, 1);
			if (is_array($rencaiInfoTmp) && $rencaiInfoTmp[0]['id'] > 0) {
				$resumePayStatus = 0;
			}
			$historyListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_history')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND resume_id = ' . $resume_id . ' ', 'ORDER BY id DESC', 0, 1);
			if (!is_array($historyListTmp) || $historyListTmp[0]['id'] <= 0) {
				$insertData = array();
				$insertData['user_id'] = $__UserInfo['id'];
				$insertData['resume_id'] = $resume_id;
				$insertData['add_time'] = TIMESTAMP;
				C::t('#tom_tczhaopin#tom_tczhaopin_history')->insert($insertData);
			}
		} else {
			$resumePayStatus = 0;
		}
		$shenqingInfo = array();
		$shenqingInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_list(' AND t.resume_id = ' . $resume_id . ' AND z.user_id = ' . $__UserInfo['id'] . ' AND t.tczhaopin_id = ' . $sq_tczhaopin_id . ' ', 'ORDER BY t.id DESC', 0, 1);
		if (is_array($shenqingInfoTmp) && !empty($shenqingInfoTmp[0])) {
			$shenqingInfo = $shenqingInfoTmp[0];
			if ($shenqingInfo['status'] == 0) {
				$updateData = array();
				$updateData['status'] = 1;
				C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->update($shenqingInfo['id'], $updateData);
			}
		}
		if ($resumeInfo['gongkai_status'] == 0) {
			if ($resumeInfo['user_id'] != $__UserInfo['id']) {
				if ((!$shenqingInfo || $shenqingInfo['id'] <= 0) && (!is_array($rencaiInfoTmp) || $rencaiInfoTmp[0]['id'] <= 0)) {
					tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=index'));
					exit(0);
				}
			}
		}
		$collectInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume_collect')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' AND resume_id = ' . $resume_id);
		if (is_array($collectInfoTmp) && !empty($collectInfoTmp[0])) {
			$showCollectStatus = 2;
		}
	} else {
		if ($resumeInfo['gongkai_status'] == 0) {
			tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=index'));
			exit(0);
		}
	}
	$sex_call = '';
	if ($resumeInfo['sex'] == 1) {
		$sex_call = lang('plugin/tom_tczhaopin', 'resumelist_sex_1_call');
	} elseif ($resumeInfo['sex'] == 2) {
		$sex_call = lang('plugin/tom_tczhaopin', 'resumelist_sex_2_call');
	}
	$resume_name = cutstr($resumeInfo['name'], 2, '') . $sex_call;
	$shareTitle = $resume_name;
	if (!empty($tczhaopinConfig['resume_info_share_title'])) {
		$shareTitle = $tczhaopinConfig['resume_info_share_title'];
		$shareTitle = str_replace('{NAME}', $resume_name, $shareTitle);
		$shareTitle = str_replace('{JINGYAN}', $workJingyanArray[$resumeInfo['work_jingyan']], $shareTitle);
		$shareTitle = str_replace('{WORKER}', $resumeInfo['cate_child_str'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tczhaopinConfig['resume_info_share_desc'])) {
		$shareDesc = $tczhaopinConfig['resume_info_share_desc'];
		$shareDesc = str_replace('{NAME}', $resume_name, $shareDesc);
		$shareDesc = str_replace('{JINGYAN}', $workJingyanArray[$resumeInfo['work_jingyan']], $shareDesc);
		$shareDesc = str_replace('{WORKER}', $resumeInfo['cate_child_str'], $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	$shareLogo = $avatar;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=resumeinfo&resume_id=' . $resume_id);
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$messageUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&to_user_id=' . $resumeInfo['user_id'] . '&formhash=' . FORMHASH;
	$logoUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=my';
	$payLookResumeUrl = 'plugin.php?id=tom_tczhaopin:pay&site=' . $site_id . '&user_id=' . $__UserInfo['id'] . '&resume_id=' . $resume_id . '&act=pay_look_resume&formhash=' . $formhash;
	$resumeClicksUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=resumeClicks&resume_id=' . $resume_id . '&formhash=' . $formhash;
	$collectAjaxUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=collectResume&resume_id=' . $resume_id . '&user_id=' . $__UserInfo['id'] . '&formhash=' . $formhash;
	$ajaxResumeLookUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=resumeLook&resume_id=' . $resume_id . '&user_id=' . $__UserInfo['id'] . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tczhaopin:resumeinfo');
} elseif ($_GET['mod'] == 'companylist') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$industry_id = intval($_GET['industry_id']) > 0 ? intval($_GET['industry_id']) : 0;
	$selectIndustryName = '';
	$industryListTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_all_list('', 'ORDER BY isort ASC,id DESC', 0, 100);
	$industryList = array();
	if (is_array($industryListTmp) && !empty($industryListTmp)) {
		foreach ($industryListTmp as $key => $value) {
			$industryList[$key] = $value;
			if ($industry_id > 0 && $industry_id == $value['id']) {
				$selectIndustryName = $value['name'];
			}
		}
	}
	$whereStr = ' AND c.show_status=1 AND r.shenhe_status = 1 ';
	if (!empty($sql_in_site_ids)) {
		$whereStr .= ' AND c.site_id IN(' . $sql_in_site_ids . ') ';
	}
	$companyCount = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_all_company_rzcompany_count($whereStr);
	if (!empty($tczhaopinConfig['company_list_share_title'])) {
		$shareTitle = $tczhaopinConfig['company_list_share_title'];
		$shareTitle = str_replace('{NUM}', $companyCount, $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tczhaopinConfig['company_list_share_desc'])) {
		$shareDesc = $tczhaopinConfig['company_list_share_desc'];
		$shareDesc = str_replace('{NUM}', $companyCount, $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	if (!empty($tczhaopinConfig['company_share_pic'])) {
		$shareLogo = $tczhaopinConfig['company_share_pic'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=companylist&industry_id=' . $industry_id);
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$ajaxListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=companylist&industry_id=' . $industry_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tczhaopin:companylist');
} elseif ($_GET['mod'] == 'companyinfo') {
	$company_id = intval($_GET['company_id']) > 0 ? intval($_GET['company_id']) : 0;
	$meeting_click_id = intval($_GET['meeting_click_id']) > 0 ? intval($_GET['meeting_click_id']) : 0;
	$companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($company_id);
	if (!is_array($companyInfo) || empty($companyInfo)) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$renzhengCompanyInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($companyInfo['renzheng_company_id']);
	if (!is_array($renzhengCompanyInfo) || empty($renzhengCompanyInfo)) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$companyInfo = update_company_status($companyInfo);
	$renzhengNatureInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_nature')->fetch_by_id($renzhengCompanyInfo['nature_id']);
	$renzhengScaleInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_scale')->fetch_by_id($renzhengCompanyInfo['scale_id']);
	$renzhengIndustryInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_by_id($renzhengCompanyInfo['industry_id']);
	if (!preg_match('/^http/', $renzhengCompanyInfo['logo'])) {
		if (strpos($renzhengCompanyInfo['logo'], 'source/plugin/tom_') === false) {
			$renzhengCompanyLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $renzhengCompanyInfo['logo'];
		} else {
			$renzhengCompanyLogo = $_G['siteurl'] . $renzhengCompanyInfo['logo'];
		}
	} else {
		$renzhengCompanyLogo = $renzhengCompanyInfo['logo'];
	}
	$renzhengCompanyInfo['content'] = stripslashes($renzhengCompanyInfo['content']);
	$renzhengPhotoListTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company_photo')->fetch_all_list(' AND company_id = ' . $renzhengCompanyInfo['id'] . ' ', 'ORDER BY id ASC', 0, 10);
	$renzhengPhotoList = array();
	if (is_array($renzhengPhotoListTmp) && !empty($renzhengPhotoListTmp)) {
		foreach ($renzhengPhotoListTmp as $key => $value) {
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$renzhengPhotoList[] = $picurlTmp;
		}
	}
	$renzhengPhotoStr = implode('|', $renzhengPhotoList);
	$renzhengPhotoCount = count($renzhengPhotoList);
	$tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND company_id=' . $company_id . ' ', ' ORDER BY top_status DESC,refresh_time DESC,id DESC ', 0, 3, '');
	if (is_array($tczhaopinListTmp) && !empty($tczhaopinListTmp)) {
		foreach ($tczhaopinListTmp as $key => $value) {
			$tczhaopinList[$key] = $value;
			$areaInfoTmp = $streetInfoTmp = array();
			if ($value['area_id'] > 0) {
				$areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
				$streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
			}
			$tczhaopinList[$key]['areaInfo'] = $areaInfoTmp;
			$tczhaopinList[$key]['streetInfo'] = $streetInfoTmp;
		}
	}
	$focuspicListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' AND type = 4 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_focuspic')->fetch_all_list(' AND site_id=1 AND type = 4 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	if (is_array($focuspicListTmp) && !empty($focuspicListTmp)) {
		foreach ($focuspicListTmp as $key => $value) {
			$focuspicList[$key] = $value;
			$focuspicList[$key]['link'] = str_replace('{site}', $site_id, $focuspicList[$key]['link']);
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$focuspicList[$key]['picurl'] = $picurl;
		}
	}
	$myResumeCount = $myResumeShenheCount = 0;
	if ($__UserInfo['id'] > 0) {
		$myResumeCount = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count(' AND user_id=' . $__UserInfo['id'] . ' AND shenhe_status = 1 ');
		$myResumeShenheCount = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count(' AND user_id=' . $__UserInfo['id'] . ' AND (shenhe_status = 2 OR shenhe_status = 3) ');
	}
	$shenqingStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$tczhaopinIdsList = array();
		$tczhaopinIdsListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list_ids(' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND company_id=' . $company_id . ' ', ' ORDER BY id DESC ', 0, 1000);
		if (is_array($tczhaopinIdsListTmp) && !empty($tczhaopinIdsListTmp)) {
			foreach ($tczhaopinIdsListTmp as $key => $value) {
				$tczhaopinIdsList[] = $value['id'];
			}
		}
		if (is_array($tczhaopinIdsList) && !empty($tczhaopinIdsList)) {
			$shenqingListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_list(' AND tczhaopin_id IN (' . implode(',', $tczhaopinIdsList) . (') AND user_id = ' . $__UserInfo['id'] . ' '), ' ORDER BY id DESC ', 0, 1);
			if (is_array($shenqingListTmp) && !empty($shenqingListTmp['0'])) {
				$shenqingStatus = 1;
			}
		}
	}
	$allowTel = 1;
	if ($tczhaopinConfig['must_tel_resume'] == 1 && $myResumeCount == 0) {
		$allowTel = 2;
	}
	if ($allowTel == 2 && $myResumeShenheCount > 0) {
		$allowTel = 3;
	}
	if ($allowTel == 1 && $tczhaopinConfig['must_tel_sq_resume'] == 1 && $shenqingStatus != 1) {
		$allowTel = 4;
	}
	$shareTitle = $renzhengCompanyInfo['name'];
	if (!empty($tczhaopinConfig['company_info_share_title'])) {
		$shareTitle = $tczhaopinConfig['company_info_share_title'];
		$shareTitle = str_replace('{NAME}', $renzhengCompanyInfo['name'], $shareTitle);
		$shareTitle = str_replace('{NUM}', $companyInfo['num'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tczhaopinConfig['company_info_share_desc'])) {
		$shareDesc = $tczhaopinConfig['company_info_share_desc'];
		$shareDesc = str_replace('{NAME}', $renzhengCompanyInfo['name'], $shareDesc);
		$shareDesc = str_replace('{NUM}', $companyInfo['num'], $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	$shareLogo = $renzhengCompanyLogo;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=companyinfo&company_id=' . $company_id);
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	if ($meeting_click_id > 0) {
		$ajaxListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=zhaopinlist&company_id=' . $company_id . '&meeting_click_id=' . $meeting_click_id . '&formhash=' . $formhash;
	} else {
		$ajaxListUrl = 'plugin.php?id=tom_tczhaopin:ajax&site=' . $site_id . '&act=zhaopinlist&company_id=' . $company_id . '&formhash=' . $formhash;
	}
	$messageUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&to_user_id=' . $companyInfo['user_id'] . '&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tczhaopin:companyinfo');
} elseif ($_GET['mod'] == 'meeting') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/meeting.php';
} elseif ($_GET['mod'] == 'meetinginfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/meetinginfo.php';
} elseif ($_GET['mod'] == 'meetinginfosearchlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/meetinginfosearchlist.php';
} elseif ($_GET['mod'] == 'baidumap') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/baidumap.php';
} elseif ($_GET['mod'] == 'my') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/my.php';
} elseif ($_GET['mod'] == 'vip') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/vip.php';
} elseif ($_GET['mod'] == 'myresumelist') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/myresumelist.php';
} elseif ($_GET['mod'] == 'buyresume') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/buyresume.php';
} elseif ($_GET['mod'] == 'myzhaopinlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/myzhaopinlist.php';
} elseif ($_GET['mod'] == 'buyzhaopin') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/buyzhaopin.php';
} elseif ($_GET['mod'] == 'buyxufeizhaopin') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/buyxufeizhaopin.php';
} elseif ($_GET['mod'] == 'zpshenqinglist') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/zpshenqinglist.php';
} elseif ($_GET['mod'] == 'daozpshenqinglist') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/daozpshenqinglist.php';
} elseif ($_GET['mod'] == 'myshenqinglist') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/myshenqinglist.php';
} elseif ($_GET['mod'] == 'rencailist') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/rencailist.php';
} elseif ($_GET['mod'] == 'daorencai') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/daorencai.php';
} elseif ($_GET['mod'] == 'historylist') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/historylist.php';
} elseif ($_GET['mod'] == 'mydingyuelist') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/mydingyuelist.php';
} elseif ($_GET['mod'] == 'resumecollect') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/resumecollect.php';
} elseif ($_GET['mod'] == 'zhaopincollect') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/zhaopincollect.php';
} elseif ($_GET['mod'] == 'buycompany') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/buycompany.php';
} elseif ($_GET['mod'] == 'managerList') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/managerList.php';
} elseif ($_GET['mod'] == 'managerResumeList') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/managerResumeList.php';
} elseif ($_GET['mod'] == 'fabuzhaopin') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/fabuzhaopin.php';
} elseif ($_GET['mod'] == 'editzhaopin') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/editzhaopin.php';
} elseif ($_GET['mod'] == 'faburesume') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/faburesume.php';
} elseif ($_GET['mod'] == 'editresume') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/editresume.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/upload.php';
} elseif ($_GET['mod'] == 'mianshi') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/mianshi.php';
} elseif ($_GET['mod'] == 'mianshilist') {
	include DISCUZ_ROOT . './source/plugin/tom_tczhaopin/module/mianshilist.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tczhaopin&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();