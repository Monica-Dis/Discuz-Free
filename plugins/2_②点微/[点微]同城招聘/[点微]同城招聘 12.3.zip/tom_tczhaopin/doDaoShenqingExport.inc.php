<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
$tomSysOffset = getglobal('setting/timeoffset');

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.utf.php';
}
$welfareArray = array();
$welfare_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['welfare_list']); 
$welfare_list_str = str_replace("\n","{n}",$welfare_list_str);
$welfare_list_arr = explode("{n}", $welfare_list_str);
if(is_array($welfare_list_arr) && !empty($welfare_list_arr)){
    foreach ($welfare_list_arr as $key => $value){
        $welfare_list_item = explode("|", $value);
        $welfare_list_item_id = intval($welfare_list_item[0]);
        $welfare_list_item_name = trim($welfare_list_item[1]);
        if($welfare_list_item_id > 0 && !empty($welfare_list_item_name)){
            $welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
        }
    }
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$resume_default_avatar = explode("|", $tczhaopinConfig['resume_default_avatar']);
$man_resume_avatar = "source/plugin/tom_tczhaopin/images/resume_avatar/".$resume_default_avatar[0];
$woman_resume_avatar = "source/plugin/tom_tczhaopin/images/resume_avatar/".$resume_default_avatar[1];

$page        = isset($_GET['page'])? intval($_GET['page']):1;
$type        = isset($_GET['type'])? intval($_GET['type']):0;
$from        = isset($_GET['from'])? addslashes($_GET['from']):'';

if($__UserInfo['id'] > 0){
    
    $zhaopinIdsListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list_ids(" AND user_id = {$__UserInfo['id']} AND shenhe_status = 1 AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1000);
    $zhaopinIdsList = array();
    if(is_array($zhaopinIdsListTmp) && !empty($zhaopinIdsListTmp)){
        foreach($zhaopinIdsListTmp as $key => $value){
            $zhaopinIdsList[] = $value['id'];
        }
    }
    
    if(!empty($zhaopinIdsList)){
        $zhaopinIdsStr = implode(',', $zhaopinIdsList);
        $where = " AND tczhaopin_id IN ({$zhaopinIdsStr})";
    }else{
        $where = " AND tczhaopin_id = 999999999999999999 ";
    }
    
    if($type == 1){
        $where .= " AND status = 1 ";
    }else if($type == 2){
        $where .= " AND status = 0 ";
    }

    $order = " ORDER BY add_time DESC,id DESC ";

    $pagesize = 1000;
    $start = ($page-1)*$pagesize;
    
    $shenqingListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_list($where,$order,$start,$pagesize);
    $shenqingList = array();
    foreach ($shenqingListTmp as $key => $value) {
        $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($value['tczhaopin_id']);
        $resumeInfo = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($value['resume_id']);
        if($tczhaopinInfo['shenhe_status'] == 1 && $resumeInfo['shenhe_status'] == 1 && $resumeInfo['deleted'] == 0){
            $shenqingList[$key] = $value;
            $shenqingList[$key]['tczhaopinInfo'] = $tczhaopinInfo;
            $shenqingList[$key]['resumeInfo'] = $resumeInfo;
            
            $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($resumeInfo['cate_id']);
            $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($resumeInfo['area_id']);
            $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($resumeInfo['street_id']);

            $resumeList[$key]['name'] = $value['name'];

            if(!empty($resumeInfo['avatar'])){
                if(!preg_match('/^http/', $resumeInfo['avatar'])){
                    if(strpos($resumeInfo['avatar'], 'source/plugin/tom_') === FALSE){
                        $avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$resumeInfo['avatar'];
                    }else{
                        $avatar = $_G['siteurl'].$resumeInfo['avatar'];
                    }
                }else{
                    $avatar = $resumeInfo['avatar'];
                }
            }else{
                if($resumeInfo['sex'] == 1){
                    $avatar = $man_resume_avatar;
                }else if($resumeInfo['sex'] == 2){
                    $avatar = $woman_resume_avatar;
                }
            }
            
            $shenqingList[$key]['resumeInfo']['avatar'] = $avatar;

            if($resumeInfo['work_salary'] > 1){
                $shenqingList[$key]['resumeInfo']['work_salary'] = $workSalaryArray[$resumeInfo['work_salary']].lang('plugin/tom_tczhaopin', 'doDao_yuan');
            }else{
                $shenqingList[$key]['resumeInfo']['work_salary'] = $workSalaryArray[$resumeInfo['work_salary']];
            }
            $shenqingList[$key]['resumeInfo']['work_jingyan']   = $workJingyanArray[$resumeInfo['work_jingyan']];
            $shenqingList[$key]['resumeInfo']['resume_cate']    = $cateInfo['name'].'/'.$resumeInfo['cate_child_str'];
            $shenqingList[$key]['resumeInfo']['age']            = dgmdate(TIMESTAMP,"Y",$tomSysOffset) - $resumeInfo['birth_year'];
            $shenqingList[$key]['resumeInfo']['xueli']          = $xueliArray[$resumeInfo['xueli']];
            $shenqingList[$key]['resumeInfo']['marital']        = lang('plugin/tom_tczhaopin', 'doDao_resume_marital_'.$resumeInfo['marital']);
            if($resumeInfo['area_id'] > 0 && $resumeInfo['street_id'] > 0){
                $shenqingList[$key]['resumeInfo']['resume_location']    = $areaInfoTmp['name'].'-'.$streetInfoTmp['name'];
            }else{
                $shenqingList[$key]['resumeInfo']['resume_location']    = $areaInfoTmp['name'];
            }
        }
        
    }
    
    $zhaopin_title      = lang('plugin/tom_tczhaopin','doDao_zhaopin');
    $name               = lang('plugin/tom_tczhaopin','doDao_name');
    $avatar             = lang('plugin/tom_tczhaopin','doDao_avatar');
    $age                = lang('plugin/tom_tczhaopin','doDao_resume_age');
    $marital            = lang('plugin/tom_tczhaopin','doDao_resume_marital');
    $xueli              = lang('plugin/tom_tczhaopin','doDao_resume_xueli');
    $resume_cate        = lang('plugin/tom_tczhaopin','doDao_resume_cate');
    $resume_location    = lang('plugin/tom_tczhaopin','doDao_resume_location');
    $work_salary        = lang('plugin/tom_tczhaopin','doDao_resume_salary');
    $tel                = lang('plugin/tom_tczhaopin','doDao_resume_tel');
    $work_jingyan       = lang('plugin/tom_tczhaopin','doDao_resume_jinyan');
    $work_jingli        = lang('plugin/tom_tczhaopin','doDao_resume_work_jingli');
    $edu_jingli         = lang('plugin/tom_tczhaopin','doDao_resume_edu_jingli');
    $describe           = lang('plugin/tom_tczhaopin','doDao_resume_describe');
    $video_url          = lang('plugin/tom_tczhaopin','doDao_resume_video_url');
    
    
    $listData[] = array(
        $zhaopin_title,
        $name,
        $avatar,
        $age,
        $marital,
        $xueli,
        $resume_cate,
        $resume_location,
        $work_salary,
        $tel,
        $work_jingyan,
        $work_jingli,
        $edu_jingli,
        $describe,
        $video_url
    ); 
    foreach ($shenqingList as $v){
        
        $v['resumeInfo']['work_jingli'] = str_replace("\r\n","",$v['resumeInfo']['work_jingli']);
        $v['resumeInfo']['work_jingli'] = str_replace("\n","",$v['resumeInfo']['work_jingli']);
        $v['resumeInfo']['work_jingli'] = str_replace("\r","",$v['resumeInfo']['work_jingli']);
        
        $v['resumeInfo']['edu_jingli'] = str_replace("\r\n","",$v['resumeInfo']['edu_jingli']);
        $v['resumeInfo']['edu_jingli'] = str_replace("\n","",$v['resumeInfo']['edu_jingli']);
        $v['resumeInfo']['edu_jingli'] = str_replace("\r","",$v['resumeInfo']['edu_jingli']);
        
        $v['resumeInfo']['describe'] = str_replace("\r\n","",$v['resumeInfo']['describe']);
        $v['resumeInfo']['describe'] = str_replace("\n","",$v['resumeInfo']['describe']);
        $v['resumeInfo']['describe'] = str_replace("\r","",$v['resumeInfo']['describe']);
        
        $lineData = array();
        $lineData[] = $v['tczhaopinInfo']['title'];
        $lineData[] = $v['resumeInfo']['name'];
        $lineData[] = $v['resumeInfo']['avatar'];
        $lineData[] = $v['resumeInfo']['age'];
        $lineData[] = $v['resumeInfo']['marital'];
        $lineData[] = $v['resumeInfo']['xueli'];
        $lineData[] = $v['resumeInfo']['resume_cate'];
        $lineData[] = $v['resumeInfo']['resume_location'];
        $lineData[] = $v['resumeInfo']['work_salary'];
        $lineData[] = $v['resumeInfo']['tel'].',';
        $lineData[] = $v['resumeInfo']['work_jingyan'];
        $lineData[] = $v['resumeInfo']['work_jingli'];
        $lineData[] = $v['resumeInfo']['edu_jingli'];
        $lineData[] = $v['resumeInfo']['describe'];
        $lineData[] = $v['resumeInfo']['video_url'];
        
        $listData[] = $lineData;
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=shenqingExportResume.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}