<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);
$tczhaopinConfig    = $_G['cache']['plugin']['tom_tczhaopin'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);

if('utf-8' != CHARSET) {
    if(defined('IN_MOBILE')) {}else{
        foreach($_POST AS $pk => $pv) {
            if(!is_numeric($pv)) {
                $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
            }
        }
    }
}

$share_url      = isset($_GET['share_url'])? daddslashes($_GET['share_url']):'';
$company_id     = isset($_GET['company_id'])? intval($_GET['company_id']):0;

$companyInfo = C::t("#tom_tczhaopin#tom_tczhaopin_company")->fetch_by_id($company_id);
$renzhengCompanyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_id($companyInfo['renzheng_company_id']);

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
    include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
}else{
    echo 'QR|phpqrcode';exit;
}

$logo = '';
if(!preg_match('/^http/', $renzhengCompanyInfo['logo']) ){
    if(strpos($renzhengCompanyInfo['logo'], 'source/plugin/tom_') === FALSE){
        $logo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$renzhengCompanyInfo['logo'];
        if(strpos($logo, $_G['siteurl']) !== false){
            $logo = str_replace($_G['siteurl'], "", $logo);
            $logo = DISCUZ_ROOT.$logo;
        }
    }else{
        $logo = DISCUZ_ROOT.$renzhengCompanyInfo['logo'];
    }
}else{
    $logo = $renzhengCompanyInfo['logo'];
}

$haibaoBg = $tczhaopinConfig['company_haibao_bg'];

$logoImg = DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/data/haibao/'.md5($logo).'_logo.png';
$logoUrl = 'source/plugin/tom_tczhaopin/data/haibao/'.md5($logo).'_logo.png';

$haibaoBgImg = DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/data/haibao/'.md5($haibaoBg).'_haibao_bg1.png';
$haibaoBgUrl = 'source/plugin/tom_tczhaopin/data/haibao/'.md5($haibaoBg).'_haibao_bg1.png';

$qrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/data/haibao/'.md5($share_url).'_qrcode.png';
$qrcodeUrl = 'source/plugin/tom_tczhaopin/data/haibao/'.md5($share_url).'_qrcode.png';

$wxqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/data/haibao/'.md5($share_url).'_wxqrcode'.date("Ymd").'.png';
$wxqrcodeUrl = 'source/plugin/tom_tczhaopin/data/haibao/'.md5($share_url).'_wxqrcode'.date("Ymd").'.png';

$tempDir = "/source/plugin/tom_tczhaopin/data/haibao/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0755); 
}

if(file_exists($logoImg)){
}else{
    $logo_content = file_get_contents($logo);
    if(false === file_put_contents($logoImg,$logo_content)){
        $logoImg = $logo;
    }
}

if(file_exists($haibaoBgImg)){
}else{
    $haibao_bg_pic_content = file_get_contents($haibaoBg);
    if(false === file_put_contents($haibaoBgImg,$haibao_bg_pic_content)){
        $haibaoBgImg = $haibaoBg;
    }
}

$outQrcodeUrl = '';
if($tczhaopinConfig['open_wxqrcode'] == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_weixin/tom_weixin.inc.php')){
    
    $qrcodeKey  = md5($share_url);
    $qrcodeInfo = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_by_qkey($qrcodeKey);
    $qrcodeId = 0;
    if($qrcodeInfo){
        $qrcodeId = $qrcodeInfo['id'];
        $updateData = array();
        $updateData['title']  = $renzhengCompanyInfo['name'];
        $updateData['picurl'] = $_G['siteurl'].$logoUrl;
        $updateData['link']   = $share_url;
        $updateData['desc']   = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        C::t('#tom_weixin#tom_weixin_qrcode')->update($qrcodeId,$updateData);
    }else{
        $insertData = array();
        $insertData['qkey']     = $qrcodeKey;
        $insertData['title']    = $renzhengCompanyInfo['name'];
        $insertData['picurl']   = $_G['siteurl'].$logoUrl;
        $insertData['desc']     = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        $insertData['link']     = $share_url;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_weixin#tom_weixin_qrcode')->insert($insertData);
        $qrcodeId = C::t('#tom_weixin#tom_weixin_qrcode')->insert_id();
    }
    
    if(file_exists($wxqrcodeImg)){
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        $access_token = $weixinClass->get_access_token();

        $dateStr = '{"expire_seconds": 2592000, "action_name": "QR_SCENE", "action_info": {"scene": {"scene_id": '.$qrcodeId.'}}}';
        $response   = postDataCurl($dateStr, 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token);
        $returnData = json_decode($response,true);
        if(isset($returnData['ticket']) &&  !empty($returnData['ticket'])){
            $wx_pic_content = getHtml('https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$returnData['ticket']);
            if(false === file_put_contents($wxqrcodeImg,$wx_pic_content)){
            }
        }
    }
    
    $outQrcodeUrl = $wxqrcodeUrl;
}else{
    if(file_exists($qrcodeImg)){
    }else{
        QRcode::png($share_url,$qrcodeImg,'H',5,2);
    }
    $outQrcodeUrl = $qrcodeUrl;
}

echo 'OK|'.$logoUrl.'|'.$haibaoBgUrl.'|'.$outQrcodeUrl;exit;

function wx_iconv_recurrence($value) {
	if(is_array($value)) {
		foreach($value AS $key => $val) {
			$value[$key] = wx_iconv_recurrence($val);
		}
	} else {
		$value = diconv($value, 'utf-8', CHARSET);
	}
	return $value;
}

function getHtml($url){
    if(function_exists('curl_init')){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $return = curl_exec($ch);
        curl_close($ch); 
        return $return;
    }
    return false;
}

function postDataCurl($data, $url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,FALSE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $return = curl_exec($ch);
    if($return){
        curl_close($ch);
        return $return;
    } else { 
        $error = curl_errno($ch);
        curl_close($ch);
        return false;
    }
}