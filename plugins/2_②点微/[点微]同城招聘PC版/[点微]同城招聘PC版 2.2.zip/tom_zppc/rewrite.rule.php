<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$rewritedata = array(
	'rulesearch' => array(
        'zhaopin_site'          => $zppcConfig['rewrite_zhaopin_name'].'/index-{site}.html',
		'zhaopin_list'          => $zppcConfig['rewrite_zhaopin_name'].'/list-{site}-{cate_id}-{cate_child_id}-{page}.html',
        'zhaopin_jianzhilist'   => $zppcConfig['rewrite_zhaopin_name'].'/jianzhilist-{site}-{jianzhi_cate_id}-{page}.html',
        'zhaopin_zhaopininfo'   => $zppcConfig['rewrite_zhaopin_name'].'/info-{site}-{tczhaopin_id}.html',
        'zhaopin_companylist'   => $zppcConfig['rewrite_zhaopin_name'].'/companylist-{site}-{industry_id}-{page}.html',
        'zhaopin_companyinfo'   => $zppcConfig['rewrite_zhaopin_name'].'/companyinfo-{site}-{company_id}.html',
        'zhaopin_resumelist'    => $zppcConfig['rewrite_zhaopin_name'].'/resumelist-{site}-{cate_id}-{cate_child_id}-{page}.html',
        'zhaopin_resumeinfo'    => $zppcConfig['rewrite_zhaopin_name'].'/resumeinfo-{site}-{resume_id}.html',
        'zhaopin_meeting'       => $zppcConfig['rewrite_zhaopin_name'].'/meeting-{site}-{page}.html',
        'zhaopin_meetinginfo'   => $zppcConfig['rewrite_zhaopin_name'].'/meetinginfo-{site}-{meeting_id}.html',
        'zhaopin_about'         => $zppcConfig['rewrite_zhaopin_name'].'/about-{site}-{about_id}.html',
        'zhaopin_index'         => $zppcConfig['rewrite_zhaopin_name'].'/',
	),
	'rulereplace' => array(
        'zhaopin_site'          => 'plugin.php?id=tom_zppc&site={site}&mod=index',
		'zhaopin_list'          => 'plugin.php?id=tom_zppc&site={site}&mod=list&cate_id={cate_id}&cate_child_id={cate_child_id}&page={page}',
        'zhaopin_jianzhilist'   => 'plugin.php?id=tom_zppc&site={site}&mod=jianzhilist&jianzhi_cate_id={jianzhi_cate_id}&page={page}',
        'zhaopin_zhaopininfo'   => 'plugin.php?id=tom_zppc&site={site}&mod=zhaopininfo&tczhaopin_id={tczhaopin_id}',
        'zhaopin_companylist'   => 'plugin.php?id=tom_zppc&site={site}&mod=companylist&industry_id={industry_id}&page={page}',
        'zhaopin_companyinfo'   => 'plugin.php?id=tom_zppc&site={site}&mod=companyinfo&company_id={company_id}',
        'zhaopin_resumelist'    => 'plugin.php?id=tom_zppc&site={site}&mod=resumelist&cate_id={cate_id}&cate_child_id={cate_child_id}&page={page}',
        'zhaopin_resumeinfo'    => 'plugin.php?id=tom_zppc&site={site}&mod=resumeinfo&resume_id={resume_id}',
        'zhaopin_meeting'       => 'plugin.php?id=tom_zppc&site={site}&mod=meeting&page={page}',
        'zhaopin_meetinginfo'   => 'plugin.php?id=tom_zppc&site={site}&mod=meetinginfo&meeting_id={meeting_id}',
        'zhaopin_about'         => 'plugin.php?id=tom_zppc&site={site}&mod=about&about_id={about_id}',
        'zhaopin_index'         => 'plugin.php?id=tom_zppc&site=1&mod=index',
	),
	'rulevars' => array(
        'zhaopin_site'          => array('{site}' => '([0-9]+)'),
		'zhaopin_list'          => array('{site}' => '([0-9]+)', '{cate_id}' => '([0-9]+)', '{cate_child_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'zhaopin_jianzhilist'   => array('{site}' => '([0-9]+)', '{jianzhi_cate_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'zhaopin_zhaopininfo'   => array('{site}' => '([0-9]+)', '{tczhaopin_id}' => '([0-9]+)'),
        'zhaopin_companylist'   => array('{site}' => '([0-9]+)', '{industry_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'zhaopin_companyinfo'   => array('{site}' => '([0-9]+)', '{company_id}' => '([0-9]+)'),
        'zhaopin_resumelist'    => array('{site}' => '([0-9]+)', '{cate_id}' => '([0-9]+)', '{cate_child_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'zhaopin_resumeinfo'    => array('{site}' => '([0-9]+)', '{resume_id}' => '([0-9]+)'),
        'zhaopin_meeting'       => array('{site}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'zhaopin_meetinginfo'   => array('{site}' => '([0-9]+)', '{meeting_id}' => '([0-9]+)'),
        'zhaopin_about'         => array('{site}' => '([0-9]+)', '{about_id}' => '([0-9]+)'),
        'zhaopin_index'         => array(),
	)
);

if($zppcConfig['open_zhaopin_hosts'] == 1 && $zppcConfig['closed_rewrite_name'] == 1){
    foreach($rewritedata['rulesearch'] as $key => $value) {
        $rewritedata['rulesearch'][$key] = str_replace($zppcConfig['rewrite_zhaopin_name'].'/', '', $value);
    }
}

$rule['{apache1}'] = $rule['{apache2}'] = $rule['{iis}'] = $rule['{iis7}'] = $rule['{zeus}'] = $rule['{nginx}'] = '';
foreach($rewritedata['rulesearch'] as $k => $v) {
    $pvmaxv = count($rewritedata['rulevars'][$k]) + 2;
    $vkeys = array_keys($rewritedata['rulevars'][$k]);
    $rewritedata['rulereplace'][$k] = pvsort($vkeys, $v, $rewritedata['rulereplace'][$k]);
    $v = str_replace($vkeys, $rewritedata['rulevars'][$k], addcslashes($v, '?*+^$.[]()|'));
    $rule['{apache1}'] .= "\t".'RewriteCond %{QUERY_STRING} ^(.*)$'."\n\t".'RewriteRule ^(.*)/'.$v.'$ $1/'.pvadd($rewritedata['rulereplace'][$k])."&%1\n";
    if($k != 'forum_archiver') {
        $rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^'.$v.'$ '.$rewritedata['rulereplace'][$k]."&%1\n";
    } else {
        $rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^archiver/'.$v.'$ archiver/'.$rewritedata['rulereplace'][$k]."&%1\n";
    }
    $rule['{iis}'] .= 'RewriteRule ^(.*)/'.$v.'(\?(.*))*$ $1/'.addcslashes(pvadd($rewritedata['rulereplace'][$k]).'&$'.($pvmaxv + 1), '.?')."\n";
    $rule['{iis7}'] .= "\t\t".'&lt;rule name="'.$k.'"&gt;'."\n\t\t\t".'&lt;match url="^(.*/)*'.str_replace('\.', '.', $v).'\?*(.*)$" /&gt;'."\n\t\t\t".'&lt;action type="Rewrite" url="{R:1}/'.str_replace(array('&', 'page\%3D'), array('&amp;amp;', 'page%3D'), addcslashes(pvadd($rewritedata['rulereplace'][$k], 1).'&{R:'.$pvmaxv.'}', '?')).'" /&gt;'."\n\t\t".'&lt;/rule&gt;'."\n";
    $rule['{zeus}'] .= 'match URL into $ with ^(.*)/'.$v.'\?*(.*)$'."\n".'if matched then'."\n\t".'set URL = $1/'.pvadd($rewritedata['rulereplace'][$k]).'&$'.$pvmaxv."\nendif\n";
    $rule['{nginx}'] .= 'rewrite ^([^\.]*)/'.$v.'$ $1/'.stripslashes(pvadd($rewritedata['rulereplace'][$k]))." last;\n";
}
$rule['{nginx}'] .= "if (!-e \$request_filename) {\n\treturn 404;\n}";
echo str_replace(array_keys($rule), $rule, $scriptlang['tom_zppc']['rewrite_message']);
    
function pvsort($key, $v, $s) {
	$r = '/';
	$p = '';
	foreach($key as $k) {
		$r .= $p.preg_quote($k);
		$p = '|';
	}
	$r .= '/';
	preg_match_all($r, $v, $a);
	$a = $a[0];
	$a = array_flip($a);
	foreach($a as $key => $value) {
		$s = str_replace($key, '$'.($value + 1), $s);
	}
	return $s;
}

function pvadd($s, $t = 0) {
	$s = str_replace(array('$6','$5','$4', '$3', '$2', '$1'), array('~7', '~6', '~5', '~4', '~3', '~2'), $s);
	if(!$t) {
		return str_replace(array('~7','~6','~5', '~4', '~3', '~2'), array('$7','$6','$5', '$4', '$3', '$2'), $s);
	} else {
		return str_replace(array('~7','~6','~5', '~4', '~3', '~2'), array('{R:7}','{R:6}','{R:5}','{R:4}', '{R:3}', '{R:2}'), $s);
	}

}