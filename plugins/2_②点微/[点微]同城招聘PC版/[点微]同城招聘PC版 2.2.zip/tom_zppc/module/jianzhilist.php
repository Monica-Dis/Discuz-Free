<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page                      = intval($_GET['page'])>0 ? intval($_GET['page']):1;
$jianzhi_cate_id           = intval($_GET['jianzhi_cate_id'])>0 ? intval($_GET['jianzhi_cate_id']):0;
$refresh_type              = intval($_GET['refresh_type'])>0? intval($_GET['refresh_type']):0;
$area_id                   = intval($_GET['area_id'])>0 ? intval($_GET['area_id']):0;
$street_id                 = intval($_GET['street_id'])>0 ? intval($_GET['street_id']):0;
$jianzhi_jiesuan_fangshi   = intval($_GET['jianzhi_jiesuan_fangshi'])>0? intval($_GET['jianzhi_jiesuan_fangshi']):0;
$keyword                   = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$keyword                   = dhtmlspecialchars($keyword);

if($__Mobile == 1 && $zppcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=jianzhilist&jianzhi_cate_id={$jianzhi_cate_id}");exit;
}

$jianzhiCateUrl = '';
$jianzhiCateListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_jianzhi_cate")->fetch_all_list(" ", 'ORDER BY csort ASC,id DESC');
$jianzhiCateList = array();
if(is_array($jianzhiCateListTmp) && !empty($jianzhiCateListTmp)){
    foreach ($jianzhiCateListTmp as $key => $value){
        $jianzhiCateList[$value['id']] = $value;
        $jianzhiCateList[$value['id']]['link'] = tom_zppc_url('jianzhilist',$site_id,array('jianzhi_cate_id'=>$value['id']));
    }
    $jianzhiCateUrl = tom_zppc_url('jianzhilist',$site_id,array('jianzhi_cate_id'=>$jianzhi_cate_id));
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$areaList = array();
if(is_array($areaListTmp) && !empty($areaListTmp)){
    $areaList = $areaListTmp;
}

$streetList = array();
if($area_id > 0){
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
}

$guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 6 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 6 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$jianzhiSearchArr = array();
$jianzhiSearchArrTmp = explode('|', $tczhaopinConfig['jianzhi_zhaopin_search_str']);
if(is_array($jianzhiSearchArrTmp) && !empty($jianzhiSearchArrTmp)){
    foreach($jianzhiSearchArrTmp as $key => $value){
        $jianzhiSearchArr[] = daddslashes($value);
    }
}

$jianzhiSearchCount = count($jianzhiSearchArr);

$url = '';
$rewriteStatus = 1;
$where = ' AND type = 2 AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2)  ';
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}
if($jianzhi_jiesuan_fangshi > 0){
    $rewriteStatus = 0;
    $where .= " AND jianzhi_jiesuan_fangshi = {$jianzhi_jiesuan_fangshi} ";
    $url .= "&jianzhi_jiesuan_fangshi={$jianzhi_jiesuan_fangshi}";
}
if($refresh_type > 0){
    $rewriteStatus = 0;
    $min_refresh_time = TIMESTAMP;
    if($refresh_type == 1){
        $min_refresh_time = $min_refresh_time - (1 * 86400);
    }else if($refresh_type == 2){
        $min_refresh_time = $min_refresh_time - (7 * 86400);
    }else if($refresh_type == 3){
        $min_refresh_time = $min_refresh_time - (14 * 86400);
    }else if($refresh_type == 4){
        $min_refresh_time = $min_refresh_time - (30 * 86400);
    }
    $where.= " AND refresh_time >= {$min_refresh_time} ";
    $url .= "&refresh_type={$refresh_type}";
}
if($jianzhi_cate_id > 0){
    $where .= " AND jianzhi_cate_id = {$jianzhi_cate_id} ";
    $url .= "&jianzhi_cate_id={$jianzhi_cate_id}";
}
if($area_id > 0){
    $rewriteStatus = 0;
    $where .= " AND area_id = {$area_id} ";
    $url .= "&area_id={$area_id}";
}
if($street_id > 0){
    $rewriteStatus = 0;
    $where .= " AND street_id = {$street_id} ";
    $url .= "&street_id={$street_id}";
}
if(!empty($keyword)){
    $rewriteStatus = 0;
    $keywordTmp = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND search_text LIKE '%{$keywordTmp}%'";
    $url .= "&keyword={$keyword}";
}

$order = " ORDER BY top_status DESC,over_status ASC,refresh_time DESC,id DESC ";

$pagesize =20;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count($where);

$tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list($where,$order,$start,$pagesize);
$tczhaopinList = list_zhaopin($tczhaopinListTmp);

if($rewriteStatus == 1){
    $pageArr['link'] = tom_zppc_url('jianzhilist',$site_id,array('jianzhi_cate_id'=>$jianzhi_cate_id,'page'=>'{page}'));
}else{
    $pageArr['link'] = $_G['siteurl']."plugin.php?id=tom_zppc&site={$site_id}&mod=jianzhilist&{$url}&page={page}";
}
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$jianzhiCateName = '';

if($jianzhi_cate_id > 0){
    $jianzhiCateName = $jianzhiCateList[$jianzhi_cate_id]['name'];
}

$seo_jianzhicate_name = '';
if(!empty($jianzhiCateName)){
    $seo_jianzhicate_name = $jianzhiCateName;
}else{
    $seo_jianzhicate_name = lang('plugin/tom_zppc', 'list_jianzhi_title');
}

$seo_title          = $zppcConfig['seo_jianzhilist_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{JIANZHICATENAME}",$seo_jianzhicate_name, $seo_title);
$seo_title          = str_replace("{PAGE}",$page, $seo_title);

$seo_keywords       = $zppcConfig['seo_jianzhilist_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{JIANZHICATENAME}",$seo_jianzhicate_name, $seo_keywords);
$seo_keywords       = str_replace("{PAGE}",$page, $seo_keywords);

$seo_description    = $zppcConfig['seo_jianzhilist_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{JIANZHICATENAME}",$seo_jianzhicate_name, $seo_description);
$seo_description    = str_replace("{PAGE}",$page, $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:jianzhilist");