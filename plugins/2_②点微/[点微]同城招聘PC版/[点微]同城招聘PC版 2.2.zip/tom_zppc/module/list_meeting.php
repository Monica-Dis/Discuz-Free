<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function list_meeting($meetingListTmp){
    global $_G,$tongchengConfig,$site_id,$tomSysOffset;
    
    $meetingList = array();
    if(is_array($meetingListTmp) && !empty($meetingListTmp)){

        $meetingIdsArrTmp = array();
        foreach ($meetingListTmp as $key => $value) {
            $meetingIdsArrTmp[] = $value['id'];
        }
        
        foreach ($meetingListTmp as $key => $value) {
            $meetingList[$key] = $value;
            
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                    $meetingPic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $meetingPic = $value['picurl'];
                }
            }else{
                $meetingPic = $value['picurl'];
            }
            $meetingShowType = 1;
            if($value['start_time'] > TIMESTAMP){
                $meetingShowType = 2;
            }
            if($value['end_time'] <= TIMESTAMP){
                $meetingShowType = 3;
            }
            
            $meetingList[$key]['meetingShowType']    = $meetingShowType;
            $meetingList[$key]['picurl']             = $meetingPic;
            $meetingList[$key]['start_time']         = dgmdate($value['start_time'],"Y-m-d",$tomSysOffset);
            $meetingList[$key]['end_time']           = dgmdate($value['end_time'],"Y-m-d",$tomSysOffset);
            $meetingList[$key]['link']               = tom_zppc_url('meetinginfo',$site_id,array('meeting_id'=>$value['id']));
            
        }
    }
    
    return $meetingList;
}