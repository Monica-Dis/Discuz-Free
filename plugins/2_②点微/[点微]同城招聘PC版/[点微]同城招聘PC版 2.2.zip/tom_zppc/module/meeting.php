<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page  = intval($_GET['page'])>0 ? intval($_GET['page']):1;

if($__Mobile == 1 && $zppcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=meeting");exit;
}

$rewriteStatus = 1;
$where = ' AND status = 1 ';
if(!empty($sql_in_site_ids)){
    $where.= " AND site_id IN({$sql_in_site_ids}) ";
}

$order = " ORDER BY msort ASC, id DESC  ";

$pagesize = 10;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_all_count($where);

$meetingListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_meeting')->fetch_all_list($where,$order,$start,$pagesize);
$meetingList = list_meeting($meetingListTmp);

if($rewriteStatus == 1){
    $pageArr['link'] = tom_zppc_url('meeting',$site_id,array('page'=>'{page}'));
}else{
    $pageArr['link'] = $_G['siteurl']."plugin.php?id=tom_zppc&site={$site_id}&mod=meeting&page={page}";
}
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$seo_title          = $zppcConfig['seo_meeting_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{PAGE}",$page, $seo_title);

$seo_keywords       = $zppcConfig['seo_meeting_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{PAGE}",$page, $seo_keywords);

$seo_description    = $zppcConfig['seo_meeting_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{PAGE}",$page, $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:meeting");