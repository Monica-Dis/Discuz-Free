<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page             = intval($_GET['page'])>0 ? intval($_GET['page']):1;
$cate_id          = intval($_GET['cate_id'])>0 ? intval($_GET['cate_id']):0;
$cate_child_id    = intval($_GET['cate_child_id'])>0 ? intval($_GET['cate_child_id']):0;
$salary           = intval($_GET['salary'])>0? intval($_GET['salary']):0;
$refresh_type     = intval($_GET['refresh_type'])>0? intval($_GET['refresh_type']):0;
$area_id          = intval($_GET['area_id'])>0 ? intval($_GET['area_id']):0;
$street_id        = intval($_GET['street_id'])>0 ? intval($_GET['street_id']):0;
$keyword          = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$keyword          = dhtmlspecialchars($keyword);

if($__Mobile == 1 && $zppcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=zhaopinlist&cate_id={$cate_id}&cate_child_id={$cate_child_id}");exit;
}

$cateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,500);
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$value['id']] = $value;
        $cateList[$value['id']]['link'] = tom_zppc_url('list',$site_id,array('cate_id'=>$value['id']));
    }
}

$cateUrl = '';
if($cate_id > 0){
    $cateChildListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid = {$cate_id} "," ORDER BY csort ASC,id DESC ",0,5000);
    $cateChildList = array();
    if(is_array($cateChildListTmp) && !empty($cateChildListTmp)){
        foreach($cateChildListTmp as $key => $value){
            $cateChildList[$value['id']] = $value;
            $cateChildList[$value['id']]['link'] = tom_zppc_url('list',$site_id,array('cate_id'=>$cate_id,'cate_child_id'=>$value['id']));
        }
    }
    
    $cateUrl = tom_zppc_url('list',$site_id,array('cate_id'=>$cate_id));
    if($cate_child_id > 0){
        $cateChildUrl = tom_zppc_url('list',$site_id,array('cate_id'=>$cate_id,'cate_child_id'=>$cate_child_id));
    }
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$areaList = array();
if(is_array($areaListTmp) && !empty($areaListTmp)){
    $areaList = $areaListTmp;
}

$streetList = array();
if($area_id > 0){
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
}

$guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 5 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 5 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$zpSearchArr = array();
$zhaopinSearchArr = explode('|', $tczhaopinConfig['zhaopin_search_str']);
if(is_array($zhaopinSearchArr) && !empty($zhaopinSearchArr)){
    foreach($zhaopinSearchArr as $key => $value){
        $zpSearchArr[] = daddslashes($value);
    }
}

$zpSearchCount = count($zpSearchArr);

$url = '';
$rewriteStatus = 1;
$where = 'AND type=1 AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2)  ';
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}
if($salary > 0){
    $rewriteStatus = 0;
    if($salary == 2){
        $where.= " AND (work_salary = {$salary} OR work_salary_min < 1000) ";
    }else if($salary == 3){
        $where.= " AND (work_salary = {$salary} OR (work_salary_max < 2000 AND work_salary_max > 1000)) ";
    }else if($salary == 4){
        $where.= " AND (work_salary = {$salary} OR (work_salary_max < 3000 AND work_salary_max > 2000)) ";
    }else if($salary == 5){
        $where.= " AND (work_salary = {$salary} OR (work_salary_max < 4000 AND work_salary_max > 3000)) ";
    }else if($salary == 6){
        $where.= " AND (work_salary = {$salary} OR (work_salary_max < 5000 AND work_salary_max > 4000)) ";
    }else if($salary == 7){
        $where.= " AND (work_salary = {$salary} OR (work_salary_max < 8000 AND work_salary_max > 5000)) ";
    }else if($salary == 8){
        $where.= " AND (work_salary = {$salary} OR (work_salary_max < 12000 AND work_salary_max > 8000)) ";
    }else if($salary == 9){
        $where.= " AND (work_salary = {$salary} OR (work_salary_max < 20000 AND work_salary_max > 12000)) ";
    }else if($salary == 10){
        $where.= " AND (work_salary = {$salary} OR work_salary_max > 20000) ";
    }else{
        $where.= " AND work_salary = {$salary} ";
    }
    $url .= "&salary={$salary}";
}
if($refresh_type > 0){
    $rewriteStatus = 0;
    $min_refresh_time = TIMESTAMP;
    if($refresh_type == 1){
        $min_refresh_time = $min_refresh_time - (1 * 86400);
    }else if($refresh_type == 2){
        $min_refresh_time = $min_refresh_time - (7 * 86400);
    }else if($refresh_type == 3){
        $min_refresh_time = $min_refresh_time - (14 * 86400);
    }else if($refresh_type == 4){
        $min_refresh_time = $min_refresh_time - (30 * 86400);
    }
    $where.= " AND refresh_time >= {$min_refresh_time} ";
    $url .= "&refresh_type={$refresh_type}";
}
if($cate_id > 0){
    $where .= " AND cate_id = {$cate_id} ";
    $url .= "&cate_id={$cate_id}";
}
if($cate_child_id > 0){
    $where .= " AND cate_child_id = {$cate_child_id} ";
    $url .= "&cate_child_id={$cate_child_id}";
}
if($area_id > 0){
    $rewriteStatus = 0;
    $where .= " AND area_id = {$area_id} ";
    $url .= "&area_id={$area_id}";
}
if($street_id > 0){
    $rewriteStatus = 0;
    $where .= " AND street_id = {$street_id} ";
    $url .= "&street_id={$street_id}";
}
if(!empty($keyword)){
    $rewriteStatus = 0;
    $keywordTmp = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND search_text LIKE '%{$keywordTmp}%'";
    $url .= "&keyword={$keyword}";
}

$order = " ORDER BY top_status DESC,over_status ASC,refresh_time DESC,id DESC ";

$pagesize =20;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count($where);

$tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list($where,$order,$start,$pagesize);
$tczhaopinList = list_zhaopin($tczhaopinListTmp);

if($rewriteStatus == 1){
    $pageArr['link'] = tom_zppc_url('list',$site_id,array('cate_id'=>$cate_id,'cate_child_id'=>$cate_child_id,'page'=>'{page}'));
}else{
    $pageArr['link'] = $_G['siteurl']."plugin.php?id=tom_zppc&site={$site_id}&mod=list&{$url}&page={page}";
}
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$cateName = $cateChildName  = '';
if($cate_id > 0){
    $cateName = $cateList[$cate_id]['name'];
}
if($cate_child_id > 0){
    $cateChildName = $cateChildList[$cate_child_id]['name'];
}

$seo_cate_name = $seo_cate_child_name = '';
if(!empty($cateName)){
    $seo_cate_name = $cateName;
}else{
    $seo_cate_name = lang('plugin/tom_zppc', 'list_title');
}
if(!empty($cateChildName)){
    $seo_cate_child_name = $cateChildName;
}

$seo_title          = $zppcConfig['seo_list_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{CATENAME}",$seo_cate_name, $seo_title);
$seo_title          = str_replace("{CATECHILDNAME}",$seo_cate_child_name, $seo_title);
$seo_title          = str_replace("{PAGE}",$page, $seo_title);

$seo_keywords       = $zppcConfig['seo_list_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CATENAME}",$seo_cate_name, $seo_keywords);
$seo_keywords       = str_replace("{CATECHILDNAME}",$seo_cate_child_name, $seo_keywords);
$seo_keywords       = str_replace("{PAGE}",$page, $seo_keywords);

$seo_description    = $zppcConfig['seo_list_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{CATENAME}",$seo_cate_name, $seo_description);
$seo_description    = str_replace("{CATECHILDNAME}",$seo_cate_child_name, $seo_description);
$seo_description    = str_replace("{PAGE}",$page, $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:list");