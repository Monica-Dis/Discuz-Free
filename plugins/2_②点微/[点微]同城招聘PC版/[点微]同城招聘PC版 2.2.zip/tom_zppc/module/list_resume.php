<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function list_resume($resumeListTmp){
    global $_G,$tongchengConfig,$site_id,$tomSysOffset,$man_resume_avatar,$woman_resume_avatar;

    $resumeList = array();
    if(is_array($resumeListTmp) && !empty($resumeListTmp)){

        $resumeIdsArrTmp = $districtIdsArrTmp = array();
        foreach ($resumeListTmp as $key => $value) {
            $resumeIdsArrTmp[] = $value['id'];
            if($value['area_id'] > 0){
                $districtIdsArrTmp[] = $value['area_id'];
            }
            if($value['street_id'] > 0){
                $districtIdsArrTmp[] = $value['street_id'];
            }
        }
        
        $districtListTmp = array();
        if(is_array($districtIdsArrTmp) && !empty($districtIdsArrTmp)){
            $districtIdsStrTmp = implode(',', $districtIdsArrTmp);
            $districtArrTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_list(" AND id IN({$districtIdsStrTmp}) "," ORDER BY id ASC ",0,200);
            if(is_array($districtArrTmp) && !empty($districtArrTmp)){
                foreach($districtArrTmp as $key => $value){
                    $districtListTmp[$value['id']] = $value;
                }
            }
        }
        
        foreach ($resumeListTmp as $key => $value) {
            $resumeList[$key] = $value;
            
            if(!empty($value['avatar'])){
                if(!preg_match('/^http/', $value['avatar']) ){
                    if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                        $avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
                    }else{
                        $avatar = $_G['siteurl'].$value['avatar'];
                    }
                }else{
                    $avatar = $value['avatar'];
                }
            }else{
                if($value['sex'] == 1){
                    $avatar = $man_resume_avatar;
                }else if($value['sex'] == 2){
                    $avatar = $woman_resume_avatar;
                }
            }
            
            $resumeList[$key]['avatar']                = $avatar;
            $resumeList[$key]['name']                  = cutstr($value['name'], 2,'');
            $resumeList[$key]['refresh_time']          = dgmdate($value['refresh_time'],"Y.m.d",$tomSysOffset);
            $nowYear = dgmdate(TIMESTAMP,"Y",$tomSysOffset);
            $resumeList[$key]['age'] = $nowYear - $value['birth_year'];
            
            $resumeList[$key]['area_street'] = '';
            $areaNameTmp = '';
            if(!empty($value['area_id'])){
                $areaInfoTmp = $districtListTmp[$value['area_id']];
                $areaNameTmp = $areaInfoTmp['name'];
            }
            $streetNameTmp = '';
            if(!empty($value['street_id'])){
                $streetInfoTmp = $districtListTmp[$value['street_id']];
                $streetNameTmp = $streetInfoTmp['name'];
            }
            if(!empty($areaNameTmp) && !empty($streetNameTmp)){
                $resumeList[$key]['area_street'] = $areaNameTmp."-".$streetNameTmp;
            }else{
                $resumeList[$key]['area_street'] = $areaNameTmp;
            }
            
            $resumeList[$key]['link']                  = tom_zppc_url('resumeinfo',$site_id,array('resume_id'=>$value['id']));
        }
    }
    
    return $resumeList;
}