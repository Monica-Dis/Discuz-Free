<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function list_company($companyListTmp){
    global $_G,$tongchengConfig,$site_id;
    
    $companyList = array();
    if(is_array($companyListTmp) && !empty($companyListTmp)){

        $companyIdsArrTmp = $natureIdsArrTmp = $industryIdsArrTmp = $scaleIdsArrTmp = array();
        foreach ($companyListTmp as $key => $value) {
            $companyIdsArrTmp[] = $value['id'];
            $natureIdsArrTmp[]  = $value['nature_id'];
            $industryIdsArrTmp[]  = $value['industry_id'];
            $scaleIdsArrTmp[]     = $value['scale_id'];
        }
        
        $natureListTmp = array();
        if(is_array($natureIdsArrTmp) && !empty($natureIdsArrTmp)){
            $natureIdsStrTmp = implode(',', $natureIdsArrTmp);
            $natureArrTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_nature')->fetch_all_list(" AND id IN({$natureIdsStrTmp}) "," ORDER BY id ASC ",0,200);
            if(is_array($natureArrTmp) && !empty($natureArrTmp)){
                foreach($natureArrTmp as $key => $value){
                    $natureListTmp[$value['id']] = $value;
                }
            }
        }
        
        $industryListTmp = array();
        if(is_array($industryIdsArrTmp) && !empty($industryIdsArrTmp)){
            $industryIdsStrTmp = implode(',', $industryIdsArrTmp);
            $industryArrTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_all_list(" AND id IN({$industryIdsStrTmp}) "," ORDER BY id ASC ",0,200);
            if(is_array($industryArrTmp) && !empty($industryArrTmp)){
                foreach($industryArrTmp as $key => $value){
                    $industryListTmp[$value['id']] = $value;
                }
            }
        }
        
        $scaleListTmp = array();
        if(is_array($scaleIdsArrTmp) && !empty($scaleIdsArrTmp)){
            $scaleIdsStrTmp = implode(',', $scaleIdsArrTmp);
            $scaleArrTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_scale')->fetch_all_list(" AND id IN({$scaleIdsStrTmp}) "," ORDER BY id ASC ",0,200);
            if(is_array($scaleArrTmp) && !empty($scaleArrTmp)){
                foreach($scaleArrTmp as $key => $value){
                    $scaleListTmp[$value['id']] = $value;
                }
            }
        }
                
        foreach ($companyListTmp as $key => $value) {
            $companyList[$key] = $value;
            
            if(!preg_match('/^http/', $value['logo']) ){
                if(strpos($value['logo'], 'source/plugin/tom_') === FALSE){
                    $renzhengCompanyLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['logo'];
                }else{
                    $renzhengCompanyLogo = $_G['siteurl'].$value['logo'];
                }
            }else{
                $renzhengCompanyLogo = $value['logo'];
            }
            $companyList[$key]['logo']                  = $renzhengCompanyLogo;
            
            $natureInfoTmp                              = $natureListTmp[$value['nature_id']];
            $industryInfoTmp                            = $industryListTmp[$value['industry_id']];
            $scaleInfoTmp                               = $scaleListTmp[$value['scale_id']];
            $industryInfoTmp['name']                    = str_replace("|","/","{$industryInfoTmp['name']}");
            $companyList[$key]['natureInfo']            = $natureInfoTmp;
            $companyList[$key]['industryInfo']          = $industryInfoTmp;
            $companyList[$key]['scaleInfo']             = $scaleInfoTmp;
            $companyList[$key]['link']                  = tom_zppc_url('companyinfo',$site_id,array('company_id'=>$value['id']));
            
        }
    }
    
    return $companyList;
}