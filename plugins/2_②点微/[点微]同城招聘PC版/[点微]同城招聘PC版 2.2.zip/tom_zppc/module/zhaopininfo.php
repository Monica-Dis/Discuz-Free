<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tczhaopin_id = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):0;

if($__Mobile == 1 && $zppcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=zhaopininfo&tczhaopin_id={$tczhaopin_id}");exit;
}

$tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);

if($tczhaopinInfo['status'] == 1 && $tczhaopinInfo['shenhe_status'] == 1){
}else{
    dheader('location:'."{$listUrl}");exit;
}

if($tczhaopinInfo['area_id'] > 0){
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tczhaopinInfo['area_id']);
}

$workWelfareArr = explode('-', trim($tczhaopinInfo['work_welfare'], '-'));
$welfareList = array();
if(is_array($welfareArray) && !empty($welfareArray)){
    foreach($welfareArray as $key => $value){
        if(in_array($key,$workWelfareArr)){
            $welfareList[$key]['name'] = $value;
        }
    }
}

$demand_desc = str_replace("\r\n","<br/>",$tczhaopinInfo['demand_desc']);
$demand_desc = str_replace("\n","<br/>",$demand_desc);
$demand_desc = str_replace("\r","<br/>",$demand_desc);
if($tczhaopinConfig['hide_demand_desc_tel'] == 1){
    $demand_desc = preg_replace("/\d{7}/", '*****', $demand_desc);
}

$zhaopininfo_desc    = dhtmlspecialchars($tczhaopinConfig['zhaopininfo_desc']);

$companyInfo         = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
$renzhengCompanyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_id($companyInfo['renzheng_company_id']);
$industryInfo        = C::t("#tom_tcrenzheng#tom_tcrenzheng_industry")->fetch_by_id($renzhengCompanyInfo['industry_id']);
$natureInfo          = C::t("#tom_tcrenzheng#tom_tcrenzheng_nature")->fetch_by_id($renzhengCompanyInfo['nature_id']);

$industryInfo['name'] = str_replace("|","/",$industryInfo['name']);

if(!preg_match('/^http/', $renzhengCompanyInfo['logo']) ){
    if(strpos($renzhengCompanyInfo['logo'], 'source/plugin/tom_') === FALSE){
        $renzhengCompanyLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$renzhengCompanyInfo['logo'];
    }else{
        $renzhengCompanyLogo = $_G['siteurl'].$renzhengCompanyInfo['logo'];
    }
}else{
    $renzhengCompanyLogo = $renzhengCompanyInfo['logo'];
}

DB::query("UPDATE ".DB::table('tom_tczhaopin')." SET clicks=clicks+1 WHERE id='{$tczhaopin_id}'", 'UNBUFFERED');

$cateInfo        = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($tczhaopinInfo['cate_id']);
$cateChildInfo   = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($tczhaopinInfo['cate_child_id']);
$jianzhiCateInfo = C::t("#tom_tczhaopin#tom_tczhaopin_jianzhi_cate")->fetch_by_id($tczhaopinInfo['jianzhi_cate_id']);

$companyUrl      = tom_zppc_url('companyinfo',$site_id,array('company_id'=>$tczhaopinInfo['company_id']));
$zpinfoUrl       = tom_zppc_url('zhaopininfo',$site_id,array('tczhaopin_id'=>$tczhaopinInfo['id']));
$cateUrl         = tom_zppc_url('list',$site_id,array('cate_id'=>$tczhaopinInfo['cate_id']));
$cateChildUrl    = tom_zppc_url('list',$site_id,array('cate_id'=>$tczhaopinInfo['cate_id'], 'cate_child_id'=>$tczhaopinInfo['cate_child_id']));
$jianzhiCateUrl  = tom_zppc_url('list',$site_id,array('jianzhi_cate_id'=>$tczhaopinInfo['jianzhi_cate_id']));

$photoListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_photo')->fetch_all_list(" AND tczhaopin_id = {$tczhaopinInfo['id']} "," ORDER BY psort ASC,id ASC ");
$photoList = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];
        $photoList[] = $picurlTmp;
    }
}
$photoCount = count($photoList);

$where = " AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND id != {$tczhaopinInfo['id']} AND cate_id = {$tczhaopinInfo['cate_id']}";

$order = " ORDER BY top_status DESC,over_status ASC,refresh_time DESC,id DESC ";

$zhaopinCount = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count($where);
$tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list($where,$order,0,5);
$tczhaopinList = list_zhaopin($tczhaopinListTmp);

$guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 7 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 7 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);
    
$zhaopinInfoUrl = $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=zhaopininfo&tczhaopin_id={$tczhaopinInfo['id']}";

$seo_title          = $zppcConfig['seo_info_title'];
$seo_title          = str_replace("{TITLE}",$tczhaopinInfo['title'], $seo_title);
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);

$seo_keywords       = $zppcConfig['seo_info_keywords'];
$seo_keywords       = str_replace("{TITLE}",$tczhaopinInfo['title'], $seo_keywords);
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);

$seo_description    = $zppcConfig['seo_info_description'];
$seo_description    = str_replace("{TITLE}",$tczhaopinInfo['title'], $seo_description);
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:zhaopininfo");