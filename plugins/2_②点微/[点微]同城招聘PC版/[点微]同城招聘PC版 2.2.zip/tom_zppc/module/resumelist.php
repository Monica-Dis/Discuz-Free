<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page           = intval($_GET['page'])>0 ? intval($_GET['page']):1;
$cate_id        = intval($_GET['cate_id'])>0 ? intval($_GET['cate_id']):0;
$cate_child_id  = intval($_GET['cate_child_id'])>0 ? intval($_GET['cate_child_id']):0;
$area_id        = intval($_GET['area_id'])>0 ? intval($_GET['area_id']):0;
$street_id      = intval($_GET['street_id'])>0 ? intval($_GET['street_id']):0;
$sex            = intval($_GET['sex'])>0? intval($_GET['sex']):0;
$work_status    = intval($_GET['work_status'])>0? intval($_GET['work_status']):0;
$xueli          = intval($_GET['xueli'])>0? intval($_GET['xueli']):0;
$jingyan        = intval($_GET['jingyan'])>0? intval($_GET['jingyan']):0;
$refresh_type   = intval($_GET['refresh_type'])>0? intval($_GET['refresh_type']):0;
$keyword        = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$keyword        = dhtmlspecialchars($keyword);

if($__Mobile == 1 && $zppcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=resumelist&cate_id={$cate_id}&cate_child_id={$cate_child_id}");exit;
}

$cateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,500);
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$value['id']] = $value;
        $cateList[$value['id']]['link'] = tom_zppc_url('resumelist',$site_id,array('cate_id'=>$value['id']));
    }
}

$cateUrl = '';
if($cate_id > 0){
    $cateChildListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid = {$cate_id} "," ORDER BY csort ASC,id DESC ",0,5000);
    $cateChildList = array();
    if(is_array($cateChildListTmp) && !empty($cateChildListTmp)){
        foreach($cateChildListTmp as $key => $value){
            $cateChildList[$value['id']] = $value;
            $cateChildList[$value['id']]['link'] = tom_zppc_url('resumelist',$site_id,array('cate_id'=>$cate_id,'cate_child_id'=>$value['id']));
        }
    }
    
    $cateUrl = tom_zppc_url('resumelist',$site_id,array('cate_id'=>$cate_id));
    if($cate_child_id > 0){
        $cateChildUrl = tom_zppc_url('resumelist',$site_id,array('cate_id'=>$cate_id,'cate_child_id'=>$cate_child_id));
    }
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$areaList = array();
if(is_array($areaListTmp) && !empty($areaListTmp)){
    $areaList = $areaListTmp;
}

$streetList = array();
if($area_id > 0){
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
}

$guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 8 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 8 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$reSearchArr = array();
$resumeSearchArr = explode('|', $tczhaopinConfig['resume_search_str']);
if(is_array($resumeSearchArr) && !empty($resumeSearchArr)){
    foreach($resumeSearchArr as $key => $value){
        $reSearchArr[] = daddslashes($value);
    }
}
$reSearchCount = count($reSearchArr);

$url = '';
$rewriteStatus = 1;
$where = ' AND status=1 AND shenhe_status=1 AND gongkai_status = 1 AND deleted = 0 ';
if(!empty($sql_in_site_ids)){
    $where.= " AND site_id IN({$sql_in_site_ids}) ";
}
if($cate_id > 0){
    $where.= " AND cate_id={$cate_id} ";
    $url .= "&cate_id={$cate_id}";
}
if($area_id > 0){
    $rewriteStatus = 0;
    $where.= " AND area_id={$area_id} ";
    $url .= "&area_id={$area_id}";
}
if($street_id > 0){
    $rewriteStatus = 0;
    $where.= " AND street_id={$street_id} ";
    $url .= "&street_id={$street_id}";
}
if($sex > 0){
    $rewriteStatus = 0;
    $where.= " AND sex={$sex} ";
    $url .= "&sex={$sex}";
}
if($xueli > 0){
    $rewriteStatus = 0;
    $where.= " AND xueli={$xueli} ";
    $url .= "&xueli={$xueli}";
}
if($work_status > 0){
    $rewriteStatus = 0;
    $where.= " AND work_status={$work_status} ";
    $url .= "&work_status={$work_status}";
}
if($jingyan > 0){
    $rewriteStatus = 0;
    $where.= " AND work_jingyan={$jingyan} ";
    $url .= "&jingyan={$jingyan}";
}
if($refresh_type > 0){
    $rewriteStatus = 0;
    $min_refresh_time = TIMESTAMP;
    if($refresh_type == 1){
        $min_refresh_time = $min_refresh_time - (1 * 86400);
    }else if($refresh_type == 2){
        $min_refresh_time = $min_refresh_time - (7 * 86400);
    }else if($refresh_type == 3){
        $min_refresh_time = $min_refresh_time - (14 * 86400);
    }else if($refresh_type == 4){
        $min_refresh_time = $min_refresh_time - (30 * 86400);
    }
    $where.= " AND refresh_time >= {$min_refresh_time} ";
    $url .= "&refresh_type={$refresh_type}";
}
$cate_child_search = '';
if($cate_child_id > 0){
    $cate_child_search = '-'.$cate_child_id.'-';
}
if(!empty($cate_child_search)){
    $cate_child_searchTmp = str_replace(array('%', '_'),'',$cate_child_search);
    $where .= " AND cate_child_search LIKE '%{$cate_child_searchTmp}%'";
    $url .= "&cate_child_search={$cate_child_search}";
}
if(!empty($keyword)){
    $rewriteStatus = 0;
    $keywordTmp = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND search_text LIKE '%{$keywordTmp}%'";
    $url .= "&keyword={$keyword}";
}

$order = " ORDER BY top_status DESC,refresh_time DESC,id DESC  ";

$pagesize = 20;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count($where);

$resumeListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_list($where,$order,$start,$pagesize,$cate_child_search,$keyword);
$resumeList = list_resume($resumeListTmp);

if($rewriteStatus == 1){
    $pageArr['link'] = tom_zppc_url('resumelist',$site_id,array('cate_id'=>$cate_id,'cate_child_id'=>$cate_child_id,'page'=>'{page}'));
}else{
    $pageArr['link'] = $_G['siteurl']."plugin.php?id=tom_zppc&site={$site_id}&mod=resumelist&{$url}&page={page}";
}
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$cateName = $cateChildName = '';
if($cate_id > 0){
    $cateName = $cateList[$cate_id]['name'];
}
if($cate_child_id > 0){
    $cateChildName = $cateChildList[$cate_child_id]['name'];
}

$seo_cate_name = $seo_cate_child_name = '';
if(!empty($cateName)){
    $seo_cate_name = $cateName;
}else{
    $seo_cate_name = lang('plugin/tom_zppc', 'list_resume_title');
}
if(!empty($cateChildName)){
    $seo_cate_child_name = $cateChildName;
}

$seo_title          = $zppcConfig['seo_resumelist_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{CATENAME}",$seo_cate_name, $seo_title);
$seo_title          = str_replace("{CATECHILDNAME}",$seo_cate_child_name, $seo_title);
$seo_title          = str_replace("{PAGE}",$page, $seo_title);

$seo_keywords       = $zppcConfig['seo_resumelist_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CATENAME}",$seo_cate_name, $seo_keywords);
$seo_keywords       = str_replace("{CATECHILDNAME}",$seo_cate_child_name, $seo_keywords);
$seo_keywords       = str_replace("{PAGE}",$page, $seo_keywords);

$seo_description    = $zppcConfig['seo_resumelist_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{CATENAME}",$seo_cate_name, $seo_description);
$seo_description    = str_replace("{CATECHILDNAME}",$seo_cate_child_name, $seo_description);
$seo_description    = str_replace("{PAGE}",$page, $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:resumelist");