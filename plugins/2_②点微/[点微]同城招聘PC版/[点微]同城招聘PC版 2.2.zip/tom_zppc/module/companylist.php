<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page             = intval($_GET['page'])>0 ? intval($_GET['page']):1;
$industry_id      = intval($_GET['industry_id'])>0? intval($_GET['industry_id']):0;

if($__Mobile == 1 && $zppcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=companylist&industry_id={$industry_id}");exit;
}

$industryListTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_all_list("" ,'ORDER BY isort ASC,id DESC', 0, 100);
$industryList = array();
if(is_array($industryListTmp) && !empty($industryListTmp)){
    foreach($industryListTmp as $key => $value){
        $industryList[$key] = $value;
        $industryList[$key]['name']  = str_replace("|","/","{$value['name']}");
        $industryList[$key]['link'] = tom_zppc_url('companylist',$site_id,array('industry_id'=>$value['id']));
    }
}

$guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 10 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 10 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$url = '';
$rewriteStatus = 1;
$where = ' AND c.show_status=1 AND r.shenhe_status = 1 ';
if(!empty($sql_in_site_ids)){
    $where.= " AND c.site_id IN({$sql_in_site_ids}) ";
}
if($industry_id > 0){
    $where .= "  AND r.industry_id = {$industry_id} ";
    $url .= "&industry_id={$industry_id}";
}

$order = " ORDER BY c.top_status DESC,c.csort ASC, c.id DESC  ";

$pagesize = 20;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_all_company_rzcompany_count($where);

$companyListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_all_company_rzcompany_list($where,$order,$start,$pagesize);
$companyList = list_company($companyListTmp);

if($rewriteStatus == 1){
    $pageArr['link'] = tom_zppc_url('companylist',$site_id,array('industry_id'=>$industry_id,'page'=>'{page}'));
}else{
    $pageArr['link'] = $_G['siteurl']."plugin.php?id=tom_zppc&site={$site_id}&mod=companylist&{$url}&page={page}";
}
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$industryUrl = tom_zppc_url('companylist',$site_id,array('industry_id'=>$industry_id));

$industryInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_by_id($industry_id);

$industryName = '';
if($industry_id > 0){
    $industryName  = str_replace("|","/","{$industryInfo['name']}");
}

$seo_industry_name = '';
if(!empty($industryName)){
    $seo_industry_name = $industryName;
}else{
    $seo_industry_name = lang('plugin/tom_zppc', 'list_company_title');
}

$seo_title          = $zppcConfig['seo_companylist_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{INDUSTRYNAME}",$seo_industry_name, $seo_title);
$seo_title          = str_replace("{PAGE}",$page, $seo_title);

$seo_keywords       = $zppcConfig['seo_companylist_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{INDUSTRYNAME}",$seo_industry_name, $seo_keywords);
$seo_keywords       = str_replace("{PAGE}",$page, $seo_keywords);

$seo_description    = $zppcConfig['seo_companylist_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{INDUSTRYNAME}",$seo_industry_name, $seo_description);
$seo_description    = str_replace("{PAGE}",$page, $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:companylist");