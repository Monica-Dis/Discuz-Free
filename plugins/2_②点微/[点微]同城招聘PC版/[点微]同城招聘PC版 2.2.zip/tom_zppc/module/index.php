<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($__Mobile == 1 && $zppcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=index");exit;
}

$zhaopinNum = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count(" AND site_id IN({$sql_in_site_ids})");
$zhaopinNum = $zhaopinNum + $tczhaopinConfig['virtual_zhaopin_num'];
$zhaopinNum = sprintf("%08d", $zhaopinNum);

$commonClicks = C::t('#tom_tczhaopin#tom_tczhaopin_common')->fetch_all_sun_clicks(" AND site_id IN({$sql_in_site_ids}) ");
$clicksNum = $commonClicks + $tczhaopinConfig['virtual_clicks'];
$clicksNum = sprintf("%08d", $clicksNum);

$index_nav_type = 1;
if($tczhaopinConfig['open_zhaopin_cate_child'] == 1 && $zppcConfig['index_nav_type'] == 2){
    $index_nav_type = 2;
}

$cateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,500);
$cateList = $cateIndexList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        
        $value['link'] = tom_zppc_url('list',$site_id,array('cate_id'=>$value['id']));
        
        $cateList[$value['id']] = $value;
        $cateIndexList[$value['id']] = $value;
    }
}

$cateChildListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND pid > 0 "," ORDER BY csort ASC,id DESC ",0,5000);
$cateChildList = array();
if(is_array($cateChildListTmp) && !empty($cateChildListTmp)){
    foreach($cateChildListTmp as $key => $value){
        $value['link'] = tom_zppc_url('list',$site_id,array('cate_id'=>$value['pid'],'cate_child_id'=>$value['id']));
        
        $cateChildList[$value['id']] = $value;
        $cateList[$value['pid']]['cateChildList'][$value['id']] = $value;
    }
}

if(is_array($cateIndexList) && !empty($cateIndexList)){
    foreach($cateIndexList as $key => $value){
        $i = 1;
        foreach($cateList[$value['id']]['cateChildList'] as $k => $v){
            if($i <= 2){
                $cateIndexList[$value['id']]['cateChildList'][] = $v;
            }
            $i++;
        }
    }
}

$focuspicListTmp = C::t('#tom_zppc#tom_zppc_focuspic')->fetch_all_list(" AND site_id={$site_id} AND type=1 "," ORDER BY fsort ASC,id DESC ", 0, 10);
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
}else if($site_id > 1){
    $focuspicListTmp = C::t('#tom_zppc#tom_zppc_focuspic')->fetch_all_list(" AND site_id=1 AND type=1 "," ORDER BY fsort ASC,id DESC ", 0, 10);
}
$focuspicList = array();
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
    foreach($focuspicListTmp as $key => $value){
        $focuspicList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $focuspicList[$key]['picurl'] = $picurl;
        $focuspicList[$key]['link'] = str_replace("{site}",$site_id, $value['link']);
    }
}
$focuspicCount = count($focuspicList);

$guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi IN(2,3,4,12,13,14) AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi IN(2,3,4,12,13) AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoLine4List = $guanggaoTonglan1List = $guanggaoTonglan2List = $guanggaoTonglan3List = $guanggaoTonglan4List = $guanggaoTonglan5List = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        if($value['weizhi'] == 2){
            $guanggaoTonglan1List[] = $guanggaoItemTmp;
        }
        if($value['weizhi'] == 3){
            $guanggaoTonglan2List[] = $guanggaoItemTmp;
        }
        if($value['weizhi'] == 4){
            $guanggaoTonglan3List[] = $guanggaoItemTmp;
        }
        if($value['weizhi'] == 12){
            $guanggaoTonglan4List[] = $guanggaoItemTmp;
        }
        if($value['weizhi'] == 13){
            $guanggaoTonglan5List[] = $guanggaoItemTmp;
        }
        if($value['weizhi'] == 14){
            $guanggaoLine4List[] = $guanggaoItemTmp;
        }
    }
}

$linksListTmp = C::t('#tom_zppc#tom_zppc_links')->fetch_all_list(" AND site_id={$site_id} "," ORDER BY lsort ASC,id DESC ");
if(is_array($linksListTmp) && !empty($linksListTmp)){
}else{
    $linksListTmp = C::t('#tom_zppc#tom_zppc_links')->fetch_all_list(" AND site_id=1 "," ORDER BY lsort ASC,id DESC ");
}
$linksList = array();
if(is_array($linksListTmp) && !empty($linksListTmp)){
    foreach($linksListTmp as $key => $value){
        $linksList[$key] = $value;
        $linksList[$key]['link'] = str_replace("{site}",$site_id, $value['link']);
    }
}
$linksCount = count($linksList);

$zpSearchArr = array();
$zhaopinSearchArr = explode('|', $tczhaopinConfig['zhaopin_search_str']);
if(is_array($zhaopinSearchArr) && !empty($zhaopinSearchArr)){
    foreach($zhaopinSearchArr as $key => $value){
        $zpSearchArr[] = daddslashes($value);
    }
}

$zpSearchCount = count($zpSearchArr);

$zpWhere = ' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ';
if(!empty($sql_in_site_ids)){
    $zpWhere .= " AND site_id IN({$sql_in_site_ids}) ";
}

$zpCount = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count($zpWhere);
$tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list($zpWhere," ORDER BY top_status DESC,over_status ASC,refresh_time DESC,id DESC ",0,$zppcConfig['index_zhaopinlist_num']);
$tczhaopinList = list_zhaopin($tczhaopinListTmp);

$zpNewWhere = ' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ';
if(!empty($sql_in_site_ids)){
    $zpNewWhere .= " AND site_id IN({$sql_in_site_ids}) ";
}
$tczhaopinNewListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list($zpNewWhere," ORDER BY id DESC ",0,$zppcConfig['index_zhaopinlist_new_num']);
$tczhaopinNewList = list_zhaopin($tczhaopinNewListTmp);

$cpWhere = ' AND c.show_status=1 AND r.shenhe_status = 1 ';
if(!empty($sql_in_site_ids)){
    $cpWhere .= " AND c.site_id IN({$sql_in_site_ids}) ";
}

$cpCount = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_all_company_rzcompany_count($cpWhere);
$companyListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_company")->fetch_all_company_rzcompany_list($cpWhere, 'ORDER BY c.tuijian_status DESC,c.top_status DESC,c.csort ASC, c.id DESC', 0, $zppcConfig['index_companylist_num']);
$companyList = list_company($companyListTmp);

$reWhere = ' AND status=1 AND shenhe_status=1 AND gongkai_status = 1 AND deleted = 0 ';
if(!empty($sql_in_site_ids)){
    $reWhere .= " AND site_id IN({$sql_in_site_ids}) ";
}

$reCount = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_all_count($reWhere);
$resumeListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_all_list($reWhere, 'ORDER BY top_status DESC,refresh_time DESC,id DESC', 0, $zppcConfig['index_resumelist_num']);
$resumeList = list_resume($resumeListTmp);

$seo_title          = $zppcConfig['seo_index_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);

$seo_keywords       = $zppcConfig['seo_index_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);

$seo_description    = $zppcConfig['seo_index_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:index");