<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function list_zhaopin($tczhaopinListTmp){
    global $_G,$tongchengConfig,$site_id,$tomSysOffset,$welfareArray;
    
    $tczhaopinList = array();
    if(is_array($tczhaopinListTmp) && !empty($tczhaopinListTmp)){

        $zhaopinIdsArrTmp = $cateIdsArrTmp = $districtIdsArrTmp = $companyIdsArrTmp = $rzcompanyIdsArrTmp = $industryIdsArrTmp = $natureIdsArrTmp = $scaleIdsArrTmp = array();
        foreach ($tczhaopinListTmp as $key => $value) {
            $zhaopinIdsArrTmp[] = $value['id'];
            $userIdsArrTmp[] = $value['user_id'];
            $cateIdsArrTmp[] = $value['cate_id'];
            $cateIdsArrTmp[] = $value['cate_child_id'];
            if($value['area_id'] > 0){
                $districtIdsArrTmp[] = $value['area_id'];
            }
            if($value['street_id'] > 0){
                $districtIdsArrTmp[] = $value['street_id'];
            }
            $companyIdsArrTmp[] = $value['company_id'];
        }
        
        $userListTmp = array();
        if(is_array($userIdsArrTmp) && !empty($userIdsArrTmp)){
            $userIdsStrTmp = implode(',', $userIdsArrTmp);
            $userArrTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_list(" AND id IN({$userIdsStrTmp}) "," ORDER BY id DESC ",0,1000);
            if(is_array($userArrTmp) && !empty($userArrTmp)){
                foreach($userArrTmp as $key => $value){
                    $userListTmp[$value['id']] = $value;
                }
            }
        }
                
        $cateListTmp = array();
        if(is_array($cateIdsArrTmp) && !empty($cateIdsArrTmp)){
            $cateIdsStrTmp = implode(',', $cateIdsArrTmp);
            $cateArrTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list(" AND id IN({$cateIdsStrTmp}) "," ORDER BY id ASC ",0,2000);
            if(is_array($cateArrTmp) && !empty($cateArrTmp)){
                foreach($cateArrTmp as $key => $value){
                    $cateListTmp[$value['id']] = $value;
                }
            }
        }

        $districtListTmp = array();
        if(is_array($districtIdsArrTmp) && !empty($districtIdsArrTmp)){
            $districtIdsStrTmp = implode(',', $districtIdsArrTmp);
            $districtArrTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_list(" AND id IN({$districtIdsStrTmp}) "," ORDER BY id ASC ",0,2000);
            if(is_array($districtArrTmp) && !empty($districtArrTmp)){
                foreach($districtArrTmp as $key => $value){
                    $districtListTmp[$value['id']] = $value;
                }
            }
        }
        
        $companyListTmp = array();
        if(is_array($companyIdsArrTmp) && !empty($companyIdsArrTmp)){
            $companyIdsStrTmp = implode(',', $companyIdsArrTmp);
            $companyArrTmp = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_all_list(" AND id IN({$companyIdsStrTmp}) "," ORDER BY id ASC ",0,200);
            if(is_array($companyArrTmp) && !empty($companyArrTmp)){
                foreach($companyArrTmp as $key => $value){
                    $companyListTmp[$value['id']] = $value;
                    $rzcompanyIdsArrTmp[] = $value['renzheng_company_id'];
                }
            }
        }
        
        $rzcompanyListTmp = array();
        if(is_array($rzcompanyIdsArrTmp) && !empty($rzcompanyIdsArrTmp)){
            $rzcompanyIdsStrTmp = implode(',', $rzcompanyIdsArrTmp);
            $rzcompanyArrTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_list(" AND id IN({$rzcompanyIdsStrTmp}) "," ORDER BY id ASC ",0,200);
            if(is_array($rzcompanyArrTmp) && !empty($rzcompanyArrTmp)){
                foreach($rzcompanyArrTmp as $key => $value){
                    $rzcompanyListTmp[$value['id']] = $value;
                    $industryIdsArrTmp[] = $value['industry_id'];
                    $natureIdsArrTmp[]   = $value['nature_id'];
                    $scaleIdsArrTmp[]   = $value['scale_id'];
                    
                    if(!preg_match('/^http/', $value['logo']) ){
                        if(strpos($value['logo'], 'source/plugin/tom_') === FALSE){
                            $companyPicurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['logo'];
                        }else{
                            $companyPicurlTmp = $_G['siteurl'].$value['logo'];
                        }
                    }else{
                        $companyPicurlTmp = $value['logo'];
                    }

                    $rzcompanyListTmp[$value['id']]['logo'] = $companyPicurlTmp;
                }
            }
        }
        
        $industryListTmp = array();
        if(is_array($industryIdsArrTmp) && !empty($industryIdsArrTmp)){
            $industryIdsStrTmp = implode(',', $industryIdsArrTmp);
            $industryArrTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_all_list(" AND id IN({$industryIdsStrTmp}) "," ORDER BY id ASC ",0,200);
            if(is_array($industryArrTmp) && !empty($industryArrTmp)){
                foreach($industryArrTmp as $key => $value){
                    $industryListTmp[$value['id']] = $value;

                }
            }
        }
        
        $natureListTmp = array();
        if(is_array($natureIdsArrTmp) && !empty($natureIdsArrTmp)){
            $natureIdsStrTmp = implode(',', $natureIdsArrTmp);
            $natureArrTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_nature')->fetch_all_list(" AND id IN({$natureIdsStrTmp}) "," ORDER BY id ASC ",0,200);
            if(is_array($natureArrTmp) && !empty($natureArrTmp)){
                foreach($natureArrTmp as $key => $value){
                    $natureListTmp[$value['id']] = $value;

                }
            }
        }
        
        $scaleListTmp = array();
        if(is_array($scaleIdsArrTmp) && !empty($scaleIdsArrTmp)){
            $scaleIdsStrTmp = implode(',', $scaleIdsArrTmp);
            $scaleArrTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_scale')->fetch_all_list(" AND id IN({$scaleIdsStrTmp}) "," ORDER BY id ASC ",0,200);
            if(is_array($scaleArrTmp) && !empty($scaleArrTmp)){
                foreach($scaleArrTmp as $key => $value){
                    $scaleListTmp[$value['id']] = $value;

                }
            }
        }
        
        foreach ($tczhaopinListTmp as $key => $value) {
            $tczhaopinList[$key] = $value;
            
            $userInfoTmp = $userListTmp[$value['user_id']];
            if(!preg_match('/^http/', $userInfoTmp['picurl']) ){
                $userInfoTmp['picurl'] = $_G['siteurl'].$userInfoTmp['picurl'];
            }
            $tczhaopinList[$key]['userInfo']        = $userInfoTmp;

            $tczhaopinList[$key]['area_street'] = '';
            $areaNameTmp = '';
            if(!empty($value['area_id'])){
                $areaInfoTmp = $districtListTmp[$value['area_id']];
                $areaNameTmp = $areaInfoTmp['name'];
            }
            $streetNameTmp = '';
            if(!empty($value['street_id'])){
                $streetInfoTmp = $districtListTmp[$value['street_id']];
                $streetNameTmp = $streetInfoTmp['name'];
            }
            if(!empty($areaNameTmp) && !empty($streetNameTmp)){
                $tczhaopinList[$key]['area_street'] = $areaNameTmp."-".$streetNameTmp;
            }else{
                $tczhaopinList[$key]['area_street'] = $areaNameTmp;
            }
         
            $workWelfareArr = explode('-', trim($value['work_welfare'], '-'));
            $welfareList = array();
            if(is_array($welfareArray) && !empty($welfareArray)){
                foreach($welfareArray as $k => $v){
                    if(in_array($k,$workWelfareArr)){
                        $welfareList[$k]['name'] = $v;
                    }
                }
            }
            
            $tczhaopinList[$key]['month']      = dgmdate($value['refresh_time'],"n",$tomSysOffset);
            $tczhaopinList[$key]['day']        = dgmdate($value['refresh_time'],"j",$tomSysOffset);
            
            $tczhaopinList[$key]['companyRenzheng']     = 0;
            $rzConpanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list(" AND user_id = {$value['user_id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
            if(is_array($rzConpanyInfoTmp) && !empty($rzConpanyInfoTmp[0]) && $rzConpanyInfoTmp[0]['id'] > 0){
                $tczhaopinList[$key]['companyRenzheng']     = 1;
            }
            $companyInfoTmp   = $companyListTmp[$value['company_id']];
            $rzcompanyInfoTmp = $rzcompanyListTmp[$companyInfoTmp['renzheng_company_id']];
            $industryInfoTmp  = $industryListTmp[$rzcompanyInfoTmp['industry_id']];
            $natureInfoTmp    = $natureListTmp[$rzcompanyInfoTmp['nature_id']];
            $scaleInfoTmp     = $scaleListTmp[$rzcompanyInfoTmp['scale_id']];
            $companyPicurlTmp = $rzcompanyListTmp[$companyInfoTmp['renzheng_company_id']]['logo'];
            $companyNameTmp   = $rzcompanyListTmp[$companyInfoTmp['renzheng_company_id']]['name'];
            $industryInfoTmp['name'] = str_replace("|"," / ","{$industryInfoTmp['name']}");
           
            $tczhaopinList[$key]['welfareList']            = $welfareList;
            $tczhaopinList[$key]['companyPicurl']          = $companyPicurlTmp;
            $tczhaopinList[$key]['companyName']            = $companyNameTmp;
            $tczhaopinList[$key]['rzcompanyInfo']          = $rzcompanyInfoTmp;
            $tczhaopinList[$key]['companyInfo']            = $companyInfoTmp;
            $tczhaopinList[$key]['industryInfo']           = $industryInfoTmp;
            $tczhaopinList[$key]['natureInfo']             = $natureInfoTmp;
            $tczhaopinList[$key]['scaleInfo']              = $scaleInfoTmp;
            $tczhaopinList[$key]['company_link']           = tom_zppc_url('companyinfo',$site_id,array('company_id'=>$companyInfoTmp['id']));
            $tczhaopinList[$key]['link']                   = tom_zppc_url('zhaopininfo',$site_id,array('tczhaopin_id'=>$value['id']));
        }
    }
    return $tczhaopinList;
}