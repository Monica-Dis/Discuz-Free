<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$resume_id = intval($_GET['resume_id'])>0? intval($_GET['resume_id']):0;

if($__Mobile == 1 && $zppcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=resumeinfo&resume_id={$resume_id}");exit;
}

$resumeInfo = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($resume_id);

if(is_array($resumeInfo) && !empty($resumeInfo) && $resumeInfo['deleted'] == 0){
}else{
    dheader('location:'."{$resumelistUrl}");exit;
}

if(!empty($resumeInfo['avatar'])){
    if(!preg_match('/^http/', $resumeInfo['avatar'])){
        if(strpos($resumeInfo['avatar'], 'source/plugin/tom_') === FALSE){
            $avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$resumeInfo['avatar'];
        }else{
            $avatar = $_G['siteurl'].$resumeInfo['avatar'];
        }
    }else{
        $avatar = $resumeInfo['avatar'];
    }
}else{
    if($resumeInfo['sex'] == 1){
        $avatar = $man_resume_avatar;
    }else if($resumeInfo['sex'] == 2){
        $avatar = $woman_resume_avatar;
    }
}

$cateInfo     = C::t("#tom_tczhaopin#tom_tczhaopin_cate")->fetch_by_id($resumeInfo['cate_id']);
$areaInfo     = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($resumeInfo['area_id']);
$streetInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($resumeInfo['street_id']);

$cateUrl      = tom_zppc_url('resumelist',$site_id,array('cate_id'=>$resumeInfo['cate_id']));
$reUrl        = tom_zppc_url('resumeinfo',$site_id,array('resume_id'=>$resumeInfo['id']));

$shortname    = cutstr($resumeInfo['name'], 2,'');
$refresh_time = dgmdate($resumeInfo['refresh_time'],'Y-m-d',$tomSysOffset);
$age          = dgmdate(TIMESTAMP,"Y",$tomSysOffset) - $resumeInfo['birth_year'];
$tel          = cutstr($resumeInfo['tel'], 3,'********');

$work_jingli = str_replace("\r\n","<br/>",$resumeInfo['work_jingli']);
$work_jingli = str_replace("\n","<br/>",$work_jingli);
$work_jingli = str_replace("\r","<br/>",$work_jingli);
$work_jingli = preg_replace("/\d{7}/", '*****', $work_jingli);

$edu_jingli = str_replace("\r\n","<br/>",$resumeInfo['edu_jingli']);
$edu_jingli = str_replace("\n","<br/>",$edu_jingli);
$edu_jingli = str_replace("\r","<br/>",$edu_jingli);
$edu_jingli = preg_replace("/\d{7}/", '*****', $edu_jingli);

$describe   = str_replace("\r\n","<br/>",$resumeInfo['describe']);
$describe   = str_replace("\n","<br/>",$describe);
$describe   = str_replace("\r","<br/>",$describe);
$describe   = preg_replace("/\d{7}/", '*****', $describe);

DB::query("UPDATE ".DB::table('tom_tczhaopin_resume')." SET clicks=clicks+1 WHERE id='{$resume_id}'", 'UNBUFFERED');

$guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 9 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 9 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$resumeLookStatus = $resumeCollectStatus = $shenyuVipResumeNum = 0;

if($__UserInfo['id'] > 0){
    
    if($resumeInfo['user_id'] != $__UserInfo['id']){
        
        $rencaiInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_rencai")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND resume_id = {$resume_id} ", 'ORDER BY id DESC', 0, 1);
        if(is_array($rencaiInfoTmp) && $rencaiInfoTmp[0]['id'] > 0){
            $resumeLookStatus = 1;
        }
        
        if($resumeLookStatus == 0 && $tczhaopinConfig['show_resume_must_fabu'] == 1){
            $fabuZhaopinCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND shenhe_status = 1 AND status = 1 AND user_id = {$__UserInfo['id']} ");
            if($fabuZhaopinCount == 0){
                $resumeLookStatus = 2;
            }
        }
        
        if($resumeLookStatus == 0){
            $companyRenzhengStatus = 0;
            $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$__UserInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
            if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
                $companyRenzhengStatus = 1;
            }
            $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND type = 3 AND deduct_type = 1 ");
            if($companyRenzhengStatus == 1){
                $freeResumeNum = $tczhaopinConfig['company_free_resume_num'];
            }else{
                $freeResumeNum = $tczhaopinConfig['personal_free_resume_num'];
            }
            if($freeResumeNum > $userLogCount){
                $resumeLookStatus = 3;
            }
        }

        if($resumeLookStatus == 0){
            $userVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($__UserInfo['id']);
            if($userVipInfo['vip_id'] > 0 && $userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
                $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
                $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND type = 3 AND deduct_type = 2");
                if($vipInfo['resume_num'] > $userVipLogCount){
                    $resumeLookStatus = 4;
                    $shenyuVipResumeNum = $vipInfo['resume_num'] - $userVipLogCount;
                }
            }
        }

        $historyListTmp = C::t("#tom_tczhaopin#tom_tczhaopin_history")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND resume_id = {$resume_id} ", 'ORDER BY id DESC', 0, 1);
        if(is_array($historyListTmp) && $historyListTmp[0]['id'] > 0){}else{
            $insertData = array();
            $insertData['user_id']      = $__UserInfo['id'];
            $insertData['resume_id']    = $resume_id;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tczhaopin#tom_tczhaopin_history')->insert($insertData);
        }

    }else{
        $resumeLookStatus = 1;
    }

    $collectInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume_collect')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND resume_id = {$resume_id}");
    if(is_array($collectInfoTmp) && !empty($collectInfoTmp[0])){
        $resumeCollectStatus = 1;
    }

}

$lookResumeUrl = $_G['siteurl']."plugin.php?id=tom_zppc:ajax&site={$site_id}&resume_id={$resume_id}&act=look_resume&formhash=".$formhash;

$resumeInfoUrl = $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=resumeinfo&resume_id={$resumeInfo['id']}";

$collectAjaxUrl = $_G['siteurl']."plugin.php?id=tom_tczhaopin:ajax&site={$site_id}&act=collectResume&resume_id={$resume_id}&user_id={$__UserInfo['id']}&formhash=".$formhash;

if($resumeInfo['sex'] == 1){
    $seo_name = $shortname.lang('plugin/tom_zppc', 'resume_sex_1');
}else{
    $seo_name = $shortname.lang('plugin/tom_zppc', 'resume_sex_2');
}

$seo_title          = $zppcConfig['seo_resumeinfo_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{NAME}",$seo_name, $seo_title);

$seo_keywords       = $zppcConfig['seo_resumeinfo_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{NAME}",$seo_name, $seo_keywords);

$seo_description    = $zppcConfig['seo_resumeinfo_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{NAME}",$seo_name, $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:resumeinfo");