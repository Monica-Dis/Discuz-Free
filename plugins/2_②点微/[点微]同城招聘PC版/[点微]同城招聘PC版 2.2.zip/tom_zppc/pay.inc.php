<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$zppcConfig         = $_G['cache']['plugin']['tom_zppc'];
$tczhaopinConfig    = $_G['cache']['plugin']['tom_tczhaopin'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

## tcrenzheng start
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')){
    $tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
    if($tcrenzhengConfig['open_tcrenzheng'] == 1){
        $__ShowTcrenzheng = 1;
    }
}
## tcrenzheng end
## xiaofenlei start
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')){
    $xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
    $__ShowXiaofenlei = 1;
}
## xiaofenlei end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.utf.php';
}
$welfareArray = array();
$welfare_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['welfare_list']); 
$welfare_list_str = str_replace("\n","{n}",$welfare_list_str);
$welfare_list_arr = explode("{n}", $welfare_list_str);
if(is_array($welfare_list_arr) && !empty($welfare_list_arr)){
    foreach ($welfare_list_arr as $key => $value){
        $welfare_list_item = explode("|", $value);
        $welfare_list_item_id = intval($welfare_list_item[0]);
        $welfare_list_item_name = trim($welfare_list_item[1]);
        if($welfare_list_item_id > 0 && !empty($welfare_list_item_name)){
            $welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
        }
    }
}

$agesArray = array();
$ages_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['zhaopin_ages_list']); 
$ages_list_str = str_replace("\n","{n}",$ages_list_str);
$ages_list_arr = explode("{n}", $ages_list_str);
if(is_array($ages_list_arr) && !empty($ages_list_arr)){
    foreach ($ages_list_arr as $key => $value){
        $ages_list_item = explode("|", $value);
        $ages_list_item_id = intval($ages_list_item[0]);
        $ages_list_item_name = trim($ages_list_item[1]);
        if($ages_list_item_id > 0 && !empty($ages_list_item_name)){
            $agesArray[$ages_list_item_id] = $ages_list_item_name;
        }
    }
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/class/function.core.php';

$_G['m_siteurl'] = $_G['siteurl'];

$zppcConfig['zhaopin_hosts']    = trim($zppcConfig['zhaopin_hosts']);
$zppcConfig['tongcheng_hosts']  = trim($zppcConfig['tongcheng_hosts']);

if($zppcConfig['open_zhaopin_hosts'] == 1 && !empty($zppcConfig['zhaopin_hosts']) && !empty($zppcConfig['tongcheng_hosts'])){
    
    $zppcConfig['tongcheng_hosts']  = rtrim($zppcConfig['tongcheng_hosts'], '/');
    $zppcConfig['tongcheng_hosts']  = $zppcConfig['tongcheng_hosts'].'/';
    
    $_G['m_siteurl'] = $zppcConfig['tongcheng_hosts'];
    
}

$tempDir = "/source/plugin/tom_zppc/data/payqrcode/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0755); 
}

$act = isset($_GET['act'])? addslashes($_GET['act']):"zhaopin";

if($act == "zhaopin" && submitcheck('title') && $userStatus){
    
    $outArr = array(
        'code'=> 1,
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id                    = intval($_GET['site_id'])>0? intval($_GET['site_id']):1;
    $title                      = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title                      = dhtmlspecialchars($title);
    $type                       = isset($_GET['type'])? intval($_GET['type']):0;
    $cate_id                    = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id              = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $jianzhi_cate_id            = isset($_GET['jianzhi_cate_id'])? intval($_GET['jianzhi_cate_id']):0;
    $work_salary                = isset($_GET['work_salary'])? intval($_GET['work_salary']):0;
    $work_salary_min            = intval($_GET['work_salary_min'])>0? intval($_GET['work_salary_min']):0;
    $work_salary_max            = intval($_GET['work_salary_max'])>0? intval($_GET['work_salary_max']):0;
    $jianzhi_work_salary        = isset($_GET['jianzhi_work_salary'])? intval($_GET['jianzhi_work_salary']):0;
    $jianzhi_work_salary_unit   = isset($_GET['jianzhi_work_salary_unit'])? intval($_GET['jianzhi_work_salary_unit']):0;
    $jianzhi_jiesuan_fangshi    = isset($_GET['jianzhi_jiesuan_fangshi'])? intval($_GET['jianzhi_jiesuan_fangshi']):0;
    $renshu                     = isset($_GET['renshu'])? intval($_GET['renshu']):0;
    $demand_sex                 = isset($_GET['demand_sex'])? intval($_GET['demand_sex']):0;
    $demand_ages                = isset($_GET['demand_ages'])? intval($_GET['demand_ages']):0;
    $demand_xueli               = isset($_GET['demand_xueli'])? intval($_GET['demand_xueli']):0;
    $demand_jingyan             = isset($_GET['demand_jingyan'])? intval($_GET['demand_jingyan']):0;
    $demand_desc                = isset($_GET['demand_desc'])? addslashes($_GET['demand_desc']):'';
    $demand_desc                = dhtmlspecialchars($demand_desc);
    $area_id                    = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id                  = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $lng                        = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                        = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address                    = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address                    = dhtmlspecialchars($address);
    $xm                         = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $company_name               = isset($_GET['company_name'])? addslashes($_GET['company_name']):'';
    $video_url                  = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_pic                  = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic                  = dhtmlspecialchars($video_pic);
    
    $fabu_days                  = intval($_GET['fabu_days'])>0? intval($_GET['fabu_days']):0;
    
    $firstFabuDaysStatus = $fabu_pay_price = 0;
    if($fabu_days > 0){
        $zhaopin_show_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['shoufei_zhaopin_price_list']); 
        $zhaopin_show_list_str = str_replace("\n","{n}",$zhaopin_show_list_str);
        $zhaopin_show_list_arr = explode("{n}", $zhaopin_show_list_str);
        $i = 1;
        if(is_array($zhaopin_show_list_arr) && !empty($zhaopin_show_list_arr)){
            foreach ($zhaopin_show_list_arr as $key => $value){
                $zhaopinShowInfoTmp = array();
                $zhaopinShowInfoTmp = explode("|", $value);
                if($zhaopinShowInfoTmp[0] == $fabu_days){
                    $fabu_pay_price = $zhaopinShowInfoTmp[1];
                    if($i == 1){
                        $firstFabuDaysStatus = 1;
                    }
                }
                $i++;
            }
        }
        if($fabu_pay_price > 0){}else{
            $outArr = array(
                'code'  => 200,
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photopsort_") !== false){
            $kk = intval(ltrim($key, "photopsort_"));
            $photoArr[$kk]['psort'] = addslashes($value);
        }
    }
    
    $__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
    if(!empty($__CommonInfo['forbid_word'])){
        $forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
        $forbid_word = str_replace(array("\\*"), array('.*'), $forbid_word);
        $forbid_word = '.*('.$forbid_word.').*';
        $forbid_word = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word).')$/i';
        $contentTmpTmp = $title.$company_name.$demand_desc;
        $contentTmpTmp = str_replace("\r\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\r","",$contentTmpTmp);
        if(@preg_match($forbid_word, $contentTmpTmp,$matches)) {
            $i = count($matches)-1;
            $word = '';
            if(isset($matches[$i]) && !empty($matches[$i])){
                $word = diconv($matches[$i],CHARSET,'utf-8');
            }
            if($tongchengConfig['safe_words_do'] == 1){
                $tczhaopinConfig['zhaopin_must_shenhe'] = 1;
            }else{
                $outArr = array(
                    'code'  => 200,
                    'status'=> 505,
                    'word'=> $word,
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    if($__ShowXiaofenlei == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php';
        if($xiaofenleiConfig['open_msgseccheck'] == 1){
            @$s_m_r = wx_msgSecCheck($title.$company_name.$demand_desc);
            if($s_m_r['code'] == 100){
                $tczhaopinConfig['zhaopin_must_shenhe'] = 1;
            }
            if($s_m_r['code'] == 500){
                $outArr = array(
                    'code'  => 200,
                    'status'=> 505,
                    'word'=> $s_m_r['word'],
                );
                echo json_encode($outArr); exit;
            }
        }
        $imgseccheck_listArr = unserialize($xiaofenleiConfig['imgseccheck_list']);
        if(array_search('2',$imgseccheck_listArr) !== false && $xiaofenleiConfig['open_imgseccheck'] == 1){
            if(is_array($photoArr) && !empty($photoArr)){
                foreach ($photoArr as $kk => $vv){
                    if(!preg_match('/^http/', $vv['picurl']) ){
                        if(strpos($vv['picurl'], 'source/plugin/tom_') === false){    
                            $check_picurl_tmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                        }else{
                            $check_picurl_tmp = $_G['siteurl'].$vv['picurl'];
                        }
                    }else{
                        $check_picurl_tmp = $vv['picurl'];
                    }
                    @$s_i_r = wx_imgSecCheck($check_picurl_tmp);
                    if($s_i_r['code'] == 500){
                        $tczhaopinConfig['zhaopin_must_shenhe'] = 1;
                    }
                }
            }
        }
    }
    
    $workWelfareArr = array();
    if(is_array($_GET['work_welfare']) && !empty($_GET['work_welfare'])){
        foreach($_GET['work_welfare'] as $key => $value){
            $workWelfareArr[] = intval($value);
        }
    }
    $work_welfare = '-'.implode('-', $workWelfareArr).'-';
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$__UserInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    $companyRenzhengStatus = 0;
    $rzCompanyInfo = array();
    if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
        $companyRenzhengStatus = 1;
        $rzCompanyInfo = $rzCompanyInfoTmp[0];
    }
    
    if($companyRenzhengStatus == 1){
        $company_name = $rzCompanyInfo['name'];
    }

    $search_text = '';
    if($type == 1){
        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_id);
        $cateChildInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_child_id);
        $search_text = $title.'-'.$cateInfo['name'].'-'.$cateChildInfo['name'].'-'.$company_name;
    }else if($type == 2){
        $jianzhiCateInfo =  C::t("#tom_tczhaopin#tom_tczhaopin_jianzhi_cate")->fetch_by_id($jianzhi_cate_id);
        $search_text = $title.'-'.$jianzhiCateInfo['name'].'-'.$company_name;
    }
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($__UserInfo['id']);
    if(is_array($companyInfo) && !empty($companyInfo)){ 
        update_company_status($companyInfo);
    }else{
        $insertData = array();
        $insertData['site_id']              = $site_id;
        $insertData['user_id']              = $__UserInfo['id'];
        $insertData['add_time']             = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_company')->insert($insertData)){
            $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($__UserInfo['id']);
            update_company_status($companyInfo);
        }
    }
    
    $vipInfo = array();
    $userVipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($__UserInfo['id']);
    if($userVipInfoTmp['vip_id'] > 0 && $userVipInfoTmp['expire_status'] == 1 && $userVipInfoTmp['expire_time'] > TIMESTAMP){
        $vipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfoTmp['vip_id']);
        if($vipInfoTmp && $vipInfoTmp > 0){
            $vipInfo = $vipInfoTmp;
        }
    }
    
    $fabuPayStatus = 1;
    if($fabuPayStatus == 1){
        $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND type = 1 AND deduct_type = 1 ");
        if($companyRenzhengStatus == 1){
            $freeFabuNum = $tczhaopinConfig['company_free_fabu_num'];
        }else{
            $freeFabuNum = $tczhaopinConfig['personal_free_fabu_num'];
        }
        if($freeFabuNum > $userLogCount && $firstFabuDaysStatus == 1){
            $fabuPayStatus = 2;
        }
    }

    if($fabuPayStatus == 1){
        if($vipInfo && $vipInfo['id'] > 0){
            $vipFabuNum = $vipInfo['fabu_num'];
            $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND expire_status = 3");
            if($vipFabuNum > $userVipLogCount){
                $fabuPayStatus = 3;
            }
        }
    }

    if($fabuPayStatus == 1 && $tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
        $zhaopinScorePayNum = ceil($fabu_pay_price * $tongchengConfig['pay_score_yuan']);
        if($__UserInfo['score'] >= $zhaopinScorePayNum){
            $fabuPayStatus = 4;
        }
    }
    
    $pay_price = 0;
    if($fabuPayStatus == 1){
        $pay_price = $fabu_pay_price;
    }
    
    $pay_score = 0;
    if($fabuPayStatus == 4){
        $pay_score = $zhaopinScorePayNum;
    }
        
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['user_id']          = $__UserInfo['id'];
    $insertData['company_id']       = $companyInfo['id'];
    $insertData['title']            = $title;
    $insertData['type']             = $type;
    if($type == 1){
        $insertData['cate_id']            = $cate_id;
        $insertData['cate_child_id']      = $cate_child_id;
    }else if($type == 2){
        $insertData['jianzhi_cate_id']    = $jianzhi_cate_id;
    }
    if($type == 1){
        $insertData['work_salary']          = $work_salary;
        $insertData['work_salary_min']      = $work_salary_min;
        $insertData['work_salary_max']      = $work_salary_max;
        $insertData['work_welfare']         = $work_welfare;
    }else if($type == 2){
        $insertData['jianzhi_work_salary']       = $jianzhi_work_salary;
        $insertData['jianzhi_work_salary_unit']  = $jianzhi_work_salary_unit;
        $insertData['jianzhi_jiesuan_fangshi']   = $jianzhi_jiesuan_fangshi;
    }
    $insertData['renshu']             = $renshu;
    $insertData['demand_sex']         = $demand_sex;
    $insertData['demand_ages']        = $demand_ages;
    $insertData['demand_xueli']       = $demand_xueli;
    $insertData['demand_jingyan']     = $demand_jingyan;
    $insertData['demand_desc']        = $demand_desc;
    $insertData['city_id']            = $city_id;
    $insertData['area_id']            = $area_id;
    $insertData['street_id']          = $street_id;
    $insertData['address']            = $address;
    $insertData['latitude']           = $lat;
    $insertData['longitude']          = $lng;
    $insertData['xm']                 = $xm;
    $insertData['tel']                = $tel;
    if($companyRenzhengStatus == 1){
        $insertData['company_name']            = $rzCompanyInfo['name'];
        $insertData['company_nature_id']       = $rzCompanyInfo['nature_id'];
        $insertData['company_industry_id']     = $rzCompanyInfo['industry_id'];
        $insertData['company_scale_id']        = $rzCompanyInfo['scale_id'];
    }else{
        $insertData['company_name']            = $company_name;
    }
    if(!empty($video_url)){
        $insertData['video_status']       = 1;
    }else{
        $insertData['video_status']       = 0;
    }
    $insertData['video_url']          = $video_url;
    $insertData['video_pic']          = $video_pic;
    $insertData['search_text']        = $search_text;
    
    if($tczhaopinConfig['zhaopin_must_shenhe'] == 1){
        $insertData['shenhe_status']    = 2;
    }else{
        $insertData['shenhe_status']    = 1;
    }
    
    $insertData['expire_status']    = 2;
    $insertData['status']           = 0;
    
    if($fabuPayStatus == 1){
        $insertData['pay_status']       = 1;
    }else{
        $insertData['pay_status']       = 0;
    }
    
    $insertData['refresh_time']     = TIMESTAMP;
    $insertData['add_time']         = TIMESTAMP;
    $insertData['client_ip_port']   = $_G['clientip'].'|'.$_SERVER['REMOTE_PORT'];
    
    if(C::t("#tom_tczhaopin#tom_tczhaopin")->insert($insertData)){
        
        $tczhaopin_id = C::t("#tom_tczhaopin#tom_tczhaopin")->insert_id();
        
        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['tczhaopin_id'] = $tczhaopin_id;
                $insertData['picurl']       = $value['picurl'];
                $insertData['psort']        = $value['psort'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tczhaopin#tom_tczhaopin_photo')->insert($insertData);
            }
        }
        
        if($fabuPayStatus == 2){
            
            $insertData = array();
            $insertData['user_id']              = $__UserInfo['id'];
            $insertData['tczhaopin_id']         = $tczhaopin_id;
            $insertData['deduct_type']          = 1;
            $insertData['type']                 = 1;
            $insertData['today_time']           = $nowDayTime;
            $insertData['log_time']             = TIMESTAMP;
            C::t("#tom_tczhaopin#tom_tczhaopin_log")->insert($insertData);
            
            $fabu_time = $fabu_days * 86400 + TIMESTAMP;
            
            $updateData = array();
            $updateData['expire_status']        = 1;
            $updateData['expire_time']          = $fabu_time;
            $updateData['status']               = 1;
            C::t("#tom_tczhaopin#tom_tczhaopin")->update($tczhaopin_id, $updateData);
        }
        
        if($fabuPayStatus == 3){
            
            $insertData = array();
            $insertData['user_id']              = $__UserInfo['id'];
            $insertData['tczhaopin_id']         = $tczhaopin_id;
            $insertData['deduct_type']          = 2;
            $insertData['type']                 = 1;
            $insertData['today_time']           = $nowDayTime;
            $insertData['log_time']             = TIMESTAMP;
            C::t("#tom_tczhaopin#tom_tczhaopin_log")->insert($insertData);
            
            $updateData = array();
            $updateData['expire_status']    = 3;
            $updateData['status']           = 1;
            C::t("#tom_tczhaopin#tom_tczhaopin")->update($tczhaopin_id, $updateData);
        }
        
        if($fabuPayStatus == 4){
            
            $updateData = array();
            $updateData['score'] = $__UserInfo['score'] - $pay_score;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
            
            $fabu_time = $fabu_days * 86400 + TIMESTAMP;

            $updateData = array();
            $updateData['expire_status']        = 1;
            $updateData['expire_time']          = $fabu_time;
            $updateData['status']               = 1;
            C::t("#tom_tczhaopin#tom_tczhaopin")->update($tczhaopin_id, $updateData);
            
            
            $insertData = array();
            $insertData['user_id']          = $__UserInfo['id'];
            $insertData['score_value']      = $pay_score;
            $insertData['old_value']        = $__UserInfo['score'];
            $insertData['log_type']         = 44;
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        }

        if($fabuPayStatus == 1){
            
            if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
                include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
            }else{
                $outArr = array(
                    'code'  => 200,
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }
            
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'code'  => 200,
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

            $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['tczhaopin_id']     = $tczhaopin_id;
            $insertData['type']             = 1;
            $insertData['user_id']          = $__UserInfo['id'];
            $insertData['openid']           = $__UserInfo['openid'];
            $insertData['order_no']         = $order_no;
            $insertData['fabu_days']        = $fabu_days;
            $insertData['fabu_price']       = $fabu_pay_price;
            $insertData['pay_price']        = $pay_price;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
                $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

                $insertData = array();
                $insertData['plugin_id']       = 'tom_tczhaopin';          
                $insertData['order_no']        = $order_no;                 
                $insertData['goods_id']        = $order_id;         
                $insertData['goods_name']      = $title;
                $insertData['goods_beizu']     = '';
                $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$tczhaopin_id;
                $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=myzhaopinlist';
                $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist"; 
                $insertData['allow_alipay']    = 1;
                $insertData['pay_price']       = $pay_price;
                $insertData['order_status']    = 1;
                $insertData['add_time']        = TIMESTAMP;
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    
                    $payurl = $_G['m_siteurl']."plugin.php?id=tom_pay&order_no=".$order_no;
                    
                    $payqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_zppc/data/payqrcode/'.md5($payurl).'.png';
                    $payqrcodeUrl = $_G['siteurl'].'source/plugin/tom_zppc/data/payqrcode/'.md5($payurl).'.png';
                    
                    if(file_exists($payqrcodeImg)){
                    }else{
                        QRcode::png($payurl,$payqrcodeImg,'H',5,2);
                    }
                    
                    $outArr = array(
                        'code'          => 200,
                        'status'        => 200,
                        'pay_status'    => 1,
                        'pay_price'     => $pay_price,
                        'payqrcode'     => $payqrcodeUrl,
                    );
                    echo json_encode($outArr); exit;
                }else{
                    $outArr = array(
                        'code'      => 200,
                        'status'    => 304,
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
        }else{
            
            update_zhaopin_tongcheng($tczhaopin_id);
            update_company_status($companyInfo);
            
            if(!empty($tongchengConfig['template_id']) && $tczhaopinConfig['zhaopin_must_shenhe'] == 1){
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
                $weixinClass = new weixinClass($appid,$appsecret);

                $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($manageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_fabuzhaopin_shenhe_msg'),
                        'keyword1'      => $tczhaopinConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }

                $zpmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinConfig['zpmanage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($zpmanageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_fabuzhaopin_shenhe_msg'),
                        'keyword1'      => $tczhaopinConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($zpmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }
            $outArr = array(
                'code'      => 200,
                'status'    => 200,
            );
            echo json_encode($outArr); exit;
        }
        
    }
    
    echo json_encode($outArr); exit;
    
}else if($act == "zhaopin_pay" && submitcheck('tczhaopin_id') && $userStatus){

    $outArr = array(
        'code'  => 1,
        'status'=> 1,
    );
    
    $tczhaopin_id  = intval($_GET['tczhaopin_id'])>0 ? intval($_GET['tczhaopin_id']):0;
    
    $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($tczhaopin_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinInfo['user_id']);
    
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
    }else{
        $outArr = array(
            'code'  => 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'code'  => 200,
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($tczhaopinInfo) && $tczhaopinInfo['pay_status'] == 1){ }else{
        $outArr = array(
            'code'  => 200,
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $orderInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_order")->fetch_all_list(" AND tczhaopin_id = {$tczhaopin_id} AND type = 1 ", 'ORDER BY id DESC', 0, 1);
    $orderInfo = array();
    if(is_array($orderInfoTmp) && !empty($orderInfoTmp[0]) && $orderInfoTmp[0]['order_status'] == 1 && $orderInfoTmp[0]['fabu_days'] > 0){
        $orderInfo = $orderInfoTmp[0];
    }else{
        $outArr = array(
            'code'  => 200,
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    $pay_price = $orderInfo['pay_price'];
    if($pay_price <= 0){
        $outArr = array(
            'code'  => 200,
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    $insertData = array();
    $insertData['site_id']          = $orderInfo['site_id'];
    $insertData['tczhaopin_id']     = $tczhaopin_id;
    $insertData['type']             = 1;
    $insertData['user_id']          = $userInfo['id'];
    $insertData['openid']           = $userInfo['openid'];
    $insertData['order_no']         = $order_no;
    $insertData['fabu_days']        = $orderInfo['fabu_days'];
    $insertData['fabu_price']       = $orderInfo['fabu_price'];
    $insertData['top_days']         = $orderInfo['top_days'];
    $insertData['top_price']        = $orderInfo['top_price'];
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
        $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tczhaopin';          
        $insertData['order_no']        = $order_no;                 
        $insertData['goods_id']        = $order_id;         
        $insertData['goods_name']      = $tczhaopinInfo['title'];
        $insertData['goods_beizu']     = '';
        $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$tczhaopin_id;
        $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=myzhaopinlist';
        $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist"; 
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $pay_price;
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            
            $payurl = $_G['m_siteurl']."plugin.php?id=tom_pay&order_no=".$order_no;
                    
            $payqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_zppc/data/payqrcode/'.md5($payurl).'.png';
            $payqrcodeUrl = $_G['siteurl'].'source/plugin/tom_zppc/data/payqrcode/'.md5($payurl).'.png';

            if(file_exists($payqrcodeImg)){
            }else{
                QRcode::png($payurl,$payqrcodeImg,'H',5,2);
            }

            $outArr = array(
                'code'          => 200,
                'status'        => 200,
                'pay_price'     => $pay_price,
                'payqrcode'     => $payqrcodeUrl,
            );
            echo json_encode($outArr); exit;
            
        }else{
            $outArr = array(
                'code'  => 200,
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    echo json_encode($outArr); exit;

}else if($act == "pay_refresh" && submitcheck('tczhaopin_id') && $userStatus){
    
    $outArr = array(
        'code'=> 1,
        'status'=> 1,
    );
    
    $tczhaopin_id   = intval($_GET['tczhaopin_id'])>0 ? intval($_GET['tczhaopin_id']):0;
    
    $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($tczhaopin_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinInfo['user_id']);
    
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
    }else{
        $outArr = array(
            'code'  => 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'code'  => 200,
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }

    if($userInfo['id'] > 0 && $tczhaopinInfo['id'] > 0){ }else{
        $outArr = array(
            'code'  => 200,
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $companyRenzhengStatus = 0;
    $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$userInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
        $companyRenzhengStatus = 1;
    }
    
    $refreshPayStatus = 1;
    if($refreshPayStatus == 1){
        $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$userInfo['id']} AND type = 2 AND today_time = {$nowDayTime} AND deduct_type = 1 ");
        if($companyRenzhengStatus == 1){
            $freeRefreshNum = $tczhaopinConfig['company_free_refresh_num'];
        }else{
            $freeRefreshNum = $tczhaopinConfig['personal_free_refresh_num'];
        }
        if($freeRefreshNum > $userLogCount){
            $refreshPayStatus = 2;
        }
    }
    if($refreshPayStatus == 1){
        $userVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($userInfo['id']);
        if($userVipInfo['vip_id'] > 0 && $userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
            $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
            $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$userInfo['id']} AND type = 2 AND today_time = {$nowDayTime} AND deduct_type = 2 ");
            if($vipInfo['refresh_num'] > $userLogCount){
                $refreshPayStatus = 3;
            }
        }
    }
    
    if($refreshPayStatus == 1){
        if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $scorePayNum = ceil(floatval($tczhaopinConfig['shoufei_zhaopin_refresh_price']) * $tongchengConfig['pay_score_yuan']);
            if($userInfo['score'] >= $scorePayNum){
                $refreshPayStatus = 4;
            }
        }
    }
    
    if($refreshPayStatus == 2 || $refreshPayStatus == 3){
        
        $insertData = array();
        $insertData['user_id']              = $userInfo['id'];
        $insertData['tczhaopin_id']         = $tczhaopin_id;
        if($refreshPayStatus == 2){
            $insertData['deduct_type']          = 1;
        }else if($refreshPayStatus == 3){
            $insertData['deduct_type']          = 2;
        }
        $insertData['type']                 = 2;
        $insertData['today_time']           = $nowDayTime;
        $insertData['log_time']             = TIMESTAMP;
        C::t("#tom_tczhaopin#tom_tczhaopin_log")->insert($insertData);
        
    }
    
    if($refreshPayStatus == 4){
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $scorePayNum;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $scorePayNum;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 48;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    }
    
    if($refreshPayStatus != 1){

        $companyRenzhengStatus = 0;
        $renzhengInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$userInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
        $renzhengInfo = array();
        if(is_array($renzhengInfoTmp) && !empty($renzhengInfoTmp)){
            $renzhengInfo = $renzhengInfoTmp[0];
            $companyRenzhengStatus = 1;
        }
        
        $updateData = array();
        if($companyRenzhengStatus == 1){
            $updateData['company_name']            = $renzhengInfo['name'];
            $updateData['company_nature_id']       = $renzhengInfo['nature_id'];
            $updateData['company_industry_id']     = $renzhengInfo['industry_id'];
            $updateData['company_scale_id']        = $renzhengInfo['scale_id'];
        }
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin')->update($tczhaopin_id,$updateData);
    }
    
    if($refreshPayStatus == 1){
        
        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        $pay_price = $tczhaopinConfig['shoufei_zhaopin_refresh_price'];

        $insertData = array();
        $insertData['site_id']          = $tczhaopinInfo['site_id'];
        $insertData['tczhaopin_id']     = $tczhaopin_id;
        $insertData['type']             = 3;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert($insertData)){
            $order_id = C::t('#tom_tczhaopin#tom_tczhaopin_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tczhaopin';          
            $insertData['order_no']        = $order_no;                 
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = $tczhaopinInfo['title'];
            $insertData['goods_beizu']     = lang('plugin/tom_tczhaopin', 'pay_refresh_beizu');
            $insertData['goods_url']       = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=myzhaopinlist';
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=myzhaopinlist';
            $insertData['fail_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist"; 
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                
                $payurl = $_G['m_siteurl']."plugin.php?id=tom_pay&order_no=".$order_no;
                    
                $payqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_zppc/data/payqrcode/'.md5($payurl).'.png';
                $payqrcodeUrl = $_G['siteurl'].'source/plugin/tom_zppc/data/payqrcode/'.md5($payurl).'.png';

                if(file_exists($payqrcodeImg)){
                }else{
                    QRcode::png($payurl,$payqrcodeImg,'H',5,2);
                }
                
                $outArr = array(
                    'code'          => 200,
                    'status'        => 200,
                    'pay_status'    => 1,
                    'pay_price'     => $pay_price,
                    'payqrcode'     => $payqrcodeUrl,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'code'  => 200,
                    'status'=> 304,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'code'  => 200,
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    update_zhaopin_tongcheng($tczhaopin_id);
    
    $outArr = array(
        'code'          => 200,
        'status'        => 200,
        'pay_status'    => 0,
    );
    echo json_encode($outArr); exit;
    
}else{
    $outArr = array(
        'code'  => 111111,
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}