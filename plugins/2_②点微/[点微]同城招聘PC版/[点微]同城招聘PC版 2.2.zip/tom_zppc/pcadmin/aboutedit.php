<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$about_id  = intval($_GET['about_id'])>0 ? intval($_GET['about_id']):0;
$aboutInfo = C::t('#tom_zppc#tom_zppc_about')->fetch_by_id($about_id);
if(empty($aboutInfo)){
    dheader('location:'.$pcadminUrl."&tmod=about");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=aboutedit&about_id={$about_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('title')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
    $asort          = isset($_GET['asort'])? intval($_GET['asort']):10;
    
    $updateData = array();
    $updateData['title']        = $title;
    $updateData['content']      = $content;
    $updateData['asort']        = $asort;
    $updateData['add_time']     = TIMESTAMP;
    if(C::t('#tom_zppc#tom_zppc_about')->update($about_id, $updateData)){
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$aboutInfo['content'] = stripcslashes($aboutInfo['content']);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:pcadmin/aboutedit");