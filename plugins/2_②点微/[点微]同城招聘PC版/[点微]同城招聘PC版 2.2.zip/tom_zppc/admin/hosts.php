<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=hosts';
$modListUrl = $adminListUrl.'&tmod=hosts';
$modFromUrl = $adminFromUrl.'&tmod=hosts';

$zppcConfig['zhaopin_hosts']    = trim($zppcConfig['zhaopin_hosts']);
$zppcConfig['tongcheng_hosts']  = trim($zppcConfig['tongcheng_hosts']);

$zhaopin_hosts = rtrim($zppcConfig['zhaopin_hosts'], '/');
$zhaopin_hosts = str_replace('http://', '', $zhaopin_hosts);
$zhaopin_hosts = str_replace('https://', '', $zhaopin_hosts);

$hosts = str_replace('.', '\.', $zhaopin_hosts);

$hostStr = <<<EOF
<h1>Apache Web Server &nbsp;&nbsp;<font color="#fd0d0d">{$Lang['hosts_apache_msg']}</font></h1>
<pre class="colorbox">
RewriteEngine On
RewriteBase /

RewriteCond %{HTTP_HOST} ^{HOSTS}$
RewriteRule ^/?$ /%{HTTP_HOST}
RewriteRule ^/{HOSTS}/?$ /plugin.php?id=tom_zppc&site=1&mod=index [L]

</pre>

<h1>Nginx Web Server &nbsp;&nbsp;<font color="#fd0d0d">{$Lang['hosts_nginx_msg']}</font></h1>
<pre class="colorbox">

if (\$host ~* "^{HOSTS}$"){
    rewrite ^/?$ /plugin.php?id=tom_zppc&site=1&mod=index last;
}

</pre>

<h1>IIS7+ Web Server </h1>
<pre class="colorbox">

&lt;rewrite&gt;
    &lt;rules&gt;

        &lt;rule name="zhaopin_hosts_rewrite" stopProcessing="true"&gt;
            &lt;match url=".*"/&gt;
            &lt;conditions logicalGrouping="MatchAll" trackAllCaptures="false"&gt;
                &lt;add input="{HTTP_HOST}" pattern="^{HOSTS}$"/&gt;
                &lt;add input="{REQUEST_URI}" pattern="^\/?$"/&gt;
            &lt;/conditions&gt;
            &lt;action type="Rewrite" url="plugin.php?id=tom_zppc&amp;amp;site=1&amp;amp;mod=index"/&gt;
        &lt;/rule&gt;

    &lt;/rules&gt;
&lt;/rewrite&gt;

</pre>
EOF;

$hostStr = str_replace('{HOSTS}', $hosts, $hostStr);

if($zppcConfig['open_zhaopin_hosts'] == 1 && !empty($zppcConfig['zhaopin_hosts']) && !empty($zppcConfig['tongcheng_hosts'])){
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['hosts_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['hosts_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    echo "<br/>";
    
    echo $hostStr;
    
}else{
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['hosts_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['hosts_help_1'] . '</li>';
    echo '<li>' . $Lang['hosts_no_open'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
}