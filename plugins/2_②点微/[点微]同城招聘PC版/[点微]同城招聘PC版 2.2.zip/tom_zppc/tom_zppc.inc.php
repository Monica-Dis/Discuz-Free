<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$timestamp = TIMESTAMP;
$zppcConfig = $_G['cache']['plugin']['tom_zppc'];
$tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = "20210813";

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')){}else{
    echo " no install https://addon.dismall.com/?@tom_tczhaopin.plugin";exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/qqface.php';
include DISCUZ_ROOT.'./source/plugin/tom_zppc/sitesinfo.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/class/function.page.php';
include DISCUZ_ROOT.'./source/plugin/tom_zppc/class/function.url.php';
include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/list_zhaopin.php';
include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/list_company.php';
include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/list_resume.php';
include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/list_meeting.php';

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.utf.php';
}

$__IsWeixin = $__Ios = $__Android = $__Mobile = 0;
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){ $__IsWeixin = 1;$__Mobile = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') !== false){$__Ios = 1;$__Mobile = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false){$__Android = 1;$__Mobile = 1;}

## tcadmin start
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
## tcadmin end
## tcrenzheng start
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')){
    $tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
    if($tcrenzhengConfig['open_tcrenzheng'] == 1){
        $__ShowTcrenzheng = 1;
    }
}
## tcrenzheng end
## video start
$__ShowVideo = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/video.inc.php')){
    $__ShowVideo = 1;
}
## video end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';
include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/site_lbs.php';

include DISCUZ_ROOT.'./source/plugin/tom_zppc/userinfo.php';

$__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
if(!$__CommonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tongcheng#tom_tongcheng_common')->insert($insertData);
}
if($site_id > 1){
    $__siteCommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id($site_id);
    if(!$__siteCommonInfo){
        $insertData = array();
        $insertData['id']      = $site_id;
        C::t('#tom_tongcheng#tom_tongcheng_common')->insert($insertData);
    }
}

$welfareArray = array();
$welfare_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['welfare_list']); 
$welfare_list_str = str_replace("\n","{n}",$welfare_list_str);
$welfare_list_arr = explode("{n}", $welfare_list_str);
if(is_array($welfare_list_arr) && !empty($welfare_list_arr)){
    foreach ($welfare_list_arr as $key => $value){
        $welfare_list_item = explode("|", $value);
        $welfare_list_item_id = intval($welfare_list_item[0]);
        $welfare_list_item_name = trim($welfare_list_item[1]);
        if($welfare_list_item_id > 0 && !empty($welfare_list_item_name)){
            $welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
        }
    }
}

$workStatusArray = array();
$work_status_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['work_status_list']); 
$work_status_list_str = str_replace("\n","{n}",$work_status_list_str);
$work_status_list_arr = explode("{n}", $work_status_list_str);
if(is_array($work_status_list_arr) && !empty($work_status_list_arr)){
    foreach ($work_status_list_arr as $key => $value){
        $work_status_list_item = explode("|", $value);
        $work_status_list_item_id = intval($work_status_list_item[0]);
        $work_status_list_item_name = trim($work_status_list_item[1]);
        if($work_status_list_item_id > 0 && !empty($work_status_list_item_name)){
            $workStatusArray[$work_status_list_item_id] = $work_status_list_item_name;
        }
    }
}

$agesArray = array();
$ages_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['zhaopin_ages_list']); 
$ages_list_str = str_replace("\n","{n}",$ages_list_str);
$ages_list_arr = explode("{n}", $ages_list_str);
if(is_array($ages_list_arr) && !empty($ages_list_arr)){
    foreach ($ages_list_arr as $key => $value){
        $ages_list_item = explode("|", $value);
        $ages_list_item_id = intval($ages_list_item[0]);
        $ages_list_item_name = trim($ages_list_item[1]);
        if($ages_list_item_id > 0 && !empty($ages_list_item_name)){
            $agesArray[$ages_list_item_id] = $ages_list_item_name;
        }
    }
}

$resume_default_avatar = explode("|", $tczhaopinConfig['resume_default_avatar']);
$man_resume_avatar = $_G['siteurl']."source/plugin/tom_tczhaopin/images/resume_avatar/".$resume_default_avatar[0];
$woman_resume_avatar = $_G['siteurl']."source/plugin/tom_tczhaopin/images/resume_avatar/".$resume_default_avatar[1];

$aboutListTmp = C::t('#tom_zppc#tom_zppc_about')->fetch_all_list(""," ORDER BY asort ASC,id DESC ",0,50);
$aboutList = array();
if(is_array($aboutListTmp) && !empty($aboutListTmp)){
    foreach ($aboutListTmp as $key => $value){
        $aboutList[$key] = $value;
        $aboutList[$key]['link'] = tom_zppc_url('about',$site_id,array('about_id'=>$value['id']));
    }
}
$aboutCount = count($aboutList);

$guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 1 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_zppc#tom_zppc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 1 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoTonglanTopList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoTonglanTopList[] = $guanggaoItemTmp;
    }
}

$footer_qrcode_List = array();
if(!empty($zppcConfig['footer_qrcode_list'])){
    $footer_qrcode_str = str_replace("\r\n","{n}",trim($zppcConfig['footer_qrcode_list'])); 
    $footer_qrcode_str = str_replace("\n","{n}",$footer_qrcode_str);
    $footer_qrcode_str = str_replace("{site}",$site_id,$footer_qrcode_str);
    $footer_qrcode_arr = explode("{n}", $footer_qrcode_str);
    if(is_array($footer_qrcode_arr) && !empty($footer_qrcode_arr)){
        foreach ($footer_qrcode_arr as $key => $value){
            $footer_qrcode_List[] = explode("|", $value);
        }
    }
}
$footerQrcodeCount = count($footer_qrcode_List);
if($footerQrcodeCount > 3){
    $footer_qrcode_List = array_slice($footer_qrcode_List,0,3);
}
$footer_qrcode_List = array_reverse($footer_qrcode_List); 

$zppcConfig['pc_logo'] = trim($zppcConfig['pc_logo']);
if(!empty($zppcConfig['pc_logo']) && !preg_match('/^http/', $zppcConfig['pc_logo']) ){
    $zppcConfig['pc_logo'] = $_G['siteurl'].$zppcConfig['pc_logo'];
}

$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
if($__SitesInfo['id'] > 1 && !empty($__SitesInfo['kefu_qrcode'])){
    if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])){
        if(strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_') === FALSE){
            $kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
        }else{
            $kefuQrcodeSrc = $_G['siteurl'].$__SitesInfo['kefu_qrcode'];
        }
    }else{
        $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
    }
}

$tczhaopinConfig['kefu_qrcode'] = trim($tczhaopinConfig['kefu_qrcode']);
if(!empty($tczhaopinConfig['kefu_qrcode'])){
    $kefuQrcodeSrc = $tczhaopinConfig['kefu_qrcode'];
}

$_G['m_siteurl'] = $_G['siteurl'];

$zppcConfig['zhaopin_hosts']    = trim($zppcConfig['zhaopin_hosts']);
$zppcConfig['tongcheng_hosts']  = trim($zppcConfig['tongcheng_hosts']);

if($zppcConfig['open_zhaopin_hosts'] == 1 && !empty($zppcConfig['zhaopin_hosts']) && !empty($zppcConfig['tongcheng_hosts'])){
    
    $zppcConfig['tongcheng_hosts']  = rtrim($zppcConfig['tongcheng_hosts'], '/');
    $zppcConfig['tongcheng_hosts']  = $zppcConfig['tongcheng_hosts'].'/';
    
    $_G['m_siteurl'] = $zppcConfig['tongcheng_hosts'];
    
}

$index1Url         = tom_zppc_url('index',1);
$indexUrl          = tom_zppc_url('index',$site_id);
$listUrl           = tom_zppc_url('list',$site_id);
$jianzhilistUrl    = tom_zppc_url('jianzhilist',$site_id);
$resumelistUrl     = tom_zppc_url('resumelist',$site_id);
$companylistUrl    = tom_zppc_url('companylist',$site_id);
$meetinglistUrl    = tom_zppc_url('meeting',$site_id);
$mUrl              = $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=index";
$fabuUrl           = $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=fabuzhaopin&frompc=1";
$fabuResumeUrl     = $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=faburesume&frompc=1";

if($_GET['mod'] == 'index'){
    
    $search_type = 'zhaopin';
    
    include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/index.php';
    
}else if($_GET['mod'] == 'list'){
    
    $search_type = 'zhaopin';
    
    include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/list.php';
    
}else if($_GET['mod'] == 'jianzhilist'){
    
    $search_type = 'jianzhi';
    
    include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/jianzhilist.php';
    
}else if($_GET['mod'] == 'zhaopininfo'){
    
    $search_type = 'zhaopin';
    
    include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/zhaopininfo.php';
    
}else if($_GET['mod'] == 'resumelist'){
    
    $search_type = 'resume';
    
    include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/resumelist.php';
    
}else if($_GET['mod'] == 'resumeinfo'){
    
    $search_type = 'resume';
    
    include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/resumeinfo.php';
    
}else if($_GET['mod'] == 'companylist'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/companylist.php';
    
}else if($_GET['mod'] == 'companyinfo'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/companyinfo.php';
    
}else if($_GET['mod'] == 'meeting'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/meeting.php';
    
}else if($_GET['mod'] == 'meetinginfo'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/meetinginfo.php';
    
}else if($_GET['mod'] == 'about'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/about.php';
    
}else{
    
    $search_type = 'zhaopin';
    
    include DISCUZ_ROOT.'./source/plugin/tom_zppc/module/index.php';
}