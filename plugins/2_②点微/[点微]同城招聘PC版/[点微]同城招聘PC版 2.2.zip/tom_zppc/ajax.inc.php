<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/class/function.core.php';

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.utf.php';
}
$welfareArray = array();
$welfare_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['welfare_list']); 
$welfare_list_str = str_replace("\n","{n}",$welfare_list_str);
$welfare_list_arr = explode("{n}", $welfare_list_str);
if(is_array($welfare_list_arr) && !empty($welfare_list_arr)){
    foreach ($welfare_list_arr as $key => $value){
        $welfare_list_item = explode("|", $value);
        $welfare_list_item_id = intval($welfare_list_item[0]);
        $welfare_list_item_name = trim($welfare_list_item[1]);
        if($welfare_list_item_id > 0 && !empty($welfare_list_item_name)){
            $welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
        }
    }
}

$resume_default_avatar = explode("|", $tczhaopinConfig['resume_default_avatar']);
$man_resume_avatar = "source/plugin/tom_tczhaopin/images/resume_avatar/".$resume_default_avatar[0];
$woman_resume_avatar = "source/plugin/tom_tczhaopin/images/resume_avatar/".$resume_default_avatar[1];

if($_GET['act'] == 'look_resume' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $resume_id      = intval($_GET['resume_id'])>0 ? intval($_GET['resume_id']):0;
    
    $resumeInfo = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_by_id($resume_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($__UserInfo['id']);

    if($userInfo['id'] > 0 && $resumeInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['id'] == $resumeInfo['user_id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    $rencaiInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_rencai")->fetch_all_list(" AND user_id = {$userInfo['id']} AND resume_id = {$resume_id} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($rencaiInfoTmp) && $rencaiInfoTmp[0]['id'] > 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $companyRenzhengStatus = 0;
    $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$userInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
        $companyRenzhengStatus = 1;
    }
    
    $resumePayStatus = 1;
    if($resumePayStatus == 1){
        $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$userInfo['id']} AND type = 3 AND deduct_type = 1 ");
        if($companyRenzhengStatus == 1){
            $freeResumeNum = $tczhaopinConfig['company_free_resume_num'];
        }else{
            $freeResumeNum = $tczhaopinConfig['personal_free_resume_num'];
        }
        if($freeResumeNum > $userLogCount){
            $resumePayStatus = 2;
        }
    }

    if($resumePayStatus == 1){
        $userVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($userInfo['id']);
        if($userVipInfo['vip_id'] > 0 && $userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
            $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
            $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$userInfo['id']} AND type = 3 AND deduct_type = 2");
            if($vipInfo['resume_num'] > $userVipLogCount){
                $resumePayStatus = 3;
            }
        }
    }

    if($resumePayStatus == 2 || $resumePayStatus == 3){

        $insertData = array();
        $insertData['user_id']              = $userInfo['id'];
        $insertData['resume_id']            = $resume_id;
        if($resumePayStatus == 2){
            $insertData['deduct_type']          = 1;
        }else if($resumePayStatus == 3){
            $insertData['deduct_type']          = 2;
        }
        $insertData['type']                 = 3;
        $insertData['today_time']           = $nowDayTime;
        $insertData['log_time']             = TIMESTAMP;
        C::t("#tom_tczhaopin#tom_tczhaopin_log")->insert($insertData);
        
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['resume_id']    = $resume_id;
        $insertData['type']         = 2;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->insert($insertData);
        
    }else{
        $outArr = array(
            'status'        => 201,
        );
        echo json_encode($outArr); exit;
    }
        
    $outArr = array(
        'status'        => 200,
    );
    echo json_encode($outArr); exit;
    
}else{
    echo 'error';exit;
}