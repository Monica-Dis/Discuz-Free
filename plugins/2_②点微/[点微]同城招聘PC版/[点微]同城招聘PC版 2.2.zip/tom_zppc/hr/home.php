<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPchrUrl = $pchrUrl."&tmod=home";

$zhaopinCount       = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count("AND user_id={$__UserInfo['id']}");
$rencaiCount        = C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->fetch_all_rencai_resume_count("AND t.user_id={$__UserInfo['id']} AND r.status = 1 AND r.shenhe_status = 1");
$shenqingCount      = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_count("AND z.user_id = {$__UserInfo['id']} AND z.shenhe_status = 1 AND r.shenhe_status = 1");
$mianshiCount       = C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->fetch_all_count("AND yaoqing_user_id = {$__UserInfo['id']}");
$resumeCollectCount = C::t('#tom_tczhaopin#tom_tczhaopin_resume_collect')->fetch_all_count("AND user_id={$__UserInfo['id']}");
$historyResumeCount = C::t('#tom_tczhaopin#tom_tczhaopin_history')->fetch_all_history_resume_count("AND t.user_id={$__UserInfo['id']} AND r.status = 1 AND r.gongkai_status = 1 AND r.shenhe_status = 1");

$companyRenzhengStatus = 0;
$renzhengCompanyInfo = array();
$renzhengCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($__UserInfo['id']);
if($renzhengCompanyInfoTmp['id'] > 0){
    $companyRenzhengStatus = 1;
    $renzhengCompanyInfo = $renzhengCompanyInfoTmp;
}

$shenyuVipResumeNum = $shengyuFabu = 0;
$vipInfo        = array();
$userVipInfo    = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($__UserInfo['id']);
if($userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
    $vipInfo        = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
    $userVipFabuLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND expire_status = 3 ");
    if($vipInfo['fabu_num'] > $userVipFabuLogCount){
        $shengyuFabu = $vipInfo['fabu_num'] - $userVipFabuLogCount;
    }
    $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND type = 3 AND deduct_type = 2");
    if($vipInfo['resume_num'] > $userVipLogCount){
        $shenyuVipResumeNum = $vipInfo['resume_num'] - $userVipLogCount;
    }
}

$expire_time = dgmdate($userVipInfo['expire_time'],"Y-m-d H:i",$tomSysOffset);

$shenqingListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_list("AND z.user_id = {$__UserInfo['id']} AND z.shenhe_status = 1 AND r.shenhe_status = 1 AND r.deleted = 0 "," ORDER BY t.add_time DESC,t.id DESC ",0,6);
$shenqingList = array();
if(is_array($shenqingListTmp) && !empty($shenqingListTmp)){
    foreach ($shenqingListTmp as $key => $value){
        $shenqingList[$key] = $value;

        $resumeInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($value['resume_id']); 

        if(!empty($value['r_avatar'])){
            if(!preg_match('/^http/', $value['r_avatar'])){
                if(strpos($value['r_avatar'], 'source/plugin/tom_') === FALSE){
                    $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['r_avatar'];
                }else{
                    $avatarTmp = $value['r_avatar'];
                }
            }else{
                $avatarTmp = $value['r_avatar'];
            }
        }else{
            if($value['r_sex'] == 1){
                $avatarTmp = $man_resume_avatar;
            }elseif($value['r_sex'] == 2){
                $avatarTmp = $woman_resume_avatar;
            }
        }
        
        if($value['status'] == 0){
            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->update($value['id'], $updateData);
        }

        $shenqingList[$key]['r_avatar']           = $avatarTmp;
        $shenqingList[$key]['add_time']           = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $shenqingList[$key]['resumeInfo']         = $resumeInfoTmp;
    }
}

$renzheng_back_url = $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=my";  
$renzheng_back_url = urlencode($renzheng_back_url);
$companyRenzhengUrl = $_G['m_siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=company&renzheng_plugin=zhaopin&renzheng_back={$renzheng_back_url}";

$buyVipUrl = $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=vip";    

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:hr/home");