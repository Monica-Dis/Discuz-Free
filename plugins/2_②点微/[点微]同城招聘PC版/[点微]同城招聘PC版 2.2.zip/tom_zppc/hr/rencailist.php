<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPchrUrl = $pchrUrl."&tmod=rencailist";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('rencai_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $rencai_id = intval($_GET['rencai_id'])>0? intval($_GET['rencai_id']):0;
    
    $rencaiInfo = C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->fetch_by_id($rencai_id);

    if($rencaiInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
    
    C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->delete_by_id($rencai_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$name               = isset($_GET['name'])? addslashes($_GET['name']):'';
$tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
$type               = intval($_GET['type'])>0? intval($_GET['type']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = "AND t.user_id={$__UserInfo['id']} AND r.status = 1 AND r.shenhe_status = 1  AND r.deleted = 0 ";
if($type > 0){
    $whereStr .= " AND t.type = {$type} ";
}
if(!empty($name)){
    $name = str_replace(array('%', '_'),'',$name);
    $whereStr .= " AND r.name LIKE '%{$name}%'";
}
if(!empty($tel)){
    $whereStr .= " AND r.tel = '{$tel}'";
}

$order = "ORDER BY t.id DESC";

$start          = ($page - 1)*$pagesize;
$count = C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->fetch_all_rencai_resume_count($whereStr);
$rencaiListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->fetch_all_rencai_resume_list($whereStr, $order, $start, $pagesize);
$rencaiList = array();
if(!empty($rencaiListTmp)){
    foreach ($rencaiListTmp as $key => $value) {
        $rencaiList[$key] = $value;
        
        $resumeInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($value['resume_id']); 

        if(!empty($value['avatar'])){
            if(!preg_match('/^http/', $value['avatar'])){
                if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                    $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
                }else{
                    $avatarTmp = $value['avatar'];
                }
            }else{
                $avatarTmp = $value['avatar'];
            }
        }else{
            if($value['sex'] == 1){
                $avatarTmp = $man_resume_avatar;
            }elseif($value['sex'] == 2){
                $avatarTmp = $woman_resume_avatar;
            }
        }
        $rencaiList[$key]['add_time']       = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $rencaiList[$key]['avatar']         = $avatarTmp;
        $rencaiList[$key]['resumeInfo']     = $resumeInfoTmp;

        if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value['resume_id'], $updateData);
        }
    }
}

$resumeInfoUrl = $pchrUrl."&tmod=resumeinfo";
$mianshiUrl = $pchrUrl."&tmod=mianshi";
$pageUrl = $modPchrUrl."&type={$type}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:hr/rencailist");