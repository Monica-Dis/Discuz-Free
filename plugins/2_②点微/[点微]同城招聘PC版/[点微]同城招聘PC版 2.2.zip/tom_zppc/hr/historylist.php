<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPchrUrl = $pchrUrl."&tmod=historylist";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('history_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $history_id = intval($_GET['history_id'])>0? intval($_GET['history_id']):0;
    
    $historyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_history')->fetch_by_id($history_id);
    
    if($historyInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
    
    C::t('#tom_tczhaopin#tom_tczhaopin_history')->delete_by_id($history_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = "AND t.user_id={$__UserInfo['id']} AND r.status = 1 AND r.gongkai_status = 1 AND r.shenhe_status = 1 AND r.deleted = 0 ";

$order = "ORDER BY t.id DESC";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tczhaopin#tom_tczhaopin_history')->fetch_all_history_resume_count($whereStr);
$historyListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_history')->fetch_all_history_resume_list($whereStr, $order, $start, $pagesize);
$historyList = array();
if(is_array($historyListTmp) && !empty($historyListTmp)){
    foreach ($historyListTmp as $key => $value){
        $historyList[$key] = $value;

        if(!empty($value['avatar'])){
            if(!preg_match('/^http/', $value['avatar'])){
                if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                    $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
                }else{
                    $avatarTmp = $value['avatar'];
                }
            }else{
                $avatarTmp = $value['avatar'];
            }
        }else{
            if($value['sex'] == 1){
                $avatarTmp = $man_resume_avatar;
            }else if($value['sex'] == 2){
                $avatarTmp = $woman_resume_avatar;
            }
        }
        
        $rencaiListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->fetch_all_list("AND user_id = {$__UserInfo['id']} AND resume_id = {$value['resume_id']}","",0,1);
        if(is_array($rencaiListTmp) && !empty($rencaiListTmp)){
            $historyList[$key]['is_rencai']     = 1;
        }else{
            $historyList[$key]['is_rencai']     = 0;
        }
        
        $historyList[$key]['avatar']            = $avatarTmp;
        $historyList[$key]['refresh_time']      = dgmdate($value['refresh_time'],"Y-m-d H:i",$tomSysOffset);
        
        $historyList[$key]['resume_url']  = tom_zppc_url('resumeinfo',$value['site_id'],array('resume_id'=>$value['resume_id']));

        if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['tom_time']     = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($value['resume_id'], $updateData);
        }
    }
}

$resumeInfoUrl = $pchrUrl."&tmod=resumeinfo";
$pageUrl = $modPchrUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:hr/historylist");