<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPchrUrl = $pchrUrl."&tmod=resumecollect";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('collect_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $collect_id = intval($_GET['collect_id'])>0? intval($_GET['collect_id']):0;
    
    $resumeCollectInfo = C::t('#tom_tczhaopin#tom_tczhaopin_resume_collect')->fetch_by_id($collect_id);

    if($collectInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
    
    C::t('#tom_tczhaopin#tom_tczhaopin_resume_collect')->delete_by_id($collect_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$page         = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize     = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = "AND user_id={$__UserInfo['id']}";

$order = "ORDER BY id DESC";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tczhaopin#tom_tczhaopin_resume_collect')->fetch_all_count($whereStr);
$collectListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume_collect')->fetch_all_list($whereStr, $order, $start, $pagesize);
$collectList = array();
if(is_array($collectListTmp) && !empty($collectListTmp)){
    foreach ($collectListTmp as $key => $value){
        $collectList[$key] = $value;
        
        $resumeInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($value['resume_id']);

        if(!empty($resumeInfoTmp['avatar'])){
            if(!preg_match('/^http/', $resumeInfoTmp['avatar'])){
                if(strpos($resumeInfoTmp['avatar'], 'source/plugin/tom_') === FALSE){
                    $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$resumeInfoTmp['avatar'];
                }else{
                    $avatarTmp = $resumeInfoTmp['avatar'];
                }
            }else{
                $avatarTmp = $resumeInfoTmp['avatar'];
            }
        }else{
            if($resumeInfoTmp['sex'] == 1){
                $avatarTmp = $man_resume_avatar;
            }else if($resumeInfoTmp['sex'] == 2){
                $avatarTmp = $woman_resume_avatar;
            }
        }
        $rencaiListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->fetch_all_list("AND user_id = {$__UserInfo['id']} AND resume_id = {$value['resume_id']}","",0,1);
        if(is_array($rencaiListTmp) && !empty($rencaiListTmp)){
            $collectList[$key]['is_rencai']     = 1;
        }else{
            $collectList[$key]['is_rencai']     = 0;
        }
        
        $collectList[$key]['resumeInfo']            = $resumeInfoTmp;
        $collectList[$key]['resumeInfo']['avatar']  = $avatarTmp;
        $collectList[$key]['resumeInfo']['refresh_time']   = dgmdate($resumeInfoTmp['refresh_time'],"Y-m-d H:i",$tomSysOffset);
        
        $collectList[$key]['resumeInfo']['resume_url']  = tom_zppc_url('resumeinfo',$resumeInfoTmp['site_id'],array('resume_id'=>$resumeInfoTmp['id']));

        if($resumeInfoTmp['top_status'] == 1 && $resumeInfoTmp['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin_resume')->update($resumeInfoTmp['resume_id'], $updateData);
        }
        
    }
}

$resumeInfoUrl = $pchrUrl."&tmod=resumeinfo";
$pageUrl = $modPchrUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:hr/resumecollect");