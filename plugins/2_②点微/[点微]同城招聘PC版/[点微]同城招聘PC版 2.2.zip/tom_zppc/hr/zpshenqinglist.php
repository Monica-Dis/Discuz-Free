<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPchrUrl = $pchrUrl."&tmod=zpshenqinglist";

$tczhaopin_id       = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):'';
$resume_id          = intval($_GET['resume_id'])>0? intval($_GET['resume_id']):'';
$status             = intval($_GET['status'])>0? intval($_GET['status']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = " AND z.user_id = {$__UserInfo['id']} AND z.shenhe_status = 1 AND r.shenhe_status = 1 AND r.deleted = 0 ";
if($status == 1){
    $whereStr .= " AND t.status = 1 ";
}else if($status == 2){
    $whereStr .= " AND t.status = 0 ";
}

if($tczhaopin_id > 0){
    $whereStr .= "  AND t.tczhaopin_id = {$tczhaopin_id} ";
}
if($resume_id > 0){
    $whereStr .= "  AND t.resume_id = {$resume_id} ";
}

$order = " ORDER BY t.add_time DESC,t.id DESC ";

$start          = ($page - 1)*$pagesize;
$count = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_count($whereStr);
$shenqingListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->fetch_all_shenqing_zhaopin_resume_list($whereStr," {$order} ",$start,$pagesize);
$shenqingList = array();
if(is_array($shenqingListTmp) && !empty($shenqingListTmp)){
    foreach ($shenqingListTmp as $key => $value){
        $shenqingList[$key] = $value;

        $resumeInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($value['resume_id']); 

        if(!empty($value['r_avatar'])){
            if(!preg_match('/^http/', $value['r_avatar'])){
                if(strpos($value['r_avatar'], 'source/plugin/tom_') === FALSE){
                    $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['r_avatar'];
                }else{
                    $avatarTmp = $value['r_avatar'];
                }
            }else{
                $avatarTmp = $value['r_avatar'];
            }
        }else{
            if($value['r_sex'] == 1){
                $avatarTmp = $man_resume_avatar;
            }elseif($value['r_sex'] == 2){
                $avatarTmp = $woman_resume_avatar;
            }
        }
        
        if($value['status'] == 0){
            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tczhaopin#tom_tczhaopin_shenqing')->update($value['id'], $updateData);
        }

        $shenqingList[$key]['r_avatar']           = $avatarTmp;
        $shenqingList[$key]['add_time']           = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $shenqingList[$key]['resumeInfo']         = $resumeInfoTmp;
   }
}

$resumeInfoUrl = $pchrUrl."&tmod=resumeinfo";
$mianshiUrl = $pchrUrl."&tmod=mianshi";
$pageUrl = $modPchrUrl."&status={$status}&tczhaopin_id={$tczhaopin_id}&resume_id={$resume_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:hr/zpshenqinglist");