<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPchrUrl = $pchrUrl."&tmod=add";

$companyInfo   = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($__UserInfo['id']);
$rzCompanyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_id($companyInfo['renzheng_company_id']);

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$__CityInfo = array();
if(!empty($tongchengConfig['city_id'])){
    $__CityInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);

$jianzhiCateList = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,100);

$cateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$companyRenzhengStatus = 0;
$rzCompanyInfo = array();
$rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$__UserInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
    $companyRenzhengStatus = 1;
    $rzCompanyInfo = $rzCompanyInfoTmp[0];
}

$vipInfo = array();
$userVipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($__UserInfo['id']);
if($userVipInfoTmp['vip_id'] > 0 && $userVipInfoTmp['expire_status'] == 1 && $userVipInfoTmp['expire_time'] > TIMESTAMP){
    $vipInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfoTmp['vip_id']);
    if($vipInfoTmp && $vipInfoTmp > 0){
        $vipInfo = $vipInfoTmp;
    }
}

$zhaopinFabuList = array();
$shenyuFabuNum = $shenyuVipFabuNum = 0;
$fabuPayStatus = 1;
if($fabuPayStatus == 1){
    $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND type = 1 AND deduct_type = 1 ");
    if($companyRenzhengStatus == 1){
        $freeFabuNum = $tczhaopinConfig['company_free_fabu_num'];
    }else{
        $freeFabuNum = $tczhaopinConfig['personal_free_fabu_num'];
    }
    if($freeFabuNum > $userLogCount){
        $shenyuFabuNum = $freeFabuNum - $userLogCount;
    }
}

if($fabuPayStatus == 1){
    if($vipInfo && $vipInfo['id'] > 0){
        $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND expire_status = 3 ");
        if($vipInfo['fabu_num'] > $userVipLogCount){
            $shenyuVipFabuNum = $vipInfo['fabu_num'] - $userVipLogCount;
        }
    }
}

$zhaopin_fabu_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['shoufei_zhaopin_price_list']);
$zhaopin_fabu_list_str = str_replace("\n","{n}",$zhaopin_fabu_list_str);
$zhaopin_fabu_list_arr = explode("{n}", $zhaopin_fabu_list_str);
$i = 0;
if(is_array($zhaopin_fabu_list_arr) && !empty($zhaopin_fabu_list_arr)){
    foreach ($zhaopin_fabu_list_arr as $key => $value){
        $arr = explode("|", $value);

        $zhaopinFabuList[$key]['days']             = $arr[0];
        $zhaopinFabuList[$key]['price']            = $arr[1];
        $zhaopinFabuList[$key]['desc']             = $arr[2];
        $zhaopinFabuList[$key]['pay_score_status'] = 0;
        $zhaopinFabuList[$key]['pay_score']        = 0;
        $zhaopinFabuList[$key]['free_status']      = 0;

        if($i == 0 && $shenyuFabuNum > 0){
            $zhaopinFabuList[$key]['free_status'] = 1;
        }

        if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $fabu_pay_score = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($fabu_pay_score > 0 && $__UserInfo['score'] >= $fabu_pay_score){
                $zhaopinFabuList[$key]['pay_score_status'] = 1;
                $zhaopinFabuList[$key]['pay_score'] = $fabu_pay_score;
            }
        }
        $i++;
    }
}

$streetList     = array();
$old_area_id    = $old_street_id = 0;
$old_company_name = $old_address = $old_xm = $old_tel = $old_latitude = $old_longitude = '';
$tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list(" AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,1);
if(is_array($tczhaopinListTmp) && !empty($tczhaopinListTmp) && $tczhaopinListTmp[0]['id'] > 0){
    $old_area_id        = $tczhaopinListTmp[0]['area_id'];
    $old_street_id      = $tczhaopinListTmp[0]['street_id'];
    $old_company_name   = $tczhaopinListTmp[0]['company_name'];
    $old_address        = $tczhaopinListTmp[0]['address'];
    $old_xm             = $tczhaopinListTmp[0]['xm'];
    $old_tel            = $tczhaopinListTmp[0]['tel'];
    $old_latitude       = $tczhaopinListTmp[0]['latitude'];
    $old_longitude      = $tczhaopinListTmp[0]['longitude'];
    if($old_area_id > 0){
        $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($old_area_id);
    }
}else if($rzCompanyInfo){
    $old_xm  = $rzCompanyInfo['rz_name'];
    $old_tel = $rzCompanyInfo['tel'];
}

$addUrl = "plugin.php?id=tom_zppc:pay&act=zhaopin";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:hr/add");