<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tczhaopin_id = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):0;
$tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);

if(empty($tczhaopinInfo) || ($tczhaopinInfo['user_id'] != $__UserInfo['id'])){
    tomheader('location:'.$_G['siteurl']."{$pchrUrl}&tmod=list");exit;
}

$modPchrUrl = $pchrUrl."&tmod=edit&tczhaopin_id={$tczhaopin_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($_GET['act'] == 'save' && submitcheck('tczhaopin_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
        
    $site_id                    = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $title                      = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title                      = dhtmlspecialchars($title);
    $type                       = isset($_GET['type'])? intval($_GET['type']):0;
    $cate_id                    = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id              = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $jianzhi_cate_id            = isset($_GET['jianzhi_cate_id'])? intval($_GET['jianzhi_cate_id']):0;
    $work_salary                = isset($_GET['work_salary'])? intval($_GET['work_salary']):0;
    $work_salary_min            = intval($_GET['work_salary_min'])>0? intval($_GET['work_salary_min']):0;
    $work_salary_max            = intval($_GET['work_salary_max'])>0? intval($_GET['work_salary_max']):0;
    $jianzhi_work_salary        = isset($_GET['jianzhi_work_salary'])? intval($_GET['jianzhi_work_salary']):0;
    $jianzhi_work_salary_unit   = isset($_GET['jianzhi_work_salary_unit'])? intval($_GET['jianzhi_work_salary_unit']):0;
    $jianzhi_jiesuan_fangshi    = isset($_GET['jianzhi_jiesuan_fangshi'])? intval($_GET['jianzhi_jiesuan_fangshi']):0;
    $renshu                     = isset($_GET['renshu'])? intval($_GET['renshu']):0;
    $demand_sex                 = isset($_GET['demand_sex'])? intval($_GET['demand_sex']):0;
    $demand_ages                = isset($_GET['demand_ages'])? intval($_GET['demand_ages']):0;
    $demand_xueli               = isset($_GET['demand_xueli'])? intval($_GET['demand_xueli']):0;
    $demand_jingyan             = isset($_GET['demand_jingyan'])? intval($_GET['demand_jingyan']):0;
    $demand_desc                = isset($_GET['demand_desc'])? addslashes($_GET['demand_desc']):'';
    $demand_desc                = dhtmlspecialchars($demand_desc);
    $area_id                    = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id                  = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $lng                        = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                        = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address                    = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address                    = dhtmlspecialchars($address);
    $xm                         = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $company_name               = isset($_GET['company_name'])? addslashes($_GET['company_name']):'';
    $video_url                  = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_pic                  = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic                  = dhtmlspecialchars($video_pic);
    
    $__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
    if(!empty($__CommonInfo['forbid_word'])){
        $forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
        $forbid_word = str_replace(array("\\*"), array('.*'), $forbid_word);
        $forbid_word = '.*('.$forbid_word.').*';
        $forbid_word = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word).')$/i';
        $contentTmpTmp = $title.$company_name.$demand_desc;
        $contentTmpTmp = str_replace("\r\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\r","",$contentTmpTmp);
        if(@preg_match($forbid_word, $contentTmpTmp,$matches)) {
            $i = count($matches)-1;
            $word = '';
            if(isset($matches[$i]) && !empty($matches[$i])){
                $word = diconv($matches[$i],CHARSET,'utf-8');
            }
            if($tongchengConfig['safe_words_do'] == 1){
                $tczhaopinConfig['zhaopin_must_shenhe'] = 1;
            }else{
                $outArr = array(
                    'code'=> 200,
                    'status'=> 505,
                    'word'=> $word,
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photosort_") !== false){
            $kk = intval(ltrim($key, "photosort_"));
            $photoArr[$kk]['sort'] = addslashes($value);
        }
    }
    
    if($__ShowXiaofenlei == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php';
        if($xiaofenleiConfig['open_msgseccheck'] == 1){
            @$s_m_r = wx_msgSecCheck($title.$company_name.$demand_desc);
            if($s_m_r['code'] == 100){
                $tczhaopinConfig['zhaopin_must_shenhe'] = 1;
            }
            if($s_m_r['code'] == 500){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 505,
                    'word'=> $s_m_r['word'],
                );
                echo json_encode($outArr); exit;
            }
        }
        $imgseccheck_listArr = unserialize($xiaofenleiConfig['imgseccheck_list']);
        if(array_search('2',$imgseccheck_listArr) !== false && $xiaofenleiConfig['open_imgseccheck'] == 1){
            if(is_array($photoArr) && !empty($photoArr)){
                foreach ($photoArr as $kk => $vv){
                    if(!preg_match('/^http/', $vv['picurl']) ){
                        if(strpos($vv['picurl'], 'source/plugin/tom_') === false){    
                            $check_picurl_tmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                        }else{
                            $check_picurl_tmp = $_G['siteurl'].$vv['picurl'];
                        }
                    }else{
                        $check_picurl_tmp = $vv['picurl'];
                    }
                    @$s_i_r = wx_imgSecCheck($check_picurl_tmp);
                    if($s_i_r['code'] == 500){
                        $tczhaopinConfig['zhaopin_must_shenhe'] = 1;
                    }
                }
            }
        }
    }
   
    $workWelfareArr = array();
    if(is_array($_GET['work_welfare']) && !empty($_GET['work_welfare'])){
        foreach($_GET['work_welfare'] as $key => $value){
            $workWelfareArr[] = intval($value);
        }
    }
    $work_welfare = '-'.implode('-', $workWelfareArr).'-';
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$__UserInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    $companyRenzhengStatus = 0;
    $rzCompanyInfo = array();
    if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
        $companyRenzhengStatus = 1;
        $rzCompanyInfo = $rzCompanyInfoTmp[0];
    }
    
    if($companyRenzhengStatus == 1){
        $company_name = $rzCompanyInfo['name'];
    }

    $search_text = '';
    if($type == 1){
        $cateInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_id);
        $cateChildInfo = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($cate_child_id);
        $search_text = $title.'-'.$cateInfo['name'].'-'.$cateChildInfo['name'].'-'.$company_name;
    }else if($type == 2){
        $jianzhiCateInfo =  C::t("#tom_tczhaopin#tom_tczhaopin_jianzhi_cate")->fetch_by_id($jianzhi_cate_id);
        $search_text = $title.'-'.$jianzhiCateInfo['name'].'-'.$company_name;
    }
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($__UserInfo['id']);
    if(is_array($companyInfo) && !empty($companyInfo)){ 
        update_company_status($companyInfo);
    }else{
        $insertData = array();
        $insertData['site_id']              = $site_id;
        $insertData['user_id']              = $__UserInfo['id'];
        $insertData['add_time']             = TIMESTAMP;
        if(C::t('#tom_tczhaopin#tom_tczhaopin_company')->insert($insertData)){
            $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_user_id($__UserInfo['id']);
            update_company_status($companyInfo);
        }
    }
    
    $updateData = array();
    $updateData['site_id']            = $site_id;
    $updateData['user_id']            = $__UserInfo['id'];
    $updateData['company_id']         = $companyInfo['id'];
    $updateData['title']              = $title;
    $updateData['type']               = $type;
    if($type == 1){
        $updateData['cate_id']            = $cate_id;
        $updateData['cate_child_id']      = $cate_child_id;
    }else if($type == 2){
        $updateData['jianzhi_cate_id']    = $jianzhi_cate_id;
    }
    if($type == 1){
        $updateData['work_salary']          = $work_salary;
        $updateData['work_salary_min']      = $work_salary_min;
        $updateData['work_salary_max']      = $work_salary_max;
        $updateData['work_welfare']         = $work_welfare;
    }else if($type == 2){
        $updateData['jianzhi_work_salary']       = $jianzhi_work_salary;
        $updateData['jianzhi_work_salary_unit']  = $jianzhi_work_salary_unit;
        $updateData['jianzhi_jiesuan_fangshi']   = $jianzhi_jiesuan_fangshi;
    }
    $updateData['renshu']             = $renshu;
    $updateData['demand_sex']         = $demand_sex;
    $updateData['demand_ages']        = $demand_ages;
    $updateData['demand_xueli']       = $demand_xueli;
    $updateData['demand_jingyan']     = $demand_jingyan;
    $updateData['demand_desc']        = $demand_desc;
    $updateData['city_id']            = $city_id;
    $updateData['area_id']            = $area_id;
    $updateData['street_id']          = $street_id;
    $updateData['address']            = $address;
    $updateData['latitude']           = $lat;
    $updateData['longitude']          = $lng;
    $updateData['xm']                 = $xm;
    $updateData['tel']                = $tel;
    if($companyRenzhengStatus == 1){
        $updateData['company_name']            = $rzCompanyInfo['name'];
        $updateData['company_nature_id']       = $rzCompanyInfo['nature_id'];
        $updateData['company_industry_id']     = $rzCompanyInfo['industry_id'];
        $updateData['company_scale_id']        = $rzCompanyInfo['scale_id'];
    }else{
        $updateData['company_name']            = $company_name;
    }
    if(!empty($video_url)){
        $updateData['video_status']       = 1;
    }else{
        $updateData['video_status']       = 0;
    }
    $updateData['video_url']          = $video_url;
    $updateData['video_pic']          = $video_pic;
    $updateData['search_text']        = $search_text;
    if($tczhaopinConfig['zhaopin_must_shenhe'] == 1){
        $updateData['shenhe_status']            = 2;
    }
    C::t('#tom_tczhaopin#tom_tczhaopin')->update($tczhaopin_id,$updateData);
    if($tczhaopin_id > 0){
        C::t("#tom_tczhaopin#tom_tczhaopin_photo")->delete_by_tczhaopin_id($tczhaopin_id);
        
        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['tczhaopin_id'] = $tczhaopin_id;
                $insertData['picurl']       = $value['picurl'];
                $insertData['psort']        = $value['sort'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tczhaopin#tom_tczhaopin_photo')->insert($insertData);
            }
        }
        update_company_status($companyInfo);
        update_zhaopin_tongcheng($tczhaopin_id);
        
        if(!empty($tongchengConfig['template_id']) && $tczhaopinConfig['zhaopin_must_shenhe'] == 1){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_fabuzhaopin_shenhe_msg'),
                    'keyword1'      => $tczhaopinConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $zpmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tczhaopinConfig['zpmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($zpmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=managerList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tczhaopin', 'zhaopin_fabuzhaopin_shenhe_msg'),
                    'keyword1'      => $tczhaopinConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($zpmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    } 
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY paixu ASC,id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$jianzhiCateList = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,100);

$cateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$workWelfareArr = explode('-', '-'.$tczhaopinInfo['work_welfare'].'-');
$checkedWelfareList = array();
if(is_array($welfareArray) && !empty($welfareArray)){
    foreach($welfareArray as $key => $value){
        $checkedWelfareList[$key]['name'] = $value;
        if(in_array($key,$workWelfareArr)){
            $checkedWelfareList[$key]['status'] = 1;
        }else{
            $checkedWelfareList[$key]['status'] = 0;
        }
    }
}

$rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$tczhaopinInfo['user_id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
$companyRenzhengStatus = 0;
if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
    $companyRenzhengStatus = 1;
    $company_name = $rzCompanyInfoTmp[0]['name'];
}else{
    $company_name = $tczhaopinInfo['company_name'];
}

$video_pic = get_file_url($tczhaopinInfo['video_pic']);

$photoListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_photo')->fetch_all_list(" AND tczhaopin_id={$tczhaopin_id} ", 'ORDER BY psort ASC,id ASC',0, 100);
$photoList = array();
$i = 1;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $photoList[$key] = $value;
        
        $photoList[$key]['pic_url'] = $value['picurlTmp'];
        $photoList[$key]['i'] = $i;
        $i++;
    }
}
$photoCount = Count($photoList);

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($tczhaopinInfo['city_id']);
$areaList = array();
if(!empty($areaListTmp)){
    foreach ($areaListTmp as $key => $value){
        $areaList[$value['id']] = $value;
    }
}

$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($tczhaopinInfo['area_id']);
$streetList = array();
if(!empty($streetListTmp)){
    foreach ($streetListTmp as $key => $value){
        $streetList[$value['id']] = $value;
    }
}

$editUrl = $modPchrUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:hr/edit");