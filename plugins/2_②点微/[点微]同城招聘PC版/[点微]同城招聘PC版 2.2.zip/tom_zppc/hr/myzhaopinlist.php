<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPchrUrl = $pchrUrl."&tmod=myzhaopinlist";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'hide' && submitcheck('tczhaopin_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tczhaopin_id = intval($_GET['tczhaopin_id'])>0 ? intval($_GET['tczhaopin_id']):0;

    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tczhaopin#tom_tczhaopin')->update($tczhaopin_id,$updateData);
    
    update_zhaopin_tongcheng($tczhaopinInfo['id']);
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
    update_company_status($companyInfo);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('tczhaopin_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tczhaopin_id = intval($_GET['tczhaopin_id'])>0 ? intval($_GET['tczhaopin_id']):0;
    
    $tczhaopinInfo = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tczhaopin#tom_tczhaopin')->update($tczhaopin_id,$updateData);
    
    update_zhaopin_tongcheng($tczhaopinInfo['id']);
    
    $companyInfo = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($tczhaopinInfo['company_id']);
    update_company_status($companyInfo);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_show' && submitcheck('tczhaopin_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tczhaopinIdsArr = array();
    if(is_array($_GET['tczhaopin_ids'])){
        foreach($_GET['tczhaopin_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tczhaopinIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tczhaopinIdsArr)){
        foreach($tczhaopinIdsArr as $key => $value){
            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value,$updateData);
            update_zhaopin_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_hide' && submitcheck('tczhaopin_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tczhaopinIdsArr = array();
    if(is_array($_GET['tczhaopin_ids'])){
        foreach($_GET['tczhaopin_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tczhaopinIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tczhaopinIdsArr)){
        foreach($tczhaopinIdsArr as $key => $value){
            $updateData = array();
            $updateData['status'] = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value,$updateData);
            update_zhaopin_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('tczhaopin_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tczhaopin_id = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):0;
    
    $tczhaopinInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_by_id($tczhaopin_id);
    $tczhaopinInfo = array();
    if(!empty($tczhaopinInfoTmp)){
        
        $tczhaopinInfo = $tczhaopinInfoTmp;
        
        if($tczhaopinInfo['type'] == 1){
            $cateInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($tczhaopinInfo['cate_id']);
            $cateChildInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_by_id($tczhaopinInfo['cate_child_id']);
        }elseif($tczhaopinInfo['type'] == 2){
            $jianzhiCateInfoTmp =  C::t("#tom_tczhaopin#tom_tczhaopin_jianzhi_cate")->fetch_by_id($tczhaopinInfo['jianzhi_cate_id']);
        }
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tczhaopinInfo['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tczhaopinInfo['street_id']);
        
        $workWelfareArr = explode('-', '-'.$tczhaopinInfo['work_welfare'].'-');
        $checkedWelfareListTmp = array();
        if(is_array($welfareArray) && !empty($welfareArray)){
            foreach($welfareArray as $key => $value){
                if(in_array($key,$workWelfareArr)){
                    $checkedWelfareListTmp[$key]['name'] = $value;
                }
            }
        }
        
        $works_salary   = $workSalaryArray[$tczhaopinInfo['work_salary']];
        $demand_ages    = $agesArray[$tczhaopinInfo['demand_ages']];
        $demand_xueli   = $xueliArray[$tczhaopinInfo['demand_xueli']];
        $demand_jingyan = $workJingyanArray[$tczhaopinInfo['demand_jingyan']];
        $jianzhi_work_salary_unit  = $jianzhiJieSuanUnitArray[$tczhaopinInfo['jianzhi_work_salary_unit']];
        
        $video_pic = get_file_url($tczhaopinInfo['video_pic']);
        $photoListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_photo')->fetch_all_list(" AND tczhaopin_id={$tczhaopinInfo['id']} ", 'ORDER BY psort ASC,id ASC',0, 100);
        $photoList = array();
        if(is_array($photoListTmp) && !empty($photoListTmp)){
            foreach($photoListTmp as $key => $value){
                $photoList[$key] = $value;
                $photoList[$key]['pic_url'] = $value['picurlTmp'];
            }
        }
        
        $tczhaopinInfo['cateInfo']           = $cateInfoTmp;
        $tczhaopinInfo['cateChildInfo']      = $cateChildInfoTmp;
        $tczhaopinInfo['jianzhiCateInfo']    = $jianzhiCateInfoTmp;
        $tczhaopinInfo['areaInfo']           = $areaInfoTmp;
        $tczhaopinInfo['streetInfo']         = $streetInfoTmp;
        $tczhaopinInfo['works_salary']       = $works_salary;
        $tczhaopinInfo['jianzhi_work_salary_unit']   = $jianzhi_work_salary_unit;
        $tczhaopinInfo['checkedWelfareList'] = $checkedWelfareListTmp;
        $tczhaopinInfo['demand_ages']        = $demand_ages;
        $tczhaopinInfo['demand_xueli']       = $demand_xueli;
        $tczhaopinInfo['demand_jingyan']     = $demand_jingyan;
        $tczhaopinInfo['video_pic']          = $video_pic;
        $tczhaopinInfo['photoList']          = $photoList;
        
    }
    
    $tczhaopinInfo = iconv_to_utf8($tczhaopinInfo);
    $outArr = array(
        'code'  => 200,
        "msg"   => "",
        "data"  => $tczhaopinInfo
    );
    echo json_encode($outArr); exit;
}

$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$tczhaopin_id       = isset($_GET['tczhaopin_id'])? intval($_GET['tczhaopin_id']):0;
$cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
$cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
$status             = isset($_GET['status'])? intval($_GET['status']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
$expire_status      = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
$keyword            = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));


$whereStr = "AND user_id={$__UserInfo['id']}";
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}
if(!empty($tczhaopin_id)){
    $whereStr.= " AND id={$tczhaopin_id} ";
}
if(!empty($tel)){
    $whereStr.= " AND tel='{$tel}' ";
}
if(!empty($cate_id)){
    $whereStr.= " AND cate_id={$cate_id} ";
}
if(!empty($cate_child_id)){
    $whereStr.= " AND cate_child_id={$cate_child_id} ";
}
if(!empty($status)){
    if($status == 1){
        $whereStr.= " AND status=1 ";
    }else if($status == 2){
        $whereStr.= " AND status != 1 ";
    }
}
if(!empty($shenhe_status)){
    if($shenhe_status == 2){
        $whereStr.= " AND shenhe_status=2 AND pay_status!=1 ";
    }else{
        $whereStr.= " AND shenhe_status={$shenhe_status} ";
    }
}
if($top_status > 0){
    if($top_status == 1){
        $whereStr.= " AND top_status = 1 ";
    }else if($top_status == 2){
        $whereStr.= " AND top_status = 0 ";
    }
}
if($expire_status > 0){
    if($expire_status == 1){
        $whereStr.= " AND (pay_status = 0 OR pay_status = 2) AND expire_status = 1 AND expire_time > ".TIMESTAMP;
    }else if($expire_status == 2){
        $whereStr.= " AND (pay_status = 1 OR expire_status = 2) ";
    }else if($expire_status == 3){
        $whereStr.= " AND (pay_status = 0 OR pay_status = 2) AND expire_status = 3 ";
    }
}

$order = "ORDER BY refresh_time DESC,id DESC";

$start          = ($page - 1)*$pagesize;
$count          = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count($whereStr,$keyword);
$tczhaopinListTmp  = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list($whereStr,$order,$start,$pagesize,$keyword);
$tczhaopinList = array();
if(!empty($tczhaopinListTmp)){
    foreach ($tczhaopinListTmp as $key => $value) {
        $tczhaopinList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        $siteInfoTmp = $sitesList[$value['site_id']];
        $cateInfoTmp = $cateList[$value['cate_id']];
        $cateChildInfoTmp   = $cateChildList[$value['cate_id']][$value['cate_child_id']];
        $jianzhiCateInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_jianzhi_cate')->fetch_by_id($value['jianzhi_cate_id']);
        
        $tczhaopinList[$key]['userInfo']              = $userInfoTmp;
        $tczhaopinList[$key]['cateInfo']              = $cateInfoTmp;
        $tczhaopinList[$key]['cateChildInfo']         = $cateChildInfoTmp;
        $tczhaopinList[$key]['jianzhiCateInfo']       = $jianzhiCateInfoTmp;
        $tczhaopinList[$key]['siteInfo']              = $siteInfoTmp;
        $tczhaopinList[$key]['top_time']              = dgmdate($value['top_time'],"Y-m-d H:i",$tomSysOffset);
        $tczhaopinList[$key]['refresh_time']          = dgmdate($value['refresh_time'],"Y-m-d H:i",$tomSysOffset);
        $tczhaopinList[$key]['add_time']              = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $tczhaopinList[$key]['expire_time']           = dgmdate($value['expire_time'],"Y-m-d H:i",$tomSysOffset);
        
        if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value['id'], $updateData);
        }
        
        if($value['pay_status'] == 1 && $value['expire_status'] == 3){
            $updateData['expire_status']   = 2;
            $updateData['expire_time']     = 0;
            $updateData['status']          = 0;
            $updateData['pay_status']      = 0;
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value['id'], $updateData);
            $tczhaopinList[$key]['expire_status'] = 2;
        }
        
        if($value['expire_status'] == 1 && $value['expire_time'] <= TIMESTAMP && $value['top_status'] == 0){
            $updateData = array();
            $updateData['expire_status']   = 2;
            $updateData['expire_time']     = 0;
            if($tczhaopinConfig['expire_do_type'] == 1){
                $updateData['status']      = 0;
            }
            C::t('#tom_tczhaopin#tom_tczhaopin')->update($value['id'], $updateData);
            update_zhaopin_tongcheng($value['id']);
            $companyInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_company')->fetch_by_id($value['company_id']);
            update_company_status($companyInfoTmp);
            $tczhaopinList[$key]['expire_status'] = 2;
        }
    }
}

$renzhengStatus = $companyRenzhengStatus = 0;
$rzCompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$__UserInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
if(is_array($rzCompanyInfoTmp) && !empty($rzCompanyInfoTmp[0])){
    $renzhengStatus = 1;
    $companyRenzhengStatus = 1;
}
if($renzhengStatus == 0 && $tczhaopinConfig['open_shenhe_status_2_fabu'] == 1){
    $rz2CompanyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$__UserInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($rz2CompanyInfoTmp) && !empty($rz2CompanyInfoTmp[0])){
        $renzhengStatus = 2;
    }
}
if($tczhaopinConfig['close_personal_renzheng'] == 0){
    $personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_user_id($__UserInfo['id']);
    if(is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1){
        $renzhengStatus = 1;
    }
    if(is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 2 && $tczhaopinConfig['open_shenhe_status_2_fabu'] == 1){
        $renzhengStatus = 2;
    }
}

$refreshPayStatus = 1;
$shenyuVipRefreshNum = 0;
if($refreshPayStatus == 1){
    $userLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND type = 2 AND today_time = {$nowDayTime} AND deduct_type = 1 ");
    if($companyRenzhengStatus == 1){
        $freeRefreshNum = $tczhaopinConfig['company_free_refresh_num'];
    }else{
        $freeRefreshNum = $tczhaopinConfig['personal_free_refresh_num'];
    }
    if($freeRefreshNum > $userLogCount){
        $refreshPayStatus = 2;
    }
}

$userVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($__UserInfo['id']);
$vipInfo = array();
$nowTime = TIMESTAMP;
$vipShengyuFabuNum = 0;
if($userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > $nowTime){
    $shengyuDays = ceil(($userVipInfo['expire_time'] - $nowTime)/86400);
    $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
    
    $userVipFabuLogCount = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND expire_status = 3 ");
    $vipShengyuFabuNum = $vipInfo['fabu_num'] - $userVipFabuLogCount;
    if($vipShengyuFabuNum <= 0){
        $vipShengyuFabuNum = 0;
    }
}else if($userVipInfo['id'] > 0 && $userVipInfo['expire_status'] == 0){
    $vipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($userVipInfo['vip_id']);
}

if($refreshPayStatus == 1){
    if($userVipInfo['vip_id'] > 0 && $userVipInfo['expire_status'] == 1 && $userVipInfo['expire_time'] > TIMESTAMP){
        $userVipLogCount = C::t("#tom_tczhaopin#tom_tczhaopin_log")->fetch_all_count(" AND user_id={$__UserInfo['id']} AND type = 2 AND today_time = {$nowDayTime} AND deduct_type = 2 ");
        if($vipInfo['refresh_num'] > $userVipLogCount){
            $refreshPayStatus = 3;
            $shenyuVipRefreshNum = $vipInfo['refresh_num'] - $userVipLogCount;
        }
    }
}

if($refreshPayStatus == 1){
    if($tczhaopinConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
        $scorePayNum = ceil(floatval($tczhaopinConfig['shoufei_zhaopin_refresh_price']) * $tongchengConfig['pay_score_yuan']);
        if($__UserInfo['score'] >= $scorePayNum){
            $refreshPayStatus = 4;
        }
    }
}

$payUrl     = "plugin.php?id=tom_zppc:pay";
$buyVipUrl  = $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=vip&frompc=1";
$xufeiUrl   = $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=buyxufeizhaopin&frompc=1&tczhaopin_id=";  
$topUrl     = $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=buyzhaopin&frompc=1&tczhaopin_id=";  

$renzheng_back_url = $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=my";  
$renzheng_back_url = urlencode($renzheng_back_url);
$companyRenzhengUrl = $_G['m_siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=company&renzheng_plugin=zhaopin&renzheng_back={$renzheng_back_url}";
$personalRenzhengUrl = $_G['m_siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=personal&renzheng_plugin=zhaopin&renzheng_back={$renzheng_back_url}";

$showMustPhoneBtn = 0;
if($tczhaopinConfig['zhaopin_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$site_id}&mod=my";  
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = $_G['m_siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$pageUrl = $modPchrUrl."&cate_id={$cate_id}&cate_child_id={$cate_child_id}&site_id={$site_id}&status={$status}&shenhe_status={$shenhe_status}&top_status={$top_status}&expire_status={$expire_status}&keyword={$keyword}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:hr/myzhaopinlist");