<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$resume_id  = intval($_GET['resume_id'])>0? intval($_GET['resume_id']):0;

$resumeInfo = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_by_id($resume_id); 

$rencaiListTmp = C::t('#tom_tczhaopin#tom_tczhaopin_rencai')->fetch_all_list("AND user_id = {$__UserInfo['id']} AND resume_id = {$resume_id}","",0,1);

if(is_array($rencaiListTmp) && !empty($rencaiListTmp)){}else{
    include template("tom_zppc:hr/error");exit;
}

$modPchrUrl = $pchrUrl."&tmod=mianshi";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'mianshi' && submitcheck('tczhaopin_id')){
   $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $tczhaopin_id   = intval($_GET['tczhaopin_id'])>0? intval($_GET['tczhaopin_id']):0;
    $address        = isset($_GET['address'])? addslashes($_GET['address']):'';
    $xm             = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $lng            = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat            = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $beizu          = isset($_GET['beizu'])? addslashes($_GET['beizu']):'';
    $beizu          = dhtmlspecialchars($beizu);
    
    $mianshiInfo = C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->fetch_all_list("AND tczhaopin_id = {$tczhaopin_id} AND resume_id = {$resume_id}","",0,1);
    if(is_array($mianshiInfo) && !empty($mianshiInfo)){
        $updateData = array();
        $updateData['xm']           = $xm;
        $updateData['tel']          = $tel;
        $updateData['address']      = $address;
        $updateData['latitude']     = $lat;
        $updateData['longitude']    = $lng;
        $updateData['beizu']        = $beizu;
        $updateData['status']       = 0;
        $updateData['add_time']     = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->update($mianshiInfo[0]['id'],$updateData);
        
        $mianshi_id = $mianshiInfo[0]['id'];
        
    }else{
        $insertData = array();
        $insertData['user_id']           = $resumeInfo['user_id'];
        $insertData['yaoqing_user_id']   = $__UserInfo['id'];
        $insertData['tczhaopin_id']      = $tczhaopin_id;
        $insertData['resume_id']         = $resume_id;
        $insertData['xm']                = $xm;
        $insertData['tel']               = $tel;
        $insertData['address']           = $address;
        $insertData['latitude']          = $lat;
        $insertData['longitude']         = $lng;
        $insertData['beizu']             = $beizu;
        $insertData['add_time']          = TIMESTAMP;
        C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->insert($insertData);
        
        $mianshi_id = C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->insert_id();
    }

    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($resumeInfo['user_id']);

    if(!empty($tongchengConfig['template_id']) && $toUser){
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($toUser['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['m_siteurl']."plugin.php?id=tom_tczhaopin&site={$toUser['site_id']}&mod=mianshilist&mianshi_id={$mianshi_id}&type=1");
            $template_first =  lang('plugin/tom_tczhaopin','mianshi_resume_template');
            $smsData = array(
                'first'         => $template_first,
                'keyword1'      => $tczhaopinConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}

$tczhaopinList = array();
$tczhaopinListTmp = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ", 'ORDER BY id DESC', 0, 100);
if(!empty($tczhaopinListTmp)){
    foreach($tczhaopinListTmp as $key => $value){
        $tczhaopinList[$key] = $value;
    }
}
$zhaopinCount = count($tczhaopinList);

$mianshiInfoTmp = C::t('#tom_tczhaopin#tom_tczhaopin_mianshi')->fetch_all_list("AND yaoqing_user_id = {$__UserInfo['id']}", " ORDER BY add_time DESC,id DESC ",0,1);
if(is_array($mianshiInfoTmp) && !empty($mianshiInfoTmp)){
    $address   = $mianshiInfoTmp[0]['address'];
    $latitude  = $mianshiInfoTmp[0]['latitude'];
    $longitude = $mianshiInfoTmp[0]['longitude'];
    $xm        = $mianshiInfoTmp[0]['xm'];
    $tel       = $mianshiInfoTmp[0]['tel'];
    $beizu     = $mianshiInfoTmp[0]['beizu'];
}else{
    $zhaopinInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ", "ORDER BY refresh_time DESC,id DESC ",0,1);
    if(is_array($zhaopinInfoTmp) && !empty($zhaopinInfoTmp)){
        $address   = $zhaopinInfoTmp[0]['address'];
        $latitude  = $zhaopinInfoTmp[0]['latitude'];
        $longitude = $zhaopinInfoTmp[0]['longitude'];
        $xm        = $zhaopinInfoTmp[0]['xm'];
        $tel       = $zhaopinInfoTmp[0]['tel'];
    }
}

$mianshiUrl = $modPchrUrl."&act=mianshi&resume_id={$resume_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_zppc:hr/mianshi");