<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$zppcConfig = $_G['cache']['plugin']['tom_zppc'];
$tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20210226";

$pchrUrl = 'plugin.php?id=tom_zppc:hr';
$ajaxUrl = 'plugin.php?id=tom_admin:ajax';
$uploadUrl = 'plugin.php?id=tom_admin:upload';
$baidumapUrl = 'plugin.php?id=tom_admin:baidumap';

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_zppc/config/pchr.lang.php';
include DISCUZ_ROOT.'./source/plugin/tom_zppc/class/function.url.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/config/config.utf.php';
}

## xiaofenlei start
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')){
    $xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
    $__ShowXiaofenlei = 1;
}
## xiaofenlei end

$welfareArray = array();
$welfare_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['welfare_list']); 
$welfare_list_str = str_replace("\n","{n}",$welfare_list_str);
$welfare_list_arr = explode("{n}", $welfare_list_str);
if(is_array($welfare_list_arr) && !empty($welfare_list_arr)){
    foreach ($welfare_list_arr as $key => $value){
        $welfare_list_item = explode("|", $value);
        $welfare_list_item_id = intval($welfare_list_item[0]);
        $welfare_list_item_name = trim($welfare_list_item[1]);
        if($welfare_list_item_id > 0 && !empty($welfare_list_item_name)){
            $welfareArray[$welfare_list_item_id] = $welfare_list_item_name;
        }
    }
}

$agesArray = array();
$ages_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['zhaopin_ages_list']); 
$ages_list_str = str_replace("\n","{n}",$ages_list_str);
$ages_list_arr = explode("{n}", $ages_list_str);
if(is_array($ages_list_arr) && !empty($ages_list_arr)){
    foreach ($ages_list_arr as $key => $value){
        $ages_list_item = explode("|", $value);
        $ages_list_item_id = intval($ages_list_item[0]);
        $ages_list_item_name = trim($ages_list_item[1]);
        if($ages_list_item_id > 0 && !empty($ages_list_item_name)){
            $agesArray[$ages_list_item_id] = $ages_list_item_name;
        }
    }
}

$workStatusArray = array();
$work_status_list_str = str_replace("\r\n","{n}",$tczhaopinConfig['work_status_list']); 
$work_status_list_str = str_replace("\n","{n}",$work_status_list_str);
$work_status_list_arr = explode("{n}", $work_status_list_str);
if(is_array($work_status_list_arr) && !empty($work_status_list_arr)){
    foreach ($work_status_list_arr as $key => $value){
        $work_status_list_item = explode("|", $value);
        $work_status_list_item_id = intval($work_status_list_item[0]);
        $work_status_list_item_name = trim($work_status_list_item[1]);
        if($work_status_list_item_id > 0 && !empty($work_status_list_item_name)){
            $workStatusArray[$work_status_list_item_id] = $work_status_list_item_name;
        }
    }
}

$resume_default_avatar = explode("|", $tczhaopinConfig['resume_default_avatar']);
$man_resume_avatar = "source/plugin/tom_tczhaopin/images/resume_avatar/".$resume_default_avatar[0];
$woman_resume_avatar = "source/plugin/tom_tczhaopin/images/resume_avatar/".$resume_default_avatar[1];

$Lang = $pchrLang;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_pc.php';

$_G['m_siteurl'] = $_G['siteurl'];

$zppcConfig['zhaopin_hosts']    = trim($zppcConfig['zhaopin_hosts']);
$zppcConfig['tongcheng_hosts']  = trim($zppcConfig['tongcheng_hosts']);

if($zppcConfig['open_zhaopin_hosts'] == 1 && !empty($zppcConfig['zhaopin_hosts']) && !empty($zppcConfig['tongcheng_hosts'])){
    
    $zppcConfig['tongcheng_hosts']  = rtrim($zppcConfig['tongcheng_hosts'], '/');
    $zppcConfig['tongcheng_hosts']  = $zppcConfig['tongcheng_hosts'].'/';
    
    $_G['m_siteurl'] = $zppcConfig['tongcheng_hosts'];
    
}

$index1Url = tom_zppc_url('index',1);

if(!empty($_GET['tmod'])){
    if($_GET['tmod'] == 'home'){
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/home.php';
    }else if($_GET['tmod'] == 'myzhaopinlist'){
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/myzhaopinlist.php';
    }else if($_GET['tmod'] == 'add'){
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/add.php';
    }else if($_GET['tmod'] == 'edit'){
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/edit.php';
    }else if($_GET['tmod'] == 'rencailist'){
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/rencailist.php';
    }else if($_GET['tmod'] == 'doDaoRencai'){
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/doDaoRencai.php';
    }else if($_GET['tmod'] == 'zpshenqinglist'){
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/zpshenqinglist.php';
    }else if($_GET['tmod'] == 'mianshilist'){
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/mianshilist.php';
    }else if($_GET['tmod'] == 'resumecollect'){
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/resumecollect.php';
    }else if($_GET['tmod'] == 'historylist'){
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/historylist.php';
    }else if($_GET['tmod'] == 'resumeinfo'){
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/resumeinfo.php';
    }else if($_GET['tmod'] == 'mianshi'){
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/mianshi.php';
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_zppc/hr/home.php';
    }   
}else{
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_zppc:hr/index");
}