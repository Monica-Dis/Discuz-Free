<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function tom_zppc_url($mod,$site,$param = array()){
    global $_G;
    
    $zppcConfig = $_G['cache']['plugin']['tom_zppc'];
    
    $siteurl = $_G['siteurl'];
    
    $zppcConfig['zhaopin_hosts'] = trim($zppcConfig['zhaopin_hosts']);
    if($zppcConfig['open_zhaopin_hosts'] == 1 && !empty($zppcConfig['zhaopin_hosts'])){
        $zppcConfig['zhaopin_hosts']  = rtrim($zppcConfig['zhaopin_hosts'], '/');
        $zppcConfig['zhaopin_hosts']  = $zppcConfig['zhaopin_hosts'].'/';
        $siteurl = $zppcConfig['zhaopin_hosts'];
    }
    
    $url = '';
    
    $rewrite = 0;
    if($zppcConfig['open_rewrite'] == 1){
        $rewrite = 1;
    }
    
    if($site > 0){}else{
        $site = 1;
    }
    
    if($mod == 'index'){
        if($rewrite == 1){
            if($site > 1){
                $url = $siteurl.$zppcConfig['rewrite_zhaopin_name']."/index-{$site}.html";
            }else{
                if($zppcConfig['open_zhaopin_hosts'] == 1 && !empty($zppcConfig['zhaopin_hosts'])){
                    $url = $siteurl;
                }else{
                    $url = $siteurl.$zppcConfig['rewrite_zhaopin_name']."/";
                }
            }
        }else{
            if($site == 1 && $zppcConfig['open_zhaopin_hosts'] == 1 && !empty($zppcConfig['zhaopin_hosts'])){
                $url = $siteurl;
            }else{
                $url = $siteurl."plugin.php?id=tom_zppc&site={$site}&mod=index";
            }
        }
        
    }else if($mod == 'list'){
        if($rewrite == 1){
            $cate_id = $cate_child_id = 0;
            $page = 1;
            if(isset($param['cate_id']) && $param['cate_id'] > 0){
                $cate_id = $param['cate_id'];
            }
            if(isset($param['cate_child_id']) && $param['cate_child_id'] > 0){
                $cate_child_id = $param['cate_child_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $siteurl.$zppcConfig['rewrite_zhaopin_name']."/list-{$site}-{$cate_id}-{$cate_child_id}-{$page}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_zppc&site={$site}&mod=list";
            if(isset($param['cate_id']) && $param['cate_id'] > 0){
                $url = $url."&cate_id={$param['cate_id']}";
            }
            if(isset($param['cate_child_id']) && $param['cate_child_id'] > 0){
                $url = $url."&cate_child_id={$param['cate_child_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
        
    }else if($mod == 'jianzhilist'){
        if($rewrite == 1){
            $jianzhi_cate_id = 0;
            $page = 1;
            if(isset($param['jianzhi_cate_id']) && $param['jianzhi_cate_id'] > 0){
                $jianzhi_cate_id = $param['jianzhi_cate_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $siteurl.$zppcConfig['rewrite_zhaopin_name']."/jianzhilist-{$site}-{$jianzhi_cate_id}-{$page}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_zppc&site={$site}&mod=jianzhilist";
            if(isset($param['jianzhi_cate_id']) && $param['jianzhi_cate_id'] > 0){
                $url = $url."&jianzhi_cate_id={$param['jianzhi_cate_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
        
    }else if($mod == 'zhaopininfo'){
        if($rewrite == 1){
            $url = $siteurl.$zppcConfig['rewrite_zhaopin_name']."/info-{$site}-{$param['tczhaopin_id']}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_zppc&site={$site}&mod=zhaopininfo&tczhaopin_id={$param['tczhaopin_id']}";
        }
        
    }else if($mod == 'companylist'){
        if($rewrite == 1){
            $industry_id = 0;
            $page = 1;
            if(isset($param['industry_id']) && $param['industry_id'] > 0){
                $industry_id = $param['industry_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $siteurl.$zppcConfig['rewrite_zhaopin_name']."/companylist-{$site}-{$industry_id}-{$page}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_zppc&site={$site}&mod=companylist";
            if(isset($param['industry_id']) && $param['industry_id'] > 0){
                $url = $url."&industry_id={$param['industry_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
    }else if($mod == 'companyinfo'){
        if($rewrite == 1){
            $url = $siteurl.$zppcConfig['rewrite_zhaopin_name']."/companyinfo-{$site}-{$param['company_id']}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_zppc&site={$site}&mod=companyinfo&company_id={$param['company_id']}";
        }
    }else if($mod == 'resumelist'){
        if($rewrite == 1){
            $cate_id = $cate_child_id = 0;
            $page = 1;
            if(isset($param['cate_id']) && $param['cate_id'] > 0){
                $cate_id = $param['cate_id'];
            }
            if(isset($param['cate_child_id']) && $param['cate_child_id'] > 0){
                $cate_child_id = $param['cate_child_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $siteurl.$zppcConfig['rewrite_zhaopin_name']."/resumelist-{$site}-{$cate_id}-{$cate_child_id}-{$page}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_zppc&site={$site}&mod=resumelist";
            if(isset($param['cate_id']) && $param['cate_id'] > 0){
                $url = $url."&cate_id={$param['cate_id']}";
            }
            if(isset($param['cate_child_id']) && $param['cate_child_id'] > 0){
                $url = $url."&cate_child_id={$param['cate_child_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
    }else if($mod == 'resumeinfo'){
        if($rewrite == 1){
            $url = $siteurl.$zppcConfig['rewrite_zhaopin_name']."/resumeinfo-{$site}-{$param['resume_id']}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_zppc&site={$site}&mod=resumeinfo&resume_id={$param['resume_id']}";
        }
    }else if($mod == 'meeting'){
        if($rewrite == 1){
            $page = 1;
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $siteurl.$zppcConfig['rewrite_zhaopin_name']."/meeting-{$site}-{$page}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_zppc&site={$site}&mod=meeting";
            
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
    }else if($mod == 'meetinginfo'){
        if($rewrite == 1){
            $url = $siteurl.$zppcConfig['rewrite_zhaopin_name']."/meetinginfo-{$site}-{$param['meeting_id']}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_zppc&site={$site}&mod=meetinginfo&meeting_id={$param['meeting_id']}";
        }
    }else if($mod == 'about'){
        if($rewrite == 1){
            $url = $siteurl.$zppcConfig['rewrite_zhaopin_name']."/about-{$site}-{$param['about_id']}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_zppc&site={$site}&mod=about&about_id={$param['about_id']}";
        }
    }
    
    if($rewrite == 1 && $zppcConfig['open_zhaopin_hosts'] == 1 && $zppcConfig['closed_rewrite_name'] == 1){
        $url = str_replace('/'.$zppcConfig['rewrite_zhaopin_name'].'/', '/', $url);
    }
    
    return $url;
    
}