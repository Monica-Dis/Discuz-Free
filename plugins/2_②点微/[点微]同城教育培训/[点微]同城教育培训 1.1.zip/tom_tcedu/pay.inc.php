<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$timeStamp          = TIMESTAMP;
$tceduConfig        = $_G['cache']['plugin']['tom_tcedu'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset       = getglobal('setting/timeoffset');

$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass        = new weixinClass($appid,$appsecret);

## tcyikatong start
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
    $tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $__ShowTcyikatong = 1;
    }
}
## tcyikatong end
## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';

$user_id = isset($_GET['user_id'])? intval($_GET['user_id']):0;

$tj_hehuoren_id = 0;
if(isset($_GET['tj_hehuoren_id'])){
    $tj_hehuoren_id = isset($_GET['tj_hehuoren_id'])?intval($_GET['tj_hehuoren_id']):0;
}else if(isset($_GET['tjid'])){
    $tj_hehuoren_id = isset($_GET['tjid'])?intval($_GET['tjid']):0;
}

$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
if($__ShowTchehuoren == 1 && $userInfo['id'] > 0 && $tj_hehuoren_id == 0){
    
    if($tchehuorenConfig['tcedu_type'] == 1 || $tchehuorenConfig['tcedu_type'] == 3){
        $cookie_tj_hehuoren_id = getcookie('tom_tcedu_tj_hehuoren_id');
        if($cookie_tj_hehuoren_id > 0){
            $tj_hehuoren_id = $cookie_tj_hehuoren_id;
        }
    }
    if($tchehuorenConfig['tcedu_type'] == 2  && $userInfo['tj_hehuoren_id'] > 0){
        $tj_hehuoren_id = $userInfo['tj_hehuoren_id'];
    }
    if($tchehuorenConfig['tcedu_type'] == 3 && $userInfo['tj_hehuoren_id'] > 0 && $tj_hehuoren_id == 0){
        $tj_hehuoren_id = $userInfo['tj_hehuoren_id'];
    }
}

$act = isset($_GET['act'])? addslashes($_GET['act']):"";
if($act == "ruzhu" && submitcheck('name')){

    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $cate_child_ids     = isset($_GET['cate_child_ids'])? addslashes($_GET['cate_child_ids']):'';
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $longitude          = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $latitude           = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $edu_xm             = isset($_GET['edu_xm'])? addslashes($_GET['edu_xm']):'';
    $edu_tel            = isset($_GET['edu_tel'])? addslashes($_GET['edu_tel']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $vip_id             = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $code               = isset($_GET['code'])? addslashes($_GET['code']):'';
    
    if($userInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 310,
        );
        echo json_encode($outArr); exit;
    }
    
    $fabuPayStatus = 0;
    if(!empty($code)){
        $vipCodeInfo = C::t('#tom_tcedu#tom_tcedu_vip_code')->fetch_by_code($code);
        if(empty($vipCodeInfo)){
            $outArr = array(
                'status'=> 312,
            );
            echo json_encode($outArr); exit;
        }
        if($vipCodeInfo['use_status'] == 1){
            $outArr = array(
                'status'=> 313,
            );
            echo json_encode($outArr); exit;
        }
        $vipInfo = C::t("#tom_tcedu#tom_tcedu_vip")->fetch_by_id($vipCodeInfo['vip_id']);
        if(is_array($vipInfo) && !empty($vipInfo)){
            $fabuPayStatus = 2;
        }else{
            $outArr = array(
                'status'=> 500,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $vipInfo = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_by_id($vip_id);
        if(is_array($vipInfo) && !empty($vipInfo) && $vipInfo['status'] == 1){ }else{
            $outArr = array(
                'status'=> 500,
            );
            echo json_encode($outArr); exit;
        }
        
        if($vipInfo['xiangou_num'] > 0){
            $vipLogCount = C::t('#tom_tcedu#tom_tcedu_vip_log')->fetch_all_count(" AND vip_id = {$vipInfo['id']} AND user_id = {$userInfo['id']} AND type = 1 ");
            if($vipLogCount >= $vipInfo['xiangou_num']){
                $outArr = array(
                    'status'=> 311,
                );
                echo json_encode($outArr); exit;
            }
        }
        
        if($vipInfo['price'] > 0){
            $fabuPayStatus = 1;
        }
    }
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $cateChildIdsArrTmp = explode(',', $cate_child_ids);
    $cateChildIdsArr = array();
    if(is_array($cateChildIdsArrTmp) && !empty($cateChildIdsArrTmp)){
        foreach($cateChildIdsArrTmp as $key => $value){
            $value = intval($value);
            if($value > 0){
                $cateChildIdsArr[] = $value;
            }
        }
    }
    
    $cateNameArr = array();
    $cateIdsStr = $cateChildIdsStr = '';
    if(!empty($cateChildIdsArr)){
        $cateChildIdsStrTmp = implode(',', $cateChildIdsArr);
        $cateChildListTmp = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_all_list(" AND id IN ({$cateChildIdsStrTmp}) ");
        $cateIdsArr = array();
        foreach($cateChildListTmp as $key => $value){
            $cateIdsArr[$value['pid']] = $value['pid'];
            $cateNameArr[] = $value['name'];
        }
        
        $cateIdsStrTmp = implode(',', $cateIdsArr);
        $cateListTmp = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_all_list(" AND id IN ({$cateIdsStrTmp}) ");
        foreach($cateListTmp as $key => $value){
            $cateNameArr[] = $value['name'];
        }
        
        $cateIdsStr = '|'.implode('|', $cateIdsArr).'|';
        $cateChildIdsStr = '|'.implode('|', $cateChildIdsArr).'|';
    }
    
    $tabsArr = array();
    foreach($_GET['tabs'] as $key => $value){
        $value = addslashes($value);
        if(!empty($value)){
            $tabsArr[] = $value;
        }
    }
    
    $tabsStr = implode('|', $tabsArr);
    
    $eduColorList = array();
    $edu_color_str = str_replace("\r\n","{n}",$tceduConfig['edu_color_list']); 
    $edu_color_str = str_replace("\n","{n}",$edu_color_str);
    $edu_color_arr = explode("{n}", $edu_color_str);
    if(is_array($edu_color_arr) && !empty($edu_color_arr)){
        foreach ($edu_color_arr as $key => $value){
            $arrTmp = explode("|", $value);

            $eduColorList[$key]['color']    = $arrTmp[0];
        }
    }
    
    $num = rand(0, count($eduColorList) - 1);
    $theme_color = $eduColorList[$num]['color'];
    
    $search_text = $name.'|'.$tel.'|'.implode('', $cateNameArr).'|'.$tabsStr;
    
    $insertData = array();
    $insertData['site_id']              = $site_id;
    $insertData['user_id']              = $userInfo['id'];
    $insertData['vip_id']               = $vipInfo['id'];
    $insertData['vip_rank']             = $vipInfo['vip_rank'];
    $insertData['name']                 = $name;
    $insertData['theme_color']          = $theme_color;
    $insertData['cate_ids']             = $cateIdsStr;
    $insertData['cate_child_ids']       = $cateChildIdsStr;
    $insertData['city_id']              = $city_id;
    $insertData['area_id']              = $area_id;
    $insertData['street_id']            = $street_id;
    $insertData['longitude']            = $longitude;
    $insertData['latitude']             = $latitude;
    $insertData['address']              = $address;
    $insertData['tabs']                 = $tabsStr;
    $insertData['edu_xm']               = $edu_xm;
    $insertData['edu_tel']              = $edu_tel;
    $insertData['tel']                  = $tel;
    $insertData['search_text']          = $search_text;
    if($tceduConfig['must_shenhe'] == 1){
        $insertData['shenhe_status']        = 2;
    }else{
        $insertData['shenhe_status']        = 1;
    }
    $insertData['status']               = 0;
    $insertData['huanjing_score']       = $tceduConfig['ruzhu_default_score'];
    $insertData['fuwu_score']           = $tceduConfig['ruzhu_default_score'];
    $insertData['teacher_score']        = $tceduConfig['ruzhu_default_score'];
    $insertData['total_score']          = $tceduConfig['ruzhu_default_score'];
    $insertData['update_time']          = TIMESTAMP;
    $insertData['add_time']             = TIMESTAMP;
    $tcedu_id = C::t('#tom_tcedu#tom_tcedu')->insert($insertData, true);
    if($tcedu_id > 0){
        
        if(!empty($tceduConfig['default_edu_avatar'])){
            $insertData = array();
            $insertData['tcedu_id']  = $tcedu_id;
            $insertData['type']      = 1;
            $insertData['picurl']    = $tceduConfig['default_edu_avatar'];
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcedu#tom_tcedu_photo')->insert($insertData);
        }
        
        ## pay start
        if($fabuPayStatus == 1){
            
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'status'=> 301,
                );
                echo json_encode($outArr); exit;
            }
            
            $pay_price = $vipInfo['price'];
            
            $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
            
            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['tcedu_id']         = $tcedu_id;
            $insertData['tcedu_name']       = $name;
            $insertData['order_type']       = 2;
            $insertData['vip_id']           = $vipInfo['id'];
            $insertData['vip_days']         = $vipInfo['days'];
            $insertData['vip_price']        = $vipInfo['price'];
            $insertData['user_id']          = $userInfo['id'];
            $insertData['openid']           = $userInfo['openid'];
            $insertData['order_no']         = $order_no;
            $insertData['pay_price']        = $pay_price;
            $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tcedu#tom_tcedu_order')->insert($insertData)){
                $insertData = array();
                $insertData['plugin_id']       = 'tom_tcedu';
                $insertData['order_no']        = $order_no;
                $insertData['goods_id']        = $tcedu_id;
                $insertData['goods_name']      = $name;
                $insertData['goods_beizu']     = '';
                $insertData['goods_url']       = "plugin.php?id=tom_tcedu&site={$site_id}&mod=info&tcedu_id={$tcedu_id}";
                $insertData['succ_back_url']   = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist";
                $insertData['fail_back_url']   = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist";
                $insertData['allow_alipay']    = 1;
                $insertData['pay_price']       = $pay_price;
                $insertData['order_status']    = 1;
                $insertData['add_time']        = TIMESTAMP;
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    $outArr = array(
                        'pay_status'    => 1,
                        'status'        => 200,
                        'payurl'        => "plugin.php?id=tom_pay&order_no=".$order_no,
                    );
                    echo json_encode($outArr); exit;
                }else{
                    $outArr = array(
                        'status'=> 306,
                    );
                    echo json_encode($outArr); exit;
                }
            }else{
                $outArr = array(
                    'status'=> 305,
                );
                echo json_encode($outArr); exit;
            }
            
        }else{
            
            $updateData = array();
            $updateData['expire_status']   = 1;
            $updateData['expire_time']     = TIMESTAMP + 86400 * $vipInfo['days'];
            C::t('#tom_tcedu#tom_tcedu')->update($tcedu_id, $updateData);
            
            if($fabuPayStatus == 2){
                $updateData = array();
                $updateData['use_status']   = 1;
                $updateData['user_id']      = $user_id;
                $updateData['tcedu_id']     = $tcedu_id;
                $updateData['use_time']     = TIMESTAMP;
                C::t('#tom_tcedu#tom_tcedu_vip_code')->update($vipCodeInfo['id'], $updateData);
            }
            
            $insertData = array();
            $insertData['user_id']      = $user_id;
            $insertData['tcedu_id']     = $tcedu_id;
            if($fabuPayStatus == 2){
                $insertData['type']         = 2;
                $insertData['vip_code_id']  = $vipCodeInfo['id'];
            }else{
                $insertData['type']         = 1;
                $insertData['vip_id']       = $vipInfo['id'];
            }
            $insertData['log_time']     = TIMESTAMP;
            C::t('#tom_tcedu#tom_tcedu_vip_log')->insert($insertData);
            
            if($tceduConfig['must_shenhe'] == 1){
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
                if($toUserTmp && !empty($toUserTmp['openid'])){
                    $access_token = $weixinClass->get_access_token();

                    if($access_token && !empty($toUserTmp['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=managerEduList");
                        $smsData = array(
                            'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcedu', 'shenhe_template_first'),
                            'keyword1'      => $tceduConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                            'remark'        => ''
                        );
                        $r = $templateSmsClass->sendSms01($toUserTmp['openid'],$tongchengConfig['template_id'],$smsData);
                    }
                }
                
                if($tceduConfig['manage_user_id'] > 0){
                    $toEduUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduConfig['manage_user_id']);
                    if($toEduUserTmp && !empty($toEduUserTmp['openid'])){
                        $access_token = $weixinClass->get_access_token();

                        if($access_token && !empty($toEduUserTmp['openid'])){
                            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=managerEduList");
                            $smsData = array(
                                'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcedu', 'shenhe_template_first'),
                                'keyword1'      => $tceduConfig['plugin_name'],
                                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                                'remark'        => ''
                            );
                            $r = $templateSmsClass->sendSms01($toEduUserTmp['openid'],$tongchengConfig['template_id'],$smsData);
                        }
                    }
                }
                
            }
        }
        
        ## pay end
        $outArr = array(
            'pay_status' => 0,
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "course_buy" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $course_id      = intval($_GET['course_id'])>0? intval($_GET['course_id']):0;
    $option_id      = intval($_GET['option_id'])>0? intval($_GET['option_id']):0;
    $xm             = isset($_GET['xm'])? daddslashes($_GET['xm']):'';
    $tel            = isset($_GET['tel'])? daddslashes($_GET['tel']):'';

    if($userInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $courseInfo = C::t("#tom_tcedu#tom_tcedu_course")->fetch_by_id($course_id);
    if($courseInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($courseInfo['hasoption'] == 1){
        $optionInfo = C::t("#tom_tcedu#tom_tcedu_course_option")->fetch_by_id($option_id);
        if($optionInfo['id'] > 0 && $courseInfo['id'] == $optionInfo['course_id']){ }else{
            $outArr = array(
                'status'=> 310,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($courseInfo['open_bm_end_time'] == 1 && TIMESTAMP > $courseInfo['bm_end_time']){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($courseInfo['hexiao_limit'] == 1 && $courseInfo['hexiao_days'] <= 0){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    if($courseInfo['hexiao_limit'] == 2 && TIMESTAMP > $courseInfo['hexiao_time']){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    if($courseInfo['xiangou_num'] > 0){
        $bmCount = C::t("#tom_tcedu#tom_tcedu_course_bm")->fetch_all_count(" AND course_id = {$courseInfo['id']} AND user_id = {$userInfo['id']} AND pay_status IN(0,2) ");
        if($bmCount >= $courseInfo['xiangou_num']){
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $attrList = array();
    if(!empty($courseInfo['attr_ids'])){
        $attrListTmp = C::t("#tom_tcedu#tom_tcedu_attr")->fetch_all_list("AND tcedu_id = {$courseInfo['tcedu_id']} AND id IN({$courseInfo['attr_ids']}) AND is_show = 1 ", 'ORDER BY asort ASC, id DESC');
        if(is_array($attrListTmp) && !empty($attrListTmp)){
            foreach($attrListTmp as $key => $value){
                $attrList[$key] = $value;

                if($value['type'] == 1){
                    $attrList[$key]['attr_value'] = isset($_GET['attr_'.$value['id']])? addslashes($_GET['attr_'.$value['id']]):'';
                }else if($value['type'] == 2){
                    $attrList[$key]['attr_value'] = intval($_GET['attr_'.$value['id']])>0? intval($_GET['attr_'.$value['id']]):0;
                }else if($value['type'] == 3){
                    $attrList[$key]['attr_value'] = isset($_GET['attr_'.$value['id']])? addslashes($_GET['attr_'.$value['id']]):'';
                }else if($value['type'] == 4){
                    $attrList[$key]['attr_value'] = '';
                    if(is_array($_GET['attr_'.$value['id']]) && !empty($_GET['attr_'.$value['id']])){
                        $attrValueArr = array();
                        foreach($_GET['attr_'.$value['id']] as $k => $v){
                            $attrValueTmp = isset($v)? addslashes($v):'';
                            if(!empty($attrValueTmp)){
                                $attrValueArr[] = $attrValueTmp;
                            }
                        }
                        $attrList[$key]['attr_value'] = implode('|', $attrValueArr);
                    }
                }
            }
        }
    }
    
    $tcyikatongPayStatus = 0;
    if($__ShowTcyikatong == 1 && $tceduConfig['open_course_tcyikatong'] == 1 && $courseInfo['open_vip'] == 1){
        $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($userInfo['id']);
        if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
            $tcyikatongPayStatus = 1;
        }
    }
    
    $tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($courseInfo['tcedu_id']);
    
    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    $hexiao_no = date("YmdHis")."-".mt_rand(111111, 666666);
    $pay_price = $courseInfo['buy_price'];
    
    if($courseInfo['hasoption'] == 1){
        $buy_price = $optionInfo['buy_price'];
        if($tcyikatongPayStatus == 1){
            $pay_price = $optionInfo['vip_price'];
        }
    }else{
        if($tcyikatongPayStatus == 1){
            $pay_price = $courseInfo['vip_price'];
        }
    }
    
    $bmInfoTmp = C::t("#tom_tcedu#tom_tcedu_course_bm")->fetch_all_list(" AND course_id = {$courseInfo['id']} AND user_id = {$userInfo['id']} AND pay_status = 1 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($bmInfoTmp) && !empty($bmInfoTmp[0])){
        $course_bm_id = $bmInfoTmp[0]['id'];
        
        $updateData = array();
        $updateData['xm']               = $xm;
        $updateData['tel']              = $tel;
        $updateData['hexiao_no']        = $hexiao_no;
        if($courseInfo['hasoption'] == 1){
            $updateData['option_id']        = $optionInfo['id'];
            $updateData['option_name']      = $optionInfo['name'];
            $updateData['class_num']        = $optionInfo['class_num'];
        }else{
            $updateData['option_id']        = '';
            $updateData['option_name']      = '';
            $updateData['class_num']        = $courseInfo['class_num'];
        }
        if($pay_price > 0){
            $updateData['order_no']             = $order_no;
            $updateData['pay_price']            = $pay_price;
            $updateData['pay_status']           = 1;
        }else{
            $updateData['order_no']             = '';
            $updateData['pay_price']            = 0;
            $updateData['pay_status']           = 0;
        }
        if($tcyikatongPayStatus == 1){
            $updateData['vip_pay_status']       = 1;
        }else{
            $updateData['vip_pay_status']       = 0;
        }
        $updateData['add_time']         = TIMESTAMP;
        C::t('#tom_tcedu#tom_tcedu_course_bm')->update($course_bm_id, $updateData);
        
        C::t('#tom_tcedu#tom_tcedu_course_bm_attr')->delete_by_bm_id($course_bm_id);
        
        DB::query("UPDATE ".DB::table('tom_tcedu_order')." SET order_status=3 WHERE course_id={$courseInfo['id']} AND course_bm_id = {$course_bm_id} AND order_status = 1 ", 'UNBUFFERED');
    
    }else{
        $insertData = array();
        $insertData['tcedu_id']         = $courseInfo['tcedu_id'];
        $insertData['tcedu_name']       = $tceduInfo['name'];
        $insertData['course_id']        = $courseInfo['id'];
        $insertData['course_name']      = $courseInfo['name'];
        if($courseInfo['hasoption'] == 1){
            $insertData['option_id']        = $optionInfo['id'];
            $insertData['option_name']      = $optionInfo['name'];
            $insertData['class_num']        = $optionInfo['class_num'];
        }else{
            $insertData['class_num']        = $courseInfo['class_num'];
        }
        $insertData['user_id']          = $userInfo['id'];
        $insertData['xm']               = $xm;
        $insertData['tel']              = $tel;
        $insertData['hexiao_no']        = $hexiao_no;
        if($pay_price > 0){
            $insertData['order_no']             = $order_no;
            $insertData['pay_price']            = $pay_price;
            $insertData['pay_status']           = 1;
        }
        if($tcyikatongPayStatus == 1){
            $insertData['vip_pay_status']       = 1;
        }
        $insertData['add_time']         = TIMESTAMP;
        $course_bm_id = C::t('#tom_tcedu#tom_tcedu_course_bm')->insert($insertData, true);
    }
    
    if($course_bm_id > 0){
        if(is_array($attrList) && !empty($attrList)){
            foreach($attrList as $key => $value){
                if(!empty($value['attr_value'])){
                    $insertData = array();
                    $insertData['bm_id']            = $course_bm_id;
                    $insertData['user_id']          = $userInfo['id'];
                    $insertData['tcedu_id']         = $courseInfo['tcedu_id'];
                    $insertData['course_id']        = $courseInfo['id'];
                    $insertData['attr_id']          = $value['id'];
                    $insertData['attr_type']        = $value['type'];
                    $insertData['attr_name']        = $value['name'];
                    $insertData['value']            = $value['attr_value'];
                    $insertData['unit']             = $value['unit'];
                    $insertData['asort']            = $value['asort'];
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tcedu#tom_tcedu_course_bm_attr')->insert($insertData);
                }
            }
        }
        
        if($pay_price > 0){
            $insertData = array();
            $insertData['site_id']          = $courseInfo['site_id'];
            $insertData['tcedu_id']         = $courseInfo['tcedu_id'];
            $insertData['tcedu_name']       = $tceduInfo['name'];
            $insertData['course_id']        = $courseInfo['id'];
            $insertData['course_name']      = $courseInfo['name'];
            if($courseInfo['hasoption'] == 1){
                $insertData['option_id']        = $optionInfo['id'];
                $insertData['option_name']      = $optionInfo['name'];
            }
            $insertData['course_bm_id']     = $course_bm_id;
            $insertData['order_type']       = 1;
            $insertData['user_id']          = $userInfo['id'];
            $insertData['openid']           = $userInfo['openid'];
            $insertData['order_no']         = $order_no;
            $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
            if($tcyikatongPayStatus == 1){
                $insertData['vip_pay_status']       = 1;
            }
            $insertData['pay_price']        = $pay_price;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tcedu#tom_tcedu_order')->insert($insertData)){
                $insertData = array();
                $insertData['plugin_id']       = 'tom_tcedu';
                $insertData['order_no']        = $order_no;
                $insertData['goods_id']        = $course_bm_id;
                $insertData['goods_name']      = $courseInfo['name'];
                $insertData['goods_beizu']     = '';
                $insertData['goods_url']       = "plugin.php?id=tom_tcedu&site={$site_id}&mod=courseinfo&course_id={$courseInfo['id']}";
                $insertData['succ_back_url']   = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mybm";
                $insertData['fail_back_url']   = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mybm";
                $insertData['allow_alipay']    = 1;
                $insertData['pay_price']       = $pay_price;
                $insertData['order_status']    = 1;
                $insertData['add_time']        = TIMESTAMP;
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    $outArr = array(
                        'status'    => 200,
                        'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                    );
                    echo json_encode($outArr); exit;
                }else{
                    $outArr = array(
                        'status'=> 306,
                    );
                    echo json_encode($outArr); exit;
                }
            }else{
                $outArr = array(
                    'status'=> 305,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            
            DB::query("UPDATE ".DB::table('tom_tcedu_course')." SET sale_num=sale_num+1 WHERE id={$courseInfo['id']}", 'UNBUFFERED');
            if($courseInfo['hasoption'] == 1){
                DB::query("UPDATE ".DB::table('tom_tcedu_course_option')." SET sale_num=sale_num+1 WHERE id={$optionInfo['id']}", 'UNBUFFERED');
            }
            
            if(!empty($tceduConfig['template_neworder'])){
        
                include DISCUZ_ROOT.'./source/plugin/tom_tcedu/class/templatesms.class.php';

                $access_token = $weixinClass->get_access_token();
                
                if($access_token && !empty($userInfo['openid']) ){
                    $templateSmsClass = new eduTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site=".$site_id."&mod=mybm");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcedu','template_user_course_first'),
                        'keyword1'      => $courseInfo['name'],
                        'keyword2'      => 0,
                        'keyword3'      => $xm,
                        'keyword4'      => $tel,
                        'keyword5'      => '',
                        'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
                    );
                    @$r = $templateSmsClass->sendSmsNewOrder($userInfo['openid'],$tceduConfig['template_neworder'],$smsData);
                }
                
                $tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($courseInfo['tcedu_id']);
                $tceduUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduInfo['user_id']);
                
                if($access_token && !empty($tceduUserInfo['openid']) ){
                    $templateSmsClass = new eduTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site=".$site_id."&mod=coursebm&course_id={$courseInfo['id']}");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcedu','template_neworder_course_first'),
                        'keyword1'      => $courseInfo['name'],
                        'keyword2'      => 0,
                        'keyword3'      => $xm,
                        'keyword4'      => $tel,
                        'keyword5'      => '',
                        'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
                    );
                    @$r = $templateSmsClass->sendSmsNewOrder($tceduUserInfo['openid'],$tceduConfig['template_neworder'],$smsData);
                }
                
                if($tceduInfo['manage_user_id'] > 0){
                    $tceduManageUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduInfo['manage_user_id']);
                    
                    if($access_token && !empty($tceduManageUserInfo['openid']) ){
                        $templateSmsClass = new eduTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site=".$site_id."&mod=coursebm&course_id={$courseInfo['id']}");
                        $smsData = array(
                            'first'         => lang('plugin/tom_tcedu','template_neworder_course_first'),
                            'keyword1'      => $courseInfo['name'],
                            'keyword2'      => 0,
                            'keyword3'      => $xm,
                            'keyword4'      => $tel,
                            'keyword5'      => '',
                            'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
                        );
                        @$r = $templateSmsClass->sendSmsNewOrder($tceduManageUserInfo['openid'],$tceduConfig['template_neworder'],$smsData);
                    }
                }
            }
            
            $outArr = array(
                'status'=> 200,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "vip_pay" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $tcedu_id           = isset($_GET['tcedu_id'])? intval($_GET['tcedu_id']):0;
    $vip_id             = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $back_url           = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
    
    if($userInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 310,
        );
        echo json_encode($outArr); exit;
    }
    
    $tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
    if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $userInfo['id'] || $tceduInfo['manage_user_id'] == $userInfo['id'])){ }else{
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    $fabuPayStatus = 0;
    $vipInfo = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_by_id($vip_id);
    if($vipInfo['id'] > 0 && $vipInfo['status'] == 1){ }else{
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    if($vipInfo['xiangou_num'] > 0){
        $vipLogCount = C::t("#tom_tcedu#tom_tcedu_vip_log")->fetch_all_count(" AND user_id = {$userInfo['id']} AND vip_id = {$vipInfo['id']} AND type = 1 ");
        if($vipLogCount >= $vipInfo['xiangou_num']){
            $outArr = array(
                'status'=> 311,
            );
            echo json_encode($outArr); exit;
        }
    }
    if($vipInfo['price'] > 0){
        $fabuPayStatus = 1;
    }
    
    ## pay start
    if($fabuPayStatus == 1){

        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }

        $pay_price = $vipInfo['price'];

        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['tcedu_id']         = $tcedu_id;
        $insertData['tcedu_name']       = $tceduInfo['name'];
        $insertData['order_type']       = 3;
        $insertData['vip_id']           = $vipInfo['id'];
        $insertData['vip_days']         = $vipInfo['days'];
        $insertData['vip_price']        = $vipInfo['price'];
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcedu#tom_tcedu_order')->insert($insertData)){
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcedu';
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $tcedu_id;
            $insertData['goods_name']      = $vipInfo['name'];
            $insertData['goods_beizu']     = $vipInfo['days_msg'];
            $insertData['goods_url']       = "plugin.php?id=tom_tcedu&site={$site_id}&mod=info&tcedu_id={$tcedu_id}";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tcedu&site={$site_id}&mod=vipbuy&tcedu_id={$tcedu_id}&back_url=".urlencode($back_url);
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcedu&site={$site_id}&mod=vipbuy&tcedu_id={$tcedu_id}&back_url=".urlencode($back_url);
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'pay_status'    => 1,
                    'status'        => 200,
                    'payurl'        => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }

    }else{
        
        $expire_time = TIMESTAMP + 86400 * $vipInfo['days'];
        if($tceduInfo['expire_status'] == 1 && $tceduInfo['expire_time'] > TIMESTAMP){
            $expire_time = $tceduInfo['expire_time'] + 86400 * $vipInfo['days'];
        }
        
        $updateData = array();
        $updateData['vip_id']           = $vipInfo['id'];
        $updateData['vip_rank']         = $vipInfo['vip_rank'];
        $updateData['expire_status']    = 1;
        $updateData['expire_time']      = $expire_time;
        C::t('#tom_tcedu#tom_tcedu')->update($tcedu_id, $updateData);

        $insertData = array();
        $insertData['user_id']      = $user_id;
        $insertData['tcedu_id']     = $tcedu_id;
        $insertData['vip_id']       = $vipInfo['id'];
        $insertData['type']         = 1;
        $insertData['log_time']     = TIMESTAMP;
        C::t('#tom_tcedu#tom_tcedu_vip_log')->insert($insertData);
        if($tceduConfig['must_shenhe'] == 1){
            if(!empty($tceduConfig['template_neworder'])){
                
                include DISCUZ_ROOT.'./source/plugin/tom_tcedu/class/templatesms.class.php';
                
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($userInfo['openid']) ){
                    $templateSmsClass = new eduTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site=".$site_id."&mod=edu&tcedu_id={$tcedu_id}");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcedu','template_vip_pay'),
                        'keyword1'      => $vipInfo['name'],
                        'keyword2'      => 0,
                        'keyword3'      => '',
                        'keyword4'      => '',
                        'keyword5'      => '',
                        'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
                    );
                    @$r = $templateSmsClass->sendSmsNewOrder($userInfo['openid'],$tceduConfig['template_neworder'],$smsData);
                }
                
                if($tceduInfo['manage_user_id'] > 0){
                    $manage_user_id = $tceduInfo['manage_user_id'];
                    if($userInfo['id'] == $tceduInfo['manage_user_id']){
                        $manage_user_id = $tceduInfo['user_id'];
                    }
                    $tceduManageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($manage_user_id);
                    if($access_token && !empty($tceduManageUserInfo['openid']) ){
                        $templateSmsClass = new eduTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site=".$site_id."&mod=edu&tcedu_id={$tcedu_id}");
                        $smsData = array(
                            'first'         => lang('plugin/tom_tcedu','template_vip_pay'),
                            'keyword1'      => $vipInfo['name'],
                            'keyword2'      => 0,
                            'keyword3'      => '',
                            'keyword4'      => '',
                            'keyword5'      => '',
                            'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
                        );
                        @$r = $templateSmsClass->sendSmsNewOrder($tceduManageUserInfo['openid'],$tceduConfig['template_neworder'],$smsData);
                    }
                }
                
                $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
                if($access_token && !empty($toUserTmp['openid']) ){
                    $templateSmsClass = new eduTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site=".$site_id."&mod=index");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcedu','template_neworder_vip_pay'),
                        'keyword1'      => $vipInfo['name'],
                        'keyword2'      => 0,
                        'keyword3'      => '',
                        'keyword4'      => '',
                        'keyword5'      => '',
                        'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
                    );
                    @$r = $templateSmsClass->sendSmsNewOrder($toUserTmp['openid'],$tceduConfig['template_neworder'],$smsData);
                }
                
                if($tceduConfig['manage_user_id'] > 0){
                    $toEduManageUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduConfig['manage_user_id']);
                    if($access_token && !empty($toEduManageUserTmp['openid']) ){
                        $templateSmsClass = new eduTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site=".$site_id."&mod=index");
                        $smsData = array(
                            'first'         => lang('plugin/tom_tcedu','template_neworder_vip_pay'),
                            'keyword1'      => $vipInfo['name'],
                            'keyword2'      => 0,
                            'keyword3'      => '',
                            'keyword4'      => '',
                            'keyword5'      => '',
                            'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
                        );
                        @$r = $templateSmsClass->sendSmsNewOrder($toEduManageUserTmp['openid'],$tceduConfig['template_neworder'],$smsData);
                    }
                }
            }
        }
    }

    ## pay end
    $outArr = array(
        'pay_status' => 0,
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == "top_buy" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $tcedu_id       = intval($_GET['tcedu_id'])>0 ? intval($_GET['tcedu_id']):0;
    $top_days       = intval($_GET['top_days'])>0 ? intval($_GET['top_days']):0;
    $back_url       = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
    
    $tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($tceduInfo) && $tceduInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
    if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $userInfo['id'] || $tceduInfo['manage_user_id'] == $userInfo['id'])){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $top_pay_price = $top_pay_score = 0;
    $top_pay_price_msg = '';
    $top_list_str = str_replace("\r\n","{n}",$tceduConfig['edu_top_list']); 
    $top_list_str = str_replace("\n","{n}",$top_list_str);
    $top_list_arr = explode("{n}", $top_list_str);
    if(is_array($top_list_arr) && !empty($top_list_arr)){
        foreach ($top_list_arr as $key => $value){
            $topInfoTmp = array();
            $topInfoTmp = explode("|", $value);

            if($topInfoTmp[0] == $top_days){
                $top_pay_price = $topInfoTmp[1];
                $top_pay_price_msg = $topInfoTmp[2];
                
                if($tceduConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                    $top_pay_score = intval($top_pay_price * $tongchengConfig['pay_score_yuan']);
                }
            }
        }
    }
    
    if($top_pay_price <= 0){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($top_pay_score > 0 && $userInfo['score'] >= $top_pay_score){
        $pay_score = $top_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 52;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        if($tceduInfo['top_time'] > TIMESTAMP){
            $top_time = $top_days * 86400 + $tceduInfo['top_time'];
        }else{
            $top_time = $top_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        $updateData['top_rand']     = 10000;
        C::t('#tom_tcedu#tom_tcedu')->update($tceduInfo['id'], $updateData);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $pay_price = $top_pay_price;
        
        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        
        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['tcedu_id']         = $tcedu_id;
        $insertData['tcedu_name']       = $tceduInfo['name'];
        $insertData['order_type']       = 4;
        $insertData['top_days']         = $top_days;
        $insertData['top_price']        = $top_pay_price;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcedu#tom_tcedu_order')->insert($insertData)){

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcedu';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $tcedu_id;         
            $insertData['goods_name']      = $tceduInfo['name'];
            $insertData['goods_beizu']     = lang('plugin/tom_tcedu','edu_top').$top_pay_price_msg;
            $insertData['goods_url']       = 'plugin.php?id=tom_tcedu&site='.$site_id.'&mod=info&tcedu_id='.$tcedu_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcedu&site='.$site_id.'&mod=topbuy&tcedu_id='.$tcedu_id.'&back_url='.urlencode($back_url);
            $insertData['fail_back_url']   = 'plugin.php?id=tom_tcedu&site='.$site_id.'&mod=topbuy&tcedu_id='.$tcedu_id.'&back_url='.urlencode($back_url);
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 307,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }
    echo json_encode($outArr); exit;
    
}else if($act == "course_top_buy" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $course_id      = intval($_GET['course_id'])>0 ? intval($_GET['course_id']):0;
    $top_days       = intval($_GET['top_days'])>0 ? intval($_GET['top_days']):0;
    $back_url       = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
    
    if($userInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 310,
        );
        echo json_encode($outArr); exit;
    }
    
    $courseInfo = C::t("#tom_tcedu#tom_tcedu_course")->fetch_by_id($course_id);
    if(is_array($courseInfo) && $courseInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($courseInfo['tcedu_id']);
    if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $userInfo['id'] || $tceduInfo['manage_user_id'] == $userInfo['id'])){ }else{
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $top_pay_price = $top_pay_score = 0;
    $top_pay_price_msg = '';
    $top_list_str = str_replace("\r\n","{n}",$tceduConfig['course_top_list']); 
    $top_list_str = str_replace("\n","{n}",$top_list_str);
    $top_list_arr = explode("{n}", $top_list_str);
    if(is_array($top_list_arr) && !empty($top_list_arr)){
        foreach ($top_list_arr as $key => $value){
            $topInfoTmp = array();
            $topInfoTmp = explode("|", $value);

            if($topInfoTmp[0] == $top_days){
                $top_pay_price = $topInfoTmp[1];
                $top_pay_price_msg = $topInfoTmp[2];
                
                if($tceduConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                    $top_pay_score = intval($top_pay_price * $tongchengConfig['pay_score_yuan']);
                }
            }
        }
    }
    
    if($top_pay_price <= 0){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($top_pay_score > 0 && $userInfo['score'] >= $top_pay_score){
        $pay_score = $top_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 52;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        if($courseInfo['top_time'] > TIMESTAMP){
            $top_time = $top_days * 86400 + $courseInfo['top_time'];
        }else{
            $top_time = $top_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcedu#tom_tcedu_course')->update($courseInfo['id'], $updateData);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        
        $pay_price = $top_pay_price;
        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        
        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['tcedu_id']         = $tcedu_id;
        $insertData['tcedu_name']       = $tceduInfo['name'];
        $insertData['course_id']        = $courseInfo['id'];
        $insertData['course_name']      = $courseInfo['name'];
        $insertData['order_type']       = 5;
        $insertData['top_days']         = $top_days;
        $insertData['top_price']        = $top_pay_price;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcedu#tom_tcedu_order')->insert($insertData)){

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcedu';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $courseInfo['id'];         
            $insertData['goods_name']      = $courseInfo['name'];
            $insertData['goods_beizu']     = lang('plugin/tom_tcedu','course_top').$top_pay_price_msg;
            $insertData['goods_url']       = 'plugin.php?id=tom_tcedu&site='.$site_id.'&mod=courseinfo&course_id='.$courseInfo['id'];
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcedu&site='.$site_id.'&mod=coursetopbuy&course_id='.$courseInfo['id'].'&back_url='.urlencode($back_url);
            $insertData['fail_back_url']   = 'plugin.php?id=tom_tcedu&site='.$site_id.'&mod=coursetopbuy&course_id='.$courseInfo['id'].'&back_url='.urlencode($back_url);
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 307,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }
    echo json_encode($outArr); exit;
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}