<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tceduConfig = $_G['cache']['plugin']['tom_tcedu'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20210332";

$pcadminUrl = 'plugin.php?id=tom_tcedu:pcadmin';
$ajaxUrl = 'plugin.php?id=tom_admin:ajax';
$eduAjaxUrl = 'plugin.php?id=tom_tcedu:pcadminAjax';
$uploadUrl = 'plugin.php?id=tom_admin:upload';
$baidumapUrl = 'plugin.php?id=tom_admin:baidumap';

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcedu/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcedu/config/pcadmin.lang.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

$Lang = $pcadminLang;

include DISCUZ_ROOT.'./source/plugin/tom_tcedu/config/config.data.php';

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcyikatong start
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
    $tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $__ShowTcyikatong = 1;
    }
}
## tcyikatong end
## video start
$__ShowVideo = 0;
if($tceduConfig['open_video'] == 1){
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/video.inc.php')){
        $__ShowVideo = 1;
    }
}
## video end

include DISCUZ_ROOT.'./source/plugin/tom_admin/login_check.php';

if($_GET['tmod'] == 'list'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/list.php';
}else if($_GET['tmod'] == 'add'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/add.php';
}else if($_GET['tmod'] == 'edit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/edit.php';
}else if($_GET['tmod'] == 'teacher'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/teacher.php';
}else if($_GET['tmod'] == 'pinglun'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/pinglun.php';
}else if($_GET['tmod'] == 'guanzu'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/guanzu.php';
}else if($_GET['tmod'] == 'course'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/course.php';
}else if($_GET['tmod'] == 'courseadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/courseadd.php';
}else if($_GET['tmod'] == 'courseedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/courseedit.php';
}else if($_GET['tmod'] == 'coursecate'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/coursecate.php';
}else if($_GET['tmod'] == 'coursecollect'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/coursecollect.php';
}else if($_GET['tmod'] == 'coursebm'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/coursebm.php';
}else if($_GET['tmod'] == 'vip'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/vip.php';
}else if($_GET['tmod'] == 'vipadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/vipadd.php';
}else if($_GET['tmod'] == 'vipedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/vipedit.php';
}else if($_GET['tmod'] == 'vipcode'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/vipcode.php';
}else if($_GET['tmod'] == 'cate'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/cate.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/focuspic.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/order.php';
}else if($_GET['tmod'] == 'coursebminfo'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/coursebminfo.php';
}else if($_GET['tmod'] == 'phb'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/phb.php';
}else if($_GET['tmod'] == 'phbedu'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/phbedu.php';
}else if($_GET['tmod'] == 'diynav'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/diynav.php';
}else if($_GET['tmod'] == 'attr'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/attr.php';
}else if($_GET['tmod'] == 'viplog'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/viplog.php';
}else if($_GET['tmod'] == 'bmlog'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/bmlog.php';
}else if($_GET['tmod'] == 'common'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/common.php';
}else if($_GET['tmod'] == 'popup'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/popup.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/pcadmin/list.php';
}