<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcedu_id   = intval($_GET['tcedu_id']) > 0 ? intval($_GET['tcedu_id']) : 0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
if($tceduInfo['id'] > 0 && ($__UserInfo['id'] == $tceduInfo['user_id'] || $__UserInfo['id'] == $tceduInfo['manage_user_id'])){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

if($tceduInfo['vip_id'] > 0){
    $vipInfo = C::t("#tom_tcedu#tom_tcedu_vip")->fetch_by_id($tceduInfo['vip_id']);
    
    if(!preg_match('/^http/', $vipInfo['logo']) ){
        if(strpos($vipInfo['logo'], 'source/plugin/tom_') === FALSE){
            $vipInfo['logo'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vipInfo['logo'];
        }else{
            $vipInfo['logo'] = $_G['siteurl'].$vipInfo['logo'];
        }
    }else{
        $vipInfo['logo'] = $vipInfo['logo'];
    }
}

$score_yuan = $tongchengConfig['score_yuan'];
if($tceduConfig['score_yuan'] > 0){
    $score_yuan = $tceduConfig['score_yuan'];
}

$vipListTmp = C::t("#tom_tcedu#tom_tcedu_vip")->fetch_all_list(" AND status = 1 ", "ORDER BY vsort ASC, id DESC");
$vipList = $vipArr = array();
$hasfreeVip = 0;
if(is_array($vipListTmp) && !empty($vipListTmp)){
    foreach($vipListTmp as $key => $value){
        
        if($value['xiangou_num'] > 0){
            $vipLogCount = C::t("#tom_tcedu#tom_tcedu_vip_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND vip_id = {$value['id']} AND type = 1 ");
            if($vipLogCount >= $value['xiangou_num']){
                continue;
            }
        }
        
        if(!preg_match('/^http/', $value['logo']) ){
            if(strpos($value['logo'], 'source/plugin/tom_') === FALSE){
                $logoTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['logo'];
            }else{
                $logoTmp = $_G['siteurl'].$value['logo'];
            }
        }else{
            $logoTmp = $value['logo'];
        }
        
        $scoreTmp = $value['price'] * $score_yuan;
        if($scoreTmp < 1){
            $scoreTmp = 0;
        }
        if($value['price'] == 0){
            $hasfreeVip = 1;
        }
        
        if($__IsMiniprogram == 1 && $__Ios == 1  && $tceduConfig['closed_ios_pay'] == 1 && $value['price'] > 0){ }else{
            $vipList[$key] = $value;
            $vipArr[] = $value;

            $vipList[$key]['price'] = floatval($value['price']);
            $vipList[$key]['score'] = $scoreTmp;
            $vipList[$key]['logo']  = $logoTmp;

        }
    }
}
$vipCount = count($vipArr);

$columnArr = array(
    0 => 'open_video',
    1 => 'open_experience_course',
    2 => 'experience_course_num',
    3 => 'course_num',
    4 => 'vip_rank',
    5 => 'yongjin_bili',
);

$vipTequanList = array();
if(is_array($vipArr) && !empty($vipArr)){
    $viplength = count($vipArr);
    $columnlength = count($columnArr);
    for ($i = 0; $i < $columnlength; $i++) {
        $value = array();
        for ($j = 0; $j < $viplength; $j++) {
            $value[] = $vipArr[$j][$columnArr[$i]];
        }
        $vipTequanList[$columnArr[$i]] = $value;
    }
}

$payVipUrl = $_G['siteurl']."plugin.php?id=tom_tcedu:pay&site={$site_id}&act=vip_pay&back_url=".urlencode($back_url);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:vipbuy");