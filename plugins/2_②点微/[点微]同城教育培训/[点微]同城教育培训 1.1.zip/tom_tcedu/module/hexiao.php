<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$hexiao_no = isset($_GET['hexiao_no'])? addslashes($_GET['hexiao_no']):'';

$bmInfo = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_by_hexiao_no($hexiao_no);
if(is_array($bmInfo) && !empty($bmInfo)){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=index");exit;
}

$courseInfo = C::t('#tom_tcedu#tom_tcedu_course')->fetch_by_id($bmInfo['course_id']);
$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($bmInfo['tcedu_id']);

if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ }else{
    $teacherInfoTmp = C::t("#tom_tcedu#tom_tcedu_teacher")->fetch_all_list(" AND tcedu_id = {$tceduInfo['id']} AND user_id = {$__UserInfo['id']} AND open_hexiao = 1 ", 'ORDER BY id DESC',0 ,1);
    if(is_array($teacherInfoTmp) && !empty($teacherInfoTmp[0])){ }else{
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=index");exit;
    }
}

$bmInfo['sy_num'] = $bmInfo['class_num'] - $bmInfo['use_num'];

if($_GET['act'] == 'hexiao' && $_GET['formhash'] == FORMHASH){
    
    $hexiao_num = intval($_GET['num'])>0? intval($_GET['num']):0;
    
    if(($bmInfo['pay_status'] == 0 || $bmInfo['pay_status'] == 2) && $bmInfo['use_status'] == 0 && $bmInfo['refund_status'] == 0){ }else{
        echo 404;exit;
    }
    
    if($hexiao_num > $bmInfo['sy_num']){
        echo 301;exit;
    }
    
    $use_status = 0;
    if($hexiao_num == $bmInfo['sy_num']){
        $use_status = 1;
    }
    
    $use_num = $bmInfo['use_num'] + $hexiao_num;
    
    $updateData = array();
    if($use_status == 1){
        $updateData['use_status']       = 1;
        $updateData['hexiao_user_id']   = $__UserInfo['id'];
        $updateData['hexiao_time']      = TIMESTAMP;
    }
    $updateData['use_num']          = $use_num;
    if(C::t('#tom_tcedu#tom_tcedu_course_bm')->update($bmInfo['id'],$updateData)){
        
        $insertData = array();
        $insertData['bm_id']            = $bmInfo['id'];
        $insertData['tcedu_id']         = $bmInfo['tcedu_id'];
        $insertData['course_id']        = $bmInfo['course_id'];
        $insertData['use_num']          = $hexiao_num;
        $insertData['hexiao_user_id']   = $__UserInfo['id'];
        $insertData['hexiao_time']      = TIMESTAMP;
        C::t('#tom_tcedu#tom_tcedu_course_bm_log')->insert($insertData);
        
        if(!empty($bmInfo['order_no']) && $bmInfo['balance_status'] == 0){
            include DISCUZ_ROOT.'./source/plugin/tom_tcedu/module/balance.php';
        }
        echo 200;exit;
    }
    
    echo 1;exit;
}

$photoInfoTmp = C::t("#tom_tcedu#tom_tcedu_photo")->fetch_all_list(" AND course_id = {$courseInfo['id']} AND type = 4 ", 'ORDER BY id DESC', 0, 1);
if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
    $courseInfo['picurl'] = $photoInfoTmp[0]['picurlTmp'];
}

$hexiaoEndTimeTmp = '';
if($courseInfo['hexiao_limit'] > 0){
    $hexiaoEndTimeStamp = 0;
    if($courseInfo['hexiao_limit'] == 1){
        $hexiaoEndTimeStamp = $courseInfo['hexiao_days'] * 86400 + $bmInfo['add_time'];
        $hexiaoEndTimeTmp = dgmdate($hexiaoEndTimeStamp,"Y-m-d H:i",$tomSysOffset);
    }else if($courseInfo['hexiao_limit'] == 2){
        $hexiaoEndTimeStamp = $courseInfo['hexiao_time'];
        $hexiaoEndTimeTmp = dgmdate($courseInfo['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
    }
    
    if($hexiaoEndTimeStamp < TIMESTAMP && $bmInfo['use_status'] == 0){
        $bmInfo['use_status'] = 2;
    }
}

$bmAttrListTmp = C::t("#tom_tcedu#tom_tcedu_course_bm_attr")->fetch_all_list(" AND bm_id = {$bmInfo['id']} ",'ORDER BY asort ASC,id DESC');
$bmAttrList = array();
if(is_array($bmAttrListTmp) && !empty($bmAttrListTmp)){
    foreach($bmAttrListTmp as $key => $value){
        $bmAttrList[$key] = $value;
        if($value['attr_type'] == 4){
            $bmAttrList[$key]['value'] = str_replace("|"," ", $value['value']);
        }
    }
}

if($bmInfo['hexiao_user_id'] > 0){
    $hexiaoUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($bmInfo['hexiao_user_id']);
}

$useLogListTmp = C::t('#tom_tcedu#tom_tcedu_course_bm_log')->fetch_all_list(" AND bm_id = {$bmInfo['id']} ", 'ORDER BY id DESC');
$useLogList = array();
if(is_array($useLogListTmp) && !empty($useLogListTmp)){
    foreach($useLogListTmp as $key => $value){
        $useLogList[$key] = $value;
        
        $hexiaoUserInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['hexiao_user_id']);
        
        $useLogList[$key]['hexiaoUserInfo']  = $hexiaoUserInfoTmp;
        $useLogList[$key]['hexiao_time']     = dgmdate($value['hexiao_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}
$useLogCount = count($useLogList);

$hexiaoUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=hexiao&act=hexiao&hexiao_no={$hexiao_no}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:hexiao");