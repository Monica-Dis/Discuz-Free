<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$course_id = isset($_GET['course_id'])? intval($_GET['course_id']):0;

$courseInfo = C::t("#tom_tcedu#tom_tcedu_course")->fetch_by_id($course_id);
if($courseInfo['id'] > 0){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($courseInfo['tcedu_id']);

$editPowerStatus = 0;
if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ 
    $editPowerStatus = 1;
}

# check start
if($editPowerStatus == 0){
    if($__UserInfo['id'] == $tceduConfig['manage_user_id']){
        $editPowerStatus = 2;
    }else{
        if($__UserInfo['groupid'] == 1){
            $editPowerStatus = 2;
        }else if($__UserInfo['groupid'] == 2){
            if($tceduInfo['site_id'] == $__UserInfo['groupsiteid']){
                $editPowerStatus = 2;
            }
        }
    }
}
# check end

if($editPowerStatus == 0){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $course_cate_id     = isset($_GET['course_cate_id'])? intval($_GET['course_cate_id']):0;
    $class_type         = isset($_GET['class_type'])? intval($_GET['class_type']):0;
    $class_num          = isset($_GET['class_num'])? intval($_GET['class_num']):0;
    $xiangou_num        = intval($_GET['xiangou_num'])>0? intval($_GET['xiangou_num']):0;
    $hexiao_limit       = isset($_GET['hexiao_limit'])? intval($_GET['hexiao_limit']):0;
    $hexiao_days        = isset($_GET['hexiao_days'])? intval($_GET['hexiao_days']):0;
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = str_replace("T", " ", $hexiao_time);
    $hexiao_time        = strtotime($hexiao_time);
    $open_bm_end_time   = isset($_GET['open_bm_end_time'])? intval($_GET['open_bm_end_time']):0;
    $bm_end_time        = isset($_GET['bm_end_time'])? addslashes($_GET['bm_end_time']):'';
    $bm_end_time        = str_replace("T", " ", $bm_end_time);
    $bm_end_time        = strtotime($bm_end_time);
    $market_price       = floatval($_GET['market_price'])? floatval($_GET['market_price']):0.00;
    $buy_price          = floatval($_GET['buy_price'])? floatval($_GET['buy_price']):0.00;
    $open_vip           = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $vip_price          = floatval($_GET['vip_price'])? floatval($_GET['vip_price']):0.00;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $tabs_diy           = isset($_GET['tabs_diy'])? addslashes($_GET['tabs_diy']):'';
    
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    
    $teacherIdsArr = array();
    foreach($_GET['teacher'] as $key => $value){
        $value = intval($value);
        if(!empty($value)){
            $teacherIdsArr[] = $value;
        }
    }
    $teacherIdsStr = '';
    if(is_array($teacherIdsArr) && !empty($teacherIdsArr)){
        $teacherIdsStr = '|'.implode('|', $teacherIdsArr).'|';
    }
    $attrIdsArr = array();
    foreach($_GET['attr'] as $key => $value){
        $value = intval($value);
        if(!empty($value)){
            $attrIdsArr[] = $value;
        }
    }
    $attrIdsStr = '';
    if(is_array($attrIdsArr) && !empty($attrIdsArr)){
        $attrIdsStr = implode(',', $attrIdsArr);
    }
    
    $tabsArr = array();
    foreach($_GET['tabs'] as $key => $value){
        $value = addslashes($value);
        if(!empty($value)){
            $tabsArr[] = $value;
        }
    }
    
    if(!empty($tabs_diy)){
        $tabs_diy = trim($tabs_diy);
        $tabs_diy_arr = explode(" ", $tabs_diy);
        foreach($tabs_diy_arr as $key => $value){
            $value = trim($value);
            if(!empty($value)){
                $tabsArr[] = $value;
            }
        }
    }
    
    $cateInfo = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_by_id($cate_id);
    $cateChildInfo = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_by_id($cate_child_id);
    $courseCateInfo = C::t("#tom_tcedu#tom_tcedu_course_cate")->fetch_by_id($course_cate_id);
    
    $search_text = $name.'|'.$cateInfo['name'].'|'.$cateChildInfo['name'].'|'.$courseCateInfo['name'].'|'.$tceduInfo['name'].'|'.$tceduInfo['tel'].'|'.implode('|', $tabsArr);
    
    $updateData = array();
    $updateData['name']                 = $name;
    $updateData['cate_id']              = $cate_id;
    $updateData['cate_child_id']        = $cate_child_id;
    $updateData['course_cate_id']       = $course_cate_id;
    $updateData['hasoption']            = $hasoption;
    if($hasoption == 0){
        $updateData['show_market_price']    = $market_price;
        $updateData['show_buy_price']       = $buy_price;
        $updateData['show_vip_price']       = $vip_price;
    }
    $updateData['market_price']         = $market_price;
    $updateData['buy_price']            = $buy_price;
    $updateData['open_vip']             = $open_vip;
    $updateData['vip_price']            = $vip_price;
    $updateData['teacher_ids']          = $teacherIdsStr;
    $updateData['attr_ids']             = $attrIdsStr;
    $updateData['tabs']                 = implode('|', $tabsArr);
    $updateData['class_type']           = $class_type;
    $updateData['class_num']            = $class_num;
    $updateData['xiangou_num']          = $xiangou_num;
    $updateData['hexiao_limit']         = $hexiao_limit;
    $updateData['hexiao_days']          = $hexiao_days;
    $updateData['hexiao_time']          = $hexiao_time;
    $updateData['open_bm_end_time']     = $open_bm_end_time;
    $updateData['bm_end_time']          = $bm_end_time;
    if($courseInfo['admin_edit'] == 0){
        $updateData['content']              = $content;
    }
    $updateData['search_text']          = $search_text;
    if($tceduConfig['course_must_shenhe'] == 1 && $editPowerStatus == 1){
        $updateData['shenhe_status']        = 2;
    }
    $updateData['update_time']      = TIMESTAMP;
    C::t('#tom_tcedu#tom_tcedu_course')->update($course_id, $updateData);
    
    C::t('#tom_tcedu#tom_tcedu_photo')->delete_by_course_id($course_id);
    if(!empty($picurl)){
        $insertData = array();
        $insertData['tcedu_id']     = $tceduInfo['id'];
        $insertData['course_id']    = $course_id;
        $insertData['picurl']       = $picurl;
        $insertData['type']         = 4;
        $insertData['add_time']     = TIMESTAMP;
        C::t("#tom_tcedu#tom_tcedu_photo")->insert($insertData);
    }
    
    if($tceduConfig['course_must_shenhe'] == 1 && $editPowerStatus == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
        if($toUserTmp && !empty($toUserTmp['openid'])){
            $access_token = $weixinClass->get_access_token();
            
            if($access_token && !empty($toUserTmp['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=managerCourseList");
                $smsData = array(
                    'first'         => '['.$tceduInfo['name'].']'.lang('plugin/tom_tcedu', 'course_shenhe_template_edit'),
                    'keyword1'      => $tceduConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUserTmp['openid'],$tongchengConfig['template_id'],$smsData);
            }
        }
        
        if($tceduConfig['manage_user_id'] > 0){
            $tceduManageUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduConfig['manage_user_id']);
            if($tceduManageUserTmp && !empty($tceduManageUserTmp['openid'])){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($tceduManageUserTmp['openid'])  ){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=managerCourseList");
                    $smsData = array(
                        'first'         => '['.$tceduInfo['name'].']'.lang('plugin/tom_tcedu', 'course_shenhe_template_edit'),
                        'keyword1'      => $tceduConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                        'remark'        => ''
                    );
                    $r = $templateSmsClass->sendSms01($tceduManageUserTmp['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
}

$hexiao_time = '';
if($courseInfo['hexiao_time'] > 0){
    $hexiao_time = dgmdate($courseInfo['hexiao_time'],'Y-m-d H:i:s',$tomSysOffset);
    $hexiao_time = str_replace(" ", "T", $hexiao_time);
}

$bm_end_time = '';
if($courseInfo['bm_end_time'] > 0){
    $bm_end_time = dgmdate($courseInfo['bm_end_time'],'Y-m-d H:i:s',$tomSysOffset);
    $bm_end_time = str_replace(" ", "T", $bm_end_time);
}

$cate_ids = trim($tceduInfo['cate_ids'], '|');
$cateIdsArr = explode('|', $cate_ids);
$cateIdsStr = implode(',', $cateIdsArr);

$cate_child_ids = trim($tceduInfo['cate_child_ids'], '|');
$cateChildIdsArr = explode('|', $cate_child_ids);
$cateChildIdsStr = implode(',', $cateChildIdsArr);

$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" AND id IN ({$cateIdsStr}) ", 'ORDER BY csort ASC, id DESC');
$cateList = array();
$i = 0;
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach ($cateListTmp as $key => $value){
        $cateList[$i]['id'] = $value['id'];
        $cateList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        
        if($courseInfo['cate_id'] == $value['id']){
            $courseInfo['cate_name'] = $value['name'];
        }
        
        $cateChildListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" AND pid = {$value['id']} AND id IN ({$cateChildIdsStr}) ", 'ORDER BY csort ASC, id DESC');
        
        $j = 0;
        if(is_array($cateChildListTmp) && !empty($cateChildListTmp)){
            foreach ($cateChildListTmp as $kk => $vv){
                $cateList[$i]['sub'][$j]['id'] = $vv['id'];
                $cateList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                
                if($courseInfo['cate_child_id'] == $vv['id']){
                    $courseInfo['cate_child_name'] = $vv['name'];
                }
                
                $j++;
            }
        }
        $i++;
    }
}
$cateData = urlencode(json_encode($cateList));

$courseCateList = array();
$courseCateListTmp = C::t("#tom_tcedu#tom_tcedu_course_cate")->fetch_all_list(" AND tcedu_id = {$tceduInfo['id']} ", 'ORDER BY csort ASC, id DESC');
if(is_array($courseCateListTmp) && !empty($courseCateListTmp)){
    foreach ($courseCateListTmp as $key => $value){
        $courseCateList[$key] = $value;
    }
}

$courseInfo['teacher_ids'] = trim($courseInfo['teacher_ids'], '|');
$teacherIdsArr = explode('|', $courseInfo['teacher_ids']);
$teacherList = array();
$teacherListTmp = C::t("#tom_tcedu#tom_tcedu_teacher")->fetch_all_list(" AND tcedu_id = {$tceduInfo['id']} AND status = 1 ", 'ORDER BY tsort ASC, id DESC');
if(is_array($teacherListTmp) && !empty($teacherListTmp)){
    foreach ($teacherListTmp as $key => $value){
        $teacherList[$key] = $value;
        $teacherList[$key]['status'] = 0;
        if(in_array($value['id'], $teacherIdsArr)){
            $teacherList[$key]['status'] = 1;
        }
    }
}

$attrIdsArr = explode(',', $courseInfo['attr_ids']);
$attrListTmp = C::t("#tom_tcedu#tom_tcedu_attr")->fetch_all_list(" AND tcedu_id = {$tceduInfo['id']} AND is_show = 1 ", 'ORDER BY asort ASC, id DESC');
$attrList = array();
if(is_array($attrListTmp) && !empty($attrListTmp)){
    foreach ($attrListTmp as $key => $value){
        $attrList[$key] = $value;
        $attrList[$key]['status'] = 0;
        if(in_array($value['id'], $attrIdsArr)){
            $attrList[$key]['status'] = 1;
        }
    }
}

$courseTabsArr = array();
$course_tab_str = str_replace("\r\n","{n}",$tceduConfig['course_tab_list']); 
$course_tab_str = str_replace("\n","{n}",$course_tab_str);
$course_tab_arr = explode("{n}", $course_tab_str);
if(is_array($course_tab_arr) && !empty($course_tab_arr)){
    foreach ($course_tab_arr as $key => $value){
        $value = trim($value);

        if(!empty($value)){
            $courseTabsArr[] = $value;
        }
    }
}

$tabsArray = array();
if(!empty($courseInfo['tabs'])){
    $tabsArray = explode('|', $courseInfo['tabs']);
}
$tabsList = array();
foreach ($courseTabsArr as $key => $value){
    $tabsList[$key]['name'] = $value;
    $tabsList[$key]['status'] = 0;
    if(is_array($tabsArray) && !empty($tabsArray) && in_array($value, $tabsArray)){
        $tabsList[$key]['status'] = 1;
    }
}

$tabsArray = array_diff($tabsArray, $courseTabsArr);
$i = count($tabsList) + 1;
foreach ($tabsArray as $key => $value){
    $tabsList[$i]['name'] = $value;
    $tabsList[$i]['status'] = 1;
    $i++;
}

$photoInfoTmp = C::t("#tom_tcedu#tom_tcedu_photo")->fetch_all_list(" AND course_id = {$courseInfo['id']} AND type = 4 ", 'ORDER BY id DESC', 0, 1);
if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
    $courseInfo['picurl']       = $photoInfoTmp[0]['picurl'];
    $courseInfo['picurlTmp']    = $photoInfoTmp[0]['picurlTmp'];
}

$ossBatchUrl = 'plugin.php?id=tom_tcedu:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcedu:qiniuBatch';
$saveUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=courseedit&course_id={$course_id}";
$uploadUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tcedu:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:courseedit");