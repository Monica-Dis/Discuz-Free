<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';

$whereStr = " AND manage_user_id = {$__UserInfo['id']} ";

if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    $whereStr .= " AND search_text LIKE '%{$keyword}%' ";
}

$pagesize       = 8;
$start          = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcedu#tom_tcedu')->fetch_all_count($whereStr);
$tceduListTmp  = C::t('#tom_tcedu#tom_tcedu')->fetch_all_list($whereStr," ORDER BY id DESC ",$start,$pagesize);
$tceduList = array();
if(is_array($tceduListTmp) && !empty($tceduListTmp)){
    foreach ($tceduListTmp as $key => $value){
        $tceduList[$key] = $value;
        
        $picurlTmp = '';
        $photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(" AND tcedu_id = {$value['id']} AND type = 1 "," ORDER BY id DESC ",0,1);
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $vipInfoTmp = array();
        if($value['vip_id'] > 0){
            $vipInfoTmp = C::t("#tom_tcedu#tom_tcedu_vip")->fetch_by_id($value['vip_id']);
        }
        
        $tceduList[$key]['clicks']      = $value['clicks'] + $value['virtual_clicks'];
        $tceduList[$key]['tabsList']    = explode('|', $value['tabs']);
        $tceduList[$key]['picurl']      = $picurlTmp;
        $tceduList[$key]['vipInfo']     = $vipInfoTmp;
        $tceduList[$key]['expire_time'] = dgmdate($value['expire_time'],"Y-m-d H:i:s",$tomSysOffset);
        $tceduList[$key]['top_time']    = dgmdate($value['top_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mymanagelist&page={$prePage}&keyword={$keyword}";
$nextPageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mymanagelist&page={$nextPage}&keyword={$keyword}";

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tcedu:ajax&site={$site_id}&act=updateStatus&formhash={$formhash}";
$searchUrl = "plugin.php?id=tom_tcedu:ajax&site={$site_id}&act=get_mymanagelist_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:mymanagelist");