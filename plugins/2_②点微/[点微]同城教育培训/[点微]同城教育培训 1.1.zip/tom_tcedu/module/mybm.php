<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$course_id  = intval($_GET['course_id'])>0? intval($_GET['course_id']):0;
$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

$where = " AND user_id = {$__UserInfo['id']} AND pay_status != 3 ";

if($course_id > 0){
    $where .=" AND course_id = {$course_id} ";
}
if($type == 1){
    $where .=" AND pay_status IN(0, 2) AND use_status = 0 ";
}else if($type == 2){
    $where .=" AND pay_status IN(0, 2) AND use_status = 1 ";
}else if($type == 3){
    $where .=" AND pay_status = 1  ";
}else if($type == 4){
    $where .=" AND pay_status IN(0, 2) AND (use_status = 1 OR (use_status = 0 AND use_num > 0)) AND pinglun_status = 0 ";
}

$pagesize       = 8;
$start          = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_all_count($where);
$bmListTmp = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$bmList = array();
if(is_array($bmListTmp) && !empty($bmListTmp)){
    foreach ($bmListTmp as $key => $value){
        $bmList[$key] = $value;
        
        $courseInfoTmp = C::t('#tom_tcedu#tom_tcedu_course')->fetch_by_id($value['course_id']);
        
        $photoInfoTmp = C::t("#tom_tcedu#tom_tcedu_photo")->fetch_all_list(" AND course_id = {$courseInfoTmp['id']} AND type = 4 ", 'ORDER BY id DESC', 0, 1);
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $courseInfoTmp['picurl'] = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $hexiaoEndTimeTmp = '';
        if($courseInfoTmp['hexiao_limit'] > 0){
            $hexiaoEndTimeStamp = 0;
            if($courseInfoTmp['hexiao_limit'] == 1){
                $hexiaoEndTimeStamp = $courseInfoTmp['hexiao_days'] * 86400 + $value['add_time'];
                $hexiaoEndTimeTmp = dgmdate($hexiaoEndTimeStamp,"Y-m-d H:i",$tomSysOffset);
            }else if($courseInfoTmp['hexiao_limit'] == 2){
                $hexiaoEndTimeStamp = $courseInfoTmp['hexiao_time'];
                $hexiaoEndTimeTmp = dgmdate($courseInfoTmp['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
            }

            if($hexiaoEndTimeStamp < TIMESTAMP && $value['use_status'] == 0){
                $bmList[$key]['use_status'] = 2;
            }
        }
        
        $bmList[$key]['courseInfo']     = $courseInfoTmp;
        $bmList[$key]['hexiaoEndTime']  = $hexiaoEndTimeTmp;
        $bmList[$key]['add_time']       = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mybm&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mybm&type={$type}&page={$nextPage}";

$ajaxCancelBmUrl = "plugin.php?id=tom_tcedu:ajax&site={$site_id}&act=cancel_bm&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:mybm");