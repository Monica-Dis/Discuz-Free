<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword        = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$tabs           = isset($_GET['tabs'])? daddslashes(diconv(urldecode($_GET['tabs']),'utf-8')):'';
$tcedu_id       = intval($_GET['tcedu_id'])>0? intval($_GET['tcedu_id']):0;
$area_id        = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id      = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$cate_id        = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$cate_child_id  = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
$course_cate_id = intval($_GET['course_cate_id'])>0? intval($_GET['course_cate_id']):0;
$type           = intval($_GET['type'])>0? intval($_GET['type']):0;
$class_type     = intval($_GET['class_type'])>0? intval($_GET['class_type']):0;
$class_types    = isset($_GET['class_types'])? addslashes($_GET['class_types']):'';
$ordertype      = isset($_GET['ordertype'])? addslashes($_GET['ordertype']):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):15;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$where = ' AND status=1 AND shenhe_status=1 AND deleted = 0 ';
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}

if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND search_text LIKE '%{$keyword}%' ";
}
if(!empty($tabs)){
    $selectTabsArr = explode(',', $tabs);
    foreach ($selectTabsArr as $key => $value){
        $value = str_replace(array('%', '_'),'',$value);
        $where .= " AND tabs LIKE '%{$value}%' ";
    }
}
if(!empty($tcedu_id)){
    $where .= " AND tcedu_id={$tcedu_id} ";
}
if(!empty($course_cate_id)){
    $where .= " AND course_cate_id={$course_cate_id} ";
}
if(!empty($type)){
    $where .= " AND type={$type} ";
}
if(!empty($class_type)){
    $where .= " AND class_type={$class_type} ";
}
if(!empty($class_types)){
    $classTypesArr = explode(',', $class_types);
    $classTypesList = array();
    foreach($classTypesArr as $key => $value){
        $value = intval($value);
        if($value > 0){
            $classTypesList[] = $value;
        }
    }
    
    if(!empty($classTypesList)){
        $classTypesStr = implode(',', $classTypesList);
        $where .= " AND class_type IN({$classTypesStr}) ";
    }
}
if(!empty($area_id)){
    $where .= " AND area_id={$area_id} ";
}
if(!empty($street_id)){
    $where .= " AND street_id={$street_id} ";
}
if(!empty($cate_id)){
    $where .= " AND cate_id={$cate_id} ";
}
if(!empty($cate_child_id)){
    $where .= " AND cate_child_id={$cate_child_id} ";
}

if($ordertype == 'hot'){
    $orderStr = " ORDER BY clicks DESC ,id DESC ";
}else if($ordertype == 'price_asc'){
    $where .= " AND type = 2 ";
    $orderStr = " ORDER BY show_buy_price ASC ,id DESC ";
}else if($ordertype == 'price_desc'){
    $where .= " AND type = 2 ";
    $orderStr = " ORDER BY show_buy_price DESC ,id DESC ";
}else{
    $orderStr = " ORDER BY top_status DESC,id DESC ";
}

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;

if($ordertype == 'nearby'){
    $courseListTmp = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_list($where,$orderStr,$start,$pagesize,$latitude,$longitude);
}else{
    $courseListTmp = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_list($where,$orderStr,$start,$pagesize);
}
$courseList = array();
if(is_array($courseListTmp) && !empty($courseListTmp)){
    foreach ($courseListTmp as $key => $value) {
        $courseList[$key] = $value;
        
        $photoInfoTmp = C::t("#tom_tcedu#tom_tcedu_photo")->fetch_all_list(" AND course_id = {$value['id']} AND type = 4 ", 'ORDER BY id DESC', 0, 1);
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }

        $tabsArrTmp = array();
        if(!empty($value['tabs'])){
            $tabsArrTmp = explode('|', $value['tabs']);
        }
        
        $tceduInfoTmp = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($value['tcedu_id']);

        $juliTmp = 0;
        if(!empty($longitude) && !empty($latitude) && !empty($value['longitude']) && !empty($value['latitude'])){
            $juliTmp = tomGetDistance($longitude, $latitude, $value['longitude'], $value['latitude']);
        }
            
        $courseList[$key]['tceduInfo']      = $tceduInfoTmp;
        $courseList[$key]['juli']           = $juliTmp;
        $courseList[$key]['picurl']         = $picurlTmp;
        $courseList[$key]['tabsArr']        = $tabsArrTmp;
    }
}

if(is_array($courseList) && !empty($courseList)){
    foreach ($courseList as $key => $value){
        $outStr .= '<a class="course_item dislay-flex" href="plugin.php?id=tom_tcedu&site='.$site_id.'&mod=courseinfo&course_id='.$value['id'].'">';
            $outStr .= '<div class="course_pic">';
                $outStr .= '<img src="'.$value['picurl'].'">';
                if($value['type'] == 2){
                    $outStr .= '<span class="ty">'.lang('plugin/tom_tcedu', 'template_tyk').'</span>';
                }
            $outStr .= '</div>';
            $outStr .= '<div class="course_main flex">';
                if($value['top_status'] == 1){
                    $outStr .= '<div class="course_name"><span class="top">'.lang('plugin/tom_tcedu', 'template_list_top').'</span>'.$value['name'].'</div>';
                }else{
                    $outStr .= '<div class="course_name">'.$value['name'].'</div>';
                }
                $outStr .= '<div class="course_attr clearfix">';
                    $outStr .= '<span class="type">'.$classTypeArr[$value['class_type']].'</span>';
                    $outStr .= '<span class="type">'.lang('plugin/tom_tcedu', 'template_gong').$value['class_num'].lang('plugin/tom_tcedu', 'template_jie').'</span>';
                    if(is_array($value['tabsArr']) && !empty($value['tabsArr'])){
                        foreach($value['tabsArr'] as $k => $v){
                            $outStr .= '<span>'.$v.'&nbsp;</span>';
                        }
                    }
                $outStr .= '</div>';
                $outStr .= '<div class="course_price">';
                    if($value['show_buy_price'] > 0){
                        $outStr .= '<span class="buy_price">'.lang('plugin/tom_tcedu','yuan_ico').'<span>'.$value['show_buy_price'].'</span></span>';
                        //$outStr .= '<span class="old_price">'.lang('plugin/tom_tcedu','yuan_ico').$value['market_price'].'</span>';
                    }else{
                        $outStr .= '<span class="free">'.lang('plugin/tom_tcedu','template_free').'</span>';
                    }
                    if($tcedu_id == 0){
                        if($ordertype == 'nearby' && $value['juli'] > 0){
                            $outStr .= '<span class="edu_name">'.$value['tceduInfo']['name'].'&nbsp;&nbsp;'.$value['juli'] .'km</span>';
                        }else{
                            $outStr .= '<span class="edu_name">'.$value['tceduInfo']['name'].'</span>';
                        }
                    }
                $outStr .= '</div>';
                
            $outStr .= '</div>';
        $outStr .= '</a>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;