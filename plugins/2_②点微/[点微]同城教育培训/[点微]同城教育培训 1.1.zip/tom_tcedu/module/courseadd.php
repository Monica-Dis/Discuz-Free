<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcedu_id = intval($_GET['tcedu_id'])>0? intval($_GET['tcedu_id']):0;

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mycourselist");exit;
}

$vipInfo = array();
$showCourseStatus = $showExperienceCourseStatus = 0;
if($tceduInfo['vip_id'] > 0 && $tceduInfo['expire_status'] == 1 && $tceduInfo['expire_time'] >= TIMESTAMP){
    $vipInfo = C::t("#tom_tcedu#tom_tcedu_vip")->fetch_by_id($tceduInfo['vip_id']);
    
    $courseCount = C::t("#tom_tcedu#tom_tcedu_course")->fetch_all_count("AND tcedu_id = {$tceduInfo['id']} AND type = 1 AND deleted = 0 ");
    $syCourseCount = $vipInfo['course_num'] - $courseCount;
    if($syCourseCount > 0){
        $showCourseStatus = 1;
    }else{
        $syCourseCount = 0;
    }
    $vipInfo['syCourseCount'] = $syCourseCount;
    
    if($vipInfo['open_experience_course'] == 1){
        $experienceCourseCount = C::t("#tom_tcedu#tom_tcedu_course")->fetch_all_count("AND tcedu_id = {$tceduInfo['id']} AND type = 2 AND deleted = 0 ");
        $syExperienceCourseCount = $vipInfo['experience_course_num'] - $experienceCourseCount;
        if($syExperienceCourseCount > 0){
            $showExperienceCourseStatus = 1;
        }else{
            $syExperienceCourseCount = 0;
        }
        $vipInfo['syExperienceCourseCount'] = $syExperienceCourseCount;
    }
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $type               = isset($_GET['type'])? intval($_GET['type']):1;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $course_cate_id     = isset($_GET['course_cate_id'])? intval($_GET['course_cate_id']):0;
    $class_type         = isset($_GET['class_type'])? intval($_GET['class_type']):0;
    $class_num          = isset($_GET['class_num'])? intval($_GET['class_num']):0;
    $xiangou_num        = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $hexiao_limit       = isset($_GET['hexiao_limit'])? intval($_GET['hexiao_limit']):0;
    $hexiao_days        = isset($_GET['hexiao_days'])? intval($_GET['hexiao_days']):0;
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = str_replace("T", " ", $hexiao_time);
    $hexiao_time        = strtotime($hexiao_time);
    $open_bm_end_time   = isset($_GET['open_bm_end_time'])? intval($_GET['open_bm_end_time']):0;
    $bm_end_time        = isset($_GET['bm_end_time'])? addslashes($_GET['bm_end_time']):'';
    $bm_end_time        = str_replace("T", " ", $bm_end_time);
    $bm_end_time        = strtotime($bm_end_time);
    $market_price       = floatval($_GET['market_price'])? floatval($_GET['market_price']):0.00;
    $buy_price          = floatval($_GET['buy_price'])? floatval($_GET['buy_price']):0.00;
    $open_vip           = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $vip_price          = floatval($_GET['vip_price'])? floatval($_GET['vip_price']):0.00;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $tabs_diy           = isset($_GET['tabs_diy'])? addslashes($_GET['tabs_diy']):'';
    
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    
    if($tceduInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tceduInfo['vip_id'] > 0 && $tceduInfo['expire_status'] == 1 && $tceduInfo['expire_time'] >= TIMESTAMP){ }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($type == 1){
        if($vipInfo['syCourseCount'] <= 0){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
    }else if($type == 2){
        if($vipInfo['syExperienceCourseCount'] <= 0){
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $teacherIdsArr = array();
    foreach($_GET['teacher'] as $key => $value){
        $value = intval($value);
        if(!empty($value)){
            $teacherIdsArr[] = $value;
        }
    }
    $teacherIdsStr = '';
    if(is_array($teacherIdsArr) && !empty($teacherIdsArr)){
        $teacherIdsStr = '|'.implode('|', $teacherIdsArr).'|';
    }
    
    $attrIdsArr = array();
    foreach($_GET['attr'] as $key => $value){
        $value = intval($value);
        if(!empty($value)){
            $attrIdsArr[] = $value;
        }
    }
    $attrIdsStr = '';
    if(is_array($attrIdsArr) && !empty($attrIdsArr)){
        $attrIdsStr = implode(',', $attrIdsArr);
    }
    
    $tabsArr = array();
    foreach($_GET['tabs'] as $key => $value){
        $value = addslashes($value);
        if(!empty($value)){
            $tabsArr[] = $value;
        }
    }
    
    if(!empty($tabs_diy)){
        $tabs_diy = trim($tabs_diy);
        $tabs_diy_arr = explode(" ", $tabs_diy);
        foreach($tabs_diy_arr as $key => $value){
            $value = trim($value);
            if(!empty($value)){
                $tabsArr[] = $value;
            }
        }
    }
    
    $cateInfo = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_by_id($cate_id);
    $cateChildInfo = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_by_id($cate_child_id);
    $courseCateInfo = C::t("#tom_tcedu#tom_tcedu_course_cate")->fetch_by_id($course_cate_id);
    
    $search_text = $name.'|'.$cateInfo['name'].'|'.$cateChildInfo['name'].'|'.$courseCateInfo['name'].'|'.$tceduInfo['name'].'|'.$tceduInfo['tel'].'|'.implode('|', $tabsArr);
    
    $insertData = array();
    $insertData['site_id']              = $tceduInfo['site_id'];
    $insertData['tcedu_id']             = $tceduInfo['id'];
    $insertData['area_id']              = $tceduInfo['area_id'];
    $insertData['street_id']            = $tceduInfo['street_id'];
    $insertData['latitude']             = $tceduInfo['latitude'];
    $insertData['longitude']            = $tceduInfo['longitude'];
    $insertData['name']                 = $name;
    $insertData['type']                 = $type;
    $insertData['cate_id']              = $cate_id;
    $insertData['cate_child_id']        = $cate_child_id;
    $insertData['course_cate_id']       = $course_cate_id;
    $insertData['hasoption']            = $hasoption;
    if($hasoption == 0){
        $insertData['show_market_price']    = $market_price;
        $insertData['show_buy_price']       = $buy_price;
        $insertData['show_vip_price']       = $vip_price;
    }
    $insertData['market_price']         = $market_price;
    $insertData['buy_price']            = $buy_price;
    $insertData['open_vip']             = $open_vip;
    $insertData['vip_price']            = $vip_price;
    $insertData['teacher_ids']          = $teacherIdsStr;
    $insertData['attr_ids']             = $attrIdsStr;
    $insertData['tabs']                 = implode('|', $tabsArr);
    $insertData['class_type']           = $class_type;
    $insertData['class_num']            = $class_num;
    $insertData['xiangou_num']          = $xiangou_num;
    $insertData['hexiao_limit']         = $hexiao_limit;
    $insertData['hexiao_days']          = $hexiao_days;
    $insertData['hexiao_time']          = $hexiao_time;
    $insertData['open_bm_end_time']     = $open_bm_end_time;
    $insertData['bm_end_time']          = $bm_end_time;
    $insertData['haibao_type']          = 1;
    $insertData['admin_edit']           = 0;
    $insertData['content']              = $content;
    $insertData['search_text']          = $search_text;
    if($tceduConfig['course_must_shenhe'] == 1){
        $insertData['shenhe_status']        = 2;
    }else{
        $insertData['shenhe_status']        = 1;
    }
    $insertData['status']               = 0;
    $insertData['add_time']             = TIMESTAMP;
    $insertData['update_time']          = TIMESTAMP;
    $course_id = C::t('#tom_tcedu#tom_tcedu_course')->insert($insertData, true);
    if($course_id > 0){
        
        if(!empty($picurl)){
            $insertData = array();
            $insertData['tcedu_id']     = $tceduInfo['id'];
            $insertData['course_id']    = $course_id;
            $insertData['picurl']       = $picurl;
            $insertData['type']         = 4;
            $insertData['add_time']     = TIMESTAMP;
            C::t("#tom_tcedu#tom_tcedu_photo")->insert($insertData);
        }
        
        if($tceduConfig['course_must_shenhe'] == 1){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $access_token = $weixinClass->get_access_token();

                if($access_token && !empty($toUserTmp['openid'])  ){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=managerCourseList");
                    $smsData = array(
                        'first'         => '['.$tceduInfo['name'].']'.lang('plugin/tom_tcedu', 'course_shenhe_template_first'),
                        'keyword1'      => $tceduConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                        'remark'        => ''
                    );
                    $r = $templateSmsClass->sendSms01($toUserTmp['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
            
            if($tceduConfig['manage_user_id']){
                $tceduManageUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduConfig['manage_user_id']);
                if($tceduManageUserTmp && !empty($tceduManageUserTmp['openid'])){
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($tceduManageUserTmp['openid'])  ){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=managerCourseList");
                        $smsData = array(
                            'first'         => '['.$tceduInfo['name'].']'.lang('plugin/tom_tcedu', 'course_shenhe_template_first'),
                            'keyword1'      => $tceduConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                            'remark'        => ''
                        );
                        $r = $templateSmsClass->sendSms01($tceduManageUserTmp['openid'],$tongchengConfig['template_id'],$smsData);
                    }
                }
            }
        }
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$cate_ids = trim($tceduInfo['cate_ids'], '|');
$cateIdsArr = explode('|', $cate_ids);
$cateIdsStr = implode(',', $cateIdsArr);

$cate_child_ids = trim($tceduInfo['cate_child_ids'], '|');
$cateChildIdsArr = explode('|', $cate_child_ids);
$cateChildIdsStr = implode(',', $cateChildIdsArr);

$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" AND id IN ({$cateIdsStr}) ", 'ORDER BY csort ASC, id DESC');
$cateList = array();
$i = 0;
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach ($cateListTmp as $key => $value){
        $cateList[$i]['id'] = $value['id'];
        $cateList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $cateChildListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" AND pid = {$value['id']} AND id IN ({$cateChildIdsStr}) ", 'ORDER BY csort ASC, id DESC');
        
        $j = 0;
        if(is_array($cateChildListTmp) && !empty($cateChildListTmp)){
            foreach ($cateChildListTmp as $kk => $vv){
                $cateList[$i]['sub'][$j]['id'] = $vv['id'];
                $cateList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cateData = urlencode(json_encode($cateList));

$courseCateListTmp = C::t("#tom_tcedu#tom_tcedu_course_cate")->fetch_all_list(" AND tcedu_id = {$tceduInfo['id']} ", 'ORDER BY csort ASC, id DESC');
$courseCateList = array();
if(is_array($courseCateListTmp) && !empty($courseCateListTmp)){
    foreach ($courseCateListTmp as $key => $value){
        $courseCateList[$key] = $value;
    }
}

$teacherListTmp = C::t("#tom_tcedu#tom_tcedu_teacher")->fetch_all_list(" AND tcedu_id = {$tceduInfo['id']} AND status = 1 ", 'ORDER BY tsort ASC, id DESC');
$teacherList = array();
if(is_array($teacherListTmp) && !empty($teacherListTmp)){
    foreach ($teacherListTmp as $key => $value){
        $teacherList[$key] = $value;
    }
}

$attrListTmp = C::t("#tom_tcedu#tom_tcedu_attr")->fetch_all_list(" AND tcedu_id = {$tceduInfo['id']} AND is_show = 1 ", 'ORDER BY asort ASC, id DESC');
$attrList = array();
if(is_array($attrListTmp) && !empty($attrListTmp)){
    foreach ($attrListTmp as $key => $value){
        $attrList[$key] = $value;
    }
}

$courseTabsArr = array();
$course_tab_str = str_replace("\r\n","{n}",$tceduConfig['course_tab_list']); 
$course_tab_str = str_replace("\n","{n}",$course_tab_str);
$course_tab_arr = explode("{n}", $course_tab_str);
if(is_array($course_tab_arr) && !empty($course_tab_arr)){
    foreach ($course_tab_arr as $key => $value){
        $value = trim($value);

        if(!empty($value)){
            $courseTabsArr[] = $value;
        }
    }
}

$ossBatchUrl = 'plugin.php?id=tom_tcedu:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcedu:qiniuBatch';
$saveUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=courseadd&tcedu_id={$tceduInfo['id']}";
$uploadUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tcedu:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:courseadd");