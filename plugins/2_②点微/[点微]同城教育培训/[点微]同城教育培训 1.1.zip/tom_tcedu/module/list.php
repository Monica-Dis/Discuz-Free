<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword        = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$tabs           = isset($_GET['tabs'])? daddslashes(diconv(urldecode($_GET['tabs']),'utf-8')):'';
$cate_id        = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$cate_child_id  = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
$area_id        = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id      = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$ordertype      = isset($_GET['ordertype'])? addslashes($_GET['ordertype']):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$where = ' AND status=1 AND shenhe_status=1 AND expire_status = 1 AND is_ok = 1 ';
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND search_text LIKE '%{$keyword}%' ";
}
if(!empty($tabs)){
    $selectTabsArr = explode(',', $tabs);
    foreach ($selectTabsArr as $key => $value){
        $value = str_replace(array('%', '_'),'',$value);
        $where .= " AND tabs LIKE '%{$value}%' ";
    }
}
if($cate_id > 0){
    $where .= " AND cate_ids LIKE '%|{$cate_id}|%' ";
}
if($cate_child_id > 0){
    $where .= " AND cate_child_ids LIKE '%|{$cate_child_id}|%' ";
}
if($area_id > 0){
    $where .= " AND area_id = {$area_id} ";
}
if($street_id > 0){
    $where .= " AND street_id = {$street_id} ";
}

if($ordertype == 'hot'){
    $orderStr = " ORDER BY renqi DESC,id DESC ";
}else{
    $orderStr = " ORDER BY top_status DESC,top_rand DESC,vip_rank DESC,id DESC ";
}

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
if($ordertype == 'nearby'){
    $tceduListTmp  = C::t('#tom_tcedu#tom_tcedu')->fetch_all_list($where,$orderStr,$start,$pagesize,$latitude,$longitude);
}else{
    $tceduListTmp = C::t('#tom_tcedu#tom_tcedu')->fetch_all_list($where,$orderStr,$start,$pagesize);
}
$tceduList = array();
if(is_array($tceduListTmp) && !empty($tceduListTmp)){
    foreach ($tceduListTmp as $key => $value) {
        $tceduList[$key] = $value;
        
        $picurlTmp = '';
        $photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(" AND tcedu_id = {$value['id']} AND type = 1 "," ORDER BY id DESC ",0,1);
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $courseInfoTmp = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_list(" AND tcedu_id = {$value['id']} AND type = 1 AND status = 1 AND shenhe_status = 1 AND deleted = 0 "," ORDER BY clicks DESC,id DESC ",0,1);
        $tyCourseInfoTmp = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_list(" AND tcedu_id = {$value['id']} AND type = 2 AND status = 1 AND shenhe_status = 1 AND deleted = 0 "," ORDER BY clicks DESC,id DESC ",0,1);
        
        $phbInfoTmp = array();
        if($cate_id > 0 && $cate_child_id > 0){
            $phbInfoTmpTmp = C::t("#tom_tcedu#tom_tcedu_phb")->fetch_all_list(" AND tcedu_id = {$value['id']} AND status = 1 AND cate_id = {$cate_id} AND cate_child_id = {$cate_child_id} ", 'ORDER BY id DESC', 0, 1);
            if(is_array($phbInfoTmpTmp) && !empty($phbInfoTmpTmp[0])){
                $phbInfoTmp = $phbInfoTmpTmp[0];
            }
        }
        if(empty($phbInfoTmp) && $cate_id > 0){
            $phbInfoTmpTmp = C::t("#tom_tcedu#tom_tcedu_phb")->fetch_all_list(" AND tcedu_id = {$value['id']} AND status = 1 AND cate_id = {$cate_id} ", 'ORDER BY id DESC', 0, 1);
            if(is_array($phbInfoTmpTmp) && !empty($phbInfoTmpTmp[0])){
                $phbInfoTmp = $phbInfoTmpTmp[0];
            }
        }
        if(empty($phbInfoTmp)){
            $phbInfoTmpTmp = C::t("#tom_tcedu#tom_tcedu_phb")->fetch_all_list(" AND tcedu_id = {$value['id']} AND status = 1 ", 'ORDER BY ranking ASC,id DESC', 0, 1);
            if(is_array($phbInfoTmpTmp) && !empty($phbInfoTmpTmp[0])){
                $phbInfoTmp = $phbInfoTmpTmp[0];
            }
        }
        if(!empty($phbInfoTmp)){
            $phbCateInfoTmp = C::t("#tom_tcedu#tom_tcedu_phb_cate")->fetch_by_id($phbInfoTmp['phb_cate_id']);
            $phbInfoTmp['phbCateInfo'] = $phbCateInfoTmp;
        }
        
        $juliTmp = 0;
        if($ordertype == 'nearby' && !empty($longitude) && !empty($latitude) && !empty($value['longitude']) && !empty($value['latitude'])){
            $juliTmp = tomGetDistance($longitude, $latitude, $value['longitude'], $value['latitude']);
        }
        
        $tceduList[$key]['total_bili']      = $value['total_score'] / 5 * 100;
        $tceduList[$key]['total_score']     = sprintf("%.1f", round($value['total_score'], 1));
        $tceduList[$key]['tabsList']        = explode('|', $value['tabs']);
        $tceduList[$key]['picurl']          = $picurlTmp;
        $tceduList[$key]['courseInfo']      = $courseInfoTmp[0];
        $tceduList[$key]['tyCourseInfo']    = $tyCourseInfoTmp[0];
        $tceduList[$key]['phbInfo']         = $phbInfoTmp;
        $tceduList[$key]['juli']            = $juliTmp;
    }
}

if(is_array($tceduList) && !empty($tceduList)){
    foreach ($tceduList as $key => $val){
        $outStr .= '<div class="edu_item dislay-flex">';
            $outStr .= '<a class="edu_pic" href="plugin.php?id=tom_tcedu&site='.$site_id.'&mod=info&tcedu_id='.$val['id'].'">';
                $outStr .= '<img src="'.$val['picurl'].'">';
            $outStr .= '</a>';
            $outStr .= '<div class="edu_main flex">';
                $outStr .= '<a href="plugin.php?id=tom_tcedu&site='.$site_id.'&mod=info&tcedu_id='.$val['id'].'">';
                    if($val['top_status'] == 1){
                        $outStr .= '<div class="edu_name"><span class="top">'.lang('plugin/tom_tcedu', 'template_list_top').'</span>'.$val['name'].'</div>';
                    }else{
                        $outStr .= '<div class="edu_name">'.$val['name'].'</div>';
                    }
                    $outStr .= '<div class="edu_info">';
                        $outStr .= '<span class="ping_socre">';
                            $outStr .= '<span class="socre socre_bg"><i class="tciconfont tcicon-grade0"></i><i class="tciconfont tcicon-grade0"></i><i class="tciconfont tcicon-grade0"></i><i class="tciconfont tcicon-grade0"></i><i class="tciconfont tcicon-grade0"></i></span>';
                            $outStr .= '<span class="socre socre_fill" style="width:'.$val['total_bili'].'%;"><i class="tciconfont tcicon-grade1"></i><i class="tciconfont tcicon-grade1"></i><i class="tciconfont tcicon-grade1"></i><i class="tciconfont tcicon-grade1"></i><i class="tciconfont tcicon-grade1"></i></span>';
                        $outStr .= '</span>';
                        $outStr .= '&nbsp;&nbsp;<span class="socre_num">'.$val['total_score'].'</span>';
                    $outStr .= '</div>';
                    $outStr .= '<div class="edu_address dislay-flex">';
                        $outStr .= '<span class="course_name flex"><i class="tciconfont tcicon-dingwei2"></i>'.$val['address'].'</span>';
                        if($ordertype == 'nearby' && $val['juli'] > 0){
                            $outStr .= '<span class="juli">'.$val['juli'] .'km</span>';
                        }
                    $outStr .= '</div>';
                    if(is_array($val['tabsList']) && !empty($val['tabsList'])){
                        $outStr .= '<div class="edu_tabs clearfix">';
                            foreach ($val['tabsList'] as $k => $v){
                                $outStr .= '<span class="tab">'.$v.'</span>';
                            }
                        $outStr .= '</div>';
                    }
                $outStr .= '</a>';
                if($val['phbInfo'] || $val['tyCourseInfo'] || $val['courseInfo']){
                    $outStr .= '<div class="line"></div>';
                }
                if($val['phbInfo']){
                    $outStr .= '<a class="edu_phb" href="plugin.php?id=tom_tcedu&site='.$site_id.'&mod=phbinfo&phb_cate_id='.$val['phbInfo']['phb_cate_id'].'"><span class="course_icon course_icon_ph">'.lang('plugin/tom_tcedu', 'template_list_course_phb').'</span>'.$val['phbInfo']['phbCateInfo']['name'].lang('plugin/tom_tcedu', 'template_list_phb_1').$val['phbInfo']['ranking'].lang('plugin/tom_tcedu', 'template_list_phb_2').'<i class="tciconfont tcicon-jiantou__you"></i></a>';
                }
                if($val['tyCourseInfo']){
                    $outStr .= '<a class="edu_phb" href="plugin.php?id=tom_tcedu&site='.$site_id.'&mod=courseinfo&course_id='.$val['tyCourseInfo']['id'].'"><span class="course_icon course_icon_ty">'.lang('plugin/tom_tcedu', 'template_list_course_ty').'</span>'.$val['tyCourseInfo']['name'].'<i class="tciconfont tcicon-jiantou__you"></i></a>';
                }
                if($val['courseInfo']){
                    $outStr .= '<a class="edu_phb" href="plugin.php?id=tom_tcedu&site='.$site_id.'&mod=courseinfo&course_id='.$val['courseInfo']['id'].'"><span class="course_icon">'.lang('plugin/tom_tcedu', 'template_list_course_pu').'</span>'.$val['courseInfo']['name'].'<i class="tciconfont tcicon-jiantou__you"></i></a>';
                }
            $outStr .= '</div>';
        $outStr .= '</div>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;