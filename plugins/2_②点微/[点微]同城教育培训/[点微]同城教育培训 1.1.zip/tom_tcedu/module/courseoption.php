<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$course_id = intval($_GET['course_id'])>0? intval($_GET['course_id']):0;

$courseInfo = C::t('#tom_tcedu#tom_tcedu_course')->fetch_by_id($course_id);
$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($courseInfo['tcedu_id']);

if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

$act = isset($_GET['act'])? addslashes($_GET['act']):'';
if($act == 'remove_option' && $_GET['formhash'] == FORMHASH){
    
    $option_id = intval($_GET['option_id'])>0? intval($_GET['option_id']): 0;
    
    C::t("#tom_tcedu#tom_tcedu_course_option")->delete_by_id($option_id);
    
    $optionListTmp = C::t("#tom_tcedu#tom_tcedu_course_option")->fetch_all_list(" AND course_id = {$course_id} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_market_price = $show_buy_price = $show_vip_price = 0;
        foreach($optionListTmp as $key => $value){
            if($show_buy_price == 0){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
                $show_vip_price     = $value['vip_price'];
            }else if($value['buy_price'] < $show_buy_price){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
                $show_vip_price     = $value['vip_price'];
            }
        }
        if($show_buy_price > 0){
            $updateData = array();
            $updateData['show_market_price']    = $show_market_price;
            $updateData['show_buy_price']       = $show_buy_price;
            $updateData['show_vip_price']       = $show_vip_price;
            $updateData['update_time']          = TIMESTAMP;
            C::t("#tom_tcedu#tom_tcedu_course")->update($course_id,$updateData);
        }
    }
    
    echo 1;exit;

}else if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $option_id          = intval($_GET['option_id'])> 0? intval($_GET['option_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):"";
    $market_price       = floatval($_GET['market_price'])> 0? floatval($_GET['market_price']):0.00;
    $buy_price          = floatval($_GET['buy_price'])> 0? floatval($_GET['buy_price']):0.00;
    $vip_price          = floatval($_GET['vip_price'])> 0? floatval($_GET['vip_price']):0.00;
    $class_num          = intval($_GET['class_num'])> 0? intval($_GET['class_num']):0;
    $osort              = intval($_GET['osort'])> 0? intval($_GET['osort']):0;
    
    if($option_id > 0){
        $optionInfo = C::t('#tom_tcedu#tom_tcedu_course_option')->fetch_by_id($option_id);
        
        $updateData = array();
        $updateData['name']                 = $name;
        $updateData['market_price']         = $market_price;
        $updateData['buy_price']            = $buy_price;
        $updateData['vip_price']            = $vip_price;
        $updateData['class_num']            = $class_num;
        $updateData['osort']                = $osort;
        $updateData['part1']                = TIMESTAMP;
        C::t('#tom_tcedu#tom_tcedu_course_option')->update($option_id,$updateData);
    }else{
        $insertData = array();
        $insertData['course_id']            = $course_id;
        $insertData['tcedu_id']             = $tceduInfo['id'];
        $insertData['name']                 = $name;
        $insertData['market_price']         = $market_price;
        $insertData['buy_price']            = $buy_price;
        $insertData['vip_price']            = $vip_price;
        $insertData['class_num']            = $class_num;
        $insertData['osort']                = $osort;
        $insertData['add_time']             = TIMESTAMP;
        C::t('#tom_tcedu#tom_tcedu_course_option')->insert($insertData);
        $option_id = C::t('#tom_tcedu#tom_tcedu_course_option')->insert_id();
    }
    
    $optionListTmp = C::t("#tom_tcedu#tom_tcedu_course_option")->fetch_all_list(" AND course_id = {$course_id} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_market_price = $show_buy_price = $show_vip_price = 0;
        foreach($optionListTmp as $key => $value){
            if($show_buy_price == 0){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
                $show_vip_price     = $value['vip_price'];
            }else if($value['buy_price'] < $show_buy_price){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
                $show_vip_price     = $value['vip_price'];
            }
        }
        if($show_buy_price > 0){
            $updateData = array();
            $updateData['show_market_price']    = $show_market_price;
            $updateData['show_buy_price']       = $show_buy_price;
            $updateData['show_vip_price']       = $show_vip_price;
            $updateData['update_time']          = TIMESTAMP;
            C::t("#tom_tcedu#tom_tcedu_course")->update($course_id,$updateData);
        }
    }
    
    $outArr = array(
        'status'=> 200,
        'option_id'=> $option_id,
    );
    echo json_encode($outArr); exit;

}

$optionListTmp = C::t('#tom_tcedu#tom_tcedu_course_option')->fetch_all_list(" AND course_id = {$course_id}", 'ORDER BY osort ASC,id ASC', 0, 100);
$optionList = array();
if(is_array($optionListTmp) && !empty($optionListTmp)){
    foreach($optionListTmp as $key => $value){
        $optionList[$key] = $value;
    }
}

$saveUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=courseoption&course_id={$course_id}&act=save&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:courseoption");