<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$s              = intval($_GET['s'])>0? intval($_GET['s']):0;
$phb_cate_id    = intval($_GET['phb_cate_id'])>0? intval($_GET['phb_cate_id']):0;

$phbCateInfo = C::t('#tom_tcedu#tom_tcedu_phb_cate')->fetch_by_id($phb_cate_id);
if($phbCateInfo['id'] > 0 && $phbCateInfo['status'] == 1){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=index");exit;
}

if(!preg_match('/^http/', $phbCateInfo['picurl']) ){
    if(strpos($phbCateInfo['picurl'], 'source/plugin/tom_') === false){
        $phbCateInfo['picurlTmp'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$phbCateInfo['picurl'];
    }else{
        $phbCateInfo['picurlTmp'] = $_G['siteurl'].$phbCateInfo['picurl'];
    }
}else{
    $phbCateInfo['picurlTmp'] = $phbCateInfo['picurl'];
}

if($phbCateInfo['type'] == 2 && $phbCateInfo['update_time'] < $nowDayTime){
    auto_update_phb($phbCateInfo['id']);
}

$phbListTmp = C::t('#tom_tcedu#tom_tcedu_phb')->fetch_all_list(" AND phb_cate_id = {$phb_cate_id}  ", 'ORDER BY ranking ASC, id DESC', 0, 50);
$phbList = array();
if(is_array($phbListTmp) && !empty($phbListTmp)){
    foreach($phbListTmp as $key => $value){
        $phbList[$key] = $value;
        
        $tceduInfoTmp = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($value['tcedu_id']);
        
        $photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(" AND tcedu_id = {$value['tcedu_id']} AND type = 1 "," ORDER BY id DESC ",0,1);
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $tceduInfoTmp['picurl'] = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $tceduInfoTmp['total_bili']     = $tceduInfoTmp['total_score'] / 5 * 100;
        $tceduInfoTmp['total_score']    = sprintf("%.1f", round($tceduInfoTmp['total_score'], 1));
        
        $phbList[$key]['tceduInfo'] = $tceduInfoTmp;
    }
}

$shareTitle = $phbCateInfo['name'];
if(!empty($phbCateInfo['picurl'])){
    $shareLogo = $phbCateInfo['picurlTmp'];
}
$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=phbinfo&phb_cate_id={$phb_cate_id}&s=1";
if($__TjShowStatus == 1){
    $shareUrl = $shareUrl."&tjid={$tchehuorenInfo['id']}";
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:phbinfo");