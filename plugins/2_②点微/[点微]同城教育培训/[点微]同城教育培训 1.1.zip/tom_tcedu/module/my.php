<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$bmCount = C::t("#tom_tcedu#tom_tcedu_course_bm")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND pay_status IN(0,2) ");
$bmCount1 = C::t("#tom_tcedu#tom_tcedu_course_bm")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND pay_status IN(0,2) AND use_status = 0 ");
$bmCount3 = C::t("#tom_tcedu#tom_tcedu_course_bm")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND pay_status = 1 ");
$bmCount4 = C::t("#tom_tcedu#tom_tcedu_course_bm")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND pay_status IN(0,2) AND use_status = 1 AND pinglun_status = 0 ");

$tceduGuanzuCount = C::t("#tom_tcedu#tom_tcedu_guanzu")->fetch_all_count(" AND user_id = {$__UserInfo['id']} ");
$courseCollectCount = C::t("#tom_tcedu#tom_tcedu_course_collect")->fetch_all_count(" AND user_id = {$__UserInfo['id']} ");

$tceduCount = C::t("#tom_tcedu#tom_tcedu")->fetch_all_count(" AND user_id = {$__UserInfo['id']} ");
$tceduManageCount = C::t("#tom_tcedu#tom_tcedu")->fetch_all_count(" AND manage_user_id = {$__UserInfo['id']} ");

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=my";
if($__TjShowStatus == 1){
    $shareUrl = $shareUrl."&tjid={$tchehuorenInfo['id']}";
}

if($__CardInfo['status'] == 1){
    $cardTypeInfo = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($__CardInfo['card_type_id']);
    if(!preg_match('/^http/', $cardTypeInfo['picurl']) ){
        if(strpos($cardTypeInfo['picurl'], 'source/plugin/tom_') === FALSE){
            $cardTypeInfo['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$cardTypeInfo['picurl'];
        }
    }
    
    $__CardInfo['expireTime'] = dgmdate($__CardInfo['expire_time'],"Y/m/d",$tomSysOffset);
}

$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
if($__SitesInfo['id'] > 1){
    if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])){
        if(strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_tongcheng/') === FALSE){
            $kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
        }else{
            $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
        }
    }else{
        $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
    }
}

$tceduConfig['kefu_qrcode'] = trim($tceduConfig['kefu_qrcode']);
if(!empty($tceduConfig['kefu_qrcode'])){
    $kefuQrcodeSrc = $tceduConfig['kefu_qrcode'];
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:my");