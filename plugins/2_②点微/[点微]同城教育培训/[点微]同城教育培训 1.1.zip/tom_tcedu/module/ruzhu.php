<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" AND status = 1 "," ORDER BY csort ASC,id DESC ");
$cateList = $cateChildList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach ($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][] = $value;
        }else{
            $cateList[$key] = $value;
        }
    }
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$cityList = array();
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$eduTabsArr = array();
$edu_tab_str = str_replace("\r\n","{n}",$tceduConfig['edu_tab_list']); 
$edu_tab_str = str_replace("\n","{n}",$edu_tab_str);
$edu_tab_arr = explode("{n}", $edu_tab_str);
if(is_array($edu_tab_arr) && !empty($edu_tab_arr)){
    foreach ($edu_tab_arr as $key => $value){
        $value = trim($value);

        if(!empty($value)){
            $eduTabsArr[] = $value;
        }
    }
}

$score_yuan = $tongchengConfig['score_yuan'];
if($tceduConfig['score_yuan'] > 0){
    $score_yuan = $tceduConfig['score_yuan'];
}

$vipListTmp = C::t("#tom_tcedu#tom_tcedu_vip")->fetch_all_list(" AND status = 1 ", 'ORDER BY vsort ASC, id DESC');
$vipList = $vipArr = array();
$hasfreeVip = 0;
if(is_array($vipListTmp) && !empty($vipListTmp)){
    foreach($vipListTmp as $key => $value){
        
        if($value['xiangou_num'] > 0){
            $vipLogCount = C::t("#tom_tcedu#tom_tcedu_vip_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND vip_id = {$value['id']} AND type = 1 ");
            if($vipLogCount >= $value['xiangou_num']){
                continue;
            }
        }
        
        if($value['open_experience_course'] == 0){
            $value['experience_course_num'] = 0;
        }
        
        if(!preg_match('/^http/', $value['logo']) ){
            if(strpos($value['logo'], 'source/plugin/tom_') === FALSE){
                $logoTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['logo'];
            }else{
                $logoTmp = $value['logo'];
            }
        }else{
            $logoTmp = $value['logo'];
        }
        
        $scoreTmp = $value['price'] * $score_yuan;
        if($scoreTmp < 1){
            $scoreTmp = 0;
        }
        
        if($value['price'] == 0){
            $hasfreeVip = 1;
        }
        
        if($__IsMiniprogram == 1 && $__Ios == 1  && $tceduConfig['closed_ios_pay'] == 1 && $value['price'] > 0){ }else{
            $vipList[$key] = $value;
            $vipArr[] = $value;
            
            $vipList[$key]['price']     = floatval($value['price']);
            $vipList[$key]['logo']      = $logoTmp;
            $vipList[$key]['score']     = $scoreTmp;
        }
    }
}
$vipCount = count($vipArr);

$columnArr = array(
    0 => 'open_video',
    1 => 'open_experience_course',
    2 => 'experience_course_num',
    3 => 'course_num',
    4 => 'vip_rank',
    5 => 'yongjin_bili',
);

$vipTequanList = array();
if(is_array($vipArr) && !empty($vipArr)){
    $viplength = count($vipArr);
    $columnlength = count($columnArr);
    for ($i = 0; $i < $columnlength; $i++) {
        $value = array();
        for ($j = 0; $j < $viplength; $j++) {
            $value[] = $vipArr[$j][$columnArr[$i]];
        }
        $vipTequanList[$columnArr[$i]] = $value;
    }
}

$commonInfo = C::t('#tom_tcedu#tom_tcedu_common')->fetch_by_site_id(1);
if(!$commonInfo){
    $insertData = array();
    $insertData['site_id'] = 1;
    C::t('#tom_tcedu#tom_tcedu_common')->insert($insertData);
}
$commonInfo['xieyi_txt'] = stripslashes($commonInfo['xieyi_txt']);

$showMustPhoneBtn = 0;
if($tceduConfig['must_tel'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$back_url}";
}

$backUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist";
$ajaxVipCodeUrl = "plugin.php?id=tom_tcedu:ajax&site={$site_id}&act=vip_code&formhash=".FORMHASH;
$payUrl = "plugin.php?id=tom_tcedu:pay&site={$site_id}";
$ossBatchUrl = 'plugin.php?id=tom_tcedu:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcedu:qiniuBatch';
$uploadUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tcedu:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:ruzhu");