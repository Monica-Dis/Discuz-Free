<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcadmin start
$__ShowTcadmin = 0;
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
    if($tcadminConfig['open_fc'] == 1){
        $__ShowTcadmin = 1;
    }
}
## tcadmin end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

$orderInfo = C::t("#tom_tcedu#tom_tcedu_order")->fetch_by_order_no($bmInfo['order_no']);
$courseInfoTmp = C::t('#tom_tcedu#tom_tcedu_course')->fetch_by_id($bmInfo['course_id']);
$tceduInfoTmp = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($bmInfo['tcedu_id']);
$tceduUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduInfoTmp['user_id']);
$vipInfoTmp = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_by_id($tceduInfoTmp['vip_id']);
$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);

if($orderInfo['pay_price'] >= 0.1){
    
    $yongjin_bili = $tceduConfig['yongjin_bili'];
    if($vipInfoTmp['yongjin_bili'] > 0){
        $yongjin_bili = $vipInfoTmp['yongjin_bili'];
    }
    $pt_money = $orderInfo['pay_price'] * ($yongjin_bili/100);
    $pt_money = number_format($pt_money,2, '.', '');
    
    $edu_fc_money = $orderInfo['pay_price'] - $pt_money;
    if($edu_fc_money >= 0.1){
        if($__ShowTchehuoren == 1 && $orderInfo['tj_hehuoren_id'] > 0 && $courseInfoTmp['hehuoren_tg_open'] == 1){
            
            $tchehuoren_fc_money = $tctchehuorenParent_fc_money = 0;
            
            $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($orderInfo['tj_hehuoren_id']);
            if($tchehuorenInfo){
                $tchehuorenDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
                $tchehuorenUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tchehuorenInfo['openid']);
            }
            
            $tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
            if($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1 && $tceduConfig['subordinate_moneytype'] > 0){
                $tctchehuorenParentInfo = C::t("#tom_tchehuoren#tom_tchehuoren")->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
                $tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
                $tctchehuorenParentUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tctchehuorenParentInfo['openid']);
            }
            
            if($tchehuorenInfo && $tchehuorenInfo['status'] == 1 && $tchehuorenDengji['edu_fc_open'] == 1){
                
                if($courseInfoTmp['hehuoren_tg_type'] == 1){
                    $tchehuoren_fc_money = $courseInfoTmp['hehuoren_fc_scale'];
                }elseif($courseInfoTmp['hehuoren_tg_type'] == 2 && ($courseInfoTmp['hehuoren_fc_scale'] > 0 && $courseInfoTmp['hehuoren_fc_scale'] < 100)){
                    $tchehuoren_fc_money = $edu_fc_money * ($courseInfoTmp['hehuoren_fc_scale']/100);
                    $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2, '.', '');
                }

                $edu_fc_money = $edu_fc_money - $tchehuoren_fc_money;

                if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                    if($courseInfoTmp['hehuoren_tg_type'] == 1){
                        $tctchehuorenParent_fc_money = $courseInfoTmp['hehuoren_fc_scale2'];
                    }elseif($courseInfoTmp['hehuoren_tg_type'] == 2 && ($courseInfoTmp['hehuoren_fc_scale2'] > 0 && $courseInfoTmp['hehuoren_fc_scale2'] < 100)){
                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($courseInfoTmp['hehuoren_fc_scale2']/100);
                        $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                    }

                    if($tceduConfig['subordinate_moneytype'] == 1){
                        $edu_fc_money   = $edu_fc_money - $tctchehuorenParent_fc_money;
                    }else if($tceduConfig['subordinate_moneytype'] == 2){
                        $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                    }
                }
                
                if($orderInfo['pay_price'] >= ($pt_money + $edu_fc_money + $tchehuoren_fc_money + $tctchehuorenParent_fc_money)){
                    
                    $sendTemplateTchehuoren = false;
                    if($tchehuoren_fc_money > 0){
                        $sendTemplateTchehuoren = true;

                        $insertData = array();
                        $insertData['order_no']         = $orderInfo['order_no'];
                        $insertData['hehuoren_id']      = $tchehuorenInfo['id'];
                        $insertData['ly_user_id']       = $userInfoTmp['id'];
                        $insertData['child_hehuoren_id'] = 0;
                        $insertData['today_time']       = $nowDayTime;
                        $insertData['week_time']        = $nowWeekTime;
                        $insertData['month_time']       = $nowMonthTime;
                        $insertData['title']            = $courseInfoTmp['name'];
                        $insertData['type']             = lang('plugin/tom_tcedu', 'order_type_1');
                        $insertData['shouyi_price']     = $tchehuoren_fc_money;
                        $insertData['content']          = lang('plugin/tom_tcedu', 'paynotify_edu_hehuoren_beizu_1') . $orderInfo['tcedu_id'] . lang('plugin/tom_tcedu', 'paynotify_hehuoren_beizu_2') . $userInfoTmp['nickname'];
                        $insertData['shouyi_status']    = 1;
                        $insertData['add_time']         = TIMESTAMP;
                        C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                    }

                    $sendTemplateTchehuorenParent = false;
                    if($tctchehuorenParent_fc_money > 0){
                        $sendTemplateTchehuorenParent = true;

                        $insertData = array();
                        $insertData['order_no']         = $orderInfo['order_no'];
                        $insertData['hehuoren_id']      = $tctchehuorenParentInfo['id'];
                        $insertData['ly_user_id']       = $userInfoTmp['id'];
                        $insertData['child_hehuoren_id'] = $tchehuorenInfo['id'];
                        $insertData['today_time']       = $nowDayTime;
                        $insertData['week_time']        = $nowWeekTime;
                        $insertData['month_time']       = $nowMonthTime;
                        $insertData['title']            = $courseInfoTmp['name'];
                        $insertData['type']             = lang('plugin/tom_tcedu', 'order_type_1');
                        $insertData['shouyi_price']     = $tctchehuorenParent_fc_money;
                        $insertData['content']          = lang('plugin/tom_tcedu', 'paynotify_edu_hehuoren_beizu_1') . $orderInfo['tcedu_id'] . lang('plugin/tom_tcedu', 'paynotify_hehuoren_beizu_2') . $userInfoTmp['nickname'];
                        $insertData['shouyi_status']    = 1;
                        $insertData['add_time']         = TIMESTAMP;
                        C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                    }
                }

            }
        }
    }
    
    if($pt_money > 0.1 && $__ShowTcadmin == 1 && $tceduConfig['zizhandi_fc'] == 1){
        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);

        $fc_scale = $tcadminConfig['fc_scale'];
        if($sitesInfo['edu_fc_scale'] > 0){
            $fc_scale = $sitesInfo['edu_fc_scale'];
        }

        $fc_money = $pt_money*($fc_scale/100);
        $fc_money = number_format($fc_money,2, '.', '');
        
        $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);

        $old_money = 0;
        if($walletInfo){
            $old_money = $walletInfo['account_balance'];

            $updateData = array();
            $updateData['account_balance']      = $walletInfo['account_balance'] + $fc_money;
            $updateData['total_income']         = $walletInfo['total_income'] + $fc_money;
            C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
        }else{
            $insertData = array();
            $insertData['site_id']              = $orderInfo['site_id'];
            $insertData['account_balance']      = $fc_money;
            $insertData['total_income']         = $fc_money;
            $insertData['add_time']             = TIMESTAMP;
            C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
        }

        $insertData = array();
        $insertData['site_id']      = $orderInfo['site_id'];
        $insertData['log_type']     = 1;
        $insertData['change_money'] = $fc_money;
        $insertData['old_money']    = $old_money;
        $insertData['beizu']        = lang('plugin/tom_tcedu', 'order_type_1');
        $insertData['order_no']     = $orderInfo['order_no'];
        $insertData['order_type']   = 99;
        $insertData['log_ip']       = $_G['clientip'];
        $insertData['log_time']     = TIMESTAMP;
        C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData);

    }
    
    if($edu_fc_money > 0){
        
        $hexiao_edu_fc_money = number_format($edu_fc_money,2, '.', '');
        
        $insertData = array();
        $insertData['user_id']          = $tceduUserInfoTmp['id'];
        $insertData['type_id']          = 2;
        $insertData['change_money']     = $hexiao_edu_fc_money;
        $insertData['old_money']        = $tceduUserInfoTmp['money'];
        $insertData['tag']              = lang('plugin/tom_tcedu', 'refund_money_log_tag');
        $insertData['beizu']            = lang('plugin/tom_tcedu', 'order_type_1');
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
        
        DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$hexiao_edu_fc_money} WHERE id='{$tceduUserInfoTmp['id']}'", 'UNBUFFERED');
    }
    
    $updateData = array();
    $updateData['balance_status'] = 1;
    C::t('#tom_tcedu#tom_tcedu_course_bm')->update($bmInfo['id'],$updateData);
    
    if($orderInfo['site_id'] > 1){
        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
        $sitename = $sitesInfo['name'];
    }else{
        $sitename = $tceduConfig['plugin_name'];
    }
    
    if($sendTemplateTchehuoren == true){
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tchehuorenInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
            $shouyiText = str_replace("{NICKNAME}",$userInfoTmp['nickname'], lang('plugin/tom_tongcheng', 'paynotify_hehuoren_template'));
            $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
            $shouyiText = str_replace("{TYPE}",lang('plugin/tom_tcedu', 'order_type_1'), $shouyiText);
            $shouyiText = str_replace("{MONEY}",$tchehuoren_fc_money, $shouyiText);
            $smsData = array(
                'first'         => $shouyiText,
                'keyword1'      => $tchehuorenConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );
            if(!empty($tchehuorenConfig['template_id'])){
                $template_id = $tchehuorenConfig['template_id'];
            }else{
                $template_id = $tongchengConfig['template_id'];
            }
            @$r = $templateSmsClass->sendSms01($tchehuorenInfo['openid'], $template_id, $smsData);
        }
    }

    if($sendTemplateTchehuorenParent == true){
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tctchehuorenParentInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
            $shouyiText = str_replace("{TCHEHUOREN}",$tchehuorenInfo['xm'], lang('plugin/tom_tongcheng', 'paynotify_hehuorenparent_template'));
            $shouyiText = str_replace("{NICKNAME}",$userInfoTmp['nickname'], $shouyiText);
            $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
            $shouyiText = str_replace("{TYPE}",lang('plugin/tom_tcedu', 'order_type_1'), $shouyiText);
            $shouyiText = str_replace("{MONEY}",$tctchehuorenParent_fc_money, $shouyiText);
            $smsData = array(
                'first'         => $shouyiText,
                'keyword1'      => $tchehuorenConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );
            if(!empty($tchehuorenConfig['template_id'])){
                $template_id = $tchehuorenConfig['template_id'];
            }else{
                $template_id = $tongchengConfig['template_id'];
            }
            @$r = $templateSmsClass->sendSms01($tctchehuorenParentInfo['openid'], $template_id, $smsData);
        }
    }
}