<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$teacher_id = intval($_GET['teacher_id'])?intval($_GET['teacher_id']):0;

$teacherInfo = C::t("#tom_tcedu#tom_tcedu_teacher")->fetch_by_id($teacher_id);
if($teacherInfo['id'] > 0){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($teacherInfo['tcedu_id']);
if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $avatar             = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $subject            = isset($_GET['subject'])? addslashes($_GET['subject']):'';
    $teach_age          = isset($_GET['teach_age'])? intval($_GET['teach_age']):0;
    $desc               = isset($_GET['desc'])? addslashes($_GET['desc']):'';
    $open_hexiao        = isset($_GET['open_hexiao'])? intval($_GET['open_hexiao']):0;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $tsort              = isset($_GET['tsort'])? intval($_GET['tsort']):0;
    
    $teacherInfoTmp = C::t("#tom_tcedu#tom_tcedu_teacher")->fetch_all_list(" AND id != {$teacher_id} AND tcedu_id = {$tceduInfo['id']} AND user_id = {$user_id} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($teacherInfoTmp) && !empty($teacherInfoTmp[0])){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    if(is_array($userInfoTmp) && !empty($userInfoTmp)){ }else{
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['user_id']              = $user_id;
    $updateData['name']                 = $name;
    $updateData['avatar']               = $avatar;
    $updateData['subject']              = $subject;
    $updateData['teach_age']            = $teach_age;
    $updateData['desc']                 = $desc;
    $updateData['open_hexiao']          = $open_hexiao;
    $updateData['status']               = $status;
    $updateData['content']              = $content;
    $updateData['tsort']                = $tsort;
    C::t('#tom_tcedu#tom_tcedu_teacher')->update($teacher_id, $updateData);
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
}

if(!preg_match('/^http/', $teacherInfo['avatar']) ){
    if(strpos($teacherInfo['avatar'], 'source/plugin/tom_') === FALSE){
        $teacherInfo['avatarTmp'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$teacherInfo['avatar'];
    }else{
        $teacherInfo['avatarTmp'] = $teacherInfo['avatar'];
    }
}else{
    $teacherInfo['avatarTmp'] = $teacherInfo['avatar'];
}

$saveUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=teacheredit&teacher_id={$teacher_id}";
$uploadUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tcedu:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:teacheredit");