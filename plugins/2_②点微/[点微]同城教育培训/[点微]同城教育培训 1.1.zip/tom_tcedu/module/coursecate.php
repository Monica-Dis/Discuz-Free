<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcedu_id   = intval($_GET['tcedu_id'])>0? intval($_GET['tcedu_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

$where = " AND tcedu_id = {$tceduInfo['id']} ";

$pagesize       = 8;
$start          = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_course_cate')->fetch_all_count($where);
$courseCateListTmp = C::t('#tom_tcedu#tom_tcedu_course_cate')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$courseCateList = array();
if(is_array($courseCateListTmp) && !empty($courseCateListTmp)){
    foreach ($courseCateListTmp as $key => $value){
        $courseCateList[$key] = $value;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=coursecate&page={$prePage}&tcedu_id={$tcedu_id}";
$nextPageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=coursecate&page={$nextPage}&tcedu_id={$tcedu_id}";

$ajaxDelUrl = "plugin.php?id=tom_tcedu:ajax&site={$site_id}&act=del_course_cate&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:coursecate");