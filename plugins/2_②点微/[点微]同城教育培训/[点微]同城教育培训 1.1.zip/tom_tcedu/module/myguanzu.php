<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND user_id={$__UserInfo['id']}";
$order = " ORDER BY id DESC ";

$count = C::t('#tom_tcedu#tom_tcedu_guanzu')->fetch_all_count($where);
$guanzuListTmp = C::t('#tom_tcedu#tom_tcedu_guanzu')->fetch_all_list($where, $order, $start, $pagesize);
$guanzuList = array();
if(is_array($guanzuListTmp) && !empty($guanzuListTmp)){
    foreach ($guanzuListTmp as $key => $value){
        $guanzuList[$key] = $value;
        
        $tceduInfoTmp = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($value['tcedu_id']);
        $photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(" AND tcedu_id = {$tceduInfoTmp['id']} AND type = 1 "," ORDER BY id DESC ",0,1);
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $tceduInfoTmp['picurl'] = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $tceduInfoTmp['total_bili']  = $tceduInfoTmp['total_score'] / 5 * 100;
        $tceduInfoTmp['total_score'] = sprintf("%.1f", round($tceduInfoTmp['total_score'], 1));
        $tceduInfoTmp['tabsList']    = explode('|', $tceduInfoTmp['tabs']);
        
        $guanzuList[$key]['tceduInfo'] = $tceduInfoTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=myguanzu&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=myguanzu&page={$nextPage}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:myguanzu");