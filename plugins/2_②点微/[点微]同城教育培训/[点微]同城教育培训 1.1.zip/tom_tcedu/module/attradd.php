<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcedu_id = isset($_GET['tcedu_id'])? intval($_GET['tcedu_id']):0;

$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);

if($__UserInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ }else{
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

if($_GET['act'] == 'save' && submitcheck('tcedu_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $type               = isset($_GET['type'])? intval($_GET['type']):0;
    $value              = isset($_GET['value'])? addslashes($_GET['value']):'';
    $is_must            = isset($_GET['is_must'])? intval($_GET['is_must']):0;
    $unit               = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $msg                = isset($_GET['msg'])? addslashes($_GET['msg']):'';
    $asort              = isset($_GET['asort'])? intval($_GET['asort']):10;
  
    $insertData = array();
    $insertData['tcedu_id']           = $tcedu_id;
    $insertData['name']               = $name;
    $insertData['type']               = $type;
    $insertData['value']              = $value;
    $insertData['is_must']            = $is_must;
    $insertData['unit']               = $unit;
    $insertData['msg']                = $msg;
    $insertData['is_show']            = 1;
    $insertData['asort']              = $asort;
    $insertData['add_time']           = TIMESTAMP;
    if(C::t('#tom_tcedu#tom_tcedu_attr')->insert($insertData)){
        echo 200; exit;
    }else{
        echo 404; exit;
    }
}

$saveUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=attradd&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:attradd");