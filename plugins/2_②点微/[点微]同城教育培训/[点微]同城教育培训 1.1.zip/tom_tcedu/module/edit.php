<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$s          = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
$tcedu_id   = intval($_GET['tcedu_id']) > 0 ? intval($_GET['tcedu_id']) : 0;

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
if($tceduInfo['id'] > 0){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

$editPowerStatus = 0;
if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ 
    $editPowerStatus = 1;
}

# check start
if($editPowerStatus == 0){
    if($__UserInfo['id'] == $tceduConfig['manage_user_id']){
        $editPowerStatus = 2;
    }else{
        if($__UserInfo['groupid'] == 1){
            $editPowerStatus = 2;
        }else if($__UserInfo['groupid'] == 2){
            if($tceduInfo['site_id'] == $__UserInfo['groupsiteid']){
                $editPowerStatus = 2;
            }
        }
    }
}
# check end

if($editPowerStatus == 0){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

$vipInfo = array();
if($tceduInfo['vip_id'] > 0 && $tceduInfo['expire_status'] == 1 && $tceduInfo['expire_time'] >= TIMESTAMP){
    $vipInfo = C::t("#tom_tcedu#tom_tcedu_vip")->fetch_by_id($tceduInfo['vip_id']);
}

if($_GET['act'] == 'save' && submitcheck('name')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $cate_child_ids     = isset($_GET['cate_child_ids'])? addslashes($_GET['cate_child_ids']):'';
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $longitude          = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $latitude           = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $edu_xm             = isset($_GET['edu_xm'])? addslashes($_GET['edu_xm']):'';
    $edu_tel            = isset($_GET['edu_tel'])? addslashes($_GET['edu_tel']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $theme_color        = isset($_GET['theme_color'])? addslashes($_GET['theme_color']):'';
    $tabs_diy           = isset($_GET['tabs_diy'])? addslashes($_GET['tabs_diy']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $kefu_qrcode        = isset($_GET['kefu_qrcode'])? addslashes($_GET['kefu_qrcode']):'';
    $video_pic          = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_url          = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $business_licence   = isset($_GET['business_licence'])? addslashes($_GET['business_licence']):'';
    
    $cateChildIdsArrTmp = explode(',', $cate_child_ids);
    $cateChildIdsArr = array();
    if(is_array($cateChildIdsArrTmp) && !empty($cateChildIdsArrTmp)){
        foreach($cateChildIdsArrTmp as $key => $value){
            $value = intval($value);
            if($value > 0){
                $cateChildIdsArr[] = $value;
            }
        }
    }
    
    $cateNameArr = array();
    $cateIdsStr = $cateChildIdsStr = '';
    if(!empty($cateChildIdsArr)){
        $cateChildIdsStrTmp = implode(',', $cateChildIdsArr);
        $cateListTmp = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_all_list(" AND id IN ({$cateChildIdsStrTmp}) ");
        $cateIdsArr = array();
        foreach($cateListTmp as $key => $value){
            $cateIdsArr[$value['pid']] = $value['pid'];
            $cateNameArr[] = $value['name'];
        }
        
        $cateIdsStrTmp = implode(',', $cateIdsArr);
        $cateListTmp = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_all_list(" AND id IN ({$cateIdsStrTmp}) ");
        foreach($cateListTmp as $key => $value){
            $cateNameArr[] = $value['name'];
        }
        
        $cateIdsStr = '|'.implode('|', $cateIdsArr).'|';
        $cateChildIdsStr = '|'.implode('|', $cateChildIdsArr).'|';
    }
    
    $tabsArr = array();
    foreach($_GET['tabs'] as $key => $value){
        $value = addslashes($value);
        if(!empty($value)){
            $tabsArr[] = $value;
        }
    }
    
    if(!empty($tabs_diy)){
        $tabs_diy = trim($tabs_diy);
        $tabs_diy_arr = explode(" ", $tabs_diy);
        foreach($tabs_diy_arr as $key => $value){
            $value = trim($value);
            if(!empty($value)){
                $tabsArr[] = $value;
            }
        }
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photosort_") !== false){
            $kk = intval(ltrim($key, "photosort_"));
            $photoArr[$kk]['sort'] = addslashes($value);
        }
    }
    
    $tabsStr = implode('|', $tabsArr);
    
    $search_text = $name.'|'.$tel.'|'.implode('', $cateNameArr).'|'.$tabsStr;
    
    $updateData = array();
    $updateData['name']                 = $name;
    $updateData['cate_ids']             = $cateIdsStr;
    $updateData['cate_child_ids']       = $cateChildIdsStr;
    $updateData['area_id']              = $area_id;
    $updateData['street_id']            = $street_id;
    $updateData['longitude']            = $longitude;
    $updateData['latitude']             = $latitude;
    $updateData['address']              = $address;
    $updateData['theme_color']          = $theme_color;
    $updateData['tabs']                 = $tabsStr;
    $updateData['edu_xm']               = $edu_xm;
    $updateData['edu_tel']              = $edu_tel;
    $updateData['tel']                  = $tel;
    if($tceduInfo['admin_edit'] == 0){
        $updateData['content']              = $content;
    }
    if(!empty($video_pic) && !empty($video_url)){
        $updateData['video_status']         = 1;
    }
    $updateData['kefu_qrcode']          = $kefu_qrcode;
    $updateData['business_licence']     = $business_licence;
    $updateData['video_pic']            = $video_pic;
    $updateData['video_url']            = $video_url;
    $updateData['search_text']          = $search_text;
    if($tceduConfig['must_shenhe'] == 1 && $editPowerStatus == 1){
        $updateData['shenhe_status']        = 2;
    }
    $updateData['is_ok']                = 1;
    $updateData['update_time']          = TIMESTAMP;
    if(C::t('#tom_tcedu#tom_tcedu')->update($tceduInfo['id'], $updateData)){
        
        C::t('#tom_tcedu#tom_tcedu_photo')->delete_by_tcedu_avatar($tceduInfo['id']);
        C::t('#tom_tcedu#tom_tcedu_photo')->delete_by_tcedu_photo($tceduInfo['id']);
        
        if($tceduInfo['street_id'] != $street_id || $tceduInfo['longitude'] != $longitude || $tceduInfo['latitude'] != $latitude){
            DB::query("UPDATE ".DB::table('tom_tcedu_course')." SET area_id={$area_id},street_id={$street_id},longitude={$longitude},latitude={$latitude} WHERE tcedu_id={$tceduInfo['id']}", 'UNBUFFERED');
        }
        
        if(!empty($picurl)){
            $insertData = array();
            $insertData['tcedu_id']  = $tceduInfo['id'];
            $insertData['type']      = 1;
            $insertData['picurl']    = $picurl;
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcedu#tom_tcedu_photo')->insert($insertData);
        }
        
        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['tcedu_id']     = $tceduInfo['id'];
                $insertData['type']         = 2;
                $insertData['picurl']       = $value['picurl'];
                $insertData['psort']        = $value['sort'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tcedu#tom_tcedu_photo')->insert($insertData);
            }
        }
        
        update_edu_tcshop($tceduInfo['id']);
        
        if($tceduConfig['must_shenhe'] == 1 && $editPowerStatus == 1){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $access_token = $weixinClass->get_access_token();

                if($access_token && !empty($toUserTmp['openid'])  ){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=managerEduList");
                    $smsData = array(
                        'first'         => '['.$__UserInfo['nickname'].']'.lang('plugin/tom_tcedu', 'shenhe_template_edit'),
                        'keyword1'      => $tceduConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                        'remark'        => ''
                    );
                    $r = $templateSmsClass->sendSms01($toUserTmp['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
            
            if($tceduConfig['manage_user_id'] > 0){
                $toEduUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduConfig['manage_user_id']);
                if($toEduUserTmp && !empty($toEduUserTmp['openid'])){
                    $access_token = $weixinClass->get_access_token();

                    if($access_token && !empty($toEduUserTmp['openid'])  ){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=managerEduList");
                        $smsData = array(
                            'first'         => '['.$__UserInfo['nickname'].']'.lang('plugin/tom_tcedu', 'shenhe_template_edit'),
                            'keyword1'      => $tceduConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                            'remark'        => ''
                        );
                        $r = $templateSmsClass->sendSms01($toEduUserTmp['openid'],$tongchengConfig['template_id'],$smsData);
                    }
                }
            }
            
        }
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$cate_ids = trim($tceduInfo['cate_ids'], '|');
$cateIdsArr = explode('|', $cate_ids);

$cate_child_ids = trim($tceduInfo['cate_child_ids'], '|');
$cateChildIdsArr = explode('|', $cate_child_ids);
$tceduInfo['cate_child_ids'] = implode(',', $cateChildIdsArr);

$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" AND status = 1 "," ORDER BY csort ASC,id DESC ");
$cateList = $cateChildList = $cateChildNameArr = $selectCateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach ($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][$key] = $value;
            $cateChildList[$value['pid']][$key]['select_on'] = false;
            
            if(in_array($value['id'], $cateChildIdsArr)){
                $cateChildList[$value['pid']][$key]['select_on'] = true;
                $cateChildNameArr[] = $value['name'];
                $selectCateList[] = $value;
            }
        }else{
            $cateList[$key] = $value;
            $cateList[$key]['select_on'] = false;
            
            if(in_array($value['id'], $cateIdsArr)){
                $cateList[$key]['select_on'] = true;
            }
        }
    }
}

$tceduInfo['cate_child_names'] = implode(',', $cateChildNameArr);

$eduColorList = array();
$edu_color_str = str_replace("\r\n","{n}",$tceduConfig['edu_color_list']); 
$edu_color_str = str_replace("\n","{n}",$edu_color_str);
$edu_color_arr = explode("{n}", $edu_color_str);
if(is_array($edu_color_arr) && !empty($edu_color_arr)){
    foreach ($edu_color_arr as $key => $value){
        $arrTmp = explode("|", $value);

        $eduColorList[$key]['color']    = $arrTmp[0];
        $eduColorList[$key]['name']     = $arrTmp[1];
    }
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($tceduInfo['city_id']);
$cityList = array();
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        
        if($tceduInfo['area_id'] == $value['id']){
            $tceduInfo['area_name'] = $value['name'];
        }
        
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                
                if($tceduInfo['street_id'] == $vv['id']){
                    $tceduInfo['street_name'] = $vv['name'];
                }
                
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

if(!preg_match('/^http/', $tceduInfo['video_pic']) ){
    if(strpos($tceduInfo['video_pic'], 'source/plugin/tom_') === FALSE){
        $tceduInfo['video_picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tceduInfo['video_pic'];
    }else{
        $tceduInfo['video_picurl'] = $tceduInfo['video_pic'];
    }
}else{
    $tceduInfo['video_picurl'] = $tceduInfo['video_pic'];
}

if(!preg_match('/^http/', $tceduInfo['kefu_qrcode']) ){
    if(strpos($tceduInfo['kefu_qrcode'], 'source/plugin/tom_') === FALSE){
        $tceduInfo['kefu_qrcode_picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tceduInfo['kefu_qrcode'];
    }else{
        $tceduInfo['kefu_qrcode_picurl'] = $tceduInfo['kefu_qrcode'];
    }
}else{
    $tceduInfo['kefu_qrcode_picurl'] = $tceduInfo['kefu_qrcode'];
}

if(!preg_match('/^http/', $tceduInfo['business_licence']) ){
    if(strpos($tceduInfo['business_licence'], 'source/plugin/tom_') === FALSE){
        $tceduInfo['business_licence_picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tceduInfo['business_licence'];
    }else{
        $tceduInfo['business_licence_picurl'] = $tceduInfo['business_licence'];
    }
}else{
    $tceduInfo['business_licence_picurl'] = $tceduInfo['business_licence'];
}

$photoListTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(" AND tcedu_id = {$tceduInfo['id']} AND type IN(1,2) ", "ORDER BY psort ASC,id ASC", 0, 100);
$photoList = array();
$i = 1;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        if($value['type'] == 1){
            $tceduInfo['picurl'] = $value['picurl'];
            $tceduInfo['picurlTmp'] = $value['picurlTmp'];
        }else{
            $photoList[$key] = $value;
            $photoList[$key]['pic_url'] = $value['picurlTmp'];
            $photoList[$key]['i'] = $i;
            $i++;
        }
    }
}
$photoCount = Count($photoList);

$eduTabsArr = array();
$edu_tab_str = str_replace("\r\n","{n}",$tceduConfig['edu_tab_list']); 
$edu_tab_str = str_replace("\n","{n}",$edu_tab_str);
$edu_tab_arr = explode("{n}", $edu_tab_str);
if(is_array($edu_tab_arr) && !empty($edu_tab_arr)){
    foreach ($edu_tab_arr as $key => $value){
        $value = trim($value);

        if(!empty($value)){
            $eduTabsArr[] = $value;
        }
    }
}

$tabsArray = array();
if(!empty($tceduInfo['tabs'])){
    $tabsArray = explode('|', $tceduInfo['tabs']);
}
$tabsList = array();
foreach ($eduTabsArr as $key => $value){
    $tabsList[$key]['name'] = $value;
    $tabsList[$key]['status'] = 0;
    if(is_array($tabsArray) && !empty($tabsArray) && in_array($value, $tabsArray)){
        $tabsList[$key]['status'] = 1;
    }
}
$tabsArray = array_diff($tabsArray, $eduTabsArr);
$i = count($tabsList) + 1;
foreach ($tabsArray as $key => $value){
    $tabsList[$i]['name'] = $value;
    $tabsList[$i]['status'] = 1;
    $i++;
}

$saveUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=edit&tcedu_id={$tceduInfo['id']}";
$uploadUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$ossBatchUrl = 'plugin.php?id=tom_tcedu:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcedu:qiniuBatch';
$wxUploadUrl = "plugin.php?id=tom_tcedu:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:edit");