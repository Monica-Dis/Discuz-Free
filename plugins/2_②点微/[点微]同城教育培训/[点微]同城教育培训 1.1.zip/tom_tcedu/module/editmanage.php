<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcedu_id = intval($_GET['tcedu_id']) > 0 ? intval($_GET['tcedu_id']) : 0;

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);

if($tceduInfo['id'] > 0 && $tceduInfo['user_id'] == $__UserInfo['id']){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $manage_user_id = isset($_GET['manage_user_id'])? intval($_GET['manage_user_id']):0;
    
    if($manage_user_id > 0){
        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($manage_user_id);
        if($manageUserInfo && $manageUserInfo['id'] > 0){ }else{
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }

        if($manageUserInfo['id'] == $__UserInfo['id']){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $updateData = array();
    $updateData['manage_user_id'] = $manage_user_id;
    if(C::t('#tom_tcedu#tom_tcedu')->update($tceduInfo['id'], $updateData)){
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

if($tceduInfo['manage_user_id'] > 0){
    $manageInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tceduInfo['manage_user_id']);
}

$saveUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=editmanage&tcedu_id={$tceduInfo['id']}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:editmanage");