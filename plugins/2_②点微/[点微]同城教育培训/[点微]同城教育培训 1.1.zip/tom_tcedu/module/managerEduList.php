<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    if($__UserInfo['id'] != $tceduConfig['manage_user_id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=index");exit;
    }
}
# check end

if($_GET['act'] == 'shenhe' && (submitcheck('tcedu_id') || submitcheck('shenhe_id'))){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $shenhe_id      = intval($_GET['shenhe_id'])>0? intval($_GET['shenhe_id']):0;
    $tcedu_id       = intval($_GET['tcedu_id'])>0? intval($_GET['tcedu_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0? intval($_GET['shenhe_status']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    if($shenhe_status == 3){
        $tcedu_id = $shenhe_id;
    }
    
    $tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
    
    $updateData = array();
    $updateData['shenhe_status'] = $shenhe_status;
    if($shenhe_status == 1){
        $updateData['status'] = 1;
    }
    C::t('#tom_tcedu#tom_tcedu')->update($tceduInfo['id'],$updateData);
    
    if($shenhe_status == 1){
        update_edu_tcshop($tceduInfo['id']);
    }
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduInfo['user_id']);
    
    if($shenhe_status == 1){
        $shenhe = str_replace('{NAME}', $tceduInfo['name'], lang('plugin/tom_tcedu', 'template_shenhe_ok'));
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcedu&site='.$site_id.'&mod=info&tcedu_id='.$tceduInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
    }else if($shenhe_status == 3){
        $shenhe = str_replace('{NAME}', $tceduInfo['name'], lang('plugin/tom_tcedu', 'template_shenhe_no'));
        $tzShenhe = $shenhe.'<br/><font color="#8e8e8e">'.$content.'</font><br/><a href="plugin.php?id=tom_tcedu&site='.$site_id.'&mod=edit&tcedu_id='.$tceduInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
    }

    $insertData = array();
    $insertData['user_id']      = $toUser['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tceduConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    
    if($access_token && !empty($toUser['openid'])){
        if($shenhe_status == 1){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$tceduInfo['site_id']}&mod=info&tcedu_id=".$tceduInfo['id']);
        }else if($shenhe_status == 3){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$tceduInfo['site_id']}&mod=edit&tcedu_id={$tceduInfo['id']}&s=1");
        }
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tceduConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
    }
    
    if($tceduInfo['manage_user_id'] > 0){
        $manageUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduInfo['manage_user_id']);
        
        $insertData = array();
        $insertData['user_id']      = $tceduInfo['manage_user_id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tceduConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        if($access_token && !empty($manageUserInfo['openid'])){
            if($shenhe_status == 1){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$tceduInfo['site_id']}&mod=info&tcedu_id=".$tceduInfo['id']);
            }else if($shenhe_status == 3){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$tceduInfo['site_id']}&mod=edit&tcedu_id={$tceduInfo['id']}&s=1");
            }
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tceduConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $content
            );
            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=managerEduList&keyword=".urlencode(trim($keyword));
    
    echo $url;exit;
    
}else if($_GET['act'] == 'del' && submitcheck('tcedu_id')){
    
    $tcedu_id = intval($_GET['tcedu_id'])>0? intval($_GET['tcedu_id']):0;
    
    $count = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_all_count(" AND tcedu_id = {$tcedu_id} AND pay_status IN(0, 2) AND use_status = 0 ");
    if($count > 0){
        echo 301;exit;
    }
    
    C::t('#tom_tcedu#tom_tcedu')->delete_by_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_course')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_course_bm')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_course_cate')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_course_collect')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_course_option')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_guanzu')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_pinglun')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_photo')->delete_by_pinglun_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_photo')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_teacher')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_history')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_vip_log')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_attr')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_course_bm_attr')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_course_bm_log')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_phb')->delete_by_tcedu_id($tcedu_id);
    C::t('#tom_tcedu#tom_tcedu_renqi_log')->delete_by_tcedu_id($tcedu_id);
    echo 200;exit;

}else if($_GET['act'] == 'shenhe_show'){
    
    $tcedu_id       = intval($_GET['tcedu_id'])>0? intval($_GET['tcedu_id']):0;
    
    $tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
    
    $name = $tceduInfo['name'];
    $shenhe_id = $tceduInfo['id'];
    
    $edu_shenhe_fail_str = str_replace("\r\n","{n}",$tceduConfig['edu_shenhe_fail_text']); 
    $edu_shenhe_fail_str = str_replace("\n","{n}",$edu_shenhe_fail_str);
    $shenheFailArray = explode("{n}", $edu_shenhe_fail_str);
    
    $ajaxShenheUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=managerEduList&act=shenhe&";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcedu:managerShenhe");exit;
}

$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$type       = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = " ";
if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND search_text LIKE '%{$keyword}%' ";
}
if($type == 1){
    $where .= " AND shenhe_status=2 ";
}
if($type == 2){
    $where .= " AND shenhe_status=3 ";
}
if($__UserInfo['groupid'] == 2){
    $where .= " AND site_id={$site_id} ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count = C::t('#tom_tcedu#tom_tcedu')->fetch_all_count($where);
$tceduListTmp = C::t('#tom_tcedu#tom_tcedu')->fetch_all_list($where," ORDER BY update_time DESC,id DESC ",$start,$pagesize);
$tceduList = array();
if(is_array($tceduListTmp) && !empty($tceduListTmp)){
    foreach ($tceduListTmp as $key => $value) {
        $tceduList[$key] = $value;

        $picurlTmp = '';
        $photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(" AND tcedu_id = {$value['id']} AND type = 1 "," ORDER BY id DESC ",0,1);
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $vipInfoTmp = array();
        if($value['vip_id'] > 0){
            $vipInfoTmp = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_by_id($value['vip_id']);
        }
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);

        $tceduList[$key]['picurl']      = $picurlTmp;
        $tceduList[$key]['vipInfo']     = $vipInfoTmp;
        $tceduList[$key]['userInfo']    = $userInfoTmp;

    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=managerEduList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=managerEduList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];

$ajaxShenheUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=managerEduList&act=shenhe&formhash=".$formhash;
$ajaxDelUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=managerEduList&act=del&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=managerEduList&act=get_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:managerEduList");