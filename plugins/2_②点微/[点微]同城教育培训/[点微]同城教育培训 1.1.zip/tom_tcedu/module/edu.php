<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$s          = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
$tcedu_id   = intval($_GET['tcedu_id']) > 0 ? intval($_GET['tcedu_id']) : 0;

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);

$manageLevel = 0;
if($tceduInfo['id'] > 0 && $tceduInfo['user_id'] == $__UserInfo['id'] && !empty($tceduInfo['content'])){
    $manageLevel = 1;
}else{
    if($tceduInfo['manage_user_id'] > 0 && $tceduInfo['manage_user_id'] == $__UserInfo['id']){ 
        $manageLevel = 2;
    }else{
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
    }
}

$photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(" AND tcedu_id = {$tceduInfo['id']} AND type = 1 "," ORDER BY id DESC ",0,1);
if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
    $tceduInfo['picurl'] = $photoInfoTmp[0]['picurlTmp'];
}

$todayPayPrice = C::t("#tom_tcedu#tom_tcedu_order")->fetch_all_pay_price(" AND tcedu_id = {$tceduInfo['id']} AND order_status = 2 AND pay_time >= {$nowDayTime} ");
$totalPayPrice = C::t("#tom_tcedu#tom_tcedu_order")->fetch_all_pay_price(" AND tcedu_id = {$tceduInfo['id']} AND order_status = 2 ");

$tceduInfo['clicks'] = $tceduInfo['clicks'] + $tceduInfo['virtual_clicks'];

$bmPayCount = C::t("#tom_tcedu#tom_tcedu_course_bm")->fetch_all_count(" AND tcedu_id = {$tceduInfo['id']} AND pay_status = 2 AND refund_status = 0 ");
$bmNoUseCount = C::t("#tom_tcedu#tom_tcedu_course_bm")->fetch_all_count(" AND tcedu_id = {$tceduInfo['id']} AND pay_status IN(0,2) AND use_status = 0 ");

$tceduListTmp = C::t("#tom_tcedu#tom_tcedu")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND id != {$tcedu_id} AND is_ok = 1 ", 'ORDER BY id DESC');
$tceduList = array();
if(is_array($tceduListTmp) && !empty($tceduListTmp)){
    foreach($tceduListTmp as $key => $value){
        if(!empty($value['content'])){
            $tceduList[$key] = $value;
        }
    }
}
$tceduCount = count($tceduList);

$shareTitle = $tceduInfo['name'];
$shareLogo = $tceduInfo['picurl'];
$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=edu&tcedu_id={$tceduInfo['id']}&s=1";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:edu");