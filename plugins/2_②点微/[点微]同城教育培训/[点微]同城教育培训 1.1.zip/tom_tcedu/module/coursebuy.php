<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$course_id = isset($_GET['course_id'])? intval($_GET['course_id']):0;
$option_id = isset($_GET['option_id'])? intval($_GET['option_id']):0;

$courseInfo = C::t("#tom_tcedu#tom_tcedu_course")->fetch_by_id($course_id);
if($courseInfo['id'] > 0 && $courseInfo['status'] == 1 && $courseInfo['shenhe_status'] == 1 && $courseInfo['deleted'] == 0){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=index");exit;
}

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($courseInfo['tcedu_id']);

$photoInfoTmp = C::t("#tom_tcedu#tom_tcedu_photo")->fetch_all_list(" AND course_id = {$courseInfo['id']} AND type = 4 ", 'ORDER BY id DESC', 0, 1);
if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
    $courseInfo['picurl'] = $photoInfoTmp[0]['picurlTmp'];
}

if($courseInfo['hasoption'] == 1){
    $optionInfo = C::t("#tom_tcedu#tom_tcedu_course_option")->fetch_by_id($option_id);
    if($optionInfo['course_id'] != $courseInfo['id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=courseinfo&course_id={$course_id}");exit;
    }
}

if($courseInfo['hexiao_limit'] == 2){
    $courseInfo['hexiaoTime'] = dgmdate($courseInfo['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
}

if($courseInfo['open_bm_end_time'] == 1){
    $courseInfo['bmEndTime'] = dgmdate($courseInfo['bm_end_time'],"Y-m-d H:i",$tomSysOffset);
}

$tcyikatongPayStatus = 0;
if($__ShowTcyikatong == 1 && $__CardInfo['status'] == 1 && $tceduConfig['open_course_tcyikatong'] == 1 && $courseInfo['open_vip'] == 1){
    $tcyikatongPayStatus = 1;
}
$buy_price = $courseInfo['buy_price'];
if($courseInfo['hasoption'] == 1){
    $buy_price = $optionInfo['buy_price'];
    if($tcyikatongPayStatus == 1){
        $buy_price = $optionInfo['vip_price'];
    }
}else{
    if($tcyikatongPayStatus == 1){
        $buy_price = $courseInfo['vip_price'];
    }
}

$bmInfoTmp = C::t("#tom_tcedu#tom_tcedu_course_bm")->fetch_all_list("AND course_id = {$courseInfo['id']} AND user_id = {$__UserInfo['id']} AND pay_status = 1 ", 'ORDER BY id DESC', 0, 1);
$bmInfo = $bmAttrList = array();
if(is_array($bmInfoTmp) && !empty($bmInfoTmp[0])){
    $bmInfo = $bmInfoTmp[0];
    
    $bmAttrListTmp = C::t("#tom_tcedu#tom_tcedu_course_bm_attr")->fetch_all_list("AND bm_id = {$bmInfo['id']}", 'ORDER BY asort ASC,id DESC');
    if(is_array($bmAttrListTmp) && !empty($bmAttrListTmp)){
        foreach($bmAttrListTmp as $key => $value){
            $bmAttrList[$value['attr_id']] = $value;
            if($value['attr_type'] == 4){
                $bmAttrList[$value['attr_id']]['value'] = explode('|', $value['value']);
            }
        }
    }
}

$attrList = array();
if(!empty($courseInfo['attr_ids'])){
    $attrListTmp = C::t("#tom_tcedu#tom_tcedu_attr")->fetch_all_list("AND tcedu_id = {$courseInfo['tcedu_id']} AND id IN({$courseInfo['attr_ids']}) AND is_show = 1 ", 'ORDER BY asort ASC, id DESC');
    if(is_array($attrListTmp) && !empty($attrListTmp)){
        foreach ($attrListTmp as $key => $value){
            $attrList[$key] = $value;
            
            if(isset($bmAttrList[$value['id']])){
                $attrList[$key]['attr_value'] = $bmAttrList[$value['id']]['value'];
            }
            
            if($value['type'] == 3 || $value['type'] == 4){
                $valueStrTmp = str_replace("\r\n","{n}",$value['value']); 
                $valueStrTmp = str_replace("\n","{n}",$valueStrTmp);
                $valueArrTmp = explode("{n}", $valueStrTmp);
                $ArrTmp = array();
                if(is_array($valueArrTmp) && !empty($valueArrTmp)){
                    foreach($valueArrTmp as $k => $v){
                        $ArrTmp[$k]['value'] = $v;
                        
                        if($value['type'] == 4){
                            $ArrTmp[$k]['status'] = 0;
                            if(isset($attrList[$key]['attr_value']) && in_array($v, $attrList[$key]['attr_value'])){
                                $ArrTmp[$k]['status'] = 1;
                            }
                        }
                    }
                }
                
                $attrList[$key]['list'] = $ArrTmp;
            }
        }
    }
}

$showXiangouCourseBtn = 0;
if($courseInfo['xiangou_num'] > 0){
    $bmCount = C::t("#tom_tcedu#tom_tcedu_course_bm")->fetch_all_count(" AND course_id = {$courseInfo['id']} AND user_id = {$__UserInfo['id']} AND pay_status IN(0,2) ");
    if($bmCount >= $courseInfo['xiangou_num']){
        $showXiangouCourseBtn = 1;
    }
}

$payUrl = "plugin.php?id=tom_tcedu:pay&site={$site_id}&act=course_buy&course_id={$courseInfo['id']}&option_id={$option_id}&tjid={$tj_hehuoren_id}";
$mybmUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mybm";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:coursebuy");