<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND user_id={$__UserInfo['id']}";
$order = " ORDER BY id DESC ";

$count = C::t('#tom_tcedu#tom_tcedu_course_collect')->fetch_all_count($where);
$collectListTmp = C::t('#tom_tcedu#tom_tcedu_course_collect')->fetch_all_list($where, $order, $start, $pagesize);
$collectList = array();
if(is_array($collectListTmp) && !empty($collectListTmp)){
    foreach ($collectListTmp as $key => $value){
        $collectList[$key] = $value;
        
        $tceduInfoTmp = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($value['tcedu_id']);
        $courseInfoTmp = C::t('#tom_tcedu#tom_tcedu_course')->fetch_by_id($value['course_id']);
        
        $photoInfoTmp = C::t("#tom_tcedu#tom_tcedu_photo")->fetch_all_list(" AND course_id = {$courseInfoTmp['id']} AND type = 4 ", 'ORDER BY id DESC', 0, 1);
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $courseInfoTmp['picurl'] = $photoInfoTmp[0]['picurlTmp'];
        }

        $tabsArrTmp = array();
        if(!empty($courseInfoTmp['tabs'])){
            $tabsArrTmp = explode('|', $courseInfoTmp['tabs']);
        }

        $juliTmp = 0;
        if(!empty($longitude) && !empty($latitude) && !empty($courseInfoTmp['longitude']) && !empty($courseInfoTmp['latitude'])){
            $juliTmp = tomGetDistance($longitude, $latitude, $courseInfoTmp['longitude'], $courseInfoTmp['latitude']);
        }
        
        $courseInfoTmp['tabsArr']   = $tabsArrTmp;
        $courseInfoTmp['juli']      = $juliTmp;
        
        $collectList[$key]['tceduInfo']     = $tceduInfoTmp;
        $collectList[$key]['courseInfo']    = $courseInfoTmp;
        
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mycollect&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mycollect&page={$nextPage}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:mycollect");