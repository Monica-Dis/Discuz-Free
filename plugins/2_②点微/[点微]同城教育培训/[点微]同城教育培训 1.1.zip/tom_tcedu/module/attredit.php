<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$attr_id    = isset($_GET['attr_id'])? intval($_GET['attr_id']):0;

$attrInfo   = C::t('#tom_tcedu#tom_tcedu_attr')->fetch_by_id($attr_id);
$tceduInfo  = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($attrInfo['tcedu_id']);

if($__UserInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ }else{
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

if($_GET['act'] == 'save' && submitcheck('attr_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $is_must        = isset($_GET['is_must'])? intval($_GET['is_must']):0;
    $value          = isset($_GET['value'])? addslashes($_GET['value']):'';
    $unit           = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $msg            = isset($_GET['msg'])? addslashes($_GET['msg']):'';
    $asort          = isset($_GET['asort'])? intval($_GET['asort']):10;
    
    $updateData = array();
    $updateData['name']              = $name;
    $updateData['is_must']           = $is_must;
    $updateData['value']             = $value;
    $updateData['unit']              = $unit;
    $updateData['msg']               = $msg;
    $updateData['asort']             = $asort;
    $updateData['add_time']          = TIMESTAMP;
    if(C::t('#tom_tcedu#tom_tcedu_attr')->update($attr_id,$updateData)){
        
        echo 200;exit;
        
    }else{
        echo 404;exit;
    }
}

$backUrl = urlencode($back_url);
$saveUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=attredit&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:attredit");