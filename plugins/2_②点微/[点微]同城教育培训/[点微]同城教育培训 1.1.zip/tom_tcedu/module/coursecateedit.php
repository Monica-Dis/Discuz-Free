<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$course_cate_id = intval($_GET['course_cate_id'])?intval($_GET['course_cate_id']):0;

$courseCateInfo = C::t("#tom_tcedu#tom_tcedu_course_cate")->fetch_by_id($course_cate_id);
if($courseCateInfo['id'] > 0){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($courseCateInfo['tcedu_id']);
if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $csort              = isset($_GET['csort'])? intval($_GET['csort']):0;
    
    $updateData = array();
    $updateData['name']                 = $name;
    $updateData['csort']                = $csort;
    C::t('#tom_tcedu#tom_tcedu_course_cate')->update($course_cate_id, $updateData);
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
}

$saveUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=coursecateedit&course_cate_id={$course_cate_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:coursecateedit");