<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$course_id  = intval($_GET['course_id']) > 0 ? intval($_GET['course_id']) : 0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$courseInfo = C::t("#tom_tcedu#tom_tcedu_course")->fetch_by_id($course_id);
if($courseInfo['id'] > 0){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($courseInfo['tcedu_id']);
if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

$topList = array();
$hasScorePay = 0;
$top_list_str = str_replace("\r\n","{n}",$tceduConfig['course_top_list']); 
$top_list_str = str_replace("\n","{n}",$top_list_str);
$top_list_arr = explode("{n}", $top_list_str);
if(is_array($top_list_arr) && !empty($top_list_arr)){
    foreach ($top_list_arr as $key => $value){
        $arr = explode("|", $value);
        
        $topList[$key]['day']   = $arr[0];
        $topList[$key]['price'] = $arr[1];
        $topList[$key]['score'] = 0;
        $topList[$key]['score_pay'] = 0;
        
        if($tceduConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $scorePayNum = intval($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($scorePayNum > 0 && $__UserInfo['score'] >= $scorePayNum){
                $topList[$key]['score'] = $scorePayNum;
                $topList[$key]['score_pay'] = 1;
                $hasScorePay = 1;
            }
        }
    }
}

$payUrl = $_G['siteurl']."plugin.php?id=tom_tcedu:pay&site={$site_id}&act=course_top_buy&back_url=".urlencode($back_url);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:coursetopbuy");