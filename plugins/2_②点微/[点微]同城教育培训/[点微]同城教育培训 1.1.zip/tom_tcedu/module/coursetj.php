<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$course_id = intval($_GET['course_id'])>0? intval($_GET['course_id']):0;

$courseInfo = C::t("#tom_tcedu#tom_tcedu_course")->fetch_by_id($course_id);
if($courseInfo['id'] > 0){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($courseInfo['tcedu_id']);

$editPowerStatus = 0;
if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){
    $editPowerStatus = 1;
}

# check start
if($editPowerStatus == 0){
    if($__UserInfo['id'] == $tceduConfig['manage_user_id']){
        $editPowerStatus = 2;
    }else{
        if($__UserInfo['groupid'] == 1){
            $editPowerStatus = 2;
        }else if($__UserInfo['groupid'] == 2){
            if($tceduInfo['site_id'] == $__UserInfo['groupsiteid']){
                $editPowerStatus = 2;
            }
        }
    }
}
# check end

if($editPowerStatus == 0){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $hehuoren_tg_open    = isset($_GET['hehuoren_tg_open'])? intval($_GET['hehuoren_tg_open']):0;
    $hehuoren_tg_type    = isset($_GET['hehuoren_tg_type'])? intval($_GET['hehuoren_tg_type']):0;
    $hehuoren_fc_scale   = isset($_GET['hehuoren_fc_scale'])? floatval($_GET['hehuoren_fc_scale']):0;
    $hehuoren_fc_scale2  = isset($_GET['hehuoren_fc_scale2'])? floatval($_GET['hehuoren_fc_scale2']):0;

    $updateData = array();
    $updateData['hehuoren_tg_open']      = $hehuoren_tg_open;
    $updateData['hehuoren_tg_type']      = $hehuoren_tg_type;
    $updateData['hehuoren_fc_scale']     = $hehuoren_fc_scale;
    if($tceduConfig['subordinate_moneytype'] == 1 && $tchehuorenConfig['open_subordinate'] == 1){
        $updateData['hehuoren_fc_scale2']    = $hehuoren_fc_scale2;
    }
    C::t('#tom_tcedu#tom_tcedu_course')->update($courseInfo['id'],$updateData);

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
}

$saveUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=coursetj&course_id={$course_id}&act=save&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:coursetj");