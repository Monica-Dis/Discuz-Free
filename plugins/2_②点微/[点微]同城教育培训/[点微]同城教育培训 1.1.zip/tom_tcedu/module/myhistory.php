<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type = intval($_GET['type'])>0? intval($_GET['type']):1;
$act  = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'list' && $_GET['formhash'] == FORMHASH){
    $outStr = '';

    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

    $pagesize = $pagesize;
    $start = ($page - 1)*$pagesize;

    if($__UserInfo['id'] > 0){ }else{
        $outStr = '205';
        echo json_encode($outStr); exit;
    }

    $where = " AND user_id={$__UserInfo['id']} AND type={$type} ";

    $order = " ORDER BY id DESC ";

    $count = C::t('#tom_tcedu#tom_tcedu_history')->fetch_all_count($where);
    $historyListTmp = C::t('#tom_tcedu#tom_tcedu_history')->fetch_all_list($where, $order, $start, $pagesize);
    $historyList = array();
    if(is_array($historyListTmp) && !empty($historyListTmp)){
        foreach ($historyListTmp as $key => $value){

            $historyList[$key] = $value;
            $historyList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d",$tomSysOffset);

            $tceduInfoTmp = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($value['tcedu_id']);

            if($value['type'] == 1){
                $photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(" AND tcedu_id = {$tceduInfoTmp['id']} AND type = 1 "," ORDER BY id DESC ",0,1);
                if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
                    $tceduInfoTmp['picurl'] = $photoInfoTmp[0]['picurlTmp'];
                }

                $tceduInfoTmp['total_bili']     = $tceduInfoTmp['total_score'] / 5 * 100;
                $tceduInfoTmp['total_score']    = sprintf("%.1f", round($tceduInfoTmp['total_score'], 1));
                $tceduInfoTmp['tabsList']       = explode('|', $tceduInfoTmp['tabs']);

                $historyList[$key]['tceduInfo'] = $tceduInfoTmp;
            }else if($value['type'] == 2){

                $courseInfoTmp = C::t('#tom_tcedu#tom_tcedu_course')->fetch_by_id($value['course_id']);
                $photoInfoTmp = C::t("#tom_tcedu#tom_tcedu_photo")->fetch_all_list(" AND course_id = {$courseInfoTmp['id']} AND type = 4 ", 'ORDER BY id DESC', 0, 1);
                if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
                    $courseInfoTmp['picurl'] = $photoInfoTmp[0]['picurlTmp'];
                }

                $tabsArrTmp = array();
                if(!empty($courseInfoTmp['tabs'])){
                    $tabsArrTmp = explode('|', $courseInfoTmp['tabs']);
                }

                $courseInfoTmp['tabsArr'] = $tabsArrTmp;

                $historyList[$key]['tceduInfo']     = $tceduInfoTmp;
                $historyList[$key]['courseInfo']    = $courseInfoTmp;
            }
        }
    }

    if(is_array($historyList) && !empty($historyList)){
        foreach ($historyList as $key => $value){
            if($type == 1){
                $outStr .= '<div class="edu_item dislay-flex">';
                    $outStr .= '<a class="edu_pic" href="plugin.php?id=tom_tcedu&site='.$site_id.'&mod=info&tcedu_id='.$value['tceduInfo']['id'].'">';
                        $outStr .= '<img src="'.$value['tceduInfo']['picurl'].'">';
                    $outStr .= '</a>';
                    $outStr .= '<div class="edu_main flex">';
                        $outStr .= '<a href="plugin.php?id=tom_tcedu&site='.$site_id.'&mod=info&tcedu_id='.$value['tceduInfo']['id'].'">';
                            $outStr .= '<div class="edu_name dislay-flex">';
                                $outStr .= '<span class="name flex">'.$value['tceduInfo']['name'].'</span>';
                                $outStr .= '<span class="time">'.$value['add_time'].'</span>';
                            $outStr .= '</div>';
                            $outStr .= '<div class="edu_info">';
                                $outStr .= '<span class="ping_socre">';
                                    $outStr .= '<span class="socre socre_bg"><i class="tciconfont tcicon-grade0"></i><i class="tciconfont tcicon-grade0"></i><i class="tciconfont tcicon-grade0"></i><i class="tciconfont tcicon-grade0"></i><i class="tciconfont tcicon-grade0"></i></span>';
                                    $outStr .= '<span class="socre socre_fill" style="width:'.$value['tceduInfo']['total_bili'].'%;"><i class="tciconfont tcicon-grade1"></i><i class="tciconfont tcicon-grade1"></i><i class="tciconfont tcicon-grade1"></i><i class="tciconfont tcicon-grade1"></i><i class="tciconfont tcicon-grade1"></i></span>';
                                $outStr .= '</span>';
                                $outStr .= '&nbsp;&nbsp;<span class="socre_num">'.$value['tceduInfo']['total_score'].'</span>';
                            $outStr .= '</div>';
                            $outStr .= '<div class="edu_address dislay-flex">';
                                $outStr .= '<span class="course_name flex"><i class="tciconfont tcicon-dingwei2"></i>'.$value['tceduInfo']['address'].'</span>';
                            $outStr .= '</div>';
                            if($value['tceduInfo']['tabsList']){
                                $outStr .= '<div class="edu_tabs clearfix">';
                                    foreach($value['tceduInfo']['tabsList'] as $tk => $tv){
                                        $outStr .= '<span class="tab">'.$tv.'</span>';
                                    }
                                $outStr .= '</div>';
                            }
                        $outStr .= '</a>';
                    $outStr .= '</div>';
                $outStr .= '</div>';
            }else if($type == 2){
                $outStr .= '<a class="course_item dislay-flex" href="plugin.php?id=tom_tcedu&site='.$site_id.'&mod=courseinfo&course_id='.$value['courseInfo']['id'].'">';
                    $outStr .= '<div class="course_pic">';
                        $outStr .= '<img src="'.$value['courseInfo']['picurl'].'">';
                        if($value['courseInfo']['type'] == 2){
                            $outStr .= '<span class="ty">'.lang('plugin/tom_tcedu', 'template_tyk').'</span>';
                        }
                    $outStr .= '</div>';
                    $outStr .= '<div class="course_main flex">';
                        $outStr .= '<div class="course_name dislay-flex">';
                            $outStr .= '<span class="name">'.$value['courseInfo']['name'].'</span>';
                            $outStr .= '<span class="time">'.$value['add_time'].'</span>';
                        $outStr .= '</div>';
                        $outStr .= '<div class="course_attr clearfix">';
                            $outStr .= '<span class="type">'.$classTypeArr[$value['courseInfo']['class_type']].'&nbsp;</span>';
                            if($value['courseInfo']['tabsArr']){
                                foreach($value['courseInfo']['tabsArr'] as $tk => $tv){
                                    $outStr .= '<span>'.$tv.'&nbsp;</span>';
                                }
                            }
                        $outStr .= '</div>';
                        $outStr .= '<div class="course_price">';
                            if($value['courseInfo']['show_buy_price'] > 0){
                                $outStr .= '<span class="buy_price">'.lang('plugin/tom_tcedu', 'yuan_ico').'<span>'.$value['courseInfo']['show_buy_price'].'</span></span>';
                            }else{
                                $outStr .= '<span class="free">'.lang('plugin/tom_tcedu', 'template_free').'</span>';
                            }
                            $outStr .= '<span class="edu_name">'.$value['tceduInfo']['name'].'</span>';
                        $outStr .= '</div>';
                    $outStr .= '</div>';
                $outStr .= '</a>';
            }
        }
    }else{
        $outStr = '205';
    }
    
    $outStr = tom_link_replace($outStr);
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
}



$count = C::t('#tom_tcedu#tom_tcedu_history')->fetch_all_count(" AND user_id={$__UserInfo['id']} AND type={$type} ");

$md5HostUrl = md5($_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=myhistory");

$ajaxClearHistoryUrl = "plugin.php?id=tom_tcedu:ajax&site={$site_id}&act=clear_history&type={$type}&formhash={$formhash}";
$ajaxLoadListUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=myhistory&act=list&type={$type}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:myhistory");