<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcedu_id   = intval($_GET['tcedu_id'])>0? intval($_GET['tcedu_id']):0;
$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
if($tceduInfo['id'] > 0 && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=mylist");exit;
}

$vipInfo = array();
if($tceduInfo['vip_id'] > 0){
    $vipInfo = C::t("#tom_tcedu#tom_tcedu_vip")->fetch_by_id($tceduInfo['vip_id']);
    
    if($tceduInfo['expire_status'] == 1 && $tceduInfo['expire_time'] >= TIMESTAMP){
        $courseCount = C::t("#tom_tcedu#tom_tcedu_course")->fetch_all_count("AND tcedu_id = {$tceduInfo['id']} AND type = 1 AND deleted = 0 ");
        $syCourseCount = $vipInfo['course_num'] - $courseCount;
        if($syCourseCount < 0){
            $syCourseCount = 0;
        }
        $vipInfo['courseCount'] = $courseCount;
        $vipInfo['syCourseCount'] = $syCourseCount;
        
        $experienceCourseCount = C::t("#tom_tcedu#tom_tcedu_course")->fetch_all_count("AND tcedu_id = {$tceduInfo['id']} AND type = 2 AND deleted = 0 ");
        $vipInfo['experienceCourseCount'] = $experienceCourseCount;
        
        if($vipInfo['open_experience_course'] == 1){
            $syExperienceCourseCount = $vipInfo['experience_course_num'] - $experienceCourseCount;
            if($syExperienceCourseCount < 0){
                $syExperienceCourseCount = 0;
            }
            $vipInfo['syExperienceCourseCount'] = $syExperienceCourseCount;
        }else{
            $vipInfo['experience_course_num'] = 0;
            $vipInfo['syExperienceCourseCount'] = 0;
        }
    }
}

$whereStr = " AND tcedu_id = {$tceduInfo['id']} AND deleted = 0 ";
if($type == 1){
    $whereStr.=" AND status = 1 AND shenhe_status = 1 ";
}else if($type == 2){
    $whereStr.=" AND shenhe_status = 2  ";
}else if($type == 3){
    $whereStr.=" AND shenhe_status = 3  ";
}

if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    $whereStr .= " AND search_text LIKE '%{$keyword}%' ";
}

$pagesize       = 8;
$start          = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count($whereStr);
$courseListTmp  = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_list($whereStr," ORDER BY id DESC ",$start,$pagesize);
$courseList = array();
if(is_array($courseListTmp) && !empty($courseListTmp)){
    foreach ($courseListTmp as $key => $value){
        $courseList[$key] = $value;

        $photoInfoTmp = C::t("#tom_tcedu#tom_tcedu_photo")->fetch_all_list(" AND course_id = {$value['id']} AND type = 4 ", 'ORDER BY id DESC', 0, 1);
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $courseCateInfoTmp = C::t('#tom_tcedu#tom_tcedu_course_cate')->fetch_by_id($value['course_cate_id']);
        
        $courseList[$key]['picurl']         = $picurlTmp;
        $courseList[$key]['clicks']         = $value['clicks'] + $value['virtual_clicks'];
        $courseList[$key]['courseCateInfo'] = $courseCateInfoTmp;
        $courseList[$key]['top_time']       = dgmdate($value['top_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mycourselist&type={$type}&page={$prePage}&keyword={$keyword}&tcedu_id={$tceduInfo['id']}";
$nextPageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mycourselist&type={$type}&page={$nextPage}&keyword={$keyword}&tcedu_id={$tceduInfo['id']}";

$pageUrl = "plugin.php?id=tom_tcedu&site={$site_id}&mod=mycourselist&type={$type}&keyword={$keyword}&tcedu_id={$tceduInfo['id']}";

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tcedu:ajax&site={$site_id}&act=updateCourseStatus&formhash={$formhash}";
$ajaxDelUrl = "plugin.php?id=tom_tcedu:ajax&site={$site_id}&act=delCourse&formhash={$formhash}";
$searchUrl = "plugin.php?id=tom_tcedu:ajax&site={$site_id}&act=get_mycourselist_search_url&type={$type}&tcedu_id={$tceduInfo['id']}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:mycourselist");