<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$bm_id = intval($_GET['bm_id'])>0? intval($_GET['bm_id']):0;

$bmInfo = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_by_id($bm_id);
if(!$bmInfo){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=coursebm");exit;
}

$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($bmInfo['tcedu_id']);
if($tceduInfo && ($tceduInfo['user_id'] == $__UserInfo['id'] || $tceduInfo['manage_user_id'] == $__UserInfo['id'])){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcedu&site={$site_id}&mod=coursebm");exit;
}

$courseInfo = C::t("#tom_tcedu#tom_tcedu_course")->fetch_by_id($bmInfo['course_id']);
$photoInfoTmp = C::t("#tom_tcedu#tom_tcedu_photo")->fetch_all_list(" AND course_id = {$courseInfo['id']} AND type = 4 ", 'ORDER BY id DESC', 0, 1);
if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
    $courseInfo['picurl'] = $photoInfoTmp[0]['picurlTmp'];
}

$eduPhotoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(" AND tcedu_id = {$tceduInfo['id']} AND type = 1 "," ORDER BY id DESC ",0,1);
if(is_array($eduPhotoInfoTmp) && !empty($eduPhotoInfoTmp[0])){
    $tceduInfo['picurl'] = $eduPhotoInfoTmp[0]['picurlTmp'];
}

$hexiaoEndTimeTmp = '';
if($courseInfo['hexiao_limit'] > 0){
    $hexiaoEndTimeStamp = 0;
    if($courseInfo['hexiao_limit'] == 1){
        $hexiaoEndTimeStamp = $courseInfo['hexiao_days'] * 86400 + $bmInfo['add_time'];
        $hexiaoEndTimeTmp = dgmdate($hexiaoEndTimeStamp,"Y-m-d H:i",$tomSysOffset);
    }else if($courseInfo['hexiao_limit'] == 2){
        $hexiaoEndTimeStamp = $courseInfo['hexiao_time'];
        $hexiaoEndTimeTmp = dgmdate($courseInfo['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
    }
    
    if($hexiaoEndTimeStamp < TIMESTAMP && $bmInfo['use_status'] == 0){
        $bmInfo['use_status'] = 2;
    }
}

$bmAttrListTmp = C::t("#tom_tcedu#tom_tcedu_course_bm_attr")->fetch_all_list(" AND bm_id = {$bmInfo['id']} ",'ORDER BY asort ASC,id DESC');
$bmAttrList = array();
if(is_array($bmAttrListTmp) && !empty($bmAttrListTmp)){
    foreach($bmAttrListTmp as $key => $value){
        $bmAttrList[$key] = $value;
        if($value['attr_type'] == 4){
            $bmAttrList[$key]['value'] = str_replace("|"," ", $value['value']);
        }
    }
}

$useLogListTmp = C::t("#tom_tcedu#tom_tcedu_course_bm_log")->fetch_all_list("AND bm_id = {$bmInfo['id']} ", 'ORDER BY id DESC');
$useLogList = array();
if(is_array($useLogListTmp) && !empty($useLogListTmp)){
    foreach($useLogListTmp as $key => $value){
        $useLogList[$key] = $value;
        
        $hexiaoUserInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['hexiao_user_id']);
        
        $useLogList[$key]['hexiaoUserInfo']  = $hexiaoUserInfoTmp;
        $useLogList[$key]['hexiao_time']     = dgmdate($value['hexiao_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}
$useLogCount = count($useLogList);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:coursebminfo");