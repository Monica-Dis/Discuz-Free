<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcedu_id = intval($_GET['tcedu_id'])>0 ? intval($_GET['tcedu_id']):0;

$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
if(empty($tceduInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=attr&tcedu_id={$tcedu_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $type           = isset($_GET['type'])? intval($_GET['type']):0;
    $value          = isset($_GET['value'])? addslashes($_GET['value']):'';
    $is_must        = isset($_GET['is_must'])? intval($_GET['is_must']):0;
    $is_show        = isset($_GET['is_show'])? intval($_GET['is_show']):0;
    $unit           = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $msg            = isset($_GET['msg'])? addslashes($_GET['msg']):'';
    $asort          = isset($_GET['asort'])? intval($_GET['asort']):10;
    
    $insertData = array();
    $insertData['tcedu_id']     = $tcedu_id;
    $insertData['name']         = $name;
    $insertData['type']         = $type;
    $insertData['value']        = $value;
    $insertData['is_must']      = $is_must;
    $insertData['is_show']      = $is_show;
    $insertData['unit']         = $unit;
    $insertData['msg']          = $msg;
    $insertData['asort']        = $asort;
    $insertData['add_time']     = TIMESTAMP;
    if(C::t('#tom_tcedu#tom_tcedu_attr')->insert($insertData)){
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
}else if($act == 'edit' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $attr_id        = intval($_GET['attr_id'])>0 ? intval($_GET['attr_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $type           = isset($_GET['type'])? intval($_GET['type']):0;
    $value          = isset($_GET['value'])? addslashes($_GET['value']):'';
    $is_must        = isset($_GET['is_must'])? intval($_GET['is_must']):0;
    $is_show        = isset($_GET['is_show'])? intval($_GET['is_show']):0;
    $unit           = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $msg            = isset($_GET['msg'])? addslashes($_GET['msg']):'';
    $asort          = isset($_GET['asort'])? intval($_GET['asort']):10;
    
    $updateData = array();
    $updateData['name']         = $name;
    $updateData['type']         = $type;
    $updateData['value']        = $value;
    $updateData['is_must']      = $is_must;
    $updateData['is_show']      = $is_show;
    $updateData['unit']         = $unit;
    $updateData['msg']          = $msg;
    $updateData['asort']        = $asort;
    C::t('#tom_tcedu#tom_tcedu_attr')->update($attr_id, $updateData);
        
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($act == 'update_is_must' && submitcheck('attr_id')){
    $outArr = array(
        'code'=> 1,
    );

    $attr_id    = intval($_GET['attr_id'])>0 ? intval($_GET['attr_id']):0;
    $is_must    = intval($_GET['is_must'])>0 ? intval($_GET['is_must']):0;

    $updateData = array();
    $updateData['is_must'] = $is_must;
    C::t('#tom_tcedu#tom_tcedu_attr')->update($attr_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'update_is_show' && submitcheck('attr_id')){
    $outArr = array(
        'code'=> 1,
    );

    $is_show        = intval($_GET['is_show'])>0 ? intval($_GET['is_show']):0;
    $attr_id        = intval($_GET['attr_id'])>0 ? intval($_GET['attr_id']):0;

    $updateData = array();
    $updateData['is_show'] = $is_show;
    C::t('#tom_tcedu#tom_tcedu_attr')->update($attr_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('attr_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $attr_id = intval($_GET['attr_id'])>0 ? intval($_GET['attr_id']):0;
    
    C::t('#tom_tcedu#tom_tcedu_attr')->delete_by_id($attr_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('attr_id')){
    $outArr = array(
        'code'=> 1,
    );

    $attr_id = intval($_GET['attr_id'])>0 ? intval($_GET['attr_id']):0;
    
    $attrInfo = C::t('#tom_tcedu#tom_tcedu_attr')->fetch_by_id($attr_id);
    
    $list = iconv_to_utf8($attrInfo);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;
$site_id    = intval($_GET['site_id'])>0? intval($_GET['site_id']):0;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = " AND tcedu_id={$tcedu_id} ";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_attr')->fetch_all_count($where);
$attrListTmp = C::t('#tom_tcedu#tom_tcedu_attr')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$attrList = array();
if(is_array($attrListTmp) && !empty($attrListTmp)){
    foreach ($attrListTmp as $key => $value) {
        $attrList[$key] = $value;
        
        $attrList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/attr");