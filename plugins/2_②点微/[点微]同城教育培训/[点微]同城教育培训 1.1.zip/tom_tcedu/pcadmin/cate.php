<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pid = intval($_GET['pid'])? intval($_GET['pid']):0;
if($pid > 0){
    $parentInfo = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_by_id($pid);
}

$modPcadminUrl = $pcadminUrl."&tmod=cate&pid={$pid}"; 

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name       = isset($_GET['name'])? addslashes($_GET['name']):'';
    $picurl     = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $status     = isset($_GET['status'])? intval($_GET['status']):0;
    $csort      = isset($_GET['csort'])? intval($_GET['csort']):100;
    
    $insertData = array();
    $insertData['name']             = $name;
    $insertData['pid']              = $pid;
    $insertData['picurl']           = $picurl;
    $insertData['status']           = $status;
    $insertData['csort']            = $csort;
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tcedu#tom_tcedu_cate')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && submitcheck('cate_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $cate_id    = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $name       = isset($_GET['name'])? addslashes($_GET['name']):'';
    $picurl     = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $status     = isset($_GET['status'])? intval($_GET['status']):0;
    $csort      = isset($_GET['csort'])? intval($_GET['csort']):100;
    
    $updateData = array();
    $updateData['name']             = $name;
    $updateData['pid']              = $pid;
    $updateData['picurl']           = $picurl;
    $updateData['status']           = $status;
    $updateData['csort']            = $csort;
    C::t('#tom_tcedu#tom_tcedu_cate')->update($cate_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('cate_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $cate_id = intval($_GET['cate_id'])>0 ? intval($_GET['cate_id']):0;
    
    C::t('#tom_tcedu#tom_tcedu_cate')->delete_by_id($cate_id);
    C::t('#tom_tcedu#tom_tcedu_cate')->delete_by_pid($cate_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('cate_id')){
    $outArr = array(
        'code'=> 1,
    );

    $cate_id = intval($_GET['cate_id'])>0 ? intval($_GET['cate_id']):0;

    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcedu#tom_tcedu_cate')->update($cate_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('cate_id')){
    $outArr = array(
        'code'=> 1,
    );

    $cate_id = intval($_GET['cate_id'])>0 ? intval($_GET['cate_id']):0;

    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcedu#tom_tcedu_cate')->update($cate_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('cate_id')){
    $outArr = array(
        'code'=> 1,
    );

    $cate_id = intval($_GET['cate_id'])>0 ? intval($_GET['cate_id']):0;
    
    $cateInfo = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_by_id($cate_id);
    $cateInfo['picurlTmp'] = get_file_url($cateInfo['picurl']);
    
    $list = iconv_to_utf8($cateInfo);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}else if($act == 'import' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'code'=> 1,
    );
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/config/import.data.php';
    
    foreach ($catesArr as $key => $value){
        $insertData = array();
        $insertData['name']     = $value['name'];
        $insertData['picurl']   = $value['picurl'];
        $insertData['status']   = 1;
        $insertData['csort']    = $key;
        $insertData['add_time'] = TIMESTAMP;
        $parent_id = C::t('#tom_tcedu#tom_tcedu_cate')->insert($insertData, true);
        if($parent_id > 0){
            foreach ($value['childs'] as $k => $v){
                $insertData = array();
                $insertData['pid']      = $parent_id;
                $insertData['name']     = $v;
                $insertData['status']   = 1;
                $insertData['csort']    = $k;
                $insertData['add_time'] = TIMESTAMP;
                C::t('#tom_tcedu#tom_tcedu_cate')->insert($insertData);
            }
        }
    }
    
    $outArr = array(
        'code'  => 200,
    );
    echo json_encode($outArr); exit;
}

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):50;

$where = " AND pid = {$pid} ";
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_count($where);
$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list($where," ORDER BY csort ASC,id DESC ",$start,$pagesize);
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach ($cateListTmp as $key => $value) {
        
        $cateList[$key] = $value;
        $cateList[$key]['picurl']      = get_file_url($value['picurl']);
        $cateList[$key]['add_time']    = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/cate"); 