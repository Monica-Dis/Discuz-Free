<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcedu_id = intval($_GET['tcedu_id'])>0 ? intval($_GET['tcedu_id']):0;

$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
if(empty($tceduInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=coursecate&tcedu_id={$tcedu_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $csort          = isset($_GET['csort'])? intval($_GET['csort']):10;
    
    $insertData = array();
    $insertData['tcedu_id']     = $tcedu_id;
    $insertData['name']         = $name;
    $insertData['csort']        = $csort;
    $insertData['add_time']     = TIMESTAMP;
    if(C::t('#tom_tcedu#tom_tcedu_course_cate')->insert($insertData)){
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}else if($act == 'edit' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $course_cate_id = intval($_GET['course_cate_id'])>0 ? intval($_GET['course_cate_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $csort          = isset($_GET['csort'])? intval($_GET['csort']):10;
    
    $courseCateInfo = C::t("#tom_tcedu#tom_tcedu_course_cate")->fetch_by_id($course_cate_id);
    if($courseCateInfo && $courseCateInfo['tcedu_id'] == $tcedu_id){ }else{
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['name']         = $name;
    $updateData['csort']        = $csort;
    C::t('#tom_tcedu#tom_tcedu_course_cate')->update($course_cate_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('course_cate_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $course_cate_id = intval($_GET['course_cate_id'])>0 ? intval($_GET['course_cate_id']):0;
    
    C::t('#tom_tcedu#tom_tcedu_course_cate')->delete_by_id($course_cate_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('course_cate_id')){
    $outArr = array(
        'code'=> 1,
    );

    $course_cate_id = intval($_GET['course_cate_id'])>0 ? intval($_GET['course_cate_id']):0;
    
    $courseCateInfo = C::t('#tom_tcedu#tom_tcedu_course_cate')->fetch_by_id($course_cate_id);
    
    $list = iconv_to_utf8($courseCateInfo);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = " AND tcedu_id = {$tcedu_id} ";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_course_cate')->fetch_all_count($where);
$courseCateListTmp = C::t('#tom_tcedu#tom_tcedu_course_cate')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$courseCateList = array();
if(is_array($courseCateListTmp) && !empty($courseCateListTmp)){
    foreach ($courseCateListTmp as $key => $value) {
        $courseCateList[$key] = $value;
        
        $courseCateList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/coursecate");