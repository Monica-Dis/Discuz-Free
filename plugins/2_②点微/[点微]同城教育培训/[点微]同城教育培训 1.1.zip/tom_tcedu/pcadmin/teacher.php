<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcedu_id = intval($_GET['tcedu_id'])>0 ? intval($_GET['tcedu_id']):0;

$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
if(empty($tceduInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=teacher&tcedu_id={$tcedu_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $avatar         = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $subject        = isset($_GET['subject'])? addslashes($_GET['subject']):'';
    $teach_age      = isset($_GET['teach_age'])? intval($_GET['teach_age']):0;
    $desc           = isset($_GET['desc'])? addslashes($_GET['desc']):'';
    $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
    $open_hexiao    = isset($_GET['open_hexiao'])? intval($_GET['open_hexiao']):0;
    $tsort          = isset($_GET['tsort'])? intval($_GET['tsort']):10;
    
    $teacherInfoTmp = C::t("#tom_tcedu#tom_tcedu_teacher")->fetch_all_list(" AND tcedu_id = {$tcedu_id} AND user_id = {$user_id} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($teacherInfoTmp) && !empty($teacherInfoTmp[0])){
        $outArr = array(
            'code'=> 1001,
            'msg'=> $Lang['teacher_has_user_err'],
        );
        $outArr = iconv_to_utf8($outArr);
        echo json_encode($outArr); exit;
    }
    
    $insertData = array();
    $insertData['tcedu_id']     = $tcedu_id;
    $insertData['user_id']      = $user_id;
    $insertData['name']         = $name;
    $insertData['avatar']       = $avatar;
    $insertData['subject']      = $subject;
    $insertData['teach_age']    = $teach_age;
    $insertData['desc']         = $desc;
    $insertData['content']      = $content;
    $insertData['open_hexiao']  = $open_hexiao;
    $insertData['tsort']        = $tsort;
    $insertData['add_time']     = TIMESTAMP;
    if(C::t('#tom_tcedu#tom_tcedu_teacher')->insert($insertData)){
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 1001,
            'msg'=> $Lang['error'],
        );
        $outArr = iconv_to_utf8($outArr);
        echo json_encode($outArr); exit;
    }
}else if($act == 'edit' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $teacher_id     = intval($_GET['teacher_id'])>0 ? intval($_GET['teacher_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $avatar         = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $subject        = isset($_GET['subject'])? addslashes($_GET['subject']):'';
    $teach_age      = isset($_GET['teach_age'])? intval($_GET['teach_age']):0;
    $desc           = isset($_GET['desc'])? addslashes($_GET['desc']):'';
    $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
    $open_hexiao    = isset($_GET['open_hexiao'])? intval($_GET['open_hexiao']):0;
    $tsort          = isset($_GET['tsort'])? intval($_GET['tsort']):10;
    
    $teacherInfoTmp = C::t("#tom_tcedu#tom_tcedu_teacher")->fetch_all_list(" AND tcedu_id = {$tcedu_id} AND user_id = {$user_id} AND id != {$teacher_id} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($teacherInfoTmp) && !empty($teacherInfoTmp[0])){
        $outArr = array(
            'code'=> 1001,
            'msg'=> $Lang['teacher_has_user_err'],
        );
        $outArr = iconv_to_utf8($outArr);
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['user_id']      = $user_id;
    $updateData['name']         = $name;
    $updateData['avatar']       = $avatar;
    $updateData['subject']      = $subject;
    $updateData['teach_age']    = $teach_age;
    $updateData['desc']         = $desc;
    $updateData['content']      = $content;
    $updateData['open_hexiao']  = $open_hexiao;
    $updateData['tsort']        = $tsort;
    C::t('#tom_tcedu#tom_tcedu_teacher')->update($teacher_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('teacher_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $teacher_id = intval($_GET['teacher_id'])>0 ? intval($_GET['teacher_id']):0;
    
    $updateData['status'] = 1;
    C::t('#tom_tcedu#tom_tcedu_teacher')->update($teacher_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('teacher_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $teacher_id = intval($_GET['teacher_id'])>0 ? intval($_GET['teacher_id']):0;
    
    $updateData['status'] = 0;
    C::t('#tom_tcedu#tom_tcedu_teacher')->update($teacher_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'update_open_hexiao' && submitcheck('teacher_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $teacher_id     = intval($_GET['teacher_id'])>0 ? intval($_GET['teacher_id']):0;
    $open_hexiao    = intval($_GET['open_hexiao'])>0 ? intval($_GET['open_hexiao']):0;
    
    $updateData['open_hexiao'] = $open_hexiao;
    C::t('#tom_tcedu#tom_tcedu_teacher')->update($teacher_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'del' && submitcheck('teacher_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $teacher_id = intval($_GET['teacher_id'])>0 ? intval($_GET['teacher_id']):0;
    
    C::t('#tom_tcedu#tom_tcedu_teacher')->delete_by_id($teacher_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('teacher_id')){
    $outArr = array(
        'code'=> 1,
    );

    $teacher_id = intval($_GET['teacher_id'])>0 ? intval($_GET['teacher_id']):0;
    
    $teacherInfo = C::t('#tom_tcedu#tom_tcedu_teacher')->fetch_by_id($teacher_id);
    $teacherInfo['avatarTmp'] = get_file_url($teacherInfo['avatar']);
    
    $list = iconv_to_utf8($teacherInfo);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = " AND tcedu_id = {$tcedu_id} ";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_teacher')->fetch_all_count($where);
$teacherListTmp = C::t('#tom_tcedu#tom_tcedu_teacher')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$teacherList = array();
if(is_array($teacherListTmp) && !empty($teacherListTmp)){
    foreach ($teacherListTmp as $key => $value) {
        $teacherList[$key] = $value;
        
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        
        $teacherList[$key]['avatar']        = get_file_url($value['avatar']);
        $teacherList[$key]['userInfo']      = $userInfoTmp;
        $teacherList[$key]['add_time']      = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/teacher");