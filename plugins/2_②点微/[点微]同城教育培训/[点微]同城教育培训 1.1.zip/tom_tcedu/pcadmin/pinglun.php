<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=pinglun";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('pinglun_id')){
    $outArr = array(
        'code'=> 1,
    );

    $pinglun_id = intval($_GET['pinglun_id'])>0? intval($_GET['pinglun_id']):0;
    
    $pinglunInfo = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_by_id($pinglun_id);
    $tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($pinglunInfo['tcedu_id']);
    
    $totalPinglunCount = $tceduInfo['pinglun_count'] - 1;
    
    $old_huanjing_score = $tceduInfo['pinglun_count'] * $tceduInfo['huanjing_score'];
    $old_fuwu_score     = $tceduInfo['pinglun_count'] * $tceduInfo['fuwu_score'];
    $old_teacher_score  = $tceduInfo['pinglun_count'] * $tceduInfo['teacher_score'];
    $old_total_score    = $tceduInfo['pinglun_count'] * $tceduInfo['total_score'];
    
    if($totalPinglunCount <= 0){
        $new_huanjing_score = $tceduConfig['ruzhu_default_score'];
        $new_fuwu_score     = $tceduConfig['ruzhu_default_score'];
        $new_teacher_score  = $tceduConfig['ruzhu_default_score'];
        $new_total_score    = $tceduConfig['ruzhu_default_score'];
    }else{
        $new_huanjing_score = round(($old_huanjing_score - $pinglunInfo['huanjing_score']) / $totalPinglunCount, 3);
        $new_fuwu_score     = round(($old_fuwu_score - $pinglunInfo['fuwu_score']) / $totalPinglunCount, 3);
        $new_teacher_score  = round(($old_teacher_score - $pinglunInfo['teacher_score']) / $totalPinglunCount, 3);
        $new_total_score    = round(($old_total_score - $pinglunInfo['total_score']) / $totalPinglunCount, 3);
    }
    
    $updateData = array();
    $updateData['huanjing_score']   = $new_huanjing_score;
    $updateData['fuwu_score']       = $new_fuwu_score;
    $updateData['teacher_score']    = $new_teacher_score;
    $updateData['total_score']      = $new_total_score;
    $updateData['pinglun_count']    = $totalPinglunCount;
    C::t('#tom_tcedu#tom_tcedu')->update($tceduInfo['id'], $updateData);
    
    C::t('#tom_tcedu#tom_tcedu_pinglun')->delete_by_id($pinglun_id);
    C::t('#tom_tcedu#tom_tcedu_photo')->delete_by_pinglun_id($pinglun_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('pinglun_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $pinglunIdsArr = array();
    if(is_array($_GET['pinglun_ids'])){
        foreach($_GET['pinglun_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $pinglunIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($pinglunIdsArr)){
        $pinglunIdsStr = implode(',', $pinglunIdsArr);
        $pinglunList = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_all_list(" AND id IN({$pinglunIdsStr}) ");
        foreach ($pinglunList as $key => $value){
            
            $tceduInfoTmp = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($value['tcedu_id']);

            $totalPinglunCount = $tceduInfoTmp['pinglun_count'] - 1;

            $old_huanjing_score = $tceduInfoTmp['pinglun_count'] * $tceduInfoTmp['huanjing_score'];
            $old_fuwu_score     = $tceduInfoTmp['pinglun_count'] * $tceduInfoTmp['fuwu_score'];
            $old_teacher_score  = $tceduInfoTmp['pinglun_count'] * $tceduInfoTmp['teacher_score'];
            $old_total_score    = $tceduInfoTmp['pinglun_count'] * $tceduInfoTmp['total_score'];
            
            if($totalPinglunCount <= 0){
                $new_huanjing_score = $tceduConfig['ruzhu_default_score'];
                $new_fuwu_score     = $tceduConfig['ruzhu_default_score'];
                $new_teacher_score  = $tceduConfig['ruzhu_default_score'];
                $new_total_score    = $tceduConfig['ruzhu_default_score'];
            }else{
                $new_huanjing_score = round(($old_huanjing_score - $value['huanjing_score']) / $totalPinglunCount, 3);
                $new_fuwu_score     = round(($old_fuwu_score - $value['fuwu_score']) / $totalPinglunCount, 3);
                $new_teacher_score  = round(($old_teacher_score - $value['teacher_score']) / $totalPinglunCount, 3);
                $new_total_score    = round(($old_total_score - $value['total_score']) / $totalPinglunCount, 3);
            }
            
            $updateData = array();
            $updateData['huanjing_score']   = $new_huanjing_score;
            $updateData['fuwu_score']       = $new_fuwu_score;
            $updateData['teacher_score']    = $new_teacher_score;
            $updateData['total_score']      = $new_total_score;
            $updateData['pinglun_count']    = $totalPinglunCount;
            C::t('#tom_tcedu#tom_tcedu')->update($tceduInfoTmp['id'], $updateData);
            
            C::t('#tom_tcedu#tom_tcedu_pinglun')->delete_by_id($value);
            C::t('#tom_tcedu#tom_tcedu_photo')->delete_by_pinglun_id($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$tcedu_id   = intval($_GET['tcedu_id'])>0? intval($_GET['tcedu_id']):0;
$course_id  = intval($_GET['course_id'])>0? intval($_GET['course_id']):0;
$user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$type       = intval($_GET['type'])>0? intval($_GET['type']):1;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = "";
if($tcedu_id > 0){
    $where .= " AND tcedu_id={$tcedu_id} ";
}
if($course_id > 0){
    $where .= " AND course_id={$course_id} ";
}
if($user_id > 0){
    $where .= " AND user_id={$user_id} ";
}
if($type == 1){
    $where .= " AND type=1 ";
}else if($type == 2){
    $where .= " AND type=2 ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_all_count($where);
$pinglunListTmp = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_all_list($where, "ORDER BY id DESC", $start, $pagesize);
$pinglunList = array();
if(!empty($pinglunListTmp)){
    foreach($pinglunListTmp as $key => $value){
        $pinglunList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $pinglunPhotoListTmpTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(" AND type = 3 AND pinglun_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);
        $photoListTmp = array();
        if(!empty($pinglunPhotoListTmpTmp)){
            foreach($pinglunPhotoListTmpTmp as $pk => $pv){
                $photoListTmp[] = get_file_url($pv['picurl']);
            }
        }
        
        $tceduInfoTmp = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($value['tcedu_id']);
        $courseInfoTmp = C::t('#tom_tcedu#tom_tcedu_course')->fetch_by_id($value['course_id']);
        
        $pinglunList[$key]['userInfo']      = $userInfoTmp;
        $pinglunList[$key]['photoList']     = $photoListTmp;
        $pinglunList[$key]['tceduInfo']     = $tceduInfoTmp;
        $pinglunList[$key]['courseInfo']    = $courseInfoTmp;
        $pinglunList[$key]['add_time']      = dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/pinglun");