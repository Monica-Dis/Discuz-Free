<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcedu_id = intval($_GET['tcedu_id'])>0? intval($_GET['tcedu_id']):0;
$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
if(empty($tceduInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=guanzu&tcedu_id={$tcedu_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('guanzu_id')){
    $outArr = array(
        'code'=> 1,
    );

    $guanzu_id = intval($_GET['guanzu_id'])>0? intval($_GET['guanzu_id']):0;
    
    C::t('#tom_tcedu#tom_tcedu_guanzu')->delete_by_id($guanzu_id);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('guanzu_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $guanzuIdsArr = array();
    if(is_array($_GET['guanzu_ids'])){
        foreach($_GET['guanzu_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $guanzuIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($guanzuIdsArr)){
        foreach ($guanzuIdsArr as $key => $value){
            C::t('#tom_tcedu#tom_tcedu_guanzu')->delete_by_id($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = "AND tcedu_id={$tcedu_id}";
if($user_id > 0){
    $where .= " AND user_id={$user_id} ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_guanzu')->fetch_all_count($where);
$guanzuListTmp = C::t('#tom_tcedu#tom_tcedu_guanzu')->fetch_all_list($where, "ORDER BY id ASC", $start, $pagesize);
$guanzuList = array();
if(is_array($guanzuListTmp) && !empty($guanzuListTmp)){
    foreach($guanzuListTmp as $key => $value){
        $guanzuList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $guanzuList[$key]['userInfo']   = $userInfoTmp;
        $guanzuList[$key]['add_time']   = dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/guanzu");