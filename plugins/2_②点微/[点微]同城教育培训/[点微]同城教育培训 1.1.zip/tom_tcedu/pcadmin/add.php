<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=add";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $manage_user_id     = isset($_GET['manage_user_id'])? intval($_GET['manage_user_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $theme_color        = isset($_GET['theme_color'])? addslashes($_GET['theme_color']):'';
    $edu_xm             = isset($_GET['edu_xm'])? addslashes($_GET['edu_xm']):'';
    $edu_tel            = isset($_GET['edu_tel'])? addslashes($_GET['edu_tel']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tabs_diy           = isset($_GET['tabs_diy'])? addslashes($_GET['tabs_diy']):'';
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $kefu_qrcode        = isset($_GET['kefu_qrcode'])? addslashes($_GET['kefu_qrcode']):'';
    $business_licence   = isset($_GET['business_licence'])? addslashes($_GET['business_licence']):'';
    $virtual_clicks     = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $video_pic          = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_url          = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $longitude          = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $latitude           = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    
    $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    if(is_array($userInfoTmp) && !empty($userInfoTmp)){ }else{
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $tabsArr = array();
    foreach($_GET['tabs'] as $key => $value){
        $value = addslashes($value);
        if(!empty($value)){
            $tabsArr[] = $value;
        }
    }
    
    if(!empty($tabs_diy)){
        $tabs_diy = trim($tabs_diy);
        $tabs_diy_arr = explode(" ", $tabs_diy);
        foreach($tabs_diy_arr as $key => $value){
            $value = trim($value);
            if(!empty($value)){
                $tabsArr[] = $value;
            }
        }
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photosort_") !== false){
            $kk = intval(ltrim($key, "photosort_"));
            $photoArr[$kk]['sort'] = addslashes($value);
        }
    }
    
    $cateIdsArr = array();
    foreach($_GET['cate'] as $key => $value){
        $value = intval($value);
        if(!empty($value)){
            $cateIdsArr[] = $value;
        }
    }
    
    $cateChildIdsArr = array();
    foreach($_GET['cate_child'] as $key => $value){
        $value = intval($value);
        if(!empty($value)){
            $cateChildIdsArr[] = $value;
        }
    }
    
    $cateIdsList = array_merge($cateIdsArr, $cateChildIdsArr);
    $cateIdsStr = implode(',', $cateIdsList);
    
    $cateListTmp = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_all_list(" AND id IN({$cateIdsStr}) ", 'ORDER BY csort ASC, id DESC');
    $cateName = '';
    if(is_array($cateListTmp) && !empty($cateListTmp)){
        foreach($cateListTmp as $key => $value){
            $cateName .= $value['name'];
        }
    }
    
    $tabsStr = implode('|', $tabsArr);
    
    $search_text = $name.'|'.$tel.'|'.$tabsStr.'|'.$cateName;
    
    $insertData = array();
    $insertData['site_id']              = $site_id;
    $insertData['user_id']              = $user_id;
    $insertData['manage_user_id']       = $manage_user_id;
    $insertData['name']                 = $name;
    $insertData['theme_color']          = $theme_color;
    $insertData['cate_ids']             = '|'.implode('|', $cateIdsArr).'|';
    $insertData['cate_child_ids']       = '|'.implode('|', $cateChildIdsArr).'|';
    $insertData['city_id']              = $city_id;
    $insertData['area_id']              = $area_id;
    $insertData['street_id']            = $street_id;
    $insertData['longitude']            = $longitude;
    $insertData['latitude']             = $latitude;
    $insertData['address']              = $address;
    $insertData['tabs']                 = $tabsStr;
    $insertData['edu_xm']               = $edu_xm;
    $insertData['edu_tel']              = $edu_tel;
    $insertData['tel']                  = $tel;
    $insertData['admin_edit']           = $admin_edit;
    $insertData['content']              = $content;
    if(!empty($video_pic) && !empty($video_url)){
        $insertData['video_status']         = 1;
    }
    $insertData['kefu_qrcode']          = $kefu_qrcode;
    $insertData['business_licence']     = $business_licence;
    $insertData['video_pic']            = $video_pic;
    $insertData['video_url']            = $video_url;
    $insertData['search_text']          = $search_text;
    $insertData['virtual_clicks']       = $virtual_clicks;
    $insertData['shenhe_status']        = 1;
    $insertData['status']               = 0;
    $insertData['huanjing_score']       = $tceduConfig['ruzhu_default_score'];
    $insertData['fuwu_score']           = $tceduConfig['ruzhu_default_score'];
    $insertData['teacher_score']        = $tceduConfig['ruzhu_default_score'];
    $insertData['total_score']          = $tceduConfig['ruzhu_default_score'];
    $insertData['is_ok']                = 1;
    $insertData['update_time']          = TIMESTAMP;
    $insertData['add_time']             = TIMESTAMP;
    $tcedu_id = C::t('#tom_tcedu#tom_tcedu')->insert($insertData, true);
    if($tcedu_id > 0){
        if(!empty($picurl)){
            $insertData = array();
            $insertData['tcedu_id']  = $tcedu_id;
            $insertData['type']      = 1;
            $insertData['picurl']    = $picurl;
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcedu#tom_tcedu_photo')->insert($insertData);
        }
        
        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['tcedu_id']     = $tcedu_id;
                $insertData['type']         = 2;
                $insertData['picurl']       = $value['picurl'];
                $insertData['psort']        = $value['sort'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tcedu#tom_tcedu_photo')->insert($insertData);
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$eduColorList = array();
$edu_color_str = str_replace("\r\n","{n}",$tceduConfig['edu_color_list']); 
$edu_color_str = str_replace("\n","{n}",$edu_color_str);
$edu_color_arr = explode("{n}", $edu_color_str);
if(is_array($edu_color_arr) && !empty($edu_color_arr)){
    foreach ($edu_color_arr as $key => $value){
        $arrTmp = explode("|", $value);
        
        $eduColorList[$key]['color']    = $arrTmp[0];
        $eduColorList[$key]['name']     = $arrTmp[1];
    }
}

$city_id = 0;
$cityInfoTmp = array();
if(!empty($tongchengConfig['city_id'])){
    $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
}
if(!empty($cityInfoTmp)){
    $city_id = $cityInfoTmp['id'];
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($city_id);

$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ");
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $itemInfoTmp = array();
        
        $itemInfoTmp['title']   = $value['name'];
        $itemInfoTmp['id']      = $value['id'];
        $itemInfoTmp['field']   = $value['name'];
        
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][] = $itemInfoTmp;
        }else{
            $cateList[$value['id']] = $itemInfoTmp;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['children'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$eduTabsArr = array();
$edu_tab_str = str_replace("\r\n","{n}",$tceduConfig['edu_tab_list']); 
$edu_tab_str = str_replace("\n","{n}",$edu_tab_str);
$edu_tab_arr = explode("{n}", $edu_tab_str);
if(is_array($edu_tab_arr) && !empty($edu_tab_arr)){
    foreach ($edu_tab_arr as $key => $value){
        $value = trim($value);

        if(!empty($value)){
            $eduTabsArr[] = $value;
        }
    }
}

$addUrl = $modPcadminUrl."&act=add";

$ossBatchUrl = 'plugin.php?id=tom_tcedu:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcedu:qiniuBatch';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/add");