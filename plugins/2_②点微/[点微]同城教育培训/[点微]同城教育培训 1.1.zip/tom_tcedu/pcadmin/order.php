<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=order";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$order_no           = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$tcedu_id           = isset($_GET['tcedu_id'])? intval($_GET['tcedu_id']):0;
$course_id          = isset($_GET['course_id'])? intval($_GET['course_id']):0;
$course_bm_id       = isset($_GET['course_bm_id'])? intval($_GET['course_bm_id']):0;
$start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
$end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
$order_type         = isset($_GET['order_type'])? intval($_GET['order_type']):0;
$order_status       = isset($_GET['order_status'])? intval($_GET['order_status']):0;
$vip_pay_status     = isset($_GET['vip_pay_status'])? intval($_GET['vip_pay_status']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = "";
if(!empty($site_id)){
    $where.=" AND site_id={$site_id} ";
}
if(!empty($order_no)){
    $where.=" AND order_no='{$order_no}' ";
}
if(!empty($order_type)){
    $where.=" AND order_type={$order_type} ";
}
if(!empty($order_status)){
    $where.=" AND order_status={$order_status} ";
}
if(!empty($user_id)){
    $where.=" AND user_id={$user_id} ";
}
if(!empty($tcedu_id)){
    $where.=" AND tcedu_id={$tcedu_id} ";
}
if(!empty($course_id)){
    $where.=" AND course_id={$course_id} ";
}
if(!empty($course_bm_id)){
    $where.=" AND course_bm_id={$course_bm_id} ";
}
if(!empty($vip_pay_status)){
    $where.=" AND vip_pay_status={$vip_pay_status} ";
}
if(!empty($start_time)){
    $startTime = strtotime($start_time);
    $where.=" AND order_time >=  {$startTime} ";
}
if(!empty($end_time)){
    $endTime = strtotime($end_time);
    $where.=" AND order_time < {$endTime} ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_order')->fetch_all_count($where);
$orderListTmp = C::t('#tom_tcedu#tom_tcedu_order')->fetch_all_list($where,"ORDER BY order_time DESC,id DESC",$start,$pagesize);
$orderList = array();
if(is_array($orderListTmp) && !empty($orderListTmp)){
    foreach($orderListTmp as $key => $value){
        $orderList[$key] = $value;
        
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        
        $site_name_tmp = $Lang['sites_one'];
        if($value['site_id'] > 1){
            $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
            $site_name_tmp = $siteInfoTmp['name'];
        }
        
        if($value['order_type'] == 2 || $value['order_type'] == 3){
            $vipInfoTmp = C::t("#tom_tcedu#tom_tcedu_vip")->fetch_by_id($value['vip_id']);
            $orderList[$key]['vipInfo'] = $vipInfoTmp;
        }
        
        $bmInfoTmp = array();
        if($value['order_type'] == 1 && $value['course_bm_id'] > 0){
            $bmInfoTmp = C::t("#tom_tcedu#tom_tcedu_course_bm")->fetch_by_id($value['course_bm_id']);
        }
        
        $orderList[$key]['userInfo']        = $userInfoTmp;
        $orderList[$key]['site_name']       = $site_name_tmp;
        $orderList[$key]['bmInfo']          = $bmInfoTmp;
        $orderList[$key]['order_time']      = dgmdate($value['order_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $orderList[$key]['payTime']         = dgmdate($value['pay_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&order_no={$order_no}&order_status={$order_status}&user_id={$user_id}&tcedu_id={$tcedu_id}&course_id={$course_id}&course_bm_id={$course_bm_id}&start_time={$start_time}&end_time={$end_time}&order_type={$order_type}&vip_pay_status={$vip_pay_status}";

$todayPayPrice = C::t('#tom_tcedu#tom_tcedu_order')->fetch_all_pay_price(" AND pay_time > {$nowDayTime} AND order_status=2 ");
$monthPayPrice = C::t('#tom_tcedu#tom_tcedu_order')->fetch_all_pay_price(" AND pay_time > {$nowMonthTime} AND order_status=2 ");
$allPayPrice = C::t('#tom_tcedu#tom_tcedu_order')->fetch_all_pay_price(" AND order_status = 2 ");

if(!empty($where)){
    $searchAllPayPrice = C::t('#tom_tcedu#tom_tcedu_order')->fetch_all_pay_price($where);
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/order");