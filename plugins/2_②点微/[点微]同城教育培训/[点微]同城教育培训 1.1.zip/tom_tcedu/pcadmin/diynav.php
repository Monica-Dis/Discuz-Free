<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=diynav";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $type           = isset($_GET['type'])? intval($_GET['type']):0;
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id  = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $link           = isset($_GET['link'])? addslashes($_GET['link']):'';
    $dsort          = isset($_GET['dsort'])? intval($_GET['dsort']):10;
    
    $insertData = array();
    $insertData['site_id']      = $site_id;
    $insertData['name']         = $name;
    $insertData['type']         = $type;
    $insertData['picurl']       = $picurl;
    $insertData['cate_id']      = $cate_id;
    $insertData['cate_child_id']= $cate_child_id;
    $insertData['link']         = $link;
    $insertData['dsort']        = $dsort;
    $insertData['add_time']     = TIMESTAMP;
    C::t('#tom_tcedu#tom_tcedu_diynav')->insert($insertData);
        
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $diynav_id      = isset($_GET['diynav_id'])? intval($_GET['diynav_id']):0;
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $type           = isset($_GET['type'])? intval($_GET['type']):0;
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id  = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $link           = isset($_GET['link'])? addslashes($_GET['link']):'';
    $dsort          = isset($_GET['dsort'])? intval($_GET['dsort']):10;
    
    $updateData = array();
    $updateData['site_id']      = $site_id;
    $updateData['name']         = $name;
    $updateData['type']         = $type;
    $updateData['picurl']       = $picurl;
    $updateData['cate_id']      = $cate_id;
    $updateData['cate_child_id']= $cate_child_id;
    $updateData['link']         = $link;
    $updateData['dsort']        = $dsort;
    C::t('#tom_tcedu#tom_tcedu_diynav')->update($diynav_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('diynav_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $diynav_id = intval($_GET['diynav_id'])>0 ? intval($_GET['diynav_id']):0;
    
    C::t('#tom_tcedu#tom_tcedu_diynav')->delete_by_id($diynav_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('diynav_id')){
    $outArr = array(
        'code'=> 1,
    );

    $diynav_id = intval($_GET['diynav_id'])>0 ? intval($_GET['diynav_id']):0;
    
    $diynavInfo = C::t('#tom_tcedu#tom_tcedu_diynav')->fetch_by_id($diynav_id);
    $diynavInfo['picurlTmp'] = get_file_url($diynavInfo['picurl']);
    
    $cateChildList = array();
    if($diynavInfo['cate_id'] > 0){
        $cateChildListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" AND pid = {$diynavInfo['cate_id']} "," ORDER BY csort ASC,id DESC ");
        if(is_array($cateChildListTmp) && !empty($cateChildListTmp)){
            foreach($cateChildListTmp as $key => $value){
                $cateChildList[$key] = $value;
            }
        }
    }
    
    $diynavInfo['cateChildList'] = $cateChildList;
    
    $list = iconv_to_utf8($diynavInfo);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}else if($act == 'load_child' && submitcheck('cate_id')){
    $outArr = array(
        'code'=> 1,
    );

    $cate_id = intval($_GET['cate_id'])>0 ? intval($_GET['cate_id']):0;
    
    $cateChildListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" AND pid = {$cate_id} "," ORDER BY csort ASC,id DESC ");
    $cateChildList = array();
    if(is_array($cateChildListTmp) && !empty($cateChildListTmp)){
        foreach($cateChildListTmp as $key => $value){
            $cateChildList[$key] = $value;
        }
    }
    
    $list = iconv_to_utf8($cateChildList);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" AND pid = 0 "," ORDER BY csort ASC,id DESC ");
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$value['id']] = $value;
    }
}

$where = '';

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_diynav')->fetch_all_count($where);
$diynavListTmp = C::t('#tom_tcedu#tom_tcedu_diynav')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$diynavList = array();
if(is_array($diynavListTmp) && !empty($diynavListTmp)){
    foreach ($diynavListTmp as $key => $value) {
        $diynavList[$key] = $value;
        
        if($value['cate_id'] > 0){
            $cateInfoTmp = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_by_id($value['cate_id']);
            $diynavList[$key]['cateInfo'] = $cateInfoTmp;
        }
        if($value['cate_child_id'] > 0){
            $cateChildInfoTmp = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_by_id($value['cate_child_id']);
            $diynavList[$key]['cateChildInfo'] = $cateChildInfoTmp;
        }
        
        $diynavList[$key]['siteInfo']   = $sitesList[$value['site_id']];
        $diynavList[$key]['picurl']     = get_file_url($value['picurl']);
        $diynavList[$key]['add_time']   = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/diynav");