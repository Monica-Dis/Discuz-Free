<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=course";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'show' && submitcheck('course_id')){
    $outArr = array(
        'code'=> 1,
    );

    $course_id = intval($_GET['course_id'])>0 ? intval($_GET['course_id']):0;

    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tcedu#tom_tcedu_course')->update($course_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('course_id')){
    $outArr = array(
        'code'=> 1,
    );

    $course_id = intval($_GET['course_id'])>0 ? intval($_GET['course_id']):0;

    $updateData = array();
    $updateData['status']     = 0;
    C::t('#tom_tcedu#tom_tcedu_course')->update($course_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'shenhe' && submitcheck('course_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $course_id      = intval($_GET['course_id'])>0 ? intval($_GET['course_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $courseInfo = C::t('#tom_tcedu#tom_tcedu_course')->fetch_by_id($course_id);
    $tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($courseInfo['tcedu_id']);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduInfo['user_id']);
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status']    = 1;
        $updateData['status']           = 1;
        C::t('#tom_tcedu#tom_tcedu_course')->update($course_id,$updateData);
        
        $shenhe = str_replace('{NAME}', $courseInfo['name'], $Lang['template_shenhe_ok']);

        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tceduConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$courseInfo['site_id']}&mod=courseinfo&course_id=".$courseInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tceduConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
            if($tceduInfo['manage_user_id'] > 0){
                $manageUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduInfo['manage_user_id']);
                
                $insertData = array();
                $insertData['user_id']      = $manageUserInfo['id'];
                $insertData['type']         = 1;
                $insertData['content']      = '<font color="#238206">'.$tceduConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
                $insertData['is_read']      = 0;
                $insertData['tz_time']      = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
                
                if($access_token && !empty($manageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$courseInfo['site_id']}&mod=courseinfo&course_id=".$courseInfo['id']);
                    $smsData = array(
                        'first'         => $shenhe,
                        'keyword1'      => $tceduConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                    if($r){
                    }else{
                        $outArr = array(
                            'code'=> 200,
                            'send_status'=> 301,
                        );
                        echo json_encode($outArr); exit;
                    }
                }
            }
            
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status']    = 3;
        $updateData['status']           = 0;
        C::t('#tom_tcedu#tom_tcedu_course')->update($courseInfo['id'],$updateData);
        
        $shenhe = str_replace('{NAME}', $courseInfo['name'], $Lang['template_shenhe_no']);
        
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tceduConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$courseInfo['site_id']}&mod=courseedit&course_id=".$courseInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tceduConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
            if($tceduInfo['manage_user_id'] > 0){
                $manageUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tceduInfo['manage_user_id']);
                
                $insertData = array();
                $insertData['user_id']      = $manageUserInfo['id'];
                $insertData['type']         = 1;
                $insertData['content']      = '<font color="#238206">'.$tceduConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
                $insertData['is_read']      = 0;
                $insertData['tz_time']      = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
                
                if($access_token && !empty($manageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcedu&site={$courseInfo['site_id']}&mod=courseedit&course_id=".$courseInfo['id']);
                    $smsData = array(
                        'first'         => $shenhe,
                        'keyword1'      => $tceduConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                    if($r){
                    }else{
                        $outArr = array(
                            'code'=> 200,
                            'send_status'=> 301,
                        );
                        echo json_encode($outArr); exit;
                    }
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('course_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $course_id = intval($_GET['course_id'])>0 ? intval($_GET['course_id']):0;
    
    $count = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_all_count(" AND course_id = {$course_id} AND pay_status IN(0, 2) AND use_status = 0 ");
    if($count > 0){
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    C::t('#tom_tcedu#tom_tcedu_course')->delete_by_id($course_id);
    C::t('#tom_tcedu#tom_tcedu_photo')->delete_by_course_id($course_id);
    C::t('#tom_tcedu#tom_tcedu_course_bm')->delete_by_course_id($course_id);
    C::t('#tom_tcedu#tom_tcedu_course_bm_attr')->delete_by_course_id($course_id);
    C::t('#tom_tcedu#tom_tcedu_course_bm_log')->delete_by_course_id($course_id);
    C::t('#tom_tcedu#tom_tcedu_course_collect')->delete_by_course_id($course_id);
    C::t('#tom_tcedu#tom_tcedu_course_option')->delete_by_course_id($course_id);
    C::t('#tom_tcedu#tom_tcedu_history')->delete_by_course_id($course_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('course_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $idsArr = array();
    if(is_array($_GET['course_ids'])){
        foreach($_GET['course_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $idsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($idsArr)){
        foreach ($idsArr as $key => $value){
            
            $count = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_all_count(" AND course_id = {$value} AND pay_status IN(0, 2) AND use_status = 0 ");
            if($count > 0){
                continue;
            }
            
            C::t('#tom_tcedu#tom_tcedu_course')->delete_by_id($value);
            C::t('#tom_tcedu#tom_tcedu_photo')->delete_by_course_id($value);
            C::t('#tom_tcedu#tom_tcedu_course_bm')->delete_by_course_id($value);
            C::t('#tom_tcedu#tom_tcedu_course_bm_attr')->delete_by_course_id($value);
            C::t('#tom_tcedu#tom_tcedu_course_bm_log')->delete_by_course_id($value);
            C::t('#tom_tcedu#tom_tcedu_course_collect')->delete_by_course_id($value);
            C::t('#tom_tcedu#tom_tcedu_course_option')->delete_by_course_id($value);
            C::t('#tom_tcedu#tom_tcedu_history')->delete_by_course_id($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edittop' && submitcheck('course_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $course_id      = intval($_GET['course_id'])>0 ? intval($_GET['course_id']):0;
    $top_time       = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
    $top_time       = strtotime($top_time);
    
    $updateData = array();
    if($top_time > TIMESTAMP){
        $updateData['top_status']   = 1;
    }else{
        $updateData['top_status']   = 0;
    }
    $updateData['top_time']     = $top_time;
    C::t('#tom_tcedu#tom_tcedu_course')->update($course_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$search_text    = !empty($_GET['search_text'])? addslashes($_GET['search_text']):'';
$site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
$cate_child_id  = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
$tcedu_id       = isset($_GET['tcedu_id'])? intval($_GET['tcedu_id']):0;
$course_id      = isset($_GET['course_id'])? intval($_GET['course_id']):0;
$type           = isset($_GET['type'])? intval($_GET['type']):0;
$top_status     = isset($_GET['top_status'])? intval($_GET['top_status']):0;
$status         = isset($_GET['status'])? intval($_GET['status']):0;
$shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$bm_end_status  = isset($_GET['bm_end_status'])? intval($_GET['bm_end_status']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateData = $cateChildData = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildData[$value['pid']][$value['id']] = $value;
        }else{
            $cateData[$value['id']] = $value;
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildData as $key => $value){
        $cateData[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateData);
$cateData = array();
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$where = "";
if(!empty($search_text)){
    $search_text = str_replace(array('%', '_'),'',$search_text);
    $where .= " AND search_text LIKE '%{$search_text}%' ";
}
if(!empty($site_id)){
    $where.= " AND site_id={$site_id} ";
}
if(!empty($cate_id)){
    $where.= " AND cate_id={$cate_id} ";
}
if(!empty($cate_child_id)){
    $where.= " AND cate_child_id={$cate_child_id} ";
}
if(!empty($tcedu_id)){
    $where.= " AND tcedu_id={$tcedu_id} ";
}
if(!empty($course_id)){
    $where.= " AND id={$course_id} ";
}
if(!empty($type)){
    $where.= " AND type={$type} ";
}
if($top_status == 1){
    $where.= " AND top_status=1 ";
}else if($top_status == 2){
    $where.= " AND top_status=0 ";
}
if($status == 1){
    $where.= " AND status=1 AND deleted=0 ";
}else if($status == 2){
    $where.= " AND status=0 AND deleted=0";
}else if($status == 3){
    $where.= " AND deleted=1 ";
}
if($shenhe_status > 0){
    $where.= " AND shenhe_status={$shenhe_status} ";
}
if($bm_end_status == 1){
    $where.= " AND bm_end_time < ".TIMESTAMP." AND bm_end_time > 0 ";
}

$sort = " ORDER BY id DESC ";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count($where);
$courseListTmp = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_list($where,$sort,$start,$pagesize);
$courseList = array();
if(is_array($courseListTmp) && !empty($courseListTmp)){
    foreach ($courseListTmp as $key => $value) {
        $courseList[$key] = $value;
        
        $photoInfoTmp = C::t("#tom_tcedu#tom_tcedu_photo")->fetch_all_list(" AND course_id = {$value['id']} AND type = 4 ", 'ORDER BY id DESC', 0, 1);
        $courseList[$key]['picurl'] = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $courseList[$key]['picurl'] = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $tceduInfoTmp = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($value['tcedu_id']);
        $courseCateInfoTmp = C::t("#tom_tcedu#tom_tcedu_course_cate")->fetch_by_id($value['course_cate_id']);
        
        if($value['hexiao_limit'] == 2){
            $courseList[$key]['hexiao_time']    = dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
        }
        if($value['open_bm_end_time'] == 1){
            $courseList[$key]['bm_end_time']    = dgmdate($value['bm_end_time'],"Y-m-d H:i",$tomSysOffset);
        }
        
        $courseList[$key]['siteInfo']       = $sitesList[$value['site_id']];
        $courseList[$key]['cateInfo']       = $cateList[$value['cate_id']];
        $courseList[$key]['cateChildInfo']  = $cateChildData[$value['cate_id']][$value['cate_child_id']];
        $courseList[$key]['tceduInfo']      = $tceduInfoTmp;
        $courseList[$key]['courseCateInfo'] = $courseCateInfoTmp;
        $courseList[$key]['add_time']       = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $courseList[$key]['top_time']       = dgmdate($value['top_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&search_text={$search_text}&site_id={$site_id}&cate_id={$cate_id}&cate_child_id={$cate_child_id}&tcedu_id={$tcedu_id}&type={$type}&status={$status}&shenhe_status={$shenhe_status}";

$countShenheStatus2 = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(" AND shenhe_status=2 AND deleted = 0 ");
$countShenheStatus3 = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(" AND shenhe_status=3 AND deleted = 0 ");
$bmEndStatus1 = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(" AND bm_end_time < ".TIMESTAMP." AND bm_end_time > 0 AND deleted = 0 ");

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/course");