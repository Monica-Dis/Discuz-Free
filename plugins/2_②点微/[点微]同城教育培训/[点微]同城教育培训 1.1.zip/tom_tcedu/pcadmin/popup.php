<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=popup";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $show_num       = isset($_GET['show_num'])? intval($_GET['show_num']):0;
    $link           = isset($_GET['link'])? addslashes($_GET['link']):'';
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $status         = isset($_GET['status'])? intval($_GET['status']):1;
    
    $siteIdsArr = array();
    if(is_array($_GET['sites']) && !empty($_GET['sites'])){
        foreach($_GET['sites'] as $key => $value){
            $value = intval($value);
            if($value > 0){
                $siteIdsArr[] = '['.$value.']';
            }
        }
    }
    $siteIdsStr = implode(',', $siteIdsArr);
    
    $insertData = array();
    $insertData['site_ids']     = $siteIdsStr;
    $insertData['show_num']     = $show_num;
    $insertData['link']         = $link;
    $insertData['picurl']       = $picurl;
    $insertData['status']       = $status;
    $insertData['add_time']     = TIMESTAMP;
    if(C::t('#tom_tcedu#tom_tcedu_popup')->insert($insertData)){
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}else if($act == 'edit' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $popup_id       = isset($_GET['popup_id'])? intval($_GET['popup_id']):0;
    $show_num       = isset($_GET['show_num'])? intval($_GET['show_num']):0;
    $link           = isset($_GET['link'])? addslashes($_GET['link']):'';
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $status         = isset($_GET['status'])? intval($_GET['status']):1;
    
    $siteIdsArr = array();
    if(is_array($_GET['sites']) && !empty($_GET['sites'])){
        foreach($_GET['sites'] as $key => $value){
            $value = intval($value);
            if($value > 0){
                $siteIdsArr[] = '['.$value.']';
            }
        }
    }
    $siteIdsStr = implode(',', $siteIdsArr);
    
    $updateData = array();
    $updateData['site_ids']     = $siteIdsStr;
    $updateData['show_num']     = $show_num;
    $updateData['link']         = $link;
    $updateData['picurl']       = $picurl;
    $updateData['status']       = $status;
    C::t('#tom_tcedu#tom_tcedu_popup')->update($popup_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('popup_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $popup_id = intval($_GET['popup_id'])>0 ? intval($_GET['popup_id']):0;
    
    C::t('#tom_tcedu#tom_tcedu_popup')->delete_by_id($popup_id);
    C::t('#tom_tcedu#tom_tcedu_popup_log')->delete_by_popup_id($popup_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('popup_id')){
    $outArr = array(
        'code'=> 1,
    );

    $popup_id = intval($_GET['popup_id'])>0 ? intval($_GET['popup_id']):0;
    
    $popupInfo = C::t('#tom_tcedu#tom_tcedu_popup')->fetch_by_id($popup_id);
    $popupInfo['picurlTmp'] = get_file_url($popupInfo['picurl']);
    
    $siteIdsArr = explode(',', $popupInfo['site_ids']);
    
    $sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesList = array();
    if(is_array($sitesListTmp) && !empty($sitesListTmp)){
        foreach($sitesListTmp as $key => $value){
            $sitesList[$value['id']] = $value;
            $sitesList[$value['id']]['checked'] = false;

            $idTmp = '['.$value['id'].']';
            if(in_array($idTmp, $siteIdsArr)){
                $sitesList[$value['id']]['checked'] = true;
            }
        }
    }
    
    $siteOneChecked = false;
    if(in_array('[1]', $siteIdsArr)){
        $siteOneChecked = true;
    }
    
    $popupInfo['sitesList'] = $sitesList;
    $popupInfo['siteOneChecked'] = $siteOneChecked;
    
    $list = iconv_to_utf8($popupInfo);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}

$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$site_id    = intval($_GET['site_id'])>0? intval($_GET['site_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = "";
if($site_id > 0){
    $where .= " AND site_id={$site_id} ";
}
if($type > 0){
    $where .= " AND type={$type} ";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_popup')->fetch_all_count($where);
$popupListTmp = C::t('#tom_tcedu#tom_tcedu_popup')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$popupList = array();
if(is_array($popupListTmp) && !empty($popupListTmp)){
    foreach ($popupListTmp as $key => $value) {
        $popupList[$key] = $value;
        
        $popupList[$key]['picurlTmp']   = get_file_url($value['picurl']);
        $popupList[$key]['siteInfo']    = $sitesList[$value['site_id']];
        $popupList[$key]['add_time']    = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&type={$type}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/popup");