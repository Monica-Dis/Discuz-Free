<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=vipadd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $days                   = isset($_GET['days'])? intval($_GET['days']):0;
    $days_msg               = isset($_GET['days_msg'])? addslashes($_GET['days_msg']):'';
    $price                  = floatval($_GET['price'])? floatval($_GET['price']):0.00;
    $open_video             = isset($_GET['open_video'])? intval($_GET['open_video']):0;
    $open_experience_course = isset($_GET['open_experience_course'])? intval($_GET['open_experience_course']):0;
    $experience_course_num  = isset($_GET['experience_course_num'])? intval($_GET['experience_course_num']):0;
    $course_num             = isset($_GET['course_num'])? intval($_GET['course_num']):0;
    $xiangou_num            = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $yongjin_bili           = isset($_GET['yongjin_bili'])? intval($_GET['yongjin_bili']):0;
    $vip_rank               = isset($_GET['vip_rank'])? intval($_GET['vip_rank']):0;
    $tcshop_vip_id          = isset($_GET['tcshop_vip_id'])? intval($_GET['tcshop_vip_id']):0;
    $status                 = isset($_GET['status'])? intval($_GET['status']):0;
    $vsort                  = isset($_GET['vsort'])? intval($_GET['vsort']):100;
    $logo                   = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    
    if($yongjin_bili > 100){
        $yongjin_bili = 100;
    }
    
    $insertData = array();
    $insertData['name']                     = $name;
    $insertData['days']                     = $days;
    $insertData['days_msg']                 = $days_msg;
    $insertData['price']                    = $price;
    $insertData['open_video']               = $open_video;
    $insertData['open_experience_course']   = $open_experience_course;
    $insertData['experience_course_num']    = $experience_course_num;
    $insertData['course_num']               = $course_num;
    $insertData['xiangou_num']              = $xiangou_num;
    $insertData['yongjin_bili']             = $yongjin_bili;
    $insertData['vip_rank']                 = $vip_rank;
    $insertData['logo']                     = $logo;
    $insertData['vsort']                    = $vsort;
    $insertData['tcshop_vip_id']            = $tcshop_vip_id;
    $insertData['status']                   = $status;
    $insertData['add_time']                 = TIMESTAMP;
    if(C::t('#tom_tcedu#tom_tcedu_vip')->insert($insertData)){
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
}

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/vipadd");