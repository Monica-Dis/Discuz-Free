<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$phb_cate_id = isset($_GET['phb_cate_id'])? intval($_GET['phb_cate_id']):0;
$phbCateInfo = C::t('#tom_tcedu#tom_tcedu_phb_cate')->fetch_by_id($phb_cate_id);
if(empty($phbCateInfo)){
    dheader('location:'.$pcadminUrl."&tmod=phb");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=phbedu&phb_cate_id={$phb_cate_id}"; 

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('tcedu_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcedu_id   = isset($_GET['tcedu_id'])? intval($_GET['tcedu_id']):0;
    $ranking    = isset($_GET['ranking'])? intval($_GET['ranking']):0;
    
    $tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
    if($tceduInfo){ }else{
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($phbCateInfo['type'] == 2){
        if($phbCateInfo['cate_id'] > 0 && strpos($tceduInfo['cate_ids'], '|'.$phbCateInfo['cate_id'].'|') === FALSE){
            $outArr = array(
                'code'=> 200,
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }

        if($phbCateInfo['cate_child_id'] > 0 && strpos($tceduInfo['cate_child_ids'], '|'.$phbCateInfo['cate_child_id'].'|') === FALSE){
            $outArr = array(
                'code'=> 200,
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $phbInfoTmp = C::t("#tom_tcedu#tom_tcedu_phb")->fetch_all_list(" AND tcedu_id = {$tcedu_id} AND phb_cate_id = {$phb_cate_id} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($phbInfoTmp) && !empty($phbInfoTmp[0])){
        $outArr = array(
            'code'=> 200,
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    $insertData = array();
    $insertData['phb_cate_id']      = $phb_cate_id;
    $insertData['tcedu_id']         = $tcedu_id;
    $insertData['cate_id']          = $phbCateInfo['cate_id'];
    $insertData['cate_child_id']    = $phbCateInfo['cate_child_id'];
    $insertData['ranking']          = $ranking;
    $insertData['add_type']         = 2;
    $insertData['add_time']         = TIMESTAMP;
    if(C::t('#tom_tcedu#tom_tcedu_phb')->insert($insertData)){
        if($phbCateInfo['type'] > 1){
            auto_update_phb($phb_cate_id);
        }
    }
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && submitcheck('tcedu_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $phb_id     = isset($_GET['phb_id'])? intval($_GET['phb_id']):0;
    $ranking    = isset($_GET['ranking'])? intval($_GET['ranking']):0;
    $tcedu_id   = isset($_GET['tcedu_id'])? intval($_GET['tcedu_id']):0;
    
    $tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
    
    if($tceduInfo){ }else{
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $phbInfoTmp = C::t("#tom_tcedu#tom_tcedu_phb")->fetch_all_list(" AND id != {$phb_id} AND tcedu_id = {$tcedu_id} AND phb_cate_id = {$phb_cate_id} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($phbInfoTmp) && !empty($phbInfoTmp[0])){
        $outArr = array(
            'code'=> 200,
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    $phbInfo = C::t("#tom_tcedu#tom_tcedu_phb")->fetch_by_id($phb_id);
    
    $updateData = array();
    $updateData['tcedu_id']         = $tcedu_id;
    $updateData['ranking']          = $ranking;
    $updateData['add_type']         = 2;
    if(C::t('#tom_tcedu#tom_tcedu_phb')->update($phb_id, $updateData)){
        if($phbCateInfo['type'] > 1){
            auto_update_phb($phb_cate_id);
        }
    }
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('phb_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $phb_id = isset($_GET['phb_id'])? intval($_GET['phb_id']):0;
    
    C::t('#tom_tcedu#tom_tcedu_phb')->delete_by_id($phb_id);
    
    if($phbCateInfo['type'] > 1){
        auto_update_phb($phb_cate_id);
    }
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('phb_id')){
    $outArr = array(
        'code'=> 1,
    );

    $phb_id = isset($_GET['phb_id'])? intval($_GET['phb_id']):0;
    
    $phbInfo = C::t('#tom_tcedu#tom_tcedu_phb')->fetch_by_id($phb_id);
    
    $list = iconv_to_utf8($phbInfo);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}

$tcedu_id       = intval($_GET['tcedu_id'])>0? intval($_GET['tcedu_id']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;


if($tceduConfig['phb_auto_update_num'] > 0){
    $Lang['phbedu_help_1'] = str_replace("10",$tceduConfig['phb_auto_update_num'],$Lang['phbedu_help_1']);
}

$where = " AND phb_cate_id = {$phbCateInfo['id']} ";
if($tcedu_id > 0){
    $where .= "AND tcedu_id = {$tcedu_id}";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_phb')->fetch_all_count($where);
$phbListTmp = C::t('#tom_tcedu#tom_tcedu_phb')->fetch_all_list($where," ORDER BY ranking ASC,id DESC ",$start,$pagesize);
$phbList = array();
if(is_array($phbListTmp) && !empty($phbListTmp)){
    foreach ($phbListTmp as $key => $value) {
        $phbList[$key] = $value;
        
        $tceduInfoTmp = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($value['tcedu_id']);
        
        $phbList[$key]['tceduInfo'] = $tceduInfoTmp;
        $phbList[$key]['add_time']  = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/phbedu"); 