<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=courseadd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcedu_id           = isset($_GET['tcedu_id'])? intval($_GET['tcedu_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $course_cate_id     = isset($_GET['course_cate_id'])? intval($_GET['course_cate_id']):0;
    $class_type         = isset($_GET['class_type'])? intval($_GET['class_type']):0;
    $class_num          = isset($_GET['class_num'])? intval($_GET['class_num']):0;
    $xiangou_num        = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):1;
    $market_price       = floatval($_GET['market_price'])? floatval($_GET['market_price']):0.00;
    $buy_price          = floatval($_GET['buy_price'])? floatval($_GET['buy_price']):0.00;
    $open_vip           = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $vip_price          = floatval($_GET['vip_price'])? floatval($_GET['vip_price']):0.00;
    $virtual_clicks     = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $tabs_diy           = isset($_GET['tabs_diy'])? addslashes($_GET['tabs_diy']):'';
    $hexiao_limit       = isset($_GET['hexiao_limit'])? intval($_GET['hexiao_limit']):0;
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = strtotime($hexiao_time);
    $hexiao_days        = isset($_GET['hexiao_days'])? intval($_GET['hexiao_days']):0;
    $open_bm_end_time   = isset($_GET['open_bm_end_time'])? intval($_GET['open_bm_end_time']):0;
    $bm_end_time        = isset($_GET['bm_end_time'])? addslashes($_GET['bm_end_time']):'';
    $bm_end_time        = strtotime($bm_end_time);
    
    $haibao_type        = isset($_GET['haibao_type'])? intval($_GET['haibao_type']):1;
    $haibao_picurl      = isset($_GET['haibao_picurl'])? addslashes($_GET['haibao_picurl']):'';
    $qrcode_location    = isset($_GET['qrcode_location'])? intval($_GET['qrcode_location']):0;
    $haibao_text_color  = isset($_GET['haibao_text_color'])? addslashes($_GET['haibao_text_color']):'';
    
    $hehuoren_tg_open   = isset($_GET['hehuoren_tg_open'])? intval($_GET['hehuoren_tg_open']):0;
    $hehuoren_tg_type   = isset($_GET['hehuoren_tg_type'])? intval($_GET['hehuoren_tg_type']):0;
    $hehuoren_fc_scale  = isset($_GET['hehuoren_fc_scale'])? floatval($_GET['hehuoren_fc_scale']):0;
    $hehuoren_fc_scale2 = isset($_GET['hehuoren_fc_scale2'])? floatval($_GET['hehuoren_fc_scale2']):0;
    
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    
    $tceduInfoTmp = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
    if(is_array($tceduInfoTmp) && !empty($tceduInfoTmp)){ }else{
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $teacherIdsArr = array();
    foreach($_GET['teacher'] as $key => $value){
        $value = intval($value);
        if(!empty($value)){
            $teacherIdsArr[] = $value;
        }
    }
    $teacherIdsStr = '';
    if(is_array($teacherIdsArr) && !empty($teacherIdsArr)){
        $teacherIdsStr = '|'.implode('|', $teacherIdsArr).'|';
    }
    
    $attrIdsArr = array();
    foreach($_GET['attr'] as $key => $value){
        $value = intval($value);
        if(!empty($value)){
            $attrIdsArr[] = $value;
        }
    }
    $attrIdsStr = '';
    if(is_array($attrIdsArr) && !empty($attrIdsArr)){
        $attrIdsStr = implode(',', $attrIdsArr);
    }
    
    $tabsArr = array();
    foreach($_GET['tabs'] as $key => $value){
        $value = addslashes($value);
        if(!empty($value)){
            $tabsArr[] = $value;
        }
    }
    
    if(!empty($tabs_diy)){
        $tabs_diy = trim($tabs_diy);
        $tabs_diy_arr = explode(" ", $tabs_diy);
        foreach($tabs_diy_arr as $key => $value){
            $value = trim($value);
            if(!empty($value)){
                $tabsArr[] = $value;
            }
        }
    }
    
    if($hasoption == 1){
        $optionList = array();
        foreach($_GET as $key => $value){
            if(strpos($key, "option_name_") !== false){
                $key = intval(ltrim($key, "option_name_"));
                $optionList[$key]['name'] = addslashes($value);
            }
            if(strpos($key, "option_market_price_") !== false){
                $key = intval(ltrim($key, "option_market_price_"));
                $optionList[$key]['market_price'] = floatval($value);
            }
            if(strpos($key, "option_buy_price_") !== false){
                $key = intval(ltrim($key, "option_buy_price_"));
                $optionList[$key]['buy_price'] = floatval($value);
            }
            if(strpos($key, "option_vip_price_") !== false){
                $key = intval(ltrim($key, "option_vip_price_"));
                $optionList[$key]['vip_price'] = floatval($value);
            }
            if(strpos($key, "option_class_num_") !== false){
                $key = intval(ltrim($key, "option_class_num_"));
                $optionList[$key]['class_num'] = intval($value);
            }
            if(strpos($key, "option_sort_") !== false){
                $key = intval(ltrim($key, "option_sort_"));
                $optionList[$key]['osort'] = intval($value);
            }
        }
        
        if(empty($optionList)){
            $outArr = array(
                'code'=> 200,
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
        
        foreach($optionList as $key => $value){
            if(empty($value['name'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    
    $cateInfo = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_by_id($cate_id);
    $cateChildInfo = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_by_id($cate_child_id);
    $courseCateInfo = C::t("#tom_tcedu#tom_tcedu_course_cate")->fetch_by_id($course_cate_id);
    
    $search_text = $name.'|'.$cateInfo['name'].'|'.$cateChildInfo['name'].'|'.$courseCateInfo['name'].'|'.$tceduInfoTmp['name'].'|'.$tceduInfoTmp['tel'].'|'.implode('|', $tabsArr);
    
    $insertData = array();
    $insertData['site_id']              = $tceduInfoTmp['site_id'];
    $insertData['tcedu_id']             = $tceduInfoTmp['id'];
    $insertData['area_id']              = $tceduInfoTmp['area_id'];
    $insertData['street_id']            = $tceduInfoTmp['street_id'];
    $insertData['latitude']             = $tceduInfoTmp['latitude'];
    $insertData['longitude']            = $tceduInfoTmp['longitude'];
    $insertData['name']                 = $name;
    $insertData['type']                 = $type;
    $insertData['cate_id']              = $cate_id;
    $insertData['cate_child_id']        = $cate_child_id;
    $insertData['course_cate_id']       = $course_cate_id;
    $insertData['market_price']         = $market_price;
    $insertData['buy_price']            = $buy_price;
    $insertData['open_vip']             = $open_vip;
    $insertData['vip_price']            = $vip_price;
    $insertData['virtual_clicks']       = $virtual_clicks;
    $insertData['teacher_ids']          = $teacherIdsStr;
    $insertData['attr_ids']             = $attrIdsStr;
    $insertData['tabs']                 = implode('|', $tabsArr);
    $insertData['class_type']           = $class_type;
    $insertData['class_num']            = $class_num;
    $insertData['xiangou_num']          = $xiangou_num;
    $insertData['hexiao_limit']         = $hexiao_limit;
    $insertData['hexiao_days']          = $hexiao_days;
    $insertData['hexiao_time']          = $hexiao_time;
    $insertData['open_bm_end_time']     = $open_bm_end_time;
    $insertData['bm_end_time']          = $bm_end_time;
    $insertData['haibao_type']          = $haibao_type;
    $insertData['haibao_picurl']        = $haibao_picurl;
    $insertData['qrcode_location']      = $qrcode_location;
    $insertData['haibao_text_color']    = $haibao_text_color;
    $insertData['hehuoren_tg_open']     = $hehuoren_tg_open;
    $insertData['hehuoren_tg_type']     = $hehuoren_tg_type;
    $insertData['hehuoren_fc_scale']    = $hehuoren_fc_scale;
    $insertData['hehuoren_fc_scale2']   = $hehuoren_fc_scale2;
    $insertData['admin_edit']           = $admin_edit;
    $insertData['content']              = $content;
    $insertData['search_text']          = $search_text;
    $insertData['hasoption']            = $hasoption;
    if($hasoption == 0){
        $insertData['show_market_price']          = $market_price;
        $insertData['show_buy_price']             = $buy_price;
        $insertData['show_vip_price']             = $vip_price;
    }
    $insertData['shenhe_status']        = 1;
    $insertData['status']               = 0;
    $insertData['add_time']             = TIMESTAMP;
    $insertData['update_time']          = TIMESTAMP;
    $course_id = C::t('#tom_tcedu#tom_tcedu_course')->insert($insertData, true);
    if($course_id > 0){
        
        if(!empty($picurl)){
            $insertData = array();
            $insertData['tcedu_id']     = $tceduInfoTmp['id'];
            $insertData['course_id']    = $course_id;
            $insertData['picurl']       = $picurl;
            $insertData['type']         = 4;
            $insertData['add_time']     = TIMESTAMP;
            C::t("#tom_tcedu#tom_tcedu_photo")->insert($insertData);
        }
        
        if($hasoption == 1){
            if(is_array($optionList) && !empty($optionList)){
                foreach ($optionList as $key => $value){
                    $insertData = array();
                    $insertData['tcedu_id']         = $tceduInfoTmp['id'];
                    $insertData['course_id']        = $course_id;
                    $insertData['name']             = $value['name'];
                    $insertData['market_price']     = $value['market_price'];
                    $insertData['buy_price']        = $value['buy_price'];
                    $insertData['vip_price']        = $value['vip_price'];
                    $insertData['class_num']        = $value['class_num'];
                    $insertData['osort']            = $value['osort'];
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tcedu#tom_tcedu_course_option')->insert($insertData);
                }
                
                $optionListTmp = C::t("#tom_tcedu#tom_tcedu_course_option")->fetch_all_list(" AND course_id = {$course_id} ", 'ORDER BY id DESC', 0, 100);
                if(is_array($optionListTmp) && !empty($optionListTmp)){
                    $show_market_price = $show_buy_price = $show_vip_price = 0;
                    foreach($optionListTmp as $key => $value){
                        if($show_buy_price == 0){
                            $show_market_price  = $value['market_price'];
                            $show_buy_price     = $value['buy_price'];
                            $show_vip_price     = $value['vip_price'];
                        }else if($value['buy_price'] < $show_buy_price){
                            $show_market_price  = $value['market_price'];
                            $show_buy_price     = $value['buy_price'];
                            $show_vip_price     = $value['vip_price'];
                        }
                    }
                    if($show_buy_price > 0){
                        $updateData = array();
                        $updateData['show_market_price']    = $show_market_price;
                        $updateData['show_buy_price']       = $show_buy_price;
                        $updateData['show_vip_price']       = $show_vip_price;
                        $updateData['update_time']          = TIMESTAMP;
                        C::t("#tom_tcedu#tom_tcedu_course")->update($course_id,$updateData);
                    }
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
}else if($act == 'load_cate' && submitcheck('tcedu_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcedu_id = intval($_GET['tcedu_id'])>0 ? intval($_GET['tcedu_id']):0;
    $tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
    
    $cateList = array();
    if(!empty($tceduInfo['cate_ids'])){
        $cate_ids = trim($tceduInfo['cate_ids'], '|');
        $cateIdsArr = explode('|', $cate_ids);
        $cateIdsStr = implode(',', $cateIdsArr);
        $cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" AND id IN ({$cateIdsStr}) ", 'ORDER BY csort ASC,id DESC');
        if(is_array($cateListTmp) && !empty($cateListTmp)){
            foreach ($cateListTmp as $key => $value){
                $cateList[$key] = $value;
            }
        }
    }
    
    $courseCateListTmp = C::t('#tom_tcedu#tom_tcedu_course_cate')->fetch_all_list(" AND tcedu_id = {$tcedu_id} ", 'ORDER BY csort ASC,id DESC');
    $courseCateList = array();
    if(is_array($courseCateListTmp) && !empty($courseCateListTmp)){
        foreach ($courseCateListTmp as $key => $value){
            $courseCateList[$key] = $value;
        }
    }
    
    $teacherListTmp = C::t('#tom_tcedu#tom_tcedu_teacher')->fetch_all_list(" AND tcedu_id = {$tcedu_id} AND status = 1 ", 'ORDER BY tsort ASC,id DESC');
    $teacherList = array();
    if(is_array($teacherListTmp) && !empty($teacherListTmp)){
        foreach ($teacherListTmp as $key => $value){
            $teacherList[$key] = $value;
        }
    }
    
    $attrListTmp = C::t('#tom_tcedu#tom_tcedu_attr')->fetch_all_list(" AND tcedu_id = {$tcedu_id} AND is_show = 1 ", 'ORDER BY asort ASC,id DESC');
    $attrList = array();
    if(is_array($attrListTmp) && !empty($attrListTmp)){
        foreach ($attrListTmp as $key => $value){
            $attrList[$key] = $value;
        }
    }
    
    $list['courseCateList'] = $courseCateList;
    $list['teacherList']    = $teacherList;
    $list['cateList']       = $cateList;
    $list['attrList']       = $attrList;
    
    $list = iconv_to_utf8($list);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}else if($act == 'load_cate_child' && submitcheck('tcedu_id')){
    
    $outArr = array(
        'code'=> 1,
    );
    
    $tcedu_id   = intval($_GET['tcedu_id'])>0 ? intval($_GET['tcedu_id']):0;
    $cate_id    = intval($_GET['cate_id'])>0 ? intval($_GET['cate_id']):0;
    
    $tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
    
    $cateList = array();
    if(!empty($tceduInfo['cate_child_ids'])){
        $cate_child_ids = trim($tceduInfo['cate_child_ids'], '|');
        $cateChildIdsArr = explode('|', $cate_child_ids);
        $cateChildIdsStr = implode(',', $cateChildIdsArr);
        $cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" AND pid = {$cate_id} AND id IN ({$cateChildIdsStr}) ", 'ORDER BY csort ASC,id DESC');
        if(is_array($cateListTmp) && !empty($cateListTmp)){
            foreach ($cateListTmp as $key => $value){
                $cateList[$key] = $value;
            }
        }
    }
    
    $list = iconv_to_utf8($cateList);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}

$courseTabsArr = array();
$course_tab_str = str_replace("\r\n","{n}",$tceduConfig['course_tab_list']); 
$course_tab_str = str_replace("\n","{n}",$course_tab_str);
$course_tab_arr = explode("{n}", $course_tab_str);
if(is_array($course_tab_arr) && !empty($course_tab_arr)){
    foreach ($course_tab_arr as $key => $value){
        $value = trim($value);

        if(!empty($value)){
            $courseTabsArr[] = $value;
        }
    }
}

$addUrl = $modPcadminUrl."&act=add";

$ossBatchUrl = 'plugin.php?id=tom_tcedu:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcedu:qiniuBatch';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/courseadd");