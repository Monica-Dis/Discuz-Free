<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcedu_id = intval($_GET['tcedu_id'])>0? intval($_GET['tcedu_id']):0;

$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
if(empty($tceduInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=viplog&tcedu_id={$tcedu_id}";

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = "AND tcedu_id = {$tcedu_id}";

$start = ($page-1)*$pagesize;	
$count = C::t('#tom_tcedu#tom_tcedu_vip_log')->fetch_all_count($where);
$vipLogListTmp = C::t('#tom_tcedu#tom_tcedu_vip_log')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$vipLogList = array();
if(is_array($vipLogListTmp) && !empty($vipLogListTmp)){
    foreach($vipLogListTmp as $key => $value){
        $vipLogList[$key] = $value;
        
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $vipInfoTmp = $vipCodeInfoTmp = array();
        if($value['type'] == 1){
            $vipInfoTmp = C::t("#tom_tcedu#tom_tcedu_vip")->fetch_by_id($value['vip_id']);
        }else if($value['type'] == 2){
            $vipCodeInfoTmp = C::t("#tom_tcedu#tom_tcedu_vip_code")->fetch_by_id($value['vip_code_id']);
            $vipInfoTmp = C::t("#tom_tcedu#tom_tcedu_vip")->fetch_by_id($vipCodeInfoTmp['vip_id']);
        }
        
        $vipLogList[$key]['userInfo']       = $userInfoTmp;
        $vipLogList[$key]['vipInfo']        = $vipInfoTmp;
        $vipLogList[$key]['vipCodeInfo']    = $vipCodeInfoTmp;
        $vipLogList[$key]['log_time']       = dgmdate($value['log_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/viplog");