<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$course_id = intval($_GET['course_id'])>0? intval($_GET['course_id']):0;
$courseInfo = C::t('#tom_tcedu#tom_tcedu_course')->fetch_by_id($course_id);
if(empty($courseInfo)){
    dheader('location:'.$pcadminUrl."&tmod=course");exit;
}

$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($courseInfo['tcedu_id']);

$modPcadminUrl = $pcadminUrl."&tmod=coursecollect&course_id={$course_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('collect_id')){
    $outArr = array(
        'code'=> 1,
    );

    $collect_id = intval($_GET['collect_id'])>0? intval($_GET['collect_id']):0;
    
    C::t('#tom_tcedu#tom_tcedu_course_collect')->delete_by_id($collect_id);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('collect_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $collectIdsArr = array();
    if(is_array($_GET['collect_ids'])){
        foreach($_GET['collect_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $collectIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($collectIdsArr)){
        foreach ($collectIdsArr as $key => $value){
            C::t('#tom_tcedu#tom_tcedu_course_collect')->delete_by_id($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = "AND course_id={$course_id}";
if($user_id > 0){
    $where .= " AND user_id={$user_id} ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_course_collect')->fetch_all_count($where);
$collectListTmp = C::t('#tom_tcedu#tom_tcedu_course_collect')->fetch_all_list($where, "ORDER BY id ASC", $start, $pagesize);
$collectList = array();
if(is_array($collectListTmp) && !empty($collectListTmp)){
    foreach($collectListTmp as $key => $value){
        $collectList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $collectList[$key]['userInfo']      = $userInfoTmp;
        $collectList[$key]['add_time']      = dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/coursecollect");