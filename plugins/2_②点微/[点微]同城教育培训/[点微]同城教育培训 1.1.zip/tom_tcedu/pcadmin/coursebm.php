<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=coursebm";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'pay_status' && submitcheck('bm_id')){
    $outArr = array(
        'code'=> 1,
    );

    $bm_id      = intval($_GET['bm_id'])>0? intval($_GET['bm_id']):0;
    $pay_status = intval($_GET['pay_status'])>0? intval($_GET['pay_status']):0;
    
    $updateData = array();
    $updateData['pay_status'] = $pay_status;
    C::t('#tom_tcedu#tom_tcedu_course_bm')->update($bm_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'use_status' && submitcheck('bm_id')){
    $outArr = array(
        'code'=> 1,
    );

    $bm_id      = intval($_GET['bm_id'])>0? intval($_GET['bm_id']):0;
    $use_status = intval($_GET['use_status'])>0? intval($_GET['use_status']):0;
    
    $updateData = array();
    $updateData['use_status'] = $use_status;
    C::t('#tom_tcedu#tom_tcedu_course_bm')->update($bm_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'cancel_refund' && submitcheck('bm_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $bm_id = intval($_GET['bm_id'])>0 ? intval($_GET['bm_id']):0;
    
    $updateData = array();
    $updateData['refund_status'] = 0;
    C::t("#tom_tcedu#tom_tcedu_course_bm")->update($bm_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$course_id      = intval($_GET['course_id'])>0? intval($_GET['course_id']):0;
$user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$xm             = !empty($_GET['xm'])? addslashes($_GET['xm']):'';
$tel            = !empty($_GET['tel'])? addslashes($_GET['tel']):'';
$pay_status     = intval($_GET['pay_status'])>0? intval($_GET['pay_status']):0;
$use_status     = intval($_GET['use_status'])>0? intval($_GET['use_status']):0;
$refund_status  = intval($_GET['refund_status'])>0? intval($_GET['refund_status']):0;
$vip_pay_status = intval($_GET['vip_pay_status'])>0? intval($_GET['vip_pay_status']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = "";
if($course_id > 0){
    $where .= " AND course_id={$course_id} ";
}
if($user_id > 0){
    $where .= " AND user_id={$user_id} ";
}
if(!empty($xm)){
    $xm = str_replace(array('%', '_'),'',$xm);
    $where .= " AND xm LIKE '%{$xm}%' ";
}
if(!empty($tel)){
    $tel = str_replace(array('%', '_'),'',$tel);
    $where .= " AND tel LIKE '%{$tel}%' ";
}
if($pay_status > 0){
    if($pay_status == 999){
        $where .= " AND pay_status=0 ";
    }else{
        $where .= " AND pay_status={$pay_status} ";
    }
}
if($use_status > 0){
    if($use_status == 1){
        $where .= " AND use_status={$use_status} ";
    }else{
        $where .= " AND use_status=0 ";
    }
}
if($refund_status > 0){
    $where .= " AND refund_status={$refund_status} ";
}
if($vip_pay_status > 0){
    $where .= " AND vip_pay_status={$vip_pay_status} ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_all_count($where);
$bmListTmp = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_all_list($where, "ORDER BY add_time DESC,id ASC", $start, $pagesize);
$bmList = array();
if(is_array($bmListTmp) && !empty($bmListTmp)){
    foreach($bmListTmp as $key => $value){
        $bmList[$key] = $value;
        
        $tceduInfoTmp = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($value['tcedu_id']);
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $hexiaoUserInfoTmp = array();
        if($value['hexiao_user_id'] > 0){
            $hexiaoUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        }
        
        $bmAttrListTmpTmp = C::t("#tom_tcedu#tom_tcedu_course_bm_attr")->fetch_all_list(" AND bm_id = {$value['id']} ",'ORDER BY asort ASC,id DESC');
        $bmAttrListTmp = array();
        if(is_array($bmAttrListTmpTmp) && !empty($bmAttrListTmpTmp)){
            foreach($bmAttrListTmpTmp as $k => $v){
                $bmAttrListTmp[$k] = $v;
                if($v['attr_type'] == 4){
                    $bmAttrListTmp[$k]['value'] = str_replace("|"," ", $v['value']);
                }
            }
        }
        
        $hexiaoUrlTmp = $_G['siteurl']."plugin.php?id=tom_tcedu&site={$tceduInfoTmp['site_id']}&mod=hexiao&hexiao_no={$value['hexiao_no']}";
        $qrcodeImgTmp = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($hexiaoUrlTmp);
        
        $bmList[$key]['userInfo']       = $userInfoTmp;
        $bmList[$key]['hexiaoUserInfo'] = $hexiaoUserInfoTmp;
        $bmList[$key]['bmAttrList']     = $bmAttrListTmp;
        $bmList[$key]['qrcodeImg']      = $qrcodeImgTmp;
        $bmList[$key]['add_time']       = dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&course_id={$course_id}&user_id={$user_id}&xm={$xm}&tel={$tel}&pay_status={$pay_status}&use_status={$use_status}&refund_status={$refund_status}&vip_pay_status={$vip_pay_status}";

$todayPayPrice = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_all_pay_price(" AND add_time > {$nowDayTime} AND pay_status = 2 AND refund_status IN(0,1) ");
$monthPayPrice = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_all_pay_price(" AND add_time > {$nowMonthTime} AND pay_status = 2 AND refund_status IN(0,1) ");
$allPayPrice = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_all_pay_price(" AND pay_status = 2 AND refund_status IN(0,1) ");
$shenqingRefundCount = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_all_count(" AND pay_status = 2 AND refund_status = 1 ");

if(!empty($where)){
    $searchAllPayPrice = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_all_pay_price($where);
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/coursebm");