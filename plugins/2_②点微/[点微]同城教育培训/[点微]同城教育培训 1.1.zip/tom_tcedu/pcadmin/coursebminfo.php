<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$bm_id = intval($_GET['bm_id'])>0? intval($_GET['bm_id']):0;

$bmInfo = C::t('#tom_tcedu#tom_tcedu_course_bm')->fetch_by_id($bm_id);

$modPcadminUrl = $pcadminUrl."&tmod=coursebminfo&bm_id={$bm_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'refund' && submitcheck('refund_price')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $refund_price   = floatval($_GET['refund_price'])>0 ? floatval($_GET['refund_price']) :0.00;
    $refund_beizu   = isset($_GET['refund_beizu'])? addslashes($_GET['refund_beizu']):'';
    
    $orderInfo = C::t('#tom_tcedu#tom_tcedu_order')->fetch_by_order_no($bmInfo['order_no']);
    
    if($refund_price > $bmInfo['pay_price']){
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $wxpay_appid        = trim($tongchengConfig['wxpay_appid']);
    $wxpay_mchid        = trim($tongchengConfig['wxpay_mchid']);
    $wxpay_key          = trim($tongchengConfig['wxpay_key']);
    $wxpay_appsecret    = trim($tongchengConfig['wxpay_appsecret']);

    define("TOM_WXPAY_APPID", $wxpay_appid);
    define("TOM_WXPAY_MCHID", $wxpay_mchid);
    define("TOM_WXPAY_KEY", $wxpay_key);
    define("TOM_WXPAY_APPSECRET", $wxpay_appsecret);
    define("TOM_WXPAY_SSLCERT_PATH", DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_cert.pem');
    define("TOM_WXPAY_SSLKEY_PATH", DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_key.pem');
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/wxpay/lib/WxPay.Api.php';
    
    $template_sms = $template_url = '';
    $payOrderInfo = C::t('#tom_pay#tom_pay_order')->fetch_by_order_no($orderInfo['order_no']);
    if($payOrderInfo['payment'] == 'wxpay_jsapi' || $payOrderInfo['payment'] == 'wxpay_h5' || $payOrderInfo['payment'] == 'wxpay_native'){
        if($orderInfo && !empty($orderInfo['order_no']) && $orderInfo['order_status'] == 2){
            $pay_price = $orderInfo['pay_price']*100;
            $pay_refund_price = $refund_price*100;
            $refund_no = 'T'.WxPayConfig::MCHID.date("YmdHis");
            
            $input = new WxPayRefund();
            $input->SetOut_trade_no($orderInfo['order_no']);
            $input->SetTotal_fee($pay_price);                       
            $input->SetRefund_fee($pay_refund_price);                      
            $input->SetOut_refund_no($refund_no);
            $input->SetOp_user_id(WxPayConfig::MCHID);
            $return = WxPayApi::refund($input);
            
            if(is_array($return) && $return['result_code'] == 'SUCCESS'){
                $template_sms = $Lang['refund_refund_price_succ_template_1'];
                $template_url = $_G['siteurl']."plugin.php?id=tom_tcedu&site={$orderInfo['site_id']}&mod=mybminfo&bm_id={$bmInfo['id']}";
                
                $updateData = array();
                $updateData['refund_no']        = $refund_no;
                $updateData['refund_price']     = $refund_price;
                $updateData['refund_beizu']     = $refund_beizu;
                $updateData['refund_status']    = 2;
                $updateData['refund_type']      = 1;
                $updateData['wx_refund_status'] = 1;
                $updateData['pay_status']       = 4;
                $updateData['refund_time']      = TIMESTAMP;
                if(C::t('#tom_tcedu#tom_tcedu_course_bm')->update($bmInfo['id'], $updateData)){

                    $updateData = array();
                    $updateData['order_status'] = 4;
                    if(C::t('#tom_tcedu#tom_tcedu_order')->update($orderInfo['id'], $updateData)){
                        DB::query("UPDATE ".DB::table('tom_tcedu_course')." SET sale_num=sale_num-1 WHERE id={$bmInfo['course_id']}", 'UNBUFFERED');
                        if($bmInfo['option_id'] > 0){
                            DB::query("UPDATE ".DB::table('tom_tcedu_course_option')." SET sale_num=sale_num-1 WHERE id={$bmInfo['option_id']}", 'UNBUFFERED');
                        }
                    }
                }
            }else{
                
                $err_code_des = diconv($return['return_msg'], 'utf-8', CHARSET);
                $outArr = array(
                    'code'=> 200,
                    'status'=> 302,
                    'msg'=> $err_code_des,
                );
                echo json_encode($outArr); exit;
            }
        }
    }else{
        
        if($orderInfo && !empty($orderInfo['order_no']) && !empty($refund_price) && $orderInfo['order_status'] = 2){
            $orderUserInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
            $insertData = array();
            $insertData['user_id']          = $orderInfo['user_id'];
            $insertData['type_id']          = 2;
            $insertData['change_money']     = $refund_price;
            $insertData['old_money']        = $orderUserInfo['money'];
            $insertData['tag']              = $Lang['refund_money_log_tag'];
            $insertData['beizu']            = $Lang['beizu_order_no'] . $orderInfo['order_no'];
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);

            DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$refund_price} WHERE id='{$orderUserInfo['id']}'", 'UNBUFFERED');

            $updateData = array();
            $updateData['refund_price']     = $refund_price;
            $updateData['refund_beizu']     = $refund_beizu;
            $updateData['refund_status']    = 2;
            $updateData['refund_type']      = 2;
            $updateData['pay_status']       = 4;
            $updateData['refund_time']      = TIMESTAMP;
            if(C::t('#tom_tcedu#tom_tcedu_course_bm')->update($bmInfo['id'], $updateData)){
                
                $updateData = array();
                $updateData['order_status'] = 4;
                if(C::t('#tom_tcedu#tom_tcedu_order')->update($orderInfo['id'], $updateData)){
                    DB::query("UPDATE ".DB::table('tom_tcedu_course')." SET sale_num=sale_num-1 WHERE id={$bmInfo['course_id']}", 'UNBUFFERED');
                    if($bmInfo['option_id'] > 0){
                        DB::query("UPDATE ".DB::table('tom_tcedu_course_option')." SET sale_num=sale_num-1 WHERE id={$bmInfo['option_id']}", 'UNBUFFERED');
                    }
                }
            }
            $template_sms = $Lang['refund_refund_price_succ_template_2'];
            $template_url = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$orderInfo['site_id']}&mod=money";
        }
    }
    
    if(!empty($template_sms) && !empty($template_url)){
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($orderInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $template_url);
            $smsData = array(
                'first'         => $template_sms,
                'keyword1'      => $tceduConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($orderInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }

        $insertData = array();
        $insertData['user_id']      = $orderInfo['user_id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tceduConfig['plugin_name'].'</font><br/>'.$template_sms.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    }
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$orderInfo = C::t('#tom_tcedu#tom_tcedu_order')->fetch_by_order_no($bmInfo['order_no']);

$userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($bmInfo['user_id']);
$tceduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($bmInfo['tcedu_id']);
$courseInfo = C::t("#tom_tcedu#tom_tcedu_course")->fetch_by_id($bmInfo['course_id']);

$orderInfo['orderTime']     = dgmdate($orderInfo['order_time'], 'Y-m-d H:i:s',$tomSysOffset);
$orderInfo['payTime']       = dgmdate($orderInfo['pay_time'], 'Y-m-d H:i:s',$tomSysOffset);
$bmInfo['refundAddTime']    = dgmdate($bmInfo['refund_add_time'], 'Y-m-d H:i:s',$tomSysOffset);
$bmInfo['refundTime']       = dgmdate($bmInfo['refund_time'], 'Y-m-d H:i:s',$tomSysOffset);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/coursebminfo");