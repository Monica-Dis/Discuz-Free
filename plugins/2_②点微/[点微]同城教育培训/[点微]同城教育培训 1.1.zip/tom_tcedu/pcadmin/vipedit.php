<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$vip_id = intval($_GET['vip_id']) > 0 ? intval($_GET['vip_id']) : 0;

$vipInfo = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_by_id($vip_id);
if(empty($vipInfo)){
    dheader('location:'.$pcadminUrl."&tmod=vip");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=vipedit&vip_id={$vip_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $days                   = isset($_GET['days'])? intval($_GET['days']):0;
    $days_msg               = isset($_GET['days_msg'])? addslashes($_GET['days_msg']):'';
    $price                  = floatval($_GET['price'])? floatval($_GET['price']):0.00;
    $open_video             = isset($_GET['open_video'])? intval($_GET['open_video']):0;
    $open_experience_course = isset($_GET['open_experience_course'])? intval($_GET['open_experience_course']):0;
    $experience_course_num  = isset($_GET['experience_course_num'])? intval($_GET['experience_course_num']):0;
    $course_num             = isset($_GET['course_num'])? intval($_GET['course_num']):0;
    $xiangou_num            = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $yongjin_bili           = isset($_GET['yongjin_bili'])? intval($_GET['yongjin_bili']):0;
    $vip_rank               = isset($_GET['vip_rank'])? intval($_GET['vip_rank']):0;
    $tcshop_vip_id          = isset($_GET['tcshop_vip_id'])? intval($_GET['tcshop_vip_id']):0;
    $status                 = isset($_GET['status'])? intval($_GET['status']):0;
    $vsort                  = isset($_GET['vsort'])? intval($_GET['vsort']):100;
    $logo                   = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    
    if($yongjin_bili > 100){
        $yongjin_bili = 100;
    }
    
    $updateData = array();
    $updateData['name']                     = $name;
    $updateData['days']                     = $days;
    $updateData['days_msg']                 = $days_msg;
    $updateData['price']                    = $price;
    $updateData['open_video']               = $open_video;
    $updateData['open_experience_course']   = $open_experience_course;
    $updateData['experience_course_num']    = $experience_course_num;
    $updateData['course_num']               = $course_num;
    $updateData['xiangou_num']              = $xiangou_num;
    $updateData['yongjin_bili']             = $yongjin_bili;
    $updateData['vip_rank']                 = $vip_rank;
    $updateData['logo']                     = $logo;
    $updateData['tcshop_vip_id']            = $tcshop_vip_id;
    $updateData['vsort']                    = $vsort;
    $updateData['status']                   = $status;
    if(C::t('#tom_tcedu#tom_tcedu_vip')->update($vip_id, $updateData)){
        if($vipInfo['vip_rank'] != $vip_rank){
            DB::query("UPDATE ".DB::table('tom_tcedu')." SET vip_rank={$vip_rank} WHERE vip_id={$vip_id}", 'UNBUFFERED');
        }
    }
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$vipInfo['logoTmp'] = get_file_url($vipInfo['logo']);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/vipedit");