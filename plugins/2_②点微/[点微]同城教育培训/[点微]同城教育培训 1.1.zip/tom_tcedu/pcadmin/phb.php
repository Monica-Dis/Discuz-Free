<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=phb"; 

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $type           = isset($_GET['type'])? intval($_GET['type']):1;
    $cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id  = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    
    if($type == 1){
        $cate_id = 0;
        $cate_child_id = 0;
    }
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['name']             = $name;
    $insertData['type']             = $type;
    $insertData['cate_id']          = $cate_id;
    $insertData['cate_child_id']    = $cate_child_id;
    $insertData['status']           = $status;
    $insertData['picurl']           = $picurl;
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tcedu#tom_tcedu_phb_cate')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && submitcheck('phb_cate_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $phb_cate_id    = isset($_GET['phb_cate_id'])? intval($_GET['phb_cate_id']):0;
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $type           = isset($_GET['type'])? intval($_GET['type']):1;
    $cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id  = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    
    if($type == 1){
        $cate_id = 0;
        $cate_child_id = 0;
    }
    
    $updateData = array();
    $updateData['site_id']          = $site_id;
    $updateData['name']             = $name;
    $updateData['type']             = $type;
    $updateData['cate_id']          = $cate_id;
    $updateData['cate_child_id']    = $cate_child_id;
    $updateData['status']           = $status;
    $updateData['picurl']           = $picurl;
    C::t('#tom_tcedu#tom_tcedu_phb_cate')->update($phb_cate_id, $updateData);
    
    DB::query("UPDATE ".DB::table('tom_tcedu_phb')." SET status={$status},cate_id={$cate_id},cate_child_id={$cate_child_id} WHERE phb_cate_id={$phb_cate_id}", 'UNBUFFERED');
    
    if($type > 1){
        auto_update_phb($phb_cate_id);
    }
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('phb_cate_id')){
    $outArr = array(
        'code'=> 1,
    );

    $phb_cate_id = isset($_GET['phb_cate_id'])? intval($_GET['phb_cate_id']):0;

    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcedu#tom_tcedu_phb_cate')->update($phb_cate_id, $updateData);
    
    DB::query("UPDATE ".DB::table('tom_tcedu_phb')." SET status=1 WHERE phb_cate_id={$phb_cate_id}", 'UNBUFFERED');
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('phb_cate_id')){
    $outArr = array(
        'code'=> 1,
    );

    $phb_cate_id = isset($_GET['phb_cate_id'])? intval($_GET['phb_cate_id']):0;

    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcedu#tom_tcedu_phb_cate')->update($phb_cate_id, $updateData);
    
    DB::query("UPDATE ".DB::table('tom_tcedu_phb')." SET status=0 WHERE phb_cate_id={$phb_cate_id}", 'UNBUFFERED');
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('phb_cate_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $phb_cate_id = intval($_GET['phb_cate_id'])>0 ? intval($_GET['phb_cate_id']):0;
    
    C::t('#tom_tcedu#tom_tcedu_phb_cate')->delete_by_id($phb_cate_id);
    C::t('#tom_tcedu#tom_tcedu_phb')->delete_by_phb_cate_id($phb_cate_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('phb_cate_id')){
    $outArr = array(
        'code'=> 1,
    );

    $phb_cate_id = intval($_GET['phb_cate_id'])>0 ? intval($_GET['phb_cate_id']):0;
    
    $phbCateInfo = C::t('#tom_tcedu#tom_tcedu_phb_cate')->fetch_by_id($phb_cate_id);
    $phbCateInfo['picurlTmp'] = get_file_url($phbCateInfo['picurl']);
    
    $list = iconv_to_utf8($phbCateInfo);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}else if($act == 'refresh' && submitcheck('phb_cate_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $phb_cate_id = intval($_GET['phb_cate_id'])>0 ? intval($_GET['phb_cate_id']):0;
    
    auto_update_phb($phb_cate_id);
    
    $outArr = array(
        'code'  => 200,
    );
    echo json_encode($outArr); exit;
}

$site_id        = intval($_GET['site_id'])>0? intval($_GET['site_id']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$where = "";
if($site_id > 0){
    $where .= "AND site_id = {$site_id}";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_phb_cate')->fetch_all_count($where);
$phbCateListTmp = C::t('#tom_tcedu#tom_tcedu_phb_cate')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$phbCateList = array();
if(is_array($phbCateListTmp) && !empty($phbCateListTmp)){
    foreach ($phbCateListTmp as $key => $value) {
        $phbCateList[$key] = $value;
        
        $phbCateList[$key]['siteInfo']      = $sitesList[$value['site_id']];
        $phbCateList[$key]['cateInfo']      = $cateList[$value['cate_id']];
        $phbCateList[$key]['cateChildInfo'] = $cateChildList[$value['cate_id']][$value['cate_child_id']];
        $phbCateList[$key]['picurl']        = get_file_url($value['picurl']);
        $phbCateList[$key]['add_time']      = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/phb"); 