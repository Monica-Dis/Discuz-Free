<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcedu_id = intval($_GET['tcedu_id'])>0 ? intval($_GET['tcedu_id']):0;

$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
if(empty($tceduInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=edit&tcedu_id={$tcedu_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('tcedu_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $manage_user_id     = isset($_GET['manage_user_id'])? intval($_GET['manage_user_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $theme_color        = isset($_GET['theme_color'])? addslashes($_GET['theme_color']):'';
    $edu_xm             = isset($_GET['edu_xm'])? addslashes($_GET['edu_xm']):'';
    $edu_tel            = isset($_GET['edu_tel'])? addslashes($_GET['edu_tel']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tabs_diy           = isset($_GET['tabs_diy'])? addslashes($_GET['tabs_diy']):'';
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $kefu_qrcode        = isset($_GET['kefu_qrcode'])? addslashes($_GET['kefu_qrcode']):'';
    $business_licence   = isset($_GET['business_licence'])? addslashes($_GET['business_licence']):'';
    $virtual_clicks     = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $renqi              = isset($_GET['renqi'])? intval($_GET['renqi']):0;
    $video_pic          = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_url          = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $longitude          = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $latitude           = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    
    $huanjing_score     = isset($_GET['huanjing_score'])? floatval($_GET['huanjing_score']):0;
    $fuwu_score         = isset($_GET['fuwu_score'])? floatval($_GET['fuwu_score']):0;
    $teacher_score      = isset($_GET['teacher_score'])? floatval($_GET['teacher_score']):0;
    
    if($huanjing_score > 5){
        $huanjing_score = 5;
    }
    if($fuwu_score > 5){
        $fuwu_score = 5;
    }
    if($teacher_score > 5){
        $teacher_score = 5;
    }
    
    $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    if(is_array($userInfoTmp) && !empty($userInfoTmp)){ }else{
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $tabsArr = array();
    foreach($_GET['tabs'] as $key => $value){
        $value = addslashes($value);
        if(!empty($value)){
            $tabsArr[] = $value;
        }
    }
    
    if(!empty($tabs_diy)){
        $tabs_diy = trim($tabs_diy);
        $tabs_diy_arr = explode(" ", $tabs_diy);
        foreach($tabs_diy_arr as $key => $value){
            $value = trim($value);
            if(!empty($value)){
                $tabsArr[] = $value;
            }
        }
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photosort_") !== false){
            $kk = intval(ltrim($key, "photosort_"));
            $photoArr[$kk]['sort'] = addslashes($value);
        }
    }
    
    $cateIdsArr = array();
    foreach($_GET['cate'] as $key => $value){
        $value = intval($value);
        if(!empty($value)){
            $cateIdsArr[] = $value;
        }
    }
    
    $cateChildIdsArr = array();
    foreach($_GET['cate_child'] as $key => $value){
        $value = intval($value);
        if(!empty($value)){
            $cateChildIdsArr[] = $value;
        }
    }
    
    $cateIdsList = array_merge($cateIdsArr, $cateChildIdsArr);
    $cateIdsStr = implode(',', $cateIdsList);
    
    $cateListTmp = C::t("#tom_tcedu#tom_tcedu_cate")->fetch_all_list(" AND id IN({$cateIdsStr}) ", 'ORDER BY csort ASC, id DESC');
    $cateName = '';
    if(is_array($cateListTmp) && !empty($cateListTmp)){
        foreach($cateListTmp as $key => $value){
            $cateName .= $value['name'];
        }
    }
    
    $tabsStr = implode('|', $tabsArr);
    
    $search_text = $name.'|'.$tel.'|'.$tabsStr.'|'.$cateName;
    
    $total_score    = round(($fuwu_score + $huanjing_score + $teacher_score) / 3, 3);
    $fuwu_score     = round($fuwu_score, 3);
    $huanjing_score = round($huanjing_score, 3);
    $teacher_score  = round($teacher_score, 3);
    
    $updateData = array();
    $updateData['site_id']              = $site_id;
    $updateData['user_id']              = $user_id;
    $updateData['manage_user_id']       = $manage_user_id;
    $updateData['name']                 = $name;
    $updateData['theme_color']          = $theme_color;
    $updateData['cate_ids']             = '|'.implode('|', $cateIdsArr).'|';
    $updateData['cate_child_ids']       = '|'.implode('|', $cateChildIdsArr).'|';
    $updateData['city_id']              = $city_id;
    $updateData['area_id']              = $area_id;
    $updateData['street_id']            = $street_id;
    $updateData['longitude']            = $longitude;
    $updateData['latitude']             = $latitude;
    $updateData['address']              = $address;
    $updateData['tabs']                 = $tabsStr;
    $updateData['edu_xm']               = $edu_xm;
    $updateData['edu_tel']              = $edu_tel;
    $updateData['tel']                  = $tel;
    $updateData['admin_edit']           = $admin_edit;
    $updateData['content']              = $content;
    if(!empty($video_pic) && !empty($video_url)){
        $updateData['video_status']         = 1;
    }else{
        $updateData['video_status']         = 0;
    }
    $updateData['kefu_qrcode']          = $kefu_qrcode;
    $updateData['business_licence']     = $business_licence;
    $updateData['video_pic']            = $video_pic;
    $updateData['video_url']            = $video_url;
    $updateData['search_text']          = $search_text;
    $updateData['virtual_clicks']       = $virtual_clicks;
    $updateData['renqi']                = $renqi;
    $updateData['fuwu_score']           = $fuwu_score;
    $updateData['huanjing_score']       = $huanjing_score;
    $updateData['teacher_score']        = $teacher_score;
    $updateData['total_score']          = $total_score;
    $updateData['is_ok']                = 1;
    $updateData['update_time']          = TIMESTAMP;
    if(C::t('#tom_tcedu#tom_tcedu')->update($tcedu_id, $updateData)){
        C::t('#tom_tcedu#tom_tcedu_photo')->delete_by_tcedu_avatar($tcedu_id);
        C::t('#tom_tcedu#tom_tcedu_photo')->delete_by_tcedu_photo($tcedu_id);

        if($tceduInfo['site_id'] != $site_id || $tceduInfo['street_id'] != $street_id || $tceduInfo['longitude'] != $longitude || $tceduInfo['latitude'] != $latitude){
            DB::query("UPDATE ".DB::table('tom_tcedu_course')." SET site_id={$site_id},area_id={$area_id},street_id={$street_id},longitude={$longitude},latitude={$latitude} WHERE tcedu_id={$tceduInfo['id']}", 'UNBUFFERED');
        }
        
        if(!empty($picurl)){
            $insertData = array();
            $insertData['tcedu_id']  = $tcedu_id;
            $insertData['type']      = 1;
            $insertData['picurl']    = $picurl;
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcedu#tom_tcedu_photo')->insert($insertData);
        }

        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['tcedu_id']     = $tcedu_id;
                $insertData['type']         = 2;
                $insertData['picurl']       = $value['picurl'];
                $insertData['psort']        = $value['sort'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tcedu#tom_tcedu_photo')->insert($insertData);
            }
        }
        
        update_edu_tcshop($tcedu_id);

        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'code'=> 1001,
        );
        echo json_encode($outArr); exit;
    }
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$eduColorList = array();
$edu_color_str = str_replace("\r\n","{n}",$tceduConfig['edu_color_list']); 
$edu_color_str = str_replace("\n","{n}",$edu_color_str);
$edu_color_arr = explode("{n}", $edu_color_str);
if(is_array($edu_color_arr) && !empty($edu_color_arr)){
    foreach ($edu_color_arr as $key => $value){
        $arrTmp = explode("|", $value);
        
        $eduColorList[$key]['color']    = $arrTmp[0];
        $eduColorList[$key]['name']     = $arrTmp[1];
    }
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($tceduInfo['city_id']);
$streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($tceduInfo['area_id']);

$cateIdsStr = trim($tceduInfo['cate_ids'], '|');
$cateChildIdsStr = trim($tceduInfo['cate_child_ids'], '|');
$cateIdsArr = explode('|', $cateIdsStr.'|'.$cateChildIdsStr);

$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ");
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $itemInfoTmp = array();
        
        $itemInfoTmp['title']   = $value['name'];
        $itemInfoTmp['id']      = $value['id'];
        $itemInfoTmp['field']   = $value['name'];
        $itemInfoTmp['checked'] = false;
        $itemInfoTmp['spread']  = false;
        if(in_array($value['id'], $cateIdsArr)){
            $itemInfoTmp['spread']  = true;
        }
        
        if($value['pid'] > 0){
            if(in_array($value['id'], $cateIdsArr)){
                $itemInfoTmp['checked'] = true;
            }
            $cateChildList[$value['pid']][] = $itemInfoTmp;
        }else{
            $cateList[$value['id']] = $itemInfoTmp;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['children'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$tceduInfo['content'] = stripcslashes($tceduInfo['content']);
$video_pic = get_file_url($tceduInfo['video_pic']);
$kefu_qrcode = get_file_url($tceduInfo['kefu_qrcode']);
$business_licence = get_file_url($tceduInfo['business_licence']);

$tceduInfo['huanjing_score']    = floatval($tceduInfo['huanjing_score']);
$tceduInfo['teacher_score']     = floatval($tceduInfo['teacher_score']);
$tceduInfo['fuwu_score']        = floatval($tceduInfo['fuwu_score']);

$photoListTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(" AND tcedu_id = {$tcedu_id} AND type IN(1,2) ", "ORDER BY psort ASC,id ASC", 0, 100);
$photoList = array();
$i = 1;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        if($value['type'] == 1){
            $tceduInfo['picurl'] = $value['picurl'];
            $tceduInfo['picurlTmp'] = $value['picurlTmp'];
        }else{
            $photoList[$key] = $value;
            $photoList[$key]['pic_url'] = $value['picurlTmp'];
            $photoList[$key]['i'] = $i;
            $i++;
        }
    }
}
$photoCount = Count($photoList);

$eduTabsArr = array();
$edu_tab_str = str_replace("\r\n","{n}",$tceduConfig['edu_tab_list']); 
$edu_tab_str = str_replace("\n","{n}",$edu_tab_str);
$edu_tab_arr = explode("{n}", $edu_tab_str);
if(is_array($edu_tab_arr) && !empty($edu_tab_arr)){
    foreach ($edu_tab_arr as $key => $value){
        $value = trim($value);

        if(!empty($value)){
            $eduTabsArr[] = $value;
        }
    }
}

$tabsArray = explode('|', $tceduInfo['tabs']);
$tabsList = array();
foreach ($eduTabsArr as $key => $value){
    $tabsList[$key]['name'] = $value;
    $tabsList[$key]['status'] = 0;
    if(is_array($tabsArray) && !empty($tabsArray) && in_array($value, $tabsArray)){
        $tabsList[$key]['status'] = 1;
    }
}
$tabsArray = array_diff($tabsArray, $eduTabsArr);
$i = count($tabsList) + 1;
foreach ($tabsArray as $key => $value){
    $tabsList[$i]['name'] = $value;
    $tabsList[$i]['status'] = 1;
    $i++;
}

$saveUrl = $modPcadminUrl."&act=save";

$ossBatchUrl = 'plugin.php?id=tom_tcedu:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcedu:qiniuBatch';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/edit");