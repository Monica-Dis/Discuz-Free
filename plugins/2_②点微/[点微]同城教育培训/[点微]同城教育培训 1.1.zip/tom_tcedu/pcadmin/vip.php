<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=vip";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'update_status' && submitcheck('vip_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $vip_id = intval($_GET['vip_id'])>0 ? intval($_GET['vip_id']):0;
    $status = intval($_GET['status'])>0 ? intval($_GET['status']):0;
    
    $updateData = array();
    $updateData['status'] = $status;
    C::t("#tom_tcedu#tom_tcedu_vip")->update($vip_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('vip_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $vip_id = intval($_GET['vip_id'])>0 ? intval($_GET['vip_id']):0;
    
    $tceduCount = C::t('#tom_tcedu#tom_tcedu')->fetch_all_count("AND vip_id = {$vip_id} AND expire_status = 1 ");
    if($tceduCount > 0){
        $outArr = array(
            'code'  => 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    C::t('#tom_tcedu#tom_tcedu_vip')->delete_by_id($vip_id);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'import' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'code'=> 1,
    );
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcedu/config/import.data.php';
    
    foreach ($vipArr as $key => $value){
        $insertData = array();
        $insertData['name']                     = $value['name'];
        $insertData['logo']                     = $value['logo'];
        $insertData['days']                     = $value['days'];
        $insertData['days_msg']                 = $value['days_msg'];
        $insertData['price']                    = $value['price'];
        $insertData['open_video']               = $value['open_video'];
        $insertData['open_experience_course']   = $value['open_experience_course'];
        $insertData['experience_course_num']    = $value['experience_course_num'];
        $insertData['course_num']               = $value['course_num'];
        $insertData['xiangou_num']              = $value['xiangou_num'];
        $insertData['yongjin_bili']             = $value['yongjin_bili'];
        $insertData['vip_rank']                 = $value['vip_rank'];
        $insertData['status']                   = 1;
        $insertData['vsort']                    = $key;
        $insertData['add_time']                 = TIMESTAMP;
        C::t('#tom_tcedu#tom_tcedu_vip')->insert($insertData, true);
    }
    
    $outArr = array(
        'code'  => 200,
    );
    echo json_encode($outArr); exit;
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = '';

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_all_count($where);
$vipListTmp = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_all_list($where," ORDER BY vsort ASC,id DESC ",$start,$pagesize);
$vipList = array();
if(is_array($vipListTmp) && !empty($vipListTmp)){
    foreach ($vipListTmp as $key => $value) {
        $vipList[$key] = $value;
        
        $vipList[$key]['logo']      = get_file_url($value['logo']);
        $vipList[$key]['add_time']  = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/vip");