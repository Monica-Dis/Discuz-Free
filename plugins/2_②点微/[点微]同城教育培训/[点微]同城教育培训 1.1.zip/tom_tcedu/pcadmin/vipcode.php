<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=vipcode";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'zdadd' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $vip_id = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $num    = isset($_GET['num'])? intval($_GET['num']):0;

    if($num > 50){
        $num = 50;
    }
    
    $codeInfoTmp = C::t('#tom_tcedu#tom_tcedu_vip_code')->fetch_all_list(" ", " ORDER BY id DESC", 0, 1);
    $min_id = 1111;
    if(is_array($codeInfoTmp) && !empty($codeInfoTmp['0'])){
        $min_id = $codeInfoTmp['0']['id'] + 1;
    }

    $id = intval($min_id);
    for($i=0; $i<$num; $i++){
        $code = '';
        $len = strlen($id);
        $inviteCode = tom_random($len, 'qwertyupasdfghjkzxcvbnm');
        $no = strval($id);
        for($j=0;$j<$len;$j++){
            $code.=$inviteCode[$j].$no[$j];
        }
        
        $insertData = array();
        $insertData['id']           = $id++;
        $insertData['vip_id']       = $vip_id;
        $insertData['code']         = $code;
        $insertData['use_status']   = 0;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tcedu#tom_tcedu_vip_code')->insert($insertData);
    }
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
        
}else if($act == 'sdadd' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $vip_id     = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $content    = isset($_GET['content'])? addslashes($_GET['content']):'';

    $codeListStr = str_replace("\r\n","{n}",trim($content));
    $codeListStr = str_replace("\n","{n}",$codeListStr);
    $codeListStr = explode("{n}", $codeListStr);
    
    $codeInfoTmp = C::t('#tom_tcedu#tom_tcedu_vip_code')->fetch_all_list(" ", " ORDER BY id DESC", 0, 1);
    $min_id = 1111;
    if(is_array($codeInfoTmp) && !empty($codeInfoTmp['0'])){
        $min_id = $codeInfoTmp['0']['id'] + 1;
    }

    foreach($codeListStr as $key => $value){
        $insertData = array();
        $insertData['id']           = $min_id++;
        $insertData['vip_id']       = $vip_id;
        $insertData['code']         = trim($value);
        $insertData['use_status']   = 0;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tcedu#tom_tcedu_vip_code')->insert($insertData);
    }
        
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('vip_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $vip_id = intval($_GET['vip_id'])>0 ? intval($_GET['vip_id']):0;
    
    C::t('#tom_tcedu#tom_tcedu_vip_code')->delete_by_id($vip_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;
$vip_id         = intval($_GET['vip_id'])>0? intval($_GET['vip_id']):0;
$code           = isset($_GET['code'])? addslashes($_GET['code']):'';
$user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$tcedu_id       = intval($_GET['tcedu_id'])>0? intval($_GET['tcedu_id']):0;
$user_status    = intval($_GET['user_status'])>0? intval($_GET['user_status']):0;

$vipListTmp = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_all_list(" "," ORDER BY id DESC ");
$vipList = array();
if(is_array($vipListTmp) && !empty($vipListTmp)){
    foreach($vipListTmp as $key => $value){
        $vipList[$value['id']] = $value;
    }
}

$where = "";
if(!empty($code)){
    $code = str_replace(array('%', '_'),'',$code);
    $where .= " AND code LIKE '%{$code}%' ";
}
if($vip_id > 0){
    $where .= " AND vip_id={$vip_id} ";
}
if($user_id > 0){
    $where .= " AND user_id={$user_id} ";
}
if($tcedu_id > 0){
    $where .= " AND tcedu_id={$tcedu_id} ";
}
if($user_status == 1){
    $where .= " AND user_status=1 ";
}else if($user_status == 2){
    $where .= " AND user_status=0 ";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcedu#tom_tcedu_vip_code')->fetch_all_count($where);
$codeListTmp = C::t('#tom_tcedu#tom_tcedu_vip_code')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$codeList = array();
if(is_array($codeListTmp) && !empty($codeListTmp)){
    foreach ($codeListTmp as $key => $value) {
        $codeList[$key] = $value;
        
        $userInfoTmp = $tceduInfoTmp = array();
        if($value['use_status'] == 1){
            $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
            $tceduInfoTmp = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($value['tcedu_id']);
        }
        
        $codeList[$key]['vipInfo']      = $vipList[$value['vip_id']];
        $codeList[$key]['userInfo']     = $userInfoTmp;
        $codeList[$key]['tceduInfo']    = $tceduInfoTmp;
        $codeList[$key]['use_time']     = dgmdate($value['use_time'],"Y-m-d H:i:s",$tomSysOffset);
        $codeList[$key]['add_time']     = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcedu:pcadmin/vipcode");