<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function tom_random($length, $chars = '') {
	$hash = '';
	$max = strlen($chars) - 1;
	for($i = 0; $i < $length; $i++) {
		$hash .= $chars[mt_rand(0, $max)];
	}
	return $hash;
}

function auto_update_phb($phb_cate_id){
    global $tceduConfig;
    
    if($phb_cate_id <= 0){
        return false;
    }
    
    $phbCateInfo = C::t('#tom_tcedu#tom_tcedu_phb_cate')->fetch_by_id($phb_cate_id);
    if($phbCateInfo && $phbCateInfo['type'] > 1){ }else{
        return false;
    }
        
    $phb_auto_update_num = 10;
    if($tceduConfig['phb_auto_update_num'] > 0){
        $phb_auto_update_num = $tceduConfig['phb_auto_update_num'];
    }

    if($phb_auto_update_num > 50){
        $phb_auto_update_num = 50;
    }
    
    $phbListTmp = C::t("#tom_tcedu#tom_tcedu_phb")->fetch_all_list(" AND phb_cate_id = {$phb_cate_id} AND add_type = 2 ", 'ORDER BY id DESC');
    $phbNoAutoRankList = $phbTceduIdsArr = array();
    if(is_array($phbListTmp) && !empty($phbListTmp)){
        foreach($phbListTmp as $key => $value){
            $phbNoAutoRankList[] = $value['ranking'];
            $phbTceduIdsArr[] = $value['tcedu_id'];
        }
    }
    $phbCount = count($phbTceduIdsArr);
    if($phbCount > 0){
        $phb_auto_update_num = $phb_auto_update_num - $phbCount;
    }

    C::t("#tom_tcedu#tom_tcedu_phb")->delete_by_auto_phb_cate_id($phb_cate_id);

    $eduWhere = " AND site_id = {$phbCateInfo['site_id']} AND status=1 AND shenhe_status=1 AND expire_status = 1";
    if($phbCateInfo['cate_id'] > 0){
        $eduWhere .= " AND cate_ids LIKE '%|{$phbCateInfo['cate_id']}|%' ";
    }
    if($phbCateInfo['cate_child_id'] > 0){
        $eduWhere .= " AND cate_child_ids LIKE '%|{$phbCateInfo['cate_child_id']}|%' ";
    }
    if(!empty($phbTceduIdsArr)){
        $phbTceduIdsStr = implode(',', $phbTceduIdsArr);
        $eduWhere .= " AND id NOT IN({$phbTceduIdsStr}) ";
    }
    
    $eduOrder = "";
    if($phbCateInfo['type'] == 2){
        $eduOrder = 'ORDER BY renqi DESC,vip_rank DESC,id DESC';
    }
    
    $tceduListTmp = C::t("#tom_tcedu#tom_tcedu")->fetch_all_list($eduWhere, $eduOrder, 0, $phb_auto_update_num);
    $i = 1;
    if(is_array($tceduListTmp) && !empty($tceduListTmp)){
        foreach($tceduListTmp as $key => $value){
            $i = tom_back_rank($i, $phbNoAutoRankList);
            
            $insertData = array();
            $insertData['phb_cate_id']      = $phb_cate_id;
            $insertData['tcedu_id']         = $value['id'];
            $insertData['cate_id']          = $phbCateInfo['cate_id'];
            $insertData['cate_child_id']    = $phbCateInfo['cate_child_id'];
            $insertData['ranking']          = $i;
            $insertData['add_type']         = 1;
            $insertData['status']           = $phbCateInfo['status'];
            $insertData['add_time']         = TIMESTAMP;
            C::t('#tom_tcedu#tom_tcedu_phb')->insert($insertData);
            $i++;
        }
    }
    
    $updateData = array();
    $updateData['update_time'] = TIMESTAMP;
    C::t('#tom_tcedu#tom_tcedu_phb_cate')->update($phb_cate_id, $updateData);
}

function tom_back_rank($rank, $rankArr = array()){
    if(empty($rankArr)){
        return $rank;
    }
    if(in_array($rank, $rankArr)){
        $rank++;
        $rank = tom_back_rank($rank, $rankArr);
    }
    return $rank;
}

function update_edu_tcshop($tcedu_id,$paramArr = array()){
    
    if(is_array($paramArr) && !empty($paramArr)){
        $tceduConfig   = $paramArr['tceduConfig'];
    }else{
        global $tceduConfig;
    }
    
    $eduInfo = C::t("#tom_tcedu#tom_tcedu")->fetch_by_id($tcedu_id);
    if($eduInfo && $eduInfo['id'] > 0 && $eduInfo['is_ok'] == 1 && $eduInfo['status'] == 1 && $eduInfo['shenhe_status'] == 1 && $eduInfo['expire_status'] == 1 && $eduInfo['expire_time'] >= TIMESTAMP){
    }else{
        return false;
    }

    if($tceduConfig['open_tongbu_tcshop'] == 1){}else{
        return false;
    }
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($eduInfo['tcshop_id']);
    if($tceduConfig['tongbu_tcshop_type'] == 1 && $tcshopInfo && $tcshopInfo['id'] > 0){
        return false;
    }
    
    $eduVipInfo = C::t("#tom_tcedu#tom_tcedu_vip")->fetch_by_id($eduInfo['vip_id']);
    if($eduVipInfo && $eduVipInfo['tcshop_vip_id'] > 0){}else{
        return false;
    }
    
    $tcshopVipInfo = C::t("#tom_tcshop#tom_tcshop_vip")->fetch_by_id($eduVipInfo['tcshop_vip_id']);
    if($tcshopVipInfo && $tcshopVipInfo['id'] > 0){}else{
        return false;
    }
    
    $cateInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($tceduConfig['tcshop_cate_id']);
    if($cateInfo['id'] > 0){}else{
        return false;
    }

    $photoListTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(" AND tcedu_id = {$eduInfo['id']} AND type IN(1,2) "," ORDER BY id ASC ",0,100);
    $logo = '';
    $photoList = array();
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach($photoListTmp as $key => $value){
            if($value['type'] == 1){
                $logo = $value['picurl'];
            }else if($value['type'] == 2){
                $photoList[] = $value['picurl'];
            }
        }
    }
    
    if($tcshopInfo && $tcshopInfo['id'] > 0){
        
        $updateData = array();
        $updateData['site_id']          = $eduInfo['site_id'];
        $updateData['user_id']          = $eduInfo['user_id'];
        $updateData['name']             = $eduInfo['name'];
        $updateData['city_id']          = $eduInfo['city_id'];
        $updateData['area_id']          = $eduInfo['area_id'];
        $updateData['street_id']        = $eduInfo['street_id'];
        $updateData['address']          = $eduInfo['address'];
        $updateData['latitude']         = $eduInfo['latitude'];
        $updateData['longitude']        = $eduInfo['longitude'];
        $updateData['tel']              = $eduInfo['tel'];
        $updateData['shopkeeper_tel']   = $eduInfo['edu_tel'];
        $updateData['content']          = $eduInfo['content'];
        $updateData['picurl']           = $logo;
        $updateData['business_licence'] = $eduInfo['business_licence'];
        $updateData['part1']            = TIMESTAMP;
        C::t('#tom_tcshop#tom_tcshop')->update($tcshopInfo['id'],$updateData);
        
        C::t('#tom_tcshop#tom_tcshop_photo')->delete_by_tcshop_id($tcshopInfo['id']);
        
        if(is_array($photoList) && !empty($photoList)){
            foreach ($photoList as $key => $value){
                $insertData = array();
                $insertData['tcshop_id'] = $tcshopInfo['id'];
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcshop#tom_tcshop_photo')->insert($insertData);
            }
        }
        
    }else{
        
        $insertData = array();
        $insertData['site_id']          = $eduInfo['site_id'];
        $insertData['user_id']          = $eduInfo['user_id'];
        $insertData['name']             = $eduInfo['name'];
        $insertData['cate_id']          = $cateInfo['id'];
        $insertData['cate_child_id']    = 0;
        $insertData['city_id']          = $eduInfo['city_id'];
        $insertData['area_id']          = $eduInfo['area_id'];
        $insertData['street_id']        = $eduInfo['street_id'];
        $insertData['address']          = $eduInfo['address'];
        $insertData['latitude']         = $eduInfo['latitude'];
        $insertData['longitude']        = $eduInfo['longitude'];
        $insertData['tel']              = $eduInfo['tel'];
        $insertData['shopkeeper_tel']   = $eduInfo['edu_tel'];
        $insertData['content']          = $eduInfo['content'];
        $insertData['picurl']           = $logo;
        $insertData['business_licence'] = $eduInfo['business_licence'];;
        $insertData['is_ok']            = 1;
        $insertData['status']           = 1;
        $insertData['shenhe_status']    = 1;
        $insertData['vip_id']           = $tcshopVipInfo['id'];
        $insertData['vip_rank']         = $tcshopVipInfo['rank'];
        $insertData['vip_status']       = 1;
        $insertData['vip_time']         = $eduInfo['expire_time'];
        $insertData['ruzhu_time']       = TIMESTAMP;
        C::t('#tom_tcshop#tom_tcshop')->insert($insertData);
        
        $tcshop_id = C::t('#tom_tcshop#tom_tcshop')->insert_id();
        
        $updateData = array();
        $updateData['tcshop_id']   = $tcshop_id;
        C::t('#tom_tcedu#tom_tcedu')->update($eduInfo['id'],$updateData);
        
        if(is_array($photoList) && !empty($photoList)){
            foreach ($photoList as $key => $value){
                $insertData = array();
                $insertData['tcshop_id'] = $tcshop_id;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcshop#tom_tcshop_photo')->insert($insertData);
            }
        }
    }
    
    return true;
}

/**
 * ��ɫ16���� ת RGB
 */
function hex2rgbstr($hexColor){
    
    $color = str_replace('#','',$hexColor);
    if (strlen($color)> 3){
         $rgb = array(
              'r'=>hexdec(substr($color,0,2)),
              'g'=>hexdec(substr($color,2,2)),
              'b'=>hexdec(substr($color,4,2))
         );
    }else{
         $r = substr($color,0,1). substr($color,0,1);
         $g = substr($color,1,1). substr($color,1,1);
         $b = substr($color,2,1). substr($color,2,1);
         $rgb = array( 
              'r'=>hexdec($r),
              'g'=>hexdec($g),
              'b'=>hexdec($b)
         );
    }
    return $rgb['r'].','.$rgb['g'].','.$rgb['b'];
 
}