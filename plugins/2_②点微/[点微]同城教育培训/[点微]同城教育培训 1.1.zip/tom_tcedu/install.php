<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcedu`;
CREATE TABLE `pre_tom_tcedu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `manage_user_id` int(11) DEFAULT '0',
  `vip_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `theme_color` varchar(255) DEFAULT NULL,
  `cate_ids` varchar(255) DEFAULT NULL,
  `cate_child_ids` varchar(255) DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `street_id` int(11) DEFAULT '0',
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `tabs` varchar(255) DEFAULT NULL,
  `huanjing_score` decimal(10,3) DEFAULT '0.000',
  `fuwu_score` decimal(10,3) DEFAULT '0.000',
  `teacher_score` decimal(10,3) DEFAULT '0.000',
  `total_score` decimal(10,3) DEFAULT '0.000',
  `edu_xm` varchar(255) DEFAULT NULL,
  `edu_tel` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `admin_edit` tinyint(4) DEFAULT '0',
  `content` mediumtext,
  `video_status` tinyint(4) DEFAULT '0',
  `video_url` varchar(255) DEFAULT NULL,
  `video_pic` varchar(255) DEFAULT NULL,
  `kefu_qrcode` varchar(255) DEFAULT NULL,
  `business_licence` varchar(255) DEFAULT NULL,
  `search_text` varchar(255) DEFAULT NULL,
  `virtual_clicks` int(11) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `renqi` int(11) DEFAULT '0',
  `pinglun_count` int(11) DEFAULT '0',
  `is_ok` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `vip_rank` int(11) DEFAULT '0',
  `shenhe_status` tinyint(4) DEFAULT '0',
  `expire_status` tinyint(4) DEFAULT '0',
  `expire_time` int(11) unsigned DEFAULT '0',
  `top_status` tinyint(4) DEFAULT '0',
  `top_time` int(11) unsigned DEFAULT '0',
  `top_rand` int(11) DEFAULT '0',
  `update_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_expire_status` (`expire_status`),
  KEY `idx_cate_ids` (`cate_ids`),
  KEY `idx_cate_child_ids` (`cate_child_ids`),
  KEY `idx_vip_id` (`vip_id`),
  KEY `idx_area_id` (`area_id`),
  KEY `idx_street_id` (`street_id`),
  KEY `idx_renqi` (`renqi`),
  KEY `idx_top_status` (`top_status`),
  KEY `idx_top_rand` (`top_rand`),
  KEY `idx_vip_rank` (`vip_rank`),
  KEY `idx_is_ok` (`is_ok`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_attr`;
CREATE TABLE `pre_tom_tcedu_attr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcedu_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '1',
  `value` text,
  `is_must` int(11) DEFAULT '0',
  `is_show` tinyint(4) DEFAULT '0',
  `unit` varchar(255) DEFAULT NULL,
  `msg` varchar(255) DEFAULT NULL,
  `asort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tcedu_id` (`tcedu_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_cate`;
CREATE TABLE `pre_tom_tcedu_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `pid` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `csort` int(11) DEFAULT '100',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_common`;
CREATE TABLE `pre_tom_tcedu_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `clicks` int(11) DEFAULT '0',
  `xieyi_txt` text,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_course`;
CREATE TABLE `pre_tom_tcedu_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tcedu_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `street_id` int(11) DEFAULT '0',
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `cate_id` int(11) DEFAULT '0',
  `cate_child_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `tabs` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '0',
  `teacher_ids` varchar(255) DEFAULT NULL,
  `attr_ids` varchar(255) DEFAULT NULL,
  `course_cate_id` int(11) DEFAULT '0',
  `market_price` decimal(10,2) DEFAULT '0.00',
  `buy_price` decimal(10,2) DEFAULT '0.00',
  `open_vip` tinyint(4) DEFAULT '0',
  `vip_price` decimal(10,2) DEFAULT '0.00',
  `class_type` tinyint(4) DEFAULT '0',
  `class_num` int(11) DEFAULT '0',
  `hasoption` tinyint(4) DEFAULT '0',
  `show_market_price` decimal(10,2) DEFAULT '0.00',
  `show_buy_price` decimal(10,2) DEFAULT '0.00',
  `show_vip_price` decimal(10,2) DEFAULT '0.00',
  `xiangou_num` int(11) DEFAULT '0',
  `hexiao_time` int(11) unsigned DEFAULT '0',
  `hexiao_limit` tinyint(4) DEFAULT '0',
  `hexiao_days` int(11) DEFAULT '0',
  `open_bm_end_time` tinyint(4) DEFAULT '0',
  `bm_end_time` int(11) unsigned DEFAULT '0',
  `haibao_type` tinyint(4) DEFAULT '1',
  `haibao_picurl` varchar(255) DEFAULT NULL,
  `qrcode_location` tinyint(4) DEFAULT '0',
  `haibao_text_color` varchar(255) DEFAULT NULL,
  `admin_edit` tinyint(4) DEFAULT '0',
  `content` mediumtext,
  `search_text` varchar(255) DEFAULT NULL,
  `clicks` int(11) DEFAULT '0',
  `virtual_clicks` int(11) DEFAULT '0',
  `sale_num` int(11) DEFAULT '0',
  `top_status` tinyint(4) DEFAULT '0',
  `top_time` int(11) unsigned DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `shenhe_status` tinyint(4) DEFAULT '0',
  `hehuoren_tg_open` tinyint(4) DEFAULT '0',
  `hehuoren_tg_type` tinyint(4) DEFAULT '0',
  `hehuoren_fc_scale` decimal(10,2) DEFAULT '0.00',
  `hehuoren_fc_scale2` decimal(10,2) DEFAULT '0.00',
  `deleted` tinyint(4) DEFAULT '0',
  `update_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_tcedu_id` (`tcedu_id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_deleted` (`deleted`),
  KEY `idx_course_cate_id` (`course_cate_id`),
  KEY `idx_type` (`type`),
  KEY `idx_class_type` (`class_type`),
  KEY `idx_cate_id` (`cate_id`),
  KEY `idx_cate_child_id` (`cate_child_id`),
  KEY `idx_area_id` (`area_id`),
  KEY `idx_street_id` (`street_id`),
  KEY `idx_top_status` (`top_status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_course_bm`;
CREATE TABLE `pre_tom_tcedu_course_bm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcedu_id` int(11) DEFAULT '0',
  `tcedu_name` varchar(255) DEFAULT NULL,
  `course_id` int(11) DEFAULT '0',
  `course_name` varchar(255) DEFAULT NULL,
  `option_id` int(11) DEFAULT '0',
  `option_name` varchar(255) DEFAULT NULL,
  `order_no` varchar(255) DEFAULT NULL,
  `hexiao_no` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `vip_pay_status` tinyint(4) DEFAULT '0',
  `pay_status` tinyint(4) DEFAULT '0',
  `use_status` tinyint(4) DEFAULT '0',
  `class_num` int(11) DEFAULT '0',
  `use_num` int(11) DEFAULT '0',
  `hexiao_time` varchar(255) DEFAULT NULL,
  `hexiao_user_id` int(11) DEFAULT '0',
  `pinglun_status` tinyint(4) DEFAULT '0',
  `refund_status` tinyint(4) DEFAULT '0',
  `refund_add_time` int(11) unsigned DEFAULT '0',
  `refund_no` varchar(255) DEFAULT NULL,
  `refund_price` decimal(10,2) DEFAULT '0.00',
  `refund_beizu` varchar(255) DEFAULT NULL,
  `shenqing_refund_msg` varchar(255) DEFAULT NULL,
  `refund_type` tinyint(4) DEFAULT '0',
  `wx_refund_status` tinyint(4) DEFAULT '0',
  `balance_status` tinyint(4) DEFAULT '0',
  `refund_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tcedu_id` (`tcedu_id`),
  KEY `idx_course_id` (`course_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_pay_status` (`pay_status`),
  KEY `idx_use_status` (`use_status`),
  KEY `idx_pinglun_status` (`pinglun_status`),
  KEY `idx_refund_status` (`refund_status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_course_bm_attr`;
CREATE TABLE `pre_tom_tcedu_course_bm_attr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bm_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `tcedu_id` int(11) DEFAULT '0',
  `course_id` int(11) DEFAULT '0',
  `attr_id` int(11) DEFAULT '0',
  `attr_type` int(11) DEFAULT '0',
  `attr_name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `asort` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tcedu_id` (`tcedu_id`),
  KEY `idx_course_id` (`course_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_course_bm_log`;
CREATE TABLE `pre_tom_tcedu_course_bm_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bm_id` int(11) DEFAULT '0',
  `tcedu_id` int(11) DEFAULT '0',
  `course_id` int(11) DEFAULT '0',
  `use_num` int(11) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_course_cate`;
CREATE TABLE `pre_tom_tcedu_course_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcedu_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `csort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_course_collect`;
CREATE TABLE `pre_tom_tcedu_course_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcedu_id` int(11) DEFAULT '0',
  `course_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_course_option`;
CREATE TABLE `pre_tom_tcedu_course_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcedu_id` int(11) DEFAULT '0',
  `course_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `market_price` decimal(10,2) DEFAULT '0.00',
  `buy_price` decimal(10,2) DEFAULT '0.00',
  `vip_price` decimal(10,2) DEFAULT '0.00',
  `class_num` int(11) DEFAULT '0',
  `sale_num` int(11) DEFAULT '0',
  `osort` int(11) DEFAULT '10',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_diynav`;
CREATE TABLE `pre_tom_tcedu_diynav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `name` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `cate_id` int(11) DEFAULT '0',
  `cate_child_id` int(11) DEFAULT '0',
  `link` varchar(255) DEFAULT NULL,
  `add_time` int(11) unsigned DEFAULT '0',
  `dsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_focuspic`;
CREATE TABLE `pre_tom_tcedu_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_guanzu`;
CREATE TABLE `pre_tom_tcedu_guanzu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcedu_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_history`;
CREATE TABLE `pre_tom_tcedu_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `tcedu_id` int(11) DEFAULT '0',
  `course_id` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_order`;
CREATE TABLE `pre_tom_tcedu_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tcedu_id` int(11) DEFAULT '0',
  `tcedu_name` varchar(255) DEFAULT NULL,
  `course_id` int(11) DEFAULT '0',
  `course_name` varchar(255) DEFAULT NULL,
  `option_id` int(11) DEFAULT '0',
  `option_name` varchar(255) DEFAULT NULL,
  `course_bm_id` int(11) DEFAULT '0',
  `vip_id` int(11) DEFAULT '0',
  `vip_days` int(11) DEFAULT '0',
  `vip_price` decimal(10,2) DEFAULT '0.00',
  `top_days` int(11) DEFAULT '0',
  `top_price` decimal(10,2) DEFAULT '0.00',
  `order_type` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `order_no` varchar(255) DEFAULT NULL,
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `vip_pay_status` tinyint(4) DEFAULT '0',
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `pay_time` int(11) unsigned DEFAULT '0',
  `order_status` tinyint(4) DEFAULT '0',
  `order_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_order_status` (`order_status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_phb`;
CREATE TABLE `pre_tom_tcedu_phb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phb_cate_id` int(11) DEFAULT '0',
  `tcedu_id` int(11) DEFAULT '0',
  `cate_id` int(11) DEFAULT '0',
  `cate_child_id` int(11) DEFAULT '0',
  `ranking` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `add_type` tinyint(4) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_phb_cate`;
CREATE TABLE `pre_tom_tcedu_phb_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `name` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '1',
  `picurl` varchar(255) DEFAULT NULL,
  `cate_id` int(11) DEFAULT '0',
  `cate_child_id` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `update_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_photo`;
CREATE TABLE `pre_tom_tcedu_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcedu_id` int(11) DEFAULT '0',
  `pinglun_id` int(11) DEFAULT '0',
  `course_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `oss_picurl` varchar(255) DEFAULT NULL,
  `oss_status` int(11) DEFAULT '0',
  `qiniu_picurl` varchar(255) DEFAULT NULL,
  `qiniu_status` int(11) DEFAULT '0',
  `psort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_pinglun`;
CREATE TABLE `pre_tom_tcedu_pinglun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcedu_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `course_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '1',
  `course_name` varchar(255) DEFAULT NULL,
  `huanjing_score` tinyint(4) DEFAULT '0',
  `fuwu_score` tinyint(4) DEFAULT '0',
  `teacher_score` tinyint(4) DEFAULT '0',
  `total_score` tinyint(4) DEFAULT '0',
  `photo_status` tinyint(4) DEFAULT '0',
  `content` text,
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_popup`;
CREATE TABLE `pre_tom_tcedu_popup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_ids` text,
  `link` varchar(255) DEFAULT NULL,
  `clicks` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `show_num` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_popup_log`;
CREATE TABLE `pre_tom_tcedu_popup_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `popup_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `num` int(11) DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_renqi_log`;
CREATE TABLE `pre_tom_tcedu_renqi_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tcedu_id` int(11) DEFAULT '0',
  `today_time` int(11) unsigned DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_teacher`;
CREATE TABLE `pre_tom_tcedu_teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcedu_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `teach_age` tinyint(4) DEFAULT '0',
  `desc` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `tsort` int(11) DEFAULT '10',
  `status` tinyint(4) DEFAULT '0',
  `open_hexiao` tinyint(4) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_vip`;
CREATE TABLE `pre_tom_tcedu_vip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `days` int(11) DEFAULT '0',
  `days_msg` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `open_video` tinyint(4) DEFAULT '0',
  `open_experience_course` tinyint(4) DEFAULT '0',
  `experience_course_num` int(11) DEFAULT '0',
  `course_num` int(11) DEFAULT '0',
  `xiangou_num` int(11) DEFAULT '0',
  `yongjin_bili` int(11) DEFAULT '0',
  `vip_rank` int(11) DEFAULT '0',
  `tcshop_vip_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `vsort` int(11) unsigned DEFAULT '100',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_vip_code`;
CREATE TABLE `pre_tom_tcedu_vip_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vip_id` int(11) DEFAULT '0',
  `code` varchar(255) DEFAULT NULL,
  `use_status` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `tcedu_id` int(11) DEFAULT '0',
  `use_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcedu_vip_log`;
CREATE TABLE `pre_tom_tcedu_vip_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tcedu_id` int(11) DEFAULT '0',
  `vip_code_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `vip_id` int(11) DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;