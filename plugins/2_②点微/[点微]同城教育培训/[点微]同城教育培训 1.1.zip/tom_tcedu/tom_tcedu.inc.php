<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$timeStamp = TIMESTAMP;
$tceduConfig = $_G['cache']['plugin']['tom_tcedu'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = '20210719';
$sql_in_site_ids = $site_id;
if (!file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/tom_tongcheng.inc.php')) {
	echo '<a href="https://dism.taobao.com/?@tom_tongcheng.plugin">https://dism.taobao.com/?@tom_tongcheng.plugin</a>';
	exit(0);
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tcedu/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/function.html.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tceduConfig['wx_share_title'];
$shareDesc = $tceduConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . 'plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index';
$shareLogo = $tceduConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tcedu/config/config.data.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')) {
	$tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
	if ($tcyikatongConfig['open_tcyikatong'] == 1) {
		$__ShowTcyikatong = 1;
	}
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$tcadminConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcadmin/tom_tcadmin.inc.php')) {
	$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
$__ShowVideo = 0;
if ($tceduConfig['open_video'] == 1) {
	if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/video.inc.php')) {
		$__ShowVideo = 1;
	}
}
$__TjShowStatus = 0;
if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
	if ($tchehuorenConfig['tcedu_type'] == 1 || $tchehuorenConfig['tcedu_type'] == 3) {
		if ($tj_hehuoren_id > 0) {
			$lifeTime = 86400;
			dsetcookie('tom_tcedu_tj_hehuoren_id', $tj_hehuoren_id, $lifeTime);
		} else {
			$cookie_tj_hehuoren_id = getcookie('tom_tcedu_tj_hehuoren_id');
			if ($cookie_tj_hehuoren_id > 0) {
				$tj_hehuoren_id = $cookie_tj_hehuoren_id;
			}
		}
	}
	if ($tchehuorenConfig['tcedu_type'] == 2 && $__UserInfo['tj_hehuoren_id'] > 0) {
		$tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
	}
	if ($tchehuorenConfig['tcedu_type'] == 3 && $__UserInfo['tj_hehuoren_id'] > 0 && $tj_hehuoren_id == 0) {
		$tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
	}
	$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
	$tchehuorenInfo = array();
	if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
		$__TjShowStatus = 1;
		$tchehuorenInfo = $tchehuorenInfoTmp;
		$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfo['id']);
	}
}
$__CommonInfo = C::t('#tom_tcedu#tom_tcedu_common')->fetch_by_site_id($site_id);
if (!$__CommonInfo) {
	$insertData = array();
	$insertData['site_id'] = $site_id;
	C::t('#tom_tcedu#tom_tcedu_common')->insert($insertData);
}
$__CardInfo = array();
if ($__ShowTcyikatong == 1 && $__UserInfo['id'] > 0) {
	$cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($__UserInfo['id']);
	if (is_array($cardInfoTmp) && !empty($cardInfoTmp)) {
		$__CardInfo = $cardInfoTmp;
	}
}
if ($__ShowTcyikatong == 1) {
	$card_name = cutstr($tcyikatongConfig['card_name'], 6, '');
	$buyVipUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=card';
}
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&formhash=' . $formhash;
$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
$ajaxAutoPinglunUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=auto_pinglun&formhash=' . $formhash;
$ajaxUpdateEduUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=update_edu&formhash=' . $formhash;
$ajaxRefundqueryUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=refundquery&formhash=' . $formhash;
$ajaxCommonClicksUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=commonClicks&formhash=' . $formhash;
$ajaxUpdateToprandUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=updateToprand&&formhash=' . $formhash;
$back_url = $weixinClass->get_url();
$back_url = urlencode($back_url);
$loginUrl = $_G['siteurl'] . 'plugin.php?id=tom_ucenter&mod=login&t_from=tongcheng&t_back=' . $back_url;
$template_color_rgb = '';
if (!empty($tceduConfig['template_color'])) {
	$template_color_rgb = hex2rgbstr($tceduConfig['template_color']);
}
if ($_GET['mod'] == 'index') {
	if ($tceduConfig['open_select_sites'] == 1 && $tcadminConfig['open_sites'] == 1) {
		include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/selectSites.php';
	}
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$commonClicks = C::t('#tom_tcedu#tom_tcedu_common')->fetch_all_sun_clicks(' AND site_id IN(' . $sql_in_site_ids . ') ');
	$clicksNum = $commonClicks + $tceduConfig['virtual_clicks'];
	$clicksNumTxt = $clicksNum;
	if ($clicksNum > 10000) {
		$clicksNumTmp = $clicksNum / 10000;
		$clicksNumTxt = number_format($clicksNumTmp, 2, '.', '');
	}
	$allTceduCount = C::t('#tom_tcedu#tom_tcedu')->fetch_all_count(' AND status=1 AND shenhe_status=1 AND expire_status = 1 ');
	$allTceduNum = $allTceduCount + $tceduConfig['virtual_edu'];
	$allTceduNumTxt = $allTceduNum;
	if ($allTceduNum > 10000) {
		$allTceduNumTmp = $allTceduNum / 10000;
		$allTceduNumTxt = number_format($allTceduNumTmp, 2, '.', '');
	}
	$allCourseCount = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(' AND status = 1 AND shenhe_status = 1 AND deleted = 0 ');
	$allCourseNum = $allCourseCount + $tceduConfig['virtual_course'];
	$allCourseNumTxt = $allCourseNum;
	if ($allCourseNum > 10000) {
		$allCourseNumTmp = $allCourseNum / 10000;
		$allCourseNumTxt = number_format($allCourseNumTmp, 2, '.', '');
	}
	$focuspicTopListTmp = C::t('#tom_tcedu#tom_tcedu_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicTopListTmp) || empty($focuspicTopListTmp)) {
		$focuspicTopListTmp = C::t('#tom_tcedu#tom_tcedu_focuspic')->fetch_all_list(' AND site_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicTopList = array();
	if (is_array($focuspicTopListTmp) && !empty($focuspicTopListTmp)) {
		foreach ($focuspicTopListTmp as $key => $value) {
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$focuspicTopList[$key] = $value;
			$focuspicTopList[$key]['picurl'] = $picurlTmp;
			$focuspicTopList[$key]['link'] = str_replace('{site}', $site_id, $value['link']);
		}
	}
	$focuspicTopCount = count($focuspicTopList);
	$lineNavList = array();
	if (!empty($tceduConfig['index_line_nav'])) {
		$index_line_str = str_replace("\r\n", '{n}', trim($tceduConfig['index_line_nav']));
		$index_line_str = str_replace("\n", '{n}', $index_line_str);
		$index_line_str = str_replace('{site}', $site_id, $index_line_str);
		$index_line_arr = explode('{n}', $index_line_str);
		if (is_array($index_line_arr) && !empty($index_line_arr)) {
			foreach ($index_line_arr as $key => $value) {
				$lineNavList[] = explode('|', $value);
			}
		}
	}
	$lineNavCount = count($lineNavList);
	$diyListTmp = C::t('#tom_tcedu#tom_tcedu_diynav')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY dsort ASC,id DESC ');
	if (!is_array($diyListTmp) || empty($diyListTmp)) {
		if ($site_id > 1) {
			$diyListTmp = C::t('#tom_tcedu#tom_tcedu_diynav')->fetch_all_list(' AND site_id=1 ', ' ORDER BY dsort ASC,id DESC ');
		}
	}
	$diyList = array();
	$i = 1;
	if (is_array($diyListTmp) && !empty($diyListTmp)) {
		foreach ($diyListTmp as $key => $value) {
			$diyList[$key] = $value;
			$diyList[$key]['i'] = $i;
			$diyList[$key]['link'] = str_replace('{site}', $site_id, $diyList[$key]['link']);
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$diyList[$key]['picurl'] = $picurlTmp;
			if ($value['type'] == 1) {
				$diyList[$key]['link'] = 'plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=list&cate_id=' . $value['cate_id'];
				if ($value['cate_child_id'] > 0) {
					$diyList[$key]['link'] = 'plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=list&cate_id=' . $value['cate_id'] . '&cate_child_id=' . $value['cate_child_id'];
				}
			}
			$i++;
		}
	}
	$navCount = count($diyList);
	$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(' AND pid = 0 AND status = 1 ', 'ORDER BY csort ASC,id ASC', 0, 100);
	$cateList = array();
	$i = 1;
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			$cateList[$key]['i'] = $i;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$cateList[$key]['picurl'] = $picurlTmp;
			$i++;
		}
	}
	$cateCount = count($cateList);
	$courseListTmp = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_list(' AND type = 2 AND site_id IN(' . $sql_in_site_ids . ') AND status = 1 AND shenhe_status = 1 AND deleted = 0 ', 'ORDER BY top_status DESC,id DESC', 0, 12);
	$courseList = array();
	$j = $i = 0;
	if (is_array($courseListTmp) && !empty($courseListTmp)) {
		foreach ($courseListTmp as $key => $value) {
			$tceduInfoTmp = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($value['tcedu_id']);
			$photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(' AND course_id = ' . $value['id'] . ' AND type = 4 ', 'ORDER BY id DESC', 0, 1);
			$picurlTmp = '';
			if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
				$picurlTmp = $photoInfoTmp[0]['picurlTmp'];
			}
			if ($i % 3 == 0) {
				$j++;
			}
			$courseList[$j]['list'][$key] = $value;
			$courseList[$j]['list'][$key]['picurl'] = $picurlTmp;
			$courseList[$j]['list'][$key]['tceduInfo'] = $tceduInfoTmp;
			$i++;
		}
	}
	$courseCount = count($courseList);
	$popupInfoTmp = C::t('#tom_tcedu#tom_tcedu_popup')->fetch_all_by_site_ids(' AND status=1', ' ORDER BY id DESC ', 0, 1, '[' . $site_id . ']');
	$popupInfo = array();
	if ($popupInfoTmp && !empty($popupInfoTmp[0])) {
		$popupInfo = $popupInfoTmp[0];
		$ajaxLoadPopupUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=load_popup&formhash=' . $formhash;
		$ajaxClosePopupUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=close_popup&formhash=' . $formhash;
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tcedu/images/index.js';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:index');
	echo '<script src="source/plugin/tom_tcedu/images/index.js"></script>';
} elseif ($_GET['mod'] == 'list') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$tabs = isset($_GET['tabs']) ? addslashes(urldecode($_GET['tabs'])) : '';
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$ordertype = isset($_GET['ordertype']) ? addslashes($_GET['ordertype']) : '';
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$areaList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$cateName = '';
	$cateList = array();
	$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(' AND pid = 0 AND status =1 ', 'ORDER BY csort ASC,id DESC');
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			if ($cate_id == $value['id']) {
				$cateName = $value['name'];
			}
		}
	}
	if ($cate_id > 0) {
		$cateChildListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(' AND pid = ' . $cate_id . ' AND status =1  ', 'ORDER BY csort ASC,id DESC');
		$cateChildList = array();
		if (is_array($cateChildListTmp) && !empty($cateChildListTmp)) {
			foreach ($cateChildListTmp as $key => $value) {
				$cateChildList[$key] = $value;
				if ($cate_child_id == $value['id']) {
					$cateName = $value['name'];
				}
			}
		}
	}
	$eduTabsArr = array();
	$edu_tab_str = str_replace("\r\n", '{n}', $tceduConfig['edu_tab_list']);
	$edu_tab_str = str_replace("\n", '{n}', $edu_tab_str);
	$edu_tab_arr = explode('{n}', $edu_tab_str);
	if (is_array($edu_tab_arr) && !empty($edu_tab_arr)) {
		foreach ($edu_tab_arr as $key => $value) {
			$value = trim($value);
			if (!empty($value)) {
				$eduTabsArr[] = $value;
			}
		}
	}
	$selectTabsArr = explode(',', $tabs);
	$tabsList = array();
	foreach ($eduTabsArr as $key => $value) {
		$tabsList[$key]['name'] = $value;
		$tabsList[$key]['status'] = 0;
		if (is_array($selectTabsArr) && !empty($selectTabsArr) && in_array($value, $selectTabsArr)) {
			$tabsList[$key]['status'] = 1;
		}
	}
	$where = ' AND status = 1 AND shenhe_status = 1 AND expire_status = 1 ';
	if (!empty($sql_in_site_ids)) {
		$where .= ' AND site_id IN(' . $sql_in_site_ids . ') ';
	}
	if (!empty($keyword)) {
		$keyword = str_replace(array('%', '_'), '', $keyword);
		$where .= ' AND search_text LIKE \'%' . $keyword . '%\' ';
	}
	if (!empty($tabs)) {
		$selectTabsArr = explode(',', $tabs);
		foreach ($selectTabsArr as $key => $value) {
			$value = str_replace(array('%', '_'), '', $value);
			$where .= ' AND tabs LIKE \'%' . $value . '%\' ';
		}
	}
	if ($cate_id > 0) {
		$where .= ' AND cate_ids LIKE \'%|' . $cate_id . '|%\' ';
	}
	if ($cate_child_id > 0) {
		$where .= ' AND cate_child_ids LIKE \'%|' . $cate_child_id . '|%\' ';
	}
	if ($area_id > 0) {
		$where .= ' AND area_id = ' . $area_id . ' ';
	}
	if ($street_id > 0) {
		$where .= ' AND street_id = ' . $street_id . ' ';
	}
	$tceduCount = C::t('#tom_tcedu#tom_tcedu')->fetch_all_count($where);
	$list_cate_name = $tceduConfig['edu_list_cate_name'];
	if ($cate_id > 0) {
		$list_cate_name = $cateName;
	}
	if (!empty($tceduConfig['edu_list_share_title'])) {
		$shareTitle = $tceduConfig['edu_list_share_title'];
		$shareTitle = str_replace('{CATENAME}', $list_cate_name, $shareTitle);
		$shareTitle = str_replace('{NUM}', $tceduCount, $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tceduConfig['edu_list_share_desc'])) {
		$shareDesc = $tceduConfig['edu_list_share_desc'];
		$shareDesc = str_replace('{CATENAME}', $list_cate_name, $shareDesc);
		$shareDesc = str_replace('{NUM}', $tceduCount, $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	if (!empty($tceduConfig['edu_share_pic'])) {
		$shareLogo = $tceduConfig['edu_share_pic'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=list&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&area_id=' . $area_id . '&street_id=' . $street_id . '&s=1');
	if ($__TjShowStatus == 1) {
		$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfo['id']);
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=list&keyword=' . $keyword . '&tabs=' . $tabs . '&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&area_id=' . $area_id . '&street_id=' . $street_id . '&ordertype=' . $ordertype . '&s=' . $s));
	$ajaxLoadCateListUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=load_cate_list&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$searchUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=search&');
	$searchAjaxUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=get_search_url&formhash=' . $formhash;
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:list');
} elseif ($_GET['mod'] == 'search') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$tabs = isset($_GET['tabs']) ? daddslashes(diconv(urldecode($_GET['tabs']), 'utf-8')) : '';
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$ordertype = isset($_GET['ordertype']) ? addslashes($_GET['ordertype']) : '';
	$cookieKeywordsStr = getcookie('tom_tcedu_search_keywords_str');
	$keywordsArr = array();
	if (!empty($cookieKeywordsStr)) {
		$keywordsArr = explode('|', $cookieKeywordsStr);
	}
	$keywordsCount = count($keywordsArr);
	$defaultStr = $tceduConfig['default_edu_search_str'];
	$defaultArr = array();
	if (!empty($defaultStr)) {
		$defaultArr = explode('|', $defaultStr);
	}
	$defaultCount = count($defaultArr);
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=search&s=1');
	if ($__TjShowStatus == 1) {
		$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfo['id']);
	}
	$searchUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=get_search_url&formhash=' . $formhash;
	$ajaxClearSearchUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=clear_search&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:search');
} elseif ($_GET['mod'] == 'info') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$tcedu_id = intval($_GET['tcedu_id']) > 0 ? intval($_GET['tcedu_id']) : 0;
	$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
	if ($tceduInfo['id'] > 0) {
		if ($tceduInfo['status'] != 1 || $tceduInfo['shenhe_status'] != 1) {
			if ($__UserInfo['groupid'] != 1 && $__UserInfo['groupid'] != 2) {
				tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
				exit(0);
			}
		}
	} else {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$vipInfo = array();
	$showEndVipTimeBox = 0;
	if ($tceduInfo['vip_id'] > 0 && $tceduInfo['expire_status'] == 1 && $tceduInfo['expire_time'] >= TIMESTAMP) {
		$vipInfo = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_by_id($tceduInfo['vip_id']);
	} else {
		$showEndVipTimeBox = 1;
	}
	if ($tceduInfo['video_status'] == 1 && $vipInfo['open_video'] == 1) {
		if (!preg_match('/^http/', $tceduInfo['video_pic'])) {
			if (strpos($tceduInfo['video_pic'], 'source/plugin/tom_') === false) {
				$tceduInfo['video_pic'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tceduInfo['video_pic'];
			} else {
				$tceduInfo['video_pic'] = $_G['siteurl'] . $tceduInfo['video_pic'];
			}
		} else {
			$tceduInfo['video_pic'] = $tceduInfo['video_pic'];
		}
	}
	$tceduInfo['clicks'] = $tceduInfo['virtual_clicks'] + $tceduInfo['clicks'];
	$tceduInfo['total_bili'] = $tceduInfo['total_score'] / 5 * 100;
	$tceduInfo['huanjing_score'] = sprintf('%.1f', round($tceduInfo['huanjing_score'], 1));
	$tceduInfo['fuwu_score'] = sprintf('%.1f', round($tceduInfo['fuwu_score'], 1));
	$tceduInfo['teacher_score'] = sprintf('%.1f', round($tceduInfo['teacher_score'], 1));
	$tceduInfo['total_score'] = sprintf('%.1f', round($tceduInfo['total_score'], 1));
	if ($tceduInfo['admin_edit'] == 1) {
		$tceduInfo['content'] = stripslashes($tceduInfo['content']);
	} else {
		$tceduInfo['content'] = stripslashes($tceduInfo['content']);
		$tceduInfo['content'] = strip_tags($tceduInfo['content']);
		$tceduInfo['content'] = str_replace("\r\n", '<br/>', $tceduInfo['content']);
		$tceduInfo['content'] = str_replace("\n", '<br/>', $tceduInfo['content']);
		$tceduInfo['content'] = str_replace("\r", '<br/>', $tceduInfo['content']);
	}
	if (!preg_match('/^http/', $tceduInfo['kefu_qrcode']) && !empty($tceduInfo['kefu_qrcode'])) {
		if (strpos($tceduInfo['kefu_qrcode'], 'source/plugin/tom_') === false) {
			$tceduInfo['kefu_qrcode'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tceduInfo['kefu_qrcode'];
		}
	}
	$photoListTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND type IN(1,2) ', ' ORDER BY psort ASC,id ASC ', 0, 100);
	$photoList = array();
	$logoPicurl = '';
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			if ($value['type'] == 1) {
				$logoPicurl = $value['picurlTmp'];
			} elseif ($value['type'] == 2) {
				$photoList[] = $value['picurlTmp'];
			}
		}
	}
	$photoCount = count($photoList);
	$photoListStr = implode('|', $photoList);
	$showPhotoBoxStatus = 0;
	if ($tceduInfo['video_status'] == 1 && $vipInfo['open_video'] == 1 && $photoCount >= 2) {
		$showPhotoBoxStatus = 1;
	} else {
		if ($photoCount >= 3) {
			$showPhotoBoxStatus = 1;
		}
	}
	$phbListTmp = C::t('#tom_tcedu#tom_tcedu_phb')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status = 1 ', 'ORDER BY ranking ASC,id DESC');
	$phbList = array();
	if (is_array($phbListTmp) && !empty($phbListTmp)) {
		foreach ($phbListTmp as $key => $value) {
			$phbList[$key] = $value;
			$phbCateInfoTmp = C::t('#tom_tcedu#tom_tcedu_phb_cate')->fetch_by_id($value['phb_cate_id']);
			$phbList[$key]['phbCateInfo'] = $phbCateInfoTmp;
		}
	}
	$courseCount = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status = 1 AND shenhe_status = 1 AND deleted = 0 ');
	$teacherListTmp = C::t('#tom_tcedu#tom_tcedu_teacher')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status = 1 ', ' ORDER BY tsort ASC,id DESC');
	$teacherList = array();
	if (is_array($teacherListTmp) && !empty($teacherListTmp)) {
		foreach ($teacherListTmp as $key => $value) {
			$teacherList[$key] = $value;
			if (!preg_match('/^http/', $value['avatar'])) {
				if (strpos($value['avatar'], 'source/plugin/tom_') === false) {
					$avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['avatar'];
				} else {
					$avatarTmp = $value['avatar'];
				}
			} else {
				$avatarTmp = $value['avatar'];
			}
			$teacherList[$key]['avatar'] = $avatarTmp;
		}
	}
	$teacherCount = count($teacherList);
	$totalPinglunCount = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' ');
	$pinglunCount = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND type = 1 ');
	$pinglunListTmp = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND type = 1 ', 'ORDER BY id DESC', 0, 5);
	$pinglunList = array();
	if (is_array($pinglunListTmp) && !empty($pinglunListTmp)) {
		foreach ($pinglunListTmp as $key => $value) {
			$pinglunList[$key] = $value;
			$pinglunUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$pinglunList[$key]['total_bili'] = $value['total_score'] / 5 * 100;
			$pinglunList[$key]['userInfo'] = $pinglunUserInfo;
		}
	}
	$baiduMapFromName = lang('plugin/tom_tcedu', 'wodeweizhi');
	$baiduMapFromName = urlencode($baiduMapFromName);
	$baiduMapToName = $tceduInfo['name'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapRegion = lang('plugin/tom_tcedu', 'china');
	$baiduMapRegion = urlencode($baiduMapRegion);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tceduInfo['latitude'] . ',' . $tceduInfo['longitude'] . '&title=' . $baiduMapToName . '&content=&output=html';
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tceduConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$guanzuStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$guanzuInfoTmp = C::t('#tom_tcedu#tom_tcedu_guanzu')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
		if (is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])) {
			$guanzuStatus = 1;
		}
	}
	if (!empty($tceduConfig['edu_info_share_title'])) {
		$shareTitle = $tceduConfig['edu_info_share_title'];
		$shareTitle = str_replace('{NAME}', $tceduInfo['name'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tceduConfig['edu_info_share_desc'])) {
		$shareDesc = $tceduConfig['edu_info_share_desc'];
		$shareDesc = str_replace('{NAME}', $tceduInfo['name'], $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	$shareLogo = $logoPicurl;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info&tcedu_id=' . $tceduInfo['id'] . '&s=1');
	if ($__TjShowStatus == 1) {
		$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfo['id']);
	}
	$searchUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=get_edu_search_url&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxClicksUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_clicks&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxGuanzuUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=guanzu&tcedu_id=' . $tceduInfo['id'] . '&formhash=') . FORMHASH;
	$ajaxHistoryUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_history&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxLoadCourseListUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=courselist&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:info');
} elseif ($_GET['mod'] == 'info_course') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$tcedu_id = intval($_GET['tcedu_id']) > 0 ? intval($_GET['tcedu_id']) : 0;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
	if ($tceduInfo['id'] > 0) {
		if ($tceduInfo['status'] != 1 || $tceduInfo['shenhe_status'] != 1) {
			if ($__UserInfo['groupid'] != 1 && $__UserInfo['groupid'] != 2) {
				tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
				exit(0);
			}
		}
	} else {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	if ($tceduInfo['vip_id'] <= 0 || $tceduInfo['expire_status'] != 1 || $tceduInfo['expire_time'] < TIMESTAMP) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info&tcedu_id=' . $tcedu_id));
		exit(0);
	}
	$vipInfo = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_by_id($tceduInfo['vip_id']);
	$photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND type = 1 ', ' ORDER BY psort ASC,id ASC ', 0, 1);
	$logoPicurl = '';
	if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
		$logoPicurl = $photoInfoTmp[0]['picurlTmp'];
	}
	$courseCount = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status = 1 AND shenhe_status = 1 AND deleted = 0 ');
	$teacherCount = C::t('#tom_tcedu#tom_tcedu_teacher')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status = 1 ');
	$pinglunCount = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' ');
	$photoCount = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND type = 2 ');
	$courseCateListTmp = C::t('#tom_tcedu#tom_tcedu_course_cate')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' ', 'ORDER BY csort ASC, id DESC');
	$courseCateList = array();
	if (is_array($courseCateListTmp) && !empty($courseCateListTmp)) {
		foreach ($courseCateListTmp as $key => $value) {
			$courseCateList[$key] = $value;
			$courseCountTmp = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status = 1 AND shenhe_status = 1 AND course_cate_id = ' . $value['id'] . ' AND deleted = 0 ');
			$courseCateList[$key]['courseCount'] = $courseCountTmp;
		}
	}
	$courseCateCount = count($courseCateList);
	$guanzuStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$guanzuInfoTmp = C::t('#tom_tcedu#tom_tcedu_guanzu')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
		if (is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])) {
			$guanzuStatus = 1;
		}
	}
	if (!empty($tceduConfig['edu_info_share_title'])) {
		$shareTitle = $tceduConfig['edu_info_share_title'];
		$shareTitle = str_replace('{NAME}', $tceduInfo['name'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tceduConfig['edu_info_share_desc'])) {
		$shareDesc = $tceduConfig['edu_info_share_desc'];
		$shareDesc = str_replace('{NAME}', $tceduInfo['name'], $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	$shareLogo = $logoPicurl;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info&tcedu_id=' . $tceduInfo['id'] . '&s=1');
	if ($__TjShowStatus == 1) {
		$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfo['id']);
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info_course&tcedu_id=' . $tceduInfo['id']));
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=courselist&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxClicksUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_clicks&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxHistoryUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_history&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxCollectUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_collect&user_id=' . $__UserInfo['id'] . '&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$searchUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=get_edu_search_url&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxGuanzuUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=guanzu&tcedu_id=' . $tceduInfo['id'] . '&formhash=') . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:info_course');
} elseif ($_GET['mod'] == 'info_teacher') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$tcedu_id = intval($_GET['tcedu_id']) > 0 ? intval($_GET['tcedu_id']) : 0;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
	if ($tceduInfo['id'] > 0) {
		if ($tceduInfo['status'] != 1 || $tceduInfo['shenhe_status'] != 1) {
			if ($__UserInfo['groupid'] != 1 && $__UserInfo['groupid'] != 2) {
				tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
				exit(0);
			}
		}
	} else {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	if ($tceduInfo['vip_id'] <= 0 || $tceduInfo['expire_status'] != 1 || $tceduInfo['expire_time'] < TIMESTAMP) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info&tcedu_id=' . $tcedu_id));
		exit(0);
	}
	$vipInfo = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_by_id($tceduInfo['vip_id']);
	$photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND type = 1 ', ' ORDER BY psort ASC,id ASC ', 0, 1);
	$logoPicurl = '';
	if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
		$logoPicurl = $photoInfoTmp[0]['picurlTmp'];
	}
	$courseCount = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status = 1 AND shenhe_status = 1 AND deleted = 0 ');
	$pinglunCount = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' ');
	$photoCount = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND type = 2 ');
	$teacherListTmp = C::t('#tom_tcedu#tom_tcedu_teacher')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status = 1 ', ' ORDER BY tsort ASC,id DESC');
	$teacherList = array();
	if (is_array($teacherListTmp) && !empty($teacherListTmp)) {
		foreach ($teacherListTmp as $key => $value) {
			$teacherList[$key] = $value;
			if (!preg_match('/^http/', $value['avatar'])) {
				if (strpos($value['avatar'], 'source/plugin/tom_') === false) {
					$avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['avatar'];
				} else {
					$avatarTmp = $value['avatar'];
				}
			} else {
				$avatarTmp = $value['avatar'];
			}
			$teacherList[$key]['avatar'] = $avatarTmp;
		}
	}
	$guanzuStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$guanzuInfoTmp = C::t('#tom_tcedu#tom_tcedu_guanzu')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
		if (is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])) {
			$guanzuStatus = 1;
		}
	}
	if (!empty($tceduConfig['edu_info_share_title'])) {
		$shareTitle = $tceduConfig['edu_info_share_title'];
		$shareTitle = str_replace('{NAME}', $tceduInfo['name'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tceduConfig['edu_info_share_desc'])) {
		$shareDesc = $tceduConfig['edu_info_share_desc'];
		$shareDesc = str_replace('{NAME}', $tceduInfo['name'], $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	$shareLogo = $logoPicurl;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info&tcedu_id=' . $tceduInfo['id'] . '&s=1');
	if ($__TjShowStatus == 1) {
		$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfo['id']);
	}
	$ajaxClicksUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_clicks&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxHistoryUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_history&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxCollectUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_collect&user_id=' . $__UserInfo['id'] . '&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxGuanzuUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=guanzu&tcedu_id=' . $tceduInfo['id'] . '&formhash=') . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:info_teacher');
} elseif ($_GET['mod'] == 'info_pinglun') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$tcedu_id = intval($_GET['tcedu_id']) > 0 ? intval($_GET['tcedu_id']) : 0;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
	if ($tceduInfo['id'] > 0) {
		if ($tceduInfo['status'] != 1 || $tceduInfo['shenhe_status'] != 1) {
			if ($__UserInfo['groupid'] != 1 && $__UserInfo['groupid'] != 2) {
				tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
				exit(0);
			}
		}
	} else {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	if ($tceduInfo['vip_id'] <= 0 || $tceduInfo['expire_status'] != 1 || $tceduInfo['expire_time'] < TIMESTAMP) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info&tcedu_id=' . $tcedu_id));
		exit(0);
	}
	$vipInfo = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_by_id($tceduInfo['vip_id']);
	$tceduInfo['huanjing_score'] = sprintf('%.1f', round($tceduInfo['huanjing_score'], 1));
	$tceduInfo['fuwu_score'] = sprintf('%.1f', round($tceduInfo['fuwu_score'], 1));
	$tceduInfo['teacher_score'] = sprintf('%.1f', round($tceduInfo['teacher_score'], 1));
	$tceduInfo['total_score'] = sprintf('%.1f', round($tceduInfo['total_score'], 1));
	$photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND type = 1 ', ' ORDER BY psort ASC,id ASC ', 0, 1);
	$logoPicurl = '';
	if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
		$logoPicurl = $photoInfoTmp[0]['picurlTmp'];
	}
	$pinglunCount = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' ');
	$courseCount = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status = 1 AND shenhe_status = 1 AND deleted = 0 ');
	$teacherCount = C::t('#tom_tcedu#tom_tcedu_teacher')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status = 1 ');
	$photoCount = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND type = 2 ');
	$guanzuStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$guanzuInfoTmp = C::t('#tom_tcedu#tom_tcedu_guanzu')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
		if (is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])) {
			$guanzuStatus = 1;
		}
	}
	if (!empty($tceduConfig['edu_info_share_title'])) {
		$shareTitle = $tceduConfig['edu_info_share_title'];
		$shareTitle = str_replace('{NAME}', $tceduInfo['name'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tceduConfig['edu_info_share_desc'])) {
		$shareDesc = $tceduConfig['edu_info_share_desc'];
		$shareDesc = str_replace('{NAME}', $tceduInfo['name'], $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	$shareLogo = $logoPicurl;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info&tcedu_id=' . $tceduInfo['id'] . '&s=1');
	if ($__TjShowStatus == 1) {
		$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfo['id']);
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info_pinglun&tcedu_id=' . $tceduInfo['id']));
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=pinglun_list&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxClicksUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_clicks&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxHistoryUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_history&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxCollectUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_collect&user_id=' . $__UserInfo['id'] . '&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxGuanzuUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=guanzu&tcedu_id=' . $tceduInfo['id'] . '&formhash=') . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:info_pinglun');
} elseif ($_GET['mod'] == 'info_photo') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$tcedu_id = intval($_GET['tcedu_id']) > 0 ? intval($_GET['tcedu_id']) : 0;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($tcedu_id);
	if ($tceduInfo['id'] > 0) {
		if ($tceduInfo['status'] != 1 || $tceduInfo['shenhe_status'] != 1) {
			if ($__UserInfo['groupid'] != 1 && $__UserInfo['groupid'] != 2) {
				tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
				exit(0);
			}
		}
	} else {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	if ($tceduInfo['vip_id'] <= 0 || $tceduInfo['expire_status'] != 1 || $tceduInfo['expire_time'] < TIMESTAMP) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info&tcedu_id=' . $tcedu_id));
		exit(0);
	}
	$vipInfo = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_by_id($tceduInfo['vip_id']);
	$photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND type = 1 ', ' ORDER BY psort ASC,id ASC ', 0, 1);
	$logoPicurl = '';
	if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
		$logoPicurl = $photoInfoTmp[0]['picurlTmp'];
	}
	$courseCount = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status = 1 AND shenhe_status = 1 AND deleted = 0 ');
	$teacherCount = C::t('#tom_tcedu#tom_tcedu_teacher')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status = 1 ');
	$pinglunCount = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' ');
	$photoListTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND type = 2 ', ' ORDER BY psort ASC,id ASC ', 0, 100);
	$photoList = array();
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			$photoList[] = $value['picurlTmp'];
		}
	}
	$photoListStr = implode('|', $photoList);
	$guanzuStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$guanzuInfoTmp = C::t('#tom_tcedu#tom_tcedu_guanzu')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
		if (is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])) {
			$guanzuStatus = 1;
		}
	}
	if (!empty($tceduConfig['edu_info_share_title'])) {
		$shareTitle = $tceduConfig['edu_info_share_title'];
		$shareTitle = str_replace('{NAME}', $tceduInfo['name'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tceduConfig['edu_info_share_desc'])) {
		$shareDesc = $tceduConfig['edu_info_share_desc'];
		$shareDesc = str_replace('{NAME}', $tceduInfo['name'], $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	$shareLogo = $logoPicurl;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info&tcedu_id=' . $tceduInfo['id'] . '&s=1');
	if ($__TjShowStatus == 1) {
		$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfo['id']);
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info_photo&tcedu_id=' . $tceduInfo['id']));
	$ajaxClicksUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_clicks&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxHistoryUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_history&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxCollectUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_collect&user_id=' . $__UserInfo['id'] . '&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$ajaxGuanzuUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=guanzu&tcedu_id=' . $tceduInfo['id'] . '&formhash=') . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:info_photo');
} elseif ($_GET['mod'] == 'teacherinfo') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$teacher_id = intval($_GET['teacher_id']) > 0 ? intval($_GET['teacher_id']) : 0;
	$teacherInfo = C::t('#tom_tcedu#tom_tcedu_teacher')->fetch_by_id($teacher_id);
	if ($teacherInfo['id'] <= 0 || $teacherInfo['status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($teacherInfo['tcedu_id']);
	if ($tceduInfo['vip_id'] <= 0 || $tceduInfo['expire_status'] != 1 || $tceduInfo['expire_time'] < TIMESTAMP) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info&tcedu_id=' . $tcedu_id));
		exit(0);
	}
	if (!preg_match('/^http/', $teacherInfo['avatar'])) {
		if (strpos($teacherInfo['avatar'], 'source/plugin/tom_') === false) {
			$teacherInfo['avatar'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $teacherInfo['avatar'];
		} else {
			$teacherInfo['avatar'] = $_G['siteurl'] . $teacherInfo['avatar'];
		}
	} else {
		$teacherInfo['avatar'] = $teacherInfo['avatar'];
	}
	$guanzuStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$guanzuInfoTmp = C::t('#tom_tcedu#tom_tcedu_guanzu')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
		if (is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])) {
			$guanzuStatus = 1;
		}
	}
	$ajaxGuanzuUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=guanzu&tcedu_id=' . $tceduInfo['id'] . '&formhash=') . FORMHASH;
	$ajaxClicksUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=edu_clicks&tcedu_id=' . $tceduInfo['id'] . '&formhash=' . $formhash;
	$shareTitle = $teacherInfo['name'];
	$shareDesc = $teacherInfo['desc'];
	$shareLogo = $teacherInfo['avatar'];
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=teacherinfo&teacher_id=' . $teacherInfo['id'] . '&s=1');
	if ($__TjShowStatus == 1) {
		$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfo['id']);
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:teacherinfo');
} elseif ($_GET['mod'] == 'courselist') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$tabs = isset($_GET['tabs']) ? daddslashes(urldecode($_GET['tabs'])) : '';
	$class_types = isset($_GET['class_types']) ? addslashes($_GET['class_types']) : '';
	$ordertype = isset($_GET['ordertype']) ? addslashes($_GET['ordertype']) : '';
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$areaList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$cateName = '';
	$cateList = array();
	$cateListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(' AND pid = 0 AND status =1 ', 'ORDER BY csort ASC,id DESC');
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			if ($cate_id == $value['id']) {
				$cateName = $value['name'];
			}
		}
	}
	if ($cate_id > 0) {
		$cateChildListTmp = C::t('#tom_tcedu#tom_tcedu_cate')->fetch_all_list(' AND pid = ' . $cate_id . ' AND status =1  ', 'ORDER BY csort ASC,id DESC');
		$cateChildList = array();
		if (is_array($cateChildListTmp) && !empty($cateChildListTmp)) {
			foreach ($cateChildListTmp as $key => $value) {
				$cateChildList[$key] = $value;
				if ($cate_child_id == $value['id']) {
					$cateName = $value['name'];
				}
			}
		}
	}
	$courseTabsArr = array();
	$course_tab_str = str_replace("\r\n", '{n}', $tceduConfig['course_tab_list']);
	$course_tab_str = str_replace("\n", '{n}', $course_tab_str);
	$course_tab_arr = explode('{n}', $course_tab_str);
	if (is_array($course_tab_arr) && !empty($course_tab_arr)) {
		foreach ($course_tab_arr as $key => $value) {
			$value = trim($value);
			if (!empty($value)) {
				$courseTabsArr[] = $value;
			}
		}
	}
	$selectTabsArr = explode(',', $tabs);
	$tabsList = array();
	foreach ($courseTabsArr as $key => $value) {
		$tabsList[$key]['name'] = $value;
		$tabsList[$key]['status'] = 0;
		if (is_array($selectTabsArr) && !empty($selectTabsArr) && in_array($value, $selectTabsArr)) {
			$tabsList[$key]['status'] = 1;
		}
	}
	$selectClassTypesArr = explode(',', $class_types);
	$classTypeList = array();
	foreach ($classTypeArr as $key => $value) {
		$classTypeList[$key]['name'] = $value;
		$classTypeList[$key]['status'] = 0;
		if (is_array($selectClassTypesArr) && !empty($selectClassTypesArr) && in_array($key, $selectClassTypesArr)) {
			$classTypeList[$key]['status'] = 1;
		}
	}
	$where = ' AND status=1 AND shenhe_status=1 AND deleted = 0 ';
	if (!empty($sql_in_site_ids)) {
		$where .= ' AND site_id IN(' . $sql_in_site_ids . ') ';
	}
	if (!empty($keyword)) {
		$keyword = str_replace(array('%', '_'), '', $keyword);
		$where .= ' AND search_text LIKE \'%' . $keyword . '%\' ';
	}
	if (!empty($tabs)) {
		$selectTabsArr = explode(',', $tabs);
		foreach ($selectTabsArr as $key => $value) {
			$value = str_replace(array('%', '_'), '', $value);
			$where .= ' AND tabs LIKE \'%' . $value . '%\' ';
		}
	}
	if (!empty($area_id)) {
		$where .= ' AND area_id=' . $area_id . ' ';
	}
	if (!empty($street_id)) {
		$where .= ' AND street_id=' . $street_id . ' ';
	}
	if (!empty($cate_id)) {
		$where .= ' AND cate_id=' . $cate_id . ' ';
	}
	if (!empty($cate_child_id)) {
		$where .= ' AND cate_child_id=' . $cate_child_id . ' ';
	}
	if (!empty($type)) {
		$where .= ' AND type=' . $type . ' ';
	}
	if (!empty($class_types)) {
		$classTypesArr = explode(',', $class_types);
		$classTypesList = array();
		foreach ($classTypesArr as $key => $value) {
			$value = intval($value);
			if ($value > 0) {
				$classTypesList[] = $value;
			}
		}
		if (!empty($classTypesList)) {
			$classTypesStr = implode(',', $classTypesList);
			$where .= ' AND class_type IN(' . $classTypesStr . ') ';
		}
	}
	$courseCount = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count($where);
	$list_cate_name = $tceduConfig['course_list_cate_name'];
	if ($cate_id > 0) {
		$list_cate_name = $cateName;
	}
	if (!empty($tceduConfig['course_list_share_title'])) {
		$shareTitle = $tceduConfig['course_list_share_title'];
		$shareTitle = str_replace('{CATENAME}', $list_cate_name, $shareTitle);
		$shareTitle = str_replace('{NUM}', $courseCount, $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tceduConfig['course_list_share_desc'])) {
		$shareDesc = $tceduConfig['course_list_share_desc'];
		$shareDesc = str_replace('{CATENAME}', $list_cate_name, $shareDesc);
		$shareDesc = str_replace('{NUM}', $courseCount, $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	if (!empty($tceduConfig['course_share_pic'])) {
		$shareLogo = $tceduConfig['course_share_pic'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=courselist&s=1');
	if ($__TjShowStatus == 1) {
		$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfo['id']);
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=courselist&keyword=' . $keyword . '&area_id=' . $area_id . '&street_id=' . $street_id . '&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&type=' . $type . '&tabs=' . $tabs . '&class_types=' . $class_types . '&ordertype=' . $ordertype . '&s=' . $s));
	$ajaxLoadCateListUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=load_cate_list&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$searchAjaxUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=get_search_course_url&formhash=' . $formhash;
	$searchUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=searchcourse&');
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=courselist&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:courselist');
} elseif ($_GET['mod'] == 'searchcourse') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$tabs = isset($_GET['tabs']) ? daddslashes(diconv(urldecode($_GET['tabs']), 'utf-8')) : '';
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$class_type = intval($_GET['class_type']) > 0 ? intval($_GET['class_type']) : 0;
	$ordertype = isset($_GET['ordertype']) ? addslashes($_GET['ordertype']) : '';
	$cookieKeywordsStr = getcookie('tom_tcedu_searchcourse_keywords_str');
	$keywordsArr = array();
	if (!empty($cookieKeywordsStr)) {
		$keywordsArr = explode('|', $cookieKeywordsStr);
	}
	$keywordsCount = count($keywordsArr);
	$defaultStr = $tceduConfig['default_course_search_str'];
	$defaultArr = array();
	if (!empty($defaultStr)) {
		$defaultArr = explode('|', $defaultStr);
	}
	$defaultCount = count($defaultArr);
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=searchcourse&s=1');
	if ($__TjShowStatus == 1) {
		$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfo['id']);
	}
	$searchUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=get_search_course_url&formhash=' . $formhash;
	$ajaxClearSearchUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=clear_search_course&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:searchcourse');
} elseif ($_GET['mod'] == 'courseinfo') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$course_id = intval($_GET['course_id']) > 0 ? intval($_GET['course_id']) : 0;
	$courseInfo = C::t('#tom_tcedu#tom_tcedu_course')->fetch_by_id($course_id);
	if ($courseInfo['id'] > 0) {
		if ($courseInfo['status'] != 1 || $courseInfo['shenhe_status'] != 1 || $courseInfo['deleted'] != 0) {
			if ($__UserInfo['groupid'] != 1 && $__UserInfo['groupid'] != 2) {
				tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
				exit(0);
			}
		}
	} else {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$tceduInfo = C::t('#tom_tcedu#tom_tcedu')->fetch_by_id($courseInfo['tcedu_id']);
	$vipInfo = C::t('#tom_tcedu#tom_tcedu_vip')->fetch_by_id($tceduInfo['vip_id']);
	if ($tceduInfo['vip_id'] <= 0 || $tceduInfo['expire_status'] != 1 || $tceduInfo['expire_time'] < TIMESTAMP) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=info&tcedu_id=' . $tceduInfo['id']));
		exit(0);
	}
	$photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(' AND course_id = ' . $courseInfo['id'] . ' AND type = 4 ', 'ORDER BY id DESC', 0, 1);
	if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
		$courseInfo['picurl'] = $photoInfoTmp[0]['picurlTmp'];
	}
	if ($courseInfo['admin_edit'] == 1) {
		$courseInfo['content'] = stripslashes($courseInfo['content']);
	}
	if (!empty($courseInfo['tabs'])) {
		$tabsArr = explode('|', $courseInfo['tabs']);
	}
	$showBmCourseBtn = 1;
	if ($courseInfo['hexiao_limit'] == 1) {
		$hexiaoDaysTime = $courseInfo['hexiao_days'] * 86400 + TIMESTAMP;
		if ($hexiaoDaysTime <= TIMESTAMP) {
			$showBmCourseBtn = 2;
		}
	} elseif ($courseInfo['hexiao_limit'] == 2) {
		$courseInfo['hexiaoTime'] = dgmdate($courseInfo['hexiao_time'], 'Y-m-d H:i', $tomSysOffset);
		if ($courseInfo['hexiao_time'] <= TIMESTAMP) {
			$showBmCourseBtn = 2;
		}
	}
	if ($courseInfo['open_bm_end_time'] == 1) {
		$courseInfo['bmEndTime'] = dgmdate($courseInfo['bm_end_time'], 'Y-m-d H:i', $tomSysOffset);
		if ($courseInfo['bm_end_time'] <= TIMESTAMP) {
			$showBmCourseBtn = 2;
		}
	}
	if (!empty($courseInfo['teacher_ids'])) {
		$teacherIdsStr = trim($courseInfo['teacher_ids'], '|');
		$teacherIdsArr = explode('|', $teacherIdsStr);
		$teacherIdsStr = implode(',', $teacherIdsArr);
		$teacherListTmp = C::t('#tom_tcedu#tom_tcedu_teacher')->fetch_all_list(' AND id IN(' . $teacherIdsStr . ')  AND status = 1 ', ' ORDER BY tsort ASC,id DESC');
		$teacherList = array();
		if (is_array($teacherListTmp) && !empty($teacherListTmp)) {
			foreach ($teacherListTmp as $key => $value) {
				$teacherList[$key] = $value;
				if (!preg_match('/^http/', $value['avatar'])) {
					if (strpos($value['avatar'], 'source/plugin/tom_') === false) {
						$avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['avatar'];
					} else {
						$avatarTmp = $value['avatar'];
					}
				} else {
					$avatarTmp = $value['avatar'];
				}
				$teacherList[$key]['avatar'] = $avatarTmp;
			}
		}
	}
	$show_max_buy_price = $show_max_market_price = $show_max_vip_price = 0;
	if ($courseInfo['hasoption'] == 1) {
		$optionListTmp = C::t('#tom_tcedu#tom_tcedu_course_option')->fetch_all_list('AND course_id = ' . $courseInfo['id'], 'ORDER BY osort ASC, id ASC', 0, 100);
		$optionList = array();
		if (is_array($optionListTmp) && !empty($optionListTmp)) {
			foreach ($optionListTmp as $key => $value) {
				$optionList[$key] = $value;
				if ($value['buy_price'] > $show_max_buy_price) {
					$show_max_buy_price = $value['buy_price'];
				}
				if ($value['market_price'] > $show_max_market_price) {
					$show_max_market_price = $value['market_price'];
				}
				if ($value['vip_price'] > $show_max_vip_price) {
					$show_max_vip_price = $value['vip_price'];
				}
			}
		}
		$optionCount = count($optionList);
	}
	if ($courseInfo['show_vip_price'] > 100 && $courseInfo['hasoption'] == 1) {
		$courseInfo['show_vip_price'] = intval($courseInfo['show_vip_price']);
	}
	if ($show_max_vip_price > 100 && $courseInfo['hasoption'] == 1) {
		$show_max_vip_price = intval($show_max_vip_price);
	}
	$photoInfoTmp = C::t('#tom_tcedu#tom_tcedu_photo')->fetch_all_list(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND type = 1 ', ' ORDER BY psort ASC,id ASC ', 0, 1);
	if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
		$tceduInfo['logo'] = $photoInfoTmp[0]['picurlTmp'];
	}
	$tceduInfo['course_count'] = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(' AND tcedu_id = ' . $tceduInfo['id'] . ' AND status=1 AND shenhe_status=1 AND deleted = 0 ');
	if (!preg_match('/^http/', $tceduInfo['kefu_qrcode']) && !empty($tceduInfo['kefu_qrcode'])) {
		if (strpos($tceduInfo['kefu_qrcode'], 'source/plugin/tom_') === false) {
			$tceduInfo['kefu_qrcode'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tceduInfo['kefu_qrcode'];
		}
	}
	$pinglunCount = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_all_count(' AND course_id = ' . $courseInfo['id'] . ' AND type = 1 ');
	$pinglunListTmp = C::t('#tom_tcedu#tom_tcedu_pinglun')->fetch_all_list(' AND course_id = ' . $courseInfo['id'] . ' AND type = 1 ', 'ORDER BY id DESC', 0, 5);
	$pinglunList = array();
	if (is_array($pinglunListTmp) && !empty($pinglunListTmp)) {
		foreach ($pinglunListTmp as $key => $value) {
			$pinglunList[$key] = $value;
			$pinglunUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$pinglunList[$key]['total_bili'] = $value['total_score'] / 5 * 100;
			$pinglunList[$key]['userInfo'] = $pinglunUserInfo;
		}
	}
	$collectStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$collectInfoTmp = C::t('#tom_tcedu#tom_tcedu_course_collect')->fetch_all_list(' AND course_id = ' . $courseInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
		if (is_array($collectInfoTmp) && !empty($collectInfoTmp[0])) {
			$collectStatus = 1;
		}
	}
	if (!preg_match('/^http/', $courseInfo['haibao_picurl'])) {
		if (strpos($courseInfo['haibao_picurl'], 'source/plugin/tom_') === false) {
			$haibao_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $courseInfo['haibao_picurl'];
		} else {
			$haibao_picurl = $courseInfo['haibao_picurl'];
		}
	} else {
		$haibao_picurl = $courseInfo['haibao_picurl'];
	}
	if (empty($courseInfo['haibao_text_color'])) {
		$courseInfo['haibao_text_color'] = '#ffffff';
	}
	$showTgButton = 0;
	if ($__ShowTchehuoren == 1 && $courseInfo['hehuoren_tg_open'] == 1 && $__UserInfo['id'] > 0 && $courseInfo['show_buy_price'] > 0) {
		if ($tchehuorenInfo['id'] > 0) {
			$dengjiInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
			$dengjiInfo = array();
			if (is_array($dengjiInfoTmp) && !empty($dengjiInfoTmp)) {
				$dengjiInfo = $dengjiInfoTmp;
			}
			if ($dengjiInfo['edu_fc_open'] == 1) {
				$showTgButton = 1;
				$pay_price = $courseInfo['show_buy_price'];
				$yongjin_bili = $tceduConfig['yongjin_bili'];
				if ($vipInfo['yongjin_bili'] > 0) {
					$yongjin_bili = $vipInfo['yongjin_bili'];
				}
				$pt_money = $pay_price * ($yongjin_bili / 100);
				$pt_money = number_format($pt_money, 2, '.', '');
				$edu_money = $pay_price - $pt_money;
				if ($courseInfo['hehuoren_tg_type'] == 1) {
					$needPrice = $courseInfo['hehuoren_fc_scale'];
				} elseif ($courseInfo['hehuoren_tg_type'] == 2) {
					$needPrice = $edu_money * ($courseInfo['hehuoren_fc_scale'] / 100);
					$needPrice = number_format($needPrice, 2, '.', '');
				}
			}
		}
	}
	if (!empty($tceduConfig['course_info_share_title'])) {
		$shareTitle = $tceduConfig['course_info_share_title'];
		$shareTitle = str_replace('{NAME}', $courseInfo['name'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tceduConfig['course_info_share_desc'])) {
		$shareDesc = $tceduConfig['course_info_share_desc'];
		$shareDesc = str_replace('{NAME}', $courseInfo['name'], $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	$shareLogo = $courseInfo['picurl'];
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=courseinfo&course_id=' . $courseInfo['id'] . '&s=1');
	if ($showTgButton == 1) {
		$shareUrl .= '&tjid=' . $tchehuorenInfo['id'];
	}
	$buyUrl = 'plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=coursebuy&course_id=' . $courseInfo['id'];
	if ($tj_hehuoren_id > 0 && $courseInfo['hehuoren_tg_open'] == 1) {
		$buyUrl .= '&tjid=' . $tj_hehuoren_id;
	}
	$haibaoQrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($shareUrl);
	$kefuSmsUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&&to_user_id=' . $tceduInfo['user_id'] . '&tcedu_course_id=' . $courseInfo['id'] . '&formhash=' . FORMHASH;
	$ajaxCollectUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=collect&course_id=' . $courseInfo['id'] . '&formhash=') . FORMHASH;
	$ajaxClicksUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=course_clicks&course_id=' . $courseInfo['id'] . '&tcedu_id=' . $courseInfo['tcedu_id'] . '&formhash=' . $formhash;
	$ajaxHistoryUrl = 'plugin.php?id=tom_tcedu:ajax&site=' . $site_id . '&act=course_history&course_id=' . $courseInfo['id'] . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:courseinfo');
} elseif ($_GET['mod'] == 'baidumap') {
	$lat = !empty($_GET['lat']) ? addslashes($_GET['lat']) : '';
	$lng = !empty($_GET['lng']) ? addslashes($_GET['lng']) : '';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcedu:baidumap');
} elseif ($_GET['mod'] == 'phbinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/phbinfo.php';
} elseif ($_GET['mod'] == 'my') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/my.php';
} elseif ($_GET['mod'] == 'myguanzu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/myguanzu.php';
} elseif ($_GET['mod'] == 'mycollect') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/mycollect.php';
} elseif ($_GET['mod'] == 'myhistory') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/myhistory.php';
} elseif ($_GET['mod'] == 'edu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/edu.php';
} elseif ($_GET['mod'] == 'ruzhu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/ruzhu.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/edit.php';
} elseif ($_GET['mod'] == 'editmanage') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/editmanage.php';
} elseif ($_GET['mod'] == 'mylist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/mylist.php';
} elseif ($_GET['mod'] == 'mymanagelist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/mymanagelist.php';
} elseif ($_GET['mod'] == 'vipbuy') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/vipbuy.php';
} elseif ($_GET['mod'] == 'topbuy') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/topbuy.php';
} elseif ($_GET['mod'] == 'coursetopbuy') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/coursetopbuy.php';
} elseif ($_GET['mod'] == 'courseoption') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/courseoption.php';
} elseif ($_GET['mod'] == 'mycourselist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/mycourselist.php';
} elseif ($_GET['mod'] == 'mybm') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/mybm.php';
} elseif ($_GET['mod'] == 'mybminfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/mybminfo.php';
} elseif ($_GET['mod'] == 'courseadd') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/courseadd.php';
} elseif ($_GET['mod'] == 'courseedit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/courseedit.php';
} elseif ($_GET['mod'] == 'coursebm') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/coursebm.php';
} elseif ($_GET['mod'] == 'coursebminfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/coursebminfo.php';
} elseif ($_GET['mod'] == 'coursebuy') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/coursebuy.php';
} elseif ($_GET['mod'] == 'coursetj') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/coursetj.php';
} elseif ($_GET['mod'] == 'teacher') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/teacher.php';
} elseif ($_GET['mod'] == 'teacheradd') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/teacheradd.php';
} elseif ($_GET['mod'] == 'teacheredit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/teacheredit.php';
} elseif ($_GET['mod'] == 'coursecate') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/coursecate.php';
} elseif ($_GET['mod'] == 'coursecateadd') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/coursecateadd.php';
} elseif ($_GET['mod'] == 'coursecateedit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/coursecateedit.php';
} elseif ($_GET['mod'] == 'attr') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/attr.php';
} elseif ($_GET['mod'] == 'attradd') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/attradd.php';
} elseif ($_GET['mod'] == 'attredit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/attredit.php';
} elseif ($_GET['mod'] == 'hexiao') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/hexiao.php';
} elseif ($_GET['mod'] == 'yu_balance') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/yu_balance.php';
} elseif ($_GET['mod'] == 'pinglun') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/pinglun.php';
} elseif ($_GET['mod'] == 'managerEduList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/managerEduList.php';
} elseif ($_GET['mod'] == 'managerCourseList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/managerCourseList.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tcedu/module/upload.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcedu&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();