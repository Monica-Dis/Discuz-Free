<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tc114Config = $_G['cache']['plugin']['tom_tc114'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = '20200119';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tc114/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tc114Config['wx_share_title'];
$shareDesc = $tc114Config['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tc114&site=' . $site_id . '&mod=index');
$shareLogo = $tc114Config['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
$__ShowTcshop = 0;
$tcshopConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcshop/tom_tcshop.inc.php')) {
	$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
	if ($tcshopConfig['open_tcshop'] == 1) {
		$__ShowTcshop = 1;
	}
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$ajaxLoadListUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
$ajaxCommonClicksUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=commonClicks&formhash=' . $formhash;
$ajaxCommonSharesUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=commonShares&formhash=' . $formhash;
$ajaxUpdateBaseLevelUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=update_base_level&formhash=' . $formhash;
$ajaxAutoClickUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=auto_click&formhash=' . $formhash;
$searchUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=get_search_url';
$addPinglunUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=pinglun&formhash=' . FORMHASH;
$ajaxCollectUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=collect&&formhash=' . $formhash;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
$__CommonInfo = C::t('#tom_tc114#tom_tc114_common')->fetch_by_id(1);
if (!$__CommonInfo) {
	$insertData = array();
	$insertData['id'] = 1;
	C::t('#tom_tc114#tom_tc114_common')->insert($insertData);
}
if ($site_id > 1) {
	$__siteCommonInfo = C::t('#tom_tc114#tom_tc114_common')->fetch_by_id($site_id);
	if (!$__siteCommonInfo) {
		$insertData = array();
		$insertData['id'] = $site_id;
		C::t('#tom_tc114#tom_tc114_common')->insert($insertData);
	}
}
if ($_GET['mod'] == 'index') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$commonClicks = C::t('#tom_tc114#tom_tc114_common')->fetch_all_sun_clicks(' AND id IN(' . $sql_in_site_ids . ') ');
	if ($site_id == 1) {
		$clicksNum = $commonClicks + $tc114Config['virtual_clicks_num'];
	} else {
		$clicksNum = $commonClicks + $tc114Config['virtual_clicks_num'];
	}
	$clicksNumTxt = $clicksNum;
	if ($clicksNum > 10000) {
		$clicksNumTmp = $clicksNum / 10000;
		$clicksNumTxt = number_format($clicksNumTmp, 2);
	} elseif ($clicksNum > 1000000) {
		$clicksNumTmp = $clicksNum / 10000;
		$clicksNumTxt = number_format($clicksNumTmp, 0);
	}
	$commonShares = C::t('#tom_tc114#tom_tc114_common')->fetch_all_sun_shares(' AND id IN(' . $sql_in_site_ids . ') ');
	if ($site_id == 1) {
		$sharesNum = $commonShares + $tc114Config['virtual_shares_num'];
	} else {
		$sharesNum = $commonShares + $tc114Config['virtual_shares_num'];
	}
	$sharesNumTxt = $sharesNum;
	if ($sharesNum > 10000) {
		$sharesNumTmp = $sharesNum / 10000;
		$sharesNumTxt = number_format($sharesNumTmp, 2);
	} elseif ($sharesNum > 1000000) {
		$sharesNumTmp = $sharesNum / 10000;
		$sharesNumTxt = number_format($sharesNumTmp, 0);
	}
	$ruzhuNum = C::t('#tom_tc114#tom_tc114')->fetch_all_count(' AND status=1 AND site_id IN(' . $sql_in_site_ids . ') ');
	$ruzhuNum = $ruzhuNum + $tc114Config['virtual_ruzhu_num'];
	$ruzhuNumTxt = $ruzhuNum;
	if ($ruzhuNum > 10000) {
		$ruzhuNumTmp = $ruzhuNum / 10000;
		$ruzhuNumTxt = number_format($ruzhuNumTmp, 2);
	} elseif ($ruzhuNum > 1000000) {
		$ruzhuNumTmp = $ruzhuNum / 10000;
		$ruzhuNumTxt = number_format($ruzhuNumTmp, 0);
	}
	$focuspicListTmp = C::t('#tom_tc114#tom_tc114_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tc114#tom_tc114_focuspic')->fetch_all_list(' AND site_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	$focuspicCount = 0;
	if (is_array($focuspicListTmp) && !empty($focuspicListTmp)) {
		foreach ($focuspicListTmp as $key => $value) {
			$focuspicList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$focuspicList[$key]['picurl'] = $picurl;
			$focuspicList[$key]['link'] = str_replace('{site}', $site_id, $focuspicList[$key]['link']);
			$focuspicCount = $focuspicCount + 1;
		}
	}
	$cateListTmp = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(' AND pid=0 ', ' ORDER BY csort ASC,id DESC ', 0, 100);
	$cateList = array();
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		$i = 1;
		$cateCount = 0;
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			$cateList[$key]['i'] = $i;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$cateList[$key]['picurl'] = $picurl;
			$i = $i + 1;
			$cateCount = $cateCount + 1;
		}
	}
	$tc114ListTmp = C::t('#tom_tc114#tom_tc114')->fetch_all_list(' AND status = 1 AND site_id IN(' . $sql_in_site_ids . ') ', 'ORDER BY id DESC', 0, 10);
	$tc114List = array();
	$tc114Count = 0;
	if (is_array($tc114ListTmp) && !empty($tc114ListTmp)) {
		foreach ($tc114ListTmp as $key => $value) {
			$tc114List[$key] = $value;
			$tc114List[$key]['title'] = cutstr($value['title'], 12, '...');
			$tc114Count = $tc114Count + 1;
		}
	}
	$tagListTmp = C::t('#tom_tc114#tom_tc114_tag')->fetch_all_list(' AND pid=0 ', 'ORDER BY tsort ASC,id DESC', 0, 50);
	$tagList = array();
	$i = 0;
	if (is_array($tagListTmp) && !empty($tagListTmp)) {
		foreach ($tagListTmp as $key => $value) {
			$tagList[$key] = $value;
			$i = $i + 1;
		}
	}
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tc114/images/index.js';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	if ($tc114Config['open_new_template'] == 2) {
		include template('tom_tc114:new-index');
	} else {
		include template('tom_tc114:index');
	}
	echo '<script src="source/plugin/tom_tc114/images/index.js"></script>';
} elseif ($_GET['mod'] == 'info') {
	$tc114_id = intval($_GET['tc114_id']) > 0 ? intval($_GET['tc114_id']) : 0;
	$tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($tc114_id);
	if ($tc114Info['status'] != 1 || $tc114Info['shenhe_status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tc114&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$cateInfo = C::t('#tom_tc114#tom_tc114_cate')->fetch_by_id($tc114Info['cate_id']);
	$cateChildInfo = C::t('#tom_tc114#tom_tc114_cate')->fetch_by_id($tc114Info['cate_child_id']);
	$shoufeiStatus = 0;
	if ($cateInfo['open_shoufei'] && $tc114Config['pay_shoufei_price'] > 0) {
		$shoufeiStatus = 1;
		if ($__UserInfo['id'] > 0) {
			$orderInfoTmp = C::t('#tom_tc114#tom_tc114_order')->fetch_all_list(' AND tc114_id=' . $tc114_id . ' AND user_id=' . $__UserInfo['id'] . ' AND order_type=4 AND order_status=2 ', 'ORDER BY id DESC', 0, 1);
			if (is_array($orderInfoTmp) && !empty($orderInfoTmp[0])) {
				$shoufeiStatus = 0;
			}
		}
		if ($__UserInfo['id'] == $tc114Info['user_id']) {
			$shoufeiStatus = 0;
		}
		if ($__UserInfo['editor'] == 1) {
			$shoufeiStatus = 0;
		}
	}
	if ($shoufeiStatus == 1) {
		$tc114Info['tel'] = cutstr($tc114Info['tel'], 4, '*******');
		$tc114Info['tel2'] = cutstr($tc114Info['tel2'], 4, '*******');
	}
	$photoListTmp = C::t('#tom_tc114#tom_tc114_photo')->fetch_all_list(' AND tc114_id=' . $tc114_id . ' ', ' ORDER BY id ASC ', 0, 50);
	$photoList = array();
	$photoCount = 0;
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$photoList[$key] = $picurlTmp;
			$photoCount = $photoCount + 1;
		}
	}
	$photoListStr = implode('|', $photoList);
	if (!preg_match('/^http/', $tc114Info['picurl'])) {
		if (strpos($tc114Info['picurl'], 'source/plugin/tom_') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tc114Info['picurl'];
		} else {
			$picurl = $_G['siteurl'] . $tc114Info['picurl'];
		}
	} else {
		$picurl = $tc114Info['picurl'];
	}
	$bgPicurl = $picurl;
	if ($tc114Info['picurl'] == $tc114Config['default_picurl']) {
		$bgPicurl = 'source/plugin/tom_tc114/images/bgPicurl.jpg';
	}
	if (!preg_match('/^http/', $tc114Info['qrcode'])) {
		if (strpos($tc114Info['qrcode'], 'source/plugin/tom_') === false) {
			$qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tc114Info['qrcode'];
		} else {
			$qrcode = $tc114Info['qrcode'];
		}
	} else {
		$qrcode = $tc114Info['qrcode'];
	}
	$soucangCount = C::t('#tom_tc114#tom_tc114_collect')->fetch_all_count(' AND tc114_id = ' . $tc114_id . ' ');
	$soucangs = intval($soucangCount);
	$clicks = intval($tc114Info['clicks'] + $tc114Info['virtual_clicks']);
	$shares = intval($tc114Info['shares'] + $tc114Info['virtual_shares']);
	$content = contentFormat($tc114Info['content']);
	$contentTmp = strip_tags($content);
	$contentTmp = str_replace("\r\n", '', $contentTmp);
	$contentTmp = str_replace("\n", '', $contentTmp);
	$contentTmp = str_replace("\r", '', $contentTmp);
	$haibaoContent = cutstr($contentTmp, 146, '...');
	if (!empty($contentTmp)) {
		$shareDesc = $contentTmp;
	}
	$latitude = getcookie('tom_tongcheng_user_latitude');
	$longitude = getcookie('tom_tongcheng_user_longitude');
	$isCollect = 0;
	if (!empty($__UserInfo['id'])) {
		$collectListTmp = C::t('#tom_tc114#tom_tc114_collect')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' AND tc114_id=' . $tc114_id . ' ', ' ORDER BY id DESC ', 0, 1);
		if (is_array($collectListTmp) && !empty($collectListTmp)) {
			$collect_id = $collectListTmp[0]['id'];
			$isCollect = 1;
		}
	}
	$showLbsMap = 0;
	if (!empty($tc114Info['latitude']) && !empty($tc114Info['longitude'])) {
		$showLbsMap = 1;
	}
	$baiduMapToName = $tc114Info['title'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tc114Info['latitude'] . ',' . $tc114Info['longitude'] . '&title=' . $baiduMapToName . '&content=&output=html';
	$fabuFlUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=fabu&model_id=';
	$ajaxLoadFlListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&user_id=' . $tc114Info['user_id'] . '&act=list&formhash=' . $formhash;
	$ajaxLoadShopListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=list&user_id=' . $tc114Info['user_id'] . '&formhash=' . $formhash;
	$ajax114CollectUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=collect&tc114_id=' . $tc114_id . '&formhash=' . $formhash;
	$ajaxCancel114CollectUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=collect_cancel&formhash=' . $formhash;
	$ajaxClicksUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=clicks&tc114_id=' . $tc114_id . '&formhash=' . FORMHASH;
	$ajaxSharesUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=shares&tc114_id=' . $tc114_id . '&formhash=' . FORMHASH;
	$shareTitle = str_replace('{TITLE}', $tc114Info['title'], $tc114Config['details_share_title']);
	$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	if (!empty($tc114Info['picurl'])) {
		$shareLogo = $picurl;
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tc114&site=' . $site_id . '&mod=info&tc114_id=') . $tc114_id;
	$jiucuoAjaxUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=jiucuo&tc114_id=' . $tc114_id . '&formhash=' . FORMHASH;
	$renlingAjaxUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=renling&tc114_id=' . $tc114_id . '&formhash=' . FORMHASH;
	$renlingPayUrl = 'plugin.php?id=tom_tc114:pay&site=' . $site_id . '&act=renling&user_id=' . $__UserInfo['id'] . '&tc114_id=' . $tc114_id . '&formhash=' . FORMHASH;
	$fufeiPayUrl = 'plugin.php?id=tom_tc114:pay&site=' . $site_id . '&act=shoufei&user_id=' . $__UserInfo['id'] . '&tc114_id=' . $tc114_id . '&formhash=' . FORMHASH;
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tc114Config['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tc114:info');
} elseif ($_GET['mod'] == 'cate') {
	$cateCountsTmp = C::t('#tom_tc114#tom_tc114')->fetch_all_count_cate_child_id();
	$cateCounts = array();
	if (is_array($cateCountsTmp) && !empty($cateCountsTmp)) {
		foreach ($cateCountsTmp as $key => $value) {
			$cateCounts[$value['cate_child_id']] = $value['num'];
		}
	}
	$cateListTmp = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(' AND pid=0 ', 'ORDER BY csort ASC,id DESC', 0, 50);
	$cateList = array();
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $_G['siteurl'] . $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$cateList[$key]['picurl'] = $picurl;
			$cateChildListTmp = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(' AND pid=' . $value['id'] . ' ', 'ORDER BY csort ASC,id DESC', 0, 100);
			$cateChildList = array();
			$i = 1;
			if (is_array($cateChildListTmp) && !empty($cateChildListTmp)) {
				foreach ($cateChildListTmp as $k => $v) {
					$cateChildList[$k] = $v;
					$cateChildList[$k]['num'] = 0;
					if (isset($cateCounts[$v['id']])) {
						$cateChildList[$k]['num'] = $cateCounts[$v['id']];
					}
					if ($i % 4 == 0) {
						$cateChildList[$k]['class'] = 'four-child__term';
					}
					$i = $i + 1;
				}
			}
			$cateList[$key]['cateChildList'] = $cateChildList;
		}
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tc114&site=' . $site_id . '&mod=cate');
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tc114:cate');
} elseif ($_GET['mod'] == 'list') {
	$cate_id = isset($_GET['cate_id']) ? intval($_GET['cate_id']) : 0;
	$cate_child_id = isset($_GET['cate_child_id']) ? intval($_GET['cate_child_id']) : 0;
	$city_id = intval($_GET['city_id']) > 0 ? intval($_GET['city_id']) : 0;
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$type = isset($_GET['type']) ? intval($_GET['type']) : 0;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	if ($cate_id > 0) {
		$cateInfo = C::t('#tom_tc114#tom_tc114_cate')->fetch_by_id($cate_id);
	}
	if ($type == 0) {
		if ($cateInfo['open_position_sort'] == 1) {
			$type = 3;
		} else {
			$type = 2;
		}
	}
	if ($cate_child_id > 0) {
		$cateChildInfo = C::t('#tom_tc114#tom_tc114_cate')->fetch_by_id($cate_child_id);
	}
	$areaInfo = array();
	if (!empty($area_id)) {
		$areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
	}
	$streetInfo = array();
	if (!empty($street_id)) {
		$streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
	}
	if ($tag_child_id > 0) {
		$tagChildCount = C::t('#tom_tc114#tom_tc114')->fetch_all_Count(' AND site_id IN(' . $sql_in_site_ids . ') AND tag_child_id = ' . $tag_child_id . ' AND status = 1 AND shenhe_status=1 ');
		if ($tagChildCount == 1) {
			$tagChildTc114Info = C::t('#tom_tc114#tom_tc114')->fetch_all_list(' AND tag_child_id = ' . $tag_child_id . ' ', 'ORDER BY id DESC', 0, 1);
			tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tc114&site=' . $site_id . '&mod=info&tc114_id=' . $tagChildTc114Info[0]['id']));
			exit(0);
		}
	}
	$whereStr = ' AND status=1 AND shenhe_status=1 ';
	if (!empty($sql_in_site_ids)) {
		$whereStr .= ' AND site_id IN(' . $sql_in_site_ids . ') ';
	}
	if ($cate_id > 0) {
		$whereStr .= ' AND cate_id=' . $cate_id . ' ';
	}
	if ($cate_child_id > 0) {
		$whereStr .= ' AND cate_child_id=' . $cate_child_id . ' ';
	}
	$tc114ListCount = C::t('#tom_tc114#tom_tc114')->fetch_all_count($whereStr);
	$cateListTmp = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(' AND pid=0 ', 'ORDER BY csort ASC,id DESC', 0, 50);
	$cateList = array();
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
		}
	}
	$cateChildList = array();
	if ($cate_id > 0) {
		$cateChildListTmp = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(' AND pid=' . $cate_id . ' ', 'ORDER BY csort ASC,id DESC', 0, 50);
		if (is_array($cateChildListTmp) && !empty($cateChildListTmp)) {
			foreach ($cateChildListTmp as $key => $value) {
				$cateChildList[$key] = $value;
			}
		}
	}
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		$areaList = $areaListTmp;
	}
	$ajaxGetCateChildUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=list_get_cate_child&&formhash=' . $formhash;
	$ajaxGetStreetUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=list_get_street&&formhash=' . $formhash;
	$shareTitle = lang('plugin/tom_tc114', 'list_title') . '-' . $__SitesInfo['name'];
	if ($cateInfo && $cateInfo['id'] > 0) {
		$shareTitle = $cateInfo['name'] . '(' . $tc114ListCount . ')-' . $__SitesInfo['name'];
	}
	if ($cateChildInfo && $cateChildInfo['id'] > 0) {
		$shareTitle = $cateChildInfo['name'] . '(' . $tc114ListCount . ')-' . $__SitesInfo['name'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tc114&site=' . $site_id . '&mod=list&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id);
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tc114:list');
} elseif ($_GET['mod'] == 'mylist') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$where = ' AND user_id=' . $__UserInfo['id'] . ' ';
	$order = ' ORDER BY id DESC ';
	if ($type == 1) {
		$where .= ' AND status=1 ';
	}
	if ($type == 2) {
		$where .= ' AND pay_status=1 ';
	}
	if ($type == 3) {
		$where .= ' AND (shenhe_status=2 OR shenhe_status=3) ';
		$order = ' ORDER BY shenhe_status ASC,id DESC ';
	}
	$count = C::t('#tom_tc114#tom_tc114')->fetch_all_count(' ' . $where . ' ');
	$tc114ListTmp = C::t('#tom_tc114#tom_tc114')->fetch_all_list(' ' . $where . ' ', ' ' . $order . ' ', $start, $pagesize);
	$tc114List = array();
	if (is_array($tc114ListTmp) && !empty($tc114ListTmp)) {
		foreach ($tc114ListTmp as $key => $value) {
			$tc114List[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $_G['siteurl'] . $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$tc114List[$key]['picurl'] = $picurl;
			$overTime = 1;
			if ($value['base_level'] == 2) {
				$overTime = dgmdate($value['base_time'], 'Y-m-d', $tomSysOffset);
			}
			$tc114List[$key]['overTime'] = $overTime;
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tc114&site=' . $site_id . '&mod=mylist&type=' . $type . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tc114&site=' . $site_id . '&mod=mylist&type=' . $type . '&page=' . $nextPage;
	$payUrl = 'plugin.php?id=tom_tc114:pay&site=' . $site_id . '&act=pay&formhash=' . $formhash;
	$xufeiUrl = 'plugin.php?id=tom_tc114:pay&site=' . $site_id . '&act=xufei&formhash=' . $formhash;
	$ajaxUpdateStatusUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=updateStatus&&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tc114:mylist');
} elseif ($_GET['mod'] == 'baidumap') {
	$lat = !empty($_GET['lat']) ? addslashes($_GET['lat']) : '';
	$lng = !empty($_GET['lng']) ? addslashes($_GET['lng']) : '';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tc114:baidumap');
} elseif ($_GET['mod'] == 'collect') {
	$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
	$pagesize = 10;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tc114#tom_tc114_collect')->fetch_all_count(' AND user_id = ' . $__UserInfo['id'] . ' ');
	$collectListTmp = C::t('#tom_tc114#tom_tc114_collect')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', $start, $pagesize);
	$collectList = array();
	if (is_array($collectListTmp) && !empty($collectListTmp)) {
		foreach ($collectListTmp as $key => $value) {
			$tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($value['tc114_id']);
			if ($tc114Info) {
				$collectList[$key] = $value;
				if (!preg_match('/^http/', $tc114Info['picurl'])) {
					if (strpos($tc114Info['picurl'], 'source/plugin/tom_') === false) {
						$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tc114Info['picurl'];
					} else {
						$picurl = $_G['siteurl'] . $tc114Info['picurl'];
					}
				} else {
					$picurl = $tc114Info['picurl'];
				}
				$tc114Info['picurl'] = $picurl;
				$collectList[$key]['tc114Info'] = $tc114Info;
			}
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tc114&site=' . $site_id . '&mod=collect&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tc114&site=' . $site_id . '&mod=collect&page=' . $nextPage;
	$ajax114CollectUrl = 'plugin.php?id=tom_tc114:ajax&site=' . $site_id . '&act=collect_cancel&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tc114:collect');
} elseif ($_GET['mod'] == 'renlinglist') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$pagesize = 10;
	$start = ($page - 1) * $pagesize;
	$where = ' AND user_id=' . $__UserInfo['id'] . ' AND order_status IN(0,2) ';
	$order = ' ORDER BY id DESC ';
	if ($type == 1) {
		$where .= ' AND shenhe_status=1 ';
	}
	if ($type == 2) {
		$where .= ' AND shenhe_status=2 ';
	}
	if ($type == 3) {
		$where .= ' AND shenhe_status=3 ';
	}
	$count = C::t('#tom_tc114#tom_tc114_renling')->fetch_all_count(' ' . $where . ' ');
	$renlingListTmp = C::t('#tom_tc114#tom_tc114_renling')->fetch_all_list(' ' . $where . ' ', ' ' . $order . ' ', $start, $pagesize);
	$renlingList = array();
	if (is_array($renlingListTmp) && !empty($renlingListTmp)) {
		foreach ($renlingListTmp as $key => $value) {
			$tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($value['tc114_id']);
			if ($tc114Info) {
				$renlingList[$key] = $value;
				if (!preg_match('/^http/', $tc114Info['picurl'])) {
					if (strpos($tc114Info['picurl'], 'source/plugin/tom_') === false) {
						$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tc114Info['picurl'];
					} else {
						$picurl = $_G['siteurl'] . $tc114Info['picurl'];
					}
				} else {
					$picurl = $tc114Info['picurl'];
				}
				$tc114Info['picurl'] = $picurl;
				$renlingList[$key]['tc114Info'] = $tc114Info;
			}
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tc114&site=' . $site_id . '&mod=renlinglist&type=' . $type . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tc114&site=' . $site_id . '&mod=renlinglist&type=' . $type . '&page=' . $nextPage;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tc114:renlinglist');
} elseif ($_GET['mod'] == 'tousu') {
	$tc114_id = intval($_GET['tc114_id']) > 0 ? intval($_GET['tc114_id']) : 0;
	if ($_GET['act'] == 'tousu' && $_GET['formhash'] == FORMHASH) {
		$tel = isset($_GET['tel']) ? daddslashes($_GET['tel']) : '';
		$content = isset($_GET['content']) ? daddslashes(diconv(urldecode($_GET['content']), 'utf-8')) : '';
		$insertData = array();
		$insertData['user_id'] = $__UserInfo['id'];
		$insertData['tc114_id'] = $tc114_id;
		$insertData['content'] = $content;
		$insertData['tel'] = $tel;
		$insertData['add_time'] = TIMESTAMP;
		C::t('#tom_tc114#tom_tc114_tousu')->insert($insertData);
		echo 200;
		exit(0);
	}
	$jubaoInfoUrl = 'plugin.php?id=tom_tc114&site=' . $site_id . '&mod=tousu';
	$succBackUrl = 'plugin.php?id=tom_tc114&site=' . $site_id . '&mod=info&tc114_id=' . $tc114_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tc114:tousu');
} elseif ($_GET['mod'] == 'ruzhu') {
	include DISCUZ_ROOT . './source/plugin/tom_tc114/module/ruzhu.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tc114/module/edit.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tc114/module/upload.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tc114&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();