<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tc114Config = $_G['cache']['plugin']['tom_tc114'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

include DISCUZ_ROOT.'./source/plugin/tom_tc114/class/function.core.php';

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end

$act = isset($_GET['act'])? addslashes($_GET['act']):"";

if($act == "ruzhu" && $_GET['formhash'] == FORMHASH){
   
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $invite_code        = isset($_GET['invite_code'])? addslashes($_GET['invite_code']):'';
    $invite_code        = trim($invite_code);
    $invite_code        = str_replace(" ", "", $invite_code);
    $ruzhu_level        = isset($_GET['ruzhu_level'])? intval($_GET['ruzhu_level']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $city_id            = isset($_GET['city_id'])? intval($_GET['city_id']):0;
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $xm                 = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel2               = isset($_GET['tel2'])? addslashes($_GET['tel2']):'';
    $job                = isset($_GET['job'])? addslashes($_GET['job']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content            = filterEmoji($content);
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):$tc114Config['default_picurl'];
    $qrcode             = isset($_GET['qrcode'])? addslashes($_GET['qrcode']):'';
    $lng                = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }

    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    if(empty($userInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $tjTchehuorenId = 0;
    if($__ShowTchehuoren == 1 && $tchehuorenConfig['tc114_type'] == 1){
        if(!empty($invite_code)){
            $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_list(" AND invite_code = '{$invite_code}' AND status=1 ", 'ORDER BY id DESC', 0, 1);
            if(is_array($tchehuorenInfoTmp) && !empty($tchehuorenInfoTmp[0])){
                $tjTchehuorenId = $tchehuorenInfoTmp[0]['id'];
            }
        }
    }else if($__ShowTchehuoren == 1 && $tchehuorenConfig['tc114_type'] == 2){
        if($userInfo['tj_hehuoren_id'] > 0){
            $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($userInfo['tj_hehuoren_id']);
            if($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1){
                $tjTchehuorenId = $userInfo['tj_hehuoren_id'];
            }
        }
    }
    
    $checkTelInfo = C::t('#tom_tc114#tom_tc114')->fetch_by_tel($tel);
    if($checkTelInfo){
        $outArr = array(
            'status'    => 201,
            'tc114_id'  => $checkTelInfo['id'],
        );
        echo json_encode($outArr); exit;
    }
    
    if($ruzhu_level == 2){
        $pay_price = $tc114Config['ruzhu_yongjiu_price'];
    }else{
        $pay_price = $tc114Config['ruzhu_price'];
    }
    
    if($pay_price > 0 && $tjTchehuorenId > 0 && $__ShowTchehuoren == 1 && $tchehuorenConfig['tc114_type'] == 1){
        $tc114_ruzhu_discount_arr = array(2=>0.95,3=>0.9,4=>0.85,5=>0.8,6=>0.75,7=>0.7,8=>0.65,9=>0.6,10=>0.55,11=>0.5);
        if(isset($tc114_ruzhu_discount_arr[$tchehuorenConfig['tc114_ruzhu_discount']])){
            $tc114_ruzhu_discount      = $tc114_ruzhu_discount_arr[$tchehuorenConfig['tc114_ruzhu_discount']];
            $pay_price         = number_format($pay_price*$tc114_ruzhu_discount,2,'.','');
        }
    }

    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['user_id']          = $user_id;
    if($tc114Config['base_time_type'] > 1 && $tc114Config['base_time_type'] < 7 && $ruzhu_level == 1){
        $insertData['base_level']    = 2;
        if($pay_price > 0){
        }else{
            if($tc114Config['base_time_type'] == 2){
                $insertData['base_time'] = TIMESTAMP + 7*86400;
            }else if($tc114Config['base_time_type'] == 3){
                $insertData['base_time'] = TIMESTAMP + 30*86400;
            }else if($tc114Config['base_time_type'] == 4){
                $insertData['base_time'] = TIMESTAMP + 90*86400;
            }else if($tc114Config['base_time_type'] == 5){
                $insertData['base_time'] = TIMESTAMP + 180*86400;
            }else if($tc114Config['base_time_type'] == 6){
                $insertData['base_time'] = TIMESTAMP + 365*86400;
            }
        }
    }
    $insertData['tj_hehuoren_id']   = $tjTchehuorenId;
    $insertData['cate_id']          = $cate_id;
    $insertData['cate_child_id']    = $cate_child_id;
    $insertData['city_id']          = $city_id;
    $insertData['area_id']          = $area_id;
    $insertData['street_id']        = $street_id;
    $insertData['title']            = $title;
    $insertData['xm']               = $xm;
    $insertData['tel']              = $tel;
    $insertData['tel2']             = $tel2;
    $insertData['job']              = $job;
    $insertData['content']          = $content.'|+|+|+|+|+|+|+|+|+|'.$title.'-'.$tel.'-'.$tel2.'-'.$address;
    $insertData['picurl']           = $picurl;
    $insertData['qrcode']           = $qrcode;
    $insertData['latitude']         = $lat;
    $insertData['longitude']        = $lng;
    $insertData['address']          = $address;
    $insertData['add_time']         = TIMESTAMP;
    if($pay_price > 0){
        $insertData['status']       = 2;
        $insertData['pay_status']   = 1;
    }else{
        $insertData['status']       = 1;
        $insertData['pay_status']   = 0;
    }
    if($tc114Config['must_shenhe'] == 1 ){
        $insertData['shenhe_status']       = 2;
    }else{
        $insertData['shenhe_status']       = 1;
    }
    if(C::t('#tom_tc114#tom_tc114')->insert($insertData)){
        
        $tc114Id = C::t('#tom_tc114#tom_tc114')->insert_id();
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['tc114_id'] = $tc114Id;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tc114#tom_tc114_photo')->insert($insertData);
            }
        }
        
        ## pay start
        if($pay_price > 0){
            
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }
            
            $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
            
            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['order_no']         = $order_no;
            $insertData['order_type']       = 1;
            $insertData['user_id']          = $user_id;
            $insertData['openid']           = $userInfo['openid'];
            $insertData['tc114_id']         = $tc114Id;
            $insertData['pay_price']        = $pay_price;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tc114#tom_tc114_order')->insert($insertData)){

                $insertData = array();
                $insertData['plugin_id']       = 'tom_tc114';      
                $insertData['order_no']        = $order_no;            
                $insertData['goods_id']        = $tc114Id;           
                $insertData['goods_name']      = lang('plugin/tom_tc114','pay_order_type_1');
                $insertData['goods_beizu']     = lang('plugin/tom_tc114','pay_order_type_1');
                $insertData['goods_url']       = "plugin.php?id=tom_tc114&site={$site_id}&mod=info&tc114_id={$tc114Id}";
                $insertData['succ_back_url']   = "plugin.php?id=tom_tc114&site={$site_id}&mod=mylist&fromlist=mylist";
                $insertData['fail_back_url']   = "plugin.php?id=tom_tc114&site={$site_id}&mod=ruzhu";
                $insertData['allow_alipay']    = 1;         
                $insertData['pay_price']       = $pay_price;    
                $insertData['order_status']    = 1;             
                $insertData['add_time']        = TIMESTAMP;     
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    $outArr = array(
                        'pay_status' => 1,
                        'status'    => 200,
                        'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                    );
                    echo json_encode($outArr); exit;
                    
                }else{
                    $outArr = array(
                        'status'=> 303,
                    );
                    echo json_encode($outArr); exit;
                }

            }else{
                $outArr = array(
                    'status'=> 304,
                );
                echo json_encode($outArr); exit;
            }
        }
        ## pay end
        
        if($site_id > 1){
            $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
            $manage_user_id = $siteInfo['manage_user_id'];
            $site_name = $siteInfo['name'];
        }else{
            $manage_user_id = $tongchengConfig['manage_user_id'];
            $site_name = $tongchengConfig['plugin_name'];
        }
        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($manage_user_id);
    
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($toUser['openid'])){

            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tc114&site={$site_id}&mod=index");

            if($tc114Config['must_shenhe'] == 1){
                $template_first = str_replace("{NAME}",$title, lang('plugin/tom_tc114','shenhe_template_first'));
            }else{
                $template_first = str_replace("{NAME}",$title, lang('plugin/tom_tc114','ruzhu_template_0_first'));
            }

            $smsData = array(
                'first'         => $template_first,
                'keyword1'      => $site_name,
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);

        }
        
        $outArr = array(
            'pay_status' => 0,
            'status'=> 200,
            'tc114_id'=> $tc114Id,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "pay" && $_GET['formhash'] == FORMHASH){
    
    $tc114_id   = isset($_GET['tc114_id'])? intval($_GET['tc114_id']):0;
    
    $tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($tc114_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tc114Info['user_id']); 
    
    $pay_price = $tc114Config['ruzhu_price'];
    
    $orderListTmp = C::t('#tom_tc114#tom_tc114_order')->fetch_all_list(" AND tc114_id={$tc114_id} AND user_id={$userInfo['id']} AND order_type=1 AND order_status=1 ","ORDER BY id DESC",0,10);
    if(is_array($orderListTmp) && !empty($orderListTmp)){
        foreach ($orderListTmp as $key => $value){
            $updateData = array();
            $updateData['order_status'] = 3;
            C::t('#tom_tc114#tom_tc114_order')->update($value['id'],$updateData);
        }
    }
    
    if($pay_price > 0){
        
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        
        $insertData = array();
        $insertData['site_id']          = $tc114Info['site_id'];
        $insertData['order_no']         = $order_no;
        $insertData['order_type']       = 1;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['tc114_id']         = $tc114_id;
        $insertData['pay_price']        = $pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tc114#tom_tc114_order')->insert($insertData)){
            
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tc114';      
            $insertData['order_no']        = $order_no;            
            $insertData['goods_id']        = $tc114_id;           
            $insertData['goods_name']      = lang('plugin/tom_tc114','pay_order_type_1');
            $insertData['goods_beizu']     = lang('plugin/tom_tc114','pay_order_type_1');
            $insertData['goods_url']       = "plugin.php?id=tom_tc114&site={$site_id}&mod=info&tc114_id={$tc114_id}";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tc114&site={$site_id}&mod=mylist&fromlist=mylist";
            $insertData['fail_back_url']   = "plugin.php?id=tom_tc114&site={$site_id}&mod=mylist&fromlist=mylist";
            $insertData['allow_alipay']    = 1;         
            $insertData['pay_price']       = $pay_price;    
            $insertData['order_status']    = 1;             
            $insertData['add_time']        = TIMESTAMP;     
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'pay_status' => 1,
                    'status'    => 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
                
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }
            
        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    
    }else{
        $outArr = array(
            'status'=> 400,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "xufei" && $_GET['formhash'] == FORMHASH){
    
    $tc114_id   = isset($_GET['tc114_id'])? intval($_GET['tc114_id']):0;
    
    $tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($tc114_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tc114Info['user_id']);
    
    if($tc114Info['base_level'] == 1){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tc114Info['status'] != 3){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    $pay_price = $tc114Config['base_xufei_price'];
    
    $orderListTmp = C::t('#tom_tc114#tom_tc114_order')->fetch_all_list(" AND tc114_id={$tc114_id} AND user_id={$userInfo['id']} AND order_type=2 AND order_status=1 ","ORDER BY id DESC",0,10);
    if(is_array($orderListTmp) && !empty($orderListTmp)){
        foreach ($orderListTmp as $key => $value){
            $updateData = array();
            $updateData['order_status'] = 3;
            C::t('#tom_tc114#tom_tc114_order')->update($value['id'],$updateData);
        }
    }
    
    if($pay_price > 0){
        
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        
        $insertData = array();
        $insertData['site_id']          = $tc114Info['site_id'];
        $insertData['order_no']         = $order_no;
        $insertData['order_type']       = 2;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['tc114_id']         = $tc114_id;
        $insertData['pay_price']        = $pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tc114#tom_tc114_order')->insert($insertData)){

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tc114';
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $tc114_id;
            $insertData['goods_name']      = lang('plugin/tom_tc114','pay_order_type_2');
            $insertData['goods_beizu']     = lang('plugin/tom_tc114','pay_order_type_2');
            $insertData['goods_url']       = "plugin.php?id=tom_tc114&site={$site_id}&mod=details&tc114_id={$tc114_id}";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tc114&site={$site_id}&mod=mylist&tc114_id={$tc114_id}";
            $insertData['fail_back_url']   = "plugin.php?id=tom_tc114&site={$site_id}&mod=mylist&tc114_id={$tc114_id}";
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'    => 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }

    }else{
        $outArr = array(
            'status'=> 400,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "renling" && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $tc114_id   = intval($_GET['tc114_id'])>0? intval($_GET['tc114_id']):0;
    $user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $name       = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tel        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $content    = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($tc114_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    if($user_id <= 0){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $renlingInfoTmp = C::t('#tom_tc114#tom_tc114_renling')->fetch_all_list(" AND user_id = {$user_id} AND shenhe_status = 2 AND order_status = 2 AND tc114_id = {$tc114_id} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($renlingInfoTmp) && !empty($renlingInfoTmp[0])){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tc114Info['user_id'] == $userInfo['id']){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if(floatval($tc114Config['pay_renling_price']) <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $pay_price = floatval($tc114Config['pay_renling_price']);
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['tc114_id']         = $tc114_id;
    $insertData['user_id']          = $userInfo['id'];
    $insertData['name']             = $name;
    $insertData['tel']              = $tel;
    $insertData['content']          = $content;
    $insertData['shenhe_status']    = 2;
    $insertData['order_status']     = 1;
    $insertData['add_time']         = TIMESTAMP;
    if(C::t('#tom_tc114#tom_tc114_renling')->insert($insertData)){
        $renling_id = C::t('#tom_tc114#tom_tc114_renling')->insert_id();
        
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        
        $insertData = array();
        $insertData['site_id']          = $tc114Info['site_id'];
        $insertData['order_no']         = $order_no;
        $insertData['order_type']       = 3;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['tc114_id']         = $tc114_id;
        $insertData['renling_id']       = $renling_id;
        $insertData['pay_price']        = $pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tc114#tom_tc114_order')->insert($insertData)){

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tc114';
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $tc114_id;
            $insertData['goods_name']      = lang('plugin/tom_tc114','pay_order_type_3');
            $insertData['goods_beizu']     = lang('plugin/tom_tc114','pay_order_type_3');
            $insertData['goods_url']       = "plugin.php?id=tom_tc114&site={$site_id}&mod=info&tc114_id={$tc114_id}";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tc114&site={$site_id}&mod=info&tc114_id={$tc114_id}";
            $insertData['fail_back_url']   = "plugin.php?id=tom_tc114&site={$site_id}&mod=info&tc114_id={$tc114_id}";
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'    => 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 304,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }

    }else{
        $outArr = array(
            'status'=> 400,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "shoufei" && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $tc114_id   = intval($_GET['tc114_id'])>0? intval($_GET['tc114_id']):0;
    $user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    
    $tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($tc114_id);
    $cateInfo = C::t('#tom_tc114#tom_tc114_cate')->fetch_by_id($tc114Info['cate_id']);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    if($user_id <= 0){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tc114Config['pay_shoufei_price'] <= 0){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $pay_price = $tc114Config['pay_shoufei_price'];

    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }

    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

    $insertData = array();
    $insertData['site_id']          = $tc114Info['site_id'];
    $insertData['order_no']         = $order_no;
    $insertData['order_type']       = 4;
    $insertData['user_id']          = $userInfo['id'];
    $insertData['openid']           = $userInfo['openid'];
    $insertData['tc114_id']         = $tc114_id;
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tc114#tom_tc114_order')->insert($insertData)){

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tc114';
        $insertData['order_no']        = $order_no;
        $insertData['goods_id']        = $tc114_id;
        $insertData['goods_name']      = lang('plugin/tom_tc114','pay_order_type_4');
        $insertData['goods_beizu']     = lang('plugin/tom_tc114','pay_order_type_4');
        $insertData['goods_url']       = "plugin.php?id=tom_tc114&site={$site_id}&mod=info&tc114_id={$tc114_id}";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tc114&site={$site_id}&mod=info&tc114_id={$tc114_id}";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tc114&site={$site_id}&mod=info&tc114_id={$tc114_id}";
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $pay_price;
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'    => 200,
                'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }

    }else{
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}