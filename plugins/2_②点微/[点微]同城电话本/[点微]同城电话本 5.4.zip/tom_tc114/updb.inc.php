<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/plugin');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $sql = '';

    $tom_tc114_field = C::t('#tom_tc114#tom_tc114')->fetch_all_field();
    if (!isset($tom_tc114_field['sort'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114` ADD `sort` int(11) DEFAULT '999999';\n";
    }
    if (!isset($tom_tc114_field['changyong_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114` ADD `changyong_status` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tc114_field['city_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114` ADD `city_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tc114_field['area_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114` ADD `area_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tc114_field['street_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114` ADD `street_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tc114_field['tj_hehuoren_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114` ADD `tj_hehuoren_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tc114_field['tel2'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114` ADD `tel2` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tc114_field['xm'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114` ADD `xm` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tc114_field['job'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114` ADD `job` varchar(255) DEFAULT NULL;\n";
    }

    $tom_tc114_cate_field = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_field();
    if (!isset($tom_tc114_cate_field['open_position_sort'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114_cate` ADD `open_position_sort` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tc114_cate_field['open_shoufei'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114_cate` ADD `open_shoufei` tinyint(4) DEFAULT '0';\n";
    }

    $tom_tc114_renling_field = C::t('#tom_tc114#tom_tc114_renling')->fetch_all_field();
    if (!isset($tom_tc114_renling_field['order_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114_renling` ADD `order_status` int(11) DEFAULT '0';\n";
    }

    $tom_tc114_order_field = C::t('#tom_tc114#tom_tc114_order')->fetch_all_field();
    if (!isset($tom_tc114_order_field['renling_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114_order` ADD `renling_id` int(11) DEFAULT '0';\n";
    }
    
    if (!empty($sql)) {
        runquery($sql);
    }
    
    $sql = <<<EOF
    CREATE TABLE IF NOT EXISTS `pre_tom_tc114_focuspic` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `site_id` int(11) DEFAULT '1',
        `title` varchar(255) DEFAULT NULL,
        `picurl` varchar(255) DEFAULT NULL,
        `link` varchar(255) DEFAULT NULL,
        `fsort` int(11) DEFAULT '10',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_tc114_cache` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `site_id` int(11) DEFAULT '0',
      `cate_id` int(11) DEFAULT '0',
      `cate_child_id` int(11) DEFAULT '0',
      `user_id` int(11) DEFAULT '0',
      `title` varchar(255) DEFAULT NULL,
      `tel` varchar(255) DEFAULT NULL,
      `address` varchar(255) DEFAULT NULL,
      `content` text,
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

EOF;

    runquery($sql);
    
    $sql = '';

    $tom_tc114_cache_field = C::t('#tom_tc114#tom_tc114_cache')->fetch_all_field();
    if (!isset($tom_tc114_cache_field['city_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114_cache` ADD `city_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tc114_cache_field['area_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114_cache` ADD `area_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tc114_cache_field['street_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114_cache` ADD `street_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tc114_cache_field['longitude'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114_cache` ADD `longitude` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tc114_cache_field['latitude'])) {
        $sql .= "ALTER TABLE `pre_tom_tc114_cache` ADD `latitude` varchar(255) DEFAULT NULL;\n";
    }
    if (!empty($sql)) {
        runquery($sql);
    }

    echo 'OK';exit;
    
}else{
    exit('Access Denied');
}



