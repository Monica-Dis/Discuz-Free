<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
loaducenter();
$formhash = FORMHASH;
$tc114Config = $_G['cache']['plugin']['tom_tc114'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$__ShowTcshop = 0;
$tcshopConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcshop/tom_tcshop.inc.php')) {
	$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
	if ($tcshopConfig['open_tcshop'] == 1) {
		$__ShowTcshop = 1;
	}
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login_ajax.php';
include DISCUZ_ROOT . './source/plugin/tom_tc114/class/function.core.php';
$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');
if ($_GET['act'] == 'list' && $_GET['formhash'] == FORMHASH) {
	include DISCUZ_ROOT . './source/plugin/tom_tc114/module/list.php';
} elseif ($_GET['act'] == 'tag_list' && $_GET['formhash'] == FORMHASH) {
	$outStr = '';
	$tag_id = intval($_GET['tag_id']) > 0 ? intval($_GET['tag_id']) : 0;
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$pagesize = intval($_GET['pagesize']) > 0 ? intval($_GET['pagesize']) : 20;
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$orderStr = ' ORDER BY add_time DESC,id DESC ';
	$pagesize = $pagesize;
	$start = ($page - 1) * $pagesize;
	if ($tag_id > 0) {
		$tagListTmp = C::t('#tom_tc114#tom_tc114_tag')->fetch_all_list(' AND pid = ' . $tag_id . ' ', 'ORDER BY tsort ASC,id DESC', $start, $pagesize);
	} else {
		$tagListTmp = C::t('#tom_tc114#tom_tc114_tag')->fetch_all_list(' AND is_cy = 1 ', 'ORDER BY tsort ASC,id DESC', $start, $pagesize);
	}
	$tagList = array();
	foreach ($tagListTmp as $key => $value) {
		$tagList[$key] = $value;
		if (!preg_match('/^http/', $value['picurl'])) {
			if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
				$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
			} else {
				$picurl = $_G['siteurl'] . $value['picurl'];
			}
		} else {
			$picurl = $value['picurl'];
		}
		$tagList[$key]['picurl'] = $picurl;
	}
	if (is_array($tagList) && !empty($tagList)) {
		foreach ($tagList as $key => $val) {
			$outStr .= '<a href="plugin.php?id=tom_tc114&site=' . $site_id . '&mod=list&tag_child_id=' . $val['id'] . '" class="tc114-xinxi__term">';
			$outStr .= '<div class="term-logo"><img src="' . $val['picurl'] . '"></div>';
			$outStr .= '<div class="term-title">' . $val['name'] . '</div>';
			$outStr .= '</a>';
		}
	} else {
		$outStr = '205';
	}
	$outStr = tom_link_replace($outStr);
	$outStr = diconv($outStr, CHARSET, 'utf-8');
	echo json_encode($outStr);
	exit(0);
} elseif ($_GET['act'] == 'jiucuo' && $_GET['formhash'] == FORMHASH) {
	$outArr = array('status' => 1);
	if ('utf-8' != CHARSET) {
		if (!defined('IN_MOBILE')) {
			foreach ($_POST as $pk => $pv) {
				if (!is_numeric($pv)) {
					$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
				}
			}
		}
	}
	$tc114_id = intval($_GET['tc114_id']) > 0 ? intval($_GET['tc114_id']) : 0;
	$name = isset($_GET['name']) ? addslashes($_GET['name']) : '';
	$tel = isset($_GET['tel']) ? addslashes($_GET['tel']) : '';
	$content = isset($_GET['content']) ? addslashes($_GET['content']) : '';
	$tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($tc114_id);
	$jiucuoInfoTmp = C::t('#tom_tc114#tom_tc114_jiucuo')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND shenhe_status = 2 AND tc114_id = ' . $tc114_id . ' ', 'ORDER BY id DESC', 0, 1);
	if (is_array($jiucuoInfoTmp) && !empty($jiucuoInfoTmp[0])) {
		$outArr = array('status' => 301);
		echo json_encode($outArr);
		exit(0);
	}
	$insertData = array();
	$insertData['site_id'] = $site_id;
	$insertData['tc114_id'] = $tc114_id;
	$insertData['user_id'] = $__UserInfo['id'];
	$insertData['name'] = $name;
	$insertData['tel'] = $tel;
	$insertData['content'] = $content;
	$insertData['shenhe_status'] = 2;
	$insertData['add_time'] = TIMESTAMP;
	C::t('#tom_tc114#tom_tc114_jiucuo')->insert($insertData);
	$outArr = array('status' => 200);
	echo json_encode($outArr);
	exit(0);
} elseif ($_GET['act'] == 'renling' && $_GET['formhash'] == FORMHASH) {
	$outArr = array('status' => 1);
	if ('utf-8' != CHARSET) {
		if (!defined('IN_MOBILE')) {
			foreach ($_POST as $pk => $pv) {
				if (!is_numeric($pv)) {
					$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
				}
			}
		}
	}
	$tc114_id = intval($_GET['tc114_id']) > 0 ? intval($_GET['tc114_id']) : 0;
	$name = isset($_GET['name']) ? addslashes($_GET['name']) : '';
	$tel = isset($_GET['tel']) ? addslashes($_GET['tel']) : '';
	$content = isset($_GET['content']) ? addslashes($_GET['content']) : '';
	$tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($tc114_id);
	$renlingInfoTmp = C::t('#tom_tc114#tom_tc114_renling')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND shenhe_status = 2 AND tc114_id = ' . $tc114_id . ' ', 'ORDER BY id DESC', 0, 1);
	if (is_array($renlingInfoTmp) && !empty($renlingInfoTmp[0])) {
		$outArr = array('status' => 301);
		echo json_encode($outArr);
		exit(0);
	}
	if ($tc114Info['user_id'] == $__UserInfo['id']) {
		$outArr = array('status' => 500);
		echo json_encode($outArr);
		exit(0);
	}
	$insertData = array();
	$insertData['site_id'] = $site_id;
	$insertData['tc114_id'] = $tc114_id;
	$insertData['user_id'] = $__UserInfo['id'];
	$insertData['name'] = $name;
	$insertData['tel'] = $tel;
	$insertData['content'] = $content;
	$insertData['shenhe_status'] = 2;
	$insertData['add_time'] = TIMESTAMP;
	C::t('#tom_tc114#tom_tc114_renling')->insert($insertData);
	$outArr = array('status' => 200);
	echo json_encode($outArr);
	exit(0);
} elseif ($_GET['act'] == 'updateStatus' && $_GET['formhash'] == FORMHASH && $userStatus) {
	$tc114_id = intval($_GET['tc114_id']) > 0 ? intval($_GET['tc114_id']) : 0;
	$tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($tc114_id);
	if ($tc114Info['user_id'] != $__UserInfo['id']) {
		echo '404';
		exit(0);
	}
	if ($_GET['status'] == 1) {
		$updateData = array();
		$updateData['status'] = 1;
		C::t('#tom_tc114#tom_tc114')->update($tc114_id, $updateData);
	} elseif ($_GET['status'] == 2) {
		$updateData = array();
		$updateData['status'] = 2;
		C::t('#tom_tc114#tom_tc114')->update($tc114_id, $updateData);
	}
	echo 200;
	exit(0);
} elseif ($_GET['act'] == 'collect' && $_GET['formhash'] == FORMHASH) {
	$tc114_id = intval($_GET['tc114_id']) > 0 ? intval($_GET['tc114_id']) : 0;
	$tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($tc114_id);
	$collectInfoTmp = C::t('#tom_tc114#tom_tc114_collect')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND tc114_id = ' . $tc114_id . ' ', 'ORDER BY id DESC', 0, 1);
	if (is_array($collectInfoTmp) && !empty($collectInfoTmp[0])) {
		echo 301;
		exit(0);
	}
	$insertData = array();
	$insertData['site_id'] = $site_id;
	$insertData['user_id'] = $__UserInfo['id'];
	$insertData['tc114_id'] = $tc114_id;
	C::t('#tom_tc114#tom_tc114_collect')->insert($insertData);
	echo 200;
	exit(0);
} elseif ($_GET['act'] == 'collect_cancel' && $_GET['formhash'] == FORMHASH) {
	$collect_id = intval($_GET['collect_id']) > 0 ? intval($_GET['collect_id']) : 0;
	C::t('#tom_tc114#tom_tc114_collect')->delete_by_id($collect_id);
	echo 200;
	exit(0);
} elseif ($_GET['act'] == 'list_get_cate_child' && $_GET['formhash'] == FORMHASH) {
	$outStr = '';
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$childCateList = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(' AND pid=' . $cate_id . ' ', ' ORDER BY csort ASC,id DESC ', 0, 100);
	if (is_array($childCateList) && !empty($childCateList)) {
		$outStr = '<li class="item" data-id="0" data-name="' . lang('plugin/tom_tc114', 'template_cate_all') . '">' . lang('plugin/tom_tc114', 'template_cate_all') . '</li>';
		foreach ($childCateList as $key => $value) {
			$outStr .= '<li class="item" data-id="' . $value['id'] . '" data-name="' . $value['name'] . '">' . $value['name'] . '</li>';
		}
	} else {
		$outStr = '100';
	}
	$outStr = diconv($outStr, CHARSET, 'utf-8');
	echo json_encode($outStr);
	exit(0);
} elseif ($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH) {
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$url = $_G['siteurl'] . 'plugin.php?id=tom_tc114&site=' . $site_id . '&mod=list&keyword=' . urlencode(trim($keyword));
	$url = tom_link_replace($url);
	echo $url;
	exit(0);
} elseif ($_GET['act'] == 'clicks' && $_GET['formhash'] == FORMHASH && $userStatus) {
	$tc114_id = intval($_GET['tc114_id']) > 0 ? intval($_GET['tc114_id']) : 0;
	DB::query('UPDATE ' . DB::table('tom_tc114') . (' SET clicks=clicks+1 WHERE id=\'' . $tc114_id . '\''), 'UNBUFFERED');
	echo 1;
	exit(0);
} elseif ($_GET['act'] == 'shares' && $_GET['formhash'] == FORMHASH && $userStatus) {
	$tc114_id = intval($_GET['tc114_id']) > 0 ? intval($_GET['tc114_id']) : 0;
	DB::query('UPDATE ' . DB::table('tom_tc114') . (' SET shares=shares+1 WHERE id=\'' . $tc114_id . '\''), 'UNBUFFERED');
	echo 1;
	exit(0);
} elseif ($_GET['act'] == 'update_lbs' && $_GET['formhash'] == FORMHASH) {
	$latitude = isset($_GET['latitude']) ? addslashes($_GET['latitude']) : '';
	$longitude = isset($_GET['longitude']) ? addslashes($_GET['longitude']) : '';
	$cookieTime = 86400 * 3;
	dsetcookie('tom_tongcheng_user_latitude', $latitude, $cookieTime);
	dsetcookie('tom_tongcheng_user_longitude', $longitude, $cookieTime);
	echo 200;
	exit(0);
} elseif ($_GET['act'] == 'commonClicks' && $_GET['formhash'] == FORMHASH) {
	DB::query('UPDATE ' . DB::table('tom_tc114_common') . (' SET clicks=clicks+1 WHERE id=\'' . $site_id . '\' '), 'UNBUFFERED');
	echo 200;
	exit(0);
} elseif ($_GET['act'] == 'commonShares' && $_GET['formhash'] == FORMHASH) {
	DB::query('UPDATE ' . DB::table('tom_tc114_common') . (' SET shares=shares+1 WHERE id=\'' . $site_id . '\' '), 'UNBUFFERED');
	echo 200;
	exit(0);
} elseif ($_GET['act'] == 'update_base_level' && $_GET['formhash'] == FORMHASH) {
	if ($tc114Config['base_time_type'] == 1) {
		echo 100;
		exit(0);
	}
	$cookiesBaseLevel = getcookie('tom_tc114_update_base_level');
	if (empty($cookiesBaseLevel) || $cookiesBaseLevel != 1) {
		$tc114ListTmp = C::t('#tom_tc114#tom_tc114')->fetch_all_list(' AND status = 1 AND pay_status IN (0,2) AND base_level=2 AND base_time<' . TIMESTAMP . ' ', ' ORDER BY base_time ASC,id DESC ', 0, 10);
		if (is_array($tc114ListTmp) && !empty($tc114ListTmp)) {
			foreach ($tc114ListTmp as $key => $value) {
				$updateData = array();
				$updateData['status'] = 3;
				C::t('#tom_tc114#tom_tc114')->update($value['id'], $updateData);
			}
		}
		dsetcookie('tom_tc114_update_base_level', 1, 300);
	}
	echo 200;
	exit(0);
} elseif ($_GET['act'] == 'auto_click' && $_GET['formhash'] == FORMHASH) {
	$cookies_auto_click_status = getcookie('tom_tc114_auto_click_status');
	$halfhour = TIMESTAMP - 1800;
	$threedays = TIMESTAMP - 86400 * 3;
	if ($tc114Config['open_auto_click'] == 1) {
		$auto_min_num = 5;
		$auto_max_num = 10;
		if ($tc114Config['auto_min_num'] < $tc114Config['auto_max_num']) {
			$auto_min_num = $tc114Config['auto_min_num'];
			$auto_max_num = $tc114Config['auto_max_num'];
		}
		if (empty($cookies_auto_click_status) || $cookies_auto_click_status != 1) {
			$tc114ListTmp = C::t('#tom_tc114#tom_tc114')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND add_time<' . $halfhour . ' AND auto_click_time<' . $nowDayTime, ' ORDER BY id DESC ', 0, 10);
			if (is_array($tc114ListTmp) && !empty($tc114ListTmp)) {
				$i = 0;
				foreach ($tc114ListTmp as $key => $value) {
					$auto_click_num = mt_rand($auto_min_num, $auto_max_num);
					$i = $i + $auto_click_num;
					$updateData = array();
					$updateData['clicks'] = $value['clicks'] + $auto_click_num;
					$updateData['auto_click_time'] = $nowDayTime;
					C::t('#tom_tc114#tom_tc114')->update($value['id'], $updateData);
				}
				if ($tc114Config['open_tj_commonclicks'] == 1) {
					DB::query('UPDATE ' . DB::table('tom_tc114_common') . (' SET clicks=clicks+' . $i . ' WHERE id=\'' . $site_id . '\' '), 'UNBUFFERED');
				}
			}
			dsetcookie('tom_tc114_auto_click_status', 1, 300);
		}
	}
	echo 200;
	exit(0);
} elseif ($_GET['act'] == 'childcates') {
	$callback = $_GET['callback'];
	$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
	$outArr = array();
	$childCateList = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(' AND pid=' . $pid . ' ', ' ORDER BY csort ASC,id DESC ', 0, 50);
	if (is_array($childCateList) && !empty($childCateList)) {
		foreach ($childCateList as $key => $value) {
			$outArr[$key]['id'] = $value['id'];
			$outArr[$key]['name'] = diconv($value['name'], CHARSET, 'utf-8');
		}
	}
	$outStr = '';
	$outStr = json_encode($outArr);
	if ($callback) {
		$outStr = $callback . '(' . $outStr . ')';
	}
	echo $outStr;
	exit(0);
} elseif ($_GET['act'] == 'getstreet') {
	$callback = $_GET['callback'];
	$area_id = isset($_GET['area_id']) ? intval($_GET['area_id']) : 0;
	$outArr = array();
	$streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
	if (is_array($streetList) && !empty($streetList)) {
		foreach ($streetList as $key => $value) {
			$outArr[$key]['id'] = $value['id'];
			$outArr[$key]['name'] = diconv($value['name'], CHARSET, 'utf-8');
		}
	}
	$outStr = '';
	$outStr = json_encode($outArr);
	if ($callback) {
		$outStr = $callback . '(' . $outStr . ')';
	}
	echo $outStr;
	exit(0);
} elseif ($_GET['act'] == 'childtags') {
	$callback = $_GET['callback'];
	$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
	$outArr = array();
	$childTagList = C::t('#tom_tc114#tom_tc114_tag')->fetch_all_list(' AND pid=' . $pid . ' ', ' ORDER BY tsort ASC,id DESC ', 0, 50);
	if (is_array($childTagList) && !empty($childTagList)) {
		foreach ($childTagList as $key => $value) {
			$outArr[$key]['id'] = $value['id'];
			$outArr[$key]['name'] = diconv($value['name'], CHARSET, 'utf-8');
		}
	}
	$outStr = '';
	$outStr = json_encode($outArr);
	if ($callback) {
		$outStr = $callback . '(' . $outStr . ')';
	}
	echo $outStr;
	exit(0);
} elseif ($_GET['act'] == 'get_geocoder' && $_GET['formhash'] == FORMHASH) {
	$outStr = '205';
	$longitude = !empty($_GET['longitude']) ? addslashes($_GET['longitude']) : '';
	$latitude = !empty($_GET['latitude']) ? addslashes($_GET['latitude']) : '';
	if (!empty($latitude) && !empty($longitude)) {
		$distanceApi = 'http://api.map.baidu.com/reverse_geocoding/v3/?ak=' . $tc114Config['baidu_ak'] . '&location=' . $latitude . ',' . $longitude . '&output=json&pois=0';
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $distanceApi);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		$content = curl_exec($ch);
		curl_close($ch);
		$return = json_decode($content, true);
		$return = wx_iconv_recurrence($return);
		if (is_array($return) && $return['status'] == 0 && !empty($return['result'])) {
			$outStr = $return['result']['addressComponent']['city'] . $return['result']['addressComponent']['district'] . $return['result']['addressComponent']['town'] . $return['result']['addressComponent']['street'] . $return['result']['addressComponent']['street_number'];
			if (!empty($return['result']['poiRegions']['name'])) {
				$outStr .= $return['result']['poiRegions']['name'];
			}
		}
	}
	$outStr = diconv($outStr, CHARSET, 'utf-8');
	echo json_encode($outStr);
	exit(0);
} else {
	echo 'error';
	exit(0);
}