<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=cache';
$modListUrl = $adminListUrl.'&tmod=cache';
$modFromUrl = $adminFromUrl.'&tmod=cache';

if($_GET['act'] == 'csv'){
    if(submitcheck('submit')){
        
        $file_url = '';
        if($_FILES["csv_array"]['tmp_name']) {
            $upload = new tom_upload();
            if(!$upload->init($_FILES["csv_array"], 'temp', random(3, 1), random(8)) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }

            $file_url = $upload->attach['attachment'];
        }
        
        $dataArr = array();
		if(!empty($file_url)){
			if(file_exists($_G['setting']['attachdir'].'temp/'.$file_url)){
                $row = 1;
                $handle = fopen($_G['setting']['attachdir'].'temp/'.$file_url,"r");
                while ($data = fgetcsv_reg($handle, 1000, ",")) {
                    $num = count($data);
                    if($row > 1){
                        for ($c=0; $c < $num; $c++) {
                            $dataArr[$row][$c] = $data[$c] ;
                        }
                    }
                    $row++;
                }
                fclose($handle);
            }
		}
        
        if (CHARSET == 'utf-8') {
            $dataArr = tom_iconv($dataArr,'gbk','utf-8');
        }
        
        if(is_array($dataArr) && !empty($dataArr)){
            foreach ($dataArr as $key => $value){
                $insertData = array();
                $insertData['site_id']          = $value[0];
                $insertData['cate_id']          = $value[1];
                $insertData['cate_child_id']    = $value[2];
                $insertData['user_id']          = $value[3];
                $insertData['title']            = $value[4];
                $insertData['tel']              = $value[5];
                $insertData['address']          = $value[6];
                $insertData['content']          = $value[7];
                $insertData['city_id']          = $value[8];
                $insertData['area_id']          = $value[9];
                $insertData['street_id']        = $value[10];
                $insertData['longitude']        = $value[11];
                $insertData['latitude']         = $value[12];
                C::t('#tom_tc114#tom_tc114_cache')->insert($insertData);
            }
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }
    
}else if($_GET['act'] == 'batch_import'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $cacheInfo = C::t('#tom_tc114#tom_tc114_cache')->fetch_by_id($value);
            $checkTelInfo = C::t('#tom_tc114#tom_tc114')->fetch_by_tel($cacheInfo['tel']);
            if($checkTelInfo){
                C::t('#tom_tc114#tom_tc114_cache')->delete_by_id($value);
            }else{
                $insertData = array();
                $insertData['site_id']            = $cacheInfo['site_id'];
                $insertData['cate_id']            = $cacheInfo['cate_id'];
                $insertData['cate_child_id']      = $cacheInfo['cate_child_id'];
                $insertData['city_id']            = $cacheInfo['city_id'];
                $insertData['area_id']            = $cacheInfo['area_id'];
                $insertData['street_id']          = $cacheInfo['street_id'];
                $insertData['user_id']            = $cacheInfo['user_id'];
                $insertData['title']              = $cacheInfo['title'];
                $insertData['tel']                = $cacheInfo['tel'];
                $insertData['address']            = $cacheInfo['address'];
                $insertData['longitude']          = $cacheInfo['longitude'];
                $insertData['latitude']           = $cacheInfo['latitude'];
                $insertData['content']            = $cacheInfo['content'].'|+|+|+|+|+|+|+|+|+|'.$cacheInfo['title'].'-'.$cacheInfo['tel'].'-'.$cacheInfo['address'];
                $insertData['picurl']             = $tc114Config['default_picurl'];
                $insertData['status']             = 1;
                $insertData['add_time']           = TIMESTAMP;
                C::t('#tom_tc114#tom_tc114')->insert($insertData);
                C::t('#tom_tc114#tom_tc114_cache')->delete_by_id($value);
            }
        }
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'batch_del'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            C::t('#tom_tc114#tom_tc114_cache')->delete_by_id($value);
        }
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tc114#tom_tc114_cache')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'truncate'){
    
    $sql='TRUNCATE TABLE '.DB::table('tom_tc114_cache');
    DB::query($sql);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['cache_list_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['cache_help_1'] . '</li>';
    echo '<li>' . $Lang['cache_help_2'] . '</li>';
    echo '<li>' . $Lang['cache_help_3'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();
    
    showformheader($modFromUrl.'&act=csv','enctype');
    showtableheader();
    tomshowsetting(true,array('title'=>$Lang['cache_file'],'name'=>'csv_array','value'=>'','msg'=>$Lang['cache_file_msg']),"file");
    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['cache_list_list_title'] . '</th></tr>';
    showtablefooter();
    
    tomshownavheader();
    tomshownavli($Lang['cache_truncate'],$modBaseUrl.'&act=truncate&formhash='.FORMHASH,false);
    tomshownavfooter();
    
    $cacheList = C::t('#tom_tc114#tom_tc114_cache')->fetch_all_list(" ","ORDER BY id ASC",0,1000);
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return ok1_form();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />';
    showtableheader();
    echo '<tr class="header">';
    echo '<th>-</th>';
    echo '<th>' . $Lang['cache_site_id'] . '</th>';
    echo '<th>' . $Lang['cache_cate_id'] . '</th>';
    echo '<th>' . $Lang['cache_user_id'] . '</th>';
    echo '<th>' . $Lang['cache_title'] . '</th>';
    echo '<th>' . $Lang['cache_tel'] . '</th>';
    echo '<th>' . $Lang['cache_address'] . '</th>';
    echo '<th style="max-width:200px;">' . $Lang['cache_content'] . '</th>';
    echo '<th>' . $Lang['cache_area'] . '</th>';
    echo '<th>' . $Lang['cache_longitude'] . '</th>';
    echo '<th>' . $Lang['cache_latitude'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($cacheList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $cateInfo = C::t('#tom_tc114#tom_tc114_cate')->fetch_by_id($value['cate_id']);
        $cateChildInfo = C::t('#tom_tc114#tom_tc114_cate')->fetch_by_id($value['cate_child_id']);
        $cityInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['city_id']);
        $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
        
        echo '<tr>';
        echo '<td><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" ></td>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $cateInfo['name'] .'<font color="#fd0d0d">>></font>'. $cateChildInfo['name'] . '&nbsp;</td>';
        echo '<td>' . $userInfo['nickname'] .'(UID:' .$userInfo['id']. ')&nbsp;</td>';
        echo '<td>' . $value['title'] . '&nbsp;</td>';
        echo '<td>' . $value['tel'] . '&nbsp;</td>';
        echo '<td>' . $value['address'] . '&nbsp;</td>';
        echo '<td style="max-width:200px;">' . $value['content'] . '&nbsp;</td>';
        echo '<td>' . $cityInfo['name'] . '&nbsp;' . $areaInfo['name'] . '&nbsp;' . $streetInfo['name'] . '&nbsp;</td>';
        echo '<td>' . $value['longitude'] . '&nbsp;</td>';
        echo '<td>' . $value['latitude'] . '&nbsp;</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    $formstr = <<<EOF
        <tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="">{$Lang['batch_cache_no']}</option>
                    <option value="batch_import">{$Lang['batch_cache_import']}</option>
                    <option value="batch_del">{$Lang['batch_cache_del']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>
        <script type="text/javascript">
        function ok1_form(){
          var r = confirm("{$Lang['batch_cache_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        </script>
EOF;
    echo $formstr;
    showformfooter();
    
}

function fgetcsv_reg(& $handle, $length = null, $d = ',', $e = '"') {
    $d = preg_quote($d);
    $e = preg_quote($e);
    $_line = "";
    $eof=false;
    while ($eof != true) {
    $_line .= (empty ($length) ? fgets($handle) : fgets($handle, $length));
    $itemcnt = preg_match_all('/' . $e . '/', $_line, $dummy);
    if ($itemcnt % 2 == 0)
    $eof = true;
    }
    $_csv_line = preg_replace('/(?: |[ ])?$/', $d, trim($_line));
    $_csv_pattern = '/(' . $e . '[^' . $e . ']*(?:' . $e . $e . '[^' . $e . ']*)*' . $e . '|[^' . $d . ']*)' . $d . '/';
    preg_match_all($_csv_pattern, $_csv_line, $_csv_matches);
    $_csv_data = $_csv_matches[1];
    for ($_csv_i = 0; $_csv_i < count($_csv_data); $_csv_i++) {
    $_csv_data[$_csv_i] = preg_replace('/^' . $e . '(.*)' . $e . '$/s', '$1', $_csv_data[$_csv_i]);
    $_csv_data[$_csv_i] = str_replace($e . $e, $e, $_csv_data[$_csv_i]);
    }
    return empty ($_line) ? false : $_csv_data;
}