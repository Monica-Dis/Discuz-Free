<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=tag';
$modListUrl = $adminListUrl.'&tmod=tag';
$modFromUrl = $adminFromUrl.'&tmod=tag';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tc114#tom_tc114_tag')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $tagInfo = C::t('#tom_tc114#tom_tc114_tag')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($tagInfo);
        C::t('#tom_tc114#tom_tc114_tag')->update($tagInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($tagInfo);
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
}else if($_GET['act'] == 'add_child_tag'){
    $tagInfo = C::t('#tom_tc114#tom_tc114_tag')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['pid'] = $tagInfo['id'];
        C::t('#tom_tc114#tom_tc114_tag')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add_child_tag&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
}else if($_GET['act'] == 'edit_child_tag'){
    $tagInfo = C::t('#tom_tc114#tom_tc114_tag')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($tagInfo);
        C::t('#tom_tc114#tom_tc114_tag')->update($tagInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit_child_tag&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($tagInfo);
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'import'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tc114/config/import.data.php';
    
    foreach ($tagArr as $key => $value){
        $insertData = array();
        $insertData['name']     = $value['name'];
        $insertData['tsort']    = $key;
        C::t('#tom_tc114#tom_tc114_tag')->insert($insertData);
        
        $parent_id = C::t('#tom_tc114#tom_tc114_tag')->insert_id();
        
        foreach ($value['childs'] as $k1 => $v1){
            $insertData = array();
            $insertData['pid']     = $parent_id;
            $insertData['is_cy']   = $v1['is_cy'];
            $insertData['name']    = $v1['name'];
            $insertData['picurl']  = $v1['picurl'];
            $insertData['tsort']   = $k1;
            C::t('#tom_tc114#tom_tc114_tag')->insert($insertData);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tc114#tom_tc114_tag')->delete_by_id($_GET['id']);
    C::t('#tom_tc114#tom_tc114_tag')->delete_by_pid($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['tag_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=import&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['tag_import'].'</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter();
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $tagList = C::t('#tom_tc114#tom_tc114_tag')->fetch_all_list(" AND pid = 0 "," ORDER BY tsort ASC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>ID</th>';
    echo '<th>' . $Lang['tag_name'] . '</th>';
    //echo '<th>' . $Lang['tag_is_cy'] . '</th>';
    echo '<th> ' . $Lang['tag_tsort'] . ' </th>';
    //echo '<th>' . $Lang['tag_child_tsort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tagList as $key => $value) {
        
        //$childCataList = C::t('#tom_tc114#tom_tc114_tag')->fetch_all_list(" AND pid = {$value['id']} "," ORDER BY tsort ASC,id DESC ", 0, 1000);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['tsort'] . '</td>';
        echo '<td>';
        //echo '<a href="'.$modBaseUrl.'&act=add_child_tag&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['tag_add_child']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['tag_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        /*foreach($childCataList as $k => $v){
            echo '<tr>';
            echo '<td></td>';
            echo '<td><img src="source/plugin/tom_tc114/images/cates_admin_ico.png">' . $v['name'] . '<img width="40" src="'.tomgetfileurl($v['picurl']).'"></td>';
            if($v['is_cy'] == 1){
                echo '<td><font color="#238206">' . $Lang['tag_is_cy_1'] . '</font></td>';
            }else{
                echo '<td><font color="#8e8e8e">' . $Lang['tag_is_cy_0'] . '</font></td>';
            }
            echo '<td>' . $v['tsort'] . '</td>';
            echo '<td>';
            echo '<a href="'.$modBaseUrl.'&act=edit_child_tag&id='.$v['id'].'&formhash='.FORMHASH.'">' . $Lang['tag_edit_child']. '</a>&nbsp;|&nbsp;';
            echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$v['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
            echo '</td>';
            echo '</tr>';
        }*/
        
        $i++;
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function import_confirm(url){
  var r = confirm("{$Lang['makesure_import_msg2']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $is_cy       = isset($_GET['is_cy'])? intval($_GET['is_cy']):10;
    $name        = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tsort       = isset($_GET['tsort'])? intval($_GET['tsort']):10;

    $picurl = "";
    if($_GET['act'] == 'add_child_tag'){
        $picurl         = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit_child_tag'){
        $picurl         = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    //$data['is_cy']              = $is_cy;
    $data['name']               = $name;
    //$data['picurl']             = $picurl;
    $data['tsort']              = $tsort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'is_cy'          => 0,
        'name'           => '',
        'picurl'         => '',
        'tsort'          => 10,
    );
    $options = array_merge($options, $infoArr);
    
    if($_GET['act'] == 'add_child_tag' || $_GET['act'] == 'edit_child_tag'){
        $is_cy_item = array(0=>$Lang['tag_is_cy_0'],1=>$Lang['tag_is_cy_1']);
        //tomshowsetting(true,array('title'=>$Lang['tag_is_cy'],'name'=>'is_cy','value'=>$options['is_cy'],'msg'=>$Lang['tag_is_cy_msg'],'item'=>$is_cy_item),"radio");
    }
    tomshowsetting(true,array('title'=>$Lang['tag_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['tag_name_msg']),"input");
    if($_GET['act'] == 'add_child_tag' || $_GET['act'] == 'edit_child_tag'){
        //tomshowsetting(true,array('title'=>$Lang['tag_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['tag_picurl_msg']),"file");
    }
    tomshowsetting(true,array('title'=>$Lang['tag_tsort'],'name'=>'tsort','value'=>$options['tsort'],'msg'=>$Lang['tag_tsort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['tag_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['tag_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['tag_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['tag_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['tag_edit'],"",true);
    }else if($_GET['act'] == 'add_child_tag'){
        tomshownavli($Lang['tag_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['tag_add_child'],"",true);
    }else if($_GET['act'] == 'edit_child_tag'){
        tomshownavli($Lang['tag_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['tag_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['tag_edit_child'],"",true);
    }else{
        tomshownavli($Lang['tag_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['tag_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}