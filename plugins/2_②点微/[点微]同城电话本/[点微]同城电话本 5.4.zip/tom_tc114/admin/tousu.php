<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=tousu';
$modListUrl = $adminListUrl.'&tmod=tousu';
$modFromUrl = $adminFromUrl.'&tmod=tousu';

if($_GET['act'] == 'add'){

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tc114#tom_tc114_tousu')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $tousuList = C::t('#tom_tc114#tom_tc114_tousu')->fetch_all_list(" "," ORDER BY add_time DESC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['tousu_tc114_id'] . '</th>';
    echo '<th>' . $Lang['tousu_user'] .'</th>';
    echo '<th>' . $Lang['tousu_tel'] . '</th>';
    echo '<th width="35%">' . $Lang['tousu_content'] . '</th>';
    echo '<th>' . $Lang['tousu_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tousuList as $key => $value) {
        
        $tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($value['tc114_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);

        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a href="'.$adminBaseUrl.'&tmod=index&tc114_id='.$value['tc114_id'].'">' . $tc114Info['title'] . '</a></td>';
        echo '<td>' . $userInfo['nickname'] .'(' .$value['user_id']. ')</td>';
        echo '<td>' . $value['tel'] . '</td>';
        echo '<td>' . $value['content'] . '</td>';
        echo '<td>' . dgmdate($value['add_time'], "Y-m-d H:i", $tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    
    tomshownavli($Lang['tousu_list_title'],$modBaseUrl,true);
    
    tomshownavfooter();
}