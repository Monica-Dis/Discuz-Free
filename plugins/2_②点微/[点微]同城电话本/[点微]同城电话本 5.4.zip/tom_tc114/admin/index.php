<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_tc114_admin_index_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tc114#tom_tc114')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
        
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $goodsInfo = C::t('#tom_tc114#tom_tc114')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($goodsInfo);
        C::t('#tom_tc114#tom_tc114')->update($goodsInfo['id'],$updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($goodsInfo);
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status']     = 1;
    C::t('#tom_tc114#tom_tc114')->update($_GET['id'],$updateData);
    
    $tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tc114Info['user_id']);

    $shenhe = str_replace('{TITLE}', $tc114Info['title'], $Lang['template_tc114_shenhe_ok']);

    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tc114&site={$tc114Info['site_id']}&mod=info&tc114_id=".$tc114Info['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tc114Config['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['tc114_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['tc114_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tc114Config['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tc114Info['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tc114#tom_tc114')->update($_GET['id'],$updateData);
        
        $shenhe = str_replace('{TITLE}', $tc114Info['title'], $Lang['template_tc114_shenhe_no']);
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tc114&site={$tc114Info['site_id']}&mod=edit&tc114_id=".$tc114Info['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tc114Config['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tc114_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tc114_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tc114Config['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tc114_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tc114_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tc114_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tc114#tom_tc114')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status']     = 2;
    C::t('#tom_tc114#tom_tc114')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tc114#tom_tc114')->delete_by_id($_GET['id']);
    C::t('#tom_tc114#tom_tc114_photo')->delete_by_tc114_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'photo'){
    
    $tc114_id = $_GET['tc114_id'];

    if(submitcheck('submit')){
        
        if($_FILES["picurl"]['tmp_name']) {
            $upload = new tom_upload();
            if(!$upload->init($_FILES["picurl"], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }

            $picurl = $upload->attach['attachment'];
        }else{
            $picurl = addslashes($_GET["picurl"]);
        }
        
        $insertData = array();
        $insertData['tc114_id']     = $tc114_id;
        $insertData['picurl']       = $picurl;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tc114#tom_tc114_photo')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl."&act=photo&tc114_id=".$_GET['tc114_id'], 'succeed');
    }
    
    $goodsInfo = C::t('#tom_tc114#tom_tc114')->fetch_by_id($_GET['tc114_id']);
    
    $photoList = C::t('#tom_tc114#tom_tc114_photo')->fetch_all_list(" AND tc114_id={$tc114_id} ","ORDER BY id ASC",0,100);
    __create_nav_html();
    showformheader($modFromUrl.'&act=photo&tc114_id='.$tc114_id,'enctype');
    showtableheader();
    tomshowsetting(true,array('title'=>$Lang['index_photo_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['index_photo_picurl_msg']),"file");
    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['index_photo_picurl'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($photoList as $key => $value) {
        echo '<tr>';
        echo '<td><img src="' . tomgetfileurl($value['picurl']) . '" width="60" /></td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&tc114_id='.$tc114_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tc114#tom_tc114_photo')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl."&act=photo&tc114_id=".$_GET['tc114_id'], 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'pay'){
    
    $pay_status     = isset($_GET['pay_status'])? intval($_GET['pay_status']):1;
    
    $updateData = array();
    $updateData['pay_status']     = $pay_status;
    C::t('#tom_tc114#tom_tc114')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'changyong'){
    
    $changyong_status     = isset($_GET['changyong_status'])? intval($_GET['changyong_status']):0;
    
    $updateData = array();
    $updateData['changyong_status']     = $changyong_status;
    C::t('#tom_tc114#tom_tc114')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editbase'){
    $info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $base_level    = isset($_GET['base_level'])? intval($_GET['base_level']):1;
        $base_time     = isset($_GET['base_time'])? addslashes($_GET['base_time']):'';
        $base_time     = strtotime($base_time);
        $updateData = array();
        if($base_level == 1){
            $updateData['base_level'] = 1;
            $updateData['base_time'] = 0;
        }else if($base_level == 2){
            $updateData['base_level'] = 2;
            $updateData['base_time'] = $base_time;
        }else{
            $updateData['status'] = 3;
            $updateData['base_level'] = 2;
            $updateData['base_time'] = TIMESTAMP;
        }
        C::t('#tom_tc114#tom_tc114')->update($_GET['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editbase&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_base_title'] .'</th></tr>';
        $base_level_item = array(1=>$Lang['edit_base_level_1'],2=>$Lang['edit_base_level_2'],3=>$Lang['edit_base_level_3']);
        tomshowsetting(true,array('title'=>$Lang['edit_base_level'],'name'=>'base_level','value'=>$info['base_level'],'msg'=>$Lang['edit_base_level_msg'],'item'=>$base_level_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['edit_base_time'],'name'=>'base_time','value'=>$info['base_time'],'msg'=>$Lang['edit_base_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
    
}else{
    
    set_list_url("tom_tc114_admin_index_list");
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ list-style-type: none; height: 25px; line-height: 25px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;padding: 3px 10px;color: #6a6d6a; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
</style>
EOF;
    echo $csstr;
    
    $search             = intval($_GET['search'])>0? intval($_GET['search']):0;
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $keyword            = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
    $tc114_id           = isset($_GET['tc114_id'])? intval($_GET['tc114_id']):0;
    $tag_id             = isset($_GET['tag_id'])? intval($_GET['tag_id']):0;
    $tag_child_id       = isset($_GET['tag_child_id'])? intval($_GET['tag_child_id']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $sort_type          = intval($_GET['sort_type'])>0? intval($_GET['sort_type']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($tc114_id)){
        $where.= " AND id={$tc114_id} ";
    }
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($tag_id)){
        $where.= " AND tag_id={$tag_id} ";
    }
    if(!empty($tag_child_id)){
        $where.= " AND tag_child_id={$tag_child_id} ";
    }
    if(!empty($cate_id)){
        $where.= " AND cate_id={$cate_id} ";
    }
    if(!empty($cate_child_id)){
        $where.= " AND cate_child_id={$cate_child_id} ";
    }
    if(!empty($status)){
        if($status == 1){
            $where.= " AND status=1 ";
        }else if($status == 2){
            $where.= " AND status != 1 ";
        }
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    
    $order = "ORDER BY add_time DESC,id DESC";
    if($sort_type == 1){
        $order = 'ORDER BY changyong_status DESC, sort ASC,id DESC';
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_tc114#tom_tc114')->fetch_all_count("{$where}",$keyword);
    $tc114List  = C::t('#tom_tc114#tom_tc114')->fetch_all_list("{$where}",$order,$start,$pagesize,$keyword);

    showtableheader();
    $Lang['index_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_1']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();

    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&status={$status}&shenhe_status={$shenhe_status}&keyword={$keyword}&tag_id={$tag_id}&tag_child_id={$tag_child_id}&cate_id={$cate_id}&cate_child_id={$cate_child_id}&sort_type={$sort_type}&search={$search}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    $site_1 = '';
    if($site_id == 1){
        $site_1 = 'selected';
    }
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '(<a href="'.$modBaseUrl.'&search=1"><font color="#F90B0B">' . $Lang['index_gaoji_search'] . '</font></a>)</th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    echo '<input type="hidden" name="search" value="'.$search.'">';
    $keywordStr = '<tr><td width="100" align="right"><b>'.$Lang['index_search_keyword'].'</b></td>';
    $keywordStr.= '<td><input style="width:260px" type="text" value="'.$keyword.'" name="keyword"></td></tr>';
    echo $keywordStr;
        
    if($search == 1){
        $tagList = C::t('#tom_tc114#tom_tc114_tag')->fetch_all_list(" AND pid = 0 "," ORDER BY tsort ASC,id DESC ",0,200);
        $tagStr = '<tr><td width="100" align="right"><b>'.$Lang['index_search_tag'].'</b></td>';
        $tagStr.= '<td ><select style="width: 260px;" name="tag_id" id="tag_id">';
        $tagStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
        foreach ($tagList as $key => $value){
            if($tag_id == $value['id']){
                $tagStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $tagStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $tagStr.= '</select></td></tr>';
        echo $tagStr;
    
        $cateList   = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(" AND pid = 0 "," ORDER BY csort ASC,id DESC ",0,200);
        $cateStr = '<tr><td width="100" align="right"><b>'.$Lang['index_search_cate'].'</b></td>';
        $cateStr.= '<td ><select style="width: 100px;" name="cate_id" id="cate_id" onchange="getChild();">';
        $cateStr.=  '<option value="0">'.$Lang['index_search_all'].'</option>';
        foreach ($cateList as $key => $value){
            if($cate_id == $value['id']){
                $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $cateStr.= '</select>&nbsp;&nbsp;';

        $cateStr.= '<select style="width:100px;" name="cate_child_id" id="cate_child_id">';
        $cateStr.=  '<option value="0">'.$Lang['index_cate_child_id'].'</option>';
        if($cate_id > 0){
            $cateChildList = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(" AND pid = {$cate_id} "," ORDER BY csort ASC,id DESC ",0,200);
            foreach ($cateChildList as $key => $value){
                if($cate_child_id == $value['id']){
                    $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
                }else{
                    $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                }
            }
        }
        $cateStr.= '</select></td></tr>';
        echo $cateStr;
    }
    
    if($search == 1){
        $status_1 = $status_2 = '';
        if($status == 1){
            $status_1 = 'selected';
        }else if($status == 2){
            $status_2 = 'selected';
        }
        $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_status'].'</b></td>';
        $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
        $statusStr.=  '<option value="0">'.$Lang['index_status'].'</option>';
        $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['index_status_1'].'</option>';
        $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['index_status_2'].'</option>';
        $statusStr.= '</select></td></tr>';
        echo $statusStr;
    }
    
    $status_shenhe_1 = $status_shenhe_2 = $status_shenhe_3 = '';
    if($shenhe_status == 1){
        $status_shenhe_1 = 'selected';
    }else if($shenhe_status == 2){
        $status_shenhe_2 = 'selected';
    }else if($shenhe_status == 3){
        $status_shenhe_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['index_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$status_shenhe_1.'>'.$Lang['index_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$status_shenhe_2.'>'.$Lang['index_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$status_shenhe_3.'>'.$Lang['index_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    if($search == 1){
        $sort_type_1 = $sort_type_2 = '';
        if($sort_type == 1){
            $sort_type_1 = 'selected';
        }
        if($sort_type == 2){
            $sort_type_2 = 'selected';
        }
        $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_sort_type'].'</b></td>';
        $statusStr.= '<td><select style="width: 260px;" name="sort_type" id="sort_type">';
        $statusStr.=  '<option value="0">'.$Lang['index_sort_type_0'].'</option>';
        $statusStr.=  '<option value="1" '.$sort_type_1.'>'.$Lang['index_sort_type_1'].'</option>';
        $statusStr.=  '<option value="2" '.$sort_type_2.'>'.$Lang['index_sort_type_2'].'</option>';
        $statusStr.= '</select></td></tr>';
        echo $statusStr;
    }
    
    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 60px;">' . $Lang['sites_title'] . '</th>';
    echo '<th style="width: 60px;">' . $Lang['index_picurl'] . '</th>';
    if($tc114Config['open_upload_qrcode'] == 1){
        echo '<th style="width: 150px;">' . $Lang['index_wx_picurl'] . '</th>';
    }
    echo '<th style="width: 40%;">' . $Lang['index_info'] . '</th>';
    echo '<th>' . $Lang['index_status2'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tc114List as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $cateInfo = C::t('#tom_tc114#tom_tc114_cate')->fetch_by_id($value['cate_id']);
        $cateChildInfo = C::t('#tom_tc114#tom_tc114_cate')->fetch_by_id($value['cate_child_id']);
        $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
        $tagInfo = C::t('#tom_tc114#tom_tc114_tag')->fetch_by_id($value['tag_id']);
        $tagChildInfo = C::t('#tom_tc114#tom_tc114_tag')->fetch_by_id($value['tag_child_id']);
        
        echo '<tr style="border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #70b4e6;">';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td><img src="'.tomgetfileurl($value['picurl']).'" width="40" /></td>';
        if($tc114Config['open_upload_qrcode'] == 1){
            echo '<td><img src="'.tomgetfileurl($value['qrcode']).'" width="40" /></td>';
        }
        
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['index_user'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $userInfo['nickname'] .'(UID:' .$userInfo['id']. ')</font></li>';
        echo '<li><b>'.$Lang['index_cate_id'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $cateInfo['name'] .'--'. $cateChildInfo['name'] . '</font></li>';
        if($value['area_id'] > 0){
            echo '<li><b>'.$Lang['index_area'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $areaInfo['name'] .'--'. $streetInfo['name'] .'</font></li>';
        }
        if($value['tag_id'] > 0){
            echo '<li><b>'.$Lang['index_tag_id'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $tagInfo['name'] .'</font></li>';
        }
        echo '<li><b>'.$Lang['index_title'].'&nbsp;:&nbsp;</b>' . $value['title'] . '</li>';
        echo '<li><b>'.$Lang['index_xm'].'&nbsp;:&nbsp;</b>' . $value['xm'] . '</li>';
        echo '<li><b>'.$Lang['index_tel'].'&nbsp;:&nbsp;</b>' . $value['tel'] . '</li>';
        echo '<li><b>'.$Lang['index_tel'].'2&nbsp;:&nbsp;</b>' . $value['tel2'] . '</li>';
        echo '<li><b>'.$Lang['index_job'].'&nbsp;:&nbsp;</b>' . $value['job'] . '</li>';
        echo '<li><b>'.$Lang['index_address'].'&nbsp;:&nbsp;</b>' . $value['address'] . '</li>';
        echo '</ul></div></td>';
        
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['paixu'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $value['sort'] .'</font></li>';
        $changyongBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=changyong&changyong_status=1&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_changyong_btn_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=changyong&changyong_status=0&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_changyong_btn_0']. '</a>)';
        if($value['changyong_status'] == 1 ){
            echo '<li><b>'.$Lang['index_changyong_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['index_changyong_status_1'] . '</font>'.$changyongBtnStr.'</li>';
        }else{
            echo '<li><b>'.$Lang['index_changyong_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['index_changyong_status_0'] . '</font>'.$changyongBtnStr.'</li>';
        }
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shenhe_btn_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shenhe_btn_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<li><b>'.$Lang['index_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['index_shenhe_status_1'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 2){
            echo '<li><b>'.$Lang['index_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['index_shenhe_status_2'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 3){
            echo '<li><b>'.$Lang['index_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['index_shenhe_status_3'] . '</font>'.$sheheBtnStr.'</li>';
        }
        $payBtnStr = '&nbsp;(&nbsp;<a href="javascript:;" onclick="pay_confirm(\''.$modBaseUrl.'&act=pay&id='.$value['id'].'&pay_status=1&formhash='.FORMHASH.'\', \''.$Lang['index_pay_status_1_msg'].'\');">' . $Lang['index_pay_status_1']. '</a>&nbsp;|&nbsp;<a href="javascript:;" onclick="pay_confirm(\''.$modBaseUrl.'&act=pay&id='.$value['id'].'&pay_status=2&formhash='.FORMHASH.'\', \''.$Lang['index_pay_status_2_msg'].'\');">' . $Lang['index_pay_status_2']. '</a>)';
        if($value['pay_status'] == 1){
            echo '<li><b>'.$Lang['index_pay_status'].'&nbsp;:&nbsp;</b><font color="#f00">' . $Lang['index_pay_status_1'] . $payBtnStr . '</font></li>';
        }else if($value['pay_status'] == 2){
            echo '<li><b>'.$Lang['index_pay_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['index_pay_status_2'] . $payBtnStr . '</font></li>';
        }
        if($value['status'] == 1){
            echo '<li><b>'.$Lang['index_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['index_status_1'] . '</font></li>';
        }else{
            echo '<li><b>'.$Lang['index_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['index_status_2'] . '</font></li>';
        }
        echo '<li>';
        echo '<b>'.$Lang['index_base_time'].'&nbsp;:&nbsp;</b>&nbsp;&nbsp;';
        if($value['base_level'] == 1){
            echo '<font color="#f00">(' . $Lang['index_yongjiu_time'] . ')</font>';
        }else if($value['base_level'] == 2){
            echo '<font color="#f00">(' . dgmdate($value['base_time'],"Y-m-d",$tomSysOffset) . '&nbsp;' . $Lang['index_old_time'] . ')</font>';
        }
        echo '</li>';
        echo '</ul></div></td>';

        echo '<td><div class="tc_content_box_handle"><ul>';
        echo '<li><a href="'.$modBaseUrl.'&act=editbase&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_base_title']. '</a></li>';
        if($value['status'] == 1 ){
            echo '<li><a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_status_2']. '</a></li>';
        }else{
            echo '<li><a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_status_1']. '</a></li>';
        }
        echo '<li><a href="'.$modBaseUrl.'&act=photo&tc114_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_photo']. '</a></li>';
        echo '<li><a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_edit']. '</a></li>';
        echo '<li><a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a></li>';
        echo '</ul></div></td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
  
function pay_confirm(url,msg){
  var r = confirm(msg)
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}

function getChild(){
  var cate_id = jq("#cate_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tc114:ajax",
        data: "act=childcates&pid="+cate_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var cateChildHtml = '<option value="0">{$Lang['index_cate_child_id']}</option>';
            jq.each(json,function(k,v){
                cateChildHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#cate_child_id").html(cateChildHtml);
            jq("#cate_child_id").show();
        }
    });
}

function getTagChild(){
  var tag_id = jq("#tag_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tc114:ajax",
        data: "act=childtags&pid="+tag_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var cateChildHtml = '<option value="0">{$Lang['index_tag_child_id']}</option>';
            jq.each(json,function(k,v){
                cateChildHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#tag_child_id").html(cateChildHtml);
            jq("#tag_child_id").show();
        }
    });
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    global $tc114Config,$tongchengConfig;
    $data = array();
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $tag_id             = isset($_GET['tag_id'])? intval($_GET['tag_id']):0;
    $tag_child_id       = isset($_GET['tag_child_id'])? intval($_GET['tag_child_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $xm                 = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel2               = isset($_GET['tel2'])? addslashes($_GET['tel2']):'';
    $job                = isset($_GET['job'])? addslashes($_GET['job']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $virtual_clicks     = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    //$virtual_shares     = isset($_GET['virtual_shares'])? intval($_GET['virtual_shares']):0;
    $sort               = isset($_GET['sort'])? intval($_GET['sort']):10000;
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        $city_id = $sitesInfoTmp['city_id'];
    }else{
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
            $city_id = $cityInfoTmp['id'];
        }
    }

    $picurl = $qrcode = "";
    if($_GET['act'] == 'add'){
        $picurl         = tomuploadFile("picurl");
        $qrcode         = tomuploadFile("qrcode");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
        $qrcode        = tomuploadFile("qrcode",$infoArr['qrcode']);
    }
    
    if(empty($picurl)){
        $picurl = $tc114Config['default_picurl'];
    }
    
    $data['site_id']            = $site_id;
    $data['cate_id']            = $cate_id;
    $data['cate_child_id']      = $cate_child_id;
    $data['city_id']            = $city_id;
    $data['area_id']            = $area_id;
    $data['street_id']          = $street_id;
    $data['tag_id']             = $tag_id;
    $data['tag_child_id']       = $tag_child_id;
    $data['user_id']            = $user_id;
    $data['title']              = $title;
    $data['xm']                 = $xm;
    $data['tel']                = $tel;
    $data['tel2']               = $tel2;
    $data['job']                = $job;
    $data['content']            = $content.'|+|+|+|+|+|+|+|+|+|'.$title.'-'.$tel.'-'.$tel2;
    $data['longitude']          = $longitude;
    $data['latitude']           = $latitude;
    $data['address']            = $address;
    $data['picurl']             = $picurl;
    $data['qrcode']             = $qrcode;
    $data['virtual_clicks']     = $virtual_clicks;
    //$data['virtual_shares']     = $virtual_shares;
    $data['sort']               = $sort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$tongchengConfig;
    $options = array(
        'site_id'           => 1,
        'cate_id'           => 0,
        'cate_child_id'     => 0,
        'city_id'           => 0,
        'area_id'           => 0,
        'street_id'         => 0,
        'tag_id'            => 0,
        'tag_child_id'      => 0,
        'user_id'           => 0,
        'title'             => '',
        'picurl'            => '',
        'qrcode'            => '',
        'xm'                => '',
        'tel'               => '',
        'tel2'              => '',
        'job'               => '',
        'content'           => '',
        'longitude'         => '',
        'latitude'          => '',
        'address'           => '',
        'virtual_clicks'    => '',
        'virtual_shares'    => '',
        'sort'              => 999999,
    );
    $options = array_merge($options, $infoArr);
    
    $options['content'] = contentFormat($options['content']);
    
    tomshowsetting(true,array('title'=>$Lang['index_site_id'],'name'=>'site_id','value'=>$options['site_id'],'msg'=>$Lang['index_site_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['index_user_id_msg']),"input");

    $cateList = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,100);
    $catesStr = '<tr class="header"><th>'.$Lang['index_cate_id'].'</th><th></th></tr>';
    $catesStr.= '<tr><td width="300"><select style="width: 150px;" name="cate_id" id="cate_id" onchange="getChild();">';
    $catesStr.=  '<option value="0">'.$Lang['index_cate_id'].'</option>';
    foreach ($cateList as $key => $value){
        if($value['id'] == $options['cate_id']){
            $catesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $catesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $catesStr.= '</select>&nbsp;&nbsp;<select style="width: 150px;" name="cate_child_id" id="cate_child_id">';
    $catesStr.=  '<option value="0">'.$Lang['index_cate_child_id'].'</option>';
    if($options['cate_id'] > 0){
        $childCateList = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(" AND pid={$options['cate_id']} "," ORDER BY csort ASC,id DESC ",0,50);
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $key => $value) {
                if($value['id'] == $options['cate_child_id']){
                    $catesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
                }else{
                    $catesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                }
            }
        }
    }
    $catesStr.= '</select></td><td>'.$Lang['index_cate_child_id_msg'].'</td></tr>';
    echo $catesStr;
    
    if($_GET['act'] == 'edit'){
        $city_id_tmp = 0;
        if($options['site_id'] > 1){
            $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($options['site_id']);
            $city_id_tmp = $sitesInfoTmp['city_id'];
        }else{
            if(!empty($tongchengConfig['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
                $city_id_tmp = $cityInfoTmp['id'];
            }
        }
        $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($city_id_tmp);
        $cityStr = '<tr class="header"><th>'.$Lang['index_area'].'</th><th></th></tr>';
        $cityStr.= '<tr><td width="300"><select style="width: 150px;" name="area_id" id="area_id" onchange="getStreet();">';
        $cityStr.=  '<option value="0">'.$Lang['index_area_id'].'</option>';
        foreach ($areaList as $key => $value){
            if($value['id'] == $options['area_id']){
                $cityStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $cityStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $cityStr.= '</select>&nbsp;&nbsp;<select style="width: 150px;" name="street_id" id="street_id">';
        $cityStr.=  '<option value="0">'.$Lang['index_street_id'].'</option>';
        if($options['area_id'] > 0){
            $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($options['area_id']);
            if(is_array($streetListTmp) && !empty($streetListTmp)){
                foreach ($streetListTmp as $key => $value) {
                    if($value['id'] == $options['street_id']){
                        $cityStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
                    }else{
                        $cityStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                    }
                }
            }
        }
        $cityStr.= '</select></td><td>'.$Lang['index_street_id_msg'].'</td></tr>';
        echo $cityStr;
    }
    
    
    $tagList = C::t('#tom_tc114#tom_tc114_tag')->fetch_all_list(" AND pid=0 "," ORDER BY tsort ASC,id DESC ",0,100);
    $tagsStr = '<tr class="header"><th>'.$Lang['index_tag_id'].'</th><th></th></tr>';
    $tagsStr.= '<tr><td width="300"><select style="width: 150px;" name="tag_id" id="tag_id">';
    $tagsStr.=  '<option value="0">'.$Lang['index_tag_id'].'</option>';
    foreach ($tagList as $key => $value){
        if($value['id'] == $options['tag_id']){
            $tagsStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $tagsStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $tagsStr.= '</select>';
    $tagsStr.= '</td><td>'.$Lang['index_tag_id_msg'].'</td></tr>';
    echo $tagsStr;
    
    tomshowsetting(true,array('title'=>$Lang['index_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['index_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['index_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_wx_picurl'],'name'=>'qrcode','value'=>$options['qrcode'],'msg'=>$Lang['index_wx_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_xm'],'name'=>'xm','value'=>$options['xm'],'msg'=>$Lang['index_xm_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_tel'],'name'=>'tel','value'=>$options['tel'],'msg'=>$Lang['index_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_tel'].'2','name'=>'tel2','value'=>$options['tel2'],'msg'=>$Lang['index_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_job'],'name'=>'job','value'=>$options['job'],'msg'=>$Lang['index_job_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_latitude'],'name'=>'latitude','value'=>$options['latitude'],'msg'=>$Lang['index_latitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_longitude'],'name'=>'longitude','value'=>$options['longitude'],'msg'=>$Lang['index_longitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['index_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['index_content_msg']),"textarea");
    tomshowsetting(true,array('title'=>$Lang['index_virtual_clicks'],'name'=>'virtual_clicks','value'=>$options['virtual_clicks'],'msg'=>$Lang['index_virtual_clicks_msg']),"input");
    //tomshowsetting(true,array('title'=>$Lang['index_virtual_shares'],'name'=>'virtual_shares','value'=>$options['virtual_shares'],'msg'=>$Lang['index_virtual_shares_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['paixu'],'name'=>'sort','value'=>$options['sort'],'msg'=>''),"input");
    
    $jsstr = <<<EOF
<script type="text/javascript">
function getChild(){
  var cate_id = jq("#cate_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tc114:ajax",
        data: "act=childcates&pid="+cate_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var cateChildHtml = '<option value="0">{$Lang['index_cate_child_id']}</option>';
            jq.each(json,function(k,v){
                cateChildHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#cate_child_id").html(cateChildHtml);
            jq("#cate_child_id").show();
        }
    });
}

function getStreet(){
  var area_id = jq("#area_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tc114:ajax",
        data: "act=getstreet&area_id="+area_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var streetHtml = '<option value="0">{$Lang['index_street_id']}</option>';
            jq.each(json,function(k,v){
                streetHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#street_id").html(streetHtml);
            jq("#street_id").show();
        }
    });
}
</script>
EOF;
    echo $jsstr;
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['index_edit'],"",true);
    }else if($_GET['act'] == 'photo'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_photo'],"",true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['cache_list_title'],$adminBaseUrl."&tmod=cache",false);
    }
    tomshownavfooter();
}