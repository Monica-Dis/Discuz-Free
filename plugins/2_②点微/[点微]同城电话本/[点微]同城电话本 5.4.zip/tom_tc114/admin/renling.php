<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=renling';
$modListUrl = $adminListUrl.'&tmod=renling';
$modFromUrl = $adminFromUrl.'&tmod=renling';

if($_GET['act'] == 'add'){

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe'){
    
    $shenhe_status     = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):1;

    $updateData = array();
    $updateData['shenhe_status']     = $shenhe_status;
    if(C::t('#tom_tc114#tom_tc114_renling')->update($_GET['id'],$updateData)){
        if($shenhe_status == 1){
            $renlingInfo = C::t('#tom_tc114#tom_tc114_renling')->fetch_by_id($_GET['id']);
            
            $updateData = array();
            $updateData['base_level']   = 2;
            $updateData['base_time']    = TIMESTAMP + 365*86400;
            $updateData['user_id']      = $renlingInfo['user_id'];
            C::t('#tom_tc114#tom_tc114')->update($renlingInfo['tc114_id'],$updateData);
            
        }
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tc114#tom_tc114_renling')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $renlingList = C::t('#tom_tc114#tom_tc114_renling')->fetch_all_list(" "," ORDER BY add_time DESC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['renling_tc114_id'] . '</th>';
    echo '<th>' . $Lang['renling_user'] .'</th>';
    echo '<th>' . $Lang['renling_tel'] . '</th>';
    echo '<th width="35%">' . $Lang['renling_content'] . '</th>';
    echo '<th>' . $Lang['renling_shenhe_status'] . '</th>';
    echo '<th>' . $Lang['renling_order_status'] . '</th>';
    echo '<th>' . $Lang['renling_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($renlingList as $key => $value) {
        
        $tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($value['tc114_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a href="'.$adminBaseUrl.'&tmod=index&tc114_id='.$value['tc114_id'].'">' . $tc114Info['title'] . '</a></td>';
        echo '<td>' . $userInfo['nickname'] .'(' .$value['user_id']. ')</td>';
        echo '<td>' . $value['tel'] . '</td>';
        echo '<td>' . $value['content'] . '</td>';
        
        echo '<td>';
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="javascript:void(0);" onClick="shenhe_confirm(\''.$modBaseUrl.'&act=shenhe&id='.$value['id'].'&shenhe_status=1&formhash='.FORMHASH.'\');">' . $Lang['renling_shenhe_btn_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe&id='.$value['id'].'&shenhe_status=3&formhash='.FORMHASH.'">' . $Lang['renling_shenhe_btn_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<font color="#0a9409">' . $Lang['renling_shenhe_status_1'] . '</font>'.$sheheBtnStr;
        }else if($value['shenhe_status'] == 2){
            echo '<font color="#f70404">' . $Lang['renling_shenhe_status_2'] . '</font>'.$sheheBtnStr;
        }else if($value['shenhe_status'] == 3){
            echo '<font color="#f70404">' . $Lang['renling_shenhe_status_3'] . '</font>'.$sheheBtnStr;
        }
        echo '</td>';
        
        echo '<td>';
        if($value['order_status'] == 1 ){
            echo '<font color="#f70404">' . $Lang['renling_order_status_1'] . '</font>';
        }else if($value['order_status'] == 2){
            echo '<font color="#0a9409">' . $Lang['renling_order_status_2'] . '</font>';
        }else{
            echo '--';
        }
        echo '</td>';
        
        echo '<td>' . dgmdate($value['add_time'], "Y-m-d H:i", $tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
  
function shenhe_confirm(url){
  var r = confirm("{$Lang['makesure_renling_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    
    tomshownavli($Lang['renling_list_title'],$modBaseUrl,true);
    
    tomshownavfooter();
}