<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=jiucuo';
$modListUrl = $adminListUrl.'&tmod=jiucuo';
$modFromUrl = $adminFromUrl.'&tmod=jiucuo';

if($_GET['act'] == 'add'){

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe'){
    
    $shenhe_status     = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):1;

    $updateData = array();
    $updateData['shenhe_status']     = $shenhe_status;
    C::t('#tom_tc114#tom_tc114_jiucuo')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tc114#tom_tc114_jiucuo')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $jiucuoList = C::t('#tom_tc114#tom_tc114_jiucuo')->fetch_all_list(" "," ORDER BY add_time DESC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['jiucuo_tc114_id'] . '</th>';
    echo '<th>' . $Lang['jiucuo_user'] .'</th>';
    echo '<th>' . $Lang['jiucuo_tel'] . '</th>';
    echo '<th width="35%">' . $Lang['jiucuo_content'] . '</th>';
    echo '<th>' . $Lang['jiucuo_shenhe_status'] . '</th>';
    echo '<th>' . $Lang['jiucuo_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($jiucuoList as $key => $value) {
        
        $tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($value['tc114_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a href="'.$adminBaseUrl.'&tmod=index&tc114_id='.$value['tc114_id'].'">' . $tc114Info['title'] . '</a></td>';
        echo '<td>' . $userInfo['nickname'] .'(' .$value['user_id']. ')</td>';
        echo '<td>' . $value['tel'] . '</td>';
        echo '<td>' . $value['content'] . '</td>';
        
        echo '<td>';
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe&id='.$value['id'].'&shenhe_status=1&formhash='.FORMHASH.'">' . $Lang['jiucuo_shenhe_btn_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe&id='.$value['id'].'&shenhe_status=3&formhash='.FORMHASH.'">' . $Lang['jiucuo_shenhe_btn_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<font color="#f70404">' . $Lang['jiucuo_shenhe_status_1'] . '</font>'.$sheheBtnStr;
        }else if($value['shenhe_status'] == 2){
            echo '<font color="#0a9409">' . $Lang['jiucuo_shenhe_status_2'] . '</font>'.$sheheBtnStr;
        }else if($value['shenhe_status'] == 3){
            echo '<font color="#f70404">' . $Lang['jiucuo_shenhe_status_3'] . '</font>'.$sheheBtnStr;
        }
        echo '</td>';
        
        echo '<td>' . dgmdate($value['add_time'], "Y-m-d H:i", $tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    
    tomshownavli($Lang['jiucuo_list_title'],$modBaseUrl,true);
    
    tomshownavfooter();
}