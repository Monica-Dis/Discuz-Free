<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword        = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$cate_id        = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$cate_child_id  = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
$area_id        = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id      = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$tag_id         = intval($_GET['tag_id'])>0? intval($_GET['tag_id']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$type           = intval($_GET['type'])>0? intval($_GET['type']):0;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):20;

if($tag_id == 888888 || $cate_id == 888888){
    $tag_id = 0;
    $cate_id = 0;
    $type   = 1;
}else if($tag_id == 999999 || $cate_id == 999999){
    $tag_id = 0;
    $cate_id = 0;
    $type   = 2;
}else if($tag_id == 777777 || $cate_id == 777777){
    $tag_id = 0;
    $cate_id = 0;
    $type   = 3;
}

$searchAddress = '';
if($tc114Config['open_ruzhu_area'] == 0){
    if(!empty($street_id)){
        $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
        $searchAddress = $streetInfo['name'];
    }else if(!empty($area_id)){
        $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
        $searchAddress = $areaInfo['name'];
    }
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND status=1 AND shenhe_status=1 ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($cate_id)){
    $cateInfo = C::t("#tom_tc114#tom_tc114_cate")->fetch_by_id($cate_id);
    $whereStr.= " AND cate_id={$cate_id} ";
}
if(!empty($cate_child_id)){
    $whereStr.= " AND cate_child_id={$cate_child_id} ";
}
if($tc114Config['open_ruzhu_area'] == 1){
    if(!empty($area_id)){
        $whereStr.= " AND area_id={$area_id} ";
    }
    if(!empty($street_id)){
        $whereStr.= " AND street_id={$street_id} ";
    }
}

if($tc114Config['changyong_type'] == 1 && $type == 1){
    $whereStr.= " AND changyong_status=1 ";
}

if(!empty($tag_id)){
    $whereStr.= " AND tag_id={$tag_id} ";
}

if($type == 1){
    $orderStr = " ORDER BY changyong_status DESC,sort ASC,id DESC ";
}else if($cate_id > 0){
    $orderStr = " ORDER BY sort ASC,id DESC ";
}else if(!empty($keyword)){
    $orderStr = " ORDER BY changyong_status DESC,sort ASC,id DESC ";
}else{
    $orderStr = " ORDER BY id DESC ";
}

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
if($type == 3 && !empty($longitude) && !empty($latitude)){
    $tc114ListTmp = C::t('#tom_tc114#tom_tc114')->fetch_all_nearby_list($whereStr,$start,$pagesize,$keyword,$searchAddress,$latitude,$longitude);
}else{
    $tc114ListTmp = C::t('#tom_tc114#tom_tc114')->fetch_all_list($whereStr,$orderStr,$start,$pagesize,$keyword,$searchAddress);
}
$tc114List = array();
foreach ($tc114ListTmp as $key => $value) {
    $tc114List[$key] = $value;
    if(!preg_match('/^http/', $value['picurl']) ){
        if(strpos($value['picurl'], 'source/plugin/tom_') === false){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $picurl = $_G['siteurl'].$value['picurl'];
        }
    }else{
        $picurl = $value['picurl'];
    }
    $qrcode = '';
    if(!empty($value['qrcode'])){
        if(!preg_match('/^http/', $value['qrcode']) ){
            if(strpos($value['qrcode'], 'source/plugin/tom_') === false){
                $qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['qrcode'];
            }else{
                $qrcode = $_G['siteurl'].$value['qrcode'];
            }
        }else{
            $qrcode = $value['qrcode'];
        }
    }

    $cateInfoTmp = C::t("#tom_tc114#tom_tc114_cate")->fetch_by_id($value['cate_id']);

    $tc114List[$key]['picurl'] = $picurl;
    $tc114List[$key]['qrcode'] = $qrcode;
    $tc114List[$key]['hide_tel'] = cutstr($value['tel'],4,"****");
    $tc114List[$key]['cateInfo'] = $cateInfoTmp;
    $tc114List[$key]['clicks'] = $value['clicks'] + $value['virtual_clicks'];
}

if(is_array($tc114List) && !empty($tc114List)){
    $i = 0;
    foreach ($tc114List as $key => $val){
        $i++;
        if($tc114Config['open_load_list_clicks'] == 1){
            DB::query("UPDATE ".DB::table('tom_tc114')." SET clicks=clicks+1 WHERE id='{$val['id']}' ", 'UNBUFFERED');
        }

        $outStr .= '<div class="list-item">';
            $outStr .= '<div class="list-item__hd dislay-flex">';
                $outStr .= '<a class="item-hd__logo" href="plugin.php?id=tom_tc114&site='.$site_id.'&mod=info&tc114_id='.$val['id'].'"><img src="'.$val['picurl'].'"></a>';
                $outStr .= '<div class="item-hd__xx flex">';
                    $outStr .= '<a class="name"  href="plugin.php?id=tom_tc114&site='.$site_id.'&mod=info&tc114_id='.$val['id'].'">'.$val['title'].'';
                    $outStr .= '</a>';
                    if($tc114Config['open_list_tel_hide'] == 1 || $val['cateInfo']['open_shoufei'] == 1){
                        $outStr .= '<a class="tel" href="plugin.php?id=tom_tc114&site='.$site_id.'&mod=info&tc114_id='.$val['id'].'"><i class="tciconfont tcicon-dianhua"></i>'.$val['hide_tel'].'</a>';
                    }else{
                        $outStr .= '<a class="tel" href="plugin.php?id=tom_tc114&site='.$site_id.'&mod=info&tc114_id='.$val['id'].'"><i class="tciconfont tcicon-dianhua"></i>'.$val['tel'].'</a>';
                    }
                $outStr .= '</div>';
                
                if($val['cateInfo']['open_shoufei'] == 1 && $tc114Config['pay_shoufei_price'] > 0){
                    $outStr .= '<div class="item-hd__tel"><a href="plugin.php?id=tom_tc114&site='.$site_id.'&mod=info&tc114_id='.$val['id'].'"><i class="tciconfont tc-template__color tcicon-dianhua_kong"></i></a></div>';
                }else{
                    if(!empty($val['qrcode'])){
                        $outStr .= '<div class="item-hd__wx" data-qrcode="'.$val['qrcode'].'"><i class="tciconfont tc-template__color tcicon-weixin"></i></div>';
                    }
                    $outStr .= '<div class="item-hd__tel"><a href="tel:'.$val['tel'].'"><i class="tciconfont tc-template__color tcicon-dianhua_kong"></i></a></div>';
                }

            $outStr .= '</div>';
            if(!empty($val['address'])){
                $outStr .= '<a class="list-item__bd dislay-flex"  href="plugin.php?id=tom_tc114&site='.$site_id.'&mod=info&tc114_id='.$val['id'].'">';
                    $outStr .= '<div class="item-bd__lt flex"><i class="tciconfont tcicon-114__dingwei"></i> '.$val['address'].'</div>';
                    if($type == 3 && !empty($longitude) && !empty($latitude)){
                        $juli = tomGetDistance($longitude, $latitude, $val['longitude'], $val['latitude']);
                        $outStr .= '<div class="item-bd__rt">'.$juli.'km</div>';
                    }else{
                        $outStr .= '<div class="item-bd__rt">'.$val['clicks'].lang('plugin/tom_tc114', 'ajax_list_clicks').'</div>';
                    }
                $outStr .= '</a>';
            }
        $outStr .= '</div>';
    }

    if($tc114Config['open_load_list_clicks'] == 1 && $tc114Config['open_tj_commonclicks'] == 1){
        DB::query("UPDATE ".DB::table('tom_tc114_common')." SET clicks=clicks+{$i} WHERE id='$site_id' ", 'UNBUFFERED');
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;