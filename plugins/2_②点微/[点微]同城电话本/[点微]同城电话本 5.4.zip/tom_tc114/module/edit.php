<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$test = intval($_GET['test'])>0 ? intval($_GET['test']):0;
$tc114_id = intval($_GET['tc114_id'])>0? intval($_GET['tc114_id']):0;

$tc114Info = C::t('#tom_tc114#tom_tc114')->fetch_by_id($tc114_id);

if($__UserInfo['id'] != $tc114Info['user_id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tc114&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $qrcode             = isset($_GET['qrcode'])? addslashes($_GET['qrcode']):'';
    $xm                 = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel2               = isset($_GET['tel2'])? addslashes($_GET['tel2']):'';
    $job                = isset($_GET['job'])? addslashes($_GET['job']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content            = filterEmoji($content);
    $lng                = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $updateData = array();
    $updateData['cate_id']          = $cate_id;
    $updateData['cate_child_id']    = $cate_child_id;
    $updateData['area_id']          = $area_id;
    $updateData['street_id']        = $street_id;
    $updateData['title']            = $title;
    $updateData['picurl']           = $picurl;
    $updateData['qrcode']           = $qrcode;
    $updateData['xm']               = $xm;
    $updateData['tel']              = $tel;
    $updateData['tel2']             = $tel2;
    $updateData['job']              = $job;
    $updateData['content']          = $content.'|+|+|+|+|+|+|+|+|+|'.$title.'-'.$tel.'-'.$tel2.'-'.$address;
    $updateData['latitude']         = $lat;
    $updateData['longitude']        = $lng;
    $updateData['address']          = $address;
    $updateData['part1']            = TIMESTAMP;
    if(C::t('#tom_tc114#tom_tc114')->update($tc114_id,$updateData)){
        
        C::t('#tom_tc114#tom_tc114_photo')->delete_by_tc114_id($tc114_id);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['tc114_id']  = $tc114_id;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tc114#tom_tc114_photo')->insert($insertData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
            'tc114_id'=> $tc114_id,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}

if($tc114Info['pay_status'] == 1){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tc114&site={$site_id}&mod=mylist");exit;
}

$cateInfo = C::t('#tom_tc114#tom_tc114_cate')->fetch_by_id($tc114Info['cate_id']);
$cateChildInfo = C::t('#tom_tc114#tom_tc114_cate')->fetch_by_id($tc114Info['cate_child_id']);

if(!preg_match('/^http/', $tc114Info['picurl']) ){
    if(strpos($tc114Info['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tc114Info['picurl'];
    }else{
        $picurl = $tc114Info['picurl'];
    }
}else{
    $picurl = $tc114Info['picurl'];
}

if(!preg_match('/^http/', $tc114Info['qrcode']) ){
    if(strpos($tc114Info['qrcode'], 'source/plugin/tom_') === FALSE){
        $qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tc114Info['qrcode'];
    }else{
        $qrcode = $tc114Info['qrcode'];
    }
}else{
    $qrcode = $tc114Info['qrcode'];
}

$tc114PhotoListTmp = C::t('#tom_tc114#tom_tc114_photo')->fetch_all_list(" AND tc114_id={$tc114Info['id']} "," ORDER BY id ASC ",0,50);
$tc114PhotoList = array();
$photoCount = 0;
if(is_array($tc114PhotoListTmp) && !empty($tc114PhotoListTmp)){
    foreach ($tc114PhotoListTmp as $kk => $vv){
        $photoCount++;
        if(!preg_match('/^http/', $vv['picurl']) ){
            if(strpos($vv['picurl'], 'source/plugin/tom_') === false){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
            }else{
                $picurlTmp = $vv['picurl'];
            }
        }else{
            $picurlTmp = $vv['picurl'];
        }
        $tc114PhotoList[$kk]['picurl'] = $vv['picurl'];
        $tc114PhotoList[$kk]['src'] = $picurlTmp;
        $tc114PhotoList[$kk]['li_i'] = $photoCount;

    }
}
    

$cateArr = array();
$cateList = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,100);
$i = 0;
if(is_array($cateList) && !empty($cateList)){
    foreach ($cateList as $key => $value){
        $cateArr[$i]['id'] = $value['id'];
        $cateArr[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $childCateList = C::t('#tom_tc114#tom_tc114_cate')->fetch_all_list(" AND pid={$value['id']} "," ORDER BY csort ASC,id DESC ",0,100);
        $j = 0;
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $kk => $vv){
                $cateArr[$i]['sub'][$j]['id'] = $vv['id'];
                $cateArr[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cateData = urlencode(json_encode($cateArr));

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$cityList = array();
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$areaName = '';
if(!empty($tc114Info['area_id'])){
    $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tc114Info['area_id']);
    $areaName = $areaInfoTmp['name'];
}

$streetName = '';
if(!empty($tc114Info['street_id'])){
    $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tc114Info['street_id']);
    $streetName = $streetInfoTmp['name'];
}

$content = contentFormat($tc114Info['content']);

$saveUrl = "plugin.php?id=tom_tc114&site={$site_id}&mod=edit&act=save";
$uploadUrl1 = "plugin.php?id=tom_tc114&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2 = "plugin.php?id=tom_tc114&site={$site_id}&mod=upload&act=qrcode&formhash=".FORMHASH;
$uploadUrl3 = "plugin.php?id=tom_tc114&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tc114:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tc114:edit");