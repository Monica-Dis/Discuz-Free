<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

include_once 'Auth/AbstractCredential.php';
include_once 'Auth/BearerTokenCredential.php';
include_once 'Auth/ISigner.php';
include_once 'Auth/BearTokenSigner.php';
include_once 'Auth/Credential.php';
include_once 'Auth/EcsRamRoleCredential.php';
include_once 'Auth/EcsRamRoleService.php';
include_once 'Auth/RamRoleArnCredential.php';
include_once 'Auth/RamRoleArnService.php';
include_once 'Auth/ShaHmac1Signer.php';
include_once 'Auth/ShaHmac256Signer.php';

include_once 'Exception/ClientException.php';
include_once 'Exception/ServerException.php';

include_once 'Http/HttpHelper.php';
include_once 'Http/HttpResponse.php';

include_once 'Profile/IClientProfile.php';
include_once 'Profile/DefaultProfile.php';

include_once 'Regions/Endpoint.php';
include_once 'Regions/EndpointProvider.php';
include_once 'Regions/ProductDomain.php';
include_once 'Regions/LocationService.php';
include_once 'Regions/EndpointConfig.php';

//config http proxy
/**
 *
 */
define('ENABLE_HTTP_PROXY', false);
/**
 *
 */
define('HTTP_PROXY_IP', '127.0.0.1');
/**
 *
 */
define('HTTP_PROXY_PORT', '8888');
