<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.cn
   
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/video/aliyun-php-sdk-core/AcsRequest.php';
include_once DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/video/aliyun-php-sdk-core/AcsResponse.php';
include_once DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/video/aliyun-php-sdk-core/IAcsClient.php';
include_once DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/video/aliyun-php-sdk-core/DefaultAcsClient.php';
include_once DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/video/aliyun-php-sdk-core/RoaAcsRequest.php';
include_once DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/video/aliyun-php-sdk-core/RpcAcsRequest.php';
include_once DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/video/aliyun-php-sdk-core/Config.php';
include_once DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/video/aliyun-php-sdk-sts/Sts/Request/V20150401/AssumeRoleRequest.php';
include_once DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/video/aliyun-php-sdk-sts/Sts/Request/V20150401/GenerateSessionAccessKeyRequest.php';
include_once DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/video/aliyun-php-sdk-sts/Sts/Request/V20150401/GetCallerIdentityRequest.php';

use Sts\Request\V20150401 as Sts;

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');

$tongchengConfig['alioss_endpoint'] = trim($tongchengConfig['alioss_endpoint']);
$tongchengConfig['alioss_ram_access_id'] = trim($tongchengConfig['alioss_ram_access_id']);
$tongchengConfig['alioss_ram_access_key'] = trim($tongchengConfig['alioss_ram_access_key']);
$tongchengConfig['alioss_ram_arn'] = trim($tongchengConfig['alioss_ram_arn']);
$tongchengConfig['alioss_buckey'] = trim($tongchengConfig['alioss_buckey']);
$tongchengConfig['alioss_hosts'] = trim($tongchengConfig['alioss_hosts']);

$region = str_replace('.aliyuncs.com', '', $tongchengConfig['alioss_endpoint']);

$region_id = str_replace('oss-', '', $tongchengConfig['alioss_endpoint']);
$region_id = str_replace('.aliyuncs.com', '', $region_id);
$bucket    = $tongchengConfig['alioss_buckey'];

$hosts = 'https://'.$tongchengConfig['alioss_buckey'].'.'.$tongchengConfig['alioss_endpoint'];
if(!empty($tongchengConfig['alioss_hosts'])){
    $hosts = $tongchengConfig['alioss_hosts'];
}

define("REGION_ID", $region_id);
define("ENDPOINT", "sts.".$region_id.".aliyuncs.com");
// ָ����ɫ ARN
$roleArn = $tongchengConfig['alioss_ram_arn'];
// �ڰ��ݽ�ɫʱ������һ��Ȩ�޲��ԣ���һ�����ƽ�ɫ��Ȩ��
// ����Ȩ�޲��Ա�ʾӵ�п��Զ�ȡ���� OSS ��ֻ��Ȩ��
$policy=<<<POLICY
{
	"Statement": [
        {
            "Action": "oss:*",
            "Effect": "Allow",
            "Resource": "*"
        }
    ],
    "Version": "1"
}
POLICY;

if(submitcheck('user_id') || $_G['uid'] == 1){
    
    // ֻ���� RAM �û�ʹ�ý�ɫ
    DefaultProfile::addEndpoint(REGION_ID, REGION_ID, "Sts", ENDPOINT);
    $iClientProfile = DefaultProfile::getProfile(REGION_ID, $tongchengConfig['alioss_ram_access_id'], $tongchengConfig['alioss_ram_access_key']);
    $client = new DefaultAcsClient($iClientProfile);

    $request = new Sts\AssumeRoleRequest();
    // RoleSessionName ����ʱ���ݵĻỰ���ƣ��������ֲ�ͬ����ʱ����
    $request->setRoleSessionName("client_tom");
    $request->setRoleArn($roleArn);
    $request->setPolicy($policy);
    $request->setDurationSeconds(1800);
    try {
        $response = $client->getAcsResponse($request);
        $response = object_to_array($response);

        $outArr = array(
            'status'			=> 200,
            'region'            => $region,
            'bucket'            => $bucket,
            'hosts'             => $hosts,
            'AccessKeyId'		=> $response['Credentials']['AccessKeyId'],
            'AccessKeySecret'	=> $response['Credentials']['AccessKeySecret'],
            'SecurityToken'		=> $response['Credentials']['SecurityToken'],
        );
        echo json_encode($outArr); exit;

    } catch(ServerException $e) {
        $outArr = array(
            'status'		=> 301,
            'errormsg'		=> "Error: " . $e->getErrorCode() . " Message: " . $e->getMessage(),
        );
        echo json_encode($outArr); exit;
        //print "Error: " . $e->getErrorCode() . " Message: " . $e->getMessage() . "\n";
    } catch(ClientException $e) {
        $outArr = array(
            'status'		=> 301,
            'errormsg'		=> "Error: " . $e->getErrorCode() . " Message: " . $e->getMessage(),
        );
        echo json_encode($outArr); exit;
        //print "Error: " . $e->getErrorCode() . " Message: " . $e->getMessage() . "\n";
    }
}else{
    $outArr = array(
        'status'			=> 500,
    );
    echo json_encode($outArr); exit;
}

function object_to_array($obj) {
    $obj = (array)$obj;
    foreach ($obj as $k => $v) {
        if (gettype($v) == 'resource') {
            return;
        }
        if (gettype($v) == 'object' || gettype($v) == 'array') {
            $obj[$k] = (array)object_to_array($v);
        }
    }
 
    return $obj;
}