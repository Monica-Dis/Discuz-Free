<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tongcheng_sfc extends discuz_table{
	public function __construct() {
        parent::__construct(); /* DISM �� Taobao �� Com*/
		$this->_table = 'tom_tongcheng_sfc_cache';
		$this->_pk    = 'id';
	}

    public function fetch_all_sfc($condition = '',$orders = '',$start = 0,$limit = 10,$chufa = '',$mude = '',$is_route = 0) {
        if(!empty($chufa) && !empty($mude) && $is_route == 1){
            $chufa = str_replace(array('%', '_'),'',$chufa);
            $mude = str_replace(array('%', '_'),'',$mude);
            $data = DB::fetch_all('SELECT t.*, s.chufa,s.mude,s.chufa_time,s.chufa_int_time,s.renshu_type,s.renshu FROM '.DB::table('tom_tongcheng').' t LEFT JOIN '.DB::table('tom_tongcheng_sfc_cache')." s ON t.id = s.tongcheng_id  WHERE 1 %i AND (s.chufa LIKE %s OR s.chufa LIKE %s) AND (s.mude LIKE %s OR s.mude LIKE %s) $orders LIMIT $start,$limit",array($condition,'%'.$chufa.'%','%'.$mude.'%','%'.$chufa.'%','%'.$mude.'%'));
        }else if(!empty($chufa) && !empty($mude)){
            $chufa = str_replace(array('%', '_'),'',$chufa);
            $mude = str_replace(array('%', '_'),'',$mude);
            $data = DB::fetch_all('SELECT t.*, s.chufa,s.mude,s.chufa_time,s.chufa_int_time,s.renshu_type,s.renshu FROM '.DB::table('tom_tongcheng').' t LEFT JOIN '.DB::table('tom_tongcheng_sfc_cache')." s ON t.id = s.tongcheng_id  WHERE 1 %i AND s.chufa LIKE %s AND s.mude LIKE %s $orders LIMIT $start,$limit",array($condition,'%'.$chufa.'%','%'.$mude.'%'));
        }else if(!empty($chufa)){
            $chufa = str_replace(array('%', '_'),'',$chufa);
            $data = DB::fetch_all('SELECT t.*, s.chufa,s.mude,s.chufa_time,s.chufa_int_time,s.renshu_type,s.renshu FROM '.DB::table('tom_tongcheng').' t LEFT JOIN '.DB::table('tom_tongcheng_sfc_cache')." s ON t.id = s.tongcheng_id  WHERE 1 %i AND s.chufa LIKE %s $orders LIMIT $start,$limit",array($condition,'%'.$chufa.'%'));
        }else if(!empty($mude)){
            $mude = str_replace(array('%', '_'),'',$mude);
            $data = DB::fetch_all('SELECT t.*, s.chufa,s.mude,s.chufa_time,s.chufa_int_time,s.renshu_type,s.renshu FROM '.DB::table('tom_tongcheng').' t LEFT JOIN '.DB::table('tom_tongcheng_sfc_cache')." s ON t.id = s.tongcheng_id  WHERE 1 %i AND s.mude LIKE %s $orders LIMIT $start,$limit",array($condition,'%'.$mude.'%'));
        }else{
            $data = DB::fetch_all('SELECT t.*, s.chufa,s.mude,s.chufa_time,s.chufa_int_time,s.renshu_type,s.renshu FROM '.DB::table('tom_tongcheng').' t LEFT JOIN '.DB::table('tom_tongcheng_sfc_cache')." s ON t.id = s.tongcheng_id  WHERE 1 %i $orders LIMIT $start,$limit",array($condition));
        }
        return $data;
    }
    
    public function fetch_all_count($condition = '',$chufa = '',$mude = '') {
        if(!empty($chufa) && !empty($mude)){
            $chufa = str_replace(array('%', '_'),'',$chufa);
            $mude = str_replace(array('%', '_'),'',$mude);
            $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i AND chufa LIKE %s AND mude LIKE %s ",array($this->_table,$condition,'%'.$chufa.'%','%'.$mude.'%'));
        }else if(!empty($chufa)){
            $chufa = str_replace(array('%', '_'),'',$chufa);
            $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i AND chufa LIKE %s ",array($this->_table,$condition,'%'.$chufa.'%'));
        }else if(!empty($mude)){
            $mude = str_replace(array('%', '_'),'',$mude);
            $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i AND mude LIKE %s ",array($this->_table,$condition,'%'.$mude.'%'));
        }else{
            $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i ",array($this->_table,$condition));
        }
        
		return $return['num'];
	}
}