<?php

/*
   ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
   ���²����http://t.cn/Aiux1Jx1
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcpinche'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcpinche&pmod=admin'; 
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcpinche&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcpinche&pmod=admin';
$tomSysOffset = getglobal('setting/timeoffset');

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){
}else{
    echo '<a href="https://dism.taobao.com/?@tom_tongcheng.plugin">https://dism.taobao.com/?@tom_tongcheng.plugin</a>';exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tcpinche/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcpinche/class/function.a.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';

$tcpincheConfig = get_tcpinche_config($pluginid);
$tongchengPlugin = C::t('#tom_tcshop#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$Lang = formatLang($Lang);

if($_GET['tmod'] == 'route'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpinche/admin/route.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpinche/admin/focuspic.php';
}else if($_GET['tmod'] == 'cache'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpinche/admin/cache.php';
}else if($_GET['tmod'] == 'common'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpinche/admin/common.php';
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpinche/admin/addon.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcpinche/admin/route.php';
}