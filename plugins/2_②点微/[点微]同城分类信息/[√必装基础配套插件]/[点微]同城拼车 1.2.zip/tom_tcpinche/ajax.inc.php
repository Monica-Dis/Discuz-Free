<?php

/*
   ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
   ���²����http://t.cn/Aiux1Jx1
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tcpincheConfig = $_G['cache']['plugin']['tom_tcpinche'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$mingtianTimestamp = $nowDayTime + 86400;
$houtianTimestamp = $nowDayTime + 86400*2;
$dahoutianTimestamp = $nowDayTime + 86400*3;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
$sql_in_site_ids = $site_id;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

include DISCUZ_ROOT.'./source/plugin/tom_tcpinche/class/function.core.php';

## tchongbao start
$__ShowTchongbao = 0;
$__TchongbaoHost = '';
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchongbao/tom_tchongbao.inc.php')){
    $tchongbaoConfig = $_G['cache']['plugin']['tom_tchongbao'];
    if($tchongbaoConfig['open_tchongbao'] == 1){
        $__ShowTchongbao = 1;
        if($tchongbaoConfig['open_only_hosts'] == 1 && !empty($tchongbaoConfig['tongcheng_hosts']) && !empty($tchongbaoConfig['hongbao_hosts'])){
            $__TchongbaoHost = str_replace($tchongbaoConfig['tongcheng_hosts'], $tchongbaoConfig['hongbao_hosts'], $_G['siteurl']);
            if($tchongbaoConfig['must_http'] == 1){
                $__TchongbaoHost = str_replace("https", "http", $__TchongbaoHost);
            }
        }
    }
}
## tchongbao end

## tcrenzheng start
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')){
    $tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
    if($tcrenzhengConfig['open_tcrenzheng'] == 1){
        $__ShowTcrenzheng = 1;
    }
}
## tcrenzheng end

$modelInfo  = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list("AND type=2 ","ORDER BY id DESC",0,1);
$model_id   = $modelInfo['0']['id'];

if($_GET['act'] == 'list' && $_GET['formhash'] == FORMHASH){
    
    $outStr = '';
    
    $paixu_type  = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):0;
    $type_id     = intval($_GET['type_id'])>0? intval($_GET['type_id']):0;
    $route_id    = intval($_GET['route_id'])>0? intval($_GET['route_id']):0;
    $chufa       = isset($_GET['chufa'])? daddslashes(diconv(urldecode($_GET['chufa']),'utf-8')):'';
    $mude        = isset($_GET['mude'])? daddslashes(diconv(urldecode($_GET['mude']),'utf-8')):'';
    $page        = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize    = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):6;
    
    $is_route = 0;
    if($route_id > 0){
        $is_route   = 1;
        $routeInfo  = C::t('#tom_tcpinche#tom_tcpinche_route')->fetch_by_id($route_id);
        $chufa      = $routeInfo['chufa'];
        $mude       = $routeInfo['mude'];
    }

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

    $whereStr = "AND t.model_id={$model_id} AND t.status=1 AND t.shenhe_status=1 ";
    if(!empty($sql_in_site_ids)){
        $whereStr.= " AND t.site_id IN({$sql_in_site_ids}) ";
    }
    if(!empty($type_id)){
        $whereStr.= " AND t.type_id={$type_id} ";
    }
   
    $orderStr = " ORDER BY t.refresh_time DESC,t.id DESC ";

    if($paixu_type > 0){
        $orderStr = " ORDER BY t.finish ASC,s.chufa_int_time ASC,t.id DESC ";
    }else if($tongchengConfig['top_paixu_type'] == 2){
        $orderStr = " ORDER BY t.topstatus DESC,t.toptime DESC, t.finish ASC,t.refresh_time DESC,t.id DESC ";
    }else if($tongchengConfig['top_paixu_type'] == 3){
        $orderStr = " ORDER BY t.topstatus DESC,t.finish ASC,t.refresh_time DESC,t.id DESC ";
    }else{
        $orderStr = " ORDER BY t.topstatus DESC,t.finish ASC,t.refresh_time DESC,t.id DESC ";
    }

    $pagesize = $pagesize;
    $start = ($page - 1)*$pagesize;
    
    $sfcCacheListTmp = C::t('#tom_tcpinche#tom_tongcheng_sfc')->fetch_all_sfc($whereStr,$orderStr,$start,$pagesize, $chufa, $mude,$is_route);
    
    $sfcCacheList = array();
    foreach ($sfcCacheListTmp as $key => $value) {
        $modelInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($value['model_id']);
        $typeInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($value['type_id']);
        
        if($value['finish'] == 0 && $value['topstatus'] == 0 && $typeInfoTmp['over_time_attr_id'] > 0 && $typeInfoTmp['over_time_do'] > 0){
            $tongchengAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id={$value['id']} AND attr_id={$typeInfoTmp['over_time_attr_id']} "," ORDER BY id DESC ",0,1);
            if(is_array($tongchengAttrInfoTmp) && !empty($tongchengAttrInfoTmp) && $tongchengAttrInfoTmp[0] && $tongchengAttrInfoTmp[0]['time_value'] > 0){
                if($tongchengAttrInfoTmp[0]['time_value'] < TIMESTAMP){
                    if($typeInfoTmp['over_time_do'] == 1){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2,finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($typeInfoTmp['over_time_do'] == 2){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }
                }
            }
        }
        
        if($typeInfoTmp['jifei_type'] == 2 && $value['over_days'] > 0){
            if($value['topstatus'] == 0 && $value['finish'] == 0){
                if($value['over_time'] < TIMESTAMP){
                    if($tongchengConfig['over_time_do'] == 1){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($tongchengConfig['over_time_do'] == 2){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2,finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($tongchengConfig['over_time_do'] == 4){
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }
                }
            }
        }else{
            if($value['topstatus'] == 0 && $value['finish'] == 0 && $tongchengConfig['over_time_limit'] > 0){
                if(($value['refresh_time']+$tongchengConfig['over_time_limit']*86400) < TIMESTAMP){
                    if($tongchengConfig['over_time_do'] == 1){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($tongchengConfig['over_time_do'] == 2){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2,finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($tongchengConfig['over_time_do'] == 4){
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }
                }
            }
        }
        
        $sfcCacheList[$key] = $value;
        $sfcCacheList[$key]['content'] = contentFormat($value['content']);
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 

        $tchongbaoInfo = array();
        if($__ShowTchongbao == 1){
            $tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(" AND tongcheng_id = {$value['id']} AND pay_status = 2 AND only_show = 1 ", 'ORDER BY add_time DESC,id DESC', 0, 1);
            if(is_array($tchongbaoInfoTmp) && !empty($tchongbaoInfoTmp[0])){
                $tchongbaoInfo = $tchongbaoInfoTmp[0];
            }
        }
        
        $tongchengTagListTmp = C::t('#tom_tongcheng#tom_tongcheng_tag')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY id DESC ",0,50);
        
        $sfcCacheList[$key]['userInfo'] = $userInfoTmp;
        $sfcCacheList[$key]['modelInfo'] = $modelInfoTmp;
        $sfcCacheList[$key]['typeInfo'] = $typeInfoTmp;
        $sfcCacheList[$key]['tagList']  = $tongchengTagListTmp;
        $sfcCacheList[$key]['tchongbaoInfo'] = $tchongbaoInfo;
        
        if($__ShowTcrenzheng == 1){
            $companyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($userInfoTmp['id']);
            if(is_array($companyInfoTmp) && $companyInfoTmp['shenhe_status'] == 1){
                $sfcCacheList[$key]['companyRenzhengStatus'] = 1;
            }
            
            $personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_user_id($userInfoTmp['id']);
            if(is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1){
                $sfcCacheList[$key]['personalRenzhengStatus'] = 1;
            }
            
            $depositInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_by_user_id($userInfoTmp['id']);
            if(is_array($depositInfoTmp) && $depositInfoTmp['order_status'] == 2){
                $sfcCacheList[$key]['depositStatus'] = 1;
            }
        }
    }
    
    if(is_array($sfcCacheList) && !empty($sfcCacheList)){
        $i = 0;
        foreach ($sfcCacheList as $key => $val){
            $i++;
            if($tongchengConfig['open_load_list_clicks'] == 1){
                DB::query("UPDATE ".DB::table('tom_tongcheng')." SET clicks=clicks+1 WHERE id='{$val['id']}' ", 'UNBUFFERED');
            }
            
            if(!empty($val['tchongbaoInfo'])){
                $infoUrl = $__TchongbaoHost.'plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=hbao&xxid='.$val['id'];
            }else{
                $infoUrl = 'plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=view&xxid='.$val['id'];
            }
            $outStr.= '<div class="pinchelist_item">';
                $outStr.= '<div class="pinchelist_item_top">';
                    $outStr.= '<div class="pinchelist_item_top_left">';
                        $outStr.= '<div class="pinchelist_item_dizhi">';
                            if($val['topstatus'] == 1){
                                $outStr .= '<span><a style="background-color: #f15555;border-radius: 2px;padding: 0px 1px;">'.lang("plugin/tom_tcpinche", "top").'</a></span>&nbsp; ';
                            }
                            $outStr.= '<span class="type tc-template__bg"><a class="tc-template__bg" href="plugin.php?id=tom_tcpinche&site='.$site_id.'&mod=index&type_id='.$val['typeInfo']['id'].'">'.$val['typeInfo']['name'].'</a></span>&nbsp; ';
                            if($val['companyRenzhengStatus'] == 1 || $val['personalRenzhengStatus'] == 1 || $val['depositStatus'] == 1){
                                $outStr.= '<a class="renzhenicon" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">';
                                    if($val['companyRenzhengStatus'] == 1){
                                        $outStr.= '<i class="tciconfont tc-template__color tcicon-company__renzheng"></i>';
                                    }
                                    if($val['personalRenzhengStatus'] == 1){
                                        $outStr.= '<i class="tciconfont tc-template__color tcicon-personal__renzheng"></i>';
                                    }
                                    if($val['depositStatus'] == 1){
                                        $outStr.= '<i class="tciconfont tc-template__color tcicon-deposit"></i>';
                                    }
                                $outStr.= '</a>&nbsp;';
                            }
                            $outStr.= '<span>'.$val['chufa'].' --> '.$val['mude'].'</span>';
                            if(!empty($val['tchongbaoInfo'])){
                                $outStr .= '&nbsp;<span class="hongbao">'.lang("plugin/tom_tcpinche", "ajax_list_hongbao").'</span>&nbsp; ';
                            }
                        $outStr.= '</div>';
                        $outStr .= '<a href="'.$infoUrl.'">';
                            $outStr.= '<div class="xiangqing time">';
                                $outStr.= '<span class="left">'.lang('plugin/tom_tcpinche', 'ajax_list_chufa_time').'</span>';
                                $chufa_time = strstr($val['chufa_time'] ,  ' ');
                                $chufa_time = trim($chufa_time);
                                $chufa_time = substr($chufa_time,0,-3);
                                $chufaTimestamp     = $val['chufa_int_time'];
                                if($chufaTimestamp >= $nowDayTime && $chufaTimestamp < $mingtianTimestamp){
                                    $outStr.= '<span class="right"><b>'.lang('plugin/tom_tcpinche', 'ajax_list_jintian').$chufa_time.'</b></span>';
                                }elseif($chufaTimestamp >= $mingtianTimestamp && $chufaTimestamp < $houtianTimestamp){
                                    $outStr.= '<span class="right"><b>'.lang('plugin/tom_tcpinche', 'ajax_list_mingtian').$chufa_time.'</b></span>';
                                }elseif($chufaTimestamp >= $houtianTimestamp && $chufaTimestamp < $dahoutianTimestamp){
                                    $outStr.= '<span class="right"><b>'.lang('plugin/tom_tcpinche', 'ajax_list_houtian').$chufa_time.'</b></span>';
                                }else{
                                    $outStr.= '<span class="right">'.$val['chufa_time'].'</span>';
                                }
                            $outStr.= '</div>';
                        $outStr.= '</a>';
                        $outStr .= '<a href="'.$infoUrl.'">';
                            $outStr.= '<div class="xiangqing num">';
                                if($val['renshu_type'] == 2){
                                    $outStr.= '<span class="left">'.lang('plugin/tom_tcpinche', 'ajax_list_chufa_renshu2').'</span>';
                                }else{
                                    $outStr.= '<span class="left">'.lang('plugin/tom_tcpinche', 'ajax_list_chufa_renshu').'</span>';
                                }
                                $outStr.= '<span class="right">'.$val['renshu'].'</span>';
                            $outStr.= '</div>';
                        $outStr.= '</a>';
                    $outStr.= '</div>';
                    $outStr.= '<div class="pinchelist_item_top_right">';
                        $outStr.= '<div class="pinchelist_item_right_box">';
                        if($val['finish'] == 1){
                            $outStr .= '<a href="javascript:void(0);">';
                            $outStr .= '<div class="sfcline-complete"></div>';
                        }else{
                            if($val['typeInfo']['open_tel_price'] == 1){
                                $outStr.= '<a href="'.$infoUrl.'">';
                            }else{
                                $outStr.= '<a href="tel:'.$val['tel'].'">';
                            }
                        }
                            if($val['finish'] == 1){
                                $outStr.= '<div class="tel" style="background:#dedede">';
                            }else{
                                $outStr.= '<div class="tel">';
                            }
                                    $outStr.= '<i class="tciconfont tcicon-dianhua" style="font-size:14px;"></i>';
                                    $outStr.= '<span>'.lang('plugin/tom_tcpinche', 'ajax_list_pinche_tel').'</span>';
                                $outStr.= '</div>';
                            $outStr.= '</a>';
                            $sfc_refresh_time = dgmdate($val['refresh_time'], 'u','9999','m-d H:i');
                            if(strpos($sfc_refresh_time, '201') !== FALSE || strpos($sfc_refresh_time, '202') !== FALSE){
                                $outStr .= '<div class="time">'.dgmdate($val['refresh_time'],"m-d H:i",$tomSysOffset).'</div>';
                            }else{
                                $outStr .= '<div class="time">'.$sfc_refresh_time.'</div>';
                            }
                        $outStr.= '</div>';
                    $outStr.= '</div>';
                $outStr.= '</div>';
                $outStr.= '<div class="pinchelist_item_bottom">';
                    $outStr.= '<a href="'.$infoUrl.'">';
                        $outStr.= '<div class="pinche_tab clearfix">';
                            foreach ($val['tagList'] as $k1 => $v1){
                                $outStr.= '<span class="tab tab_'.$k1.'">'.$v1['tag_name'].'</span>';
                            }
                        $outStr.= '</div>';

                        $outStr.= '<div class="content">'.$val['content'].'</div>';
                    $outStr.= '</a>';
                $outStr.= '</div>';
            $outStr.= '</div>';
        $outStr.= '</div>';
        }
        if($tongchengConfig['open_load_list_clicks'] == 1 && $tongchengConfig['open_tj_commonclicks'] == 1){
            DB::query("UPDATE ".DB::table('tom_tongcheng_common')." SET clicks=clicks+{$i} WHERE id='$site_id' ", 'UNBUFFERED');
        }
    }else{
        $outStr = '205';
    }
    $outStr = tom_link_replace($outStr);
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($_GET['act'] == 'get_pinche_search_url' && $_GET['formhash'] == FORMHASH){
    
    $chufa = isset($_GET['chufa'])? daddslashes(diconv(urldecode($_GET['chufa']),'utf-8')):'';
    $mude = isset($_GET['mude'])? daddslashes(diconv(urldecode($_GET['mude']),'utf-8')):'';

    $url = $_G['siteurl']."plugin.php?id=tom_tcpinche&site={$site_id}&mod=index&chufa=".urlencode(trim($chufa))."&mude=".urlencode(trim($mude));
    $url = tom_link_replace($url);
    echo $url;exit;
    
}else if($_GET['act'] == 'commonClicks' && $_GET['formhash'] == FORMHASH){
    
    DB::query("UPDATE ".DB::table('tom_tongcheng_common')." SET clicks=clicks+1 WHERE id='$site_id' ", 'UNBUFFERED');
    echo 200;exit;
    
}else{
    echo 'error';exit;
}