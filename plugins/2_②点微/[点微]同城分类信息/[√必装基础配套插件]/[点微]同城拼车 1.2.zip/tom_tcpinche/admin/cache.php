<?php

/*
   ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
   ���²����http://t.cn/Aiux1Jx1
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=cache';
$modListUrl = $adminListUrl.'&tmod=cache';
$modFromUrl = $adminFromUrl.'&tmod=cache';

if($_GET['act'] == 'add'){
    
    $modelInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(' AND type=2 ', 'ORDER BY id DESC', 0, 1);
    if(is_array($modelInfoTmp) && !empty($modelInfoTmp[0])){
        
        $typeListTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_all_list(" AND model_id = {$modelInfoTmp[0]['id']} ", 'ORDER BY id DESC', 0, 10);
        $typeList= array();
        if(is_array($typeListTmp) && !empty($typeListTmp[0])){
            foreach($typeListTmp as $key => $value){
                $typeList[] = $value['id'];
            }
            $tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list(" AND model_id={$modelInfoTmp[0]['id']} AND type_id IN(".implode(',', $typeList).")  AND status=1 AND shenhe_status=1 ", 'ORDER BY refresh_time DESC,id DESC', 0, 1000);
            if(is_array($tongchengListTmp) && !empty($tongchengListTmp[0])){
                foreach($tongchengListTmp as $key => $value){
                    $typeInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($value['type_id']);
                    if(!empty($typeInfoTmp['sfc_chufa_attr_id']) && !empty($typeInfoTmp['sfc_mude_attr_id']) && !empty($typeInfoTmp['sfc_time_attr_id']) && !empty($typeInfoTmp['sfc_renshu_attr_id'])){
                        
                        $sfcAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id = {$value['id']}", 'ORDER BY id DESC', 0, 10);
                        
                        $sfcChufaAttrInfoTmp = $sfcMudeAttrInfoTmp = $sfcTimeAttrInfoTmp = $sfcRenshuAttrInfoTmp = array();
                        if(is_array($sfcAttrInfoTmp) && !empty($sfcAttrInfoTmp)){
                            foreach ($sfcAttrInfoTmp as $ks => $vs){
                                if($vs['attr_id'] == $typeInfoTmp['sfc_chufa_attr_id']){
                                    $sfcChufaAttrInfoTmp = $vs;
                                }
                                if($vs['attr_id'] == $typeInfoTmp['sfc_mude_attr_id']){
                                    $sfcMudeAttrInfoTmp = $vs;
                                }
                                if($vs['attr_id'] == $typeInfoTmp['sfc_time_attr_id']){
                                    $sfcTimeAttrInfoTmp = $vs;
                                }
                                if($vs['attr_id'] == $typeInfoTmp['sfc_renshu_attr_id']){
                                    $sfcRenshuAttrInfoTmp = $vs;
                                }
                            }
                        }
                        
                        if(is_array($sfcChufaAttrInfoTmp) && !empty($sfcChufaAttrInfoTmp) && is_array($sfcMudeAttrInfoTmp) && !empty($sfcMudeAttrInfoTmp)){
                            $sfcCacheInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sfc_cache')->fetch_all_list(" AND tongcheng_id = {$value['id']} ", 'ORDER BY id DESC', 0, 1);
                            if(is_array($sfcCacheInfoTmp) && !empty($sfcCacheInfoTmp[0])){
                            }else{
                                $insertData = array();
                                $insertData['site_id']      = $value['site_id'];
                                $insertData['tongcheng_id'] = $value['id'];
                                $insertData['model_id']     = $modelInfoTmp[0]['id'];
                                $insertData['type_id']      = $value['type_id'];
                                $insertData['chufa']        = $sfcChufaAttrInfoTmp['value'];
                                $insertData['mude']         = $sfcMudeAttrInfoTmp['value'];
                                $insertData['chufa_time']   = $sfcTimeAttrInfoTmp['value'];
                                $insertData['chufa_int_time']  = $sfcTimeAttrInfoTmp['time_value'];
                                $insertData['renshu_type']  = $typeInfoTmp['sfc_renshu_type'];
                                $insertData['renshu']       = $sfcRenshuAttrInfoTmp['value'];
                                $insertData['add_time']     = TIMESTAMP;
                                C::t('#tom_tongcheng#tom_tongcheng_sfc_cache')->insert($insertData);
                            }
                        }
                    }else{
                        cpmsg($Lang['cache_error_2'], $modListUrl, 'error');
                    }
                }
            }
            
        }
    }else{
        cpmsg($Lang['cache_error_1'], $modListUrl, 'error');
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['act'] == 'clear'){
    
    $sql = 'TRUNCATE TABLE '.DB::table('tom_tongcheng_sfc_cache');
	DB::query($sql);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    showtableheader();/*Dism_taobao_com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['cache_title'] . '</th></tr>';
    showtablefooter();/*Dism_taobao-com*/
    
    tomshownavheader();
    tomshownavli($Lang['cache_add_title'],$modBaseUrl.'&act=add',false);
    tomshownavli($Lang['cache_clear_title'],$modBaseUrl.'&act=clear',false);
    tomshownavfooter();/*DisM �� Taobao - Com*/
}