<?php

/*
   ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
   ���²����http://t.cn/Aiux1Jx1
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$type_id    = intval($_GET['type_id'])>0? intval($_GET['type_id']):0;
$route_id   = intval($_GET['route_id'])>0? intval($_GET['route_id']):0;
$chufa      = isset($_GET['chufa'])? addslashes(urldecode($_GET['chufa'])):'';
$mude       = isset($_GET['mude'])? addslashes(urldecode($_GET['mude'])):'';

$modelInfo  = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list("AND type=2 ","ORDER BY id DESC",0,1);
if($modelInfo && $modelInfo['0']['id'] > 0){
    $model_id   = $modelInfo['0']['id'];
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=index");exit;
}

$focuspicListTmp = C::t('#tom_tcpinche#tom_tcpinche_focuspic')->fetch_all_list(" AND site_id={$site_id} "," ORDER BY fsort ASC,id DESC ",0,10);
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
}else{
    $focuspicListTmp = C::t('#tom_tcpinche#tom_tcpinche_focuspic')->fetch_all_list(" AND site_id=1 "," ORDER BY fsort ASC,id DESC ",0,10);
}
$focuspicList = array();
foreach ($focuspicListTmp as $key => $value) {
    $focuspicList[$key] = $value;    
    if(!preg_match('/^http/', $value['picurl']) ){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
    }else{
        $picurl = $value['picurl'];
    }
    $focuspicList[$key]['picurl'] = $picurl;
}

$routeListTmp = C::t('#tom_tcpinche#tom_tcpinche_route')->fetch_all_list("AND site_id={$site_id} ","ORDER BY rsort ASC,id DESC",0,100);
$routeList = array();
if(is_array($routeListTmp) && !empty($routeListTmp)){
    foreach ($routeListTmp as $key => $value) {
        $routeList[$key] = $value;
    }
}

if(!empty($__CommonInfo['sfc_txt'])){
    $sfcTxt = stripslashes($__CommonInfo['sfc_txt']);
    $sfcTxtTitle = cutstr(strip_tags(stripslashes($__CommonInfo['sfc_txt'])), 100 ,'...');
    $sfcTxtTitle = str_replace("\r\n","",$sfcTxtTitle);
    $sfcTxtTitle = str_replace("\n","",$sfcTxtTitle);
    $sfcTxtTitle = str_replace("\r","",$sfcTxtTitle);
}

$whereStr = "";
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($type_id)){
    $whereStr.= " AND type_id={$type_id} ";
}
$pincheCount = C::t('#tom_tcpinche#tom_tongcheng_sfc')->fetch_all_count($whereStr,$chufa,$mude);


$str_replace_search_array   = array('{PINGCHE}','{LOVE}','{YIKATONG}','{114}','{KANJIA}','{PINTUAN}','{HONGBAO}','{QIANGGOU}','{HAODIAN}','{HEHUOREN}','{RUZHU}','{FABU}','{XIANGQIN}','{TOUTIAO}');
$str_replace_search_replace = array(
    "plugin.php?id=tom_tcpinche&site={$site_id}&mod=index",
    "plugin.php?id=tom_love&mod=index",
    "plugin.php?id=tom_tcyikatong&site={$site_id}&mod=index",
    "plugin.php?id=tom_tc114&site={$site_id}&mod=index",
    "plugin.php?id=tom_tckjia&site={$site_id}&mod=index",
    "plugin.php?id=tom_tcptuan&site={$site_id}&mod=index",
    "plugin.php?id=tom_tchongbao&site={$site_id}&mod=index",
    "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index",
    "plugin.php?id=tom_tcshop&site={$site_id}&mod=index",
    "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=inlet",
    "plugin.php?id=tom_tcshop&site={$site_id}&mod=ruzhu",
    "plugin.php?id=tom_tongcheng&site={$site_id}&mod=fabu",
    "plugin.php?id=tom_xiangqin&mod=index",
    "plugin.php?id=tom_tctoutiao&site={$site_id}&mod=index",
);
$menuList = array();
$i = 1;
if(!empty($tcpincheConfig['index_nav'])){
    $index_menu_str = str_replace($str_replace_search_array, $str_replace_search_replace, $tcpincheConfig['index_nav']);
    $index_menu_str = str_replace('{PINGCHE_', "plugin.php?id=tom_tcpinche&site={$site_id}&mod=index&type_id=", $index_menu_str);
    $index_menu_str = str_replace('}', "", $index_menu_str);
    $index_menu_str = str_replace("\r\n","{n}",$index_menu_str); 
    $index_menu_str = str_replace("\n","{n}",$index_menu_str);
    $index_menu_arr = explode("{n}", $index_menu_str);
    if(is_array($index_menu_arr) && !empty($index_menu_arr)){
        foreach ($index_menu_arr as $key => $value){
            $menuList[$i] = explode("|", $value);
            $i++;
        }
    }
}
$menuCount = count($menuList);

$md5HostUrl          = md5($_G['siteurl']."plugin.php?id=tom_tcpinche&site={$site_id}&mod=list&type_id={$type_id}&route_id={$route_id}&chufa={$chufa}&mude={$mude}");
$ajaxLoadListUrl     = 'plugin.php?id=tom_tcpinche:ajax&site='.$site_id.'&act=list&formhash='.$formhash;
$pincheSearchUrl     = "plugin.php?id=tom_tcpinche:ajax&site={$site_id}&act=get_pinche_search_url";
$ajaxCommonClicksUrl = 'plugin.php?id=tom_tcpinche:ajax&site='.$site_id.'&act=commonClicks&&formhash='.$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcpinche:index");