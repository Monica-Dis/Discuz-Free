<?php

/*
   ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
   ���²����http://t.cn/Aiux1Jx1
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcpincheConfig = $_G['cache']['plugin']['tom_tcpinche'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = "20190506112";

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/nofind.php';

$wxJssdkConfig = array();
$wxJssdkConfig["appId"]     = "";
$wxJssdkConfig["timestamp"] = time();
$wxJssdkConfig["nonceStr"]  = "";
$wxJssdkConfig["signature"] = "";
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcpincheConfig['wx_share_title'];
$shareDesc  = $tcpincheConfig['wx_share_desc'];
$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tcpinche&site=".$site_id."&mod=index";
$shareLogo  = $tcpincheConfig['wx_share_pic'];

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesinfo.php';

$shareTitle = str_replace("{SITENAME}",$__SitesInfo['name'], $shareTitle);
$shareDesc = str_replace("{SITENAME}",$__SitesInfo['name'], $shareDesc);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login.php';

$ajaxLoadListUrl    = 'plugin.php?id=tom_tcpinche:ajax&site='.$site_id.'&act=list&formhash='.$formhash;

$__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
if(!$__CommonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tongcheng#tom_tongcheng_common')->insert($insertData);
}

/********************* index ***********************/
if($_GET['mod'] == 'index'){

    include DISCUZ_ROOT.'./source/plugin/tom_tcpinche/module/index.php';
    
}else{
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcpinche/module/index.php';
    
}
tomoutput();