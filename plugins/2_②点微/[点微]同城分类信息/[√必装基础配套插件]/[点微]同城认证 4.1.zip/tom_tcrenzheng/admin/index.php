<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_tcrenzheng_admin_index_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'info'){
    
    $info = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($_GET['id']);
    $photoList = C::t('#tom_tcrenzheng#tom_tcrenzheng_company_photo')->fetch_all_list(" AND company_id={$info['id']} ", 'ORDER BY id DESC', 0, 100);
    $natureInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_nature')->fetch_by_id($info['nature_id']);
    $industryInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_by_id($info['industry_id']);
    $scaleInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_scale')->fetch_by_id($info['scale_id']);
    
    $fenghao = $Lang['fenghao'];
    
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_info_title'] . '</th></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_name'].$fenghao.'</b></td><td>'.$info['name'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_tel'].$fenghao.'</b></td><td>' . $info['tel'] . '</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_nature'].$fenghao.'</b></td><td>'.$natureInfo['name'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_industry'].$fenghao.'</b></td><td>' . $industryInfo['name'] . '</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_scale'].$fenghao.'</b></td><td>' . $scaleInfo['name'] . '</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_rz_name'].$fenghao.'</b></td><td>' . $info['rz_name'] . '</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_rz_tel'].$fenghao.'</b></td><td>' . $info['rz_tel'] . '</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_address'].$fenghao.'</b></td><td>' . $info['address'] . '</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_content'].$fenghao.'</b></td><td>' . $info['content'] . '</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_picurl'].$fenghao.'</b></td><td><a href="' . tomgetfileurl($info['logo']) . '" target="_blank"><img width="200" src="' . tomgetfileurl($info['logo']) . '"></a><span>'.$Lang['index_click_look_big_pic'].'</span></td><td></td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_business_license'].$fenghao.'</b></td><td><a href="' . tomgetfileurl($info['business_license']) . '" target="_blank"><img width="200" src="' . tomgetfileurl($info['business_license']) . '"></a><span>'.$Lang['index_click_look_big_pic'].'</span></td><td></td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_photolist'].$fenghao.'</b></td><td>';
    foreach($photoList as $key => $value){
        echo '<a href="' . tomgetfileurl($value['picurl']) . '" target="_blank"><img width="200" src="' . tomgetfileurl($value['picurl']) . '"></a>&nbsp;&nbsp;';
    }
    echo '</td><td></td></tr>';
    showtablefooter(); //From: Dism��taobao��com
    
}else if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['first_shenhe']     = 1;
        $insertData['shenhe_status']    = 1;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); //From: Dism��taobao��com
        showformfooter(); //From: Dism_taobao-com
    }
    
}else if($_GET['act'] == 'edit'){
    $companyInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($companyInfo);
        C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->update($companyInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
        __create_info_html($companyInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); //From: Dism��taobao��com
        showformfooter(); //From: Dism_taobao-com
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['first_shenhe']     = 1;
    $updateData['shenhe_status']    = 1;
    C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->update($_GET['id'],$updateData);
    
    $companyInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($companyInfo['user_id']);
    
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')){
        @$r = tom_html_get($_G['siteurl'].'plugin.php?id=tom_tczhaopin:ajax&site='.$site_id.'&act=update_company_status_by_user_id&user_id='.$companyInfo['user_id']);
    }

    $shenhe = str_replace('{NAME}', $companyInfo['name'], $Lang['index_template_company_shenhe_ok']);
    
    $site_id = 1;
    if($tcUserInfo['site_id'] > 0){
        $site_id = $tcUserInfo['site_id'];
    }

    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=index");
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcrenzhengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['renzheng_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['renzheng_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcrenzhengConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $companyInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($companyInfo['user_id']);
        
        $site_id = 1;
        if($tcUserInfo['site_id'] > 0){
            $site_id = $tcUserInfo['site_id'];
        }
        
        $updateData = array();
        $updateData['shenhe_status'] = 3;
        C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->update($_GET['id'],$updateData);
        
        $shenhe = str_replace('{NAME}', $companyInfo['name'], $Lang['index_template_company_shenhe_no']);
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=company");
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcrenzhengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['renzheng_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['renzheng_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcrenzhengConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['renzheng_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
        tomshowsetting(true,array('title'=>$Lang['renzheng_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['renzheng_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); //From: Dism��taobao��com
        showformfooter(); //From: Dism_taobao-com
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->delete_by_id($_GET['id']);
    C::t('#tom_tcrenzheng#tom_tcrenzheng_company_photo')->delete_by_company_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tcrenzheng#tom_tcrenzheng_company_photo')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl.'&act=photo&company_id='.$_GET['company_id'], 'succeed');
    
}else if($_GET['act'] == 'photo'){
    
    $company_id     = intval($_GET['company_id'])>0? intval($_GET['company_id']):0;
    
    if(submitcheck('submit')){
        
        $psort          = isset($_GET['psort'])? intval($_GET['psort']):10;
        $picurl         = tomuploadFile("picurl");
        
        $insertData = array();
        $insertData['company_id']       = $company_id;
        $insertData['picurl']           = $picurl;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcrenzheng#tom_tcrenzheng_company_photo')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl.'&act=photo&company_id='.$company_id, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        tomshownavheader();
        tomshownavli($Lang['index_photo_add'],'',true);
        tomshownavfooter();
        showformheader($modFromUrl.'&act=photo&company_id='.$company_id,'enctype');
        showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
        tomshowsetting(true,array('title'=>$Lang['index_photo'],'name'=>'picurl','value'=>'','msg'=>$Lang['index_photo_msg']),"file");
        showsubmit('submit', 'submit');
        showtablefooter(); //From: Dism��taobao��com
        showformfooter(); //From: Dism_taobao-com
    }
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $companyInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($company_id);
    $count = C::t('#tom_tcrenzheng#tom_tcrenzheng_company_photo')->fetch_all_count(" AND company_id = {$company_id} ");
    $photoList = C::t('#tom_tcrenzheng#tom_tcrenzheng_company_photo')->fetch_all_list(" AND company_id = {$company_id} "," ORDER BY id ASC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&act=photo&site_id={$site_id}";
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    echo '<tr><th colspan="15" class="partition">' .$companyInfo['name'].'&gt;'. $Lang['index_photo_title'] . '</th></tr>';
    showtablefooter(); //From: Dism��taobao��com
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['index_photo'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($photoList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a href="' . tomgetfileurl($value['picurl']) . '" target="_blank"><img height="40" src="' . tomgetfileurl($value['picurl']) . '"></a></td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&company_id='.$company_id.'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); //From: Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}else{
    
    set_list_url("tom_tcrenzheng_admin_index_list");
    
    $keyword            = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $credit_code        = isset($_GET['credit_code'])? addslashes($_GET['credit_code']):'';
    $rz_tel             = isset($_GET['rz_tel'])? addslashes($_GET['rz_tel']):'';
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if($user_id > 0){
        $where.= " AND user_id={$user_id} ";
    }
    if(!empty($credit_code)){
        $where.= " AND credit_code={$credit_code} ";
    }
    if(!empty($rz_tel)){
        $where.= " AND rz_tel={$rz_tel} ";
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    
    $order = "ORDER BY id DESC";
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_count($where,$keyword);
    $companyList  = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_list($where,$order,$start,$pagesize,$keyword);

    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    $Lang['index_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_1']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); //From: Dism��taobao��com

    $modBasePageUrl = $modBaseUrl."&credit_code={$credit_code}&keyword={$keyword}&rz_tel={$rz_tel}&credit_code={$credit_code}&shenhe_status={$shenhe_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    $keywordStr = '<tr><td width="100" align="right"><b>'.$Lang['index_search_keyword'].'</b></td>';
    $keywordStr.= '<td><input style="width:260px" type="text" value="'.$keyword.'" name="keyword"></td></tr>';
    echo $keywordStr;
    
    $userStr = '<tr><td width="100" align="right"><b>'.$Lang['search_user_id'].'</b></td>';
    $userStr.= '<td><input style="width:260px" type="text" value="'.$user_id.'" name="user_id"></td></tr>';
    echo $userStr;
    
    $creditCodeStr = '<tr><td width="100" align="right"><b>'.$Lang['index_credit_code'].'</b></td>';
    $creditCodeStr.= '<td><input style="width:260px" type="text" value="'.$credit_code.'" name="credit_code"></td></tr>';
    echo $creditCodeStr;
    
    $rzTelStr = '<tr><td width="100" align="right"><b>'.$Lang['index_rz_tel'].'</b></td>';
    $rzTelStr.= '<td><input style="width:260px" type="text" value="'.$rz_tel.'" name="rz_tel"></td></tr>';
    echo $rzTelStr;
    
    $status_shenhe_1 = $status_shenhe_2 = $status_shenhe_3 = '';
    if($shenhe_status == 1){
        $status_shenhe_1 = 'selected';
    }else if($shenhe_status == 2){
        $status_shenhe_2 = 'selected';
    }else if($shenhe_status == 3){
        $status_shenhe_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['index_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$status_shenhe_1.'>'.$Lang['index_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$status_shenhe_2.'>'.$Lang['index_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$status_shenhe_3.'>'.$Lang['index_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); //From: Dism��taobao��com
    showformfooter(); //From: Dism_taobao-com
    
    __create_nav_html();
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    echo '<tr class="header">';
    echo '<th style="width: 60px;"> ID </th>';
    echo '<th>' . $Lang['index_user_id'] . '</th>';
    echo '<th >' . $Lang['index_picurl'] . '</th>';
    echo '<th style="width: 150px;">' . $Lang['index_name'] . '</th>';
    echo '<th>' . $Lang['index_nature'] . '</th>';
    echo '<th >' . $Lang['index_industry'] . '</th>';
    echo '<th >' . $Lang['index_scale'] . '</th>';
    echo '<th >' . $Lang['index_address'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['index_shenhe_status'] . '</th>';
    echo '<th >' . $Lang['handle'] . '</th>';
    echo '</tr>';
    $i = 1;
    foreach ($companyList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $natureInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_nature')->fetch_by_id($value['nature_id']);
        $industryInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_by_id($value['industry_id']);
        $scaleInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_scale')->fetch_by_id($value['scale_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'].'<font color="#f00">(ID:' .$value['user_id']. ')</font></td>';
        echo '<td><a href="'.tomgetfileurl($value['logo']).'" target="_blank"><img width="50px;" src="' . tomgetfileurl($value['logo']) . '"></a></td>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $natureInfo['name'] . '</td>';
        echo '<td>' . $industryInfo['name'] . '</td>';
        echo '<td>' . $scaleInfo['name'] . '</td>';
        echo '<td>' . $value['address'] . '</td>';
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shenhe_status_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shenhe_status_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['index_shenhe_status_1']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 2 ){
            echo '<td><font color="#f70404">' . $Lang['index_shenhe_status_2']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 3 ){
            echo '<td><font color="#f70404">' . $Lang['index_shenhe_status_3']. '</font>'.$sheheBtnStr.'</td>';
        }else{
            echo '<td> -- </td>';
        }
        
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'" target="_blank">' . $Lang['info']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=photo&company_id='.$value['id'].'" target="_blank">' . $Lang['index_photo_title']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'" target="_blank">' . $Lang['edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a><br/>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); //From: Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $nature_id      = intval($_GET['nature_id'])>0? intval($_GET['nature_id']):0;
    $industry_id    = intval($_GET['industry_id'])>0? intval($_GET['industry_id']):0;
    $scale_id       = intval($_GET['scale_id'])>0? intval($_GET['scale_id']):0;
    $credit_code    = isset($_GET['credit_code'])? addslashes($_GET['credit_code']):'';
    $rz_name        = isset($_GET['rz_name'])? addslashes($_GET['rz_name']):'';
    $rz_tel         = isset($_GET['rz_tel'])? addslashes($_GET['rz_tel']):'';
    $address        = isset($_GET['address'])? addslashes($_GET['address']):'';
    $content        = isset($_GET['content'])? addslashes($_GET['content']):'';

    $business_license = $logo = "";
    if($_GET['act'] == 'add'){
        $logo               = tomuploadFile("logo");
        $business_license   = tomuploadFile("business_license");
    }else if($_GET['act'] == 'edit'){
        $logo               = tomuploadFile("logo",$infoArr['logo']);
        $business_license   = tomuploadFile("business_license",$infoArr['business_license']);
    }
    
    $data['user_id']            = $user_id;
    $data['name']               = $name;
    $data['tel']                = $tel;
    $data['nature_id']          = $nature_id;
    $data['industry_id']        = $industry_id;
    $data['scale_id']           = $scale_id;
    $data['credit_code']        = $credit_code;
    $data['rz_name']            = $rz_name;
    $data['rz_tel']             = $rz_tel;
    $data['address']            = $address;
    $data['content']            = $content;
    $data['logo']               = $logo;
    $data['business_license']   = $business_license;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'user_id'           => '',
        'name'              => '',
        'tel'               => '',
        'nature_id'         => 0,
        'industry_id'       => 0,
        'scale_id'          => 0,
        'business_license'  => '',
        'credit_code'       => '',
        'rz_name'           => '',
        'rz_tel'            => '',
        'logo'              => '',
        'address'           => '',
        'content'           => '',
    );
    $options = array_merge($options, $infoArr);
    
    $natureListTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_nature')->fetch_all_list('', 'ORDER BY nsort ASC,id DESC');
    $natureList = array();
    if(is_array($natureListTmp) && !empty($natureListTmp)){
        foreach($natureListTmp as $key => $value){
            $natureList[$value['id']] = $value['name'];
        }
    }
    $industryListTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_all_list('', 'ORDER BY isort ASC,id DESC');
    $industryList = array();
    if(is_array($industryListTmp) && !empty($industryListTmp)){
        foreach($industryListTmp as $key => $value){
            $industryList[$value['id']] = $value['name'];
        }
    }
    $scaleListTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_scale')->fetch_all_list('', 'ORDER BY ssort ASC,id DESC');
    $scaleList = array();
    if(is_array($scaleListTmp) && !empty($scaleListTmp)){
        foreach($scaleListTmp as $key => $value){
            $scaleList[$value['id']] = $value['name'];
        }
    }
    
    tomshowsetting(true,array('title'=>$Lang['index_user_id'].'ID','name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['index_user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['index_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_picurl'],'name'=>'logo','value'=>$options['logo'],'msg'=>$Lang['index_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_tel'],'name'=>'tel','value'=>$options['tel'],'msg'=>$Lang['index_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_nature'],'name'=>'nature_id','value'=>$options['nature_id'],'msg'=>$Lang['index_nature_msg'],item=>$natureList),"select");
    tomshowsetting(true,array('title'=>$Lang['index_industry'],'name'=>'industry_id','value'=>$options['industry_id'],'msg'=>$Lang['index_industry_msg'],item=>$industryList),"select");
    tomshowsetting(true,array('title'=>$Lang['index_scale'],'name'=>'scale_id','value'=>$options['scale_id'],'msg'=>$Lang['index_scale_msg'],item=>$scaleList),"select");
    tomshowsetting(true,array('title'=>$Lang['index_business_license'],'name'=>'business_license','value'=>$options['business_license'],'msg'=>$Lang['index_business_license_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_credit_code'],'name'=>'credit_code','value'=>$options['credit_code'],'msg'=>$Lang['index_credit_code_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_rz_name'],'name'=>'rz_name','value'=>$options['rz_name'],'msg'=>$Lang['index_rz_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_rz_tel'],'name'=>'rz_tel','value'=>$options['rz_tel'],'msg'=>$Lang['index_rz_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['index_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['index_content_msg']),"textarea");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'info'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_info'],"",true);
    }else if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',false);
        tomshownavli($Lang['edit'],$modBaseUrl.'&act=edit',true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',false);
    }
    tomshownavfooter();
}