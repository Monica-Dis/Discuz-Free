<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=personal';
$modListUrl = $adminListUrl.'&tmod=personal';
$modFromUrl = $adminFromUrl.'&tmod=personal';

$get_list_url_value = get_list_url("tom_tcrenzheng_admin_personal_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'info'){
    
    $info = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_id($_GET['id']);
    
    $fenghao = $Lang['fenghao'];
    
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_info_title'] . '</th></tr>';
    echo '<tr><td align="right"><b>'.$Lang['personal_rz_name'].$fenghao.'</b></td><td>'.$info['rz_name'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['personal_rz_tel'].$fenghao.'</b></td><td>'.$info['rz_tel'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['personal_card_number'].$fenghao.'</b></td><td>'.$info['card_number'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['personal_rz_desc'].$fenghao.'</b></td><td>'.$info['rz_desc'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['personal_card'].$fenghao.'</b></td><td><a href="' . tomgetfileurl($info['card_shou']) . '" target="_blank"><img width="200" src="' . tomgetfileurl($info['card_shou']) . '"></a><span>'.$Lang['index_click_look_big_pic'].'</span></td><td></td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['personal_card_zheng'].$fenghao.'</b></td><td><a href="' . tomgetfileurl($info['card_zheng']) . '" target="_blank"><img width="200" src="' . tomgetfileurl($info['card_zheng']) . '"></a><span>'.$Lang['index_click_look_big_pic'].'</span></td><td></td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['personal_card_fan'].$fenghao.'</b></td><td><a href="' . tomgetfileurl($info['card_fan']) . '" target="_blank"><img width="200" src="' . tomgetfileurl($info['card_fan']) . '"></a><span>'.$Lang['index_click_look_big_pic'].'</span></td><td></td></tr>';
    showtablefooter(); //From: Dism��taobao��com
    
}else if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['shenhe_status']    = 1;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); //From: Dism��taobao��com
        showformfooter(); //From: Dism_taobao-com
    }
    
}else if($_GET['act'] == 'edit'){
    $personalInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($personalInfo);
        C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->update($personalInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
        __create_info_html($personalInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); //From: Dism��taobao��com
        showformfooter(); //From: Dism_taobao-com
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status']     = 1;
    C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->update($_GET['id'],$updateData);

    $personalInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($personalInfo['user_id']);
    
    $site_id = 1;
    if($tcUserInfo['site_id'] > 0){
        $site_id = $tcUserInfo['site_id'];
    }

    $shenhe = $Lang['index_template_personal_shenhe_ok'];

    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=index");
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcrenzhengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['renzheng_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['renzheng_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcrenzhengConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $personalInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($personalInfo['user_id']);
        
        $site_id = 1;
        if($tcUserInfo['site_id'] > 0){
            $site_id = $tcUserInfo['site_id'];
        }
        
        $updateData = array();
        $updateData['shenhe_status'] = 3;
        C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->update($_GET['id'],$updateData);
        
        $shenhe = $Lang['index_template_personal_shenhe_no'];
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=personal");
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcrenzhengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['renzheng_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['renzheng_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcrenzhengConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['renzheng_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
        tomshowsetting(true,array('title'=>$Lang['renzheng_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['renzheng_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); //From: Dism��taobao��com
        showformfooter(); //From: Dism_taobao-com
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_tcrenzheng_admin_personal_list");
    
    $keyword            = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $rz_tel             = isset($_GET['rz_tel'])? addslashes($_GET['rz_tel']):'';
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if($user_id > 0){
        $where.= " AND user_id={$user_id} ";
    }
    if(!empty($rz_tel)){
        $where.= " AND rz_tel={$rz_tel} ";
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    
    $order = "ORDER BY add_time DESC,id DESC";
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_all_count($where,$keyword);
    $personalList  = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_all_list($where,$order,$start,$pagesize,$keyword);

    $modBasePageUrl = $modBaseUrl."&keyword={$keyword}&rz_tel={$rz_tel}&shenhe_status={$shenhe_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    $keywordStr = '<tr><td width="100" align="right"><b>'.$Lang['personal_search_keyword'].'</b></td>';
    $keywordStr.= '<td><input style="width:260px" type="text" value="'.$keyword.'" name="keyword"></td></tr>';
    echo $keywordStr;
    
    $userStr = '<tr><td width="100" align="right"><b>'.$Lang['search_user_id'].'</b></td>';
    $userStr.= '<td><input style="width:260px" type="text" value="'.$user_id.'" name="user_id"></td></tr>';
    echo $userStr;
    
    $rzTelStr = '<tr><td width="100" align="right"><b>'.$Lang['index_rz_tel'].'</b></td>';
    $rzTelStr.= '<td><input style="width:260px" type="text" value="'.$rz_tel.'" name="rz_tel"></td></tr>';
    echo $rzTelStr;
    
    $status_shenhe_1 = $status_shenhe_2 = $status_shenhe_3 = '';
    if($shenhe_status == 1){
        $status_shenhe_1 = 'selected';
    }else if($shenhe_status == 2){
        $status_shenhe_2 = 'selected';
    }else if($shenhe_status == 3){
        $status_shenhe_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['index_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$status_shenhe_1.'>'.$Lang['index_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$status_shenhe_2.'>'.$Lang['index_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$status_shenhe_3.'>'.$Lang['index_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); //From: Dism��taobao��com
    showformfooter(); //From: Dism_taobao-com
    
    __create_nav_html();
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    echo '<tr class="header">';
    echo '<th style="width: 60px;"> ID </th>';
    echo '<th>' . $Lang['index_user_id'] . '</th>';
    echo '<th>' . $Lang['personal_rz_name'] . '</th>';
    echo '<th>' . $Lang['personal_rz_tel'] . '</th>';
    echo '<th>' . $Lang['personal_card_number'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['personal_rz_desc'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['index_shenhe_status'] . '</th>';
    echo '<th >' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($personalList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'].'<font color="#f00">(ID:' .$value['user_id']. ')</font></td>';
        echo '<td>' . $value['rz_name'] . '</td>';
        echo '<td>' . $value['rz_tel'] . '</td>';
        echo '<td>' . $value['card_number'] . '</td>';
        echo '<td>' . $value['rz_desc'] . '</td>';
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shenhe_status_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shenhe_status_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['index_shenhe_status_1']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 2 ){
            echo '<td><font color="#f70404">' . $Lang['index_shenhe_status_2']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 3 ){
            echo '<td><font color="#f70404">' . $Lang['index_shenhe_status_3']. '</font>'.$sheheBtnStr.'</td>';
        }else{
            echo '<td> -- </td>';
        }
        
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'" target="_blank">' . $Lang['info']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'" target="_blank">' . $Lang['edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a><br/>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); //From: Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $rz_name        = isset($_GET['rz_name'])? addslashes($_GET['rz_name']):'';
    $rz_tel         = isset($_GET['rz_tel'])? addslashes($_GET['rz_tel']):'';
    $card_number    = isset($_GET['card_number'])? addslashes($_GET['card_number']):'';
    $rz_desc        = isset($_GET['rz_desc'])? addslashes($_GET['rz_desc']):'';

    $card_shou = $card_zheng = $card_fan = "";
    if($_GET['act'] == 'add'){
        $card_shou      = tomuploadFile("card_shou");
        $card_zheng     = tomuploadFile("card_zheng");
        $card_fan       = tomuploadFile("card_fan");
    }else if($_GET['act'] == 'edit'){
        $card_shou      = tomuploadFile("card_shou",$infoArr['card_shou']);
        $card_zheng     = tomuploadFile("card_zheng",$infoArr['card_zheng']);
        $card_fan       = tomuploadFile("card_fan",$infoArr['card_fan']);
    }
    
    $data['user_id']            = $user_id;
    $data['rz_name']            = $rz_name;
    $data['rz_tel']             = $rz_tel;
    $data['card_number']        = $card_number;
    $data['card_shou']          = $card_shou;
    $data['card_zheng']         = $card_zheng;
    $data['card_fan']           = $card_fan;
    $data['rz_desc']            = $rz_desc;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'user_id'           => 0,
        'rz_name'           => '',
        'rz_tel'            => '',
        'card_number'       => '',
        'card_shou'         => '',
        'card_zheng'        => '',
        'card_fan'          => '',
        'rz_desc'           => '',
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['index_user_id'].'ID','name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['index_user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['personal_rz_name'],'name'=>'rz_name','value'=>$options['rz_name'],'msg'=>$Lang['personal_rz_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['personal_rz_tel'],'name'=>'rz_tel','value'=>$options['rz_tel'],'msg'=>$Lang['personal_rz_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['personal_card_number'],'name'=>'card_number','value'=>$options['card_number'],'msg'=>$Lang['personal_card_number_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['personal_card'],'name'=>'card_shou','value'=>$options['card_shou'],'msg'=>$Lang['personal_card_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['personal_card_zheng'],'name'=>'card_zheng','value'=>$options['card_zheng'],'msg'=>$Lang['personal_card_zheng_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['personal_card_fan'],'name'=>'card_fan','value'=>$options['card_fan'],'msg'=>$Lang['personal_card_fan_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['personal_rz_desc'],'name'=>'rz_desc','value'=>$options['rz_desc'],'msg'=>$Lang['personal_rz_desc_msg']),"textarea");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'info'){
        tomshownavli($Lang['personal_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['personal_add'],"",true);
    }else if($_GET['act'] == 'add'){
        tomshownavli($Lang['personal_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['personal_add'],$modBaseUrl.'&act=add',true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['personal_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['personal_add'],$modBaseUrl.'&act=add',false);
        tomshownavli($Lang['edit'],$modBaseUrl.'&act=edit',true);
    }else{
        tomshownavli($Lang['personal_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['personal_add'],$modBaseUrl.'&act=add',false);
    }
    tomshownavfooter();
}