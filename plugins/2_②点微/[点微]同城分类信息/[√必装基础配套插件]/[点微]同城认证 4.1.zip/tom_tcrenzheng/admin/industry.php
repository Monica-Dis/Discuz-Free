<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=industry';
$modListUrl = $adminListUrl.'&tmod=industry';
$modFromUrl = $adminFromUrl.'&tmod=industry';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); //From: Dism��taobao��com
        showformfooter(); //From: Dism_taobao-com
    }
    
}else if($_GET['act'] == 'edit'){
    $industryInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($industryInfo);
        C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->update($industryInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
        __create_info_html($industryInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); //From: Dism��taobao��com
        showformfooter(); //From: Dism_taobao-com
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'import'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/config/import.data.php';
    
    foreach ($industryArray as $key => $value){
        $insertData = array();
        $insertData['name']     = $value;
        $insertData['isort']    = $key;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->insert($insertData);
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=import&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['industry_import'].'</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter(); //From: Dism��taobao��com
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $industryList = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_all_list(" "," ORDER BY isort ASC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    echo '<tr class="header">';
    echo '<th>' . $Lang['industry_name'] . '</th>';
    echo '<th>' . $Lang['industry_isort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($industryList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['isort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); //From: Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function import_confirm(url){
  var r = confirm("{$Lang['industry_import_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;

}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name        = isset($_GET['name'])? addslashes($_GET['name']):'';
    $isort       = isset($_GET['isort'])? intval($_GET['isort']):10;

    $data['name']       = $name;
    $data['isort']      = $isort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'           => '',
        'isort'          => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['industry_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['industry_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['paixu'],'name'=>'isort','value'=>$options['isort'],'msg'=>$Lang['industry_isort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['industry_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['industry_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['industry_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['industry_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['industry_edit'],"",true);
    }else{
        tomshownavli($Lang['industry_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['industry_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}