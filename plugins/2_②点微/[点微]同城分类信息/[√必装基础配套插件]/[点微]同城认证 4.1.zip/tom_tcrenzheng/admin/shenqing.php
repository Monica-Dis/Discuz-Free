<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=shenqing';
$modListUrl = $adminListUrl.'&tmod=shenqing';
$modFromUrl = $adminFromUrl.'&tmod=shenqing';

if($_GET['act'] == 'shenhe_ok' && $_GET['formhash'] == FORMHASH){
    
    $shenqingInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_shenqing')->fetch_by_id($_GET['id']);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($shenqingInfo['user_id']);
    
    $updateData = array();
    $updateData['shenhe_status'] = 1;
    C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_shenqing')->update($_GET['id'], $updateData);
    
    DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$shenqingInfo['money']} WHERE id='{$userInfo['id']}'", 'UNBUFFERED');

    $insertData = array();
    $insertData['user_id']          = $userInfo['id'];
    $insertData['type_id']          = 2;
    $insertData['change_money']     = $shenqingInfo['money'];
    $insertData['old_money']        = $userInfo['money'];
    $insertData['tag']              = lang('plugin/tom_tcrenzheng', 'shenqing_tag');
    $insertData['beizu']            = '';
    $insertData['log_time']         = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
    
    $templateSms = str_replace('{MONEY}', $shenqingInfo['money'], $Lang['shenqing_template_shenhe_ok']);

    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($userInfo['openid']) && !empty($tongchengConfig['template_id'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site=1&mod=money");
        $smsData = array(
            'first'         => $templateSms,
            'keyword1'      => lang('plugin/tom_tcrenzheng', 'shenqing_template_shenhe_title'),
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
    }
    
    $insertData = array();
    $insertData['user_id']      = $userInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.lang('plugin/tom_tcrenzheng', 'shenqing_template_shenhe_title').'</font><br/>'.$templateSms.'<br/><a href="'.$_G['siteurl'].'plugin.php?id=tom_tongcheng&site=1&mod=money">'.$Lang['shenqing_template_shenhe_ok_btn'].'</a><br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['act'] == 'shenhe_ok2' && $_GET['formhash'] == FORMHASH){
    
    $updateData = array();
    $updateData['shenhe_status'] = 1;
    C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_shenqing')->update($_GET['id'], $updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if($user_id > 0){
        $where.= " AND user_id={$user_id} ";
    }
    if($shenhe_status > 0){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_shenqing')->fetch_all_count($where);
    $shenqingList = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_shenqing')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&shenhe_status={$shenhe_status}";
    
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['shenqing_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); //From: Dism��taobao��com
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    
    $userStr = '<tr><td width="100" align="right"><b>'.$Lang['search_user_id'].'</b></td>';
    $userStr.= '<td><input style="width:260px" type="text" value="'.$user_id.'" name="user_id"></td></tr>';
    echo $userStr;
    
    $shenhe_status_1 = $shenhe_status_2 = '';
    if($shenhe_status == 1){
        $shenhe_status_1 = 'selected';
    }else if($shenhe_status == 2){
        $shenhe_status_2 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['shenqing_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="order_status" id="order_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$shenhe_status_1.'>'.$Lang['shenqing_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$shenhe_status_2.'>'.$Lang['shenqing_shenhe_status_2'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); //From: Dism��taobao��com
    showformfooter(); //From: Dism_taobao-com
    
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['shenqing_user_id'] . '</th>';
    echo '<th>' . $Lang['shenqing_value'] . '</th>';
    echo '<th>' . $Lang['shenqing_shenhe_status'] . '</th>';
    echo '<th>' . $Lang['shenqing_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($shenqingList as $key => $value) {
        
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f00">(ID:'.$value['user_id'].')</font></td>';
        echo '<td>' . $value['money'] . '</td>';
        if($value['shenhe_status'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['shenqing_shenhe_status_1'] . '</font></td>';
        }else if($value['shenhe_status'] == 2){
            echo '<td><font color="#f70404">' . $Lang['shenqing_shenhe_status_2'] . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset). '</td>';
        
        echo '<td>';
        if($value['shenhe_status'] == 2){
            echo '<a href="javascript:void(0);" onclick="shenhe_confirm(\''.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['shenqing_shenhe_btn_1']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
            echo '<a href="javascript:void(0);" onclick="shenhe_confirm2(\''.$modBaseUrl.'&act=shenhe_ok2&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['shenqing_shenhe_btn_2']. '</a>';
        }else{
            echo '--';
        }
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); //From: Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script>
function shenhe_confirm(url){
  var r = confirm("{$Lang['shenqing_ok_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function shenhe_confirm2(url){
  var r = confirm("{$Lang['shenqing_ok2_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}