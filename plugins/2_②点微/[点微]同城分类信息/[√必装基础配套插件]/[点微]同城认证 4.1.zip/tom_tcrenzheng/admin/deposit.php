<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=deposit';
$modListUrl = $adminListUrl.'&tmod=deposit';
$modFromUrl = $adminFromUrl.'&tmod=deposit';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $addData = __get_post_data();
        
        $depositInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->fetch_by_user_id($addData['user_id']);
        if(is_array($depositInfo) && !empty($depositInfo)){
            cpmsg($Lang['deposit_error'], $modListUrl, 'error');exit;
        }
        
        $insertData = array();
        $insertData = $addData;
        $insertData['is_admin']     = 1;
        $insertData['order_time']   = TIMESTAMP;
        if(C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->insert($insertData)){
            $deposit_id = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->insert_id();
            
            $insertData = array();
            $insertData['deposit_id']       = $deposit_id;
            $insertData['deposit_type']     = $addData['type'];
            $insertData['type']             = 1;
            $insertData['old_value']        = 0;
            $insertData['change_value']     = $addData['deposit'];
            $insertData['is_admin']         = 1;
            $insertData['add_time']         = TIMESTAMP;
            C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_log')->insert($insertData);
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); //From: Dism��taobao��com
        showformfooter(); //From: Dism_taobao-com
    }
    
}else if($_GET['act'] == 'edit'){
    $depositInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($depositInfo);
        if(C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->update($depositInfo['id'],$updateData) && $depositInfo['deposit'] != $updateData['deposit']){

            $insertData = array();
            $insertData['deposit_id']       = $depositInfo['id'];
            $insertData['deposit_type']     = $updateData['type'];
            $insertData['type']             = 3;
            $insertData['old_value']        = $depositInfo['deposit'];
            $insertData['change_value']     = $updateData['deposit'];
            $insertData['is_admin']         = 1;
            $insertData['add_time']         = TIMESTAMP;
            C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_log')->insert($insertData);
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
        __create_info_html($depositInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); //From: Dism��taobao��com
        showformfooter(); //From: Dism_taobao-com
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'blocked_status_1'){

    $updateData = array();
    $updateData['blocked_status'] = 1;
    C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'blocked_status_0'){

    $updateData = array();
    $updateData['blocked_status'] = 0;
    C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    $depositInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->fetch_by_id($_GET['id']);
    
    if($depositInfo['order_status'] != 2){
        C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->delete_by_id($_GET['id']);
        C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_log')->delete_by_deposit_id($_GET['id']);
        C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_shenqing')->delete_by_deposit_id($_GET['id']);
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['act'] == 'deposit_log'){
    
    $deposit_id = intval($_GET['deposit_id'])>0? intval($_GET['deposit_id']):0;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $depositInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->fetch_by_id($deposit_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($depositInfo['user_id']);
    
    $modDepositBaseUrl = $modBaseUrl."&act=deposit_log&deposit_id={$deposit_id}";
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_log')->fetch_all_count(" AND deposit_id = {$depositInfo['id']} ");
    $logList = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_log')->fetch_all_list(" AND deposit_id = {$depositInfo['id']} "," ORDER BY add_time DESC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    echo '<tr><th colspan="15" class="partition">'.$userInfo['nickname'].'&nbsp;&gt;&gt;&nbsp;'. $Lang['deposit_log_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['deposit_type'] . '</th>';
    echo '<th>' . $Lang['deposit_log_type'] . '</th>';
    echo '<th>' . $Lang['deposit_log_value'] . '</th>';
    echo '<th>' . $Lang['deposit_log_change_value'] . '</th>';
    echo '<th>' . $Lang['deposit_is_admin'] . '</th>';
    echo '<th>' . $Lang['deposit_log_add_time'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($logList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['type'] == 1){
            echo '<td>' . $Lang['deposit_log_type_1'] . '</td>';
        }else if($value['type'] == 2){
            echo '<td>' . $Lang['deposit_log_type_2'] . '</td>';
        }else if($value['type'] == 3){
            echo '<td>' . $Lang['deposit_log_type_3'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['deposit_type'] == 1){
            echo '<td>' . $Lang['deposit_type_1'] . '</td>';
        }else if($value['deposit_type'] == 2){
            echo '<td>' . $Lang['deposit_type_2'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $value['old_value'] . '</td>';
        echo '<td>' . $value['change_value'] . '</td>';
        if($value['is_admin'] == 1){
            echo '<td>' . $Lang['deposit_is_admin_1'] . '</td>';
        }else{
            echo '<td>' . $Lang['deposit_is_admin_0'] . '</td>';
        }
        echo '<td>' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset). '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); //From: Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modDepositBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $order_status   = intval($_GET['order_status'])>0? intval($_GET['order_status']):0;
    
    $where = "";
    if($user_id > 0){
        $where.= " AND user_id={$user_id} ";
    }
    if($order_status > 0){
        $where.= " AND order_status={$order_status} ";
    }
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->fetch_all_count($where);
    $depositList = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->fetch_all_list($where," ORDER BY order_time DESC,id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&order_status={$order_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    
    $userStr = '<tr><td width="100" align="right"><b>'.$Lang['search_user_id'].'</b></td>';
    $userStr.= '<td><input style="width:260px" type="text" value="'.$user_id.'" name="user_id"></td></tr>';
    echo $userStr;
    
    $order_status_1 = $order_status_2 = $order_status_3 = '';
    if($order_status == 1){
        $order_status_1 = 'selected';
    }else if($order_status == 2){
        $order_status_2 = 'selected';
    }else if($order_status == 3){
        $order_status_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['deposit_order_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="order_status" id="order_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$order_status_1.'>'.$Lang['deposit_order_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$order_status_2.'>'.$Lang['deposit_order_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$order_status_3.'>'.$Lang['deposit_order_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); //From: Dism��taobao��com
    showformfooter(); //From: Dism_taobao-com
    
    $depositMoney = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->fetch_deposit_sum(" AND order_status = 2 ");
    $depositMoney4 = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->fetch_deposit_sum(" AND order_status = 2 AND blocked_status = 1 ");
    echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
    echo $Lang['deposit_all_deposit'].'<font color="#fd0d0d">('.floatval($depositMoney).')</font>&nbsp;&nbsp;';
    echo $Lang['deposit_all_dongjie_deposit'].'<font color="#fd0d0d">('.floatval($depositMoney4).')</font>&nbsp;&nbsp;';
    echo '</div>';
    
    __create_nav_html();
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['deposit_order_no'] . '</th>';
    echo '<th>' . $Lang['deposit_user_id'] . '</th>';
    echo '<th>' . $Lang['deposit_type'] . '</th>';
    echo '<th>' . $Lang['deposit_deposit'] . '</th>';
    echo '<th>' . $Lang['deposit_blocked_status'] . '</th>';
    echo '<th>' . $Lang['deposit_order_status'] . '</th>';
    echo '<th>' . $Lang['deposit_is_admin'] . '</th>';
    echo '<th>' . $Lang['deposit_order_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($depositList as $key => $value) {
        
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $value['order_no'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f00">(ID:'.$value['user_id'].')</font></td>';
        if($value['type'] == 1){
            echo '<td>' . $Lang['deposit_type_1'] . '</td>';
        }else if($value['type'] == 2){
            echo '<td>' . $Lang['deposit_type_2'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td><font color="#f00">' . $value['deposit'] . '</font>&nbsp;<a href="'.$modBaseUrl.'&act=deposit_log&deposit_id='.$value['id'].'&formhash='.FORMHASH.'">(' . $Lang['deposit_log_title']. ')</a></td>';
        
        if($value['blocked_status'] == 1 ){
            echo '<td><font color="#f70404">' . $Lang['deposit_blocked_status_1']. '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=blocked_status_0&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['deposit_blocked_status_0']. ')</a></td>';
        }else{
            echo '<td><font color="#0a9409">' . $Lang['deposit_blocked_status_0']. '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=blocked_status_1&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['deposit_blocked_status_1']. ')</a></td>';
        }
        
        if($value['order_status'] == 1){
            echo '<td><font color="#f70404">' . $Lang['deposit_order_status_1'] . '</font></td>';
        }else if($value['order_status'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['deposit_order_status_2'] . '</font></td>';
        }else if($value['order_status'] == 3){
            echo '<td><font color="#f70404">' . $Lang['deposit_order_status_3'] . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['is_admin'] == 1){
            echo '<td>' . $Lang['deposit_is_admin_1'] . '</td>';
        }else{
            echo '<td>' . $Lang['deposit_is_admin_0'] . '</td>';
        }
        echo '<td>' . dgmdate($value['order_time'], 'Y-m-d H:i:s',$tomSysOffset). '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>';
        if($value['order_status'] != 2){
            echo '&nbsp;|&nbsp;<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        }
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); //From: Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script>
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $type           = isset($_GET['type'])? intval($_GET['type']):0;
    $company_id     = isset($_GET['company_id'])? intval($_GET['company_id']):0;
    $personal_id    = isset($_GET['personal_id'])? intval($_GET['personal_id']):0;
    $deposit        = isset($_GET['deposit'])? floatval($_GET['deposit']):0.00;
    $order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;

    $data['user_id']        = $user_id;
    $data['type']           = $type;
    $data['company_id']     = $company_id;
    $data['personal_id']    = $personal_id;
    $data['deposit']        = $deposit;
    $data['order_status']   = $order_status;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'user_id'           => 0,
        'type'              => 1,
        'company_id'        => 0,
        'personal_id'       => 0,
        'deposit'           => 0.00,
        'order_status'      => 0,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>'UID','name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['deposit_user_id_msg']),"input");
    $deposit_type_item = array(1=>$Lang['deposit_type_1'],2=>$Lang['deposit_type_2']);
    tomshowsetting(true,array('title'=>$Lang['deposit_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['deposit_type_msg'],'item'=>$deposit_type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['deposit_company_id'],'name'=>'company_id','value'=>$options['company_id'],'msg'=>$Lang['deposit_company_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['deposit_personal_id'],'name'=>'personal_id','value'=>$options['personal_id'],'msg'=>$Lang['deposit_personal_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['deposit_deposit'],'name'=>'deposit','value'=>$options['deposit'],'msg'=>$Lang['deposit_deposit_msg']),"input");
    $deposit_order_status_item = array(1=>$Lang['deposit_order_status_1'],2=>$Lang['deposit_order_status_2'],3=>$Lang['deposit_order_status_3']);
    tomshowsetting(true,array('title'=>$Lang['deposit_order_status'],'name'=>'order_status','value'=>$options['order_status'],'msg'=>$Lang['deposit_order_status_msg'],'item'=>$deposit_order_status_item),"radio");

    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['deposit_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['deposit_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['deposit_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['deposit_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['deposit_edit'],"",true);
    }else if($_GET['act'] == 'deposit_log'){
        tomshownavli($Lang['deposit_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['deposit_add'],$modBaseUrl."&act=add",false);
    }else{
        tomshownavli($Lang['deposit_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['deposit_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}