<?php

/*
   Ӧ�ø���֧�֣�https://dism.taobao.com
   ���²����http://t.cn/Aiux1Jx1
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tcrenzhengConfig   = $_G['cache']['plugin']['tom_tcrenzheng'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset       = getglobal('setting/timeoffset');
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass        = new weixinClass($appid,$appsecret);

$depositInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->fetch_by_order_no($order_no);
if($depositInfo && $depositInfo['order_status'] == 1){
    
    $updateData = array();
    $updateData['order_status'] = 2;
    $updateData['pay_time']     = TIMESTAMP;
    C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->update($depositInfo['id'],$updateData);
    
    $insertData = array();
    $insertData['deposit_id']       = $depositInfo['id'];
    $insertData['deposit_type']     = $depositInfo['type'];
    $insertData['type']             = 1;
    $insertData['old_value']        = 0;
    $insertData['change_value']     = $depositInfo['pay_price'];
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_log')->insert($insertData);
    
    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($depositInfo['order_no'])));

    if(!empty($tongchengConfig['template_id'])){
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($manageUserInfo['openid'])){
            
            $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($depositInfo['user_id']);
            
            if($depositInfo['type'] == 1){
                $templateSms = lang('plugin/tom_tcrenzheng', 'paynotify_deposit_type_1');
            }else if($depositInfo['type'] == 2){
                $templateSms = lang('plugin/tom_tcrenzheng', 'paynotify_deposit_type_2');
            }

            $templateSms = str_replace('{NAME}', $userInfo['nickname'], $templateSms);
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site=1&mod=index");
            $smsData = array(
                'first'         => $templateSms,
                'keyword1'      => $tcrenzhengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
        
        $rzManageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcrenzhengConfig['rzmanage_user_id']);
        if($access_token && !empty($rzManageUserInfo['openid'])){
            
            $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($depositInfo['user_id']);
            
            if($depositInfo['type'] == 1){
                $templateSms = lang('plugin/tom_tcrenzheng', 'paynotify_deposit_type_1');
            }else if($depositInfo['type'] == 2){
                $templateSms = lang('plugin/tom_tcrenzheng', 'paynotify_deposit_type_2');
            }

            $templateSms = str_replace('{NAME}', $userInfo['nickname'], $templateSms);
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site=1&mod=index");
            $smsData = array(
                'first'         => $templateSms,
                'keyword1'      => $tcrenzhengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($rzManageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
}