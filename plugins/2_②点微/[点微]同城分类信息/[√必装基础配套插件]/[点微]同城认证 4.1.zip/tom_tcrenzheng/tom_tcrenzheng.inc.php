<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH; //D IS M.TA OBAO.C OM
$tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = "20210519";

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/nofind.php';

$wxJssdkConfig = array();
$wxJssdkConfig["appId"]     = "";
$wxJssdkConfig["timestamp"] = time();
$wxJssdkConfig["nonceStr"]  = "";
$wxJssdkConfig["signature"] = "";
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcrenzhengConfig['wx_share_title'];
$shareDesc  = $tcrenzhengConfig['wx_share_desc'];
$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=index";
$shareLogo  = $tcrenzhengConfig['wx_share_pic'];

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesinfo.php';

$shareTitle = str_replace("{SITENAME}",$__SitesInfo['name'], $shareTitle);
$shareDesc = str_replace("{SITENAME}",$__SitesInfo['name'], $shareDesc);

## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcqianggou start
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
    $tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
    if($tcqianggouConfig['open_tcqianggou'] == 1){
        $__ShowTcqianggou = 1;
    }
}
## tcqianggou end
## tcmall start
$__ShowTcmall = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcmall/tom_tcmall.inc.php')){
    $tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
    if($tcmallConfig['open_tcmall'] == 1){
        $__ShowTcmall = 1;
    }
}
## tcmall end
## xiangqin start
$__ShowXiangqin = 0;
$xiangqinConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiangqin/tom_xiangqin.inc.php')){
    $xiangqinConfig = $_G['cache']['plugin']['tom_xiangqin'];
    if($xiangqinConfig['open_xiangqin'] == 1){
        $__ShowXiangqin = 1;
    }
}
## xiangqin end
## tczhaopin start
$__ShowTczhaopin = 0;
$tczhaopinConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')){
    $tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
    if($tczhaopinConfig['open_tczhaopin'] == 1){
        $__ShowTczhaopin = 1;
    }
}
## tczhaopin end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login.php';

$ajaxLoadListUrl = 'plugin.php?id=tom_tcrenzheng:ajax&site='.$site_id.'&act=list&formhash='.$formhash;

/********************* index ***********************/
if($_GET['mod'] == 'index'){
    
    $personalRenzhengStatus = $companyRenzhengStatus = $depositStatus = 0;
    $personalInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_user_id($__UserInfo['id']);
    if(is_array($personalInfo) && !empty($personalInfo)){
        $personalRenzhengStatus = 1;
    }
    $companyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($__UserInfo['id']);
    if(is_array($companyInfo) && !empty($companyInfo)){
        $companyRenzhengStatus = 1;
    }
    $depositInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_by_user_id($__UserInfo['id']);
    if(is_array($depositInfo) && $depositInfo['order_status'] == 2){
        $depositStatus = 1;
    }
    
    $renzheng_advantage = stripslashes($tcrenzhengConfig['renzheng_advantage']);
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
    include template("tom_tcrenzheng:index");
    
    
    
/********************* deposit ***********************/
}else if($_GET['mod'] == 'deposit'){
    
    $depositInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_by_user_id($__UserInfo['id']);
    
    $depositStatus = $renzhengStatus = $personalRenzhengStatus = $companyRenzhengStatus = 0;
    if(is_array($depositInfo) && !empty($depositInfo) && $depositInfo['order_status'] == 2){
        $depositStatus = 1;
    }else{
        
        $defaultRenzhengType = 1;
        if($tcrenzhengConfig['open_personal_deposit'] == 1){
            $personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_all_list("AND user_id = {$__UserInfo['id']}", 'ORDER BY id DESC', 0, 1);
            if(is_array($personalInfoTmp) && !empty($personalInfoTmp[0])){
                $renzhengStatus = $personalRenzhengStatus = 1;
            }
        }else{
            $defaultRenzhengType = 2;
        }
        $companyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$__UserInfo['id']}", 'ORDER BY id DESC', 0, 1);
        if(is_array($companyInfoTmp) && !empty($companyInfoTmp[0])){
            $renzhengStatus = $companyRenzhengStatus = 1;
            if($personalRenzhengStatus == 0){
                $defaultRenzhengType = 2;
            }
        }
        
    }
    
    $deposit_desc = discuzcode($tcrenzhengConfig['deposit_desc'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);
    
    $payUrl = "plugin.php?id=tom_tcrenzheng:pay&site={$site_id}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
    include template("tom_tcrenzheng:deposit");
    
    
    
/********************* refunddeposit ***********************/
}else if($_GET['mod'] == 'refunddeposit'){
    
    $depositInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_by_user_id($__UserInfo['id']);

    $refundDepositTime = $tcrenzhengConfig['refund_deposit_time'] * 86400 + $depositInfo['order_time'];

    $refundDepositStatus = 1;
    if(TIMESTAMP < $refundDepositTime){
        $refundDepositStatus = 2;
    }
    if($depositInfo['blocked_status'] == 1){
        $refundDepositStatus = 3;
    }
    
    $refund_deposit_desc = discuzcode($tcrenzhengConfig['refund_deposit_desc'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);
    
    $depositlogUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=depositlog&deposit_id={$depositInfo['id']}";
    $ajaxUrl = "plugin.php?id=tom_tcrenzheng:ajax&site={$site_id}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
    include template("tom_tcrenzheng:refunddeposit");
    
    
    
/********************* depositlog ***********************/
}else if($_GET['mod'] == 'depositlog'){
    
    $deposit_id = intval($_GET['deposit_id'])>0? intval($_GET['deposit_id']):0;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;

    $depositInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->fetch_by_id($deposit_id);
    if($depositInfo['user_id'] != $__UserInfo['id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=index");
    }
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;

    $whereStr = " AND deposit_id = {$deposit_id} ";
    
    $count = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_log')->fetch_all_count($whereStr);
    $depositlogListTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_log')->fetch_all_list($whereStr,"ORDER BY id DESC",$start,$pagesize);
    $depositlogList = array();
    if(is_array($depositlogListTmp) && !empty($depositlogListTmp)){
        foreach ($depositlogListTmp as $key => $value){
            $depositlogList[$key] = $value;
            
            if($value['type'] == 2){
                $shenqingInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_shenqing')->fetch_by_id($value['shenqing_id']);
                $depositlogList[$key]['shenqing_status'] = $shenqingInfoTmp['shenhe_status'];
            }
        }
    }

    $showNextPage = 1;
    if(($start + $pagesize) >= $count){
        $showNextPage = 0;
    }
    $allPageNum = ceil($count/$pagesize);
    $prePage = $page - 1;
    $nextPage = $page + 1;
    $prePageUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=depositlog&deposit_id={$deposit_id}&page={$prePage}";
    $nextPageUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=depositlog&deposit_id={$deposit_id}&page={$nextPage}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
    include template("tom_tcrenzheng:depositlog");
    
    
    
/********************* company ***********************/
}else if($_GET['mod'] == 'company'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/module/company.php';
    
/********************* personal ***********************/
}else if($_GET['mod'] == 'personal'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/module/personal.php';

/********************* success ***********************/
}else if($_GET['mod'] == 'success'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/module/success.php';
    
/********************* managerCompanyList ***********************/
}else if($_GET['mod'] == 'managerCompanyList'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/module/managerCompanyList.php';
    
/********************* managerPersonalList ***********************/
}else if($_GET['mod'] == 'managerPersonalList'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/module/managerPersonalList.php';
    
/********************* upload ***********************/
}else if($_GET['mod'] == 'upload'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/module/upload.php';
    
}else{
    
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=index");exit;
    
}
tomoutput();