<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    if($__UserInfo['id'] != $tcrenzhengConfig['rzmanage_user_id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=index");exit;
    }
}
# check end

if($_GET['act'] == 'shenhe' && submitcheck('company_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $company_id     = intval($_GET['company_id'])>0? intval($_GET['company_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0? intval($_GET['shenhe_status']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $companyInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($company_id);
    
    $updateData = array();
    $updateData['shenhe_status'] = $shenhe_status;
    C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->update($company_id,$updateData);
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($companyInfo['user_id']);
    
    if($companyInfo){
        
        if($shenhe_status == 1){
            $shenhe = str_replace('{NAME}', $companyInfo['name'], lang('plugin/tom_tcrenzheng', 'index_template_company_shenhe_ok'));
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcrenzheng&site='.$site_id.'&mod=index">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }else if($shenhe_status == 3){
            $shenhe = str_replace('{NAME}', $companyInfo['name'], lang('plugin/tom_tcrenzheng', 'index_template_company_shenhe_no'));
            $tzShenhe = $shenhe.'<br/><font color="#8e8e8e">'.$content.'</font><br/><a href="plugin.php?id=tom_tcrenzheng&site='.$site_id.'&mod=index">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }
        
        $insertData = array();
        $insertData['user_id']      = $toUser['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcrenzhengConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        if($shenhe_status == 1 && $__ShowTczhaopin == 1){
            @$r = tom_html_get($_G['siteurl'].'plugin.php?id=tom_tczhaopin:ajax&site='.$site_id.'&act=update_company_status_by_user_id&user_id='.$companyInfo['user_id']);
        }
        
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    
    $nextSmsTime = $toUser['last_smstp_time'] + 0;
    if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=index");
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcrenzhengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $updateData = array();
            $updateData['last_smstp_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerCompanyList&keyword=".urlencode(trim($keyword));
    
    echo $url;exit;
    
}else if($_GET['act'] == 'del' && submitcheck('company_id')){
    
    $company_id = intval($_GET['company_id'])>0? intval($_GET['company_id']):0;
    $companyInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($company_id);
    
    C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->delete_by_id($company_id);
    C::t('#tom_tcrenzheng#tom_tcrenzheng_company_photo')->delete_by_company_id($company_id);
    echo 200;exit;

}else if($_GET['act'] == 'shenhe_show'){
    
    $company_id   = intval($_GET['company_id'])>0? intval($_GET['company_id']):0;
    $fromtype       = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage       = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $companyInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($company_id);

    $company_shenhe_fail_str = str_replace("\r\n","{n}",$tcrenzhengConfig['company_shenhe_fail_text']); 
    $company_shenhe_fail_str = str_replace("\n","{n}",$company_shenhe_fail_str);
    $companyShenheFailArray = explode("{n}", $company_shenhe_fail_str);
    
    $ajaxShenheUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerCompanyList&act=shenhe&";
    $backUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerCompanyList&type={$fromtype}&page={$frompage}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
    include template("tom_tcrenzheng:managerCompanyShenhe");exit;
    
}else if($_GET['act'] == 'managerCompanySave' && submitcheck('name')){
    
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $nature_id          = intval($_GET['nature_id'])>0? intval($_GET['nature_id']):0;
    $industry_id        = intval($_GET['industry_id'])>0? intval($_GET['industry_id']):0;
    $scale_id           = intval($_GET['scale_id'])>0? intval($_GET['scale_id']):0;
    $credit_code        = isset($_GET['credit_code'])? addslashes($_GET['credit_code']):'';
    $rz_name            = isset($_GET['rz_name'])? addslashes($_GET['rz_name']):'';
    $rz_tel             = isset($_GET['rz_tel'])? addslashes($_GET['rz_tel']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $logo               = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    $business_license   = isset($_GET['business_license'])? addslashes($_GET['business_license']):'';
    $company_id         = intval($_GET['company_id'])>0? intval($_GET['company_id']):0;
    
    $photolistArr = array();
    if(is_array($_GET['photolist']) && !empty($_GET['photolist'])){
        foreach($_GET['photolist'] as $key => $value){
            if(!empty($value)){
                $photolistArr[] = addslashes($value);
            }
        }
    }
    
    $companyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_id($company_id);
    
    $updateData = array();
    $updateData['name']             = $name;
    $updateData['nature_id']        = $nature_id;
    $updateData['industry_id']      = $industry_id;
    $updateData['scale_id']         = $scale_id;
    $updateData['business_license'] = $business_license;
    $updateData['credit_code']      = $credit_code;
    $updateData['rz_name']          = $rz_name;
    $updateData['rz_tel']           = $rz_tel;
    $updateData['logo']             = $logo;
    $updateData['address']          = $address;
    $updateData['tel']              = $tel;
    $updateData['content']          = $content;
    if(C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->update($companyInfo['id'], $updateData)){
        C::t("#tom_tcrenzheng#tom_tcrenzheng_company_photo")->delete_by_company_id($companyInfo['id']);
        if(is_array($photolistArr) && !empty($photolistArr)){
            foreach($photolistArr as $key => $value){
                $insertData = array();
                $insertData['company_id']   = $companyInfo['id'];
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t("#tom_tcrenzheng#tom_tcrenzheng_company_photo")->insert($insertData);
            }
        }
    }
            
    $outArr = array(
        'status'=> 200,
    );
    
    echo json_encode($outArr); exit; //dism - taobao _ com
    
}else if($_GET['act'] == 'managerCompany'){
    
    $company_id     = intval($_GET['company_id'])>0? intval($_GET['company_id']):0;
    $fromtype       = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage       = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $companyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_id($company_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($companyInfo['user_id']);
    
    $logoPicurl = $businessLicensePicurl = '';
    if(!preg_match('/^http/', $companyInfo['logo']) ){
        if(strpos($companyInfo['logo'], 'source/plugin/tom_') === FALSE){
            $logoPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$companyInfo['logo'];
        }else{
            $logoPicurl = $companyInfo['logo'];
        }
    }else{
        $logoPicurl = $companyInfo['logo'];
    }

    if(!preg_match('/^http/', $companyInfo['business_license']) ){
        if(strpos($companyInfo['business_license'], 'source/plugin/tom_') === FALSE){
            $businessLicensePicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$companyInfo['business_license'];
        }else{
            $businessLicensePicurl = $companyInfo['business_license'];
        }
    }else{
        $businessLicensePicurl = $companyInfo['business_license'];
    }

    $photoListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company_photo")->fetch_all_list("AND company_id = {$companyInfo['id']}", 'ORDER BY id ASC', 0, 100);
    $photoList = array();
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach($photoListTmp as $key => $value){
            $photoList[$key] = $value;

            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurlTmp = $value['picurl'];
                }
            }else{
                $picurlTmp = $value['picurl'];
            }

            $photoList[$key]['picurlTmp'] = $picurlTmp;
        }
    }
    $photoCount = count($photoList);
    
    $natureListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_nature")->fetch_all_list("", 'ORDER BY nsort ASC,id DESC', 0, 100);
    $natureList = array();
    if(is_array($natureListTmp) && !empty($natureListTmp)){
        foreach($natureListTmp as $key => $value){
            $natureList[$key] = $value;
        }
    }

    $industryListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_industry")->fetch_all_list("", 'ORDER BY isort ASC,id DESC', 0, 100);
    $industryList = array();
    if(is_array($industryListTmp) && !empty($industryListTmp)){
        foreach($industryListTmp as $key => $value){
            $industryList[$key] = $value;
        }
    }

    $scaleListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_scale")->fetch_all_list("", 'ORDER BY ssort ASC,id DESC', 0, 100);
    $scaleList = array();
    if(is_array($scaleListTmp) && !empty($scaleListTmp)){
        foreach($scaleListTmp as $key => $value){
            $scaleList[$key] = $value;
        }
    }

    $saveUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerCompanyList&company_id={$company_id}";
    $uploadUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=upload&act=renzheng_picurl&formhash={$formhash}&suffix=";
    $wxUploadUrl = "plugin.php?id=tom_tcrenzheng:wxMediaDowmload&site={$site_id}&act=renzheng_picurl&formhash={$formhash}&suffix=";
    $backUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerCompanyList&type={$fromtype}&page={$frompage}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
    include template("tom_tcrenzheng:managerCompany");exit;
}

$keyword  = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page  = intval($_GET['page'])>0? intval($_GET['page']):1;
$type  = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = " ";
if($type == 1){
    $where.= " AND shenhe_status=2 ";
}
if($type == 2){
    $where.= " AND shenhe_status=3 ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_count($where,$keyword);
$companyListTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize,$keyword);
$companyList = array();
foreach ($companyListTmp as $key => $value) {
    $companyList[$key] = $value;
    
    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $natureTnfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_nature')->fetch_by_id($value['nature_id']);
    $industryTnfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_by_id($value['industry_id']);
    $scaleTnfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_scale')->fetch_by_id($value['scale_id']);
    
    $companyList[$key]['userInfo']      = $userInfoTmp;
    $companyList[$key]['natureTnfo']    = $natureTnfoTmp;
    $companyList[$key]['industryTnfo']  = $industryTnfoTmp;
    $companyList[$key]['scaleTnfo']     = $scaleTnfoTmp;
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerCompanyList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerCompanyList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];

$ajaxShenheUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerCompanyList&act=shenhe&formhash=".$formhash;
$ajaxDelUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerCompanyList&act=del&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerCompanyList&act=get_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcrenzheng:managerCompanyList");