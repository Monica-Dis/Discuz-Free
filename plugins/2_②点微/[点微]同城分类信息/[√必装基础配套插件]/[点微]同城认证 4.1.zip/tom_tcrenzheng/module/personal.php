<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$test               = intval($_GET['test'])>0? intval($_GET['test']):0;
$renzheng_back      = isset($_GET['renzheng_back'])? daddslashes($_GET['renzheng_back']):'';
$renzheng_plugin    = isset($_GET['renzheng_plugin'])? daddslashes($_GET['renzheng_plugin']):'';

if($_GET['act'] == 'save' && submitcheck('rz_name')){
    
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $rz_name            = isset($_GET['rz_name'])? addslashes($_GET['rz_name']):'';
    $rz_tel             = isset($_GET['rz_tel'])? addslashes($_GET['rz_tel']):'';
    $card_number        = isset($_GET['card_number'])? addslashes($_GET['card_number']):'';
    $card_shou          = isset($_GET['card_shou'])? addslashes($_GET['card_shou']):'';
    $card_zheng         = isset($_GET['card_zheng'])? addslashes($_GET['card_zheng']):'';
    $card_fan           = isset($_GET['card_fan'])? addslashes($_GET['card_fan']):'';
    $rz_desc            = isset($_GET['rz_desc'])? addslashes($_GET['rz_desc']):'';
    
    if($__UserInfo['id'] > 0){
        
        $personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_all_list(" AND user_id = {$__UserInfo['id']}", 'ORDER BY id DESC', 0, 1);
        if(is_array($personalInfoTmp) && !empty($personalInfoTmp[0])){
            $personalInfo = $personalInfoTmp[0];
            
            $updateData = array();
            $updateData['rz_name']          = $rz_name;
            if($tcrenzhengConfig['open_bind_tel'] == 1){
                $updateData['rz_tel']           = $__UserInfo['tel'];
            }else{
                $updateData['rz_tel']           = $rz_tel;
            }
            $updateData['card_number']      = $card_number;
            $updateData['card_shou']        = $card_shou;
            $updateData['card_zheng']       = $card_zheng;
            $updateData['card_fan']         = $card_fan;
            $updateData['rz_desc']          = $rz_desc;
            $updateData['shenhe_status']    = 2;
            $updateData['add_time']         = TIMESTAMP;
            C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->update($personalInfo['id'], $updateData);
            
        }else{
            $insertData = array();
            $insertData['user_id']          = $__UserInfo['id'];
            $insertData['rz_name']          = $rz_name;
            if($tcrenzhengConfig['open_bind_tel'] == 1){
                $insertData['rz_tel']           = $__UserInfo['tel'];
            }else{
                $insertData['rz_tel']           = $rz_tel;
            }
            $insertData['card_number']      = $card_number;
            $insertData['card_shou']        = $card_shou;
            $insertData['card_zheng']       = $card_zheng;
            $insertData['card_fan']         = $card_fan;
            $insertData['rz_desc']          = $rz_desc;
            $insertData['shenhe_status']    = 2;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->insert($insertData);
        }
        
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        
        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($manageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerPersonalList");
            $smsData = array(
                'first'         => lang('plugin/tom_tcrenzheng', 'renzheng_personal_renzheng_msg'),
                'keyword1'      => $tcrenzhengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }

        $rzManageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcrenzhengConfig['rzmanage_user_id']);
        if($access_token && !empty($rzManageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerPersonalList");
            $smsData = array(
                'first'         => lang('plugin/tom_tcrenzheng', 'renzheng_personal_renzheng_msg'),
                'keyword1'      => $tcrenzhengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($rzManageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
        
        $outArr = array(
            'status'=> 200,
        );
    }else{
        $outArr = array(
            'status'=> 404,
        );
    }
    echo json_encode($outArr); exit; //dism - taobao _ com
    
}

$personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_all_list("AND user_id = {$__UserInfo['id']}", 'ORDER BY id DESC', 0, 1);
$personalInfo = array();
$cardShouPicurl = $cardZhengPicurl = $cardFanPicurl = '';
if(is_array($personalInfoTmp) && !empty($personalInfoTmp[0])){
    $personalInfo = $personalInfoTmp[0];

    if(!preg_match('/^http/', $personalInfo['card_shou']) ){
        if(strpos($personalInfo['card_shou'], 'source/plugin/tom_') === FALSE){
            $cardShouPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$personalInfo['card_shou'];
        }else{
            $cardShouPicurl = $personalInfo['card_shou'];
        }
    }else{
        $cardShouPicurl = $personalInfo['card_shou'];
    }

    if(!preg_match('/^http/', $personalInfo['card_zheng']) ){
        if(strpos($personalInfo['card_zheng'], 'source/plugin/tom_') === FALSE){
            $cardZhengPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$personalInfo['card_zheng'];
        }else{
            $cardZhengPicurl = $personalInfo['card_zheng'];
        }
    }else{
        $cardZhengPicurl = $personalInfo['card_zheng'];
    }

    if(!preg_match('/^http/', $personalInfo['card_fan']) ){
        if(strpos($personalInfo['card_fan'], 'source/plugin/tom_') === FALSE){
            $cardFanPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$personalInfo['card_fan'];
        }else{
            $cardFanPicurl = $personalInfo['card_fan'];
        }
    }else{
        $cardFanPicurl = $personalInfo['card_fan'];
    }
}

$showMustPhoneBtn = 0;
if(empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0 && $tcrenzhengConfig['open_bind_tel']==1){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$renzheng_advantage = stripslashes($tcrenzhengConfig['renzheng_advantage']);

$successUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=success&renzheng_plugin={$renzheng_plugin}&renzheng_back=".urlencode($renzheng_back);

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=personal";
$saveUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=personal";
$uploadUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=upload&act=renzheng_picurl&formhash={$formhash}&suffix=";
$wxUploadUrl = "plugin.php?id=tom_tcrenzheng:wxMediaDowmload&site={$site_id}&act=renzheng_picurl&formhash={$formhash}&suffix=";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcrenzheng:personal");