<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$renzheng_back      = isset($_GET['renzheng_back'])? daddslashes($_GET['renzheng_back']):'';
$renzheng_plugin    = isset($_GET['renzheng_plugin'])? daddslashes($_GET['renzheng_plugin']):'';

$renzheng_advantage = stripslashes($tcrenzhengConfig['renzheng_advantage']);

$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
if($__SitesInfo['id'] > 1){
    if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])){
        if(strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_tongcheng/') === FALSE){
            $kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
        }else{
            $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
        }
    }else{
        $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
    }
}

$tcrenzhengConfig['kefu_qrcode'] = trim($tcrenzhengConfig['kefu_qrcode']);
if(!empty($tcrenzhengConfig['kefu_qrcode'])){
    $kefuQrcodeSrc = $tcrenzhengConfig['kefu_qrcode'];
}
    
$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcrenzheng:success");