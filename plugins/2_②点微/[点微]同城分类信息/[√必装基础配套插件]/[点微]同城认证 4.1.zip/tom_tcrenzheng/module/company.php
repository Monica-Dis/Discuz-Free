<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$test               = intval($_GET['test'])>0? intval($_GET['test']):0;
$renzheng_back      = isset($_GET['renzheng_back'])? daddslashes($_GET['renzheng_back']):'';
$renzheng_plugin    = isset($_GET['renzheng_plugin'])? daddslashes($_GET['renzheng_plugin']):'';

if($_GET['act'] == 'save' && submitcheck('name')){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $nature_id          = intval($_GET['nature_id'])>0? intval($_GET['nature_id']):0;
    $industry_id        = intval($_GET['industry_id'])>0? intval($_GET['industry_id']):0;
    $scale_id           = intval($_GET['scale_id'])>0? intval($_GET['scale_id']):0;
    $credit_code        = isset($_GET['credit_code'])? addslashes($_GET['credit_code']):'';
    $rz_name            = isset($_GET['rz_name'])? addslashes($_GET['rz_name']):'';
    $rz_tel             = isset($_GET['rz_tel'])? addslashes($_GET['rz_tel']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $logo               = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    $business_license   = isset($_GET['business_license'])? addslashes($_GET['business_license']):'';
    
    $photolistArr = array();
    if(is_array($_GET['photolist']) && !empty($_GET['photolist'])){
        foreach($_GET['photolist'] as $key => $value){
            if(!empty($value)){
                $photolistArr[] = addslashes($value);
            }
        }
    }
    
    if($__UserInfo['id'] > 0){
        
        $companyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list(" AND user_id = {$__UserInfo['id']}", 'ORDER BY id DESC', 0, 1);
        if(is_array($companyInfoTmp) && !empty($companyInfoTmp[0])){
            $companyInfo = $companyInfoTmp[0];
            
            $updateData = array();
            $updateData['name']             = $name;
            $updateData['nature_id']        = $nature_id;
            $updateData['industry_id']      = $industry_id;
            $updateData['scale_id']         = $scale_id;
            $updateData['business_license'] = $business_license;
            $updateData['credit_code']      = $credit_code;
            $updateData['rz_name']          = $rz_name;
            $updateData['rz_tel']           = $rz_tel;
            $updateData['logo']             = $logo;
            $updateData['address']          = $address;
            if($companyInfo['first_shenhe'] == 0){
                $updateData['tel']              = $tel;
                $updateData['content']          = $content;
            }
            $updateData['shenhe_status']    = 2;
            $updateData['add_time']         = TIMESTAMP;
            if(C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->update($companyInfo['id'], $updateData)){
                if($companyInfo['first_shenhe'] == 0){
                    C::t("#tom_tcrenzheng#tom_tcrenzheng_company_photo")->delete_by_company_id($companyInfo['id']);
                    if(is_array($photolistArr) && !empty($photolistArr)){
                        foreach($photolistArr as $key => $value){
                            $insertData = array();
                            $insertData['company_id']   = $companyInfo['id'];
                            $insertData['picurl']       = $value;
                            $insertData['add_time']     = TIMESTAMP;
                            C::t("#tom_tcrenzheng#tom_tcrenzheng_company_photo")->insert($insertData);
                        }
                    }
                }
            }
            
        }else{
            $insertData = array();
            $insertData['user_id']          = $__UserInfo['id'];
            $insertData['name']             = $name;
            $insertData['tel']              = $tel;
            $insertData['nature_id']        = $nature_id;
            $insertData['industry_id']      = $industry_id;
            $insertData['scale_id']         = $scale_id;
            $insertData['business_license'] = $business_license;
            $insertData['credit_code']      = $credit_code;
            $insertData['rz_name']          = $rz_name;
            $insertData['rz_tel']           = $rz_tel;
            $insertData['logo']             = $logo;
            $insertData['address']          = $address;
            $insertData['content']          = $content;
            $insertData['shenhe_status']    = 2;
            $insertData['add_time']         = TIMESTAMP;
            if(C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->insert($insertData)){
                $company_id = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->insert_id();
                if(is_array($photolistArr) && !empty($photolistArr)){
                    foreach($photolistArr as $key => $value){
                        $insertData = array();
                        $insertData['company_id']   = $company_id;
                        $insertData['picurl']       = $value;
                        $insertData['add_time']     = TIMESTAMP;
                        C::t("#tom_tcrenzheng#tom_tcrenzheng_company_photo")->insert($insertData);
                    }
                }
            }
        }
        
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        
        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($manageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerCompanyList");
            $smsData = array(
                'first'         => lang('plugin/tom_tcrenzheng', 'renzheng_company_renzheng_msg'),
                'keyword1'      => $tcrenzhengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }

        $rzManageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcrenzhengConfig['rzmanage_user_id']);
        if($access_token && !empty($rzManageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerCompanyList");
            $smsData = array(
                'first'         => lang('plugin/tom_tcrenzheng', 'renzheng_company_renzheng_msg'),
                'keyword1'      => $tcrenzhengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($rzManageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }

        $outArr = array(
            'status'=> 200,
        );
    }else{
        $outArr = array(
            'status'=> 404,
        );
    }
    echo json_encode($outArr); exit; //dism - taobao _ com
    
}else if($_GET['act'] == 'noshenhe_save' && submitcheck('company_id')){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $company_id         = intval($_GET['company_id'])>0? intval($_GET['company_id']):0;
    $tel                = isset($_GET['tel'])>0? addslashes($_GET['tel']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $companyInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_id($company_id);
    
    $photolistArr = array();
    if(is_array($_GET['photolist']) && !empty($_GET['photolist'])){
        foreach($_GET['photolist'] as $key => $value){
            if(!empty($value)){
                $photolistArr[] = addslashes($value);
            }
        }
    }
    
    if($companyInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }
    
    $updateData = array();
    $updateData['tel']              = $tel;
    $updateData['content']          = $content;
    $updateData['add_time']         = TIMESTAMP;
    if(C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->update($companyInfo['id'], $updateData)){
        C::t("#tom_tcrenzheng#tom_tcrenzheng_company_photo")->delete_by_company_id($companyInfo['id']);

        if(is_array($photolistArr) && !empty($photolistArr)){
            foreach($photolistArr as $key => $value){
                $insertData = array();
                $insertData['company_id']   = $companyInfo['id'];
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t("#tom_tcrenzheng#tom_tcrenzheng_company_photo")->insert($insertData);
            }
        }
    }
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit; //dism - taobao _ com
}

$companyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$__UserInfo['id']}", 'ORDER BY id DESC', 0, 1);
$companyInfo = array();
$logoPicurl = $businessLicensePicurl = '';
if(is_array($companyInfoTmp) && !empty($companyInfoTmp[0])){
    $companyInfo = $companyInfoTmp[0];

    if(!preg_match('/^http/', $companyInfo['logo']) && !empty($companyInfo['logo']) ){
        if(strpos($companyInfo['logo'], 'source/plugin/tom_') === FALSE){
            $logoPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$companyInfo['logo'];
        }else{
            $logoPicurl = $companyInfo['logo'];
        }
    }else{
        $logoPicurl = $companyInfo['logo'];
    }

    if(!preg_match('/^http/', $companyInfo['business_license']) ){
        if(strpos($companyInfo['business_license'], 'source/plugin/tom_') === FALSE){
            $businessLicensePicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$companyInfo['business_license'];
        }else{
            $businessLicensePicurl = $companyInfo['business_license'];
        }
    }else{
        $businessLicensePicurl = $companyInfo['business_license'];
    }

    $photoListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company_photo")->fetch_all_list("AND company_id = {$companyInfo['id']}", 'ORDER BY id ASC', 0, 100);
    $photoList = array();
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach($photoListTmp as $key => $value){
            $photoList[$key] = $value;

            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurlTmp = $value['picurl'];
                }
            }else{
                $picurlTmp = $value['picurl'];
            }

            $photoList[$key]['picurlTmp'] = $picurlTmp;
        }
    }
    $photoCount = count($photoList);
}

$must_company_logo = 1;
$tcrenzhengConfig['default_company_logo'] = trim($tcrenzhengConfig['default_company_logo']);
if($tcrenzhengConfig['open_default_company_logo'] == 1 && !empty($tcrenzhengConfig['default_company_logo'])){
    $must_company_logo = 0;
    if(empty($companyInfo['logo'])){
        $companyInfo['logo'] = "source/plugin/tom_tcrenzheng/images/company_logo/".$tcrenzhengConfig['default_company_logo'];
        $logoPicurl          = "source/plugin/tom_tcrenzheng/images/company_logo/".$tcrenzhengConfig['default_company_logo'];
    }
}

$natureListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_nature")->fetch_all_list("", 'ORDER BY nsort ASC,id DESC', 0, 100);
$natureList = array();
if(is_array($natureListTmp) && !empty($natureListTmp)){
    foreach($natureListTmp as $key => $value){
        $natureList[$key] = $value;
    }
}

$industryListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_industry")->fetch_all_list("", 'ORDER BY isort ASC,id DESC', 0, 100);
$industryList = array();
if(is_array($industryListTmp) && !empty($industryListTmp)){
    foreach($industryListTmp as $key => $value){
        $industryList[$key] = $value;
    }
}

$scaleListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_scale")->fetch_all_list("", 'ORDER BY ssort ASC,id DESC', 0, 100);
$scaleList = array();
if(is_array($scaleListTmp) && !empty($scaleListTmp)){
    foreach($scaleListTmp as $key => $value){
        $scaleList[$key] = $value;
    }
}

$showMustPhoneBtn = 0;
if(empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0 && $tcrenzhengConfig['open_bind_tel']==1){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$renzheng_advantage = stripslashes($tcrenzhengConfig['renzheng_advantage']);

$successUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=success&renzheng_plugin={$renzheng_plugin}&renzheng_back=".urlencode($renzheng_back);

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=company";
$saveUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=company";
$uploadUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=upload&act=renzheng_picurl&formhash={$formhash}&suffix=";
$wxUploadUrl = "plugin.php?id=tom_tcrenzheng:wxMediaDowmload&site={$site_id}&act=renzheng_picurl&formhash={$formhash}&suffix=";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcrenzheng:company");