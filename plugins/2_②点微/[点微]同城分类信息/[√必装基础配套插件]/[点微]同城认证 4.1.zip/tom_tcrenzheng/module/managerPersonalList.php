<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    if($__UserInfo['id'] != $tcrenzhengConfig['rzmanage_user_id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=index");exit;
    }
}
# check end

if($_GET['act'] == 'shenhe' && submitcheck('personal_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $personal_id    = intval($_GET['personal_id'])>0? intval($_GET['personal_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0? intval($_GET['shenhe_status']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $personalInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_id($personal_id);
    
    $updateData = array();
    $updateData['shenhe_status'] = $shenhe_status;
    C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->update($personal_id,$updateData);
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($personalInfo['user_id']);
    
    if($personalInfo){
        
        if($shenhe_status == 1){
            $shenhe = lang('plugin/tom_tcrenzheng', 'index_template_personal_shenhe_ok');
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcrenzheng&site='.$site_id.'&mod=index">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }else if($shenhe_status == 3){
            $shenhe = lang('plugin/tom_tcrenzheng', 'index_template_personal_shenhe_no');
            $tzShenhe = $shenhe.'<br/><font color="#8e8e8e">'.$content.'</font><br/><a href="plugin.php?id=tom_tcrenzheng&site='.$site_id.'&mod=index">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }
        
        $insertData = array();
        $insertData['user_id']      = $toUser['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcrenzhengConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    
    $nextSmsTime = $toUser['last_smstp_time'] + 0;
    if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=index");
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcrenzhengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $updateData = array();
            $updateData['last_smstp_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerPersonalList&keyword=".urlencode(trim($keyword));
    
    echo $url;exit;
    
}else if($_GET['act'] == 'del' && submitcheck('personal_id')){
    
    $personal_id = intval($_GET['personal_id'])>0? intval($_GET['personal_id']):0;
    
    C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->delete_by_id($personal_id);
    
    echo 200;exit;

}else if($_GET['act'] == 'shenhe_show'){
    
    $personal_id    = intval($_GET['personal_id'])>0? intval($_GET['personal_id']):0;
    $fromtype       = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage       = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $personalInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_id($personal_id);

    $personal_shenhe_fail_str = str_replace("\r\n","{n}",$tcrenzhengConfig['personal_shenhe_fail_text']); 
    $personal_shenhe_fail_str = str_replace("\n","{n}",$personal_shenhe_fail_str);
    $personalShenheFailArray = explode("{n}", $personal_shenhe_fail_str);

    $ajaxShenheUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerPersonalList&act=shenhe&";
    $backUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerPersonalList&type={$fromtype}&page={$frompage}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
    include template("tom_tcrenzheng:managerPersonalShenhe");exit;

}else if($_GET['act'] == 'managerPersonalSave' && submitcheck('personal_id')){
    
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $rz_name            = isset($_GET['rz_name'])? addslashes($_GET['rz_name']):'';
    $rz_tel             = isset($_GET['rz_tel'])? addslashes($_GET['rz_tel']):'';
    $card_number        = isset($_GET['card_number'])? addslashes($_GET['card_number']):'';
    $card_shou          = isset($_GET['card_shou'])? addslashes($_GET['card_shou']):'';
    $card_zheng         = isset($_GET['card_zheng'])? addslashes($_GET['card_zheng']):'';
    $card_fan           = isset($_GET['card_fan'])? addslashes($_GET['card_fan']):'';
    $rz_desc            = isset($_GET['rz_desc'])? addslashes($_GET['rz_desc']):'';
    $personal_id        = intval($_GET['personal_id'])>0? intval($_GET['personal_id']):0;
    
    $personalInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_id($personal_id);
    
    $updateData = array();
    $updateData['rz_name']          = $rz_name;
    $updateData['rz_tel']           = $rz_tel;
    $updateData['card_number']      = $card_number;
    $updateData['card_shou']        = $card_shou;
    $updateData['card_zheng']       = $card_zheng;
    $updateData['card_fan']         = $card_fan;
    $updateData['rz_desc']          = $rz_desc;
    C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->update($personalInfo['id'], $updateData);

    $outArr = array(
        'status'=> 200,
    );
    
    echo json_encode($outArr); exit; //dism - taobao _ com
    
}else if($_GET['act'] == 'managerPersonal'){
    
    $personal_id    = intval($_GET['personal_id'])>0? intval($_GET['personal_id']):0;
    $fromtype       = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage       = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $personalInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_id($personal_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($personalInfo['user_id']);
    
    $cardShouPicurl = $cardZhengPicurl = $cardFanPicurl = '';
    if(!preg_match('/^http/', $personalInfo['card_shou']) ){
        if(strpos($personalInfo['card_shou'], 'source/plugin/tom_') === FALSE){
            $cardShouPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$personalInfo['card_shou'];
        }else{
            $cardShouPicurl = $personalInfo['card_shou'];
        }
    }else{
        $cardShouPicurl = $personalInfo['card_shou'];
    }

    if(!preg_match('/^http/', $personalInfo['card_zheng']) ){
        if(strpos($personalInfo['card_zheng'], 'source/plugin/tom_') === FALSE){
            $cardZhengPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$personalInfo['card_zheng'];
        }else{
            $cardZhengPicurl = $personalInfo['card_zheng'];
        }
    }else{
        $cardZhengPicurl = $personalInfo['card_zheng'];
    }

    if(!preg_match('/^http/', $personalInfo['card_fan']) ){
        if(strpos($personalInfo['card_fan'], 'source/plugin/tom_') === FALSE){
            $cardFanPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$personalInfo['card_fan'];
        }else{
            $cardFanPicurl = $personalInfo['card_fan'];
        }
    }else{
        $cardFanPicurl = $personalInfo['card_fan'];
    }

    $saveUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerPersonalList&personal_id={$personal_id}";
    $uploadUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=upload&act=renzheng_picurl&formhash={$formhash}&suffix=";
    $wxUploadUrl = "plugin.php?id=tom_tcrenzheng:wxMediaDowmload&site={$site_id}&act=renzheng_picurl&formhash={$formhash}&suffix=";
    $backUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerPersonalList&type={$fromtype}&page={$frompage}";

    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
    include template("tom_tcrenzheng:managerPersonal");exit;
    
}

$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$type       = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = " ";
if($type == 1){
    $where.= " AND shenhe_status=2 ";
}
if($type == 2){
    $where.= " AND shenhe_status=3 ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_all_count($where,$keyword);
$personalListTmp  = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize,$keyword);
$personalList = array();
foreach ($personalListTmp as $key => $value) {
    $personalList[$key] = $value;

    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
    $personalList[$key]['userInfo'] = $userInfo;
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerPersonalList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerPersonalList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];

$ajaxShenheUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerPersonalList&act=shenhe&&formhash=".$formhash;
$ajaxDelUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerPersonalList&act=del&&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=managerPersonalList&act=get_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcrenzheng:managerPersonalList");