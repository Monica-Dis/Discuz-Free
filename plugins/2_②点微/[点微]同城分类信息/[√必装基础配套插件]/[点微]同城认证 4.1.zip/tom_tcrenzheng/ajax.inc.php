<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH; //D IS M.TA OBAO.C OM
$tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

if($_GET['act'] == 'refund_deposit' && submitcheck('money')){
    
    $deposit_id = intval($_GET['deposit_id'])>0? intval($_GET['deposit_id']):0;
    $money      = floatval($_GET['money'])>0? floatval($_GET['money']):0.00;
    
    $depositInfo = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_by_id($deposit_id);

    if($depositInfo['user_id'] != $__UserInfo['id'] || $depositInfo['order_status'] != 2){
        echo 404;exit;
    }
    
    if($money <= 0){
        echo 301;exit;
    }
    
    if($tcrenzhengConfig['open_many_refund_deposit'] != 1){
        $money = $depositInfo['deposit'];
    }
    
    if($money > $depositInfo['deposit']){
        echo 302;exit;
    }
    
    $refundDepositTime = $tcrenzhengConfig['refund_deposit_time'] * 86400 + $depositInfo['order_time'];
    if(TIMESTAMP < $refundDepositTime){
        echo 303;exit;
    }
    
    $insertData = array();
    $insertData['deposit_id']       = $deposit_id;
    $insertData['user_id']          = $depositInfo['user_id'];
    $insertData['money']            = $money;
    $insertData['shenhe_status']    = 2;
    $insertData['add_time']         = TIMESTAMP;
    if(C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit_shenqing")->insert($insertData)){
        $shenqing_id = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit_shenqing")->insert_id();    
    }else{
        echo 304;exit;
    }
    
    $sydeposit = ($depositInfo['deposit']*100 - $money*100)/100;
    
    $updateData = array();
    if($sydeposit == 0){
        $updateData['deposit']      = 0;
        $updateData['order_status'] = 3;
    }else{
        $updateData['deposit']      = $sydeposit;
    }
    C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->update($deposit_id, $updateData);
    
    $insertData = array();
    $insertData['deposit_id']       = $depositInfo['id'];
    $insertData['shenqing_id']      = $shenqing_id;
    $insertData['deposit_type']     = $depositInfo['type'];
    $insertData['type']             = 2;
    $insertData['old_value']        = $depositInfo['deposit'];
    $insertData['change_value']     = $money;
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit_log')->insert($insertData);
    
    if(!empty($tongchengConfig['template_id'])){
        
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

        $weixinClass = new weixinClass($appid,$appsecret);
        $access_token = $weixinClass->get_access_token();
        
        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
        if($access_token && !empty($manageUserInfo['openid'])){
            
            if($depositInfo['type'] == 1){
                $templateSms = lang('plugin/tom_tcrenzheng', 'ajax_refunddeposit_type_1');
            }else if($depositInfo['type'] == 2){
                $templateSms = lang('plugin/tom_tcrenzheng', 'ajax_refunddeposit_type_2');
            }
            $templateSms = str_replace('{NAME}', $__UserInfo['nickname'], $templateSms);
            $templateSms = str_replace('{MONEY}', $money, $templateSms);
            
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site=1&mod=index");
            $smsData = array(
                'first'         => $templateSms,
                'keyword1'      => $tcrenzhengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
        
        $rzManageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcrenzhengConfig['rzmanage_user_id']);
        if($access_token && !empty($rzManageUserInfo['openid'])){
            
            if($depositInfo['type'] == 1){
                $templateSms = lang('plugin/tom_tcrenzheng', 'ajax_refunddeposit_type_1');
            }else if($depositInfo['type'] == 2){
                $templateSms = lang('plugin/tom_tcrenzheng', 'ajax_refunddeposit_type_2');
            }
            $templateSms = str_replace('{NAME}', $__UserInfo['nickname'], $templateSms);
            $templateSms = str_replace('{MONEY}', $money, $templateSms);
            
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site=1&mod=index");
            $smsData = array(
                'first'         => $templateSms,
                'keyword1'      => $tcrenzhengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($rzManageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    echo 200;exit;
    
}else{
    echo 'error';exit;
}