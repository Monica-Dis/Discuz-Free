<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcrenzheng'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcrenzheng&pmod=admin';
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcrenzheng&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcrenzheng&pmod=admin';

$tomSysOffset = getglobal('setting/timeoffset');

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){
}else{
    echo '<a href="https://dism.taobao.com/?@tom_tongcheng.plugin">https://dism.taobao.com/?@tom_tongcheng.plugin</a>';exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/class/function.a.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';
$tcrenzhengConfig = get_plugin_config($pluginid);
$Lang = formatLang($Lang);

$tongchengPlugin = C::t('#tom_tcrenzheng#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

if($_GET['tmod'] == 'index'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/admin/index.php';
}else if($_GET['tmod'] == 'personal'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/admin/personal.php';
}else if($_GET['tmod'] == 'deposit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/admin/deposit.php';
}else if($_GET['tmod'] == 'shenqing'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/admin/shenqing.php';
}else if($_GET['tmod'] == 'nature'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/admin/nature.php';
}else if($_GET['tmod'] == 'industry'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/admin/industry.php';
}else if($_GET['tmod'] == 'scale'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/admin/scale.php';
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/admin/addon.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/admin/index.php';
}