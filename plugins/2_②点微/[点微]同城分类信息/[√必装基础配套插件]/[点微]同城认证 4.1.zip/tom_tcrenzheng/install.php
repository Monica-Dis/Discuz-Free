<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcrenzheng_company`;
CREATE TABLE `pre_tom_tcrenzheng_company` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `nature_id` int(11) DEFAULT '0',
  `industry_id` int(11) DEFAULT '0',
  `scale_id` int(11) DEFAULT '0',
  `business_license` varchar(255) DEFAULT NULL,
  `credit_code` varchar(255) DEFAULT NULL,
  `rz_name` varchar(255) DEFAULT NULL,
  `rz_tel` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `content` text,
  `first_shenhe` tinyint(4) DEFAULT '0',
  `shenhe_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcrenzheng_company_photo`;
CREATE TABLE `pre_tom_tcrenzheng_company_photo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcrenzheng_deposit`;
CREATE TABLE `pre_tom_tcrenzheng_deposit` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT '0',
  `personal_id` int(11) DEFAULT '0',
  `type` tinyint(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `deposit` decimal(10,2) DEFAULT '0.00',
  `order_no` varchar(255) DEFAULT NULL,
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `pay_time` int(11) DEFAULT '0',
  `blocked_status` tinyint(4) DEFAULT '0',
  `order_status` tinyint(4) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `is_admin` tinyint(4) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcrenzheng_deposit_log`;
CREATE TABLE `pre_tom_tcrenzheng_deposit_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `deposit_id` int(11) DEFAULT '0',
  `shenqing_id` int(11) DEFAULT '0',
  `deposit_type` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `old_value` decimal(10,2) DEFAULT '0.00',
  `change_value` decimal(10,2) DEFAULT '0.00',
  `is_admin` tinyint(4) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcrenzheng_deposit_shenqing`;
CREATE TABLE `pre_tom_tcrenzheng_deposit_shenqing` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `deposit_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00',
  `shenhe_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcrenzheng_industry`;
CREATE TABLE `pre_tom_tcrenzheng_industry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `isort` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcrenzheng_nature`;
CREATE TABLE `pre_tom_tcrenzheng_nature` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `nsort` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcrenzheng_personal`;
CREATE TABLE `pre_tom_tcrenzheng_personal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `rz_name` varchar(255) DEFAULT NULL,
  `rz_tel` varchar(255) DEFAULT NULL,
  `card_number` varchar(255) DEFAULT NULL,
  `card_shou` varchar(255) DEFAULT NULL,
  `card_zheng` varchar(255) DEFAULT NULL,
  `card_fan` varchar(255) DEFAULT NULL,
  `rz_desc` varchar(255) DEFAULT NULL,
  `shenhe_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcrenzheng_scale`;
CREATE TABLE `pre_tom_tcrenzheng_scale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `ssort` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;