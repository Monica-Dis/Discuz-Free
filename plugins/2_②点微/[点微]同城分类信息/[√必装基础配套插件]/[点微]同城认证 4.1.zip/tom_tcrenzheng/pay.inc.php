<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
$tongchengConfig  = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$act = isset($_GET['act'])? addslashes($_GET['act']):"";

if($act == "pay_deposit" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $user_id    = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    $type       = intval($_GET['type'])>0 ? intval($_GET['type']):0;

    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }
    
    if(is_array($userInfo) && $userInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }
    
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    if($type == 1){
        $pay_price = $tcrenzhengConfig['personal_deposit_money'];
        
        $personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_all_list("AND user_id = {$user_id}", 'ORDER BY id DESC', 0, 1);
        if(is_array($personalInfoTmp) && !empty($personalInfoTmp[0])){ }else{
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit; //dism - taobao _ com
        }
    }else if($type == 2){
        $pay_price = $tcrenzhengConfig['company_deposit_money'];
        
        $companyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id = {$user_id}", 'ORDER BY id DESC', 0, 1);
        if(is_array($companyInfoTmp) && !empty($companyInfoTmp[0])){ }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit; //dism - taobao _ com
        }
    }
    
    if($pay_price <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }
    
    $depositInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->fetch_by_user_id($user_id);
    if(is_array($depositInfo) && $depositInfo){
        
        if($depositInfo['order_status'] == 2){
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit; //dism - taobao _ com
        }
        
        $updateData = array();
        $updateData['type']         = $type;
        if($type == 1){
            $updateData['personal_id']  = $personalInfoTmp[0]['id'];
            $updateData['company_id']   = 0;
        }else if($type == 2){
            $updateData['personal_id']  = 0;
            $updateData['company_id']   = $companyInfoTmp[0]['id'];
        }
        $updateData['order_no']     = $order_no;
        $updateData['deposit']      = $pay_price;
        $updateData['pay_price']    = $pay_price;
        $updateData['order_status'] = 1;
        $updateData['order_time']   = TIMESTAMP;
        C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->update($depositInfo['id'], $updateData);
        $deposit_id = $depositInfo['id'];
    }else{
        $insertData = array();
        $insertData['type']         = $type;
        if($type == 1){
            $insertData['personal_id']  = $personalInfoTmp[0]['id'];
        }else if($type == 2){
            $insertData['company_id']   = $companyInfoTmp[0]['id'];
        }
        $insertData['user_id']      = $user_id;
        $insertData['openid']       = $userInfo['openid'];
        $insertData['deposit']      = $pay_price;
        $insertData['order_no']     = $order_no;
        $insertData['pay_price']    = $pay_price;
        $insertData['order_status'] = 1;
        $insertData['order_time']   = TIMESTAMP; 
        if(C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->insert($insertData)){
            $deposit_id = C::t('#tom_tcrenzheng#tom_tcrenzheng_deposit')->insert_id();
        }
    }
    
    $insertData = array();
    $insertData['plugin_id']       = 'tom_tcrenzheng';          
    $insertData['order_no']        = $order_no;                 
    $insertData['goods_id']        = $deposit_id;
    $insertData['goods_name']      = lang('plugin/tom_tcrenzheng', 'pay_deposit_title');
    $insertData['goods_beizu']     = '';
    $insertData['goods_url']       = 'plugin.php?id=tom_tcrenzheng&site='.$site_id.'&mod=deposit';
    $insertData['succ_back_url']   = 'plugin.php?id=tom_tcrenzheng&site='.$site_id.'&mod=deposit';
    $insertData['fail_back_url']   = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=deposit"; 
    $insertData['allow_alipay']    = 1;
    $insertData['pay_price']       = $pay_price;
    $insertData['order_status']    = 1;
    $insertData['add_time']        = TIMESTAMP;
    if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
        $outArr = array(
            'status'        => 200,
            'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }else{
        $outArr = array(
            'status'=> 306,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit; //dism - taobao _ com
}