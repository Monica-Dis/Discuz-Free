<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=personaladd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $rz_name        = isset($_GET['rz_name'])? addslashes($_GET['rz_name']):'';
    $rz_tel         = isset($_GET['rz_tel'])? addslashes($_GET['rz_tel']):'';
    $card_number    = isset($_GET['card_number'])? addslashes($_GET['card_number']):'';
    $rz_desc        = isset($_GET['rz_desc'])? addslashes($_GET['rz_desc']):'';
    $card_shou      = isset($_GET['card_shou'])? addslashes($_GET['card_shou']):'';
    $card_zheng     = isset($_GET['card_zheng'])? addslashes($_GET['card_zheng']):'';
    $card_fan       = isset($_GET['card_fan'])? addslashes($_GET['card_fan']):'';
    
    $insertData = array();
    $insertData['user_id']            = $user_id;
    $insertData['rz_name']            = $rz_name;
    $insertData['rz_tel']             = $rz_tel;
    $insertData['card_number']        = $card_number;
    $insertData['rz_desc']            = $rz_desc;
    $insertData['card_shou']          = $card_shou;
    $insertData['card_zheng']         = $card_zheng;
    $insertData['card_fan']           = $card_fan;
    $insertData['shenhe_status']      = 1;
    $insertData['add_time']           = TIMESTAMP;
    $personal_id = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->insert($insertData, true);    
        
    if($personal_id > 0){

        $outArr = array(
            'code'=> 200,
            'id'=> $company_id,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }
}

$addUrl = $modPcadminUrl."&act=add";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcrenzheng:pcadmin/personaladd");