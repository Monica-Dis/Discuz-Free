<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=company";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'info' && submitcheck('company_id')){
    $outArr = array(
        'code'=> 1,
    );
        
    $company_id = intval($_GET['company_id'])>0? intval($_GET['company_id']):0;
    
    $companyInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($company_id);
    $companyInfo = array();
    if(!empty($companyInfoTmp)){
        
        $companyInfo = $companyInfoTmp;
        
        $userInfoTmp     = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($companyInfo['user_id']);
        $natureInfoTmp   = C::t('#tom_tcrenzheng#tom_tcrenzheng_nature')->fetch_by_id($companyInfo['nature_id']);
        $industryInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_by_id($companyInfo['industry_id']);
        $scaleInfoTmp    = C::t('#tom_tcrenzheng#tom_tcrenzheng_scale')->fetch_by_id($companyInfo['scale_id']);
        
        $photoListTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company_photo')->fetch_all_list(" AND company_id={$company_id} ", 'ORDER BY id DESC', 0, 100);
        $photoList = array();
        if(is_array($photoListTmp) && !empty($photoListTmp)){
            foreach($photoListTmp as $key => $value){
                $photoList[$key] = $value;
                $photoList[$key]['picurl'] = get_file_url($value['picurl']);
            }
        }
        
        $logo  = get_file_url($companyInfo['logo']);
        $business_license    = get_file_url($companyInfo['business_license']);

        $companyInfo['userInfo']          = $userInfoTmp;
        $companyInfo['natureInfo']        = $natureInfoTmp;
        $companyInfo['industryInfo']      = $industryInfoTmp;
        $companyInfo['scaleInfo']         = $scaleInfoTmp;
        $companyInfo['logo']              = $logo;
        $companyInfo['business_license']  = $business_license;
        $companyInfo['photoList']         = $photoList;
        
    }
    
    $companyInfo = iconv_to_utf8($companyInfo);
    $outArr = array(
        'code'  => 200,
        "msg"   => "",
        "data"  => $companyInfo
    );
    echo json_encode($outArr); exit; //dism - taobao _ com
}else if($act == 'del' && submitcheck('company_id')){
    $outArr = array(
        'code'=> 1,
    );

    $company_id  = intval($_GET['company_id'])>0 ? intval($_GET['company_id']):0;
    
    C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->delete_by_id($company_id);
    C::t('#tom_tcrenzheng#tom_tcrenzheng_company_photo')->delete_by_company_id($company_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit; //dism - taobao _ com
}else if($act == 'shenhe' && submitcheck('company_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $company_id     = intval($_GET['company_id'])>0 ? intval($_GET['company_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $companyInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_id($company_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($companyInfo['user_id']);
    
    $site_id = 1;
    if($userInfo['site_id'] > 0){
        $site_id = $userInfo['site_id'];
    }
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['first_shenhe']     = 1;
        $updateData['shenhe_status']    = 1;
        C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->update($company_id,$updateData);
                
        $shenhe = str_replace('{NAME}', $companyInfo['name'], $Lang['template_company_shenhe_ok']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcrenzheng&site='.$site_id.'&mod=index">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcrenzhengConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit; //dism - taobao _ com
                }
            }
        }

        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcrenzhengConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        if($__ShowTczhaopin == 1){
            @$r = tom_html_get($_G['siteurl'].'plugin.php?id=tom_tczhaopin:ajax&site=1&act=update_company_status_by_user_id&user_id='.$companyInfo['user_id']);
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status'] = 3;
        C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->update($company_id,$updateData);
        
        $shenhe = str_replace('{NAME}', $companyInfo['name'], $Lang['template_company_shenhe_no']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcrenzheng&site='.$site_id.'&mod=company">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=company");
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcrenzhengConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit; //dism - taobao _ com
                }
            }
        }
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcrenzhengConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }
    echo json_encode($outArr); exit; //dism - taobao _ com
}

$keyword            = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$credit_code        = isset($_GET['credit_code'])? addslashes($_GET['credit_code']):'';
$rz_tel             = isset($_GET['rz_tel'])? addslashes($_GET['rz_tel']):'';
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = '';
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}
if(!empty($credit_code)){
    $whereStr.= " AND credit_code='{$credit_code}' ";
}
if(!empty($rz_tel)){
    $whereStr.= " AND rz_tel='{$rz_tel}' ";
}
if(!empty($shenhe_status)){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}

$order = "ORDER BY id DESC";

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_count($whereStr,$keyword);
$companyListTmp  = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_list($whereStr,$order,$start,$pagesize,$keyword);
$companyList = array();
if(!empty($companyListTmp)){
    foreach ($companyListTmp as $key => $value) {
        $companyList[$key] = $value;
        
        $companyList[$key]['logo']      = get_file_url($value['logo']);
        
        $userInfoTmp     = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        $natureInfoTmp   = C::t('#tom_tcrenzheng#tom_tcrenzheng_nature')->fetch_by_id($value['nature_id']);
        $industryInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_industry')->fetch_by_id($value['industry_id']);
        $scaleInfoTmp    = C::t('#tom_tcrenzheng#tom_tcrenzheng_scale')->fetch_by_id($value['scale_id']);
        
        $companyList[$key]['userInfo']              = $userInfoTmp;
        $companyList[$key]['natureInfo']            = $natureInfoTmp;
        $companyList[$key]['industryInfo']          = $industryInfoTmp;
        $companyList[$key]['scaleInfo']             = $scaleInfoTmp;
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&credit_code={$credit_code}&rz_tel={$rz_tel}&shenhe_status={$shenhe_status}&keyword={$keyword}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcrenzheng:pcadmin/company");