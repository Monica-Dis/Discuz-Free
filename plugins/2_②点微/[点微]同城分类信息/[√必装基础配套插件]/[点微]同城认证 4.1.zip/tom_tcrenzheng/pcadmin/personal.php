<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=personal";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'info' && submitcheck('personal_id')){
    $outArr = array(
        'code'=> 1,
    );
        
    $personal_id = intval($_GET['personal_id'])>0? intval($_GET['personal_id']):0;
    
    $personalInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_id($personal_id);
    $personalInfo = array();
    if(!empty($personalInfoTmp)){
        
        $personalInfo = $personalInfoTmp;
        
        $userInfoTmp     = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($companyInfo['user_id']);
       
        $card_shou    = get_file_url($personalInfo['card_shou']);
        $card_zheng   = get_file_url($personalInfo['card_zheng']);
        $card_fan     = get_file_url($personalInfo['card_fan']);

        $personalInfo['userInfo']          = $userInfoTmp;
        $personalInfo['card_shou']         = $card_shou;
        $personalInfo['card_zheng']        = $card_zheng;
        $personalInfo['card_fan']          = $card_fan;
        
    }
    
    $personalInfo = iconv_to_utf8($personalInfo);
    $outArr = array(
        'code'  => 200,
        "msg"   => "",
        "data"  => $personalInfo
    );
    echo json_encode($outArr); exit; //dism - taobao _ com
}else if($act == 'del' && submitcheck('personal_id')){
    $outArr = array(
        'code'=> 1,
    );

    $personal_id  = intval($_GET['personal_id'])>0 ? intval($_GET['personal_id']):0;
    
    C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->delete_by_id($personal_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit; //dism - taobao _ com
}else if($act == 'shenhe' && submitcheck('personal_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $personal_id    = intval($_GET['personal_id'])>0 ? intval($_GET['personal_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $personalInfo = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_id($personal_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($personalInfo['user_id']);
    
    $site_id = 1;
    if($userInfo['site_id'] > 0){
        $site_id = $userInfo['site_id'];
    }
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status']    = 1;
        C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->update($personal_id,$updateData);
                
        $shenhe = $Lang['template_personal_shenhe_ok'];
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcrenzhengConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit; //dism - taobao _ com
                }
            }
        }

        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcrenzhengConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status'] = 3;
        C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->update($personal_id,$updateData);
        
        $shenhe = $Lang['template_personal_shenhe_no'];
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=personal");
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcrenzhengConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit; //dism - taobao _ com
                }
            }
        }
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcrenzhengConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }
    echo json_encode($outArr); exit; //dism - taobao _ com
}

$keyword            = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$rz_tel             = isset($_GET['rz_tel'])? addslashes($_GET['rz_tel']):'';
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = '';
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}
if(!empty($rz_tel)){
    $whereStr.= " AND rz_tel='{$rz_tel}' ";
}
if(!empty($shenhe_status)){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}

$order = "ORDER BY add_time DESC,id DESC";

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_all_count($whereStr,$keyword);
$personalListTmp  = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_all_list($whereStr,$order,$start,$pagesize,$keyword);
$personalList = array();
if(!empty($personalListTmp)){
    foreach ($personalListTmp as $key => $value) {
        $personalList[$key] = $value;
        
        $userInfoTmp     = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        
        $personalList[$key]['userInfo']              = $userInfoTmp;
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&rz_tel={$rz_tel}&shenhe_status={$shenhe_status}&keyword={$keyword}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcrenzheng:pcadmin/personal");