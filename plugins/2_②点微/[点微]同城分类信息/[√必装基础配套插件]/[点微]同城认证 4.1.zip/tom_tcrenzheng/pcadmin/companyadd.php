<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=companyadd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id            = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $nature_id          = intval($_GET['nature_id'])>0? intval($_GET['nature_id']):0;
    $industry_id        = intval($_GET['industry_id'])>0? intval($_GET['industry_id']):0;
    $scale_id           = intval($_GET['scale_id'])>0? intval($_GET['scale_id']):0;
    $credit_code        = isset($_GET['credit_code'])? addslashes($_GET['credit_code']):'';
    $rz_name            = isset($_GET['rz_name'])? addslashes($_GET['rz_name']):'';
    $rz_tel             = isset($_GET['rz_tel'])? addslashes($_GET['rz_tel']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $logo               = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    $business_license   = isset($_GET['business_license'])? addslashes($_GET['business_license']):'';
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
    }
  
    $insertData = array();
    $insertData['user_id']            = $user_id;
    $insertData['name']               = $name;
    $insertData['nature_id']          = $nature_id;
    $insertData['industry_id']        = $industry_id;
    $insertData['scale_id']           = $scale_id;
    $insertData['credit_code']        = $credit_code;
    $insertData['rz_name']            = $rz_name;
    $insertData['rz_tel']             = $rz_tel;
    $insertData['tel']                = $tel;
    $insertData['address']            = $address;
    $insertData['content']            = $content;
    $insertData['logo']               = $logo;
    $insertData['business_license']   = $business_license;
    $insertData['first_shenhe']       = 1;
    $insertData['shenhe_status']      = 1;
    $insertData['add_time']           = TIMESTAMP;
    $company_id = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->insert($insertData, true);    
        
    if($company_id > 0){
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['company_id']   = $company_id;
                $insertData['picurl']       = $value['picurl'];
                $insertData['add_time']     = TIMESTAMP;
                C::t("#tom_tcrenzheng#tom_tcrenzheng_company_photo")->insert($insertData);
            }
        }

        $outArr = array(
            'code'=> 200,
            'id'=> $company_id,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit; //dism - taobao _ com
    }
}

$natureListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_nature")->fetch_all_list("", 'ORDER BY nsort ASC,id DESC', 0, 100);
$natureList = array();
if(is_array($natureListTmp) && !empty($natureListTmp)){
    foreach($natureListTmp as $key => $value){
        $natureList[$key] = $value;
    }
}

$industryListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_industry")->fetch_all_list("", 'ORDER BY isort ASC,id DESC', 0, 100);
$industryList = array();
if(is_array($industryListTmp) && !empty($industryListTmp)){
    foreach($industryListTmp as $key => $value){
        $industryList[$key] = $value;
    }
}

$scaleListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_scale")->fetch_all_list("", 'ORDER BY ssort ASC,id DESC', 0, 100);
$scaleList = array();
if(is_array($scaleListTmp) && !empty($scaleListTmp)){
    foreach($scaleListTmp as $key => $value){
        $scaleList[$key] = $value;
    }
}

$addUrl = $modPcadminUrl."&act=add";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcrenzheng:pcadmin/companyadd");