<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH; //D IS M.TA OBAO.C OM
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20210319";

$pcadminUrl = 'plugin.php?id=tom_tcrenzheng:pcadmin';
$ajaxUrl = 'plugin.php?id=tom_admin:ajax';
$uploadUrl = 'plugin.php?id=tom_admin:upload';
$baidumapUrl = 'plugin.php?id=tom_admin:baidumap';

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/config/pcadmin.lang.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

$Lang = $pcadminLang;

## tczhaopin start
$__ShowTczhaopin = 0;
$tczhaopinConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')){
    $tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
    if($tczhaopinConfig['open_tczhaopin'] == 1){
        $__ShowTczhaopin = 1;
    }
}
## tczhaopin end

include DISCUZ_ROOT.'./source/plugin/tom_admin/login_check.php';

if($_GET['tmod'] == 'company'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/pcadmin/company.php';
}else if($_GET['tmod'] == 'companyadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/pcadmin/companyadd.php';
}else if($_GET['tmod'] == 'companyedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/pcadmin/companyedit.php';
}else if($_GET['tmod'] == 'personal'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/pcadmin/personal.php';
}else if($_GET['tmod'] == 'personaladd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/pcadmin/personaladd.php';
}else if($_GET['tmod'] == 'personaledit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/pcadmin/personaledit.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/pcadmin/company.php';
}