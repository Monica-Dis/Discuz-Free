<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_admin/config/power.config.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_pc.php';

$__Admin = array();

$fromAdmin = getcookie('tom_admin');
$fromAdminKey = getcookie('tom_admin_key');
$adminKey = md5($appid.'_'.$fromAdmin.'_'.$appsecret);
if($fromAdminKey != $adminKey){
    include template("tom_admin:error");exit;
}

if($fromAdmin == 'admin'){
    $__Admin['admin'] = 'admin';
}else if($fromAdmin == 'shopadmin'){
    $__Admin['admin'] = 'shopadmin';
}else{
    include template("tom_admin:error");exit;
}

if(strpos($_GET['id'], ':')){
    $pluginIdTmp = array_shift(explode(':', $_GET['id']));
}else{
    $pluginIdTmp = $_GET['id'];
}

if($fromAdmin == 'admin'){
    $powerList = array();
    if(!empty($adminConfig['manage_user_id']) && $adminConfig['manage_user_id'] == $__UserInfo['id']){
        if(!empty($powerArr)){
            foreach($powerArr as $key => $value){
                $powerList[$value['id']] = array();
                foreach($value['data'] as $k => $v){
                    $powerList[$value['id']][] = $k;
                }
            }
        }
        
    }else{
        
        $addminManagerInfoTmp = C::t("#tom_admin#tom_admin_manager")->fetch_by_user_id($__UserInfo['id']);
        if(empty($addminManagerInfoTmp)){
            include template("tom_admin:error");exit;
        }
        
        $__Admin['manager'] = $addminManagerInfoTmp;
        
        $powerListTmp = C::t("#tom_admin#tom_admin_role_power")->fetch_all_list(" AND role_id={$__Admin['manager']['role_id']} ", "ORDER BY id ASC");
        if(!empty($powerListTmp)){
            foreach($powerListTmp as $key => $value){
                $powerList[$value['plugin_id']][] = $value['type'];
            }
        }
    }

    $__Admin['power_list'] = $powerList;
    
    $powerGroupId = '';
    if($pluginIdTmp == 'tom_tcshop'){
        $powerGroupId = 'shop';
    }else if($pluginIdTmp == 'tom_tcmall'){
        $powerGroupId = 'mall';
    }else if($pluginIdTmp == 'tom_tcqianggou'){
        $powerGroupId = 'qianggou';
    }else if($pluginIdTmp == 'tom_tcptuan'){
        $powerGroupId = 'ptuan';
    }else if($pluginIdTmp == 'tom_tckjia'){
        $powerGroupId = 'kjia';
    }else if($pluginIdTmp == 'tom_tczhaopin'){
        $powerGroupId = 'zhaopin';
    }else if($pluginIdTmp == 'tom_tcfangchan'){
        $powerGroupId = 'fangchan';
    }else if($pluginIdTmp == 'tom_tcyuyue'){
        $powerGroupId = 'yuyue';
    }else if($pluginIdTmp == 'tom_tongcheng'){
        $powerGroupId = 'tongcheng';

        if($_GET['tmod'] == 'user' || $_GET['tmod'] == 'userform' || $_GET['tmod'] == 'pmMessage'){
            $powerGroupId = 'user';
        }
    }else if($pluginIdTmp == 'tom_zppc'){
        $powerGroupId = 'zppc';
    }else if($pluginIdTmp == 'tom_fcpc'){
        $powerGroupId = 'fcpc';
    }else if($pluginIdTmp == 'tom_tcrenzheng'){
        $powerGroupId = 'renzheng';
    }else if($pluginIdTmp == 'tom_tcedu'){
        $powerGroupId = 'edu';
    }else if($pluginIdTmp == 'tom_admin'){
        $powerGroupId = 'admin';
    }

    $powerGroupList = $__Admin['power_list'][$powerGroupId];

        
    $powerStatus = false;
    if($powerGroupId == 'shop'){
        if(($_GET['tmod'] == 'list' || $_GET['tmod'] == 'mallSet' || $_GET['tmod'] == 'clerk' || $_GET['tmod'] == 'viplog' || $_GET['tmod'] == 'add' || $_GET['tmod'] == 'edit') && in_array('list', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'pinglun' || $_GET['tmod'] == 'pinglunReplay') && in_array('pinglun', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'focuspic' || $_GET['tmod'] == 'focuspicadd' || $_GET['tmod'] == 'focuspicedit') && in_array('focuspic', $powerGroupList)){
            $powerStatus = true;
        }
    }else if($powerGroupId == 'mall'){
        if(($_GET['tmod'] == 'list' || $_GET['tmod'] == 'add' || $_GET['tmod'] == 'edit' || $_GET['tmod'] == 'optionlog' || $_GET['tmod'] == 'stocklog' || $_GET['tmod'] == 'pinglun'|| $_GET['tmod'] == 'goodsorder' || $_GET['tmod'] == 'goodsorderinfo') && in_array('list', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'order' || $_GET['tmod'] == 'orderinfo') && in_array('order', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'coupon' || $_GET['tmod'] == 'couponadd' || $_GET['tmod'] == 'couponedit' || $_GET['tmod'] == 'lingqulist') && in_array('coupon', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'shoprecom') && in_array('shoprecom', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'focuspic' || $_GET['tmod'] == 'focuspicadd' || $_GET['tmod'] == 'focuspicedit') && in_array('focuspic', $powerGroupList)){
            $powerStatus = true;
        }
    }else if($powerGroupId == 'qianggou'){
        if(($_GET['tmod'] == 'list' || $_GET['tmod'] == 'add' || $_GET['tmod'] == 'edit' || $_GET['tmod'] == 'stocklog' || $_GET['tmod'] == 'option' || $_GET['tmod'] == 'goodsshop' || $_GET['tmod'] == 'goodsshopadd' || $_GET['tmod'] == 'goodsshopedit' || $_GET['tmod'] == 'goodsshopuselog' || $_GET['tmod'] == 'code' || $_GET['tmod'] == 'xubuy') && in_array('list', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'coupon' || $_GET['tmod'] == 'couponadd' || $_GET['tmod'] == 'couponedit' || $_GET['tmod'] == 'stocklog') && in_array('coupon', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'trade' || $_GET['tmod'] == 'tradeadd' || $_GET['tmod'] == 'tradeedit') && in_array('trade', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'order' || $_GET['tmod'] == 'orderuselog' || $_GET['tmod'] == 'orderinfo') && in_array('order', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'popup' || $_GET['tmod'] == 'popupadd' || $_GET['tmod'] == 'popupedit') && in_array('popup', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'group' || $_GET['tmod'] == 'groupadd' || $_GET['tmod'] == 'groupedit') && in_array('group', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'focuspic' || $_GET['tmod'] == 'focuspicadd' || $_GET['tmod'] == 'focuspicedit') && in_array('focuspic', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'recom_cate' || $_GET['tmod'] == 'recom_cate_add' || $_GET['tmod'] == 'recom_cate_edit') && in_array('recom_cate', $powerGroupList)){
            $powerStatus = true;
        }
    }else if($powerGroupId == 'ptuan'){
        if(($_GET['tmod'] == 'list' || $_GET['tmod'] == 'add' || $_GET['tmod'] == 'edit' || $_GET['tmod'] == 'stocklog') && in_array('list', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'tuan') && in_array('tuan', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'order' || $_GET['tmod'] == 'orderinfo') && in_array('order', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'focuspic' || $_GET['tmod'] == 'focuspicadd' || $_GET['tmod'] == 'focuspicedit') && in_array('focuspic', $powerGroupList)){
            $powerStatus = true;
        }
    }else if($powerGroupId == 'kjia'){
        if(($_GET['tmod'] == 'list' || $_GET['tmod'] == 'add' || $_GET['tmod'] == 'edit' || $_GET['tmod'] == 'stocklog') && in_array('list', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'kanjia' || $_GET['tmod'] == 'kanjialog') && in_array('kanjia', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'order' || $_GET['tmod'] == 'orderinfo') && in_array('order', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'focuspic' || $_GET['tmod'] == 'focuspicadd' || $_GET['tmod'] == 'focuspicedit') && in_array('focuspic', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'jubao') && in_array('jubao', $powerGroupList)){
            $powerStatus = true;
        }
    }else if($powerGroupId == 'zhaopin'){
        if(($_GET['tmod'] == 'list' || $_GET['tmod'] == 'add' || $_GET['tmod'] == 'edit' || $_GET['tmod'] == 'doDaoZhaopin' || $_GET['tmod'] == 'shenqing') && in_array('list', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'resume' || $_GET['tmod'] == 'resumeadd' || $_GET['tmod'] == 'resumeedit' || $_GET['tmod'] == 'doDaoResume' || $_GET['tmod'] == 'shenqing') && in_array('resume', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'shenqing') && in_array('shenqing', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'order') && in_array('order', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'company' || $_GET['tmod'] == 'add') && in_array('company', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'meeting' || $_GET['tmod'] == 'meetingadd' || $_GET['tmod'] == 'meetingedit' || $_GET['tmod'] == 'meeting_companylist') && in_array('meeting', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'uservip' || $_GET['tmod'] == 'uselist' || $_GET['tmod'] == 'paylist') && in_array('uservip', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'jubao') && in_array('jubao', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'focuspic' || $_GET['tmod'] == 'focuspicadd'  || $_GET['tmod'] == 'focuspicedit' ) && in_array('focuspic', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'popup' || $_GET['tmod'] == 'popupadd' || $_GET['tmod'] == 'popupedit') && in_array('popup', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'wxqun' || $_GET['tmod'] == 'wxqunadd' || $_GET['tmod'] == 'wxqunedit') && in_array('wxqun', $powerGroupList)){
            $powerStatus = true;
        }
        
    }else if($powerGroupId == 'fangchan'){
        if(($_GET['tmod'] == 'list' || $_GET['tmod'] == 'add' || $_GET['tmod'] == 'edit' || $_GET['tmod'] == 'doDaoFangchan' || $_GET['tmod'] == 'choose_houses' || $_GET['tmod'] == 'guanzulist') && in_array('list', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'needs' || $_GET['tmod'] == 'needsadd' || $_GET['tmod'] == 'needsedit') && in_array('needs', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'order') && in_array('order', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'newhouses' || $_GET['tmod'] == 'newhousesadd' || $_GET['tmod'] == 'newhousesedit' || $_GET['tmod'] == 'newhouses_guanzulist' || $_GET['tmod'] == 'doDaoNewhousesGuanzu' || $_GET['tmod'] == 'adviser' || $_GET['tmod'] == 'adviseradd' || $_GET['tmod'] == 'adviseredit') && in_array('newhouses', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'houses' || $_GET['tmod'] == 'housesadd' || $_GET['tmod'] == 'housesedit' || $_GET['tmod'] == 'houses_guanzulist') && in_array('houses', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'trade') && in_array('trade', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'mendian' || $_GET['tmod'] == 'mendianadd' || $_GET['tmod'] == 'mendianedit' || $_GET['tmod'] == 'viplog') && in_array('mendian', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'agent' || $_GET['tmod'] == 'agentadd' || $_GET['tmod'] == 'agentedit') && in_array('agent', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'guanggao' || $_GET['tmod'] == 'guanggaoadd' || $_GET['tmod'] == 'guanggaoedit') && in_array('guanggao', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'jubao') && in_array('jubao', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'focuspic' || $_GET['tmod'] == 'focuspicadd'  || $_GET['tmod'] == 'focuspicedit' ) && in_array('focuspic', $powerGroupList)){
            $powerStatus = true;
        }
        
    }else if($powerGroupId == 'yuyue'){
        if(($_GET['tmod'] == 'list' || $_GET['tmod'] == 'add' || $_GET['tmod'] == 'edit' || $_GET['tmod'] == 'attr' || $_GET['tmod'] == 'attradd' || $_GET['tmod'] == 'attredit' || $_GET['tmod'] == 'clerk') && in_array('list', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'modeltimetype' || $_GET['tmod'] == 'modeltime') && in_array('modeltimetype', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'yuyueuser') && in_array('yuyueuser', $powerGroupList)){
            $powerStatus = true;
        }
        
    }else if($powerGroupId == 'zppc'){
        
        if(($_GET['tmod'] == 'focuspic' || $_GET['tmod'] == 'focuspicadd'  || $_GET['tmod'] == 'focuspicedit' ) && in_array('focuspic', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'guanggao' || $_GET['tmod'] == 'guanggaoadd'  || $_GET['tmod'] == 'guanggaoedit' ) && in_array('guanggao', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'about' || $_GET['tmod'] == 'aboutadd'  || $_GET['tmod'] == 'aboutedit' ) && in_array('about', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'links' || $_GET['tmod'] == 'linksadd'  || $_GET['tmod'] == 'linksedit' ) && in_array('links', $powerGroupList)){
            $powerStatus = true;
        }

    }else if($powerGroupId == 'fcpc'){
        
        if(($_GET['tmod'] == 'focuspic' || $_GET['tmod'] == 'focuspicadd'  || $_GET['tmod'] == 'focuspicedit' ) && in_array('focuspic', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'guanggao' || $_GET['tmod'] == 'guanggaoadd'  || $_GET['tmod'] == 'guanggaoedit' ) && in_array('guanggao', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'about' || $_GET['tmod'] == 'aboutadd'  || $_GET['tmod'] == 'aboutedit' ) && in_array('about', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'links' || $_GET['tmod'] == 'linksadd'  || $_GET['tmod'] == 'linksedit' ) && in_array('links', $powerGroupList)){
            $powerStatus = true;
        }

    }else if($powerGroupId == 'renzheng'){
        
        if(($_GET['tmod'] == 'company' || $_GET['tmod'] == 'companyadd' || $_GET['tmod'] == 'companyedit' ) && in_array('company', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'personal' || $_GET['tmod'] == 'personaladd' || $_GET['tmod'] == 'personaledit' ) && in_array('personal', $powerGroupList)){
            $powerStatus = true;
        }

    }else if($powerGroupId == 'tongcheng'){
        if(($_GET['tmod'] == 'list' || $_GET['tmod'] == 'add' || $_GET['tmod'] == 'edit' || $_GET['tmod'] == 'doDao') && in_array('list', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'order') && in_array('order', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'pinglun') && in_array('pinglun', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'tousu') && in_array('tousu', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'popup' || $_GET['tmod'] == 'popupadd' || $_GET['tmod'] == 'popupedit') && in_array('popup', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'focuspic' || $_GET['tmod'] == 'focuspicadd' || $_GET['tmod'] == 'focuspicedit') && in_array('focuspic', $powerGroupList)){
            $powerStatus = true;
        }

    }else if($powerGroupId == 'user'){
        if(($_GET['tmod'] == 'user' || $_GET['tmod'] == 'userform') && in_array('user', $powerGroupList)){
            $powerStatus = true;
        }

        if(($_GET['tmod'] == 'pmMessage') && in_array('pmMessage', $powerGroupList)){
            $powerStatus = true;
        }
    }else if($powerGroupId == 'edu'){
        if(($_GET['tmod'] == 'list' || $_GET['tmod'] == 'add' || $_GET['tmod'] == 'edit' || $_GET['tmod'] == 'teacher' || $_GET['tmod'] == 'pinglun' || $_GET['tmod'] == 'coursecate' || $_GET['tmod'] == 'guanzu' || $_GET['tmod'] == 'attr' || $_GET['tmod'] == 'viplog' || $_GET['tmod'] == 'common') && in_array('list', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'course' || $_GET['tmod'] == 'courseadd' || $_GET['tmod'] == 'courseedit' || $_GET['tmod'] == 'coursecollect' || $_GET['tmod'] == 'coursebm' || $_GET['tmod'] == 'bmlog') && in_array('course', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'coursebm') && in_array('coursebm', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'order' || $_GET['tmod'] == 'coursebminfo') && in_array('order', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'vip' || $_GET['tmod'] == 'vipadd' || $_GET['tmod'] == 'vipedit' || $_GET['tmod'] == 'vipcode') && in_array('vip', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'cate') && in_array('cate', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'phb' || $_GET['tmod'] == 'phbedu') && in_array('phb', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'diynav') && in_array('diynav', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'focuspic') && in_array('focuspic', $powerGroupList)){
            $powerStatus = true;
        }
        
        if(($_GET['tmod'] == 'popup') && in_array('popup', $powerGroupList)){
            $powerStatus = true;
        }
    }

    if($powerGroupId == 'admin'){
        $powerStatus = true;
    }

    if($powerStatus === false){
        include template("tom_admin:error");exit;
    }
}else if($fromAdmin == 'shopadmin'){
    
    if($pluginIdTmp == 'tom_shopadmin' || $pluginIdTmp == 'tom_tcshop' || $pluginIdTmp == 'tom_tcmall' || $pluginIdTmp == 'tom_tcqianggou' || $pluginIdTmp == 'tom_tcptuan' || $pluginIdTmp == 'tom_tckjia' || $pluginIdTmp == 'tom_tcyuyue'){
        
        $myTcshopListCount = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND (pay_status = 0 OR pay_status = 2) ");
        if($myTcshopListCount > 0){
        }else{
            include template("tom_admin:error");exit;
        }
        
    }else{
        include template("tom_admin:error");exit;
    }
    
}