<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_tom_weixin_subuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `open_id` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `headimgurl` varchar(255) DEFAULT NULL,
  `sex` int(11) DEFAULT '0',
  `country` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `up_time` int(11) DEFAULT '0',
  `sub_time` int(11) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_weixin_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_id` int(11) DEFAULT '0',
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `media_id` varchar(255) DEFAULT NULL,
  `appid` varchar(255) DEFAULT NULL,
  `pagepath` varchar(255) DEFAULT NULL,
  `msort` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_weixin_qrcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `qkey` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qkey` (`qkey`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_weixin_fqrcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `qkey` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `extend` varchar(255) DEFAULT NULL,
  `tcshop_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qkey` (`qkey`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$sql = '';

$tom_weixin_subuser_field = C::t('#tom_weixin#tom_weixin_subuser')->fetch_all_field();
if (!isset($tom_weixin_subuser_field['nickname'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_weixin_subuser')." ADD `nickname` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_weixin_subuser_field['headimgurl'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_weixin_subuser')." ADD `headimgurl` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_weixin_subuser_field['sex'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_weixin_subuser')." ADD `sex` int(11) DEFAULT '0';\n";
}
if (!isset($tom_weixin_subuser_field['country'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_weixin_subuser')." ADD `country` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_weixin_subuser_field['province'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_weixin_subuser')." ADD `province` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_weixin_subuser_field['city'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_weixin_subuser')." ADD `city` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_weixin_subuser_field['up_time'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_weixin_subuser')." ADD `up_time` int(11) DEFAULT '0';\n";
}

$tom_weixin_qrcode_field = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_all_field();
if (!isset($tom_weixin_qrcode_field['extend'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_weixin_qrcode')." ADD `extend` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_weixin_qrcode_field['user_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_weixin_qrcode')." ADD `user_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_weixin_qrcode_field['tcshop_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_weixin_qrcode')." ADD `tcshop_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_weixin_qrcode_field['tcchoujiang_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_weixin_qrcode')." ADD `tcchoujiang_id` int(11) DEFAULT '0';\n";
}

if (!empty($sql)) {
	runquery($sql);
}

$finish = TRUE; /*dism��taobao��com*/

