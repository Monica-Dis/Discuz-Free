<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=menu';
$modListUrl = $adminListUrl.'&tmod=menu';
$modFromUrl = $adminFromUrl.'&tmod=menu';

if($_GET['act'] == 'add'){
    
    $menuCount = C::t('#tom_weixin#tom_weixin_menu')->fetch_all_count(" AND sub_id=0 ");
    
    if($menuCount >= 3){
        cpmsg($Lang['menu_add_error'], $modListUrl, 'error');
    }
    
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_weixin#tom_weixin_menu')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        loadeditorjs();/*Dism��taobao��com*/
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();/*Dism_taobao_com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao-com*/
        showformfooter();/*dis'.'m.tao'.'bao.com*/
    }
    
}else if($_GET['act'] == 'addchild'){
    
    $sub_id       = isset($_GET['sub_id'])? intval($_GET['sub_id']):0;
    
    $menuCount = C::t('#tom_weixin#tom_weixin_menu')->fetch_all_count(" AND sub_id={$sub_id} ");
    
    if($menuCount >= 5){
        cpmsg($Lang['menu_addchild_error'], $modListUrl, 'error');
    }
    
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['sub_id'] = $sub_id;
        C::t('#tom_weixin#tom_weixin_menu')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        loadeditorjs();/*Dism��taobao��com*/
        __create_nav_html();
        showformheader($modFromUrl.'&act=addchild&sub_id='.$sub_id,'enctype');
        showtableheader();/*Dism_taobao_com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao-com*/
        showformfooter();/*dis'.'m.tao'.'bao.com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $menuInfo = C::t('#tom_weixin#tom_weixin_menu')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($menuInfo);
        C::t('#tom_weixin#tom_weixin_menu')->update($menuInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        loadeditorjs();/*Dism��taobao��com*/
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();/*Dism_taobao_com*/
        __create_info_html($menuInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao-com*/
        showformfooter();/*dis'.'m.tao'.'bao.com*/
    }
}else if($_GET['act'] == 'editchild'){
    $menuInfo = C::t('#tom_weixin#tom_weixin_menu')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($menuInfo);
        C::t('#tom_weixin#tom_weixin_menu')->update($menuInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        loadeditorjs();/*Dism��taobao��com*/
        __create_nav_html();
        showformheader($modFromUrl.'&act=editchild&id='.$_GET['id'],'enctype');
        showtableheader();/*Dism_taobao_com*/
        __create_info_html($menuInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao-com*/
        showformfooter();/*dis'.'m.tao'.'bao.com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_weixin#tom_weixin_menu')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'create'){
    
    $returnData = getHtml("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={$appId}&secret={$appSecret}");
    $returnArr = array();
    $returnArr = json_decode($returnData, true);

	$access_token = '';
	if(isset($returnArr['access_token'])){
		$access_token = $returnArr['access_token'];
	}else{
        $returnArr['errmsg'] = diconv($returnArr['errmsg'], 'utf-8', CHARSET);
        echo $returnArr['errmsg'];exit;
	}
    
    $replaceData    = array();
    $menuData       = array();
    $menuList       = C::t('#tom_weixin#tom_weixin_menu')->fetch_all_list(" AND sub_id=0 "," ORDER BY msort ASC,id DESC ",0,3);
    if(is_array($menuList) && !empty($menuList)){
        foreach ($menuList as $key => $value){
            
            $value['name'] = diconv($value['name'],CHARSET,'utf-8');
            $value['key'] = diconv($value['key'],CHARSET,'utf-8');
            
            $replaceData['name_'.$value['id'].'_']      = trim($value['name']);
            $replaceData['key_'.$value['id'].'_']       = trim($value['key']);
            $replaceData['url_'.$value['id'].'_']       = trim($value['url']);
            $replaceData['pagepath_'.$value['id'].'_']  = trim($value['pagepath']);
            
            $menuData[$key]['name'] = 'name_'.$value['id'].'_';
            
            $subMenu = array();
            $childCateList = C::t('#tom_weixin#tom_weixin_menu')->fetch_all_list(" AND sub_id={$value['id']} "," ORDER BY msort ASC,id DESC ",0,5);
            if(is_array($childCateList) && !empty($childCateList)){
                foreach ($childCateList as $k => $v){
                    
                    $v['name'] = diconv($v['name'],CHARSET,'utf-8');
                    $v['key'] = diconv($v['key'],CHARSET,'utf-8');
                    
                    $replaceData['name_'.$v['id'].'_']      = trim($v['name']);
                    $replaceData['key_'.$v['id'].'_']       = trim($v['key']);
                    $replaceData['url_'.$v['id'].'_']       = trim($v['url']);
                    $replaceData['pagepath_'.$v['id'].'_']  = trim($v['pagepath']);
                    
                    $subMenu[$k]['name'] = 'name_'.$v['id'].'_';
                    if($v['type'] == 'click'){
                        $subMenu[$k]['type']         = 'click';
                        $subMenu[$k]['key']          = 'key_'.$v['id'].'_';
                    }else if($v['type'] == 'view'){
                        $subMenu[$k]['type']         = 'view';
                        $subMenu[$k]['url']          = 'url_'.$v['id'].'_';
                    }else if($v['type'] == 'miniprogram'){
                        $subMenu[$k]['type']         = 'miniprogram';
                        $subMenu[$k]['url']          = 'url_'.$v['id'].'_';
                        $subMenu[$k]['appid']        = $v['appid'];
                        $subMenu[$k]['pagepath']     = 'pagepath_'.$v['id'].'_';
                    }
                }
                $menuData[$key]['sub_button'] = $subMenu;
            }else{
                if($value['type'] == 'click'){
                    $menuData[$key]['type']         = 'click';
                    $menuData[$key]['key']          = 'key_'.$value['id'].'_';
                }else if($value['type'] == 'view'){
                    $menuData[$key]['type']         = 'view';
                    $menuData[$key]['url']          = 'url_'.$value['id'].'_';
                }else if($value['type'] == 'miniprogram'){
                    $menuData[$key]['type']         = 'miniprogram';
                    $menuData[$key]['url']          = 'url_'.$value['id'].'_';
                    $menuData[$key]['appid']        = $value['appid'];
                    $menuData[$key]['pagepath']     = 'pagepath_'.$value['id'].'_';
                }
            }
            
        }
    }
    
    $data = array();
    $data['button'] = $menuData;
    $dateStr = json_encode($data);
    foreach ($replaceData as $kk => $vv){
        $dateStr = str_replace($kk, $vv, $dateStr);
    }
    
    $response   = postDataCurl($dateStr, 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token='.$access_token);
    $returnData = json_decode($response,true);
    if(isset($returnData['errmsg']) && $returnData['errmsg'] == 'ok'){
        cpmsg($Lang['menu_create_succ'], $modListUrl, 'succeed');
    }else if(isset($returnData['errcode']) && $returnData['errcode'] == '40018'){
        cpmsg($Lang['act_success'], $modListUrl, 'error');
    }else{
        echo $returnData['errmsg'];exit;
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'delete'){
    
    $returnData = getHtml("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={$appId}&secret={$appSecret}");
    $returnArr = array();
    $returnArr = json_decode($returnData, true);

	$access_token = '';
	if(isset($returnArr['access_token'])){
		$access_token = $returnArr['access_token'];
	}else{
        $returnArr['errmsg'] = diconv($returnArr['errmsg'], 'utf-8', CHARSET);
        echo $returnArr['errmsg'];exit;
	}
    
    getHtml('https://api.weixin.qq.com/cgi-bin/menu/delete?access_token='.$access_token);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    showtableheader();/*Dism_taobao_com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['menu_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['menu_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();/*Dism_taobao-com*/
    
    $menuList = C::t('#tom_weixin#tom_weixin_menu')->fetch_all_list(" AND sub_id=0 "," ORDER BY msort ASC,id DESC ",0,10);
    __create_nav_html();
    showtableheader();/*Dism_taobao_com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['menu_name'] . '</th>';
    echo '<th>' . $Lang['menu_type'] . '</th>';
    echo '<th>' . $Lang['menu_param'] . '</th>';
    echo '<th>' . $Lang['menu_msort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    foreach ($menuList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        if($value['type'] == 'click'){
            echo '<td><font color="#fd0d0d">' . $Lang['menu_type_click'] . '</font></td>';
            echo '<td>' . $value['key'] . '</td>';
        }else if($value['type'] == 'view'){
            echo '<td><font color="#0894fb">' . $Lang['menu_type_view'] . '</font></td>';
            echo '<td>' . $value['url'] . '</td>';
        }else if($value['type'] == 'miniprogram'){
            echo '<td><font color="#238206">' . $Lang['menu_type_miniprogram'] . '</font></td>';
            echo '<td>' . $value['pagepath'] . '</td>';
        }
        echo '<td>' . $value['msort'] . '</td>';
        echo '<td>';
        if($value['sub_id'] == 0){
            echo '<a href="'.$modBaseUrl.'&act=addchild&sub_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['menu_addchild']. '</a>&nbsp;|&nbsp;';
        }
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['menu_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $childCateList = C::t('#tom_weixin#tom_weixin_menu')->fetch_all_list(" AND sub_id={$value['id']} "," ORDER BY msort ASC,id DESC ",0,10);
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $k => $v){
                echo '<tr style="background-color: #f6f6f6;">';
                echo '<td><img src="source/plugin/tom_weixin/images/menu_admin_ico.png?v=3" style="vertical-align: top;"/>&nbsp;' . $v['name'] . '</td>';
                if($v['type'] == 'click'){
                    echo '<td><font color="#fd0d0d">' . $Lang['menu_type_click'] . '</font></td>';
                    echo '<td>' . $v['key'] . '</td>';
                }else if($v['type'] == 'view'){
                    echo '<td><font color="#0894fb">' . $Lang['menu_type_view'] . '</font></td>';
                    echo '<td>' . $v['url'] . '</td>';
                }else if($v['type'] == 'miniprogram'){
                    echo '<td><font color="#238206">' . $Lang['menu_type_miniprogram'] . '</font></td>';
                    echo '<td>' . $v['pagepath'] . '</td>';
                }
                echo '<td>' . $v['msort'] . '</td>';
                echo '<td>';
                echo '<a href="'.$modBaseUrl.'&act=editchild&id='.$v['id'].'&formhash='.FORMHASH.'">' . $Lang['menu_editchild']. '</a>&nbsp;|&nbsp;';
                echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$v['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
                echo '</td>';
                echo '</tr>';
            }
        }
    }
    showtablefooter();/*Dism_taobao-com*/
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $type               = isset($_GET['type'])? addslashes($_GET['type']):'';
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $key                = isset($_GET['key'])? addslashes($_GET['key']):'';
    $url                = isset($_GET['url'])? addslashes($_GET['url']):'';
    $appid              = isset($_GET['appid'])? addslashes($_GET['appid']):'';
    $pagepath           = isset($_GET['pagepath'])? addslashes($_GET['pagepath']):'';
    $msort              = isset($_GET['msort'])? intval($_GET['msort']):10;
    

    $data['type']            = $type;
    $data['name']            = $name;
    $data['key']             = $key;
    $data['url']             = $url;
    $data['appid']           = $appid;
    $data['pagepath']        = $pagepath;
    $data['msort']           = $msort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'type'                 => 'click',
        'name'                 => '',
        'key'                  => '',
        'url'                  => '',
        'appid'                => '',
        'pagepath'             => '',
        'msort'                => 10,
    );
    $options = array_merge($options, $infoArr);
    
    $type_item = array('click'=>$Lang['menu_type_click'],'view'=>$Lang['menu_type_view'],'miniprogram'=>$Lang['menu_type_miniprogram']);
    tomshowsetting(array('title'=>$Lang['menu_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['menu_type_msg'],'item'=>$type_item),"radio");
    tomshowsetting(array('title'=>$Lang['menu_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['menu_name_msg']),"input");
    tomshowsetting(array('title'=>$Lang['menu_key'],'name'=>'key','value'=>$options['key'],'msg'=>$Lang['menu_key_msg']),"input");
    tomshowsetting(array('title'=>$Lang['menu_url'],'name'=>'url','value'=>$options['url'],'msg'=>$Lang['menu_url_msg']),"input");
    tomshowsetting(array('title'=>$Lang['menu_appid'],'name'=>'appid','value'=>$options['appid'],'msg'=>$Lang['menu_appid_msg']),"input");
    tomshowsetting(array('title'=>$Lang['menu_pagepath'],'name'=>'pagepath','value'=>$options['pagepath'],'msg'=>$Lang['menu_pagepath_msg']),"input");
    tomshowsetting(array('title'=>$Lang['menu_msort'],'name'=>'msort','value'=>$options['msort'],'msg'=>$Lang['menu_msort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['menu_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['menu_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['menu_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['menu_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['menu_edit'],"",true);
    }else if($_GET['act'] == 'addchild'){
        tomshownavli($Lang['menu_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['menu_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['menu_addchild'],"",true);
    }else if($_GET['act'] == 'editchild'){
        tomshownavli($Lang['menu_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['menu_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['menu_editchild'],"",true);
    }else{
        tomshownavli($Lang['menu_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['menu_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['menu_create'],$modBaseUrl."&act=create",false);
        tomshownavli($Lang['menu_delete'],$modBaseUrl."&act=delete",false);
        
    }
    tomshownavfooter();/*DisM �� Taobao - Com*/
}

function getHtml($url){
    if(function_exists('curl_init')){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $return = curl_exec($ch);
        curl_close($ch); 
        return $return;
    }
    return false;
}

function postDataCurl($data, $url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,FALSE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $return = curl_exec($ch);
    if($return){
        curl_close($ch);
        return $return;
    } else { 
        $error = curl_errno($ch);
        curl_close($ch);
        return false;
    }
}