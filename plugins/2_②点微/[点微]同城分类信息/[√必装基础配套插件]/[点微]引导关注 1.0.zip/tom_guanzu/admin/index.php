<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_guanzu#tom_guanzu')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
        loadeditorjs();/*Dism��taobao��com*/
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();/*Dism_taobao_com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao-com*/
        showformfooter();/*dis'.'m.tao'.'bao.com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $guanzuInfo = C::t('#tom_guanzu#tom_guanzu')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($guanzuInfo);
        C::t('#tom_guanzu#tom_guanzu')->update($guanzuInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
        loadeditorjs();/*Dism��taobao��com*/
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();/*Dism_taobao_com*/
        __create_info_html($guanzuInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao-com*/
        showformfooter();/*dis'.'m.tao'.'bao.com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    C::t('#tom_guanzu#tom_guanzu')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{

    $pagesize = 15;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_guanzu#tom_guanzu')->fetch_all_count(" ");
    $guanzuList = C::t('#tom_guanzu#tom_guanzu')->fetch_all_list(" ","ORDER BY add_time DESC",$start,$pagesize);
    __create_nav_html();
    showtableheader();/*Dism_taobao_com*/
    echo '<tr class="header">';
    echo '<th width="10%">ID</th>';
    echo '<th>' . $Lang['guanzu_title'] . '</th>';
    echo '<th>' . $Lang['guanzu_url'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($guanzuList as $key => $value) {
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $value['title'] . '</td>';
        echo '<td>'.$_G['siteurl'].'plugin.php?id=tom_guanzu&gid=' . $value['id'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['guanzu_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism_taobao-com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $qrcode_msg         = isset($_GET['qrcode_msg'])? addslashes($_GET['qrcode_msg']):'';
    $canjia_msg         = isset($_GET['canjia_msg'])? addslashes($_GET['canjia_msg']):'';
    $help_msg           = isset($_GET['help_msg'])? addslashes($_GET['help_msg']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $pic_url = "";
    if($_GET['act'] == 'add'){
        $pic_url        = tomuploadFile("pic_url");
    }else if($_GET['act'] == 'edit'){
        $pic_url        = tomuploadFile("pic_url",$infoArr['pic_url']);
    }
    
    $qrcode_url = "";
    if($_GET['act'] == 'add'){
        $qrcode_url        = tomuploadFile("qrcode_url");
    }else if($_GET['act'] == 'edit'){
        $qrcode_url        = tomuploadFile("qrcode_url",$infoArr['qrcode_url']);
    }
    
    $data['title']         = $title;
    $data['pic_url']       = $pic_url;
    $data['qrcode_url']    = $qrcode_url;
    $data['qrcode_msg']    = $qrcode_msg;
    $data['canjia_msg']    = $canjia_msg;
    $data['help_msg']      = $help_msg;
    $data['content']       = $content;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'title'          => $Lang['guanzu_title_value'],
        'pic_url'        => "",
        'qrcode_url'     => "",
        'qrcode_msg'     => $Lang['guanzu_qrcode_value'],
        'canjia_msg'     => $Lang['guanzu_canjia_msg_value'],
        'help_msg'       => $Lang['guanzu_help_msg_value'],
        'content'        => "",
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(array('title'=>$Lang['guanzu_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['guanzu_title_msg']),"input");
    tomshowsetting(array('title'=>$Lang['guanzu_pic_url'],'name'=>'pic_url','value'=>$options['pic_url'],'msg'=>$Lang['guanzu_pic_url_msg']),"file");
    tomshowsetting(array('title'=>$Lang['guanzu_qrcode_url'],'name'=>'qrcode_url','value'=>$options['qrcode_url'],'msg'=>$Lang['guanzu_qrcode_url_msg']),"file");
    tomshowsetting(array('title'=>$Lang['guanzu_qrcode_msg'],'name'=>'qrcode_msg','value'=>$options['qrcode_msg'],'msg'=>$Lang['guanzu_qrcode_msg_msg']),"textarea");
    tomshowsetting(array('title'=>$Lang['guanzu_canjia_msg'],'name'=>'canjia_msg','value'=>$options['canjia_msg'],'msg'=>$Lang['guanzu_canjia_msg_msg']),"textarea");
    tomshowsetting(array('title'=>$Lang['guanzu_help_msg'],'name'=>'help_msg','value'=>$options['help_msg'],'msg'=>$Lang['guanzu_help_msg_msg']),"textarea");
    tomshowsetting(array('title'=>$Lang['guanzu_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['guanzu_content_msg']),"text");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['guanzu_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['guanzu_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['guanzu_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['guanzu_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['guanzu_edit'],"",true);
    }else{
        tomshownavli($Lang['guanzu_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['guanzu_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();/*DisM �� Taobao - Com*/
}
//From: Dism_ taobao- com
?>
