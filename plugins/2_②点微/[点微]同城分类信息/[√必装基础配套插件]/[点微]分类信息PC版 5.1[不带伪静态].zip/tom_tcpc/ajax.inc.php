<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tcpcConfig = $_G['cache']['plugin']['tom_tcpc'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;

## tcadmin start
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
## tcadmin end
## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tcrenzheng start
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')){
    $tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
    if($tcrenzhengConfig['open_tcrenzheng'] == 1){
        $__ShowTcrenzheng = 1;
    }
}
## tcrenzheng end
## tczhaopin start
$__ShowTczhaopin = 0;
$tczhaopinConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')){
    $tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
    if($tczhaopinConfig['open_tczhaopin'] == 1){
        $__ShowTczhaopin = 1;
    }
}
## tczhaopin end
## tcpinche start
$__ShowTcpinche = 0;
$tcpincheConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcpinche/tom_tcpinche.inc.php')){
    $tcpincheConfig = $_G['cache']['plugin']['tom_tcpinche'];
    $__ShowTcpinche = 1;
}
## tcpinche end
## tcfangchan start
$__ShowFangchan = 0;
$tcfangchanConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/tom_tcfangchan.inc.php')){
    $tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
    if($tcfangchanConfig['open_tcfangchan'] == 1){
        $__ShowFangchan = 1;
    }
}
## tcfangchan end
## video start
$__ShowVideo = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/video.inc.php')){
    $__ShowVideo = 1;
}
## video end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';

if($_GET['act'] == 'update_tongcheng' && submitcheck('tongcheng_ids')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $tongcheng_ids = isset($_GET['tongcheng_ids'])? addslashes($_GET['tongcheng_ids']):'';
    
    $tongchengIdsArr = explode('|', $tongcheng_ids);
    $tongchengIdsStr = '';
    if(is_array($tongchengIdsArr) && !empty($tongchengIdsArr)){
        $tongchengIdsList = array();
        foreach ($tongchengIdsArr as $key => $value){
            $value = intval($value);
            if($value > 0){
                $tongchengIdsList[] = $value;
            }
        }
        $tongchengIdsStr = implode(',', $tongchengIdsList);
    }

    if(empty($tongchengIdsStr)){
        echo 301;exit;
    }
    
    $tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list("AND id IN({$tongchengIdsStr})","ORDER BY id DESC",0,100);
    foreach ($tongchengListTmp as $key => $value) {

        $typeInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($value['type_id']);

        if($value['finish'] == 0 && $value['topstatus'] == 0 && $typeInfoTmp['over_time_attr_id'] > 0 && $typeInfoTmp['over_time_do'] > 0){
            $tongchengAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id={$value['id']} AND attr_id={$typeInfoTmp['over_time_attr_id']} "," ORDER BY id DESC ",0,1);
            if(is_array($tongchengAttrInfoTmp) && !empty($tongchengAttrInfoTmp) && $tongchengAttrInfoTmp[0] && $tongchengAttrInfoTmp[0]['time_value'] > 0){
                if($tongchengAttrInfoTmp[0]['time_value'] < TIMESTAMP){
                    if($typeInfoTmp['over_time_do'] == 1){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2,finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($typeInfoTmp['over_time_do'] == 2){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }
                }
            }
        }

        if($typeInfoTmp['jifei_type'] == 2 && $value['over_days'] > 0){
            if($value['topstatus'] == 0 && $value['finish'] == 0){
                if($value['over_time'] < TIMESTAMP){
                    if($tongchengConfig['over_time_do'] == 1){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($tongchengConfig['over_time_do'] == 2){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2,finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($tongchengConfig['over_time_do'] == 4){
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }
                }
            }
        }else{
            if($value['topstatus'] == 0 && $value['finish'] == 0 && $tongchengConfig['over_time_limit'] > 0){
                if(($value['refresh_time']+$tongchengConfig['over_time_limit']*86400) < TIMESTAMP){
                    if($tongchengConfig['over_time_do'] == 1){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($tongchengConfig['over_time_do'] == 2){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2,finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($tongchengConfig['over_time_do'] == 4){
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }
                }
            }
        }

        if($tongchengConfig['open_load_list_clicks'] == 1){
            if($value['tczhaopin_id'] > 0 && $__ShowTczhaopin == 1){
                DB::query("UPDATE ".DB::table('tom_tczhaopin')." SET clicks=clicks+1 WHERE id='{$value['tczhaopin_id']}' ", 'UNBUFFERED');
            }else if($value['tczhaopin_resume_id'] > 0 && $__ShowTczhaopin == 1){
                DB::query("UPDATE ".DB::table('tom_tczhaopin_resume')." SET clicks=clicks+1 WHERE id='{$value['tczhaopin_resume_id']}' ", 'UNBUFFERED');
            }else if($value['tcfangchan_id'] > 0 && $__ShowFangchan == 1){
                DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET clicks=clicks+1 WHERE id='{$value['tcfangchan_id']}' ", 'UNBUFFERED');
            }else{
                DB::query("UPDATE ".DB::table('tom_tongcheng')." SET clicks=clicks+1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
            }
        }
        
    }

    echo 200;exit;
    
}else{
    echo 'error';exit;
}