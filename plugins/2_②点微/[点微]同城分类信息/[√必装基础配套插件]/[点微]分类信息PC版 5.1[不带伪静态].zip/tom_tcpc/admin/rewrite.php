<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=rewrite';
$modListUrl = $adminListUrl.'&tmod=rewrite';
$modFromUrl = $adminFromUrl.'&tmod=rewrite';


if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcpc/rewrite.rule.php')){
    
    if($tcpcConfig['open_rewrite'] == 1){
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['rewrite_help_title'] . '</th></tr>';
        echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
        echo '<li>' . $Lang['rewrite_help_1'] . '</li>';
        echo '</ul></td></tr>';
        showtablefooter(); /*Dism_taobao_com*/
        echo "<br/>";
        include DISCUZ_ROOT.'./source/plugin/tom_tcpc/rewrite.rule.php';
    }else{
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['rewrite_help_title'] . '</th></tr>';
        echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
        echo '<li>' . $Lang['rewrite_no_open'] . '</li>';
        echo '</ul></td></tr>';
        showtablefooter(); /*Dism_taobao_com*/
    }
    
}else{
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['rewrite_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['rewrite_no_msg'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*Dism_taobao_com*/
}