<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);
$tcpcConfig         = $_G['cache']['plugin']['tom_tcpc'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

if('utf-8' != CHARSET) {
    if(defined('IN_MOBILE')) {}else{
        foreach($_POST AS $pk => $pv) {
            if(!is_numeric($pv)) {
                $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
            }
        }
    }
}

$qrcode_title   = isset($_GET['qrcode_title'])? daddslashes($_GET['qrcode_title']):'';
$qrcode_link	= isset($_GET['qrcode_link'])? daddslashes($_GET['qrcode_link']):'';
$qrcode_picurl	= isset($_GET['qrcode_picurl'])? daddslashes($_GET['qrcode_picurl']):'';
$qrcode_desc	= isset($_GET['qrcode_desc'])? daddslashes($_GET['qrcode_desc']):'';
$allow_wxqrcode = intval($_GET['allow_wxqrcode'])>0? intval($_GET['allow_wxqrcode']):0;


if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
    include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
}else{
    echo 'QR|phpqrcode';exit;
}

$qrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tcpc/data/qrcode/'.md5($qrcode_link).'_qrcode.png';
$qrcodeUrl = $_G['siteurl'].'source/plugin/tom_tcpc/data/qrcode/'.md5($qrcode_link).'_qrcode.png';

$wxqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tcpc/data/qrcode/'.md5($qrcode_link).'_wxqrcode'.date("Ymd").'.png';
$wxqrcodeUrl = $_G['siteurl'].'source/plugin/tom_tcpc/data/qrcode/'.md5($qrcode_link).'_wxqrcode'.date("Ymd").'.png';

$tempDir = "/source/plugin/tom_tcpc/data/qrcode/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0755); 
}

$outQrcodeUrl = '';
if($tcpcConfig['open_wxqrcode'] == 1 && $allow_wxqrcode == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_weixin/tom_weixin.inc.php')){
    
    $qrcodeKey  = md5($qrcode_link);
    $qrcodeInfo = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_by_qkey($qrcodeKey);
    $qrcodeId = 0;
    if($qrcodeInfo){
        $qrcodeId = $qrcodeInfo['id'];
        $updateData = array();
        $updateData['title']  = $qrcode_title;
        $updateData['picurl'] = $qrcode_picurl;
        $updateData['desc']   = $qrcode_desc;
        C::t('#tom_weixin#tom_weixin_qrcode')->update($qrcodeId,$updateData);
    }else{
        
        $qrcodeList = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_all_list(" ","ORDER BY id DESC",0,1);
        $qrcodeId = 100001;
        if(is_array($qrcodeList) && !empty($qrcodeList) && isset($qrcodeList['0']) && $qrcodeList['0']['id']>100000){
            $qrcodeId = $qrcodeList['0']['id']+1;
        }
        
        $insertData = array();
        $insertData['id']       = $qrcodeId;
        $insertData['qkey']     = $qrcodeKey;
        $insertData['title']    = $qrcode_title;
        $insertData['picurl']   = $qrcode_picurl;
        $insertData['desc']     = $qrcode_desc;
        $insertData['link']     = $qrcode_link;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_weixin#tom_weixin_qrcode')->insert($insertData);
        $qrcodeId = C::t('#tom_weixin#tom_weixin_qrcode')->insert_id();
    }
    
    if(file_exists($wxqrcodeImg)){
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        $access_token = $weixinClass->get_access_token();

        $dateStr = '{"expire_seconds": 2592000, "action_name": "QR_SCENE", "action_info": {"scene": {"scene_id": '.$qrcodeId.'}}}';
        $response   = postDataCurl($dateStr, 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token);
        $returnData = json_decode($response,true);
        if(isset($returnData['ticket']) &&  !empty($returnData['ticket'])){
            $wx_pic_content = getHtml('https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$returnData['ticket']);
            if(false === file_put_contents($wxqrcodeImg,$wx_pic_content)){
            }
        }
    }
    
    $outQrcodeUrl = $wxqrcodeUrl;
}else{
    if(file_exists($qrcodeImg)){
    }else{
        QRcode::png($qrcode_link,$qrcodeImg,'H',5,2);
    }
    $outQrcodeUrl = $qrcodeUrl;
}

echo 'OK|'.$outQrcodeUrl;exit;

function getHtml($url){
    if(function_exists('curl_init')){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $return = curl_exec($ch);
        curl_close($ch); 
        return $return;
    }
    return false;
}

function postDataCurl($data, $url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,FALSE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $return = curl_exec($ch);
    if($return){
        curl_close($ch);
        return $return;
    } else { 
        $error = curl_errno($ch);
        curl_close($ch);
        return false;
    }
}