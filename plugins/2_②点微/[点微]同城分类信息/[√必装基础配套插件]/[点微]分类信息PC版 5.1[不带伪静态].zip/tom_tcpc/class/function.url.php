<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function tom_tcpc_url($mod,$site,$param = array()){
    global $_G,$__ShowTcpcRewrite;
    
    $tcpcConfig = $_G['cache']['plugin']['tom_tcpc'];
    
    $url = '';
    
    $rewrite = 0;
    if($tcpcConfig['open_rewrite'] == 1 && $__ShowTcpcRewrite == 1){
        $rewrite = 1;
    }
    
    if($site > 0){}else{
        $site = 1;
    }
    
    if($mod == 'index'){
        if($rewrite == 1){
            if($site > 1){
                $url = $_G['siteurl'].$tcpcConfig['rewrite_site_name']."-{$site}.html";
            }else{
                $url = $_G['siteurl'].$tcpcConfig['rewrite_index_name'].".html";
            }
        }else{
            $url = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site}&mod=index";
        }
        
    }else if($mod == 'list'){
        if($rewrite == 1){
            $model_id = $type_id = 0;
            $page = 1;
            if(isset($param['model_id']) && $param['model_id'] > 0){
                $model_id = $param['model_id'];
            }
            if(isset($param['type_id']) && $param['type_id'] > 0){
                $type_id = $param['type_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $_G['siteurl'].$tcpcConfig['rewrite_fenlei_name']."/list-{$site}-{$model_id}-{$type_id}-{$page}.html";
        }else{
            $url = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site}&mod=list";
            if(isset($param['model_id']) && $param['model_id'] > 0){
                $url = $url."&model_id={$param['model_id']}";
            }
            if(isset($param['type_id']) && $param['type_id'] > 0){
                $url = $url."&type_id={$param['type_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
        
    }else if($mod == 'info'){
        if($rewrite == 1){
            $url = $_G['siteurl'].$tcpcConfig['rewrite_fenlei_name']."/info-{$site}-{$param['tongcheng_id']}.html";
        }else{
            $url = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site}&mod=info&xxid={$param['tongcheng_id']}";
        }
        
    }else if($mod == 'home'){
        if($rewrite == 1){
            $page = 1;
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $_G['siteurl'].$tcpcConfig['rewrite_fenlei_name']."/home-{$site}-{$param['user_id']}-{$page}.html";
        }else{
            $url = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site}&mod=home&user_id={$param['user_id']}";
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
        
    }else if($mod == 'about'){
        if($rewrite == 1){
            $url = $_G['siteurl'].$tcpcConfig['rewrite_fenlei_name']."/about-{$site}-{$param['about_id']}.html";
        }else{
            $url = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site}&mod=about&about_id={$param['about_id']}";
        }
        
    }else if($mod == 'toutiao'){
        if($rewrite == 1){
            $cate_id = 0;
            $page = 1;
            if(isset($param['cate_id']) && $param['cate_id'] > 0){
                $cate_id = $param['cate_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $_G['siteurl'].$tcpcConfig['rewrite_toutiao_name']."/list-{$site}-{$cate_id}-{$page}.html";
        }else{
            $url = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site}&mod=toutiao";
            if(isset($param['cate_id']) && $param['cate_id'] > 0){
                $url = $url."&cate_id={$param['cate_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
        
    }else if($mod == 'toutiaoinfo'){
        if($rewrite == 1){
            $url = $_G['siteurl'].$tcpcConfig['rewrite_toutiao_name']."/info-{$site}-{$param['tctoutiao_id']}.html";
        }else{
            $url = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site}&mod=toutiaoinfo&aid={$param['tctoutiao_id']}";
        }
        
    }else if($mod == 'toutiaozuozhe'){
        if($rewrite == 1){
            $type = 0;
            $page = 1;
            if(isset($param['type']) && $param['type'] > 0){
                $type = $param['type'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $_G['siteurl'].$tcpcConfig['rewrite_toutiao_name']."/zuozhe-{$site}-{$param['zuozhe_id']}-{$type}-{$page}.html";
        }else{
            $url = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site}&mod=toutiaozuozhe&zuozhe_id={$param['zuozhe_id']}";
            if(isset($param['type']) && $param['type'] > 0){
                $url = $url."&type={$param['type']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
        
    }else if($mod == 'shop'){
        if($rewrite == 1){
            $url = $_G['siteurl'].$tcpcConfig['rewrite_shop_name']."/shop-{$site}.html";
        }else{
            $url = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site}&mod=shop";
        }
        
    }else if($mod == 'shoplist'){
        if($rewrite == 1){
            $cate_id = $cate_child_id = 0;
            $page = 1;
            if(isset($param['cate_id']) && $param['cate_id'] > 0){
                $cate_id = $param['cate_id'];
            }
            if(isset($param['cate_child_id']) && $param['cate_child_id'] > 0){
                $cate_child_id = $param['cate_child_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $_G['siteurl'].$tcpcConfig['rewrite_shop_name']."/list-{$site}-{$cate_id}-{$cate_child_id}-{$page}.html";
        }else{
            $url = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site}&mod=shoplist";
            if(isset($param['cate_id']) && $param['cate_id'] > 0){
                $url = $url."&cate_id={$param['cate_id']}";
            }
            if(isset($param['cate_child_id']) && $param['cate_child_id'] > 0){
                $url = $url."&cate_child_id={$param['cate_child_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
    }else if($mod == 'shopinfo'){
        if($rewrite == 1){
            $url = $_G['siteurl'].$tcpcConfig['rewrite_shop_name']."/info-{$site}-{$param['tcshop_id']}.html";
        }else{
            $url = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site}&mod=shopinfo&dpid={$param['tcshop_id']}";
        }
    }
    
    return $url;
    
}