<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(isset($_GET['xxid'])){
    $tongcheng_id = intval($_GET['xxid'])>0? intval($_GET['xxid']):0;
}else{
    $tongcheng_id = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
}

if($__Mobile == 1 && $tcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=view&xxid={$tongcheng_id}");exit;
}

$tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);

if(!$tongchengInfo || $tongchengInfo['shenhe_status'] != 1){
    dheader('location:'."{$indexUrl}");exit;
}

$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengInfo['user_id']);
if(!$userInfo){
    DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2,finish=1 WHERE id='{$tongchengInfo['id']}' ", 'UNBUFFERED');
    dheader('location:'."{$indexUrl}");exit;
}

if(!preg_match('/^http/', $userInfo['picurl']) ){
    $userInfo['picurl'] = $_G['siteurl'].$userInfo['picurl'];
}

$modelInfo = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($tongchengInfo['model_id']);
$typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
$cateInfo = array();
if($tongchengInfo['cate_id'] > 0){
    $cateInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_by_id($tongchengInfo['cate_id']);
    if($cateInfoTmp){
        $cateInfo = $cateInfoTmp;
    }
}
$attrList = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY paixu ASC,id DESC ",0,50);
$tagList = C::t('#tom_tongcheng#tom_tongcheng_tag')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id DESC ",0,50);

$addressStr = "";
$areaNameTmp = '';
if(!empty($tongchengInfo['area_id'])){
    $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengInfo['area_id']);
    $areaNameTmp = $areaInfoTmp['name'];
}
$streetNameTmp = '';
if(!empty($tongchengInfo['street_id'])){
    $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengInfo['street_id']);
    $streetNameTmp = $streetInfoTmp['name'];
}
if(!empty($areaNameTmp)){
    $addressStr = $areaNameTmp." ".$streetNameTmp;
}

$modelUrl = tom_tcpc_url('list',$site_id,array('model_id'=>$modelInfo['id']));
$infoUrl = tom_tcpc_url('info',$site_id,array('tongcheng_id'=>$tongchengInfo['id']));
$homeUrl = tom_tcpc_url('home',$site_id,array('user_id'=>$userInfo['id']));

$title = '';
if(!empty($tongchengInfo['title'])){
    $title = $tongchengInfo['title'];
}else{
    $contentTmp = contentFormat($tongchengInfo['content']);
    $contentTmp = strip_tags($contentTmp);
    $contentTmp = str_replace("\r\n","",$contentTmp);
    $contentTmp = str_replace("\n","",$contentTmp);
    $contentTmp = str_replace("\r","",$contentTmp);
    $title = cutstr($contentTmp,50,"...");
}
if($sfcModelInfo && $sfcModelInfo['id'] > 0 && $tongchengInfo['model_id'] == $sfcModelInfo['id'] ){
    $sfcInfo = array();
    if(is_array($attrList) && !empty($attrList)){
        foreach ($attrList as $key => $value){
            if($value['attr_id'] == $sfcTypeArr[$value['type_id']]['sfc_chufa_attr_id']){
                $sfcInfo['chufa'] = $value['value'];
            }
            if($value['attr_id'] == $sfcTypeArr[$value['type_id']]['sfc_mude_attr_id']){
                $sfcInfo['mude'] = $value['value'];
            }
            if($value['attr_id'] == $sfcTypeArr[$value['type_id']]['sfc_time_attr_id']){
                $sfcInfo['time'] = dgmdate($value['time_value'],"Y-m-d H:i",$tomSysOffset);
                $sfcInfo['int_time'] = $value['time_value'];
            }
            if($value['attr_id'] == $sfcTypeArr[$value['type_id']]['sfc_renshu_attr_id']){
                $sfcInfo['renshu'] = $value['value'];
            }
        }
    }
    if(!empty($sfcInfo) && !empty($tcpcConfig['sfc_title'])){
        $sfcTitle   = str_replace("{TYPENAME}",$typeInfo['name'],$tcpcConfig['sfc_title']);
        $sfcTitle   = str_replace("{CHUFA}",$sfcInfo['chufa'],$sfcTitle);
        $sfcTitle   = str_replace("{MUDE}",$sfcInfo['mude'],$sfcTitle);
        $sfcTitle   = str_replace("{TIME}",$sfcInfo['time'],$sfcTitle);
        $title = $sfcTitle;
    }
}

$title = preg_replace("/\d{7}/", '*****', $title);

$contentInfo = C::t('#tom_tongcheng#tom_tongcheng_content')->fetch_by_tongcheng_id($tongchengInfo['id']);
$showNewContent = 0;
$newContent = '';
if($contentInfo && $contentInfo['is_show'] == 1){
    $showNewContent = 1;
    $newContent = stripslashes($contentInfo['content']);
}

$newContent = str_replace('src="source/plugin/', 'src="'.$_G['siteurl'].'source/plugin/', $newContent);
$newContent = str_replace('src="data/attachment/', 'src="'.$_G['siteurl'].'data/attachment/', $newContent);

$content = contentFormat($tongchengInfo['content']);
$content = str_replace("\r\n","<br/>",$content);
$content = str_replace("\n","<br/>",$content);
$content = str_replace("\r","<br/>",$content);
$content = preg_replace("/\d{7}/", '*****', $content);

$tongchengInfo['tel'] = cutstr($tongchengInfo['tel'] ,4,"*******");

$mInfoUrl = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=info&xxid={$tongcheng_id}";

$baiduMapToName = diconv($title, CHARSET, 'utf-8');
$baiduMapToName = urlencode($baiduMapToName);
$baiduMapUrl = "https://api.map.baidu.com/marker?location={$tongchengInfo['latitude']},{$tongchengInfo['longitude']}&title={$baiduMapToName}&content=&output=html";

$photoCount = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_count(" AND tongcheng_id={$tongchengInfo['id']} ");
$photoListTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id ASC ",0,50);
$photoList = array();
$wxqrcode_picurl = $tongchengConfig['wxqrcode_src'];
$i = 1;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach ($photoListTmp as $kk => $vv){
        if($tongchengConfig['open_yun'] == 2 && !empty($vv['oss_picurl']) && $vv['oss_status'] == 1){
            $picurl = $vv['oss_picurl'];
        }else if($tongchengConfig['open_yun'] == 3 && !empty($vv['qiniu_picurl']) && $vv['qiniu_status'] == 1){
            $picurl = $vv['qiniu_picurl'];
        }else{
            if(!preg_match('/^http/', $vv['picurl']) ){
                if(strpos($vv['picurl'], 'source/plugin/tom_') === false){
                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                }else{
                    $picurl = $_G['siteurl'].$vv['picurl'];
                }
            }else{
                $picurl = $vv['picurl'];
            }
        }
        $photoList[$kk] = $picurl;
        if($i == 1){
            $wxqrcode_picurl = $picurl;
        }
        $i++;
    }
}
$photoListStr = implode('|', $photoList);

if(!empty($tongchengConfig['open_click_add'])){
    $randArr = explode('|', $tongchengConfig['open_click_add']);
    if(!empty($randArr) && is_array($randArr)){
        $minRand = intval($randArr[0]);
        $maxRand = intval($randArr[1]);
        $randNum = mt_rand($minRand, $maxRand);
        if($randNum > 0){
            DB::query("UPDATE ".DB::table('tom_tongcheng')." SET clicks=clicks+{$randNum} WHERE id='$tongcheng_id' ", 'UNBUFFERED');
        }else{
            DB::query("UPDATE ".DB::table('tom_tongcheng')." SET clicks=clicks+1 WHERE id='$tongcheng_id' ", 'UNBUFFERED');
        }
    }
}else{
    DB::query("UPDATE ".DB::table('tom_tongcheng')." SET clicks=clicks+1 WHERE id='$tongcheng_id' ", 'UNBUFFERED');
}

$companyRenzhengStatus = $personalRenzhengStatus = $depositStatus = 0;
if($__ShowTcrenzheng == 1){
    $companyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($userInfo['id']);
    if(is_array($companyInfoTmp) && $companyInfoTmp['shenhe_status'] == 1){
        $companyRenzhengStatus = 1;
    }
    $personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_user_id($userInfo['id']);
    if(is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1){
        $personalRenzhengStatus = 1;
    }
    $depositInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_by_user_id($userInfo['id']);
    if(is_array($depositInfoTmp) && $depositInfoTmp['order_status'] == 2){
        $depositStatus = 1;
    }
}

$where = " AND status=1 AND shenhe_status=1 AND id != {$tongcheng_id} AND model_id IN ({$showModelIdsStr})  ";
if(!empty($sql_in_site_ids)){
    $where.= " AND site_id IN({$sql_in_site_ids}) ";
}
if($tongchengConfig['open_finish_paixu'] == 1){
    if($tongchengConfig['top_paixu_type'] == 2){
        $order = " ORDER BY topstatus DESC,toptime DESC,finish ASC, refresh_time DESC,id DESC ";
    }else if($tongchengConfig['top_paixu_type'] == 3){
        $order = " ORDER BY topstatus DESC,finish ASC,refresh_time DESC,id DESC ";
    }else{
        $order = " ORDER BY topstatus DESC,toprand DESC,finish ASC, refresh_time DESC,id DESC ";
    }
}else{
    if($tongchengConfig['top_paixu_type'] == 2){
        $order = " ORDER BY topstatus DESC,toptime DESC, refresh_time DESC,id DESC ";
    }else if($tongchengConfig['top_paixu_type'] == 3){
        $order = " ORDER BY topstatus DESC,refresh_time DESC,id DESC ";
    }else{
        $order = " ORDER BY topstatus DESC,toprand DESC, refresh_time DESC,id DESC ";
    }
}
$tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list($where,$order,0,10);
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list_tongcheng.php';


$guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi=4 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi=4 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$fenleiYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        if($value['weizhi'] == 4){
            $fenleiYouList[] = $guanggaoItemTmp;
        }
    }
}

$seo_model_name = $seo_type_name = $seo_cate_name = '';
if(!empty($modelInfo)){
    $seo_model_name = $modelInfo['name'];
}
if(!empty($typeInfo)){
    $seo_type_name = $typeInfo['name'];
}
if(!empty($cateInfo)){
    $seo_cate_name = $cateInfo['name'];
}

$seo_title          = $tcpcConfig['seo_info_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{MODELBANE}",$seo_model_name, $seo_title);
$seo_title          = str_replace("{TYPENAME}",$seo_type_name, $seo_title);
$seo_title          = str_replace("{CATENAME}",$seo_cate_name, $seo_title);
$seo_title          = str_replace("{TITLE}",$title, $seo_title);

$seo_keywords       = $tcpcConfig['seo_info_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{MODELBANE}",$seo_model_name, $seo_keywords);
$seo_keywords       = str_replace("{TYPENAME}",$seo_type_name, $seo_keywords);
$seo_keywords       = str_replace("{CATENAME}",$seo_cate_name, $seo_keywords);
$seo_keywords       = str_replace("{TITLE}",$title, $seo_keywords);

$seo_description    = $tcpcConfig['seo_info_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{MODELBANE}",$seo_model_name, $seo_description);
$seo_description    = str_replace("{TYPENAME}",$seo_type_name, $seo_description);
$seo_description    = str_replace("{CATENAME}",$seo_cate_name, $seo_description);
$seo_description    = str_replace("{TITLE}",$title, $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcpc:info");