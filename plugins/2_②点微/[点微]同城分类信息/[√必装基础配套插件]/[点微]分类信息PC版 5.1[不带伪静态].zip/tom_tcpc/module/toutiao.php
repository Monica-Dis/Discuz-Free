<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page       = intval($_GET['page'])>0 ? intval($_GET['page']):1;
$cate_id    = intval($_GET['cate_id'])>0 ? intval($_GET['cate_id']):0;
$keyword    = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$keyword    = dhtmlspecialchars($keyword);

if($__Mobile == 1 && $tcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$site_id}&mod=index&cate_id={$cate_id}");exit;
}

$where = ' AND status=1 AND shenhe_status=1 AND index_show = 1  ';
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids},99) ";
}
if($cate_id > 0){
    $where .= " AND cate_id = {$cate_id} ";
}
if(!empty($keyword)){
    $keywordTmp = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND search_text LIKE '%{$keywordTmp}%'";
}

$order = " ORDER BY is_recom DESC,paixu ASC,add_time DESC,id DESC ";

$pagesize = 30;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_count($where);
$tctoutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list($where,$order,$start,$pagesize);
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list_toutiao.php';

$pageArr['link'] = tom_tcpc_url('toutiao',$site_id,array('cate_id'=>$cate_id,'page'=>'{page}'));
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$cateInfo = array();
if($cate_id > 0){
    $cateInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_cate')->fetch_by_id($cate_id);
    if($cateInfoTmp){
        $cateInfo = $cateInfoTmp;
    }
}

$cateListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_cate')->fetch_all_list(" AND is_show = 1 ", "ORDER BY csort ASC, id DESC", 0, 100);
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$key] = $value;
        $cateList[$key]['link'] = tom_tcpc_url('toutiao',$site_id,array('cate_id'=>$value['id']));;
    }
}

$listUrl = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site_id}&mod=toutiao&";

$focuspicListTmp = C::t('#tom_tcpc#tom_tcpc_focuspic')->fetch_all_list(" AND site_id={$site_id} AND type=2 "," ORDER BY fsort ASC,id DESC ");
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
}else if($site_id > 1){
    $focuspicListTmp = C::t('#tom_tcpc#tom_tcpc_focuspic')->fetch_all_list(" AND site_id=1 AND type=2 "," ORDER BY fsort ASC,id DESC ");
}
$focuspicList = array();
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
    foreach($focuspicListTmp as $key => $value){
        $focuspicList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $focuspicList[$key]['picurl'] = $picurl;
        $focuspicList[$key]['link'] = str_replace("{site}",$site_id, $value['link']);
    }
}
$focuspicCount = count($focuspicList);

$guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi=5 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi=5 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$toutiaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        if($value['weizhi'] == 5){
            $toutiaoYouList[] = $guanggaoItemTmp;
        }
    }
}

$seo_cate_name = '';
if(!empty($cateInfo)){
    $seo_cate_name = $cateInfo['name'];
}else{
    $seo_cate_name = $tcpcConfig['toutiao_title'];
}

$seo_title          = $tcpcConfig['seo_toutiao_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{CATENAME}",$seo_cate_name, $seo_title);

$seo_keywords       = $tcpcConfig['seo_toutiao_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CATENAME}",$seo_cate_name, $seo_keywords);

$seo_description    = $tcpcConfig['seo_toutiao_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{CATENAME}",$seo_cate_name, $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcpc:toutiao");