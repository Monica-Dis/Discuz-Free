<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$zuozhe_id = intval($_GET['zuozhe_id'])>0? intval($_GET['zuozhe_id']): 0;

if($__Mobile == 1 && $tcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$site_id}&mod=zuozheinfo&zuozhe_id={$zuozhe_id}");exit;
}

$zuozheInfo  = C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe")->fetch_by_id($zuozhe_id);

if(!$zuozheInfo){
    dheader('location:'."{$indexUrl}");exit;
}

if(!preg_match('/^http/', $zuozheInfo['picurl']) ){
    if(strpos($zuozheInfo['picurl'], 'source/plugin/tom_') === false){
        $zuozheLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$zuozheInfo['picurl'];
    }else{
        $zuozheLogo = $_G['siteurl'].$zuozheInfo['picurl'];
    }
}else{
    $zuozheLogo = $zuozheInfo['picurl'];
}
if(!preg_match('/^http/', $zuozheInfo['bgpic']) ){
    if(strpos($zuozheInfo['bgpic'], 'source/plugin/tom_') === false){
        $zuozheBgpic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$zuozheInfo['bgpic'];
    }else{
        $zuozheBgpic = $_G['siteurl'].$zuozheInfo['bgpic'];
    }
}else{
    $zuozheBgpic = $zuozheInfo['bgpic'];
}

#list start
$page       = intval($_GET['page'])>0 ? intval($_GET['page']):1;
$type       = intval($_GET['type'])>0 ? intval($_GET['type']):0;

$where = " AND status=1 AND shenhe_status=1 AND index_show = 1 AND zuozhe_id = {$zuozheInfo['id']} ";
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids},99) ";
}
if($type > 0){
    $where .= " AND type = {$type} ";
}
$order = " ORDER BY is_recom DESC,paixu ASC,add_time DESC,id DESC ";

$pagesize = 30;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_count($where);
$tctoutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list($where,$order,$start,$pagesize);
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list_toutiao.php';

$pageArr['link'] = tom_tcpc_url('toutiaozuozhe',$site_id,array('zuozhe_id'=>$zuozhe_id,'type'=>$type,'page'=>'{page}'));
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);
#list end

$type0Url = tom_tcpc_url('toutiaozuozhe',$site_id,array('zuozhe_id'=>$zuozhe_id,'type'=>0));
$type1Url = tom_tcpc_url('toutiaozuozhe',$site_id,array('zuozhe_id'=>$zuozhe_id,'type'=>1));
$type2Url = tom_tcpc_url('toutiaozuozhe',$site_id,array('zuozhe_id'=>$zuozhe_id,'type'=>2));
$type3Url = tom_tcpc_url('toutiaozuozhe',$site_id,array('zuozhe_id'=>$zuozhe_id,'type'=>3));

$guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi=5 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi=5 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$toutiaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        if($value['weizhi'] == 5){
            $toutiaoYouList[] = $guanggaoItemTmp;
        }
    }
}

$seo_title          = $tcpcConfig['seo_toutiaozuozhe_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{ZUOZHE}",$zuozheInfo['name'], $seo_title);

$seo_keywords       = $tcpcConfig['seo_toutiaozuozhe_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{ZUOZHE}",$zuozheInfo['name'], $seo_keywords);

$seo_description    = $tcpcConfig['seo_toutiaozuozhe_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{ZUOZHE}",$zuozheInfo['name'], $seo_description);


$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcpc:toutiaozuozhe");