<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tctoutiao_id   = intval($_GET['tctoutiao_id'])? intval($_GET['tctoutiao_id']):0;
$aid            = intval($_GET['aid'])? intval($_GET['aid']):0;

if($aid > 0){
    $tctoutiao_id = $aid;
}

if($__Mobile == 1 && $tcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$site_id}&mod=info&aid={$tctoutiao_id}");exit;
}

$tctoutiaoInfo = C::t("#tom_tctoutiao#tom_tctoutiao")->fetch_by_id($tctoutiao_id);

if($tctoutiaoInfo['id'] > 0){}else{
    dheader('location:'."{$toutiaoUrl}");exit;
}

$yearText = lang("plugin/tom_tcpc", 'year');
$monthText = lang("plugin/tom_tcpc", 'month');
$dayText = lang("plugin/tom_tcpc", 'day');
$add_time = dgmdate($tctoutiaoInfo['add_time'], 'u','9999',"Y{$yearText}m{$monthText}d{$dayText} H:i");

$infoUrl         = tom_tcpc_url('toutiaoinfo',$site_id,array('tctoutiao_id'=>$tctoutiaoInfo['id']));

$cateInfo = C::t('#tom_tctoutiao#tom_tctoutiao_cate')->fetch_by_id($tctoutiaoInfo['cate_id']);
$cateUrl = tom_tcpc_url('toutiao',$site_id,array('cate_id'=>$cateInfo['id']));;

$zuozheInfo = C::t("#tom_tctoutiao#tom_tctoutiao_zuozhe")->fetch_by_id($tctoutiaoInfo['zuozhe_id']);
if(!preg_match('/^http/', $zuozheInfo['picurl']) ){
    if(strpos($zuozheInfo['picurl'], 'source/plugin/tom_') === false){
        $zuozheLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$zuozheInfo['picurl'];
    }else{
        $zuozheLogo = $_G['siteurl'].$zuozheInfo['picurl'];
    }
}else{
    $zuozheLogo = $zuozheInfo['picurl'];
}

$zuozheUrl       = tom_tcpc_url('toutiaozuozhe',$site_id,array('zuozhe_id'=>$zuozheInfo['id']));

$tctoutiaoInfo['clicks'] = $tctoutiaoInfo['clicks'] + $tctoutiaoInfo['virtual_clicks'];

$showFufeiTemplate = 0;
if($tctoutiaoInfo['type'] == 1 || $tctoutiaoInfo['type'] == 3){
    if($tctoutiaoConfig['open_pay_reading'] == 1 && $tctoutiaoInfo['open_pay_reading'] == 1){
        $showFufeiTemplate = 1;
        $tctoutiaoInfo['app_read'] = 0;
        if($tctoutiaoInfo['type'] == 1){
            $tctoutiaoInfo['content']       = $tctoutiaoInfo['nopay_content'];
        }
        if($tctoutiaoInfo['type'] == 3){
            $tctoutiaoInfo['video_link']    = $tctoutiaoInfo['nopay_video_link'];
        }
    }
    $content = stripslashes($tctoutiaoInfo['content']);
    if($tongchengConfig['open_yun'] == 2 || $tongchengConfig['open_yun'] == 3){
        $photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(" AND tctoutiao_id = {$tctoutiao_id} AND type = 5 ",'ORDER BY psort ASC,id DESC', 0, 100);
        if(is_array($photoListTmp) && !empty($photoListTmp)){
            foreach($photoListTmp as $key => $value){
                if($value['is_yun_pic'] == 1){
                    $content = str_replace($value['picurl'], $value['picurlTmp'], $content);
                }
            }
        }
    }
}
$content = str_replace('src="source/plugin/', 'src="'.$_G['siteurl'].'source/plugin/', $content);
$content = str_replace('src="data/attachment/', 'src="'.$_G['siteurl'].'data/attachment/', $content);

if($tctoutiaoInfo['type'] == 2){
    $photoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(" AND tctoutiao_id = {$tctoutiao_id} AND type = 2 ",'ORDER BY psort ASC,id DESC', 0, 100);
    $photoList = array();
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach($photoListTmp as $key => $value){
            $photoList[$key] = $value;
        }
    }
}

if($tctoutiaoInfo['type'] == 3){
    ## video start
    $video_type = '';
    $video_id   = '';
    if(strpos($tctoutiaoInfo['video_link'], 'youku.com') !== FALSE){
        preg_match("#embed/(.*)#", $tctoutiaoInfo['video_link'], $matches);
        if(is_array($matches) && !empty($matches['1'])){
            $video_type = 'youku';
            $video_id = trim($matches['1']);
        }
    }else if(strpos($tctoutiaoInfo['video_link'], 'qq.com') !== FALSE){
        preg_match("#vid=([0-9a-zA-Z]*)#", $tctoutiaoInfo['video_link'], $matches);
        if(is_array($matches) && !empty($matches['1'])){
            $video_type = 'qq';
            $video_id = trim($matches['1']);
        }
    }else if(strpos($tctoutiaoInfo['video_link'], '.mp4') !== FALSE || strpos($tctoutiaoInfo['video_link'], '.MP4') !== FALSE){
        $video_type = 'video';
    }else if(strpos($tctoutiaoInfo['video_link'], '.MOV') !== FALSE || strpos($tctoutiaoInfo['video_link'], '.mov') !== FALSE){
        $video_type = 'video';
    }else{
        $video_type = 'other';
    }
    ## video end
}

$video_pic = '';
if($tctoutiaoInfo['type'] == 3){
    $photoInfoTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_admin_list(" AND tctoutiao_id = {$tctoutiaoInfo['id']} AND type = 3 ",'ORDER BY psort ASC,id DESC', 0, 1);
    if(!empty($photoInfoTmp[0]['picurlTmp'])){
        $video_pic = $photoInfoTmp[0]['picurlTmp'];
    }
}

$mInfoUrl = $_G['siteurl']."plugin.php?id=tom_tctoutiao&site={$site_id}&mod=info&aid={$tctoutiaoInfo['id']}";

$whereStr = " AND status=1 AND shenhe_status=1 AND id != {$tctoutiao_id} ";
if(!empty($sql_in_site_ids)){
    $whereStr .= " AND site_id IN({$sql_in_site_ids},99) ";
}
if($tctoutiaoConfig['info_show_toutiao_type'] == 1){
    $tctoutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list(" {$whereStr} AND id != {$tctoutiao_id} ", 'ORDER BY id DESC',0,10);
}else if($tctoutiaoConfig['info_show_toutiao_type'] == 2){
    $tctoutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_hot_list(" {$whereStr} AND id != {$tctoutiao_id} ",0,10);
}else if($tctoutiaoConfig['info_show_toutiao_type'] == 3){
    $tctoutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list(" {$whereStr} AND id != {$tctoutiao_id} AND cate_id = {$tctoutiaoInfo['cate_id']}  ", 'ORDER BY id DESC',0,10);
}else if($tctoutiaoConfig['info_show_toutiao_type'] == 4){
    $tctoutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list(" {$whereStr} AND id != {$tctoutiao_id} AND zuozhe_id = {$tctoutiaoInfo['zuozhe_id']}  ", 'ORDER BY id DESC',0,10);
}
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list_toutiao.php';

$ajaxClicksUrl = $_G['siteurl']."plugin.php?id=tom_tctoutiao:ajax&site={$site_id}&act=clicks&tctoutiao_id={$tctoutiao_id}&formhash=".$formhash;

$seo_cate_name = '';
if(!empty($cateInfo)){
    $seo_cate_name = $cateInfo['name'];
}else{
    $seo_cate_name = $tcpcConfig['toutiao_title'];
}

$seo_title          = $tcpcConfig['seo_toutiaoinfo_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{CATENAME}",$seo_cate_name, $seo_title);
$seo_title          = str_replace("{TITLE}",$tctoutiaoInfo['title'], $seo_title);

$seo_keywords       = $tcpcConfig['seo_toutiaoinfo_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CATENAME}",$seo_cate_name, $seo_keywords);
$seo_keywords       = str_replace("{TITLE}",$tctoutiaoInfo['title'], $seo_keywords);

$seo_description    = $tcpcConfig['seo_toutiaoinfo_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{CATENAME}",$seo_cate_name, $seo_description);
$seo_description    = str_replace("{TITLE}",$tctoutiaoInfo['title'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcpc:toutiaoinfo");