<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tongchengList = array();
$tongchengIdsArr = array();
if(is_array($tongchengListTmp) && !empty($tongchengListTmp)){
    
    $tongchengIdsArrTmp = $modelIdsArrTmp = $typeIdsArrTmp = $cateIdsArrTmp = $userIdsArrTmp = $districtIdsArrTmp = $sfcIdsArrTmp = array();
    foreach ($tongchengListTmp as $key => $value) {
        $tongchengIdsArrTmp[]   = $value['id'];
        $modelIdsArrTmp[]       = $value['model_id'];        
        $typeIdsArrTmp[]        = $value['type_id'];   
        $userIdsArrTmp[]        = $value['user_id'];
        if(!empty($value['cate_id'])){
            $cateIdsArrTmp[]    = $value['cate_id'];
        }
        if(!empty($value['area_id'])){
            $districtIdsArrTmp[] = $value['area_id'];
        }
        $streetNameTmp = '';
        if(!empty($value['street_id'])){
            $districtIdsArrTmp[] = $value['street_id'];
        }
        if($sfcModelInfo && $sfcModelInfo['id'] > 0 && $value['model_id'] == $sfcModelInfo['id'] ){
            $sfcIdsArrTmp[]   = $value['id'];
        }
    }
    
    $modelListTmp = array();
    if(is_array($modelIdsArrTmp) && !empty($modelIdsArrTmp)){
        $modelIdsStrTmp = implode(',', $modelIdsArrTmp);
        $modelArrTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(" AND id IN({$modelIdsStrTmp}) "," ORDER BY paixu ASC,id DESC ",0,100);
        if(is_array($modelArrTmp) && !empty($modelArrTmp)){
            foreach($modelArrTmp as $key => $value){
                $modelListTmp[$value['id']] = $value;
            }
        }
    }
    
    $typeListTmp = array();
    if(is_array($typeIdsArrTmp) && !empty($typeIdsArrTmp)){
        $typeIdsStrTmp = implode(',', $typeIdsArrTmp);
        $typeArrTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_all_list(" AND id IN({$typeIdsStrTmp}) "," ORDER BY paixu ASC,id DESC ",0,1000);
        if(is_array($typeArrTmp) && !empty($typeArrTmp)){
            foreach($typeArrTmp as $key => $value){
                $typeListTmp[$value['id']] = $value;
            }
        }
    }
    
    $cateListTmp = array();
    if(is_array($cateIdsArrTmp) && !empty($cateIdsArrTmp)){
        $cateIdsStrTmp = implode(',', $cateIdsArrTmp);
        $cateArrTmp = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_all_list(" AND id IN({$cateIdsStrTmp}) "," ORDER BY paixu ASC,id DESC ",0,1000);
        if(is_array($cateArrTmp) && !empty($cateArrTmp)){
            foreach($cateArrTmp as $key => $value){
                $cateListTmp[$value['id']] = $value;
            }
        }
    }
    
    $userListTmp = array();
    if(is_array($userIdsArrTmp) && !empty($userIdsArrTmp)){
        $userIdsStrTmp = implode(',', $userIdsArrTmp);
        $userArrTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_list(" AND id IN({$userIdsStrTmp}) "," ORDER BY id DESC ",0,1000);
        if(is_array($userArrTmp) && !empty($userArrTmp)){
            foreach($userArrTmp as $key => $value){
                $userListTmp[$value['id']] = $value;
            }
        }
    }
    
    $districtListTmp = array();
    if(is_array($districtIdsArrTmp) && !empty($districtIdsArrTmp)){
        $districtIdsStrTmp = implode(',', $districtIdsArrTmp);
        $districtArrTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_list(" AND id IN({$districtIdsStrTmp}) "," ORDER BY id DESC ",0,1000);
        if(is_array($districtArrTmp) && !empty($districtArrTmp)){
            foreach($districtArrTmp as $key => $value){
                $districtListTmp[$value['id']] = $value;
            }
        }
    }
    
    $photoListTmp = array();
    if(is_array($tongchengIdsArrTmp) && !empty($tongchengIdsArrTmp)){
        $tongchengIdsStrTmp = implode(',', $tongchengIdsArrTmp);
        $photoArrTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id IN({$tongchengIdsStrTmp}) "," ORDER BY id ASC ",0,1000);
        if(is_array($photoArrTmp) && !empty($photoArrTmp)){
            foreach($photoArrTmp as $key => $value){
                $photoListTmp[$value['tongcheng_id']][] = $value;
            }
        }
    }
    
    $sfcListTmp = array();
    if(is_array($sfcIdsArrTmp) && !empty($sfcIdsArrTmp)){
        $sfcIdsStrTmp = implode(',', $sfcIdsArrTmp);
        $sfcAttrListTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id IN({$sfcIdsStrTmp}) ", 'ORDER BY id DESC', 0, 1000);
        if(is_array($sfcAttrListTmp) && !empty($sfcAttrListTmp)){
            foreach ($sfcAttrListTmp as $key => $value){
                if($value['attr_id'] == $sfcTypeArr[$value['type_id']]['sfc_chufa_attr_id']){
                    $sfcListTmp[$value['tongcheng_id']]['chufa'] = $value['value'];
                }
                if($value['attr_id'] == $sfcTypeArr[$value['type_id']]['sfc_mude_attr_id']){
                    $sfcListTmp[$value['tongcheng_id']]['mude'] = $value['value'];
                }
                if($value['attr_id'] == $sfcTypeArr[$value['type_id']]['sfc_time_attr_id']){
                    $sfcListTmp[$value['tongcheng_id']]['time'] = dgmdate($value['time_value'],"Y-m-d H:i",$tomSysOffset);
                    $sfcListTmp[$value['tongcheng_id']]['int_time'] = $value['time_value'];
                }
                if($value['attr_id'] == $sfcTypeArr[$value['type_id']]['sfc_renshu_attr_id']){
                    $sfcListTmp[$value['tongcheng_id']]['renshu'] = $value['value'];
                }
            }
        }
    }
    
    foreach ($tongchengListTmp as $key => $value) {

        $modelInfoTmp = $modelListTmp[$value['model_id']];
        $typeInfoTmp = $typeListTmp[$value['type_id']];

        $tongchengIdsArr[] = $value['id'];

        $tongchengList[$key] = $value;
        $tongchengList[$key]['content'] = contentFormat($value['content']);

        $userInfoTmp = $userListTmp[$value['user_id']];
        
        if(!preg_match('/^http/', $userInfoTmp['picurl']) ){
            $userInfoTmp['picurl'] = $_G['siteurl'].$userInfoTmp['picurl'];
        }

        $cateInfoTmp = array();
        if($value['cate_id'] > 0){
            $cateInfoTmp = $cateListTmp[$value['cate_id']];
        }

        $tongchengList[$key]['area_street'] = '';
        $areaNameTmp = '';
        if(!empty($value['area_id'])){
            $areaInfoTmp = $districtListTmp[$value['area_id']];
            $areaNameTmp = $areaInfoTmp['name'];
        }
        $streetNameTmp = '';
        if(!empty($value['street_id'])){
            $streetInfoTmp = $districtListTmp[$value['street_id']];
            $streetNameTmp = $streetInfoTmp['name'];
        }
        if(!empty($areaNameTmp)){
            $tongchengList[$key]['area_street'] = $areaNameTmp."/".$streetNameTmp;
        }

        $tongchengPhotoCount = count($photoListTmp[$value['id']]);
        $picUrl = '';
        if($tongchengPhotoCount > 0){
            $tongchengPhotoListTmp = $photoListTmp[$value['id']];
            $tongchengPhotoList = array();
            if(is_array($tongchengPhotoListTmp) && !empty($tongchengPhotoListTmp)){
                foreach ($tongchengPhotoListTmp as $kk => $vv){
                    if($tongchengConfig['open_yun'] == 2 && !empty($vv['oss_picurl']) && $vv['oss_status'] == 1){
                        $picurl = $vv['oss_picurl'];
                    }else if($tongchengConfig['open_yun'] == 3 && !empty($vv['qiniu_picurl']) && $vv['qiniu_status'] == 1){
                        $picurl = $vv['qiniu_picurl'];
                    }else{
                        if(!preg_match('/^http/', $vv['picurl']) ){
                            if(strpos($vv['picurl'], 'source/plugin/tom_') === false){
                                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                            }else{
                                $picurl = $_G['siteurl'].$vv['picurl'];
                            }
                        }else{
                            $picurl = $vv['picurl'];
                        }
                    }
                    $tongchengPhotoList[$kk]['picurl'] = $picurl;
                }
            }
            $picUrl = $tongchengPhotoList[0]['picurl'];
        }

        if(!preg_match('/^http/', $value['video_pic']) ){
            if(strpos($value['video_pic'], 'source/plugin/tom_') === false){
                $videoPicTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['video_pic'];
            }else{
                $videoPicTmp = $_G['siteurl'].$value['video_pic'];
            }
        }else{
            $videoPicTmp = $value['video_pic'];
        }
        
        $tongchengList[$key]['show_pic'] = 0;
        if($tongchengPhotoCount > 0 || !empty($value['video_pic'])){
            $tongchengList[$key]['show_pic'] = 1;
        }else if($tcpcConfig['open_default_pic'] == 1){
            $tongchengList[$key]['show_pic'] = 2;
        }

        if(!empty($value['title'])){
            $tongchengList[$key]['title']         = $value['title'];
        }else{
            $contentTmp = contentFormat($value['content']);
            $contentTmp = strip_tags($contentTmp);
            $contentTmp = str_replace("\r\n","",$contentTmp);
            $contentTmp = str_replace("\n","",$contentTmp);
            $tongchengList[$key]['title'] = str_replace("\r","",$contentTmp);
        }
        
        if(isset($sfcListTmp[$value['id']]) && !empty($tcpcConfig['sfc_title'])){
            $sfc_title_tmp   = str_replace("{TYPENAME}",$typeInfoTmp['name'],$tcpcConfig['sfc_title']);
            $sfc_title_tmp   = str_replace("{CHUFA}",$sfcListTmp[$value['id']]['chufa'],$sfc_title_tmp);
            $sfc_title_tmp   = str_replace("{MUDE}",$sfcListTmp[$value['id']]['mude'],$sfc_title_tmp);
            $sfc_title_tmp   = str_replace("{TIME}",$sfcListTmp[$value['id']]['time'],$sfc_title_tmp);
            $tongchengList[$key]['title'] = $sfc_title_tmp;
        }
        
        $tongchengList[$key]['title'] = cutstr($tongchengList[$key]['title'],70,"...");
        
        $tongchengList[$key]['title'] = preg_replace("/\d{7}/", '*****', $tongchengList[$key]['title']);

        $tongchengList[$key]['video_pic']       = $videoPicTmp;
        $tongchengList[$key]['pic_count']       = $tongchengPhotoCount;
        $tongchengList[$key]['pic_url']         = $picUrl;
        $tongchengList[$key]['userInfo']        = $userInfoTmp;
        $tongchengList[$key]['modelInfo']       = $modelInfoTmp;
        $tongchengList[$key]['typeInfo']        = $typeInfoTmp;
        $tongchengList[$key]['cateInfo']        = $cateInfoTmp;
        $tongchengList[$key]['model_type_name'] = $modelInfoTmp['name'].'/'.$typeInfoTmp['name'];
        
        $tongchengList[$key]['typeUrl']        = tom_tcpc_url('list',$site_id,array('model_id'=>$modelInfoTmp['id'],'type_id'=>$typeInfoTmp['id']));
        $tongchengList[$key]['infoUrl']         = tom_tcpc_url('info',$site_id,array('tongcheng_id'=>$value['id']));
        $tongchengList[$key]['homeUrl']         = tom_tcpc_url('home',$site_id,array('user_id'=>$userInfoTmp['id']));

    }
}

$tongchengIdsStr = '';
if(is_array($tongchengIdsArr) && !empty($tongchengIdsArr)){
    $tongchengIdsStr = implode('|', $tongchengIdsArr);
}