<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($__Mobile == 1 && $tcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=index");exit;
}

$focuspicListTmp = C::t('#tom_tcpc#tom_tcpc_focuspic')->fetch_all_list(" AND site_id={$site_id} AND type=1 "," ORDER BY fsort ASC,id DESC ", 0, 10);
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
}else if($site_id > 1){
    $focuspicListTmp = C::t('#tom_tcpc#tom_tcpc_focuspic')->fetch_all_list(" AND site_id=1 AND type=1 "," ORDER BY fsort ASC,id DESC ", 0, 10);
}
$focuspicList = array();
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
    foreach($focuspicListTmp as $key => $value){
        $focuspicList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $focuspicList[$key]['picurl'] = $picurl;
        $focuspicList[$key]['link'] = str_replace("{site}",$site_id, $value['link']);
    }
}
$focuspicCount = count($focuspicList);

$diyInfoTmp = C::t('#tom_tcpc#tom_tcpc_diy')->fetch_all_list(" AND site_id={$site_id} AND status=1 "," ORDER BY id DESC ", 0, 1);
if(is_array($diyInfoTmp) && !empty($diyInfoTmp)){
}else if($site_id > 1){
    $diyInfoTmp = C::t('#tom_tcpc#tom_tcpc_diy')->fetch_all_list(" AND site_id=1 AND status=1 "," ORDER BY id DESC ", 0, 1);
}
$diyInfo = array();
if(!empty($diyInfoTmp[0])){
    $diyInfo = $diyInfoTmp[0];
    
    $diyInfo['content'] = stripslashes($diyInfo['content']);
    $diyInfo['content'] = htmlspecialchars_decode($diyInfo['content']);
    $diyInfo['content'] = str_replace("{SITE}",$site_id, $diyInfo['content']);
}

$newWhere = ' AND status=1 AND shenhe_status=1 AND model_id IN ('.$showModelIdsStr.')  ';
if(!empty($sql_in_site_ids)){
    $newWhere.= " AND site_id IN({$sql_in_site_ids}) ";
}
$newTongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list($newWhere,"ORDER BY id DESC",0,10);
$newTongchengList = array();
if(is_array($newTongchengListTmp) && !empty($newTongchengListTmp)){
    $newModelIdsArrTmp = $newTypeIdsArrTmp = $newSfcIdsArrTmp = array();
    foreach ($newTongchengListTmp as $key => $value) {
        $newModelIdsArrTmp[]       = $value['model_id'];  
        $newTypeIdsArrTmp[]        = $value['type_id'];   
        if($sfcModelInfo && $sfcModelInfo['id'] > 0 && $value['model_id'] == $sfcModelInfo['id'] ){
            $newSfcIdsArrTmp[]   = $value['id'];
        }
    }
    $newModelListTmp = array();
    if(is_array($newModelIdsArrTmp) && !empty($newModelIdsArrTmp)){
        $newModelIdsStrTmp = implode(',', $newModelIdsArrTmp);
        $newModelArrTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(" AND id in({$newModelIdsStrTmp}) "," ORDER BY paixu ASC,id DESC ",0,100);
        if(is_array($newModelArrTmp) && !empty($newModelArrTmp)){
            foreach($newModelArrTmp as $key => $value){
                $newModelListTmp[$value['id']] = $value;
            }
        }
    }
    $newTypeListTmp = array();
    if(is_array($newTypeIdsArrTmp) && !empty($newTypeIdsArrTmp)){
        $newTypeIdsStrTmp = implode(',', $newTypeIdsArrTmp);
        $newTypeArrTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_all_list(" AND id in({$newTypeIdsStrTmp}) "," ORDER BY paixu ASC,id DESC ",0,100);
        if(is_array($newTypeArrTmp) && !empty($newTypeArrTmp)){
            foreach($newTypeArrTmp as $key => $value){
                $newTypeListTmp[$value['id']] = $value;
            }
        }
    }
    $newSfcListTmp = array();
    if(is_array($newSfcIdsArrTmp) && !empty($newSfcIdsArrTmp)){
        $newSfcIdsStrTmp = implode(',', $newSfcIdsArrTmp);
        $newSfcAttrListTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id in({$newSfcIdsStrTmp}) ", 'ORDER BY id DESC', 0, 1000);
        if(is_array($newSfcAttrListTmp) && !empty($newSfcAttrListTmp)){
            foreach ($newSfcAttrListTmp as $key => $value){
                if($value['attr_id'] == $sfcTypeArr[$value['type_id']]['sfc_chufa_attr_id']){
                    $newSfcListTmp[$value['tongcheng_id']]['chufa'] = $value['value'];
                }
                if($value['attr_id'] == $sfcTypeArr[$value['type_id']]['sfc_mude_attr_id']){
                    $newSfcListTmp[$value['tongcheng_id']]['mude'] = $value['value'];
                }
                if($value['attr_id'] == $sfcTypeArr[$value['type_id']]['sfc_time_attr_id']){
                    $newSfcListTmp[$value['tongcheng_id']]['time'] = dgmdate($value['time_value'],"Y-m-d H:i",$tomSysOffset);
                    $newSfcListTmp[$value['tongcheng_id']]['int_time'] = $value['time_value'];
                }
                if($value['attr_id'] == $sfcTypeArr[$value['type_id']]['sfc_renshu_attr_id']){
                    $newSfcListTmp[$value['tongcheng_id']]['renshu'] = $value['value'];
                }
            }
        }
    }
    foreach ($newTongchengListTmp as $key => $value) {
        $newTongchengList[$key] = $value;
        $newModelInfoTmp = $newModelListTmp[$value['model_id']];
        $newTypeInfoTmp = $newTypeListTmp[$value['type_id']];
        if(!empty($value['title'])){
            $newTongchengList[$key]['title']         = $value['title'];
        }else{
            $newContentTmp = contentFormat($value['content']);
            $newContentTmp = strip_tags($newContentTmp);
            $newContentTmp = str_replace("\r\n","",$newContentTmp);
            $newContentTmp = str_replace("\n","",$newContentTmp);
            $newTongchengList[$key]['title'] = str_replace("\r","",$newContentTmp);
        }
        if(isset($newSfcListTmp[$value['id']]) && !empty($tcpcConfig['sfc_title'])){
            $new_sfc_title_tmp   = str_replace("{TYPENAME}",$newTypeInfoTmp['name'],$tcpcConfig['sfc_title']);
            $new_sfc_title_tmp   = str_replace("{CHUFA}",$newSfcListTmp[$value['id']]['chufa'],$new_sfc_title_tmp);
            $new_sfc_title_tmp   = str_replace("{MUDE}",$newSfcListTmp[$value['id']]['mude'],$new_sfc_title_tmp);
            $new_sfc_title_tmp   = str_replace("{TIME}",$newSfcListTmp[$value['id']]['time'],$new_sfc_title_tmp);
            $newTongchengList[$key]['title'] = $new_sfc_title_tmp;
        }
        
        $newTongchengList[$key]['title'] = preg_replace("/\d{7}/", '*****', $newTongchengList[$key]['title']);
        
        $newTongchengList[$key]['modelInfo']       = $newModelInfoTmp;
        $newTongchengList[$key]['typeInfo']        = $newTypeInfoTmp;
        $newTongchengList[$key]['modelUrl']        = tom_tcpc_url('list',$site_id,array('model_id'=>$newModelInfoTmp['id']));
        $newTongchengList[$key]['infoUrl']         = tom_tcpc_url('info',$site_id,array('tongcheng_id'=>$value['id']));
    }
}
$newTongchengCount = count($newTongchengList);

$modelWhereStr = " AND is_show=1 ";
if($site_id > 1){
    if(!empty($__SitesInfo['model_ids'])){
        $modelWhereStr.= " AND id IN({$__SitesInfo['model_ids']}) ";
    }
}else{
    $modelWhereStr.= " AND sites_show=0 ";
}
$modelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(" {$modelWhereStr} "," ORDER BY paixu ASC,id DESC ",0,50);
$modelList = array();
$m_i = 1;
$modelCount = 0;
if(is_array($modelListTmp) && !empty($modelListTmp)){
    foreach($modelListTmp as $key => $value){
        $modelList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $modelList[$key]['i']           = $m_i;
        $modelList[$key]['picurl']      = $picurl;
        $modelList[$key]['link']        = tom_tcpc_url('list',$site_id,array('model_id'=>$value['id']));
        $m_i++;
        $modelCount++;
    }
}

$where = ' AND status=1 AND shenhe_status=1 AND model_id IN ('.$showModelIdsStr.')  ';
if(!empty($sql_in_site_ids)){
    $where.= " AND site_id IN({$sql_in_site_ids}) ";
}
if($tongchengConfig['open_finish_paixu'] == 1){
    if($tongchengConfig['top_paixu_type'] == 2){
        $order = " ORDER BY topstatus DESC,toptime DESC,finish ASC, refresh_time DESC,id DESC ";
    }else if($tongchengConfig['top_paixu_type'] == 3){
        $order = " ORDER BY topstatus DESC,finish ASC,refresh_time DESC,id DESC ";
    }else{
        $order = " ORDER BY topstatus DESC,toprand DESC,finish ASC, refresh_time DESC,id DESC ";
    }
}else{
    if($tongchengConfig['top_paixu_type'] == 2){
        $order = " ORDER BY topstatus DESC,toptime DESC, refresh_time DESC,id DESC ";
    }else if($tongchengConfig['top_paixu_type'] == 3){
        $order = " ORDER BY topstatus DESC,refresh_time DESC,id DESC ";
    }else{
        $order = " ORDER BY topstatus DESC,toprand DESC, refresh_time DESC,id DESC ";
    }
}
$pagesize = 30;
$start = 0;
$tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list($where,$order,$start,$pagesize);
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list_tongcheng.php';

if($__ShowTctoutiao == 1){
    $ttWhere = ' AND status=1 AND shenhe_status=1 AND index_show = 1  ';
    if(!empty($sql_in_site_ids)){
        $ttWhere .= " AND site_id IN({$sql_in_site_ids},99) ";
    }
    $ttOrder = " ORDER BY is_recom DESC,paixu ASC,add_time DESC,id DESC ";
    $tctoutiaoListTmp = C::t('#tom_tctoutiao#tom_tctoutiao')->fetch_all_list($ttWhere,$ttOrder,0,20);
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list_toutiao.php';
}

$tcshopCount = 0;
if($__ShowTcshop == 1 && $tcpcConfig['open_shop_index_show'] == 1 && $tcpcConfig['shop_index_show_num'] > 0){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list_shop.php';
    
    $spWhere = ' AND status=1 AND shenhe_status=1  ';
    if(!empty($sql_in_site_ids)){
        $spWhere .= " AND site_id IN({$sql_in_site_ids},99) ";
    }

    $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list($spWhere," ORDER BY topstatus DESC, toprand DESC,vip_rank DESC,clicks DESC,id DESC ",0,$tcpcConfig['shop_index_show_num']);
    $tcshopList = tom_handle_shop($tcshopListTmp);
    $tcshopCount = count($tcshopList);
}

$guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi IN(1,2,3,7) AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi IN(1,2,3,7) AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoTonglan1List = $guanggaoTonglan2List = $guanggaoTonglan3List = $guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        if($value['weizhi'] == 1){
            $guanggaoTonglan1List[] = $guanggaoItemTmp;
        }
        if($value['weizhi'] == 2){
            $guanggaoTonglan2List[] = $guanggaoItemTmp;
        }
        if($value['weizhi'] == 7){
            $guanggaoTonglan3List[] = $guanggaoItemTmp;
        }
        if($value['weizhi'] == 3){
            $guanggaoYouList[] = $guanggaoItemTmp;
        }
        
    }
}

$linksListTmp = C::t('#tom_tcpc#tom_tcpc_links')->fetch_all_list(" AND site_id={$site_id} "," ORDER BY lsort ASC,id DESC ");
if(is_array($linksListTmp) && !empty($linksListTmp)){
}else{
    $linksListTmp = C::t('#tom_tcpc#tom_tcpc_links')->fetch_all_list(" AND site_id=1 "," ORDER BY lsort ASC,id DESC ");
}
$linksList = array();
if(is_array($linksListTmp) && !empty($linksListTmp)){
    foreach($linksListTmp as $key => $value){
        $linksList[$key] = $value;
        $linksList[$key]['link'] = str_replace("{site}",$site_id, $value['link']);
    }
}
$linksCount = count($linksList);

$seo_title          = $tcpcConfig['seo_index_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);

$seo_keywords       = $tcpcConfig['seo_index_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);

$seo_description    = $tcpcConfig['seo_index_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcpc:index");