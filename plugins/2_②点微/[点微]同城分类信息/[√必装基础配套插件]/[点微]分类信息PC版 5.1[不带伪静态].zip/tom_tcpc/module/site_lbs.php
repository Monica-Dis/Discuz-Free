<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($site_id > 1 && $__SitesInfo['open_sites'] == 0){
    $tcadminConfig['open_sites'] = 0;
}
$hotSitesList = $cateSitesList = array();
if($tcadminConfig['open_sites'] == 1){
    $hotSitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 AND is_hot=1 AND open_sites=1 "," ORDER BY paixu ASC,id DESC ",0,1000);
    if(is_array($hotSitesListTmp) && !empty($hotSitesListTmp)){
        foreach ($hotSitesListTmp as $key => $value){
            $hotSitesList[$key] = $value;
            $hotSitesList[$key]['link'] = tom_tcpc_url('index',$value['id']);
        }
    }
    $cateSitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites_cate')->fetch_all_list(" "," ORDER BY paixu ASC,id DESC ",0,100);
    if(is_array($cateSitesListTmp) && !empty($cateSitesListTmp)){
        $sitesListTmp = array();
        $sitesListTmpTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 AND open_sites=1 "," ORDER BY paixu ASC,id DESC ",0,1000);
        if(is_array($sitesListTmpTmp) && !empty($sitesListTmpTmp)){
            foreach ($sitesListTmpTmp as $sk => $sv){
                $sv['link'] = tom_tcpc_url('index',$sv['id']);
                $sitesListTmp[$sv['cate_id']][] = $sv;
            }
        }
        foreach ($cateSitesListTmp as $key => $value){
            $cateSitesList[$key] = $value;
            if(isset($sitesListTmp[$value['id']]) && !empty($sitesListTmp[$value['id']])){
                $cateSitesList[$key]['sites'] = $sitesListTmp[$value['id']];
            }
        }
    }
}