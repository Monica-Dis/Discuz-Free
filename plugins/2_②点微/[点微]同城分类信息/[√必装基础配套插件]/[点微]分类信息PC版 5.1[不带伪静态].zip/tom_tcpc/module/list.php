<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page       = intval($_GET['page'])>0 ? intval($_GET['page']):1;
$model_id   = intval($_GET['model_id'])>0 ? intval($_GET['model_id']):0;
$type_id    = intval($_GET['type_id'])>0 ? intval($_GET['type_id']):0;
$area_id    = intval($_GET['area_id'])>0 ? intval($_GET['area_id']):0;
$street_id  = intval($_GET['street_id'])>0 ? intval($_GET['street_id']):0;
$cate_id    = intval($_GET['cate_id'])>0 ? intval($_GET['cate_id']):0;
$keyword    = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$keyword    = dhtmlspecialchars($keyword);

if($__Mobile == 1 && $tcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=list&model_id={$model_id}&type_id={$type_id}");exit;
}

$modelWhereStr = " AND is_show=1 ";
if($site_id > 1){
    if(!empty($__SitesInfo['model_ids'])){
        $modelWhereStr.= " AND id IN({$__SitesInfo['model_ids']}) ";
    }
}else{
    $modelWhereStr.= " AND sites_show=0 ";
}
$modelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(" {$modelWhereStr} "," ORDER BY paixu ASC,id DESC ",0,100);
$modelList = array();
if(is_array($modelListTmp) && !empty($modelListTmp)){
    foreach($modelListTmp as $key => $value){
        $modelList[$value['id']] = $value;
        $modelList[$value['id']]['link'] = tom_tcpc_url('list',$site_id,array('model_id'=>$value['id']));
    }
}

$typeListTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_all_list("  "," ORDER BY paixu ASC,id DESC ",0,1000);
$typeList = array();
$typeArr = array();
if(is_array($typeListTmp) && !empty($typeListTmp)){
    foreach($typeListTmp as $key => $value){
        $typeList[$value['id']] = $value;
        $modelList[$value['model_id']]['typeList'][] = $value;
        
        if($model_id > 0 && $model_id == $value['model_id']){
            $typeArr[$value['id']] = $value;
            $typeArr[$value['id']]['link'] = tom_tcpc_url('list',$site_id,array('model_id'=>$value['model_id'],'type_id'=>$value['id']));
        }
    }
}

$cateList = array();
if(!empty($type_id)){
    $cateListTmp = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_all_list("  AND type_id={$type_id}  "," ORDER BY paixu ASC,id DESC ",0,10000);
    if(is_array($cateListTmp) && !empty($cateListTmp)){
        foreach($cateListTmp as $key => $value){
            $cateList[$value['id']] = $value;
        }
    }
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$areaList = array();
if(is_array($areaListTmp) && !empty($areaListTmp)){
    $areaList = $areaListTmp;
}
$streetList = array();
if(!empty($area_id)){
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
}

$modelInfo = array();
$modelUrl = '';
if(!empty($model_id)){
    $modelInfo = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($model_id);
    $modelUrl = tom_tcpc_url('list',$site_id,array('model_id'=>$modelInfo['id']));
}
$typeInfo = array();
if(!empty($type_id)){
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($type_id);
}
$cateInfo = array();
if(!empty($cate_id)){
    $cateInfo = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_by_id($cate_id);
}

$url = '';
$rewriteStatus = 1;
$where = ' AND status=1 AND shenhe_status=1 AND model_id IN ('.$showModelIdsStr.')  ';
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}
if($model_id > 0){
    $where .= " AND model_id = {$model_id}";
    $url .= "&model_id={$model_id}";
}
if($type_id > 0){
    $where .= " AND type_id = {$type_id}";
    $url .= "&type_id={$type_id}";
}
if($cate_id > 0){
    $rewriteStatus = 0;
    $where .= " AND cate_id = {$cate_id}";
    $url .= "&cate_id={$cate_id}";
}
if($area_id > 0){
    $rewriteStatus = 0;
    $where .= " AND area_id = {$area_id}";
    $url .= "&area_id={$area_id}";
}
if($street_id > 0){
    $rewriteStatus = 0;
    $where .= " AND street_id = {$street_id}";
    $url .= "&street_id={$street_id}";
}
if(!empty($keyword)){
    $rewriteStatus = 0;
    $keywordTmp = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND content LIKE '%{$keywordTmp}%'";
    $url .= "&keyword={$keyword}";
}

if($tongchengConfig['open_finish_paixu'] == 1){
    if($tongchengConfig['top_paixu_type'] == 2){
        $order = " ORDER BY topstatus DESC,toptime DESC,finish ASC, refresh_time DESC,id DESC ";
    }else if($tongchengConfig['top_paixu_type'] == 3){
        $order = " ORDER BY topstatus DESC,finish ASC,refresh_time DESC,id DESC ";
    }else{
        $order = " ORDER BY topstatus DESC,toprand DESC,finish ASC, refresh_time DESC,id DESC ";
    }
}else{
    if($tongchengConfig['top_paixu_type'] == 2){
        $order = " ORDER BY topstatus DESC,toptime DESC, refresh_time DESC,id DESC ";
    }else if($tongchengConfig['top_paixu_type'] == 3){
        $order = " ORDER BY topstatus DESC,refresh_time DESC,id DESC ";
    }else{
        $order = " ORDER BY topstatus DESC,toprand DESC, refresh_time DESC,id DESC ";
    }
}

$pagesize = 30;
$start = ($page - 1) * $pagesize;
$count = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count($where);
$tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list($where,$order,$start,$pagesize);
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list_tongcheng.php';

if($rewriteStatus == 1){
    $pageArr['link'] = tom_tcpc_url('list',$site_id,array('model_id'=>$model_id,'type_id'=>$type_id,'page'=>'{page}'));
}else{
    $pageArr['link'] = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site_id}&mod=list&{$url}&page={page}";
}
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi=4 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi=4 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$fenleiYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        if($value['weizhi'] == 4){
            $fenleiYouList[] = $guanggaoItemTmp;
        }
    }
}

$seo_model_name = $seo_type_name = $seo_cate_name = '';
if(!empty($modelInfo)){
    $seo_model_name = $modelInfo['name'];
}else{
    $seo_model_name = lang('plugin/tom_tcpc', 'list_title');
}
if(!empty($typeInfo)){
    $seo_type_name = $typeInfo['name'];
}
if(!empty($cateInfo)){
    $seo_cate_name = $cateInfo['name'];
}

$seo_title          = $tcpcConfig['seo_list_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{MODELBANE}",$seo_model_name, $seo_title);
$seo_title          = str_replace("{TYPENAME}",$seo_type_name, $seo_title);
$seo_title          = str_replace("{CATENAME}",$seo_cate_name, $seo_title);
$seo_title          = str_replace("{PAGE}",$page, $seo_title);

$seo_keywords       = $tcpcConfig['seo_list_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{MODELBANE}",$seo_model_name, $seo_keywords);
$seo_keywords       = str_replace("{TYPENAME}",$seo_type_name, $seo_keywords);
$seo_keywords       = str_replace("{CATENAME}",$seo_cate_name, $seo_keywords);
$seo_keywords       = str_replace("{PAGE}",$page, $seo_keywords);

$seo_description    = $tcpcConfig['seo_list_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{MODELBANE}",$seo_model_name, $seo_description);
$seo_description    = str_replace("{TYPENAME}",$seo_type_name, $seo_description);
$seo_description    = str_replace("{CATENAME}",$seo_cate_name, $seo_description);
$seo_description    = str_replace("{PAGE}",$page, $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcpc:list");