<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$__SitesInfo = array(
    'id'                => 1,
    'name'              => $tongchengConfig['plugin_name'],
    'lbs_name'          => $tongchengConfig['lbs_name'],
    'dingyue_qrcode'    => $tongchengConfig['dingyue_qrcode'],
    'kefu_qrcode'       => $tongchengConfig['kefu_qrcode'],
);
$__CityInfo  = array('id'=>0,'name'=>'');

if($site_id > 1){
    $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
    if($sitesInfoTmp){
        $__SitesInfo = $sitesInfoTmp;
        if($__SitesInfo['status'] == 2){
            dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcpc&site=1&mod=index");exit;
        }
        if(!empty($__SitesInfo['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
            if($cityInfoTmp){
                $__CityInfo = $cityInfoTmp;
            }
        }
        if(!empty($__SitesInfo['seo_city_name'])){
            $__CityInfo['name'] = $__SitesInfo['seo_city_name'];
        }
        if(!empty($__SitesInfo['dingyue_qrcode'])){
            if(!preg_match('/^http/', $__SitesInfo['dingyue_qrcode']) ){
                $__SitesInfo['dingyue_qrcode'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['dingyue_qrcode'];
            }
        }
        if(!empty($__SitesInfo['kefu_qrcode'])){
            if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode']) ){
                $__SitesInfo['kefu_qrcode'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
            }
        }
    }else{
        $site_id = 1;
    }
}

if($site_id == 1){
    $cityInfoTmp = array();
    if(!empty($tongchengConfig['city_id'])){
        $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
    }
    if(!empty($cityInfoTmp)){
        $__CityInfo = $cityInfoTmp;
    }
}