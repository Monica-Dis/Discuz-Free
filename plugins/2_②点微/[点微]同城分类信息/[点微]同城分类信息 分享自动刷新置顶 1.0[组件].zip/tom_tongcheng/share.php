<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.cn
   
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$allow_share_do = 1;
if($tongchengSetting['share_do_limit'] == 2){
    if($userInfo['add_time'] > (TIMESTAMP - 86400*30)){
        $allow_share_do = 0;
    }
}

if($__UserInfo['id'] > 0 && $tongchengSetting['open_share_refresh_top'] == 1 && $tongchengInfo['share_refresh_time'] < $nowDayTime && $tongchengInfo['finish'] == 0 && $allow_share_do == 1){
    $shareUrl   = $shareUrl."&sruid={$__UserInfo['id']}";
    if($__UserInfo['id'] != $tongchengInfo['user_id'] && $_GET['sruid'] == $tongchengInfo['user_id']){
        $updateData = array();
        $updateData['refresh_time']             = TIMESTAMP;
        $updateData['share_refresh_time']       = $nowDayTime;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongchengInfo['id'],$updateData);
    }
    if($__UserInfo['id'] == $tongchengInfo['user_id'] && !empty($tongchengSetting['share_refresh_txt'])){
        $show_share_refresh_box = 1;
    }
}

if($__UserInfo['id'] > 0 && $tongchengSetting['open_share_refresh_top'] == 2 && $tongchengInfo['topstatus'] == 0 && $tongchengInfo['share_top_status'] == 0 && $tongchengInfo['finish'] == 0 && $allow_share_do == 1){
    $shareUrl   = $shareUrl."&sruid={$__UserInfo['id']}";
    $share_top_count = C::t('#tom_tongcheng#tom_tongcheng_share_log')->fetch_all_count(" AND type = 1 AND tongcheng_id={$tongchengInfo['id']} ");
    if($__UserInfo['id'] != $tongchengInfo['user_id'] && $_GET['sruid'] == $tongchengInfo['user_id']){
        $is_share_top = C::t('#tom_tongcheng#tom_tongcheng_share_log')->fetch_all_count(" AND type = 1 AND tongcheng_id={$tongchengInfo['id']} AND view_user_id={$__UserInfo['id']} ");
        if($is_share_top > 0){
        }else{
            $insertData = array();
            $insertData['type']         = 1;
            $insertData['user_id']      = $tongchengInfo['user_id'];
            $insertData['tongcheng_id'] = $tongchengInfo['id'];
            $insertData['view_user_id'] = $__UserInfo['id'];
            $insertData['time_key']     = $nowDayTime;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_share_log')->insert($insertData);

            if(($share_top_count + 1) >= $tongchengSetting['share_top_num']){
                $updateData = array();
                $updateData['share_top_status'] = 1;
                $updateData['topstatus']        = 1;
                $updateData['toprand']          = 10000;
                $updateData['toptime']          = TIMESTAMP + $tongchengSetting['share_top_days']*86400;
                $updateData['refresh_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng')->update($tongchengInfo['id'],$updateData);
            }
        }
    }
    if($__UserInfo['id'] == $tongchengInfo['user_id'] && !empty($tongchengSetting['share_top_txt'])){
        $show_share_top_box = 1;
        $tongchengSetting['share_top_txt'] = str_replace('{XUCHAKAN}', '&nbsp;<font color="#fd0d0d">'.$tongchengSetting['share_top_num'].'</font>&nbsp;', $tongchengSetting['share_top_txt']);
        $tongchengSetting['share_top_txt'] = str_replace('{DAYS}', '&nbsp;<font color="#fd0d0d">'.$tongchengSetting['share_top_days'].'</font>&nbsp;', $tongchengSetting['share_top_txt']);
        $tongchengSetting['share_top_txt'] = str_replace('{YICHAKAN}', '&nbsp;<font color="#fd0d0d">'.$share_top_count.'</font>&nbsp;', $tongchengSetting['share_top_txt']);
    }
}