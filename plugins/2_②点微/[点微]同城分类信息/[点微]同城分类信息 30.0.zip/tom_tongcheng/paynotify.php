<?php

/**
   Copyright 2001-2099 DisM!Ӧ������.
   This is NOT a freeware, use is subject to license terms
   Ӧ�ø���֧�֣�https://dism.taobao.com
   ���²����http://t.cn/Aiux1Jx1
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);

$tongchengSetting = C::t('#tom_tongcheng#tom_tongcheng_setting')->fetch_by_id(1);
if($tongchengSetting && $tongchengSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tongcheng#tom_tongcheng_setting')->insert($insertData);
    $tongchengSetting = C::t('#tom_tongcheng#tom_tongcheng_setting')->fetch_by_id(1);
}

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcadmin start
$__ShowTcadmin = 0;
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
    if($tcadminConfig['open_fc'] == 1){
        $__ShowTcadmin = 1;
    }
}
## tcadmin end

$tuiListMoney = array();
if($__ShowTchehuoren == 1){
    $tui_list_money_str = str_replace("\r\n","{n}",$tchehuorenConfig['tui_list_money']); 
    $tui_list_money_str = str_replace("\n","{n}",$tui_list_money_str);
    $tui_list_money_arr = explode("{n}", $tui_list_money_str);
    if(is_array($tui_list_money_arr) && !empty($tui_list_money_arr)){
        foreach ($tui_list_money_arr as $key => $value){
            $tuiListMoneyArr = explode("|", $value);
            $tuiListMoney[$tuiListMoneyArr[1]] = $tuiListMoneyArr[0];
        }
    }
}

$appid = trim($tongchengConfig['wxpay_appid']);  
$appsecret = trim($tongchengConfig['wxpay_appsecret']); 
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$orderInfo = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_by_order_no($order_no);
if($orderInfo && $orderInfo['order_status'] == 1){
    $updateData = array();
    $updateData['order_status'] = 2;
    $updateData['pay_time'] = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_order')->update($orderInfo['id'],$updateData);
    
    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($orderInfo['order_no'])));
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($orderInfo['tongcheng_id']);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
    
    if($orderInfo['order_type'] == 1){
        
        $updateData = array();
        $updateData['status'] = 1;
        $updateData['pay_status'] = 2;
        if($tongchengInfo['over_days'] > 0){
            $updateData['over_time'] = TIMESTAMP + $tongchengInfo['over_days']*86400;
        }
        if($orderInfo['top_days'] > 0){
            $updateData['topstatus']    = 1;
            $updateData['toptime']      = TIMESTAMP + $orderInfo['top_days']*86400;
        }
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng')->update($orderInfo['tongcheng_id'],$updateData);
        
        if($orderInfo['tui_click_num'] > 0){
            $tui_click_pay_price = $tui_click_all_money = $tui_click_click_money = 0;
            if(isset($tuiListMoney[$orderInfo['tui_click_num']]) && $tuiListMoney[$orderInfo['tui_click_num']] > 0){
                $tui_click_pay_price = $tuiListMoney[$orderInfo['tui_click_num']];
                $tui_click_all_money = $tuiListMoney[$orderInfo['tui_click_num']];
                if($tchehuorenConfig['tui_yongjin'] > 0 && $tchehuorenConfig['tui_yongjin'] < 100){
                    $tui_click_all_money = $tui_click_all_money * ((100 - $tchehuorenConfig['tui_yongjin'])/100);
                }
                $tui_click_click_money = $tui_click_all_money/$orderInfo['tui_click_num'];
            }
            if($tui_click_pay_price > 0 && $tui_click_all_money > 0 && $tui_click_click_money >= 0.01){
                $insertData = array();
                $insertData['order_no']         = $order_no;
                $insertData['site_id']          = $tongchengInfo['site_id'];
                $insertData['plugin_id']        = 'tom_tongcheng';
                $insertData['tongcheng_id']     = $tongchengInfo['id'];
                $insertData['all_money']        = $tui_click_all_money;
                $insertData['sy_money']         = $tui_click_all_money;
                $insertData['click_money']      = $tui_click_click_money;
                $insertData['add_type']         = 1;
                $insertData['pay_status']       = 2;
                $insertData['status']           = 1;
                $insertData['is_show']          = 1;
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_tchehuoren#tom_tchehuoren_tui')->insert($insertData);
                
                $orderInfo['pay_price'] = $orderInfo['pay_price'] - $tui_click_pay_price;
                
            }
        }
        
        if(!empty($tongchengConfig['fabu_xx_tz'])){
            $contentTz = contentFormat($tongchengInfo['content']);
            $contentTz = strip_tags($contentTz);
            $contentTz = str_replace("\r\n","",$contentTz);
            $contentTz = str_replace("\n","",$contentTz);
            $contentTz = str_replace("\r","",$contentTz);
            $contentTz = cutstr($contentTz,30,"...");
            $insertData = array();
            $insertData['user_id']      = $orderInfo['user_id'];
            $insertData['type']         = 1;
            $insertData['content']      = str_replace("{CONTENT}",$contentTz,$tongchengConfig['fabu_xx_tz']);
            $insertData['is_read']      = 0;
            $insertData['tz_time']      = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        }
        
    }else if($orderInfo['order_type'] == 2){
        
        $updateData = array();
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng')->update($orderInfo['tongcheng_id'],$updateData);
        
    }else if($orderInfo['order_type'] == 3){
        
        $toptime = TIMESTAMP;
        if($tongchengInfo['toptime'] > TIMESTAMP){
            $toptime = $tongchengInfo['toptime'] + $orderInfo['time_value']*86400;
        }else{
            $toptime = TIMESTAMP + $orderInfo['time_value']*86400;
        }
        $updateData = array();
        $updateData['topstatus'] = 1;
        $updateData['toprand'] = 10000;
        $updateData['toptime'] = $toptime;
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongchengInfo['id'],$updateData);
    
    }else if($orderInfo['order_type'] == 9){
        
        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['type']             = 1;
        $insertData['object_id']        = $orderInfo['tongcheng_id'];
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tel')->insert($insertData);
        
    }else if($orderInfo['order_type'] == 10){
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] + $orderInfo['score_value'];
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $orderInfo['score_value'];
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 21;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
    }else if($orderInfo['order_type'] == 11){
        
        $updateData = array();
        $updateData['status']       = 1;
        $updateData['pay_status']   = 2;
        $updateData['finish']       = 0;
        if($tongchengInfo['over_days'] > 0){
            if($tongchengInfo['over_time'] > TIMESTAMP){
                $updateData['over_time'] = $tongchengInfo['over_time'] + $tongchengInfo['over_days']*86400;
            }else{
                $updateData['over_time'] = TIMESTAMP + $tongchengInfo['over_days']*86400;
            }
            if($orderInfo['time_value'] > 0){
                $updateData['topstatus']    = 1;
                if($tongchengInfo['toptime'] > TIMESTAMP){
                    $updateData['toptime'] = $tongchengInfo['toptime'] + $orderInfo['time_value']*86400;
                }else{
                    $updateData['toptime'] = TIMESTAMP + $orderInfo['time_value']*86400;
                }
            }
        }
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng')->update($orderInfo['tongcheng_id'],$updateData);
        
    }else if($orderInfo['order_type'] == 12){
        
        $updateData = array();
        $updateData['pay_status'] = 2;
        C::t('#tom_tongcheng#tom_tongcheng_apply_sites')->update($orderInfo['apply_sites_id'],$updateData);
        
    }else if($orderInfo['order_type'] == 13){
        
        $updateData = array();
        $updateData['refresh_num'] = $userInfo['refresh_num'] + $orderInfo['refresh_num'];
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
        
    }

    # fc start
    $adminFc = false;
    if($__ShowTchehuoren == 1 && $userInfo['tj_hehuoren_id'] > 0 && $orderInfo['pay_price'] > 0){

        $shenyu_money = $orderInfo['pay_price'];
        $child_site_fc_money = $tchehuoren_fc_money = $tctchehuorenParent_fc_money = 0;
        
        $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($userInfo['tj_hehuoren_id']);
        if($tchehuorenInfo){
            $tchehuorenDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
            $tchehuorenUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tchehuorenInfo['openid']);
        }
        
        $tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
        if($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1){
            $tctchehuorenParentInfo = C::t("#tom_tchehuoren#tom_tchehuoren")->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
            $tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
            $tctchehuorenParentUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tctchehuorenParentInfo['openid']);
        }
        
        if($tchehuorenInfo && $tchehuorenInfo['status'] == 1 && $tchehuorenDengji['fl_fc_open'] == 1){
            if($orderInfo['site_id'] > 1){
                $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                $sitename = $sitesInfo['name'];
                if($__ShowTcadmin && $sitesInfo['hehuoren_fc_open'] == 1){
                    
                    $tchehuoren_fc_money = $orderInfo['pay_price'] * ($tchehuorenDengji['fl_fc_scale']/100);
                    $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2);
                    
                    $fc_scale = $tcadminConfig['fc_scale'];
                    if($sitesInfo['fl_fc_scale'] > 0){
                        $fc_scale = $sitesInfo['fl_fc_scale'];
                    }
                    $child_site_fc_money = $orderInfo['pay_price'] * ($fc_scale/100);
                    $child_site_fc_money = number_format($child_site_fc_money,2);
                    $child_site_fc_money = $child_site_fc_money - $tchehuoren_fc_money;
                    
                    if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                        $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2);
                        if($tchehuorenConfig['subordinate_moneytype'] == 1){
                            $child_site_fc_money   = $child_site_fc_money - $tctchehuorenParent_fc_money;
                        }else{
                            $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                        }
                    }
                    
                    $shenyu_money = $shenyu_money - $child_site_fc_money - $tchehuoren_fc_money;

                }else{
                    if($__ShowTcadmin == 1){
                        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                        $fc_scale = $tcadminConfig['fc_scale'];
                        if($sitesInfo['fl_fc_scale'] > 0){
                            $fc_scale = $sitesInfo['fl_fc_scale'];
                        }
                        $child_site_fc_money = $orderInfo['pay_price'] * ($fc_scale/100);
                        $child_site_fc_money = number_format($child_site_fc_money,2);
                    }
                    
                    $shenyu_money = $shenyu_money - $child_site_fc_money;
                    
                }
                
            }else{
                $sitename = $tongchengConfig['plugin_name'];
                $tchehuoren_fc_money = $orderInfo['pay_price'] * ($tchehuorenDengji['fl_fc_scale']/100);
                $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2);
                
                if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                    $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                    $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2);
                    if($tchehuorenConfig['subordinate_moneytype'] == 1){
                    }else{
                        $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                    }
                }
                
                $shenyu_money = $shenyu_money - $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
            }
            
            Log::DEBUG("update shenyu_money:" . $shenyu_money);
            Log::DEBUG("update child_site_fc_money:" . $child_site_fc_money);
            Log::DEBUG("update tchehuoren_fc_money:" . $tchehuoren_fc_money);
            Log::DEBUG("update TCtchehuoren_fc_money:" . $tctchehuorenParent_fc_money);
            
            if($orderInfo['pay_price'] >= ($child_site_fc_money +  $tchehuoren_fc_money + $tctchehuorenParent_fc_money)){  

                if($child_site_fc_money > 0){
                    $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);
                    
                    $old_money = 0;
                    if($walletInfo){
                        $old_money = $walletInfo['account_balance'];

                        $updateData = array();
                        $updateData['account_balance']   = $walletInfo['account_balance'] + $child_site_fc_money;
                        $updateData['total_income']   = $walletInfo['total_income'] + $child_site_fc_money;
                        C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
                    }else{
                        $insertData = array();
                        $insertData['site_id']              = $orderInfo['site_id'];
                        $insertData['account_balance']      = $child_site_fc_money;
                        $insertData['total_income']         = $child_site_fc_money;
                        $insertData['add_time']             = TIMESTAMP;
                        C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
                    }

                    $insertData = array();
                    $insertData['site_id']      = $orderInfo['site_id'];
                    $insertData['log_type']     = 1;
                    $insertData['change_money'] = $child_site_fc_money;
                    $insertData['old_money']    = $old_money;
                    if($orderInfo['order_type'] == 10){
                        $insertData['beizu']        = lang('plugin/tom_tongcheng', 'score_recharge_tag');
                    }else{
                        $insertData['beizu']        = contentFormat($tongchengInfo['content']);
                    }
                    $insertData['order_no']     = $orderInfo['order_no'];
                    $insertData['order_type']   = $orderInfo['order_type'];
                    $insertData['log_ip']       = $_G['clientip'];
                    $insertData['log_time']     = TIMESTAMP;
                    C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData); 
                }
                
                $title = '';
                $type = '';
                $titleTmp = contentFormat($tongchengInfo['content']);
                $titleTmp = strip_tags($titleTmp);
                $titleTmp = str_replace("\r\n","",$titleTmp);
                $titleTmp = str_replace("\n","",$titleTmp);
                $titleTmp = str_replace("\r","",$titleTmp);
                $titleTmp = cutstr($titleTmp,30,"...");
                if($orderInfo['order_type'] == 1){
                    $title = $titleTmp;
                    $type = lang('plugin/tom_tongcheng', 'order_type_1');
                }else if($orderInfo['order_type'] == 2){
                    $title = $titleTmp;
                    $type = lang('plugin/tom_tongcheng', 'order_type_2');
                }else if($orderInfo['order_type'] == 3){
                    $title = $titleTmp;
                    $type = lang('plugin/tom_tongcheng', 'order_type_3');
                }else if($orderInfo['order_type'] == 9){
                    $title = $titleTmp;
                    $type = lang('plugin/tom_tongcheng', 'order_type_9');
                }else if($orderInfo['order_type'] == 10){
                    $title = lang('plugin/tom_tongcheng', 'order_type_10');
                    $type = $tongchengConfig['plugin_name'];
                }else if($orderInfo['order_type'] == 11){
                    $title = $titleTmp;
                    $type = lang('plugin/tom_tongcheng', 'order_type_11');
                }else if($orderInfo['order_type'] == 12){
                    $title = lang('plugin/tom_tongcheng', 'order_type_12');
                    $type = $tongchengConfig['plugin_name'];
                }else if($orderInfo['order_type'] == 13){
                    $title = lang('plugin/tom_tongcheng', 'order_type_13');
                    $type = $tongchengConfig['plugin_name'];
                }
                
                $sendTemplateTchehuoren = false;
                if($tchehuoren_fc_money > 0){
                    $sendTemplateTchehuoren = true;
                    
                    $insertData = array();
                    $insertData['order_no']         = $orderInfo['order_no'];
                    $insertData['hehuoren_id']      = $tchehuorenInfo['id'];
                    $insertData['ly_user_id']       = $userInfo['id'];
                    $insertData['child_hehuoren_id'] = 0;
                    $insertData['today_time']       = $nowDayTime;
                    $insertData['week_time']        = $nowWeekTime;
                    $insertData['month_time']       = $nowMonthTime;
                    $insertData['title']            = $title;
                    $insertData['type']             = $type;
                    $insertData['shouyi_price']     = $tchehuoren_fc_money;
                    if($orderInfo['order_type'] == 10){
                        $insertData['content']        = lang('plugin/tom_tongcheng', 'score_recharge_tag');
                    }else{
                        $insertData['content']          = lang('plugin/tom_tongcheng', 'hehuoren_beizu_1') . $tongchengInfo['id'] . lang('plugin/tom_tongcheng', 'hehuoren_beizu_2') . $userInfo['nickname'];
                    }
                    $insertData['shouyi_status']    = 1;
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                }
                
                $sendTemplateTchehuorenParent = false;
                if($tctchehuorenParent_fc_money > 0){
                    $sendTemplateTchehuorenParent = true;
                    
                    $insertData = array();
                    $insertData['order_no']         = $orderInfo['order_no'];
                    $insertData['hehuoren_id']      = $tctchehuorenParentInfo['id'];
                    $insertData['ly_user_id']       = $userInfo['id'];
                    $insertData['child_hehuoren_id'] = $tchehuorenInfo['id'];
                    $insertData['today_time']       = $nowDayTime;
                    $insertData['week_time']        = $nowWeekTime;
                    $insertData['month_time']       = $nowMonthTime;
                    $insertData['title']            = $title;
                    $insertData['type']             = $type;
                    $insertData['shouyi_price']     = $tctchehuorenParent_fc_money;
                    if($orderInfo['order_type'] == 10){
                        $insertData['content']        = lang('plugin/tom_tongcheng', 'score_recharge_tag');
                    }else{
                        $insertData['content']          = lang('plugin/tom_tongcheng', 'hehuoren_beizu_1') . $tongchengInfo['id'] . lang('plugin/tom_tongcheng', 'hehuoren_beizu_2') . $userInfo['nickname'];
                    }
                    $insertData['shouyi_status']    = 1;
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                }
                
                if($sendTemplateTchehuoren == true){
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($tchehuorenInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                        $shouyiText = str_replace("{NICKNAME}",$userInfo['nickname'], lang('plugin/tom_tongcheng', 'paynotify_hehuoren_template'));
                        $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                        $shouyiText = str_replace("{TYPE}",$type, $shouyiText);
                        $shouyiText = str_replace("{MONEY}",$tchehuoren_fc_money, $shouyiText);
                        $smsData = array(
                            'first'         => $shouyiText,
                            'keyword1'      => $tchehuorenConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );
                        if(!empty($tchehuorenConfig['template_id'])){
                            $template_id = $tchehuorenConfig['template_id'];
                        }else{
                            $template_id = $tongchengConfig['template_id'];
                        }
                        @$r = $templateSmsClass->sendSms01($tchehuorenInfo['openid'], $template_id, $smsData);
                    }
                }
                
                if($sendTemplateTchehuorenParent == true){
                    
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($tctchehuorenParentInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                        $shouyiText = str_replace("{TCHEHUOREN}",$tchehuorenInfo['xm'], lang('plugin/tom_tongcheng', 'paynotify_hehuorenparent_template'));
                        $shouyiText = str_replace("{NICKNAME}",$userInfo['nickname'], $shouyiText);
                        $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                        $shouyiText = str_replace("{TYPE}",$type, $shouyiText);
                        $shouyiText = str_replace("{MONEY}",$tctchehuorenParent_fc_money, $shouyiText);
                        $smsData = array(
                            'first'         => $shouyiText,
                            'keyword1'      => $tchehuorenConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );
                        if(!empty($tchehuorenConfig['template_id'])){
                            $template_id = $tchehuorenConfig['template_id'];
                        }else{
                            $template_id = $tongchengConfig['template_id'];
                        }
                        @$r = $templateSmsClass->sendSms01($tctchehuorenParentInfo['openid'], $template_id, $smsData);
                    }
                }
            }
            
        }else{
            $adminFc = true;
        }
    }else{
        $adminFc = true;
    }
    
    if($__ShowTcadmin == 1 && $adminFc && $orderInfo['pay_price'] > 0){

        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
        $fc_scale = $tcadminConfig['fc_scale'];
        if($sitesInfo['fl_fc_scale'] > 0){
            $fc_scale = $sitesInfo['fl_fc_scale'];
        }
        $fc_money = $orderInfo['pay_price']*($fc_scale/100);
        $fc_money = number_format($fc_money,2);

        Log::DEBUG("update fc_money:" . $fc_money);

        $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);

        $old_money = 0;
        if($walletInfo){
            $old_money = $walletInfo['account_balance'];

            $updateData = array();
            $updateData['account_balance']   = $walletInfo['account_balance'] + $fc_money;
            $updateData['total_income']   = $walletInfo['total_income'] + $fc_money;
            C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
        }else{
            $insertData = array();
            $insertData['site_id']              = $orderInfo['site_id'];
            $insertData['account_balance']      = $fc_money;
            $insertData['total_income']         = $fc_money;
            $insertData['add_time']             = TIMESTAMP;
            C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
        }

        $insertData = array();
        $insertData['site_id']      = $orderInfo['site_id'];
        $insertData['log_type']     = 1;
        $insertData['change_money'] = $fc_money;
        $insertData['old_money']    = $old_money;
        if($orderInfo['order_type'] == 10){
            $insertData['beizu']        = lang('plugin/tom_tongcheng', 'score_recharge_tag');
        }else{
            $insertData['beizu']        = contentFormat($tongchengInfo['content']);
        }
        
        $insertData['order_no']     = $orderInfo['order_no'];
        $insertData['order_type']   = $orderInfo['order_type'];
        $insertData['log_ip']       = $_G['clientip'];
        $insertData['log_time']     = TIMESTAMP;
        C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData);Log::DEBUG("update fc_end:" . $fc_money);
    }
    # fc end
    
    if($orderInfo['order_type'] == 12){
        $access_token = $weixinClass->get_access_token();
        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
        if($access_token && !empty($manageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$orderInfo['site_id']}&mod=index");
            
            $smsData = array(
                'first'         => lang('plugin/tom_tongcheng', 'paynotify_apply_sites_template'),
                'keyword1'      => $tongchengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => ''
            );
            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
}
