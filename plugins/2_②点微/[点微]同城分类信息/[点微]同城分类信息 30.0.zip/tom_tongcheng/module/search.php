<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!empty($__SitesInfo['search_all_type'])){
    $tongcheng_search_all_type = explode('|', $__SitesInfo['search_all_type']);
}else{
    $tongcheng_search_all_type = unserialize($tongchengConfig['tongcheng_search_all_type']);
}
$searchTypeList = array();
if(is_array($tongcheng_search_all_type) && !empty($tongcheng_search_all_type)){
    foreach($tongcheng_search_all_type as $key => $value){
        if($value == 'tongcheng'){
            $searchTypeList[$key]['value'] = $value;
            $searchTypeList[$key]['url'] = "plugin.php?id=tom_tongcheng:ajax&site={$site_id}&act=get_search_url";
        }else if($value == 'shop' && $__ShowTcshop == 1){
            $searchTypeList[$key]['value'] = $value;
            $searchTypeList[$key]['url'] = "plugin.php?id=tom_tcshop:ajax&site={$site_id}&act=get_search_url";
        }else if($value == 'mall' && $__ShowTcmall == 1){
            $searchTypeList[$key]['value'] = $value;
            $searchTypeList[$key]['url'] = "plugin.php?id=tom_tcmall:ajax&site={$site_id}&act=get_search_url";
        }else if($value == 'qianggou' && $__ShowTcqianggou == 1){
            $searchTypeList[$key]['value'] = $value;
            $searchTypeList[$key]['url'] = "plugin.php?id=tom_tcqianggou:ajax&site={$site_id}&act=get_search_url";
        }else if($value == 'ptuan' && $__ShowTcptuan == 1){
            $searchTypeList[$key]['value'] = $value;
            $searchTypeList[$key]['url'] = "plugin.php?id=tom_tcptuan:ajax&site=".$site_id."&act=get_search_url";
        }else if($value == 'toutiao' && $__ShowTctoutiao == 1){
            $searchTypeList[$key]['value'] = $value;
            $searchTypeList[$key]['url'] = "plugin.php?id=tom_tctoutiao:ajax&site=".$site_id."&act=get_search_url";
        }else if($value == 'kaquan' && $__ShowTcqianggou == 1){
            $searchTypeList[$key]['value'] = $value;
            $searchTypeList[$key]['url'] = "plugin.php?id=tom_tcqianggou:ajax&site={$site_id}&act=get_coupon_search_url";
        }else if($value == '114' && $__ShowTc114 == 1){
            $searchTypeList[$key]['value'] = $value;
            $searchTypeList[$key]['url'] = "plugin.php?id=tom_tc114:ajax&site={$site_id}&act=get_search_url";
        }
    }
}
$searchTypeCount = count($searchTypeList);

$searchListTmp = C::t("#tom_tongcheng#tom_tongcheng_search")->fetch_all_list(" AND site_id = {$site_id} ", 'ORDER BY ssort ASC, id DESC ');
if(is_array($searchListTmp) && !empty($searchListTmp)){ 
}else{
    $searchListTmp = C::t("#tom_tongcheng#tom_tongcheng_search")->fetch_all_list(" AND site_id = 1 ", 'ORDER BY ssort ASC, id DESC ');
}
$searchList = array();
if(is_array($searchListTmp) && !empty($searchListTmp)){
    foreach($searchListTmp as $key => $value){
        $value['link'] = str_replace("{site}",$site_id, $value['link']);
        if($value['type'] == 1){
            
            if($value['plugin_id'] == 'tongcheng'){
                $searchList[$key] = $value;
                $searchList[$key]['link'] = "plugin.php?id=tom_tongcheng:ajax&site={$site_id}&act=get_search_url";
            }else if($value['plugin_id'] == 'shop' && $__ShowTcshop == 1){
                $searchList[$key] = $value;
                $searchList[$key]['link'] = "plugin.php?id=tom_tcshop:ajax&site={$site_id}&act=get_search_url";
            }else if($value['plugin_id'] == 'mall' && $__ShowTcmall == 1){
                $searchList[$key] = $value;
                $searchList[$key]['link'] = "plugin.php?id=tom_tcmall:ajax&site={$site_id}&act=get_search_url";
            }else if($value['plugin_id'] == 'qianggou' && $__ShowTcqianggou == 1){
                $searchList[$key] = $value;
                $searchList[$key]['link'] = "plugin.php?id=tom_tcqianggou:ajax&site={$site_id}&act=get_search_url";
            }else if($value['plugin_id'] == 'ptuan' && $__ShowTcptuan == 1){
                $searchList[$key] = $value;
                $searchList[$key]['link'] = "plugin.php?id=tom_tcptuan:ajax&site=".$site_id."&act=get_search_url";
            }else if($value['plugin_id'] == 'toutiao' && $__ShowTctoutiao == 1){
                $searchList[$key] = $value;
                $searchList[$key]['link'] = "plugin.php?id=tom_tctoutiao:ajax&site=".$site_id."&act=get_search_url";
            }else if($value['plugin_id'] == 'kaquan' && $__ShowTcqianggou == 1){
                $searchList[$key] = $value;
                $searchList[$key]['link'] = "plugin.php?id=tom_tcqianggou:ajax&site={$site_id}&act=get_coupon_search_url";
            }else if($value['plugin_id'] == '114' && $__ShowTc114 == 1){
                $searchList[$key] = $value;
                $searchList[$key]['link'] = "plugin.php?id=tom_tc114:ajax&site={$site_id}&act=get_search_url";
            }
            
        }else if($value['type'] == 2){
            $searchList[$key] = $value;
        }
    }
}
$searchCount = count($searchList);

$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=search";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:search");  