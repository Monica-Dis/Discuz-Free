<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($tcadminConfig['open_child_apply_sites'] == 1){
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=index");exit;
}

$applySitesInfo = C::t("#tom_tongcheng#tom_tongcheng_apply_sites")->fetch_by_user_id($__UserInfo['id']);

$cityListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid(0);
$cityList = array();
$chooseI = $chooseJ = 0;
$i = 0;
if(is_array($cityListTmp) && !empty($cityListTmp)){
    foreach ($cityListTmp as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        if($applySitesInfo['city_id'] == $value['id']){
            $chooseI = $i;
        }
        $areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($areaListTmp) && !empty($areaListTmp)){
            foreach ($areaListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                if($applySitesInfo['area_id'] == $vv['id']){
                    $chooseJ = $j;
                }
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$cityName = '';
if(!empty($applySitesInfo['city_id'])){
    $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($applySitesInfo['city_id']);
    $cityName = $cityInfoTmp['name'];
}

$areaName = '';
if(!empty($applySitesInfo['area_id'])){
    $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($applySitesInfo['area_id']);
    $areaName = $areaInfoTmp['name'];
}

$showPhoneDialog = 0;
if(empty($__UserInfo['tel'])){
    $showPhoneDialog = 1;
}

$phone_back_url = $weixinClass->get_url();
$phone_back_url = urlencode($phone_back_url);

$payUrl   = "plugin.php?id=tom_tongcheng:pay&site={$site_id}&act=pay_apply_sites&formhash=".$formhash;

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=applysites";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:applysites");  