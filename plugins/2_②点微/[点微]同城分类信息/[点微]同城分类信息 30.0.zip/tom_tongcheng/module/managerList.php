<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=index");exit;
}
# check end

if($_GET['act'] == 'shenhe' && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $tongcheng_id = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    $shenhe_status = intval($_GET['shenhe_status'])>0? intval($_GET['shenhe_status']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    
    $updateData = array();
    $updateData['shenhe_status']      = $shenhe_status;
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id,$updateData);
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengInfo['user_id']);
    
    if($tongchengInfo){
        $message = strip_tags($tongchengInfo['content']);
        $message = cutstr(contentFormat($message),50,"...");
        $message = $message.'<br/><a href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=info&tongcheng_id='.$tongchengInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        
        $insertData = array();
        $insertData['user_id']      = $toUser['id'];
        $insertData['type']     = 1;
        if($shenhe_status == 1){
            $insertData['content']      = '<b><font color="#238206">'.lang("plugin/tom_tongcheng", "shenhe_status_1_title").'</font></b><br/>'.$message;
        }else if($shenhe_status == 3){
            $insertData['content']      = '<b><font color="#fd0d0d">'.lang("plugin/tom_tongcheng", "shenhe_status_3_title").'</font></b><br/><font color="#8e8e8e">'.$content.'</font><br/>'.$message;
        }
        $insertData['is_read']     = 0;
        $insertData['tz_time']     = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    $nextSmsTime = $toUser['last_smstp_time'] + 0;
    
    $content = strip_tags($tongchengInfo['content']);
    $content = cutstr(contentFormat($content),20,"...");

    if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=message");
        if($shenhe_status == 1){
            $template_first = lang("plugin/tom_tongcheng", "shenhe_status_1_title");
        }else if($shenhe_status == 3){
            $template_first = lang("plugin/tom_tongcheng", "shenhe_status_3_title");
        }
        $smsData = array(
            'first'         => $template_first,
            'keyword1'      => $__SitesInfo['name'],
            'keyword2'      => $content,
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);

        if($r){
            $updateData = array();
            $updateData['last_smstp_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
        }

    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'fenghao' && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $fenghao_time   = intval($_GET['fenghao_time'])>0? intval($_GET['fenghao_time']):0;
    $fenghao_msg    = isset($_GET['fenghao_msg'])? daddslashes($_GET['fenghao_msg']):'';
    
    $fenghaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id); 
    
    if($fenghaoUserInfo){
        
        $fenghao_end_time = 999;
        if($fenghao_time == 2){
            $fenghao_end_time = TIMESTAMP + 86400*7;
        }else if($fenghao_time == 3){
            $fenghao_end_time = TIMESTAMP + 86400*30;
        }else if($fenghao_time == 4){
            $fenghao_end_time = TIMESTAMP + 86400*90;
        }
        
        $updateData = array();
        $updateData['status']           = 2;
        $updateData['fenghao_time']     = $fenghao_end_time;
        $updateData['fenghao_msg']      = $fenghao_msg;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($fenghaoUserInfo['id'],$updateData);

        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2 WHERE user_id='{$fenghaoUserInfo['id']}' ", 'UNBUFFERED');
        
        if($__ShowTczhaopin == 1){
            DB::query("UPDATE ".DB::table('tom_tczhaopin')." SET status=0 WHERE user_id='{$fenghaoUserInfo['id']}' ", 'UNBUFFERED');
        }
        
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'jiefen' && $_GET['formhash'] == FORMHASH){
    
    $tongcheng_id = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    
    $updateData = array();
    $updateData['status']           = 1;
    $updateData['fenghao_time']     = 0;
    $updateData['fenghao_msg']      = '';
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($tongchengInfo['user_id'],$updateData);
    
    echo 200;exit;
    
}else if($_GET['act'] == 'del' && $_GET['formhash'] == FORMHASH){
    
    $tongcheng_id = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    $photoListTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$tongcheng_id} "," ORDER BY id ASC ",0,20);
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach ($photoListTmp as $key => $value){
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                    $picurl = $_G['setting']['attachdir'].'tomwx/'.$value['picurl'];
                }else{
                    $picurl = DISCUZ_ROOT.'./'.$value['picurl'];
                }
                if(file_exists($picurl)){
                    @unlink($picurl);
                }
            }
        }
    }
    
    C::t('#tom_tongcheng#tom_tongcheng')->delete_by_id($tongcheng_id);
    C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongcheng_id);
    C::t('#tom_tongcheng#tom_tongcheng_photo')->delete_by_tongcheng_id($tongcheng_id);
    C::t('#tom_tongcheng#tom_tongcheng_tag')->delete_by_tongcheng_id($tongcheng_id);
    C::t('#tom_tongcheng#tom_tongcheng_content')->delete_by_tongcheng_id($tongcheng_id);
    C::t('#tom_tongcheng#tom_tongcheng_sfc_cache')->delete_by_tongcheng_id($tongcheng_id);
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=managerList&keyword=".urlencode(trim($keyword));
    
    echo $url;exit;
    
}else if($_GET['act'] == 'shenhe_show'){
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    $fromtype       = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage       = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    
    $content = contentFormat($tongchengInfo['content']);
    
    $shenhe_fail_list = array();
    if(!empty($tongchengConfig['shenhe_fail_list'])){
        $shenhe_fail_list_str = str_replace("\r\n","{n}",$tongchengConfig['shenhe_fail_list']); 
        $shenhe_fail_list_str = str_replace("\n","{n}",$shenhe_fail_list_str);
        $shenhe_fail_list_tmp = explode("{n}", $shenhe_fail_list_str);
        if(is_array($shenhe_fail_list_tmp) && !empty($shenhe_fail_list_tmp)){
            foreach ($shenhe_fail_list_tmp as $key => $value){
                if(!empty($value)){
                    $shenhe_fail_list[] = $value;
                }
            }
        }
    }
    
    $ajaxShenheUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=managerList&act=shenhe&";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tongcheng:managerShenhe");exit;
    
}else if($_GET['act'] == 'fenghao_show'){
    
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $fromtype       = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage       = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $fenghaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id); 
    
    $ajaxFenghaoUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=managerList&act=fenghao";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tongcheng:managerFenghao");exit;
    
}


$keyword  = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$uid   = intval($_GET['uid'])>0? intval($_GET['uid']):0;
$page  = intval($_GET['page'])>0? intval($_GET['page']):1;
$type  = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = " AND pay_status!=1 AND tczhaopin_id=0 AND tczhaopin_resume_id=0 AND tcfangchan_id=0 AND tcershou_goods_id=0 AND tcershou_needs_id=0 AND tcfangchan_needs_id=0 ";
if($type == 1){
    $where.= " AND shenhe_status=2 ";
}
if($type == 2){
    $where.= " AND shenhe_status=3 ";
}
if($__UserInfo['groupid'] == 2){
    $where.= " AND site_id={$site_id} ";
}
if($uid > 0){
    $where.= " AND user_id={$uid} ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count(" {$where} ",$keyword);
$tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list(" {$where} "," ORDER BY refresh_time DESC,id DESC ",$start,$pagesize,$keyword);

$tongchengList = array();
foreach ($tongchengListTmp as $key => $value) {
    $tongchengList[$key] = $value;
    $tongchengList[$key]['content'] = contentFormat($value['content']);

    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
    $typeInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($value['type_id']);
    $siteInfoTmp = array('id'=>1,'name'=>$tongchengConfig['plugin_name']);
    if($value['site_id'] > 1){
        $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
    }

    $tongchengAttrListTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY paixu ASC,id DESC ",0,50);
    $tongchengTagListTmp = C::t('#tom_tongcheng#tom_tongcheng_tag')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY id DESC ",0,50);
    $tongchengPhotoListTmpTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY id ASC ",0,50);
    $tongchengPhotoListTmp = array();
    if(is_array($tongchengPhotoListTmpTmp) && !empty($tongchengPhotoListTmpTmp)){
        foreach ($tongchengPhotoListTmpTmp as $kk => $vv){
            if(!preg_match('/^http/', $vv['picurl']) ){
                if(strpos($vv['picurl'], 'source/plugin/tom_') === false){
                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                }else{
                    $picurl = $vv['picurl'];
                }
            }else{
                $picurl = $vv['picurl'];
            }
            $tongchengPhotoListTmp[$kk] = $picurl;
        }
    }
    
    $tchongbaoInfo = array();
    if($__ShowTchongbao == 1){
        $tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(" AND tongcheng_id = {$value['id']} AND pay_status = 2 AND only_show = 1 ", 'ORDER BY add_time DESC,id DESC', 0, 1);
        if(is_array($tchongbaoInfoTmp) && !empty($tchongbaoInfoTmp[0])){
            $tchongbaoInfo = $tchongbaoInfoTmp[0];
        }
    }
    
    $tongchengList[$key]['userInfo'] = $userInfoTmp;
    $tongchengList[$key]['typeInfo'] = $typeInfoTmp;
    $tongchengList[$key]['attrList'] = $tongchengAttrListTmp;
    $tongchengList[$key]['tagList'] = $tongchengTagListTmp;
    $tongchengList[$key]['photoList'] = $tongchengPhotoListTmp;
    $tongchengList[$key]['siteInfo'] = $siteInfoTmp;
    $tongchengList[$key]['tchongbaoInfo'] = $tchongbaoInfo;
    
    $payRefreshStatus = 0;
    $shengyuRefreshTimes = 0;
    if($tongchengConfig['free_refresh_times'] > 0){
        $refresh_log_count = C::t('#tom_tongcheng#tom_tongcheng_refresh_log')->fetch_all_count(" AND tongcheng_id={$value['id']} AND time_key={$nowDayTime} ");
        if($tongchengConfig['free_refresh_times'] > $refresh_log_count){
            $shengyuRefreshTimes = $tongchengConfig['free_refresh_times'] - $refresh_log_count;
        }else{
            $payRefreshStatus = 1;
        }
    }else{
        $payRefreshStatus = 1;
    }
    
    $tongchengList[$key]['payRefreshStatus'] = $payRefreshStatus;
    $tongchengList[$key]['shengyuRefreshTimes'] = $shengyuRefreshTimes;
    
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=managerList&type={$type}&page={$prePage}&uid={$uid}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=managerList&type={$type}&page={$nextPage}&uid={$uid}&keyword=".$_GET['keyword'];

$ajaxShenheUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=managerList&act=shenhe&&formhash=".$formhash;
$ajaxFenhaoUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=managerList&act=fenhao&&formhash=".$formhash;
$ajaxJiefenUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=managerList&act=jiefen&&formhash=".$formhash;
$ajaxDelUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=managerList&act=del&&formhash=".$formhash;

$searchUrl = 'plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=managerList&act=get_search_url';


$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:managerList");