<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$tongcheng_id = isset($_GET['tongcheng_id'])? intval($_GET['tongcheng_id']):0;

$tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
$typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);

# check start
if($tongchengInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=index");exit;
}
# check end

$content = contentFormat($tongchengInfo['content']);

 $sites_priceTmp = C::t('#tom_tongcheng#tom_tongcheng_sites_price')->fetch_all_list(" AND site_id={$site_id} AND type_id={$tongchengInfo['type_id']} "," ORDER BY id DESC ",0,1);
 if(is_array($sites_priceTmp) && !empty($sites_priceTmp) && $sites_priceTmp[0]['id']>0){
     $typeInfo['free_status'] = $sites_priceTmp[0]['free_status'];
     $typeInfo['fabu_price'] = $sites_priceTmp[0]['fabu_price'];
     $typeInfo['fabu_price_str']  = $sites_priceTmp[0]['fabu_price_str'];
 }

$over_days_item = array();
if(!empty($typeInfo['fabu_price_str'])){
    $fabu_price_str = str_replace("\r\n","{n}",$typeInfo['fabu_price_str']); 
    $fabu_price_str = str_replace("\n","{n}",$fabu_price_str);
    $fabu_price_list = explode("{n}", $fabu_price_str);
    if(is_array($fabu_price_list) && !empty($fabu_price_list)){
        foreach ($fabu_price_list as $key => $value){
            $fabu_price_list_item = explode("|", $value);
            $fabu_price_list_item_days = intval($fabu_price_list_item[0]);
            $fabu_price_list_item_price = floatval($fabu_price_list_item[1]);
            if(isset($fabu_price_list_item[2]) && !empty($fabu_price_list_item[2])){
                $fabu_price_list_item_msg = trim($fabu_price_list_item[2]);
            }else{
                $fabu_price_list_item_msg = 'NULL';
            }
            if(strpos($fabu_price_list_item_msg, 'TOP') !== false){
                $top_days_tmp = 0;
                $topStrTmp = str_replace('TOP', '', $fabu_price_list_item_msg);
                if(intval($topStrTmp) > 0){
                    $top_days_tmp = intval($topStrTmp);
                }
                if($top_days_tmp > 0){
                    $fabu_price_list_item_msg = str_replace("{DAYS}",$top_days_tmp, lang('plugin/tom_tongcheng', 'fabu_top_zengsong_days'));
                }
            }
            if($fabu_price_list_item_days > 0 && $fabu_price_list_item_price > 0){
                $over_days_item[$fabu_price_list_item_days]['days'] = $fabu_price_list_item_days;
                $over_days_item[$fabu_price_list_item_days]['price'] = $fabu_price_list_item_price;
                $over_days_item[$fabu_price_list_item_days]['vipprice'] = $fabu_price_list_item_price/2;
                $over_days_item[$fabu_price_list_item_days]['msg'] = $fabu_price_list_item_msg;
            }
        }
    }
}

$shop_free_fenlei_times = 0;
if($__ShowTcshop == 1){
    $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$__UserInfo['id']} AND v.fenlei_times > 0 "," ORDER BY s.id DESC ",0,100);
    if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
        foreach ($tcshopListTmp as $key => $value){
            $shop_free_fenlei_times = $shop_free_fenlei_times + $value['vip_fenlei_times'];
        }
    }
}

$fabuPayStatus = 0;
$isVipFabu = 0;
$isShopFabu = 0;
if($typeInfo['free_status'] == 2 && $typeInfo['fabu_price'] > 0 && $__UserInfo['editor']==0){
    $fabuPayStatus = 1;
    ## VIP start
    $shengyuVipTimes = 0;
    if($__ShowTcyikatong == 1 && $tcyikatongConfig['open_fenlei_tequan'] == 1 && $tcyikatongConfig['fenlei_tequan_type'] == 1){
        $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($__UserInfo['id']);
        if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
            $isVipFabu = 1;
            $typeInfo['fabu_price'] = $typeInfo['fabu_price']/2;
        }else{
            $isVipFabu = 3;
        }
    }
    if($__ShowTcyikatong == 1 && $tcyikatongConfig['open_fenlei_tequan'] == 1 && $tcyikatongConfig['fenlei_tequan_type'] == 2){
        $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($__UserInfo['id']);
        if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
            $vip_fabu_log_count = C::t('#tom_tcyikatong#tom_tcyikatong_fabu_log')->fetch_all_count(" AND user_id={$__UserInfo['id']} AND time_key={$nowDayTime} ");
            if($vip_fabu_log_count < $tcyikatongConfig['fenlei_tequan_times']){
                $fabuPayStatus      = 0;
                $isVipFabu          = 2;
                $shengyuVipTimes    = $tcyikatongConfig['fenlei_tequan_times'] - $vip_fabu_log_count;
            }
        }else{
            $isVipFabu = 4;
        }
    }
    ## VIP end
    
    if($__ShowTcshop == 1 && $shop_free_fenlei_times > 0 && $fabuPayStatus == 1){
        $shop_fabu_log_count = C::t('#tom_tcshop#tom_tcshop_fabu_log')->fetch_all_count(" AND user_id={$__UserInfo['id']} AND time_key={$nowDayTime} ");
        $shengyuShopTimes = 0;
        if($shop_fabu_log_count < $shop_free_fenlei_times){
            $fabuPayStatus      = 0;
            $isShopFabu         = 1;
            $shengyuShopTimes   = $shop_free_fenlei_times - $shop_fabu_log_count;
        }
    }

    if($tongchengConfig['free_fabu_times'] > 0 && $fabuPayStatus == 1 && $typeInfo['jifei_type'] == 1){
        $fabu_log_count = C::t('#tom_tongcheng#tom_tongcheng_fabu_log')->fetch_all_count(" AND user_id={$__UserInfo['id']} AND time_key={$nowDayTime} ");
        if($tongchengSetting['open_all_free_fabu_times'] == 1 && $tongchengSetting['all_free_fabu_times'] > 0){
            if($tongchengSetting['free_fabu_times_days'] > 0){
                $free_fabu_times_days_time = TIMESTAMP - $tongchengSetting['free_fabu_times_days']*86400;
                $all_fabu_log_count = C::t('#tom_tongcheng#tom_tongcheng_fabu_log')->fetch_all_count(" AND user_id={$__UserInfo['id']} AND add_time > {$free_fabu_times_days_time} ");
            }else{
                $all_fabu_log_count = C::t('#tom_tongcheng#tom_tongcheng_fabu_log')->fetch_all_count(" AND user_id={$__UserInfo['id']} ");
            }
            if($tongchengSetting['all_free_fabu_times'] <= $all_fabu_log_count){
                $tongchengConfig['free_fabu_times'] = 0;
            }
        }
        if($tongchengConfig['free_fabu_times'] > $fabu_log_count){
            $fabuPayStatus = 3;
        }
    }

    if($tongchengConfig['pay_score_yuan'] > 0 && $fabuPayStatus == 1 && $typeInfo['jifei_type'] == 1 && $tongchengConfig['open_fabu_score_pay'] == 1){
        $useScore = $tongchengConfig['pay_score_yuan']*$typeInfo['fabu_price'];
        $useScore = ceil($useScore);
        if($__UserInfo['score'] >= $useScore){
            $fabuPayStatus = 2;
        }
    }
}

$payUrl = "plugin.php?id=tom_tongcheng:pay&site={$site_id}&act=xufei";
$myListAllUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:xufei");