<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$nowMonthTime = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);

$act  = isset($_GET['act'])? addslashes($_GET['act']):'';

$ajaxHongbaoTzUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=hongbao_tz&&formhash='.$formhash;


$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
if($__SitesInfo['id'] > 1){
    if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])){
        if(strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_') === FALSE){
            $kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
        }else{
            $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
        }
    }else{
        $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
    }
}

$hehuorenFcOpen = 0;
if($site_id > 1 && $__SitesInfo['hehuoren_fc_open'] == 1){
    $hehuorenFcOpen = 1;
}else if($site_id == 1){
    $hehuorenFcOpen = 1;
}

$showHehuorenBtn = 0;
if($__ShowTchehuoren == 1){
    $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
    if($tchehuorenInfoTmp){
        $showHehuorenBtn = 1;
    }
}

$showTcshopBtn = 0;
if($__ShowTcshop == 1){
    $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(" AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,10);
    if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
        $showTcshopBtn = 1;
    }
}

$__CardInfo = array();
$isVip = 0;
if($__ShowTcyikatong == 1){
    $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($__UserInfo['id']);
    if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
        $isVip = 1;
        $__CardInfo = $cardInfoTmp;
    }
}

## tcmajia start
$openMajiaStatus = 0;
if($__ShowTcmajia == 1){
    if($tcmajiaConfig['use_majia_admin_1'] == $__UserInfo['id']){
        $openMajiaStatus = 1;
    }
    if($tcmajiaConfig['use_majia_admin_2'] == $__UserInfo['id']){
        $openMajiaStatus = 1;
    }
    if($tcmajiaConfig['use_majia_admin_3'] == $__UserInfo['id']){
        $openMajiaStatus = 1;
    }
    if($tcmajiaConfig['use_majia_admin_4'] == $__UserInfo['id']){
        $openMajiaStatus = 1;
    }
    if($tcmajiaConfig['use_majia_admin_5'] == $__UserInfo['id']){
        $openMajiaStatus = 1;
    }
    if($__UserInfo['is_majia'] == 1){
        $openMajiaStatus = 1;
    }
}
## tcmajia end

$address_back_url = $weixinClass->get_url();
$address_back_url = urlencode($address_back_url);

$ajaxLoginOutUrl = 'plugin.php?id=tom_ucenter:ajax&site='.$site_id.'&act=loginout&&formhash='.$formhash;
$bbsLoginOutBackUrl = urlencode("plugin.php?id=tom_tongcheng&site={$site_id}&mod=index");
$bbsLoginOut = "member.php?mod=logging&action=logout&referer={$bbsLoginOutBackUrl}&formhash={$formhash}&handlekey=logout";

$signStatus = 0;
if($__ShowTcsign == 1 && $__UserInfo['id'] > 0){
    $signDataList = C::t('#tom_tcsign#tom_tcsign_data')->fetch_all_list("AND user_id = {$__UserInfo['id']} AND time_key = {$nowDayTime}"," ORDER BY id DESC ",0,1);
    if(is_array($signDataList) && !empty($signDataList[0]) && $signDataList[0]['id'] > 0){
        $signStatus = 1;
    }
}

$fenghao_time = '';
if($__UserInfo['fenghao_time'] > 1000){
    $fenghao_time = dgmdate($__UserInfo['fenghao_time'],"Y-m-d",$tomSysOffset);
}

if($act == 'shop'){
    
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=store");exit;
    
}else if($act == 'set'){
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tongcheng:personal_set");
}else{
    $onlyTcmall = 0;
    $nowtime = TIMESTAMP;
    if($__ShowTcmall == 1){
        $onlyTcmall = 1;
        $cartGoodsCount = C::t('#tom_tcmall#tom_tcmall_cart')->fetch_goods_num(" AND user_id={$__UserInfo['id']} ");
        $mallCount = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND order_status IN(1,2,3) ");
        $daiFuKuanCount = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND order_status = 1 ");
        $daiFaHuoCount = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND order_status = 2 ");
        $daiShouHuoCount = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND order_status = 3 ");
        $daiPinglunCount = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND order_status = 4 AND pinglun_status = 0 ");
    }
    
    if($__ShowTcqianggou == 1){
        $onlyTcmall = 0;
        $qianggouCount = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND type_id=1 AND order_status=2 ");
        $qianggouOverCount = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table("tom_tcqianggou_order")." o LEFT JOIN ".DB::table("tom_tcqianggou_goods")." g ON o.goods_id=g.id  WHERE o.user_id = {$__UserInfo['id']} AND o.type_id=1 AND o.order_status=2 AND o.peisong_type=1 AND g.hexiao_time < {$nowtime} ");
        if($qianggouOverCount['num'] > 0){
            $qianggouCount = $qianggouCount - $qianggouOverCount['num'];
        }
        
        $kaquanCount = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND type_id IN(2,3,4) AND order_status=2 ");
        $kaquanOverCount = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table("tom_tcqianggou_order")." o LEFT JOIN ".DB::table("tom_tcqianggou_goods")." g ON o.goods_id=g.id  WHERE o.user_id = {$__UserInfo['id']} AND o.type_id IN(2,3,4) AND o.order_status=2 AND o.peisong_type=1 AND g.hexiao_time < {$nowtime} ");
        if($kaquanOverCount['num'] > 0){
            $kaquanCount = $kaquanCount - $kaquanOverCount['num'];
        }
    }
    
    if($__ShowTcptuan == 1){
        $onlyTcmall = 0;
        $ptuanCount = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND order_status IN (2,3,4) ");
        $ptuanOverCount = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table("tom_tcptuan_order")." o LEFT JOIN ".DB::table("tom_tcptuan_goods")." g ON o.goods_id=g.id  WHERE o.user_id = {$__UserInfo['id']} AND o.order_status IN (2,3,4) AND o.peisong_type=1 AND g.hexiao_time < {$nowtime} ");
        if($ptuanOverCount['num'] > 0){
            $ptuanCount = $ptuanCount - $ptuanOverCount['num'];
        }
    }
    
    if($__ShowTckjia == 1){
        $onlyTcmall = 0;
        $kjiaCount  = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND order_status=2 ");
        $kjiaOverCount = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table("tom_tckjia_order")." o LEFT JOIN ".DB::table("tom_tckjia_goods")." g ON o.goods_id=g.id  WHERE o.user_id = {$__UserInfo['id']} AND o.order_status=2 AND o.peisong_type=1 AND g.hexiao_time < {$nowtime} ");
        if($kjiaOverCount['num'] > 0){
            $kjiaCount = $kjiaCount - $kjiaOverCount['num'];
        }
    }
    
    $orderPluginNum = 0;
    if($__ShowTcmall == 1){ $orderPluginNum+= 1;}
    if($__ShowTcqianggou == 1){ $orderPluginNum+= 1;}
    if($__ShowTcptuan == 1){ $orderPluginNum+= 1;}
    if($__ShowTckjia == 1){ $orderPluginNum+= 1;}
    
    if($__ShowTcchoujiang == 1){
        $choujiangCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND order_status IN(1,2) ");
        $choujiangOverCount = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table("tom_tcchoujiang_order")." o LEFT JOIN ".DB::table("tom_tcchoujiang")." g ON o.tcchoujiang_id=g.id  WHERE o.user_id = {$__UserInfo['id']} AND o.order_status IN(1,2) AND g.hexiao_time < {$nowtime} ");
        if($choujiangOverCount['num'] > 0){
            $choujiangCount = $choujiangCount - $choujiangOverCount['num'];
        }
    }
    
    if($__ShowTchehuoren == 1){
        $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
        if($tchehuorenInfo['id'] > 0){
            $shouyiNumDay = 3;
            if($tchehuorenConfig['shouyi_num_day'] > 0){
                $shouyiNumDay = $tchehuorenConfig['shouyi_num_day'];
            }
            $ruzhangTime = TIMESTAMP - ($shouyiNumDay * 86400);
            $ruzhuangShouyiTmp = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_all_list(" AND hehuoren_id = {$tchehuorenInfo['id']} AND add_time <= {$ruzhangTime} AND shouyi_status = 1 " , 'ORDER BY id DESC', 0, 10000);
            if(is_array($ruzhuangShouyiTmp) && !empty($ruzhuangShouyiTmp)){
                foreach($ruzhuangShouyiTmp as $key => $value){
                    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($__UserInfo['id']);

                    $updateData = array();
                    $updateData['shouyi_status']    = 2;
                    $updateData['handle_status']    = 1;
                    $updateData['shouyi_time']      = TIMESTAMP;
                    C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->update($value['id'], $updateData);

                    DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$value['shouyi_price']} WHERE id='{$userInfoTmp['id']}'", 'UNBUFFERED');

                    $insertData = array();
                    $insertData['user_id']          = $userInfoTmp['id'];
                    $insertData['type_id']          = 2;
                    $insertData['change_money']     = $value['shouyi_price'];
                    $insertData['old_money']        = $userInfoTmp['money'];
                    $insertData['tag']              = $tchehuorenConfig['hehuoren_name'].lang('plugin/tom_tchehuoren', 'shouyi_tag');
                    $insertData['beizu']            = $value['content'];
                    $insertData['log_time']         = TIMESTAMP;
                    C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
                }
                
                $userAllMoneyTmp   = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_total_shouyi_sum(" AND hehuoren_id = {$tchehuorenInfo['id']} ");
                $userMonthMoneyTmp = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_total_shouyi_sum(" AND hehuoren_id = {$tchehuorenInfo['id']} AND month_time = {$nowMonthTime} ");
                $userWeekMoneyTmp  = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_total_shouyi_sum(" AND hehuoren_id = {$tchehuorenInfo['id']} AND week_time = {$nowWeekTime} ");
                $userAllMoneyTmp   = number_format(floatval($userAllMoneyTmp), 2, '.', '');
                $userMonthMoneyTmp = number_format(floatval($userMonthMoneyTmp), 2, '.', '');
                $userWeekMoneyTmp  = number_format(floatval($userWeekMoneyTmp), 2, '.', '');

                if($tchehuorenInfo['open_xu_money'] == 0){
                    $updateData = array();
                    $updateData['all_money']            = $userAllMoneyTmp;
                    $updateData['week_money']           = $userWeekMoneyTmp;
                    $updateData['month_money']          = $userMonthMoneyTmp;
                    C::t('#tom_tchehuoren#tom_tchehuoren')->update($tchehuorenInfo['id'], $updateData);
                }
            }
        }
    }
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tongcheng:personal");
}