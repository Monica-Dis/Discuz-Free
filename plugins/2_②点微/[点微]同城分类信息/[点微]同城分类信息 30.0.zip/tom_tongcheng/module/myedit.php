<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$act  = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 200,
    );
    $nickname   = isset($_GET['nickname'])? daddslashes(diconv(urldecode($_GET['nickname']),'utf-8')):'';
    $nickname   = dhtmlspecialchars($nickname);
    $picurl     = isset($_GET['picurl'])? daddslashes($_GET['picurl']):'';
    
    if($__ShowXiaofenlei == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php';
        if($xiaofenleiConfig['open_msgseccheck'] == 1){
            @$s_m_r = wx_msgSecCheck($nickname);
            if($s_m_r['code'] == 100 || $s_m_r['code'] == 500){
                $outArr = array(
                    'status'=> 500,
                    'word'=> $s_m_r['word'],
                );
                echo json_encode($outArr); exit;
            }
        }
        $imgseccheck_listArr = unserialize($xiaofenleiConfig['imgseccheck_list']);
        if(array_search('1',$imgseccheck_listArr) !== false && $xiaofenleiConfig['open_imgseccheck'] == 1){
            $check_picurl_tmp = $_G['siteurl'].$picurl;
            @$s_i_r = wx_imgSecCheck($check_picurl_tmp);
            if($s_i_r['code'] == 500){
                $outArr = array(
                    'status'=> 501,
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    
    if(empty($nickname)){
        $nickname = $__UserInfo['nickname'];
    }
    $updateData = array();
    $updateData['nickname'] = $nickname;
    $updateData['picurl'] = $picurl;
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
    
    echo json_encode($outArr); exit;
}

$mustUploadAvatar = 0;
if(empty($__UserInfo['picurl'])){
    $mustUploadAvatar = 1;
}

$uploadUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=upload&act=avatar&formhash=".FORMHASH;
$saveUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=myedit&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:myedit");