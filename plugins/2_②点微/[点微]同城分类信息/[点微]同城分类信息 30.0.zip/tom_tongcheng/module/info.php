<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(isset($_GET['xxid'])){
    $tongcheng_id = intval($_GET['xxid'])>0? intval($_GET['xxid']):0;
}else{
    $tongcheng_id = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
}

$tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);

if(!$tongchengInfo || $tongchengInfo['status'] != 1){
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tongcheng:404");
    tomoutput();
    exit;
}

if($tongchengInfo['shenhe_status'] != 1){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist&type=4");exit;
}

if($tongchengInfo['tczhaopin_id'] > 0){
    tomheader('location:'.$_G['siteurl'].'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$tongchengInfo['tczhaopin_id']);exit;
}else if($tongchengInfo['tczhaopin_resume_id'] > 0){
    tomheader('location:'.$_G['siteurl'].'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=resumeinfo&resume_id='.$tongchengInfo['tczhaopin_resume_id']);exit;
}else if($tongchengInfo['tcfangchan_id'] > 0){
    tomheader('location:'.$_G['siteurl'].'plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=info&tcfangchan_id='.$tongchengInfo['tcfangchan_id']);exit;
}else if($tongchengInfo['tcershou_goods_id'] > 0){
    tomheader('location:'.$_G['siteurl'].'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=goodsinfo&goods_id='.$tongchengInfo['tcershou_goods_id']);exit;
}else if($tongchengInfo['tcershou_needs_id'] > 0){
    tomheader('location:'.$_G['siteurl'].'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=needsinfo&needs_id='.$tongchengInfo['tcershou_needs_id']);exit;
}else if($tongchengInfo['tcfangchan_needs_id'] > 0){
    tomheader('location:'.$_G['siteurl'].'plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=needsinfo&needs_id='.$tongchengInfo['tcfangchan_needs_id']);exit;
}

$vipTequanPicurl = '';
if($__ShowTcyikatong == 1){
    $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($tongchengInfo['user_id']);
    if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
        $cartTypeInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($cardInfoTmp['card_type_id']);
        if(!empty($cartTypeInfoTmp['picurl'])){
            if(!preg_match('/^http/', $cartTypeInfoTmp['picurl']) ){
                if(strpos($cartTypeInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                    $vipTequanPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$cartTypeInfoTmp['picurl'];
                }else{
                    $vipTequanPicurl = $cartTypeInfoTmp['picurl'];
                }
            }else{
                $vipTequanPicurl = $cartTypeInfoTmp['picurl'];
            }
        }
    }
}

$open_edit_pinglun = 0;
if($tongchengInfo['user_id'] == $__UserInfo['id'] && $tongchengConfig['open_fbr_remove_pinglun'] == 1){
    $open_edit_pinglun = 1;
}else if($__UserInfo['groupid'] == 1 && $site_id == 1){
    $open_edit_pinglun = 1;
}else if($__UserInfo['groupid'] == 2 && $site_id == $__UserInfo['groupsiteid']){
    $open_edit_pinglun = 1;
}

$contentInfo = C::t('#tom_tongcheng#tom_tongcheng_content')->fetch_by_tongcheng_id($tongchengInfo['id']);
$showNewContent = 0;
$newContent = '';
if($contentInfo && $contentInfo['is_show'] == 1){
    $showNewContent = 1;
    $newContent = stripslashes($contentInfo['content']);
}

$content = contentFormat($tongchengInfo['content']);
$contentTmp = strip_tags($content);
$contentTmp = str_replace("\r\n","",$contentTmp);
$contentTmp = str_replace("\n","",$contentTmp);
$contentTmp = str_replace("\r","",$contentTmp);

$content = str_replace("\r\n","<br/>",$content);
$content = str_replace("\n","<br/>",$content);
$content = str_replace("\r","<br/>",$content);

$title  = cutstr($contentTmp,80,"...");
$desc   = cutstr($contentTmp,100,"...");
$haibaoContent = cutstr($contentTmp,300,"...");
$haibaoContent = str_replace("-","&nbsp;-&nbsp;",$haibaoContent);
$haibaoContent = preg_replace("/\d{7}/", '*****', $haibaoContent);
if(!empty($tongchengInfo['title'])){
    $title = $tongchengInfo['title'];
}

$haibao_txt_msg = '';
$haibao_txt_picurl = 'source/plugin/tom_tongcheng/images/haibao_type.png';
if(!empty($tongchengConfig['haibao_txt'])){
    list($haibao_txt_msg, $haibao_txt_picurl) = explode("|", $tongchengConfig['haibao_txt']);
}

$addressStr = "";
$areaNameTmp = '';
if(!empty($tongchengInfo['area_id'])){
    $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengInfo['area_id']);
    $areaNameTmp = $areaInfoTmp['name'];
}
$streetNameTmp = '';
if(!empty($tongchengInfo['street_id'])){
    $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengInfo['street_id']);
    $streetNameTmp = $streetInfoTmp['name'];
}
if(!empty($areaNameTmp)){
    $addressStr = $areaNameTmp." ".$streetNameTmp;
}

$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengInfo['user_id']); 
$modelInfo = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($tongchengInfo['model_id']);
$typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
$cateInfo = array();
if($tongchengInfo['cate_id'] > 0){
    $cateInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_by_id($tongchengInfo['cate_id']);
    if($cateInfoTmp){
        $cateInfo = $cateInfoTmp;
    }
}
$siteInfo = array('id'=>1,'name'=>$tongchengConfig['plugin_name']);
if($tongchengInfo['site_id'] > 1){
    $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tongchengInfo['site_id']);
}

$zhapian_msg = $tongchengConfig['zhapian_msg'];
if(!empty($typeInfo['zhapian_msg'])){
    $zhapian_msg = $typeInfo['zhapian_msg'];
}

$attrList = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY paixu ASC,id DESC ",0,50);
$tagList = C::t('#tom_tongcheng#tom_tongcheng_tag')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id DESC ",0,50);
$photoCount = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_count(" AND tongcheng_id={$tongchengInfo['id']} ");
$photoListTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id ASC ",0,50);
$photoList = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach ($photoListTmp as $kk => $vv){
        if($tongchengConfig['open_yun'] == 2 && !empty($vv['oss_picurl']) && $vv['oss_status'] == 1){
            $picurl = $vv['oss_picurl'];
        }else if($tongchengConfig['open_yun'] == 3 && !empty($vv['qiniu_picurl']) && $vv['qiniu_status'] == 1){
            $picurl = $vv['qiniu_picurl'];
        }else{
            if(!preg_match('/^http/', $vv['picurl']) ){
                if(strpos($vv['picurl'], 'source/plugin/tom_') === false){
                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                }else{
                    $picurl = $_G['siteurl'].$vv['picurl'];
                }
            }else{
                $picurl = $vv['picurl'];
            }
        }
        $photoList[$kk] = $picurl;
    }
}
$photoListStr = implode('|', $photoList);

$haibaoPicurlList = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach ($photoListTmp as $kk => $vv){
        if(!preg_match('/^http/', $vv['picurl']) ){
            if(strpos($vv['picurl'], 'source/plugin/tom_') === false){
                //$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                $picurl = 'data/attachment/tomwx/'.$vv['picurl'];
            }else{
                //$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$vv['picurl'];
                $picurl = $vv['picurl'];
            }
        }else{
            $picurl = $vv['picurl'];
        }
        $haibaoPicurlList[$kk] = $picurl;
    }
}

$modelWhereStr = " AND is_show=1 ";
if($site_id > 1){
    if(!empty($__SitesInfo['model_ids'])){
        $modelWhereStr.= " AND id IN({$__SitesInfo['model_ids']}) ";
    }
}else{
    $modelWhereStr.= " AND sites_show=0 ";
}
$modelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(" {$modelWhereStr} "," ORDER BY paixu ASC,id DESC ",0,50);
    
$modelList = array();
$i = 1;
$modelCount = 0;
if(is_array($modelListTmp) && !empty($modelListTmp)){
    foreach ($modelListTmp as $key => $value){
        $modelList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $modelList[$key]['picurl'] = $picurl;
        $modelList[$key]['i'] = $i;
        $i++;
        $modelCount++;
    }
}
$tcCount = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count(" AND user_id={$userInfo['id']} AND status=1 ");
if(!empty($tongchengConfig['open_click_add'])){
    $randArr = explode('|', $tongchengConfig['open_click_add']);
    if(!empty($randArr) && is_array($randArr)){
        $minRand = intval($randArr[0]);
        $maxRand = intval($randArr[1]);
        $randNum = mt_rand($minRand, $maxRand);
        if($randNum > 0){
            DB::query("UPDATE ".DB::table('tom_tongcheng')." SET clicks=clicks+{$randNum} WHERE id='$tongcheng_id' ", 'UNBUFFERED');
        }else{
            DB::query("UPDATE ".DB::table('tom_tongcheng')." SET clicks=clicks+1 WHERE id='$tongcheng_id' ", 'UNBUFFERED');
        }
    }
}else{
    DB::query("UPDATE ".DB::table('tom_tongcheng')." SET clicks=clicks+1 WHERE id='$tongcheng_id' ", 'UNBUFFERED');
}

$pinglunListTmp = C::t('#tom_tongcheng#tom_tongcheng_pinglun')->fetch_all_list(" AND tongcheng_id = {$tongchengInfo['id']} ", 'ORDER BY ping_time DESC,id DESC', 0, 5);
$pinglunList = array();
if(is_array($pinglunListTmp) && !empty($pinglunListTmp)){
    foreach($pinglunListTmp as $key => $value){
        
        $value['content'] = cutstr($value['content'], 260, '..');
        
        $pingUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $pinglunList[$key] = $value;
        $pinglunList[$key]['content'] = qqface_replace(dhtmlspecialchars($value['content']));
        $pinglunList[$key]['userInfo'] = $pingUserInfoTmp;
        if($value['touser_id'] > 0){
            $pinglunList[$key]['userInfo']['nickname'] = cutstr($pingUserInfoTmp['nickname'], 10, '');
            $pinglunList[$key]['touser_nickname'] = cutstr($value['touser_nickname'], 10, '');
        }
        $pinglunList[$key]['reply_list'] = '';
        $replyListTmp = C::t('#tom_tongcheng#tom_tongcheng_pinglun_reply')->fetch_all_list(" AND tongcheng_id = {$tongchengInfo['id']} AND ping_id = {$value['id']} ", "ORDER BY reply_time ASC,id ASC", 0, 1000);
        if(is_array($replyListTmp) && !empty($replyListTmp)){
            $pinglunList[$key]['reply_list'] .= '<div class="comment_reply_pinglun_box"  style="display:none;">';
            foreach($replyListTmp as $k => $v){
                if($tongchengInfo['user_id'] == $v['reply_user_id']){
                    $pinglunList[$key]['reply_list'].= '<div class="comment-item-content-text" id="comment-item-content-text_'.$v['id'].'"><span>'.$v['reply_user_nickname'].'&nbsp;<span class="floor_main">'.lang('plugin/tom_tongcheng', 'info_pinglun_floor_main').'</span>'.lang('plugin/tom_tongcheng','pinglun_hueifu_dian').'&nbsp;</span>'.qqface_replace(dhtmlspecialchars($v['content'])).'&nbsp;&nbsp;<span class="remove" onClick="removeReply('.$v['id'].');">'.lang('plugin/tom_tongcheng','info_comment_del').'</span></div>'; 
                }else{
                    $pinglunList[$key]['reply_list'].= '<div class="comment-item-content-text" id="comment-item-content-text_'.$v['id'].'"><span>'.$v['reply_user_nickname'].lang('plugin/tom_tongcheng','pinglun_hueifu_dian').'&nbsp;</span>'.qqface_replace(dhtmlspecialchars($v['content'])).'&nbsp;&nbsp;<span class="remove" onClick="removeReply('.$v['id'].');">'.lang('plugin/tom_tongcheng','info_comment_del').'</span></div>'; 
                }
            }
            $pinglunList[$key]['reply_list'] .= '</div>';
        }
    }
}
$must_phone_projectArr = unserialize($tongchengConfig['must_phone_project']);
$showMustPhoneBtn = 0;
if(array_search('2',$must_phone_projectArr) !== false && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=view&xxid=".$tongcheng_id;
if(strpos($userInfo['picurl'], 'data/attachment/tomwx') !== false){
    $shareLogo  = $_G['siteurl'].$userInfo['picurl'];
}else if(strpos($userInfo['picurl'], 'uc_server/') !== false){
    $shareLogo  = $_G['siteurl'].$userInfo['picurl'];
}else{
    $shareLogo  = $userInfo['picurl'];
}

if($typeInfo && !empty($typeInfo['share_logo'])){
    if(!preg_match('/^http/', $typeInfo['share_logo']) ){
        $typeInfo['share_logo'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$typeInfo['share_logo'];
    }
    $shareLogo = $typeInfo['share_logo'];
}

$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
if($__SitesInfo['id'] > 1){
    if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])){
        if(strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_') === FALSE){
            $kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
        }else{
            $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
        }
    }else{
        $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
    }
}

if(is_array($photoList) && !empty($photoList) && !empty($photoList[0])){
    $shareLogo = $photoList[0];
}

if(!empty($tongchengInfo['video_pic'])){
    $shareLogo = $tongchengInfo['video_pic'];
}

$isCollect = 0;
if($__UserInfo){
    $collectListTmp = C::t('#tom_tongcheng#tom_tongcheng_collect')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND tongcheng_id={$tongcheng_id} "," ORDER BY id DESC ",0,1);
    if(is_array($collectListTmp) && !empty($collectListTmp)){
        $isCollect = 1;
    }
}

if($__ShowTcshop == 1){
    $shopNum = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count("  AND status=1 AND user_id={$userInfo['id']} ");
    $ajaxLoadShopListUrl = "plugin.php?id=tom_tcshop:ajax&site={$site_id}&act=list&user_id={$userInfo['id']}&formhash=".$formhash;
}
$showDingwei = 0;
if($typeInfo['open_dingwei'] == 1 && $tongchengInfo['is_dingwei'] == 1){
    $showDingwei = 1;
    $juli = 0;
    if(!empty($longitude) && !empty($latitude) && !empty($tongchengInfo['longitude']) && !empty($tongchengInfo['latitude'])){
        $juli = tomGetDistance($longitude, $latitude, $tongchengInfo['longitude'], $tongchengInfo['latitude']);
    }
}

$lqHongbaoStatus = 0;
$tchongbaoInfo = array();
$tchongbaoLogCount = 0;
$tchongbaoLogList = array();
$openLocaltionDistance = 0;
if($__ShowTchongbao == 1){
    $tchongbaoInfoTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(" AND tongcheng_id = {$tongcheng_id} AND pay_status = 2 AND only_show = 1 ", 'ORDER BY add_time DESC,id DESC', 0, 1);
    if(is_array($tchongbaoInfoTmp) && !empty($tchongbaoInfoTmp[0])){
        $tchongbaoInfo = $tchongbaoInfoTmp[0];
        
        $shareUrl   = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=hbao&xxid=".$tongcheng_id;
        
        $tchongbaoLogCount = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_count(" AND hongbao_id = {$tchongbaoInfo['id']} ");
        $tchongbaoLogListTmp = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_list(" AND hongbao_id = {$tchongbaoInfo['id']} ", 'ORDER BY log_time DESC,id DESC', 0, 10);
        if(is_array($tchongbaoLogListTmp) && !empty($tchongbaoLogListTmp[0])){
            foreach($tchongbaoLogListTmp as $key => $value){
                $tchongbaoLogList[$key] = $value;
            }
        }
        
        if($tchongbaoLogCount >= $tchongbaoInfo['hb_count'] || $tchongbaoInfo['money'] <= 0){
            $updateData = array();
            $updateData['status'] = 2;
            C::t('#tom_tchongbao#tom_tchongbao')->update($tchongbaoInfo['id'], $updateData);
            $tchongbaoInfo['status'] = 2;
        }
        
        if($__UserInfo){
            $hongbaoLogInfo = C::t('#tom_tchongbao#tom_tchongbao_qiang_log')->fetch_all_list(" AND hongbao_id = {$tchongbaoInfo['id']} AND user_id = {$__UserInfo['id']} ", 'ORDER BY id DESC', 0, 1);
            if(is_array($hongbaoLogInfo) && !empty($hongbaoLogInfo[0])){
                $lqHongbaoStatus = 1;
            }
        }
        
        if($__UserInfo['hongbao_tz'] == 0 && $__UserInfo['hongbao_tz_first'] != 1){
            $updateData = array();
            $updateData['hongbao_tz'] = 1;
            $updateData['hongbao_tz_first'] = 1;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'], $updateData);
        }

        if($tchongbaoConfig['open_hb_position'] == 1){
            if(strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') !== false){
                if(!empty($tchongbaoConfig['baidu_js_ak'])){
                    $openLocaltionDistance = 1;
                }else{
                    $openLocaltionDistance = 3;
                }
            }else{
                $openLocaltionDistance = 2;
            }
            
            $hongbaoLocationInfo = C::t('#tom_tchongbao#tom_tchongbao_location')->fetch_by_user_id($__UserInfo['id']);
            $hongbaoLocationStatus = 0;
            if(is_array($hongbaoLocationInfo) && !empty($hongbaoLocationInfo)){
                $overTime = ($tchongbaoConfig['hongbao_update_location_num'] * 86400) + $hongbaoLocationInfo['last_time'];
                if($overTime > TIMESTAMP){
                    if($hongbaoLocationInfo['location_status'] == 1){
                        $hongbaoLocationStatus = 1;
                    }else{
                        $hongbaoLocationStatus = 2;
                    }
                }
            }
        }
        
        $show_hongbao_button = 1;
        if(!$__UserInfo){
            $show_hongbao_button = 0;
        }else{
            if($__IsWeixin != 1 && $tchongbaoConfig['hb_lq_type'] != 1){
                $show_hongbao_button = 0;
            }
        }
    }
}

$companyRenzhengStatus = $personalRenzhengStatus = $depositStatus = 0;
if($__ShowTcrenzheng == 1){
    $companyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($userInfo['id']);
    if(is_array($companyInfoTmp) && $companyInfoTmp['shenhe_status'] == 1){
        $companyRenzhengStatus = 1;
    }
    
    $personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_user_id($userInfo['id']);
    if(is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1){
        $personalRenzhengStatus = 1;
    }
    
    $depositInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_by_user_id($userInfo['id']);
    if(is_array($depositInfoTmp) && $depositInfoTmp['order_status'] == 2){
        $depositStatus = 1;
    }
}

$ajaxHongbaoUrl = 'plugin.php?id=tom_tchongbao:ajax&formhash='.FORMHASH;
$ajaxDistanceHongbaoUrl = 'plugin.php?id=tom_tchongbao:ajax&act=distance&site='.$site_id.'&formhash='.FORMHASH;
$myMoneyUrl= 'plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=money';
$hongbaoLogListUrl= 'plugin.php?id=tom_tchongbao&mod=loglist&site='.$site_id.'&hongbao_id='.$tchongbaoInfo['id'];
$hongbaoIndexUrl = 'plugin.php?id=tom_tchongbao&mod=index&site='.$site_id;

$infoShareTitle = str_replace("{TITLE}",$title, $typeInfo['info_share_title']);
$infoShareDesc = str_replace("{TITLE}",$title, $typeInfo['info_share_desc']);
$infoShareTitle = str_replace("{SITENAME}",$__SitesInfo['name'], $infoShareTitle);
$infoShareDesc = str_replace("{SITENAME}",$__SitesInfo['name'], $infoShareDesc);
if(!empty($cateInfo)){
    $infoShareTitle = str_replace("{CATENAME}",$cateInfo['name'], $infoShareTitle);
    $infoShareDesc = str_replace("{CATENAME}",$cateInfo['name'], $infoShareDesc);
}
$infoShareTitle = str_replace("{AREANAME}",$areaNameTmp, $infoShareTitle);
$infoShareTitle = str_replace("{STREETNAME}",$streetNameTmp, $infoShareTitle);
if(is_array($attrList) && !empty($attrList)){
    foreach ($attrList as $key => $value){
        if(!empty($value['time_value'])){
            $value['value'] = dgmdate($value['time_value'],"m-d H:i",$tomSysOffset);
        }
        $value['value'] = str_replace(" ",'|', $value['value']);
        $infoShareTitle = str_replace("{ATTR".$value['attr_id']."}",$value['value'], $infoShareTitle);
        $infoShareDesc = str_replace("{ATTR".$value['attr_id']."}",$value['value'], $infoShareDesc);
    }
}
$infoShareTitle = str_replace(" ",'', $infoShareTitle);
$infoShareDesc = str_replace(" ",'', $infoShareDesc);
$infoShareDesc = str_replace("&nbsp;",'', $infoShareDesc);
$infoShareDesc = str_replace("{AREANAME}",$areaNameTmp, $infoShareDesc);
$infoShareDesc = str_replace("{STREETNAME}",$streetNameTmp, $infoShareDesc);
$shareTitle = lang("plugin/tom_tongcheng", "kuohao_left")."{$typeInfo['name']}".lang("plugin/tom_tongcheng", "kuohao_right")."{$title}-{$__SitesInfo['name']}";
$shareDesc = $desc;
if(!empty($infoShareTitle)){
    $shareTitle = $infoShareTitle;
}
if(!empty($infoShareDesc)){
    $shareDesc = $infoShareDesc;
}
if($tchongbaoInfo && $tchongbaoInfo['status']==1 && $tchongbaoConfig && isset($tchongbaoConfig['hongbao_tongcheng_prefix'])){
    $shareTitle = $tchongbaoConfig['hongbao_tongcheng_prefix'].$shareTitle;
}


$zanCount = C::t('#tom_tongcheng#tom_tongcheng_collect')->fetch_all_count(" AND tongcheng_id = {$tongchengInfo['id']} ");
$zanListTmp = C::t('#tom_tongcheng#tom_tongcheng_collect')->fetch_all_list(" AND tongcheng_id = {$tongchengInfo['id']} ", 'ORDER BY id DESC', 0 ,20);
$zanList = array();
if(is_array($zanListTmp) && !empty($zanListTmp)){
    foreach($zanListTmp as $key => $value){
        $zanList[$key] = $value;
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $zanList[$key]['userInfo'] = $userInfoTmp;
    }
}

$focuspicListTmp = C::t('#tom_tongcheng#tom_tongcheng_focuspic')->fetch_all_list(" AND site_id={$site_id} AND type_id=3 AND model_id={$tongchengInfo['model_id']} "," ORDER BY fsort ASC,id DESC ",0,10);
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){}else{
    $focuspicListTmp = C::t('#tom_tongcheng#tom_tongcheng_focuspic')->fetch_all_list(" AND site_id=1 AND type_id=3 AND model_id={$tongchengInfo['model_id']} "," ORDER BY fsort ASC,id DESC ",0,10);
}
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){}else{
    $focuspicListTmp = C::t('#tom_tongcheng#tom_tongcheng_focuspic')->fetch_all_list(" AND site_id={$site_id} AND type_id=3 AND model_id=0 "," ORDER BY fsort ASC,id DESC ",0,10);
    if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){}else{
        $focuspicListTmp = C::t('#tom_tongcheng#tom_tongcheng_focuspic')->fetch_all_list(" AND site_id=1 AND type_id=3 AND model_id=0 "," ORDER BY fsort ASC,id DESC ",0,10);
    }
}
$focuspicList = array();
foreach ($focuspicListTmp as $key => $value) {
    $focuspicList[$key] = $value;    
    if(!preg_match('/^http/', $value['picurl']) ){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
    }else{
        $picurl = $value['picurl'];
    }
    $focuspicList[$key]['picurl'] = $picurl;
    $focuspicList[$key]['link'] = str_replace("{site}",$site_id, $focuspicList[$key]['link']);
}

$messageUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=message&act=create&tongcheng_id=".$tongchengInfo['id'].'&to_user_id='.$userInfo['id'].'&formhash='.FORMHASH;
$tousuUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=tousu&tongcheng_id=".$tongchengInfo['id'];
$addPinglunUrl = "plugin.php?id=tom_tongcheng:ajax&act=pinglun&formhash=".FORMHASH;
$showPinglunUrl = "plugin.php?id=tom_tongcheng:ajax&act=loadPinglun&tongcheng_id={$tongchengInfo['id']}&formhash=".FORMHASH;
$removePinglunUrl = "plugin.php?id=tom_tongcheng:ajax&act=removePinglun&tongcheng_id={$tongchengInfo['id']}&formhash=".FORMHASH;
$removeReplyUrl = "plugin.php?id=tom_tongcheng:ajax&act=removeReplyPinglun&tongcheng_id={$tongchengInfo['id']}&formhash=".FORMHASH;
$ajaxZhuanfaUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=zhuanfa&tongcheng_id='.$tongcheng_id.'&formhash='.FORMHASH;


if($__ShowTcyikatong == 1 && $tcyikatongConfig['open_free_tel'] == 1 && $__UserInfo['id'] > 0){
    $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($__UserInfo['id']);
    if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
        $typeInfo['open_tel_price'] = 0;
    }
}

$payTelUrl = "plugin.php?id=tom_tongcheng:pay&site={$site_id}&act=tel&formhash=".$formhash;
$ajaxTelUrl = "plugin.php?id=tom_tongcheng:ajax&site={$site_id}&act=get_tel&&formhash=".$formhash;
$showBuyTelBtn = 0;
if($typeInfo['open_tel_price'] == 1 && !empty($tongchengInfo['tel'])){
    if($__UserInfo['id'] > 0){
        $telListTmp = C::t('#tom_tongcheng#tom_tongcheng_tel')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND type=1 AND object_id={$tongchengInfo['id']}  ","ORDER BY id DESC",0,1);
        if(is_array($telListTmp) && !empty($telListTmp)){
        }else if($__UserInfo['editor'] == 1 || $__UserInfo['id'] == $tongchengInfo['user_id']){
            $shareTitle = preg_replace("/\d{7}/", '*****', $shareTitle);
            $shareDesc = preg_replace("/\d{7}/", '*****', $shareDesc);
        }else{
            $getTelScore = $tongchengConfig['pay_score_yuan']*$typeInfo['tel_price'];
            $getTelScore = ceil($getTelScore);
            if($getTelScore <= $__UserInfo['score']){
                $showBuyTelBtn = 3;
            }else{
                $sites_priceTmp = C::t('#tom_tongcheng#tom_tongcheng_sites_price')->fetch_all_list(" AND site_id={$tongchengInfo['site_id']} AND type_id={$tongchengInfo['type_id']} "," ORDER BY id DESC ",0,1);
                if(is_array($sites_priceTmp) && !empty($sites_priceTmp) && $sites_priceTmp[0]['id']>0 && $tongchengInfo['site_id'] > 1){
                    $typeInfo['tel_price'] = $sites_priceTmp[0]['tel_price'];
                }
                $showBuyTelBtn = 1;
            }
            $tongchengInfo['xm'] = cutstr($tongchengInfo['xm'], 3, '*******');
            $tongchengInfo['tel'] = substr($tongchengInfo['tel'], 0, 3)."*******";
            $title = preg_replace("/\d{7}/", '*****', $title);
            $content = preg_replace("/\d{7}/", '*****', $content);
            $shareTitle = preg_replace("/\d{7}/", '*****', $shareTitle);
            $shareDesc = preg_replace("/\d{7}/", '*****', $shareDesc);
            //$newContent = preg_replace("/\d{7}/", '*****', $newContent);
        }
    }else{
        $showBuyTelBtn = 2;
        $tongchengInfo['xm'] = cutstr($tongchengInfo['xm'], 3, '*******');
        $tongchengInfo['tel'] = substr($tongchengInfo['tel'], 0, 3)."*******";
        $title = preg_replace("/\d{7}/", '*****', $title);
        $content = preg_replace("/\d{7}/", '*****', $content);
        $shareTitle = preg_replace("/\d{7}/", '*****', $shareTitle);
        $shareDesc = preg_replace("/\d{7}/", '*****', $shareDesc);
        //$newContent = preg_replace("/\d{7}/", '*****', $newContent);
    }
}

$tcqianggouInfo = array();
if($typeInfo['open_qianggou'] == 1 && $tongchengInfo['tcqianggou_goods_id'] > 0){
    $tcqianggouInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_list(" AND status=1 AND shenhe_status=1 AND type_id=1 AND id={$tongchengInfo['tcqianggou_goods_id']} AND qiang_status IN(1,2)"," ORDER BY id DESC ",0,1);
    if(is_array($tcqianggouInfoTmp) && !empty($tcqianggouInfoTmp[0])){
        $tcqianggouInfo = $tcqianggouInfoTmp[0];
        
        if(!preg_match('/^http/', $tcqianggouInfo['picurl']) ){
            if(strpos($tcqianggouInfo['picurl'], 'source/plugin/tom_') === FALSE){
                $tcqianggouInfo['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcqianggouInfo['picurl'];
            }
        }
    }
}
$tcqianggouCouponInfo = array();
if($typeInfo['open_qianggou_coupon'] == 1 && $tongchengInfo['tcqianggou_coupon_id'] > 0){
    $tcqianggouCouponInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_list(" AND status=1 AND shenhe_status=1 AND type_id IN(2,3,4) AND id={$tongchengInfo['tcqianggou_coupon_id']} AND qiang_status IN(1,2)"," ORDER BY id DESC ",0,1);
    if(is_array($tcqianggouCouponInfoTmp) && !empty($tcqianggouCouponInfoTmp[0])){
        $tcqianggouCouponInfo = $tcqianggouCouponInfoTmp[0];
        
        if(!preg_match('/^http/', $tcqianggouCouponInfo['picurl']) ){
            if(strpos($tcqianggouCouponInfo['picurl'], 'source/plugin/tom_') === FALSE){
                $tcqianggouCouponInfo['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcqianggouCouponInfo['picurl'];
            }
        }
    }
}
$tcptuanInfo = array();
if($typeInfo['open_ptuan'] == 1 && $tongchengInfo['tcptuan_goods_id'] > 0){
    $tcptuanInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_like_list(" AND ptuan_status = 1 AND status=1 AND shenhe_status=1 AND id={$tongchengInfo['tcptuan_goods_id']} "," ORDER BY id DESC ",0,1);
    if(is_array($tcptuanInfoTmp) && !empty($tcptuanInfoTmp[0])){
        $tcptuanInfo = $tcptuanInfoTmp[0];
        
        if(!preg_match('/^http/', $tcptuanInfo['picurl']) ){
            if(strpos($tcptuanInfo['picurl'], 'source/plugin/tom_') === FALSE){
                $tcptuanInfo['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcptuanInfo['picurl'];
            }
        }
    }
}
$tcmallInfo = array();
if($typeInfo['open_mall'] == 1 && $tongchengInfo['tcmall_goods_id'] > 0){
    $tcmallInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list("  AND status=1 AND shenhe_status=1 AND id={$tongchengInfo['tcmall_goods_id']} "," ORDER BY id DESC ",0,1);
    if(is_array($tcmallInfoTmp) && !empty($tcmallInfoTmp[0])){
        $tcmallInfo = $tcmallInfoTmp[0];
        
        if(!preg_match('/^http/', $tcmallInfo['picurl']) ){
            if(strpos($tcmallInfo['picurl'], 'source/plugin/tom_') === FALSE){
                $tcmallInfo['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcmallInfo['picurl'];
            }
        }
    }
}
$tcdaojiaInfo = array();
if($typeInfo['open_daojia'] == 1 && $tongchengInfo['tcdaojia_goods_id'] > 0){
    $tcdaojiaInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND id={$tongchengInfo['tcdaojia_goods_id']} "," ORDER BY id DESC ",0,1);
    if(is_array($tcdaojiaInfoTmp) && !empty($tcdaojiaInfoTmp[0])){
        $tcdaojiaInfo = $tcdaojiaInfoTmp[0];
        
        $photoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND goods_id = {$tcdaojiaInfo['id']} AND type = 1 "," ORDER BY id ASC ",0,1);
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        
            if(!preg_match('/^http/', $picurlTmp) ){
                if(strpos($picurlTmp, 'source/plugin/tom_') === FALSE){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$picurlTmp;
                }
            }
        }
        
        $tcdaojiaInfo['picurl'] = $picurlTmp;
    }
}

if($__ShowTchehuoren == 1){
    $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
    if($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1){
        $shareUrl   = $shareUrl."&tjid={$tchehuorenInfoTmp['id']}";
    }
}

$haibaoQrcodeImg = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($shareUrl);

$open_wx_map = 0;
if($__IsWeixin == 1){
    $open_wx_map = 1;
}
$baiduMapToName = diconv($title, CHARSET, 'utf-8');
$baiduMapToName = urlencode($baiduMapToName);
$baiduMapUrl = "https://api.map.baidu.com/marker?location={$tongchengInfo['latitude']},{$tongchengInfo['longitude']}&title={$baiduMapToName}&content=&output=html";

if($__ShowTcsign == 1){
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/renwu/fenlei.php';
}

$show_share_refresh_box = $show_share_top_box = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/share.php')){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/share.php';
}

$ajaxTuiDoTzUrl = '';
if($__ShowTchehuoren == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tui_do.php')){
    include DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tui_do.php';
}

$__TongchengHost =  '';
if($__ShowTchongbao == 1){
    $tchongbaoConfig['tongcheng_hosts'] = trim($tchongbaoConfig['tongcheng_hosts']);
    $tchongbaoConfig['hongbao_hosts']      = trim($tchongbaoConfig['hongbao_hosts']);
    if($tchongbaoConfig['open_only_hosts'] == 1 && !empty($tchongbaoConfig['tongcheng_hosts']) && !empty($tchongbaoConfig['hongbao_hosts'])){
        if(strpos($_G['siteurl'],$tchongbaoConfig['tongcheng_hosts']) === FALSE && strpos($_G['siteurl'],$tchongbaoConfig['hongbao_hosts']) !== FALSE){
            $__TongchengHost = str_replace($tchongbaoConfig['hongbao_hosts'], $tchongbaoConfig['tongcheng_hosts'], $_G['siteurl']);
            if($tchongbaoConfig['must_http'] == 1){
                if(strpos($__TongchengHost,'https') === FALSE){
                    $__TongchengHost = str_replace("http", "https", $__TongchengHost);
                }
            }
        }
    }
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:info");