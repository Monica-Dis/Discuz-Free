<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$tcshop_id  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$model_id   = intval($_GET['model_id'])>0? intval($_GET['model_id']):0;
$model_ids  = isset($_GET['model_ids'])? daddslashes($_GET['model_ids']):'';
$type_id    = intval($_GET['type_id'])>0? intval($_GET['type_id']):0;
$cate_id    = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$city_id    = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
$area_id    = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id  = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$keyword    = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):6;
$ordertype  = !empty($_GET['ordertype'])? addslashes($_GET['ordertype']):'default';

$modelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list("", 'ORDER BY id DESC', 0, 1000);
$modelList = $modelShowIdsArr = array();
if(is_array($modelListTmp) && !empty($modelListTmp)){
    foreach($modelListTmp as $key => $value){
        $modelList[$value['id']] = $value;
        if($value['is_show'] == 1){
            $modelShowIdsArr[] = $value['id'];
        }
    }
}

$typeListTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_all_list("", 'ORDER BY id DESC', 0, 1000);
$typeList = array();
if(is_array($typeListTmp) && !empty($typeListTmp)){
    foreach($typeListTmp as $key => $value){
        $typeList[$value['id']] = $value;
    }
}

$template_type = $tongchengSetting['template_type'];
if($model_id > 0){
    if(isset($modelList[$model_id]['template_type']) && !empty($modelList[$model_id]['template_type'])){
        $template_type = $modelList[$model_id]['template_type'];
    }
}

if($template_type == 'tuwenlist'){
    $pagesize = 10;
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$nearby = 0;
if($model_id == 999999){
    $model_id = 0;
    $nearby = 1;
}

$whereStr = ' AND status=1 AND shenhe_status=1 ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($tcshop_id)){
    $whereStr.= " AND tcshop_id={$tcshop_id} ";
}
if(!empty($model_id)){
    $whereStr.= " AND model_id={$model_id} ";
}else if(!empty($model_ids)){
    $model_ids_arr = explode('|', $model_ids);
    $modelIdsArr = array();
    if(is_array($model_ids_arr) && !empty($model_ids_arr)){
        foreach ($model_ids_arr as $key => $value){
            $value = (int)$value;
            if(!empty($value)){
                $modelIdsArr[] = $value;
            }
        }
    }
    if(!empty($modelIdsArr)){
        $whereStr.= " AND model_id IN(".  implode(',', $modelIdsArr).") ";
    }
}else if(!empty($modelShowIdsArr)){
    $whereStr.= " AND model_id IN(".  implode(',', $modelShowIdsArr).") ";
}else{
    $whereStr.= " AND model_id = 999999999 ";
}
if(!empty($type_id)){
    $whereStr.= " AND type_id={$type_id} ";
}
if(!empty($cate_id)){
    $whereStr.= " AND cate_id={$cate_id} ";
}
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}
if(!empty($city_id)){
    $whereStr.= " AND city_id={$city_id} ";
}
if(!empty($area_id)){
    $whereStr.= " AND area_id={$area_id} ";
}
if(!empty($street_id)){
    $whereStr.= " AND street_id={$street_id} ";
}

if($tongchengConfig['open_finish_paixu'] == 1){
    if($tongchengConfig['top_paixu_type'] == 2){
        $orderStr = " ORDER BY topstatus DESC,toptime DESC,finish ASC, refresh_time DESC,id DESC ";
    }else if($tongchengConfig['top_paixu_type'] == 3){
        $orderStr = " ORDER BY topstatus DESC,finish ASC,refresh_time DESC,id DESC ";
    }else{
        $orderStr = " ORDER BY topstatus DESC,toprand DESC,finish ASC, refresh_time DESC,id DESC ";
    }
}else{
    if($tongchengConfig['top_paixu_type'] == 2){
        $orderStr = " ORDER BY topstatus DESC,toptime DESC, refresh_time DESC,id DESC ";
    }else if($tongchengConfig['top_paixu_type'] == 3){
        $orderStr = " ORDER BY topstatus DESC,refresh_time DESC,id DESC ";
    }else{
        $orderStr = " ORDER BY topstatus DESC,toprand DESC, refresh_time DESC,id DESC ";
    }
}

if($ordertype == 'new'){
    $orderStr = " ORDER BY refresh_time DESC,id DESC ";
}else if($ordertype == 'hot'){
    $orderStr = " ORDER BY clicks DESC,id DESC ";
}else if($ordertype == 'nearby'){
    $nearby = 1;
}

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
if($nearby == 1 && !empty($latitude) && !empty($longitude)){
    $tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_nearby_list($whereStr,$start,$pagesize,$latitude,$longitude);
}else{
    $tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list($whereStr,$orderStr,$start,$pagesize,$keyword);
}

$tongchengList = $userIdsArr = $userFabuIdsArr = $siteIdsArr = $cateIdsArr = $districtIdsArr = $tongchengIdsArr = array();
$tcqianggouGoodsIdsArr = $tcqianggouCouponIdsArr = $tcptuanGoodsIdsArr = $tcshopIdsArr = $tcmallGoodsIdsArr = $tcdaojiaGoodsIdsArr = array();
$clickZhaopinIdsArr = $clickZhaopinResumeIdsArr = $clickFangchanIdsArr = $clickErshouIdsArr = $clickTongchengIdsArr = $clickErshouNeedsIdsArr = $clickFangchanNeesdIdsArr = array();
if(is_array($tongchengListTmp) && !empty($tongchengListTmp)){
    foreach ($tongchengListTmp as $key => $value) {

        $modelInfoTmp = $modelList[$value['model_id']];
        $typeInfoTmp  = $typeList[$value['type_id']];

        if($value['finish'] == 0 && $value['topstatus'] == 0 && $typeInfoTmp['over_time_attr_id'] > 0 && $typeInfoTmp['over_time_do'] > 0){
            $tongchengAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id={$value['id']} AND attr_id={$typeInfoTmp['over_time_attr_id']} "," ORDER BY id DESC ",0,1);
            if(is_array($tongchengAttrInfoTmp) && !empty($tongchengAttrInfoTmp) && $tongchengAttrInfoTmp[0] && $tongchengAttrInfoTmp[0]['time_value'] > 0){
                if($tongchengAttrInfoTmp[0]['time_value'] < TIMESTAMP){
                    if($typeInfoTmp['over_time_do'] == 1){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2,finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($typeInfoTmp['over_time_do'] == 2){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }
                }
            }
        }

        if($typeInfoTmp['jifei_type'] == 2 && $value['over_days'] > 0){
            if($value['topstatus'] == 0 && $value['finish'] == 0){
                if($value['over_time'] < TIMESTAMP){
                    if($tongchengConfig['over_time_do'] == 1){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($tongchengConfig['over_time_do'] == 2){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2,finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($tongchengConfig['over_time_do'] == 4){
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }
                }
            }
        }else{
            if($value['topstatus'] == 0 && $value['finish'] == 0 && $tongchengConfig['over_time_limit'] > 0 && $typeInfoTmp['over_time_attr_id'] == 0 ){
                if(($value['refresh_time']+$tongchengConfig['over_time_limit']*86400) < TIMESTAMP){
                    if($tongchengConfig['over_time_do'] == 1){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($tongchengConfig['over_time_do'] == 2){
                        $value['finish'] = 1;
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2,finish=1 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }else if($tongchengConfig['over_time_do'] == 4){
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }
                }
            }
        }
        
        $tongchengIdsArr[]      = $value['id'];
        $userFabuIdsArr[]       = $value['user_id'];
        $userIdsArr[]           = $value['user_id'];
        $tcshopIdsArr[]         = $value['tcshop_id'];

        if($value['site_id'] > 1){
            $siteIdsArr[] = $value['site_id'];
        }
        if($value['cate_id'] > 0){
            $cateIdsArr[] = $value['cate_id'];
        }
        if(!empty($value['area_id'])){
            $districtIdsArr[] = $value['area_id'];
        }
        if(!empty($value['street_id'])){
            $districtIdsArr[] = $value['street_id'];
        }

        if($typeInfoTmp['open_qianggou'] == 1 && $value['tcqianggou_goods_id'] > 0){
            $tcqianggouGoodsIdsArr[]    = $value['tcqianggou_goods_id'];
        }else{
            $value['tcqianggou_goods_id'] = 0;
        }
        if($typeInfoTmp['open_qianggou_coupon'] == 1 && $value['tcqianggou_coupon_id'] > 0){
            $tcqianggouCouponIdsArr[]   = $value['tcqianggou_coupon_id'];
        }else{
            $value['tcqianggou_coupon_id'] = 0;
        }
        if($typeInfoTmp['open_ptuan'] == 1 && $value['tcptuan_goods_id'] > 0){
            $tcptuanGoodsIdsArr[]       = $value['tcptuan_goods_id'];
        }else{
            $value['tcptuan_goods_id'] = 0;
        }
        if($typeInfoTmp['open_mall'] == 1 && $value['tcmall_goods_id'] > 0){
            $tcmallGoodsIdsArr[]        = $value['tcmall_goods_id'];
        }else{
            $value['tcmall_goods_id'] = 0;
        }
        if($typeInfoTmp['open_daojia'] == 1 && $value['tcdaojia_goods_id'] > 0){
            $tcdaojiaGoodsIdsArr[]      = $value['tcdaojia_goods_id'];
        }else{
            $value['tcdaojia_goods_id'] = 0;
        }
        
        if($tongchengConfig['open_load_list_clicks'] == 1){
            if($value['tczhaopin_id'] > 0 && $__ShowTczhaopin == 1){
                $clickZhaopinIdsArr[] = $value['tczhaopin_id'];
            }else if($value['tczhaopin_resume_id'] > 0 && $__ShowTczhaopin == 1){
                $clickZhaopinResumeIdsArr[] = $value['tczhaopin_resume_id'];
            }else if($value['tcfangchan_id'] > 0 && $__ShowFangchan == 1){
                $clickFangchanIdsArr[] = $value['tcfangchan_id'];
            }else if($value['tcershou_goods_id'] > 0 && $__ShowTcershou == 1){
                $clickErshouIdsArr[] = $value['tcershou_goods_id'];
            }else if($value['tcershou_needs_id'] > 0 && $__ShowTcershou == 1){
                $clickErshouNeedsIdsArr[] = $value['tcershou_needs_id'];
            }else if($value['tcfangchan_needs_id'] > 0 && $__ShowFangchan == 1){
                $clickFangchanNeesdIdsArr[] = $value['tcfangchan_needs_id'];
            }else{
                $clickTongchengIdsArr[] = $value['id'];
            }
        }

        if(!preg_match('/^http/', $value['video_pic']) ){
            if(strpos($value['video_pic'], 'source/plugin/tom_') === false){
                $videoPicTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['video_pic'];
            }else{
                $videoPicTmp = $_G['siteurl'].$value['video_pic'];
            }
        }else{
            $videoPicTmp = $value['video_pic'];
        }

        $pinglunCount = C::t('#tom_tongcheng#tom_tongcheng_pinglun')->fetch_all_count(" AND tongcheng_id = {$value['id']} ");
        $pinglunListTmpTmp = C::t('#tom_tongcheng#tom_tongcheng_pinglun')->fetch_all_list(" AND tongcheng_id = {$value['id']} ", 'ORDER BY ping_time DESC,id DESC', 0, 5);
        $pinglunListTmp = array();
        if(is_array($pinglunListTmpTmp) && !empty($pinglunListTmpTmp)){
            foreach($pinglunListTmpTmp as $k => $v){
                $userIdsArr[] = $v['user_id'];
                $pinglunListTmp[$k] = $v;
            }
        }
        
        $collectListTmp = array();
        if($value['collect'] > 0){
            $collectListTmpTmp = C::t('#tom_tongcheng#tom_tongcheng_collect')->fetch_all_list(" AND tongcheng_id={$value['id']} ", 'ORDER BY id DESC', 0, 5);
            if(is_array($collectListTmpTmp) && !empty($collectListTmpTmp)){
                foreach($collectListTmpTmp as $k => $v){
                    $userIdsArr[] = $v['user_id'];
                    $collectListTmp[$k] = $v;
                }
            }
        }
        
        $siteInfoTmp = array('id'=>1,'name'=>$tongchengConfig['plugin_name']);

        $tongchengList[$key]                            = $value;
        $tongchengList[$key]['content']                 = contentFormat($value['content']);
        $tongchengList[$key]['collectList']             = $collectListTmp;
        $tongchengList[$key]['video_pic']               = $videoPicTmp;
        $tongchengList[$key]['modelInfo']               = $modelInfoTmp;
        $tongchengList[$key]['typeInfo']                = $typeInfoTmp;
        $tongchengList[$key]['siteInfo']                = $siteInfoTmp;
        $tongchengList[$key]['pinglunList']             = $pinglunListTmp;
        $tongchengList[$key]['pinglunCount']            = $pinglunCount;
        
    }
}else{
    
    $outStr = '205';
    echo json_encode($outStr); exit;
    
}

$userList = array();
$userIdsArr = array_unique($userIdsArr);
$countTmp = count($userIdsArr);
$userIdsStr = implode(',', $userIdsArr);
$userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN ({$userIdsStr}) ", 'ORDER BY id DESC', 0, $countTmp);
if(is_array($userListTmp) && !empty($userListTmp)){
    foreach($userListTmp as $key => $value){
        $userList[$value['id']] = $value;
    }
}

$userFabuIdsArr = array_unique($userFabuIdsArr);
$countTmp = count($userFabuIdsArr);
$userFabuIdsStr = implode(',', $userFabuIdsArr);
$vipPicurlList = $companyList = $personalList = $depositList = array();
if($__ShowTcyikatong == 1){
    $cardListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_all_list(" AND user_id IN ({$userFabuIdsStr}) AND status = 1 ", 'ORDER BY id DESC', 0, $countTmp);
    $cardUserIdsArr = array();
    if(is_array($cardListTmp) && !empty($cardListTmp)){
        foreach ($cardListTmp as $key => $value){
            $cardUserIdsArr[$value['card_type_id']] = $value['user_id'];
        }
    }
    if(!empty($cardUserIdsArr)){
        $cardTypeIdsArr = array_keys($cardUserIdsArr);
        $cardTypeIdsStr = implode(',', $cardTypeIdsArr);
        $cartTypeListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_all_list(" AND id IN ({$cardTypeIdsStr})", 'ORDER BY id DESC', 0, 10);
        if(is_array($cartTypeListTmp) && !empty($cartTypeListTmp)){
            foreach ($cartTypeListTmp as $key => $value){
                $vipPicurlTmp = '';
                if(!empty($value['picurl'])){
                    if(!preg_match('/^http/', $value['picurl']) ){
                        if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                            $vipPicurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                        }else{
                            $vipPicurlTmp = $value['picurl'];
                        }
                    }else{
                        $vipPicurlTmp = $value['picurl'];
                    }
                }
                $vipPicurlList[$cardUserIdsArr[$value['id']]] = $vipPicurlTmp;
            }
        }
    }
}
if($__ShowTcrenzheng == 1){
    $companyListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list("AND user_id IN ({$userFabuIdsStr})",'ORDER BY id DESC', 0, $countTmp);
    if(is_array($companyListTmp) && !empty($companyListTmp)){
        foreach($companyListTmp as $key => $value){
            if($value['shenhe_status'] == 1){
                $companyList[$value['user_id']] = 1;
            }
        }
    }
    $personalListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_all_list("AND user_id IN ({$userFabuIdsStr})",'ORDER BY id DESC', 0, $countTmp);
    if(is_array($personalListTmp) && !empty($personalListTmp)){
        foreach($personalListTmp as $key => $value){
            if($value['shenhe_status'] == 1){
                $personalList[$value['user_id']] = 1;
            }
        }
    }
    $depositListTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_all_list("AND user_id IN ({$userFabuIdsStr})",'ORDER BY id DESC', 0, $countTmp);
    if(is_array($depositListTmp) && !empty($depositListTmp)){
        foreach($depositListTmp as $key => $value){
            if($value['order_status'] == 2){
                $depositList[$value['user_id']] = 1;
            }
        }
    }
}

$sitesList = array();
if(!empty($siteIdsArr)){
    $siteIdsArr = array_unique($siteIdsArr);
    $countTmp = count($siteIdsArr);
    $siteIdsStr = implode(',', $siteIdsArr);
    $sitesListTmp = C::t("#tom_tongcheng#tom_tongcheng_sites")->fetch_all_list(" AND id IN ({$siteIdsStr}) ", 'ORDER BY id DESC', 0, $countTmp);
    if(is_array($sitesListTmp) && !empty($sitesListTmp)){
        foreach($sitesListTmp as $key => $value){
            $sitesList[$value['id']] = $value;
        }
    }
}

$cateList = array();
if(!empty($cateIdsArr)){
    $cateIdsArr = array_unique($cateIdsArr);
    $countTmp = count($cateIdsArr);
    $cateIdsStr = implode(',', $cateIdsArr);
    $cateListTmp = C::t("#tom_tongcheng#tom_tongcheng_model_cate")->fetch_all_list(" AND id IN ({$cateIdsStr}) ", 'ORDER BY id DESC', 0, $countTmp);
    if(is_array($cateListTmp) && !empty($cateListTmp)){
        foreach($cateListTmp as $key => $value){
            $cateList[$value['id']] = $value;
        }
    }
}

$districtList = array();
if(!empty($districtIdsArr)){
    $districtIdsArr = array_unique($districtIdsArr);
    $countTmp = count($districtIdsArr);
    $districtIdsStr = implode(',', $districtIdsArr);
    $districtListTmp = C::t("#tom_tongcheng#tom_tongcheng_district")->fetch_all_list(" AND id IN ({$districtIdsStr}) ", 'ORDER BY id DESC', 0, $countTmp);
    if(is_array($districtListTmp) && !empty($districtListTmp)){
        foreach($districtListTmp as $key => $value){
            $districtList[$value['id']] = $value;
        }
    }
}

$tchongbaoList = $tongchengAttrList = $tongchengTagList = $tongchengPhotoList = $tongchengAlbumList = array();
$tongchengIdsStr = implode(',', $tongchengIdsArr);
if($__ShowTchongbao == 1){
    $tchongbaoListTmp = C::t('#tom_tchongbao#tom_tchongbao')->fetch_all_list(" AND tongcheng_id IN ({$tongchengIdsStr}) AND pay_status = 2 AND only_show = 1 ", 'ORDER BY add_time DESC,id DESC', 0, 100);
    if(is_array($tchongbaoListTmp) && !empty($tchongbaoListTmp)){
        foreach($tchongbaoListTmp as $key => $value){
            $tchongbaoList[$value['tongcheng_id']] = $value;
        }
    }
}
$tongchengAttrListTmp = C::t("#tom_tongcheng#tom_tongcheng_attr")->fetch_all_list(" AND tongcheng_id IN ({$tongchengIdsStr}) "," ORDER BY paixu ASC,id DESC ");
if(is_array($tongchengAttrListTmp) && !empty($tongchengAttrListTmp)){
    foreach($tongchengAttrListTmp as $key => $value){
        $tongchengAttrList[$value['tongcheng_id']][] = $value;
    }
}
$tongchengTagListTmp = C::t("#tom_tongcheng#tom_tongcheng_tag")->fetch_all_list(" AND tongcheng_id IN ({$tongchengIdsStr}) ");
if(is_array($tongchengTagListTmp) && !empty($tongchengTagListTmp)){
    foreach($tongchengTagListTmp as $key => $value){
        $tongchengTagList[$value['tongcheng_id']][] = $value;
    }
}
$tongchengPhotoListTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id IN ({$tongchengIdsStr})"," ORDER BY id ASC ");
if(is_array($tongchengPhotoListTmp) && !empty($tongchengPhotoListTmp)){
    foreach ($tongchengPhotoListTmp as $kk => $vv){
        if($tongchengConfig['open_yun'] == 2 && !empty($vv['oss_picurl']) && $vv['oss_status'] == 1){
            $picurl = $vv['oss_picurl'];
            //$picurl = $vv['oss_picurl'].'?x-oss-process=image/resize,m_fill,h_120,w_120';
            $albumurl = $vv['oss_picurl'];
        }else if($tongchengConfig['open_yun'] == 3 && !empty($vv['qiniu_picurl']) && $vv['qiniu_status'] == 1){
            $picurl = $vv['qiniu_picurl'];
            //$picurl = $vv['qiniu_picurl'].'?imageView2/1/w/120/h/120';
            $albumurl = $vv['qiniu_picurl'];
        }else{
            if(!preg_match('/^http/', $vv['picurl']) ){
                if(strpos($vv['picurl'], 'source/plugin/tom_') === false){
                    $picurl = $albumurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                }else{
                    $picurl = $albumurl = $_G['siteurl'].$vv['picurl'];
                }
            }else{
                $picurl = $albumurl = $vv['picurl'];
            }
        }
        $tongchengPhotoList[$vv['tongcheng_id']][$kk]['picurl'] = $picurl;
        $tongchengPhotoList[$vv['tongcheng_id']][$kk]['albumurl'] = $albumurl;
        $tongchengAlbumList[$vv['tongcheng_id']][] = $albumurl;
    }
}

$tcqianggouList = $tcqianggouCouponList = array();
if($__ShowTcqianggou == 1){
    if(!empty($tcqianggouGoodsIdsArr)){
        $tcqianggouGoodsIdsArr = array_unique($tcqianggouGoodsIdsArr);
        $countTmp = count($tcqianggouGoodsIdsArr);
        $tcqianggouGoodsIdsStr = implode(',', $tcqianggouGoodsIdsArr);
        $tcqianggouListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list("AND status=1 AND shenhe_status=1 AND type_id = 1 AND qiang_status IN(1,2) AND id IN({$tcqianggouGoodsIdsStr}) ", 'ORDER BY id DESC', 0, $countTmp);
        if(is_array($tcqianggouListTmp) && !empty($tcqianggouListTmp)){
            foreach($tcqianggouListTmp as $key => $value){
                if(!preg_match('/^http/', $value['picurl']) ){
                    if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                        $value['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                    }else{
                        $value['picurl'] = $value['picurl'];
                    }
                }else{
                    $value['picurl'] = $value['picurl'];
                }
                $tcqianggouList[$value['id']] = $value;
            }
        }
    }
    
    if(!empty($tcqianggouCouponIdsArr)){
        $tcqianggouCouponIdsArr = array_unique($tcqianggouCouponIdsArr);
        $countTmp = count($tcqianggouCouponIdsArr);
        $tcqianggouCouponIdsStr = implode(',', $tcqianggouCouponIdsArr);
        $tcqianggouCouponListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list("AND status=1 AND shenhe_status=1 AND type_id IN(2,3,4) AND qiang_status IN(1,2) AND id IN({$tcqianggouCouponIdsStr}) ", 'ORDER BY id DESC', 0, $countTmp);
        if(is_array($tcqianggouCouponListTmp) && !empty($tcqianggouCouponListTmp)){
            foreach($tcqianggouCouponListTmp as $key => $value){
                if(!preg_match('/^http/', $value['picurl']) ){
                    if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                        $value['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                    }else{
                        $value['picurl'] = $value['picurl'];
                    }
                }else{
                    $value['picurl'] = $value['picurl'];
                }
                $tcqianggouCouponList[$value['id']] = $value;
            }
        }
    }
}

$tcptuanList = array();
if($__ShowTcptuan == 1 && !empty($tcptuanGoodsIdsArr)){
    $tcptuanGoodsIdsArr = array_unique($tcptuanGoodsIdsArr);
    $countTmp = count($tcptuanGoodsIdsArr);
    $tcptuanGoodsIdsStr = implode(',', $tcptuanGoodsIdsArr);
    $tcptuanListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_list(" AND ptuan_status = 1 AND status=1 AND shenhe_status=1  AND id IN({$tcptuanGoodsIdsStr}) ", 'ORDER BY id DESC', 0, $countTmp);
    if(is_array($tcptuanListTmp) && !empty($tcptuanListTmp)){
        foreach ($tcptuanListTmp as $key => $value){
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                    $value['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $value['picurl'] = $value['picurl'];
                }
            }else{
                $value['picurl'] = $value['picurl'];
            }
            $tcptuanList[$value['id']] = $value;
        }
    }
}

$tcshopList = array();
if($__ShowTcshop == 1 && !empty($tcshopIdsArr)){
    $tcshopIdsArr = array_unique($tcshopIdsArr);
    $countTmp = count($tcshopIdsArr);
    $tcshopIdsStr = implode(',', $tcshopIdsArr);
    $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(" AND id IN({$tcshopIdsStr}) ", 'ORDER BY id DESC', 0, $countTmp);
    if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
        foreach ($tcshopListTmp as $key => $value){
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                    $value['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $value['picurl'] = $value['picurl'];
                }
            }else{
                $value['picurl'] = $value['picurl'];
            }
            $tcshopList[$value['id']] = $value;
        }
    }
}

$tcmallGoodsList = array();
if($__ShowTcmall == 1 && !empty($tcmallGoodsIdsArr)){
    $tcmallGoodsIdsArr = array_unique($tcmallGoodsIdsArr);
    $countTmp = count($tcmallGoodsIdsArr);
    $tcmallGoodsIdsStr = implode(',', $tcmallGoodsIdsArr);
    $tcmallGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND id IN({$tcmallGoodsIdsStr}) "," ORDER BY id DESC ",0,$countTmp);
    if(is_array($tcmallGoodsListTmp) && !empty($tcmallGoodsListTmp)){
        foreach ($tcmallGoodsListTmp as $key => $value){
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                    $value['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $value['picurl'] = $value['picurl'];
                }
            }else{
                $value['picurl'] = $value['picurl'];
            }
            $tcmallGoodsList[$value['id']] = $value;
        }
    }
}

$tcdaojiaGoodsList = array();
if($__ShowTcdaojia == 1 && !empty($tcdaojiaGoodsIdsArr)){
    $tcdaojiaGoodsIdsArr = array_unique($tcdaojiaGoodsIdsArr);
    $countTmp = count($tcdaojiaGoodsIdsArr);
    $tcdaojiaGoodsIdsStr = implode(',', $tcdaojiaGoodsIdsArr);
    $tcdaojiaGoodsListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND id IN ({$tcdaojiaGoodsIdsStr}) "," ORDER BY id DESC ",0,$countTmp);
    if(is_array($tcdaojiaGoodsListTmp) && !empty($tcdaojiaGoodsListTmp)){
        foreach($tcdaojiaGoodsListTmp as $key => $value){
            $photoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND goods_id = {$value['id']} AND type = 1 "," ORDER BY id ASC ",0,1);
            $picurlTmp = '';
            if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
                $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
                if(!preg_match('/^http/', $picurlTmp) ){
                    if(strpos($picurlTmp, 'source/plugin/tom_') === FALSE){
                        $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$picurlTmp;
                    }
                }
            }
            $tcdaojiaGoodsList[$value['id']]              = $value;
            $tcdaojiaGoodsList[$value['id']]['picurl']    = $picurlTmp;
        }
    }
}

if(!empty($clickZhaopinIdsArr)){
    $clickZhaopinIdsStr = implode(',', $clickZhaopinIdsArr);
    DB::query("UPDATE ".DB::table('tom_tczhaopin')." SET clicks=clicks+1 WHERE id IN ({$clickZhaopinIdsStr}) ", 'UNBUFFERED');
}
if(!empty($clickZhaopinResumeIdsArr)){
    $clickZhaopinResumeIdsStr = implode(',', $clickZhaopinResumeIdsArr);
    DB::query("UPDATE ".DB::table('tom_tczhaopin_resume')." SET clicks=clicks+1 WHERE id IN ({$clickZhaopinResumeIdsStr}) ", 'UNBUFFERED');
}
if(!empty($clickFangchanIdsArr)){
    $clickFangchanIdsStr = implode(',', $clickFangchanIdsArr);
    DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET clicks=clicks+1 WHERE id IN ({$clickFangchanIdsStr}) ", 'UNBUFFERED');
}
if(!empty($clickErshouIdsArr)){
    $clickErshouIdsStr = implode(',', $clickErshouIdsArr);
    DB::query("UPDATE ".DB::table('tom_tcershou_goods')." SET clicks=clicks+1 WHERE id IN ({$clickErshouIdsStr}) ", 'UNBUFFERED');
}
if(!empty($clickErshouNeedsIdsArr)){
    $clickErshouNeedsIdsStr = implode(',', $clickErshouNeedsIdsArr);
    DB::query("UPDATE ".DB::table('tom_tcershou_needs')." SET clicks=clicks+1 WHERE id IN ({$clickErshouNeedsIdsStr}) ", 'UNBUFFERED');
}
if(!empty($clickFangchanNeesdIdsArr)){
    $clickFangchanNeesdIdsStr = implode(',', $clickFangchanNeesdIdsArr);
    DB::query("UPDATE ".DB::table('tom_tcfangchan_needs')." SET clicks=clicks+1 WHERE id IN ({$clickFangchanNeesdIdsStr}) ", 'UNBUFFERED');
}
if(!empty($clickTongchengIdsArr)){
    $clickTongchengIdsStr = implode(',', $clickTongchengIdsArr);
    DB::query("UPDATE ".DB::table('tom_tongcheng')." SET clicks=clicks+1 WHERE id IN ({$clickTongchengIdsStr}) ", 'UNBUFFERED');
}
if($tongchengConfig['open_load_list_clicks'] == 1 && $tongchengConfig['open_tj_commonclicks'] == 1){
    $tongchengClicks = count($tongchengList);
    DB::query("UPDATE ".DB::table('tom_tongcheng_common')." SET clicks=clicks+{$tongchengClicks} WHERE id='$site_id' ", 'UNBUFFERED');
}

foreach($tongchengList as $key => $value){
    
    $allow_manage_btn = 1;
    $allow_message_btn = 1;
    $allow_pinglun_zan_btn = 1;
    $clicksTmp = $value['clicks'];
    $close_tel_btn = $value['typeInfo']['open_tel_price'];
    
    if(isset($tchongbaoList[$value['id']]) && !empty($tchongbaoList[$value['id']])){
        $infoUrlTmp = $__TchongbaoHost.'plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=hbao&xxid='.$value['id'];
    }else{
        $infoUrlTmp = 'plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=view&xxid='.$value['id'];
    }
    
    if($value['tczhaopin_id'] > 0 && $__ShowTczhaopin == 1){
        $allow_manage_btn = 0;
        $allow_message_btn = 0;
        $allow_pinglun_zan_btn = 0;
        $close_tel_btn = 1;
        $infoUrlTmp = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=zhaopininfo&tczhaopin_id='.$value['tczhaopin_id'];
        $tczhaopinInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($value['tczhaopin_id']);
        $clicksTmp = $tczhaopinInfoTmp['clicks'];
    }else if($value['tczhaopin_resume_id'] > 0 && $__ShowTczhaopin == 1){
        $allow_manage_btn = 0;
        $allow_message_btn = 0;
        $allow_pinglun_zan_btn = 0;
        $close_tel_btn = 1;
        $infoUrlTmp = 'plugin.php?id=tom_tczhaopin&site='.$site_id.'&mod=resumeinfo&resume_id='.$value['tczhaopin_resume_id'];
        $resumeInfoTmp = C::t("#tom_tczhaopin#tom_tczhaopin_resume")->fetch_by_id($value['tczhaopin_resume_id']);
        $clicksTmp = $resumeInfoTmp['clicks'];
    }else if($value['tcfangchan_id'] > 0 && $__ShowFangchan == 1){
        $allow_manage_btn = 0;
        $allow_pinglun_zan_btn = 0;
        $close_tel_btn = 1;
        $infoUrlTmp = 'plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=info&tcfangchan_id='.$value['tcfangchan_id'];
        $tcfangchanInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($value['tcfangchan_id']);
        $clicksTmp = $tcfangchanInfoTmp['clicks'];
    }else if($value['tcershou_goods_id'] > 0 && $__ShowTcershou == 1){
        $allow_manage_btn = 0;
        $allow_pinglun_zan_btn = 0;
        $close_tel_btn = 1;
        $infoUrlTmp = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=goodsinfo&goods_id='.$value['tcershou_goods_id'];
        $tcershouGoodsInfoTmp = C::t("#tom_tcershou#tom_tcershou_goods")->fetch_by_id($value['tcershou_goods_id']);
        $clicksTmp = $tcershouGoodsInfoTmp['clicks'];
    }else if($value['tcershou_needs_id'] > 0 && $__ShowTcershou == 1){
        $allow_manage_btn = 0;
        $allow_pinglun_zan_btn = 0;
        $close_tel_btn = 1;
        $infoUrlTmp = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=needsinfo&needs_id='.$value['tcershou_needs_id'];
        $tcershouNeedsInfoTmp = C::t("#tom_tcershou#tom_tcershou_needs")->fetch_by_id($value['tcershou_needs_id']);
        $clicksTmp = $tcershouNeedsInfoTmp['clicks'];
    }else if($value['tcfangchan_needs_id'] > 0 && $__ShowFangchan == 1){
        $allow_manage_btn = 0;
        $allow_message_btn = 0;
        $allow_pinglun_zan_btn = 0;
        $close_tel_btn = 1;
        $infoUrlTmp = 'plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=needsinfo&needs_id='.$value['tcfangchan_needs_id'];
        $tcfangchanNeedsInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_needs")->fetch_by_id($value['tcfangchan_needs_id']);
        $clicksTmp = $tcfangchanNeedsInfoTmp['clicks'];
    }
    
    $tongchengList[$key]['infoUrl']                     = $infoUrlTmp;
    $tongchengList[$key]['clicks']                      = $clicksTmp;
    $tongchengList[$key]['close_tel_btn']               = $close_tel_btn;
    $tongchengList[$key]['allow_manage_btn']            = $allow_manage_btn;
    $tongchengList[$key]['allow_message_btn']           = $allow_message_btn;
    $tongchengList[$key]['allow_pinglun_zan_btn']       = $allow_pinglun_zan_btn;

    $tongchengList[$key]['userInfo']                = $userList[$value['user_id']];
    
    $tongchengList[$key]['vipPicurl']               = isset($vipPicurlList[$value['user_id']]) && !empty($vipPicurlList[$value['user_id']]) ? $vipPicurlList[$value['user_id']] : '';
    $tongchengList[$key]['companyRenzhengStatus']   = isset($companyList[$value['user_id']]) && !empty($companyList[$value['user_id']]) ? $companyList[$value['user_id']] : 0;
    $tongchengList[$key]['personalRenzhengStatus']  = isset($personalList[$value['user_id']]) && !empty($personalList[$value['user_id']]) ? $personalList[$value['user_id']] : 0;
    $tongchengList[$key]['depositStatus']           = isset($depositList[$value['user_id']]) && !empty($depositList[$value['user_id']]) ? $depositList[$value['user_id']] : 0;

    $tongchengList[$key]['area_street'] = '';
    $areaNameTmp = '';
    if(!empty($value['area_id'])){
        $areaNameTmp = $districtList[$value['area_id']]['name'];
    }
    $streetNameTmp = '';
    if(!empty($value['street_id'])){
        $streetNameTmp = $districtList[$value['street_id']]['name'];
    }
    if(!empty($areaNameTmp)){
        $tongchengList[$key]['area_street'] = $areaNameTmp." ".$streetNameTmp;
    }
    
    $tongchengList[$key]['siteInfo']        = $sitesList[$value['site_id']];
    $tongchengList[$key]['cateInfo']        = $cateList[$value['cate_id']];
    $tongchengList[$key]['attrList']        = $tongchengAttrList[$value['id']];
    $tongchengList[$key]['tagList']         = $tongchengTagList[$value['id']];
    $tongchengList[$key]['photoList']       = $tongchengPhotoList[$value['id']];
    $tongchengList[$key]['photoListCount']  = count($tongchengPhotoList[$value['id']]);
    $tongchengList[$key]['albumList']       = $tongchengAlbumList[$value['id']];
    
    if($template_type != 'tuwenlist'){
        $tongchengList[$key]['content'] = str_replace("\r\n","<br/>",$value['content']);
        $tongchengList[$key]['content'] = str_replace("\n","<br/>",$tongchengList[$key]['content']);
        $tongchengList[$key]['content'] = str_replace("\r","<br/>",$tongchengList[$key]['content']);
    }
    if($close_tel_btn == 1){
        $tongchengList[$key]['content'] = preg_replace("/\d{7}/", '*****', $tongchengList[$key]['content']);
    }
    
    if($value['refresh_time'] > TIMESTAMP){
        $tongchengList[$key]['refresh_time'] = $nowDayTime + 600;
    }
    
    $tongchengList[$key]['messageUrl']  = 'plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=message&act=create&tongcheng_id='.$value['id'].'&to_user_id='.$tongchengList[$key]['userInfo']['id'].'&formhash='.FORMHASH;
    $tongchengList[$key]['tousuUrl']    = 'plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=tousu&tongcheng_id='.$value['id'];

    $juliTmp = 0;
    if(!empty($longitude) && !empty($latitude) && !empty($value['longitude']) && !empty($value['latitude'])){
        $juliTmp = tomGetDistance($longitude, $latitude, $value['longitude'], $value['latitude']);
    }
    $tongchengList[$key]['juli'] = $juliTmp;
    
    $tongchengList[$key]['tchongbaoInfo'] = array();
    if(isset($tchongbaoList[$value['id']]) && !empty($tchongbaoList[$value['id']])){
        $tongchengList[$key]['tchongbaoInfo']   = $tchongbaoList[$value['id']];
    }
    $tongchengList[$key]['tcqianggouInfo'] = array();
    if(isset($tcqianggouList[$value['tcqianggou_goods_id']]) && !empty($tcqianggouList[$value['tcqianggou_goods_id']])){
        $tongchengList[$key]['tcqianggouInfo'] = $tcqianggouList[$value['tcqianggou_goods_id']];
    }
    $tongchengList[$key]['tcqianggouCouponInfo'] = array();
    if(isset($tcqianggouCouponList[$value['tcqianggou_coupon_id']]) && !empty($tcqianggouCouponList[$value['tcqianggou_coupon_id']])){
        $tongchengList[$key]['tcqianggouCouponInfo'] = $tcqianggouCouponList[$value['tcqianggou_coupon_id']];
    }
    $tongchengList[$key]['tcmallGoodsInfo'] = array();
    if(isset($tcmallGoodsList[$value['tcmall_goods_id']]) && !empty($tcmallGoodsList[$value['tcmall_goods_id']])){
        $tongchengList[$key]['tcmallGoodsInfo'] = $tcmallGoodsList[$value['tcmall_goods_id']];
    }
    $tongchengList[$key]['tcdaojiaGoodsInfo'] = array();
    if(isset($tcdaojiaGoodsList[$value['tcdaojia_goods_id']]) && !empty($tcdaojiaGoodsList[$value['tcdaojia_goods_id']])){
        $tongchengList[$key]['tcdaojiaGoodsInfo'] = $tcdaojiaGoodsList[$value['tcdaojia_goods_id']];
    }
    $tongchengList[$key]['tcptuanInfo'] = array();
    if(isset($tcptuanList[$value['tcptuan_goods_id']]) && !empty($tcptuanList[$value['tcptuan_goods_id']])){
        $tongchengList[$key]['tcptuanInfo'] = $tcptuanList[$value['tcptuan_goods_id']];
    }
    $tongchengList[$key]['tcshopInfo'] = array();
    if(isset($tcshopList[$value['tcshop_id']]) && !empty($tcshopList[$value['tcshop_id']])){
        $tongchengList[$key]['tcshopInfo'] = $tcshopList[$value['tcshop_id']];
    }
    
}

if(is_array($tongchengList) && !empty($tongchengList)){
    foreach ($tongchengList as $key => $val){

        if($template_type == 'default'){
            $outStr.= '<div class="tcline-item noAllowCopy">';
                $outStr.= '<div class="avatar-label">';
                    if(!empty($val['vipPicurl'])){
                        $outStr.= '<a href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'"><img src="'.$val['userInfo']['picurl'].'" class="avatar" /><img src="'.$val['vipPicurl'].'" class="guajian"></a>';
                    }else{
                        $outStr.= '<a href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'"><img src="'.$val['userInfo']['picurl'].'" class="avatar" /></a>';
                    }
                    $showManageListBtn = 0;
                    if($__UserInfo['id'] == $val['userInfo']['id'] && $val['finish'] == 0 && $val['allow_manage_btn'] == 1){
                        if($__IsMiniprogram == 1 && $__Ios == 1 && $tongchengConfig['closed_ios_pay'] == 1){}else{
                            $showManageListBtn = 1;
                            $outStr.= '<div class="manage-label">';
                                $outStr.= '<a href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=buy&tongcheng_id='.$val['id'].'">'.lang('plugin/tom_tongcheng', 'ajax_list_manage_top').'</a>';
                                if($__ShowTchongbao == 1){
                                    $outStr.= '<a href="plugin.php?id=tom_tchongbao&site='.$site_id.'&mod=add&tongcheng_id='.$val['id'].'">'.lang('plugin/tom_tongcheng', 'ajax_list_manage_hb').'</a>';
                                }
                                $outStr.= '<a href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=mylist&tongcheng_id='.$val['id'].'&do_refresh='.mt_rand(111111, 999999).'">'.lang('plugin/tom_tongcheng', 'ajax_list_manage_refresh').'</a>';
                                $outStr.= '<a href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=mylist&tongcheng_id='.$val['id'].'">'.lang('plugin/tom_tongcheng', 'ajax_list_manage_more').'</a>';
                            $outStr.= '</div>';
                        }
                    }else{
                        if(!empty($val['tchongbaoInfo']) && $val['tchongbaoInfo']['status'] == 1){
                            $outStr.= '<a class="hb-label" href="'.$val['infoUrl'].'">';
                                $outStr.= '<img src="source/plugin/tom_tchongbao/images/list-hongbao.png">';
                            $outStr.= '</a>';
                        }else if($__UserInfo['groupid'] == 1 && $__UserInfo['id'] != $val['userInfo']['id'] ){
                            $showManageListBtn = 1;
                            $outStr.= '<div class="manage-label">';
                                $outStr.= '<a href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=managerList&act=fenghao_show&user_id='.$val['userInfo']['id'].'">'.lang('plugin/tom_tongcheng', 'fenhao').'</a>';
                                $outStr.= '<a href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=managerList&act=shenhe_show&tongcheng_id='.$val['id'].'">'.lang('plugin/tom_tongcheng', 'pingbi').'</a>';
                            $outStr.= '</div>';
                        }
                    }
                $outStr.= '</div>';
                if($showManageListBtn == 1){
                    $outStr.= '<div class="tcline-detail" style="min-height: 145px;" data-id='.$val['id'].'>';
                }else{
                    $outStr.= '<div class="tcline-detail" data-id='.$val['id'].'>';
                }
                    $outStr.= '<div class="tcline-detail__hd dislay-flex">';
                        $outStr.= '<div class="detail-hd__lt">';
                            if($val['topstatus'] == 1){
                                $outStr.= '<a class="typename" style="background-color: #f15555;">'.lang("plugin/tom_tongcheng", "top").'</a>&nbsp;';
                            }
                            $outStr.= '<a class="typename tc-template__bg" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=list&type_id='.$val['typeInfo']['id'].'">'.$val['typeInfo']['name'].'</a>&nbsp;';
                            if($val['companyRenzhengStatus'] == 1 || $val['personalRenzhengStatus'] == 1 || $val['depositStatus'] == 1){
                                $outStr.= '<a class="renzhenicon" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">';
                                    if($val['companyRenzhengStatus'] == 1){
                                        $outStr.= '<i class="tciconfont tcicon-renzheng_company" style="color: #0592f7;"></i>';
                                    }
                                    if($val['personalRenzhengStatus'] == 1){
                                        $outStr.= '<i class="tciconfont tcicon-renzheng_personal" style="color: #3ebb3c;"></i>';
                                    }
                                    if($val['depositStatus'] == 1){
                                        $outStr.= '<i class="tciconfont tcicon-renzheng_deposit" style="color: #f9542f;"></i>';
                                    }
                                $outStr.= '</a>&nbsp;';
                            }
                            if($tongchengConfig['list_title_type'] == 1){
                                $outStr.= '<a class="username" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">'.$val['userInfo']['nickname'].'</a>';
                            }else if($tongchengConfig['list_title_type'] == 2 && !empty ($val['xm'])){
                                $outStr.= '<a class="username" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">'.$val['xm'].'</a>';
                            }else if($tongchengConfig['list_title_type'] == 3 && !empty ($val['title'])){
                                $outStr.= '<a class="username" href="'.$val['infoUrl'].'">'.$val['title'].'</a>';
                            }else{
                                $outStr.= '<a class="username" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">'.$val['userInfo']['nickname'].'</a>';
                            }
                        $outStr.= '</div>';
                        $outStr.= '<div class="detail-hd__rt">';
                            if ($val['tchongbaoInfo']['status'] == 1){
                                $outStr.= '<a href="'.$val['infoUrl'].'" class="ext-act tchongbao"><i class="tciconfont tcicon-hongbao"></i> '.lang('plugin/tom_tongcheng', 'ajax_qiang_hb').' </a>';
                            }else{
                                if($tongchengConfig['list_show_tel_btn'] == 1 && $val['typeInfo']['close_tel'] == 0 && !empty($val['tel'])){
                                    if($val['close_tel_btn'] == 1){
                                        $outStr.= '<a href="'.$val['infoUrl'].'" class="ext-tel"><i class="tciconfont tcicon-dianhua"></i>'.lang("plugin/tom_tongcheng", "list_tel_btn").'</a>';
                                    }else if($val['finish'] == 1){
                                        $outStr.= '<a href="'.$val['infoUrl'].'" class="ext-tel" style="background-color: #cecaca;border: #cecaca 1px solid;"><i class="tciconfont tcicon-dianhua"></i>'.lang("plugin/tom_tongcheng", "list_tel_btn").'</a>';
                                    }else{
                                        $outStr.= '<a href="tel:'.$val['tel'].'" class="ext-tel"><i class="tciconfont tcicon-dianhua"></i>'.lang("plugin/tom_tongcheng", "list_tel_btn").'</a>';
                                    }
                                }else{
                                    $outStr.= '<a href="'.$val['infoUrl'].'" class="ext-act"><i class="tciconfont tcicon-yanjing"></i>'.lang("plugin/tom_tongcheng", "template_xiangqing").' </a>';
                                }
                            }
                        $outStr.= '</div>';
                    $outStr.= '</div>';
                    $outStr.= '<article style="max-height: none;">';
                    if($tongchengConfig['open_list_quanwen'] == 0){
                        $outStr.= '<a href="'.$val['infoUrl'].'">';
                    }
                        if(is_array($val['tagList']) && !empty($val['tagList'])){
                            $outStr.= '<div class="detail-tags">';
                                foreach ($val['tagList'] as $k1 => $v1){
                                    $outStr.= '<span class="span'.$k1.'">'.$v1['tag_name'].'</span>';
                                }
                                $outStr.= '<div class="clear"></div>';
                            $outStr.= '</div>';
                        }
                        $outStr.= '<div class="detail-attr" style="max-height:63px; overflow:hidden;" >';
                        $a = 0;
                        if(is_array($val['cateInfo']) && !empty($val['cateInfo'])){
                            $a = 1;
                            $outStr.= '<p><font class="tc-template__color" color="#f60">'.$val['typeInfo']['cate_title'].'&nbsp;:&nbsp;</font>'.$val['cateInfo']['name'].'</p>';
                        }
                        if(is_array($val['attrList']) && !empty($val['attrList'])){
                            foreach ($val['attrList'] as $k2 => $v2){
                                if(!empty($v2['value'])){
                                    $outStr.= '<p><font class="tc-template__color" color="#f60">'.$v2['attr_name'].'&nbsp;:&nbsp;</font></b>'.$v2['value'];
                                    if($v2['unit']){
                                        $outStr.= ''.$v2['unit'];
                                    }
                                    $outStr.= '</p>';
                                    $a++;
                                }
                            }
                        }
                        if(!empty($val['area_street'])){
                            $outStr.= '<p><font class="tc-template__color" color="#F60">'.lang("plugin/tom_tongcheng", "template_address").'&nbsp;:&nbsp;</font></b>'.$val['area_street'].'</p>';
                            $a++;
                        }
                        $outStr.= '</div>';
                        if($a > 3){
                            $outStr.= '<div class="detail-attr__more"><i></i><i></i><i></i></div>';
                        }

                        $outStr.= '<p class="detail-content detail-content__line2">'.$val['content'].'</p>';
                    if($tongchengConfig['open_list_quanwen'] == 0){
                        $outStr.= '</a>';
                    }
                    $outStr.= '</article>';
                    $outStr.= '<div class="detail-toggle">'.lang("plugin/tom_tongcheng", "template_quanwen").'</div>';
                    $outStr.= '<div class="detail-toggle2" style="display:none;">'.lang("plugin/tom_tongcheng", "template_shouqi").'</div>';
                    if((is_array($val['photoList']) && !empty($val['photoList'])) || !empty($val['video_url'])){
                        $outStr.= '<div class="detail-pics clearfix"><input type="hidden" name="photo_list" class="photo_list" value="'.implode('|', $val['albumList']).'">';
                        $list_xz_pic_num = 3;
                        if(!empty($val['video_url'])){
                            $list_xz_pic_num = 2;
                            $outStr.= '<a href="'.$val['infoUrl'].'"><img src="'.$val['video_pic'].'"><span class="play"></span></a>';
                        }
                        $i_photo = 0;
                        foreach ($val['photoList'] as $k3 => $v3){
                            $i_photo++;
                            if($tongchengConfig['open_list_xz_pic'] == 1){
                                if($i_photo == $list_xz_pic_num && $val['photoListCount'] > $list_xz_pic_num){
                                    $outStr.= '<a href="javascript:void(0);" onclick="showPicList($(this),'.($i_photo - 1).');"><img src="'.$v3['picurl'].'"><span class="more-pic">'.lang("plugin/tom_tongcheng", 'template_more_pic_1').'<br/>'.lang("plugin/tom_tongcheng", 'template_more_pic_2').'</span></a>';
                                }else if($i_photo >= ($list_xz_pic_num + 1)){
                                    continue;
                                }else{
                                    $outStr.= '<a href="javascript:void(0);" onclick="showPicList($(this),'.($i_photo - 1).');"><img src="'.$v3['picurl'].'"></a>';
                                }
                            }else{
                                $outStr.= '<a href="javascript:void(0);" onclick="showPicList($(this),'.($i_photo - 1).');"><img src="'.$v3['picurl'].'"></a>';
                            }
                        }
                        $outStr.= '</div>';
                    }
                    if(is_array($val['tcshopInfo']) && !empty($val['tcshopInfo'])){
                        $outStr.= '<a class="detail-link" href="plugin.php?id=tom_tcshop&site='.$val['tcshopInfo']['site_id'].'&mod=details&dpid='.$val['tcshopInfo']['id'].'" target="_blank"><img src="'.$val['tcshopInfo']['picurl'].'"><b>'.$val['tcshopInfo']['name'].'</b><br><img src="source/plugin/tom_tongcheng/images/detail-link-ico.png" style="width: 13px;height: 17px;margin-right: 0px;">&nbsp;&nbsp;'.$val['tcshopInfo']['address'].'</a>';
                    }
                    if(is_array($val['tcqianggouInfo']) && !empty($val['tcqianggouInfo'])){
                        $outStr.= '<a class="detail-link" href="plugin.php?id=tom_tcqianggou&site='.$val['tcqianggouInfo']['site_id'].'&mod=details&goods_id='.$val['tcqianggouInfo']['id'].'" target="_blank"><img src="'.$val['tcqianggouInfo']['picurl'].'"><b>'.$val['tcqianggouInfo']['title'].'</b><br>'.lang("plugin/tom_tongcheng", "list_qianggou_price").' <font color="#fd0d0d">'.lang('plugin/tom_tcqianggou','yuan_ico').floatval($val['tcqianggouInfo']['show_buy_price']).'</font></a>';
                    }
                    if(is_array($val['tcqianggouCouponInfo']) && !empty($val['tcqianggouCouponInfo'])){
                        $outStr.= '<a class="detail-link" href="plugin.php?id=tom_tcqianggou&site='.$val['tcqianggouCouponInfo']['site_id'].'&mod=coupon&goods_id='.$val['tcqianggouCouponInfo']['id'].'" target="_blank">';
                            $outStr.= '<img src="'.$val['tcqianggouCouponInfo']['picurl'].'"><b>'.$val['tcqianggouCouponInfo']['title'].'</b>';
                            if($val['tcqianggouCouponInfo']['type_id'] == 2){
                                $outStr.= '<br><font color="#fd0d0d">'.$val['tcqianggouCouponInfo']['coupon_price'].'</font>'.lang('plugin/tom_tongcheng', 'yuan').lang('plugin/tom_tongcheng', 'list_qg_coupon_type_2_title').'';
                            }else if($val['tcqianggouCouponInfo']['type_id'] == 3){
                                $outStr.= '<br><font color="#fd0d0d">'.$val['tcqianggouCouponInfo']['coupon_zhekou'].'</font>'.lang('plugin/tom_tongcheng', 'list_qg_coupon_type_3_title');
                            }else if($val['tcqianggouCouponInfo']['type_id'] == 4){
                                $outStr.= '<br><font color="#fd0d0d">'.$val['tcqianggouCouponInfo']['coupon_price'].'</font>'.lang('plugin/tom_tongcheng', 'yuan').lang('plugin/tom_tongcheng', 'list_qg_coupon_type_4_title').'';
                            }
                        $outStr.= '</a>';
                    }
                    if(is_array($val['tcptuanInfo']) && !empty($val['tcptuanInfo'])){
                        $outStr.= '<a class="detail-link" href="plugin.php?id=tom_tcptuan&site='.$val['tcptuanInfo']['site_id'].'&mod=goodsinfo&goods_id='.$val['tcptuanInfo']['id'].'" target="_blank"><img src="'.$val['tcptuanInfo']['picurl'].'"><b>'.$val['tcptuanInfo']['name'].'</b><br>'.$val['tcptuanInfo']['tuan_num'].''.lang('plugin/tom_tcptuan','ajax_list_rentuan').' <font color="#fd0d0d">'.lang('plugin/tom_tcptuan','ajax_list_yuan_ico').''.$val['tcptuanInfo']['show_tuan_price'].'</font></a>';
                    }
                    if(is_array($val['tcmallGoodsInfo']) && !empty($val['tcmallGoodsInfo'])){
                        $outStr.= '<a class="detail-link" href="plugin.php?id=tom_tcmall&site='.$val['tcmallGoodsInfo']['site_id'].'&mod=goodsinfo&goods_id='.$val['tcmallGoodsInfo']['id'].'" target="_blank"><img src="'.$val['tcmallGoodsInfo']['picurl'].'"><b>'.$val['tcmallGoodsInfo']['title'].'</b><br><font color="#fd0d0d">'.lang('plugin/tom_tongcheng', 'yuan_ico').$val['tcmallGoodsInfo']['show_buy_price'].'</font></a>';
                    }
                    if(is_array($val['tcdaojiaGoodsInfo']) && !empty($val['tcdaojiaGoodsInfo'])){
                        $outStr.= '<a class="detail-link" href="plugin.php?id=tom_tcdaojia&site='.$val['tcdaojiaGoodsInfo']['site_id'].'&mod=goodsinfo&goods_id='.$val['tcdaojiaGoodsInfo']['id'].'" target="_blank"><img src="'.$val['tcdaojiaGoodsInfo']['picurl'].'"><b>'.$val['tcdaojiaGoodsInfo']['title'].'</b><br><font color="#fd0d0d">'.lang('plugin/tom_tongcheng', 'yuan_ico').$val['tcdaojiaGoodsInfo']['price'].'</font></a>';
                    }
                    if($val['typeInfo']['open_dingwei'] == 1 && $val['is_dingwei'] == 1 && !empty($val['address'])){
                        $outStr.= '<div class="detail-dingwei">';
                            $outStr.= '<i class="tciconfont tcicon-dingwei_shi"></i>'.$val['address'];
                            if($val['juli'] > 0){
                                $outStr.= '<span>'.lang("plugin/tom_tongcheng", "template_juli").$val['juli'].'km</span>';
                            }
                        $outStr.= '</div>';
                    }
                    $outStr.= '<div class="detail-time">';
                        $outStr.= '<div>';
                        $outStr.= '<span>'.$val['clicks'].lang("plugin/tom_tongcheng", "template_clicks").'</span>';
                        if($tongchengSetting['open_list_pinglun_zan'] == 0){
                            if($val['collect'] > 0){
                                $outStr.= '<span>'.$val['collect'].lang("plugin/tom_tongcheng", "template_collect").'</span>';
                            }
                            if($val['pinglunCount'] > 0){
                                $outStr.= '<span>'.$val['pinglunCount'].lang("plugin/tom_tongcheng", "template_pinglun").'</span>';
                            }
                        }
                        if(($val['refresh_time'] - $val['add_time']) > 3600){
                            $outStr.= '<span>'.dgmdate($val['refresh_time'], 'u','9999','m-d H:i').lang("plugin/tom_tongcheng", "template_refresh_title").'</span>';
                        }else{
                            $outStr.= '<span>'.dgmdate($val['refresh_time'], 'u','9999','m-d H:i').'</span>';
                        }
                        $outStr.= '</div>';
                        if($val['allow_pinglun_zan_btn'] == 1 || ($tongchengConfig['open_message'] == 1 && $val['allow_message_btn'] == 1) || ($val['typeInfo']['close_tel'] == 0 && !empty($val['tel']))){
                            $outStr.= '<div class="detail-time-icon" data-id="'.$val['id'].'" data-message="'.$val['messageUrl'].'" data-tousu="'.$val['tousuUrl'].'" data-tel="tel:'.$val['tel'].'" data-user-id="'.$__UserInfo['id'].'"></div>';
                        }
                        $outStr.= '<div class="detail-toolbar">';
                            if($val['allow_pinglun_zan_btn'] == 1 && $tongchengSetting['open_list_pinglun_zan'] == 1){
                                if($tongchengConfig['open_pinglun'] == 1){
                                    $outStr.= '<a href="javascript:void(0);" rel="nofolow" class="list-plugin__btn" data-id="'.$val['id'].'"><img src="source/plugin/tom_tongcheng/images/icon_replay.png">'.lang("plugin/tom_tongcheng", "list_tousu_plugin").'</a>';
                                }
                                $outStr.= '<a href="javascript:void(0);" onclick="collect('.$__UserInfo['id'].','.$val['id'].');" class="ajax-post"><img src="source/plugin/tom_tongcheng/images/list_zan.png">'.lang("plugin/tom_tongcheng", "list_collect_btn").'</a>';
                            }
                            if($tongchengConfig['open_message'] == 1 && $val['allow_message_btn'] == 1){
                                $outStr.= '<a href="'.$val['messageUrl'].'"><img src="source/plugin/tom_tongcheng/images/icon-message.png">'.lang("plugin/tom_tongcheng", "list_sms_btn").'</a>';
                            }
                            if($val['typeInfo']['close_tel'] == 0 && !empty($val['tel'])){
                                if($val['finish'] == 0){
                                    if($val['close_tel_btn'] == 1){
                                        $outStr.= '<a href="'.$val['infoUrl'].'" class="ajax-get"><img src="source/plugin/tom_tongcheng/images/icon-tel.png">'.lang("plugin/tom_tongcheng", "list_tel_btn").'</a>';
                                    }else{
                                        $outStr.= '<a href="tel:'.$val['tel'].'" class="ajax-get"><img src="source/plugin/tom_tongcheng/images/icon-tel.png">'.lang("plugin/tom_tongcheng", "list_tel_btn").'</a>';
                                    }
                                }
                            }
                        $outStr.= '</div>';
                    $outStr.= '</div>';
                    if($val['finish'] == 1){
                        $outStr.= '<section class="mark-img succ"></section>';
                    }
                    if($val['allow_pinglun_zan_btn'] == 1 && $tongchengSetting['open_list_pinglun_zan'] == 1){
                        if($val['collect'] > 0 || $val['pinglunCount'] > 0){
                            $outStr.= '<div class="detail-cmt-wrap detail-list__'.$val['id'].'">';
                        }else{
                            $outStr.= '<div class="detail-cmt-wrap box_hide detail-list__'.$val['id'].'">';
                        }
                            $outStr.= '<i class="detail-cmtr"></i>';
                            $outStr.= '<div class="detail-cmt">';
                                $outStr.= '<div class="like-list detail-collect__'.$val['id'].'">';
                                    $outStr.= '<span class="num">'.$val['collect'].'</span> '.lang("plugin/tom_tongcheng", "template_collect2");
                                    if($val['collect'] > 0){
                                        if(is_array($val['collectList']) && !empty($val['collectList'])){
                                            foreach($val['collectList'] as $kc => $vc){
                                                $outStr.= '<span><img src="'.$userList[$vc['user_id']]['picurl'].'"></span>';
                                            }
                                        }
                                    }

                                $outStr.= '</div>';
                            $outStr.= '</div>';
                            if($tongchengConfig['open_pinglun'] == 1){
                            if($val['pinglunCount'] > 0){
                                $outStr.= '<div class="detail-cmt detail-plugin__'.$val['id'].'">';
                            }else{
                                $outStr.= '<div class="detail-cmt box_hide detail-plugin__'.$val['id'].'">';
                            }
                                    $outStr.= '<div class="plugin-item">';
                                    if(is_array($val['pinglunList']) && !empty($val['pinglunList'])){
                                        foreach($val['pinglunList'] as $kp => $vp){
                                            $vp['content'] = cutstr($vp['content'], 60, '..');
                                            if($vp['touser_id'] > 0){
                                                $outStr.= '<a href="javascript:void(0);" class="replay-plugin__btn" data-id="'.$val['id'].'" data-touserid="'.$userList[$vp['user_id']]['id'].'" data-tonickname="'.$userList[$vp['user_id']]['nickname'].'"><span class="nick">'.$userList[$vp['user_id']]['nickname'].'</span>&nbsp;'.lang("plugin/tom_tongcheng", "pinglun_hueifu").'&nbsp;<span class="nick">'.$vp['touser_nickname'].lang("plugin/tom_tongcheng", "pinglun_hueifu_dian").'</span>&nbsp;'.$vp['content'].'</a>';
                                            }else{
                                                $outStr.= '<a href="javascript:void(0);" class="replay-plugin__btn" data-id="'.$val['id'].'" data-touserid="'.$userList[$vp['user_id']]['id'].'" data-tonickname="'.$userList[$vp['user_id']]['nickname'].'"><span class="nick">'.$userList[$vp['user_id']]['nickname'].lang("plugin/tom_tongcheng", "pinglun_hueifu_dian").'</span>&nbsp;'.$vp['content'].'</a>';
                                            }
                                        }
                                        if($val['pinglunCount'] > 5){
                                            $outStr.= '<a href="'.$val['infoUrl'].'">'.lang("plugin/tom_tongcheng", "ajax_look_more_plugin_1").$val['pinglunCount'].lang("plugin/tom_tongcheng", "ajax_look_more_plugin_2").'</a>';
                                        }
                                    }
                                    $outStr.= '</div>';
                                $outStr.= '</div>';
                            }
                        $outStr.= '</div>';
                    }
                $outStr.= '</div>';
            $outStr.= '</div>';
            
        }else if($template_type == 'kuanlist'){
            
            $outStr.= '<div class="tcline-item noAllowCopy">';
                $outStr.= '<div class="tcline-detail kuanlist-detail" data-id='.$val['id'].'>';
                    $outStr.= '<div class="tcline-detail__hd dislay-flex">';
                        $outStr.= '<div class="detail-hd__lt">';
                            
                            if(!empty($val['vipPicurl'])){
                                $outStr.= '<a class="user" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'"><img src="'.$val['userInfo']['picurl'].'" class="avatar" /><img src="'.$val['vipPicurl'].'" class="guajian"></a>';
                            }else{
                                $outStr.= '<a class="user" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'"><img src="'.$val['userInfo']['picurl'].'" class="avatar" /></a>';
                            }
                            
                            if($val['topstatus'] == 1){
                                $outStr.= '<a class="typename" style="background-color: #f15555;">'.lang("plugin/tom_tongcheng", "top").'</a>&nbsp;';
                            }
                            $outStr.= '<a class="typename tc-template__bg" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=list&type_id='.$val['typeInfo']['id'].'">'.$val['typeInfo']['name'].'</a>&nbsp;';
                            if($val['companyRenzhengStatus'] == 1 || $val['personalRenzhengStatus'] == 1 || $val['depositStatus'] == 1){
                                $outStr.= '<a class="renzhenicon" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">';
                                    if($val['companyRenzhengStatus'] == 1){
                                        $outStr.= '<i class="tciconfont tcicon-renzheng_company" style="color: #0592f7;"></i>';
                                    }
                                    if($val['personalRenzhengStatus'] == 1){
                                        $outStr.= '<i class="tciconfont tcicon-renzheng_personal" style="color: #3ebb3c;"></i>';
                                    }
                                    if($val['depositStatus'] == 1){
                                        $outStr.= '<i class="tciconfont tcicon-renzheng_deposit" style="color: #f9542f;"></i>';
                                    }
                                $outStr.= '</a>&nbsp;';
                            }

                            if($tongchengConfig['list_title_type'] == 1){
                                $outStr.= '<a class="username" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">'.$val['userInfo']['nickname'].'</a>';
                            }else if($tongchengConfig['list_title_type'] == 2 && !empty ($val['xm'])){
                                $outStr.= '<a class="username" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">'.$val['xm'].'</a>';
                            }else if($tongchengConfig['list_title_type'] == 3 && !empty ($val['title'])){
                                $outStr.= '<a class="username" href="'.$val['infoUrl'].'">'.$val['title'].'</a>';
                            }else{
                                $outStr.= '<a class="username" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">'.$val['userInfo']['nickname'].'</a>';
                            }
                        $outStr.= '</div>';
                        $outStr.= '<div class="detail-hd__rt">';
                            if ($val['tchongbaoInfo']['status'] == 1){
                                $outStr.= '<a href="'.$val['infoUrl'].'" class="ext-act tchongbao"><i class="tciconfont tcicon-hongbao"></i> '.lang('plugin/tom_tongcheng', 'ajax_qiang_hb').' </a>';
                            }else{
                                if($tongchengConfig['list_show_tel_btn'] == 1 && $val['typeInfo']['close_tel'] == 0 && !empty($val['tel'])){
                                    if($val['close_tel_btn'] == 1){
                                        $outStr.= '<a href="'.$val['infoUrl'].'" class="ext-tel"><i class="tciconfont tcicon-dianhua"></i>'.lang("plugin/tom_tongcheng", "list_tel_btn").'</a>';
                                    }else if($val['finish'] == 1){
                                        $outStr.= '<a href="'.$val['infoUrl'].'" class="ext-tel" style="background-color: #cecaca;border: #cecaca 1px solid;"><i class="tciconfont tcicon-dianhua"></i>'.lang("plugin/tom_tongcheng", "list_tel_btn").'</a>';
                                    }else{
                                        $outStr.= '<a href="tel:'.$val['tel'].'" class="ext-tel"><i class="tciconfont tcicon-dianhua"></i>'.lang("plugin/tom_tongcheng", "list_tel_btn").'</a>';
                                    }
                                }else{
                                    $outStr.= '<a href="'.$val['infoUrl'].'" class="ext-act"><i class="tciconfont tcicon-yanjing"></i>'.lang("plugin/tom_tongcheng", "template_xiangqing").' </a>';
                                }
                            }
                        $outStr.= '</div>';
                    $outStr.= '</div>';
                    $outStr.= '<article style="max-height: none;">';
                    if($tongchengConfig['open_list_quanwen'] == 0){
                        $outStr.= '<a href="'.$val['infoUrl'].'">';
                    }
                        if(is_array($val['tagList']) && !empty($val['tagList'])){
                        $outStr.= '<div class="detail-tags">';
                            foreach ($val['tagList'] as $k1 => $v1){
                             $outStr.= '<span class="span'.$k1.'">'.$v1['tag_name'].'</span>';
                            }
                             $outStr.= '<div class="clear"></div>';
                        $outStr.= '</div>';
                        }
                        $outStr.= '<div class="detail-attr" style="max-height:63px; overflow:hidden;" >';
                        $a = 0;
                        if(is_array($val['cateInfo']) && !empty($val['cateInfo'])){
                            $a = 1;
                            $outStr.= '<p><font class="tc-template__color" color="#f60">'.$val['typeInfo']['cate_title'].'&nbsp;:&nbsp;</font>'.$val['cateInfo']['name'].'</p>';
                        }
                        if(is_array($val['attrList']) && !empty($val['attrList'])){
                            foreach ($val['attrList'] as $k2 => $v2){
                               if(!empty($v2['value'])){
                                   $outStr.= '<p><font class="tc-template__color" color="#f60">'.$v2['attr_name'].'&nbsp;:&nbsp;</font></b>'.$v2['value'];
                                   if($v2['unit']){
                                       $outStr.= ''.$v2['unit'];
                                   }
                                   $outStr.= '</p>';
                                   $a++;
                               }
                            }
                        }
                        if(!empty($val['area_street'])){
                           $outStr.= '<p><font class="tc-template__color" color="#F60">'.lang("plugin/tom_tongcheng", "template_address").'&nbsp;:&nbsp;</font></b>'.$val['area_street'].'</p>';
                           $a++;
                        }
                        $outStr.= '</div>';
                        if($a > 3){
                            $outStr.= '<div class="detail-attr__more"><i></i><i></i><i></i></div>';
                        }
                        $outStr.= '<p class="detail-content detail-content__line2">'.$val['content'].'</p>';
                    if($tongchengConfig['open_list_quanwen'] == 0){
                        $outStr.= '</a>';
                    }
                    $outStr.= '</article>';
                    $outStr.= '<div class="detail-toggle">'.lang("plugin/tom_tongcheng", "template_quanwen").'</div>';
                    $outStr.= '<div class="detail-toggle2" style="display:none;">'.lang("plugin/tom_tongcheng", "template_shouqi").'</div>';
                    if((is_array($val['photoList']) && !empty($val['photoList'])) || !empty($val['video_url'])){
                        $outStr.= '<div class="detail-pics clearfix">';
                        $list_xz_pic_num = 3;
                        if(!empty($val['video_url'])){
                            $list_xz_pic_num = 2;
                            $outStr.= '<a href="'.$val['infoUrl'].'"><img src="'.$val['video_pic'].'"><span class="play"></span></a>';
                        }
                        $i_photo = 0;
                        foreach ($val['photoList'] as $k3 => $v3){
                            $i_photo++;
                            if($tongchengConfig['open_list_xz_pic'] == 1){
                                if($i_photo == $list_xz_pic_num && $val['photoListCount'] > $list_xz_pic_num){
                                    $outStr.= '<a href="javascript:void(0);" onclick="showPicList($(this),'.($i_photo - 1).');"><img src="'.$v3['picurl'].'"><span class="more-pic">'.lang("plugin/tom_tongcheng", 'template_more_pic_1').'<br/>'.lang("plugin/tom_tongcheng", 'template_more_pic_2').'</span></a>';
                                }else if($i_photo >= ($list_xz_pic_num + 1)){
                                    continue;
                                }else{
                                    $outStr.= '<a href="javascript:void(0);" onclick="showPicList($(this),'.($i_photo - 1).');"><img src="'.$v3['picurl'].'"></a>';
                                }
                            }else{
                                $outStr.= '<a href="javascript:void(0);" onclick="showPicList($(this),'.($i_photo - 1).');"><img src="'.$v3['picurl'].'"></a>';
                            }
                        }
                        $outStr.= '<input type="hidden" name="photo_list" class="photo_list" value="'.implode('|', $val['albumList']).'"></div>';
                    }
                    if(is_array($val['tcshopInfo']) && !empty($val['tcshopInfo'])){
                        $outStr.= '<a class="detail-link" href="plugin.php?id=tom_tcshop&site='.$val['tcshopInfo']['site_id'].'&mod=details&dpid='.$val['tcshopInfo']['id'].'" target="_blank"><img src="'.$val['tcshopInfo']['picurl'].'"><b>'.$val['tcshopInfo']['name'].'</b><br><img src="source/plugin/tom_tongcheng/images/detail-link-ico.png" style="width: 13px;height: 17px;margin-right: 0px;">&nbsp;&nbsp;'.$val['tcshopInfo']['address'].'</a>';
                    }
                    if(is_array($val['tcqianggouInfo']) && !empty($val['tcqianggouInfo'])){
                        $outStr.= '<a class="detail-link" href="plugin.php?id=tom_tcqianggou&site='.$val['tcqianggouInfo']['site_id'].'&mod=details&goods_id='.$val['tcqianggouInfo']['id'].'" target="_blank"><img src="'.$val['tcqianggouInfo']['picurl'].'"><b>'.$val['tcqianggouInfo']['title'].'</b><br>'.lang("plugin/tom_tongcheng", "list_qianggou_price").' <font color="#fd0d0d">'.lang('plugin/tom_tcqianggou','yuan_ico').floatval($val['tcqianggouInfo']['show_buy_price']).'</font></a>';
                    }
                    if(is_array($val['tcqianggouCouponInfo']) && !empty($val['tcqianggouCouponInfo'])){
                        $outStr.= '<a class="detail-link" href="plugin.php?id=tom_tcqianggou&site='.$val['tcqianggouCouponInfo']['site_id'].'&mod=coupon&goods_id='.$val['tcqianggouCouponInfo']['id'].'" target="_blank">';
                            $outStr.= '<img src="'.$val['tcqianggouCouponInfo']['picurl'].'"><b>'.$val['tcqianggouCouponInfo']['title'].'</b>';
                            if($val['tcqianggouCouponInfo']['type_id'] == 2){
                                $outStr.= '<br><font color="#fd0d0d">'.$val['tcqianggouCouponInfo']['coupon_price'].'</font>'.lang('plugin/tom_tongcheng', 'yuan').lang('plugin/tom_tongcheng', 'list_qg_coupon_type_2_title').'';
                            }else if($val['tcqianggouCouponInfo']['type_id'] == 3){
                                $outStr.= '<br><font color="#fd0d0d">'.$val['tcqianggouCouponInfo']['coupon_zhekou'].'</font>'.lang('plugin/tom_tongcheng', 'list_qg_coupon_type_3_title');
                            }else if($val['tcqianggouCouponInfo']['type_id'] == 4){
                                $outStr.= '<br><font color="#fd0d0d">'.$val['tcqianggouCouponInfo']['coupon_price'].'</font>'.lang('plugin/tom_tongcheng', 'yuan').lang('plugin/tom_tongcheng', 'list_qg_coupon_type_4_title').'';
                            }
                        $outStr.= '</a>';
                    }
                    if(is_array($val['tcptuanInfo']) && !empty($val['tcptuanInfo'])){
                        $outStr.= '<a class="detail-link" href="plugin.php?id=tom_tcptuan&site='.$val['tcptuanInfo']['site_id'].'&mod=goodsinfo&goods_id='.$val['tcptuanInfo']['id'].'" target="_blank"><img src="'.$val['tcptuanInfo']['picurl'].'"><b>'.$val['tcptuanInfo']['name'].'</b><br>'.$val['tcptuanInfo']['tuan_num'].''.lang('plugin/tom_tcptuan','ajax_list_rentuan').' <font color="#fd0d0d">'.lang('plugin/tom_tcptuan','ajax_list_yuan_ico').''.$val['tcptuanInfo']['show_tuan_price'].'</font></a>';
                    }
                    if(is_array($val['tcmallGoodsInfo']) && !empty($val['tcmallGoodsInfo'])){
                        $outStr.= '<a class="detail-link" href="plugin.php?id=tom_tcmall&site='.$val['tcmallGoodsInfo']['site_id'].'&mod=goodsinfo&goods_id='.$val['tcmallGoodsInfo']['id'].'" target="_blank"><img src="'.$val['tcmallGoodsInfo']['picurl'].'"><b>'.$val['tcmallGoodsInfo']['title'].'</b><br><font color="#fd0d0d">'.lang('plugin/tom_tongcheng', 'yuan_ico').$val['tcmallGoodsInfo']['show_buy_price'].'</font></a>';
                    }
                    if(is_array($val['tcdaojiaGoodsInfo']) && !empty($val['tcdaojiaGoodsInfo'])){
                        $outStr.= '<a class="detail-link" href="plugin.php?id=tom_tcdaojia&site='.$val['tcdaojiaGoodsInfo']['site_id'].'&mod=goodsinfo&goods_id='.$val['tcdaojiaGoodsInfo']['id'].'" target="_blank"><img src="'.$val['tcdaojiaGoodsInfo']['picurl'].'"><b>'.$val['tcdaojiaGoodsInfo']['title'].'</b><br><font color="#fd0d0d">'.lang('plugin/tom_tongcheng', 'yuan_ico').$val['tcdaojiaGoodsInfo']['price'].'</font></a>';
                    }
                    if($val['typeInfo']['open_dingwei'] == 1 && $val['is_dingwei'] == 1 && !empty($val['address'])){
                        $outStr.= '<div class="detail-dingwei">';
                            $outStr.= '<i class="tciconfont tcicon-dingwei_shi"></i>'.$val['address'];
                            if($val['juli'] > 0){
                                $outStr.= '<span>'.lang("plugin/tom_tongcheng", "template_juli").$val['juli'].'km</span>';
                            }
                        $outStr.= '</div>';
                    }
                    $outStr.= '<div class="detail-time">';
                        $outStr.= '<div>';
                        $outStr.= '<span>'.$val['clicks'].lang("plugin/tom_tongcheng", "template_clicks").'</span>';
                        if($tongchengSetting['open_list_pinglun_zan'] == 0){
                            if($val['collect'] > 0){
                                $outStr.= '<span>'.$val['collect'].lang("plugin/tom_tongcheng", "template_collect").'</span>';
                            }
                            if($val['pinglunCount'] > 0){
                                $outStr.= '<span>'.$val['pinglunCount'].lang("plugin/tom_tongcheng", "template_pinglun").'</span>';
                            }
                        }
                        if(($val['refresh_time'] - $val['add_time']) > 3600){
                            $outStr.= '<span>'.dgmdate($val['refresh_time'], 'u','9999','m-d H:i').lang("plugin/tom_tongcheng", "template_refresh_title").'</span>';
                        }else{
                            $outStr.= '<span>'.dgmdate($val['refresh_time'], 'u','9999','m-d H:i').'</span>';
                        }
                        $outStr.= '</div>';
                        if($val['allow_pinglun_zan_btn'] == 1 || ($tongchengConfig['open_message'] == 1 && $val['allow_message_btn'] == 1) || ($val['typeInfo']['close_tel'] == 0 && !empty($val['tel']))){
                            $outStr.= '<div class="detail-time-icon" data-id="'.$val['id'].'" data-message="'.$val['messageUrl'].'" data-tousu="'.$val['tousuUrl'].'" data-tel="tel:'.$val['tel'].'" data-user-id="'.$__UserInfo['id'].'"></div>';
                        }
                        $outStr.= '<div class="detail-toolbar">';
                           if($val['allow_pinglun_zan_btn'] == 1 && $tongchengSetting['open_list_pinglun_zan'] == 1){
                                if($tongchengConfig['open_pinglun'] == 1){
                                    $outStr.= '<a href="javascript:void(0);" rel="nofolow" class="list-plugin__btn" data-id="'.$val['id'].'"><img src="source/plugin/tom_tongcheng/images/icon_replay.png">'.lang("plugin/tom_tongcheng", "list_tousu_plugin").'</a>';
                                }
                                $outStr.= '<a href="javascript:void(0);" onclick="collect('.$__UserInfo['id'].','.$val['id'].');" class="ajax-post"><img src="source/plugin/tom_tongcheng/images/list_zan.png">'.lang("plugin/tom_tongcheng", "list_collect_btn").'</a>';
                            }
                            if($tongchengConfig['open_message'] == 1 && $val['allow_message_btn'] == 1){
                                $outStr.= '<a href="'.$val['messageUrl'].'"><img src="source/plugin/tom_tongcheng/images/icon-message.png">'.lang("plugin/tom_tongcheng", "list_sms_btn").'</a>';
                            }
                            if($val['typeInfo']['close_tel'] == 0 && !empty($val['tel'])){
                                if($val['finish'] == 0){
                                    if($val['close_tel_btn'] == 1){
                                        $outStr.= '<a href="'.$val['infoUrl'].'" class="ajax-get"><img src="source/plugin/tom_tongcheng/images/icon-tel.png">'.lang("plugin/tom_tongcheng", "list_tel_btn").'</a>';
                                    }else{
                                        $outStr.= '<a href="tel:'.$val['tel'].'" class="ajax-get"><img src="source/plugin/tom_tongcheng/images/icon-tel.png">'.lang("plugin/tom_tongcheng", "list_tel_btn").'</a>';
                                    }
                                }
                            }
                        $outStr.= '</div>';
                    $outStr.= '</div>';
                    if($val['finish'] == 1){
                        $outStr.= '<section class="mark-img succ"></section>';
                    }
                    if($val['allow_pinglun_zan_btn'] == 1 && $tongchengSetting['open_list_pinglun_zan'] == 1){
                        if($val['collect'] > 0 || $val['pinglunCount'] > 0){
                            $outStr.= '<div class="detail-cmt-wrap detail-list__'.$val['id'].'">';
                        }else{
                            $outStr.= '<div class="detail-cmt-wrap box_hide detail-list__'.$val['id'].'">';
                        }
                            $outStr.= '<i class="detail-cmtr"></i>';
                            $outStr.= '<div class="detail-cmt">';
                                $outStr.= '<div class="like-list detail-collect__'.$val['id'].'">';
                                    $outStr.= '<span class="num">'.$val['collect'].'</span> '.lang("plugin/tom_tongcheng", "template_collect2");
                                    if($val['collect'] > 0){
                                        if(is_array($val['collectList']) && !empty($val['collectList'])){
                                            foreach($val['collectList'] as $kc => $vc){
                                                $outStr.= '<span><img src="'.$userList[$vc['user_id']]['picurl'].'"></span>';
                                            }
                                        }
                                    }
                                $outStr.= '</div>';
                            $outStr.= '</div>';
                            if($tongchengConfig['open_pinglun'] == 1){
                            if($val['pinglunCount'] > 0){
                                $outStr.= '<div class="detail-cmt detail-plugin__'.$val['id'].'">';
                            }else{
                                $outStr.= '<div class="detail-cmt box_hide detail-plugin__'.$val['id'].'">';
                            }
                                    $outStr.= '<div class="plugin-item">';
                                    if(is_array($val['pinglunList']) && !empty($val['pinglunList'])){
                                        foreach($val['pinglunList'] as $kp => $vp){
                                            $vp['content'] = cutstr($vp['content'], 60, '..');
                                            if($vp['touser_id'] > 0){
                                                $outStr.= '<a href="javascript:void(0);" class="replay-plugin__btn" data-id="'.$val['id'].'" data-touserid="'.$userList[$vp['user_id']]['id'].'" data-tonickname="'.$userList[$vp['user_id']]['nickname'].'"><span class="nick">'.$userList[$vp['user_id']]['nickname'].'</span>&nbsp;'.lang("plugin/tom_tongcheng", "pinglun_hueifu").'&nbsp;<span class="nick">'.$vp['touser_nickname'].lang("plugin/tom_tongcheng", "pinglun_hueifu_dian").'</span>&nbsp;'.$vp['content'].'</a>';
                                            }else{
                                                $outStr.= '<a href="javascript:void(0);" class="replay-plugin__btn" data-id="'.$val['id'].'" data-touserid="'.$userList[$vp['user_id']]['id'].'" data-tonickname="'.$userList[$vp['user_id']]['nickname'].'"><span class="nick">'.$userList[$vp['user_id']]['nickname'].lang("plugin/tom_tongcheng", "pinglun_hueifu_dian").'</span>&nbsp;'.$vp['content'].'</a>';
                                            }
                                        }
                                        if($val['pinglunCount'] > 5){
                                            $outStr.= '<a href="'.$val['infoUrl'].'">'.lang("plugin/tom_tongcheng", "ajax_look_more_plugin_1").$val['pinglunCount'].lang("plugin/tom_tongcheng", "ajax_look_more_plugin_2").'</a>';
                                        }
                                    }
                                    $outStr.= '</div>';
                                $outStr.= '</div>';
                            }
                        $outStr.= '</div>';
                    }
                $outStr.= '</div>';
            $outStr.= '</div>';
            
        }else if($template_type == 'tuwenlist'){
            
            $outStr.= '<div class="tuwenlist_item">';
                $outStr.= '<div class="tuwenlist_hd dislay-flex">';
                    $outStr.= '<div class="title flex">';
                        if(!empty($val['vipPicurl'])){
                            $outStr.= '<a class="user_pic" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'"><img src="'.$val['userInfo']['picurl'].'" class="avatar" /><img src="'.$val['vipPicurl'].'" class="guajian"></a>';
                        }else{
                            $outStr.= '<a class="user_pic" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'"><img class="avatar"  src="'.$val['userInfo']['picurl'].'"></a>';
                        }
                        if($val['topstatus'] == 1){
                            $outStr.= '<a class="typename" style="background-color: #f15555;">'.lang("plugin/tom_tongcheng", "top").'</a>&nbsp;';
                        }
                        if($val['companyRenzhengStatus'] == 1 || $val['personalRenzhengStatus'] == 1 || $val['depositStatus'] == 1){
                            $outStr.= '<a class="renzhenicon" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">';
                                if($val['companyRenzhengStatus'] == 1){
                                    $outStr.= '<i class="tciconfont tcicon-renzheng_company" style="color: #0592f7;"></i>';
                                }
                                if($val['personalRenzhengStatus'] == 1){
                                    $outStr.= '<i class="tciconfont tcicon-renzheng_personal" style="color: #3ebb3c;"></i>';
                                }
                                if($val['depositStatus'] == 1){
                                    $outStr.= '<i class="tciconfont tcicon-renzheng_deposit" style="color: #f9542f;"></i>';
                                }
                            $outStr.= '</a>&nbsp;';
                        }
                        if($tongchengConfig['list_title_type'] == 1){
                            $outStr.= '<a class="username" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">'.$val['userInfo']['nickname'].'</a>';
                        }else if($tongchengConfig['list_title_type'] == 2 && !empty ($val['xm'])){
                            $outStr.= '<a class="username" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">'.$val['xm'].'</a>';
                        }else if($tongchengConfig['list_title_type'] == 3 && !empty ($val['title'])){
                            $outStr.= '<a class="username" href="'.$val['infoUrl'].'">'.$val['title'].'</a>';
                        }else{
                            $outStr.= '<a class="username" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=home&uid='.$val['userInfo']['id'].'">'.$val['userInfo']['nickname'].'</a>';
                        }
                    $outStr.= '</div>';
                    $outStr.= '<div class="title_rt"><a class="typename tc-template__color" href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=list&type_id='.$val['typeInfo']['id'].'">'.$val['typeInfo']['name'].'</a></div>';
                $outStr.= '</div>';
                $outStr.= '<div class="tuwenlist_bd dislay-flex">';
                    $outStr.= '<div class="tuwenlist_item_details flex">';
                        $outStr.= '<div class="tuwen_sub dislay-flex">';
                            $outStr.= '<a class="tuwen_sub_lt flex"  href="'.$val['infoUrl'].'">';
                                if(is_array($val['tagList']) && !empty($val['tagList'])){
                                    $outStr.= '<div class="sub_lt_tags">';
                                        foreach ($val['tagList'] as $k1 => $v1){
                                         $outStr.= '<span class="span'.$k1.'">'.$v1['tag_name'].'</span>';
                                        }
                                        $outStr.= '<div class="clear"></div>';
                                    $outStr.= '</div>';
                                }
                                $outStr.= '<div class="sub_lt_content">'.$val['content'].'</div>';
                                $outStr.= '<div class="sub_lt_time">';
                                    $outStr.= '<span>'.$val['clicks'].lang("plugin/tom_tongcheng", "template_clicks").'</span>';
                                    if(($val['refresh_time'] - $val['add_time']) > 3600){
                                        $outStr.= '<span>'.lang("plugin/tom_tongcheng", "template_refresh_title").dgmdate($val['refresh_time'], 'u','9999','m-d H:i').'</span>';
                                    }else{
                                        $outStr.= '<span>'.dgmdate($val['refresh_time'], 'u','9999','m-d H:i').'</span>';
                                    }
                                    if($nearby == 1 && $val['typeInfo']['open_dingwei'] == 1 && $val['is_dingwei'] == 1 && !empty($val['address']) && $val['juli'] > 0){
                                        $outStr.= '&nbsp;&nbsp;<span>'.lang("plugin/tom_tongcheng", "template_juli").$val['juli'].'km</span>';
                                    }
                                $outStr.= '</div>';
                            $outStr.= '</a>';
                        $outStr.= '</div>';
                    $outStr.= '</div>';
                    if(is_array($val['photoList']) && !empty($val['photoList'])){
                        $photoFirstTmp = array_slice($val['photoList'], 0, 1);
                        $outStr.= '<a class="tuwenlist_item_pic" href="javascript:void(0);"  onclick="showPicList($(this),0);">';
                            $outStr.= '<img src="'.$photoFirstTmp[0]['picurl'].'">';
                            if($val['photoListCount'] > 1){
                                $outStr.= '<span class="num">'.$val['photoListCount'].lang("plugin/tom_tongcheng", "template_pic_unit").'</span>';
                            }
                        $outStr.= '</a>';
                        $outStr.= '<input type="hidden" name="photo_list" class="photo_list" value="'.implode('|', $val['albumList']).'"></div>';
                    }
                $outStr.= '</div>';
            $outStr.= '</div>';
        }
    }
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;