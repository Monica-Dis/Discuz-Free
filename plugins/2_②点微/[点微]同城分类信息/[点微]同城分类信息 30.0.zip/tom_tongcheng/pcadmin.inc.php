<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20201030";

$pcadminUrl = 'plugin.php?id=tom_tongcheng:pcadmin';
$ajaxUrl = 'plugin.php?id=tom_admin:ajax';
$uploadUrl = 'plugin.php?id=tom_admin:upload';
$baidumapUrl = 'plugin.php?id=tom_admin:baidumap';

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/config/pcadmin.lang.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

$Lang = $pcadminLang;

## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tcqianggou start
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
    $tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
    if($tcqianggouConfig['open_tcqianggou'] == 1){
        $__ShowTcqianggou = 1;
    }
}
## tcqianggou end
## tcptuan start
$__ShowTcptuan = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcptuan/tom_tcptuan.inc.php')){
    $tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
    if($tcptuanConfig['open_tcptuan'] == 1){
        $__ShowTcptuan = 1;
    }
}
## tcptuan end
## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcmall start
$__ShowTcmall = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcmall/tom_tcmall.inc.php')){
    $tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
    if($tcmallConfig['open_tcmall'] == 1){
        $__ShowTcmall = 1;
    }
}
## tcmall end
## tcdaojia start
$__ShowTcdaojia = 0;
$tcdaojiaConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/tom_tcdaojia.inc.php')){
    $tcdaojiaConfig = $_G['cache']['plugin']['tom_tcdaojia'];
    if($tcdaojiaConfig['open_tcdaojia'] == 1){
        $__ShowTcdaojia = 1;
    }
}
## tcdaojia end

include DISCUZ_ROOT.'./source/plugin/tom_admin/login_check.php';

if($_GET['tmod'] == 'list'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/list.php';
}else if($_GET['tmod'] == 'add'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/add.php';
}else if($_GET['tmod'] == 'edit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/edit.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/order.php';
}else if($_GET['tmod'] == 'user'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/user.php';
}else if($_GET['tmod'] == 'userform'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/userform.php';
}else if($_GET['tmod'] == 'pinglun'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/pinglun.php';
}else if($_GET['tmod'] == 'pmMessage'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/pmMessage.php';
}else if($_GET['tmod'] == 'tousu'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/tousu.php';
}else if($_GET['tmod'] == 'popup'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/popup.php';
}else if($_GET['tmod'] == 'popupadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/popupadd.php';
}else if($_GET['tmod'] == 'popupedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/popupedit.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/focuspic.php';
}else if($_GET['tmod'] == 'focuspicadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/focuspicadd.php';
}else if($_GET['tmod'] == 'focuspicedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/focuspicedit.php';
}else if($_GET['tmod'] == 'doDao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/doDao.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/pcadmin/list.php';
}