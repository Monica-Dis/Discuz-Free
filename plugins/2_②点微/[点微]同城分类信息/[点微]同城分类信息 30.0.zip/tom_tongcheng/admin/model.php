<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=model';
$modListUrl = $adminListUrl.'&tmod=model';
$modFromUrl = $adminFromUrl.'&tmod=model';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tongcheng#tom_tongcheng_model')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); /*dism��taobao��com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $modelInfo = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($modelInfo);
        C::t('#tom_tongcheng#tom_tongcheng_model')->update($modelInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*dism��taobao��com*/
        __create_info_html($modelInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'import'){
    
    include DISCUZ_ROOT.$tongchengConfig['admin_model_data'];
    
    foreach ($modelArr as $key => $value){
        $insertData = array();
        $insertData['name']     = $value['name'];
        $insertData['picurl']   = $value['picurl'];
        $insertData['paixu']    = $key;
        C::t('#tom_tongcheng#tom_tongcheng_model')->insert($insertData);
        $model_id = C::t('#tom_tongcheng#tom_tongcheng_model')->insert_id();
        
        foreach ($value['type'] as $k1 => $v1){
            $insertData = array();
            $insertData['model_id']     = $model_id;
            $insertData['name']         = $v1['name'];
            $insertData['cate_title']   = $v1['cate_title'];
            $insertData['desc_title']   = $v1['desc_title'];
            $insertData['desc_content'] = $v1['desc_content'];
            $insertData['warning_msg']  = $v1['warning_msg'];
            $insertData['paixu']        = $k1;
            C::t('#tom_tongcheng#tom_tongcheng_model_type')->insert($insertData);
            $type_id = C::t('#tom_tongcheng#tom_tongcheng_model_type')->insert_id();
            
            if(is_array($v1['cate']) && !empty($v1['cate'])){
                foreach ($v1['cate'] as $k2 => $v2){
                    $insertData = array();
                    $insertData['model_id']     = $model_id;
                    $insertData['type_id']      = $type_id;
                    $insertData['name']         = $v2;
                    $insertData['paixu']        = $k2;
                    C::t('#tom_tongcheng#tom_tongcheng_model_cate')->insert($insertData);
                }
            }
            
            if(is_array($v1['attr']) && !empty($v1['attr'])){
                foreach ($v1['attr'] as $k3 => $v3){
                    $insertData = array();
                    $insertData['model_id']     = $model_id;
                    $insertData['type_id']      = $type_id;
                    $insertData['name']         = $v3['name'];
                    $insertData['type']         = $v3['type'];
                    $insertData['value']        = implode("\n", $v3['list']);
                    $insertData['paixu']        = $k3;
                    C::t('#tom_tongcheng#tom_tongcheng_model_attr')->insert($insertData);
                }
            }
            
            if(is_array($v1['tag']) && !empty($v1['tag'])){
                foreach ($v1['tag'] as $k4 => $v4){
                    $insertData = array();
                    $insertData['model_id']     = $model_id;
                    $insertData['type_id']      = $type_id;
                    $insertData['name']         = $v4;
                    $insertData['paixu']        = $k4;
                    C::t('#tom_tongcheng#tom_tongcheng_model_tag')->insert($insertData);
                }
            }
            
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tongcheng#tom_tongcheng_model')->delete_by_id($_GET['id']);
    C::t('#tom_tongcheng#tom_tongcheng_model_type')->delete_by_model_id($_GET['id']);
    C::t('#tom_tongcheng#tom_tongcheng_model_attr')->delete_by_model_id($_GET['id']);
    C::t('#tom_tongcheng#tom_tongcheng_model_cate')->delete_by_model_id($_GET['id']);
    C::t('#tom_tongcheng#tom_tongcheng_model_tag')->delete_by_model_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['model_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['model_help_1'] . '</li>';
    echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=import&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['model_import'].'</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $modelList = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(" "," ORDER BY paixu ASC,id DESC ",$start,$pagesize);
    $count = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_count(" ");
    __create_nav_html();
    showtableheader(); /*dism��taobao��com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['model_id'] . '</th>';
    echo '<th>' . $Lang['model_picurl'] . '</th>';
    echo '<th>' . $Lang['model_name'] . '</th>';
    echo '<th>' . $Lang['type_free_status'] . '</th>';
    echo '<th>' . $Lang['type_price'] . '</th>';
    echo '<th>' . $Lang['type_open_tel_price'] . '</th>';
    echo '<th>' . $Lang['type_jifei_type'] . '</th>';
    echo '<th>' . $Lang['model_num'] . '</th>';
    echo '<th>' . $Lang['model_must_shenhe'] . '</th>';
    echo '<th>' . $Lang['model_only_editor'] . '</th>';
    echo '<th>' . $Lang['type_open_video'] . '</th>';
    echo '<th>' . $Lang['type_close_tel'] . '</th>';
    echo '<th>' . $Lang['model_is_show'] . '</th>';
    echo '<th>' . $Lang['model_paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($modelList as $key => $value) {
        
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        $modelCountTmp          = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count(" AND model_id={$value['id']} ");
        
        $modelUrl = $adminBaseUrl.'&tmod=index';
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><img src="'.$picurl.'" width="40" /></td>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>&nbsp;</td>';
        echo '<td>&nbsp;</td>';
        echo '<td>&nbsp;</td>';
        echo '<td>&nbsp;</td>';
        echo '<td><font color="#f00">' . $modelCountTmp . '</font>&nbsp;<a href="'.$modelUrl.'&model_id='.$value['id'].'"><font color="#928c8c">(' . $Lang['model_num_chakan'] . ')</font></a></td>';
        if($value['must_shenhe'] == 1){
            echo '<td><font color="#fd0d0d">' . $Lang['model_must_shenhe_1'] . '</font></td>';
        }else{
            echo '<td><font color="#238206">' . $Lang['model_must_shenhe_0'] . '</font></td>';
        }
        if($value['only_editor'] == 1){
            echo '<td><font color="#fd0d0d">' . $Lang['model_only_editor_1'] . '</font></td>';
        }else{
            echo '<td><font color="#238206">' . $Lang['model_only_editor_0'] . '</font></td>';
        }
        echo '<td>&nbsp;</td>';
        echo '<td>&nbsp;</td>';
        if($value['is_show'] == 1){
            echo '<td><font color="#238206"><b>' . $Lang['model_is_show_1'] . '</b></font></td>';
        }else{
            echo '<td><font color="#fd0d0d"><b>' . $Lang['model_is_show_0'] . '</b></font></td>';
        }
        echo '<td>' . $value['paixu'] . '</td>';
        echo '<td>';
        echo '<a href="'.$adminBaseUrl.'&tmod=type&act=add&model_id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#FA6A03">' . $Lang['type_add']. '</font></a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['model_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $typeList = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_all_list(" AND model_id={$value['id']} "," ORDER BY paixu ASC,id DESC ",0,50);
        
        if(is_array($typeList) && !empty($typeList) && $tongchengConfig['admin_tongcheng_type_list'] == 1){
            foreach ($typeList as $kk => $vv){
                $typeCountTmp          = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count(" AND type_id={$vv['id']} ");
                echo '<tr>';
                echo '<td>&nbsp;</td>';
                echo '<td>&nbsp;</td>';
                echo '<td><font color="#FA6A03">|--</font> ' . $vv['name'] . '<font color="#fd0d0d">(ID:'.$vv['id'].')</font></td>';
                if($vv['free_status'] == $tongchengConfig['admin_tongcheng_type_free_status_1']){
                    echo '<td><font color="#0a9409">' . $Lang['type_free_status_1'] . '</font></td>';
                }else if($vv['free_status'] == $tongchengConfig['admin_tongcheng_type_free_status_2']){
                    echo '<td><font color="#f00">' . $Lang['type_free_status_2'] . '</font></td>';
                }else{
                    echo '<td>-</td>';
                }
                echo '<td><font color="#f00">' . $vv['fabu_price'].'</font>'. $Lang['type_price_fabu'].'&nbsp;,&nbsp;<font color="#f00">'. $vv['refresh_price'].'</font>'. $Lang['type_price_refresh'] .'&nbsp;</td>';
                if($vv['open_tel_price'] == 0){
                    echo '<td><font color="#0a9409">' . $Lang['type_open_tel_price_0'] . '</font></td>';
                }else if($vv['open_tel_price'] == 1){
                    echo '<td><font color="#f00">' . $vv['tel_price'].'</font>'. $Lang['type_price_tel'].'</td>';
                }else{
                    echo '<td>-</td>';
                }
                if($vv['jifei_type'] == 2){
                    echo '<td>' . $Lang['type_jifei_type_2'] . '</td>';
                }else{
                    echo '<td>' . $Lang['type_jifei_type_1'] . '</td>';
                }
                echo '<td><font color="#f00">' . $typeCountTmp . '</font>&nbsp;<a href="'.$modelUrl.'&model_id='.$value['id'].'"><font color="#928c8c">(' . $Lang['model_num_chakan'] . ')</font></a></td>';
                echo '<td>&nbsp;</td>';
                echo '<td>&nbsp;</td>';
                if($vv['open_video'] == 1){
                    echo '<td><font color="#238206">' . $Lang['type_open_video_1'] . '</font></td>';
                }else{
                    echo '<td><font color="#fd0d0d">' . $Lang['type_open_video_0'] . '</font></td>';
                }
                if($vv['close_tel'] == 1){
                    echo '<td><font color="#238206">' . $Lang['type_close_tel_1'] . '</font></td>';
                }else{
                    echo '<td><font color="#fd0d0d">' . $Lang['type_close_tel_0'] . '</font></td>';
                }
                echo '<td>&nbsp;</td>';
                echo '<td>' . $vv['paixu'] . '</td>';
                echo '<td>';
                if($value['type'] == 2){
                    echo '<a href="'.$adminBaseUrl.'&tmod=type&act=sfc&model_id='.$value['id'].'&id='.$vv['id'].'&formhash='.FORMHASH.'"><font color="#238206">' . $Lang['edit_sfc_title']. '</font></a>&nbsp;|&nbsp;';
                }
                echo '<a href="'.$adminBaseUrl.'&tmod=type&act=edit&model_id='.$value['id'].'&id='.$vv['id'].'&formhash='.FORMHASH.'">' . $Lang['type_edit']. '</a>&nbsp;|&nbsp;';
                echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$adminBaseUrl.'&tmod=type&act=del&model_id='.$value['id'].'&id='.$vv['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
                echo '</td>';
                echo '</tr>';
            }
        }
        
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function import_confirm(url){
  var r = confirm("{$Lang['makesure_import_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function sfc_confirm(url){
  var r = confirm("{$Lang['makesure_sfc_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name        = isset($_GET['name'])? addslashes($_GET['name']):'';
    $area_select = isset($_GET['area_select'])? intval($_GET['area_select']):0;
    $type        = isset($_GET['type'])? intval($_GET['type']):1;
    $must_shenhe = isset($_GET['must_shenhe'])? intval($_GET['must_shenhe']):0;
    $only_editor = isset($_GET['only_editor'])? intval($_GET['only_editor']):0;
    $open_fabu_title = isset($_GET['open_fabu_title'])? intval($_GET['open_fabu_title']):0;
    $is_show     = isset($_GET['is_show'])? intval($_GET['is_show']):1;
    $close_fabu  = isset($_GET['close_fabu'])? intval($_GET['close_fabu']):0;
    $sites_show  = isset($_GET['sites_show'])? intval($_GET['sites_show']):0;
    $paixu       = isset($_GET['paixu'])? intval($_GET['paixu']):100;
    
    $share_title        = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc         = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $template_type      = isset($_GET['template_type'])? addslashes($_GET['template_type']):'';
    
    $list_nav_style     = isset($_GET['list_nav_style'])? intval($_GET['list_nav_style']):1;
    
    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    $share_logo = "";
    if($_GET['act'] == 'add'){
        $share_logo        = tomuploadFile("share_logo");
    }else if($_GET['act'] == 'edit'){
        $share_logo        = tomuploadFile("share_logo",$infoArr['share_logo']);
    }

    $data['name']           = $name;
    $data['picurl']         = $picurl;
    $data['type']           = $type;
    $data['list_nav_style'] = $list_nav_style;
    $data['area_select']    = $area_select;
    $data['must_shenhe']    = $must_shenhe;
    $data['only_editor']    = $only_editor;
    $data['open_fabu_title']= $open_fabu_title;
    $data['is_show']        = $is_show;
    $data['close_fabu']     = $close_fabu;
    $data['sites_show']     = $sites_show;
    $data['share_title']    = $share_title;
    $data['share_desc']     = $share_desc;
    $data['share_logo']     = $share_logo;
    $data['template_type']  = $template_type;
    $data['paixu']          = $paixu;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'           => '',
        'picurl'         => '',
        'type'           => 1,
        'list_nav_style' => 1,
        'area_select'    => 0,
        'must_shenhe'    => 0,
        'only_editor'    => 0,
        'open_fabu_title'=> 0,
        'is_show'        => 0,
        'close_fabu'     => 0,
        'sites_show'     => 0,
        'share_title'    => '',
        'share_desc'     => '',
        'share_logo'     => '',
        'template_type'  => '',
        'paixu'          => 100,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['model_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['model_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['model_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['model_picurl_msg']),"file");
    $type_item = array(1=>$Lang['model_type_1'],2=>$Lang['model_type_2']);
    tomshowsetting(true,array('title'=>$Lang['model_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['model_type_msg'],'item'=>$type_item),"radio");
    $template_type_item = array(''=>$Lang['model_template_type_null'],'default'=>$Lang['model_template_type_default'],'kuanlist'=>$Lang['model_template_type_kuanlist'],'tuwenlist'=>$Lang['model_template_type_tuwenlist']);
    tomshowsetting(true,array('title'=>$Lang['model_template_type'],'name'=>'template_type','value'=>$options['template_type'],'msg'=>$Lang['model_template_type_msg'],'item'=>$template_type_item),"select");
    $list_nav_style_item = array(1=>$Lang['model_list_nav_style_1'],2=>$Lang['model_list_nav_style_2'],3=>$Lang['model_list_nav_style_3']);
    tomshowsetting(true,array('title'=>$Lang['model_list_nav_style'],'name'=>'list_nav_style','value'=>$options['list_nav_style'],'msg'=>$Lang['model_list_nav_style_msg'],'item'=>$list_nav_style_item),"select");
    $area_select_item = array(0=>$Lang['model_area_select_0'],1=>$Lang['model_area_select_1']);
    tomshowsetting(true,array('title'=>$Lang['model_area_select'],'name'=>'area_select','value'=>$options['area_select'],'msg'=>$Lang['model_area_select_msg'],'item'=>$area_select_item),"radio");
    $must_shenhe_item = array(0=>$Lang['model_must_shenhe_0'],1=>$Lang['model_must_shenhe_1']);
    tomshowsetting(true,array('title'=>$Lang['model_must_shenhe'],'name'=>'must_shenhe','value'=>$options['must_shenhe'],'msg'=>$Lang['model_must_shenhe_msg'],'item'=>$must_shenhe_item),"radio");
    $open_fabu_title_item = array(0=>$Lang['model_open_fabu_title_0'],1=>$Lang['model_open_fabu_title_1']);
    tomshowsetting(true,array('title'=>$Lang['model_open_fabu_title'],'name'=>'open_fabu_title','value'=>$options['open_fabu_title'],'msg'=>$Lang['model_open_fabu_title_msg'],'item'=>$open_fabu_title_item),"radio");
    $only_editor_item = array(0=>$Lang['model_only_editor_0'],1=>$Lang['model_only_editor_1']);
    tomshowsetting(true,array('title'=>$Lang['model_only_editor'],'name'=>'only_editor','value'=>$options['only_editor'],'msg'=>$Lang['model_only_editor_msg'],'item'=>$only_editor_item),"radio");
    $is_show_item = array(0=>$Lang['model_is_show_0'],1=>$Lang['model_is_show_1']);
    tomshowsetting(true,array('title'=>$Lang['model_is_show'],'name'=>'is_show','value'=>$options['is_show'],'msg'=>$Lang['model_is_show_msg'],'item'=>$is_show_item),"radio");
    $close_fabu_item = array(0=>$Lang['model_close_fabu_0'],1=>$Lang['model_close_fabu_1']);
    tomshowsetting(true,array('title'=>$Lang['model_close_fabu'],'name'=>'close_fabu','value'=>$options['close_fabu'],'msg'=>$Lang['model_close_fabu_msg'],'item'=>$close_fabu_item),"radio");
    $sites_show_item = array(0=>$Lang['model_sites_show_0'],1=>$Lang['model_sites_show_1']);
    tomshowsetting(true,array('title'=>$Lang['model_sites_show'],'name'=>'sites_show','value'=>$options['sites_show'],'msg'=>$Lang['model_sites_show_msg'],'item'=>$sites_show_item),"radio");
    
    tomshowsetting(true,array('title'=>$Lang['model_share_title'],'name'=>'share_title','value'=>$options['share_title'],'msg'=>$Lang['model_share_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['model_share_desc'],'name'=>'share_desc','value'=>$options['share_desc'],'msg'=>$Lang['model_share_desc_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['model_share_logo'],'name'=>'share_logo','value'=>$options['share_logo'],'msg'=>$Lang['model_share_logo_msg']),"file");
    
    tomshowsetting(true,array('title'=>$Lang['model_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['model_paixu_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['model_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['model_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['model_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['model_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['model_edit'],"",true);
    }else{
        tomshownavli($Lang['model_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['model_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}


