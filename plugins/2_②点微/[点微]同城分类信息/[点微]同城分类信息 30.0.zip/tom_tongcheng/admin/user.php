<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=user';
$modListUrl = $adminListUrl.'&tmod=user';
$modFromUrl = $adminFromUrl.'&tmod=user';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

if($_GET['act'] == 'edit'){
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $nickname               = isset($_GET['nickname'])? addslashes($_GET['nickname']):'';
        $tj_hehuoren_id         = intval($_GET['tj_hehuoren_id'])>0?intval($_GET['tj_hehuoren_id']):0;
        $tixian_shouxufei_bili  = floatval($_GET['tixian_shouxufei_bili'])>0? floatval($_GET['tixian_shouxufei_bili']):0;
        
        if(isset($_FILES['picurl'])) {
            $upload = new tom_upload();
            if(!$upload->init($_FILES['picurl'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }
            require_once libfile('class/image');
            $image = new image();
            $image->Thumb($upload->attach['target'], '', 200, 200, 2, 1);
            $picurl = 'data/attachment/tomwx/'.$upload->attach['attachment'];
        }else{
            $picurl = addslashes($_GET['picurl']);
        }
        
        $updateData = array();
        $updateData['nickname']                 = $nickname;
        $updateData['tj_hehuoren_id']           = $tj_hehuoren_id;
        $updateData['tixian_shouxufei_bili']    = $tixian_shouxufei_bili;
        $updateData['picurl']                   = $picurl;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'].'&formhash='.FORMHASH,'enctype');
        showtableheader(); /*dism��taobao��com*/
        echo '<tr><th colspan="15" class="partition">' .$userInfo['nickname'].'&nbsp;>>&nbsp;'.$Lang['user_edit_title']. '</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['user_nickname'],'name'=>'nickname','value'=>$userInfo['nickname'],'msg'=>''),"input");
        tomshowsetting(true,array('title'=>$Lang['user_tj_hehuoren'],'name'=>'tj_hehuoren_id','value'=>$userInfo['tj_hehuoren_id'],'msg'=>''),"input");
        tomshowsetting(true,array('title'=>$Lang['user_tixian_shouxufei_bili'],'name'=>'tixian_shouxufei_bili','value'=>$userInfo['tixian_shouxufei_bili'],'msg'=>$Lang['user_tixian_shouxufei_bili_msg']),"input");
        showsetting($Lang['user_picurl'],'picurl', $userInfo['picurl'], 'filetext',0,0,'<a target="_blank" href="'.$userInfo['picurl'].'"><img src="'.$userInfo['picurl'].'" width="100" /></a>');
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
}else if($_GET['act'] == 'addmoney' && $_GET['formhash'] == FORMHASH){
    
    $user_id    = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $money      = isset($_GET['money'])? floatval($_GET['money']):0;
    $type       = isset($_GET['type'])? intval($_GET['type']):0;
    $beizu      = isset($_GET['beizu'])? addslashes($_GET['beizu']):'';
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    if($type == 1){
        
        $updateData = array();
        $updateData['money'] = $userInfo['money'] + $money;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'], $updateData);
        
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type_id']      = 2;
        $insertData['change_money'] = $money;
        $insertData['old_money']    = $userInfo['money'];
        $insertData['tag']          = $Lang['moneylog_admin_type1'];
        $insertData['beizu']        = $beizu;
        $insertData['log_ip']       = $_G['clientip'];
        $insertData['log_time']     = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
        
    }else if($type == 2){
        
        $shengyuMoney = $userInfo['money'] - $money;
        if($shengyuMoney < 0){
            $shengyuMoney = 0;
            $money = $userInfo['money'];
        }
        
        $updateData = array();
        $updateData['money'] = $shengyuMoney;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'], $updateData);
        
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type_id']      = 3;
        $insertData['change_money'] = $money;
        $insertData['old_money']    = $userInfo['money'];
        $insertData['tag']          = $Lang['moneylog_admin_type2'];
        $insertData['beizu']        = $beizu;
        $insertData['log_ip']       = $_G['clientip'];
        $insertData['log_time']     = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
        
    }
    
    cpmsg($Lang['act_success'], $modListUrl.'&act=moneylog&user_id='.$user_id, 'succeed');
    
}else if($_GET['act'] == 'moneylog'){
    
    $user_id = intval($_GET['user_id'])>0?intval($_GET['user_id']):0;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    if($_G['uid'] == 1){
        tomshownavheader();
        tomshownavli($userInfo['nickname'],"",true);
        tomshownavli(' > '.$Lang['moneylog_money'].' '.$userInfo['money'],"",true);
        tomshownavfooter();
        showformheader($modFromUrl.'&act=addmoney&user_id='.$user_id.'&formhash='.$formhash,'enctype');
        showtableheader(); /*dism��taobao��com*/
        tomshowsetting(true,array('title'=>$Lang['moneylog_num'],'name'=>'money','value'=>$options['money'],'msg'=>$Lang['moneylog_num_msg']),"input");
        $type_item = array(1=>$Lang['moneylog_type1'],2=>$Lang['moneylog_type2']);
        tomshowsetting(true,array('title'=>$Lang['moneylog_type'],'name'=>'type','value'=>1,'msg'=>$Lang['moneylog_type_msg'],'item'=>$type_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['moneylog_beizu'],'name'=>'beizu','value'=>$options['beizu'],'msg'=>$Lang['moneylog_beizu_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
    tomshownavheader();
    tomshownavli($userInfo['nickname'],"",true);
    tomshownavli(' > '.$Lang['moneylog_list_title'],"",true);
    tomshownavfooter();
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tongcheng#tom_tongcheng_money_log')->fetch_all_count(" AND user_id={$user_id} ");
    $moneyLogList = C::t('#tom_tongcheng#tom_tongcheng_money_log')->fetch_all_list(" AND user_id={$user_id} "," ORDER BY id DESC ",$start,$pagesize);
    
    showtableheader(); /*dism��taobao��com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['moneylog_tag'] . '</th>';
    echo '<th>' . $Lang['moneylog_change_money'] . '</th>';
    echo '<th>' . $Lang['moneylog_old_money'] . '</th>';
    echo '<th>' . $Lang['moneylog_beizu'] . '</th>';
    echo '<th>IP</th>';
    echo '<th>' . $Lang['moneylog_log_time'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($moneyLogList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['tag'] . '</td>';
        if($value['type_id'] == 1 || $value['type_id'] == 3){
            echo '<td><font color="#238206">-' . $value['change_money'] . '</font></td>';
        }else{
            echo '<td><font color="#fd0d0d">+' . $value['change_money'] . '</font></td>';
        }
        
        echo '<td><font color="#8e8e8e">' . $value['old_money'] . '</font></td>';
        echo '<td>';
        if($value['type_id'] == 1){
            $tixianInfo = C::t('#tom_tongcheng#tom_tongcheng_money_tixian')->fetch_by_id($value['tixian_id']);
            if($tixianInfo['status'] == 1){
                echo '<font color="#fd0d0d">' . $Lang['tixian_status_1'] . '</font>';
            }else if($tixianInfo['status'] == 2){
                echo '<font color="#238206">' . $Lang['tixian_status_2'] . '</font>';
            }
        }else{
            echo '' . $value['beizu'] . '';
        }
        echo '</td>';
        echo '<td>' . $value['log_ip'] . '</td>';
        echo '<td>' . dgmdate($value['log_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl."&act=moneylog&user_id=".$user_id);	
    showsubmit('', '', '', '', $multi, false);
    
}else if($act == 'addqunfa'){
    
    $type   = isset($_GET['type'])? intval($_GET['type']):1;
    
    if(submitcheck('submit')){
        
        $title      = isset($_GET['title'])? addslashes($_GET['title']):'';
        $title      = urlencode($title);
        $content    = isset($_GET['content'])? addslashes($_GET['content']):'';
        $content    = urlencode($content);
        $link       = isset($_GET['link'])? addslashes($_GET['link']):'';
        $link       = urlencode($link);
        
        $modQunfaListUrl = $modListUrl.'&act=doqunfa&type='.$type.'&title='.$title.'&content='.$content.'&link='.$link.'&formhash='.FORMHASH;
        cpmsg($Lang['qunfa_add_msg'], $modQunfaListUrl, 'loadingform');
    }else{
        
        showformheader($modFromUrl.'&act=addqunfa&formhash='.FORMHASH);
        showtableheader(); /*dism��taobao��com*/
        echo '<tr><th colspan="15" class="partition">' .$Lang['user_doqunfa_title']. '</th></tr>';
        $type_item = array(1=>$Lang['user_addqunfa_type_1'],2=>$Lang['user_addqunfa_type_2'],3=>$Lang['user_addqunfa_type_3']);
        tomshowsetting(true,array('title'=>$Lang['user_addqunfa_type'],'name'=>'type','value'=>$type,'msg'=>$Lang['user_addqunfa_type_msg'],'item'=>$type_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['user_addqunfa_title'],'name'=>'title','value'=>'','msg'=>$Lang['user_addqunfa_title_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['user_addqunfa_content'],'name'=>'content','value'=>'','msg'=>$Lang['user_addqunfa_content_msg']),"textarea");
        tomshowsetting(true,array('title'=>$Lang['user_addqunfa_link'],'name'=>'link','value'=>'','msg'=>$Lang['user_addqunfa_link_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
}else if($act == 'send_sms'){
    
    $user_id = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    
    if(submitcheck('submit')){
        
        $send_user_id   = isset($_GET['send_user_id'])? intval($_GET['send_user_id']):0;
        $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
        $content        = dhtmlspecialchars($content);
        
        
        if($user_id == $send_user_id){
            cpmsg($Lang['user_send_sms_error_301'], $modListUrl.'&act=send_sms&user_id='.$user_id, 'error');
        }
        
        $toUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
        if($toUserInfo['id'] > 0){ }else{
            cpmsg($Lang['user_send_sms_error_302'], $modListUrl.'&act=send_sms&user_id='.$user_id, 'error');
        }
        
        $sendUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($send_user_id);
        if($sendUserInfo['id'] > 0){ }else{
            cpmsg($Lang['user_send_sms_error_303'], $modListUrl.'&act=send_sms&user_id='.$user_id, 'error');
        }
        
        $max_use_id = $min_use_id = 0;
        if($user_id > $send_user_id){
            $max_use_id = $user_id;
            $min_use_id = $send_user_id;
        }else if($user_id < $send_user_id){
            $max_use_id = $send_user_id;
            $min_use_id = $user_id;
        }
        $pmListTmp = C::t('#tom_tongcheng#tom_tongcheng_pm_lists')->fetch_all_list(" AND min_use_id={$min_use_id} AND max_use_id={$max_use_id} "," ORDER BY id DESC ",0,1);

        if(is_array($pmListTmp) && !empty($pmListTmp[0]['id']) ){
            $pm_lists_id = $pmListTmp[0]['id'];
        }else{
            $insertData = array();
            $insertData['user_id']      = $send_user_id;
            $insertData['min_use_id']   = $min_use_id;
            $insertData['max_use_id']   = $max_use_id;
            $insertData['last_content'] = 'NULL-NULL-NULL-NULL-NULL-NULL';
            $insertData['last_time']    = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_pm_lists')->insert($insertData);
            $pm_lists_id = C::t('#tom_tongcheng#tom_tongcheng_pm_lists')->insert_id();

            $insertData = array();
            $insertData['user_id']      = $send_user_id;
            $insertData['pm_lists_id']  = $pm_lists_id;
            $insertData['new_num']      = 0;
            $insertData['last_time']    = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_pm')->insert($insertData);

            $insertData = array();
            $insertData['user_id']      = $user_id;
            $insertData['pm_lists_id']  = $pm_lists_id;
            $insertData['new_num']      = 0;
            $insertData['last_time']    = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_pm')->insert($insertData);
        }
        
        $insertData = array();
        $insertData['user_id']      = $send_user_id;
        $insertData['pm_lists_id']  = $pm_lists_id;
        $insertData['content']      = $content;
        $insertData['add_time']     = TIMESTAMP;
        if(C::t('#tom_tongcheng#tom_tongcheng_pm_message')->insert($insertData)){

            $updateData = array();
            $updateData['last_content'] = $content;
            $updateData['last_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_pm_lists')->update($pm_lists_id,$updateData);

            DB::query("UPDATE ".DB::table('tom_tongcheng_pm')." SET new_num=new_num+1,last_time='".TIMESTAMP."' WHERE user_id='$user_id' AND pm_lists_id='$pm_lists_id' ", 'UNBUFFERED');

            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
            $appid = trim($tongchengConfig['wxpay_appid']);
            $appsecret = trim($tongchengConfig['wxpay_appsecret']);
            $weixinClass = new weixinClass($appid,$appsecret);
            $access_token = $weixinClass->get_access_token();
            $nextSmsTime = $toUserInfo['last_smstp_time'] + 60;

            if($access_token && !empty($toUserInfo['openid']) && TIMESTAMP > $nextSmsTime ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=message");
                $message_template_first = str_replace("{NICKNAME}",$sendUserInfo['nickname'], lang('plugin/tom_tongcheng','message_template_first'));
                $smsData = array(
                    'first'         => $message_template_first,
                    'keyword1'      => $tongchengConfig['plugin_name'],
                    'keyword2'      => $content,
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUserInfo['openid'],$tongchengConfig['template_id'],$smsData);

                if($r){
                    $updateData = array();
                    $updateData['last_smstp_time'] = TIMESTAMP;
                    C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUserInfo['id'],$updateData);
                }

            }
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
        
    }else{
        
        showformheader($modFromUrl.'&act=send_sms&user_id='.$user_id.'&formhash='.FORMHASH);
        showtableheader(); /*dism��taobao��com*/
        tomshowsetting(true,array('title'=>$Lang['user_send_sms_user'],'name'=>'send_user_id','value'=>$tongchengConfig['manage_user_id'],'msg'=>$Lang['user_send_sms_user_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['user_send_sms_content'],'name'=>'content','value'=>'','msg'=>$Lang['user_send_sms_content_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
}else if($formhash == FORMHASH && $act == 'doqunfa'){
    
    $type   = isset($_GET['type'])? intval($_GET['type']):1;
    $page           = isset($_GET['page'])? intval($_GET['page']):1;
    $nextpage = $page + 1;
    
    $title      = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title      = urldecode($title);
    $content    = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content    = urldecode($content);
    $link       = isset($_GET['link'])? addslashes($_GET['link']):'';
    $link       = urldecode($link);
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    
    $where = " AND status=1 ";
    
    $count = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_count($where,"","");
    $allPageNum = ceil($count/$pagesize);
    
    if($type == 1 && $count > 500){
        $allPageNum = 5;
    }
    
    if($type == 2 && $count > 1000){
        $allPageNum = 10;
    }
    
    if($page <= $allPageNum){
        
        $order = ' ORDER BY last_login_time DESC ';
        if($type == 3){
            $order = ' ORDER BY id ASC ';
        }
        
        $userList = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_list($where,$order,$start,$pagesize);
        
        $txt = '';
        if(!empty($title)){
            $txt.= '<font color="#238206">'.$title.'</font><br/>';
        }
        $txt.= $content;
        if(!empty($link)){
            $txt.= '<br/><a href="'.$link.'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }
        
        if(is_array($userList) && !empty($userList)){
            foreach ($userList as $key => $value){
                
                $insertData = array();
                $insertData['user_id']     = $value['id'];
                $insertData['type']        = 1;
                $insertData['content']     = $txt;
                $insertData['tz_time']     = TIMESTAMP;
                $insertData['is_read']     = 0;
                C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
            }
        }
        
        $qunfa_do_msg = str_replace("{PAGES}", $page, $Lang['qunfa_do_msg']);
        $qunfa_do_msg = str_replace("{COUNT}", $allPageNum, $qunfa_do_msg);
        
        $modQunfaListUrl = $modListUrl.'&act=doqunfa&type='.$type.'&title='.$_GET['title'].'&content='.$_GET['content'].'&link='.$_GET['link'].'&page='.$nextpage.'&formhash='.FORMHASH;
        cpmsg($qunfa_do_msg, $modQunfaListUrl, 'loadingform');
        
    }else{
        cpmsg($Lang['qunfa_do_success'], $modListUrl, 'succeed');
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'ok'){
    
    $updateData = array();
    $updateData['status']           = 1;
    $updateData['fenghao_time']     = 0;
    $updateData['fenghao_msg']      = '';
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'fenhao'){
    
    $fenghaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($_GET['id']); 
    
    if(submitcheck('submit')){
        
        $fenghao_time   = intval($_GET['fenghao_time'])>0? intval($_GET['fenghao_time']):0;
        $fenghao_msg    = isset($_GET['fenghao_msg'])? daddslashes($_GET['fenghao_msg']):'';

        $fenghao_end_time = 999;
        if($fenghao_time == 2){
            $fenghao_end_time = TIMESTAMP + 86400*7;
        }else if($fenghao_time == 3){
            $fenghao_end_time = TIMESTAMP + 86400*30;
        }else if($fenghao_time == 4){
            $fenghao_end_time = TIMESTAMP + 86400*90;
        }

        $updateData = array();
        $updateData['status']           = 2;
        $updateData['fenghao_time']     = $fenghao_end_time;
        $updateData['fenghao_msg']      = $fenghao_msg;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($fenghaoUserInfo['id'],$updateData);

        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2 WHERE user_id='{$fenghaoUserInfo['id']}' ", 'UNBUFFERED');
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        
        showformheader($modFromUrl.'&act=fenhao&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader(); /*dism��taobao��com*/
        echo '<tr><th colspan="15" class="partition">' .$fenghaoUserInfo['nickname'].'&nbsp;>>&nbsp;'.$Lang['user_fenghao_title']. '</th></tr>';
        $fenghao_time_item = array(1=>$Lang['user_fenghao_time1'],2=>$Lang['user_fenghao_time2'],3=>$Lang['user_fenghao_time3'],4=>$Lang['user_fenghao_time4']);
        tomshowsetting(true,array('title'=>$Lang['user_fenghao_time'],'name'=>'fenghao_time','value'=>1,'msg'=>$Lang['user_fenghao_time_msg'],'item'=>$fenghao_time_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['user_fenghao_msg'],'name'=>'fenghao_msg','value'=>'','msg'=>$Lang['user_fenghao_msg_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'add_editor'){
    
    $updateData = array();
    $updateData['editor']     = 1;
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del_editor'){
    
    $updateData = array();
    $updateData['editor']     = 0;
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $user_id = !empty($_GET['user_id'])? addslashes($_GET['user_id']):0;
    $nickname = !empty($_GET['nickname'])? addslashes($_GET['nickname']):'';
    $tel = !empty($_GET['tel'])? addslashes($_GET['tel']):'';
    $editor = !empty($_GET['editor'])? intval($_GET['editor']):0;
    $status = !empty($_GET['status'])? intval($_GET['status']):0;
    
    $where = "";
    if(!empty($user_id)){
        $where.= " AND id=$user_id ";
    }
    if(!empty($tel)){
        $where.= " AND tel='$tel' ";
    }
    if(!empty($editor)){
        $where.= " AND editor=1 ";
    }
    if(!empty($status) && $status == 2){
        $where.= " AND status=2 ";
    }
    
    $pagesize = 10;
    if(!empty($nickname)){
		$pagesize = 1000;
	}
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_like_count($where,$nickname);
    $userList = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_like_list($where,"ORDER BY add_time DESC",$start,$pagesize,$nickname);
    
    $modBaseUrl = $modBaseUrl."&editor={$editor}&status={$status}";
    
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['user_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><font color="#fd0d0d">' . $Lang['user_help_1'] . '</font></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['user_search_list'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['user_id'] . '</b></td><td><input name="user_id" type="text" value="'.$user_id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['user_nickname'] . '</b></td><td><input name="nickname" type="text" value="'.$nickname.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['user_tel'] . '</b></td><td><input name="tel" type="text" value="'.$tel.'" size="40" /></td></tr>';
    
    $editorStr = '<tr><td width="100" align="right"><b>'.$Lang['user_editor'].'</b></td>';
    $editorStr.= '<td><select style="width: 260px;" name="editor" id="editor">';
    $editorStr.=  '<option value="0">'.$Lang['user_editor'].'</option>';
    $editorStr.=  '<option value="1">'.$Lang['user_editor_1'].'</option>';
    $editorStr.= '</select></td></tr>';
    echo $editorStr;
    
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['user_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['user_status'].'</option>';
    $statusStr.=  '<option value="2">'.$Lang['user_status_2'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/
    
    tomshownavheader();
    tomshownavli($Lang['user_doqunfa_title'],$modBaseUrl.'&act=addqunfa',false);
    tomshownavfooter();
    
    $allmoneyPrice = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_money_sum(" ");
    echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;margin-top: 10px;" >&nbsp;&nbsp;';
    echo $Lang['user_allmoney_title'] .'<font color="#fd0d0d">('.$allmoneyPrice.')</font>&nbsp;&nbsp;';
    echo '</div>';
    
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['user_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['user_id'] . '</th>';
    echo '<th>' . $Lang['user_picurl'] . '</th>';
    echo '<th>' . $Lang['user_nickname'] . '</th>';
    echo '<th>' . $Lang['user_tel'] . '</th>';
    echo '<th>' . $Lang['user_openid'] . '</th>';
    echo '<th>' . $Lang['user_tj_hehuoren'] . '</th>';
    echo '<th>' . $Lang['user_money'] . '</th>';
    echo '<th>' . $Lang['user_score'] . '</th>';
    echo '<th>' . $Lang['user_counts'] . '</th>';
    echo '<th>' . $Lang['user_editor'] . '</th>';
    echo '<th>' . $Lang['user_majia'] . '</th>';
    echo '<th width=100>' . $Lang['user_status'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($userList as $key => $value){
        $userCountTmp        = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count(" AND user_id={$value['id']} ");
        $pinglunCountTmp     = C::t('#tom_tongcheng#tom_tongcheng_pinglun')->fetch_all_count(" AND user_id={$value['id']} ");
        $pmCountTmp          = C::t('#tom_tongcheng#tom_tongcheng_pm_message')->fetch_all_count(" AND user_id={$value['id']} ");
        
        if($value['tj_hehuoren_id'] > 0 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
            $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($value['tj_hehuoren_id']);
            $tjHehuoren = '<font color="#0a9409">'.$tchehuorenInfoTmp['xm'].'('.$tchehuorenInfoTmp['id'].')</font>';
        }else{
            $tjHehuoren = '--';
        }
            
        echo '<tr>';
        echo '<td>'.$value['id'].'</td>';
        echo '<td><img src="'.$value['picurl'].'" width="40" /></td>';
        echo '<td>'.$value['nickname'].'</td>';
        echo '<td>'.$value['tel'].'</td>';
        echo '<td>'.$value['openid'].'</td>';
        echo '<td>'.$tjHehuoren.'</td>';
        echo '<td>'.$value['money'].'</td>';
        echo '<td>'.$value['score'].'</td>';
        echo '<td>';
        echo $Lang['user_num'] .'<font color="#f00">' . $userCountTmp . '</font>&nbsp;<a href="'.$adminBaseUrl.'&tmod=index&user_id='.$value['id'].'"><font color="#928c8c">(' . $Lang['user_chakan'] . ')</font></a><br/>';
        echo $Lang['user_pinglun'] .'<font color="#f00">' . $pinglunCountTmp . '</font>&nbsp;<a href="'.$adminBaseUrl.'&tmod=pinglun&user_id='.$value['id'].'"><font color="#928c8c">(' . $Lang['user_chakan'] . ')</font></a><br/>';
        echo $Lang['user_pm'] .'<font color="#f00">' . $pmCountTmp . '</font>&nbsp;<a href="'.$adminBaseUrl.'&tmod=pmMessage&user_id='.$value['id'].'"><font color="#928c8c">(' . $Lang['user_chakan'] . ')</font></a><br/>';
        echo '</td>';
        if($value['editor'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['user_editor_1'].'</font></td>';
        }else{
            echo '<td><font color="#f00">'.$Lang['user_editor_0'].'</font></td>';
        }
        if($value['is_majia'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['user_majia_1'].'</font></td>';
        }else{
            echo '<td><font color="#f00">'.$Lang['user_majia_0'].'</font></td>';
        }
        if($value['status'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['user_status_1'].'</font></td>';
        }else{
            echo '<td>';
            echo '<font color="#f00">'.$Lang['user_status_2'].'</font><br/>';
            if($value['fenghao_time'] > 0){
                if($value['fenghao_time'] == 999){
                    echo '<font color="#0894fb">'.$Lang['user_status_2_999'].'</font><br/>';
                }else{
                    echo '<font color="#0894fb">'.dgmdate($value['fenghao_time'],"Y-m-d",$tomSysOffset).' '.$Lang['user_status_2_time'].'</font><br/>';
                }
                if($value['fenghao_msg']){
                    echo '<font color="#8e8e8e">('.$value['fenghao_msg'].')</font>';
                }
            }
            echo '</td>';
        }
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=send_sms&user_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['user_send_sms_btn']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['user_edit_title']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=moneylog&user_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['moneylog_list_title']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&tmod=gold&user_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['moneylog_edit_gold']. '</a><br/>';
        if($value['editor'] == 1){
            echo '<a href="'.$modBaseUrl.'&act=del_editor&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['user_editor_btn_0']. '</a>&nbsp;|&nbsp;';
        }else{
            echo '<a href="'.$modBaseUrl.'&act=add_editor&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['user_editor_btn_1']. '</a>&nbsp;|&nbsp;';
        }
        if($value['status'] == 1){
            echo '<a href="'.$modBaseUrl.'&act=fenhao&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['user_status_2']. '</a>';
        }else{
            echo '<a href="'.$modBaseUrl.'&act=ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['user_status_1']. '</a>';
        }
        
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
}

