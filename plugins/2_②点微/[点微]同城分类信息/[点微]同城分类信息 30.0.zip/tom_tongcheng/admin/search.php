<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=search'; 
$modListUrl = $adminListUrl.'&tmod=search';
$modFromUrl = $adminFromUrl.'&tmod=search';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_search')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); /*dism��taobao��com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $searchInfo = C::t('#tom_tongcheng#tom_tongcheng_search')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($searchInfo);
        C::t('#tom_tongcheng#tom_tongcheng_search')->update($searchInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*dism��taobao��com*/
        __create_info_html($searchInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tongcheng#tom_tongcheng_search')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    $site_id    = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $type       = isset($_GET['type'])? intval($_GET['type']):0;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if($type > 0){
        $where.= " AND type={$type} ";
    }
    
    $pagesize = 1000;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tongcheng#tom_tongcheng_search')->fetch_all_count($where);
    $searchList = C::t('#tom_tongcheng#tom_tongcheng_search')->fetch_all_list($where," ORDER BY site_id ASC, ssort ASC,id DESC ",$start,$pagesize);
    
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_list'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&type={$type}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); /*dism��taobao��com*/
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $typeArr = array(1=>$Lang['search_type_1'],2=>$Lang['search_type_2']);
    $typeStr = '<tr><td width="100" align="right"><b>'.$Lang['search_type'].'</b></td>';
    $typeStr.= '<td><select style="width: 260px;" name="type" id="type">';
    $typeStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($typeArr as $key => $value){
        if($type == $key){
            $typeStr.=  '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            $typeStr.=  '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    $typeStr.= '</select></td></tr>';
    echo $typeStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/
    
    __create_nav_html();
    showtableheader(); /*dism��taobao��com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['search_name'] . '</th>';
    echo '<th>' . $Lang['search_type'] . '</th>';
    echo '<th>' . $Lang['search_plugin_id'] . '</th>';
    echo '<th>' . $Lang['search_link'] . '</th>';
    echo '<th>' . $Lang['search_ssort'] . '</th>';
    echo '<th>' . $Lang['search_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($searchList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        
        $modelInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($value['model_id']);
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $value['name'] . '</td>';
        if($value['type'] == 1){
            echo '<td>' . $Lang['search_type_1'] . '</td>';
            echo '<td>' . $Lang['search_plugin_id_'.$value['plugin_id']] .'</td>';
            echo '<td> -- </td>';
        }else if($value['type'] == 2){
            echo '<td>' . $Lang['search_type_2'] . '</td>';
            echo '<td> -- </td>';
            echo '<td>' . $value['link'] . '</td>';
        }else{
            echo '<td> -- </td>';
            echo '<td> -- </td>';
            echo '<td> -- </td>';
        }
        echo '<td>' . $value['ssort'] . '</td>';
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $type           = isset($_GET['type'])? intval($_GET['type']):1;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $plugin_id      = isset($_GET['plugin_id'])? addslashes($_GET['plugin_id']):'';
    $link           = isset($_GET['link'])? addslashes($_GET['link']):'';
    $ssort          = isset($_GET['ssort'])? intval($_GET['ssort']):10;
    
    $data['site_id']    = $site_id;
    $data['type']       = $type;
    $data['name']       = $name;
    $data['plugin_id']  = $plugin_id;
    $data['link']       = $link;
    $data['ssort']      = $ssort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'site_id'       => 1,
        'name'          => '',
        'type'          => 1,
        'plugin_id'     => '',
        'link'          => '',
        'ssort'         => 10,
    );
    $options = array_merge($options, $infoArr);
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    tomshowsetting(true,array('title'=>$Lang['search_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['search_name_msg']),"input");
    $type_item = array(1=>$Lang['search_type_1'],2=>$Lang['search_type_2']);
    tomshowsetting(true,array('title'=>$Lang['search_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['search_type_msg'],'item'=>$type_item),"radio");
    $plugin_id_item = array('tongcheng'=>$Lang['search_plugin_id_tongcheng'],'shop'=>$Lang['search_plugin_id_shop'],'mall'=>$Lang['search_plugin_id_mall'],'qianggou'=>$Lang['search_plugin_id_qianggou'],'ptuan'=>$Lang['search_plugin_id_ptuan'],'toutiao'=>$Lang['search_plugin_id_toutiao'],'kaquan'=>$Lang['search_plugin_id_kaquan'],'114'=>$Lang['search_plugin_id_114']);
    tomshowsetting(true,array('title'=>$Lang['search_plugin_id'],'name'=>'plugin_id','value'=>$options['plugin_id'],'msg'=>$Lang['search_plugin_id_msg'],'item'=>$plugin_id_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['search_link'],'name'=>'link','value'=>$options['link'],'msg'=>$Lang['search_link_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['search_ssort'],'name'=>'ssort','value'=>$options['ssort'],'msg'=>$Lang['search_ssort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['search_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['search_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['search_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['search_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['edit'],"",true);
    }else{
        tomshownavli($Lang['search_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['search_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}