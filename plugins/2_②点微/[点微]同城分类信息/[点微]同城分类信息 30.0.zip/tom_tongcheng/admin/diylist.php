<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=diylist'; 
$modListUrl = $adminListUrl.'&tmod=diylist';
$modFromUrl = $adminFromUrl.'&tmod=diylist';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_diylist')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); /*dism��taobao��com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $diyInfo = C::t('#tom_tongcheng#tom_tongcheng_diylist')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($diyInfo);
        C::t('#tom_tongcheng#tom_tongcheng_diylist')->update($diyInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*dism��taobao��com*/
        __create_info_html($diyInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tongcheng#tom_tongcheng_diylist')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    $site_id      = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    
    $pagesize = 1000;
    $start = ($page-1)*$pagesize;	
    $diyList = C::t('#tom_tongcheng#tom_tongcheng_diylist')->fetch_all_list("{$where}"," ORDER BY site_id ASC,dsort ASC,id DESC ",$start,$pagesize);
    
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['help_title'] . '</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); /*dism��taobao��com*/
    $site_select_1 = '';
    if($site_id == 1){
        $site_select_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0" >'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_select_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/
    
    __create_nav_html();
    showtableheader(); /*dism��taobao��com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['diylist_title'] . '</th>';
    echo '<th>' . $Lang['diylist_show_type'] . '</th>';
    echo '<th>' . $Lang['diylist_type'] . '</th>';
    echo '<th>' . $Lang['diylist_xinxi'] . '</th>';
    echo '<th>' . $Lang['diylist_dsort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($diyList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        
        $modelInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($value['model_id']);
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $value['title'] . '</td>';
        
        if($value['show_type'] == 1){
            echo '<td><font color="#238206">' . $Lang['diylist_show_type_1'] . '</font></td>';
        }else if($value['show_type'] == 2){
            echo '<td><font color="#0894fb">' . $Lang['diylist_show_type_2'] . '</font></td>';
        }
        
        if($value['type'] == 1){
            echo '<td><font color="#238206">' . $Lang['diylist_type_1'] . '</font></td>';
            echo '<td>' . $pluginsArr[$value['plugins_name']]['name'] . '</td>';
        }else if($value['type'] == 2){
            echo '<td><font color="#0894fb">' . $Lang['diylist_type_2'] . '</font></td>';
            echo '<td>' . $modelInfoTmp['name'] .'(ID:'.$value['model_id'].')</td>';
        }
        
        echo '<td>' . $value['dsort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    global $Lang,$pluginsArr;
    $data = array();
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;;
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $show_type      = isset($_GET['show_type'])? intval($_GET['show_type']):0;
    $type           = isset($_GET['type'])? intval($_GET['type']):0;
    $model_id       = isset($_GET['model_id'])? intval($_GET['model_id']):0;
    $plugins_name   = isset($_GET['plugins_name'])? addslashes($_GET['plugins_name']):0;
    $dsort          = isset($_GET['dsort'])? intval($_GET['dsort']):10;
    
    $data['site_id']    = $site_id;
    $data['title']      = $title;
    $data['show_type']  = $show_type;
    $data['type']       = $type;
    if($type == 1){
        $data['model_id']       = 0;
        $data['plugins_name']   = $plugins_name;
    }else if($type == 2){
        $data['model_id']       = $model_id;
        $data['plugins_name']   = '';
    }
    $data['dsort']      = $dsort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$pluginsArr;
    $options = array(
        'site_id'        => 1,
        'title'          => '',
        'show_type'      => 1,
        'model_id'       => 0,
        'type'           => 1,
        'link'           => '',
        'dsort'          => 10,
    );
    $options = array_merge($options, $infoArr);
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    
    tomshowsetting(true,array('title'=>$Lang['diylist_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['diylist_title_msg']),"input");
    $show_type_item = array(1=>$Lang['diylist_show_type_1'],2=>$Lang['diylist_show_type_2']);
    tomshowsetting(true,array('title'=>$Lang['diylist_show_type'],'name'=>'show_type','value'=>$options['show_type'],'msg'=>$Lang['diylist_show_type_msg'],'item'=>$show_type_item),"radio");
    $type_item = array(1=>$Lang['diylist_type_1'],2=>$Lang['diylist_type_2']);
    tomshowsetting(true,array('title'=>$Lang['diylist_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['diylist_type_msg'],'item'=>$type_item),"radio");
    
    $pluginsStr = '<tr class="header"><th>'.$Lang['diylist_plugins'].'</th><th></th></tr>';
    $pluginsStr.= '<tr><td width="300"><select style="width: 260px;" name="plugins_name" id="plugins_name">';
    $pluginsStr.=  '<option value="0">'.$Lang['diylist_all'].'</option>';
    foreach ($pluginsArr as $key => $value){
        if(file_exists(DISCUZ_ROOT.'./source/plugin/'.$value['plugin_id'].'/'.$value['plugin_id'].'.inc.php')){
            if($key == $options['plugins_name']){
                $pluginsStr.=  '<option value="'.$key.'" selected>'.$value['name'].'</option>';
            }else{
                $pluginsStr.=  '<option value="'.$key.'">'.$value['name'].'</option>';
            }
        }
    }
    $pluginsStr.= '</select></td><td>'.$Lang['diylist_plugins_msg'].'</td></tr>';
    echo $pluginsStr;
    
    $modelList = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(" AND is_show=1 "," ORDER BY paixu ASC,id DESC ",0,100);
    $modelStr = '<tr class="header"><th>'.$Lang['diylist_model'].'</th><th></th></tr>';
    $modelStr.= '<tr><td width="300"><select style="width: 260px;" name="model_id" id="model_id">';
    $modelStr.=  '<option value="0">'.$Lang['diylist_all'].'</option>';
    foreach ($modelList as $key => $value){
        if($value['id'] == $options['model_id']){
            $modelStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $modelStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $modelStr.= '</select></td><td>'.$Lang['diylist_model_msg'].'</td></tr>';
    echo $modelStr;
    
    tomshowsetting(true,array('title'=>$Lang['diylist_dsort'],'name'=>'dsort','value'=>$options['dsort'],'msg'=>$Lang['diylist_dsort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_diy_list'],$modBaseUrl,false);
        tomshownavli($Lang['diylist_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_diy_list'],$modBaseUrl,false);
        tomshownavli($Lang['diylist_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['diylist_edit'],"",true);
    }else{
        tomshownavli($Lang['index_diy_list'],$modBaseUrl,true);
        tomshownavli($Lang['diylist_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}