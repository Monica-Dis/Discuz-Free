<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=setting';
$modListUrl = $adminListUrl.'&tmod=setting';
$modFromUrl = $adminFromUrl.'&tmod=setting';

if(submitcheck('submit')){
    $updateData = array();
    $updateData = __get_post_data($tongchengSetting);
    C::t('#tom_tongcheng#tom_tongcheng_setting')->update(1,$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    tomloadcalendarjs();
    loadeditorjs();
    showformheader($modFromUrl,'enctype');
    showtableheader(); /*dism��taobao��com*/
    __create_info_html($tongchengSetting);
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $index_diy_html         = isset($_GET['index_diy_html'])? addslashes($_GET['index_diy_html']):'';
    $open_model_search      = isset($_GET['open_model_search'])? intval($_GET['open_model_search']):0;
    $index_fixed_menu       = isset($_GET['index_fixed_menu'])? intval($_GET['index_fixed_menu']):3;
    
    $open_share_refresh_top      = isset($_GET['open_share_refresh_top'])? intval($_GET['open_share_refresh_top']):0;
    $share_do_limit              = isset($_GET['share_do_limit'])? intval($_GET['share_do_limit']):0;
    $share_refresh_txt           = isset($_GET['share_refresh_txt'])? addslashes($_GET['share_refresh_txt']):0;
    $share_top_num               = isset($_GET['share_top_num'])? intval($_GET['share_top_num']):0;
    $share_top_days              = isset($_GET['share_top_days'])? intval($_GET['share_top_days']):0;
    $share_top_txt               = isset($_GET['share_top_txt'])? addslashes($_GET['share_top_txt']):0;
    
    $open_all_free_fabu_times    = isset($_GET['open_all_free_fabu_times'])? intval($_GET['open_all_free_fabu_times']):0;
    $all_free_fabu_times         = isset($_GET['all_free_fabu_times'])? intval($_GET['all_free_fabu_times']):0;
    $free_fabu_times_days        = isset($_GET['free_fabu_times_days'])? intval($_GET['free_fabu_times_days']):0;
    $open_fabu_top               = isset($_GET['open_fabu_top'])? intval($_GET['open_fabu_top']):0;
    $open_fabu_tui               = isset($_GET['open_fabu_tui'])? intval($_GET['open_fabu_tui']):0;
    $open_pic_to_text            = isset($_GET['open_pic_to_text'])? intval($_GET['open_pic_to_text']):0;
    $pic_to_text_appcode         = isset($_GET['pic_to_text_appcode'])? addslashes($_GET['pic_to_text_appcode']):'';
    $template_type               = isset($_GET['template_type'])? addslashes($_GET['template_type']):'default';
    $open_message_send_pic       = isset($_GET['open_message_send_pic'])? intval($_GET['open_message_send_pic']):0;
    
    $open_refresh_price          = isset($_GET['open_refresh_price'])? intval($_GET['open_refresh_price']):0;
    $refresh_price_str           = isset($_GET['refresh_price_str'])? addslashes($_GET['refresh_price_str']):'';
    
    $closed_sites_one_fabu       = isset($_GET['closed_sites_one_fabu'])? intval($_GET['closed_sites_one_fabu']):0;
    $moneytixian_msg             = isset($_GET['moneytixian_msg'])? addslashes($_GET['moneytixian_msg']):'';
    
    $open_list_pinglun_zan       = isset($_GET['open_list_pinglun_zan'])? intval($_GET['open_list_pinglun_zan']):0;
    
    $data['index_diy_html']         = trim($index_diy_html);
    $data['open_model_search']      = $open_model_search;
    $data['index_fixed_menu']       = $index_fixed_menu;
    
    $data['open_share_refresh_top'] = $open_share_refresh_top;
    $data['share_do_limit']         = $share_do_limit;
    $data['share_refresh_txt']      = trim($share_refresh_txt);
    $data['share_top_num']          = $share_top_num;
    $data['share_top_days']         = $share_top_days;
    $data['share_top_txt']          = trim($share_top_txt);
    
    $data['open_all_free_fabu_times']  = $open_all_free_fabu_times;
    $data['all_free_fabu_times']       = $all_free_fabu_times;
    $data['free_fabu_times_days']      = $free_fabu_times_days;
    $data['open_fabu_top']             = $open_fabu_top;
    $data['open_fabu_tui']             = $open_fabu_tui;
    $data['open_pic_to_text']          = $open_pic_to_text;
    $data['pic_to_text_appcode']       = $pic_to_text_appcode;
    $data['template_type']             = $template_type;
    $data['open_message_send_pic']     = $open_message_send_pic;
    $data['open_refresh_price']        = $open_refresh_price;
    $data['refresh_price_str']         = $refresh_price_str;
    
    $data['closed_sites_one_fabu']     = $closed_sites_one_fabu;
    $data['moneytixian_msg']           = $moneytixian_msg;
    
    $data['open_list_pinglun_zan']     = $open_list_pinglun_zan;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'index_diy_html'        => '',
        'open_model_search'     => 0,
        'index_fixed_menu'      => 3,
        
        'open_share_refresh_top'    => 0,
        'share_do_limit'            => 2,
        'share_refresh_txt'         => '',
        'share_top_num'             => 0,
        'share_top_days'            => 0,
        'share_top_txt'             => '',
        
        'open_all_free_fabu_times'  => 0,
        'all_free_fabu_times'       => 0,
        'free_fabu_times_days'      => 0,
        'open_fabu_top'             => 0,
        'open_fabu_tui'             => 0,
        'open_pic_to_text'          => 0,
        'pic_to_text_appcode'       => '',
        'template_type'             => 'default',
        'open_message_send_pic'     => 0,
        'open_refresh_price'        => 0,
        'refresh_price_str'         => '',
        
        'closed_sites_one_fabu'     => 0,
        'moneytixian_msg'           => '',
        'open_list_pinglun_zan'     => 1,
        
    );
    $options = array_merge($options, $infoArr);
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/config/setting.lang.php';
    
    $open_item = array(1=>$Lang['open'],0=>$Lang['close']);
    
    $template_type_item = array('default'=>$settingLang['template_type_default'],'kuanlist'=>$settingLang['template_type_kuanlist'],'tuwenlist'=>$settingLang['template_type_tuwenlist']);
    tomshowsetting(true,array('title'=>$settingLang['template_type'],'name'=>'template_type','value'=>$options['template_type'],'msg'=>$settingLang['template_type_msg'],'item'=>$template_type_item),"select");
    
    tomshowsetting(true,array('title'=>$settingLang['open_model_search'],'name'=>'open_model_search','value'=>$options['open_model_search'],'msg'=>$settingLang['open_model_search_msg'],'item'=>$open_item),"radio");
    $index_fixed_menu_item = array(1=>$settingLang['index_fixed_menu_1'],2=>$settingLang['index_fixed_menu_2'],3=>$settingLang['index_fixed_menu_3']);
    tomshowsetting(true,array('title'=>$settingLang['index_fixed_menu'],'name'=>'index_fixed_menu','value'=>$options['index_fixed_menu'],'msg'=>$settingLang['index_fixed_menu_msg'],'item'=>$index_fixed_menu_item),"radio");
    $options['index_diy_html'] = stripslashes($options['index_diy_html']);
    tomshowsetting(true,array('title'=>$settingLang['index_diy_html'],'name'=>'index_diy_html','value'=>$options['index_diy_html'],'msg'=>$settingLang['index_diy_html_msg']),"textarea");
    
    $open_share_refresh_top_item = array(0=>$settingLang['open_share_refresh_top_0'],1=>$settingLang['open_share_refresh_top_1'],2=>$settingLang['open_share_refresh_top_2']);
    tomshowsetting(true,array('title'=>$settingLang['open_share_refresh_top'],'name'=>'open_share_refresh_top','value'=>$options['open_share_refresh_top'],'msg'=>$settingLang['open_share_refresh_top_msg'],'item'=>$open_share_refresh_top_item),"radio");
    
    $share_do_limit_item = array(1=>$settingLang['share_do_limit_1'],2=>$settingLang['share_do_limit_2']);
    tomshowsetting(true,array('title'=>$settingLang['share_do_limit'],'name'=>'share_do_limit','value'=>$options['share_do_limit'],'msg'=>$settingLang['share_do_limit_msg'],'item'=>$share_do_limit_item),"radio");
    
    tomshowsetting(true,array('title'=>$settingLang['share_refresh_txt'],'name'=>'share_refresh_txt','value'=>$options['share_refresh_txt'],'msg'=>$settingLang['share_refresh_txt_msg']),"textarea");
    tomshowsetting(true,array('title'=>$settingLang['share_top_num'],'name'=>'share_top_num','value'=>$options['share_top_num'],'msg'=>$settingLang['share_top_num_msg']),"input");
    tomshowsetting(true,array('title'=>$settingLang['share_top_days'],'name'=>'share_top_days','value'=>$options['share_top_days'],'msg'=>$settingLang['share_top_days_msg']),"input");
    tomshowsetting(true,array('title'=>$settingLang['share_top_txt'],'name'=>'share_top_txt','value'=>$options['share_top_txt'],'msg'=>$settingLang['share_top_txt_msg']),"textarea");
    
    tomshowsetting(true,array('title'=>$settingLang['open_all_free_fabu_times'],'name'=>'open_all_free_fabu_times','value'=>$options['open_all_free_fabu_times'],'msg'=>$settingLang['open_all_free_fabu_times_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['all_free_fabu_times'],'name'=>'all_free_fabu_times','value'=>$options['all_free_fabu_times'],'msg'=>$settingLang['all_free_fabu_times_msg']),"input");
    tomshowsetting(true,array('title'=>$settingLang['free_fabu_times_days'],'name'=>'free_fabu_times_days','value'=>$options['free_fabu_times_days'],'msg'=>$settingLang['free_fabu_times_days_msg']),"input");
    tomshowsetting(true,array('title'=>$settingLang['open_fabu_top'],'name'=>'open_fabu_top','value'=>$options['open_fabu_top'],'msg'=>$settingLang['open_fabu_top_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['open_fabu_tui'],'name'=>'open_fabu_tui','value'=>$options['open_fabu_tui'],'msg'=>$settingLang['open_fabu_tui_msg'],'item'=>$open_item),"radio");
    
    tomshowsetting(true,array('title'=>$settingLang['open_pic_to_text'],'name'=>'open_pic_to_text','value'=>$options['open_pic_to_text'],'msg'=>$settingLang['open_pic_to_text_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['pic_to_text_appcode'],'name'=>'pic_to_text_appcode','value'=>$options['pic_to_text_appcode'],'msg'=>$settingLang['pic_to_text_appcode_msg']),"input");
    
    
    tomshowsetting(true,array('title'=>$settingLang['open_message_send_pic'],'name'=>'open_message_send_pic','value'=>$options['open_message_send_pic'],'msg'=>$settingLang['open_message_send_pic_msg'],'item'=>$open_item),"radio");
    
    tomshowsetting(true,array('title'=>$settingLang['open_refresh_price'],'name'=>'open_refresh_price','value'=>$options['open_refresh_price'],'msg'=>$settingLang['open_refresh_price_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['refresh_price_str'],'name'=>'refresh_price_str','value'=>$options['refresh_price_str'],'msg'=>$settingLang['refresh_price_str_msg']),"textarea");
    
    $closed_sites_one_fabu_item = array(1=>$settingLang['closed_sites_one_fabu_1'],0=>$settingLang['closed_sites_one_fabu_0']);
    tomshowsetting(true,array('title'=>$settingLang['closed_sites_one_fabu'],'name'=>'closed_sites_one_fabu','value'=>$options['closed_sites_one_fabu'],'msg'=>$settingLang['closed_sites_one_fabu_msg'],'item'=>$closed_sites_one_fabu_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['moneytixian_msg'],'name'=>'moneytixian_msg','value'=>$options['moneytixian_msg'],'msg'=>$settingLang['moneytixian_msg_msg']),"textarea");
    
    tomshowsetting(true,array('title'=>$settingLang['open_list_pinglun_zan'],'name'=>'open_list_pinglun_zan','value'=>$options['open_list_pinglun_zan'],'msg'=>$settingLang['open_list_pinglun_zan_msg'],'item'=>$open_item),"radio");
    
    return;
}