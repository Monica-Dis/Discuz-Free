<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=gold&user_id='.$_GET['user_id'];
$modListUrl = $adminListUrl.'&tmod=gold&user_id='.$_GET['user_id'];
$modFromUrl = $adminFromUrl.'&tmod=gold&user_id='.$_GET['user_id'];

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/config/gold_type.config.php';

if($_GET['act'] == 'add' && $_GET['formhash'] == FORMHASH){
    $gold_num = isset($_GET['gold_num'])? intval($_GET['gold_num']):0;
    $type = isset($_GET['type'])? intval($_GET['type']):0;
    $user_id = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    if($type == 1){
        $updateData = array();
        $updateData['score'] = $userInfo['score'] + $gold_num;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'], $updateData);
        
        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $gold_num;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 8;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
    }else if($type == 2){
        $shengyuScore = $userInfo['score'] - $gold_num;
        if($shengyuScore < 0){
            $shengyuScore = 0;
            $gold_num = $userInfo['score'];
        }
        
        $updateData = array();
        $updateData['score'] = $shengyuScore;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'], $updateData);
        
        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $gold_num;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 9;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $user_id = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    tomshownavheader();
    tomshownavli($userInfo['nickname'],"",true);
    tomshownavli(' > '.$Lang['gold_shengyu_score'].' '.$userInfo['score'],"",true);
    tomshownavfooter();
    
    if($_G['uid'] == 1){
        showformheader($modFromUrl.'&act=add&user_id='.$user_id.'&formhash='.$formhash,'enctype');
        showtableheader(); /*dism��taobao��com*/
        tomshowsetting(true,array('title'=>$Lang['gold_num'],'name'=>'gold_num','value'=>$options['gold_num'],'msg'=>$Lang['gold_num_msg']),"input");
        $type_item = array(1=>$Lang['gold_type1'],2=>$Lang['gold_type2']);
        tomshowsetting(true,array('title'=>$Lang['gold_type'],'name'=>'type','value'=>1,'msg'=>$Lang['gold_type_msg'],'item'=>$type_item),"radio");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 1000;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tongcheng#tom_tongcheng_score_log')->fetch_all_count("AND user_id={$user_id}");
    $scorelogList = C::t('#tom_tongcheng#tom_tongcheng_score_log')->fetch_all_list("AND user_id={$user_id}"," ORDER BY id DESC ",$start,$pagesize);
    
    tomshownavheader();
    tomshownavli($userInfo['nickname'],"",true);
    tomshownavli(' > '.$Lang['moneylog_edit_gold'],"",true);
    tomshownavfooter();
    showtableheader(); /*dism��taobao��com*/
    echo '<tr class="header">';
    echo '<th>' . ID . '</th>';
    echo '<th>' . $Lang['gold_list_biaoqian'] . '</th>';
    echo '<th>' . $Lang['gold_list_change_value'] . '</th>';
    echo '<th>' . $Lang['gold_list_old_value'] . '</th>';
    echo '<th>' . $Lang['gold_list_log_time'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($scorelogList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $gold_typeArr[$value['log_type']]['name'] . '</td>';
        if($gold_typeArr[$value['log_type']]['type'] == 1){
            echo '<td><font color="#fd0d0d">+' . $value['score_value'] . '</font></td>';
        }else{
            echo '<td><font color="#238206">-' . $value['score_value'] . '</font></td>';
        }
        echo '<td>' . $value['old_value'] . '</td>';
        echo '<td>' . dgmdate($value['log_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
     
}

