<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=applysites'; 
$modListUrl = $adminListUrl.'&tmod=applysites';
$modFromUrl = $adminFromUrl.'&tmod=applysites';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

if($formhash == FORMHASH && $act == 'info'){
    
}else{
    
    $where = "";
    
    $pagesize = 10;
    if(!empty($nickname)){
		$pagesize = 100;
	}
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tongcheng#tom_tongcheng_apply_sites')->fetch_all_count($where);
    $applySitesList = C::t('#tom_tongcheng#tom_tongcheng_apply_sites')->fetch_all_list($where,"ORDER BY add_time DESC",$start,$pagesize);
    
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['applysites_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['applysites_user'] . '</th>';
    echo '<th>' . $Lang['applysites_xm'] . '</th>';
    echo '<th>' . $Lang['applysites_tel'] . '</th>';
    echo '<th>' . $Lang['applysites_quyu'] . '</th>';
    echo '<th>' . $Lang['applysites_content'] . '</th>';
    echo '<th>' . $Lang['applysites_pay_status'] . '</th>';
    echo '<th>' . $Lang['applysites_add_time'] . '</th>';
    echo '</tr>';
    foreach ($applySitesList as $key => $value){
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['city_id']);
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        
        echo '<tr>';
        echo '<td>'.$value['id'].'</td>';
        if($value['user_id'] > 0){
            echo '<td>'.$userInfo['nickname'].'<font color="#f00">(ID:'.$value['user_id'].')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>'.$value['xm'].'</td>';
        echo '<td>'.$value['tel'].'</td>';
        echo '<td>'.$cityInfoTmp['name'].' '.$areaInfoTmp['name'].'</td>';
        echo '<td>'.$value['content'].'</td>';
        
        if($value['pay_status'] == 1){
            echo '<td><font color="#f00">'.$Lang['applysites_pay_status_1'].'</font></td>';
        }else if($value['pay_status'] == 2){
            echo '<td><font color="#0a9409">'.$Lang['applysites_pay_status_2'].'</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        echo '<td>'.dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset).'</td>';
        echo '</tr>';
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
}