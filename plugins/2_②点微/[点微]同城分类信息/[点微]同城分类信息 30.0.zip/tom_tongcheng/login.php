<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['f'] == 'miniprogram'){
    $lifeTime = 180;
    dsetcookie('tom_miniprogram', 1, $lifeTime);
}
if($_GET['f'] == 'nominiprogram'){
    $lifeTime = 180;
    dsetcookie('tom_miniprogram', 0, $lifeTime);
}

$__IsWeixin = $__IsQianfan = $__IsXiaoyun = $__IsMagapp = $__IsMocuzapp = $__IsApp = $__IsMiniprogram = $__Ios = $__Android = 0;
$__HideHeader = $__HideFooter = 0;
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){ $__IsWeixin = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false){ $__IsQianfan = 1;$__IsApp = 1;$__HideHeader = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false){ $__IsXiaoyun = 1;$__IsApp = 1;$__HideHeader = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false){ $__IsMagapp = 1;$__IsApp = 1;$__HideHeader = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MocuzApp') !== false){ $__IsMocuzapp = 1;$__IsApp = 1;$__HideHeader = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') !== false){$__Ios = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false){$__Android = 1;}
if($_GET['h'] == '1'){ $__HideHeader = 1;}
$cookie_tom_miniprogram = getcookie('tom_miniprogram');
if($cookie_tom_miniprogram == 1 || $_GET['f'] == 'miniprogram'){ $__IsMiniprogram = 1;$__HideHeader = 1;}
if($__IsMiniprogram == 1){
    $__ShowTchongbao = 0;
    if(!empty($tctoutiaoConfig) && $tctoutiaoConfig['closed_xiao'] == 1){
        $__ShowTctoutiao = 0;
    }
}
if($__IsMiniprogram == 1){
    //dheader('location:');exit;
}

$__UserInfo = array();
$__MemberInfo = array();
$userStatus = false;
$firstLoginStatus = false;
$loginStatus = 0;
$pmNewNum = 0;

$mustLogin = true;
if($_GET['id'] == 'tom_tongcheng' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'fenlei' || $_GET['mod'] == 'list' || $_GET['mod'] == 'info' || $_GET['mod'] == 'view' || $_GET['mod'] == 'hbao' || $_GET['mod'] == 'home' || $_GET['mod'] == 'miniprogram_login')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcshop' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'list' || $_GET['mod'] == 'search' || $_GET['mod'] == 'details')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcqianggou' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'details' || $_GET['mod'] == 'coupon' || $_GET['mod'] == 'recomlist' || $_GET['mod'] == 'qianggoulist' || $_GET['mod'] == 'search' || $_GET['mod'] == 'couponlist' || $_GET['mod'] == 'couponsearch')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tchongbao' && $_GET['mod'] == 'index'){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcptuan' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'goodsinfo' || $_GET['mod'] == 'tuan' || $_GET['mod'] == 'cates' || $_GET['mod'] == 'list')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tckjia' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'details' || $_GET['mod'] == 'jian')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tc114' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'cate' || $_GET['mod'] == 'list' || $_GET['mod'] == 'info')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcyikatong' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'list' || $_GET['mod'] == 'info' || $_GET['mod'] == 'gift')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcmall' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'list' || $_GET['mod'] == 'search' || $_GET['mod'] == 'cate' || $_GET['mod'] == 'goodsinfo')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tctoutiao' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'info' || $_GET['mod'] == 'zuozheinfo')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcchoujiang' && $_GET['mod'] == 'index'){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tczhaopin' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'zhaopinlist' || $_GET['mod'] == 'zhaopinsearch' || $_GET['mod'] == 'zhaopininfo' || $_GET['mod'] == 'resumelist' || $_GET['mod'] == 'resumesearch' || $_GET['mod'] == 'companylist' || $_GET['mod'] == 'companyinfo')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcpinche' && $_GET['mod'] == 'index'){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tchuodong' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'details')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcfangchan' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'newhouseslist' || $_GET['mod'] == 'newhousesinfo' || $_GET['mod'] == 'list' || $_GET['mod'] == 'info' || $_GET['mod'] == 'houseslist' || $_GET['mod'] == 'housesinfo' || $_GET['mod'] == 'agentlist' || $_GET['mod'] == 'agentinfo' || $_GET['mod'] == 'mendianlist'|| $_GET['mod'] == 'mendianinfo' || $_GET['mod'] == 'needslist'|| $_GET['mod'] == 'needsinfo')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tctopic' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'info' || $_GET['mod'] == 'guize' || $_GET['mod'] == 'goodslist')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tclove' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'list')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcqun' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'list' || $_GET['mod'] == 'info')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcershou' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'goodslist' || $_GET['mod'] == 'goodsinfo' || $_GET['mod'] == 'needslist' || $_GET['mod'] == 'needsinfo')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcdaojia' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'goodslist' || $_GET['mod'] == 'goodsinfo' || $_GET['mod'] == 'needslist')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcedu' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'list' || $_GET['mod'] == 'info' || $_GET['mod'] == 'info_course' || $_GET['mod'] == 'info_teacher' || $_GET['mod'] == 'info_photo'  || $_GET['mod'] == 'teacherinfo' || $_GET['mod'] == 'courselist' || $_GET['mod'] == 'courseinfo')){
    $mustLogin = false;
}
#### login
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
    $mustLogin = true;
}

$tj_hehuoren_id = 0;
if(isset($_GET['tj_hehuoren_id'])){
    $tj_hehuoren_id = isset($_GET['tj_hehuoren_id'])?intval($_GET['tj_hehuoren_id']):0;
}else if(isset($_GET['tjid'])){
    $tj_hehuoren_id = isset($_GET['tjid'])?intval($_GET['tjid']):0;
}

$ucenterfilenameExists = false;
$ucenterfilename = DISCUZ_ROOT.'./source/plugin/tom_ucenter/tom_ucenter.inc.php';
if(file_exists($ucenterfilename)){
    $ucenterfilenameExists = true;
}else{
    echo '<a href="https://Dism.Taobao.Com/?@tom_ucenter.plugin">https://Dism.Taobao.Com/?@tom_ucenter.plugin</a>';exit;
}

$ucenterConfig = $_G['cache']['plugin']['tom_ucenter'];

# new login start
$cookieUid = getcookie('tom_ucenter_member_uid');
$cookieKey = getcookie('tom_ucenter_member_key');
if(!empty($cookieUid) && !empty($cookieKey)){
    $__MemberInfoTmp = C::t('#tom_ucenter#tom_ucenter_member')->fetch_by_uid($cookieUid);
    if($__MemberInfoTmp && !empty($__MemberInfoTmp['mykey'])){
        if(md5($__MemberInfoTmp['uid'].'|||'.$__MemberInfoTmp['mykey']) == $cookieKey){
            $__MemberInfo = $__MemberInfoTmp;
            $userStatus = true;
            $mustLogin = true;
        }
    }
}

if($userStatus){
    $loginStatus = 1;

    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_member_id($__MemberInfo['uid']);
    if($userInfoTmp){
        $__UserInfo = $userInfoTmp;
        if(!empty($__MemberInfo['unionid']) && $__UserInfo['unionid'] != $__MemberInfo['unionid'] && $__UserInfo['openid'] == $__MemberInfo['openid']){
            $updateData             = array();
            $updateData['unionid']  = $__MemberInfo['unionid'];
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
        }
        if(!empty($__MemberInfo['tel']) && $__UserInfo['tel'] != $__MemberInfo['tel']){
            $updateData             = array();
            $updateData['tel']      = $__MemberInfo['tel'];
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
        }
        if(!empty($__MemberInfo['openid']) && $__MemberInfo['openid'] != $__UserInfo['openid']){
            $userInfoTmpOpenid = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($__MemberInfo['openid']);
            if($userInfoTmpOpenid){
            }else{
                $updateData             = array();
                $updateData['openid']   = $__MemberInfo['openid'];
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
            }
        }
        if(strpos($__UserInfo['picurl'],'qlogo.cn') !== false && $__UserInfo['picurl'] != $__MemberInfo['picurl']){
            $updateData             = array();
            $updateData['picurl']   = $__MemberInfo['picurl'];
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
        }
    }else{
        $createNewUser = false;
        if($__MemberInfo['last_login_type'] == 'weixin'){

            $userInfoTmpOpenid = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($__MemberInfo['openid']);
            $userInfoTmpUnionid = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_unionid($__MemberInfo['unionid']);
            if(!empty($__MemberInfo['openid']) && $userInfoTmpOpenid){
                $__UserInfo = $userInfoTmpOpenid;

                $updateData                 = array();
                $updateData['member_id']    = $__MemberInfo['uid'];
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfoTmpOpenid['id'],$updateData);

                if(empty($__MemberInfo['tel']) && !empty($userInfoTmpOpenid['tel'])){
                    $memberInfoTmpTel = C::t('#tom_ucenter#tom_ucenter_member')->fetch_by_tel($userInfoTmpOpenid['tel']);
                    if(!$memberInfoTmpTel){
                        $updateData = array();
                        $updateData['tel']     = $userInfoTmpOpenid['tel'];
                        C::t('#tom_ucenter#tom_ucenter_member')->update($__MemberInfo['uid'],$updateData);
                    }
                }
            }else if(!empty($__MemberInfo['unionid']) && $userInfoTmpUnionid){
                $__UserInfo = $userInfoTmpUnionid;
                $updateData                 = array();
                $updateData['openid']       = $__MemberInfo['openid'];
                $updateData['member_id']    = $__MemberInfo['uid'];
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfoTmpUnionid['id'],$updateData);
            }else{
                $createNewUser = true;
            }
        }else if($__MemberInfo['last_login_type'] == 'tel'){
            $userInfoTmpTel = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_tel($__MemberInfo['tel']);
            if(!empty($__MemberInfo['tel']) && $userInfoTmpTel){
                $__UserInfo = $userInfoTmpTel;

                $updateData                 = array();
                $updateData['member_id']    = $__MemberInfo['uid'];
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfoTmpTel['id'],$updateData);

                if(empty($__MemberInfo['openid']) && !empty($userInfoTmpTel['openid'])){
                    $memberInfoTmpOpenid = C::t('#tom_ucenter#tom_ucenter_member')->fetch_by_openid($userInfoTmpTel['openid']);
                    if(!$memberInfoTmpOpenid){
                        $updateData = array();
                        $updateData['openid']     = $userInfoTmpTel['openid'];
                        C::t('#tom_ucenter#tom_ucenter_member')->update($__MemberInfo['uid'],$updateData);
                    }
                }

            }else{
                $createNewUser = true;
            }

        }else if($__MemberInfo['last_login_type'] == 'app'){
            $userInfoTmpUnionid = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_unionid($__MemberInfo['unionid']);
            if(!empty($__MemberInfo['unionid']) && $userInfoTmpUnionid){
                $__UserInfo = $userInfoTmpUnionid;
                $updateData                 = array();
                $updateData['member_id']    = $__MemberInfo['uid'];
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfoTmpUnionid['id'],$updateData);
            }else{
                $createNewUser = true;
            }
        }else if($__MemberInfo['last_login_type'] == 'bbs'){
            $createNewUser = true;
        }

        if($createNewUser){
            $insertData = array();
            $insertData['member_id']        = $__MemberInfo['uid'];
            $insertData['openid']           = $__MemberInfo['openid'];
            $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
            $insertData['unionid']          = $__MemberInfo['unionid'];
            $insertData['nickname']         = $__MemberInfo['nickname'];
            $insertData['picurl']           = $__MemberInfo['picurl'];
            $insertData['tel']              = $__MemberInfo['tel'];
            $insertData['score']            = $tongchengConfig['new_user_give_score'];
            if($tongchengConfig['open_hongbao_tz'] == 1){
                $insertData['hongbao_tz']   = 1;
            }
            $insertData['add_time']         = TIMESTAMP;
            if(C::t('#tom_tongcheng#tom_tongcheng_user')->insert($insertData)){
                $__UserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_member_id($__MemberInfo['uid']);
                $firstLoginStatus = true;
            }
        }
    }

}else if($mustLogin){
    $login_back_url = $weixinClass->get_url();
    $login_back_url = urlencode($login_back_url);
    if(function_exists('tomheader')){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_ucenter&mod=login&t_from=tongcheng&t_back=".$login_back_url);exit;
    }else{
        dheader('location:'.$_G['siteurl']."plugin.php?id=tom_ucenter&mod=login&t_from=tongcheng&t_back=".$login_back_url);exit;
    }
}

# new login end
    

if($tongchengConfig['new_user_give_score'] > 0 && $firstLoginStatus){
    $insertData = array();
    $insertData['user_id']          = $__UserInfo['id'];
    $insertData['score_value']      = $tongchengConfig['new_user_give_score'];
    $insertData['old_value']        = 0;
    $insertData['log_type']         = 10;
    $insertData['log_time']         = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
}
if(!empty($tongchengConfig['new_user_tz']) && $firstLoginStatus){
    $insertData = array();
    $insertData['user_id']      = $__UserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$__SitesInfo['name'].'</font><br/>'.str_replace("{SITENAME}", $__SitesInfo['name'], $tongchengConfig['new_user_tz']);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
}

if($mustLogin){

    $pmNewNum = C::t('#tom_tongcheng#tom_tongcheng_pm')->fetch_all_newnum(" AND user_id={$__UserInfo['id']} ");
    $noReadTzCount = C::t('#tom_tongcheng#tom_tongcheng_tz')->fetch_all_count(" AND user_id='{$__UserInfo['id']}' AND is_read=0 ");
    if($tongchengConfig['open_message'] == 1){
        $pmNewNum = $pmNewNum + $noReadTzCount;
    }else{
        $pmNewNum = $noReadTzCount;
    }

    $__UserInfo['groupid'] = 0;
    $__UserInfo['groupsiteid'] = 0;
    if($tongchengConfig['manage_user_id'] == $__UserInfo['id']){
        $__UserInfo['groupid'] = 1;
    }
    if(!empty($tongchengConfig['shenhe_manage_user_ids'])){
        $shenhe_manage_user_ids_arr = explode("|", $tongchengConfig['shenhe_manage_user_ids']);
        if(in_array($__UserInfo['id'], $shenhe_manage_user_ids_arr)){
            $__UserInfo['groupid'] = 1;
        }
    }
    
    if($__UserInfo['groupid'] == 0){
        $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_manage_user_id($__UserInfo['id']);
        if($siteInfoTmp){
            $tcadminfilename = DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php';
            if(file_exists($tcadminfilename)){
                $__UserInfo['groupid'] = 2;
                $__UserInfo['groupsiteid'] = $siteInfoTmp['id'];
            }
        }
    }
    
    if(empty($__UserInfo['openid']) && $__IsWeixin == 1 && $__UserInfo['is_majia'] == 0){
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/oauth2.php';
        $updateData = array();
        $updateData['openid']     = $openid;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
    }
    
    if($tj_hehuoren_id > 0){
        if(isset($_G['cache']['plugin']['tom_tchehuoren']['open_fensi_flow']) && $_G['cache']['plugin']['tom_tchehuoren']['open_fensi_flow'] == 1 && $__UserInfo['tj_hehuoren_id'] != $tj_hehuoren_id){
            $checkMyHehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($tj_hehuoren_id);
            if($checkMyHehuorenInfoTmp['user_id'] != $__UserInfo['id']){
                $updateData = array();
                $updateData['tj_hehuoren_id']     = $tj_hehuoren_id;
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
            }
        }else if(isset($_G['cache']['plugin']['tom_tchehuoren']['open_olduser']) && $_G['cache']['plugin']['tom_tchehuoren']['open_olduser'] == 1 && $__UserInfo['tj_hehuoren_id'] == 0){
            $checkMyHehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($tj_hehuoren_id);
            if($checkMyHehuorenInfoTmp['user_id'] != $__UserInfo['id']){
                $updateData = array();
                $updateData['tj_hehuoren_id']     = $tj_hehuoren_id;
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
            }
        }
    }
    
    $last_login_time_cookie = getcookie('tom_tongcheng_last_login_time');
    if($last_login_time_cookie && $last_login_time_cookie == 1){
    }else{
        $updateData = array();
        $updateData['last_login_time']     = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
        $lifeTime = 300;
        dsetcookie('tom_tongcheng_last_login_time',1,$lifeTime);
    }
    
    if(empty($__UserInfo['picurl']) && $_GET['mod'] != 'myedit' && $_GET['mod'] != 'upload'){
        dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=myedit");exit;
    }

    if($__UserInfo['status'] == 2 && $_GET['mod'] != 'personal' && $_GET['mod'] != 'help'){
        if($__UserInfo['fenghao_time'] > 1000 && $__UserInfo['fenghao_time'] < TIMESTAMP){
            $updateData = array();
            $updateData['status']           = 1;
            $updateData['fenghao_time']     = 0;
            $updateData['fenghao_msg']      = '';
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
        }else{
            dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=personal");exit;
        }
    }
}