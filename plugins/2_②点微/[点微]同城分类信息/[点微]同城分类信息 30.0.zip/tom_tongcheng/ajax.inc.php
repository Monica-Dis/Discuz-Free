<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowYear = dgmdate($_G['timestamp'], 'Y',$tomSysOffset);
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);

$tongchengSetting = C::t('#tom_tongcheng#tom_tongcheng_setting')->fetch_by_id(1);
if($tongchengSetting && $tongchengSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tongcheng#tom_tongcheng_setting')->insert($insertData);
    $tongchengSetting = C::t('#tom_tongcheng#tom_tongcheng_setting')->fetch_by_id(1);
}

$__IsMiniprogram = 0;
$cookie_tom_miniprogram = getcookie('tom_miniprogram');
if($cookie_tom_miniprogram == 1){ 
    $__IsMiniprogram = 1;
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

## tcadmin start
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
## tcadmin end
## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tcyikatong start
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
    $tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $__ShowTcyikatong = 1;
    }
}
## tcyikatong end
## tchongbao start
$__ShowTchongbao = 0;
$__TchongbaoHost = '';
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchongbao/tom_tchongbao.inc.php')){
    $tchongbaoConfig = $_G['cache']['plugin']['tom_tchongbao'];
    if($tchongbaoConfig['open_tchongbao'] == 1 && $__IsMiniprogram == 0){
        $__ShowTchongbao = 1;
        if($tchongbaoConfig['open_only_hosts'] == 1 && !empty($tchongbaoConfig['tongcheng_hosts']) && !empty($tchongbaoConfig['hongbao_hosts'])){
            $__TchongbaoHost = str_replace($tchongbaoConfig['tongcheng_hosts'], $tchongbaoConfig['hongbao_hosts'], $_G['siteurl']);
            if($tchongbaoConfig['must_http'] == 1){
                $__TchongbaoHost = str_replace("https", "http", $__TchongbaoHost);
            }
        }
    }
}
## tchongbao end
## tcrenzheng start
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')){
    $tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
    if($tcrenzhengConfig['open_tcrenzheng'] == 1){
        $__ShowTcrenzheng = 1;
    }
}
## tcrenzheng end
## tctoutiao start
$__ShowTctoutiao = 0;
$tctoutiaoConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/tom_tctoutiao.inc.php')){
    $tctoutiaoConfig = $_G['cache']['plugin']['tom_tctoutiao'];
    if($tctoutiaoConfig['open_tctoutiao'] == 1){
        $__ShowTctoutiao = 1;
    }
}
## tctoutiao end
## love start
$__ShowLove = 0;
$jyConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_love/tom_love.inc.php')){
    $jyConfig = $_G['cache']['plugin']['tom_love'];
    if($jyConfig['open_tongcheng'] == 1){
        $__ShowLove = 1;
    }
}
## love end
### tczhaopin start
$__ShowTczhaopin = 0;
$tczhaopinConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')){
    $tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
    if($tczhaopinConfig['open_tczhaopin'] == 1){
        $__ShowTczhaopin = 1;
    }
}
## tczhaopin end
## tcfangchan start
$__ShowFangchan = 0;
$tcfangchanConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/tom_tcfangchan.inc.php')){
    $tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
    if($tcfangchanConfig['open_tcfangchan'] == 1){
        $__ShowFangchan = 1;
    }
}
## tcfangchan end
## xiaofenlei start
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')){
    $xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
    $__ShowXiaofenlei = 1;
}
## xiaofenlei end
## tcershou start
$__ShowTcershou = 0;
$tcershouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcershou/tom_tcershou.inc.php')){
    $tcershouConfig = $_G['cache']['plugin']['tom_tcershou'];
    if($tcershouConfig['open_tcershou'] == 1){
        $__ShowTcershou = 1;
    }
}
## tcershou end
## tcqianggou start
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
    $tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
    if($tcqianggouConfig['open_tcqianggou'] == 1){
        $__ShowTcqianggou = 1;
    }
}
## tcqianggou end
## tcptuan start
$__ShowTcptuan = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcptuan/tom_tcptuan.inc.php')){
    $tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
    if($tcptuanConfig['open_tcptuan'] == 1){
        $__ShowTcptuan = 1;
    }
}
## tcptuan end
## tcmall start
$__ShowTcmall = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcmall/tom_tcmall.inc.php')){
    $tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
    if($tcmallConfig['open_tcmall'] == 1){
        $__ShowTcmall = 1;
    }
}
## tcmall end
## tcdaojia start
$__ShowTcdaojia = 0;
$tcdaojiaConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/tom_tcdaojia.inc.php')){
    $tcdaojiaConfig = $_G['cache']['plugin']['tom_tcdaojia'];
    if($tcdaojiaConfig['open_tcdaojia'] == 1){
        $__ShowTcdaojia = 1;
    }
}
## tcdaojia end

$__IsMiniprogram = $__Ios = 0;
if(strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') !== false){$__Ios = 1;}
$cookie_tom_miniprogram = getcookie('tom_miniprogram');
if($cookie_tom_miniprogram == 1 || $_GET['f'] == 'miniprogram'){ $__IsMiniprogram = 1;}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/qqface.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

if($_GET['act'] == 'list' && $_GET['formhash'] == FORMHASH){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/ajax_list.php';
    
}else if($_GET['act'] == 'global_topnav_list' && $_GET['formhash'] == FORMHASH){

    $outStr = '';

    $navPopupListTmp = C::t('#tom_tongcheng#tom_tongcheng_nav_popup')->fetch_all_list(" AND site_id={$site_id} "," ORDER BY nsort ASC,id DESC ");
    if(is_array($navPopupListTmp) && !empty($navPopupListTmp)){
    }else{
        $navPopupListTmp = C::t('#tom_tongcheng#tom_tongcheng_nav_popup')->fetch_all_list(" AND site_id=1 "," ORDER BY nsort ASC,id DESC ");
    }
    $navPopupList = array();
    if(is_array($navPopupListTmp) && !empty($navPopupListTmp)){
        foreach ($navPopupListTmp as $key => $value){

            if($__IsMiniprogram == 1){
                if(!empty($jyConfig) && $jyConfig['closed_xiao'] == 1 && (strpos($value['link'], 'tom_love') !== FALSE || strpos($value['link'], 'tom_xiangqin') !== FALSE)){
                    continue;
                }else if(strpos($value['link'], 'tom_tchongbao') !== FALSE){
                    continue;
                }else if(!empty($tctoutiaoConfig) && $tctoutiaoConfig['closed_xiao'] == 1 && strpos($value['link'], 'tom_tctoutiao') !== FALSE){
                    continue;
                }
            }

            $navPopupList[$key] = $value;

            if($value['type'] == 1 && $value['model_id'] > 0){
                $modelInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($value['model_id']);

                $navPopupList[$key]['title']     = $modelInfoTmp['name'];
                $navPopupList[$key]['link']      = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=list&model_id={$value['model_id']}";

                $value['picurl'] = $modelInfoTmp['picurl'];
            }

            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurlTmp = $value['picurl'];
                }
            }else{
                $picurlTmp = $value['picurl'];
            }
            $navPopupList[$key]['picurl'] = $picurlTmp;

            $navPopupList[$key]['link'] = str_replace("{site}",$site_id, $navPopupList[$key]['link']);
        }
    }

    if(is_array($navPopupList) && !empty($navPopupList)){
        foreach ($navPopupList as $key => $val){

            $outStr.= '<a class="global-nav__item dislay-flex" href="'.$val['link'].'">';
                $outStr.= '<div class="item-box">';
                    $outStr.= '<div class="hd">';
                        $outStr.= '<img src="'.$val['picurl'].'">';
                        if(!empty($val['marker'])){
                            $outStr.= '<span class="marker">'.$val['marker'].'</span>';
                        }
                    $outStr.= '</div>';
                    $outStr.= '<div class="bd">'.$val['title'].'</div>';
                $outStr.= '</div>';
            $outStr.= '</a>';
        }

    }else{
        $outStr = '205';
    }
    $outStr = tom_link_replace($outStr);
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($_GET['act'] == 'collect' && $_GET['formhash'] == FORMHASH  && $userStatus){
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    $collectListTmp = C::t('#tom_tongcheng#tom_tongcheng_collect')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND tongcheng_id={$tongcheng_id} "," ORDER BY id DESC ",0,1);
    
    if(is_array($collectListTmp) && !empty($collectListTmp)){
        echo 100;exit;
    }
    
    $insertData = array();
    $insertData['user_id']      = $__UserInfo['id'];
    $insertData['tongcheng_id'] = $tongcheng_id;
    $insertData['add_time']     = TIMESTAMP;
    if(C::t('#tom_tongcheng#tom_tongcheng_collect')->insert($insertData)){
        
        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET collect=collect+1 WHERE id='$tongcheng_id' ", 'UNBUFFERED');
        
        $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
        
        if($tongchengInfo['site_id'] == 1){
            $sitename = $tongchengConfig['plugin_name'];
        }else{
            $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tongchengInfo['site_id']);
            $sitename = $siteInfo['name'];
        }

        if(empty($tongchengInfo['title'])){
            $tongchengInfo['title'] = cutstr(contentFormat($tongchengInfo['content']),20,"...");
        }
        
        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengInfo['user_id']);
        
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $appid = trim($tongchengConfig['wxpay_appid']);  
        $appsecret = trim($tongchengConfig['wxpay_appsecret']);
        $weixinClass = new weixinClass($appid,$appsecret);
        $access_token = $weixinClass->get_access_token();
        $nextSmsTime = $toUser['last_smstp_time'] + 1800;
        $smsContent = strip_tags($tongchengInfo['title']);
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=view&xxid={$tongcheng_id}");
        
        if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime ){
            $smsData = array(
                'first'         => $__UserInfo['nickname'].lang("plugin/tom_tongcheng", "dianzan_sms_title"),
                'keyword1'      => $sitename,
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => $smsContent
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);

            if($r){
                $updateData = array();
                $updateData['last_smstp_time'] = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
            }
        }
        
        echo 200;exit;
    }
    
    echo 404;exit;
    
}else if($_GET['act'] == 'clicks' && $_GET['formhash'] == FORMHASH){
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    DB::query("UPDATE ".DB::table('tom_tongcheng')." SET clicks=clicks+1 WHERE id='$tongcheng_id' ", 'UNBUFFERED');
    if($tongchengConfig['open_tj_commonclicks'] == 1){
        DB::query("UPDATE ".DB::table('tom_tongcheng_common')." SET clicks=clicks+1 WHERE id='$site_id' ", 'UNBUFFERED');
    }
    echo 200;exit;
    
}else if($_GET['act'] == 'commonClicks' && $_GET['formhash'] == FORMHASH){
    
    DB::query("UPDATE ".DB::table('tom_tongcheng_common')." SET clicks=clicks+1 WHERE id='$site_id' ", 'UNBUFFERED');
    echo 200;exit;
    
}else if($_GET['act'] == 'zhuanfa' && $_GET['formhash'] == FORMHASH){
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    DB::query("UPDATE ".DB::table('tom_tongcheng')." SET zhuanfa=zhuanfa+1 WHERE id='$tongcheng_id' ", 'UNBUFFERED');
    echo 200;exit;
    
}else if($_GET['act'] == 'updateTopstatus' && $_GET['formhash'] == FORMHASH){
    
    DB::query("UPDATE ".DB::table('tom_tongcheng')." SET toptime=0 WHERE topstatus=0 AND toptime>0 ", 'UNBUFFERED');
    
    $cookiesTopstatus = getcookie('tom_tongcheng_update_topstatus');
    if(!empty($cookiesTopstatus) && $cookiesTopstatus==1){
    }else{
        $tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list(" AND topstatus=1 AND toptime<".TIMESTAMP." "," ORDER BY toptime ASC,id DESC ",0,10);
        if(is_array($tongchengListTmp) && !empty($tongchengListTmp)){
            foreach ($tongchengListTmp as $key => $value){
                $updateData = array();
                $updateData['topstatus']     = 0;
                $updateData['toptime']       = 0;
                $updateData['toprand']       = 1;
                C::t('#tom_tongcheng#tom_tongcheng')->update($value['id'],$updateData);
            }
        }
        dsetcookie('tom_tongcheng_update_topstatus',1,300);
    }
    echo 200;exit;
    
}else if($_GET['act'] == 'vip_auto_refresh' && $_GET['formhash'] == FORMHASH){
    
    if($__ShowTcyikatong == 1 && $tcyikatongConfig['open_fenlei_auto_refresh'] == 1){
    }else{
        echo 400;exit;
    }
    
    $cookiesRefreshstatus = getcookie('tom_tongcheng_vip_auto_refresh');
    if(!empty($cookiesRefreshstatus) && $cookiesRefreshstatus==1){
    }else{
        $ntime = TIMESTAMP;
        $cardList = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_all_list(" AND status=1 AND expire_time > {$ntime}  "," ORDER BY id DESC ",0,1000);
        $cardListUserIds = array();
        if(is_array($cardList) && !empty($cardList)){
            foreach ($cardList as $key => $value){
                $cardListUserIds[] = $value['user_id'];
            }
        }
        $auto_refresh_time = $nowDayTime + 480;
        if(is_array($cardListUserIds) && !empty($cardListUserIds)){
            DB::query("UPDATE ".DB::table('tom_tongcheng')." SET refresh_time=".$auto_refresh_time." WHERE user_id IN(".  implode(',', $cardListUserIds).") AND status=1 AND shenhe_status=1 AND finish=0 AND tczhaopin_id=0 AND tczhaopin_resume_id=0 AND tcfangchan_id=0 AND tcershou_goods_id=0 AND tcershou_needs_id=0 AND tcfangchan_needs_id=0 AND refresh_time<{$nowDayTime} ", 'UNBUFFERED');
        }
        
        dsetcookie('tom_tongcheng_vip_auto_refresh',1,300);
    }
    echo 200;exit;
    
}else if($_GET['act'] == 'updateToprand' && $_GET['formhash'] == FORMHASH){
    
    $cookiesToprand = getcookie('tom_tongcheng_update_toprand');
    if(!empty($cookiesToprand) && $cookiesToprand==1){
    }else{
        $m = dgmdate(TIMESTAMP,'i',$tomSysOffset);
        $m = $m * 1;
        if($m > 0 && $m < 10){
            $tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list(" AND topstatus=1 "," ORDER BY toprand DESC,id DESC ",0,50);
            if(is_array($tongchengListTmp) && !empty($tongchengListTmp)){
                foreach ($tongchengListTmp as $key => $value){
                    if($value['topstatus'] == 1 && (TIMESTAMP - $value['refresh_time']) > 1800){
                        $toprand = mt_rand(111, 999);
                        DB::query("UPDATE ".DB::table('tom_tongcheng')." SET toprand=".$toprand." WHERE id='{$value['id']}' ", 'UNBUFFERED');
                    }
                }
            }
            echo 200;exit;
            dsetcookie('tom_tongcheng_update_toprand',1,300);
        }
    }
    echo 100;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $model_id = intval($_GET['model_id'])>0? intval($_GET['model_id']):0;
    $type_id  = intval($_GET['type_id'])>0? intval($_GET['type_id']):0;
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=list&model_id={$model_id}&type_id={$type_id}&keyword=".urlencode(trim($keyword));
    $url = tom_link_replace($url);
    echo $url;exit;
    
}else if($_GET['act'] == 'updateStatus' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    
    if($tongchengInfo['user_id'] != $__UserInfo['id']){
        echo '404';exit;
    }
    
    if($_GET['status'] == 1){
        $updateData = array();
        $updateData['status'] = 1;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id,$updateData);
    }else if($_GET['status'] == 2){
        $updateData = array();
        $updateData['status'] = 2;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id,$updateData);
    }
    
    echo 200;exit;
}else if($_GET['act'] == 'updateFinish' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    
    if($tongchengInfo['user_id'] != $__UserInfo['id']){
        echo '404';exit;
    }
    
    $updateData = array();
    $updateData['finish']    = 1;
    if($tongchengInfo['over_time'] > 0){
        $updateData['over_time'] = TIMESTAMP;
    }
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id,$updateData);
    
    echo 200;exit;
    
}else if($_GET['act'] == 'refresh' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    
    if($tongchengInfo['user_id'] != $__UserInfo['id']){
        echo '404';exit;
    }
    
    if($__UserInfo['editor']==1){
        $tongchengConfig['free_refresh_times'] = 9999;
    }
    
    $count = C::t('#tom_tongcheng#tom_tongcheng_refresh_log')->fetch_all_count(" AND user_id={$tongchengInfo['user_id']} AND time_key={$nowDayTime} AND type = 1 ");
    if($count >= $tongchengConfig['free_refresh_times']){
        echo '404';exit;
    }
    
    $updateData = array();
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id,$updateData);
    
    $insertData = array();
    $insertData['user_id']      = $tongchengInfo['user_id'];
    $insertData['tongcheng_id'] = $tongcheng_id;
    $insertData['type']         = 1;
    $insertData['time_key']     = $nowDayTime;
    $insertData['add_time']     = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_refresh_log')->insert($insertData);
    
    echo 200;exit;
}else if($_GET['act'] == 'refresh3' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
    
    if($tongchengConfig['open_refresh_score_pay'] == 0){
        echo '404';exit;
    }
    
    if($tongchengInfo['user_id'] != $__UserInfo['id']){
        echo '404';exit;
    }
    
    $useScore = $tongchengConfig['pay_score_yuan']*$typeInfo['refresh_price'];
    $useScore = ceil($useScore);
    
    if($useScore > $__UserInfo['score']){
        echo '301';exit;
    }
    
    $updateData = array();
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id,$updateData);
    
    $updateData = array();
    $updateData['score'] = $__UserInfo['score'] - $useScore;
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);

    $insertData = array();
    $insertData['user_id']          = $__UserInfo['id'];
    $insertData['score_value']      = $useScore;
    $insertData['old_value']        = $__UserInfo['score'];
    $insertData['log_type']         = 5;
    $insertData['log_time']         = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    
    echo 200;exit;
}else if($_GET['act'] == 'refresh4' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    
    if($tongchengInfo['user_id'] != $__UserInfo['id']){
        echo '404';exit;
    }
    
    ## VIP start
    $_isVipTequan = 0;
    if($__ShowTcyikatong == 1 && $tcyikatongConfig['open_fenlei_tequan'] == 1){
        $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($__UserInfo['id']);
        if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
            $_isVipTequan = 1;
        }
    }
    ## VIP end
    
    if($_isVipTequan == 1){
        
        $count = C::t('#tom_tongcheng#tom_tongcheng_refresh_log')->fetch_all_count(" AND user_id={$tongchengInfo['user_id']} AND time_key={$nowDayTime} AND type = 2 ");
        if($count >= $tcyikatongConfig['free_fenlei_refresh_num']){
            echo '404';exit;
        }
        
        $updateData = array();
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id,$updateData);
        
        $insertData = array();
        $insertData['user_id']      = $tongchengInfo['user_id'];
        $insertData['tongcheng_id'] = $tongcheng_id;
        $insertData['type']         = 2;
        $insertData['time_key']     = $nowDayTime;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_refresh_log')->insert($insertData);
    }
    
    echo 200;exit;
}else if($_GET['act'] == 'refresh5' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    
    if($tongchengInfo['user_id'] != $__UserInfo['id']){
        echo '404';exit;
    }
    
    if($__UserInfo['refresh_num'] > 0){
        
        $updateData = array();
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id,$updateData);
        
        $updateData = array();
        $updateData['refresh_num'] = $__UserInfo['refresh_num'] - 1;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
        
        $insertData = array();
        $insertData['user_id']          = $tongchengInfo['user_id'];
        $insertData['tongcheng_id']     = $tongcheng_id;
        $insertData['type']             = 3;
        $insertData['time_key']         = $nowDayTime;
        $insertData['old_refresh_num']  = $__UserInfo['refresh_num'];
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_refresh_log')->insert($insertData);
    }
    
    echo 200;exit;
}else if($_GET['act'] == 'get_tel' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
    
    $useScore = $tongchengConfig['pay_score_yuan']*$typeInfo['tel_price'];
    $useScore = ceil($useScore);
    
    if($useScore > $__UserInfo['score']){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['score'] = $__UserInfo['score'] - $useScore;
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);

    $insertData = array();
    $insertData['user_id']          = $__UserInfo['id'];
    $insertData['score_value']      = $useScore;
    $insertData['old_value']        = $__UserInfo['score'];
    $insertData['log_type']         = 25;
    $insertData['log_time']         = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    
    $insertData = array();
    $insertData['user_id']          = $__UserInfo['id'];
    $insertData['type']             = 1;
    $insertData['object_id']        = $tongcheng_id;
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tel')->insert($insertData);
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'list_get_street' && $_GET['formhash'] == FORMHASH){
    
    $outStr = '';
    
    $area_id   = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
    
    if($area_id > 0 && is_array($streetList) && !empty($streetList)){
        $outStr = '<li class="item" data-id="0" data-name="'.lang("plugin/tom_tongcheng", "template_list_all").'">'.lang("plugin/tom_tongcheng", "template_list_all").'</li>';
        foreach ($streetList as $key => $value){
           $outStr.= '<li class="item" data-id="'.$value['id'].'" data-name="'.$value['name'].'">'.$value['name'].'</li>';
        }
    }else{
       $outStr = '100';
    }
    
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($_GET['act'] == 'list_get_type' && $_GET['formhash'] == FORMHASH){
    
    $outStr = '';
    
    $model_id   = intval($_GET['model_id'])>0? intval($_GET['model_id']):0;
    
    $typeList = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_all_list(" AND model_id={$model_id} "," ORDER BY paixu ASC,id DESC ",0,100);
    
    if(is_array($typeList) && !empty($typeList)){
        $outStr = '<li class="item" data-id="0" data-name="'.lang("plugin/tom_tongcheng", "template_list_all").'">'.lang("plugin/tom_tongcheng", "template_list_all").'</li>';
        foreach ($typeList as $key => $value){
           $outStr.= '<li class="item" data-id="'.$value['id'].'" data-name="'.$value['name'].'">'.$value['name'].'</li>';
        }
    }else{
       $outStr = '100';
    }
    
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($_GET['act'] == 'auto_click' && $_GET['formhash'] == FORMHASH){
    
    $cookies_auto_click_status = getcookie('tom_tongcheng_auto_click_status');
    $halfhour = TIMESTAMP - 1800;
    $threedays = TIMESTAMP - 86400*3;
    if($tongchengConfig['open_auto_click'] == 1){
        
        $auto_min_num = 5;
        $auto_max_num = 10;
        if($tongchengConfig['auto_min_num'] < $tongchengConfig['auto_max_num']){
            $auto_min_num = $tongchengConfig['auto_min_num'];
            $auto_max_num = $tongchengConfig['auto_max_num'];
        }
        
        if(!empty($cookies_auto_click_status) && $cookies_auto_click_status==1){
        }else{
            $tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND add_time<".$halfhour." AND auto_click_time<".$nowDayTime." AND ( refresh_time>".$threedays." OR topstatus=1 ) "," ORDER BY refresh_time DESC ",0,20);
            if(is_array($tongchengListTmp) && !empty($tongchengListTmp)){
                $i = 0;
                foreach ($tongchengListTmp as $key => $value){
                    if($value['topstatus'] == 1){
                        $auto_click_num = mt_rand($auto_min_num*2, $auto_max_num*2);
                    }else{
                        $auto_click_num = mt_rand($auto_min_num, $auto_max_num);
                    }
                    $i = $i + $auto_click_num;
                    $updateData = array();
                    $updateData['clicks']     = $value['clicks'] + $auto_click_num;
                    $updateData['auto_click_time']     = $nowDayTime;
                    C::t('#tom_tongcheng#tom_tongcheng')->update($value['id'],$updateData);
                }
                if($tongchengConfig['open_tj_commonclicks'] == 1){
                    DB::query("UPDATE ".DB::table('tom_tongcheng_common')." SET clicks=clicks+{$i} WHERE id='$site_id' ", 'UNBUFFERED');
                }
            }
            dsetcookie('tom_tongcheng_auto_click_status',1,300);
        }
    }
    
    echo 200;exit;

}else if($_GET['act'] == 'auto_zhuanfa' && $_GET['formhash'] == FORMHASH){
    
    $cookies_auto_zhuanfa_status = getcookie('tom_tongcheng_auto_zhuanfa_status');
    $halfhour = TIMESTAMP - 1800;
    $threedays = TIMESTAMP - 86400*3;
    if($tongchengConfig['open_auto_zhuanfa'] == 1){
        
        $auto_min_num = 1;
        $auto_max_num = 10;
        if($tongchengConfig['min_zhuanfa_num'] < $tongchengConfig['max_zhuanfa_num']){
            $auto_min_num = $tongchengConfig['min_zhuanfa_num'];
            $auto_max_num = $tongchengConfig['max_zhuanfa_num'];
        }

        if(!empty($cookies_auto_zhuanfa_status) && $cookies_auto_zhuanfa_status==1){
        }else{
            $tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND add_time<".$halfhour." AND auto_zhuanfa_time<".$nowDayTime." AND refresh_time>".$threedays." "," ORDER BY refresh_time DESC ",0,20);
            if(is_array($tongchengListTmp) && !empty($tongchengListTmp)){
                foreach ($tongchengListTmp as $key => $value){
                    
                    $auto_zhuanfa_num = mt_rand($auto_min_num, $auto_max_num);
                    
                    if(($value['zhuanfa'] + $auto_zhuanfa_num) < $value['clicks']){
                        $updateData = array();
                        $updateData['zhuanfa']     = $value['zhuanfa'] + $auto_zhuanfa_num;
                        $updateData['auto_zhuanfa_time']     = $nowDayTime;
                        C::t('#tom_tongcheng#tom_tongcheng')->update($value['id'],$updateData);
                        echo $value['id'].'---';
                    }
                }
            }
            dsetcookie('tom_tongcheng_auto_zhuanfa_status',1,300);
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'shenhe_sms' && $_GET['formhash'] == FORMHASH){
    
    $cookies_shenhe_sms_status = getcookie('tom_tongcheng_shenhe_sms_status');
    
    if(!empty($cookies_shenhe_sms_status) && $cookies_shenhe_sms_status==1){
        echo 404;exit;
    }else{
        $noShenheCount = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count(" AND site_id={$site_id} AND pay_status!=1 AND shenhe_status=2 AND tczhaopin_id=0 AND tczhaopin_resume_id=0 AND tcfangchan_id=0 AND tcershou_goods_id=0 AND tcershou_needs_id=0 AND tcfangchan_needs_id=0 ");
    
        if($noShenheCount >0){
        }else{
            echo 0;exit;
        }

        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);

        $toUser = array();
        $toUserId = 0;
        $toUserName = '';
        if(!empty($sitesInfo['manage_user_id'])){
            $toUserId = $sitesInfo['manage_user_id'];
            $toUserName = $sitesInfo['name'];
        }else if(!empty($tongchengConfig['manage_user_id'])){
            $toUserId = $tongchengConfig['manage_user_id'];
            $toUserName = $tongchengConfig['plugin_name'];
        }

        if(empty($toUserId)){
            echo 1;exit;
        }

        $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($toUserId);
        if($toUserTmp && !empty($toUserTmp['openid'])){
            $toUser = $toUserTmp;
        }else{
            echo 2;exit;
        }
        
        $appid = trim($tongchengConfig['wxpay_appid']);  
        $appsecret = trim($tongchengConfig['wxpay_appsecret']);
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);

        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        $nextSmsTime = $toUser['last_smstp_time'] + 300;

        if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=managerList&type=1");
            $shenhe_template_first = str_replace("{NUM}",$noShenheCount, lang('plugin/tom_tongcheng','shenhe_template_first'));
            $smsData = array(
                'first'         => $shenhe_template_first,
                'keyword1'      => $toUserName,
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);

            if($r){
                $updateData = array();
                $updateData['last_smstp_time'] = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
            }

        }

        dsetcookie('tom_tongcheng_shenhe_sms_status',1,300);
    }
    
    echo 200;exit;

}else if($_GET['act'] == 'pinglun' && submitcheck('user_id') && $userStatus){
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $touser_id = isset($_GET['touser_id'])? intval($_GET['touser_id']):0;
    $content = isset($_GET['content'])? daddslashes($_GET['content']):'';
    $content = dhtmlspecialchars($content);
    $tongcheng_id = isset($_GET['tongcheng_id'])? intval($_GET['tongcheng_id']):0;
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    if($userInfo['status'] != 1 || $__UserInfo['status'] != 1){
        $outArr = array(
            'status'=> 1,
        );
        echo json_encode($outArr); exit;
    }
    
    $__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
    if(!empty($__CommonInfo['forbid_word'])){
        $forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
        $forbid_word = str_replace(array("\\*"), array('.*'), $forbid_word);
        $forbid_word = '.*('.$forbid_word.').*';
        $forbid_word = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word).')$/i';
        if(@preg_match($forbid_word, $content,$matches)) {
            $i = count($matches)-1;
            $word = '';
            if(isset($matches[$i]) && !empty($matches[$i])){
                $word = diconv($matches[$i],CHARSET,'utf-8');
            }
            $outArr = array(
                'status'=> 505,
                'word'=> $word,
            );
            echo json_encode($outArr); exit;
        }
                
    }
    
    if($__ShowXiaofenlei == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php';
        if($xiaofenleiConfig['open_msgseccheck'] == 1){
            @$s_m_r = wx_msgSecCheck($content);
            if($s_m_r['code'] == 100 || $s_m_r['code'] == 500){
                $outArr = array(
                    'status'=> 505,
                    'word'=> $s_m_r['word'],
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    
    $pinglun_setting = explode("|", $tongchengConfig['pinglun_setting']);
    $pinglun_setting_next_minute = intval($pinglun_setting[0]);
    $pinglun_setting_24_num = intval($pinglun_setting[1]);
    $_24_hours = TIMESTAMP - 86400;
    
    $lastPinglunListTmp = C::t('#tom_tongcheng#tom_tongcheng_pinglun')->fetch_all_list(" AND user_id={$user_id} "," ORDER BY id DESC ",0,1);
    if($lastPinglunListTmp && $lastPinglunListTmp[0]['ping_time'] > 0 && $userInfo['editor']==0){
        $nextPingTime = $lastPinglunListTmp[0]['ping_time'] + $pinglun_setting_next_minute*60;
        if($nextPingTime > TIMESTAMP){
            $outArr = array(
                'status'=> 401,
                'minute'=> $pinglun_setting_next_minute,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $_24PinglunCount = C::t('#tom_tongcheng#tom_tongcheng_pinglun')->fetch_all_count(" AND user_id={$user_id} AND ping_time > {$_24_hours} ");
    if($_24PinglunCount >= $pinglun_setting_24_num && $userInfo['editor']==0){
        $outArr = array(
            'status'=> 402,
            'num'=> $pinglun_setting_24_num,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tongchengInfo['site_id'] == 1){
        $sitename = $tongchengConfig['plugin_name'];
    }else{
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tongchengInfo['site_id']);
        $sitename = $siteInfo['name'];
    }
    
    if(empty($tongchengInfo['title'])){
        $tongchengInfo['title'] = cutstr(contentFormat($tongchengInfo['content']),20,"...");
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $appid = trim($tongchengConfig['wxpay_appid']);  
    $appsecret = trim($tongchengConfig['wxpay_appsecret']);
    $weixinClass = new weixinClass($appid,$appsecret);
    $access_token = $weixinClass->get_access_token();
    $nextSmsTime = $userInfo['last_smstp_time'] + 0;
    $smsContent = strip_tags($content);
    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=message");
    
    if($touser_id > 0){
        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($touser_id);
        
        $insertData = array();
        $insertData['tongcheng_id']     = $tongcheng_id;
        $insertData['user_id']          = $user_id;
        $insertData['touser_id']        = $touser_id;
        $insertData['touser_nickname']  = $toUser['nickname'];
        $insertData['touser_avatar']    = $toUser['picurl'];
        $insertData['content']          = $content;
        $insertData['ping_time']        = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_pinglun')->insert($insertData);
        $pinglunId = C::t('#tom_tongcheng#tom_tongcheng_pinglun')->insert_id();
        
        if($tongchengInfo){
            $message = strip_tags($content);
            $message = contentFormat($message);
            $message = $message.'<br/><a href="plugin.php?id=tom_tongcheng&site='.$tongchengInfo['site_id'].'&mod=info&xxid='.$tongchengInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';

            $insertData = array();
            $insertData['user_id']      = $toUser['id'];
            $insertData['type']         = 1;
            $insertData['content']      = '<font color="#238206">'.lang('plugin/tom_tongcheng', 'ajax_pinglun_title').'</font><br/>'.$userInfo['nickname'].lang('plugin/tom_tongcheng', 'ajax_touser_1_reply').$tongchengInfo['title'].lang('plugin/tom_tongcheng', 'ajax_touser_2_reply').dhtmlspecialchars($pinglunInfo['content']).';<br/>'.lang('plugin/tom_tongcheng', 'ajax_touser_reply_pinglun').$message;
            $insertData['is_read']      = 0;
            $insertData['tz_time']      = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        }
        
        if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime ){
            $smsData = array(
                'first'         => $userInfo['nickname'].lang('plugin/tom_tongcheng', 'ajax_pinglun_reply_hueifu'),
                'keyword1'      => $sitename,
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => $smsContent
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);

            if($r){
                $updateData = array();
                $updateData['last_smstp_time'] = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
            }
        }
        $outArr = array(
            'status'=> 200200,
            'pinglun_id'=> $pinglunId,
        );
        echo json_encode($outArr); exit;
    }else{
        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengInfo['user_id']);
        
        $insertData = array();
        $insertData['tongcheng_id'] = $tongcheng_id;
        $insertData['content'] = $content;
        $insertData['user_id'] = $user_id;
        $insertData['ping_time'] = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_pinglun')->insert($insertData);
        $pinglunId = C::t('#tom_tongcheng#tom_tongcheng_pinglun')->insert_id();
        
        if($tongchengInfo){
            $message = strip_tags($content);
            $message = contentFormat($message);
            $message = $message.'<br/><a href="plugin.php?id=tom_tongcheng&site='.$tongchengInfo['site_id'].'&mod=info&xxid='.$tongchengInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';

            $insertData = array();
            $insertData['user_id']      = $toUser['id'];
            $insertData['type']     = 1;
            $insertData['content']      = '<font color="#238206">'.lang('plugin/tom_tongcheng', 'ajax_pinglun_title').'</font><br/>'.$userInfo['nickname'].lang('plugin/tom_tongcheng', 'ajax_touser_1').$tongchengInfo['title'].lang('plugin/tom_tongcheng', 'ajax_touser_2').'<br/>'.lang('plugin/tom_tongcheng', 'ajax_touser_pinglun_content').$message;
            $insertData['is_read']     = 0;
            $insertData['tz_time']     = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        }
        
        if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime ){
            $smsData = array(
                'first'         => $userInfo['nickname'].lang('plugin/tom_tongcheng', 'ajax_pinglun_reply_hueifu'),
                'keyword1'      => $sitename,
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => $smsContent
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);

            if($r){
                $updateData = array();
                $updateData['last_smstp_time'] = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
            }
        }
        $outArr = array(
            'status'=> 200,
            'pinglun_id'=> $pinglunId,
        );
        echo json_encode($outArr); exit;
    }
    $outArr = array(
        'status'=> 1
    );
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'loadPinglun' && $_GET['formhash'] == FORMHASH){
    $outStr = '';
    
    $tongcheng_id = isset($_GET['tongcheng_id'])? intval($_GET['tongcheng_id']):0;
    $loadPage   = intval($_GET['loadPage'])>0? intval($_GET['loadPage']):1;
    $pinglun_num   = intval($_GET['pinglun_num'])>0? intval($_GET['pinglun_num']):0;
    $pagesize = 5;
    $start = ($loadPage - 1) * $pagesize;
    $start = $start - $pinglun_num;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    $pinglunListTmp = C::t('#tom_tongcheng#tom_tongcheng_pinglun')->fetch_all_list(" AND tongcheng_id = {$tongcheng_id} ", 'ORDER BY ping_time DESC,id DESC', $start, $pagesize);

    if(is_array($pinglunListTmp) && !empty($pinglunListTmp)){
        foreach($pinglunListTmp as $key => $value){
            $value['content'] = cutstr($value['content'], 260, '..');
            $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
            if($value['touser_id'] > 0){
                $userInfo['nickname'] = cutstr($userInfo['nickname'], 10, '...');
            }
            $outStr.= '<div class="comment-item clearfix" id="comment-item_'.$value['id'].'" data-id="'.$tongchengInfo['id'].'" data-touserid="'.$userInfo['id'].'" data-tonickname="'.$userInfo['nickname'].'">';
                $outStr.= '<div class="comment-item-avatar"><img src="'.$userInfo['picurl'].'"></div>';
                $outStr.= '<div class="comment-item-content">';
                
                $outStr.='<h5>';
                    $outStr.='<span onClick="comment_reply(this);">'.$userInfo['nickname'].'</span>';
                    if($value['touser_id'] > 0){
                        $touser_nickname = cutstr($value['touser_nickname'], 10, '...');
                        $outStr.='<span class="hf">&nbsp;'.lang('plugin/tom_tongcheng', 'pinglun_hueifu').lang('plugin/tom_tongcheng', 'pinglun_hueifu_dian').'&nbsp;</span><span onClick="comment_reply(this);">'.$touser_nickname.'</span>';
                    }
                    $outStr.='<span class="right remove" onClick="removePinglun('.$value['id'].');">'.lang('plugin/tom_tongcheng', 'info_comment_del').'</span>';
                    $outStr.='<span class="right" onClick="comment_reply(this);">'.dgmdate($value['ping_time'],"Y-m-d",$tomSysOffset).'</span>';
                $outStr.='</h5>';
                
                $outStr.= '<div class="comment-item-content-text" onClick="comment_reply(this);">'.qqface_replace(dhtmlspecialchars($value['content'])).'</div>';
                $replyListTmp = C::t('#tom_tongcheng#tom_tongcheng_pinglun_reply')->fetch_all_list(" AND tongcheng_id = {$tongcheng_id} AND ping_id = {$value['id']} ", "ORDER BY reply_time ASC,id ASC", 0, 1000);
                if(is_array($replyListTmp) && !empty($replyListTmp)){
                    $outStr .= '<div class="comment_reply_pinglun_box" style="display:none;">';
                    foreach($replyListTmp as $k => $v){
                        if($tongchengInfo['user_id'] == $v['reply_user_id']){
                            $outStr.= '<div id="comment-item-content-text_'.$v['id'].'" class="comment-item-content-text"><span>'.$v['reply_user_nickname'].'&nbsp;<span class="floor_main">'.lang('plugin/tom_tongcheng', 'info_pinglun_floor_main').'</span>'.lang('plugin/tom_tongcheng','pinglun_hueifu_dian').'&nbsp;</span>'.qqface_replace(dhtmlspecialchars($v['content'])).'&nbsp;&nbsp;<span class="remove" onClick="removeReply('.$v['id'].');">'.lang('plugin/tom_tongcheng','info_comment_del').'</span></div>';
                        }else{
                            $outStr.= '<div id="comment-item-content-text_'.$v['id'].'" class="comment-item-content-text"><span>'.$v['reply_user_nickname'].lang('plugin/tom_tongcheng','pinglun_hueifu_dian').'&nbsp;</span>'.qqface_replace(dhtmlspecialchars($v['content'])).'&nbsp;&nbsp;<span class="remove" onClick="removeReply('.$v['id'].');">'.lang('plugin/tom_tongcheng','info_comment_del').'</span></div>';
                        }
                    }
                    $outStr .= '</div>';
                }
                    
                $outStr.= '</div>';
            $outStr.= '</div>';        
        }
        
    }else{
        $outStr = '201';
    }
    
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($_GET['act'] == 'removePinglun' && $_GET['formhash'] == FORMHASH  && $userStatus){
    $ping_id = isset($_GET['ping_id'])? intval($_GET['ping_id']): 0;
    if(C::t('#tom_tongcheng#tom_tongcheng_pinglun')->delete_by_id($ping_id)){
        C::t('#tom_tongcheng#tom_tongcheng_pinglun_reply')->delete_pinglun_id($ping_id);
        echo 200;exit;
    }
    echo 1;exit;
    
}else if($_GET['act'] == 'removeReplyPinglun' && $_GET['formhash'] == FORMHASH  && $userStatus){
    $reply_id = isset($_GET['reply_id'])? intval($_GET['reply_id']): 0;
    C::t('#tom_tongcheng#tom_tongcheng_pinglun_reply')->delete_by_id($reply_id);
    echo 200;exit;
    
}else if($_GET['act'] == 'browser_shouchang' && $_GET['formhash'] == FORMHASH){
    $user_id = isset($_GET['user_id'])? intval($_GET['user_id']): 0;
    
    $lifeTime = 86400*3;
    dsetcookie('tom_tongcheng_browser_shouchang_'.$user_id, $user_id, $lifeTime);
    echo '200';exit;
    
}else if($_GET['act'] == 'zhuanfaScore' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    echo 100;exit;
    
    $score_log_count = C::t('#tom_tongcheng#tom_tongcheng_score_log')->fetch_all_count(" AND user_id={$__UserInfo['id']} AND log_type=6 AND time_key={$nowDayTime} ");
    
    if($tongchengConfig['score_share_time'] > $score_log_count){
        $updateData = array();
        $updateData['score'] = $__UserInfo['score'] + $tongchengConfig['score_share_num'];
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $__UserInfo['id'];
        $insertData['score_value']      = $tongchengConfig['score_share_num'];
        $insertData['old_value']        = $__UserInfo['score'];
        $insertData['log_type']         = 6;
        $insertData['log_time']         = TIMESTAMP;
        $insertData['time_key']         = $nowDayTime;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        echo 200;exit;
    }
    echo 201;exit;
    
}else if($_GET['act'] == 'load_popup' && $_GET['formhash'] == FORMHASH){
    
    $outStr = '';
    
    $popupTmp = C::t('#tom_tongcheng#tom_tongcheng_popup')->fetch_all_by_site_ids(" AND status=1 " ," ORDER BY id DESC ",0,1,'['.$site_id.']' );
    if($popupTmp && !empty($popupTmp[0])){
        $popupInfo = $popupTmp[0];
        
        $popupLogTmp = array();
        if($__UserInfo['id'] > 0 && $popupInfo['show_num'] > 0){
            $popupLogTmp = C::t("#tom_tongcheng#tom_tongcheng_popup_log")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND popup_id = {$popupInfo['id']} ");
            if(is_array($popupLogTmp) && isset($popupLogTmp[0]['num']) && $popupLogTmp[0]['num'] >= $popupInfo['show_num']){
                echo 201;exit;
            }
        }
        
        $cookies_popup = getcookie('tom_tongcheng_popup_'.$popupInfo['id']);
        if(!empty($cookies_popup) && $cookies_popup==1){
            echo 201;exit;
        }else{
            
            DB::query("UPDATE ".DB::table('tom_tongcheng_popup')." SET clicks=clicks+1 WHERE id='{$popupInfo['id']}' ", 'UNBUFFERED');
            
            $popupInfo['link'] = str_replace("{site}",$site_id, $popupInfo['link']);
            
            if($popupInfo['type'] == 1){
                $outStr.= '<div id="popup_ads_animation" class="popup_ads_box">';
                    $outStr.= '<h5>'.$popupInfo['title'].'</h5>';
                    $outStr.= '<div class="content">'.stripslashes($popupInfo['content']).'</div>';
                    $outStr.= '<div class="btn">';
                        $outStr.= '<a href="javascript:void(0);" class="no" onclick="closePopup('.$popupInfo['id'].');">'.lang("plugin/tom_tongcheng", "popup_no_btn").'</a>';
                        $outStr.= '<a href="javascript:void(0);" class="ok" onclick="likePopup('.$popupInfo['id'].',\''.$popupInfo['link'].'\')" >'.lang("plugin/tom_tongcheng", "popup_ok_btn").'</a>';
                    $outStr.= '</div>';
                    $outStr.= '<div class="close" onclick="closePopup('.$popupInfo['id'].');"></div>';
                $outStr.= '</div>';
            }else if($popupInfo['type'] == 2){
                
                if(!preg_match('/^http/', $popupInfo['picurl']) ){
                    if(strpos($popupInfo['picurl'], 'source/plugin/tom_') === FALSE){
                        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$popupInfo['picurl'];
                    }else{
                        $picurl = $popupInfo['picurl'];
                    }
                }else{
                    $picurl = $popupInfo['picurl'];
                }
                
                $outStr.= '<div class="popup_ads__pic">';
                    $outStr.= '<div class="ads-pic__box">';
                        $outStr.= '<a class="ads-pic__hd" href="'.$popupInfo['link'].'">';
                            $outStr.= '<img src="'.$picurl.'">';
                        $outStr.= '</a>';
                        $outStr.= '<div class="ads-pic__bd">';
                            $outStr.= '<div class="pic-close" onclick="closePopup('.$popupInfo['id'].');"></div>';
                        $outStr.= '</div>';
                    $outStr.= '</div>';
                $outStr.= '</div>';
            }
            
            if($__UserInfo['id'] > 0 && $popupInfo['show_num'] > 0){
                if(is_array($popupLogTmp) && isset($popupLogTmp[0]['num'])){
                    DB::query("UPDATE ".DB::table('tom_tongcheng_popup_log')." SET num=num+1 WHERE id='{$popupLogTmp[0]['id']}' ", 'UNBUFFERED');
                }else{
                    $insertData = array();
                    $insertData['popup_id'] = $popupInfo['id'];
                    $insertData['user_id']  = $__UserInfo['id'];
                    $insertData['num']      = 1;
                    $insertData['log_time'] = TIMESTAMP;
                    C::t("#tom_tongcheng#tom_tongcheng_popup_log")->insert($insertData);
                }
            }
            
            $outStr = diconv($outStr,CHARSET,'utf-8');
            echo json_encode($outStr); exit;
        }
    }
    
    
    echo 201;exit;
    
}else if($_GET['act'] == 'close_popup' && $_GET['formhash'] == FORMHASH){
    
    $popup_id = isset($_GET['popup_id'])? intval($_GET['popup_id']): 0;
    dsetcookie('tom_tongcheng_popup_'.$popup_id,1,86400);
    
    echo 201;exit;
    
}else if($_GET['act'] == 'hongbao_tz' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $new_hongbao_tz = 0;
    if($__UserInfo['hongbao_tz'] == 1){
        $new_hongbao_tz = 0;
    }else{
        $new_hongbao_tz = 1;
    }
    
    $updateData = array();
    $updateData['hongbao_tz'] = $new_hongbao_tz;
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
    
    if($new_hongbao_tz == 1){
        echo 200;exit;
    }else{
        echo 100;exit;
    }
    
}else if($_GET['act'] == 'loadPmlist' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $outStr = '';
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $doPmListTmp = C::t('#tom_tongcheng#tom_tongcheng_pm')->fetch_all_list2(" AND a.user_id={$__UserInfo['id']} AND a.new_num > 0 AND b.last_content = 'NULL-NULL-NULL-NULL-NULL-NULL' "," ORDER BY a.id DESC ",0,10);
    if(is_array($doPmListTmp) && !empty($doPmListTmp)){
        foreach ($doPmListTmp as $key => $value){
            DB::query("UPDATE ".DB::table('tom_tongcheng_pm')." SET new_num=0 WHERE user_id='{$__UserInfo['id']}' AND pm_lists_id='{$value['pm_lists_id']}' ", 'UNBUFFERED');
        }
    }

    $pagesize       = 8;
    $start          = ($page - 1)*$pagesize;
    $pmListTmp = C::t('#tom_tongcheng#tom_tongcheng_pm')->fetch_all_list2(" AND a.user_id={$__UserInfo['id']} AND b.last_content != 'NULL-NULL-NULL-NULL-NULL-NULL' "," ORDER BY a.last_time DESC,a.id DESC ",$start,$pagesize);
    $pmList = array();
    if(is_array($pmListTmp) && !empty($pmListTmp)){
        foreach ($pmListTmp as $key => $value){
            $pmListsTmp = C::t('#tom_tongcheng#tom_tongcheng_pm_lists')->fetch_by_id($value['pm_lists_id']);
            if($pmListsTmp['min_use_id'] == $__UserInfo['id']){
                $toUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($pmListsTmp['max_use_id']);
            }else{
                $toUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($pmListsTmp['min_use_id']);
            }
            if('NULL-NULL-NULL-NULL-NULL-NULL' != $pmListsTmp['last_content']){
                $pmListsTmp['last_content'] = strip_tags($pmListsTmp['last_content']);
                $pmList[$key] = $value;
                $pmList[$key]['last_content'] = dhtmlspecialchars($pmListsTmp['last_content']);
                $pmList[$key]['toUserInfo'] = $toUserInfoTmp;
            }else if($value['new_num']>0){
                DB::query("UPDATE ".DB::table('tom_tongcheng_pm')." SET new_num=0 WHERE user_id='{$__UserInfo['id']}' AND pm_lists_id='{$value['pm_lists_id']}' ", 'UNBUFFERED');
            }
        }
    }
    
    if(is_array($pmList) && !empty($pmList)){
        foreach ($pmList as $key => $val){
            $outStr.= '<section class="msg-list">';
               $outStr.= '<a href="plugin.php?id=tom_tongcheng&site='.$site_id.'&mod=message&act=sms&pm_lists_id='.$val['pm_lists_id'].'">';
                    $outStr.= '<section class="msg-list-pic">';
                         $outStr.= '<img src="'.$val['toUserInfo']['picurl'].'" />';
                    $outStr.= '</section>';
                    $outStr.= '<section class="msg-list-web">';
                         $outStr.= '<h3><span>'.dgmdate($val['last_time'], 'u','9999','m-d H:i').'</span>'.$val['toUserInfo']['nickname'].'&nbsp;</h3>';
                         $outStr.= '<p>';
                         if($val['new_num']>0){
                             $outStr.= '<i>'.$val['new_num'].'</i>';
                         }
                         $outStr.= ''.$val['last_content'];
                         $outStr.= '</p>';
                    $outStr.= '</section>';
               $outStr.= '</a>';
               $outStr.= '<section class="clear"></section>';
            $outStr.= '</section>';
        }
    }else{
        $outStr = '205';
    }
    $outStr = tom_link_replace($outStr);
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($_GET['act'] == 'lbs_check' && $_GET['formhash'] == FORMHASH){
    
    $outStr = '';
    
    $city = isset($_GET['city'])? daddslashes(diconv(urldecode($_GET['city']),'utf-8')):'';
    $district = isset($_GET['district'])? daddslashes(diconv(urldecode($_GET['district']),'utf-8')):'';
    $cfrom    = isset($_GET['cfrom'])? addslashes($_GET['cfrom']):'';
    
    if(!empty($city) && !empty($district)){
        
        $sitesListTmp = array();
        $areaStr = '';
        $districtSitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_lbs_keywords(" AND status=1 "," ORDER BY id DESC ",0,1,$district);
        if(is_array($districtSitesListTmp) && !empty($districtSitesListTmp) && $districtSitesListTmp[0]['id'] > 0){
            $sitesListTmp = $districtSitesListTmp;
            $areaStr = $district;
        }else{
            $citySitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_lbs_keywords(" AND status=1 "," ORDER BY id DESC ",0,1,$city);
            if(is_array($citySitesListTmp) && !empty($citySitesListTmp)  && $citySitesListTmp[0]['id'] > 0){
                $sitesListTmp = $citySitesListTmp;
                $areaStr = $city;
            }
        }
        
        if(!empty($sitesListTmp) && isset($sitesListTmp[0]) && $sitesListTmp[0]['id'] > 0){
            if($sitesListTmp[0]['id'] != $site_id){
                
                $msg = lang("plugin/tom_tongcheng", "index_lbs_msg2");
                $msg = str_replace("{AREA}",$areaStr,$msg);
                $msg = str_replace("{SITE}",$sitesListTmp[0]['lbs_name'],$msg);
                
                $outStr.= '<div class="tcui-dialog__bd" style="padding: 2em 20px 1.7em;">'.$msg.'</div>';
                $outStr.= '<div class="tcui-dialog__ft" style="line-height: 40px;">';
                    $outStr.= '<a href="javascript:;" onclick="closeLbs();" class="tcui-btn tcui-dialog__btn tcui-dialog__btn_default">'.lang("plugin/tom_tongcheng", "index_lbs_no").'</a>';
                    if($cfrom == 'tcmall'){
                        $outStr.= '<a href="plugin.php?id=tom_tcmall&site='.$sitesListTmp[0]['id'].'&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tczhaopin'){
                        $outStr.= '<a href="plugin.php?id=tom_tczhaopin&site='.$sitesListTmp[0]['id'].'&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcfangchan'){
                        $outStr.= '<a href="plugin.php?id=tom_tcfangchan&site='.$sitesListTmp[0]['id'].'&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tchuodong'){
                        $outStr.= '<a href="plugin.php?id=tom_tchuodong&site='.$sitesListTmp[0]['id'].'&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'fenlei'){
                        $outStr.= '<a href="plugin.php?id=tom_tongcheng&site='.$sitesListTmp[0]['id'].'&mod=fenlei&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcshop'){
                        $outStr.= '<a href="plugin.php?id=tom_tcshop&site='.$sitesListTmp[0]['id'].'&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcqianggou'){
                        $outStr.= '<a href="plugin.php?id=tom_tcqianggou&site='.$sitesListTmp[0]['id'].'&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tclove'){
                        $outStr.= '<a href="plugin.php?id=tom_tclove&site='.$sitesListTmp[0]['id'].'&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcqun'){
                        $outStr.= '<a href="plugin.php?id=tom_tcqun&site='.$sitesListTmp[0]['id'].'&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcershou'){
                        $outStr.= '<a href="plugin.php?id=tom_tcershou&site='.$sitesListTmp[0]['id'].'&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcdaojia'){
                        $outStr.= '<a href="plugin.php?id=tom_tcdaojia&site='.$sitesListTmp[0]['id'].'&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcedu'){
                        $outStr.= '<a href="plugin.php?id=tom_tcedu&site='.$sitesListTmp[0]['id'].'&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else{
                        $outStr.= '<a href="plugin.php?id=tom_tongcheng&site='.$sitesListTmp[0]['id'].'&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }
                $outStr.= '</div>';
            }else{
                $outStr = '100';
            }
        }else if($tcadminConfig['open_sites_lbs'] > 1){
            if(1 != $site_id){
                $outStr.= '<div class="tcui-dialog__bd" style="padding: 2em 20px 1.7em;">'.lang("plugin/tom_tongcheng", "index_lbs_msg").''.$tongchengConfig['lbs_name'].'</div>';
                $outStr.= '<div class="tcui-dialog__ft" style="line-height: 40px;">';
                    $outStr.= '<a href="javascript:;" onclick="closeLbs();" class="tcui-btn tcui-dialog__btn tcui-dialog__btn_default">'.lang("plugin/tom_tongcheng", "index_lbs_no").'</a>';
                    if($cfrom == 'tcmall'){
                        $outStr.= '<a href="plugin.php?id=tom_tcmall&site=1&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tczhaopin'){
                        $outStr.= '<a href="plugin.php?id=tom_tczhaopin&site=1&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcfangchan'){
                        $outStr.= '<a href="plugin.php?id=tom_tcfangchan&site=1&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tchuodong'){
                        $outStr.= '<a href="plugin.php?id=tom_tchuodong&site=1&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcshop'){
                        $outStr.= '<a href="plugin.php?id=tom_tcshop&site=1&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcqianggou'){
                        $outStr.= '<a href="plugin.php?id=tom_tcqianggou&site=1&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tclove'){
                        $outStr.= '<a href="plugin.php?id=tom_tclove&site=1&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcqun'){
                        $outStr.= '<a href="plugin.php?id=tom_tcqun&site=1&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcershou'){
                        $outStr.= '<a href="plugin.php?id=tom_tcershou&site=1&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcdaojia'){
                        $outStr.= '<a href="plugin.php?id=tom_tcdaojia&site=1&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else if($cfrom == 'tcedu'){
                        $outStr.= '<a href="plugin.php?id=tom_tcedu&site=1&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }else{
                        $outStr.= '<a href="plugin.php?id=tom_tongcheng&site=1&mod=index&lbs_no=1" class="tcui-dialog__btn tcui-dialog__btn_primary">'.lang("plugin/tom_tongcheng", "index_lbs_ok").'</a>';
                    }
                $outStr.= '</div>';
            }else{
                $outStr = '100';
            }
        }else{
            $outStr = '100';
        }
        
    }else{
        $outStr = '100';
    }
    
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($_GET['act'] == 'lbs_close' && $_GET['formhash'] == FORMHASH){
    
    $lifeTime = $tcadminConfig['sites_lbs_time'];
    dsetcookie('tom_tongcheng_sites_lbs', 1, $lifeTime);
    echo '200';exit;
    
}else if($_GET['act'] == 'miniprogram'){
    
    if($_GET['ok'] == 1){
        $lifeTime = 120;
        dsetcookie('tom_miniprogram', 1, $lifeTime);
    }else{
        $lifeTime = 1;
        dsetcookie('tom_miniprogram', 0, $lifeTime);
    }
    
    echo '200';exit;
    
}else if($_GET['act'] == 'update_lbs' && $_GET['formhash'] == FORMHASH){
    
    $latitude    = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude   = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    
    $cookieTime = 86400*3;
    
    dsetcookie('tom_tongcheng_user_latitude',$latitude,$cookieTime);
    dsetcookie('tom_tongcheng_user_longitude',$longitude,$cookieTime);
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_geocoder' && $_GET['formhash'] == FORMHASH){
    
    $outStr = '205';
    
    $longitude     = !empty($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $latitude      = !empty($_GET['latitude'])? addslashes($_GET['latitude']):'';
    if(!empty($latitude) && !empty($longitude)){
        $distanceApi = "http://api.map.baidu.com/reverse_geocoding/v3/?ak={$tongchengConfig['baidu_ak']}&location={$latitude},{$longitude}&output=json&pois=0";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $distanceApi);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $content = curl_exec($ch);
        curl_close($ch); 
        $return = json_decode($content, true);
        $return = wx_iconv_recurrence($return);
        if(is_array($return) && $return['status'] == 0 && !empty($return['result'])){
            $outStr = $return['result']['addressComponent']['city'].$return['result']['addressComponent']['district'].$return['result']['addressComponent']['town'].$return['result']['addressComponent']['street'].$return['result']['addressComponent']['street_number'];
            if(!empty($return['result']['poiRegions']['name'])){
                $outStr.= $return['result']['poiRegions']['name'];
            }
        }
    }
    
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($_GET['act'] == 'check_subscribe' && $_GET['formhash'] == FORMHASH){
    
    $cookies_close_subscribe_status = getcookie('tom_tongcheng_close_subscribe');
    
    if(!empty($cookies_close_subscribe_status) && $cookies_close_subscribe_status == 1){
        echo 2;exit;
    }
    
    $appid = trim($tongchengConfig['wxpay_appid']);  
    $appsecret = trim($tongchengConfig['wxpay_appsecret']);
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $weixinClass = new weixinClass($appid,$appsecret);
    $access_token = $weixinClass->get_access_token();
    
    $open_subscribe = 0;
    if($tongchengConfig['open_subscribe']==1 && $tongchengConfig['open_child_subscribe_sites']==1){
        $open_subscribe = 1;
    }else if($tongchengConfig['open_subscribe']==1 && $site_id==1){
        $open_subscribe = 1;
    }
    if($open_subscribe==1 && $__UserInfo['id'] > 0 && !empty($__UserInfo['openid']) && !empty($access_token)){
        $get_user_info_url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token={$access_token}&openid={$__UserInfo['openid']}&lang=zh_CN";
        $return = get_html($get_user_info_url);
        if(!empty($return)){
            $tcContent = json_decode($return,true);
            if(is_array($tcContent) && !empty($tcContent) && isset($tcContent['subscribe'])){
                if($tcContent['subscribe'] == 1){
                    echo 200;exit;
                }else{
                    echo 100;exit;
                }
            }
        }
    }
    echo 1;exit;
    
}else if($_GET['act'] == 'close_subscribe' && $_GET['formhash'] == FORMHASH){
    
    dsetcookie('tom_tongcheng_close_subscribe', 1, 86400);
    echo '200';exit;
    
}else if($_GET['act'] == 'admin_type'){
    
    $callback = $_GET['callback'];
    $model_id = isset($_GET['model_id'])? intval($_GET['model_id']):0;
    $outArr = array();
    
    $typeList = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_all_list(" AND model_id={$model_id} "," ORDER BY paixu ASC,id DESC ",0,50);
    if(is_array($typeList) && !empty($typeList)){
        foreach ($typeList as $key => $value) {
            $outArr[$key]['id'] = $value['id'];
            $outArr[$key]['name'] = diconv($value['name'],CHARSET,'utf-8');
        }
    }

    $outStr = '';
    $outStr = json_encode($outArr);
    if($callback){
        $outStr = $callback . "(" . $outStr. ")";
    }
    echo $outStr;
    die();
    
}else{
    echo 'error';exit;
}