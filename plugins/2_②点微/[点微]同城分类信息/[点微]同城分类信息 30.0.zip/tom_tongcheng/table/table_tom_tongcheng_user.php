<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_tom_tongcheng_user extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
		$this->_table = 'tom_tongcheng_user';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
        $data = DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
        if($data){
            $data['nickname'] = cutstr($data['nickname'], 20, '...');
            $data['picurl'] = str_replace('http://thirdwx.qlogo.cn', 'https://thirdwx.qlogo.cn', $data['picurl']);
            $data['picurl'] = str_replace('http://wx.qlogo.cn', 'https://wx.qlogo.cn', $data['picurl']);
        }
		return $data;
	}
    
    public function fetch_by_openid($openid,$field='*') {
		$data = DB::fetch_first("SELECT $field FROM %t WHERE openid=%s", array($this->_table, $openid));
        if($data){
            $data['nickname'] = cutstr($data['nickname'], 20, '...');
            $data['picurl'] = str_replace('http://thirdwx.qlogo.cn', 'https://thirdwx.qlogo.cn', $data['picurl']);
            $data['picurl'] = str_replace('http://wx.qlogo.cn', 'https://wx.qlogo.cn', $data['picurl']);
        }
		return $data;
	}
    
    public function fetch_by_unionid($unionid,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE unionid=%s", array($this->_table, $unionid));
	}
    
    public function fetch_by_member_id($member_id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE member_id=%d", array($this->_table, $member_id));
	}
    
    public function fetch_by_tel($tel,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE tel=%s", array($this->_table, $tel));
	}
	
    public function fetch_all_list($condition,$orders = '',$start = 0,$limit = 10) {
		$dataTmp = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        $data = array();
        if(is_array($dataTmp) && !empty($dataTmp)){
            foreach ($dataTmp as $key => $value){
                $data[$key] = $value;
                $data[$key]['nickname'] = cutstr($value['nickname'], 20, '...');
                $data[$key]['picurl'] = str_replace('http://thirdwx.qlogo.cn', 'https://thirdwx.qlogo.cn', $value['picurl']);
                $data[$key]['picurl'] = str_replace('http://wx.qlogo.cn', 'https://wx.qlogo.cn', $data[$key]['picurl']);
            }
        }
		return $data;
	}

	public function fetch_all_like_list($condition,$orders = '',$start = 0,$limit = 10,$nickname='') {
        if(!empty($nickname)){
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i AND nickname LIKE %s $orders LIMIT $start,$limit",array($this->_table,$condition,'%'.$nickname.'%'));
        }else{
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        }
		
		return $data;
	}
    
    public function fetch_all_like_count($condition,$nickname='') {
        if(!empty($nickname)){
            $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i AND nickname LIKE %s ",array($this->_table,$condition,'%'.$nickname.'%'));
        }else{
            $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i ",array($this->_table,$condition));
        }
		return $return['num'];
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition) {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
    
    public function fetch_money_sum($condition) {
        $return = DB::fetch_first("SELECT SUM(money) AS price FROM ".DB::table($this->_table)." WHERE 1 $condition ");
        if($return['price'] > 0){
            return $return['price'];
        }else{
            return 0;
        }
	}
    
    public function fetch_shop_money_sum($condition) {
        $return = DB::fetch_first("SELECT SUM(shop_money) AS price FROM ".DB::table($this->_table)." WHERE 1 $condition ");
        if($return['price'] > 0){
            return $return['price'];
        }else{
            return 0;
        }
	}
    
    public function fetch_all_count_majia_cate_id() {
        $data = DB::fetch_all("SELECT majia_cate_id,COUNT(majia_cate_id) as num from %t WHERE majia_cate_id > 0 AND is_majia = 1 GROUP BY majia_cate_id;",array($this->_table));
		return $data;
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

}