<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tongcheng_sfc_cache extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
		$this->_table = 'tom_tongcheng_sfc_cache';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}

    public function fetch_by_tongcheng_id($tongcheng_id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE tongcheng_id=%d", array($this->_table, $tongcheng_id));
	}
    
    public function fetch_search_list($condition,$orders = '',$start = 0,$limit = 10,$chufa = '',$mude = '') {
        if(!empty($chufa) && !empty($mude)){
            $chufa = str_replace(array('%', '_'),'',$chufa);
            $mude = str_replace(array('%', '_'),'',$mude);
            $data = DB::fetch_all("SELECT tongcheng_id FROM %t WHERE 1 %i AND chufa LIKE %s AND mude LIKE %s  $orders LIMIT $start,$limit",array($this->_table,$condition,'%'.$chufa.'%','%'.$mude.'%'));
        }else if(!empty($chufa)){
            $chufa = str_replace(array('%', '_'),'',$chufa);
            $data = DB::fetch_all("SELECT tongcheng_id FROM %t WHERE 1 %i AND chufa LIKE %s  $orders LIMIT $start,$limit",array($this->_table,$condition,'%'.$chufa.'%'));
        }else if(!empty($mude)){
            $mude = str_replace(array('%', '_'),'',$mude);
            $data = DB::fetch_all("SELECT tongcheng_id FROM %t WHERE 1 %i AND mude LIKE %s  $orders LIMIT $start,$limit",array($this->_table,$condition,'%'.$mude.'%'));
        }else{
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        }
		return $data;
	}
    
    public function fetch_all_list($condition,$orders = '',$start = 0,$limit = 10) {
        $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
		return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition) {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
	
	public function delete_by_tongcheng_id($tongcheng_id) {
		return DB::query("DELETE FROM %t WHERE tongcheng_id=%d", array($this->_table, $tongcheng_id));
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

}



