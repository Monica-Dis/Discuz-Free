<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function tomLinkMap(){
    $map = array(
        'code'      => 0,
        'search'    => array(),
        'replace'   => array(),
    );
    
    $tom_link_rule = include DISCUZ_ROOT."./source/plugin/tom_link/data/rule.php";
    
    if(isset($tom_link_rule['tom_ucenter'])){
        $map['code']      = 1;
        $map['search'][]  = 'plugin.php?id=tom_ucenter';
        $map['replace'][] = $tom_link_rule['tom_ucenter']['rk']."?id=".$tom_link_rule['tom_ucenter']['bs'];
    }
    if(isset($tom_link_rule['tom_tongcheng'])){
        $map['code']      = 1;
        $map['search'][]  = 'plugin.php?id=tom_tongcheng';
        $map['replace'][] = $tom_link_rule['tom_tongcheng']['rk']."?id=".$tom_link_rule['tom_tongcheng']['bs'];
    }
    if(isset($tom_link_rule['tom_tcshop'])){
        $map['code']      = 1;
        $map['search'][]  = 'plugin.php?id=tom_tcshop';
        $map['replace'][] = $tom_link_rule['tom_tcshop']['rk']."?id=".$tom_link_rule['tom_tcshop']['bs'];
    }
    if(isset($tom_link_rule['tom_tchongbao'])){
        $map['code']      = 1;
        $map['search'][]  = 'plugin.php?id=tom_tchongbao';
        $map['replace'][] = $tom_link_rule['tom_tchongbao']['rk']."?id=".$tom_link_rule['tom_tchongbao']['bs'];
    }
    if(isset($tom_link_rule['tom_tcqianggou'])){
        $map['code']      = 1;
        $map['search'][]  = 'plugin.php?id=tom_tcqianggou';
        $map['replace'][] = $tom_link_rule['tom_tcqianggou']['rk']."?id=".$tom_link_rule['tom_tcqianggou']['bs'];
    }
    if(isset($tom_link_rule['tom_tcptuan'])){
        $map['code']      = 1;
        $map['search'][]  = 'plugin.php?id=tom_tcptuan';
        $map['replace'][] = $tom_link_rule['tom_tcptuan']['rk']."?id=".$tom_link_rule['tom_tcptuan']['bs'];
    }
    if(isset($tom_link_rule['tom_tckjia'])){
        $map['code']      = 1;
        $map['search'][]  = 'plugin.php?id=tom_tckjia';
        $map['replace'][] = $tom_link_rule['tom_tckjia']['rk']."?id=".$tom_link_rule['tom_tckjia']['bs'];
    }
    if(isset($tom_link_rule['tom_tchehuoren'])){
        $map['code']      = 1;
        $map['search'][]  = 'plugin.php?id=tom_tchehuoren';
        $map['replace'][] = $tom_link_rule['tom_tchehuoren']['rk']."?id=".$tom_link_rule['tom_tchehuoren']['bs'];
    }
    if(isset($tom_link_rule['tom_tc114'])){
        $map['code']      = 1;
        $map['search'][]  = 'plugin.php?id=tom_tc114';
        $map['replace'][] = $tom_link_rule['tom_tc114']['rk']."?id=".$tom_link_rule['tom_tc114']['bs'];
    }
    if(isset($tom_link_rule['tom_tcyikatong'])){
        $map['code']      = 1;
        $map['search'][]  = 'plugin.php?id=tom_tcyikatong';
        $map['replace'][] = $tom_link_rule['tom_tcyikatong']['rk']."?id=".$tom_link_rule['tom_tcyikatong']['bs'];
    }
    
    return $map;
}

function tomoutput(){
    global $_G;
    
    $isMiniprogram = false;
    $cookie_tom_miniprogram = getcookie('tom_miniprogram');
    if($cookie_tom_miniprogram == 1 || $_GET['f'] == 'miniprogram'){
        $isMiniprogram = true;
    }
    
    $content = ob_get_contents();
    
    $html = '';
    
    # miniprogram start
    if($isMiniprogram){
        
        $content = preg_replace('#\s+href="(plugin.php?[^"]*)"#', ' data-href="'.$_G['siteurl'].'\\1" onclick="jumpMiniprogram(\''.$_G['siteurl'].'\\1&f=miniprogram\');"', $content);
        $content = preg_replace('#\s+href="(http[^"]*)"#', ' data-href="\\1" onclick="jumpMiniprogram(\'\\1&f=miniprogram\');"', $content);
        $content = str_replace('res.wx.qq.com/open/js/jweixin-1.0.0.js', 'res.wx.qq.com/open/js/jweixin-1.3.2.js', $content);

        preg_match('#onMenuShareAppMessage\({[^{]*#', $content, $wxShareMatches);
        if(is_array($wxShareMatches) && isset($wxShareMatches[0]) && !empty($wxShareMatches[0])){
            $shareTitle = $shareUrl = $shareLogo = '';
            preg_match("#title\s*:\s*'([^']+)',#", $wxShareMatches[0], $wxShareMatchesTitle);
            if(is_array($wxShareMatchesTitle) && isset($wxShareMatchesTitle[1]) && !empty($wxShareMatchesTitle[1])){
                $shareTitle = $wxShareMatchesTitle[1];
            }
            preg_match("#link\s*:\s*'([^']+)',#", $wxShareMatches[0], $wxShareMatchesLink);
            if(is_array($wxShareMatchesLink) && isset($wxShareMatchesLink[1]) && !empty($wxShareMatchesLink[1])){
                $shareUrl = $wxShareMatchesLink[1]."&f=miniprogram";
            }
            preg_match("#imgUrl\s*:\s*'([^']+)',#", $wxShareMatches[0], $wxShareMatchesImgUrl);
            if(is_array($wxShareMatchesImgUrl) && isset($wxShareMatchesImgUrl[1]) && !empty($wxShareMatchesImgUrl[1])){
                $shareLogo = $wxShareMatchesImgUrl[1];
            }
            $html.= "<script>var miniprogramShareStatus = 1;var miniprogramShareTitle = '{$shareTitle}';var miniprogramShareUrl = '{$shareUrl}';var miniprogramShareLogo = '{$shareLogo}';</script>";
        }
        
        $html.= '<script src="source/plugin/tom_tongcheng/images/miniprogram.js?v=20200715"></script>';

    }
    # miniprogram end
    
    # link start
    if(file_exists(DISCUZ_ROOT."./source/plugin/tom_link/data/rule.php")){
        $map = tomLinkMap();
        if($map['code'] == 1){
            $content = str_replace($map['search'], $map['replace'], $content);
            $content = str_replace('&site=1&', '&', $content);
        }
    }
    # link end
    
    $content = str_replace('width=device-width', 'width=device-width, viewport-fit=cover', $content);
    $content = str_replace('isShowProgressTips: 0', 'isShowProgressTips: 1', $content);
    $content = str_replace('isShowProgressTips:0', 'isShowProgressTips:1', $content);
    
    ob_end_clean();
    $_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
    echo $content.$html;
    exit;
    
}

function tomheader($string){
    if(file_exists(DISCUZ_ROOT."./source/plugin/tom_link/data/rule.php")){
        $map = tomLinkMap();
        if($map['code'] == 1){
            $string = str_replace($map['search'], $map['replace'], $string);
        }
    }
    dheader($string);
    exit;
}

function tom_link_replace($string){
    global $_G;
    
    $isMiniprogram = false;
    $cookie_tom_miniprogram = getcookie('tom_miniprogram');
    if($cookie_tom_miniprogram == 1 || $_GET['f'] == 'miniprogram'){
        $isMiniprogram = true;
    }
    
    if($isMiniprogram){
        $string = preg_replace('#\s+href="(plugin.php?[^"]*)"#', ' data-href="'.$_G['siteurl'].'\\1" onclick="jumpMiniprogram(\''.$_G['siteurl'].'\\1&f=miniprogram\');"', $string);
        $string = preg_replace('#\s+href="(http[^"]*)"#', ' data-href="\\1" onclick="jumpMiniprogram(\'\\1&f=miniprogram\');"', $string);
    }
    
    if(file_exists(DISCUZ_ROOT."./source/plugin/tom_link/data/rule.php")){
        $map = tomLinkMap();
        if($map['code'] == 1){
            $string = str_replace($map['search'], $map['replace'], $string);
            $string = str_replace('&site=1&', '&', $string);
        }
    }
    
    return $string;
}