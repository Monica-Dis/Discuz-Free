<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


function wx_iconv_recurrence($value) {
    if(is_array($value)) {
        foreach($value AS $key => $val) {
            $value[$key] = wx_iconv_recurrence($val);
        }
    } else {
        $value = diconv($value, 'utf-8', CHARSET);
    }
    return $value;
}

function contentFormat($content){
    
    $content = dhtmlspecialchars($content);
    
    $pos = strpos($content,"|+|+|+|+|+|+|+|+|+|");
    if($pos === false){
        return $content;
    }else if($pos === 0){
        return "";
    }else{
        return substr($content, 0, $pos);
    }
    
}

function filterEmojiMatches($match){
	return strlen($match[0]) >= 4 ? '' : $match[0];
}

function filterEmoji($str){
    
    if(CHARSET == 'utf-8') {
        $str = preg_replace_callback(
           '/./u',
           'filterEmojiMatches',
		   $str);
    }

    return $str;
  
 }
 
 /**
 * ���������������֮��ľ���
 * @param  Decimal $longitude1 ��㾭��
 * @param  Decimal $latitude1  ���γ��
 * @param  Decimal $longitude2 �յ㾭��
 * @param  Decimal $latitude2  �յ�γ��
 * @param  Int     $unit       ��λ 1:�� 2:����
 * @param  Int     $decimal    ���� ����С��λ��
 * @return Decimal
 */
function tomGetDistance($longitude1, $latitude1, $longitude2, $latitude2, $unit=2, $decimal=1){

    $EARTH_RADIUS = 6370.996; // ����뾶ϵ��
    $PI = 3.1415926;

    $radLat1 = $latitude1 * $PI / 180.0;
    $radLat2 = $latitude2 * $PI / 180.0;

    $radLng1 = $longitude1 * $PI / 180.0;
    $radLng2 = $longitude2 * $PI / 180.0;

    $a = $radLat1 - $radLat2;
    $b = $radLng1 - $radLng2;

    $distance = 2 * asin(sqrt(pow(sin($a/2),2) + cos($radLat1) * cos($radLat2) * pow(sin($b/2),2)));
    $distance = $distance * $EARTH_RADIUS * 1000;

    if($unit==2){
        $distance = $distance / 1000;
    }

    return round($distance, $decimal);

}

function tomGetTextToPic($picurl, $code) {
    global $_G;
    
    $image = imgToBase64($picurl);
    
    $picurl = DISCUZ_ROOT.'./'.$picurl;
    if(file_exists($picurl)){
        @unlink($picurl);
    }
        
    $host = "https://imgurlocr.market.alicloudapi.com";
    $path = "/urlimages";
    $method = "POST";
    $appcode = $code;
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    array_push($headers, "Content-Type" . ":" . "application/x-www-form-urlencoded; charset=UTF-8");
    
    $querys = "";
    $bodys = "image=".$image;
    
    $url = $host . $path;

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $bodys);
    $return = curl_exec($curl);

    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    
    if ($httpCode == 200) {
        
        $return = json_decode($return,true);
        $return = wx_iconv_recurrence($return);

        if($return['code'] == 1){
            $resuleArr = array();
            foreach($return['result'] as $key => $value){
                $resuleArr[] = $value['words'];
            }

            $text = implode(PHP_EOL, $resuleArr);
            if(!empty($text)){
                return array(
                    'status' => 200,
                    'text'   => $text
                );
            }else{
                return array(
                    'status' => 301,
                    'text'   => lang('plugin/tom_tongcheng', 'pictext_no_text')
                );
            }
        }else{
            return array(
                'status' => 301,
                'text'   => 'code:'.$return['code']
            );
        }
    } else {
        return array(
            'status' => 301,
            'text'   => lang('plugin/tom_tongcheng', 'pictext_error')
        );
    }
}

function imgToBase64($img_file) {

    $img_base64 = '';
    if (file_exists($img_file)) {
        $img_info = getimagesize($img_file);

        $fp = fopen($img_file, "r");

        if ($fp) {
            $filesize = filesize($img_file);
            $content = fread($fp, $filesize);
            $file_content = chunk_split(base64_encode($content));

            $img_base64 = 'data:' . $img_info['mime'] . ';base64,' . $file_content;

        }
        fclose($fp);
    }

    return $img_base64;
}