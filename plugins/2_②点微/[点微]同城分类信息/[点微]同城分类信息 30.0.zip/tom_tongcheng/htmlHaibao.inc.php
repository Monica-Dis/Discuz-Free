<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);

$tongchengSetting = C::t('#tom_tongcheng#tom_tongcheng_setting')->fetch_by_id(1);
if($tongchengSetting && $tongchengSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tongcheng#tom_tongcheng_setting')->insert($insertData);
    $tongchengSetting = C::t('#tom_tongcheng#tom_tongcheng_setting')->fetch_by_id(1);
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

if('utf-8' != CHARSET) {
    if(defined('IN_MOBILE')) {}else{
        foreach($_POST AS $pk => $pv) {
            if(!is_numeric($pv)) {
                $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
            }
        }
    }
}

$share_url		= isset($_GET['share_url'])? daddslashes($_GET['share_url']):'';
$tongcheng_id	= isset($_GET['tongcheng_id'])? intval($_GET['tongcheng_id']):0;
$user_id		= isset($_GET['user_id'])? intval($_GET['user_id']):0;

$tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
$typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
$userInfo  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
    include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
}else{
    echo 'QR|phpqrcode';exit;
}

$content = contentFormat($tongchengInfo['content']);
$contentTmp = strip_tags($content);
$contentTmp = str_replace("\r\n","",$contentTmp);
$contentTmp = str_replace("\n","",$contentTmp);
$contentTmp = str_replace("\r","",$contentTmp);
$title  = cutstr($contentTmp,80,"...");
if(!empty($tongchengInfo['title'])){
    $title = $tongchengInfo['title'];
}

$photoListTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id ASC ",0,1);
$picurl = trim($tongchengConfig['wxqrcode_src']);
if(is_array($photoListTmp) && !empty($photoListTmp)){
    if(strpos($photoListTmp[0]['picurl'], 'source/plugin/tom_') === false){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$photoListTmp[0]['picurl'];
    }else{
        $picurl = $_G['siteurl'].$photoListTmp[0]['picurl'];
    }
}

if(strpos($userInfo['picurl'], 'data/attachment/tomwx') !== false){
    $userpic  = $_G['siteurl'].$userInfo['picurl'];
}else if(strpos($userInfo['picurl'], 'uc_server/') !== false){
    $userpic  = $_G['siteurl'].$userInfo['picurl'];
}else{
    $userpic  = $userInfo['picurl'];
}

$qrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tongcheng/data/haibao/'.md5($share_url).'_qrcode.png';
$qrcodeUrl = 'source/plugin/tom_tongcheng/data/haibao/'.md5($share_url).'_qrcode.png';

$wxqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tongcheng/data/haibao/'.md5($share_url).'_wxqrcode'.date("Ymd").'.png';
$wxqrcodeUrl = 'source/plugin/tom_tongcheng/data/haibao/'.md5($share_url).'_wxqrcode'.date("Ymd").'.png';

$userpicImg = DISCUZ_ROOT.'./source/plugin/tom_tongcheng/data/haibao/'.md5($userpic).'_userpic.png';
$userpicUrl = 'source/plugin/tom_tongcheng/data/haibao/'.md5($userpic).'_userpic.png';

$tempDir = "/source/plugin/tom_tongcheng/data/haibao/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0755); 
}

if(file_exists($userpicImg)){
}else{
    $user_pic_content = file_get_contents($userpic);
    if(false === file_put_contents($userpicImg,$user_pic_content)){
        $userpicImg = $userpic;
    }
}

$outQrcodeUrl = '';
if($tongchengConfig['open_wxqrcode'] == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_weixin/tom_weixin.inc.php')){
    
    $qrcodeKey  = md5($share_url);
    $qrcodeInfo = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_by_qkey($qrcodeKey);
    $qrcodeId = 0;
    if($qrcodeInfo){
        $qrcodeId = $qrcodeInfo['id'];
        $updateData = array();
        $updateData['title']  = lang('plugin/tom_tongcheng', 'kuohao_left').$typeInfo['name'].lang('plugin/tom_tongcheng', 'kuohao_right').$title;
        $updateData['picurl'] = $picurl;
        $updateData['desc']   = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        C::t('#tom_weixin#tom_weixin_qrcode')->update($qrcodeId,$updateData);
    }else{
        
        $qrcodeList = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_all_list(" ","ORDER BY id DESC",0,1);
        $qrcodeId = 100001;
        if(is_array($qrcodeList) && !empty($qrcodeList) && isset($qrcodeList['0']) && $qrcodeList['0']['id']>100000){
            $qrcodeId = $qrcodeList['0']['id']+1;
        }
        
        $insertData = array();
        $insertData['id']       = $qrcodeId;
        $insertData['qkey']     = $qrcodeKey;
        $insertData['title']    = lang('plugin/tom_tongcheng', 'kuohao_left').$typeInfo['name'].lang('plugin/tom_tongcheng', 'kuohao_right').$title;
        $insertData['picurl']   = $picurl;
        $insertData['desc']     = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        $insertData['link']     = $share_url;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_weixin#tom_weixin_qrcode')->insert($insertData);
        $qrcodeId = C::t('#tom_weixin#tom_weixin_qrcode')->insert_id();
    }
    
    if(file_exists($wxqrcodeImg)){
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        $access_token = $weixinClass->get_access_token();

        $dateStr = '{"expire_seconds": 2592000, "action_name": "QR_SCENE", "action_info": {"scene": {"scene_id": '.$qrcodeId.'}}}';
        $response   = postDataCurl($dateStr, 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token);
        $returnData = json_decode($response,true);
        if(isset($returnData['ticket']) &&  !empty($returnData['ticket'])){
            $wx_pic_content = getHtml('https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$returnData['ticket']);
            if(false === file_put_contents($wxqrcodeImg,$wx_pic_content)){
            }
        }
    }
    
    $outQrcodeUrl = $wxqrcodeUrl;
}else{
    if(file_exists($qrcodeImg)){
    }else{
        QRcode::png($share_url,$qrcodeImg,'H',5,2);
    }
    $outQrcodeUrl = $qrcodeUrl;
}

echo 'OK|'.$userpicUrl.'|'.$outQrcodeUrl;exit;

function getHtml($url){
    if(function_exists('curl_init')){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $return = curl_exec($ch);
        curl_close($ch); 
        return $return;
    }
    return false;
}

function postDataCurl($data, $url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,FALSE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $return = curl_exec($ch);
    if($return){
        curl_close($ch);
        return $return;
    } else { 
        $error = curl_errno($ch);
        curl_close($ch);
        return false;
    }
}