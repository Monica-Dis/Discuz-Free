<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tongcheng`;
CREATE TABLE `pre_tom_tongcheng` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `model_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `cate_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `tczhaopin_id` int(11) DEFAULT '0',
  `tczhaopin_resume_id` int(11) DEFAULT '0',
  `tcfangchan_id` int(11) DEFAULT '0',
  `tcershou_goods_id` int(11) DEFAULT '0',
  `tcershou_needs_id` int(11) DEFAULT '0',
  `tcqianggou_goods_id` int(11) DEFAULT '0',
  `tcqianggou_coupon_id` int(11) DEFAULT '0',
  `tcmall_goods_id` int(11) DEFAULT '0',
  `tcdaojia_goods_id` int(11) DEFAULT '0',
  `tcptuan_goods_id` int(11) DEFAULT '0',
  `tcfangchan_needs_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `wx` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `video_url` varchar(255) DEFAULT NULL,
  `video_pic` varchar(255) DEFAULT NULL,
  `collect` int(11) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `zhuanfa` int(11) DEFAULT '0',
  `topstatus` int(11) DEFAULT '0',
  `toprand` int(11) DEFAULT '1',
  `toptime` int(11) DEFAULT '0',
  `top_sq_time` int(11) DEFAULT '0',
  `over_days` int(11) DEFAULT '0',
  `over_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '1000',
  `refresh_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `finish` int(11) DEFAULT '0',
  `pay_status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '1',
  `score_pay` tinyint(4) DEFAULT '0',
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `street_id` int(11) DEFAULT '0',
  `is_dingwei` tinyint(11) DEFAULT '0',
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `auto_click_time` int(11) DEFAULT '0',
  `auto_zhuanfa_time` int(11) DEFAULT '0',
  `share_refresh_time` int(11) DEFAULT '0',
  `share_top_status` tinyint(4) DEFAULT '0',
  `client_ip_port` varchar(255) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_apply_sites`;
CREATE TABLE `pre_tom_tongcheng_apply_sites` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `content` text,
  `pay_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tongcheng_attr`;
CREATE TABLE `pre_tom_tongcheng_attr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `tongcheng_id` int(11) DEFAULT '0',
  `attr_id` int(11) DEFAULT NULL,
  `attr_name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `time_value` int(11) DEFAULT '0',
  `unit` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_collect`;
CREATE TABLE `pre_tom_tongcheng_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tongcheng_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_common`;
CREATE TABLE `pre_tom_tongcheng_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clicks` int(11) DEFAULT '0',
  `xieyi_txt` text,
  `help_txt` text,
  `kefu_txt` text,
  `sfc_txt` text,
  `forbid_word` text,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tongcheng_focuspic`;
CREATE TABLE `pre_tom_tongcheng_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '1',
  `model_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_model`;
CREATE TABLE `pre_tom_tongcheng_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT '1',
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `jifei_type` int(11) DEFAULT '1',
  `list_nav_style` tinyint(4) DEFAULT '1',
  `area_select` int(11) DEFAULT '0',
  `open_dingwei` int(11) DEFAULT '0',
  `must_shenhe` int(11) DEFAULT '0',
  `only_editor` int(11) DEFAULT '0',
  `open_fabu_title` int(11) DEFAULT '0',
  `is_sfc` int(11) DEFAULT '0',
  `close_fabu` int(11) DEFAULT '0',
  `is_show` int(11) DEFAULT '1',
  `sites_show` int(11) DEFAULT '0',
  `template_type` varchar(255) DEFAULT NULL,
  `share_title` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `share_logo` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '100',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_model_attr`;
CREATE TABLE `pre_tom_tongcheng_model_attr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '1',
  `value` text,
  `is_must` int(11) DEFAULT '0',
  `unit` varchar(255) DEFAULT NULL,
  `msg` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_model_cate`;
CREATE TABLE `pre_tom_tongcheng_model_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `parent_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_model_tag`;
CREATE TABLE `pre_tom_tongcheng_model_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '100',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_model_type`;
CREATE TABLE `pre_tom_tongcheng_model_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `free_status` int(11) DEFAULT '1',
  `jifei_type` int(11) DEFAULT '1',
  `fabu_price` decimal(10,2) DEFAULT '1.00',
  `app_fabu_price` decimal(10,2) DEFAULT '0.00',
  `fabu_price_str` varchar(255) DEFAULT NULL,
  `app_fabu_price_str` varchar(255) DEFAULT NULL,
  `refresh_price` decimal(10,2) DEFAULT '1.00',
  `top_price` decimal(10,2) DEFAULT '1.00',
  `top_price_str` varchar(255) DEFAULT NULL,
  `open_tel_price` int(11) DEFAULT '0',
  `tel_price` decimal(10,2) DEFAULT '0.00',
  `open_dingwei` tinyint(4) DEFAULT '0',
  `open_video` tinyint(4) DEFAULT '0',
  `open_qianggou` tinyint(4) DEFAULT '0',
  `open_ptuan` tinyint(4) DEFAULT '0',
  `open_mall` tinyint(4) DEFAULT '0',
  `open_qianggou_coupon` tinyint(4) DEFAULT '0',
  `open_daojia` tinyint(4) DEFAULT '0',
  `close_tel` tinyint(4) DEFAULT '0',
  `cate_title` varchar(255) DEFAULT NULL,
  `desc_title` varchar(255) DEFAULT NULL,
  `desc_content` varchar(255) DEFAULT NULL,
  `warning_msg` varchar(255) DEFAULT NULL,
  `zhapian_msg` varchar(255) DEFAULT NULL,
  `info_share_title` varchar(255) DEFAULT NULL,
  `info_share_desc` varchar(255) DEFAULT NULL,
  `over_time_attr_id` int(11) DEFAULT '0',
  `over_time_do` int(11) DEFAULT '0',
  `sfc_chufa_attr_id` int(11) DEFAULT '0',
  `sfc_mude_attr_id` int(11) DEFAULT '0',
  `sfc_time_attr_id` int(11) DEFAULT '0',
  `sfc_renshu_type` tinyint(4) DEFAULT '1',
  `sfc_renshu_attr_id` int(11) DEFAULT '0',
  `share_title` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `share_logo` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '100',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_order`;
CREATE TABLE `pre_tom_tongcheng_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `order_no` varchar(255) DEFAULT NULL,
  `order_type` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `tongcheng_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `tcshop_vip_id` int(11) DEFAULT '0',
  `apply_sites_id` int(11) DEFAULT '0',
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `time_value` int(11) DEFAULT '0',
  `score_value` int(11) DEFAULT '0',
  `top_days` int(11) DEFAULT '0',
  `tui_click_num` int(11) DEFAULT '0',
  `refresh_num` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `pay_time` int(11) DEFAULT '0',
  `order_status` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_photo`;
CREATE TABLE `pre_tom_tongcheng_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tongcheng_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `oss_picurl` varchar(255) DEFAULT NULL,
  `oss_status` int(11) DEFAULT '0',
  `qiniu_status` int(11) DEFAULT '0',
  `qiniu_picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_pm`;
CREATE TABLE `pre_tom_tongcheng_pm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `pm_lists_id` int(11) DEFAULT '0',
  `new_num` int(11) DEFAULT '0',
  `last_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_pm_lists`;
CREATE TABLE `pre_tom_tongcheng_pm_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `min_use_id` int(11) DEFAULT '0',
  `max_use_id` int(11) DEFAULT '0',
  `last_content` text,
  `last_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_pm_message`;
CREATE TABLE `pre_tom_tongcheng_pm_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pm_lists_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `is_pic` tinyint(4) DEFAULT '0',
  `content` text,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_refresh_log`;
CREATE TABLE `pre_tom_tongcheng_refresh_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tongcheng_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '1',
  `time_key` int(11) DEFAULT '0',
  `old_refresh_num` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_tag`;
CREATE TABLE `pre_tom_tongcheng_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `tongcheng_id` int(11) DEFAULT '0',
  `tag_id` int(11) DEFAULT '0',
  `tag_name` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_topnews`;
CREATE TABLE `pre_tom_tongcheng_topnews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_tousu`;
CREATE TABLE `pre_tom_tongcheng_tousu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tongcheng_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `content` text,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_user`;
CREATE TABLE `pre_tom_tongcheng_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `member_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `unionid` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `money` decimal(10,2) DEFAULT '0.00',
  `tixian_money` decimal(10,2) DEFAULT '0.00',
  `tixian_shouxufei_bili` decimal(10,2) DEFAULT '0.00',
  `shop_money` decimal(10,2) DEFAULT '0.00',
  `shop_tixian_money` decimal(10,2) DEFAULT '0.00',
  `score` int(11) DEFAULT '0',
  `editor` int(11) DEFAULT '0',
  `hongbao_tz` int(11) DEFAULT '0',
  `hongbao_tz_first` int(11) DEFAULT '0',
  `is_majia` int(11) DEFAULT '0',
  `majia_cate_id` int(11) DEFAULT '0',
  `refresh_num` int(11) DEFAULT '0',
  `fenghao_msg` varchar(255) DEFAULT NULL,
  `fenghao_time` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '1',
  `add_time` int(11) DEFAULT '0',
  `last_smstp_time` int(11) DEFAULT '0',
  `last_login_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_openid` (`openid`),
  KEY `index_memberid` (`member_id`),
  KEY `index_tel` (`tel`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_visitor`;
CREATE TABLE `pre_tom_tongcheng_visitor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `visit_user_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_district`;
CREATE TABLE `pre_tom_tongcheng_district` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `level` tinyint(3) unsigned DEFAULT '0',
  `upid` mediumint(8) unsigned DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_upid` (`upid`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_nav`;
CREATE TABLE `pre_tom_tongcheng_nav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `show_type` int(11) DEFAULT '1',
  `type` int(11) DEFAULT '0',
  `model_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `marker` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `nsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_nav_popup`;
CREATE TABLE `pre_tom_tongcheng_nav_popup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `type` int(11) DEFAULT '0',
  `model_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `marker` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `nsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_sites`;
CREATE TABLE `pre_tom_tongcheng_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manage_openid1` varchar(255) DEFAULT NULL,
  `manage_openid2` varchar(255) DEFAULT NULL,
  `manage_openid3` varchar(255) DEFAULT NULL,
  `manage_user_id` int(11) DEFAULT '0',
  `city_id` int(11) DEFAULT '0',
  `site_one` int(11) DEFAULT '0',
  `open_sites` int(11) DEFAULT '1',
  `cate_id` int(11) DEFAULT '0',
  `is_hot` int(11) DEFAULT '1',
  `site_ids` varchar(255) DEFAULT NULL,
  `model_ids` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `lbs_name` varchar(255) DEFAULT NULL,
  `lbs_keywords` varchar(255) DEFAULT NULL,
  `seo_city_name` varchar(255) DEFAULT NULL,
  `kefu_qrcode` varchar(255) DEFAULT NULL,
  `share_title` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `share_pic` varchar(255) DEFAULT NULL,
  `fenlei_share_title` varchar(255) DEFAULT NULL,
  `fenlei_share_desc` varchar(255) DEFAULT NULL,
  `fenlei_share_pic` varchar(255) DEFAULT NULL,
  `dingyue_qrcode` varchar(255) DEFAULT NULL,
  `fl_fc_scale` int(11) DEFAULT '0',
  `hehuoren_fc_scale` int(11) DEFAULT '0',
  `shop_fc_scale` int(11) DEFAULT '0',
  `qg_fc_scale` int(11) DEFAULT '0',
  `pt_fc_scale` int(11) DEFAULT '0',
  `kj_fc_scale` int(11) DEFAULT '0',
  `114_fc_scale` int(11) DEFAULT '0',
  `vip_fc_scale` int(11) DEFAULT '0',
  `mall_fc_scale` int(11) DEFAULT '0',
  `tt_fc_scale` int(11) DEFAULT '0',
  `zp_fc_scale` int(11) DEFAULT '0',
  `fc_fc_scale` int(11) DEFAULT '0',
  `hd_fc_scale` int(11) DEFAULT '0',
  `love_fc_scale` int(11) DEFAULT '0',
  `qun_fc_scale` int(11) DEFAULT '0',
  `ershou_fc_scale` int(11) DEFAULT '0',
  `daojia_fc_scale` int(11) DEFAULT '0',
  `edu_fc_scale` int(11) DEFAULT '0',
  `hehuoren_fc_open` int(11) DEFAULT '2',
  `virtual_clicks` int(11) DEFAULT '0',
  `virtual_fabunum` int(11) DEFAULT '0',
  `virtual_rznum` int(11) DEFAULT '0',
  `ruzhu_price` decimal(10,2) DEFAULT '0.00',
  `vip_ruzhu_price` decimal(10,2) DEFAULT '0.00',
  `vip_ruzhu_price_two` decimal(10,2) DEFAULT '0.00',
  `index_color_menu` text,
  `index_white_menu` text,
  `index_diy_html` mediumtext,
  `tcmall_line2_nav` text,
  `tcmall_line4_nav` text,
  `index_line4_nav` text,
  `search_all_type` text,
  `tcmall_tcchoujiang_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '1',
  `paixu` int(11) DEFAULT '1000',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_tz`;
CREATE TABLE `pre_tom_tongcheng_tz` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `content` text,
  `tz_time` int(11) DEFAULT '0',
  `is_read` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_pinglun`;
CREATE TABLE `pre_tom_tongcheng_pinglun` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tongcheng_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `content` text,
  `touser_id` int(11) DEFAULT '0',
  `touser_nickname` varchar(255) DEFAULT NULL,
  `touser_avatar` varchar(255) DEFAULT NULL,
  `ping_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_pinglun_reply`;
CREATE TABLE `pre_tom_tongcheng_pinglun_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ping_id` int(11) DEFAULT '0',
  `tongcheng_id` int(11) DEFAULT '0',
  `reply_user_id` int(11) DEFAULT '0',
  `reply_user_nickname` varchar(255) DEFAULT NULL,
  `reply_user_avatar` varchar(255) DEFAULT NULL,
  `content` text,
  `reply_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_score_log`;
CREATE TABLE `pre_tom_tongcheng_score_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `score_value` int(11) DEFAULT '0',
  `old_value` int(11) DEFAULT '0',
  `log_type` tinyint(4) DEFAULT '0',
  `log_time` int(11) DEFAULT '0',
  `time_key` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_popup`;
CREATE TABLE `pre_tom_tongcheng_popup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_ids` text,
  `title` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '1',
  `link` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `content` text,
  `clicks` int(11) DEFAULT '0',
  `show_num` int(11) unsigned DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_popup_log`;
CREATE TABLE `pre_tom_tongcheng_popup_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `popup_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `num` int(11) DEFAULT '0',
  `log_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_money_log`;
CREATE TABLE `pre_tom_tongcheng_money_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `change_money` decimal(10,2) DEFAULT '0.00',
  `old_money` decimal(10,2) DEFAULT '0.00',
  `tixian_id` int(11) DEFAULT '0',
  `tag` varchar(255) DEFAULT NULL,
  `beizu` text,
  `log_ip` varchar(255) DEFAULT NULL,
  `log_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_money_tixian`;
CREATE TABLE `pre_tom_tongcheng_money_tixian` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tx_order_no` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00',
  `shouxufei` decimal(10,2) DEFAULT '0.00',
  `alipay_zhanghao` varchar(255) DEFAULT NULL,
  `alipay_truename` varchar(255) DEFAULT NULL,
  `beizu` text,
  `status` int(11) DEFAULT '0',
  `tixian_ip` varchar(255) DEFAULT NULL,
  `tixian_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_content`;
CREATE TABLE `pre_tom_tongcheng_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tongcheng_id` int(11) DEFAULT '0',
  `is_show` int(11) DEFAULT '0',
  `content` text,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_help`;
CREATE TABLE `pre_tom_tongcheng_help` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `paixu` int(11) DEFAULT '100',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_sites_price`;
CREATE TABLE `pre_tom_tongcheng_sites_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `free_status` int(11) DEFAULT '1',
  `fabu_price` decimal(10,2) DEFAULT '0.00',
  `app_fabu_price` decimal(10,2) DEFAULT '0.00',
  `fabu_price_str` varchar(255) DEFAULT NULL,
  `app_fabu_price_str` varchar(255) DEFAULT NULL,
  `refresh_price` decimal(10,2) DEFAULT '0.00',
  `top_price` decimal(10,2) DEFAULT '0.00',
  `top_price_str` varchar(255) DEFAULT NULL,
  `tel_price` decimal(10,2) DEFAULT '0.00',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tongcheng_sfc_cache`;
CREATE TABLE `pre_tom_tongcheng_sfc_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `tongcheng_id` int(11) DEFAULT '0',
  `model_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `chufa` varchar(255) DEFAULT NULL,
  `mude` varchar(255) DEFAULT NULL,
  `chufa_time` varchar(255) DEFAULT NULL,
  `chufa_int_time` int(11) DEFAULT '0',
  `renshu_type` tinyint(4) DEFAULT '1',
  `renshu` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tongcheng_fabu_log`;
CREATE TABLE `pre_tom_tongcheng_fabu_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tongcheng_id` int(11) DEFAULT '0',
  `time_key` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tongcheng_sites_cate`;
CREATE TABLE `pre_tom_tongcheng_sites_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '100',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tongcheng_tel`;
CREATE TABLE `pre_tom_tongcheng_tel` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `object_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tongcheng_diylist`;
CREATE TABLE `pre_tom_tongcheng_diylist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `show_type` int(11) DEFAULT '1',
  `type` int(11) DEFAULT '0',
  `model_id` int(11) DEFAULT '0',
  `plugins_name` varchar(255) DEFAULT NULL,
  `add_time` varchar(255) DEFAULT '0',
  `dsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tongcheng_search`;
CREATE TABLE `pre_tom_tongcheng_search` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `plugin_id` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `ssort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tongcheng_share_log`;
CREATE TABLE `pre_tom_tongcheng_share_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `tongcheng_id` int(11) DEFAULT '0',
  `view_user_id` int(11) DEFAULT '0',
  `time_key` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tongcheng_setting`;
CREATE TABLE `pre_tom_tongcheng_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `index_diy_html` mediumtext,
  `open_model_search` tinyint(4) DEFAULT '0',
  `index_fixed_menu` tinyint(4) DEFAULT '3',
  `open_share_refresh_top` tinyint(4) DEFAULT '0',
  `share_do_limit` tinyint(4) DEFAULT '2',
  `share_refresh_txt` varchar(255) DEFAULT NULL,
  `share_top_num` int(11) DEFAULT '0',
  `share_top_days` int(11) DEFAULT '0',
  `share_top_txt` varchar(255) DEFAULT NULL,
  `open_fenlei_qianggou` tinyint(4) DEFAULT '0',
  `open_fenlei_ptuan` tinyint(4) DEFAULT '0',
  `open_all_free_fabu_times` tinyint(4) DEFAULT '0',
  `all_free_fabu_times` int(11) DEFAULT '0',
  `free_fabu_times_days` int(11) DEFAULT '0',
  `open_message_auto` tinyint(4) DEFAULT '1',
  `open_fabu_top` tinyint(4) DEFAULT '1',
  `open_fabu_tui` tinyint(4) DEFAULT '0',
  `open_pic_to_text` tinyint(4) DEFAULT '0',
  `pic_to_text_appcode` varchar(255) DEFAULT NULL,
  `template_type` varchar(255) DEFAULT 'default',
  `open_message_send_pic` tinyint(4) DEFAULT '0',
  `open_refresh_price` tinyint(4) DEFAULT '0',
  `refresh_price_str` varchar(255) DEFAULT NULL,
  `closed_sites_one_fabu` tinyint(4) DEFAULT '0',
  `moneytixian_msg` varchar(255) DEFAULT NULL,
  `open_list_pinglun_zan` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
