<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20210714";

$tongchengSetting = C::t('#tom_tongcheng#tom_tongcheng_setting')->fetch_by_id(1);
if($tongchengSetting && $tongchengSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tongcheng#tom_tongcheng_setting')->insert($insertData);
    $tongchengSetting = C::t('#tom_tongcheng#tom_tongcheng_setting')->fetch_by_id(1);
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/qqface.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/nofind.php';

$wxJssdkConfig = array();
$wxJssdkConfig["appId"]     = "";
$wxJssdkConfig["timestamp"] = time();
$wxJssdkConfig["nonceStr"]  = "";
$wxJssdkConfig["signature"] = "";
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tongchengConfig['wx_share_title'];
$shareDesc  = $tongchengConfig['wx_share_desc'];
$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=index";
$shareLogo  = $tongchengConfig['wx_share_pic'];

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesinfo.php';
if($site_id > 1){
    $shareTitle = $__SitesInfo['share_title'];
    $shareDesc  = $__SitesInfo['share_desc'];
    $shareLogo = $__SitesInfo['share_pic'];
}

## tcadmin start
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
## tcadmin end
## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tcqianggou start
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
    $tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
    if($tcqianggouConfig['open_tcqianggou'] == 1){
        $__ShowTcqianggou = 1;
    }
}
## tcqianggou end
## tchongbao start
$__ShowTchongbao = 0;
$tchongbaoConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchongbao/tom_tchongbao.inc.php')){
    $tchongbaoConfig = $_G['cache']['plugin']['tom_tchongbao'];
    if($tchongbaoConfig['open_tchongbao'] == 1){
        $__ShowTchongbao = 1;
        $tchongbaoConfig['hb_lq_type'] = 1;
    }
}
## tchongbao end
## tcmajia start
$__ShowTcmajia = 0;
$tcmajiaConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcmajia/tom_tcmajia.inc.php')){
    $tcmajiaConfig = $_G['cache']['plugin']['tom_tcmajia'];
    if($tcmajiaConfig['open_tcmajia'] == 1){
        $__ShowTcmajia = 1;
    }
}
## tcmajia end
## tcptuan start
$__ShowTcptuan = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcptuan/tom_tcptuan.inc.php')){
    $tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
    if($tcptuanConfig['open_tcptuan'] == 1){
        $__ShowTcptuan = 1;
    }
}
## tcptuan end
## tckjia start
$__ShowTckjia = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tckjia/tom_tckjia.inc.php')){
    $tckjiaConfig = $_G['cache']['plugin']['tom_tckjia'];
    if($tckjiaConfig['open_tckjia'] == 1){
        $__ShowTckjia = 1;
    }
}
## tckjia end
## tc114 start
$__ShowTc114 = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tc114/tom_tc114.inc.php')){
    $tc114Config = $_G['cache']['plugin']['tom_tc114'];
    if($tc114Config['open_tc114'] == 1){
        $__ShowTc114 = 1;
    }
}
## tc114 end
## tcyikatong start
$__ShowTcyikatong = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
    $tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $__ShowTcyikatong = 1;
    }
}
## tcyikatong end
## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## love start
$__ShowLove = 0;
$jyConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_love/tom_love.inc.php')){
    $jyConfig = $_G['cache']['plugin']['tom_love'];
    if($jyConfig['open_tongcheng'] == 1){
        $__ShowLove = 1;
    }
}
## love end
## tcmall start
$__ShowTcmall = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcmall/tom_tcmall.inc.php')){
    $tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
    if($tcmallConfig['open_tcmall'] == 1){
        $__ShowTcmall = 1;
    }
}
## tcmall end
## xiangqin start
$__ShowXiangqin = 0;
$xiangqinConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiangqin/tom_xiangqin.inc.php')){
    $xiangqinConfig = $_G['cache']['plugin']['tom_xiangqin'];
    if($xiangqinConfig['open_xiangqin'] == 1){
        $__ShowXiangqin = 1;
    }
}
## xiangqin end
## tctoutiao start
$__ShowTctoutiao = 0;
$tctoutiaoConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/tom_tctoutiao.inc.php')){
    $tctoutiaoConfig = $_G['cache']['plugin']['tom_tctoutiao'];
    if($tctoutiaoConfig['open_tctoutiao'] == 1){
        $__ShowTctoutiao = 1;
    }
}
## tctoutiao end
## tcsign start
$__ShowTcsign = 0;
$tcsignConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcsign/tom_tcsign.inc.php')){
    $tcsignConfig = $_G['cache']['plugin']['tom_tcsign'];
    if($tcsignConfig['open_tcsign'] == 1){
        $__ShowTcsign = 1;
    }
}
## tcsign end
## tcchoujiang start
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')){
    $tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
    if($tcchoujiangConfig['open_tcchoujiang'] == 1){
        $__ShowTcchoujiang = 1;
    }
}
## tcchoujiang end
## tcrenzheng start
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')){
    $tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
    if($tcrenzhengConfig['open_tcrenzheng'] == 1){
        $__ShowTcrenzheng = 1;
    }
}
## tcrenzheng end
## tczhaopin start
$__ShowTczhaopin = 0;
$tczhaopinConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')){
    $tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
    if($tczhaopinConfig['open_tczhaopin'] == 1){
        $__ShowTczhaopin = 1;
    }
}
## tczhaopin end
## tcpinche start
$__ShowTcpinche = 0;
$tcpincheConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcpinche/tom_tcpinche.inc.php')){
    $tcpincheConfig = $_G['cache']['plugin']['tom_tcpinche'];
    $__ShowTcpinche = 1;
}
## tcpinche end
## video start
$__ShowVideo = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/video.inc.php')){
    $__ShowVideo = 1;
}
## video end
## tchuodong start
$__ShowTchuodong = 0;
$tchuodongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchuodong/tom_tchuodong.inc.php')){
    $tchuodongConfig = $_G['cache']['plugin']['tom_tchuodong'];
    if($tchuodongConfig['open_tchuodong'] == 1){
        $__ShowTchuodong = 1;
    }
}
## tchuodong end
## tcfangchan start
$__ShowFangchan = 0;
$tcfangchanConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/tom_tcfangchan.inc.php')){
    $tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
    if($tcfangchanConfig['open_tcfangchan'] == 1){
        $__ShowFangchan = 1;
    }
}
## tcfangchan end
## tclove start
$__ShowTclove = 0;
$tcloveConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tclove/tom_tclove.inc.php')){
    $tcloveConfig = $_G['cache']['plugin']['tom_tclove'];
    if($tcloveConfig['open_tclove'] == 1){
        $__ShowTclove = 1;
    }
}
## tclove end
## tcqun start
$__ShowTcqun = 0;
$tcqunConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqun/tom_tcqun.inc.php')){
    $tcqunConfig = $_G['cache']['plugin']['tom_tcqun'];
    if($tcqunConfig['open_tcqun'] == 1){
        $__ShowTcqun = 1;
    }
}
## tcqun end
## xiaofenlei start
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')){
    $xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
    $__ShowXiaofenlei = 1;
}
## xiaofenlei end
## tcershou start
$__ShowTcershou = 0;
$tcershouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcershou/tom_tcershou.inc.php')){
    $tcershouConfig = $_G['cache']['plugin']['tom_tcershou'];
    if($tcershouConfig['open_tcershou'] == 1){
        $__ShowTcershou = 1;
    }
}
## tcershou end
## tcdaojia start
$__ShowTcdaojia = 0;
$tcdaojiaConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/tom_tcdaojia.inc.php')){
    $tcdaojiaConfig = $_G['cache']['plugin']['tom_tcdaojia'];
    if($tcdaojiaConfig['open_tcdaojia'] == 1){
        $__ShowTcdaojia = 1;
    }
}
## tcdaojia end
## tcyuyue start
$__ShowTcyuyue = 0;
$tcyuyueConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/tom_tcyuyue.inc.php')){
    $tcyuyueConfig = $_G['cache']['plugin']['tom_tcyuyue'];
    if($tcyuyueConfig['open_tcyuyue'] == 1){
        $__ShowTcyuyue = 1;
    }
}
## tcyuyue end
## tcedu start
$__ShowTcedu = 0;
$tceduConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcedu/tom_tcedu.inc.php')){
    $tceduConfig = $_G['cache']['plugin']['tom_tcedu'];
    if($tceduConfig['open_tcedu'] == 1){
        $__ShowTcedu = 1;
    }
}
## tcedu end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login.php';

$ajaxLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=list&&formhash='.$formhash;
$ajaxCollectUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=collect&&formhash='.$formhash;
$ajaxClicksUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=clicks&&formhash='.$formhash.'&tongcheng_id=';
$searchUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=get_search_url';
$ajaxCommonClicksUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=commonClicks&&formhash='.$formhash;
$ajaxUpdateTopstatusUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=updateTopstatus&&formhash='.$formhash;
$ajaxUpdateToprandUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=updateToprand&&formhash='.$formhash;
$ajaxAutoClickUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=auto_click&&formhash='.$formhash;
$ajaxAutoZhuanfaUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=auto_zhuanfa&&formhash='.$formhash;
$ajaxShenheSmsUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=shenhe_sms&&formhash='.$formhash;
$ajaxZhuanfaScoreUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=zhuanfaScore&&formhash='.$formhash;
$ajaxLoadPopupUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=load_popup&&formhash='.$formhash;
$ajaxClosePopupUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=close_popup&&formhash='.$formhash;
$addPinglunUrl = "plugin.php?id=tom_tongcheng:ajax&site={$site_id}&act=pinglun&formhash=".FORMHASH;
$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=update_lbs&formhash='.$formhash;
$ajaxCheckSubscribeUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=check_subscribe&formhash='.$formhash;
$ajaxCloseSubscribeUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=close_subscribe&formhash='.$formhash;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=global_topnav_list&&formhash='.$formhash;
$ajaxVipAutoRefreshUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=vip_auto_refresh&formhash='.$formhash;

$__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
if(!$__CommonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tongcheng#tom_tongcheng_common')->insert($insertData);
}
if($site_id > 1){
    $__siteCommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id($site_id);
    if(!$__siteCommonInfo){
        $insertData = array();
        $insertData['id']      = $site_id;
        C::t('#tom_tongcheng#tom_tongcheng_common')->insert($insertData);
    }
}

$browser_shouchang_show = 1;
$browser_uid = getcookie('tom_tongcheng_browser_shouchang_'.$__UserInfo['id']);
if($browser_uid || $__IsWeixin == 0){
    $browser_shouchang_show = 0;
}
if($tongchengConfig['open_shouchang'] == 0 || $__IsMiniprogram == 1){
    $browser_shouchang_show = 0;
}

$ajaxShouchangUrl = "plugin.php?id=tom_tongcheng:ajax&act=browser_shouchang&formhash=".FORMHASH;

$footer_nav1_content_name = $footer_nav1_content_link = $footer_nav1_content_ico = '';
if($tongchengConfig['footer_nav1_mod'] == 2){
    if(!empty($tongchengConfig['footer_nav1_content'])){
        $footer_nav1_content = explode("|", $tongchengConfig['footer_nav1_content']);
        $footer_nav1_content_name = $footer_nav1_content[0];
        $footer_nav1_content_link = $footer_nav1_content[1];
        $footer_nav1_content_link = str_replace("{site}",$site_id, $footer_nav1_content_link);
        if(isset($footer_nav1_content[2]) && !empty($footer_nav1_content[2])){
            $footer_nav1_content_ico = $footer_nav1_content[2];
        }
    }
}

$footer_nav_content_name = $footer_nav_content_link = $footer_nav_content_ico = '';
if($tongchengConfig['footer_nav_mod'] == 1){
    if(!empty($tongchengConfig['footer_nav_content'])){
        $footer_nav_content = explode("|", $tongchengConfig['footer_nav_content']);
        $footer_nav_content_name = $footer_nav_content[0];
        $footer_nav_content_link = $footer_nav_content[1];
        $footer_nav_content_link = str_replace("{site}",$site_id, $footer_nav_content_link);
        if(isset($footer_nav_content[2]) && !empty($footer_nav_content[2])){
            $footer_nav_content_ico = $footer_nav_content[2];
        }
    }
}

if($tongchengConfig['footer_nav_mod'] == 7 && $__IsMiniprogram == 1 && $tctoutiaoConfig['closed_xiao'] == 1){
    $tongchengConfig['footer_nav_mod'] = 0;
}

$must_phone_projectArr = unserialize($tongchengConfig['must_phone_project']);
$showMustPhoneBtn = 0;
if(array_search('2',$must_phone_projectArr) !== false && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
}

$phone_back_url_tmp = $weixinClass->get_url();
$mustPhoneBackUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back=".urlencode($phone_back_url_tmp);

$show_app_download = 0;
$app_download_content = array();
$tongchengConfig['app_download'] = trim($tongchengConfig['app_download']);
if(!empty($tongchengConfig['app_download'])){
    $show_app_download = 1;
    $app_download_content = explode("|", $tongchengConfig['app_download']);
}

if($__IsMiniprogram == 1){
    $show_app_download = 0;
}

//dsetcookie('tom_tongcheng_user_latitude','31.244819',86400);
//dsetcookie('tom_tongcheng_user_longitude','120.68515',86400);

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

if($_GET['mod'] == 'index'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/index.php';
    
}else if($_GET['mod'] == 'fenlei'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/fenlei.php';
    
}else if($_GET['mod'] == 'fabu'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/fabu.php';
    
}else if($_GET['mod'] == 'fenleisearch'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/fenleisearch.php';
    
}else if($_GET['mod'] == 'search'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/search.php';
    
}else if($_GET['mod'] == 'list'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/list.php';
    
}else if($_GET['mod'] == 'info'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/info.php';
    
}else if($_GET['mod'] == 'view'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/info.php';
    
}else if($_GET['mod'] == 'hbao'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/info.php';
    
}else if($_GET['mod'] == 'home'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/home.php';
    
}else if($_GET['mod'] == 'personal'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/personal.php';
    
}else if($_GET['mod'] == 'message'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/message.php';
    
}else if($_GET['mod'] == 'mycollect'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/mycollect.php';
    
}else if($_GET['mod'] == 'mylist'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/mylist.php';
    
}else if($_GET['mod'] == 'tousu'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/tousu.php';
    
}else if($_GET['mod'] == 'buy'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/buy.php';
    
}else if($_GET['mod'] == 'article'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/article.php';
    
}else if($_GET['mod'] == 'myorder'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/myorder.php';
    
}else if($_GET['mod'] == 'phone'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/phone.php';
    
}else if($_GET['mod'] == 'edit'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/edit.php';
    
}else if($_GET['mod'] == 'xufei'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/xufei.php';
    
}else if($_GET['mod'] == 'editcate'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/editcate.php';
    
}else if($_GET['mod'] == 'managerList'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/managerList.php';
    
}else if($_GET['mod'] == 'upload'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/upload.php';
    
}else if($_GET['mod'] == 'myedit'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/myedit.php';
    
}else if($_GET['mod'] == 'templatesmsTest'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/templatesmsTest.php';
    
}else if($_GET['mod'] == 'scorelog'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/scorelog.php';
    
}else if($_GET['mod'] == 'money'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/money.php';
    
}else if($_GET['mod'] == 'moneylog'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/moneylog.php';
    
}else if($_GET['mod'] == 'moneytixian'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/moneytixian.php';
    
}else if($_GET['mod'] == 'address'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/address.php';
    
}else if($_GET['mod'] == 'majia'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/majia.php';
    
}else if($_GET['mod'] == 'help'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/help.php';
    
}else if($_GET['mod'] == 'baidumap'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/baidumap.php';
    
}else if($_GET['mod'] == 'applysites'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/applysites.php';
    
}else if($_GET['mod'] == 'buyrefresh'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/buyrefresh.php';
    
}else if($_GET['mod'] == 'miniprogram_login'){

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/miniprogram_login.php';
    
}else{
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/module/index.php';
}
tomoutput();
