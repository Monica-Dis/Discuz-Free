<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=tousu";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'tz_user' && submitcheck('tousu_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tousu_id       = isset($_GET['tousu_id'])? intval($_GET['tousu_id']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    $text           = dhtmlspecialchars($text);
    
    $tousuInfo = C::t("#tom_tongcheng#tom_tongcheng_tousu")->fetch_by_id($tousu_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tousuInfo['user_id']);
    
    if($userInfo && $userInfo['id'] > 0){
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">['.$Lang['tousu_tz_user_title'].']</font><br/>'.$text;
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    }
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
    
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = '';

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tongcheng#tom_tongcheng_tousu')->fetch_all_count($where);
$tousuListTmp = C::t('#tom_tongcheng#tom_tongcheng_tousu')->fetch_all_list($where,"ORDER BY add_time DESC",$start,$pagesize);
$tousuList = array();
if(!empty($tousuListTmp)){
    foreach($tousuListTmp as $key => $value){
        $tousuList[$key] = $value;
        
        $tongchengInfoTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($value['tongcheng_id']);
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        if(empty($tongchengInfoTmp['title'])){
            $tongchengInfoTmp['title'] = cutstr(contentFormat($tongchengInfoTmp['content']),20,"...");
        }
        
        $tousuList[$key]['tongchengInfo']   = $tongchengInfoTmp;
        $tousuList[$key]['userInfo']        = $userInfoTmp;
        $tousuList[$key]['add_time']        = dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:pcadmin/tousu");