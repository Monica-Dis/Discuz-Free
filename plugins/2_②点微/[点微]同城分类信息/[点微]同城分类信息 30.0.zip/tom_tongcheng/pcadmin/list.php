<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=list";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'refresh' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tongcheng_id = intval($_GET['tongcheng_id'])>0 ? intval($_GET['tongcheng_id']):0;

    $updateData = array();
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tongcheng_id = intval($_GET['tongcheng_id'])>0 ? intval($_GET['tongcheng_id']):0;

    $updateData = array();
    $updateData['status'] = 2;
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tongcheng_id = intval($_GET['tongcheng_id'])>0 ? intval($_GET['tongcheng_id']):0;

    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'nofinish' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tongcheng_id = intval($_GET['tongcheng_id'])>0 ? intval($_GET['tongcheng_id']):0;
    
    $updateData = array();
    $updateData['finish']       = 0;
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'finish' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tongcheng_id = intval($_GET['tongcheng_id'])>0 ? intval($_GET['tongcheng_id']):0;
    
    $updateData = array();
    $updateData = array();
    $updateData['finish'] = 1;
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tongcheng_id = intval($_GET['tongcheng_id'])>0 ? intval($_GET['tongcheng_id']):0;
    
    $photoListTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$tongcheng_id} "," ORDER BY id ASC ",0,20);
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach ($photoListTmp as $key => $value){
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === false){    
                    $picurl = $_G['setting']['attachdir'].'tomwx/'.$value['picurl'];
                }else{
                    $picurl = DISCUZ_ROOT.'./'.$value['picurl'];
                }
                if(file_exists($picurl)){
                    @unlink($picurl);
                }
            }
        }
    }
    
    C::t('#tom_tongcheng#tom_tongcheng')->delete_by_id($tongcheng_id);
    C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongcheng_id);
    C::t('#tom_tongcheng#tom_tongcheng_photo')->delete_by_tongcheng_id($tongcheng_id);
    C::t('#tom_tongcheng#tom_tongcheng_tag')->delete_by_tongcheng_id($tongcheng_id);
    C::t('#tom_tongcheng#tom_tongcheng_content')->delete_by_tongcheng_id($tongcheng_id);
    C::t('#tom_tongcheng#tom_tongcheng_sfc_cache')->delete_by_tongcheng_id($tongcheng_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'edit_pay_status' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tongcheng_id = intval($_GET['tongcheng_id'])>0 ? intval($_GET['tongcheng_id']):0;
    
    $updateData = array();
    $updateData['pay_status'] = 2;
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'shenhe' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0 ? intval($_GET['tongcheng_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $tongchengInfo = C::t("#tom_tongcheng#tom_tongcheng")->fetch_by_id($tongcheng_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengInfo['user_id']);
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status']     = $shenhe_status;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id, $updateData);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist");
                $smsData = array(
                    'first'         => $Lang['shenhe_tongcheng_succ_msg'],
                    'keyword1'      => $tongchengConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'],$tongchengConfig['template_id'],$smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($shenhe_status == 3){
        $updateData = array();
        $updateData['shenhe_status'] = $shenhe_status;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id, $updateData);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist");
                
                $smsData = array(
                    'first'         => $Lang['shenhe_tongcheng_fail_msg'],
                    'keyword1'      => $tongchengConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'],$tongchengConfig['template_id'],$smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}else if($act == 'editclicks' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tongcheng_id   = intval($_GET['tongcheng_id'])>0 ? intval($_GET['tongcheng_id']):0;
    $clicks         = intval($_GET['clicks'])>0 ? intval($_GET['clicks']):0;
    
    $updateData = array();
    $updateData['clicks'] = $clicks;
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'batch_refresh' && submitcheck('tongcheng_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tongchengIdsArr = array();
    if(is_array($_GET['tongcheng_ids'])){
        foreach($_GET['tongcheng_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tongchengIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tongchengIdsArr)){
        foreach($tongchengIdsArr as $key => $value){
            $updateData = array();
            $updateData['refresh_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng')->update($value, $updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'batch_shenhe1' && submitcheck('tongcheng_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tongchengIdsArr = array();
    if(is_array($_GET['tongcheng_ids'])){
        foreach($_GET['tongcheng_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tongchengIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tongchengIdsArr)){
        $tongchengIdsStr = implode(',', $tongchengIdsArr);
        $tongchengListTmp = C::t("#tom_tongcheng#tom_tongcheng")->fetch_all_list(" AND id IN({$tongchengIdsStr}) ", 'ORDER BY id DESC', 0, 100);
        $userIdsArr = array();
        foreach($tongchengListTmp as $key => $value){
            
            $userIdsArr[] = $value['user_id'];
            
            $updateData = array();
            $updateData['shenhe_status'] = 1;
            C::t('#tom_tongcheng#tom_tongcheng')->update($value['id'], $updateData);
        }
        
        if(!empty($tongchengConfig['template_id'])){
            $userIdsStr = implode(',', $userIdsArr);
            $userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            foreach($userListTmp as $key => $value){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($value['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist");
                    $smsData = array(
                        'first'         => $Lang['shenhe_tongcheng_succ_msg'],
                        'keyword1'      => $tongchengConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($value['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_shenhe3' && submitcheck('tongcheng_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tongchengIdsArr = array();
    if(is_array($_GET['tongcheng_ids'])){
        foreach($_GET['tongcheng_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tongchengIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tongchengIdsArr)){
        $tongchengIdsStr = implode(',', $tongchengIdsArr);
        $tongchengListTmp = C::t("#tom_tongcheng#tom_tongcheng")->fetch_all_list(" AND id IN({$tongchengIdsStr}) ", 'ORDER BY id DESC', 0, 100);
        $userIdsArr = array();
        foreach($tongchengListTmp as $key => $value){
            
            $userIdsArr[] = $value['user_id'];
            
            $updateData = array();
            $updateData['shenhe_status'] = 3;
            C::t('#tom_tongcheng#tom_tongcheng')->update($value['id'], $updateData);
        }
        
        if(!empty($tongchengConfig['template_id'])){
            $userIdsStr = implode(',', $userIdsArr);
            $userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            foreach($userListTmp as $key => $value){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($value['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist");
                    $smsData = array(
                        'first'         => $Lang['shenhe_tongcheng_fail_msg'],
                        'keyword1'      => $tongchengConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($value['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('tongcheng_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tongchengIdsArr = array();
    if(is_array($_GET['tongcheng_ids'])){
        foreach($_GET['tongcheng_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tongchengIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tongchengIdsArr)){
        foreach($tongchengIdsArr as $key => $value){
            $photoListTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$value} "," ORDER BY id ASC ",0,20);
            if(is_array($photoListTmp) && !empty($photoListTmp)){
                foreach ($photoListTmp as $kk => $vv){
                    if(!preg_match('/^http/', $vv['picurl']) ){
                        if(strpos($vv['picurl'], 'source/plugin/tom_') === false){    
                            $picurl = $_G['setting']['attachdir'].'tomwx/'.$vv['picurl'];
                        }else{
                            $picurl = DISCUZ_ROOT.'./'.$vv['picurl'];
                        }
                        if(file_exists($picurl)){
                            @unlink($picurl);
                        }
                    }
                }
            }
            C::t('#tom_tongcheng#tom_tongcheng')->delete_by_id($value);
            C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($value);
            C::t('#tom_tongcheng#tom_tongcheng_photo')->delete_by_tongcheng_id($value);
            C::t('#tom_tongcheng#tom_tongcheng_tag')->delete_by_tongcheng_id($value);
            C::t('#tom_tongcheng#tom_tongcheng_content')->delete_by_tongcheng_id($value);
            C::t('#tom_tongcheng#tom_tongcheng_sfc_cache')->delete_by_tongcheng_id($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_show' && submitcheck('tongcheng_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tongchengIdsArr = array();
    if(is_array($_GET['tongcheng_ids'])){
        foreach($_GET['tongcheng_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tongchengIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tongchengIdsArr)){
        foreach($tongchengIdsArr as $key => $value){
            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tongcheng#tom_tongcheng')->update($value, $updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_hide' && submitcheck('tongcheng_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tongchengIdsArr = array();
    if(is_array($_GET['tongcheng_ids'])){
        foreach($_GET['tongcheng_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tongchengIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tongchengIdsArr)){
        foreach($tongchengIdsArr as $key => $value){
            $updateData = array();
            $updateData['status'] = 2;
            C::t('#tom_tongcheng#tom_tongcheng')->update($value, $updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_finish' && submitcheck('tongcheng_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tongchengIdsArr = array();
    if(is_array($_GET['tongcheng_ids'])){
        foreach($_GET['tongcheng_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tongchengIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tongchengIdsArr)){
        foreach($tongchengIdsArr as $key => $value){
            $updateData = array();
            $updateData['finish'] = 1;
            C::t('#tom_tongcheng#tom_tongcheng')->update($value, $updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_nofinish' && submitcheck('tongcheng_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tongchengIdsArr = array();
    if(is_array($_GET['tongcheng_ids'])){
        foreach($_GET['tongcheng_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tongchengIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tongchengIdsArr)){
        foreach($tongchengIdsArr as $key => $value){
            $updateData = array();
            $updateData['finish'] = 0;
            C::t('#tom_tongcheng#tom_tongcheng')->update($value, $updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'editcate' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tongcheng_id   = intval($_GET['tongcheng_id'])>0 ? intval($_GET['tongcheng_id']):0;
    $model_id       = intval($_GET['model_id'])>0 ? intval($_GET['model_id']):0;
    $type_id        = intval($_GET['type_id'])>0 ? intval($_GET['type_id']):0;
    
    $updateData = array();
    $updateData['model_id'] = $model_id;
    $updateData['type_id']  = $type_id;
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'editexpire' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tongcheng_id   = intval($_GET['tongcheng_id'])>0 ? intval($_GET['tongcheng_id']):0;
    $over_time      = isset($_GET['over_time'])? addslashes($_GET['over_time']):'';
    $over_time      = strtotime($over_time);
        
    $updateData = array();
    if($over_time < TIMESTAMP){
        if($tongchengConfig['over_time_do'] == 1){
            $updateData['finish']       = 1;
        }else if($tongchengConfig['over_time_do'] == 2){
            $updateData['finish']       = 1;
            $updateData['status']       = 2;
        }else if($tongchengConfig['over_time_do'] == 4){
            $updateData['status']       = 2;
        }
        $updateData['over_time'] = $over_time;
    }else{
        $updateData['finish']       = 0;
        $updateData['status']       = 1;
        $updateData['over_time']    = $over_time;
    }
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edittop' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tongcheng_id   = intval($_GET['tongcheng_id'])>0 ? intval($_GET['tongcheng_id']):0;
    $toptime        = isset($_GET['toptime'])? addslashes($_GET['toptime']):'';
    $toptime        = strtotime($toptime);
        
    $updateData = array();
    
    if($toptime <= TIMESTAMP){
        $updateData['topstatus'] = 0;
        $updateData['toprand']   = 1;
    }else{
        $updateData['topstatus'] = 1;
        $updateData['toprand'] = 10000;
        $updateData['refresh_time'] = TIMESTAMP;
    }
    $updateData['toptime'] = $toptime;
    C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'info' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tongcheng_id = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfoTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    $tongchengInfo = array();
    if(!empty($tongchengInfoTmp)){
        
        $tongchengInfo = $tongchengInfoTmp;

        $cateInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_by_id($tongchengInfo['cate_id']);
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengInfo['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengInfo['street_id']);
        
        $tongchengTagListTmp = C::t('#tom_tongcheng#tom_tongcheng_tag')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id DESC ",0,50);
        $tongchengAttrListTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id DESC ",0,50);
        $tongchengPhotoListTmpTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id ASC ",0,50);
        
        $videoPicTmp = '';
        if(!empty($tongchengInfo['video_pic'])){
            if(!preg_match('/^http/', $tongchengInfo['video_pic'])){
                if(strpos($tongchengInfo['video_pic'], 'source/plugin/tom_') === false){    
                    $videoPicTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tongchengInfo['video_pic'];
                }else{
                    $videoPicTmp = $tongchengInfo['video_pic'];
                }
            }else{
                $videoPicTmp = $tongchengInfo['video_pic'];
            }
        }

        $tongchengPhotoListTmp = array();
        if(is_array($tongchengPhotoListTmpTmp) && !empty($tongchengPhotoListTmpTmp)){
            foreach ($tongchengPhotoListTmpTmp as $kk => $vv){
                if(!preg_match('/^http/', $vv['picurl']) ){
                    if(strpos($vv['picurl'], 'source/plugin/tom_') === false){    
                        $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                    }else{
                        $picurlTmp = $vv['picurl'];
                    }
                }else{
                    $picurlTmp = $vv['picurl'];
                }
                $tongchengPhotoListTmp[$kk] = $picurlTmp;
            }
        }
        
        $tongchengInfo['content']               = htmlspecialchars_decode(contentFormat($tongchengInfo['content']));
        $tongchengInfo['video_pic']             = $videoPicTmp;
        $tongchengInfo['cateInfo']              = $cateInfoTmp;
        $tongchengInfo['areaInfo']              = $areaInfoTmp;
        $tongchengInfo['streetInfo']            = $streetInfoTmp;
        $tongchengInfo['tongchengAttrList']     = $tongchengAttrListTmp;
        $tongchengInfo['tongchengTagList']      = $tongchengTagListTmp;
        $tongchengInfo['tongchengPhotoList']    = $tongchengPhotoListTmp;
        
    }
    
    $tongchengInfo = iconv_to_utf8($tongchengInfo);
    $outArr = array(
        'code'  => 200,
        "msg"   => "",
        "count" => $count,
        "data"  => $tongchengInfo
    );
    echo json_encode($outArr); exit;
}

$site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
$model_id       = intval($_GET['model_id'])>0? intval($_GET['model_id']):0;
$type_id        = intval($_GET['type_id'])>0? intval($_GET['type_id']):0;
$user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$shenhe_status  = intval($_GET['shenhe_status'])>0? intval($_GET['shenhe_status']):0;
$topstatus      = intval($_GET['topstatus'])>0? intval($_GET['topstatus']):0;
$pay_status     = intval($_GET['pay_status'])>0? intval($_GET['pay_status']):0;
$status         = intval($_GET['status'])>0? intval($_GET['status']):0;
$keyword        = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$modelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list('', 'ORDER BY paixu ASC,id DESC', 0, 100);
$modelList = array();
if(!empty($modelListTmp)){
    foreach($modelListTmp as $key => $value){
        $modelList[$value['id']] = $value;
    }
}

$typeListTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_all_list("  "," ORDER BY paixu ASC,id DESC ",0,2000);
$typeList = $typeData = array();
if(!empty($typeListTmp)){
    foreach($typeListTmp as $key => $value){
        $typeList[$value['id']] = $value;
        $modelList[$value['model_id']]['typeList'][] = $value;
        
        $typeData[$value['model_id']][$value['id']] = diconv($value['name'],CHARSET,'utf-8');
    }
}
$typeArr[0] = $typeData;
$typeData = urlencode(json_encode($typeArr));

$whereStr = '';
if(!empty($model_id)){
    $whereStr.= " AND model_id={$model_id} ";
}
if(!empty($type_id)){
    $whereStr.= " AND type_id={$type_id} ";
}
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}
if(!empty($tongcheng_id)){
    $whereStr.= " AND id={$tongcheng_id} ";
}
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}
if(!empty($shenhe_status)){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}
if(!empty($topstatus)){
    $whereStr.= " AND topstatus={$topstatus} ";
}
if(!empty($pay_status)){
    $whereStr.= " AND pay_status={$pay_status} ";
}
if(!empty($status)){
    $whereStr.= " AND status={$status} ";
}

$start          = ($page - 1)*$pagesize;
$count          = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count($whereStr,$keyword);
$tongchengListTmp  = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list($whereStr," ORDER BY refresh_time DESC,id DESC ",$start,$pagesize,$keyword);
$tongchengList = array();
if(!empty($tongchengListTmp)){
    foreach ($tongchengListTmp as $key => $value) {
        $tongchengList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        
        $modelInfoTmp = $modelList[$value['model_id']];
        $typeInfoTmp = $typeList[$value['type_id']];
        $siteInfoTmp = $sitesList[$value['site_id']];
        
        $cateInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_by_id($value['cate_id']);
        $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
        
        $tongchengAttrListTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY id DESC ",0,50);
        $tongchengTagListTmp = C::t('#tom_tongcheng#tom_tongcheng_tag')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY id DESC ",0,50);
        $tongchengPhotoListTmpTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY id ASC ",0,50);
        
        if(!preg_match('/^http/', $value['video_pic'])){
            if(strpos($value['video_pic'], 'source/plugin/tom_') === false){    
                $videoPicTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['video_pic'];
            }else{
                $videoPicTmp = $value['video_pic'];
            }
        }else{
            $videoPicTmp = $value['video_pic'];
        }
        
        $tongchengPhotoListTmp = array();
        if(is_array($tongchengPhotoListTmpTmp) && !empty($tongchengPhotoListTmpTmp)){
            foreach ($tongchengPhotoListTmpTmp as $kk => $vv){
                if(!preg_match('/^http/', $vv['picurl']) ){
                    if(strpos($vv['picurl'], 'source/plugin/tom_') === false){    
                        $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                    }else{
                        $picurlTmp = $vv['picurl'];
                    }
                }else{
                    $picurlTmp = $vv['picurl'];
                }
                $tongchengPhotoListTmp[$kk] = $picurlTmp;
            }
        }
        
        $contentTmp = contentFormat($value['content']);
        $contentTmp = htmlspecialchars_decode($contentTmp);
        $contentTmp = strip_tags($contentTmp);
        $contentTmp = str_replace("\r\n", '', $contentTmp);
        $contentTmp = str_replace("\r", '', $contentTmp);
        $contentTmp = str_replace("\n", '', $contentTmp);
        
        $tongchengList[$key]['video_pic']           = $videoPicTmp;
        $tongchengList[$key]['content']             = $contentTmp;
        $tongchengList[$key]['userInfo']            = $userInfoTmp;
        $tongchengList[$key]['modelInfo']           = $modelInfoTmp;
        $tongchengList[$key]['typeInfo']            = $typeInfoTmp;
        $tongchengList[$key]['siteInfo']            = $siteInfoTmp;
        $tongchengList[$key]['cateInfo']            = $cateInfoTmp;
        $tongchengList[$key]['areaInfo']            = $areaInfoTmp;
        $tongchengList[$key]['streetInfo']          = $streetInfoTmp;
        $tongchengList[$key]['tongchengAttrList']   = $tongchengAttrListTmp;
        $tongchengList[$key]['tongchengTagList']    = $tongchengTagListTmp;
        $tongchengList[$key]['tongchengPhotoList']  = $tongchengPhotoListTmp;
        $tongchengList[$key]['toptime']             = dgmdate($value['toptime'],"Y-m-d H:i",$tomSysOffset);
        $tongchengList[$key]['refresh_time']        = dgmdate($value['refresh_time'],"Y-m-d H:i",$tomSysOffset);
        $tongchengList[$key]['add_time']            = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $tongchengList[$key]['over_time']           = dgmdate($value['over_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&model_id={$model_id}&type_id={$type_id}&user_id={$user_id}&site_id={$site_id}&shenhe_status={$shenhe_status}&topstatus={$topstatus}&pay_status={$pay_status}&status={$status}&keyword={$keyword}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:pcadmin/list");