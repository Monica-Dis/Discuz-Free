<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=user";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'editor' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );

    $user_id    = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    $editor     = intval($_GET['editor'])>0 ? intval($_GET['editor']):0;
    
    $updateData = array();
    $updateData['editor'] = $editor;
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($user_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'send_sms' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $send_user_id   = isset($_GET['send_user_id'])? intval($_GET['send_user_id']):0;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    $text           = dhtmlspecialchars($text);
    
    if($user_id == $send_user_id){
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    $toUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    if($toUserInfo['id'] > 0){ }else{
        $outArr = array(
            'code'=> 200,
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }

    $sendUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($send_user_id);
    if($sendUserInfo['id'] > 0){ }else{
        $outArr = array(
            'code'=> 200,
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }

    $max_use_id = $min_use_id = 0;
    if($user_id > $send_user_id){
        $max_use_id = $user_id;
        $min_use_id = $send_user_id;
    }else if($user_id < $send_user_id){
        $max_use_id = $send_user_id;
        $min_use_id = $user_id;
    }
    $pmListTmp = C::t('#tom_tongcheng#tom_tongcheng_pm_lists')->fetch_all_list(" AND min_use_id={$min_use_id} AND max_use_id={$max_use_id} "," ORDER BY id DESC ",0,1);

    if(is_array($pmListTmp) && !empty($pmListTmp[0]['id']) ){
        $pm_lists_id = $pmListTmp[0]['id'];
    }else{
        $insertData = array();
        $insertData['user_id']      = $send_user_id;
        $insertData['min_use_id']   = $min_use_id;
        $insertData['max_use_id']   = $max_use_id;
        $insertData['last_content'] = 'NULL-NULL-NULL-NULL-NULL-NULL';
        $insertData['last_time']    = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_pm_lists')->insert($insertData);
        $pm_lists_id = C::t('#tom_tongcheng#tom_tongcheng_pm_lists')->insert_id();

        $insertData = array();
        $insertData['user_id']      = $send_user_id;
        $insertData['pm_lists_id']  = $pm_lists_id;
        $insertData['new_num']      = 0;
        $insertData['last_time']    = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_pm')->insert($insertData);

        $insertData = array();
        $insertData['user_id']      = $user_id;
        $insertData['pm_lists_id']  = $pm_lists_id;
        $insertData['new_num']      = 0;
        $insertData['last_time']    = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_pm')->insert($insertData);
    }

    $insertData = array();
    $insertData['user_id']      = $send_user_id;
    $insertData['pm_lists_id']  = $pm_lists_id;
    $insertData['content']      = $text;
    $insertData['add_time']     = TIMESTAMP;
    if(C::t('#tom_tongcheng#tom_tongcheng_pm_message')->insert($insertData)){

        $updateData = array();
        $updateData['last_content'] = $text;
        $updateData['last_time'] = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_pm_lists')->update($pm_lists_id,$updateData);

        DB::query("UPDATE ".DB::table('tom_tongcheng_pm')." SET new_num=new_num+1,last_time='".TIMESTAMP."' WHERE user_id='$user_id' AND pm_lists_id='$pm_lists_id' ", 'UNBUFFERED');

        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        
        $access_token = $weixinClass->get_access_token();
        $nextSmsTime = $toUserInfo['last_smstp_time'] + 60;
        if($access_token && !empty($toUserInfo['openid']) && TIMESTAMP > $nextSmsTime ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=message");
            $message_template_first = str_replace("{NICKNAME}",$sendUserInfo['nickname'], $Lang['message_template_first']);
            $smsData = array(
                'first'         => $message_template_first,
                'keyword1'      => $tongchengConfig['plugin_name'],
                'keyword2'      => $text,
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSms01($toUserInfo['openid'],$tongchengConfig['template_id'],$smsData);

            if($r){
                $updateData = array();
                $updateData['last_smstp_time'] = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUserInfo['id'],$updateData);
            }
        }
    }
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'fenghao' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $fenghao_time   = intval($_GET['fenghao_time'])>0? intval($_GET['fenghao_time']):0;
    $text           = isset($_GET['text'])? daddslashes($_GET['text']):'';

    $fenghao_end_time = 999;
    if($fenghao_time == 2){
        $fenghao_end_time = TIMESTAMP + 86400*7;
    }else if($fenghao_time == 3){
        $fenghao_end_time = TIMESTAMP + 86400*30;
    }else if($fenghao_time == 4){
        $fenghao_end_time = TIMESTAMP + 86400*90;
    }
    
    $updateData = array();
    $updateData['status']           = 2;
    $updateData['fenghao_time']     = $fenghao_end_time;
    $updateData['fenghao_msg']      = $fenghao_msg;
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($user_id,$updateData);

    DB::query("UPDATE ".DB::table('tom_tongcheng')." SET status=2 WHERE user_id='{$user_id}' ", 'UNBUFFERED');
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'jiefeng' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;

    $updateData = array();
    $updateData['status']           = 1;
    $updateData['fenghao_time']     = 0;
    $updateData['fenghao_msg']      = '';
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($user_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']): '';
$nickname       = isset($_GET['nickname'])? addslashes($_GET['nickname']):'';
$tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
$editor         = isset($_GET['editor'])? intval($_GET['editor']):'';
$status         = isset($_GET['status'])? intval($_GET['status']):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = '';
if(!empty($user_id)){
    $where .= " AND id = {$user_id} ";
}
if(!empty($tel)){
    $where .= " AND tel = '{$tel}' ";
}
if($editor > 0){
    if($editor == 1){
        $where .= " AND editor = 1 ";
    }else if($editor == 2){
        $where .= " AND editor = 0 ";
    }
}
if(!empty($status) && $status == 2){
    $where .= " AND status = 2 ";
}   
if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    $whereTmp .= " AND yuyue_no LIKE '%{$keyword}%' ";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_like_count($where,$nickname);
$userListTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_like_list($where,"ORDER BY add_time DESC",$start,$pagesize,$nickname);
$userList = array();
if(!empty($userListTmp)){
    foreach ($userListTmp as $key => $value) {
        $userList[$key] = $value;
        
        if($value['tj_hehuoren_id'] > 0 && $__ShowTchehuoren == 1){
            $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($value['tj_hehuoren_id']);
            $userList[$key]['tchehuorenInfo'] = $tchehuorenInfoTmp;
        }
        
        $userList[$key]['fenghao_time'] = dgmdate($value['fenghao_time'],"Y-m-d H:i",$tomSysOffset) ;
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&nickname={$nickname}&tel={$tel}&editor={$editor}&status={$status}";

$userCount = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_count(" AND is_majia = 0 ");
$allmoneyPrice = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_money_sum(" ");

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:pcadmin/user");