<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=order";

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
$tcshop_id      = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$order_status   = intval($_GET['order_status'])>0? intval($_GET['order_status']):0;
$start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
$startTime      = strtotime($start_time);
$end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
$endTime        = strtotime($end_time);
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = '';
if($site_id > 0){
    $whereStr .= " AND site_id={$site_id} ";
}
if($tongcheng_id > 0){
    $whereStr .= " AND tongcheng_id = {$tongcheng_id} ";
}
if($tcshop_id > 0){
    $whereStr .= " AND tcshop_id = {$tcshop_id} ";
}
if($user_id > 0){
    $whereStr .= " AND user_id={$user_id} ";
}
if($order_status > 0){
    $whereStr .= " AND order_status={$order_status} ";
}
if($startTime > 0){
    $whereStr .= " AND pay_time >= {$startTime} ";
}
if($end_time > 0){
    $whereStr .= " AND pay_time <= {$endTime} ";
}

$start          = ($page - 1)*$pagesize;
$count          = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_count($whereStr,$keyword);
$orderListTmp  = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_list($whereStr," ORDER BY id DESC ",$start,$pagesize,$keyword);
$orderList = array();
if(!empty($orderListTmp)){
    foreach ($orderListTmp as $key => $value) {
        $orderList[$key] = $value;

        $tongchengInfoTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($value['tongcheng_id']);
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);

        $siteInfoTmp = array();
        if($value['site_id'] > 1){
            $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        }

        $tcshopInfoTmp = array();
        if($value['tcshop_id'] > 0){
            $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        }
        
        $vipInfoTmp = array();
        if($value['tcshop_vip_id'] > 0){
            $vipInfoTmp = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($value['tcshop_vip_id']);
        }

        $tongchengInfoTmp['content'] = cutstr(contentFormat($tongchengInfoTmp['content']),20,"...");

        $orderList[$key]['tongchengInfo']       = $tongchengInfoTmp;
        $orderList[$key]['userInfo']            = $userInfoTmp;
        $orderList[$key]['siteInfo']            = $siteInfoTmp;
        $orderList[$key]['vipInfo']             = $vipInfoTmp;
        $orderList[$key]['tcshopInfo']          = $tcshopInfoTmp;
        $orderList[$key]['order_time']          = dgmdate($value['order_time'],"Y-m-d H:i",$tomSysOffset) ;
        $orderList[$key]['pay_time']            = dgmdate($value['pay_time'],"Y-m-d H:i",$tomSysOffset) ;

    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&tongcheng_id={$tongcheng_id}&user_id={$user_id}&order_status={$order_status}";

$todayPayPrice = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_sun_pay_price(" AND pay_time > $nowDayTime AND order_status=2 ");
$monthPayPrice = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_sun_pay_price(" AND pay_time > $nowMonthTime AND order_status=2 ");
$allPayPrice = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_sun_pay_price(" AND order_status=2 ");

if(!empty($whereStr)){
    $searchAllPayPrice = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_sun_pay_price($whereStr);
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:pcadmin/order");