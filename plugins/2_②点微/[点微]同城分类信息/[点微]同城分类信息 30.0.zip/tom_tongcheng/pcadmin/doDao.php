<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=doDao";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'dodao_url' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $day_type       = isset($_GET['day_type'])? intval($_GET['day_type']):1;
    $days           = isset($_GET['days'])? intval($_GET['days']):0;
    $pic            = isset($_GET['pic'])? intval($_GET['pic']):1;
    $hidetel        = isset($_GET['hidetel'])? intval($_GET['hidetel']):2;
    
    $site_ids_url = '';
    if(is_array($_GET['site_ids']) && !empty($_GET['site_ids'])){
        $site_ids = implode(',', $_GET['site_ids']);
        $site_ids_url = implode('_', $_GET['site_ids']);
    }
    
    $model_ids_url = '';
    if(is_array($_GET['model_ids']) && !empty($_GET['model_ids'])){
        $model_ids = implode(',', $_GET['model_ids']);
        $model_ids_url = implode('_', $_GET['model_ids']);
    }
    
    $doDaoUrl = $_G['siteurl']."plugin.php?id=tom_tongcheng:doDao&site_id={$site_id}&site_ids={$site_ids_url}&model_ids={$model_ids_url}&day_type={$day_type}&days={$days}&pic={$pic}&hidetel={$hidetel}&from=tom_admin";
    
    $outArr = array(
        'code'=> 200,
        'url'=> $doDaoUrl,
    );
    echo json_encode($outArr); exit;
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$modelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(" AND is_show=1 "," ORDER BY paixu ASC,id DESC ",0,1000);
$modelList = array();
if(!empty($modelListTmp)){
    foreach($modelListTmp as $key => $value){
        $modelList[$value['id']] = $value;
    }
}

$daysList = array();
for($i = 1; $i <= 30; $i++){
    $daysList[] = $i;
}

$dodaoUrl = $modPcadminUrl."&act=dodao_url&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:pcadmin/doDao");