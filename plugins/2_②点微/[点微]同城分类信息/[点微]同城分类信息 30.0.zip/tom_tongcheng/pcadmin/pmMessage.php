<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=pmMessage";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('message_id')){
    $outArr = array(
        'code'=> 1,
    );

    $message_id = intval($_GET['message_id'])>0? intval($_GET['message_id']):0;

    C::t('#tom_tongcheng#tom_tongcheng_pm_message')->delete($message_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('message_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $messageIdsArr = array();
    if(is_array($_GET['message_ids'])){
        foreach($_GET['message_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $messageIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($messageIdsArr)){
        foreach ($messageIdsArr as $key => $value){
            C::t('#tom_tongcheng#tom_tongcheng_pm_message')->delete($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$pm_lists_id    = intval($_GET['pm_lists_id'])>0? intval($_GET['pm_lists_id']):0;
$is_pic         = intval($_GET['is_pic'])>0? intval($_GET['is_pic']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = "";
if(!empty($user_id)){
    $whereStr .= " AND user_id={$user_id} ";
}
if(!empty($pm_lists_id)){
    $whereStr .= " AND pm_lists_id={$pm_lists_id} ";
}
if(!empty($is_pic)){
    $whereStr .= " AND is_pic={$is_pic} ";
}

$start = ($page-1)*$pagesize;	
$count = C::t('#tom_tongcheng#tom_tongcheng_pm_message')->fetch_all_count($whereStr);
$messageListTmp = C::t('#tom_tongcheng#tom_tongcheng_pm_message')->fetch_all_list($whereStr,"ORDER BY add_time DESC",$start,$pagesize);
$messageList = array();
if(!empty($messageListTmp)){
    foreach($messageListTmp as $key => $value){
        $messageList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $pmListsInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_pm_lists')->fetch_by_id($value['pm_lists_id']);
        if($pmListsInfoTmp['min_use_id'] == $value['user_id']){
            $toUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($pmListsInfoTmp['max_use_id']);
        }else{
            $toUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($pmListsInfoTmp['min_use_id']);
        }
        
        $messageList[$key]['userInfo']      = $userInfoTmp;
        $messageList[$key]['toUserInfo']    = $toUserInfoTmp;
        $messageList[$key]['add_time']      = dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&pm_lists_id={$pm_lists_id}&is_pic={$is_pic}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:pcadmin/pmMessage");