<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=add";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $site_id        = intval($_GET['site_id'])>0? intval($_GET['site_id']):1;
    $model_id       = intval($_GET['model_id'])>0? intval($_GET['model_id']):0;
    $type_id        = intval($_GET['type_id'])>0? intval($_GET['type_id']):0;
    
    $insertData = array();
    $insertData['user_id']      = $user_id;
    $insertData['site_id']      = $site_id;
    $insertData['model_id']     = $model_id;
    $insertData['type_id']      = $type_id;
    $insertData['refresh_time'] = TIMESTAMP;
    $insertData['add_time']     = TIMESTAMP;
    $tongcheng_id = C::t("#tom_tongcheng#tom_tongcheng")->insert($insertData, true);
    if($tongcheng_id > 0){
        $outArr = array(
            'code'=> 200,
            'id'=> $tongcheng_id,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}else if($act == 'save' && submitcheck('tongcheng_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tongcheng_id           = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    $user_id                = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $site_id                = intval($_GET['site_id'])>0? intval($_GET['site_id']):0;
    $tcshop_id              = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    $tcqianggou_goods_id    = intval($_GET['tcqianggou_goods_id'])>0? intval($_GET['tcqianggou_goods_id']):0;
    $tcptuan_goods_id       = intval($_GET['tcptuan_goods_id'])>0? intval($_GET['tcptuan_goods_id']):0;
    $tcqianggou_coupon_id   = intval($_GET['tcqianggou_coupon_id'])>0? intval($_GET['tcqianggou_coupon_id']):0;
    $tcmall_goods_id        = intval($_GET['tcmall_goods_id'])>0? intval($_GET['tcmall_goods_id']):0;
    $tcdaojia_goods_id      = intval($_GET['tcdaojia_goods_id'])>0? intval($_GET['tcdaojia_goods_id']):0;
    $title                  = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title                  = dhtmlspecialchars($title);
    $cate_id                = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
    $area_id                = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id              = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $lng                    = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                    = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address                = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address                = dhtmlspecialchars($address);
    $xm                     = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $xm                     = dhtmlspecialchars($xm);
    $tel                    = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                    = dhtmlspecialchars($tel);
    $wx                     = isset($_GET['wx'])? addslashes($_GET['wx']):'';
    $wx                     = dhtmlspecialchars($wx);
    $content                = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content                = dhtmlspecialchars($content);
    $content                = filterEmoji($content);
    $video_url              = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_url              = dhtmlspecialchars($video_url);
    $video_pic              = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic              = dhtmlspecialchars($video_pic);
    $over_days              = intval($_GET['over_days'])>0? intval($_GET['over_days']):0;
    $toptime                = isset($_GET['toptime'])? addslashes($_GET['toptime']):'';
    $toptime                = strtotime($toptime);
    
    $tongchengInfo = C::t("#tom_tongcheng#tom_tongcheng")->fetch_by_id($tongcheng_id);
    
    $city_id = 0;
    if($tongchengInfo['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tongchengInfo['site_id']);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($tongchengInfo['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
    $modelInfo = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($tongchengInfo['model_id']);
    $cateInfo = array('name'=>'');
    if($cate_id > 0){
        $cateInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_by_id($cate_id);
        if($cateInfoTmp){
            $cateInfo = $cateInfoTmp;
        }
    }
    
    $attrListTmp = C::t('#tom_tongcheng#tom_tongcheng_model_attr')->fetch_all_list(" AND type_id={$tongchengInfo['type_id']} "," ORDER BY paixu ASC,id DESC ",0,50);
    $attrList = array();
    if(is_array($attrListTmp) && !empty($attrListTmp)){
        foreach ($attrListTmp as $key => $value){
            $attrTmp = $_GET['attr_'.$value['id']];
            if(isset($attrTmp) && !empty($attrTmp)){
                if(is_array($attrTmp)){
                    $valueTmp = addslashes(implode(" ", $attrTmp));
                }else{
                    $valueTmp = addslashes($attrTmp);
                }
                
                $attrList[$key] = $value;
                $attrList[$key]['value'] = $valueTmp;
            }
        }
    }
    
    $tagIdsArr = array();
    if(isset($_GET['tag']) && !empty($_GET['tag'])){
        foreach($_GET['tag'] as $key => $value){
            $value = intval($value);
            if($value > 0){
                $tagIdsArr[] = $value;
            }
        }
    }
    
    $tagList = array();
    if(!empty($tagIdsArr)){
        $tagIdsStr = implode(',', $tagIdsArr);
        $tagList = C::t('#tom_tongcheng#tom_tongcheng_model_tag')->fetch_all_list(" AND type_id={$tongchengInfo['type_id']} AND id IN({$tagIdsStr}) "," ORDER BY paixu ASC,id DESC ",0,50);
    }
    
    $photoArr = array();
    if(isset($_GET['photo']) && !empty($_GET['photo'])){
        foreach($_GET['photo'] as $key => $value){
            $value = addslashes($value);
            if(!empty($value)){
                $photoArr[] = $value;
            }
        }
    }
    
    $search_content = '';
    if(is_array($attrList) && !empty($attrList)){
        foreach ($attrList as $key => $value){
            $search_content .= ''.$value['value'].'';
        }
    }

    if(is_array($tagList) && !empty($tagList)){
        foreach ($tagList as $key => $value){
            $search_content.=''.$value['name'].'';
        }
    }
    
    $updateData = array();
    $updateData['site_id']              = $site_id;
    $updateData['user_id']              = $user_id;
    $updateData['tcshop_id']            = $tcshop_id;
    $updateData['tcqianggou_goods_id']  = $tcqianggou_goods_id;
    $updateData['tcptuan_goods_id']     = $tcptuan_goods_id;
    $updateData['tcqianggou_coupon_id'] = $tcqianggou_coupon_id;
    $updateData['tcmall_goods_id']      = $tcmall_goods_id;
    $updateData['tcdaojia_goods_id']    = $tcdaojia_goods_id;
    $updateData['title']                = $title;
    $updateData['cate_id']              = $cate_id;
    $updateData['city_id']              = $city_id;
    $updateData['area_id']              = $area_id;
    $updateData['street_id']            = $street_id;
    if($typeInfo['open_dingwei'] == 1){
        $updateData['is_dingwei']       = 1;
        $updateData['latitude']         = $lat;
        $updateData['longitude']        = $lng;
        $updateData['address']          = $address;
    }else{
        $updateData['is_dingwei']       = 0;
    }
    $updateData['xm']               = $xm;
    $updateData['tel']              = $tel;
    $updateData['wx']               = $wx;
    $updateData['content']          = $content.'|+|+|+|+|+|+|+|+|+|'.$search_content.'-'.$xm.'-'.$tel.'-'.$title.'-'.$cateInfo['name'].'-'.  mt_rand(111111, 666666);
    $updateData['video_url']        = $video_url;
    $updateData['video_pic']        = $video_pic;
    $updateData['refresh_time']     = TIMESTAMP;
    $updateData['add_time']         = TIMESTAMP;
    $updateData['status']           = 1;
    $updateData['pay_status']       = 0;
    $updateData['shenhe_status']    = 1;
    if($over_days > 0){
        $updateData['over_days']        = $over_days;
        $updateData['over_time']        = $over_days * 86400 + TIMESTAMP;
    }
    
    if($toptime > TIMESTAMP){
        $updateData['topstatus']        = 1;
        $updateData['toptime']          = $toptime;
    }
    
    $updateData['client_ip_port']   = $_G['clientip'].'|'.$_SERVER['REMOTE_PORT'];
    $updateData['part1']            = TIMESTAMP;
    if(C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id,$updateData)){
        
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongcheng_id);
        C::t('#tom_tongcheng#tom_tongcheng_photo')->delete_by_tongcheng_id($tongcheng_id);
        C::t('#tom_tongcheng#tom_tongcheng_tag')->delete_by_tongcheng_id($tongcheng_id);
        
        if(is_array($attrList) && !empty($attrList)){
            foreach ($attrList as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $modelInfo['id'];
                $insertData['type_id']      = $typeInfo['id'];
                $insertData['tongcheng_id'] = $tongcheng_id;
                $insertData['attr_id']      = $value['id'];
                $insertData['attr_name']    = $value['name'];
                $insertData['value']        = $value['value'];
                if($value['type'] == 3){
                    $insertData['time_value']   = strtotime($value['value']);
                }
                $insertData['unit']         = $value['unit'];
                $insertData['paixu']        = $value['paixu'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
        
        if(is_array($tagList) && !empty($tagList)){
            foreach ($tagList as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $modelInfo['id'];
                $insertData['type_id']      = $typeInfo['id'];
                $insertData['tongcheng_id'] = $tongcheng_id;
                $insertData['tag_id']       = $value['id'];
                $insertData['tag_name']     = $value['name'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_tag')->insert($insertData);
            }
        }
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['tongcheng_id'] = $tongcheng_id;
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_photo')->insert($insertData);
            }
        }
        
        if($modelInfo['type'] == 2 && !empty($typeInfo['sfc_chufa_attr_id']) && !empty($typeInfo['sfc_mude_attr_id'])  && !empty($typeInfo['sfc_time_attr_id']) && !empty($typeInfo['sfc_renshu_attr_id'])){
            $sfcChufaAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND attr_id = {$typeInfo['sfc_chufa_attr_id']} AND tongcheng_id = {$tongcheng_id}", 'ORDER BY id DESC', 0, 1);
            $sfcMudeAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND attr_id = {$typeInfo['sfc_mude_attr_id']} AND tongcheng_id = {$tongcheng_id}", 'ORDER BY id DESC', 0, 1);
            $sfcTimeAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND attr_id = {$typeInfo['sfc_time_attr_id']} AND tongcheng_id = {$tongcheng_id}", 'ORDER BY id DESC', 0, 1);
            $sfcRenshuAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND attr_id = {$typeInfo['sfc_renshu_attr_id']} AND tongcheng_id = {$tongcheng_id}", 'ORDER BY id DESC', 0, 1);
            
            $insertData = array();
            $insertData['site_id']      = $site_id;
            $insertData['tongcheng_id'] = $tongcheng_id;
            $insertData['model_id']     = $tongchengInfo['model_id'];
            $insertData['type_id']      = $tongchengInfo['type_id'];
            $insertData['chufa']        = $sfcChufaAttrInfoTmp[0]['value'];
            $insertData['mude']         = $sfcMudeAttrInfoTmp[0]['value'];
            $insertData['chufa_time']   = $sfcTimeAttrInfoTmp[0]['value'];
            $insertData['chufa_int_time'] = $sfcTimeAttrInfoTmp[0]['time_value'];
            $insertData['renshu_type']  = $typeInfo['sfc_renshu_type'];
            $insertData['renshu']       = $sfcRenshuAttrInfoTmp[0]['value'];
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_sfc_cache')->insert($insertData);
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$tongcheng_id = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

if($tongcheng_id > 0){
    $tongchengInfo = C::t("#tom_tongcheng#tom_tongcheng")->fetch_by_id($tongcheng_id);
    if($__ShowTcshop == 1){
        $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$tongchengInfo['user_id']} AND v.open_fenlei=1 "," ORDER BY s.id DESC ",0,1000);
        $tcshopList = array();
        if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
            foreach ($tcshopListTmp as $key => $value){
                $tcshopList[$key] = $value;
            }
        }
    }
    
    if($__ShowTcqianggou == 1){
        $tcqianggouListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_list(" AND status=1 AND shenhe_status=1 AND type_id=1 AND user_id={$tongchengInfo['user_id']} AND qiang_status IN(1,2)"," ORDER BY qiang_status ASC,paixu ASC,id DESC ",0,1000);
        $tcqianggouList = array();
        if(is_array($tcqianggouListTmp) && !empty($tcqianggouListTmp)){
            foreach ($tcqianggouListTmp as $key => $value){
                $tcqianggouList[$key] = $value;
            }
        }
        
        $tcqianggouCouponListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_list(" AND status=1 AND shenhe_status=1 AND type_id IN(2,3,4) AND user_id={$tongchengInfo['user_id']} AND qiang_status IN(1,2)"," ORDER BY qiang_status ASC,paixu ASC,id DESC ",0,1000);
        $tcqianggouCouponList = array();
        if(is_array($tcqianggouCouponListTmp) && !empty($tcqianggouCouponListTmp)){
            foreach ($tcqianggouCouponListTmp as $key => $value){
                $tcqianggouCouponList[$key] = $value;
            }
        }
    }
    
    if($__ShowTcptuan == 1){
        $tcptuanListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_like_list(" AND ptuan_status = 1 AND status=1 AND shenhe_status=1 AND user_id={$tongchengInfo['user_id']} "," ORDER BY ptuan_status ASC,paixu ASC,id DESC ",0,1000);
        $tcptuanList = array();
        if(is_array($tcptuanListTmp) && !empty($tcptuanListTmp)){
            foreach ($tcptuanListTmp as $key => $value){
                $tcptuanList[$key] = $value;
            }
        }
    }
    
    if($__ShowTcmall == 1){
        $tcmallListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list("  AND status=1 AND shenhe_status=1 AND user_id={$tongchengInfo['user_id']} "," ORDER BY gsort DESC ,add_time DESC,id DESC ",0,1000);
        $tcmallList = array();
        if(is_array($tcmallListTmp) && !empty($tcmallListTmp)){
            foreach ($tcmallListTmp as $key => $value){
                $tcmallList[$key] = $value;
            }
        }
    }
    
    if($__ShowTcdaojia == 1){
        $tcdaojiaListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND user_id={$tongchengInfo['user_id']} "," ORDER BY refresh_time DESC,id DESC ",0,1000);
        $tcdaojiaList = array();
        if(is_array($tcdaojiaListTmp) && !empty($tcdaojiaListTmp)){
            foreach ($tcdaojiaListTmp as $key => $value){
                $tcdaojiaList[$key] = $value;
            }
        }
    }
    
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
    $modelInfo = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($tongchengInfo['model_id']);
    $cateList = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_all_list(" AND type_id={$tongchengInfo['type_id']}  "," ORDER BY paixu ASC,id DESC ",0,50);
    $tagList = C::t('#tom_tongcheng#tom_tongcheng_model_tag')->fetch_all_list(" AND type_id={$tongchengInfo['type_id']} "," ORDER BY paixu ASC,id DESC ",0,50);
    
    $attrListTmp = C::t('#tom_tongcheng#tom_tongcheng_model_attr')->fetch_all_list(" AND type_id={$tongchengInfo['type_id']} "," ORDER BY paixu ASC,id DESC ",0,50);
    $attrList = array();
    if(is_array($attrListTmp) && !empty($attrListTmp)){
        foreach ($attrListTmp as $key => $value){
            $attrList[$key] = $value;
            if($value['type'] == 2 || $value['type'] == 4){
                $value_listStr = str_replace("\r\n","{n}",$value['value']); 
                $value_listStr = str_replace("\n","{n}",$value_listStr);
                $attrList[$key]['list'] = explode("{n}", $value_listStr);
            }
        }
    }
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($tongchengInfo['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tongchengInfo['site_id']);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
        }
    }else if($tongchengInfo['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    
    $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
    
    $over_days_item = array();
    if(!empty($typeInfo['fabu_price_str'])){
        $fabu_price_str = str_replace("\r\n","{n}",$typeInfo['fabu_price_str']); 
        $fabu_price_str = str_replace("\n","{n}",$fabu_price_str);
        $fabu_price_list = explode("{n}", $fabu_price_str);
        if(is_array($fabu_price_list) && !empty($fabu_price_list)){
            foreach ($fabu_price_list as $key => $value){
                $fabu_price_list_item = explode("|", $value);
                $fabu_price_list_item_days = intval($fabu_price_list_item[0]);
                if($fabu_price_list_item_days > 0){
                    $over_days_item[$fabu_price_list_item_days]['days'] = $fabu_price_list_item_days;
                }
            }
        }
    }
    
    $addUrl = $modPcadminUrl."&act=save&tongcheng_id={$tongcheng_id}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tongcheng:pcadmin/add2");
}else{
    
    $modelWhereStr = " AND sites_show=0  ";
    $modelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list($modelWhereStr," ORDER BY paixu ASC,id DESC ",0,100);
    $modelList = array();
    if(is_array($modelListTmp) && !empty($modelListTmp)){
        foreach ($modelListTmp as $key => $value){
            $modelList[$value['id']] = $value;
        }
    }
    
    $typeListTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_all_list("  "," ORDER BY paixu ASC,id DESC ",0,2000);
    $typeList = $typeData = array();
    if(!empty($typeListTmp)){
        foreach($typeListTmp as $key => $value){
            $typeList[$value['id']] = $value;
            $modelList[$value['model_id']]['typeList'][] = $value;

            $typeData[$value['model_id']][$value['id']] = diconv($value['name'],CHARSET,'utf-8');
        }
    }
    $typeArr[0] = $typeData;
    $typeData = urlencode(json_encode($typeArr));
    
    $addUrl = $modPcadminUrl."&act=add";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tongcheng:pcadmin/add1");
}