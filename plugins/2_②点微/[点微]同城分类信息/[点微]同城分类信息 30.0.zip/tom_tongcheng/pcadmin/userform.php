<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=userform";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($_GET['act'] == 'save' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id                = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $nickname               = isset($_GET['nickname'])? addslashes($_GET['nickname']):'';
    $tj_hehuoren_id         = intval($_GET['tj_hehuoren_id'])>0?intval($_GET['tj_hehuoren_id']):0;
    $tixian_shouxufei_bili  = floatval($_GET['tixian_shouxufei_bili'])>0? floatval($_GET['tixian_shouxufei_bili']):0;
    $picurl                 = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    
    if(!empty($picurl)){
        if(!preg_match('/^http/', $picurl) ){
            if(strpos($picurl, 'data/attachment/tomwx/') === FALSE){
                $picurl = 'data/attachment/tomwx/'.$picurl;
            }else{
                $picurl = $picurl;
            }
        }else{
            $picurl = $picurl;
        }
    }
    
    $updateData = array();
    $updateData['nickname']                 = $nickname;
    $updateData['tj_hehuoren_id']           = $tj_hehuoren_id;
    $updateData['tixian_shouxufei_bili']    = $tixian_shouxufei_bili;
    $updateData['picurl']                   = $picurl;
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($user_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$user_id = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;

$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:pcadmin/userform");