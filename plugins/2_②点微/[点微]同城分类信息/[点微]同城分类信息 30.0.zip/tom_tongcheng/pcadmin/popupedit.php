<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$popup_id = intval($_GET['popup_id'])>0 ? intval($_GET['popup_id']):0;

$popupInfo = C::t('#tom_tongcheng#tom_tongcheng_popup')->fetch_by_id($popup_id);
if(empty($popupInfo)){
    dheader('location:'.$pcadminUrl."&tmod=popup");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=popupedit&popup_id={$popup_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('title')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $type           = isset($_GET['type'])? intval($_GET['type']):1;
    $show_num       = isset($_GET['show_num'])? intval($_GET['show_num']):0;
    $link           = isset($_GET['link'])? addslashes($_GET['link']):'';
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $siteIdsArr = array();
    if(is_array($_GET['sites']) && !empty($_GET['sites'])){
        foreach($_GET['sites'] as $key => $value){
            $value = intval($value);
            if($value > 0){
                $siteIdsArr[] = '['.$value.']';
            }
        }
    }
    
    $siteIdsStr = implode(',', $siteIdsArr);
    
    $updateData = array();
    $updateData['site_ids']     = $siteIdsStr;
    $updateData['title']        = $title;
    $updateData['type']         = $type;
    $updateData['show_num']     = $show_num;
    $updateData['link']         = $link;
    $updateData['picurl']       = $picurl;
    $updateData['status']       = $status;
    $updateData['content']      = $content;
    $updateData['add_time']     = TIMESTAMP;
    if(C::t('#tom_tongcheng#tom_tongcheng_popup')->update($popup_id, $updateData)){
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$siteIdsArr = explode(',', $popupInfo['site_ids']);

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
        $sitesList[$value['id']]['checked'] = false;
            
        $idTmp = '['.$value['id'].']';
        if(in_array($idTmp, $siteIdsArr)){
            $sitesList[$value['id']]['checked'] = true;
        }
    }
}

$siteOneChecked = false;
if(in_array('[1]', $siteIdsArr)){
    $siteOneChecked = true;
}

$picurl = get_file_url($popupInfo['picurl']);
$popupInfo['content'] = stripcslashes($popupInfo['content']);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:pcadmin/popupedit");