<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pluginsArr = array(
    'tongcheng1' => array(
        'plugin_id' => 'tom_tongcheng',
        'name'      => '������Ϣ',
        'class'     => 'tc-sec mt0',
        'url'       => 'plugin.php?id=tom_tongcheng:ajax&site={SITE}&act=list',
    ),
    'tongcheng2' => array(
        'plugin_id' => 'tom_tongcheng',
        'name'      => '������Ϣ',
        'class'     => 'tc-sec mt0',
        'url'       => 'plugin.php?id=tom_tongcheng:ajax&site={SITE}&act=list&ordertype=nearby',
    ),
    'tcshop' => array(
        'plugin_id' => 'tom_tcshop',
        'name'      => '�õ�',
        'class'     => 'tcshop-list',
        'url'       => 'plugin.php?id=tom_tcshop:ajax&site={SITE}&act=list',
    ),
    'tcmall' => array(
        'plugin_id' => 'tom_tcmall',
        'name'      => '�̳�',
        'class'     => 'tcmall-list',
        'url'       => 'plugin.php?id=tom_tcmall:ajax&site={SITE}&act=list',
    ),
    'tcqianggou' => array(
        'plugin_id' => 'tom_tcqianggou',
        'name'      => '����',
        'class'     => 'qianggou-list',
        'url'       => 'plugin.php?id=tom_tcqianggou:ajax&site={SITE}&act=list&qiang_list_type=3',
    ),
    'tcptuan' => array(
        'plugin_id' => 'tom_tcptuan',
        'name'      => 'ƴ��',
        'class'     => 'tcptuan-list',
        'url'       => 'plugin.php?id=tom_tcptuan:ajax&site={SITE}&act=list',
    ),
    'coupon' => array(
        'plugin_id' => 'tom_tcqianggou',
        'name'      => '����',
        'class'     => 'coupon-list',
        'url'       => 'plugin.php?id=tom_tcqianggou:ajax&site={SITE}&act=couponlist',
    ),
    'tcyikatong' => array(
        'plugin_id' => 'tom_tcyikatong',
        'name'      => '������',
        'class'     => 'tcyikatong-list',
        'url'       => 'plugin.php?id=tom_tcyikatong:ajax&site={SITE}&act=list',
    ),
    'tczhaopin' => array(
        'plugin_id' => 'tom_tczhaopin',
        'name'      => '��Ƹ',
        'class'     => 'zhaopin-list',
        'url'       => 'plugin.php?id=tom_tczhaopin:ajax&site={SITE}&act=zhaopinlist',
    ),
    'resume' => array(
        'plugin_id' => 'tom_tczhaopin',
        'name'      => '���˲�',
        'class'     => 'resume-list',
        'url'       => 'plugin.php?id=tom_tczhaopin:ajax&site={SITE}&act=resumelist',
    ),
    'tctoutiao' => array(
        'plugin_id' => 'tom_tctoutiao',
        'name'      => 'ͷ��',
        'class'     => 'toutiao-list',
        'url'       => 'plugin.php?id=tom_tctoutiao:ajax&site={SITE}&act=list',
    ),
    'tcpinche' => array(
        'plugin_id' => 'tom_tcpinche',
        'name'      => 'ƴ��',
        'class'     => 'pinche-list',
        'url'       => 'plugin.php?id=tom_tcpinche:ajax&site={SITE}&act=list',
    ),
    'ershoufang' => array(
        'plugin_id' => 'tom_tcfangchan',
        'name'      => '���ַ�',
        'class'     => 'fangchan-list',
        'url'       => 'plugin.php?id=tom_tcfangchan:ajax&site={SITE}&act=list&model_id=ershoufang',
    ),
    'chuzu' => array(
        'plugin_id' => 'tom_tcfangchan',
        'name'      => '����',
        'class'     => 'fangchan-list',
        'url'       => 'plugin.php?id=tom_tcfangchan:ajax&site={SITE}&act=list&model_id=chuzu',
    ),
    'shangpu' => array(
        'plugin_id' => 'tom_tcfangchan',
        'name'      => '����',
        'class'     => 'fangchan-list',
        'url'       => 'plugin.php?id=tom_tcfangchan:ajax&site={SITE}&act=list&model_id=shangpu',
    ),
    'huodong' => array(
        'plugin_id' => 'tom_tchuodong',
        'name'      => '�',
        'class'     => 'huodong-list',
        'url'       => 'plugin.php?id=tom_tchuodong:ajax&site={SITE}&act=list&from=tongcheng',
    ),
    'qun' => array(
        'plugin_id' => 'tom_tcqun',
        'name'      => '΢��Ⱥ',
        'class'     => 'qun-list',
        'url'       => 'plugin.php?id=tom_tcqun:ajax&site={SITE}&act=list&from=tongcheng',
    ),
    'ershou' => array(
        'plugin_id' => 'tom_tcershou',
        'name'      => '����',
        'class'     => 'ershou-list',
        'url'       => 'plugin.php?id=tom_tcershou:ajax&site={SITE}&act=list&from=tongcheng',
    ),
    'daojia' => array(
        'plugin_id' => 'tom_tcdaojia',
        'name'      => '����',
        'class'     => 'daojia-list',
        'url'       => 'plugin.php?id=tom_tcdaojia:ajax&site={SITE}&act=goodslist&template_type=1&from=tongcheng',
    ),
    'edu' => array(
        'plugin_id' => 'tom_tcedu',
        'name'      => '��ѵ����',
        'class'     => 'edu_list',
        'url'       => 'plugin.php?id=tom_tcedu:ajax&site={SITE}&act=list&from=tongcheng',
    ),
    'course' => array(
        'plugin_id' => 'tom_tcedu',
        'name'      => '��ѵ�γ�',
        'class'     => 'course_list',
        'url'       => 'plugin.php?id=tom_tcedu:ajax&site={SITE}&act=courselist&from=tongcheng',
    ),
);

if (CHARSET == 'utf-8') {
    $pluginsArr = tom_pluginsArr_iconv($pluginsArr,'gbk','utf-8');
}

function tom_pluginsArr_iconv($data, $in_charset, $out_charset) {
    if(is_array($data)) {
        foreach($data AS $key => $val) {
            $data[$key] = tom_pluginsArr_iconv($val, $in_charset, $out_charset);
        }
    } else {
        $data = diconv($data, $in_charset, $out_charset);
    }
    return $data;
}