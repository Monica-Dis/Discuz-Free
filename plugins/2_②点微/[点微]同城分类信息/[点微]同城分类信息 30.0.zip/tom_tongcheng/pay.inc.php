<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

$tongchengSetting = C::t('#tom_tongcheng#tom_tongcheng_setting')->fetch_by_id(1);
if($tongchengSetting && $tongchengSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tongcheng#tom_tongcheng_setting')->insert($insertData);
    $tongchengSetting = C::t('#tom_tongcheng#tom_tongcheng_setting')->fetch_by_id(1);
}

$wxpay_appid        = trim($tongchengConfig['wxpay_appid']);
$wxpay_mchid        = trim($tongchengConfig['wxpay_mchid']);
$wxpay_key          = trim($tongchengConfig['wxpay_key']);
$wxpay_appsecret    = trim($tongchengConfig['wxpay_appsecret']);

define("TOM_WXPAY_APPID", $wxpay_appid);
define("TOM_WXPAY_MCHID", $wxpay_mchid);
define("TOM_WXPAY_KEY", $wxpay_key);
define("TOM_WXPAY_APPSECRET", $wxpay_appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($wxpay_appid,$wxpay_appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/wxpay/lib/WxPay.Api.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tcyikatong start
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
    $tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $__ShowTcyikatong = 1;
    }
}
## tcyikatong end
## tcmajia start
$__ShowTcmajia = 0;
$tcmajiaConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcmajia/tom_tcmajia.inc.php')){
    $tcmajiaConfig = $_G['cache']['plugin']['tom_tcmajia'];
    if($tcmajiaConfig['open_tcmajia'] == 1){
        $__ShowTcmajia = 1;
    }
}
##
## tcmajia end
## tcadmin start
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
## tcadmin end
## xiaofenlei start
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')){
    $xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
    $__ShowXiaofenlei = 1;
}
## xiaofenlei end
## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end

$act = isset($_GET['act'])? addslashes($_GET['act']):"fabu";

if($act == "fabu" && $_GET['formhash'] == FORMHASH && $userStatus == true){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $over_days  = isset($_GET['over_days'])? intval($_GET['over_days']):0;
    $top_days   = isset($_GET['top_days'])? intval($_GET['top_days']):0;
    $user_id    = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $model_id   = isset($_GET['model_id'])? intval($_GET['model_id']):0;
    $type_id    = isset($_GET['type_id'])? intval($_GET['type_id']):0;
    $cate_id    = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $city_id    = isset($_GET['city_id'])? intval($_GET['city_id']):0;
    $area_id    = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id  = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $tcshop_id    = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $title      = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title      = dhtmlspecialchars($title);
    $xm         = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $xm         = dhtmlspecialchars($xm);
    $tel        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel        = dhtmlspecialchars($tel);
    $wx         = isset($_GET['wx'])? addslashes($_GET['wx']):'';
    $wx         = dhtmlspecialchars($wx);
    $content    = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content    = dhtmlspecialchars($content);
    $content    = filterEmoji($content);
    $open_majia = isset($_GET['open_majia'])? intval($_GET['open_majia']):0;
    $lng        = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat        = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address    = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address    = dhtmlspecialchars($address);
    
    $video_url      = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_url      = dhtmlspecialchars($video_url);
    $video_pic      = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic      = dhtmlspecialchars($video_pic);
    
    $open_tui_click = isset($_GET['open_tui_click'])? intval($_GET['open_tui_click']):0;
    $tui_click_num  = isset($_GET['tui_click_num'])? intval($_GET['tui_click_num']):0;
    if($open_tui_click == 0){
        $tui_click_num = 0;
    }
    
    $tcqianggou_goods_id    = isset($_GET['tcqianggou_goods_id'])? intval($_GET['tcqianggou_goods_id']):0;
    $tcptuan_goods_id       = isset($_GET['tcptuan_goods_id'])? intval($_GET['tcptuan_goods_id']):0;
    $tcqianggou_coupon_id   = isset($_GET['tcqianggou_coupon_id'])? intval($_GET['tcqianggou_coupon_id']):0;
    $tcmall_goods_id        = isset($_GET['tcmall_goods_id'])? intval($_GET['tcmall_goods_id']):0;
    $tcdaojia_goods_id      = isset($_GET['tcdaojia_goods_id'])? intval($_GET['tcdaojia_goods_id']):0;
    
//    if($tcqianggou_goods_id > 0 || $tcptuan_goods_id > 0){
//        $open_tui_click = 0;
//        $tui_click_num = 0;
//    }
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($type_id);
    $modelInfo = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($typeInfo['model_id']);
    $cateInfo = array('name'=>'');
    if($cate_id > 0){
        $cateInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_by_id($cate_id);
        if($cateInfoTmp){
            $cateInfo = $cateInfoTmp;
        }
    }
    
    if(empty($userInfo) || empty($typeInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['id'] != $__UserInfo['id']){
        $outArr = array(
            'status'=> 501,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($__IsApp == 1){
        if(!empty($typeInfo['app_fabu_price']) && $typeInfo['app_fabu_price'] > 0){
            $typeInfo['fabu_price'] = $typeInfo['app_fabu_price'];
        }
        if(!empty($typeInfo['app_fabu_price_str'])){
            $typeInfo['fabu_price_str'] = $typeInfo['app_fabu_price_str'];
        }
    }
    
    $sites_priceTmp = C::t('#tom_tongcheng#tom_tongcheng_sites_price')->fetch_all_list(" AND site_id={$site_id} AND type_id={$type_id} "," ORDER BY id DESC ",0,1);
    if(is_array($sites_priceTmp) && !empty($sites_priceTmp) && $sites_priceTmp[0]['id']>0){
         $typeInfo['free_status']   = $sites_priceTmp[0]['free_status'];
         $typeInfo['fabu_price']    = $sites_priceTmp[0]['fabu_price'];
         $typeInfo['fabu_price_str']= $sites_priceTmp[0]['fabu_price_str'];
         $typeInfo['top_price']     = $sites_priceTmp[0]['top_price'];
         $typeInfo['top_price_str'] = $sites_priceTmp[0]['top_price_str'];
         
         if($__IsApp == 1){
            if(!empty($sites_priceTmp[0]['app_fabu_price']) && $sites_priceTmp[0]['app_fabu_price'] > 0){
                $typeInfo['fabu_price'] = $sites_priceTmp[0]['app_fabu_price'];
            }
            if(!empty($sites_priceTmp[0]['app_fabu_price_str'])){
                $typeInfo['fabu_price_str'] = $sites_priceTmp[0]['app_fabu_price_str'];
            }
        }
        
    }
    
    $over_days_item = array();
    if(!empty($typeInfo['fabu_price_str'])){
        $fabu_price_str = str_replace("\r\n","{n}",$typeInfo['fabu_price_str']); 
        $fabu_price_str = str_replace("\n","{n}",$fabu_price_str);
        $fabu_price_list = explode("{n}", $fabu_price_str);
        if(is_array($fabu_price_list) && !empty($fabu_price_list)){
            foreach ($fabu_price_list as $key => $value){
                $fabu_price_list_item = explode("|", $value);
                $fabu_price_list_item_days = intval($fabu_price_list_item[0]);
                $fabu_price_list_item_price = floatval($fabu_price_list_item[1]);
                $fabu_price_list_item_msg = $fabu_price_list_item[2];
                if($fabu_price_list_item_days > 0 && $fabu_price_list_item_price > 0){
                    $over_days_item[$fabu_price_list_item_days]['days'] = $fabu_price_list_item_days;
                    $over_days_item[$fabu_price_list_item_days]['price'] = $fabu_price_list_item_price;
                    $over_days_item[$fabu_price_list_item_days]['msg'] = $fabu_price_list_item_msg;
                }
            }
        }
    }
    
    $top_item = array();
    if(!empty($typeInfo['top_price_str'])){
        $top_price_str = str_replace("\r\n","{n}",$typeInfo['top_price_str']); 
        $top_price_str = str_replace("\n","{n}",$top_price_str);
        $top_price_list = explode("{n}", $top_price_str);
        if(is_array($top_price_list) && !empty($top_price_list)){
            foreach ($top_price_list as $key => $value){
                $top_price_list_item = explode("|", $value);
                $top_price_list_item_days = intval($top_price_list_item[0]);
                $top_price_list_item_price = floatval($top_price_list_item[1]);
                if($top_price_list_item_days > 0 && $top_price_list_item_price > 0){
                    $top_item[$top_price_list_item_days] = $top_price_list_item_price;
                }
            }
        }
    }
    if(empty($top_item)){
        $buy_item_days = array(1,3,5,7,15,30);
        if($typeInfo['top_price'] == 0.00){
            $typeInfo['top_price'] = 1;
        }
        foreach ($buy_item_days as $key => $value){
            $top_item[$value] = $typeInfo['top_price']*$value;
        }
    }
    
    $song_top_days = 0;
    if($typeInfo['jifei_type'] == 2){
        if(isset($over_days_item[$over_days]) && $over_days_item[$over_days]['price'] > 0){
            $typeInfo['fabu_price'] = $over_days_item[$over_days]['price'];
            if(strpos($over_days_item[$over_days]['msg'], 'TOP') !== false){
                $topStr = str_replace('TOP', '', $over_days_item[$over_days]['msg']);
                if(intval($topStr) > 0){
                    $song_top_days = intval($topStr);
                }
            }
            
        }else{
            $outArr = array(
                'status'=> 502,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $lastTongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list(" AND user_id={$user_id} "," ORDER BY id DESC ",0,1);
    if($lastTongchengListTmp && $lastTongchengListTmp[0]['add_time'] > 0 && $userInfo['editor']==0){
        $nextFabuTime = $lastTongchengListTmp[0]['add_time'] + $tongchengConfig['fabu_next_minute']*60;
        if($nextFabuTime > TIMESTAMP){
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $safe_words_shenhe = 0;
    $__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
    if(!empty($__CommonInfo['forbid_word'])){
        $forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
        $forbid_word = str_replace(array("\\*"), array('.*'), $forbid_word);
        $forbid_word = '.*('.$forbid_word.').*';
        $forbid_word = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word).')$/i';
        $contentTmpTmp = $content;
        $contentTmpTmp = str_replace("\r\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\r","",$contentTmpTmp);
        if(@preg_match($forbid_word, $contentTmpTmp,$matches)) {
            $i = count($matches)-1;
            $word = '';
            if(isset($matches[$i]) && !empty($matches[$i])){
                $word = diconv($matches[$i],CHARSET,'utf-8');
            }
            if($tongchengConfig['safe_words_do'] == 1){
                $modelInfo['must_shenhe'] = 1;
                $safe_words_shenhe = 1;
            }else{
                $outArr = array(
                    'status'=> 505,
                    'word'=> $word,
                );
                echo json_encode($outArr); exit;
            }
        }
                
    }
    
    if(!empty($video_url) && empty($video_pic)){
        $outArr = array(
            'status'=> 506,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tongchengConfig['open_similar_text'] == 1){
        $last20TongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND finish=0 "," ORDER BY id DESC ",0,20);
        if(is_array($last20TongchengListTmp) && !empty($last20TongchengListTmp)){
            foreach ($last20TongchengListTmp as $key => $value){
                $contentTmp = contentFormat($value['content']);
                similar_text($content,$contentTmp,$percentTmp);
                if($percentTmp > 85){
                    $outArr = array(
                        'status'=> 501,
                        'percent'=> $percentTmp,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        $similarTongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND finish=0 "," ORDER BY id DESC ",0,2,$content);
        if(is_array($similarTongchengListTmp) && !empty($similarTongchengListTmp)){
            $outArr = array(
                'status'=> 501,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $attrnameArr = $attrArr = $attrunitArr = $attrpaixuArr = $attrdateArr = $tagnameArr = $photoArr = array();
    foreach($_GET as $key => $value){
        $value = dhtmlspecialchars($value);
        if(strpos($key, "attrname_") !== false){
            $attr_id = intval(ltrim($key, 'attrname_'));
            $attrnameArr[$attr_id] = addslashes($value);
        }
        if(strpos($key, "attrpaixu_") !== false){
            $attr_id = intval(ltrim($key, 'attrpaixu_'));
            $attrpaixuArr[$attr_id] = addslashes($value);
        }
        if(strpos($key, "attrunit_") !== false){
            $attr_id = intval(ltrim($key, 'attrunit_'));
            $attrunitArr[$attr_id] = addslashes($value);
        }
        if(strpos($key, "attr_") !== false){
            $attr_id = intval(ltrim($key, 'attr_'));
            if(is_array($value)){
                $valueTmp = implode(" ", $value);
                $attrArr[$attr_id] = addslashes($valueTmp);
            }else{
                $attrArr[$attr_id] = addslashes($value);
            }
        }
        if(strpos($key, "attrdate_") !== false){
            $attr_id = intval(ltrim($key, 'attrdate_'));
            $value = str_replace("T", " ", $value);
            $attrdateArr[$attr_id] = addslashes($value);
        }
        if(strpos($key, "tagname_") !== false){
            $tag_id = intval(ltrim($key, 'tagname_'));
            $tagnameArr[$tag_id] = addslashes($value);
        }
        if(strpos($key, "photo_") !== false){
            $photoArr[] = addslashes($value);
        }
    }
    
    $tagArr = array();
    if(isset($_GET['tag']) && is_array($_GET['tag'])){
        foreach ($_GET['tag'] as $key => $value){
            $tagArr[] = intval($value);
        }
    }
    
    $search_content = '';
    if(is_array($attrArr) && !empty($attrArr)){
        foreach ($attrArr as $key => $value){
            $search_content.=''.$attrnameArr[$key].$value.'';
        }
    }
    if(is_array($tagArr) && !empty($tagArr)){
        foreach ($tagArr as $key => $value){
            $search_content.=''.$tagnameArr[$value].'';
        }
    }
    
    if($__ShowXiaofenlei == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php';
        if($xiaofenleiConfig['open_msgseccheck'] == 1){
            @$s_m_r = wx_msgSecCheck($content.'-'.$search_content.'-'.$xm.'-'.$tel.'-'.$title);
            if($s_m_r['code'] == 100){
                $modelInfo['must_shenhe'] = 1;
                $safe_words_shenhe = 1;
            }
            if($s_m_r['code'] == 500){
                $outArr = array(
                    'status'=> 505,
                    'word'=> $s_m_r['word'],
                );
                echo json_encode($outArr); exit;
            }
        }
        $imgseccheck_listArr = unserialize($xiaofenleiConfig['imgseccheck_list']);
        if(array_search('2',$imgseccheck_listArr) !== false && $xiaofenleiConfig['open_imgseccheck'] == 1){
            if(is_array($photoArr) && !empty($photoArr)){
                foreach ($photoArr as $kk => $vv){
                    if(!preg_match('/^http/', $vv['picurl']) ){
                        if(strpos($vv['picurl'], 'source/plugin/tom_') === false){    
                            $check_picurl_tmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                        }else{
                            $check_picurl_tmp = $_G['siteurl'].$vv['picurl'];
                        }
                    }else{
                        $check_picurl_tmp = $vv['picurl'];
                    }
                    @$s_i_r = wx_imgSecCheck($check_picurl_tmp);
                    if($s_i_r['code'] == 500){
                        $modelInfo['must_shenhe'] = 1;
                        $safe_words_shenhe = 1;
                    }
                }
            }
        }
    }
    
    $shop_free_fenlei_times = 0;
    if($__ShowTcshop == 1){
        $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$userInfo['id']} AND v.fenlei_times > 0 "," ORDER BY s.id DESC ",0,100);
        if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
            foreach ($tcshopListTmp as $key => $value){
                $shop_free_fenlei_times = $shop_free_fenlei_times + $value['vip_fenlei_times'];
            }
        }
    }
    
    $fabuPayStatus = 0;
    $fabuPayPrice  = 0;
    $isVipFabu     = 0;
    $isShopFabu    = 0;
    $useScore      = 0;
    if($typeInfo['free_status'] == 2 && $typeInfo['fabu_price'] > 0 && $userInfo['editor']==0){
        $fabuPayStatus = 1;
        ## VIP start
        if($__ShowTcyikatong == 1 && $tcyikatongConfig['open_fenlei_tequan'] == 1 && $tcyikatongConfig['fenlei_tequan_type'] == 1){
            $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($userInfo['id']);
            if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
                $typeInfo['fabu_price'] = $typeInfo['fabu_price']/2;
            }
        }
        if($__ShowTcyikatong == 1 && $tcyikatongConfig['open_fenlei_tequan'] == 1 && $tcyikatongConfig['fenlei_tequan_type'] == 2){
            $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($userInfo['id']);
            if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
                $vip_fabu_log_count = C::t('#tom_tcyikatong#tom_tcyikatong_fabu_log')->fetch_all_count(" AND user_id={$userInfo['id']} AND time_key={$nowDayTime} ");
                if($vip_fabu_log_count < $tcyikatongConfig['fenlei_tequan_times']){
                    $isVipFabu     = 1;
                    $fabuPayStatus = 0;
                }
            }
        }
        ## VIP end
        
        if($__ShowTcshop == 1 && $shop_free_fenlei_times > 0 && $fabuPayStatus == 1){
            $shop_fabu_log_count = C::t('#tom_tcshop#tom_tcshop_fabu_log')->fetch_all_count(" AND user_id={$userInfo['id']} AND time_key={$nowDayTime} ");
            if($shop_fabu_log_count < $shop_free_fenlei_times){
                $fabuPayStatus      = 0;
                $isShopFabu         = 1;
            }
        }
        
        if($tongchengConfig['free_fabu_times'] > 0  && $fabuPayStatus == 1 && $typeInfo['jifei_type'] == 1){
            $fabu_log_count = C::t('#tom_tongcheng#tom_tongcheng_fabu_log')->fetch_all_count(" AND user_id={$userInfo['id']} AND time_key={$nowDayTime} ");
            if($tongchengSetting['open_all_free_fabu_times'] == 1 && $tongchengSetting['all_free_fabu_times'] > 0){
                if($tongchengSetting['free_fabu_times_days'] > 0){
                    $free_fabu_times_days_time = TIMESTAMP - $tongchengSetting['free_fabu_times_days']*86400;
                    $all_fabu_log_count = C::t('#tom_tongcheng#tom_tongcheng_fabu_log')->fetch_all_count(" AND user_id={$userInfo['id']} AND add_time > {$free_fabu_times_days_time} ");
                }else{
                    $all_fabu_log_count = C::t('#tom_tongcheng#tom_tongcheng_fabu_log')->fetch_all_count(" AND user_id={$userInfo['id']} ");
                }
                if($tongchengSetting['all_free_fabu_times'] <= $all_fabu_log_count){
                    $tongchengConfig['free_fabu_times'] = 0;
                }
            }
            if($tongchengConfig['free_fabu_times'] > $fabu_log_count){
                $fabuPayStatus = 3;
            }
        }
        if($tongchengConfig['pay_score_yuan'] > 0 && $fabuPayStatus == 1 && $tongchengConfig['open_fabu_score_pay'] == 1){
            $useScore = $tongchengConfig['pay_score_yuan']*$typeInfo['fabu_price'];
            $useScore = ceil($useScore);
            if($userInfo['score'] >= $useScore){
                $fabuPayStatus = 2;
            }
        }
    }
    $fabuPayPrice = $typeInfo['fabu_price'];
    if($fabuPayStatus != 1){
        $fabuPayPrice = 0;
    }
    if($fabuPayStatus != 2){
        $useScore = 0;
    }
    
    $topPayStatus = 0;
    $topPayPrice  = 0;
    $useTopScore  = 0;
    if($top_days > 0 && isset($top_item[$top_days]) && $top_item[$top_days] > 0){
        $topPayStatus = 1;
        $topPayPrice  = $top_item[$top_days];
        if($tongchengConfig['open_top_score_pay'] == 1){
            $useTopScore = $tongchengConfig['pay_score_yuan']*$top_item[$top_days];
            $useTopScore = ceil($useTopScore);
            if($fabuPayStatus == 2){
                if($userInfo['score'] >= ($useScore + $useTopScore)){
                    $topPayStatus = 2;
                }
            }else{
                if($userInfo['score'] >= $useTopScore){
                    $topPayStatus = 2;
                }
            }
        }
    }else{
        $top_days = 0;
    }
    if($topPayStatus != 1){
        $topPayPrice = 0;
    }
    if($topPayStatus != 2){
        $useTopScore = 0;
    }
    
    $tuiPayStatus = 0;
    $tuiPayPrice  = 0;
    if($open_tui_click == 1 && $tui_click_num > 0){
        $tuiListMoney = array();
        $tui_list_money_str = str_replace("\r\n","{n}",$tchehuorenConfig['tui_list_money']); 
        $tui_list_money_str = str_replace("\n","{n}",$tui_list_money_str);
        $tui_list_money_arr = explode("{n}", $tui_list_money_str);
        if(is_array($tui_list_money_arr) && !empty($tui_list_money_arr)){
            foreach ($tui_list_money_arr as $key => $value){
                $tuiListMoneyArr = explode("|", $value);
                $tuiListMoney[$tuiListMoneyArr[1]] = $tuiListMoneyArr[0];
            }
        }
        $tui_click_pay_price = $tui_click_all_money = $tui_click_click_money = 0;
        if(isset($tuiListMoney[$tui_click_num]) && $tuiListMoney[$tui_click_num] > 0){
            $tui_click_pay_price = $tuiListMoney[$tui_click_num];
            $tui_click_all_money = $tuiListMoney[$tui_click_num];
            if($tchehuorenConfig['tui_yongjin'] > 0 && $tchehuorenConfig['tui_yongjin'] < 100){
                $tui_click_all_money = $tui_click_all_money * ((100 - $tchehuorenConfig['tui_yongjin'])/100);
            }
            $tui_click_click_money = $tui_click_all_money/$tui_click_num;
        }
        if($tui_click_pay_price > 0 && $tui_click_all_money > 0 && $tui_click_click_money >= 0.01){
            $tuiPayStatus = 1;
            $tuiPayPrice = $tui_click_pay_price;
        }
    }
    
    ## tcmajia start
    $openMajiaStatus = 0;
    if($__ShowTcmajia == 1 && $userInfo['editor']==1){
        if($tcmajiaConfig['use_majia_admin_1'] == $userInfo['id']){
            $openMajiaStatus = 1;
        }
        if($tcmajiaConfig['use_majia_admin_2'] == $userInfo['id']){
            $openMajiaStatus = 1;
        }
        if($tcmajiaConfig['use_majia_admin_3'] == $userInfo['id']){
            $openMajiaStatus = 1;
        }
        if($tcmajiaConfig['use_majia_admin_4'] == $userInfo['id']){
            $openMajiaStatus = 1;
        }
        if($tcmajiaConfig['use_majia_admin_5'] == $userInfo['id']){
            $openMajiaStatus = 1;
        }
    }

    if($open_majia == 1){
        $tcmajiaCount = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_count(" AND is_majia = 1 ");
        if($openMajiaStatus == 1 && $tcmajiaCount > 0){
            $num = $tcmajiaCount - 1;
            if($num == 0){
                $tcmajiaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_list(' AND is_majia = 1 ', 'ORDER BY id DESC', 0, 1);
            }else{
                $randomNum = mt_rand(0, $num);
                $tcmajiaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_list(' AND is_majia = 1 ', 'ORDER BY id DESC', $randomNum, 1);
            }

            if(is_array($tcmajiaInfoTmp) && !empty($tcmajiaInfoTmp[0])){
                $tcshop_id = 0;
                $xm = $tcmajiaInfoTmp[0]['nickname'];
                $user_id = $tcmajiaInfoTmp[0]['id'];
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
            
        }else{
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
        
    }
    ## tcmajia end

    $insertData = array();
    $insertData['site_id']      = $site_id;
    $insertData['user_id']      = $user_id;
    $insertData['model_id']     = $model_id;
    $insertData['type_id']      = $type_id;
    $insertData['cate_id']      = $cate_id;
    $insertData['city_id']      = $city_id;
    $insertData['area_id']      = $area_id;
    $insertData['street_id']    = $street_id;
    $insertData['tcshop_id']    = $tcshop_id;
    $insertData['tcqianggou_goods_id']  = $tcqianggou_goods_id;
    $insertData['tcptuan_goods_id']     = $tcptuan_goods_id;
    $insertData['tcqianggou_coupon_id'] = $tcqianggou_coupon_id;
    $insertData['tcmall_goods_id']      = $tcmall_goods_id;
    $insertData['tcdaojia_goods_id']    = $tcdaojia_goods_id;
    $insertData['title']        = $title;
    $insertData['xm']           = $xm;
    $insertData['tel']          = $tel;
    $insertData['wx']           = $wx;
    $insertData['video_url']    = $video_url;
    $insertData['video_pic']    = $video_pic;
    $insertData['content']      = $content.'|+|+|+|+|+|+|+|+|+|'.$search_content.'-'.$xm.'-'.$tel.'-'.$title.'-'.$cateInfo['name'];
    if($typeInfo['open_dingwei'] == 1){
        $insertData['is_dingwei']       = 1;
        $insertData['latitude']         = $lat;
        $insertData['longitude']        = $lng;
        $insertData['address']          = $address;
    }
    $insertData['refresh_time'] = TIMESTAMP;
    $insertData['add_time']     = TIMESTAMP;
    if($fabuPayStatus == 1){
        $insertData['status']       = 2;
        $insertData['pay_status']   = 1;
    }else{
        $insertData['status']       = 1;
        $insertData['pay_status']   = 0;
    }
    if($fabuPayStatus == 2){
        $insertData['score_pay']    = 1;
    }
    if($modelInfo['must_shenhe'] == 1 && $userInfo['editor']==0){
        $insertData['shenhe_status']       = 2;
    }else if($safe_words_shenhe == 1){
        $insertData['shenhe_status']       = 2;
    }else{
        $insertData['shenhe_status']       = 1;
    }
    if($typeInfo['jifei_type'] == 2){
        $insertData['over_days']     = $over_days;
        if($fabuPayStatus == 1){}else{
            $insertData['over_time'] = TIMESTAMP + $over_days*86400;
            if($song_top_days > 0){
                $insertData['topstatus']    = 1;
                $insertData['toptime']      = TIMESTAMP + $song_top_days*86400;
            }
        }
    }
    if($fabuPayStatus == 1 || $topPayStatus == 1 || $tuiPayStatus == 1){
    }else{
        if($top_days > 0){
            $insertData['topstatus']    = 1;
            $insertData['toptime']      = TIMESTAMP + ($top_days + $song_top_days)*86400;
        }
    }
    $insertData['client_ip_port']    = $_G['clientip'].'|'.$_SERVER['REMOTE_PORT'];
    if(C::t('#tom_tongcheng#tom_tongcheng')->insert($insertData)){
        
        $tongchengId = C::t('#tom_tongcheng#tom_tongcheng')->insert_id();
        
        if($fabuPayStatus == 2 || $topPayStatus == 2){
            
            $updateData = array();
            $updateData['score'] = $userInfo['score'] - ($useScore + $useTopScore);
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
            
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['score_value']      = $useScore + $useTopScore;
            $insertData['old_value']        = $userInfo['score'];
            $insertData['log_type']         = 4;
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        }
        
        if($fabuPayStatus == 3){
            $insertData = array();
            $insertData['user_id']      = $userInfo['id'];
            $insertData['tongcheng_id'] = $tongchengId;
            $insertData['time_key']     = $nowDayTime;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_fabu_log')->insert($insertData);
        }
        
        if($isVipFabu == 1){
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['time_key']         = $nowDayTime;
            $insertData['add_time']         = TIMESTAMP;
            C::t('#tom_tcyikatong#tom_tcyikatong_fabu_log')->insert($insertData);
        }
        
        if($isShopFabu == 1){
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['time_key']         = $nowDayTime;
            $insertData['add_time']         = TIMESTAMP;
            C::t('#tom_tcshop#tom_tcshop_fabu_log')->insert($insertData);
        }
        
        if(is_array($attrArr) && !empty($attrArr)){
            foreach ($attrArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $model_id;
                $insertData['type_id']      = $type_id;
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['attr_id']      = $key;
                $insertData['attr_name']    = $attrnameArr[$key];
                $insertData['value']        = $value;
                $insertData['unit']         = $attrunitArr[$key];
                $insertData['paixu']        = $attrpaixuArr[$key];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
        
        if(is_array($attrdateArr) && !empty($attrdateArr)){
            foreach ($attrdateArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $model_id;
                $insertData['type_id']      = $type_id;
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['attr_id']      = $key;
                $insertData['attr_name']    = $attrnameArr[$key];
                $insertData['value']        = $value;
                $insertData['time_value']   = strtotime($value);
                $insertData['unit']         = $attrunitArr[$key];
                $insertData['paixu']        = $attrpaixuArr[$key];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
        
        if(is_array($tagArr) && !empty($tagArr)){
            foreach ($tagArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $model_id;
                $insertData['type_id']      = $type_id;
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['tag_id']       = $value;
                $insertData['tag_name']     = $tagnameArr[$value];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_tag')->insert($insertData);
            }
        }
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['picurl'] = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_photo')->insert($insertData);
            }
        }
        
        if($modelInfo['type'] == 2 && !empty($typeInfo['sfc_chufa_attr_id']) && !empty($typeInfo['sfc_mude_attr_id'])  && !empty($typeInfo['sfc_time_attr_id']) && !empty($typeInfo['sfc_renshu_attr_id'])){
            $sfcChufaAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND attr_id = {$typeInfo['sfc_chufa_attr_id']} AND tongcheng_id = {$tongchengId}", 'ORDER BY id DESC', 0, 1);
            $sfcMudeAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND attr_id = {$typeInfo['sfc_mude_attr_id']} AND tongcheng_id = {$tongchengId}", 'ORDER BY id DESC', 0, 1);
            $sfcTimeAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND attr_id = {$typeInfo['sfc_time_attr_id']} AND tongcheng_id = {$tongchengId}", 'ORDER BY id DESC', 0, 1);
            $sfcRenshuAttrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND attr_id = {$typeInfo['sfc_renshu_attr_id']} AND tongcheng_id = {$tongchengId}", 'ORDER BY id DESC', 0, 1);
            
            $insertData = array();
            $insertData['site_id']      = $site_id;
            $insertData['tongcheng_id'] = $tongchengId;
            $insertData['model_id']     = $model_id;
            $insertData['type_id']      = $type_id;
            $insertData['chufa']        = $sfcChufaAttrInfoTmp[0]['value'];
            $insertData['mude']         = $sfcMudeAttrInfoTmp[0]['value'];
            $insertData['chufa_time']   = $sfcTimeAttrInfoTmp[0]['value'];
            $insertData['chufa_int_time'] = $sfcTimeAttrInfoTmp[0]['time_value'];
            $insertData['renshu_type']  = $typeInfo['sfc_renshu_type'];
            $insertData['renshu']       = $sfcRenshuAttrInfoTmp[0]['value'];
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_sfc_cache')->insert($insertData);
        }
        
        ## pay start
        if($fabuPayStatus == 1 || $topPayStatus == 1 || $tuiPayStatus == 1){
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'status'=> 307,
                );
                echo json_encode($outArr); exit;
            }
            
            $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
            
            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['order_no']         = $order_no;
            $insertData['order_type']       = 1;
            $insertData['user_id']          = $user_id;
            $insertData['openid']           = $userInfo['openid'];
            $insertData['tongcheng_id']     = $tongchengId;
            $insertData['pay_price']        = $fabuPayPrice + $topPayPrice + $tuiPayPrice;
            $insertData['order_status']     = 1;
            $insertData['top_days']         = $top_days + $song_top_days;
            $insertData['tui_click_num']    = $tui_click_num;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tongcheng#tom_tongcheng_order')->insert($insertData)){
                $order_id = C::t('#tom_tongcheng#tom_tongcheng_order')->insert_id();

                $insertData = array();
                $insertData['plugin_id']       = 'tom_tongcheng';
                $insertData['order_no']        = $order_no;            
                $insertData['goods_id']        = $tongchengId;           
                $insertData['goods_name']      = lang('plugin/tom_tongcheng','order_type_1');
                $insertData['goods_beizu']     = lang('plugin/tom_tongcheng','order_type_1');
                $insertData['goods_url']       = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=info&tongcheng_id={$tongchengId}";
                $insertData['succ_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=fabu&act=succ&tongcheng_id={$tongchengId}";
                $insertData['fail_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist";
                $insertData['allow_alipay']    = 1;         
                $insertData['pay_price']       = $fabuPayPrice + $topPayPrice + $tuiPayPrice;  
                $insertData['order_status']    = 1;             
                $insertData['add_time']        = TIMESTAMP;     
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    $outArr = array(
                        'tongcheng_id'  => $tongchengId,
                        'status'        => 200,
                        'pay_status'    => 1,
                        'payurl'        => "plugin.php?id=tom_pay&order_no=".$order_no,
                    );
                    echo json_encode($outArr); exit;
                    
                }else{
                    $outArr = array(
                        'status'=> 303,
                    );
                    echo json_encode($outArr); exit;
                }

            }else{
                $outArr = array(
                    'status'=> 304,
                );
                echo json_encode($outArr); exit;
            }

        }
        ## pay end
        
        if(!empty($tongchengConfig['fabu_xx_tz'])){
            $contentTz = contentFormat($content);
            $contentTz = strip_tags($contentTz);
            $contentTz = str_replace("\r\n","",$contentTz);
            $contentTz = str_replace("\n","",$contentTz);
            $contentTz = str_replace("\r","",$contentTz);
            $contentTz = cutstr($contentTz,30,"...");
            $insertData = array();
            $insertData['user_id']      = $user_id;
            $insertData['type']         = 1;
            $insertData['content']      = str_replace("{CONTENT}",$contentTz,$tongchengConfig['fabu_xx_tz']);
            $insertData['is_read']      = 0;
            $insertData['tz_time']      = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        }
        
        $outArr = array(
            'status'        => 200,
            'tongcheng_id'  => $tongchengId,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    
}else if($act == "xufei" && $_GET['formhash'] == FORMHASH && $userStatus == true){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $tongcheng_id   = isset($_GET['tongcheng_id'])? intval($_GET['tongcheng_id']):0;
    $over_days      = isset($_GET['over_days'])? intval($_GET['over_days']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengInfo['user_id']);
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
    
    if($__UserInfo['id'] != $userInfo['id']){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $sites_priceTmp = C::t('#tom_tongcheng#tom_tongcheng_sites_price')->fetch_all_list(" AND site_id={$site_id} AND type_id={$tongchengInfo['type_id']} "," ORDER BY id DESC ",0,1);
    if(is_array($sites_priceTmp) && !empty($sites_priceTmp) && $sites_priceTmp[0]['id']>0){
         $typeInfo['free_status'] = $sites_priceTmp[0]['free_status'];
         $typeInfo['fabu_price'] = $sites_priceTmp[0]['fabu_price'];
         $typeInfo['fabu_price_str']  = $sites_priceTmp[0]['fabu_price_str'];
    }
    
    $over_days_item = array();
    if(!empty($typeInfo['fabu_price_str'])){
        $fabu_price_str = str_replace("\r\n","{n}",$typeInfo['fabu_price_str']); 
        $fabu_price_str = str_replace("\n","{n}",$fabu_price_str);
        $fabu_price_list = explode("{n}", $fabu_price_str);
        if(is_array($fabu_price_list) && !empty($fabu_price_list)){
            foreach ($fabu_price_list as $key => $value){
                $fabu_price_list_item = explode("|", $value);
                $fabu_price_list_item_days = intval($fabu_price_list_item[0]);
                $fabu_price_list_item_price = floatval($fabu_price_list_item[1]);
                $fabu_price_list_item_msg = trim($fabu_price_list_item[2]);
                if($fabu_price_list_item_days > 0 && $fabu_price_list_item_price > 0){
                    $over_days_item[$fabu_price_list_item_days]['days'] = $fabu_price_list_item_days;
                    $over_days_item[$fabu_price_list_item_days]['price'] = $fabu_price_list_item_price;
                    $over_days_item[$fabu_price_list_item_days]['msg'] = $fabu_price_list_item_msg;
                }
            }
        }
    }
    
    if($typeInfo['jifei_type'] == 2){
        if(isset($over_days_item[$over_days]) && $over_days_item[$over_days]['price'] > 0){
            $typeInfo['fabu_price'] = $over_days_item[$over_days]['price'];
            $top_days = 0;
            if(strpos($over_days_item[$over_days]['msg'], 'TOP') !== false){
                $topStr = str_replace('TOP', '', $over_days_item[$over_days]['msg']);
                if(intval($topStr) > 0){
                    $top_days = intval($topStr);
                }
            }
        }else{
            $outArr = array(
                'status'=> 502,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $shop_free_fenlei_times = 0;
    if($__ShowTcshop == 1){
        $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$userInfo['id']} AND v.fenlei_times > 0 "," ORDER BY s.id DESC ",0,100);
        if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
            foreach ($tcshopListTmp as $key => $value){
                $shop_free_fenlei_times = $shop_free_fenlei_times + $value['vip_fenlei_times'];
            }
        }
    }
    
    $fabuPayStatus = 0;
    $isVipFabu = 0;
    $isShopFabu = 0;
    if($typeInfo['free_status'] == 2 && $typeInfo['fabu_price'] > 0 && $userInfo['editor']==0){
        $fabuPayStatus = 1;
        ## VIP start
        if($__ShowTcyikatong == 1 && $tcyikatongConfig['open_fenlei_tequan'] == 1 && $tcyikatongConfig['fenlei_tequan_type'] == 1){
            $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($userInfo['id']);
            if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
                $typeInfo['fabu_price'] = $typeInfo['fabu_price']/2;
            }
        }
        if($__ShowTcyikatong == 1 && $tcyikatongConfig['open_fenlei_tequan'] == 1 && $tcyikatongConfig['fenlei_tequan_type'] == 2){
            $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($userInfo['id']);
            if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
                $vip_fabu_log_count = C::t('#tom_tcyikatong#tom_tcyikatong_fabu_log')->fetch_all_count(" AND user_id={$userInfo['id']} AND time_key={$nowDayTime} ");
                if($vip_fabu_log_count < $tcyikatongConfig['fenlei_tequan_times']){
                    $isVipFabu     = 1;
                    $fabuPayStatus = 0;
                }
            }
        }
        ## VIP end
        
        if($__ShowTcshop == 1 && $shop_free_fenlei_times > 0 && $fabuPayStatus == 1){
            $shop_fabu_log_count = C::t('#tom_tcshop#tom_tcshop_fabu_log')->fetch_all_count(" AND user_id={$userInfo['id']} AND time_key={$nowDayTime} ");
            if($shop_fabu_log_count < $shop_free_fenlei_times){
                $fabuPayStatus      = 0;
                $isShopFabu         = 1;
            }
        }
        
        if($tongchengConfig['free_fabu_times'] > 0  && $fabuPayStatus == 1 && $typeInfo['jifei_type'] == 1){
            $fabu_log_count = C::t('#tom_tongcheng#tom_tongcheng_fabu_log')->fetch_all_count(" AND user_id={$userInfo['id']} AND time_key={$nowDayTime} ");
            if($tongchengSetting['open_all_free_fabu_times'] == 1 && $tongchengSetting['all_free_fabu_times'] > 0){
                if($tongchengSetting['free_fabu_times_days'] > 0){
                    $free_fabu_times_days_time = TIMESTAMP - $tongchengSetting['free_fabu_times_days']*86400;
                    $all_fabu_log_count = C::t('#tom_tongcheng#tom_tongcheng_fabu_log')->fetch_all_count(" AND user_id={$userInfo['id']} AND add_time > {$free_fabu_times_days_time} ");
                }else{
                    $all_fabu_log_count = C::t('#tom_tongcheng#tom_tongcheng_fabu_log')->fetch_all_count(" AND user_id={$userInfo['id']} ");
                }
                if($tongchengSetting['all_free_fabu_times'] <= $all_fabu_log_count){
                    $tongchengConfig['free_fabu_times'] = 0;
                }
            }
            if($tongchengConfig['free_fabu_times'] > $fabu_log_count){
                $fabuPayStatus = 3;
            }
        }
        if($tongchengConfig['pay_score_yuan'] > 0 && $fabuPayStatus == 1 && $tongchengConfig['open_fabu_score_pay'] == 1){
            $useScore = $tongchengConfig['pay_score_yuan']*$typeInfo['fabu_price'];
            $useScore = ceil($useScore);
            if($userInfo['score'] >= $useScore){
                $fabuPayStatus = 2;
            }
        }
    }

    $updateData = array();
    if($fabuPayStatus == 1){
        $updateData['status']       = 2;
        $updateData['pay_status']   = 1;
    }else{
        $updateData['status']       = 1;
        $updateData['pay_status']   = 0;
        $updateData['finish']       = 0;
        $updateData['refresh_time'] = TIMESTAMP;
    }
    if($fabuPayStatus == 2){
        $updateData['score_pay']    = 1;
    }
    if($typeInfo['jifei_type'] == 2){
        $updateData['over_days']     = $over_days;
        if($fabuPayStatus == 1){
        }else{
            if($tongchengInfo['over_time'] > TIMESTAMP){
                $updateData['over_time'] = $tongchengInfo['over_time'] + $over_days*86400;
            }else{
                $updateData['over_time'] = TIMESTAMP + $over_days*86400;
            }
            if($top_days > 0){
                $updateData['topstatus']    = 1;
                if($tongchengInfo['toptime'] > TIMESTAMP){
                    $updateData['toptime']      = $tongchengInfo['toptime'] + $top_days*86400;
                }else{
                    $updateData['toptime']      = TIMESTAMP + $top_days*86400;
                }
            }
        }
    }
    if(C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id,$updateData)){
        
        if($fabuPayStatus == 2){
            
            $updateData = array();
            $updateData['score'] = $userInfo['score'] - $useScore;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
            
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['score_value']      = $useScore;
            $insertData['old_value']        = $userInfo['score'];
            $insertData['log_type']         = 4;
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        }
        
        if($fabuPayStatus == 3){
            $insertData = array();
            $insertData['user_id']      = $userInfo['id'];
            $insertData['tongcheng_id'] = $tongcheng_id;
            $insertData['time_key']     = $nowDayTime;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_fabu_log')->insert($insertData);
        }
        
        if($isVipFabu == 1){
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['time_key']         = $nowDayTime;
            $insertData['add_time']         = TIMESTAMP;
            C::t('#tom_tcyikatong#tom_tcyikatong_fabu_log')->insert($insertData);
        }
        
        if($isShopFabu == 1){
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['time_key']         = $nowDayTime;
            $insertData['add_time']         = TIMESTAMP;
            C::t('#tom_tcshop#tom_tcshop_fabu_log')->insert($insertData);
        }
        
        ## pay start
        if($fabuPayStatus == 1){
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'status'=> 307,
                );
                echo json_encode($outArr); exit;
            }
            
            $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
            
            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['order_no']         = $order_no;
            $insertData['order_type']       = 11;
            $insertData['user_id']          = $userInfo['id'];
            $insertData['openid']           = $userInfo['openid'];
            $insertData['tongcheng_id']     = $tongcheng_id;
            $insertData['pay_price']        = $typeInfo['fabu_price'];
            $insertData['time_value']       = $top_days;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tongcheng#tom_tongcheng_order')->insert($insertData)){
                $order_id = C::t('#tom_tongcheng#tom_tongcheng_order')->insert_id();

                $insertData = array();
                $insertData['plugin_id']       = 'tom_tongcheng';
                $insertData['order_no']        = $order_no;            
                $insertData['goods_id']        = $tongcheng_id;           
                $insertData['goods_name']      = lang('plugin/tom_tongcheng','order_type_11');
                $insertData['goods_beizu']     = lang('plugin/tom_tongcheng','order_type_11');
                $insertData['goods_url']       = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=info&tongcheng_id={$tongcheng_id}";
                $insertData['succ_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist";
                $insertData['fail_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist";
                $insertData['allow_alipay']    = 1;         
                $insertData['pay_price']       = $typeInfo['fabu_price'];    
                $insertData['order_status']    = 1;             
                $insertData['add_time']        = TIMESTAMP;     
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    $outArr = array(
                        'status' => 200,
                        'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                    );
                    echo json_encode($outArr); exit;
                    
                }else{
                    $outArr = array(
                        'status'=> 303,
                    );
                    echo json_encode($outArr); exit;
                }

            }else{
                $outArr = array(
                    'status'=> 304,
                );
                echo json_encode($outArr); exit;
            }

        }
        ## pay end
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    
}else if($act == "pay" && $_GET['formhash'] == FORMHASH){
    
    $tongcheng_id   = isset($_GET['tongcheng_id'])? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengInfo['user_id']); 
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
    $modelInfo = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($typeInfo['model_id']);
    
    $sites_priceTmp = C::t('#tom_tongcheng#tom_tongcheng_sites_price')->fetch_all_list(" AND site_id={$tongchengInfo['site_id']} AND type_id={$tongchengInfo['type_id']} "," ORDER BY id DESC ",0,1);
    if(is_array($sites_priceTmp) && !empty($sites_priceTmp) && $sites_priceTmp[0]['id']>0){
         $typeInfo['free_status'] = $sites_priceTmp[0]['free_status'];
         $typeInfo['fabu_price'] = $sites_priceTmp[0]['fabu_price'];
         $typeInfo['fabu_price_str']  = $sites_priceTmp[0]['fabu_price_str'];
    }
    
    $over_days_item = array();
    if(!empty($typeInfo['fabu_price_str'])){
        $fabu_price_str = str_replace("\r\n","{n}",$typeInfo['fabu_price_str']); 
        $fabu_price_str = str_replace("\n","{n}",$fabu_price_str);
        $fabu_price_list = explode("{n}", $fabu_price_str);
        if(is_array($fabu_price_list) && !empty($fabu_price_list)){
            foreach ($fabu_price_list as $key => $value){
                $fabu_price_list_item = explode("|", $value);
                $fabu_price_list_item_days = intval($fabu_price_list_item[0]);
                $fabu_price_list_item_price = floatval($fabu_price_list_item[1]);
                $fabu_price_list_item_msg = $fabu_price_list_item[2];
                if($fabu_price_list_item_days > 0 && $fabu_price_list_item_price > 0){
                    $over_days_item[$fabu_price_list_item_days]['days'] = $fabu_price_list_item_days;
                    $over_days_item[$fabu_price_list_item_days]['price'] = $fabu_price_list_item_price;
                    $over_days_item[$fabu_price_list_item_days]['msg'] = $fabu_price_list_item_msg;
                }
            }
        }
    }
    if($typeInfo['jifei_type'] == 2 && $tongchengInfo['over_days'] > 0){
        if(isset($over_days_item[$tongchengInfo['over_days']]) && $over_days_item[$tongchengInfo['over_days']]['price'] > 0){
            $typeInfo['fabu_price'] = $over_days_item[$tongchengInfo['over_days']]['price'];
            $top_days = 0;
            if(strpos($over_days_item[$over_days]['msg'], 'TOP') !== false){
                $topStr = str_replace('TOP', '', $over_days_item[$over_days]['msg']);
                if(intval($topStr) > 0){
                    $top_days = intval($topStr);
                }
            }
        }
    }
    ## VIP start
    if($__ShowTcyikatong == 1 && $tcyikatongConfig['open_fenlei_tequan'] == 1 && $tcyikatongConfig['fenlei_tequan_type'] == 1){
        $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($userInfo['id']);
        if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
            $typeInfo['fabu_price'] = $typeInfo['fabu_price']/2;
        }
    }
    ## VIP end
    
    $orderListTmp = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_list(" AND tongcheng_id={$tongcheng_id} AND user_id={$userInfo['id']} AND order_type=1 AND order_status=1 ","ORDER BY id DESC",0,10);
    if(is_array($orderListTmp) && !empty($orderListTmp)){
        foreach ($orderListTmp as $key => $value){
            $updateData = array();
            $updateData['order_status'] = 3;
            C::t('#tom_tongcheng#tom_tongcheng_order')->update($value['id'],$updateData);
        }
    }
    
    if($typeInfo['free_status'] == 2 && $typeInfo['fabu_price'] > 0){
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $tongchengInfo['site_id'];
        $insertData['order_no']         = $order_no;
        $insertData['order_type']       = 1;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['tongcheng_id']     = $tongcheng_id;
        $insertData['pay_price']        = $typeInfo['fabu_price'];
        $insertData['time_value']       = $top_days;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tongcheng#tom_tongcheng_order')->insert($insertData)){
            $order_id = C::t('#tom_tongcheng#tom_tongcheng_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tongcheng';
            $insertData['order_no']        = $order_no;            
            $insertData['goods_id']        = $tongcheng_id;           
            $insertData['goods_name']      = lang('plugin/tom_tongcheng','order_type_1');
            $insertData['goods_beizu']     = lang('plugin/tom_tongcheng','order_type_1');
            $insertData['goods_url']       = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=info&tongcheng_id={$tongcheng_id}";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist";
            $insertData['fail_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist";
            $insertData['allow_alipay']    = 1;         
            $insertData['pay_price']       = $typeInfo['fabu_price'];    
            $insertData['order_status']    = 1;             
            $insertData['add_time']        = TIMESTAMP;     
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'=> 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;

            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 400,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "refresh" && $_GET['formhash'] == FORMHASH){
    
    $tongcheng_id   = isset($_GET['tongcheng_id'])? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengInfo['user_id']); 
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
    
    $sites_priceTmp = C::t('#tom_tongcheng#tom_tongcheng_sites_price')->fetch_all_list(" AND site_id={$tongchengInfo['site_id']} AND type_id={$tongchengInfo['type_id']} "," ORDER BY id DESC ",0,1);
    if(is_array($sites_priceTmp) && !empty($sites_priceTmp) && $sites_priceTmp[0]['id']>0){
        $typeInfo['refresh_price'] = $sites_priceTmp[0]['refresh_price'];
    }
    
    $orderListTmp = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_list(" AND tongcheng_id={$tongcheng_id} AND user_id={$userInfo['id']} AND order_type=2 AND order_status=1 ","ORDER BY id DESC",0,10);
    if(is_array($orderListTmp) && !empty($orderListTmp)){
        foreach ($orderListTmp as $key => $value){
            $updateData = array();
            $updateData['order_status'] = 3;
            C::t('#tom_tongcheng#tom_tongcheng_order')->update($value['id'],$updateData);
        }
    }
    
    if($typeInfo['refresh_price'] > 0){
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $tongchengInfo['site_id'];
        $insertData['order_no']         = $order_no;
        $insertData['order_type']       = 2;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['tongcheng_id']     = $tongcheng_id;
        $insertData['pay_price']        = $typeInfo['refresh_price'];
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tongcheng#tom_tongcheng_order')->insert($insertData)){
            $order_id = C::t('#tom_tongcheng#tom_tongcheng_order')->insert_id();
            
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tongcheng';
            $insertData['order_no']        = $order_no;            
            $insertData['goods_id']        = $tongcheng_id;           
            $insertData['goods_name']      = lang('plugin/tom_tongcheng','order_type_2');
            $insertData['goods_beizu']     = lang('plugin/tom_tongcheng','order_type_2');
            $insertData['goods_url']       = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=info&tongcheng_id={$tongcheng_id}";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist";
            $insertData['fail_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist";
            $insertData['allow_alipay']    = 1;         
            $insertData['pay_price']       = $typeInfo['refresh_price'];    
            $insertData['order_status']    = 1;             
            $insertData['add_time']        = TIMESTAMP;     
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'=> 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 400,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "top" && $_GET['formhash'] == FORMHASH){
    
    $tongcheng_id   = isset($_GET['tongcheng_id'])? intval($_GET['tongcheng_id']):0;
    $days   = intval($_GET['days'])>0? intval($_GET['days']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengInfo['user_id']); 
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
    
    $sites_priceTmp = C::t('#tom_tongcheng#tom_tongcheng_sites_price')->fetch_all_list(" AND site_id={$tongchengInfo['site_id']} AND type_id={$tongchengInfo['type_id']} "," ORDER BY id DESC ",0,1);
    if(is_array($sites_priceTmp) && !empty($sites_priceTmp) && $sites_priceTmp[0]['id']>0){
        $typeInfo['top_price'] = $sites_priceTmp[0]['top_price'];
        $typeInfo['top_price_str']  = $sites_priceTmp[0]['top_price_str'];
    }
    
    $buy_item = array();
    if(!empty($typeInfo['top_price_str'])){
        $top_price_str = str_replace("\r\n","{n}",$typeInfo['top_price_str']); 
        $top_price_str = str_replace("\n","{n}",$top_price_str);
        $top_price_list = explode("{n}", $top_price_str);
        if(is_array($top_price_list) && !empty($top_price_list)){
            foreach ($top_price_list as $key => $value){
                $top_price_list_item = explode("|", $value);
                $top_price_list_item_days = intval($top_price_list_item[0]);
                $top_price_list_item_price = floatval($top_price_list_item[1]);
                if($top_price_list_item_days > 0 && $top_price_list_item_price > 0){
                    $buy_item[$top_price_list_item_days] = $top_price_list_item_price;
                }
            }
        }
    }
    if(empty($buy_item)){
        $buy_item_days = array(1,3,5,7,15,30);
        if($typeInfo['top_price'] == 0.00){
            $typeInfo['top_price'] = 1;
        }
        foreach ($buy_item_days as $key => $value){
            $buy_item[$value] = $typeInfo['top_price']*$value;
        }
    }
    
    $orderListTmp = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_list(" AND tongcheng_id={$tongcheng_id} AND user_id={$userInfo['id']} AND order_type=3 AND order_status=1 ","ORDER BY id DESC",0,10);
    if(is_array($orderListTmp) && !empty($orderListTmp)){
        foreach ($orderListTmp as $key => $value){
            $updateData = array();
            $updateData['order_status'] = 3;
            C::t('#tom_tongcheng#tom_tongcheng_order')->update($value['id'],$updateData);
        }
    }
    
    if($days > 0 && isset($buy_item[$days]) && !empty($buy_item[$days])){
    }else{
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($buy_item[$days] > 0){
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit;
        }
        
        $useScore = $tongchengConfig['pay_score_yuan']*$buy_item[$days];
        $useScore = ceil($useScore);
        if($userInfo['score'] >= $useScore && $tongchengConfig['open_top_score_pay'] == 1){
            
            $toptime = TIMESTAMP;
            if($tongchengInfo['toptime'] > TIMESTAMP){
                $toptime = $tongchengInfo['toptime'] + $days*86400;
            }else{
                $toptime = TIMESTAMP + $days*86400;
            }
            $updateData = array();
            $updateData['topstatus'] = 1;
            $updateData['toprand'] = 10000;
            $updateData['toptime'] = $toptime;
            $updateData['refresh_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng')->update($tongchengInfo['id'],$updateData);
            
            $updateData = array();
            $updateData['score'] = $userInfo['score'] - $useScore;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
            
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['score_value']      = $useScore;
            $insertData['old_value']        = $userInfo['score'];
            $insertData['log_type']         = 18;
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
            
            $outArr = array(
                'status'=> 201,
                'succurl' => "plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist"
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $tongchengInfo['site_id'];
        $insertData['order_no']         = $order_no;
        $insertData['order_type']       = 3;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['tongcheng_id']     = $tongcheng_id;
        $insertData['pay_price']        = $buy_item[$days];
        $insertData['time_value']       = $days;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tongcheng#tom_tongcheng_order')->insert($insertData)){
            $order_id = C::t('#tom_tongcheng#tom_tongcheng_order')->insert_id();
            
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tongcheng';
            $insertData['order_no']        = $order_no;            
            $insertData['goods_id']        = $tongcheng_id;           
            $insertData['goods_name']      = lang('plugin/tom_tongcheng','order_type_3');
            $insertData['goods_beizu']     = lang('plugin/tom_tongcheng','order_type_3');
            $insertData['goods_url']       = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=info&tongcheng_id={$tongcheng_id}";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist";
            if($_GET['from'] == 'fabu'){
                $insertData['fail_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=fabu&act=succ&tongcheng_id={$tongcheng_id}";
            }else{
                $insertData['fail_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=buy&tongcheng_id={$tongcheng_id}";
            }
            $insertData['allow_alipay']    = 1;         
            $insertData['pay_price']       = $buy_item[$days];    
            $insertData['order_status']    = 1;             
            $insertData['add_time']        = TIMESTAMP;     
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'=> 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 400,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "tel" && $_GET['formhash'] == FORMHASH && $userStatus == true){
    
    $tongcheng_id   = isset($_GET['tongcheng_id'])? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($__UserInfo['id']); 
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
    
    $sites_priceTmp = C::t('#tom_tongcheng#tom_tongcheng_sites_price')->fetch_all_list(" AND site_id={$tongchengInfo['site_id']} AND type_id={$tongchengInfo['type_id']} "," ORDER BY id DESC ",0,1);
    if(is_array($sites_priceTmp) && !empty($sites_priceTmp) && $sites_priceTmp[0]['id']>0){
        $typeInfo['tel_price'] = $sites_priceTmp[0]['tel_price'];
    }
    
    $orderListTmp = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_list(" AND tongcheng_id={$tongcheng_id} AND user_id={$userInfo['id']} AND order_type=9 AND order_status=1 ","ORDER BY id DESC",0,10);
    if(is_array($orderListTmp) && !empty($orderListTmp)){
        foreach ($orderListTmp as $key => $value){
            $updateData = array();
            $updateData['order_status'] = 3;
            C::t('#tom_tongcheng#tom_tongcheng_order')->update($value['id'],$updateData);
        }
    }
    
    if($typeInfo['tel_price'] > 0){
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $tongchengInfo['site_id'];
        $insertData['order_no']         = $order_no;
        $insertData['order_type']       = 9;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['tongcheng_id']     = $tongcheng_id;
        $insertData['pay_price']        = $typeInfo['tel_price'];
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tongcheng#tom_tongcheng_order')->insert($insertData)){
            $order_id = C::t('#tom_tongcheng#tom_tongcheng_order')->insert_id();
            
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tongcheng';
            $insertData['order_no']        = $order_no;            
            $insertData['goods_id']        = $tongcheng_id;           
            $insertData['goods_name']      = lang('plugin/tom_tongcheng','order_type_9');
            $insertData['goods_beizu']     = lang('plugin/tom_tongcheng','order_type_9');
            $insertData['goods_url']       = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=view&xxid={$tongcheng_id}";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=view&xxid={$tongcheng_id}";
            $insertData['fail_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=view&xxid={$tongcheng_id}";
            $insertData['allow_alipay']    = 1;         
            $insertData['pay_price']       = $typeInfo['tel_price'];    
            $insertData['order_status']    = 1;             
            $insertData['add_time']        = TIMESTAMP;     
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'=> 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 400,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "recharge_score" && $_GET['formhash'] == FORMHASH && $userStatus == true){
    
    $tcsignConfig = $_G['cache']['plugin']['tom_tcsign'];
    
    $score       = isset($_GET['score'])? intval($_GET['score']):0;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($__UserInfo['id']); 
    
    $recharge_score = array();
    if(!empty($tcsignConfig['recharge_score'])){
        $recharge_score_str = str_replace("\r\n","{n}",$tcsignConfig['recharge_score']); 
        $recharge_score_str = str_replace("\n","{n}",$recharge_score_str);
        $recharge_score_list = explode("{n}", $recharge_score_str);
        if(is_array($recharge_score_list) && !empty($recharge_score_list)){
            foreach ($recharge_score_list as $key => $value){
                $recharge_score_list_item = explode("|", $value);
                $recharge_score_list_item_score = intval($recharge_score_list_item[0]);
                $recharge_score_list_item_money = floatval($recharge_score_list_item[1]);
                $recharge_score_list_item_song = intval($recharge_score_list_item[2]);
                if($recharge_score_list_item_score > 0 && $recharge_score_list_item_money > 0){
                    $recharge_score[$recharge_score_list_item_score]['score'] = $recharge_score_list_item_score;
                    $recharge_score[$recharge_score_list_item_score]['money'] = $recharge_score_list_item_money;
                    $recharge_score[$recharge_score_list_item_score]['song'] = $recharge_score_list_item_song;
                }
            }
        }
    }
    
    $orderListTmp = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_list(" AND user_id={$userInfo['id']} AND order_type=10 AND order_status=1 ","ORDER BY id DESC",0,10);
    if(is_array($orderListTmp) && !empty($orderListTmp)){
        foreach ($orderListTmp as $key => $value){
            $updateData = array();
            $updateData['order_status'] = 3;
            C::t('#tom_tongcheng#tom_tongcheng_order')->update($value['id'],$updateData);
        }
    }
    
    if(isset($recharge_score[$score]) && $recharge_score[$score]['money'] > 0){
        
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['order_no']         = $order_no;
        $insertData['order_type']       = 10;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['score_value']      = $score + $recharge_score[$score]['song'];
        $insertData['pay_price']        = $recharge_score[$score]['money'];
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tongcheng#tom_tongcheng_order')->insert($insertData)){
            $order_id = C::t('#tom_tongcheng#tom_tongcheng_order')->insert_id();
            
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tongcheng';
            $insertData['order_no']        = $order_no;            
            $insertData['goods_id']        = 0;           
            $insertData['goods_name']      = lang('plugin/tom_tongcheng','order_type_10');
            $insertData['goods_beizu']     = lang('plugin/tom_tongcheng','order_type_10');
            $insertData['goods_url']       = "plugin.php?id=tom_tcsign&site={$site_id}&mod=recharge";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tcsign&site={$site_id}&mod=scorelog";
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcsign&site={$site_id}&mod=recharge";
            $insertData['allow_alipay']    = 1;         
            $insertData['pay_price']       = $recharge_score[$score]['money'];    
            $insertData['order_status']    = 1;             
            $insertData['add_time']        = TIMESTAMP;     
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'=> 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 400,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "pay_apply_sites" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $city_id    = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id    = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $xm         = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $xm         = dhtmlspecialchars($xm);
    $tel        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel        = dhtmlspecialchars($tel);
    $content    = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content    = dhtmlspecialchars($content);
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id); 
    if(empty($userInfo) || $userInfo['status'] != 1){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $applySitesInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_apply_sites")->fetch_by_user_id($user_id);
    if(is_array($applySitesInfoTmp) && !empty($applySitesInfoTmp)){
        if($applySitesInfoTmp['pay_status'] == 1){
            C::t("#tom_tongcheng#tom_tongcheng_apply_sites")->delete_by_id($applySitesInfoTmp['id']);
        }else{
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $insertData = array();
    $insertData['user_id']      = $user_id;
    $insertData['xm']           = $xm;
    $insertData['tel']          = $tel;
    $insertData['city_id']      = $city_id;
    $insertData['area_id']      = $area_id;
    $insertData['content']      = $content;
    if($tcadminConfig['child_apply_sites_price'] > 0){
        $insertData['pay_status']       = 1;
    }else{
        $insertData['pay_status']       = 0;
    }
    $insertData['add_time']     = TIMESTAMP;
    if(C::t("#tom_tongcheng#tom_tongcheng_apply_sites")->insert($insertData)){
        $apply_sites_id = C::t("#tom_tongcheng#tom_tongcheng_apply_sites")->insert_id();
    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tcadminConfig['child_apply_sites_price'] > 0){
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $tongchengInfo['site_id'];
        $insertData['order_no']         = $order_no;
        $insertData['order_type']       = 12;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['apply_sites_id']   = $apply_sites_id;
        $insertData['pay_price']        = $tcadminConfig['child_apply_sites_price'];
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tongcheng#tom_tongcheng_order')->insert($insertData)){
            $order_id = C::t('#tom_tongcheng#tom_tongcheng_order')->insert_id();
            
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tongcheng';
            $insertData['order_no']        = $order_no;            
            $insertData['goods_id']        = $tongcheng_id;           
            $insertData['goods_name']      = lang('plugin/tom_tongcheng','order_type_12');
            $insertData['goods_beizu']     = lang('plugin/tom_tongcheng','order_type_12');
            $insertData['goods_url']       = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=index";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=applysites";
            $insertData['fail_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=applysites";
            $insertData['allow_alipay']    = 1;         
            $insertData['pay_price']       = $tcadminConfig['child_apply_sites_price'];    
            $insertData['order_status']    = 1;             
            $insertData['add_time']        = TIMESTAMP;     
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'=> 200,
                    'pay_status' => 1,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
        if($access_token && !empty($manageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$orderInfo['site_id']}&mod=index");

            $smsData = array(
                'first'         => lang('plugin/tom_tongcheng', 'paynotify_apply_sites_template'),
                'keyword1'      => $tongchengConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => ''
            );
            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
        
        $outArr = array(
            'status'=> 200,
            'pay_status' => 0,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "buyrefresh" && $_GET['formhash'] == FORMHASH && $userStatus == true){
    
    $num   = intval($_GET['num'])>0? intval($_GET['num']):0;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($__UserInfo['id']); 
    
    $tongchengSetting['refresh_price_str'] = trim($tongchengSetting['refresh_price_str']);

    $refresh_item = array();
    if(!empty($tongchengSetting['refresh_price_str'])){
        $refresh_price_str = str_replace("\r\n","{n}",$tongchengSetting['refresh_price_str']); 
        $refresh_price_str = str_replace("\n","{n}",$refresh_price_str);
        $refresh_price_list = explode("{n}", $refresh_price_str);
        if(is_array($refresh_price_list) && !empty($refresh_price_list)){
            foreach ($refresh_price_list as $key => $value){
                $refresh_price_list_item = explode("|", $value);
                $refresh_price_list_item_num = intval($refresh_price_list_item[0]);
                $refresh_price_list_item_price = floatval($refresh_price_list_item[1]);
                if($refresh_price_list_item_num > 0 && $refresh_price_list_item_price > 0){
                    $refresh_item[$refresh_price_list_item_num] = $refresh_price_list_item_price;
                }
            }
        }
    }
    
    $orderListTmp = C::t('#tom_tongcheng#tom_tongcheng_order')->fetch_all_list(" AND user_id={$userInfo['id']} AND order_type=13 AND order_status=1 ","ORDER BY id DESC",0,10);
    if(is_array($orderListTmp) && !empty($orderListTmp)){
        foreach ($orderListTmp as $key => $value){
            $updateData = array();
            $updateData['order_status'] = 3;
            C::t('#tom_tongcheng#tom_tongcheng_order')->update($value['id'],$updateData);
        }
    }
    
    if($num > 0 && isset($refresh_item[$num]) && !empty($refresh_item[$num])){
    }else{
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($refresh_item[$num] > 0){
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['order_no']         = $order_no;
        $insertData['order_type']       = 13;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['pay_price']        = $refresh_item[$num];
        $insertData['refresh_num']      = $num;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tongcheng#tom_tongcheng_order')->insert($insertData)){
            $order_id = C::t('#tom_tongcheng#tom_tongcheng_order')->insert_id();
            
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tongcheng';
            $insertData['order_no']        = $order_no;            
            $insertData['goods_id']        = 0;           
            $insertData['goods_name']      = lang('plugin/tom_tongcheng','order_type_13');
            $insertData['goods_beizu']     = lang('plugin/tom_tongcheng','order_type_13');
            $insertData['goods_url']       = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=buyrefresh";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist";
            $insertData['fail_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=buyrefresh";
            $insertData['allow_alipay']    = 1;         
            $insertData['pay_price']       = $refresh_item[$num];   
            $insertData['order_status']    = 1;             
            $insertData['add_time']        = TIMESTAMP;     
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'=> 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 400,
        );
        echo json_encode($outArr); exit;
    }
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}