<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$__IsWeixin = $__IsQianfan = $__IsXiaoyun = $__IsMagapp = $__IsMocuzapp = $__IsApp = $__IsMiniprogram = $__Ios = $__Android = 0;
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){ $__IsWeixin = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false){ $__IsQianfan = 1;$__IsApp = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false){ $__IsXiaoyun = 1;$__IsApp = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false){ $__IsMagapp = 1;$__IsApp = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MocuzApp') !== false){ $__IsMocuzapp = 1;$__IsApp = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') !== false){$__Ios = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false){$__Android = 1;}
$cookie_tom_miniprogram = getcookie('tom_miniprogram');
if($cookie_tom_miniprogram == 1 || $_GET['f'] == 'miniprogram'){ $__IsMiniprogram = 1;$__HideHeader = 1;}


$__UserInfo = array();
$userStatus = false;

$ucenterfilenameExists = false;
$ucenterfilename = DISCUZ_ROOT.'./source/plugin/tom_ucenter/tom_ucenter.inc.php';
if(file_exists($ucenterfilename)){
    $ucenterfilenameExists = true;
}
    
$__MemberInfo = array();
$cookieUid = getcookie('tom_ucenter_member_uid');
$cookieKey = getcookie('tom_ucenter_member_key');
if(!empty($cookieUid) && !empty($cookieKey)){
    $__MemberInfoTmp = C::t('#tom_ucenter#tom_ucenter_member')->fetch_by_uid($cookieUid);
    if($__MemberInfoTmp && !empty($__MemberInfoTmp['mykey'])){
        if(md5($__MemberInfoTmp['uid'].'|||'.$__MemberInfoTmp['mykey']) == $cookieKey){
            $__MemberInfo = $__MemberInfoTmp;
            $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_member_id($__MemberInfo['uid']);
            if($userInfoTmp){
                $__UserInfo = $userInfoTmp;
                $userStatus = true;
            }
        }
    }
}
    

if($userStatus && $__UserInfo['id'] > 0){
    $__UserInfo['groupid'] = 0;
    $__UserInfo['groupsiteid'] = 0;
    if($tongchengConfig['manage_user_id'] == $__UserInfo['id']){
        $__UserInfo['groupid'] = 1;
    }
    if($__UserInfo['groupid'] == 0){
        $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_manage_user_id($__UserInfo['id']);
        if($siteInfoTmp){
            $tcadminfilename = DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php';
            if(file_exists($tcadminfilename)){
                $__UserInfo['groupid'] = 2;
                $__UserInfo['groupsiteid'] = $siteInfoTmp['id'];
            }
        }
    }
}
