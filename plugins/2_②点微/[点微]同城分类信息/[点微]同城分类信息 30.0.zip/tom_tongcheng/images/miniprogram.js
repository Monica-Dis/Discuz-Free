var InMiniprogramStatus = 0;
if(wx.miniProgram){
    wx.miniProgram.getEnv(function(res) {
      if(res.miniprogram){
          InMiniprogramStatus = 1;
          $.get("plugin.php?id=tom_tongcheng:ajax&act=miniprogram&ok=1");
      }
    })
}else{
    $.get("plugin.php?id=tom_tongcheng:ajax&act=miniprogram&ok=0");
}

function miniprogramReady(){
    
    if(wx.miniProgram){
        
        if(typeof miniprogramShareStatus != "undefined"){
            var newtitle    = miniprogramShareTitle;
            var newlink     = miniprogramShareUrl;
            var newpic      = miniprogramShareLogo;
        }else{
            var newtitle    = document.title;
            var newlink     = window.location.href;
            var newpic      = '';
        }
        
        newlink         = encodeURIComponent(newlink);
        wx.miniProgram.postMessage({ data: {title:newtitle,link:newlink,pic:newpic} })
        
    }
    
  if(window.__wxjs_environment === 'miniprogram'){
      console.log('check miniProgram ok 1');
      InMiniprogramStatus = 1;
      $.get("plugin.php?id=tom_tongcheng:ajax&act=miniprogram&ok=1");
  }else{
      console.log('check miniProgram ok 0');
      $.get("plugin.php?id=tom_tongcheng:ajax&act=miniprogram&ok=0");
  }
}
if (!window.WeixinJSBridge || !WeixinJSBridge.invoke) {
  document.addEventListener('WeixinJSBridgeReady', miniprogramReady, false)
}else{
  miniprogramReady()
}

function jumpMiniprogram(link){
    if(InMiniprogramStatus == 1){
        
        var newviewurl  = encodeURIComponent(link);
        
        var linkType = 1;
        if(link.indexOf("mod=index") > 0){
            linkType = 2;
        //}else if(link.indexOf("mod=list") > 0 || link.indexOf("mod=personal") > 0 || link.indexOf("mod=my") > 0 || link.indexOf("mod=mylist") > 0 || link.indexOf("mod=myfabu") > 0 || link.indexOf("page=") > 0){
        }else if(link.indexOf("page=") > 0 || link.indexOf("mod=personal") > 0 || link.indexOf("mod=my&") > 0 || link.indexOf("mod=store") > 0){
            linkType = 3;
        }
        
        if(linkType == 1){
            wx.miniProgram.navigateTo({
              url: '/pages/index/view?viewurl=' + newviewurl
            });
        }
        if(linkType == 2){
            wx.miniProgram.reLaunch({
              url: '/pages/index/view?viewurl=' + newviewurl
            });
        }
        if(linkType == 3){
            wx.miniProgram.redirectTo({
              url: '/pages/index/view?viewurl=' + newviewurl
            });
        }
    }else{
        window.location.href=link;
    }
}