<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
 * 
 * type 1 ͷͼ  2 ��� 3��Ƶ
 * 
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_tom_tcershou_photo extends discuz_table{
	public function __construct() {
        parent::__construct();/*dis'.'m.tao'.'bao.com*/
		$this->_table = 'tom_tcershou_photo';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
    public function fetch_all_list($condition = '',$orders = '',$start = 0,$limit = 10) {
        global $_G,$tongchengConfig;
        
        $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        if(is_array($data) && !empty($data)){
            foreach($data as $key => $value){
                if($tongchengConfig['open_yun'] == 2 && !empty($value['oss_picurl']) && $value['oss_status'] == 1){
                    $picurlTmp = $value['oss_picurl'];
                }else if($tongchengConfig['open_yun'] == 3 && !empty($value['qiniu_picurl']) && $value['qiniu_status'] == 1){
                    $picurlTmp = $value['qiniu_picurl'];
                }else{
                    if(!preg_match('/^http/', $value['picurl']) ){
                        if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                            $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                        }else{
                            $picurlTmp = $_G['siteurl'].$value['picurl'];
                        }
                    }else{
                        $picurlTmp = $value['picurl'];
                    }
                }
                $data[$key]['picurlTmp'] = $picurlTmp;
            }
        }
        
        return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition) {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
    
    public function delete_all_list($condition = '') {
		return DB::query("DELETE FROM %t WHERE 1 %i", array($this->_table, $condition));
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
    
    public function delete_by_goods_id($goods_id) {
        if($goods_id > 0){
            return DB::query("DELETE FROM %t WHERE goods_id=%d", array($this->_table, $goods_id));
        }else{
            return false;
        }
	}
}