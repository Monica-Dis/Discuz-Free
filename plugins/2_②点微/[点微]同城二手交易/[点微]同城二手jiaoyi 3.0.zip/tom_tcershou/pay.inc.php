<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tcershouConfig = $_G['cache']['plugin']['tom_tcershou'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcershou/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';

## xiaofenlei start
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')){
    $xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
    $__ShowXiaofenlei = 1;
}
## xiaofenlei end

if($_GET['act'] == "fabu" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $business_mode      = isset($_GET['business_mode'])? intval($_GET['business_mode']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title              = dhtmlspecialchars($title);
    $chengse_id         = isset($_GET['chengse_id'])? intval($_GET['chengse_id']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content            = dhtmlspecialchars($content);
    $xm                 = isset($_GET['xm'])? daddslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? daddslashes($_GET['tel']):'';
    $wx                 = isset($_GET['wx'])? daddslashes($_GET['wx']):0;
    $price              = isset($_GET['price'])? addslashes($_GET['price']):'';
    $market_price       = isset($_GET['market_price'])? addslashes($_GET['market_price']):'';
    $peisong_type       = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $express_price      = isset($_GET['express_price'])? addslashes($_GET['express_price']):'';
    $city_id            = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $stock_num          = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $video_url          = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_url          = dhtmlspecialchars($video_url);
    $video_pic          = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic          = dhtmlspecialchars($video_pic);
    $fabu_days          = intval($_GET['fabu_days'])>0? intval($_GET['fabu_days']):0;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    if(!$userInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $checkSafeText = $title.$content.$xm.$tel.$wx.$address;
    $__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
    if(!empty($__CommonInfo['forbid_word'])){
        $forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
        $forbid_word = str_replace(array("\\*"), array('.*'), $forbid_word);
        $forbid_word = '.*('.$forbid_word.').*';
        $forbid_word = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word).')$/i';
        $contentTmpTmp = $checkSafeText;
        $contentTmpTmp = str_replace("\r\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\r","",$contentTmpTmp);
        if(@preg_match($forbid_word, $contentTmpTmp,$matches)) {
            $i = count($matches)-1;
            $word = '';
            if(isset($matches[$i]) && !empty($matches[$i])){
                $word = diconv($matches[$i],CHARSET,'utf-8');
            }
            $outArr = array(
                'status'=> 505,
                'word'=> $word,
            );
            echo json_encode($outArr); exit;
        }
                
    }
    
    if($__ShowXiaofenlei == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php';
        if($xiaofenleiConfig['open_msgseccheck'] == 1){
            @$s_m_r = wx_msgSecCheck($checkSafeText);
            if($s_m_r['code'] == 100){
                $tcershouConfig['fabu_goods_must_shenhe'] = 1;
            }
            if($s_m_r['code'] == 500){
                $outArr = array(
                    'status'=> 505,
                    'word'=> $s_m_r['word'],
                );
                echo json_encode($outArr); exit;
            }
        }
    }
        
    $firstFabuDaysStatus = $fabu_pay_price = $fabu_pay_score = 0;
    if($fabu_days > 0){
        $goods_fabu_list_str = str_replace("\r\n","{n}",$tcershouConfig['goods_fabu_list']); 
        $goods_fabu_list_str = str_replace("\n","{n}",$goods_fabu_list_str);
        $goods_fabu_list_arr = explode("{n}", $goods_fabu_list_str);
        $i = 1;
        if(is_array($goods_fabu_list_arr) && !empty($goods_fabu_list_arr)){
            foreach ($goods_fabu_list_arr as $key => $value){
                $goodsFabuInfoTmp = array();
                $goodsFabuInfoTmp = explode("|", $value);
                if($goodsFabuInfoTmp[0] == $fabu_days){
                    $fabu_pay_price = $goodsFabuInfoTmp[1];
                    if($i == 1){
                        $firstFabuDaysStatus = 1;
                    }
                }
                $i++;
            }
        }
        
        if($tcershouConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $fabu_pay_score = ceil($fabu_pay_price * $tongchengConfig['pay_score_yuan']);
        }

        if($fabu_pay_price > 0){}else{
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $fabuPayStatus = 0;
   
    if($tcershouConfig['open_fabu_goods_money'] == 1){
        $fabuPayStatus = 1;
    }
    if($firstFabuDaysStatus == 1  && $fabuPayStatus == 1){
        if($tcershouConfig['free_fabu_goods_num'] > 0){
            $freeFabuCount = C::t("#tom_tcershou#tom_tcershou_log")->fetch_all_count(" AND user_id = {$user_id} AND type = 1 ");
            if($tcershouConfig['free_fabu_goods_num'] > $freeFabuCount){
                $fabuPayStatus = 2;
            }
        }
    }
    
    if($fabuPayStatus == 1 && $fabu_pay_score > 0){
        if($userInfo['score'] >= $fabu_pay_score){
            $fabuPayStatus = 3;
        }
    }

    $pay_price = $pay_score = 0;
    
    if($fabuPayStatus == 1){
       $pay_price = $fabu_pay_price;
   }
    
    if($fabuPayStatus == 3){
        $pay_score = $fabu_pay_score;
    }
   
    $insertData = array();
    $insertData['site_id']        = $site_id;
    $insertData['user_id']        = $user_id;
    $insertData['business_mode']  = $business_mode;
    $insertData['cate_id']        = $cate_id;
    $insertData['chengse_id']     = $chengse_id;
    $insertData['title']          = $title;
    if($tcershouConfig['open_fabu_tel'] == 1){
        $insertData['xm']             = $xm;
        $insertData['wx']             = $wx;
        $insertData['tel']            = $tel;
    }
    $insertData['content']        = $content;
    $insertData['video_url']      = $video_url;
    $insertData['price']          = $price;
    $insertData['market_price']   = $market_price;
    $insertData['peisong_type']   = $peisong_type;
    $insertData['express_price']  = $express_price;
    $insertData['city_id']        = $city_id;
    $insertData['area_id']        = $area_id;
    $insertData['street_id']      = $street_id;
    $insertData['address']        = $address;
    $insertData['latitude']       = $latitude;
    $insertData['longitude']      = $longitude;
    $insertData['stock_num']      = $stock_num;
    if($fabuPayStatus == 1){
        $insertData['pay_status']           = 1;
    }else{
        $insertData['pay_status']           = 0;
    }
    $insertData['status']                   = 1;
    if($fabuPayStatus == 0){
        $insertData['expire_status']        = 3;
    }else{
        $insertData['expire_status']        = 2;
    }
    if($tcershouConfig['fabu_goods_must_shenhe'] == 1){
        $insertData['shenhe_status']       = 2;
    }else{
        $insertData['shenhe_status']       = 1;
    }
    $insertData['refresh_time']      = TIMESTAMP;
    $insertData['add_time']          = TIMESTAMP;
    if(C::t('#tom_tcershou#tom_tcershou_goods')->insert($insertData)){
        
        $goods_id = C::t('#tom_tcershou#tom_tcershou_goods')->insert_id();
        
        $goodsInfoTmp = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($goods_id);
        
        if(!empty($picurl)){
            $insertData = array();
            $insertData['goods_id']  = $goods_id;
            $insertData['type']      = 1;
            $insertData['picurl']    = $picurl;
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcershou#tom_tcershou_photo')->insert($insertData);
        }
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']  = $goods_id;
                $insertData['type']      = 2;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcershou#tom_tcershou_photo')->insert($insertData);
            }
        }
        if(!empty($video_pic)){
            $insertData = array();
            $insertData['goods_id']    = $goods_id;
            $insertData['type']        = 3;
            $insertData['picurl']      = $video_pic;
            $insertData['add_time']    = TIMESTAMP;
            C::t("#tom_tcershou#tom_tcershou_photo")->insert($insertData);
        }
        
        if($fabuPayStatus == 2){
            
            $insertData = array();
            $insertData['user_id']              = $userInfo['id'];
            $insertData['goods_id']             = $goods_id;
            $insertData['type']                 = 1;
            $insertData['today_time']           = $nowDayTime;
            $insertData['log_time']             = TIMESTAMP;
            C::t("#tom_tcershou#tom_tcershou_log")->insert($insertData);
            
            $fabu_time = $fabu_days * 86400 + TIMESTAMP;
            
            $updateData = array();
            $updateData['expire_status']        = 1;
            $updateData['expire_time']          = $fabu_time;
            $updateData['status']               = 1;
            C::t("#tom_tcershou#tom_tcershou_goods")->update($goods_id, $updateData);
        }
     
        if($fabuPayStatus == 3){
            
            $updateData = array();
            $updateData['score'] = $userInfo['score'] - $pay_score;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
            
            $updateData = array();

            $fabu_time = $fabu_days * 86400 + TIMESTAMP;

            $updateData['expire_status']   = 1;
            $updateData['expire_time']     = $fabu_time;
            C::t('#tom_tcershou#tom_tcershou_goods')->update($goods_id, $updateData);
            
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['score_value']      = $pay_score;
            $insertData['old_value']        = $userInfo['score'];
            $insertData['log_type']         = 58;
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        }
        
        if($pay_price > 0){
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }

            $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['goods_id']         = $goods_id;
            $insertData['type']             = 4;
            $insertData['user_id']          = $userInfo['id'];
            $insertData['openid']           = $userInfo['openid'];
            $insertData['order_no']         = $order_no;
            $insertData['fabu_days']        = $fabu_days;
            $insertData['fabu_price']       = $fabu_pay_price;
            $insertData['pay_price']        = $pay_price;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tcershou#tom_tcershou_order')->insert($insertData)){
                $order_id = C::t('#tom_tcershou#tom_tcershou_order')->insert_id();

                $insertData = array();
                $insertData['plugin_id']       = 'tom_tcershou';          
                $insertData['order_no']        = $order_no;                 
                $insertData['goods_id']        = $order_id;         
                $insertData['goods_name']      = $title;
                $insertData['goods_beizu']     = '';
                $insertData['goods_url']       = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=goodsinfo&goods_id='.$goods_id;
                $insertData['succ_back_url']   = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=myfabu';
                $insertData['fail_back_url']   = "plugin.php?id=tom_tcershou&site={$site_id}&mod=myfabu"; 
                $insertData['allow_alipay']    = 1;
                $insertData['pay_price']       = $pay_price;
                $insertData['order_status']    = 1;
                $insertData['add_time']        = TIMESTAMP;
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    $outArr = array(
                        'status'        => 200,
                        'pay_status'    => 1,
                        'payurl'        => "plugin.php?id=tom_pay&order_no=".$order_no,
                    );
                    echo json_encode($outArr); exit;
                }else{
                    $outArr = array(
                        'status'=> 303,
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
        }else{
            update_goods_tongcheng($goods_id);
            if(!empty($tongchengConfig['template_id']) && $tcershouConfig['fabu_goods_must_shenhe'] == 1 ){
                $toUser = array();
                $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
                if($toUserTmp && !empty($toUserTmp['openid'])){
                    $toUser = $toUserTmp;
                }

                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                $access_token = $weixinClass->get_access_token();

                if($access_token && !empty($toUser['openid'])  ){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=managerList");
                    $smsData = array(
                        'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcershou','shenhe_template_first'),
                        'keyword1'      => $tcershouConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                        'remark'        => ''
                    );
                    $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
                }
                
                $ershoumanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcershouConfig['ershoumanage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($ershoumanageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=managerList");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcershou', 'shenhe_template_first'),
                        'keyword1'      => $tcershouConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($ershoumanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }
            $outArr = array(
                'status'=> 200,
            );
            echo json_encode($outArr); exit;

        }
        
    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($_GET['act'] == "fabuneeds" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $price              = isset($_GET['price'])? addslashes($_GET['price']):'';
    $xm                 = isset($_GET['xm'])? daddslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? daddslashes($_GET['tel']):'';
    $wx                 = isset($_GET['wx'])? daddslashes($_GET['wx']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $city_id            = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $fabu_days          = intval($_GET['fabu_days'])>0? intval($_GET['fabu_days']):0;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    if(!$userInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $checkSafeText = $content.$xm.$tel.$wx.$address;
    $__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
    if(!empty($__CommonInfo['forbid_word'])){
        $forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
        $forbid_word = str_replace(array("\\*"), array('.*'), $forbid_word);
        $forbid_word = '.*('.$forbid_word.').*';
        $forbid_word = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word).')$/i';
        $contentTmpTmp = $checkSafeText;
        $contentTmpTmp = str_replace("\r\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\r","",$contentTmpTmp);
        if(@preg_match($forbid_word, $contentTmpTmp,$matches)) {
            $i = count($matches)-1;
            $word = '';
            if(isset($matches[$i]) && !empty($matches[$i])){
                $word = diconv($matches[$i],CHARSET,'utf-8');
            }
            $outArr = array(
                'status'=> 505,
                'word'=> $word,
            );
            echo json_encode($outArr); exit;
        }
                
    }
    
    if($__ShowXiaofenlei == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php';
        if($xiaofenleiConfig['open_msgseccheck'] == 1){
            @$s_m_r = wx_msgSecCheck($checkSafeText);
            if($s_m_r['code'] == 100){
                $tcershouConfig['fabu_needs_must_shenhe'] = 1;
            }
            if($s_m_r['code'] == 500){
                $outArr = array(
                    'status'=> 505,
                    'word'=> $s_m_r['word'],
                );
                echo json_encode($outArr); exit;
            }
        }
    }
        
    $firstFabuDaysStatus = $fabu_pay_price = $fabu_pay_score = 0;
    if($fabu_days > 0){
        $needs_fabu_list_str = str_replace("\r\n","{n}",$tcershouConfig['needs_fabu_list']); 
        $needs_fabu_list_str = str_replace("\n","{n}",$needs_fabu_list_str);
        $needs_fabu_list_arr = explode("{n}", $needs_fabu_list_str);
        $i = 1;
        if(is_array($needs_fabu_list_arr) && !empty($needs_fabu_list_arr)){
            foreach ($needs_fabu_list_arr as $key => $value){
                $needsFabuInfoTmp = array();
                $needsFabuInfoTmp = explode("|", $value);

                if($needsFabuInfoTmp[0] == $fabu_days){
                    $fabu_pay_price = $needsFabuInfoTmp[1];
                    
                    if($i == 1){
                        $firstFabuDaysStatus = 1;
                    }
                }
                $i++;
            }
        }
        
        if($tcershouConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $fabu_pay_score = ceil($fabu_pay_price * $tongchengConfig['pay_score_yuan']);
        }

        if($fabu_pay_price > 0){}else{
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }    
    
    $fabuPayStatus = 0;
   
    if($tcershouConfig['open_fabu_needs_money'] == 1){
        $fabuPayStatus = 1;
    }
    if($firstFabuDaysStatus == 1 && $fabuPayStatus == 1){
        if($tcershouConfig['free_fabu_needs_num'] > 0){
            $freeFabuCount = C::t("#tom_tcershou#tom_tcershou_log")->fetch_all_count(" AND user_id = {$user_id} AND type = 2 ");
            if($tcershouConfig['free_fabu_needs_num'] > $freeFabuCount){
                $fabuPayStatus = 2;
            }
        }
    }
    
    if($fabuPayStatus == 1 && $fabu_pay_score > 0){
        if($userInfo['score'] >= $fabu_pay_score){
            $fabuPayStatus = 3;
        }
    }

    $pay_price = $pay_score = 0;
    
    if($fabuPayStatus == 1){
       $pay_price = $fabu_pay_price;
   }
    
    if($fabuPayStatus == 3){
        $pay_score = $fabu_pay_score;
    }
    
    $insertData = array();
    $insertData['site_id']        = $site_id;
    $insertData['user_id']        = $user_id;
    $insertData['cate_id']        = $cate_id;
    $insertData['price']          = $price;
    $insertData['xm']             = $xm;
    $insertData['tel']            = $tel;
    $insertData['wx']             = $wx;
    $insertData['content']        = $content;
    $insertData['city_id']        = $city_id;
    $insertData['area_id']        = $area_id;
    $insertData['street_id']      = $street_id;
    $insertData['address']        = $address;
    $insertData['latitude']       = $latitude;
    $insertData['longitude']      = $longitude;
   if($fabuPayStatus == 1){
        $insertData['pay_status']           = 1;
    }else{
        $insertData['pay_status']           = 0;
    }
    $insertData['status']                   = 1;
    if($fabuPayStatus == 0){
        $insertData['expire_status']        = 3;
    }else{
        $insertData['expire_status']        = 2;
    }
    if($tcershouConfig['fabu_needs_must_shenhe'] == 1){
        $insertData['shenhe_status']       = 2;
    }else{
        $insertData['shenhe_status']       = 1;
    }
    $insertData['refresh_time']      = TIMESTAMP;
    $insertData['add_time']          = TIMESTAMP;
    
    if(C::t('#tom_tcershou#tom_tcershou_needs')->insert($insertData)){
        
        $needs_id = C::t('#tom_tcershou#tom_tcershou_needs')->insert_id();
        
        $needsInfoTmp = C::t('#tom_tcershou#tom_tcershou_needs')->fetch_by_id($needs_id);
        
        if($fabuPayStatus == 2){
            
            $insertData = array();
            $insertData['user_id']              = $userInfo['id'];
            $insertData['needs_id']             = $needs_id;
            $insertData['type']                 = 2;
            $insertData['today_time']           = $nowDayTime;
            $insertData['log_time']             = TIMESTAMP;
            C::t("#tom_tcershou#tom_tcershou_log")->insert($insertData);
            
            $fabu_time = $fabu_days * 86400 + TIMESTAMP;
            
            $updateData = array();
            $updateData['expire_status']        = 1;
            $updateData['expire_time']          = $fabu_time;
            $updateData['status']               = 1;
            C::t("#tom_tcershou#tom_tcershou_needs")->update($needs_id, $updateData);
        }
     
        if($fabuPayStatus == 3){
            
            $updateData = array();
            $updateData['score'] = $userInfo['score'] - $pay_score;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
            
            $updateData = array();

            $fabu_time = $fabu_days * 86400 + TIMESTAMP;

            $updateData['expire_status']   = 1;
            $updateData['expire_time']     = $fabu_time;
            C::t('#tom_tcershou#tom_tcershou_needs')->update($needs_id, $updateData);
            
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['score_value']      = $pay_score;
            $insertData['old_value']        = $userInfo['score'];
            $insertData['log_type']         = 59;
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        }
        
        if($pay_price > 0){
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }

            $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['needs_id']         = $needs_id;
            $insertData['type']             = 6;
            $insertData['user_id']          = $userInfo['id'];
            $insertData['openid']           = $userInfo['openid'];
            $insertData['order_no']         = $order_no;
            $insertData['fabu_days']        = $fabu_days;
            $insertData['fabu_price']       = $fabu_pay_price;
            $insertData['pay_price']        = $pay_price;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tcershou#tom_tcershou_order')->insert($insertData)){
                $order_id = C::t('#tom_tcershou#tom_tcershou_order')->insert_id();

                $insertData = array();
                $insertData['plugin_id']       = 'tom_tcershou';          
                $insertData['order_no']        = $order_no;                 
                $insertData['goods_id']        = $order_id;         
                $insertData['goods_name']      = $content;
                $insertData['goods_beizu']     = '';
                $insertData['goods_url']       = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=needsinfo&needs_id='.$needs_id;
                $insertData['succ_back_url']   = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=myfabu_needs';
                $insertData['fail_back_url']   = "plugin.php?id=tom_tcershou&site={$site_id}&mod=myfabu_needs"; 
                $insertData['allow_alipay']    = 1;
                $insertData['pay_price']       = $pay_price;
                $insertData['order_status']    = 1;
                $insertData['add_time']        = TIMESTAMP;
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    $outArr = array(
                        'status'        => 200,
                        'pay_status'    => 1,
                        'payurl'        => "plugin.php?id=tom_pay&order_no=".$order_no,
                    );
                    echo json_encode($outArr); exit;
                }else{
                    $outArr = array(
                        'status'=> 303,
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
        }else{
            update_needs_tongcheng($needs_id);
            if(!empty($tongchengConfig['template_id']) && $tcershouConfig['fabu_needs_must_shenhe'] == 1 ){
                $toUser = array();
                $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
                if($toUserTmp && !empty($toUserTmp['openid'])){
                    $toUser = $toUserTmp;
                }

                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                $access_token = $weixinClass->get_access_token();

                if($access_token && !empty($toUser['openid'])  ){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=managerNeedsList");
                    $smsData = array(
                        'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcershou','shenhe_needs_template_first'),
                        'keyword1'      => $tcershouConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                        'remark'        => ''
                    );
                    $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
                }
                
                $ershoumanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcershouConfig['ershoumanage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($ershoumanageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=managerNeedsList");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcershou', 'shenhe_needs_template_first'),
                        'keyword1'      => $tcershouConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($ershoumanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }

            $outArr = array(
                'status'=> 200,
            );
            echo json_encode($outArr); exit;

        }
        
    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($_GET['act'] == "goods_top_pay" && submitcheck('goods_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $goods_id       = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;
    $top_days       = intval($_GET['top_days'])>0 ? intval($_GET['top_days']):0;

    $goodsInfo = C::t("#tom_tcershou#tom_tcershou_goods")->fetch_by_id($goods_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($goodsInfo['user_id']);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($goodsInfo) && $goodsInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $top_pay_price = $top_pay_score = 0;
    $top_pay_price_msg = '';
    $goods_top_list_str = str_replace("\r\n","{n}",$tcershouConfig['goods_top_list']); 
    $goods_top_list_str = str_replace("\n","{n}",$goods_top_list_str);
    $goods_top_list_arr = explode("{n}", $goods_top_list_str);
    if(is_array($goods_top_list_arr) && !empty($goods_top_list_arr)){
        foreach ($goods_top_list_arr as $key => $value){
            $goodsTopInfoTmp = array();
            $goodsTopInfoTmp = explode("|", $value);
            if($goodsTopInfoTmp[0] == $top_days){
                $top_pay_price = $goodsTopInfoTmp[1];
                $top_pay_price_msg = $goodsTopInfoTmp[2];
                
                if($tcershouConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                    $top_pay_score = ceil($top_pay_price * $tongchengConfig['pay_score_yuan']);
                    
                }
            }
        }
    }
    
    if($top_pay_price <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['score'] >= $top_pay_score && $top_pay_score > 0){
        $pay_score = $top_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 60;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        $goodsInfo = C::t("#tom_tcershou#tom_tcershou_goods")->fetch_by_id($goods_id);
        if($goodsInfo['top_time'] > TIMESTAMP){
            $top_time = $top_days * 86400 + $goodsInfo['top_time'];
        }else{
            $top_time = $top_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcershou#tom_tcershou_goods')->update($goods_id,$updateData);
        
        update_goods_tongcheng($goods_id);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $pay_price = $top_pay_price;

        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['goods_id']         = $goods_id;
        $insertData['type']             = 2;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['top_days']         = $top_days;
        $insertData['top_price']        = $top_pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcershou#tom_tcershou_order')->insert($insertData)){
            $order_id = C::t('#tom_tcershou#tom_tcershou_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcershou';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = lang('plugin/tom_tcershou', 'fabu_goods_top');
            $insertData['goods_beizu']     = lang('plugin/tom_tcershou','goods_top').$top_pay_price_msg;
            $insertData['goods_url']       = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=goodsinfo&goods_id='.$goods_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=buygoods&goods_id='.$goods_id;
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcershou&site={$site_id}&mod=buygoods&goods_id={$goods_id}";
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }

}else if($_GET['act'] == "needs_top_pay" && submitcheck('needs_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $needs_id       = intval($_GET['needs_id'])>0 ? intval($_GET['needs_id']):0;
    $top_days       = intval($_GET['top_days'])>0 ? intval($_GET['top_days']):0;
    
    $needsInfo = C::t("#tom_tcershou#tom_tcershou_needs")->fetch_by_id($needs_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($needsInfo['user_id']);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($needsInfo) && $needsInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $top_pay_price = $top_pay_score = 0;
    $top_pay_price_msg = '';
    $needs_top_list_str = str_replace("\r\n","{n}",$tcershouConfig['needs_top_list']); 
    $needs_top_list_str = str_replace("\n","{n}",$needs_top_list_str);
    $needs_top_list_arr = explode("{n}", $needs_top_list_str);
    if(is_array($needs_top_list_arr) && !empty($needs_top_list_arr)){
        foreach ($needs_top_list_arr as $key => $value){
            $needsTopInfoTmp = array();
            $needsTopInfoTmp = explode("|", $value);
            if($needsTopInfoTmp[0] == $top_days){
                $top_pay_price = $needsTopInfoTmp[1];
                $top_pay_price_msg = $needsTopInfoTmp[2];
                
                if($tcershouConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                    $top_pay_score = ceil($top_pay_price * $tongchengConfig['pay_score_yuan']);
                    
                }
            }
        }
    }
    
    if($top_pay_price <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['score'] >= $top_pay_score && $top_pay_score > 0){
        $pay_score = $top_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 61;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        $needsInfo = C::t("#tom_tcershou#tom_tcershou_needs")->fetch_by_id($needs_id);
        if($needsInfo['top_time'] > TIMESTAMP){
            $top_time = $top_days * 86400 + $needsInfo['top_time'];
        }else{
            $top_time = $top_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcershou#tom_tcershou_needs')->update($needs_id,$updateData);
        
        update_needs_tongcheng($needs_id);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $pay_price = $top_pay_price;

        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['needs_id']         = $needs_id;
        $insertData['type']             = 3;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['top_days']         = $top_days;
        $insertData['top_price']        = $top_pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcershou#tom_tcershou_order')->insert($insertData)){
            $order_id = C::t('#tom_tcershou#tom_tcershou_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcershou';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = lang('plugin/tom_tcershou', 'fabu_needs_top');
            $insertData['goods_beizu']     = lang('plugin/tom_tcershou','needs_top').$top_pay_price_msg;
            $insertData['goods_url']       = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=needsinfo&needs_id='.$needs_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=buyneeds&needs_id='.$needs_id;
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcershou&site={$site_id}&mod=buyneeds&needs_id={$needs_id}";
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
}else if($_GET['act'] == "goods_xufei_pay" && submitcheck('goods_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $goods_id       = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;
    $fabu_days      = intval($_GET['fabu_days'])>0 ? intval($_GET['fabu_days']):0;
    $back_url       = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
    
    $goodsInfo = C::t("#tom_tcershou#tom_tcershou_goods")->fetch_by_id($goods_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($goodsInfo['user_id']);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($goodsInfo) && $goodsInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }

    $fabu_pay_price = $fabu_pay_score = 0;
    $fabu_pay_price_msg = '';
    $goods_fabu_list_str = str_replace("\r\n","{n}",$tcershouConfig['goods_fabu_list']); 
    $goods_fabu_list_str = str_replace("\n","{n}",$goods_fabu_list_str);
    $goods_fabu_list_arr = explode("{n}", $goods_fabu_list_str);
    if(is_array($goods_fabu_list_arr) && !empty($goods_fabu_list_arr)){
        foreach ($goods_fabu_list_arr as $key => $value){
            $goodsFabuInfoTmp = array();
            $goodsFabuInfoTmp = explode("|", $value);

            if($goodsFabuInfoTmp[0] == $fabu_days){
                $fabu_pay_price = $goodsFabuInfoTmp[1];
                $fabu_pay_price_msg = $goodsFabuInfoTmp[2];
                
                if($tcershouConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                    $fabu_pay_score = ceil($fabu_pay_price * $tongchengConfig['pay_score_yuan']);
                }
            }
        }
    }

    if($fabu_pay_price <= 0){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['expire_status'] == 3){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    if($fabu_pay_score > 0 && $userInfo['score'] >= $fabu_pay_score){
        $pay_score = $fabu_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 62;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        if($goodsInfo['expire_time'] > TIMESTAMP){
            $fabu_time = $fabu_days * 86400 + $goodsInfo['expire_time'];
        }else{
            $fabu_time = $fabu_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['expire_status']   = 1;
        $updateData['expire_time']     = $fabu_time;
        $updateData['status']          = 1;
        C::t('#tom_tcershou#tom_tcershou_goods')->update($goods_id, $updateData);
        
        update_goods_tongcheng($goods_id);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $pay_price = $fabu_pay_price;
        
        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['goods_id']         = $goods_id;
        $insertData['type']             = 5;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['fabu_days']        = $fabu_days;
        $insertData['fabu_price']       = $fabu_pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcershou#tom_tcershou_order')->insert($insertData)){
            $order_id = C::t('#tom_tcershou#tom_tcershou_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcershou';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = $goodsInfo['title'];
            $insertData['goods_beizu']     = lang('plugin/tom_tcershou','goods_xufei').$fabu_pay_price_msg;
            $insertData['goods_url']       = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=goodsinfo&goods_id='.$goods_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=buyxufei_goods&goods_id='.$goods_id.'&back_url='.urlencode($back_url);
            $insertData['fail_back_url']   = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=buyxufei_goods&goods_id='.$goods_id.'&back_url='.urlencode($back_url);
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 305,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }

}else if($_GET['act'] == "needs_xufei_pay" && submitcheck('needs_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $needs_id       = intval($_GET['needs_id'])>0 ? intval($_GET['needs_id']):0;
    $fabu_days      = intval($_GET['fabu_days'])>0 ? intval($_GET['fabu_days']):0;
    
    $needsInfo = C::t("#tom_tcershou#tom_tcershou_needs")->fetch_by_id($needs_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($needsInfo['user_id']);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($needsInfo) && $needsInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }

    $fabu_pay_price = $fabu_pay_score = 0;
    $fabu_pay_price_msg = '';
    $needs_fabu_list_str = str_replace("\r\n","{n}",$tcershouConfig['needs_fabu_list']); 
    $needs_fabu_list_str = str_replace("\n","{n}",$needs_fabu_list_str);
    $needs_fabu_list_arr = explode("{n}", $needs_fabu_list_str);
    if(is_array($needs_fabu_list_arr) && !empty($needs_fabu_list_arr)){
        foreach ($needs_fabu_list_arr as $key => $value){
            $needsFabuInfoTmp = array();
            $needsFabuInfoTmp = explode("|", $value);

            if($needsFabuInfoTmp[0] == $fabu_days){
                $fabu_pay_price = $needsFabuInfoTmp[1];
                $fabu_pay_price_msg = $needsFabuInfoTmp[2];
                
                if($tcershouConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                    $fabu_pay_score = ceil($fabu_pay_price * $tongchengConfig['pay_score_yuan']);
                }
            }
        }
    }

    if($fabu_pay_price <= 0){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($needsInfo['expire_status'] == 3){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    if($fabu_pay_score > 0 && $userInfo['score'] >= $fabu_pay_score){
        $pay_score = $fabu_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 63;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        if($needsInfo['expire_time'] > TIMESTAMP){
            $fabu_time = $fabu_days * 86400 + $needsInfo['expire_time'];
        }else{
            $fabu_time = $fabu_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['expire_status']   = 1;
        $updateData['expire_time']     = $fabu_time;
        $updateData['status']          = 1;
        C::t('#tom_tcershou#tom_tcershou_needs')->update($needs_id, $updateData);
        
        update_needs_tongcheng($needs_id);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $pay_price = $fabu_pay_price;
        
        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['needs_id']         = $needs_id;
        $insertData['type']             = 7;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['fabu_days']        = $fabu_days;
        $insertData['fabu_price']       = $fabu_pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcershou#tom_tcershou_order')->insert($insertData)){
            $order_id = C::t('#tom_tcershou#tom_tcershou_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcershou';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = $needsInfo['content'];
            $insertData['goods_beizu']     = lang('plugin/tom_tcershou','needs_xufei').$fabu_pay_price_msg;
            $insertData['goods_url']       = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=needsinfo&needs_id='.$needs_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=buyxufei_needs&needs_id='.$needs_id;
            $insertData['fail_back_url']   = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=buyxufei_needs&needs_id='.$needs_id;
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 305,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }

}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}