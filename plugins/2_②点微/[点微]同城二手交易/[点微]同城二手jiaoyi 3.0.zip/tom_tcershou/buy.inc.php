<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tcershouConfig = $_G['cache']['plugin']['tom_tcershou'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcershou/class/function.core.php';

if($_GET['act'] == "pay_price" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $goods_id           = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $peisong_type       = intval($_GET['peisong_type'])>0? intval($_GET['peisong_type']):0;
    $xm                 = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $goods_num          = intval($_GET['goods_num'])>0? intval($_GET['goods_num']):1;
    $address_id         = isset($_GET['address_id'])? intval($_GET['address_id']):0;
    $order_beizu        = isset($_GET['order_beizu'])? addslashes($_GET['order_beizu']):'';
    
    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $goodsInfo  = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($goods_id);
    
    $addressInfo = array('xm'=>'','tel'=>'','area_str'=>'','info'=>'');
    if($address_id > 0){
        $addressInfo = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
    }
    
    if(empty($userInfo) || empty($goodsInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $pay_price = $goodsInfo['price'];
    
    if($pay_price <= 0){
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    $stock_num      = $goodsInfo['stock_num'];
    
    if($goods_num > $stock_num){
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
    $order_no  = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    $hexiao_no = date("YmdHis")."-".mt_rand(111111, 666666);
    $pay_price = $pay_price*$goods_num;
    
    if($peisong_type == 2 && $goodsInfo['express_price'] > 0){
        $pay_price = $pay_price + $goodsInfo['express_price'];
    }
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['order_no']         = $order_no;
    $insertData['hexiao_no']        = $hexiao_no;
    $insertData['goods_id']         = $goodsInfo['id'];
    $insertData['type']             = 1;
    $insertData['goods_title']      = $goodsInfo['title'];
    $insertData['goods_num']        = $goods_num;
    $insertData['sale_user_id']     = $goodsInfo['user_id'];
    $insertData['user_id']          = $user_id;
    if($peisong_type == 2 ){
        $insertData['xm']               = $addressInfo['xm'];
        $insertData['tel']              = $addressInfo['tel'];
        $insertData['address']          = $addressInfo['area_str']." ".$addressInfo['info'];
    }else{
        $insertData['xm']               = $xm;
        $insertData['tel']              = $tel;
        $insertData['address']          = '';
    }
    $insertData['order_beizu']      = $order_beizu;
    $insertData['openid']           = $userInfo['openid'];
    $insertData['pay_price']        = $pay_price;
    if($address_id > 0 ){
        $insertData['address_id']   = $address_id;
    }
    $insertData['peisong_type']     = $peisong_type;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcershou#tom_tcershou_order')->insert($insertData)){
        $orderId = C::t('#tom_tcershou#tom_tcershou_order')->insert_id();
        
        DB::query("UPDATE ".DB::table('tom_tcershou_goods')." SET stock_num=stock_num-{$goods_num}, sale_num=sale_num+{$goods_num} WHERE id='{$goodsInfo['id']}' ", 'UNBUFFERED');
        
        $insertData = array();
        $insertData['plugin_id']       = 'tom_tcershou';          
        $insertData['order_no']        = $order_no;                 
        $insertData['goods_id']        = $goodsInfo['id'];         
        $insertData['goods_name']      = $goodsInfo['title'];      
        $insertData['goods_beizu']     = $goodsInfo['title'];      
        $insertData['goods_url']       = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=goodsinfo&goods_id='.$goodsInfo['id'];               
        $insertData['succ_back_url']   = "plugin.php?id=tom_tcershou&site={$site_id}&mod=order"; 
        $insertData['fail_back_url']   = "plugin.php?id=tom_tcershou&site={$site_id}&mod=order";  
        $insertData['allow_alipay']    = 1;             
        $insertData['pay_price']       = $pay_price;    
        $insertData['order_status']    = 1;             
        $insertData['add_time']        = TIMESTAMP;     
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'    => 200,
                'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($_GET['act'] == "pay" && submitcheck('order_no')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $order_no   = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
    
    $orderInfo  = C::t('#tom_tcershou#tom_tcershou_order')->fetch_by_order_no($order_no);
    $goodsInfo  = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($orderInfo['goods_id']);
    
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    if($orderInfo && $orderInfo['order_status'] == 1){
        
        DB::query("UPDATE ".DB::table('tom_tcershou_order')." SET order_no='{$order_no}' WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tcershou';          
        $insertData['order_no']        = $order_no;                 
        $insertData['goods_id']        = $orderInfo['goods_id'];         
        $insertData['goods_name']      = $goodsInfo['title'];
        $insertData['goods_url']       = "plugin.php?id=tom_tcershou&site={$site_id}&mod=goodsinfo&goods_id={$orderInfo['goods_id']}";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tcershou&site={$site_id}&mod=order";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tcershou&site={$site_id}&mod=order"; 
        $insertData['allow_alipay']    = 1;    
        $insertData['pay_price']       = $orderInfo['pay_price'];
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        C::t('#tom_pay#tom_pay_order')->insert($insertData);
        
        $outArr = array(
            'status'    => 200,
            'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }

}else if($_GET['act'] == "cancelpay" && submitcheck('order_no')){
    
    $order_no  = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
   
    $orderInfo = C::t('#tom_tcershou#tom_tcershou_order')->fetch_by_order_no($order_no);
    
    if($orderInfo && $orderInfo['order_status'] == 1){
        
        DB::query("UPDATE ".DB::table('tom_tcershou_order')." SET order_status=5 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
        
        DB::query("UPDATE ".DB::table('tom_tcershou_goods')." SET sale_num=sale_num-{$orderInfo['goods_num']}, stock_num=stock_num+{$orderInfo['goods_num']} WHERE id='{$orderInfo['goods_id']}' ", 'UNBUFFERED');
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}