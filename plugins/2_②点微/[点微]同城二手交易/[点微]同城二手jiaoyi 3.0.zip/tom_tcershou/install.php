<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcershou_cate`;
CREATE TABLE `pre_tom_tcershou_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `csort` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_clicks`;
CREATE TABLE `pre_tom_tcershou_clicks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `clicks` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_collect`;
CREATE TABLE `pre_tom_tcershou_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_diynav`;
CREATE TABLE `pre_tom_tcershou_diynav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `add_time` varchar(255) DEFAULT '0',
  `dsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_focuspic`;
CREATE TABLE `pre_tom_tcershou_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '1',
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_goods`;
CREATE TABLE `pre_tom_tcershou_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `cate_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `business_mode` tinyint(4) DEFAULT '1',
  `chengse_id` int(11) DEFAULT '0',
  `market_price` decimal(10,2) DEFAULT '0.00',
  `price` decimal(10,2) DEFAULT '0.00',
  `stock_num` int(11) DEFAULT '0',
  `sale_num` int(11) NOT NULL DEFAULT '0',
  `xiangou_num` int(11) DEFAULT '0',
  `peisong_type` int(11) DEFAULT '1',
  `express_price` decimal(10,2) DEFAULT '0.00',
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `street_id` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT '',
  `content` text,
  `admin_edit` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `wx` varchar(255) DEFAULT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  `clicks` int(11) DEFAULT '0',
  `finish` tinyint(4) DEFAULT '0',
  `finish_time` int(11) DEFAULT '0',
  `pay_status` tinyint(4) DEFAULT '0',
  `expire_time` int(11) DEFAULT '0',
  `expire_status` tinyint(4) DEFAULT '0',
  `top_time` int(11) DEFAULT '0',
  `top_status` int(11) DEFAULT '0',
  `refresh_time` int(11) DEFAULT NULL,
  `shenhe_status` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '1000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_cate_id` (`cate_id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_pay_status` (`pay_status`),
  KEY `idx_top_status` (`top_status`),
  KEY `idx_top_time` (`top_time`),
  KEY `idx_finish` (`finish`),
  KEY `idx_refresh_time` (`refresh_time`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_log`;
CREATE TABLE `pre_tom_tcershou_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `needs_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `today_time` int(11) DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_needs`;
CREATE TABLE `pre_tom_tcershou_needs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `cate_id` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `wx` varchar(255) DEFAULT NULL,
  `admin_edit` int(11) DEFAULT '0',
  `content` text,
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `street_id` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT '',
  `clicks` int(11) DEFAULT '0',
  `finish` tinyint(4) DEFAULT '0',
  `expire_status` tinyint(4) DEFAULT '0',
  `expire_time` int(11) DEFAULT '0',
  `pay_status` tinyint(4) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `refresh_time` int(11) DEFAULT '0',
  `top_status` int(11) DEFAULT '0',
  `top_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '1000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_cate_id` (`cate_id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_pay_status` (`pay_status`),
  KEY `idx_top_status` (`top_status`),
  KEY `idx_top_time` (`top_time`),
  KEY `idx_refresh_time` (`refresh_time`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_order`;
CREATE TABLE `pre_tom_tcershou_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `order_no` varchar(255) DEFAULT NULL,
  `hexiao_no` varchar(255) DEFAULT NULL,
  `goods_id` int(11) DEFAULT '0',
  `needs_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `goods_num` int(11) DEFAULT '0',
  `goods_title` varchar(255) DEFAULT NULL,
  `sale_user_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `openid` varchar(255) DEFAULT NULL,
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `order_time` int(11) DEFAULT '0',
  `pay_time` int(11) DEFAULT '0',
  `peisong_type` int(11) DEFAULT '1',
  `peisong_time` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `address_id` int(11) DEFAULT '0',
  `kuaidi_type` varchar(255) DEFAULT NULL,
  `kuaidi_no` varchar(255) DEFAULT NULL,
  `balance_status` int(11) DEFAULT '0',
  `order_status` int(11) DEFAULT '0',
  `refund_type` int(11) DEFAULT '0',
  `shenqing_refund` tinyint(4) DEFAULT '0',
  `shenqing_refund_msg` varchar(255) DEFAULT NULL,
  `sale_allow_refund` tinyint(4) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `fabu_days` int(11) DEFAULT '0',
  `fabu_price` decimal(10,2) DEFAULT '0.00',
  `top_days` int(11) DEFAULT '0',
  `top_price` decimal(10,2) DEFAULT '0.00',
  `show_kuaidi` int(11) DEFAULT '0',
  `order_beizu` varchar(255) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_order_status` (`order_status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_photo`;
CREATE TABLE `pre_tom_tcershou_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  `oss_picurl` varchar(255) DEFAULT NULL,
  `oss_status` tinyint(4) DEFAULT '0',
  `qiniu_picurl` varchar(255) DEFAULT NULL,
  `qiniu_status` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_pinglun`;
CREATE TABLE `pre_tom_tcershou_pinglun` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `needs_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `content` varchar(255) DEFAULT NULL,
  `pinglun_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_pinglun_reply`;
CREATE TABLE `pre_tom_tcershou_pinglun_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `needs_id` int(11) DEFAULT '0',
  `pinglun_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `user_nickname` varchar(255) DEFAULT NULL,
  `user_avatar` varchar(255) DEFAULT NULL,
  `content` text,
  `reply_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_report`;
CREATE TABLE `pre_tom_tcershou_report` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `report_user_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `needs_id` int(11) DEFAULT '0',
  `report_content` varchar(255) DEFAULT NULL,
  `report_pic_1` varchar(255) DEFAULT NULL,
  `report_pic_2` varchar(255) DEFAULT NULL,
  `report_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcershou_stock_log`;
CREATE TABLE `pre_tom_tcershou_stock_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_admin` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '1',
  `old_num` int(11) DEFAULT '0',
  `change_num` int(11) DEFAULT '0',
  `change_time` int(11) DEFAULT '0',
  `beizu` text,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$finish = TRUE;