<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcershouConfig = $_G['cache']['plugin']['tom_tcershou'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = '20200714';
$sql_in_site_ids = $site_id;
if (!file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/tom_tongcheng.inc.php')) {
	echo '<a href="https://addon.discuz.com/?@tom_tongcheng.plugin">https://addon.discuz.com/?@tom_tongcheng.plugin</a>';
	exit(0);
}
if (CHARSET == 'gbk') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/config/config.gbk.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/config/config.utf8.php';
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tcershou/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/function.html.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcershouConfig['wx_share_title'];
$shareDesc = $tcershouConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=index');
$shareLogo = $tcershouConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$tcadminConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcadmin/tom_tcadmin.inc.php')) {
	$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
$__ShowKuaidi = 0;
$kuaidiConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_kuaidi/tom_kuaidi.inc.php')) {
	$__ShowKuaidi = 1;
	$kuaidiConfig = $_G['cache']['plugin']['tom_kuaidi'];
}
$__ShowVideo = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/video.inc.php')) {
	$__ShowVideo = 1;
}
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')) {
	$tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
	if ($tcrenzhengConfig['open_tcrenzheng'] == 1) {
		$__ShowTcrenzheng = 1;
	}
}
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')) {
	$xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
	$__ShowXiaofenlei = 1;
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$__ClicksInfo = C::t('#tom_tcershou#tom_tcershou_clicks')->fetch_by_site_id($site_id);
if (!$__ClicksInfo || $__ClicksInfo['id'] <= 0) {
	$insertData = array();
	$insertData['site_id'] = $site_id;
	C::t('#tom_tcershou#tom_tcershou_clicks')->insert($insertData);
}
$renzheng_back_url = $weixinClass->get_url();
$renzheng_back_url = urlencode($renzheng_back_url);
$personalRenzhengUrl = 'plugin.php?id=tom_tcrenzheng&site=' . $site_id . '&mod=personal&renzheng_back=' . $renzheng_back_url;
$companyRenzhengurl = 'plugin.php?id=tom_tcrenzheng&site=' . $site_id . '&mod=company&renzheng_back=' . $renzheng_back_url;
$ajaxLoadListUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
$ajaxUpdateGoodsTopExpireStatusUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=update_goods_top_expire_status&formhash=' . $formhash;
$ajaxUpdateNeedsTopExpireStatusUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=update_needs_top_expire_status&formhash=' . $formhash;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
$ajaxCommonClicksUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=clicks&formhash=' . $formhash;
if ($_GET['mod'] == 'index') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/site_lbs.php';
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$focuspicListTmp = C::t('#tom_tcershou#tom_tcershou_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY fsort ASC,id DESC ', 0, 20);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tcershou#tom_tcershou_focuspic')->fetch_all_list(' AND site_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 20);
	}
	$focuspicTopList = array();
	foreach ($focuspicListTmp as $key => $value) {
		if (!preg_match('/^http/', $value['picurl'])) {
			if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
				$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
			} else {
				$picurl = $value['picurl'];
			}
		} else {
			$picurl = $value['picurl'];
		}
		$linkTmp = str_replace('{site}', $site_id, $value['link']);
		$focuspicTopList[$key] = $value;
		$focuspicTopList[$key]['picurl'] = $picurl;
		$focuspicTopList[$key]['link'] = $linkTmp;
	}
	$focuspicTopCount = count($focuspicTopList);
	$tcershouFabus = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_count(' AND site_id IN(' . $sql_in_site_ids . ') ');
	$fabuNum = $tcershouFabus + $tcershouConfig['virtual_fabu'];
	$fabuNumTxt = $fabuNum;
	if ($fabuNum > 10000) {
		$fabuNumTmp = $fabuNum / 10000;
		$fabuNumTxt = number_format($fabuNumTmp, 2, '.', '');
	}
	$tcershouOrders = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_sun_goods_num(' AND site_id IN(' . $sql_in_site_ids . ') AND type = 1 AND order_status IN(2,3,4) ');
	$orderNum = $tcershouOrders + $tcershouConfig['virtual_finish'];
	$orderNumTxt = $orderNum;
	if ($orderNum > 10000) {
		$orderNumTmp = $orderNum / 10000;
		$orderNumTxt = number_format($orderNumTmp, 2, '.', '');
	}
	$tcershouClicks = C::t('#tom_tcershou#tom_tcershou_clicks')->fetch_all_sun_clicks(' AND site_id IN(' . $sql_in_site_ids . ') ');
	$clicksNum = $tcershouClicks + $tcershouConfig['virtual_clicks'];
	$clicksNumTxt = $clicksNum;
	if ($clicksNum > 10000) {
		$clicksNumTmp = $clicksNum / 10000;
		$clicksNumTxt = number_format($clicksNumTmp, 2, '.', '');
	}
	$diyListTmp = C::t('#tom_tcershou#tom_tcershou_diynav')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY dsort ASC,id DESC ', 0, 100);
	if (!is_array($diyListTmp) || empty($diyListTmp)) {
		$diyListTmp = C::t('#tom_tcershou#tom_tcershou_diynav')->fetch_all_list(' AND site_id=1 ', ' ORDER BY dsort ASC,id DESC ', 0, 100);
	}
	$diyList = array();
	$i = 1;
	$navCount = 0;
	if (is_array($diyListTmp) && !empty($diyListTmp)) {
		foreach ($diyListTmp as $key => $value) {
			$diyList[$key] = $value;
			$diyList[$key]['i'] = $i;
			$diyList[$key]['link'] = str_replace('{site}', $site_id, $diyList[$key]['link']);
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$diyList[$key]['picurl'] = $picurl;
			$i = $i + 1;
			$navCount = $navCount + 1;
		}
	}
	$line4NavList = array();
	if (!empty($tcershouConfig['index_line4_nav'])) {
		$index_line4_str = str_replace("\r\n", '{n}', trim($tcershouConfig['index_line4_nav']));
		$index_line4_str = str_replace("\n", '{n}', $index_line4_str);
		$index_line4_str = str_replace('{site}', $site_id, $index_line4_str);
		$index_line4_arr = explode('{n}', $index_line4_str);
		if (is_array($index_line4_arr) && !empty($index_line4_arr)) {
			foreach ($index_line4_arr as $key => $value) {
				$line4NavList[] = explode('|', $value);
			}
		}
	}
	$line4NavCount = count($line4NavList);
	$newGooddsListTmp = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_list(' AND site_id IN(' . $sql_in_site_ids . ') AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ', ' ORDER BY id DESC ', 0, 5);
	$newGoodsList = array();
	if (is_array($newGooddsListTmp) && !empty($newGooddsListTmp)) {
		foreach ($newGooddsListTmp as $key => $value) {
			$newGoodsList[$key] = $value;
			$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$newGoodsList[$key]['userInfo'] = $userInfoTmp;
		}
	}
	$newGoodsCount = count($newGoodsList);
	$cateList = array();
	$cateListTmp = C::t('#tom_tcershou#tom_tcershou_cate')->fetch_all_list(' ', 'ORDER BY csort ASC,id DESC', 0, 100);
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
		}
	}
	if ($tcershouConfig['new_finish_type'] == 1) {
		$newOrderListTmp = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_list(' AND site_id IN(' . $sql_in_site_ids . ') AND type = 1 AND order_status IN (2,3,4)', ' ORDER BY id DESC ', 0, 6);
		$newOrderList = array();
		if (is_array($newOrderListTmp) && !empty($newOrderListTmp)) {
			foreach ($newOrderListTmp as $key => $value) {
				$newOrderList[$key] = $value;
				$goodsInfoTmp = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($value['goods_id']);
				$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfoTmp['user_id']);
				$goodsphotoListTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list('AND type IN (1,2) AND goods_id = ' . $goodsInfoTmp['id'], ' ORDER BY id ASC ', 0, 4);
				$goodsphotoList = array();
				if (is_array($goodsphotoListTmp) && !empty($goodsphotoListTmp)) {
					foreach ($goodsphotoListTmp as $kk => $vv) {
						$picurlTmp = $vv['picurlTmp'];
						$goodsphotoList[] = $picurlTmp;
					}
				}
				$newOrderList[$key]['userInfo'] = $userInfoTmp;
				$newOrderList[$key]['goodsInfo'] = $goodsInfoTmp;
				$newOrderList[$key]['goodsphotoList'] = $goodsphotoList;
			}
		}
	} else {
		$newFinishListTmp = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_list(' AND site_id IN(' . $sql_in_site_ids . ') AND status = 1 AND shenhe_status = 1 AND (pay_status = 0 OR pay_status = 2)  AND finish = 1 ', ' ORDER BY finish_time DESC,id DESC ', 0, 6);
		$newOrderList = array();
		if (is_array($newFinishListTmp) && !empty($newFinishListTmp)) {
			foreach ($newFinishListTmp as $key => $value) {
				$newOrderList[$key]['goodsInfo'] = $value;
				$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
				$goodsphotoListTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list('AND type IN (1,2) AND goods_id = ' . $value['id'], ' ORDER BY id ASC ', 0, 4);
				$goodsphotoList = array();
				if (is_array($goodsphotoListTmp) && !empty($goodsphotoListTmp)) {
					foreach ($goodsphotoListTmp as $kk => $vv) {
						$goodsphotoList[] = $vv['picurlTmp'];
					}
				}
				$newOrderList[$key]['userInfo'] = $userInfoTmp;
				$newOrderList[$key]['goodsphotoList'] = $goodsphotoList;
			}
		}
	}
	$newOrderCount = count($newOrderList);
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=list&cate_id=' . $cate_id . '&keyword=' . $keyword . '&formhash=' . $formhash;
	$ajaxLoadneedsListUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=needslist&formhash=' . $formhash;
	if ($__ShowTchehuoren == 1) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=index'));
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tcershou/images/index.js';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcershou:index');
	echo '<script src="source/plugin/tom_tcershou/images/index.js"></script>';
} elseif ($_GET['mod'] == 'goodslist') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$paixu_type = intval($_GET['paixu_type']) > 0 ? intval($_GET['paixu_type']) : 1;
	$chengse_ids = isset($_GET['chengse_ids']) ? addslashes($_GET['chengse_ids']) : '';
	$chengseidList = array();
	if (!empty($chengse_ids)) {
		$chengseidList = explode(',', $chengse_ids);
	}
	$chengsesArray = array();
	if (is_array($chengseArray) && !empty($chengseArray)) {
		foreach ($chengseArray as $key => $value) {
			$chengsesArray[$key]['name'] = $value;
			if (in_array($key, $chengseidList)) {
				$chengsesArray[$key]['selected'] = 1;
			} else {
				$chengsesArray[$key]['selected'] = 0;
			}
		}
	}
	$cateName = $tcershouConfig['goodslist_cate0_name'];
	$cateList = array();
	$cateListTmp = C::t('#tom_tcershou#tom_tcershou_cate')->fetch_all_list(' ', 'ORDER BY csort ASC,id DESC', 0, 100);
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			if ($cate_id == $value['id']) {
				$cateName = $value['name'];
			}
		}
	}
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$areaList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$goodslistUrl = 'plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=goodslist&';
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$shareTitle = $tcershouConfig['goodslist_share_title'];
	$shareTitle = str_replace('{CATENAME}', $cateName, $shareTitle);
	$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	$shareDesc = $tcershouConfig['goodslist_share_desc'];
	$shareDesc = str_replace('{CATENAME}', $cateName, $shareDesc);
	$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	if (!empty($tcershouConfig['goods_share_pic'])) {
		$shareLogo = $tcershouConfig['goods_share_pic'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=goodslist&cate_id=' . $cate_id);
	if ($__ShowTchehuoren == 1) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=goodslist&cate_id=' . $cate_id . '&area_id=' . $area_id . '&street_id=' . $street_id . '&paixu_type=' . $paixu_type));
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcershou:goodslist');
} elseif ($_GET['mod'] == 'search') {
	$searchArr = array();
	$goodsSearchArr = explode('|', $tcershouConfig['default_search_str']);
	if (is_array($goodsSearchArr) && !empty($goodsSearchArr)) {
		foreach ($goodsSearchArr as $key => $value) {
			$searchArr[] = daddslashes($value);
		}
	}
	$searchCount = count($searchArr);
	$ajaxSearchUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=get_search_url&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcershou:search');
} elseif ($_GET['mod'] == 'goodsinfo') {
	$goods_id = intval($_GET['goods_id']) > 0 ? intval($_GET['goods_id']) : 0;
	$tcershou_goods_id = $goods_id;
	$goodsInfo = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($goods_id);
	if ($goodsInfo['status'] != 1 || $goodsInfo['shenhe_status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']);
	$cateInfo = C::t('#tom_tcershou#tom_tcershou_cate')->fetch_by_id($goodsInfo['cate_id']);
	if ($goodsInfo['area_id'] > 0) {
		$areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($goodsInfo['area_id']);
		$streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($goodsInfo['street_id']);
	}
	$goodsphotoListTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list('AND goods_id = ' . $goods_id . ' AND type IN (1,2,3) ', 'ORDER BY type ASC,id ASC', 0, 100);
	$goodsphotoList = array();
	$goodsphotoListStr = '';
	$goods_pic = $video_pic = '';
	if (is_array($goodsphotoListTmp) && !empty($goodsphotoListTmp)) {
		foreach ($goodsphotoListTmp as $kk => $vv) {
			$picurlTmp = $vv['picurlTmp'];
			if ($vv['type'] == 1) {
				$goods_pic = $picurlTmp;
				$goodsphotoList[] = $picurlTmp;
			} elseif ($vv['type'] == 2) {
				$goodsphotoList[] = $picurlTmp;
			} elseif ($vv['type'] == 3) {
				$video_pic = $picurlTmp;
			}
		}
		$goodsphotoListStr = implode('|', $goodsphotoList);
	}
	$showBuyBtn = 0;
	if ($goodsInfo['status'] == 1 && $goodsInfo['shenhe_status'] == 1 && $goodsInfo['finish'] == 0 && $goodsInfo['expire_status'] != 2) {
		$showBuyBtn = 1;
	}
	if ($goodsInfo['business_mode'] == 2) {
		$showBuyBtn = 2;
	}
	$haibaoPicurlList = array();
	if (is_array($goodsphotoListTmp) && !empty($goodsphotoListTmp)) {
		foreach ($goodsphotoListTmp as $kk => $vv) {
			if (!preg_match('/^http/', $vv['picurl'])) {
				if (strpos($vv['picurl'], 'source/plugin/tom_') === false) {
					$picurl = 'data/attachment/tomwx/' . $vv['picurl'];
				} else {
					$picurl = $vv['picurl'];
				}
			} else {
				$picurl = $vv['picurl'];
			}
			$haibaoPicurlList[$kk] = $picurl;
		}
	}
	$content = stripslashes($goodsInfo['content']);
	$content = str_replace("\r\n", '<br/>', $content);
	$content = str_replace("\n", '<br/>', $content);
	$content = str_replace("\r", '<br/>', $content);
	$add_time = dgmdate($goodsInfo['add_time'], 'm-d H:i', $tomSysOffset);
	$pinglunCount = C::t('#tom_tcershou#tom_tcershou_pinglun')->fetch_all_count(' AND goods_id=' . $goods_id);
	$open_edit_pinglun = 0;
	if ($goodsInfo['user_id'] == $__UserInfo['id'] && $tongchengConfig['open_fbr_remove_pinglun'] == 1) {
		$open_edit_pinglun = 1;
	} else {
		if ($__UserInfo['groupid'] == 1 && $site_id == 1) {
			$open_edit_pinglun = 1;
		} else {
			if ($__UserInfo['groupid'] == 2 && $site_id == $__UserInfo['groupsiteid']) {
				$open_edit_pinglun = 1;
			}
		}
	}
	$goodsCount = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_count(' AND user_id=' . $userInfo['id'] . ' AND status=1 AND shenhe_status=1 ');
	$companyRenzhengStatus = $personalRenzhengStatus = 0;
	if ($__ShowTcrenzheng == 1) {
		$companyInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_user_id($goodsInfo['user_id']);
		if (is_array($companyInfoTmp) && $companyInfoTmp['shenhe_status'] == 1) {
			$companyRenzhengStatus = 1;
		}
		$personalInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_user_id($goodsInfo['user_id']);
		if (is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1) {
			$personalRenzhengStatus = 1;
		}
	}
	$tcershouCount = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_count('AND id !=' . $goods_id . ' AND cate_id = ' . $goodsInfo['cate_id'] . ' AND status =1 AND shenhe_status = 1 AND (pay_status = 0 OR pay_status = 2) ');
	$tcershouListTmp = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_list('AND id !=' . $goods_id . ' AND cate_id = ' . $goodsInfo['cate_id'] . ' AND status =1 AND shenhe_status = 1 AND (pay_status = 0 OR pay_status = 2) ', 'ORDER BY add_time ASC,paixu ASC,id DESC', 0, 10);
	$tcershouList = array();
	foreach ($tcershouListTmp as $key => $value) {
		$tcershouList[$key] = $value;
		$photoInfoTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list(' AND goods_id = ' . $value['id'] . ' AND type = 1 ', ' ORDER BY id ASC ', 0, 1);
		if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
			$picurlTmp = $photoInfoTmp[0]['picurlTmp'];
		}
		$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
		$tcershouList[$key]['userInfo'] = $userInfoTmp;
		$tcershouList[$key]['picurl'] = $picurlTmp;
		$tcershouList[$key]['add_time'] = dgmdate($value['add_time'], 'm-d', $tomSysOffset);
		$tcershouList[$key]['link'] = 'plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=goodsinfo&goods_id=' . $value['id'];
	}
	$orderCount = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_count(' AND type = 1 AND goods_id = ' . $goods_id . ' AND order_status IN (2,3,4) ');
	if ($__UserInfo['id'] > 0) {
		$isCollect = C::t('#tom_tcershou#tom_tcershou_collect')->fetch_all_list('AND user_id = ' . $__UserInfo['id'] . ' AND goods_id =' . $goods_id, ' ORDER BY id DESC ', 0, 1);
	}
	$haibao_txt_msg = '';
	$haibao_txt_picurl = 'source/plugin/tom_tcershou/images/haibao_type.png';
	if (!empty($tongchengConfig['haibao_txt'])) {
		list($haibao_txt_msg, $haibao_txt_picurl) = explode('|', $tongchengConfig['haibao_txt']);
	}
	$must_phone_projectArr = unserialize($tongchengConfig['must_phone_project']);
	$showMustPhoneBtn = 0;
	if (array_search('2', $must_phone_projectArr) !== false && empty($__UserInfo['tel']) && $__UserInfo['editor'] == 0 && $__UserInfo['is_majia'] == 0) {
		$showMustPhoneBtn = 1;
		$phone_back_url = $weixinClass->get_url();
		$phone_back_url = urlencode($phone_back_url);
		$phoneUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=phone&phone_back=' . $phone_back_url;
	}
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tcershouConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$baiduMapToName = $goodsInfo['title'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapToAddress = $goodsInfo['address'];
	$baiduMapToAddress = diconv($baiduMapToAddress, CHARSET, 'utf-8');
	$baiduMapToAddress = urlencode($baiduMapToAddress);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $goodsInfo['latitude'] . ',' . $goodsInfo['longitude'] . '&title=' . $baiduMapToName . '&content=' . $baiduMapToAddress . '&output=html';
	$shareTitle = $tcershouConfig['goodsinfo_share_title'];
	$shareTitle = str_replace('{TITLE}', $goodsInfo['title'], $shareTitle);
	$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	$shareDesc = $tcershouConfig['goodsinfo_share_desc'];
	$shareDesc = str_replace('{TITLE}', $goodsInfo['title'], $shareDesc);
	$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	$shareLogo = $goods_pic;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=goodsinfo&goods_id=') . $goods_id;
	$haibaoQrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($shareUrl);
	if ($__ShowTchehuoren == 1) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$ajaxTuiDoTzUrl = '';
	if ($__ShowTchehuoren == 1 && file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tui_do.php')) {
		include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tui_do.php';
	}
	$messageUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&to_user_id=' . $goodsInfo['user_id'] . '&formhash=' . FORMHASH . '&tcershou_goods_id=' . $goods_id;
	$ajaxAddShoucangUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=addshoucang';
	$addPinglunUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=pinglun&goods_id=' . $goods_id . '&formhash=' . FORMHASH;
	$removePinglunUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=removePinglun&goods_id=' . $goods_id . '&formhash=' . FORMHASH;
	$ajaxLoadPinglunUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=loadPinglun&goods_id=' . $goods_id . '&formhash=' . FORMHASH;
	$tousuUrl = 'plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=report&report_user_id=' . $goodsInfo['user_id'] . '&goods_id=' . $goodsInfo['id'];
	$ajaxClicksUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=goods_clicks&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcershou:goodsinfo');
} elseif ($_GET['mod'] == 'home') {
	$user_id = intval($_GET['user_id']) > 0 ? intval($_GET['user_id']) : 0;
	$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
	$companyRenzhengStatus = $personalRenzhengStatus = 0;
	if ($__ShowTcrenzheng == 1) {
		$companyInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_user_id($user_id);
		if (is_array($companyInfoTmp) && $companyInfoTmp['shenhe_status'] == 1) {
			$companyRenzhengStatus = 1;
		}
		$personalInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_user_id($user_id);
		if (is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1) {
			$personalRenzhengStatus = 1;
		}
	}
	$goodsCount = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_count(' AND user_id=' . $userInfo['id'] . ' AND status=1 AND shenhe_status=1 ');
	$orderCount = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_count(' AND type = 1 AND sale_user_id = ' . $userInfo['id'] . ' AND order_status IN (2,3,4) ');
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=home&user_id=' . $user_id);
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=list&user_id=' . $user_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcershou:home');
} elseif ($_GET['mod'] == 'needslist') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$paixu_type = intval($_GET['paixu_type']) > 0 ? intval($_GET['paixu_type']) : 1;
	$cateName = $tcershouConfig['needslist_cate0_name'];
	$cateList = array();
	$cateListTmp = C::t('#tom_tcershou#tom_tcershou_cate')->fetch_all_list(' ', 'ORDER BY csort ASC,id DESC', 0, 100);
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			if ($cate_id == $value['id']) {
				$cateName = $value['name'];
			}
		}
	}
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$areaList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$needslistUrl = 'plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=needslist&';
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$ajaxLoadneedsListUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=needslist&paixu_type=' . $paixu_type . '&cate_id=' . $cate_id . '&keyword=' . $keyword . '&formhash=' . $formhash;
	$shareTitle = $tcershouConfig['needslist_share_title'];
	$shareTitle = str_replace('{CATENAME}', $cateName, $shareTitle);
	$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	$shareDesc = $tcershouConfig['needslist_share_desc'];
	$shareDesc = str_replace('{CATENAME}', $cateName, $shareDesc);
	$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	if (!empty($tcershouConfig['needs_share_pic'])) {
		$shareLogo = $tcershouConfig['needs_share_pic'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=needslist&cate_id=' . $cate_id);
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=needslist&cate_id=' . $cate_id . '&area_id=' . $area_id . '&street_id=' . $street_id . '&paixu_type=' . $paixu_type));
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcershou:needslist');
} elseif ($_GET['mod'] == 'search_needs') {
	$searchArr = array();
	$needsSearchArr = explode('|', $tcershouConfig['default_search_needs_str']);
	if (is_array($needsSearchArr) && !empty($needsSearchArr)) {
		foreach ($needsSearchArr as $key => $value) {
			$searchArr[] = daddslashes($value);
		}
	}
	$searchCount = count($searchArr);
	$ajaxSearchUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=get_search_needs_url&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcershou:search_needs');
} elseif ($_GET['mod'] == 'needsinfo') {
	$needs_id = intval($_GET['needs_id']) > 0 ? intval($_GET['needs_id']) : 0;
	$needsInfo = C::t('#tom_tcershou#tom_tcershou_needs')->fetch_by_id($needs_id);
	if ($needsInfo['status'] != 1 || $needsInfo['shenhe_status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);
	$cateInfo = C::t('#tom_tcershou#tom_tcershou_cate')->fetch_by_id($needsInfo['cate_id']);
	if ($needsInfo['area_id'] > 0) {
		$areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($needsInfo['area_id']);
		$streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($needsInfo['street_id']);
	}
	$content = stripslashes($needsInfo['content']);
	$content = str_replace("\r\n", '<br/>', $content);
	$content = str_replace("\n", '<br/>', $content);
	$content = str_replace("\r", '<br/>', $content);
	$add_time = dgmdate($needsInfo['add_time'], 'u', '9999', 'm-d H:i');
	$pinglunCount = C::t('#tom_tcershou#tom_tcershou_pinglun')->fetch_all_count(' AND needs_id=' . $needs_id);
	$open_edit_pinglun = 0;
	if ($goodsInfo['user_id'] == $__UserInfo['id'] && $tongchengConfig['open_fbr_remove_pinglun'] == 1) {
		$open_edit_pinglun = 1;
	} else {
		if ($__UserInfo['groupid'] == 1 && $site_id == 1) {
			$open_edit_pinglun = 1;
		} else {
			if ($__UserInfo['groupid'] == 2 && $site_id == $__UserInfo['groupsiteid']) {
				$open_edit_pinglun = 1;
			}
		}
	}
	$must_phone_projectArr = unserialize($tongchengConfig['must_phone_project']);
	$showMustPhoneBtn = 0;
	if (array_search('2', $must_phone_projectArr) !== false && empty($__UserInfo['tel']) && $__UserInfo['editor'] == 0 && $__UserInfo['is_majia'] == 0) {
		$showMustPhoneBtn = 1;
		$phone_back_url = $weixinClass->get_url();
		$phone_back_url = urlencode($phone_back_url);
		$phoneUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=phone&phone_back=' . $phone_back_url;
	}
	$goodsList = array();
	$sendGoodsBtn = 0;
	if ($__UserInfo['id'] > 0) {
		$goodsListTmp = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_like_list(' AND user_id = ' . $__UserInfo['id'] . ' AND status = 1 AND shenhe_status = 1 AND finish = 0 ', ' ORDER BY refresh_time DESC,id DESC ', 0, 100, '');
		if (is_array($goodsListTmp) && !empty($goodsListTmp)) {
			$sendGoodsBtn = 1;
			$goodsList = $goodsListTmp;
		}
	}
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tcershouConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$baiduMapToName = $userInfo['nickname'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapToAddress = $needsInfo['address'];
	$baiduMapToAddress = diconv($baiduMapToAddress, CHARSET, 'utf-8');
	$baiduMapToAddress = urlencode($baiduMapToAddress);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $needsInfo['latitude'] . ',' . $needsInfo['longitude'] . '&title=' . $baiduMapToName . '&content=' . $baiduMapToAddress . '&output=html';
	$contentTmp = strip_tags($needsInfo['content']);
	$contentTmp = str_replace("\r\n", '', $contentTmp);
	$contentTmp = str_replace("\n", '', $contentTmp);
	$contentTmp = str_replace("\r", '', $contentTmp);
	$title = cutstr($contentTmp, 80, '...');
	$desc = cutstr($contentTmp, 100, '...');
	$shareTitle = $tcershouConfig['needsinfo_share_title'];
	$shareTitle = str_replace('{TITLE}', $title, $shareTitle);
	$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	$shareDesc = $tcershouConfig['needsinfo_share_desc'];
	$shareDesc = str_replace('{TITLE}', $desc, $shareDesc);
	$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	if (strpos($userInfo['picurl'], 'data/attachment/tomwx') !== false) {
		$shareLogo = $_G['siteurl'] . $userInfo['picurl'];
	} elseif (strpos($userInfo['picurl'], 'uc_server/') !== false) {
		$shareLogo = $_G['siteurl'] . $userInfo['picurl'];
	} else {
		$shareLogo = $userInfo['picurl'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=needsinfo&needs_id=') . $needs_id;
	$messageUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&to_user_id=' . $needsInfo['user_id'] . '&formhash=' . FORMHASH;
	$addPinglunUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=pinglun&needs_id=' . $needs_id . '&formhash=' . FORMHASH;
	$removePinglunUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=removePinglun&needs_id=' . $needs_id . '&formhash=' . FORMHASH;
	$ajaxLoadPinglunUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=loadPinglun&needs_id=' . $needs_id . '&formhash=' . FORMHASH;
	$tousuUrl = 'plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=report&report_user_id=' . $needsInfo['user_id'] . '&needs_id=' . $needsInfo['id'];
	$ajaxClicksUrl = 'plugin.php?id=tom_tcershou:ajax&site=' . $site_id . '&act=needs_clicks&needs_id=' . $needs_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcershou:needsinfo');
} elseif ($_GET['mod'] == 'buy') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/buy.php';
} elseif ($_GET['mod'] == 'report') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/report.php';
} elseif ($_GET['mod'] == 'my') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/my.php';
} elseif ($_GET['mod'] == 'collect') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/collect.php';
} elseif ($_GET['mod'] == 'order') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/order.php';
} elseif ($_GET['mod'] == 'orderinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/orderinfo.php';
} elseif ($_GET['mod'] == 'myorder') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/myorder.php';
} elseif ($_GET['mod'] == 'myorderinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/myorderinfo.php';
} elseif ($_GET['mod'] == 'orderhexiao') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/orderhexiao.php';
} elseif ($_GET['mod'] == 'fabu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/fabu.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/edit.php';
} elseif ($_GET['mod'] == 'myfabu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/myfabu.php';
} elseif ($_GET['mod'] == 'buygoods') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/buygoods.php';
} elseif ($_GET['mod'] == 'buyxufei_goods') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/buyxufei_goods.php';
} elseif ($_GET['mod'] == 'fabuneeds') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/fabuneeds.php';
} elseif ($_GET['mod'] == 'editneeds') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/editneeds.php';
} elseif ($_GET['mod'] == 'myfabu_needs') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/myfabu_needs.php';
} elseif ($_GET['mod'] == 'buyneeds') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/buyneeds.php';
} elseif ($_GET['mod'] == 'buyxufei_needs') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/buyxufei_needs.php';
} elseif ($_GET['mod'] == 'managerList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/managerList.php';
} elseif ($_GET['mod'] == 'managerNeedsList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/managerNeedsList.php';
} elseif ($_GET['mod'] == 'baidumap') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/baidumap.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tcershou/module/upload.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcershou&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();