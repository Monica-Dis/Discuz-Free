<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcershou'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcershou&pmod=admin'; 
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcershou&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcershou&pmod=admin';

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){
}else{
    echo '<a href="https://addon.dismall.com/?@tom_tongcheng.plugin">https://addon.dismall.com/?@tom_tongcheng.plugin</a>';exit;
}

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/config/config.utf8.php';
}

include DISCUZ_ROOT.'./source/plugin/tom_tcershou/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcershou/class/function.a.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcershou/class/function.core.php';
$tcershouConfig = get_tcershou_config($pluginid);
$Lang = formatLang($Lang);

$tongchengPlugin = C::t('#tom_tcershou#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/config/config.utf.php';
}

if($_GET['tmod'] == 'goods'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/goods.php';
    
}else if($_GET['tmod'] == 'needs'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/needs.php';
    
}else if($_GET['tmod'] == 'goodsorder'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/goodsorder.php';
    
}else if($_GET['tmod'] == 'order'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/order.php';
    
}else if($_GET['tmod'] == 'pinglun'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/pinglun.php';
    
}else if($_GET['tmod'] == 'pinglunReply'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/pinglunReply.php';
    
}else if($_GET['tmod'] == 'diynav'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/diynav.php';
    
}else if($_GET['tmod'] == 'cate'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/cate.php';
    
}else if($_GET['tmod'] == 'report'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/report.php';
    
}else if($_GET['tmod'] == 'focuspic'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/focuspic.php';
    
}else if($_GET['tmod'] == 'doDaoGoods'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/doDaoGoods.php';
    
}else if($_GET['tmod'] == 'doDaoNeeds'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/doDaoNeeds.php';
    
}else{
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcershou/admin/goods.php';
    
}