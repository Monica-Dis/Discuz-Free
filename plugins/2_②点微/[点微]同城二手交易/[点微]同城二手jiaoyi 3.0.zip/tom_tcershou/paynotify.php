<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.cn
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tcershouConfig = $_G['cache']['plugin']['tom_tcershou'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcadmin start
$__ShowTcadmin = 0;
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
    if($tcadminConfig['open_fc'] == 1){
        $__ShowTcadmin = 1;
    }
}
## tcadmin end

$appid = trim($tongchengConfig['wxpay_appid']);  
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcershou/class/function.core.php';

$orderInfo = C::t('#tom_tcershou#tom_tcershou_order')->fetch_by_order_no($order_no);
if($orderInfo && $orderInfo['order_status'] == 1){
    
    $userInfo  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
    if($orderInfo['goods_id'] > 0){
        $goodsInfo = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($orderInfo['goods_id']);
    }
    if($orderInfo['needs_id'] > 0){
        $needsInfo = C::t("#tom_tcershou#tom_tcershou_needs")->fetch_by_id($orderInfo['needs_id']);
    }
    
    $updateData = array();
    $updateData['order_status'] = 2;
    $updateData['pay_time'] = TIMESTAMP;
    C::t('#tom_tcershou#tom_tcershou_order')->update($orderInfo['id'],$updateData);
    
    if($orderInfo['type'] == 1){
        if($goodsInfo['stock_num'] < 1){
            $timeStamp = TIMESTAMP;
            DB::query("UPDATE ".DB::table('tom_tcershou_goods')." SET finish=1, finish_time={$timeStamp} WHERE id='{$orderInfo['goods_id']}' ", 'UNBUFFERED');
        }
    }
    
    if($orderInfo['type'] == 2){
        
        if($goodsInfo['top_time'] > TIMESTAMP){
            $top_time = $orderInfo['top_days'] * 86400 + $goodsInfo['top_time'];
        }else{
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcershou#tom_tcershou_goods')->update($orderInfo['goods_id'],$updateData);
        
        update_goods_tongcheng($orderInfo['goods_id']);
        
    }
    
    if($orderInfo['type'] == 3){
        
        if($needsInfo['top_time'] > TIMESTAMP){
            $top_time = $orderInfo['top_days'] * 86400 + $needsInfo['top_time'];
        }else{
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcershou#tom_tcershou_needs')->update($orderInfo['needs_id'],$updateData);
        
        update_needs_tongcheng($orderInfo['needs_id']);
    }
    
    if($orderInfo['type'] == 4){
        $updateData = array();
        
        if($orderInfo['fabu_days'] > 0){
            $fabu_time = $orderInfo['fabu_days'] * 86400 + TIMESTAMP;
            
            $updateData['expire_status']    = 1;
            $updateData['expire_time']      = $fabu_time;
            $updateData['pay_status']       = 2;
        }
        $updateData['status']           = 1;
        C::t('#tom_tcershou#tom_tcershou_goods')->update($orderInfo['goods_id'],$updateData);
        
        update_goods_tongcheng($orderInfo['goods_id']);
        
    }
    
    if($orderInfo['type'] == 5){
        
        if($goodsInfo['expire_time'] > TIMESTAMP){
            $fabu_time = $orderInfo['fabu_days'] * 86400 + $goodsInfo['expire_time'];
        }else{
            $fabu_time = $orderInfo['fabu_days'] * 86400 + TIMESTAMP;
        }

        $updateData = array();
        $updateData['expire_status']   = 1;
        $updateData['expire_time']     = $fabu_time;
        C::t('#tom_tcershou#tom_tcershou_goods')->update($orderInfo['goods_id'], $updateData);
        
        update_goods_tongcheng($orderInfo['goods_id']);
        
    }
    
    if($orderInfo['type'] == 6){
        $updateData = array();
        
        if($orderInfo['fabu_days'] > 0){
            $fabu_time = $orderInfo['fabu_days'] * 86400 + TIMESTAMP;
            
            $updateData['expire_status']    = 1;
            $updateData['expire_time']      = $fabu_time;
            $updateData['pay_status']       = 2;
        }
        $updateData['status']           = 1;
        C::t('#tom_tcershou#tom_tcershou_needs')->update($orderInfo['needs_id'],$updateData);
        
        update_needs_tongcheng($orderInfo['needs_id']);
        
    }
    
    if($orderInfo['type'] == 7){
        
        if($needsInfo['expire_time'] > TIMESTAMP){
            $fabu_time = $orderInfo['fabu_days'] * 86400 + $needsInfo['expire_time'];
        }else{
            $fabu_time = $orderInfo['fabu_days'] * 86400 + TIMESTAMP;
        }

        $updateData = array();
        $updateData['expire_status']   = 1;
        $updateData['expire_time']     = $fabu_time;
        $updateData['status']          = 1;
        C::t('#tom_tcershou#tom_tcershou_needs')->update($orderInfo['needs_id'], $updateData);
        
        update_needs_tongcheng($orderInfo['needs_id']);
        
    }
    
    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($orderInfo['order_no'])));
    
    if($tcershouConfig['open_back_score'] == 1){
        
        $score_yuan = $tongchengConfig['score_yuan'];
        if(!empty($tcershouConfig['score_yuan'])){
            $score_yuan = $tcershouConfig['score_yuan'];
        }
        
        $score = ceil($orderInfo['pay_price']*$score_yuan);
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] + $score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $orderInfo['user_id'];
        $insertData['score_value']      = $score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 57;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);

    }
    
    # fc start
    $adminFc = false;
    if($__ShowTchehuoren == 1 && $userInfo['tj_hehuoren_id'] > 0 && $orderInfo['type'] > 1){

        $shenyu_money = $orderInfo['pay_price'];
        $child_site_fc_money = $tchehuoren_fc_money = $tctchehuorenParent_fc_money = 0;
        
        $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($userInfo['tj_hehuoren_id']);
        if($tchehuorenInfo){
            $tchehuorenDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
            $tchehuorenUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tchehuorenInfo['openid']);
        }
        
        $tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
        if($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1){
            $tctchehuorenParentInfo = C::t("#tom_tchehuoren#tom_tchehuoren")->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
            $tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
            $tctchehuorenParentUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tctchehuorenParentInfo['openid']);
        }
        
        if($tchehuorenInfo && $tchehuorenInfo['status'] == 1 && $tchehuorenDengji['ershou_fc_open'] == 1){
            if($orderInfo['site_id'] > 1 && $tcershouConfig['zizhandi_fc'] == 1){
                $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                $sitename = $sitesInfo['name'];
                if($__ShowTcadmin && $sitesInfo['hehuoren_fc_open'] == 1){
                    
                    $tchehuoren_fc_money = $orderInfo['pay_price'] * ($tchehuorenDengji['ershou_fc_scale']/100);
                    $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2);
                    
                    $fc_scale = $tcadminConfig['fc_scale'];
                    if($sitesInfo['ershou_fc_scale'] > 0){
                        $fc_scale = $sitesInfo['ershou_fc_scale'];
                    }
                    $child_site_fc_money = $orderInfo['pay_price'] * ($fc_scale/100);
                    $child_site_fc_money = number_format($child_site_fc_money,2);
                    $child_site_fc_money = $child_site_fc_money - $tchehuoren_fc_money;
                    
                    if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                        $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2);
                        if($tchehuorenConfig['subordinate_moneytype'] == 1){
                            $child_site_fc_money   = $child_site_fc_money - $tctchehuorenParent_fc_money;
                        }else{
                            $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                        }
                    }
                    
                    $shenyu_money = $shenyu_money - $child_site_fc_money - $tchehuoren_fc_money;

                }else{
                    if($__ShowTcadmin == 1 && $tcershouConfig['zizhandi_fc'] == 1){
                        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                        $fc_scale = $tcadminConfig['fc_scale'];
                        if($sitesInfo['ershou_fc_scale'] > 0){
                            $fc_scale = $sitesInfo['ershou_fc_scale'];
                        }
                        $child_site_fc_money = $orderInfo['pay_price'] * ($fc_scale/100);
                        $child_site_fc_money = number_format($child_site_fc_money,2);
                    }
                    
                    $shenyu_money = $shenyu_money - $child_site_fc_money;
                    
                }
                
            }else{
                $sitename = $tongchengConfig['plugin_name'];
                $tchehuoren_fc_money = $orderInfo['pay_price'] * ($tchehuorenDengji['ershou_fc_scale']/100);
                $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2);
                
                if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                    $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                    $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2);
                    if($tchehuorenConfig['subordinate_moneytype'] == 1){
                    }else{
                        $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                    }
                }
                
                $shenyu_money = $shenyu_money - $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
            }
            
            Log::DEBUG("update shenyu_money:" . $shenyu_money);
            Log::DEBUG("update child_site_fc_money:" . $child_site_fc_money);
            Log::DEBUG("update tchehuoren_fc_money:" . $tchehuoren_fc_money);
            Log::DEBUG("update TCtchehuoren_fc_money:" . $tctchehuorenParent_fc_money);
            
            if($orderInfo['pay_price'] >= ($child_site_fc_money +  $tchehuoren_fc_money + $tctchehuorenParent_fc_money)){  

                if($child_site_fc_money > 0){
                    $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);
                    
                    $old_money = 0;
                    if($walletInfo){
                        $old_money = $walletInfo['account_balance'];

                        $updateData = array();
                        $updateData['account_balance']   = $walletInfo['account_balance'] + $child_site_fc_money;
                        $updateData['total_income']   = $walletInfo['total_income'] + $child_site_fc_money;
                        C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
                    }else{
                        $insertData = array();
                        $insertData['site_id']              = $orderInfo['site_id'];
                        $insertData['account_balance']      = $child_site_fc_money;
                        $insertData['total_income']         = $child_site_fc_money;
                        $insertData['add_time']             = TIMESTAMP;
                        C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
                    }

                    $insertData = array();
                    $insertData['site_id']      = $orderInfo['site_id'];
                    $insertData['log_type']     = 1;
                    $insertData['change_money'] = $child_site_fc_money;
                    $insertData['old_money']    = $old_money;
                    if($orderInfo['goods_id'] > 0){
                        $insertData['beizu']        = $goodsInfo['title']."|||ID:".$goodsInfo['id'];
                    }
                    if($orderInfo['needs_id'] > 0){
                        $insertData['beizu']        = cutstr($needsInfo['content'],30,"...")."|||ID:".$needsInfo['id'];
                    }
                    $insertData['order_no']     = $orderInfo['order_no'];
                    $insertData['order_type']   = $orderInfo['order_type'];
                    $insertData['log_ip']       = $_G['clientip'];
                    $insertData['log_time']     = TIMESTAMP;
                    C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData); 
                }
                
                $title = '';
                $type = '';
                if($orderInfo['type'] == 2){
                    $title = $goodsInfo['title'];
                    $type = lang('plugin/tom_tcershou', 'order_type_2');
                }else if($orderInfo['type'] == 3){
                    $title = cutstr($needsInfo['content'],30,"...");
                    $type = lang('plugin/tom_tcershou', 'order_type_3');
                }else if($orderInfo['type'] == 4){
                    $title = $goodsInfo['title'];
                    $type = lang('plugin/tom_tcershou', 'order_type_4');
                }else if($orderInfo['type'] == 5){
                    $title = $goodsInfo['title'];
                    $type = lang('plugin/tom_tcershou', 'order_type_5');
                }else if($orderInfo['type'] == 6){
                    $title = cutstr($needsInfo['content'],30,"...");
                    $type = lang('plugin/tom_tcershou', 'order_type_6');
                }else if($orderInfo['type'] == 7){
                    $title = cutstr($needsInfo['content'],30,"...");
                    $type = lang('plugin/tom_tcershou', 'order_type_7');
                }
                
                $sendTemplateTchehuoren = false;
                if($tchehuoren_fc_money > 0){
                    $sendTemplateTchehuoren = true;
                    
                    $insertData = array();
                    $insertData['order_no']         = $orderInfo['order_no'];
                    $insertData['hehuoren_id']      = $tchehuorenInfo['id'];
                    $insertData['ly_user_id']       = $userInfo['id'];
                    $insertData['child_hehuoren_id'] = 0;
                    $insertData['today_time']       = $nowDayTime;
                    $insertData['week_time']        = $nowWeekTime;
                    $insertData['month_time']       = $nowMonthTime;
                    $insertData['title']            = $title;
                    $insertData['type']             = $type;
                    $insertData['shouyi_price']     = $tchehuoren_fc_money;
                    if($orderInfo['goods_id'] > 0){
                        $insertData['content']        = $goodsInfo['title']."|||ID:".$goodsInfo['id'];
                    }
                    if($orderInfo['needs_id'] > 0){
                        $insertData['content']        = cutstr($needsInfo['content'],30,"...")."|||ID:".$needsInfo['id'];
                    }
                    $insertData['shouyi_status']    = 1;
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                }
                
                $sendTemplateTchehuorenParent = false;
                if($tctchehuorenParent_fc_money > 0){
                    $sendTemplateTchehuorenParent = true;
                    
                    $insertData = array();
                    $insertData['order_no']         = $orderInfo['order_no'];
                    $insertData['hehuoren_id']      = $tctchehuorenParentInfo['id'];
                    $insertData['ly_user_id']       = $userInfo['id'];
                    $insertData['child_hehuoren_id'] = $tchehuorenInfo['id'];
                    $insertData['today_time']       = $nowDayTime;
                    $insertData['week_time']        = $nowWeekTime;
                    $insertData['month_time']       = $nowMonthTime;
                    $insertData['title']            = $title;
                    $insertData['type']             = $type;
                    $insertData['shouyi_price']     = $tctchehuorenParent_fc_money;
                    if($orderInfo['goods_id'] > 0){
                        $insertData['content']        = $goodsInfo['title']."|||ID:".$goodsInfo['id'];
                    }
                    if($orderInfo['needs_id'] > 0){
                        $insertData['content']        = cutstr($needsInfo['content'],30,"...")."|||ID:".$needsInfo['id'];
                    }
                    $insertData['shouyi_status']    = 1;
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                }
                
                if($sendTemplateTchehuoren == true){
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($tchehuorenInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                        $shouyiText = str_replace("{NICKNAME}",$userInfo['nickname'], lang('plugin/tom_tongcheng', 'paynotify_hehuoren_template'));
                        $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                        $shouyiText = str_replace("{TYPE}",$type, $shouyiText);
                        $shouyiText = str_replace("{MONEY}",$tchehuoren_fc_money, $shouyiText);
                        $smsData = array(
                            'first'         => $shouyiText,
                            'keyword1'      => $tchehuorenConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );
                        if(!empty($tchehuorenConfig['template_id'])){
                            $template_id = $tchehuorenConfig['template_id'];
                        }else{
                            $template_id = $tongchengConfig['template_id'];
                        }
                        @$r = $templateSmsClass->sendSms01($tchehuorenInfo['openid'], $template_id, $smsData);
                    }
                }
                
                if($sendTemplateTchehuorenParent == true){
                    
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($tctchehuorenParentInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                        $shouyiText = str_replace("{TCHEHUOREN}",$tchehuorenInfo['xm'], lang('plugin/tom_tongcheng', 'paynotify_hehuorenparent_template'));
                        $shouyiText = str_replace("{NICKNAME}",$userInfo['nickname'], $shouyiText);
                        $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                        $shouyiText = str_replace("{TYPE}",$type, $shouyiText);
                        $shouyiText = str_replace("{MONEY}",$tctchehuorenParent_fc_money, $shouyiText);
                        $smsData = array(
                            'first'         => $shouyiText,
                            'keyword1'      => $tchehuorenConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );
                        if(!empty($tchehuorenConfig['template_id'])){
                            $template_id = $tchehuorenConfig['template_id'];
                        }else{
                            $template_id = $tongchengConfig['template_id'];
                        }
                        @$r = $templateSmsClass->sendSms01($tctchehuorenParentInfo['openid'], $template_id, $smsData);
                    }
                }
            }
            
        }else{
            $adminFc = true;
        }
    }else{
        $adminFc = true;
    }
    
    if($__ShowTcadmin == 1 && $adminFc && $orderInfo['type'] > 1 && $tcershouConfig['zizhandi_fc'] == 1){

        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
        $fc_scale = $tcadminConfig['fc_scale'];
        if($sitesInfo['ershou_fc_scale'] > 0){
            $fc_scale = $sitesInfo['ershou_fc_scale'];
        }
        $fc_money = $orderInfo['pay_price']*($fc_scale/100);
        $fc_money = number_format($fc_money,2);

        Log::DEBUG("update fc_money:" . $fc_money);

        $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);

        $old_money = 0;
        if($walletInfo){
            $old_money = $walletInfo['account_balance'];

            $updateData = array();
            $updateData['account_balance']   = $walletInfo['account_balance'] + $fc_money;
            $updateData['total_income']   = $walletInfo['total_income'] + $fc_money;
            C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
        }else{
            $insertData = array();
            $insertData['site_id']              = $orderInfo['site_id'];
            $insertData['account_balance']      = $fc_money;
            $insertData['total_income']         = $fc_money;
            $insertData['add_time']             = TIMESTAMP;
            C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
        }

        $insertData = array();
        $insertData['site_id']      = $orderInfo['site_id'];
        $insertData['log_type']     = 1;
        $insertData['change_money'] = $fc_money;
        $insertData['old_money']    = $old_money;
        if($orderInfo['goods_id'] > 0){
            $insertData['beizu']        = $goodsInfo['title']."|||ID:".$goodsInfo['id'];
        }
        if($orderInfo['needs_id'] > 0){
            $insertData['beizu']        = cutstr($needsInfo['content'],30,"...")."|||ID:".$needsInfo['id'];
        }
        $insertData['order_no']     = $orderInfo['order_no'];
        $insertData['order_type']   = $orderInfo['order_type'];
        $insertData['log_ip']       = $_G['clientip'];
        $insertData['log_time']     = TIMESTAMP;
        C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData);Log::DEBUG("update fc_end:" . $fc_money);
    }
    # fc end

    if($orderInfo['type'] == 1 && (!empty($tcershouConfig['template_neworder']) || !empty($tcershouConfig['template_buy']))){
        include DISCUZ_ROOT.'./source/plugin/tom_tcershou/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        
        $orderSaleUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['sale_user_id']); 
        $template_sms = lang('plugin/tom_tcershou','template_neworder_first');
        
        if($access_token && !empty($orderSaleUserInfoTmp['openid']) && !empty($tcershouConfig['template_neworder']) ){
            $tomSysOffset = getglobal('setting/timeoffset');
            $templateSmsClass = new esTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$orderInfo['site_id']}&mod=myorder");
            $smsData = array(
                'first'         => lang('plugin/tom_tcershou','template_neworder_first'),
                'keyword1'      => $orderInfo['goods_title'],
                'keyword2'      => $orderInfo['pay_price'],
                'keyword3'      => $orderInfo['xm'],
                'keyword4'      => $orderInfo['tel'],
                'keyword5'      => $orderInfo['order_no'],
                'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
            );
            $r = $templateSmsClass->sendSmsNewOrder($orderSaleUserInfoTmp['openid'],$tcershouConfig['template_neworder'],$smsData);
        }
        
        $orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($orderUserInfoTmp['openid']) && !empty($tcershouConfig['template_buy']) ){
            $tomSysOffset = getglobal('setting/timeoffset');
            $templateSmsClass = new esTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$orderInfo['site_id']}&mod=orderinfo&order_no=".$orderInfo['order_no']);
            $smsData = array(
                'first'         => lang('plugin/tom_tcershou','template_buyorder_first'),
                'keyword1'      => $orderInfo['goods_title'],
                'keyword2'      => $orderInfo['order_no'],
                'keyword3'      => $orderInfo['pay_price'],
                'keyword4'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSmsBuy($orderUserInfoTmp['openid'],$tcershouConfig['template_buy'],$smsData);
        }
    }
    
    if($orderInfo['type'] == 4 && !empty($tongchengConfig['template_id']) && $tcershouConfig['fabu_goods_must_shenhe'] == 1 ){
        $toUser = array();
        $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
        if($toUserTmp && !empty($toUserTmp['openid'])){
            $toUser = $toUserTmp;
        }

        $access_token = $weixinClass->get_access_token();

        if($access_token && !empty($toUser['openid'])  ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$goodsInfo['site_id']}&mod=managerList");
            $smsData = array(
                'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcershou','shenhe_template_first'),
                'keyword1'      => $tcershouConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
        }

        $ershoumanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcershouConfig['ershoumanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($ershoumanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$goodsInfo['site_id']}&mod=managerList");
            $smsData = array(
                'first'         => lang('plugin/tom_tcershou', 'shenhe_template_first'),
                'keyword1'      => $tcershouConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($ershoumanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
    if($orderInfo['type'] == 6 && !empty($tongchengConfig['template_id']) && $tcershouConfig['fabu_needs_must_shenhe'] == 1 ){
        $toUser = array();
        $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
        if($toUserTmp && !empty($toUserTmp['openid'])){
            $toUser = $toUserTmp;
        }

        $access_token = $weixinClass->get_access_token();

        if($access_token && !empty($toUser['openid'])  ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$needsInfo['site_id']}&mod=managerNeedsList");
            $smsData = array(
                'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcershou','shenhe_needs_template_first'),
                'keyword1'      => $tcershouConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
        }

        $ershoumanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcershouConfig['ershoumanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($ershoumanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$needsInfo['site_id']}&mod=managerNeedsList");
            $smsData = array(
                'first'         => lang('plugin/tom_tcershou', 'shenhe_needs_template_first'),
                'keyword1'      => $tcershouConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($ershoumanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
            
}