<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($tcershouConfig['open_fabu_goods_money'] == 1){

    $freeFabuCount = C::t("#tom_tcershou#tom_tcershou_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND type = 1  ");
    $syFreeFabuNum = $tcershouConfig['free_fabu_goods_num'] - $freeFabuCount;
    $syFreeFabuNum = intval($syFreeFabuNum);
    if($syFreeFabuNum < 0){
        $syFreeFabuNum = 0;
    }
    
    $goodsFabuList = array();
    $goods_fabu_list_str = str_replace("\r\n","{n}",$tcershouConfig['goods_fabu_list']);
    $goods_fabu_list_str = str_replace("\n","{n}",$goods_fabu_list_str);
    $goods_fabu_list_arr = explode("{n}", $goods_fabu_list_str);
    $i = 0;
    if(is_array($goods_fabu_list_arr) && !empty($goods_fabu_list_arr)){
        foreach ($goods_fabu_list_arr as $key => $value){
            $arr = explode("|", $value);

            $goodsFabuList[$key]['days']             = $arr[0];
            $goodsFabuList[$key]['price']            = $arr[1];
            $goodsFabuList[$key]['desc']             = $arr[2];
            $goodsFabuList[$key]['pay_score_status'] = 0;
            $goodsFabuList[$key]['pay_score']        = 0;
            $goodsFabuList[$key]['free_status']      = 0;

            if($i == 0 && $syFreeFabuNum > 0){
                $goodsFabuList[$key]['free_status'] = 1;
            }

            if($tcershouConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                $fabu_pay_score = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
                if($fabu_pay_score > 0 && $__UserInfo['score'] >= $fabu_pay_score){
                    $goodsFabuList[$key]['pay_score_status'] = 1;
                    $goodsFabuList[$key]['pay_score'] = $fabu_pay_score;
                }
            }
            $i++;
        }
    }
}

$cateList = C::t('#tom_tcershou#tom_tcershou_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,100);

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$cityList = array();
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

if($__Ios == 0 && $__Android == 0){
    $tongchengConfig['open_many_pic_upload'] = 0;
}

$tcershouConfig['fabu_gonggao_txt'] = str_replace('{YONGJIN}', $tcershouConfig['yongjin_bili'], $tcershouConfig['fabu_gonggao_txt']);

$oldFabuTmp = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_like_list(" AND user_id = {$__UserInfo['id']} "," ORDER BY id DESC ",0,1,'');
$oldFabu = $oldAreaInfo = $oldStreetInfo = array();
$old_area_id = $old_street_id = $old_address = $old_latitude = $old_longitude = $old_xm = $old_tel = $old_wx = '';
if(is_array($oldFabuTmp) && !empty($oldFabuTmp) && $oldFabuTmp[0]['id'] > 0){
    $oldFabu        = $oldFabuTmp[0];
    $old_area_id    = $oldFabu['area_id'];
    $old_street_id  = $oldFabu['street_id'];
    $old_address    = $oldFabu['address'];
    $old_latitude   = $oldFabu['latitude'];
    $old_longitude  = $oldFabu['longitude'];
    $old_xm         = $oldFabu['xm'];
    $old_tel        = $oldFabu['tel'];
    $old_wx         = $oldFabu['wx'];
    
    $oldAreaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($oldFabu['area_id']);
    $oldStreetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($oldFabu['street_id']);
}

$ossBatchUrl   = 'plugin.php?id=tom_tcershou:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcershou:qiniuBatch';
$uploadUrl1    = "plugin.php?id=tom_tcershou&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2    = "plugin.php?id=tom_tcershou&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;
$wxUploadUrl   = "plugin.php?id=tom_tcershou:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";

$payUrl  = "plugin.php?id=tom_tcershou:pay&site={$site_id}";
$jumpUrl = "plugin.php?id=tom_tcershou&site={$site_id}&mod=myfabu";

$subscribeFlag = 0;
$access_token = $weixinClass->get_access_token();
if($tcershouConfig['open_fabu_guanzu']==1 && $__UserInfo['id'] > 0 && !empty($__UserInfo['openid']) && !empty($access_token)){
    $get_user_info_url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token={$access_token}&openid={$__UserInfo['openid']}&lang=zh_CN";
    $return = get_html($get_user_info_url);
    if(!empty($return)){
        $tcContent = json_decode($return,true);
        if(is_array($tcContent) && !empty($tcContent) && isset($tcContent['subscribe'])){
            if($tcContent['subscribe'] == 1){
                $subscribeFlag = 1;
            }else{
                $subscribeFlag = 2;
            }
        }
    }
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcershou:fabu");