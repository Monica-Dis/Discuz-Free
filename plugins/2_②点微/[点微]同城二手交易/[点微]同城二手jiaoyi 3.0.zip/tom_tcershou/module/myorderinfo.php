<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_no  = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';

$orderInfo  = C::t('#tom_tcershou#tom_tcershou_order')->fetch_by_order_no($order_no);
$goodsInfo  = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($orderInfo['goods_id']);

if($goodsInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'fahuo' && submitcheck('kuaidi_type')){

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $kuaidi_type    = isset($_GET['kuaidi_type'])? addslashes($_GET['kuaidi_type']):'';
    $kuaidi_no      = isset($_GET['kuaidi_no'])? addslashes($_GET['kuaidi_no']):'';

    $updateData = array();
    if($__ShowKuaidi == 1){
        $updateData['show_kuaidi']  = 1;
    }else{
        $updateData['show_kuaidi']  = 0;
    }
    $updateData['kuaidi_type']      = $kuaidi_type;
    $updateData['kuaidi_no']        = $kuaidi_no;
    $updateData['order_status']     = 3;
    $updateData['peisong_time']     = TIMESTAMP;
    C::t('#tom_tcershou#tom_tcershou_order')->update($orderInfo['id'],$updateData);

    if(!empty($tcershouConfig['template_fahuo'])){

        include DISCUZ_ROOT.'./source/plugin/tom_tcershou/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();

        $orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 

        if($access_token && !empty($orderUserInfoTmp['openid']) ){
            $templateSmsClass = new esTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=orderinfo&order_no={$order_no}");
            $smsData = array(
                'first'         => lang('plugin/tom_tcershou','template_fahuo_first'),
                'keyword1'      => $orderInfo['order_no'],
                'keyword2'      => $orderInfo['goods_title'],
                'keyword3'      => $orderInfo['goods_num'],
                'keyword4'      => $orderInfo['pay_price'],
                'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
            );
            $r = $templateSmsClass->sendSmsFahuo($orderUserInfoTmp['openid'],$tcershouConfig['template_fahuo'],$smsData);
        }
    }

    echo 200;exit;

}else if($_GET['act'] == 'qianshou' && $_GET['formhash'] == FORMHASH){

    if($orderInfo['peisong_type'] == 1){
        echo 500;exit;
    }
    if($orderInfo['order_status'] == 1){
        echo 501;exit;
    }
   
    $updateData = array();
    $updateData['order_status']     = 4;
    $updateData['hexiao_user_id']   = $__UserInfo['id'];
    $updateData['hexiao_time']      = TIMESTAMP;
    C::t('#tom_tcershou#tom_tcershou_order')->update($orderInfo['id'],$updateData);
    
    if($orderInfo['balance_status'] == 0){
        include DISCUZ_ROOT.'./source/plugin/tom_tcershou/module/balance.php';
    }

    echo 200;exit;

}else if($_GET['act'] == 'allow_refund' && $_GET['formhash'] == FORMHASH){
    
    if($orderInfo['shenqing_refund'] == 1){}else{
        echo 500;exit;
    }

    $updateData = array();
    $updateData['sale_allow_refund']       = 1;
    C::t('#tom_tcershou#tom_tcershou_order')->update($orderInfo['id'],$updateData);
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    
    $orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($orderUserInfoTmp['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=&mod=orderinfo&order_no={$order_no}");
        $smsData = array(
            'first'         => lang('plugin/tom_tcershou','template_allow_refund_first'),
            'keyword1'      => $tongchengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($orderUserInfoTmp['openid'],$tongchengConfig['template_id'],$smsData);
    }
    
    $manageUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($manageUserInfo['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=index");
        $smsData = array(
            'first'         => lang('plugin/tom_tcershou','template_allow_refund_m_first'),
            'keyword1'      => $tongchengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($manageUserInfo['openid'],$tongchengConfig['template_id'],$smsData);
    }
    
    $ershoumanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcershouConfig['ershoumanage_user_id']);
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($ershoumanageUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=index");
        $smsData = array(
            'first'         => lang('plugin/tom_tcershou', 'template_allow_refund_m_first'),
            'keyword1'      => $tcershouConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($ershoumanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
    }

    echo 200;exit;
}

$goodsphotoInfoTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list("AND goods_id = {$goodsInfo['id']} AND type = 1","",0,1);
if(is_array($goodsphotoInfoTmp) && !empty($goodsphotoInfoTmp[0])){
    $picurl = $goodsphotoInfoTmp[0]['picurlTmp'];
}

$hexiaoUserInfo = array();
if($orderInfo['order_status'] == 4){
    $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']); 
}

$showQianshouBtn = 0;
if($orderInfo['order_status'] == 3 && $orderInfo['peisong_time'] > 0){
    if(TIMESTAMP > ($orderInfo['peisong_time'] + 86400 * $tcershouConfig['shop_qianshou_days'])){
        $showQianshouBtn = 1;
    }
}

$showFahuoBox = 0;
if($orderInfo['peisong_type'] == 2 && ($orderInfo['order_status'] == 2 || $orderInfo['order_status'] == 3) ){
    $showFahuoBox = 1;
}

if($orderInfo['show_kuaidi'] == 1 && !empty($orderInfo['kuaidi_type'])){
    $kuaidInfoTmp = C::t("#tom_kuaidi#tom_kuaidi")->fetch_all_list(" AND type = '{$orderInfo['kuaidi_type']}'", 'ORDER BY sort ASC, id DESC',0,1);
}

$kuaidiList = array();
if($orderInfo['peisong_type'] == 2 && $__ShowKuaidi == 1){
    $kuaidiListTmp = C::t("#tom_kuaidi#tom_kuaidi")->fetch_all_list(" ", 'ORDER BY sort ASC, id DESC');
    if(is_array($kuaidiListTmp) && !empty($kuaidiListTmp)){
        foreach($kuaidiListTmp as $key => $value){
            $kuaidiList[$key] = $value;
        }
    }
}

$showPeisongBox = 1;
if($orderInfo['peisong_type'] == 2){
    if($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList)){
        $showPeisongBox = 2;
    }
    $kuaidiSmsList = array();
    if(!empty($orderInfo['kuaidi_no']) && !empty($orderInfo['kuaidi_type']) && $__ShowKuaidi == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_kuaidi/kuaidi.func.php';
        $kuaidiNoArr = explode(' ', $orderInfo['kuaidi_no']);
        if(is_array($kuaidiNoArr) && !empty($kuaidiNoArr)){
            foreach($kuaidiNoArr as $key => $value){
                $value = trim($value);
                if(!empty($value)){
                    $kuaidiArr = query_kuaidi($value, $orderInfo['kuaidi_type']);
                    if($kuaidiArr){
                        $kuaidiSmsList[$key] = $kuaidiArr;
                        $kuaidiSmsList[$key]['kuaidi_no'] = $value;
                    }
                }
            }
        }
    }
}

$fahuoUrl    = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=myorderinfo&act=fahuo&formhash='.$formhash;
$qianshouUrl = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=myorderinfo&act=qianshou&formhash='.$formhash;
$allow_refundUrl = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=myorderinfo&act=allow_refund&formhash='.$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcershou:myorderinfo");