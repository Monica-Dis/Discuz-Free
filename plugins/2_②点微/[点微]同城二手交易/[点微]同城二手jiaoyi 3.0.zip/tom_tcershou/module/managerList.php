<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    if($__UserInfo['id'] != $tcershouConfig['ershoumanage_user_id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=index");exit;
    }
}
# check end

if($_GET['act'] == 'shenhe' && submitcheck('goods_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $goods_id       = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0? intval($_GET['shenhe_status']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $goodsInfo = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($goods_id);
    
    $updateData = array();
    $updateData['shenhe_status'] = $shenhe_status;
    if($shenhe_status == 1){
        $updateData['status']    = 1;
    }
    C::t('#tom_tcershou#tom_tcershou_goods')->update($goods_id,$updateData);
    
    update_goods_tongcheng($goods_id);
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']);
    
    if($goodsInfo){
        
        if($shenhe_status == 1){
            $shenhe = str_replace('{TITLE}', $goodsInfo['title'], lang('plugin/tom_tcershou', 'template_tcershou_shenhe_ok'));
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcershou&site='.$site_id.'&mod=goodsinfo&goods_id='.$goodsInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }else if($shenhe_status == 3){
            $shenhe = str_replace('{TITLE}', $goodsInfo['title'], lang('plugin/tom_tcershou', 'template_tcershou_shenhe_no'));
            $tzShenhe = $shenhe.'<br/><font color="#8e8e8e">'.$content.'</font><br/><a href="plugin.php?id=tom_tcershou&site='.$site_id.'&mod=edit&goods_id='.$goodsInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }
        
        $insertData = array();
        $insertData['user_id']      = $toUser['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcershouConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    
    $nextSmsTime = $toUser['last_smstp_time'] + 0;
    if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime ){
        if($shenhe_status == 1){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$goodsInfo['site_id']}&mod=goodsinfo&goods_id=".$goodsInfo['id']);
        }else if($shenhe_status == 3){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$goodsInfo['site_id']}&mod=edit&goods_id=".$goodsInfo['id']);
        }
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcershouConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $updateData = array();
            $updateData['last_smstp_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=managerList&keyword=".urlencode(trim($keyword));
    
    echo $url;exit;
    
}else if($_GET['act'] == 'del' && submitcheck('goods_id')){
    
    $goods_id = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    
    C::t('#tom_tcershou#tom_tcershou_goods')->delete_by_id($goods_id);
    C::t('#tom_tcershou#tom_tcershou_photo')->delete_by_goods_id($goods_id);
    C::t('#tom_tcershou#tom_tcershou_collect')->delete_by_goods_id($goods_id);
    C::t('#tom_tcershou#tom_tcershou_pinglun')->delete_by_goods_id($goods_id);
    C::t('#tom_tcershou#tom_tcershou_pinglun_reply')->delete_by_goods_id($goods_id);
    
    delete_goods_tongcheng($goods_id);
    
    echo 200;exit;

}else if($_GET['act'] == 'shenhe_show'){
    
    $goods_id    = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    $fromtype    = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage    = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $goodsInfo = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($goods_id);

    $goods_shenhe_fail_str = str_replace("\r\n","{n}",$tcershouConfig['goods_shenhe_fail_text']); 
    $goods_shenhe_fail_str = str_replace("\n","{n}",$goods_shenhe_fail_str);
    $goodsShenheFailArray  = explode("{n}", $goods_shenhe_fail_str);
    
    $ajaxShenheUrl = "plugin.php?id=tom_tcershou&site={$site_id}&mod=managerList&act=shenhe&";
    $backUrl = "plugin.php?id=tom_tcershou&site={$site_id}&mod=managerList&type={$fromtype}&page={$frompage}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcershou:managerShenhe");exit;
    
}

$keyword  = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page     = intval($_GET['page'])>0? intval($_GET['page']):1;
$type     = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = "  AND (pay_status = 0 OR pay_status = 2)";
if($type == 1){
    $where.= " AND shenhe_status=2 ";
}
if($type == 2){
    $where.= " AND shenhe_status=3 ";
}
if($__UserInfo['groupid'] == 2){
    $where.= " AND site_id={$site_id} ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_count(" {$where} ",$keyword);
$goodsListTmp = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_like_list(" {$where} "," ORDER BY refresh_time DESC,id DESC ",$start,$pagesize,$keyword);
$goodsList = array();
foreach ($goodsListTmp as $key => $value) {
    $goodsList[$key] = $value;

    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
    $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
    
    $photoInfoTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list(" AND goods_id = {$value['id']} AND type = 1 "," ORDER BY id ASC ",0,1);
    if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
        $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
    }
    
    $goodsList[$key]['picurl']          = $picurlTmp;
    $goodsList[$key]['userInfo']        = $userInfoTmp;
    $goodsList[$key]['areaInfo']        = $areaInfoTmp;
    $goodsList[$key]['streetInfo']      = $streetInfoTmp;
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage  = $page - 1;
$nextPage = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tcershou&site={$site_id}&mod=managerList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tcershou&site={$site_id}&mod=managerList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];
$pageUrl     = "plugin.php?id=tom_tcershou&site={$site_id}&mod=managerList&type={$type}&keyword=".$_GET['keyword'];

$ajaxShenheUrl = "plugin.php?id=tom_tcershou&site={$site_id}&mod=managerList&act=shenhe&&formhash=".$formhash;
$ajaxDelUrl    = "plugin.php?id=tom_tcershou&site={$site_id}&mod=managerList&act=del&&formhash=".$formhash;
$searchUrl     = "plugin.php?id=tom_tcershou&site={$site_id}&mod=managerList&act=get_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcershou:managerList");