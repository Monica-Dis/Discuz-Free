<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);

if($orderInfo['pay_price'] >= 0.1){
    
    $yongjin_bili = $tcershouConfig['yongjin_bili'];
    $goodsInfo = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($orderInfo['goods_id']);
    
    if($yongjin_bili <= 100){
       
        $orderUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']); 
        
        if($orderInfo['pay_price'] > $tcershouConfig['yongjin_base']){
            $pt_money = $orderInfo['pay_price']*($yongjin_bili/100);
            $pt_money = number_format($pt_money,2, '.', '');
            $money = $orderInfo['pay_price'] - $pt_money;
        }else{
            $money = $orderInfo['pay_price'];
        }
        
        $insertData = array();
        $insertData['user_id']          = $orderUserInfo['id'];
        $insertData['type_id']          = 4;
        $insertData['change_money']     = $money;
        $insertData['old_money']        = $orderUserInfo['money'];
        $insertData['tag']              = lang('plugin/tom_tcershou', 'ershou_money_log_tag');
        $insertData['beizu']            = lang('plugin/tom_tcershou', 'beizu_order_no') . $orderInfo['order_no'].'|||'.$goodsInfo['title'];
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);

        DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$money} WHERE id='{$orderUserInfo['id']}'", 'UNBUFFERED');
            
    }
    
    $updateData = array();
    $updateData['balance_status'] = 1;
    C::t('#tom_tcershou#tom_tcershou_order')->update($orderInfo['id'],$updateData);
}