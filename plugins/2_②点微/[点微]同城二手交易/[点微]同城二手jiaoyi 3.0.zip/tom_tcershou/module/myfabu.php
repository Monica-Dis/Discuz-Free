<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';

$whereStr = " AND user_id = {$__UserInfo['id']} ";

if($type == 1){
    $whereStr.=" AND status = 1 AND shenhe_status = 1 ";
}else if($type == 2){
    $whereStr.=" AND finish = 1 ";
}else if($type == 3){
    $whereStr.=" AND (shenhe_status = 2 OR shenhe_status = 3 OR status != 1) ";
}

$pagesize     = 8;
$start        = ($page - 1)*$pagesize;
$order        = " ORDER BY refresh_time DESC,id DESC ";
$count        = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_count($whereStr,$keyword);
$goodsListTmp = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_like_list($whereStr,$order,$start,$pagesize,$keyword);
$goodsList = array();
foreach ($goodsListTmp as $key => $value){
    $goodsList[$key] = $value;
    
    $photoInfoTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list(" AND goods_id = {$value['id']} AND type = 1 "," ORDER BY id ASC ",0,1);
    if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
        $picurl = $photoInfoTmp[0]['picurlTmp'];
    }
    
    if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
        $updateData = array();
        $updateData['top_status']   = 0;
        $updateData['top_time']     = 0;
        C::t('#tom_tcershou#tom_tcershou_goods')->update($value['id'], $updateData);
        update_goods_tongcheng($value['id']);
    }
    
    if($value['expire_status'] == 1 && $value['expire_time'] <= TIMESTAMP){
        $updateData = array();
        $updateData['expire_status']    = 2;
        $updateData['expire_time']      = 0;
        if($tcershouConfig['goods_expire_type'] == 1){
            $updateData['status']           = 0;
        }
        C::t('#tom_tcershou#tom_tcershou_goods')->update($value['id'], $updateData);
        update_goods_tongcheng($value['id']);
    }
    
    $goodsList[$key]['picurl'] = $picurl;
    $goodsList[$key]['link']   = 'plugin.php?id=tom_tcershou&site='.$value['site_id'].'&mod=goodsinfo&goods_id='.$value['id'];
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tcershou&site={$site_id}&mod=myfabu&type={$type}&page={$prePage}&keyword={$keyword}";
$nextPageUrl = "plugin.php?id=tom_tcershou&site={$site_id}&mod=myfabu&type={$type}&page={$nextPage}&keyword={$keyword}";
$pageUrl     = "plugin.php?id=tom_tcershou&site={$site_id}&mod=myfabu&type={$type}&keyword={$keyword}";

$ajaxUpdateFinishUrl = "plugin.php?id=tom_tcershou:ajax&site={$site_id}&act=updateGoodsFinish&&formhash=".$formhash;
$ajaxUpdateStatusUrl = "plugin.php?id=tom_tcershou:ajax&site={$site_id}&act=updateStatus&&formhash=".$formhash;
$ajaxRefreshgoodsUrl = "plugin.php?id=tom_tcershou:ajax&site={$site_id}&act=refreshGoods&&formhash=".$formhash;

$searchUrl  = "plugin.php?id=tom_tcershou:ajax&site={$site_id}&act=get_myfabu_search_url&type={$type}&keyword={$keyword}";
$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tcershou&site=".$site_id."&mod=myfabu";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcershou:myfabu");