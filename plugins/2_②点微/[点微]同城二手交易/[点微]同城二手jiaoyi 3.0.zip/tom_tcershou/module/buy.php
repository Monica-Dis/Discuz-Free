<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id         = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
$address_id       = isset($_GET['address_id'])? intval($_GET['address_id']):0;

$goodsInfo = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($goods_id);

$pay_price = $goodsInfo['price'];
$pay_price_arr = array();
for($i=1;$i<=100;$i++){
    $pay_price_arr[$i] = ($pay_price*$i);
}
$express_price = $goodsInfo['express_price'];

if($goodsInfo['peisong_type'] == 2){
    $pay_price = $pay_price + $express_price;
}

$goodsphotoInfoTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list("AND goods_id = {$goods_id} AND type = 1","",0,1);
if(is_array($goodsphotoInfoTmp) && !empty($goodsphotoInfoTmp[0])){
    $picurl = $goodsphotoInfoTmp[0]['picurlTmp'];
}

$address_back_url = $weixinClass->get_url();
$address_back_url = preg_replace('/&address_id=[0-9]*/', '', $address_back_url);
$address_back_url = urlencode($address_back_url);

$setAddressStatus = 0;
$setAddressUrl = '';
$addressListCount = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_count(" AND uid={$__MemberInfo['uid']} ");
if($addressListCount == 0){
    $setAddressStatus = 1;
    $setAddressUrl = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=address&act=add&buying=1&address_back_url={$address_back_url}";
}
$addressInfo = array();
$addressInfoTmp = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
if($addressInfoTmp && !empty($addressInfoTmp['id'])){
    $address_id  = $addressInfoTmp['id'];
    $addressInfo = $addressInfoTmp;
}else{
    $defaultAddressList = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_list(" AND uid={$__MemberInfo['uid']} AND default_id=1 ","ORDER BY id DESC",0,1);
    if($defaultAddressList && !empty($defaultAddressList['0']['id'])){
        $address_id = $defaultAddressList['0']['id'];
        $addressInfo = $defaultAddressList['0'];
    }else{
        $setAddressStatus = 1;
        $setAddressUrl = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=address&act=add&buying=1&address_back_url={$address_back_url}";
    }
}
$changeAddressUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=address&buying=1&address_id={$address_id}&address_back_url={$address_back_url}";

$orderListTmp  = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_list(" AND goods_id={$goodsInfo['id']} AND order_status=1 "," ORDER BY id DESC ",0,20);
if(is_array($orderListTmp) && !empty($orderListTmp)){
    foreach ($orderListTmp as $key => $value){
        if($value['order_status'] == 1){
            if((TIMESTAMP - $value['order_time']) > 3600){
                DB::query("UPDATE ".DB::table('tom_tcershou_goods')." SET sale_num=sale_num - {$value['goods_num']}, stock_num=stock_num + {$value['goods_num']} WHERE id='{$value['goods_id']}' ", 'UNBUFFERED');
                DB::query("UPDATE ".DB::table('tom_tcershou_order')." SET order_status=5 WHERE id='{$value['id']}' ", 'UNBUFFERED');
            }
        }
    }
}

$noPayOrderListTmp  = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_list(" AND goods_id={$goodsInfo['id']} AND user_id={$__UserInfo['id']} AND order_status=1 "," ORDER BY id DESC ",0,10);
$isHaveNoPay = 0;
if(is_array($noPayOrderListTmp) && !empty($noPayOrderListTmp)){
    foreach ($noPayOrderListTmp as $key => $value){
        if($value['order_status'] == 1){
            if((TIMESTAMP - $value['order_time']) > 3600){
                DB::query("UPDATE ".DB::table('tom_tcershou_goods')." SET sale_num=sale_num - {$value['goods_num']}, stock_num=stock_num + {$value['goods_num']} WHERE id='{$value['goods_id']}' ", 'UNBUFFERED');
                DB::query("UPDATE ".DB::table('tom_tcershou_order')." SET order_status=5 WHERE id='{$value['id']}' ", 'UNBUFFERED');
            }else{
                $isHaveNoPay = 1;
            }
        }
    }
}

$xm = $tel = "";
if($goodsInfo['peisong_type'] == 2 || $goodsInfo['peisong_type'] == 3){
    $userOrderTmp  = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND peisong_type = 2 AND order_status IN(2,3,4) "," ORDER BY id DESC ",0,1);
}else{
    $userOrderTmp  = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND order_status IN(2,3,4) "," ORDER BY id DESC ",0,1);
}
if(is_array($userOrderTmp) && !empty($userOrderTmp) && !empty($userOrderTmp[0]['tel'])){
    $xm = $userOrderTmp[0]['xm'];
    $tel = $userOrderTmp[0]['tel'];
}
if(empty($tel)){
    $tel = $__UserInfo['tel'];
}
$open_wx_map = 0;
if($__IsWeixin == 1 && $tcershouConfig['open_wx_map'] == 1){
    $open_wx_map = 1;
}

$baiduMapToName = $goodsInfo['title'];
$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
$baiduMapToName = urlencode($baiduMapToName);
$baiduMapUrl = "http://api.map.baidu.com/marker?location={$goodsInfo['latitude']},{$goodsInfo['longitude']}&title={$baiduMapToName}&content=&output=html";

$showMustPhoneBtn = 0;
if($tcershouConfig['buy_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$buyUrl = "plugin.php?id=tom_tcershou:buy&site={$site_id}&act=pay_price";
    
$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcershou:buy");