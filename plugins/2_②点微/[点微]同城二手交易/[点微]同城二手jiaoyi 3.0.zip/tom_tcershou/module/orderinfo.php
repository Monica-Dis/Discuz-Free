<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_no   = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';

$orderInfo      = C::t('#tom_tcershou#tom_tcershou_order')->fetch_by_order_no($order_no);
$goodsInfo      = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($orderInfo['goods_id']);
$saleUserInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']); 

if($orderInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'qianshou' && $_GET['formhash'] == FORMHASH){

    if($orderInfo['peisong_type'] == 1){
        echo 500;exit;
    }
    if($orderInfo['order_status'] == 1){
        echo 501;exit;
    }

    $updateData = array();
    $updateData['order_status']     = 4;
    $updateData['hexiao_user_id']   = $__UserInfo['id'];
    $updateData['hexiao_time']      = TIMESTAMP;
    C::t('#tom_tcershou#tom_tcershou_order')->update($orderInfo['id'],$updateData);
    
    if($orderInfo['balance_status'] == 0){
        include DISCUZ_ROOT.'./source/plugin/tom_tcershou/module/balance.php';
    }

    echo 200;exit;

}else if($_GET['act'] == 'refund' && submitcheck('shenqing_refund_msg')){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    if($orderInfo['shenqing_refund'] == 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    if($orderInfo['order_status'] == 2 || $orderInfo['order_status'] == 3){
    }else{
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }

    $shenqing_refund_msg        = isset($_GET['shenqing_refund_msg'])? addslashes($_GET['shenqing_refund_msg']):'';

    $updateData = array();
    $updateData['shenqing_refund']       = 1;
    $updateData['shenqing_refund_msg']   = $shenqing_refund_msg;
    C::t('#tom_tcershou#tom_tcershou_order')->update($orderInfo['id'],$updateData);

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($saleUserInfo['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=&mod=myorderinfo&order_no={$order_no}");
        $smsData = array(
            'first'         => lang('plugin/tom_tcershou','shenhe_template_refund_first'),
            'keyword1'      => $tongchengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($saleUserInfo['openid'],$tongchengConfig['template_id'],$smsData);
    }

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'cancel_refund' && submitcheck('order_no')){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    if($orderInfo['shenqing_refund'] == 1){}else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    $updateData = array();
    $updateData['shenqing_refund']       = 0;
    C::t('#tom_tcershou#tom_tcershou_order')->update($orderInfo['id'],$updateData);
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($saleUserInfo['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=&mod=myorderinfo&order_no={$order_no}");
        $smsData = array(
            'first'         => lang('plugin/tom_tcershou','shenhe_template_cancel_refund_first'),
            'keyword1'      => $tongchengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($saleUserInfo['openid'],$tongchengConfig['template_id'],$smsData);
    }

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
}

$goodsphotoInfoTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list("AND goods_id = {$goodsInfo['id']} AND type = 1","",0,1);
if(is_array($goodsphotoInfoTmp) && !empty($goodsphotoInfoTmp[0])){
    $picurl = $goodsphotoInfoTmp[0]['picurlTmp'];
}

$hexiaoUserInfo = array();
if($orderInfo['order_status'] == 4){
    $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']); 
}

$showQrcodeBox = 0;
if($orderInfo['order_status'] == 2 ){
    $showQrcodeBox = 1;
}

if($orderInfo['peisong_type'] == 1){
    $qrcodeImg = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($_G['siteurl']."plugin.php?id=tom_tcershou&site={$site_id}&mod=orderhexiao&hexiao_no={$orderInfo['hexiao_no']}");
}

if($orderInfo['show_kuaidi'] == 1 && !empty($orderInfo['kuaidi_type'])){
    $kuaidInfoTmp = C::t("#tom_kuaidi#tom_kuaidi")->fetch_all_list(" AND type = '{$orderInfo['kuaidi_type']}'", 'ORDER BY sort ASC, id DESC',0,1);
}

$kuaidiSmsList = array();
if(!empty($orderInfo['kuaidi_no']) && !empty($orderInfo['kuaidi_type']) && $__ShowKuaidi == 1 && $orderInfo['show_kuaidi'] == 1){
    include DISCUZ_ROOT.'./source/plugin/tom_kuaidi/kuaidi.func.php';
    $kuaidiNoArr = explode(' ', $orderInfo['kuaidi_no']);
    if(is_array($kuaidiNoArr) && !empty($kuaidiNoArr)){
        foreach($kuaidiNoArr as $key => $value){
            $value = trim($value);
            if(!empty($value)){
                $kuaidiArr = query_kuaidi($value, $orderInfo['kuaidi_type']);
                if($kuaidiArr){
                    $kuaidiSmsList[$key] = $kuaidiArr;
                    $kuaidiSmsList[$key]['kuaidi_no'] = $value;
                }
            }
        }
    }
}

$qianshouUrl = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=orderinfo&act=qianshou&formhash='.$formhash;
$refundUrl   = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=orderinfo&act=refund';
$cancel_refundUrl   = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=orderinfo&act=cancel_refund';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcershou:orderinfo");