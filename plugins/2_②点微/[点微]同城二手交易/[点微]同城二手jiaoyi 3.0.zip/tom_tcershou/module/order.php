<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type = intval($_GET['type'])> 0? intval($_GET['type']):0;
$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$whereStr = " AND user_id = {$__UserInfo['id']} AND type = 1";
if($type == 1){
    $whereStr .= " AND order_status = 1 ";
}else if($type == 2){
    $whereStr .= " AND order_status = 2 ";
}else if($type == 3){
    $whereStr .= " AND order_status = 3 ";
}else if($type == 4){
    $whereStr .= " AND order_status = 4";
}else if($type == 5){
    $whereStr .= " AND order_status = 5";
}else if($type == 6){
    $whereStr .= " AND order_status = 6";
}

$orderStr = " ORDER BY order_time DESC,id DESC ";

$pagesize = 10;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_count($whereStr);
$orderListTmp = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);
$orderList = array();
foreach ($orderListTmp as $key => $value){

    $goodsInfoTmp = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($value['goods_id']);

    $orderList[$key] = $value;
    $goodsphotoInfoTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list("AND goods_id = {$value['goods_id']} AND type = 1","",0,1);
    if(is_array($goodsphotoInfoTmp) && !empty($goodsphotoInfoTmp[0])){
        $picurlTmp = $goodsphotoInfoTmp[0]['picurlTmp'];
    }
    
    $orderList[$key]['picurl']    = $picurlTmp;
    $orderList[$key]['goodsInfo'] = $goodsInfoTmp;

    if($value['order_status'] == 1){
        if((TIMESTAMP - $value['order_time']) > 3590){
            DB::query("UPDATE ".DB::table('tom_tcershou_goods')." SET sale_num=sale_num-{$value['goods_num']}, stock_num=stock_num+{$value['goods_num']} WHERE id='{$value['goods_id']}' ", 'UNBUFFERED');
            DB::query("UPDATE ".DB::table('tom_tcershou_order')." SET order_status=5 WHERE id='{$value['id']}' ", 'UNBUFFERED');
            $orderList[$key]['order_status'] = 5;
        }
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum  = ceil($count/$pagesize);
$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tcershou&site={$site_id}&mod=order&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcershou&site={$site_id}&mod=order&type={$type}&page={$nextPage}";
$pageUrl     = "plugin.php?id=tom_tcershou&site={$site_id}&mod=order&type={$type}";

$payUrl        = "plugin.php?id=tom_tcershou:buy&site={$site_id}&act=pay&user_id={$__UserInfo['id']}&formhash={$formhash}";
$ajaxCancelUrl = "plugin.php?id=tom_tcershou:buy&site={$site_id}&act=cancelpay&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcershou:order");