<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       =  intval($_GET['type'])> 0? intval($_GET['type']):0;
$goods_id   = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

$whereStr   = " AND sale_user_id = {$__UserInfo['id']} AND type = 1 ";

if(!empty($goods_id)){
    $whereStr.= " AND goods_id={$goods_id} ";
}

if($type == 1){
    $whereStr.=" AND order_status=1 ";
}else if($type == 2){
    $whereStr.=" AND order_status=2 ";
}else if($type == 3){
    $whereStr.=" AND order_status=3 ";
}else if($type == 4){
    $whereStr.=" AND order_status=4 ";
}else if($type == 5){
    $whereStr.=" AND order_status=5 ";
}else if($type == 6){
    $whereStr.=" AND order_status=6 ";
}

$orderStr = " ORDER BY order_time DESC,id DESC ";

$pagesize = 10;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_count($whereStr);
$orderListTmp = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);
$orderList = array();
foreach ($orderListTmp as $key => $value){

    $orderList[$key] = $value;
    $goodsInfoTmp = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($value['goods_id']);
    
    $photoInfoTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list(" AND goods_id = {$value['goods_id']} AND type = 1 "," ORDER BY id ASC ",0,1);
    if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
        $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
    }
    
    $orderList[$key]['picurl']    = $picurlTmp;
    $orderList[$key]['goodsInfo'] = $goodsInfoTmp;

}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum  = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}
$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tcershou&site={$site_id}&mod=myorder&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcershou&site={$site_id}&mod=myorder&type={$type}&page={$nextPage}";
$pageUrl     = "plugin.php?id=tom_tcershou&site={$site_id}&mod=myorder&type={$type}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcershou:myorder");