<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$needs_id  = intval($_GET['needs_id'])>0? intval($_GET['needs_id']):0;

$needsInfo = C::t("#tom_tcershou#tom_tcershou_needs")->fetch_by_id($needs_id);
$cateInfo  = C::t("#tom_tcershou#tom_tcershou_cate")->fetch_by_id($needsInfo['cate_id']);

if($needsInfo['top_status'] == 1 && $needsInfo['top_time'] <= TIMESTAMP){
    $updateData = array();
    $updateData['top_status']   = 0;
    $updateData['top_time']     = 0;
    C::t("#tom_tcershou#tom_tcershou_needs")->update($needs_id, $updateData);
    $needsInfo['top_status'] = 0;
}

$needsTopList = array();
$needs_top_list_str = str_replace("\r\n","{n}",$tcershouConfig['needs_top_list']); 
$needs_top_list_str = str_replace("\n","{n}",$needs_top_list_str);
$needs_top_list_arr = explode("{n}", $needs_top_list_str);
if(is_array($needs_top_list_arr) && !empty($needs_top_list_arr)){
    foreach ($needs_top_list_arr as $key => $value){
        $arr = array();
        $needsTopList[$key] = $arr = explode("|", $value);
        $needsTopList[$key]['score_pay'] = 0;
        $needsTopList[$key]['score'] = 0;

        if($tcershouConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $scorePayNum = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($scorePayNum > 0 && $__UserInfo['score'] >= $scorePayNum){
                $needsTopList[$key]['score'] = $scorePayNum;
                $needsTopList[$key]['score_pay'] = 1;
            }
        }

    }
}

$payTopUrl = "plugin.php?id=tom_tcershou:pay&site={$site_id}&act=needs_top_pay&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcershou:buyneeds");