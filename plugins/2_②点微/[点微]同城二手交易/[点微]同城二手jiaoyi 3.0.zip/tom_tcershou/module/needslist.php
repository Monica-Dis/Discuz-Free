<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword            = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$cate_id            = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$user_id            = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):1;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$whereStr = ' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($cate_id)){
    $whereStr.= " AND cate_id={$cate_id} ";
}
if($area_id > 0){
    $whereStr.= " AND area_id={$area_id} ";
}
if($street_id > 0){
    $whereStr.= " AND street_id={$street_id} ";
}
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}

if($paixu_type == 1){
    $orderStr = "ORDER BY top_status DESC,top_time DESC,refresh_time DESC,id DESC";
}elseif($paixu_type == 2){
    $orderStr = " ORDER BY refresh_time DESC,top_status DESC,top_time DESC,id DESC";
}elseif($paixu_type == 3){
    $orderStr = " ORDER BY clicks DESC,top_status DESC,top_time DESC,id DESC";
}

$pagesize       = $pagesize;
$start          = ($page - 1)*$pagesize;

if($paixu_type == 4 && !empty($latitude) && !empty($longitude)){
    $needsListTmp  = C::t('#tom_tcershou#tom_tcershou_needs')->fetch_all_nearby_list($whereStr,$start,$pagesize,$latitude,$longitude);
}else{
    $needsListTmp  = C::t('#tom_tcershou#tom_tcershou_needs')->fetch_all_like_list($whereStr,$orderStr,$start,$pagesize,$keyword);
}

$needsList = array();
foreach ($needsListTmp as $key => $value){

    $needsList[$key] = $value;

    $userInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $cateInfoTmp   = C::t('#tom_tcershou#tom_tcershou_cate')->fetch_by_id($value['cate_id']);
    $areaInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
    $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
    $needsList[$key]['userInfo']   = $userInfoTmp;
    $needsList[$key]['cateInfo']   = $cateInfoTmp;
    $needsList[$key]['areaInfo']   = $areaInfoTmp;
    $needsList[$key]['streetInfo'] = $streetInfoTmp;
    $needsList[$key]['link'] = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=needsinfo&needs_id='.$value['id'];

}

if(is_array($needsList) && !empty($needsList)){
    foreach ($needsList as $key => $val){
        $outStr .= '<a href="'.$val['link'].'">';
        $outStr .= '<div class="needs-item">';
            $outStr .= '<div class="needs-item_top dislay-flex">';
                $outStr .= '<div class="needs-item_top_left">';
                    $outStr .= '<img src="'.$val['userInfo']['picurl'].'">';
                $outStr .= '</div>';
                $outStr .= '<div class="needs-item_top_right">';
                    $outStr .= '<div class="needs-xm">';
                        if($val['top_status'] == 1){
                             $outStr.= '<span class="top">'.lang('plugin/tom_tongcheng', 'top').'</span>';
                        }
                        $outStr .= '<span class="right">'.$val['userInfo']['nickname'].'</span>';
                    $outStr .= '</div>';
                    $outStr .= '<div class="needs-address dislay-flex">';
                        if($val['area_id'] > 0){
                            $outStr .= '<span class="needs-area">'.$val['areaInfo']['name'].$val['streetInfo']['name'].'</span>';
                        }
                        if($val['area_id'] > 0){
                            $outStr .= '<span class="needs-time area">'.dgmdate($val['add_time'], 'u','9999','m-d H:i').'</span>';
                        }else{
                            $outStr .= '<span class="needs-time">'.dgmdate($val['add_time'], 'u','9999','m-d H:i').'</span>';
                        }
                        if($paixu_type == 4 && !empty($latitude) && !empty($longitude)){
                            $juli = tomGetDistance($longitude, $latitude, $val['longitude'], $val['latitude']);
                            $outStr .= '<span class="needs-time area" style="border-left: 1px solid #9a9a9a;margin-left: 8px;">'.$juli.'km</span>';
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
                $outStr .= '<div class="needs-item_top_cate">';
                    $outStr .= '<span class="needs-cate" style="color: '.$tcershouConfig['template_color'].';">'.$val['cateInfo']['name'].'</span>';
                $outStr .= '</div>';
            $outStr .= '</div>';
            $outStr .= '<div class="needs-item_content">';
                $outStr .= '<div class="needs-item_content_msg">'.$val['content'].'</div>';
            $outStr .= '</div>';
            $outStr .= '<div class="needs-item_bottom dislay-flex">';
                $outStr .= '<div class="needs_price flex">';
                    $outStr .= '<span class="left">'.lang('plugin/tom_tcershou','needslist_price').'</span>';
                    if($val['price'] > 0){
                        $outStr .= '<span class="icon">'.lang('plugin/tom_tcershou','yuan_ico').'</span>';
                        $outStr .= '<span class="right">'.$val['price'].'</span>';
                    }else{
                        $outStr .= '<span class="no_price">'.lang('plugin/tom_tcershou','needslist_no_price').'</span>';
                    }
                $outStr .= '</div>';
                if($val['finish'] == 1){
                    $outStr .= '<div class="needs_finish">';
                        $outStr .= '<span>'.lang('plugin/tom_tcershou','needslist_finish').'</span>';
                    $outStr .= '</div>';
                }else{
                    $outStr .= '<div class="needs_contact">';
                        $outStr .= '<span>'.lang('plugin/tom_tcershou','needslist_contact').'</span>';
                    $outStr .= '</div>';
                }
            $outStr .= '</div>';
        $outStr .= '</div>';
        $outStr .= '</a>';
    }
}else{
    $outStr = '205';
}
$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;