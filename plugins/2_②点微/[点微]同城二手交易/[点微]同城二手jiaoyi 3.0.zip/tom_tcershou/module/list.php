<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword            = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$cate_id            = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$user_id            = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$chengse_ids        = isset($_GET['chengse_ids'])? addslashes($_GET['chengse_ids']):'';
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):1;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$latitude  = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$whereStr = ' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($cate_id)){
    $whereStr.= " AND cate_id={$cate_id} ";
}
if($area_id > 0){
    $whereStr.= " AND area_id={$area_id} ";
}
if($street_id > 0){
    $whereStr.= " AND street_id={$street_id} ";
}
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}
if(!empty($chengse_ids)){
    $whereStr.= " AND chengse_id IN ({$chengse_ids}) ";
}
if($tcershouConfig['open_finish_paixu'] == 1){
    if($paixu_type == 1){
        $orderStr = "ORDER BY top_status DESC,top_time DESC,finish ASC,refresh_time DESC,id DESC";
    }elseif($paixu_type == 2){
        $orderStr = " ORDER BY refresh_time DESC,top_status DESC,top_time DESC,id DESC";
    }elseif($paixu_type == 3){
        $orderStr = " ORDER BY clicks DESC,top_status DESC,top_time DESC,id DESC";
    }
}else{
    if($paixu_type == 1){
        $orderStr = "ORDER BY top_status DESC,top_time DESC,refresh_time DESC,id DESC";
    }elseif($paixu_type == 2){
        $orderStr = " ORDER BY refresh_time DESC,top_status DESC,top_time DESC,id DESC";
    }elseif($paixu_type == 3){
        $orderStr = " ORDER BY clicks DESC,top_status DESC,top_time DESC,id DESC";
    }
}

$pagesize   = $pagesize;
$start      = ($page - 1)*$pagesize;

if($paixu_type == 4 && !empty($latitude) && !empty($longitude)){
    $tcershouListTmp  = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_nearby_list($whereStr,$start,$pagesize,$latitude,$longitude);
}else{
    $tcershouListTmp  = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_all_like_list($whereStr,$orderStr,$start,$pagesize,$keyword);
}

$tcershouList = array();
foreach ($tcershouListTmp as $key => $value){

    $tcershouList[$key] = $value;
    
    $photoInfoTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list(" AND goods_id = {$value['id']} AND type = 1 "," ORDER BY id ASC ",0,1);
    if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
        $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
    }
    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $tcershouList[$key]['userInfo'] = $userInfoTmp;
    $tcershouList[$key]['picurl'] = $picurlTmp;
    $tcershouList[$key]['link'] = 'plugin.php?id=tom_tcershou&site='.$site_id.'&mod=goodsinfo&goods_id='.$value['id'];
    
}

if(is_array($tcershouList) && !empty($tcershouList)){
    foreach ($tcershouList as $key => $val){
        $outStr .= '<a class="goods-item" href="'.$val['link'].'">';
            $outStr .= '<div class="goods-pic">';
                $outStr .= '<img src="'.$val['picurl'].'">';
                if($val['finish'] == 1){
                    $outStr .= '<img class="goods-finish" src="source/plugin/tom_tcershou/images/finish_ico1.png">';
                }elseif($val['expire_status'] == 2){
                    $outStr .= '<img class="goods-finish" src="source/plugin/tom_tcershou/images/over_ico.png">';
                }elseif($val['video_url']){
                    $outStr .= '<img class="goods-video" src="source/plugin/tom_tcershou/images/icon_play.png">';
                }
            $outStr .= '</div>';
            $outStr .= '<div class="goods-cont">';
                $outStr .= '<div class="goods_title">';
                    if($val['top_status'] == 1){
                         $outStr.= '<span class="top">'.lang('plugin/tom_tongcheng', 'top').'</span>';
                    }
                    $outStr .= $val['title'];
                $outStr .= '</div>';
                $outStr .= '<div class="goods-price dislay-flex">';
                    $outStr .= '<div class="price">';
                        if($val['price'] > 0){
                            $outStr .= '<span class="left">'.lang('plugin/tom_tcershou', 'yuan_ico').'</span>';
                            $outStr .= '<span class="right">'.$val['price'].'</span>';
                        }else{
                            $outStr .= '<span class="yijia">'.lang('plugin/tom_tcershou', 'yijia').'</span>';
                        }
                    $outStr .= '</div>';
                    $outStr .= '<div class="tab">'.$chengseArray[$val['chengse_id']].'</div>';
                $outStr .= '</div>';
                $outStr .= '<div class="goods-user dislay-flex">';
                    $outStr .= '<div class="goods-user_left">';
                        $outStr .= '<img class="user" src="'.$val['userInfo']['picurl'].'">';
                        $outStr .= '<span class="num">'.$val['userInfo']['nickname'].'</span>';
                    $outStr .= '</div>';
                    $outStr .= '<div class="goods-user_right">';
                        if($paixu_type == 4 && !empty($latitude) && !empty($longitude)){
                            $juli = tomGetDistance($longitude, $latitude, $val['longitude'], $val['latitude']);
                            $outStr.= '<span>'.$juli.'km</span>';
                        }else{
                            $outStr .= '<span>'.dgmdate($val['add_time'],"m-d",$tomSysOffset).'</span>';
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
            $outStr .= '</div>';
        $outStr .= '</a>';
    }
}else{
    $outStr = '205';
}
$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;