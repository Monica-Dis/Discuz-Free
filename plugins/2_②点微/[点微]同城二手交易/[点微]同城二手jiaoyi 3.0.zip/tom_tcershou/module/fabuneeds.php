<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($tcershouConfig['open_fabu_needs_money'] == 1){

    $freeFabuCount = C::t("#tom_tcershou#tom_tcershou_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND type = 2  ");
    $syFreeFabuNum = $tcershouConfig['free_fabu_needs_num'] - $freeFabuCount;
    $syFreeFabuNum = intval($syFreeFabuNum);
    if($syFreeFabuNum < 0){
        $syFreeFabuNum = 0;
    }
    
    $needsFabuList = array();
    $needs_fabu_list_str = str_replace("\r\n","{n}",$tcershouConfig['needs_fabu_list']);
    $needs_fabu_list_str = str_replace("\n","{n}",$needs_fabu_list_str);
    $needs_fabu_list_arr = explode("{n}", $needs_fabu_list_str);
    $i = 0;
    if(is_array($needs_fabu_list_arr) && !empty($needs_fabu_list_arr)){
        foreach ($needs_fabu_list_arr as $key => $value){
            $arr = explode("|", $value);

            $needsFabuList[$key]['days']             = $arr[0];
            $needsFabuList[$key]['price']            = $arr[1];
            $needsFabuList[$key]['desc']             = $arr[2];
            $needsFabuList[$key]['pay_score_status'] = 0;
            $needsFabuList[$key]['pay_score']        = 0;
            $needsFabuList[$key]['free_status']      = 0;

            if($i == 0 && $syFreeFabuNum > 0){
                $needsFabuList[$key]['free_status'] = 1;
            }

            if($tcershouConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                $fabu_pay_score = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
                if($fabu_pay_score > 0 && $__UserInfo['score'] >= $fabu_pay_score){
                    $needsFabuList[$key]['pay_score_status'] = 1;
                    $needsFabuList[$key]['pay_score'] = $fabu_pay_score;
                }
            }
            $i++;
        }
    }
}

$cateList = C::t('#tom_tcershou#tom_tcershou_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,100);

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$cityList = array();
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

if($__Ios == 0 && $__Android == 0){
    $tongchengConfig['open_many_pic_upload'] = 0;
}

$payUrl  = "plugin.php?id=tom_tcershou:pay&site={$site_id}";
$jumpUrl = "plugin.php?id=tom_tcershou&site={$site_id}&mod=myfabu_needs";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcershou:fabuneeds");