<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function update_goods_tongcheng($goods_id,$paramArr = array()){
    
    if(is_array($paramArr) && !empty($paramArr)){
        $tcershouConfig    = $paramArr['tcershouConfig'];
        $tongchengConfig    = $paramArr['tongchengConfig'];
        $chengseArray       = $paramArr['chengseArray'];
    }else{
        global $tcershouConfig,$tongchengConfig,$chengseArray;
    }
    
    if($tcershouConfig['open_tongbu_tongcheng'] == 1 && $tcershouConfig['tc_goods_type_id'] > 0){}else{
        return false;
    }
    
    $tongchengTypeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tcershouConfig['tc_goods_type_id']);
    if($tongchengTypeInfo && $tongchengTypeInfo['id'] > 0){}else{
        return false;
    }
    
    $goodsInfo = C::t("#tom_tcershou#tom_tcershou_goods")->fetch_by_id($goods_id);
    if($goodsInfo && $goodsInfo['id'] > 0){}else{
        return false;
    }
    
    $photoListTmp = C::t('#tom_tcershou#tom_tcershou_photo')->fetch_all_list("AND type IN (1,2,3) AND goods_id={$goods_id} "," ORDER BY id ASC ");
    $photoList = array();
    $video_pic = '';
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach($photoListTmp as $key => $value){
            if($value['type'] == 1 || $value['type'] == 2){
                $photoList[] = $value['picurl'];
            }else if($value['type'] == 3){
                $video_pic = $value['picurl'];
            }
            
        }
    }
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_tcershou_goods_id($goodsInfo['id']);
    
    $attrArr = array();
    $attrArr[0]['name'] = lang("plugin/tom_tcershou", "tongbu_goods_cate");
    if($goodsInfo['cate_id'] > 0){
        $goodsCateInfo = C::t("#tom_tcershou#tom_tcershou_cate")->fetch_by_id($goodsInfo['cate_id']);
        $attrArr[0]['value'] = $goodsCateInfo['name'];
    }
    $attrArr[0]['unit'] = '';
    
    $attrArr[1]['name'] = lang("plugin/tom_tcershou", "tongbu_goods_title");
    $attrArr[1]['value'] = $goodsInfo['title'];
    $attrArr[1]['unit'] = '';
    
    $attrArr[2]['name'] = lang("plugin/tom_tcershou", "tongbu_goods_price");
    if($goodsInfo['price'] > 0){
        $attrArr[2]['value'] = $goodsInfo['price'];
        $attrArr[2]['unit'] = lang("plugin/tom_tcershou", "yuan");
    }else{
        $attrArr[2]['value'] = lang("plugin/tom_tcershou", "yijia");
        $attrArr[2]['unit'] = '';
    }
    
    $attrArr[3]['name'] = lang("plugin/tom_tcershou", "tongbu_goods_chengse");
    $attrArr[3]['value'] = $chengseArray[$goodsInfo['chengse_id']];
    $attrArr[3]['unit'] = '';
    
    $goodsInfo['content'] = stripslashes($goodsInfo['content']);
    $goodsInfo['content'] = strip_tags($goodsInfo['content']);
    $goodsInfo['content'] = str_replace('&nbsp;', '', $goodsInfo['content']);
    
    if($tongchengInfo && $tongchengInfo['id'] > 0){
        
        $updateData = array();
        $updateData['site_id']           = $goodsInfo['site_id'];
        $updateData['user_id']           = $goodsInfo['user_id'];
        $updateData['model_id']          = $tongchengTypeInfo['model_id'];
        $updateData['type_id']           = $tongchengTypeInfo['id'];
        $updateData['tcershou_goods_id'] = $goodsInfo['id'];
        $updateData['area_id']           = $goodsInfo['area_id'];
        $updateData['street_id']    = $goodsInfo['street_id'];
        $updateData['title']        = $goodsInfo['title'];
        $updateData['xm']           = $goodsInfo['xm'];
        $updateData['tel']          = $goodsInfo['tel'];
        $updateData['wx']           = $goodsInfo['wx'];
        $updateData['video_url']    = $goodsInfo['video_url'];
        $updateData['video_pic']    = $video_pic;
        $updateData['content']      = $goodsInfo['content'];
        if($tongchengTypeInfo['open_dingwei'] == 1){
            $updateData['is_dingwei']       = 1;
            $updateData['latitude']         = $goodsInfo['latitude'];
            $updateData['longitude']        = $goodsInfo['longitude'];
            $updateData['address']          = $goodsInfo['address'];
        }else{
            $updateData['is_dingwei']       = 0;
        }
        if($tcershouConfig['open_tongbu_top'] == 1 && $goodsInfo['top_status'] == 1){
            $updateData['topstatus']            = $goodsInfo['top_status'];
            $updateData['toprand']              = 1;
            $updateData['toptime']              = $goodsInfo['top_time'];
        }else{
            $updateData['topstatus']            = 0;
            $updateData['toprand']              = 1;
            $updateData['toptime']              = 0;
        }
        if($goodsInfo['status'] == 1 && ($goodsInfo['expire_status'] == 3 || ($goodsInfo['expire_status'] == 1 && $goodsInfo['expire_time'] > TIMESTAMP))){
            $updateData['status']               = 1;
        }else{
            $updateData['status']               = 0;
        }
        $updateData['finish']               = $goodsInfo['finish'];
        $updateData['pay_status']           = $goodsInfo['pay_status'];
        $updateData['shenhe_status']        = $goodsInfo['shenhe_status'];
        $updateData['refresh_time']         = $goodsInfo['refresh_time'];
        $updateData['add_time']             = $goodsInfo['add_time'];
        $updateData['part1']                = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongchengInfo['id'],$updateData);
        
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_photo')->delete_by_tongcheng_id($tongchengInfo['id']);
        
        if(is_array($attrArr) && !empty($attrArr)){
            foreach ($attrArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengInfo['id'];
                $insertData['attr_id']      = 0;
                $insertData['attr_name']    = $value['name'];
                $insertData['value']        = $value['value'];
                $insertData['unit']         = $value['unit'];
                $insertData['paixu']        = $key;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
        
        if(is_array($photoList) && !empty($photoList)){
            foreach($photoList as $key => $value){
                $insertData = array();
                $insertData['tongcheng_id'] = $tongchengInfo['id'];
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_photo')->insert($insertData);
            }
        }
        
    }else if($goodsInfo && $goodsInfo['status'] == 1 && $goodsInfo['shenhe_status'] == 1 && ($goodsInfo['pay_status'] == 0 || $goodsInfo['pay_status'] == 2)){
        
        $insertData = array();
        $insertData['site_id']      = $goodsInfo['site_id'];
        $insertData['user_id']      = $goodsInfo['user_id'];
        $insertData['model_id']     = $tongchengTypeInfo['model_id'];
        $insertData['type_id']      = $tongchengTypeInfo['id'];
        $insertData['tcershou_goods_id'] = $goodsInfo['id'];
        $insertData['area_id']      = $goodsInfo['area_id'];
        $insertData['street_id']    = $goodsInfo['street_id'];
        $insertData['title']        = $goodsInfo['title'];
        $insertData['xm']           = $goodsInfo['xm'];
        $insertData['tel']          = $goodsInfo['tel'];
        $insertData['wx']           = $goodsInfo['wx'];
        $insertData['video_url']    = $goodsInfo['video_url'];
        $insertData['video_pic']    = $video_pic;
        $insertData['content']      = $goodsInfo['content'];
        if($tongchengTypeInfo['open_dingwei'] == 1){
            $insertData['is_dingwei']       = 1;
            $insertData['latitude']         = $goodsInfo['latitude'];
            $insertData['longitude']        = $goodsInfo['longitude'];
            $insertData['address']          = $goodsInfo['address'];
        }else{
            $insertData['is_dingwei']       = 0;
        }
        if($tcershouConfig['open_tongbu_top'] == 1 && $goodsInfo['top_status'] == 1){
            $insertData['topstatus']            = $goodsInfo['top_status'];
            $insertData['toprand']              = 1;
            $insertData['toptime']              = $goodsInfo['top_time'];
        }else{
            $insertData['topstatus']            = 0;
            $insertData['toprand']              = 1;
            $insertData['toptime']              = 0;
        }
        if($goodsInfo['status'] == 1 && ($goodsInfo['expire_status'] == 3 || ($goodsInfo['expire_status'] == 1 && $goodsInfo['expire_time'] > TIMESTAMP))){
            $insertData['status']               = 1;
        }else{
            $insertData['status']               = 0;
        }
        $insertData['finish']               = $goodsInfo['finish'];
        $insertData['pay_status']           = $goodsInfo['pay_status'];
        $insertData['shenhe_status']        = $goodsInfo['shenhe_status'];
        $insertData['refresh_time']         = $goodsInfo['refresh_time'];
        $insertData['add_time']             = $goodsInfo['add_time'];
        C::t('#tom_tongcheng#tom_tongcheng')->insert($insertData);
        $tongchengId = C::t('#tom_tongcheng#tom_tongcheng')->insert_id();
        
        if(is_array($attrArr) && !empty($attrArr)){
            foreach ($attrArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['attr_id']      = 0;
                $insertData['attr_name']    = $value['name'];
                $insertData['value']        = $value['value'];
                $insertData['unit']         = $value['unit'];
                $insertData['paixu']        = $key;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
        
        if(is_array($photoList) && !empty($photoList)){
            foreach($photoList as $key => $value){
                $insertData = array();
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_photo')->insert($insertData);
            }
        }
    }
    
    return true;
}

function update_needs_tongcheng($needs_id,$paramArr = array()){
    
    if(is_array($paramArr) && !empty($paramArr)){
        $tcershouConfig    = $paramArr['tcershouConfig'];
        $tongchengConfig    = $paramArr['tongchengConfig'];
    }else{
        global $tcershouConfig,$tongchengConfig;
    }
    
    if($tcershouConfig['open_tongbu_tongcheng'] == 1 && $tcershouConfig['tc_needs_type_id'] > 0){}else{
        return false;
    }
    
    $tongchengTypeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tcershouConfig['tc_needs_type_id']);
    if($tongchengTypeInfo && $tongchengTypeInfo['id'] > 0){}else{
        return false;
    }
    
    $needsInfo = C::t("#tom_tcershou#tom_tcershou_needs")->fetch_by_id($needs_id);
    if($needsInfo && $needsInfo['id'] > 0){}else{
        return false;
    }
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_tcershou_needs_id($needsInfo['id']);
    
    $attrArr = array();
    $attrArr[0]['name'] = lang("plugin/tom_tcershou", "tongbu_needs_cate");
    if($needsInfo['cate_id'] > 0){
        $needsCateInfo = C::t("#tom_tcershou#tom_tcershou_cate")->fetch_by_id($needsInfo['cate_id']);
        $attrArr[0]['value'] = $needsCateInfo['name'];
    }
    $attrArr[0]['unit'] = '';
    
    $needsInfo['content'] = stripslashes($needsInfo['content']);
    $needsInfo['content'] = strip_tags($needsInfo['content']);
    $needsInfo['content'] = str_replace('&nbsp;', '', $needsInfo['content']);

    if($tongchengInfo && $tongchengInfo['id'] > 0){
        
        $updateData = array();
        $updateData['site_id']           = $needsInfo['site_id'];
        $updateData['user_id']           = $needsInfo['user_id'];
        $updateData['model_id']          = $tongchengTypeInfo['model_id'];
        $updateData['type_id']           = $tongchengTypeInfo['id'];
        $updateData['tcershou_needs_id'] = $needsInfo['id'];
        $updateData['area_id']           = $needsInfo['area_id'];
        $updateData['street_id']    = $needsInfo['street_id'];
        $updateData['title']        = $needsInfo['title'];
        $updateData['xm']           = $needsInfo['xm'];
        $updateData['tel']          = $needsInfo['tel'];
        $updateData['tel']          = $needsInfo['tel'];
        $updateData['content']      = $needsInfo['content'];
        if($tongchengTypeInfo['open_dingwei'] == 1){
            $updateData['is_dingwei']       = 1;
            $updateData['latitude']         = $needsInfo['latitude'];
            $updateData['longitude']        = $needsInfo['longitude'];
            $updateData['address']          = $needsInfo['address'];
        }else{
            $updateData['is_dingwei']       = 0;
        }
        if($tcershouConfig['open_tongbu_top'] == 1 && $needsInfo['top_status'] == 1){
            $updateData['topstatus']            = $needsInfo['top_status'];
            $updateData['toprand']              = 1;
            $updateData['toptime']              = $needsInfo['top_time'];
        }else{
            $updateData['topstatus']            = 0;
            $updateData['toprand']              = 1;
            $updateData['toptime']              = 0;
        }
        if($needsInfo['status'] == 1 && ($needsInfo['expire_status'] == 3 || ($needsInfo['expire_status'] == 1 && $needsInfo['expire_time'] > TIMESTAMP))){
            $updateData['status']               = 1;
        }else{
            $updateData['status']               = 0;
        }
        $updateData['finish']               = 0;
        $updateData['pay_status']           = $needsInfo['pay_status'];
        $updateData['shenhe_status']        = $needsInfo['shenhe_status'];
        $updateData['refresh_time']         = $needsInfo['refresh_time'];
        $updateData['add_time']             = $needsInfo['add_time'];
        $updateData['part1']                = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongchengInfo['id'],$updateData);
        
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongchengInfo['id']);
        
        if(is_array($attrArr) && !empty($attrArr)){
            foreach ($attrArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengInfo['id'];
                $insertData['attr_id']      = 0;
                $insertData['attr_name']    = $value['name'];
                $insertData['value']        = $value['value'];
                $insertData['unit']         = $value['unit'];
                $insertData['paixu']        = $key;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
    
    }else if($needsInfo && $needsInfo['status'] == 1 && $needsInfo['shenhe_status'] == 1 && ($needsInfo['pay_status'] == 0 || $needsInfo['pay_status'] == 2)){
        
        $insertData = array();
        $insertData['site_id']      = $needsInfo['site_id'];
        $insertData['user_id']      = $needsInfo['user_id'];
        $insertData['model_id']     = $tongchengTypeInfo['model_id'];
        $insertData['type_id']      = $tongchengTypeInfo['id'];
        $insertData['tcershou_needs_id'] = $needsInfo['id'];
        $insertData['area_id']      = $needsInfo['area_id'];
        $insertData['street_id']    = $needsInfo['street_id'];
        $insertData['title']        = $needsInfo['title'];
        $insertData['xm']           = $needsInfo['xm'];
        $insertData['tel']          = $needsInfo['tel'];
        $insertData['wx']           = $needsInfo['wx'];
        $insertData['content']        = $needsInfo['content'];
        if($tongchengTypeInfo['open_dingwei'] == 1){
            $insertData['is_dingwei']       = 1;
            $insertData['latitude']         = $needsInfo['latitude'];
            $insertData['longitude']        = $needsInfo['longitude'];
            $insertData['address']          = $needsInfo['address'];
        }else{
            $insertData['is_dingwei']       = 0;
        }
        if($tcershouConfig['open_tongbu_top'] == 1 && $needsInfo['top_status'] == 1){
            $insertData['topstatus']            = $needsInfo['top_status'];
            $insertData['toprand']              = 1;
            $insertData['toptime']              = $needsInfo['top_time'];
        }else{
            $insertData['topstatus']            = 0;
            $insertData['toprand']              = 1;
            $insertData['toptime']              = 0;
        }
        if($needsInfo['status'] == 1 && ($needsInfo['expire_status'] == 3 || ($needsInfo['expire_status'] == 1 && $needsInfo['expire_time'] > TIMESTAMP))){
            $insertData['status']               = 1;
        }else{
            $insertData['status']               = 0;
        }
        $insertData['pay_status']           = $needsInfo['pay_status'];
        $insertData['shenhe_status']        = $needsInfo['shenhe_status'];
        $insertData['refresh_time']         = $needsInfo['refresh_time'];
        $insertData['add_time']             = $needsInfo['add_time'];
        C::t('#tom_tongcheng#tom_tongcheng')->insert($insertData);
        $tongchengId = C::t('#tom_tongcheng#tom_tongcheng')->insert_id();
        
        if(is_array($attrArr) && !empty($attrArr)){
            foreach ($attrArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['attr_id']      = 0;
                $insertData['attr_name']    = $value['name'];
                $insertData['value']        = $value['value'];
                $insertData['unit']         = $value['unit'];
                $insertData['paixu']        = $key;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
    }
    
    return true;
}

function delete_goods_tongcheng($goods_id){
    global $tcershouConfig,$tongchengConfig;
    
    if($tcershouConfig['open_tongbu_tongcheng'] == 1){}else{
        return false;
    }
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_tcershou_goods_id($goods_id);
    if($tongchengInfo){
        C::t('#tom_tongcheng#tom_tongcheng')->delete_by_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_photo')->delete_by_tongcheng_id($tongchengInfo['id']);
    }
    return true;
}

function delete_needs_tongcheng($needs_id){
    global $tcershouConfig,$tongchengConfig;
    
    if($tcershouConfig['open_tongbu_tongcheng'] == 1){}else{
        return false;
    }
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_tcershou_needs_id($needs_id);
    if($tongchengInfo){
        C::t('#tom_tongcheng#tom_tongcheng')->delete_by_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongchengInfo['id']);
    }
    return true;
}

function wx_iconv_recurrence($value) {
    if(is_array($value)) {
        foreach($value AS $key => $val) {
            $value[$key] = wx_iconv_recurrence($val);
        }
    } else {
        $value = diconv($value, 'utf-8', CHARSET);
    }
    return $value;
}

/**
 * ���������������֮��ľ���
 * @param  Decimal $longitude1 ��㾭��
 * @param  Decimal $latitude1  ���γ��
 * @param  Decimal $longitude2 �յ㾭��
 * @param  Decimal $latitude2  �յ�γ��
 * @param  Int     $unit       ��λ 1:�� 2:����
 * @param  Int     $decimal    ���� ����С��λ��
 * @return Decimal
 */
function tomGetDistance($longitude1, $latitude1, $longitude2, $latitude2, $unit=2, $decimal=1){

    $EARTH_RADIUS = 6370.996; // ����뾶ϵ��
    $PI = 3.1415926;

    $radLat1 = $latitude1 * $PI / 180.0;
    $radLat2 = $latitude2 * $PI / 180.0;

    $radLng1 = $longitude1 * $PI / 180.0;
    $radLng2 = $longitude2 * $PI / 180.0;

    $a = $radLat1 - $radLat2;
    $b = $radLng1 - $radLng2;

    $distance = 2 * asin(sqrt(pow(sin($a/2),2) + cos($radLat1) * cos($radLat2) * pow(sin($b/2),2)));
    $distance = $distance * $EARTH_RADIUS * 1000;

    if($unit==2){
        $distance = $distance / 1000;
    }

    return round($distance, $decimal);

}