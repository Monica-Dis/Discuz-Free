<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$divnavArr = array();
$divnavArr[1] = array(
    'title'     => '�����ֻ�',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_1.png',
    'link'      => 'plugin.php?id=tom_tcershou&site={site}&mod=goodslist&cate_id=1',
);
$divnavArr[2] = array(
    'title'     => '��������',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_2.png',
    'link'      => 'plugin.php?id=tom_tcershou&site={site}&mod=goodslist&cate_id=2',
);
$divnavArr[3] = array(
    'title'     => '���ּҵ�',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_3.png',
    'link'      => 'plugin.php?id=tom_tcershou&site={site}&mod=goodslist&cate_id=3',
);
$divnavArr[4] = array(
    'title'     => '����Ь��',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_4.png',
    'link'      => 'plugin.php?id=tom_tcershou&site={site}&mod=goodslist&cate_id=4',
);
$divnavArr[5] = array(
    'title'     => '�˶�����',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_5.png',
    'link'      => 'plugin.php?id=tom_tcershou&site={site}&mod=goodslist&cate_id=5',
);
$divnavArr[6] = array(
    'title'     => '����ͼ��',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_6.png',
    'link'      => 'plugin.php?id=tom_tcershou&site={site}&mod=goodslist&cate_id=6',
);
$divnavArr[7] = array(
    'title'     => 'ĸӤ��Ʒ',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_7.png',
    'link'      => 'plugin.php?id=tom_tcershou&site={site}&mod=goodslist&cate_id=7',
);
$divnavArr[8] = array(
    'title'     => '��ͯ���',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_8.png',
    'link'      => 'plugin.php?id=tom_tcershou&site={site}&mod=goodslist&cate_id=8',
);
$divnavArr[9] = array(
    'title'     => '�ݳ�Ʒ',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_9.png',
    'link'      => 'plugin.php?id=tom_tcershou&site={site}&mod=goodslist&cate_id=9',
);
$divnavArr[10] = array(
    'title'     => '��������',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_10.png',
    'link'      => 'plugin.php?id=tom_tcershou&site={site}&mod=goodslist&cate_id=10',
);

$cateArr = array();

$cateArr[1] = array(
    'name'      => '�����ֻ�',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_1.png',
);
$cateArr[2] = array(
    'name'      => '��������',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_2.png',
);
$cateArr[3] = array(
    'name'      => '���ּҵ�',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_3.png',
);
$cateArr[4] = array(
    'name'      => '����Ь��',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_4.png',
);
$cateArr[5] = array(
    'name'      => '�˶�����',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_5.png',
);
$cateArr[6] = array(
    'name'      => '����ͼ��',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_6.png',
);
$cateArr[7] = array(
    'name'      => 'ĸӤ��Ʒ',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_7.png',
);
$cateArr[8] = array(
    'name'      => '��ͯ���',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_8.png',
);
$cateArr[9] = array(
    'name'      => '�ݳ�Ʒ',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_9.png',
);
$cateArr[10] = array(
    'name'      => '��������',
    'picurl'    => 'source/plugin/tom_tcershou/images/cate/cate_10.png',
);

if (CHARSET == 'utf-8') {
    $divnavArr    = tom_iconv($divnavArr,'gbk','utf-8');
    $cateArr      = tom_iconv($cateArr,'gbk','utf-8');
}