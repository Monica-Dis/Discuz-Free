<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$orderStatusArray = array(
    1 => '待支付',
    2 => '待发货',
    3 => '待收货',
    4 => '已签收',
    5 => '已取消',
    6 => '已退款',
);

$orderStatusColorArray = array(
    1 => '#fd0303',
    2 => '#1e9203',
    3 => '#0894fb',
    4 => '#238206',
    5 => '#0585d6',
    6 => '#ff6203',
);

$chengseArray = array(
    1 => '一成新',
    2 => '二成新',
    3 => '三成新',
    4 => '四成新',
    5 => '五成新',
    6 => '六成新',
    7 => '七成新',
    8 => '八成新',
    9 => '九成新',
    10 => '全新',
    
);