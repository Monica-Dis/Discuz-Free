<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=pinglun';
$modListUrl = $adminListUrl.'&tmod=pinglun';
$modFromUrl = $adminFromUrl.'&tmod=pinglun';

$get_list_url_value = get_list_url("tom_tcershou_admin_pinglun_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcershou#tom_tcershou_pinglun')->delete($_GET['id']);
    C::t('#tom_tcershou#tom_tcershou_pinglun_reply')->delete_by_pinglun_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_del'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            C::t('#tom_tcershou#tom_tcershou_pinglun')->delete_by_id($value);
            C::t('#tom_tcershou#tom_tcershou_pinglun_reply')->delete_by_pinglun_id($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    set_list_url("tom_tcershou_admin_pinglun_list");
    
    $goods_id    = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $needs_id    = isset($_GET['needs_id'])? intval($_GET['needs_id']):0;
    
    $pagesize = 100;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;
    
    $where = "";
    
    if($goods_id > 0){
        $where.= " AND goods_id={$goods_id} ";
    }
    
    if($needs_id > 0){
        $where.= " AND needs_id={$needs_id} ";
    }

    $count = C::t('#tom_tcershou#tom_tcershou_pinglun')->fetch_all_count($where);
    $pinglunList = C::t('#tom_tcershou#tom_tcershou_pinglun')->fetch_all_list($where,"ORDER BY pinglun_time DESC",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&goods_id={$goods_id}&needs_id={$needs_id}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
   
    echo '<tr><td width="100" align="right"><b>'.$Lang['goods_id'].'</b></td><td><input name="goods_id" type="text" value="'.$goods_id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['needs_id'].'</b></td><td><input name="needs_id" type="text" value="'.$needs_id.'" size="40" /></td></tr>';
    
    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();
    
    tomshownavheader();
    tomshownavli($Lang['pinglun_list'],$adminBaseUrl.'&tmod=pinglun',true);
    tomshownavli($Lang['pinglun_reply_list'],$adminBaseUrl.'&tmod=pinglunReply',false);
    tomshownavfooter();
  
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return batch_do();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />';
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['pinglun_list'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . '</th>';
    echo '<th>' . $Lang['goods_id'] . '</th>';
    echo '<th>' . $Lang['needs_id'] . '</th>';
    echo '<th>' . $Lang['user_picurl'] . '</th>';
    echo '<th>' . $Lang['user_nickname'] . '</th>';
    echo '<th>' . $Lang['pinglun_content'] . '</th>';
    echo '<th>' . $Lang['pinglun_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    foreach ($pinglunList as $key => $value){
        
        $modelUrl = $adminBaseUrl.'&tmod=index';
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        echo '<tr>';
        echo '<td><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" ></td>';
        if($value['goods_id'] > 0){
            echo '<td>'.$value['goods_id'].'</td>';
        }else{
            echo '<td>--</td>';
        }
        if($value['needs_id'] > 0){
            echo '<td>'.$value['needs_id'].'</td>';
        }else{
            echo '<td>--</td>';
        }
        echo '<td><img src="'.$userInfo['picurl'].'" width="40" /></td>';
        echo '<td>'.$userInfo['nickname'].'</td>';
        echo '<td>' . $value['content'] . '</td>';
        echo '<td>' . dgmdate($value['pinglun_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);

    echo $jsstr;

    $formstr = <<<EOF
        <tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="batch_del">{$Lang['batch_del']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>
        <script type="text/javascript">
        function batch_do(){
          var r = confirm("{$Lang['batch_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        </script>
EOF;
    echo $formstr;
    showformfooter();
    
}