<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=doDaoNeeds';
$modListUrl = $adminListUrl.'&tmod=doDaoNeeds';
$modFromUrl = $adminFromUrl.'&tmod=doDaoNeeds';

$day_type       = isset($_GET['day_type'])? intval($_GET['day_type']):1;
$days           = isset($_GET['days'])? intval($_GET['days']):0;
$hidetel        = isset($_GET['hidetel'])? intval($_GET['hidetel']):0;

$cate_ids = '';
$cate_ids_url = '';
if(is_array($_GET['cate_ids']) && !empty($_GET['cate_ids'])){
    $cate_ids = implode(',', $_GET['cate_ids']);
    $cate_ids_url = implode('_', $_GET['cate_ids']);
}

$site_ids = '';
$site_ids_url = '';
$chkall_site_ids_checked = 'checked';
if(is_array($_GET['site_ids']) && !empty($_GET['site_ids'])){
    $site_ids = implode(',', $_GET['site_ids']);
    $site_ids_url = implode('_', $_GET['site_ids']);
    $chkall_site_ids_checked = '';
}

tomloadcalendarjs();
showformheader($modFromUrl.'&submit_do=1&formhash='.FORMHASH);
showtableheader();
echo '<tr><th colspan="15" class="partition">' . $Lang['doDao_site_title'] .'</th></tr>';

$siteList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY add_time ASC,id DESC ",0,1000);
$sitesStr   = '<tr class="header"><th>'.$Lang['doDao_site'].' <input type="checkbox" name="chkall_site_ids" id="chkall_site_ids" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'site_ids\',\'chkall_site_ids\')" '.$chkall_site_ids_checked.'/><label for="chkall_site_ids" style="font-weight: 500;color: #18b905;">'.$Lang['checkall'].'</label></th><th></th></tr>';
$sitesStr.= '<tr><td width="800" style="line-height: 30px;">';
if(in_array(1, $_GET['site_ids'])){
    $sitesStr.=  '<label><input name="site_ids[]" type="checkbox" value="1" checked />'.$tongchengConfig['plugin_name'].'</label>';
}else if(!empty($_GET['site_ids'])){    
    $sitesStr.=  '<label><input name="site_ids[]" type="checkbox" value="1" />'.$tongchengConfig['plugin_name'].'</label>';
}else{
    $sitesStr.=  '<label><input name="site_ids[]" type="checkbox" value="1" checked />'.$tongchengConfig['plugin_name'].'</label>';
}
foreach ($siteList as $key => $value){
    if(in_array($value['id'], $_GET['site_ids'])){
        $sitesStr.=  '<label><input name="site_ids[]" type="checkbox" value="'.$value['id'].'" checked />'.$value['name'].'</label>&nbsp;&nbsp;';
    }else if(!empty($_GET['site_ids'])){
        $sitesStr.=  '<label><input name="site_ids[]" type="checkbox" value="'.$value['id'].'" />'.$value['name'].'</label>';
    }else{
        $sitesStr.=  '<label><input name="site_ids[]" type="checkbox" value="'.$value['id'].'" checked />'.$value['name'].'</label>';
    }
}
$sitesStr.= '</td><td></td></tr>';
echo $sitesStr;

$cateList  = C::t('#tom_tcershou#tom_tcershou_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,1000);
$cateStr   = '<tr class="header"><th>'.$Lang['daDao_cates'].'</th><th></th></tr>';
$cateStr.= '<tr><td width="800" style="line-height: 30px;">';
foreach ($cateList as $key => $value){
    if(in_array($value['id'], $_GET['cate_ids'])){
        $cateStr.=  '<input name="cate_ids[]" type="checkbox" value="'.$value['id'].'" checked />'.$value['name'].'&nbsp;&nbsp;';
    }else if(!empty($_GET['cate_ids'])){
        $cateStr.=  '<input name="cate_ids[]" type="checkbox" value="'.$value['id'].'" />'.$value['name'].'';
    }else{
        $cateStr.=  '<input name="cate_ids[]" type="checkbox" value="'.$value['id'].'" checked />'.$value['name'].'';
    }
}
$cateStr.= '</td><td></td></tr>';
echo $cateStr;

$day_type_1 = $day_type_2 = '';
if($day_type == 1){ $day_type_1 = 'checked';}
if($day_type == 2){ $day_type_2 = 'checked';}
$day_typeStr = '<tr class="header"><th>'.$Lang['doDao_day_type'].'</th><th></th></tr>';
$day_typeStr.= '<tr><td width="300"><label><input type="radio" name="day_type" value="1" '.$day_type_1.'>'.$Lang['doDao_day_type_1'].'<label>&nbsp;&nbsp;&nbsp;';
$day_typeStr.=  '<label><input type="radio" name="day_type" value="2" '.$day_type_2.'>'.$Lang['doDao_day_type_2'].'<label>';
$day_typeStr.= '</td><td></td></tr>';
echo $day_typeStr;

$daysStr = '<tr class="header"><th>'.$Lang['doDao_days'].'</th><th></th></tr>';
$daysStr.= '<tr><td width="300"><select style="width: 260px;" name="days" id="days">';
$daysStr.=  '<option value="0">'.$Lang['doDao_days_0'].'</option>';
for($i = 1; $i<= 30 ;$i++){
    if($i == $days){
        $daysStr.=  '<option value="'.$i.'" selected>'.$i.''.$Lang['doDao_days_msg'].'</option>';
    }else{
        $daysStr.=  '<option value="'.$i.'">'.$i.''.$Lang['doDao_days_msg'].'</option>';
    }
}
$daysStr.= '</select></td><td></td></tr>';
echo $daysStr;

$hidetel_0 = $hidetel_1 = '';
if($hidetel == 0){ $hidetel_0 = 'checked';}
if($hidetel == 1){ $hidetel_1 = 'checked';}
$hideteStr = '<tr class="header"><th>'.$Lang['doDao_hidetel'].'</th><th></th></tr>';
$hideteStr.= '<tr><td width="300">';
$hideteStr.= '<label><input type="radio" name="hidetel" value="0" '.$hidetel_0.'>'.$Lang['doDao_hidetel_0'].'<label>&nbsp;&nbsp;&nbsp;';
$hideteStr.= '<label><input type="radio" name="hidetel" value="1" '.$hidetel_1.'>'.$Lang['doDao_hidetel_1'].'<label>&nbsp;&nbsp;&nbsp;';
$hideteStr.= '</td><td></td></tr>';
echo $hideteStr;

echo '<input type="hidden" name="type" value="'.$type.'" />';
showsubmit('submit',$Lang['daDao_btn']);

showtablefooter();
showformfooter();

$where = " AND shenhe_status = 1 AND status = 1 AND (pay_status = 0 OR pay_status = 2) AND ((expire_status = 3) OR (expire_status = 1 AND expire_time > ".TIMESTAMP.")) ";

if(!empty($site_ids)){
    $where.= " AND site_id IN({$site_ids}) ";
}else{
    $where.= " AND site_id = 0 ";
}
if(!empty($cate_ids)){
    $where.= " AND cate_id IN($cate_ids) ";
}
if($days > 0){
    $minTime = TIMESTAMP - $days * 86400;
    if($day_type == 1){
        $where.= " AND refresh_time > {$minTime} ";
    }else{
        $where.= " AND add_time > {$minTime} ";
    }
}

$count = C::t('#tom_tcershou#tom_tcershou_needs')->fetch_all_count($where);

$doDaoUrl = $_G['siteurl']."plugin.php?id=tom_tcershou:doDaoNeeds&site_ids={$site_ids_url}&cate_ids={$cate_ids_url}&type={$type}&day_type={$day_type}&days={$days}&hidetel={$hidetel}";

if($_GET['submit_do'] == 1){
    if($count > 0){
        showtableheader();
        echo '<tr>';
        echo '<td><a href="'.$doDaoUrl.'" target="_blank" style="color: #FA6A03; padding:2px 7px; font-weight:600; margin-left: 10px; border-radius: 5px; border: 1px solid #FA6A03;">'.$Lang['daDao_url'].'</a></td>';
        echo '</tr>';
        showtablefooter();
        echo '<br/><b><font color="#0894fb">'.$Lang['daDao_chu_msg'].'</font></b>';
    }else{
        echo '<br/><b><font color="#fd0d0d">'.$Lang['daDao_no_msg'].'</font></b>';
    }
}