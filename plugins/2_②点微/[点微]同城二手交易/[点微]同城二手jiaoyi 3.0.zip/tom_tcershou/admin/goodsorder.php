<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=goodsorder';
$modListUrl = $adminListUrl.'&tmod=goodsorder';
$modFromUrl = $adminFromUrl.'&tmod=goodsorder';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

$get_list_url_value = get_list_url("tom_tcershou_admin_orders_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($formhash == FORMHASH && $act == 'info'){
    
    $info = C::t('#tom_tcershou#tom_tcershou_order')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $order_status = intval($_GET['order_status']);
        $updateData = array();
        $updateData['order_status'] = $order_status;
        C::t('#tom_tcershou#tom_tcershou_order')->update($_GET['id'],$updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        showformheader($modFromUrl.'&act=info&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_order_order_status'] . '</th></tr>';
        showtablefooter();
        showtableheader();
        echo '<tr><td align="right"><b>'.$Lang['order_order_status'].'</b></td><td>';
        foreach ($orderStatusArray as $key => $value){
            if($key == $info['order_status']){
                echo '<label><input type="radio" name="order_status" value="'.$key.'" checked><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b></label>&nbsp;';
            }else{
                echo '<label><input type="radio" name="order_status" value="'.$key.'" ><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b></label>&nbsp;';
            }
        }
        echo '</td></tr>';
        echo '<tr><td>&nbsp;</td><td colspan="14" ><b><font color="#fd0303">(' . $Lang['order_order_status_msg'] . ')</font></b></td></tr>';
        tomshowsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refund_show'){
    
    $info = C::t('#tom_tcershou#tom_tcershou_order')->fetch_by_id($_GET['id']);
    
    showformheader($modFromUrl.'&act=refund&id='.$_GET['id'].'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_refund_title'] .$info['goods_title']. '</th></tr>';
    showtablefooter();
    showtableheader();
    tomshowsetting(true,array('title'=>$Lang['order_refund_price'],'name'=>'refund_price','value'=>$info['pay_price'],'msg'=>$Lang['order_refund_price_msg']),"input");
    tomshowsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refund'){
    
    $wxpay_appid        = trim($tongchengConfig['wxpay_appid']);
    $wxpay_mchid        = trim($tongchengConfig['wxpay_mchid']);
    $wxpay_key          = trim($tongchengConfig['wxpay_key']);
    $wxpay_appsecret    = trim($tongchengConfig['wxpay_appsecret']);

    define("TOM_WXPAY_APPID", $wxpay_appid);
    define("TOM_WXPAY_MCHID", $wxpay_mchid);
    define("TOM_WXPAY_KEY", $wxpay_key);
    define("TOM_WXPAY_APPSECRET", $wxpay_appsecret);
    define("TOM_WXPAY_SSLCERT_PATH", DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_cert.pem');
    define("TOM_WXPAY_SSLKEY_PATH", DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_key.pem');
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/wxpay/lib/WxPay.Api.php';
    
    $refund_price   = isset($_GET['refund_price'])? floatval($_GET['refund_price']):0;
    
    $template_sms   = '';
    $orderInfo      = C::t('#tom_tcershou#tom_tcershou_order')->fetch_by_id($_GET['id']);
    $payOrderInfo   = C::t('#tom_pay#tom_pay_order')->fetch_by_order_no($orderInfo['order_no']);
    
    if($refund_price > $orderInfo['pay_price']){
        $refund_price = $orderInfo['pay_price'];
    }
    
    if($payOrderInfo['payment'] == 'wxpay_jsapi' || $payOrderInfo['payment'] == 'wxpay_h5'){

        if($orderInfo && !empty($orderInfo['order_no']) && $refund_price > 0 && $orderInfo['order_status']==2){
            $pay_price = $orderInfo['pay_price']*100;
            $refund_price = $refund_price*100;
            $input = new WxPayRefund();
            $input->SetOut_trade_no($orderInfo['order_no']);
            $input->SetTotal_fee($pay_price);
            $input->SetRefund_fee($refund_price);
            $input->SetOut_refund_no(WxPayConfig::MCHID.date("YmdHis"));
            $input->SetOp_user_id(WxPayConfig::MCHID);
            $return = WxPayApi::refund($input);
            if(is_array($return) && $return['result_code'] == 'SUCCESS'){
                
                $template_sms = $Lang['refund_succ_template_1'];
                
                DB::query("UPDATE ".DB::table('tom_tcershou_goods')." SET sale_num=sale_num-{$orderInfo['goods_num']}, stock_num=stock_num+{$orderInfo['goods_num']} WHERE id='{$orderInfo['goods_id']}' ", 'UNBUFFERED');
                DB::query("UPDATE ".DB::table('tom_tcershou_order')." SET order_status=6, refund_type=1 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
                
            }else{
                $err_code_des = diconv($return['err_code_des'], 'utf-8', CHARSET);
                cpmsg($err_code_des, $modListUrl, 'error');
            }
        }

    }else{

        if($orderInfo && !empty($orderInfo['order_no']) && $refund_price > 0 && ($orderInfo['order_status']==2 || $orderInfo['order_status']==3 )){
            $orderUserInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
            
            $insertData = array();
            $insertData['user_id']          = $orderInfo['user_id'];
            $insertData['type_id']          = 2;
            $insertData['change_money']     = $refund_price;
            $insertData['old_money']        = $orderUserInfo['money'];
            $insertData['tag']              = lang('plugin/tom_tcershou', 'refund_money_log_tag');
            $insertData['beizu']            = lang('plugin/tom_tcershou', 'beizu_order_no') . $orderInfo['order_no'];
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
            
            $template_sms = $Lang['refund_succ_template_2'];

            DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$refund_price} WHERE id='{$orderUserInfo['id']}'", 'UNBUFFERED');
            
            DB::query("UPDATE ".DB::table('tom_tcershou_goods')." SET sale_num=sale_num-{$orderInfo['goods_num']}, stock_num=stock_num+{$orderInfo['goods_num']} WHERE id='{$orderInfo['goods_id']}' ", 'UNBUFFERED');
            DB::query("UPDATE ".DB::table('tom_tcershou_order')." SET order_status=6, refund_type=2 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
        }

    }
    
    if(!empty($template_sms)){
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($orderInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcershou&site={$orderInfo['site_id']}&mod=order&type=6");
            $smsData = array(
                'first'         => $template_sms,
                'keyword1'      => $tcershouConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($orderInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }

        $insertData = array();
        $insertData['user_id']      = $orderInfo['user_id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcershouConfig['plugin_name'].'</font><br/>'.$template_sms.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    tomloadcalendarjs();
    set_list_url("tom_tcershou_admin_orders_list");
    
        $csstr = <<<EOF
<style type="text/css">
.order_nav a{ margin-bottom: 10px;margin-right: 20px;font-size: 16px; color: #797575; display: block; float: left; width: 150px; height: 30px; border: 1px solid #d0d0d0; line-height: 30px; text-align: center; text-decoration: none;}
</style>
EOF;
    echo $csstr;
    
    $file_apiclient_cert = DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_cert.pem';
    $file_apiclient_key = DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_key.pem';
    if(!file_exists($file_apiclient_cert) || !file_exists($file_apiclient_key)){
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_error_title'] . '</th></tr>';
        echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
        echo '<li><font color="#FF0000">' . $Lang['order_error_1'] . '</font></a></li>';
        echo '</ul></td></tr>';
        showtablefooter();
    }
    
    $site_id         = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id         = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $goods_id        = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $order_no        = isset($_GET['order_no'])? addslashes($_GET['order_no']):'';
    $hexiao_user_id  = isset($_GET['hexiao_user_id'])? intval($_GET['hexiao_user_id']):0;
    $order_status    = isset($_GET['order_status'])? intval($_GET['order_status']):0;
    $shenqing_refund = isset($_GET['shenqing_refund'])? intval($_GET['shenqing_refund']):0;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = " AND type = 1 ";
    $urlStr = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
        $urlStr.="&site_id={$site_id}";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
        $urlStr.="&user_id={$user_id}";
    }
    if(!empty($goods_id)){
        $where.= " AND goods_id={$goods_id} ";
        $urlStr.="&goods_id={$goods_id}";
    }
    if(!empty($order_no)){
        $where.= " AND order_no='{$order_no}' ";
        $urlStr.="&order_no={$order_no}";
    }
    if(!empty($hexiao_user_id)){
        $where.=" AND hexiao_user_id={$hexiao_user_id} ";
        $urlStr.="&hexiao_user_id={$hexiao_user_id}";
    }
    if(!empty($order_status)){
        $where.= " AND order_status={$order_status} ";
        $urlStr.="&order_status={$order_status}";
    }
    if(!empty($shenqing_refund)){
        $where.= " AND (order_status = 2 OR order_status = 3) AND shenqing_refund=1 ";
        $urlStr.="&shenqing_refund={$shenqing_refund}";
    }
    $pagesize = 15;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_count($where);
    $orderList = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl.$urlStr;
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    echo '<tr><td width="100" align="right"><b>'.$Lang['user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_order_no'] . '</b></td><td><input name="order_no" type="text" value="'.$order_no.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_goods_id'] . '</b></td><td><input name="goods_id" type="text" value="'.$goods_id.'" size="40" /><font color="#fd0d0d">' . $Lang['order_goods_id_msg'] . '</font></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_hexiao_user_id'] . '</b></td><td><input name="hexiao_user_id" type="text" value="'.$hexiao_user_id.'" size="40" /></td></tr>';
    $orderStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['order_order_status'].'</b></td>';
    $orderStatusStr.= '<td><select style="width: 260px;" name="order_status" id="order_status">';
    $orderStatusStr.=  '<option value="0">'.$Lang['order_order_status'].'</option>';
    foreach ($orderStatusArray as $key => $value){
        $orderStatusStr.=  '<option value="'.$key.'">'.$value.'</option>';
    }
    $orderStatusStr.= '</select></td></tr>';
    echo $orderStatusStr;
    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();
    
    if($goods_id > 0){
        $countOrderStatus1 = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=1 ");
        $countOrderStatus2 = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=2 ");
        $countOrderStatus3 = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=3 ");
        $countOrderStatus4 = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=4 ");
        $countOrderStatus5 = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=5 ");
        $countOrderStatus6 = C::t('#tom_tcershou#tom_tcershou_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=6 ");
        echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
        echo $orderStatusArray[1].'<font color="#fd0d0d">('.$countOrderStatus1.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[2].'<font color="#fd0d0d">('.$countOrderStatus2.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[3].'<font color="#fd0d0d">('.$countOrderStatus3.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[4].'<font color="#fd0d0d">('.$countOrderStatus4.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[5].'<font color="#fd0d0d">('.$countOrderStatus5.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[6].'<font color="#fd0d0d">('.$countOrderStatus6.')</font>&nbsp;&nbsp;';
        echo '</div>';
    }
    
    $countShenqingRefund = C::t('#tom_tcereshou#tom_tcershou_order')->fetch_all_count(" AND shenqing_refund=1 AND (order_status = 2 OR order_status = 3) ");
    echo '<div class="order_nav">';
    echo '<a style="border-color: #fd0d0d;color: #fd0d0d;" href="'.$modBaseUrl.'&shenqing_refund=1'.'">'.$Lang['shenqing_refund_count'].'&nbsp;<span>('.$countShenqingRefund.')</span></a>';
    echo '</div>';
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['order_order_no'] . '</th>';
    echo '<th>' . $Lang['order_goods_title'] . '</th>';
    echo '<th>' . $Lang['order_user_picurl'] .'</th>';
    echo '<th>' . $Lang['order_pay_price'] . '</th>';
    echo '<th>' . $Lang['order_goods_num'] . '</th>';
    echo '<th>' . $Lang['order_order_status'] . '</th>';
    echo '<th>' . $Lang['order_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($orderList as $key => $value){
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        
        if (CHARSET == 'gbk'){
            $title = mb_substr($value['goods_title'],0,20,"gbk");
        }else{
            $title = mb_substr($value['goods_title'],0,20,"utf-8");
        }
        
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td><font color="#0894fb"><b>' . $siteInfoTmp['name'] . '</b></font></td>';
        }else{
            echo '<td><font color="#0894fb"><b>' . $Lang['sites_one'] . '</b></font></td>';
        }
        echo '<td>'.$value['order_no'].'</td>';
        echo '<td style="width: 200px;">'.$title.'&nbsp;<font color="#fd0d0d">(ID:'.$value['goods_id'].')</font> </td>';
        echo '<td style="line-height: 20px;">';
        echo '<b>'.$Lang['order_user_picurl'].' : </b><img src="'.$userInfo['picurl'].'" width="40" /><br/>';
        echo '<b>UID : </b>'.$userInfo['id'].'<br/>';
        echo '<b>'.$Lang['order_user_nickname'].' : </b>'.$userInfo['nickname'].'<br/>';
        echo '<b>'.$Lang['order_user_xm'].' : </b>'.$value['xm'].'<br/>';
        echo '<b>'.$Lang['order_user_tel'].' : </b>'.$value['tel'].'<br/>';
        echo '<b>'.$Lang['order_user_address'].' : </b>'.$value['address'].'<br/>';
        echo '<b>'.$Lang['order_beizu'].' : </b>'.$value['order_beizu'].'<br/>';
        echo '</td>';
        echo '<td><font color="#0a9409">'.$value['pay_price'].'</font><br/>';
        echo '</td>';
        echo '<td><font color="#fd0d0d">'.$value['goods_num'].'</font></td>';
        echo '<td style="line-height: 20px;max-width: 150px;">';
        echo '<b><font color="'.$orderStatusColorArray[$value['order_status']].'">' . $orderStatusArray[$value['order_status']] . '</font></b><br/>';
        if($value['peisong_type'] == 1){
            echo '<font color="#0894fb">('.$Lang['goods_peisong_type_1'].')</font>';
        }else if($value['peisong_type'] == 2){
            echo '<font color="#0894fb">('.$Lang['goods_peisong_type_2'].')</font>';
        }else if($value['peisong_type'] == 3){
            echo '<font color="#0894fb">('.$Lang['goods_peisong_type_3'].')</font>';
        }
        if($value['hexiao_time'] > 0){
            echo '<br/><font color="#fd0d0d">('.$hexiaoUserInfo['nickname'].' ID:'.$hexiaoUserInfo['id'].')</font><br/>';
        }
        if($value['refund_type'] == 1){
            echo '<br/><font color="#238206">('.$Lang['refund_refund_type_1'].')</font>';
        }else if($value['refund_type'] == 2){
            echo '<br/><font color="#238206">('.$Lang['refund_refund_type_2'].')</font>';
        }
        if($value['shenqing_refund'] == 1 && ($value['order_status'] == 2 || $value['order_status'] == 3) ){
            echo '<br/><font color="#fd0d0d">'.$Lang['shenqing_refund_title'].'</font>';
            echo '<br/><font color="#8e8e8e">'.$Lang['shenqing_refund_msg'].$value['shenqing_refund_msg'].'</font>';
            if($value['sale_allow_refund'] == 1){
                echo '<br/><font color="#fd0d0d">'.$Lang['sale_allow_refund_1'].'</font>';
            }else{
                echo '<br/><font color="#fd0d0d">'.$Lang['sale_allow_refund_0'].'</font>';
            }
        }
        echo '</td>';
        echo '<td>';
        if($value['order_time'] > 0){
            echo $Lang['order_order_time'].dgmdate($value['order_time'],"Y-m-d H:i",$tomSysOffset).'<br/>';
        }else{
            echo $Lang['order_order_time'].'-<br/>';
        }
        if($value['pay_time'] > 0){
            echo $Lang['order_pay_time'].dgmdate($value['pay_time'],"Y-m-d H:i",$tomSysOffset).'<br/>';
        }else{
            echo $Lang['order_pay_time'].'-<br/>';
        }
        if($value['hexiao_time'] > 0){
            echo $Lang['order_hexiao_time'].dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset).'<br/>';
        }else{
            echo $Lang['order_hexiao_time'].'-<br/>';
        }
        echo '</td>';
        echo '<td style="line-height: 22px;">';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_order_order_status'] . '</a>';
        if($value['order_status'] == 2 || $value['order_status'] == 3){
            echo '&nbsp;|&nbsp;<a href="javascript:void(0);" onclick="refund_confirm(\''.$modBaseUrl.'&act=refund_show&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['order_refund_btn'] . '</a>';
        }
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
        $jsstr = <<<EOF
<script type="text/javascript">
function refund_confirm(url){
  var r = confirm("{$Lang['makesure_refund_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}