<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function tom_handle_shop($tcshopListTmp){
    global $_G,$tongchengConfig,$site_id;
    
    $tcshopList = array();
    if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){

        $shopIdsArrTmp = $cateIdsArrTmp = $userIdsArrTmp = $vipIdsArrTmp = $districtIdsArrTmp = array();
        foreach ($tcshopListTmp as $key => $value) {
            $shopIdsArrTmp[] = $value['id'];
            $cateIdsArrTmp[] = $value['cate_id'];
            $cateIdsArrTmp[] = $value['cate_child_id'];
            $userIdsArrTmp[] = $value['user_id'];
            $vipIdsArrTmp[]  = $value['vip_id'];
            $districtIdsArrTmp[] = $value['area_id'];
            $districtIdsArrTmp[] = $value['street_id'];
        }

        $avatarListTmp = array();
        if(is_array($shopIdsArrTmp) && !empty($shopIdsArrTmp)){
            $shopIdsStrTmp = implode(',', $shopIdsArrTmp);
            $photoArrTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(" AND tcshop_id IN({$shopIdsStrTmp}) AND type_id = 4 "," ORDER BY id ASC ",0,200);
            if(is_array($photoArrTmp) && !empty($photoArrTmp)){
                foreach($photoArrTmp as $key => $value){
                    if($tongchengConfig['open_yun'] == 2 && !empty($value['oss_picurl']) && $value['oss_status'] == 1){
                        $avatarListTmp[$value['tcshop_id']][] = $value['oss_picurl'];
                    }else if($tongchengConfig['open_yun'] == 3 && !empty($value['qiniu_picurl'])  && $value['qiniu_status'] == 1){
                        $avatarListTmp[$value['tcshop_id']][] = $value['qiniu_picurl'];
                    }
                }
            }
        }

        $cateListTmp = array();
        if(is_array($cateIdsArrTmp) && !empty($cateIdsArrTmp)){
            $cateIdsStrTmp = implode(',', $cateIdsArrTmp);
            $cateArrTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list(" AND id IN({$cateIdsStrTmp}) "," ORDER BY id ASC ",0,200);
            if(is_array($cateArrTmp) && !empty($cateArrTmp)){
                foreach($cateArrTmp as $key => $value){
                    $cateListTmp[$value['id']] = $value;
                }
            }
        }

        $companyRenzhengListTmp = $depositListTmp = array();
        if($__ShowTcrenzheng == 1 && is_array($userIdsArrTmp) && !empty($userIdsArrTmp)){
            $userIdsStrTmp = implode(',', $userIdsArrTmp);

            $companyArrTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_all_list(" AND user_id IN({$userIdsStrTmp}) AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 200);
            if(is_array($companyArrTmp) && !empty($companyArrTmp)){
                foreach($companyArrTmp as $key => $value){
                    $companyRenzhengListTmp[$value['user_id']] = $value;
                }
            }

            $depositArrTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_all_list(" AND user_id IN({$userIdsStrTmp}) AND order_status = 2 AND type = 2 ", 'ORDER BY id DESC', 0, 200);
            if(is_array($depositArrTmp) && !empty($depositArrTmp)){
                foreach($depositArrTmp as $key => $value){
                    $depositListTmp[$value['user_id']] = $value;
                }
            }
        }

        $vipListTmp = array();
        if(is_array($vipIdsArrTmp) && !empty($vipIdsArrTmp)){
            $vipIdsStrTmp = implode(',', $vipIdsArrTmp);
            $vipArrTmp = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_all_list(" AND id IN({$vipIdsStrTmp}) "," ORDER BY id ASC ",0,200);
            if(is_array($vipArrTmp) && !empty($vipArrTmp)){
                foreach($vipArrTmp as $key => $value){
                    $vipListTmp[$value['id']] = $value;

                    if(!preg_match('/^http/', $value['picurl']) ){
                        if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                            $vipPicurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                        }else{
                            $vipPicurlTmp = $_G['siteurl'].$value['picurl'];
                        }
                    }else{
                        $vipPicurlTmp = $value['picurl'];
                    }

                    $vipListTmp[$value['id']]['picurl'] = $vipPicurlTmp;
                }
            }
        }

        $districtListTmp = array();
        if(is_array($districtIdsArrTmp) && !empty($districtIdsArrTmp)){
            $districtIdsStrTmp = implode(',', $districtIdsArrTmp);
            $districtArrTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_list(" AND id IN({$districtIdsStrTmp}) "," ORDER BY id ASC ",0,200);
            if(is_array($districtArrTmp) && !empty($districtArrTmp)){
                foreach($districtArrTmp as $key => $value){
                    $districtListTmp[$value['id']] = $value;
                }
            }
        }
        
        foreach ($tcshopListTmp as $key => $value) {
            $tcshopList[$key] = $value;

            $picurlTmp = '';
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurlTmp = $_G['siteurl'].$value['picurl'];
                }
            }else{
                $picurlTmp = $value['picurl'];
            }

            $avatarPicurlTmp = $avatarListTmp[$value['id']][0];
            if(!empty($avatarPicurlTmp)){
                $picurlTmp = $avatarPicurlTmp;
            }

            $tabsStr = str_replace("    "," ",$value['tabs']);
            $tabsStr = str_replace("   "," ",$tabsStr);
            $tabsStr = str_replace("  "," ",$tabsStr);
            $tabsArrTmp = explode(' ', $tabsStr);
            $tabsArr = array();
            if(is_array($tabsArrTmp) && !empty($tabsArrTmp)){
                foreach ($tabsArrTmp as $kk => $vv){
                    $vv = trim($vv);
                    if(!empty($vv)){
                        $vv = cutstr($vv, 12, '');
                        $tabsArr[] = $vv;
                    }
                }
            }

            if(empty($tabsArr)){
                $tabsArr[] = $cateListTmp[$value['cate_id']]['name'];
                $tabsArr[] = $cateListTmp[$value['cate_child_id']]['name'];
            }

            $companyRenzhengStatusTmp = $depositStatusTmp = 0;
            if(is_array($companyRenzhengListTmp[$value['user_id']]) && !empty($companyRenzhengListTmp[$value['user_id']])){
                $companyRenzhengStatusTmp = 1;
            }
            if(is_array($depositListTmp[$value['user_id']]) && !empty($depositListTmp[$value['user_id']])){
                $depositStatusTmp = 1;
            }

            $vipInfoTmp = $vipListTmp[$value['vip_id']];

            $videoFlagTmp = $vrFlagTmp = 0;
            if($vipInfoTmp['open_video'] == 1 && !empty($value['video_url'])){
                if(strpos($value['video_url'], 'youku.com') !== FALSE){
                    $videoFlagTmp = 1;
                }else if(strpos($value['video_url'], 'qq.com') !== FALSE){
                    $videoFlagTmp = 1;
                }else if(strpos($value['video_url'], '.mp4') !== FALSE){
                    $videoFlagTmp = 1;
                }else if(strpos($value['video_url'], '.MOV') !== FALSE){
                    $videoFlagTmp = 1;
                }
            }
            if($vipInfoTmp['open_vr'] == 1 && !empty($value['vr_url'])){
                $vrFlagTmp = 1;
            }

            $tcshopList[$key]['picurl']                 = $picurlTmp;
            $tcshopList[$key]['tabsList']               = $tabsArr;
            $tcshopList[$key]['companyRenzhengStatus']  = $companyRenzhengStatusTmp;
            $tcshopList[$key]['depositStatus']          = $depositStatusTmp;
            $tcshopList[$key]['videoFlag']              = $videoFlagTmp;
            $tcshopList[$key]['vrFlag']                 = $vrFlagTmp;
            $tcshopList[$key]['vipInfo']                = $vipInfoTmp;
            $tcshopList[$key]['areaInfo']               = $districtListTmp[$value['area_id']];
            $tcshopList[$key]['streetInfo']             = $districtListTmp[$value['street_id']];
            $tcshopList[$key]['link']                   = tom_tcpc_url('shopinfo',$site_id,array('tcshop_id'=>$value['id']));
            
        }
    }
    return $tcshopList;
}