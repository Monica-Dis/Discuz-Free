<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'qrcode_login' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 1,
    );

    $key = isset($_GET['key'])? addslashes($_GET['key']):'';

    if(empty($key)){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }

    $loginInfo = C::t("#tom_tcpc#tom_tcpc_login")->fetch_by_key($key);
    if($loginInfo){
        $loginKeyExpireTime = 120;
        if(($loginInfo['refresh_time'] + $loginKeyExpireTime) < TIMESTAMP){
            $outArr = array(
                'status'=> 301,
            );    
            echo json_encode($outArr); exit;
        }

        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($loginInfo['user_id']);

        if($userInfoTmp){
            $memberInfoTmp = C::t('#tom_ucenter#tom_ucenter_member')->fetch_by_uid($userInfoTmp['member_id']);
            if($memberInfoTmp){

                $lifeTime = 86400;
                dsetcookie('tom_ucenter_member_uid',$memberInfoTmp['uid'],$lifeTime);
                dsetcookie('tom_ucenter_member_key',md5($memberInfoTmp['uid'].'|||'.$memberInfoTmp['mykey']),$lifeTime);

                $outArr = array(
                    'status'=> 200,
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    
    $outArr = array(
        'status'=> 404,
    );
    echo json_encode($outArr); exit;
}else if($act == 'tel_login' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 1,
    );
    
    $tel = isset($_GET['tel'])? daddslashes(diconv(urldecode($_GET['tel']),'utf-8')):'';
    $pwd = isset($_GET['pwd'])? daddslashes(diconv(urldecode($_GET['pwd']),'utf-8')):'';

    if(empty($tel) || empty($pwd)){
        $outArr['status'] = 500;
        echo json_encode($outArr); exit;
    }

    $memberInfo = C::t('#tom_ucenter#tom_ucenter_member')->fetch_by_tel($tel);
    if(!$memberInfo){
        $outArr['status'] = 301;
        echo json_encode($outArr); exit;
    }
    
    if(md5($pwd.'|||'.$memberInfo['mykey']) == $memberInfo['pwd']){

        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_member_id($memberInfo['uid']);
        if(!$userInfoTmp){
            $outArr['status'] = 303;
            echo json_encode($outArr); exit;
        }

        $updateData = array();
        $updateData['last_login_type']     = 'tel';
        $updateData['last_login_time']     = TIMESTAMP;
        C::t('#tom_ucenter#tom_ucenter_member')->update($memberInfo['uid'],$updateData);

        $lifeTime = 86400;
        dsetcookie('tom_ucenter_member_uid',$memberInfo['uid'],$lifeTime);
        dsetcookie('tom_ucenter_member_key',md5($memberInfo['uid'].'|||'.$memberInfo['mykey']),$lifeTime);

        $outArr['status'] = 200;
        echo json_encode($outArr); exit;
    }else{
        $outArr['status'] = 302;
        echo json_encode($outArr); exit;
    }
}else if($act == 'loginout'){
    $outArr = array(
        'status'=> 1,
    );

    $lifeTime = 86400;
    dsetcookie('tom_ucenter_member_uid','',$lifeTime);
    dsetcookie('tom_ucenter_member_key','',$lifeTime);
    $outArr['status'] = 200;
    $outArr['code'] = 200;
    echo json_encode($outArr); exit;
}

$cookieUid = getcookie('tom_ucenter_member_uid');
$cookieKey = getcookie('tom_ucenter_member_key');
if(!empty($cookieUid) && !empty($cookieKey)){
    $__MemberInfoTmp = C::t('#tom_ucenter#tom_ucenter_member')->fetch_by_uid($cookieUid);
    if($__MemberInfoTmp && !empty($__MemberInfoTmp['mykey'])){
        if(md5($__MemberInfoTmp['uid'].'|||'.$__MemberInfoTmp['mykey']) == $cookieKey){
            $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_member_id($__MemberInfoTmp['uid']);
            if($userInfoTmp){
                dheader('location:'.$t_back_url);exit;
            }
        }
    }
}

$key = $_G['clientip'].'_'.$_SERVER['HTTP_USER_AGENT'].'_'.TIMESTAMP.'_'.mt_rand(100000, 999999);
$key = md5($key);

$qrcodeUrl = $_G['siteurl']."plugin.php?id=tom_tcpc:login&mod=qrcodelogin&key={$key}";
$loginQrcodeImg = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($qrcodeUrl);
$qrcodeLoginUrl = $_G['siteurl']."plugin.php?id=tom_tcpc:login&mod=login&act=qrcode_login&key={$key}&formhash={$formhash}";
$loginUrl = $_G['siteurl']."plugin.php?id=tom_tcpc:login&mod=login&act=tel_login&key={$key}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcpc:login");