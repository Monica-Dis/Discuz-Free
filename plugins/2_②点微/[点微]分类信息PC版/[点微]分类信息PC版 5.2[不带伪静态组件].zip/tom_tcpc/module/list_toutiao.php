<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tctoutiaoList = array();
if(is_array($tctoutiaoListTmp) && !empty($tctoutiaoListTmp)){
    
    $toutiaoIdsArrTmp  = $zuozheIdsArrTmp = array();
    foreach ($tctoutiaoListTmp as $key => $value) {
        $toutiaoIdsArrTmp[] = $value['id'];
        $zuozheIdsArrTmp[] = $value['zuozhe_id'];
    }
    
    $photoListTmpTmp = array();
    if(is_array($toutiaoIdsArrTmp) && !empty($toutiaoIdsArrTmp)){
        $toutiaoIdsStrTmp = implode(',', $toutiaoIdsArrTmp);
        $photoArrTmp = C::t('#tom_tctoutiao#tom_tctoutiao_photo')->fetch_all_front_list(" AND tctoutiao_id IN({$toutiaoIdsStrTmp}) "," ORDER BY psort ASC,id DESC ",0,1000);
        if(is_array($photoArrTmp) && !empty($photoArrTmp)){
            foreach($photoArrTmp as $key => $value){
                $photoListTmpTmp[$value['tctoutiao_id']][$value['type']][] = $value;
            }
        }
    }
    
    $zuozheListTmp = array();
    if(is_array($zuozheIdsArrTmp) && !empty($zuozheIdsArrTmp)){
        $zuozheIdsStrTmp = implode(',', $zuozheIdsArrTmp);
        $zuozheArrTmp = C::t('#tom_tctoutiao#tom_tctoutiao_zuozhe')->fetch_all_list(" AND id IN({$zuozheIdsStrTmp}) "," ORDER BY id DESC ",0,100);
        if(is_array($zuozheArrTmp) && !empty($zuozheArrTmp)){
            foreach($zuozheArrTmp as $key => $value){
                $zuozheListTmp[$value['id']] = $value;
            }
        }
    }
    
    foreach ($tctoutiaoListTmp as $key => $value) {
        $tctoutiaoList[$key] = $value;
        
        $picUrlTmp = '';
        $coverArrTmp = array();
        if($value['type'] == 1){
            $photoListTmp = $photoListTmpTmp[$value['id']][$value['type']];
            
            if(is_array($photoListTmp) && !empty($photoListTmp)){
                $photoListArrTmp = array();
                if(count($photoListTmp) < 3){
                    $photoListArrTmp[] = $photoListTmp[0];
                }else{
                    $photoListArrTmp = $photoListTmp;
                }
                
                $i = 1;
                foreach($photoListArrTmp as $pk => $pv){
                    if($i == 1){
                        $picUrlTmp = $pv['picurlTmp'];
                    }
                    if($i <= 3){
                        $coverArrTmp[] = $pv['picurlTmp'];
                    }
                    $i++;
                }
            }

        }else if($value['type'] == 2){
            if($value['tuji_listpic_type'] == 1){
                $photoListTmp = $photoListTmpTmp[$value['id']][$value['type']];
            }else{
                $photoListTmp = $photoListTmpTmp[$value['id']][1];
            }
            
            if(is_array($photoListTmp) && !empty($photoListTmp)){
                $photoListArrTmp = array();
                if(count($photoListTmp) < 3){
                    $photoListArrTmp[] = $photoListTmp[0];
                }else{
                    $photoListArrTmp = $photoListTmp;
                }

                $i = 1;
                foreach($photoListArrTmp as $pk => $pv){
                    if($i == 1){
                        $picUrlTmp = $pv['picurlTmp'];
                    }
                    if($i <= 3){
                        $coverArrTmp[] = $pv['picurlTmp'];
                    }
                    $i++;
                }
            }

        }else if($value['type'] == 3){
            $photoListTmp = $photoListTmpTmp[$value['id']][$value['type']];
            if(!empty($photoListTmp[0])){
                $videoPicInfoTmp = $photoListTmp[0];
                if(!empty($videoPicInfoTmp)){
                   $picUrlTmp = $videoPicInfoTmp['picurlTmp'];
                   $coverArrTmp[] = $videoPicInfoTmp['picurlTmp'];
                }
            }
        }

        $template_type_tmp = 1;
        if(count($coverArrTmp) == 1){
            $template_type_tmp = 2;
        }else if(count($coverArrTmp) == 3){
            $template_type_tmp = 3;
        }

        $zuozheInfoTmp = $zuozheListTmp[$value['zuozhe_id']];

        $tctoutiaoList[$key] = $value;
        $tctoutiaoList[$key]['clicks']          = $value['clicks'] + $value['virtual_clicks'];
        $tctoutiaoList[$key]['template_type']   = $template_type_tmp;
        $tctoutiaoList[$key]['coverList']       = $coverArrTmp;
        $tctoutiaoList[$key]['picurl']          = $picUrlTmp;
        $tctoutiaoList[$key]['zuozheInfo']      = $zuozheInfoTmp;
        $tctoutiaoList[$key]['infoUrl']         = tom_tcpc_url('toutiaoinfo',$site_id,array('tctoutiao_id'=>$value['id']));
        $tctoutiaoList[$key]['zuozheUrl']       = tom_tcpc_url('toutiaozuozhe',$site_id,array('zuozhe_id'=>$zuozheInfoTmp['id']));
    }
}