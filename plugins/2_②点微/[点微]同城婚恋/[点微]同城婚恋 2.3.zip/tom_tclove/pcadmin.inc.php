<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tcloveConfig = $_G['cache']['plugin']['tom_tclove'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowYear = dgmdate($_G['timestamp'], 'Y',$tomSysOffset);
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20210319";

$exit_jiben_projectArr = unserialize($tcloveConfig['edit_jiben_select']);
$showXingzuo = $showXuexing = $showMinzu = $showChild = $showHjarea = 0;
if(array_search('1',$exit_jiben_projectArr) !== false){
    $showXingzuo = 1;
}
if(array_search('2',$exit_jiben_projectArr) !== false){
    $showShuxiang = 1;
}
if(array_search('3',$exit_jiben_projectArr) !== false){
    $showXuexing = 1;
}
if(array_search('4',$exit_jiben_projectArr) !== false){
    $showMinzu = 1;
}
if(array_search('5',$exit_jiben_projectArr) !== false){
    $showChild = 1;
}
if(array_search('6',$exit_jiben_projectArr) !== false){
    $showHjarea = 1;
}

$exit_contact_projectArr = unserialize($tcloveConfig['edit_contact_select']);
$showQq = 0;
if(array_search('1',$exit_contact_projectArr) !== false){
    $showQq = 1;
}

$exit_jingji_projectArr = unserialize($tcloveConfig['edit_jingji_select']);
$showHouse = $showCar = 0;
if(array_search('1',$exit_jingji_projectArr) !== false){
    $showHouse = 1;
}
if(array_search('2',$exit_jingji_projectArr) !== false){
    $showCar = 1;
}

$exit_zheou_projectArr = unserialize($tcloveConfig['edit_zheou_select']);
$showZheouHeight = $showZheouMinzu = $showZheouEdu = 0;
if(array_search('1',$exit_zheou_projectArr) !== false){
    $showZheouHeight = 1;
}
if(array_search('2',$exit_zheou_projectArr) !== false){
    $showZheouMinzu = 1;
}
if(array_search('3',$exit_zheou_projectArr) !== false){
    $showZheouEdu = 1;
}

$pcadminUrl = 'plugin.php?id=tom_tclove:pcadmin';
$ajaxUrl = 'plugin.php?id=tom_admin:ajax';
$loveAjaxUrl = 'plugin.php?id=tom_tclove:pcadminAjax';
$uploadUrl = 'plugin.php?id=tom_admin:upload';

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tclove/config/pcadmin.lang.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
include DISCUZ_ROOT.'./source/plugin/tom_tclove/class/tui_phb.func.php';
include DISCUZ_ROOT.'./source/plugin/tom_tclove/class/tclove.func.php';
$weixinClass = new weixinClass($appid,$appsecret);

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/config/works.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/config/works.utf.php';
}

$Lang = $pcadminLang;

include DISCUZ_ROOT.'./source/plugin/tom_admin/login_check.php';

if($_GET['tmod'] == 'list'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/list.php';
}else if($_GET['tmod'] == 'add'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/add.php';
}else if($_GET['tmod'] == 'edit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/edit.php';
}else if($_GET['tmod'] == 'edit_sms_times'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/edit_sms_times.php';
}else if($_GET['tmod'] == 'ufuwu'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/ufuwu.php';
}else if($_GET['tmod'] == 'doDao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/doDao.php';
}else if($_GET['tmod'] == 'talk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/talk.php';
}else if($_GET['tmod'] == 'pinglun'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/pinglun.php';
}else if($_GET['tmod'] == 'pinglunReply'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/pinglunReply.php';
}else if($_GET['tmod'] == 'talkPinglun'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/talkPinglun.php';
}else if($_GET['tmod'] == 'tuilist'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/tuilist.php';
}else if($_GET['tmod'] == 'tui_shouyi_log'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/tui_shouyi_log.php';
}else if($_GET['tmod'] == 'tui_phb'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/tui_phb.php';
}else if($_GET['tmod'] == 'hongniang'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/hongniang.php';
}else if($_GET['tmod'] == 'hongniangadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/hongniangadd.php';
}else if($_GET['tmod'] == 'hongniangedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/hongniangedit.php';
}else if($_GET['tmod'] == 'hongniang_shenqing'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/hongniang_shenqing.php';
}else if($_GET['tmod'] == 'hongniang_shouyi_log'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/hongniang_shouyi_log.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/order.php';
}else if($_GET['tmod'] == 'pmMessage'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/pmMessage.php';
}else if($_GET['tmod'] == 'diynav'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/diynav.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/focuspic.php';
}else if($_GET['tmod'] == 'report'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/report.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/pcadmin/list.php';
}