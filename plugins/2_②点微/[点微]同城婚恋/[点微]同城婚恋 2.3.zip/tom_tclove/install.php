<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tclove`;
CREATE TABLE `pre_tom_tclove` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `tui_id` int(11) DEFAULT '0',
  `hongniang_id` int(11) DEFAULT '0',
  `vip_id` int(11) DEFAULT '0',
  `vip_time` int(11) DEFAULT '0',
  `user_no` int(11) DEFAULT '0',
  `xm` varchar(255) NOT NULL,
  `sex` tinyint(4) NOT NULL DEFAULT '1',
  `birth_year` int(11) NOT NULL DEFAULT '0',
  `birth_month` int(11) DEFAULT '0',
  `birth_day` int(11) DEFAULT '0',
  `height` varchar(255) DEFAULT NULL,
  `weight` varchar(255) DEFAULT NULL,
  `xingzuo_id` int(11) DEFAULT '0',
  `shuxiang_id` int(11) DEFAULT '0',
  `xuexing_id` int(11) DEFAULT '0',
  `minzu_id` int(11) DEFAULT '0',
  `job` varchar(255) DEFAULT NULL,
  `edu_id` int(11) DEFAULT '0',
  `wx` varchar(255) DEFAULT NULL,
  `qq` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `province_id` int(11) NOT NULL DEFAULT '0',
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `towns_id` int(11) DEFAULT '0',
  `area` varchar(255) DEFAULT NULL,
  `hjprovince_id` int(11) DEFAULT '0',
  `hjcity_id` int(11) DEFAULT '0',
  `hjarea_id` int(11) DEFAULT '0',
  `hjtowns_id` int(11) DEFAULT '0',
  `hjarea` varchar(255) DEFAULT NULL,
  `marital_id` int(11) DEFAULT '0',
  `child_id` int(11) DEFAULT '0',
  `shouru` int(11) DEFAULT '0',
  `house_id` int(11) DEFAULT '0',
  `che_id` int(11) DEFAULT '0',
  `zheou_min_age` int(11) DEFAULT '0',
  `zheou_max_age` int(11) DEFAULT '0',
  `zheou_marital_id` int(11) DEFAULT '0',
  `zheou_min_height` int(11) DEFAULT '0',
  `zheou_max_height` int(11) DEFAULT '0',
  `zheou_minzu_id` int(11) DEFAULT '0',
  `zheou_edu_id` int(11) DEFAULT '0',
  `zheou_desc` varchar(255) DEFAULT NULL,
  `describe` varchar(255) DEFAULT NULL,
  `open_fujin_status` int(11) DEFAULT '0',
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `close_tel` int(11) DEFAULT '0',
  `is_open` int(11) DEFAULT '1',
  `visitor_visit` int(11) DEFAULT '1',
  `sms_times` int(11) DEFAULT '0',
  `top_status` int(11) DEFAULT '0',
  `top_time` int(11) DEFAULT '0',
  `top_do_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `is_ok` int(11) DEFAULT '0',
  `ok_time` int(11) DEFAULT '0',
  `last_login_time` int(11) DEFAULT '0',
  `agree_safe` int(11) DEFAULT '0',
  `video_status` int(11) DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `shenhe_status` tinyint(4) NOT NULL DEFAULT '1',
  `tui_award_status` tinyint(4) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sex` (`sex`),
  KEY `idx_user_no` (`user_no`),
  KEY `idx_marital_id` (`marital_id`),
  KEY `idx_birth_year` (`birth_year`),
  KEY `idx_height` (`height`),
  KEY `idx_shouru` (`shouru`),
  KEY `idx_edu_id` (`edu_id`),
  KEY `idx_is_ok` (`is_ok`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_status` (`status`),
  KEY `idx_is_open` (`is_open`),
  KEY `idx_video_status` (`video_status`),
  KEY `idx_site_id` (`site_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_autoid`;
CREATE TABLE `pre_tom_tclove_autoid` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_chakan`;
CREATE TABLE `pre_tom_tclove_chakan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tclove_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `time_key` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_clicks`;
CREATE TABLE `pre_tom_tclove_clicks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `clicks` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_collect`;
CREATE TABLE `pre_tom_tclove_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tclove_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_common`;
CREATE TABLE `pre_tom_tclove_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `xieyi_txt` text,
  `vip_txt` text,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_diynav`;
CREATE TABLE `pre_tom_tclove_diynav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `add_time` varchar(255) DEFAULT '0',
  `dsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_focuspic`;
CREATE TABLE `pre_tom_tclove_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_fuwu`;
CREATE TABLE `pre_tom_tclove_fuwu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `price_list` text,
  `desc` text NOT NULL,
  `is_hidden` tinyint(4) DEFAULT '0',
  `fsort` int(11) DEFAULT '100',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) NOT NULL,
  `part2` varchar(255) NOT NULL,
  `part3` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_hongniang`;
CREATE TABLE `pre_tom_tclove_hongniang` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `wx` varchar(255) DEFAULT NULL,
  `qrcode` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `total_shouyi` decimal(10,2) DEFAULT '0.00',
  `paixu` int(11) DEFAULT '100',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_hongniang_renling_log`;
CREATE TABLE `pre_tom_tclove_hongniang_renling_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tclove_id` int(11) DEFAULT '0',
  `hongniang_id` int(11) DEFAULT '0',
  `renling_time` int(11) DEFAULT '0',
  `renling_time_key` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_hongniang_shenqing`;
CREATE TABLE `pre_tom_tclove_hongniang_shenqing` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `wx` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `qrcode` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `pay_status` tinyint(4) DEFAULT '0',
  `shenhe_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_hongniang_shouyi_log`;
CREATE TABLE `pre_tom_tclove_hongniang_shouyi_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tclove_id` int(11) DEFAULT '0',
  `hongniang_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `change_shouyi` decimal(10,2) DEFAULT '0.00',
  `old_shouyi` decimal(10,2) DEFAULT '0.00',
  `log_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_look`;
CREATE TABLE `pre_tom_tclove_look` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tclove_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_order`;
CREATE TABLE `pre_tom_tclove_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT NULL,
  `order_no` varchar(255) DEFAULT NULL,
  `order_type` int(11) DEFAULT '1',
  `openid` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `tclove_id` int(11) DEFAULT '0',
  `time_value` int(11) DEFAULT '0',
  `fuwu_id` int(11) DEFAULT '0',
  `fuwu_times` int(11) DEFAULT '0',
  `sms_times` int(11) DEFAULT '0',
  `vip_id` int(11) DEFAULT '0',
  `hongniang_sq_id` int(11) DEFAULT '0',
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `order_time` int(11) DEFAULT '0',
  `pay_time` int(11) DEFAULT '0',
  `order_status` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_photo`;
CREATE TABLE `pre_tom_tclove_photo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tclove_id` int(11) NOT NULL DEFAULT '0',
  `talk_id` int(11) DEFAULT '0',
  `is_avatar` int(11) DEFAULT '0',
  `pic_url` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `video_url` varchar(255) DEFAULT NULL,
  `oss_picurl` varchar(255) DEFAULT NULL,
  `oss_status` int(11) DEFAULT '0',
  `qiniu_status` int(11) DEFAULT '0',
  `qiniu_picurl` varchar(255) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_report`;
CREATE TABLE `pre_tom_tclove_report` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `report_user_id` int(11) DEFAULT '0',
  `report_content` varchar(255) DEFAULT NULL,
  `report_pic_1` varchar(255) DEFAULT NULL,
  `report_pic_2` varchar(255) DEFAULT NULL,
  `report_time` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_talk`;
CREATE TABLE `pre_tom_tclove_talk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `tclove_id` int(11) DEFAULT NULL,
  `content` text,
  `pinglun_count` int(11) DEFAULT '0',
  `zan_count` int(11) DEFAULT '0',
  `must_vip` int(11) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `talk_time` int(11) DEFAULT '0',
  `is_jingxuan` int(11) DEFAULT '0',
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `shenhe_status` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_talk_pinglun`;
CREATE TABLE `pre_tom_tclove_talk_pinglun` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `talk_id` int(11) DEFAULT '0',
  `tclove_id` int(11) DEFAULT '0',
  `content` varchar(255) DEFAULT NULL,
  `pinglun_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_talk_pinglun_reply`;
CREATE TABLE `pre_tom_tclove_talk_pinglun_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `talk_id` int(11) DEFAULT '0',
  `pinglun_id` int(11) DEFAULT '0',
  `tclove_id` int(11) DEFAULT '0',
  `user_nickname` varchar(255) DEFAULT NULL,
  `user_avatar` varchar(255) DEFAULT NULL,
  `content` text,
  `reply_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_talk_pinglun_zan`;
CREATE TABLE `pre_tom_tclove_talk_pinglun_zan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `talk_id` int(11) DEFAULT '0',
  `pinglun_id` int(11) DEFAULT '0',
  `tclove_id` int(11) DEFAULT '0',
  `zan_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_talk_zan`;
CREATE TABLE `pre_tom_tclove_talk_zan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `talk_id` int(11) DEFAULT '0',
  `tclove_id` int(11) DEFAULT '0',
  `zan_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_tui`;
CREATE TABLE `pre_tom_tclove_tui` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  `total_shouyi` decimal(10,2) DEFAULT '0.00',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_tui_phb`;
CREATE TABLE `pre_tom_tclove_tui_phb` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `phb_type` int(11) DEFAULT '1',
  `month_id` int(11) DEFAULT '0',
  `week_id` int(11) DEFAULT '0',
  `shouyi` decimal(10,2) DEFAULT '0.00',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_tui_shouyi_log`;
CREATE TABLE `pre_tom_tclove_tui_shouyi_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tclove_id` int(11) DEFAULT '0',
  `tui_id` int(11) DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `change_shouyi` decimal(10,2) NOT NULL DEFAULT '0.00',
  `old_shouyi` decimal(10,2) DEFAULT '0.00',
  `beizu` text,
  `log_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_ufuwu`;
CREATE TABLE `pre_tom_tclove_ufuwu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tclove_id` int(11) NOT NULL DEFAULT '0',
  `fuwu_id` int(11) DEFAULT '0',
  `fuwu_name` varchar(255) DEFAULT NULL,
  `fuwu_times` int(11) NOT NULL,
  `part1` varchar(255) NOT NULL,
  `part2` varchar(255) NOT NULL,
  `part3` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_ufuwu_log`;
CREATE TABLE `pre_tom_tclove_ufuwu_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tclove_id` int(11) NOT NULL DEFAULT '0',
  `fuwu_id` int(11) DEFAULT '0',
  `change_times` int(11) NOT NULL DEFAULT '0',
  `old_times` int(11) NOT NULL DEFAULT '0',
  `op_type` int(11) DEFAULT '0',
  `op_user_id` int(11) DEFAULT '0',
  `beizu` text,
  `op_time` int(11) DEFAULT '0',
  `part1` varchar(255) NOT NULL,
  `part2` varchar(255) NOT NULL,
  `part3` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_video`;
CREATE TABLE `pre_tom_tclove_video` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT NULL,
  `tclove_id` int(11) NOT NULL DEFAULT '0',
  `video_url` varchar(255) DEFAULT NULL,
  `video_pic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_vip`;
CREATE TABLE `pre_tom_tclove_vip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `days` int(11) DEFAULT '0',
  `chakan_times` int(11) DEFAULT '0',
  `sms_times` int(11) DEFAULT '0',
  `vip_picurl` varchar(255) DEFAULT NULL,
  `vsort` int(11) DEFAULT '100',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_vip_fuwu`;
CREATE TABLE `pre_tom_tclove_vip_fuwu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vip_id` int(11) NOT NULL DEFAULT '0',
  `fuwu_id` int(11) DEFAULT '0',
  `fuwu_name` varchar(255) DEFAULT NULL,
  `fuwu_times` int(11) DEFAULT '0',
  `part1` varchar(255) NOT NULL,
  `part2` varchar(255) NOT NULL,
  `part3` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_xihuan`;
CREATE TABLE `pre_tom_tclove_xihuan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tclove_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_pm`;
CREATE TABLE `pre_tom_tclove_pm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `pm_lists_id` int(11) DEFAULT '0',
  `new_num` int(11) DEFAULT '0',
  `last_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_pm_lists`;
CREATE TABLE `pre_tom_tclove_pm_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `min_use_id` int(11) DEFAULT '0',
  `max_use_id` int(11) DEFAULT '0',
  `last_content` text,
  `last_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_pm_log`;
CREATE TABLE `pre_tom_tclove_pm_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `change_times` int(11) DEFAULT '0',
  `old_times` int(11) DEFAULT '0',
  `op_type` int(11) DEFAULT '0',
  `op_user_id` int(11) DEFAULT '0',
  `op_time` int(11) DEFAULT '0',
  `part1` varchar(255) NOT NULL,
  `part2` varchar(255) NOT NULL,
  `part3` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tclove_pm_message`;
CREATE TABLE `pre_tom_tclove_pm_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pm_lists_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `content` text,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
EOF;

runquery($sql);

$finish = TRUE;