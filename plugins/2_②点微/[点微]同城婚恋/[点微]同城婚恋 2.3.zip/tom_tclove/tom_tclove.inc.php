<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
loaducenter();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$nowYear = dgmdate($_G['timestamp'], 'Y', $tomSysOffset);
$tcloveConfig = $_G['cache']['plugin']['tom_tclove'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = '20210819';
if (!file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/tom_tongcheng.inc.php')) {
	echo '<a href="https://addon.discuz.com/?@tom_tongcheng.plugin">https://addon.discuz.com/?@tom_tongcheng.plugin</a>';
	exit(0);
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcloveConfig['share_title'];
$shareDesc = $tcloveConfig['share_desc'];
$shareLogo = $tcloveConfig['share_logo'];
$shareUrl = $_G['siteurl'] . 'plugin.php?id=tom_tclove&site=' . $site_id . '&mod=index';
if (CHARSET == 'gbk') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/config/works.gbk.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/config/works.utf.php';
}
include DISCUZ_ROOT . './source/plugin/tom_tclove/class/tclove.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
include DISCUZ_ROOT . './source/plugin/tom_tclove/class/tui_phb.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
include DISCUZ_ROOT . './source/plugin/tom_tclove/module/set.php';
$tcadminConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcadmin/tom_tcadmin.inc.php')) {
	$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')) {
	$tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
	if ($tcrenzhengConfig['open_tcrenzheng'] == 1) {
		$__ShowTcrenzheng = 1;
	}
}
$__ShowVideo = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/video.inc.php')) {
	$__ShowVideo = 1;
}
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')) {
	$xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
	$__ShowXiaofenlei = 1;
}
$__ClicksInfo = C::t('#tom_tclove#tom_tclove_clicks')->fetch_by_site_id($site_id);
if (!$__ClicksInfo) {
	$insertData = array();
	$insertData['site_id'] = $site_id;
	C::t('#tom_tclove#tom_tclove_clicks')->insert($insertData);
}
$__TcloveInfo = array();
if ($__UserInfo['id'] > 0) {
	$__TcloveInfoTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($__UserInfo['id']);
	if ($__TcloveInfoTmp['id'] > 0) {
		$__TcloveInfo = $__TcloveInfoTmp;
		$last_login_time_cookie = getcookie('tom_tclove_last_login_time');
		if (!$last_login_time_cookie || $last_login_time_cookie != 1) {
			$updateData = array();
			$updateData['last_login_time'] = TIMESTAMP;
			C::t('#tom_tclove#tom_tclove')->update($__TcloveInfo['id'], $updateData);
			$lifeTime = 300;
			dsetcookie('tom_tclove_last_login_time', 1, $lifeTime);
		}
	} else {
		$tui_id = isset($_GET['tui_id']) ? intval($_GET['tui_id']) : 0;
		$tuiInfoTmp = C::t('#tom_tclove#tom_tclove_tui')->fetch_by_id($tui_id);
		$tui_hongniang_id_tmp = 0;
		if ($tuiInfoTmp && $tuiInfoTmp['id'] > 0) {
			$hongniangInfoTmp = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_user_id($tuiInfoTmp['user_id']);
			if ($hongniangInfoTmp['id'] > 0) {
				$tui_hongniang_id_tmp = $hongniangInfoTmp['id'];
			}
		}
		$insertData = array();
		$insertData['site_id'] = $site_id;
		$insertData['user_id'] = $__UserInfo['id'];
		if ($tuiInfoTmp && $tuiInfoTmp['id'] > 0) {
			$insertData['tui_id'] = $tui_id;
		}
		if ($tui_hongniang_id_tmp > 0) {
			$insertData['hongniang_id'] = $tui_hongniang_id_tmp;
		}
		$insertData['xm'] = $__UserInfo['nickname'];
		if ($tcloveConfig['close_tel'] == 1) {
			$insertData['close_tel'] = 1;
		}
		$insertData['add_time'] = TIMESTAMP;
		C::t('#tom_tclove#tom_tclove')->insert($insertData);
		$__TcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($__UserInfo['id']);
		if ($tuiInfoTmp && $tuiInfoTmp['id'] > 0) {
			$updateData = array();
			$updateData['num'] = $tuiInfoTmp['num'] + 1;
			C::t('#tom_tclove#tom_tclove_tui')->update($tuiInfoTmp['id'], $updateData);
		}
	}
	$__TclovetuiInfo = C::t('#tom_tclove#tom_tclove_tui')->fetch_by_user_id($__UserInfo['id']);
	if ($__TclovetuiInfo['id'] <= 0) {
		$insertData = array();
		$insertData['user_id'] = $__UserInfo['id'];
		C::t('#tom_tclove#tom_tclove_tui')->insert($insertData);
		$__TclovetuiInfo = C::t('#tom_tclove#tom_tclove_tui')->fetch_by_user_id($__UserInfo['id']);
	}
	$shareUrl = $shareUrl . ('&tui_id=' . $__TclovetuiInfo['id']);
}
$phone_back_url = $weixinClass->get_url();
$phone_back_url = urlencode($phone_back_url);
$phoneUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=phone&phone_back=' . $phone_back_url;
$renzheng_back_url = $weixinClass->get_url();
$renzheng_back_url = urlencode($renzheng_back_url);
$personalRenzhengUrl = 'plugin.php?id=tom_tcrenzheng&site=' . $site_id . '&mod=personal&renzheng_back=' . $renzheng_back_url;
$ajaxLoadListUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
$searchUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=get_search_url';
$ajaxAddShoucangUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=addshoucang';
$ajaxDelShoucangUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=delshoucang';
$ajaxClicksUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=clicks&formhash=' . $formhash;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
if ($__TcloveInfo['status'] == 2 && $_GET['mod'] != 'my') {
	dheader('location:' . $_G['siteurl'] . 'plugin.php?id=tom_tclove&mod=my');
	exit(0);
}
$template_color_rgb = '';
if (!empty($tcloveConfig['template_color'])) {
	$template_color_rgb = hex2rgbstr($tcloveConfig['template_color']);
}
if ($_GET['mod'] == 'index') {
	if ($tcloveConfig['open_select_sites'] == 1 && $tcadminConfig['open_sites'] == 1) {
		include DISCUZ_ROOT . './source/plugin/tom_tclove/module/site_lbs.php';
	}
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 1;
	if ($tcloveConfig['show_all_sites'] == 1) {
		$userNum = C::t('#tom_tclove#tom_tclove')->fetch_all_count(' ');
	} else {
		$userNum = C::t('#tom_tclove#tom_tclove')->fetch_all_count(' AND site_id IN(' . $sql_in_site_ids . ')  ');
	}
	$userNum = $userNum + $tcloveConfig['virtual_user_num'];
	$userNumTxt = $userNum;
	if ($userNum > 10000) {
		$userNumTmp = $userNum / 10000;
		$userNumTxt = number_format($userNumTmp, 2);
	}
	if ($tcloveConfig['show_all_sites'] == 1) {
		$tcloveClicks = C::t('#tom_tclove#tom_tclove_clicks')->fetch_all_sun_clicks(' ');
	} else {
		$tcloveClicks = C::t('#tom_tclove#tom_tclove_clicks')->fetch_all_sun_clicks(' AND site_id IN(' . $sql_in_site_ids . ') ');
	}
	$clicksNum = $tcloveClicks + $tcloveConfig['virtual_clicks'];
	$clicksNumTxt = $clicksNum;
	if ($clicksNum > 10000) {
		$clicksNumTmp = $clicksNum / 10000;
		$clicksNumTxt = number_format($clicksNumTmp, 2, '.', '');
	}
	$line3NavList = array();
	if (!empty($tcloveConfig['index_line3_nav'])) {
		$index_line3_str = str_replace("\r\n", '{n}', trim($tcloveConfig['index_line3_nav']));
		$index_line3_str = str_replace("\n", '{n}', $index_line3_str);
		$index_line3_str = str_replace('{site}', $site_id, $index_line3_str);
		$index_line3_arr = explode('{n}', $index_line3_str);
		if (is_array($index_line3_arr) && !empty($index_line3_arr)) {
			foreach ($index_line3_arr as $key => $value) {
				$line3NavList[] = explode('|', $value);
			}
		}
	}
	$line3NavCount = count($line3NavList);
	$focuspicData = C::t('#tom_tclove#tom_tclove_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' ', 'ORDER BY fsort ASC,id DESC', 0, 20);
	if (!is_array($focuspicData) || empty($focuspicData)) {
		$focuspicData = C::t('#tom_tclove#tom_tclove_focuspic')->fetch_all_list(' AND site_id=1 ', 'ORDER BY fsort ASC,id DESC', 0, 20);
	}
	$focuspicList = array();
	if (is_array($focuspicData) && !empty($focuspicData)) {
		foreach ($focuspicData as $key => $value) {
			$focuspicList[$key] = $value;
			$focuspicList[$key]['title'] = dhtmlspecialchars($value['title']);
			if (!preg_match('/^http/', $value['picurl'])) {
				$focuspicList[$key]['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
			} else {
				$focuspicList[$key]['picurl'] = $value['picurl'];
			}
		}
	}
	$diyListTmp = C::t('#tom_tclove#tom_tclove_diynav')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY dsort ASC,id DESC ', 0, 100);
	if (!is_array($diyListTmp) || empty($diyListTmp)) {
		$diyListTmp = C::t('#tom_tclove#tom_tclove_diynav')->fetch_all_list(' AND site_id=1 ', ' ORDER BY dsort ASC,id DESC ', 0, 100);
	}
	$diyList = array();
	$i = 1;
	$navCount = 0;
	if (is_array($diyListTmp) && !empty($diyListTmp)) {
		foreach ($diyListTmp as $key => $value) {
			$diyList[$key] = $value;
			$diyList[$key]['i'] = $i;
			$diyList[$key]['link'] = str_replace('{site}', $site_id, $diyList[$key]['link']);
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$diyList[$key]['picurl'] = $picurl;
			$i++;
			$navCount++;
		}
	}
	$agree_safe_msg = dhtmlspecialchars($tcloveConfig['agree_safe_msg']);
	$agree_safe_msg = discuzcode($agree_safe_msg, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);
	$sex = 0;
	$ordertype = 'default';
	if ($tab == 2) {
		$sex = 1;
	} elseif ($tab == 3) {
		$sex = 2;
	} elseif ($tab == 4) {
		$ordertype = 'lbs';
	}
	$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
	$ajaxLoadListUrl = $ajaxLoadListUrl . ('&sex=' . $sex . '&ordertype=' . $ordertype);
	$wanshanUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=wanshan&formhash=' . FORMHASH;
	$vipUpdateUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=vipUpdate&formhash=' . FORMHASH;
	$topUpdateUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=topUpdate&formhash=' . FORMHASH;
	$ajaxAgreeUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=agree';
	$xihuanAjaxUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=xihuan&formhash=' . FORMHASH;
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tclove/images/index.js';
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=index&tab=' . $tab));
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:index');
	echo '<script src="source/plugin/tom_tclove/images/index.js"></script>';
} elseif ($_GET['mod'] == 'info') {
	$tclove_id = isset($_GET['tclove_id']) ? intval($_GET['tclove_id']) : 0;
	$loveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
	if (!$loveInfo || $loveInfo['id'] <= 0) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	if ($__UserInfo['groupid'] != 1 && $__UserInfo['groupid'] != 2) {
		if ($__UserInfo['id'] != $tcloveConfig['tclovemanage_user_id']) {
			if ($loveInfo['is_open'] != 1) {
				dheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tclove&mod=close&tclove_id=' . $loveInfo['id']));
				exit(0);
			}
			if ($loveInfo['shenhe_status'] != 1 || $loveInfo['status'] != 1) {
				dheader('location:' . $_G['siteurl'] . 'plugin.php?id=tom_tclove&mod=index');
				exit(0);
			}
		}
	}
	$userpic = tom_tclove_avatar($tclove_id);
	$photoData = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list(' AND tclove_id = ' . $tclove_id . ' AND type = 1', 'ORDER BY id DESC', 0, 100);
	$photoList = array();
	if (is_array($photoData) && !empty($photoData)) {
		foreach ($photoData as $key => $value) {
			$photoList[$key] = $value;
			$photoList[$key]['pic_url'] = $value['picurlTmp'];
		}
	}
	$picListAll = array();
	$picListStr = '';
	$picListCount = 0;
	if (is_array($photoData) && !empty($photoData)) {
		foreach ($photoData as $key => $value) {
			$picurlTmp = $value['picurlTmp'];
			$picListAll[] = $picurlTmp;
		}
		$picListStr = implode('|', $picListAll);
		$picListCount = count($picListAll);
	}
	$juzhuCityInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($loveInfo['city_id']);
	$juzhuAreaInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($loveInfo['area_id']);
	$hujiCityInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($loveInfo['hjcity_id']);
	$hujiAreaInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($loveInfo['hjarea_id']);
	if ($loveInfo['birth_year'] > 0) {
		if ($tcloveConfig['age_type_id'] == 1) {
			$age = $nowYear - $loveInfo['birth_year'];
		} else {
			$age = $nowYear - $loveInfo['birth_year'] + 1;
		}
	} else {
		$age = '';
	}
	if ($__UserInfo['id'] > 0) {
		$isCollect = C::t('#tom_tclove#tom_tclove_collect')->fetch_all_list('AND user_id = ' . $__UserInfo['id'] . ' AND tclove_id =' . $loveInfo['id'], ' ORDER BY id DESC ', 0, 1);
	}
	$chakanTag = $showChakanXz = $overChakanNum = $shengyuChakanNum = 0;
	if ($__UserInfo['id'] > 0) {
		$chakanData = C::t('#tom_tclove#tom_tclove_chakan')->fetch_by_user_tclove_id($__UserInfo['id'], $loveInfo['id']);
		if ($chakanData['id'] > 0 || $loveInfo['user_id'] == $__UserInfo['id']) {
			$chakanTag = 1;
		}
		$vipInfo = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($__TcloveInfo['vip_id']);
		if ($vipInfo['chakan_times'] > 0) {
			$showChakanXz = 1;
		}
		if ($showChakanXz == 1) {
			$chakanCount = C::t('#tom_tclove#tom_tclove_chakan')->fetch_all_count(' AND user_id=' . $__UserInfo['id'] . ' AND time_key=' . $nowDayTime . ' ');
			if ($chakanCount >= $vipInfo['chakan_times']) {
				$overChakanNum = 1;
			} else {
				$shengyuChakanNum = $vipInfo['chakan_times'] - $chakanCount;
			}
		}
	}
	$tongchengUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($loveInfo['user_id']);
	$personalRenzhengStatus = 0;
	if ($__ShowTcrenzheng == 1) {
		$renzhengPersonalInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_all_list(' AND user_id = ' . $loveInfo['user_id'] . ' AND shenhe_status = 1 ', 'ORDER BY id DESC', 0, 1);
		if (is_array($renzhengPersonalInfoTmp) && !empty($renzhengPersonalInfoTmp[0])) {
			$personalRenzhengStatus = 1;
		}
	}
	$videoList = C::t('#tom_tclove#tom_tclove_video')->fetch_all_list(' AND tclove_id = ' . $loveInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
	$video_pic = '';
	if (!preg_match('/^http/', $videoList[0]['video_pic'])) {
		if (strpos($videoList[0]['video_pic'], 'source/plugin/tom_') === false) {
			$video_pic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $videoList[0]['video_pic'];
		} else {
			$video_pic = $videoList[0]['video_pic'];
		}
	} else {
		$video_pic = $videoList[0]['video_pic'];
	}
	$isHongniangCount = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_all_count('AND user_id = ' . $__UserInfo['id']);
	if ($tcloveConfig['open_hongniang_look_limit'] == 1) {
		$isHongniangInfo = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_user_id($__UserInfo['id']);
		if ($loveInfo['hongniang_id'] != $isHongniangInfo['id']) {
			$isHongniangCount = 0;
		}
	}
	$showMoreInfo = 1;
	if ($tcloveConfig['vip_show_more_info'] == 1) {
		if ($__TcloveInfo['vip_id'] <= 0 && $isHongniangCount <= 0 && $loveInfo['user_id'] != $__UserInfo['id']) {
			$showMoreInfo = 0;
		}
	}
	$showZheouDesc = 1;
	if ($tcloveConfig['vip_show_zheou_desc'] == 1) {
		if ($__TcloveInfo['vip_id'] <= 0 && $isHongniangCount <= 0 && $loveInfo['user_id'] != $__UserInfo['id']) {
			$showZheouDesc = 0;
		}
	}
	$showVideoBox = 0;
	if ($__TcloveInfo['vip_id'] > 0 || $isHongniangCount > 0) {
		if ($tcloveConfig['open_look_video'] == 1) {
			if ($__TcloveInfo['video_status'] == 1) {
				$showVideoBox = 1;
			} else {
				$showVideoBox = 3;
			}
		} else {
			$showVideoBox = 1;
		}
	} else {
		$showVideoBox = 2;
	}
	$xihuancount = C::t('#tom_tclove#tom_tclove_xihuan')->fetch_all_count(' AND tclove_id = ' . $tclove_id . ' ');
	$xihuanInfoTmp = C::t('#tom_tclove#tom_tclove_xihuan')->fetch_all_list(' AND tclove_id = ' . $tclove_id . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
	$talkCount = C::t('#tom_tclove#tom_tclove_talk')->fetch_all_count('AND tclove_id = ' . $tclove_id);
	$myHongniangCount = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_all_count('AND id = ' . $__TcloveInfo['hongniang_id']);
	if ($myHongniangCount > 0) {
		$hongniangInfo = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_id($__TcloveInfo['hongniang_id']);
		if (!preg_match('/^http/', $hongniangInfo['picurl'])) {
			if (strpos($hongniangInfo['picurl'], 'source/plugin/tom_') === false) {
				$hongniangPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $hongniangInfo['picurl'];
			} else {
				$hongniangPicurl = $_G['siteurl'] . $hongniangInfo['picurl'];
			}
		} else {
			$hongniangPicurl = $hongniangInfo['picurl'];
		}
		if (!preg_match('/^http/', $hongniangInfo['qrcode'])) {
			if (strpos($hongniangInfo['qrcode'], 'source/plugin/tom_') === false) {
				$hongniangQrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $hongniangInfo['qrcode'];
			} else {
				$hongniangQrcode = $_G['siteurl'] . $hongniangInfo['qrcode'];
			}
		} else {
			$hongniangQrcode = $hongniangInfo['qrcode'];
		}
	} else {
		$hongniangListTmp = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_all_list('', 'ORDER BY paixu ASC,id DESC', 0, 50);
		$hongniangList = array();
		if (is_array($hongniangListTmp) && !empty($hongniangListTmp)) {
			foreach ($hongniangListTmp as $key => $value) {
				$hongniangList[$key] = $value;
				if (!preg_match('/^http/', $value['picurl'])) {
					if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
						$hongniangList[$key]['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
					} else {
						$hongniangList[$key]['picurl'] = $_G['siteurl'] . $value['picurl'];
					}
				} else {
					$hongniangList[$key]['picurl'] = $value['picurl'];
				}
				if (!preg_match('/^http/', $value['qrcode'])) {
					if (strpos($value['qrcode'], 'source/plugin/tom_') === false) {
						$hongniangList[$key]['qrcode'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['qrcode'];
					} else {
						$hongniangList[$key]['qrcode'] = $_G['siteurl'] . $value['qrcode'];
					}
				} else {
					$hongniangList[$key]['qrcode'] = $value['qrcode'];
				}
			}
		}
	}
	if ($__UserInfo['id'] > 0 && $__TcloveInfo['is_ok'] == 1 && $loveInfo['is_ok'] == 1) {
		$lookList = C::t('#tom_tclove#tom_tclove_look')->fetch_all_list('AND tclove_id = ' . $loveInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
		if (is_array($lookList) && !empty($lookList)) {
			$updateData = array();
			$updateData['add_time'] = TIMESTAMP;
			C::t('#tom_tclove#tom_tclove_look')->update($lookList[0]['id'], $updateData);
		} else {
			$insertData = array();
			$insertData['tclove_id'] = $loveInfo['id'];
			$insertData['user_id'] = $__UserInfo['id'];
			$insertData['add_time'] = TIMESTAMP;
			C::t('#tom_tclove#tom_tclove_look')->insert($insertData);
		}
	}
	$shareTitle = $tcloveConfig['info_share_title'];
	$shareTitle = str_replace('{NAME}', $loveInfo['xm'], $shareTitle);
	if ($loveInfo['sex'] == 1) {
		$shareTitle = str_replace('{SEX}', lang('plugin/tom_tclove', 'man'), $shareTitle);
	} elseif ($loveInfo['sex'] == 2) {
		$shareTitle = str_replace('{SEX}', lang('plugin/tom_tclove', 'woman'), $shareTitle);
	}
	$shareTitle = str_replace('{AGE}', $age, $shareTitle);
	$shareLogo = $userpic;
	$shareDesc = $loveInfo['describe'];
	$shareDesc = str_replace("\n", '', $shareDesc);
	$shareDesc = str_replace("\r", '', $shareDesc);
	$shareDesc = str_replace("\r\n", '', $shareDesc);
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=info&tclove_id=' . $loveInfo['id'] . '&tui_id=' . $__TclovetuiInfo['id']);
	$tcloveConfig['info_haibao_man_bg'] = trim($tcloveConfig['info_haibao_man_bg']);
	if ($loveInfo['sex'] == 1 && !empty($tcloveConfig['info_haibao_man_bg'])) {
		$tcloveConfig['info_haibao_bg'] = $tcloveConfig['info_haibao_man_bg'];
	}
	$haibaoShareUrl = $shareUrl;
	$haibaoQrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($shareUrl);
	$chakanUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=chakan&user_id=' . $__UserInfo['id'] . '&tclove_id=' . $loveInfo['id'] . '&formhash=' . FORMHASH;
	$ajaxTalkUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&tclove_id=' . $loveInfo['id'] . '&act=talklist';
	$talkZanAjaxUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=talkZan&formhash=' . FORMHASH;
	$xihuanAjaxUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=xihuan&formhash=' . FORMHASH;
	$messageUrl = 'plugin.php?id=tom_tclove&site=' . $site_id . '&mod=message&act=create&to_user_id=' . $loveInfo['user_id'] . '&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:info');
} elseif ($_GET['mod'] == 'list') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 1;
	$video_status = isset($_GET['video_status']) ? intval($_GET['video_status']) : 0;
	$sex = isset($_GET['sex']) ? intval($_GET['sex']) : 0;
	$xm = isset($_GET['xm']) ? daddslashes(urldecode($_GET['xm'])) : '';
	$shouru = isset($_GET['shouru']) ? intval($_GET['shouru']) : 0;
	$age = isset($_GET['age']) ? intval($_GET['age']) : 0;
	$height = isset($_GET['height']) ? intval($_GET['height']) : 0;
	$edu = isset($_GET['edu']) ? daddslashes(urldecode($_GET['edu'])) : '';
	$province_id = isset($_GET['province_id']) ? intval($_GET['province_id']) : 0;
	$city_id = isset($_GET['city_id']) ? intval($_GET['city_id']) : 0;
	$area_id = isset($_GET['area_id']) ? intval($_GET['area_id']) : 0;
	$towns_id = isset($_GET['towns_id']) ? intval($_GET['towns_id']) : 0;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$user_no = isset($_GET['user_no']) ? intval($_GET['user_no']) : 0;
	$marital = isset($_GET['marital']) ? intval($_GET['marital']) : 0;
	if (!is_numeric($keyword)) {
		$xm = $keyword;
	} else {
		$user_no = $keyword;
	}
	if ($tab == 2) {
		$sex = 1;
	} elseif ($tab == 3) {
		$sex = 2;
	} elseif ($tab == 4) {
		$video_status = 1;
	}
	$ajaxLoadListUrl = $ajaxLoadListUrl . '&xm=' . urlencode($xm) . ('&sex=' . $sex . '&age=' . $age . '&height=' . $height . '&shouru=' . $shouru . '&edu=' . $edu . '&province_id=' . $province_id . '&city_id=' . $city_id . '&area_id=' . $area_id . '}&towns_id=' . $towns_id . '&user_no=' . $user_no . '&marital=' . $marital . '&video_status=' . $video_status);
	$xihuanAjaxUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=xihuan&formhash=' . FORMHASH;
	if ($__TclovetuiInfo['id'] > 0) {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=list&tui_id=' . $__TclovetuiInfo['id']);
	} else {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=list');
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=list&xm=') . urlencode($xm) . ('&sex=' . $sex . '&age=' . $age . '&height=' . $height . '&shouru=' . $shouru . '&edu=' . $edu . '&province_id=' . $province_id . '&city_id=' . $city_id . '&area_id=' . $area_id . '}&towns_id=' . $towns_id . '&user_no=' . $user_no . '&marital=' . $marital . '&video_status=' . $video_status));
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:list');
} elseif ($_GET['mod'] == 'search') {
	$sex = isset($_GET['sex']) ? intval($_GET['sex']) : 0;
	$age = isset($_GET['age']) ? intval($_GET['age']) : 0;
	$height = isset($_GET['height']) ? intval($_GET['height']) : 0;
	$shouru = isset($_GET['shouru']) ? intval($_GET['shouru']) : 0;
	$edu = isset($_GET['edu']) ? intval($_GET['edu']) : 0;
	$marital = isset($_GET['marital']) ? intval($_GET['marital']) : 0;
	$province_id = isset($_GET['province_id']) ? intval($_GET['province_id']) : 0;
	$city_id = isset($_GET['city_id']) ? intval($_GET['city_id']) : 0;
	$area_id = isset($_GET['area_id']) ? intval($_GET['area_id']) : 0;
	$towns_id = isset($_GET['towns_id']) ? intval($_GET['towns_id']) : 0;
	$video_status = isset($_GET['video_status']) ? intval($_GET['video_status']) : 0;
	$ordertype = !empty($_GET['ordertype']) ? addslashes($_GET['ordertype']) : 'default';
	$provinceList = $hjprovinceList = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_level(1);
	$cityList = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($info['province_id']);
	$areaList = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($info['city_id']);
	$townsList = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($info['area_id']);
	$hjcityList = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($info['hjprovince_id']);
	$hjareaList = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($info['hjcity_id']);
	$hjtownsList = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($info['hjarea_id']);
	$listUrl = 'plugin.php?id=tom_tclove&site=' . $site_id . '&mod=list';
	if ($__TclovetuiInfo['id'] > 0) {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=search&tui_id=' . $__TclovetuiInfo['id']);
	} else {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=search');
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:search');
} elseif ($_GET['mod'] == 'collect') {
	$ajaxLoadcllectListUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=collectlist&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:collect');
} elseif ($_GET['mod'] == 'chakanwo') {
	$ajaxLoadchakanListUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=chakanlist&chakan=1&formhash=' . $formhash;
	$ajaxAddShoucangUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=addshoucang';
	$xihuanAjaxUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=xihuan&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:chakanwo');
} elseif ($_GET['mod'] == 'wochakan') {
	$ajaxLoadchakanListUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=chakanlist&chakan=2&formhash=' . $formhash;
	$ajaxDellookUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=dellook';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:wochakan');
} elseif ($_GET['mod'] == 'xihuanwo') {
	$ajaxLoadxihuanListUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=xihuanlist&xihuan=1&formhash=' . $formhash;
	$ajaxAddShoucangUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=addshoucang';
	$xihuanAjaxUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=xihuan&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:xihuanwo');
} elseif ($_GET['mod'] == 'woxihuan') {
	$ajaxLoadxihuanListUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=xihuanlist&xihuan=2&formhash=' . $formhash;
	$ajaxDelxihuanUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=delxihuan';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:woxihuan');
} elseif ($_GET['mod'] == 'close') {
	$tclove_id = isset($_GET['tclove_id']) ? intval($_GET['tclove_id']) : 0;
	$tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:close');
} elseif ($_GET['mod'] == 'vip') {
	$nowTime = TIMESTAMP;
	if ($__TcloveInfo['vip_id'] > 0 && $__TcloveInfo['vip_time'] < $nowTime) {
		$updateData = array();
		$updateData['vip_id'] = 0;
		$updateData['vip_time'] = 0;
		C::t('#tom_tclove#tom_tclove')->update($__TcloveInfo['id'], $updateData);
	}
	$userpic = tom_tclove_avatar($__TcloveInfo['id']);
	$vipInfo = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($__TcloveInfo['vip_id']);
	$vip_time = dgmdate($__TcloveInfo['vip_time'], 'Y-m-d', $tomSysOffset);
	$minVipDays = 0;
	if (is_array($vipInfo) && !empty($vipInfo) && $vipInfo['days'] > 0) {
		$minVipDays = $vipInfo['days'];
	}
	$vipListTmp = C::t('#tom_tclove#tom_tclove_vip')->fetch_all_list('', ' ORDER BY vsort ASC,id DESC ', 0, 100);
	$vipList = array();
	if (is_array($vipListTmp) && !empty($vipListTmp)) {
		foreach ($vipListTmp as $key => $value) {
			if ($value['days'] >= $minVipDays) {
				$vipList[$key] = $value;
				if (!preg_match('/^http/', $value['vip_picurl'])) {
					if (strpos($value['vip_picurl'], 'source/plugin/') === false) {
						$vip_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['vip_picurl'];
					} else {
						$vip_picurl = $_G['siteurl'] . $value['vip_picurl'];
					}
				} else {
					$vip_picurl = $value['vip_picurl'];
				}
				$vipfuwuDataTmp = C::t('#tom_tclove#tom_tclove_vip_fuwu')->fetch_all_list('AND vip_id = ' . $value['id'] . ' ', ' ORDER BY id DESC ', 0, 100);
				$vipfuwuList = array();
				if (is_array($vipfuwuDataTmp) && !empty($vipfuwuDataTmp)) {
					foreach ($vipfuwuDataTmp as $k => $v) {
						$vipfuwuList[$k] = $v;
					}
				}
				$vipList[$key]['vipfuwuList'] = $vipfuwuList;
				$vipList[$key]['vip_picurl'] = $vip_picurl;
			}
		}
	}
	$__CommonInfo = C::t('#tom_tclove#tom_tclove_common')->fetch_by_id(1);
	if (!$__CommonInfo) {
		$insertData = array();
		$insertData['id'] = 1;
		C::t('#tom_tclove#tom_tclove_common')->insert($insertData);
	}
	$vip_txt = stripslashes($__CommonInfo['vip_txt']);
	$ufuwuDataTmp = C::t('#tom_tclove#tom_tclove_ufuwu')->fetch_all_list('AND tclove_id = ' . $__TcloveInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 100);
	$ufuwuList = array();
	if (is_array($ufuwuDataTmp) && !empty($ufuwuDataTmp)) {
		foreach ($ufuwuDataTmp as $key => $value) {
			$ufuwuList[$key] = $value;
		}
	}
	$payUrl = 'plugin.php?id=tom_tclove:pay&site=' . $site_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:vip');
} elseif ($_GET['mod'] == 'top') {
	$top_money_listStr = str_replace("\r\n", '{n}', $tcloveConfig['top_money_list']);
	$top_money_listStr = str_replace("\n", '{n}', $top_money_listStr);
	$top_money_listStr = str_replace("\r", '{n}', $top_money_listStr);
	$top_money_listTmpArr = explode('{n}', $top_money_listStr);
	$top_moneyArr = array();
	if (is_array($top_money_listTmpArr) && !empty($top_money_listTmpArr)) {
		foreach ($top_money_listTmpArr as $key => $value) {
			if (!empty($value)) {
				list($month, $price) = explode('|', $value);
				$month = intval($month);
				if (!empty($month) && !empty($price)) {
					$top_moneyArr[$month]['price'] = $price;
					$day_money = $price / $month;
					$top_moneyArr[$month]['day_money'] = number_format($day_money, 2, '.', '');
				}
			}
		}
	}
	$top_time = dgmdate($__TcloveInfo['top_time'], 'Y-m-d', $tomSysOffset);
	$payUrl = 'plugin.php?id=tom_tclove:pay&site=' . $site_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:top');
} elseif ($_GET['mod'] == 'match') {
	if ($__TcloveInfo['is_ok'] == 0) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=edit'));
		exit(0);
	}
	$sexWhere = '';
	if ($__TcloveInfo['sex'] == 1) {
		$sexWhere = ' AND sex = 2 ';
	} else {
		$sexWhere = ' AND sex = 1 ';
	}
	$where = $sexWhere . ' AND is_ok = 1 AND shenhe_status = 1 AND status = 1 AND is_open = 1';
	$whereStr = $sexWhere . ' AND is_ok = 1 AND shenhe_status = 1 AND status = 1 AND is_open = 1';
	if ($__TcloveInfo['zheou_marital_id'] != 99) {
		$where .= ' AND marital_id = ' . $__TcloveInfo['zheou_marital_id'] . ' ';
	}
	if ($__TcloveInfo['zheou_min_age'] > 0 && $__TcloveInfo['zheou_max_age'] > 0) {
		if ($tcloveConfig['age_type_id'] == 1) {
			$startYear = $nowYear - $__TcloveInfo['zheou_max_age'];
			$endYear = $nowYear - $__TcloveInfo['zheou_min_age'];
		} else {
			$startYear = $nowYear - $__TcloveInfo['zheou_max_age'] + 1;
			$endYear = $nowYear - $__TcloveInfo['zheou_min_age'] + 1;
		}
		$where .= ' AND birth_year >= ' . $startYear . ' AND birth_year <= ' . $endYear;
	}
	$userCount = C::t('#tom_tclove#tom_tclove')->fetch_all_count($where);
	if ($userCount > 0) {
		$userListTmp = C::t('#tom_tclove#tom_tclove')->fetch_all_list($where, 'ORDER BY id DESC', 0, 10);
	} else {
		$userListTmp = C::t('#tom_tclove#tom_tclove')->fetch_all_list($whereStr, 'ORDER BY id DESC', 0, 10);
	}
	$userList = array();
	if (is_array($userListTmp) && !empty($userListTmp)) {
		foreach ($userListTmp as $key => $value) {
			$userList[$key] = $value;
			$isXihuan = C::t('#tom_tclove#tom_tclove_xihuan')->fetch_all_list('AND user_id = ' . $__UserInfo['id'] . ' AND tclove_id =' . $value['id'], ' ORDER BY id DESC ', 0, 1);
			$userList[$key]['pic_url'] = tom_tclove_avatar($value['id']);
			if ($value['birth_year'] > 0) {
				if ($tcloveConfig['age_type_id'] == 1) {
					$userList[$key]['age'] = $nowYear - $value['birth_year'];
				} else {
					$userList[$key]['age'] = $nowYear - $value['birth_year'] + 1;
				}
			} else {
				$userList[$key]['age'] = '';
			}
			$renzhengPersonalInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_all_list(' AND user_id = ' . $value['user_id'] . ' AND shenhe_status = 1 ', 'ORDER BY id DESC', 0, 1);
			$tongchengUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$xihuancount = C::t('#tom_tclove#tom_tclove_xihuan')->fetch_all_count(' AND tclove_id = ' . $value['id'] . ' ');
			$userList[$key]['isXihuan'] = $isXihuan;
			$userList[$key]['xihuancount'] = $xihuancount;
			$userList[$key]['tongchengUserInfoTmp'] = $tongchengUserInfoTmp;
			$userList[$key]['renzhengPersonalInfoTmp'] = $renzhengPersonalInfoTmp;
		}
	}
	$xihuanAjaxUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=xihuan&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:match');
} elseif ($_GET['mod'] == 'report') {
	$report_user_id = isset($_GET['report_user_id']) ? intval($_GET['report_user_id']) : 0;
	$reportUserInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($report_user_id);
	$act = isset($_GET['act']) ? trim($_GET['act']) : '';
	$report_from = isset($_GET['report_from']) ? daddslashes($_GET['report_from']) : '';
	if ($act == 'save' && submitcheck('report_user_id')) {
		if ('utf-8' != CHARSET) {
			if (!defined('IN_MOBILE')) {
				foreach ($_POST as $pk => $pv) {
					if (!is_numeric($pv)) {
						$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
					}
				}
			}
		}
		$outArr = array('status' => 200);
		$report_user_id = isset($_GET['report_user_id']) ? intval($_GET['report_user_id']) : 0;
		$report_content = isset($_GET['report_content']) ? addslashes($_GET['report_content']) : '';
		$bmpicliArr = array();
		if (is_array($_GET['bmpicli']) && !empty($_GET['bmpicli'])) {
			foreach ($_GET['bmpicli'] as $key => $value) {
				$bmpicliArr[] = daddslashes($value);
			}
		}
		$insertData = array();
		$insertData['user_id'] = $__UserInfo['id'];
		$insertData['report_user_id'] = $report_user_id;
		$insertData['report_content'] = $report_content;
		$insertData['report_pic_1'] = $bmpicliArr[0];
		$insertData['report_pic_2'] = $bmpicliArr[1];
		$insertData['report_time'] = TIMESTAMP;
		C::t('#tom_tclove#tom_tclove_report')->insert($insertData);
		$toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
		include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/templatesms.class.php';
		$access_token = $weixinClass->get_access_token();
		$smsContent = strip_tags($report_content);
		if ($access_token && !empty($toUser['openid'])) {
			$templateSmsClass = new templateSms($access_token, $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $reportUserInfo['site_id'] . '&mod=info&tclove_id=' . $reportUserInfo['id']));
			$template_first = str_replace('{NAME}', $__TcloveInfo['xm'], lang('plugin/tom_tclove', 'report_template_first'));
			$template_first = str_replace('{REPORTNAME}', $reportUserInfo['xm'], $template_first);
			$smsData = array('first' => $template_first, 'keyword1' => $tcloveConfig['plugin_name'], 'keyword2' => $smsContent, 'remark' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s', $tomSysOffset));
			@($r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData));
		}
		$tclovemanageUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveConfig['tclovemanage_user_id']);
		$access_token = $weixinClass->get_access_token();
		if ($access_token && !empty($tclovemanageUserInfo['openid'])) {
			$templateSmsClass = new templateSms($access_token, $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $reportUserInfo['site_id'] . '&mod=info&tclove_id=' . $reportUserInfo['id']));
			$template_first = str_replace('{NAME}', $__TcloveInfo['xm'], lang('plugin/tom_tclove', 'report_template_first'));
			$template_first = str_replace('{REPORTNAME}', $reportUserInfo['xm'], $template_first);
			$smsData = array('first' => $template_first, 'keyword1' => $tcloveConfig['plugin_name'], 'keyword2' => $smsContent, 'remark' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s', $tomSysOffset));
			@($r = $templateSmsClass->sendSms01($tclovemanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData));
		}
		echo json_encode($outArr);
		exit(0);
	}
	$uploadUrl = 'plugin.php?id=tom_tclove&mod=upload&act=report&formhash=' . FORMHASH;
	$reportUrl = 'plugin.php?id=tom_tclove&mod=report';
	$wxUploadUrl2 = 'plugin.php?id=tom_tclove:wxMediaDownload&site=' . $site_id . '&act=pic&tclove_id=' . $tcloveInfo['id'] . '&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:report');
} elseif ($_GET['mod'] == 'talk') {
	$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 0;
	if ($tab == 4) {
		if ($__TcloveInfo['vip_time'] <= TIMESTAMP) {
			tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=talk'));
			exit(0);
		}
	}
	$ajaxTalkUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&tab=' . $tab . '&act=talklist';
	$talkZanAjaxUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=talkZan&formhash=' . FORMHASH;
	$deltalkUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=del_talk&formhash=' . FORMHASH;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=talk&tui_id=' . $__TclovetuiInfo['id'] . '&tab=' . $tab);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:talk');
} elseif ($_GET['mod'] == 'talkinfo') {
	$talk_id = isset($_GET['talk_id']) ? intval($_GET['talk_id']) : 0;
	$talkInfo = C::t('#tom_tclove#tom_tclove_talk')->fetch_by_id($talk_id);
	if ($__UserInfo['groupid'] != 1 && $__UserInfo['groupid'] != 2 && $talkInfo['shenhe_status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=talk'));
		exit(0);
	}
	if ($talkInfo['must_vip'] == 1) {
		if ($__TcloveInfo['vip_time'] <= TIMESTAMP) {
			tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=talk'));
			exit(0);
		}
	}
	$talk_time = dgmdate($talkInfo['talk_time'], 'm-d H:i', $tomSysOffset);
	$clicks = $talkInfo['clicks'];
	$talk_avatar = tom_tclove_avatar($talkInfo['tclove_id']);
	$pinglun_avatar = tom_tclove_avatar($__TcloveInfo['id']);
	$talkInfo['content'] = tom_num_replace(dhtmlspecialchars($talkInfo['content']));
	$talkInfo['content'] = str_replace("\r\n", '<br/>', $talkInfo['content']);
	$talkInfo['content'] = str_replace("\n", '<br/>', $talkInfo['content']);
	$talkInfo['content'] = str_replace("\r", '<br/>', $talkInfo['content']);
	$talkPinglunCount = C::t('#tom_tclove#tom_tclove_talk_pinglun')->fetch_all_count(' AND talk_id=' . $talk_id);
	$talkTcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($talkInfo['tclove_id']);
	$open_edit_pinglun = 0;
	if ($talkInfo['tclove_id'] == $__TcloveInfo['id'] && $tongchengConfig['open_fbr_remove_pinglun'] == 1) {
		$open_edit_pinglun = 1;
	} else {
		if ($__UserInfo['groupid'] == 1 && $site_id == 1) {
			$open_edit_pinglun = 1;
		} else {
			if ($__UserInfo['groupid'] == 2 && $site_id == $__UserInfo['groupsiteid']) {
				$open_edit_pinglun = 1;
			}
		}
	}
	$must_phone_projectArr = unserialize($tongchengConfig['must_phone_project']);
	$showMustPhoneBtn = 0;
	if (array_search('2', $must_phone_projectArr) !== false && empty($__UserInfo['tel']) && $__UserInfo['editor'] == 0 && $__UserInfo['is_majia'] == 0) {
		$showMustPhoneBtn = 1;
		$phone_back_url = $weixinClass->get_url();
		$phone_back_url = urlencode($phone_back_url);
		$phoneUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=phone&phone_back=' . $phone_back_url;
	}
	$talkvideoInfo = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list('AND talk_id = ' . $talk_id . ' AND type = 3', 'ORDER BY id ASC', 0, 1);
	$talkphotoListTmp = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list('AND talk_id = ' . $talk_id . ' AND type = 2', 'ORDER BY id ASC', 0, 100);
	$talkphotoList = array();
	$talkphotoListStr = '';
	if (is_array($talkphotoListTmp) && !empty($talkphotoListTmp)) {
		foreach ($talkphotoListTmp as $kk => $vv) {
			$picurlTmp = $vv['picurlTmp'];
			$talkphotoList[] = $picurlTmp;
		}
		$talkphotoListStr = implode('|', $talkphotoList);
	}
	$talkphotoCount = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_count('AND talk_id = ' . $talk_id . ' AND type = 2');
	$talkZanInfoTmp = C::t('#tom_tclove#tom_tclove_talk_zan')->fetch_all_list(' AND talk_id=' . $talk_id . ' AND tclove_id = ' . $__TcloveInfo['id'], 'ORDER BY id DESC', 0, 1);
	$talkZanData = C::t('#tom_tclove#tom_tclove_talk_zan')->fetch_all_list(' AND talk_id=' . $talk_id, 'ORDER BY id DESC', 0, 20);
	$talkZanList = array();
	if (is_array($talkZanData) && !empty($talkZanData)) {
		foreach ($talkZanData as $kk => $vv) {
			$talkZanList[$kk] = $vv;
			$talkZanList[$kk]['avatar'] = tom_tclove_avatar($vv['tclove_id']);
		}
	}
	$addPinglunUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=pinglun&talk_id=' . $talk_id . '&formhash=' . FORMHASH;
	$removePinglunUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=removePinglun&talk_id=' . $talk_id . '&formhash=' . FORMHASH;
	$ajaxLoadPinglunUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=loadPinglun&talk_id=' . $talk_id . '&formhash=' . FORMHASH;
	$replyZanAjaxUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=replyZan&talk_id=' . $talk_id . '&formhash=' . FORMHASH;
	$talkZanAjaxUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=talkZan&formhash=' . FORMHASH;
	$ajaxTalkClicksUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=talkClicks&talk_id=' . $talk_id . '&formhash=' . $formhash;
	$ajaxTalkUpdateUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&act=talkUpdate&talk_id=' . $talk_id . '&formhash=' . $formhash;
	$ajaxTalk_zanlistUrl = 'plugin.php?id=tom_tclove:ajax&site=' . $site_id . '&talk_id=' . $talk_id . '&act=talk_zanlist';
	$shareTitle = $tcloveConfig['talkinfo_share_title'];
	$shareTitle = str_replace('{NAME}', $talkTcloveInfo['xm'], $shareTitle);
	$shareLogo = $talk_avatar;
	$shareDesc = $talkInfo['content'];
	$shareDesc = str_replace("\n", '', $shareDesc);
	$shareDesc = str_replace("\r", '', $shareDesc);
	$shareDesc = str_replace("\r\n", '', $shareDesc);
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=talkinfo&talk_id=' . $talkInfo['id']);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tclove:talkinfo');
} elseif ($_GET['mod'] == 'fabutalk') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/fabutalk.php';
} elseif ($_GET['mod'] == 'tui') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/tui.php';
} elseif ($_GET['mod'] == 'tui_list') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/tui_list.php';
} elseif ($_GET['mod'] == 'tui_shouyi_log') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/tui_shouyi_log.php';
} elseif ($_GET['mod'] == 'hongniang_shenqing') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/hongniang_shenqing.php';
} elseif ($_GET['mod'] == 'my') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/my.php';
} elseif ($_GET['mod'] == 'myhongniang') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/myhongniang.php';
} elseif ($_GET['mod'] == 'myfuwu') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/myfuwu.php';
} elseif ($_GET['mod'] == 'buyfuwu') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/buyfuwu.php';
} elseif ($_GET['mod'] == 'mytalkList') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/mytalkList.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/edit.php';
} elseif ($_GET['mod'] == 'edit_video') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/edit_video.php';
} elseif ($_GET['mod'] == 'edit_fujin') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/edit_fujin.php';
} elseif ($_GET['mod'] == 'managerList') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/managerList.php';
} elseif ($_GET['mod'] == 'managerTalkList') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/managerTalkList.php';
} elseif ($_GET['mod'] == 'managerHongniang') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/managerHongniang.php';
} elseif ($_GET['mod'] == 'managerHongniangList') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/managerHongniangList.php';
} elseif ($_GET['mod'] == 'managerHongniang_edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/managerHongniang_edit.php';
} elseif ($_GET['mod'] == 'managerHongniang_renling') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/managerHongniang_renling.php';
} elseif ($_GET['mod'] == 'managerHongniang_shouyi_log') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/managerHongniang_shouyi_log.php';
} elseif ($_GET['mod'] == 'managerFuwu') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/managerFuwu.php';
} elseif ($_GET['mod'] == 'message') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/message.php';
} elseif ($_GET['mod'] == 'buysms') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/buysms.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/upload.php';
} elseif ($_GET['mod'] == 'baidumap') {
	include DISCUZ_ROOT . './source/plugin/tom_tclove/module/baidumap.php';
} else {
	dheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tclove&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();