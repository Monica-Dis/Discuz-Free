<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.cn
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tcloveConfig       = $_G['cache']['plugin']['tom_tclove'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset       = getglobal('setting/timeoffset');
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass        = new weixinClass($appid,$appsecret);

$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);

include DISCUZ_ROOT.'./source/plugin/tom_tclove/class/tui_phb.func.php';

## tcadmin start
$__ShowTcadmin = 0;
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
    if($tcadminConfig['open_fc'] == 1){
        $__ShowTcadmin = 1;
    }
}
## tcadmin end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

$orderInfo = C::t('#tom_tclove#tom_tclove_order')->fetch_by_order_no($order_no);

if($orderInfo && $orderInfo['order_status'] == 1){
    $updateData = array();
    $updateData['order_status'] = 2;
    $updateData['pay_time'] = TIMESTAMP;
    C::t('#tom_tclove#tom_tclove_order')->update($orderInfo['id'],$updateData);

    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($orderInfo['order_no'])));
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($orderInfo['tclove_id']);
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 

    if($orderInfo['order_type'] == 1){
        
        $top_time = TIMESTAMP;
        if($tcloveInfo['top_time'] > TIMESTAMP){
            $top_time = $tcloveInfo['top_time'] + $orderInfo['time_value']*86400;
        }else{
            $top_time = TIMESTAMP + $orderInfo['time_value']*86400;
        }
        
        $updateData = array();
        $updateData['top_time']     = $top_time;
        $updateData['top_do_time']  = TIMESTAMP;
        $updateData['top_status']   = 1;
        C::t('#tom_tclove#tom_tclove')->update($tcloveInfo['id'],$updateData);
        
    }else if($orderInfo['order_type'] == 2){
        
        $vipInfo = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($orderInfo['vip_id']);
        
        $vip_time = TIMESTAMP;
        if($tcloveInfo['vip_time'] > TIMESTAMP){
            $vip_time = $tcloveInfo['vip_time'] + $vipInfo['days']*86400;
        }else{
            $vip_time = TIMESTAMP + $vipInfo['days']*86400;
        }
        $sms_times = $tcloveInfo['sms_times'] + $vipInfo['sms_times'];
        $updateData = array();
        $updateData['vip_id']   = $orderInfo['vip_id'];
        $updateData['vip_time'] = $vip_time;
        $updateData['sms_times'] = $sms_times;
        C::t('#tom_tclove#tom_tclove')->update($tcloveInfo['id'],$updateData);
        
        if($vipInfo['sms_times'] > 0){
            $insertData = array();
            $insertData['user_id']         = $tcloveInfo['user_id'];
            $insertData['change_times']    = $vipInfo['sms_times'];
            $insertData['old_times']       = $tcloveInfo['sms_times'];
            $insertData['op_type']         = 4;
            $insertData['op_user_id']      = $tcloveInfo['user_id'];
            $insertData['op_time']        = TIMESTAMP;
            C::t('#tom_tclove#tom_tclove_pm_log')->insert($insertData);
        }
        
        $vipfuwuData = C::t('#tom_tclove#tom_tclove_vip_fuwu')->fetch_all_list("AND vip_id = {$orderInfo['vip_id']}"," ORDER BY id DESC ",0,100);
        $vipfuwuList = array();
        if(is_array($vipfuwuData) && !empty($vipfuwuData)){
            foreach ($vipfuwuData as $key => $value){
                $vipfuwuList[$key] = $value;
                $ufuwuInfo = C::t('#tom_tclove#tom_tclove_ufuwu')->fetch_all_list("AND tclove_id = {$tcloveInfo['id']} AND fuwu_id = {$value['fuwu_id']}"," ORDER BY id DESC ",0,1);
                if(is_array($ufuwuInfo) && !empty($ufuwuInfo)){
                    $updateData = array();
                    $updateData['fuwu_times']       = $ufuwuInfo[0]['fuwu_times'] + $value['fuwu_times'];
                    C::t('#tom_tclove#tom_tclove_ufuwu')->update($ufuwuInfo[0]['id'],$updateData);
                }else{
                    $insertData = array();
                    $insertData['tclove_id']        = $tcloveInfo['id'];
                    $insertData['fuwu_id']          = $value['fuwu_id'];
                    $insertData['fuwu_name']        = $value['fuwu_name'];
                    $insertData['fuwu_times']       = $value['fuwu_times'];
                    C::t('#tom_tclove#tom_tclove_ufuwu')->insert($insertData);
                }
                $insertData = array();
                $insertData['tclove_id']        = $tcloveInfo['id'];
                $insertData['fuwu_id']          = $value['fuwu_id'];
                $insertData['change_times']     = $value['fuwu_times'];
                if(is_array($ufuwuInfo) && !empty($ufuwuInfo)){
                    $insertData['old_times']    = $ufuwuInfo[0]['fuwu_times'];
                }else{
                    $insertData['old_times']    = 0;
                }
                $insertData['op_type']          = 4;
                $insertData['op_user_id']       = $orderInfo['user_id'];
                $insertData['op_time']          = TIMESTAMP;
                C::t('#tom_tclove#tom_tclove_ufuwu_log')->insert($insertData);
            }
        }
    }else if($orderInfo['order_type'] == 3){
        
        $ufuwuInfo  = C::t('#tom_tclove#tom_tclove_ufuwu')->fetch_all_list("AND fuwu_id ={$orderInfo['fuwu_id']} AND tclove_id = {$orderInfo['tclove_id']}","ORDER BY id DESC",0,1);
        if(is_array($ufuwuInfo) && !empty($ufuwuInfo[0])){
            DB::query("UPDATE ".DB::table('tom_tclove_ufuwu')." SET fuwu_times=fuwu_times+{$orderInfo['fuwu_times']} WHERE id='{$ufuwuInfo[0]['id']}'", 'UNBUFFERED');
        }else{
            $insertData = array();
            $insertData['tclove_id']        = $orderInfo['tclove_id'];
            $insertData['fuwu_id']          = $orderInfo['fuwu_id'];
            $insertData['fuwu_name']        = $orderInfo['fuwu_name'];
            $insertData['fuwu_times']       = $orderInfo['fuwu_times'];
            C::t('#tom_tclove#tom_tclove_ufuwu')->insert($insertData);
        }
        
        $insertData = array();
        $insertData['tclove_id']        = $orderInfo['tclove_id'];
        $insertData['fuwu_id']          = $orderInfo['fuwu_id'];
        $insertData['change_times']     = $orderInfo['fuwu_times'];
        if(is_array($ufuwuInfo) && !empty($ufuwuInfo[0])){
            $insertData['old_times']    = $ufuwuInfo[0]['fuwu_times'];
        }else{
            $insertData['old_times']    = 0;
        }
        $insertData['op_type']          = 3;
        $insertData['op_user_id']       = $orderInfo['user_id'];
        $insertData['op_time']          = TIMESTAMP;
        C::t('#tom_tclove#tom_tclove_ufuwu_log')->insert($insertData);
    }else if($orderInfo['order_type'] == 4){
       
        DB::query("UPDATE ".DB::table('tom_tclove_hongniang_shenqing')." SET pay_status=1 WHERE id='{$orderInfo['hongniang_sq_id']}'", 'UNBUFFERED');
        
    }else if($orderInfo['order_type'] == 5){
       
        DB::query("UPDATE ".DB::table('tom_tclove')." SET sms_times=sms_times + {$orderInfo['sms_times']} WHERE id='{$orderInfo['tclove_id']}'", 'UNBUFFERED');
        $insertData = array();
        $insertData['user_id']         = $tcloveInfo['user_id'];
        $insertData['change_times']    = $orderInfo['sms_times'];
        $insertData['old_times']       = $tcloveInfo['sms_times'];
        $insertData['op_type']         = 3;
        $insertData['op_user_id']      = $orderInfo['user_id'];
        $insertData['op_time']         = TIMESTAMP;
        C::t('#tom_tclove#tom_tclove_pm_log')->insert($insertData);
        
    }
    
    if($tcloveConfig['open_back_score'] == 1){
        if(!empty($tcloveConfig['score_yuan'])){
            $score_yuan = $tcloveConfig['score_yuan'];
        }else{
            $score_yuan = $tongchengConfig['score_yuan'];
        }
        
        $score = ceil($orderInfo['pay_price']*$score_yuan);
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] + $score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $orderInfo['user_id'];
        $insertData['score_value']      = $score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 38;        
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);

    }
    
    $type = '';
    if($orderInfo['order_type'] == 1){
        $type = lang('plugin/tom_tclove', 'paynotify_type_1');
    }else if($orderInfo['order_type'] == 2){
        $type = lang('plugin/tom_tclove', 'paynotify_type_2');
    }else if($orderInfo['order_type'] == 3){
        $type = lang('plugin/tom_tclove', 'paynotify_type_3');
    }else if($orderInfo['order_type'] == 5){
        $type = lang('plugin/tom_tclove', 'paynotify_type_5');
    }

    $adminFc = false; 
    
    $child_site_fc_money = $tuifc_money = $hongniangfc_money = 0;
    
    if($tcloveConfig['zizhandi_fc'] == 1 && $orderInfo['site_id'] > 1){
        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
        if($__ShowTcadmin == 1){
            $fc_scale = $tcadminConfig['fc_scale'];
            if($sitesInfo['love_fc_scale'] > 0){
                $fc_scale = $sitesInfo['love_fc_scale'];
            }
            $child_site_fc_money = $orderInfo['pay_price'] * ($fc_scale/100);
            $child_site_fc_money = number_format($child_site_fc_money,2);
        }
    }
    
    if($tcloveInfo['tui_id'] > 0 && $tcloveConfig['open_tuiguang'] == 1){
        $tuifc_money = $orderInfo['pay_price'] * ($tcloveConfig['tuiguang_scale']/100);
        $tuifc_money = number_format($tuifc_money,2);
    }
    
    if($tcloveInfo['hongniang_id'] > 0){
        $hongniangInfo      = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_id($tcloveInfo['hongniang_id']);
        $hongnianguserInfo  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($hongniangInfo['user_id']);

        if((is_array($hongniangInfo) && !empty($hongniangInfo)) && $tcloveConfig['open_hongniang_fc'] == 1){

            $hongniangfc_money = $orderInfo['pay_price'] * ($tcloveConfig['hongniang_fc_scale']/100);
            $hongniangfc_money = number_format($hongniangfc_money,2);
        }
    }
    
    if($orderInfo['pay_price'] >= ($child_site_fc_money + $tuifc_money + $hongniangfc_money)){
        $sendTemplateTuiuser = false;
        if($tuifc_money > 0 && $orderInfo['order_type'] != 4 ){
            
            $tuiInfo  = C::t('#tom_tclove#tom_tclove_tui')->fetch_by_id($tcloveInfo['tui_id']);
            $tuiuserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tuiInfo['user_id']);
            
            if(is_array($tuiInfo) && !empty($tuiInfo)){
                
                $sendTemplateTuiuser = true;
                
                DB::query("UPDATE ".DB::table('tom_tclove_tui')." SET total_shouyi = total_shouyi + {$tuifc_money} WHERE id='{$tuiInfo['id']}'", 'UNBUFFERED');
                
                update_tui_phb($tuiuserInfo['id'],$tuifc_money);

                $insertData = array();
                $insertData['tui_id']         = $tcloveInfo['tui_id'];
                $insertData['tclove_id']      = $tcloveInfo['id'];
                if($orderInfo['order_type'] == 1){
                    $insertData['type']           = 3;
                }elseif($orderInfo['order_type'] == 2){
                    $insertData['type']           = 2;
                }elseif($orderInfo['order_type'] == 3){
                    $insertData['type']           = 4;
                }
                $insertData['change_shouyi']  = $tuifc_money;
                $insertData['old_shouyi']     = $tuiInfo['total_shouyi'];
                $insertData['log_time']       = TIMESTAMP;
                C::t('#tom_tclove#tom_tclove_tui_shouyi_log')->insert($insertData);

                DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$tuifc_money} WHERE id='{$tuiuserInfo['id']}'", 'UNBUFFERED');
                
                $insertData = array();
                $insertData['user_id']          = $tuiuserInfo['id'];
                $insertData['type_id']          = 2;
                $insertData['change_money']     = $tuifc_money;
                $insertData['old_money']        = $tuiuserInfo['money'];
                $insertData['tag']              = lang('plugin/tom_tclove', 'love_money_log_tag');
                $insertData['beizu']            = lang('plugin/tom_tclove', 'love_money_log_tui_title');
                $insertData['log_time']         = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
            
            }
        }
        $sendTemplatehongnianguser = false;
        if( $hongniangfc_money > 0 && $orderInfo['order_type'] != 4 ){
                
            $sendTemplatehongnianguser = true;

            DB::query("UPDATE ".DB::table('tom_tclove_hongniang')." SET total_shouyi=total_shouyi+{$hongniangfc_money} WHERE id='{$hongniangInfo['id']}'", 'UNBUFFERED');

            $insertData = array();
            $insertData['tclove_id']      = $tcloveInfo['id'];
            $insertData['hongniang_id']   = $hongniangInfo['id'];
            if($orderInfo['order_type'] == 1){
                $insertData['type']           = 1;
            }elseif($orderInfo['order_type'] == 2){
                $insertData['type']           = 2;
            }elseif($orderInfo['order_type'] == 3){
                $insertData['type']           = 3;
            }
            $insertData['change_shouyi']  = $hongniangfc_money;
            $insertData['old_shouyi']     = $hongniangInfo['total_shouyi'];
            $insertData['log_time']       = TIMESTAMP;
            C::t('#tom_tclove#tom_tclove_hongniang_shouyi_log')->insert($insertData);

            DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$hongniangfc_money} WHERE id='{$hongnianguserInfo['id']}'", 'UNBUFFERED');
            
            $insertData = array();
            $insertData['user_id']          = $hongnianguserInfo['id'];
            $insertData['type_id']          = 2;
            $insertData['change_money']     = $hongniangfc_money;
            $insertData['old_money']        = $hongnianguserInfo['money'];
            $insertData['tag']              = lang('plugin/tom_tclove', 'love_money_log_tag');
            $insertData['beizu']            = lang('plugin/tom_tclove', 'love_money_log_hongniang_title');
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);

        }
        if($child_site_fc_money > 0 ){
           
            $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);

            $old_money = 0;
            if($walletInfo){
                $old_money = $walletInfo['account_balance'];

                $updateData = array();
                $updateData['account_balance']   = $walletInfo['account_balance'] + $child_site_fc_money;
                $updateData['total_income']      = $walletInfo['total_income'] + $child_site_fc_money;
                C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
            }else{
                $insertData = array();
                $insertData['site_id']              = $orderInfo['site_id'];
                $insertData['account_balance']      = $child_site_fc_money;
                $insertData['total_income']         = $child_site_fc_money;
                $insertData['add_time']             = TIMESTAMP;
                C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
            }

            $insertData = array();
            $insertData['site_id']      = $orderInfo['site_id'];
            $insertData['log_type']     = 1;
            $insertData['change_money'] = $child_site_fc_money;
            $insertData['old_money']    = $old_money;
            $insertData['beizu']        = $type;
            $insertData['order_no']     = $orderInfo['order_no'];
            $insertData['order_type']   = $orderInfo['order_type'];
            $insertData['log_ip']       = $_G['clientip'];
            $insertData['log_time']     = TIMESTAMP;
            C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData); 
        }
    }

    # fc end
    
    if($sendTemplateTuiuser == true){
            
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tuiuserInfo['openid'])){

            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$orderInfo['site_id']}&mod=tui");
            $shouyiText = str_replace("{NICKNAME}",$tcloveInfo['xm'], lang('plugin/tom_tclove', 'paynotify_tui_template'));
            $shouyiText = str_replace("{TYPE}",$type,$shouyiText);
            $shouyiText = str_replace("{MONEY}",$tuifc_money, $shouyiText);
            $smsData = array(
                'first'         => $shouyiText,
                'keyword1'      => $tcloveConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($tuiuserInfo['openid'],$tongchengConfig['template_id'],$smsData);
        }
    }
    if($sendTemplatehongnianguser == true){
            
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($hongnianguserInfo['openid'])){

            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$orderInfo['site_id']}&mod=managerHongniang");
            $shouyiText = str_replace("{NICKNAME}",$tcloveInfo['xm'], lang('plugin/tom_tclove', 'paynotify_hongniang_template'));
            $shouyiText = str_replace("{TYPE}",$type,$shouyiText);
            $shouyiText = str_replace("{MONEY}",$hongniangfc_money, $shouyiText);
            $smsData = array(
                'first'         => $shouyiText,
                'keyword1'      => $tcloveConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($hongnianguserInfo['openid'],$tongchengConfig['template_id'],$smsData);
        }
    }
    if($orderInfo['order_type'] == 1 || $orderInfo['order_type'] == 2 || $orderInfo['order_type'] == 3 || $orderInfo['order_type'] == 5 ){

        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);

        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($toUser['openid'])){

            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$orderInfo['site_id']}&mod=index");

            $template_first = str_replace("{NAME}",$userInfo['nickname'], lang('plugin/tom_tclove','pay_template_first'));
            $template_first = str_replace("{MONEY}",$orderInfo['pay_price'],$template_first);
            $template_first = str_replace("{TYPENAME}",$type,$template_first);

            $smsData = array(
                'first'         => $template_first,
                'keyword1'      => $tcloveConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);

        }

        $tclovemanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcloveConfig['tclovemanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tclovemanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$orderInfo['site_id']}&mod=index");

            $template_first = str_replace("{NAME}",$userInfo['nickname'], lang('plugin/tom_tclove','pay_template_first'));
            $template_first = str_replace("{MONEY}",$orderInfo['pay_price'],$template_first);
            $template_first = str_replace("{TYPENAME}",$type,$template_first);

            $smsData = array(
                'first'         => $template_first,
                'keyword1'      => $tcloveConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($tclovemanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
    if($orderInfo['order_type'] == 4){
            
        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($toUser['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");
            $smsData = array(
                'first'         => lang('plugin/tom_tclove', 'template_shenqing_hongniang_shenhe_msg'),
                'keyword1'      => $tcloveConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        }

        $tclovemanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcloveConfig['tclovemanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tclovemanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");
            $smsData = array(
                'first'         => lang('plugin/tom_tclove', 'template_shenqing_hongniang_shenhe_msg'),
                'keyword1'      => $tcloveConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($tclovemanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
}