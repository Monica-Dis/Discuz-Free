<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=diynav";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'import' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'code'=> 1,
    );
    
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/config/import.data.php';
    
    foreach ($divnavArr as $key => $value){
        $insertData = array();
        $insertData['site_id']      = 1;
        $insertData['title']        = $value['title'];
        $insertData['picurl']       = $value['picurl'];
        $insertData['link']         = $value['link'];
        $insertData['dsort']        = $key;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tclove#tom_tclove_diynav')->insert($insertData);
    }
    
    $outArr = array(
        'code'  => 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'add' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $link           = isset($_GET['link'])? addslashes($_GET['link']):'';
    $dsort          = isset($_GET['dsort'])? intval($_GET['dsort']):10;
    
    $insertData = array();
    $insertData['site_id']      = $site_id;
    $insertData['title']        = $title;
    $insertData['picurl']       = $picurl;
    $insertData['link']         = $link;
    $insertData['dsort']        = $dsort;
    $insertData['add_time']     = TIMESTAMP;
    C::t('#tom_tclove#tom_tclove_diynav')->insert($insertData);
        
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $diynav_id      = isset($_GET['diynav_id'])? intval($_GET['diynav_id']):0;
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $link           = isset($_GET['link'])? addslashes($_GET['link']):'';
    $dsort          = isset($_GET['dsort'])? intval($_GET['dsort']):10;
    
    $updateData = array();
    $updateData['site_id']      = $site_id;
    $updateData['title']        = $title;
    $updateData['picurl']       = $picurl;
    $updateData['link']         = $link;
    $updateData['dsort']        = $dsort;
    C::t('#tom_tclove#tom_tclove_diynav')->update($diynav_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('diynav_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $diynav_id = intval($_GET['diynav_id'])>0 ? intval($_GET['diynav_id']):0;
    
    C::t('#tom_tclove#tom_tclove_diynav')->delete_by_id($diynav_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('diynav_id')){
    $outArr = array(
        'code'=> 1,
    );

    $diynav_id = intval($_GET['diynav_id'])>0 ? intval($_GET['diynav_id']):0;
    
    $diynavInfo = C::t('#tom_tclove#tom_tclove_diynav')->fetch_by_id($diynav_id);
    $diynavInfo['picurlTmp'] = get_file_url($diynavInfo['picurl']);
    
    $list = iconv_to_utf8($diynavInfo);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}

$site_id    = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$whereStr = '';
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}

$order = "ORDER BY site_id ASC,dsort ASC,id DESC";
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tclove#tom_tclove_diynav')->fetch_all_count($whereStr);
$diynavListTmp = C::t('#tom_tclove#tom_tclove_diynav')->fetch_all_list($whereStr,$order,$start,$pagesize);
$diynavList = array();
if(is_array($diynavListTmp) && !empty($diynavListTmp)){
    foreach ($diynavListTmp as $key => $value) {
        $diynavList[$key] = $value;
        
        $diynavList[$key]['siteInfo']   = $sitesList[$value['site_id']];
        $diynavList[$key]['picurl']     = get_file_url($value['picurl']);
        $diynavList[$key]['add_time']   = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/diynav");