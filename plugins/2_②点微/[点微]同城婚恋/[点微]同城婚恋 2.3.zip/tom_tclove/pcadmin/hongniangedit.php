<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$hongniang_id  = intval($_GET['hongniang_id'])>0? intval($_GET['hongniang_id']):0;

$hongniangInfo = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_id($hongniang_id);

if(empty($hongniangInfo)){
    tomheader('location:'.$_G['siteurl']."{$pcadminUrl}&tmod=hongniang");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=hongniangedit&hongniang_id={$hongniang_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
        
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $wx                 = isset($_GET['wx'])? addslashes($_GET['wx']):0;
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):0;
    $desc               = isset($_GET['desc'])? addslashes($_GET['desc']):'';
    $paixu              = isset($_GET['paixu'])? intval($_GET['paixu']):0;
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $qrcode             = isset($_GET['qrcode'])? addslashes($_GET['qrcode']):'';
    
    $updateData = array();
    $updateData['user_id']          = $user_id;
    $updateData['name']             = $name;
    $updateData['wx']               = $wx;
    $updateData['tel']              = $tel;
    $updateData['desc']             = $desc;
    $updateData['paixu']            = $paixu;
    $updateData['picurl']           = $picurl;
    $updateData['qrcode']           = $qrcode;
    
    C::t('#tom_tclove#tom_tclove_hongniang')->update($hongniang_id,$updateData);
        
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}

$picurl    = get_file_url($hongniangInfo['picurl']);
$qrcode    = get_file_url($hongniangInfo['qrcode']);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/hongniangedit");