<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$talk_id  = intval($_GET['talk_id'])>0? intval($_GET['talk_id']):0;

$talkInfo = C::t('#tom_tclove#tom_tclove_talk')->fetch_by_id($talk_id);

$tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($talkInfo['tclove_id']);

$modPcadminUrl = $pcadminUrl."&tmod=talkPinglun";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'delpinglun' && submitcheck('pinglun_id')){
    $outArr = array(
        'code'=> 1,
    );

    $pinglun_id  = intval($_GET['pinglun_id'])>0 ? intval($_GET['pinglun_id']):0;
    
    $pinglunInfo = C::t('#tom_tclove#tom_tclove_talk_pinglun')->fetch_by_id($pinglun_id);
    
    C::t('#tom_tclove#tom_tclove_talk_pinglun')->delete_by_id($pinglun_id);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_pinglun_id($pinglun_id);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_zan')->delete_by_pinglun_id($pinglun_id);

    $pinglunCount = C::t('#tom_tclove#tom_tclove_talk_pinglun')->fetch_all_count(" AND talk_id={$pinglunInfo['talk_id']}");
    
    DB::query("UPDATE ".DB::table('tom_tclove_talk')." SET pinglun_count={$pinglunCount} WHERE id='{$pinglunInfo['talk_id']}' ", 'UNBUFFERED');
   
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'delreply' && submitcheck('reply_id')){
    $outArr = array(
        'code'=> 1,
    );

    $reply_id  = intval($_GET['reply_id'])>0 ? intval($_GET['reply_id']):0;
    
    C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_id($reply_id);
   
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$page              = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize          = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tclove#tom_tclove_talk_pinglun')->fetch_all_count("AND talk_id = {$talk_id}");
$talkPinglunListTmp   = C::t('#tom_tclove#tom_tclove_talk_pinglun')->fetch_all_list("AND talk_id = {$talk_id}", "ORDER BY pinglun_time DESC",$start,$pagesize);
$talkPinglunList = array();
if(is_array($talkPinglunListTmp) && !empty($talkPinglunListTmp)){
    foreach ($talkPinglunListTmp as $key => $value){
        $talkPinglunList[$key] = $value;
        $tcloveInfoTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcloveInfoTmp['user_id']);
        
        $avatar = tom_tclove_avatar($value['tclove_id']);

        $talkReplyListTmp   = C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->fetch_all_list("AND pinglun_id = {$value['id']}", "ORDER BY reply_time DESC",0,100);
        
        $talkReplyList = array();
        
        if(is_array($talkReplyListTmp) && !empty($talkReplyListTmp)){
            foreach ($talkReplyListTmp as $k => $v){
                $talkReplyList[$k] = $v;
                
                $tcloveInfoReplyTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_id($v['tclove_id']);
                $userInfoReplyTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcloveInfoReplyTmp['user_id']);
                
                $talkReplyList[$k]['userInfoReply']                = $userInfoReplyTmp;
            }
        }
        
        $talkPinglunList[$key]['avatar']                = $avatar;
        $talkPinglunList[$key]['tcloveInfo']            = $tcloveInfoTmp;
        $talkPinglunList[$key]['userInfo']              = $userInfoTmp;
        $talkPinglunList[$key]['talkReplyList']         = $talkReplyList;
    }
}

$pageUrl = $modPcadminUrl."&talk_id={$talk_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/talkPinglun");