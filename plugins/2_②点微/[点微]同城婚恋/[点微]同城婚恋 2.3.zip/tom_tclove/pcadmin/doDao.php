<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=doDao";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'dodao_url' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $vip_id         = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $top_status     = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $sex            = isset($_GET['sex'])? intval($_GET['sex']):0;
    $height         = isset($_GET['height_id'])? intval($_GET['height_id']):0;
    $age            = isset($_GET['age'])? intval($_GET['age']):0;
    $shouru         = isset($_GET['shouru'])? intval($_GET['shouru']):0;
    $edu            = isset($_GET['edu_id'])? intval($_GET['edu_id']):0;
    $is_ok          = isset($_GET['is_ok'])? intval($_GET['is_ok']):0;
    $shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    
    $doDaoUrl = $_G['siteurl']."plugin.php?id=tom_tclove:doDao&vip_id={$vip_id}&top_status={$top_status}&is_ok={$is_ok}&shenhe_status={$shenhe_status}&sex={$sex}&height={$height}&age={$age}&shouru={$shouru}&edu={$edu}&from=tom_admin";
    
    $outArr = array(
        'code'=> 200,
        'url'=> $doDaoUrl,
    );
    echo json_encode($outArr); exit;
}

$vipListTmp = C::t('#tom_tclove#tom_tclove_vip')->fetch_all_list(""," ORDER BY id DESC ",0,20);
$vipList = array();
if(is_array($vipListTmp) && !empty($vipListTmp)){
    foreach ($vipListTmp as $key => $value){
        $vipList[$key] = $value;
    }
}

$dodaoUrl = $modPcadminUrl."&act=dodao_url&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/doDao");