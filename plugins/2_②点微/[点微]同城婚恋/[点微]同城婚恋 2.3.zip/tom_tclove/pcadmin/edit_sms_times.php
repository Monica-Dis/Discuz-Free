<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tclove_id  = intval($_GET['tclove_id'])>0? intval($_GET['tclove_id']):0;

$tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);

$modPcadminUrl  = $pcadminUrl."&tmod=edit_sms_times&tclove_id={$tclove_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('sms_times')){
    $outArr = array(
        'code'=> 1,
    );
    
    $sms_times     = isset($_GET['sms_times'])? intval($_GET['sms_times']):0;
    
    $updateData = array();
    $updateData['sms_times'] = $sms_times;
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
    
    $insertData = array();
    $insertData['user_id']        = $tcloveInfo['user_id'];
    $insertData['old_times']      = $tcloveInfo['sms_times'];
    $insertData['change_times']   = $sms_times;
    $insertData['op_user_id']     = $tcloveInfo['user_id'];
    $insertData['op_type']        = 1;
    $insertData['op_time']        = TIMESTAMP;
    C::t('#tom_tclove#tom_tclove_pm_log')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'list' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $page       = intval($_GET['page'])>0 ? intval($_GET['page']) :1;
    $pagesize   = intval($_GET['pagesize'])>0 ? intval($_GET['pagesize']) :10;
    
    $where = " AND user_id={$tcloveInfo['user_id']} ";
    
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tclove#tom_tclove_pm_log')->fetch_all_count($where);
    $smsLogListTmp = C::t('#tom_tclove#tom_tclove_pm_log')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    $smsLogList = array();
    if(!empty($smsLogListTmp)){
        foreach($smsLogListTmp as $key => $value){
            $smsLogList[$key] = $value;
            
            $tcloveInfoTmp    = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($value['user_id']);
            $tongchengInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['op_user_id']);
            
            $smsLogList[$key]['tcloveInfo'] = $tcloveInfoTmp;
            $smsLogList[$key]['tongchengInfo'] = $tongchengInfoTmp;
            $smsLogList[$key]['op_time'] = dgmdate($value['op_time'],"Y-m-d H:i",$tomSysOffset);
        }
    }
    
    $list = iconv_to_utf8($smsLogList);
    
    $outArr = array(
        'code'  => 0,
        'msg'   => '',
        'count' => $count,
        'data'  => $list,
    );
    echo json_encode($outArr); exit;
}

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/edit_sms_times");