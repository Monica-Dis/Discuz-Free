<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=tuilist";

//$act = isset($_GET['act'])? addslashes($_GET['act']):'';
//
//if($act == 'del' && submitcheck('tui_id')){
//    $outArr = array(
//        'code'=> 1,
//    );
//
//    $tui_id  = intval($_GET['tui_id'])>0 ? intval($_GET['tui_id']):0;
//    
//    C::t('#tom_tclove#tom_tclove_tui')->delete_by_id($tui_id);
//    
//    $outArr = array(
//        'code'=> 200,
//    );    
//    echo json_encode($outArr); exit;
//}else if($act == 'batch_del' && submitcheck('tui_ids')){
//    $outArr = array(
//        'code'=> 1,
//    );
//    
//    $tuiIdsArr = array();
//    if(is_array($_GET['tui_ids'])){
//        foreach($_GET['tui_ids'] as $key => $value){
//            $idTmp = intval($value);
//            if($idTmp > 0){
//                $tuiIdsArr[] = $idTmp;
//            }
//        }
//    }
//    
//    if(!empty($tuiIdsArr)){
//        foreach($tuiIdsArr as $key => $value){
//            
//           C::t('#tom_tclove#tom_tclove_tui')->delete_by_id($value);
//        }
//    }
//    $outArr = array(
//        'code'=> 200,
//    );    
//    echo json_encode($outArr); exit;
//}

$tui_id            = isset($_GET['tui_id'])? intval($_GET['tui_id']):0;
$user_id           = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$page              = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize          = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = " AND num > 0";
if($tui_id > 0){
    $whereStr.= " AND id= {$tui_id}";
}
if($user_id > 0){
    $whereStr.= " AND user_id= {$user_id}";
}

$order  = "ORDER BY total_shouyi DESC,id DESC";

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tclove#tom_tclove_tui')->fetch_all_count($whereStr);
$tuiListTmp = C::t('#tom_tclove#tom_tclove_tui')->fetch_all_list($whereStr,$order,$start,$pagesize);
$tuiList = array();
if(!empty($tuiListTmp)){
    foreach ($tuiListTmp as $key => $value) {
        $tuiList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $tuiList[$key]['userInfo'] = $userInfoTmp;
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/tuilist");