<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=order";

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$tclove_id      = intval($_GET['tclove_id'])>0? intval($_GET['tclove_id']):0;
$order_no       = isset($_GET['order_no'])? addslashes($_GET['order_no']):'';
$order_type     = intval($_GET['order_type'])>0? intval($_GET['order_type']):0;
$order_status   = intval($_GET['order_status'])>0? intval($_GET['order_status']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = "";
if($site_id > 0){
    $whereStr .= " AND site_id={$site_id} ";
}
if($user_id > 0){
    $whereStr.= " AND user_id={$user_id} ";
}
if($tclove_id > 0){
    $whereStr.= " AND tclove_id={$tclove_id} ";
}
if(!empty($order_no)){
    $whereStr .= " AND order_no='{$order_no}' ";
}
if($order_type > 0){
    $whereStr.= " AND order_type={$order_type} ";
}
if($order_status > 0){
    $whereStr .= " AND order_status={$order_status} ";
}
$start         = ($page - 1)*$pagesize;
$count         = C::t('#tom_tclove#tom_tclove_order')->fetch_all_count($whereStr);
$orderListTmp  = C::t('#tom_tclove#tom_tclove_order')->fetch_all_list($whereStr," ORDER BY id DESC ",$start,$pagesize);
$orderList = array();
if(!empty($orderListTmp)){
    foreach ($orderListTmp as $key => $value) {
        $orderList[$key] = $value;

        $tcloveInfoTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
        $vipInfoTmp    = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($value['vip_id']);
        $fuwuInfoTmp   = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_by_id($value['fuwu_id']);
        
        $orderList[$key]['tcloveInfo']           = $tcloveInfoTmp;
        $orderList[$key]['vipInfo']              = $vipInfoTmp;
        $orderList[$key]['fuwuInfo']             = $fuwuInfoTmp;
        $orderList[$key]['order_time']           = dgmdate($value['order_time'],"Y-m-d H:i:s",$tomSysOffset) ;
        $orderList[$key]['pay_time']             = dgmdate($value['pay_time'],"Y-m-d H:i:s",$tomSysOffset) ;

    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&user_id={$user_id}&tclove_id={$tclove_id}&order_type={$order_type}&order_status={$order_status}";

$todayPayPrice = C::t('#tom_tclove#tom_tclove_order')->fetch_all_sun_pay_price(" AND pay_time > $nowDayTime AND order_status=2 ");
$monthPayPrice = C::t('#tom_tclove#tom_tclove_order')->fetch_all_sun_pay_price(" AND pay_time > $nowMonthTime AND order_status=2 ");
$allPayPrice = C::t('#tom_tclove#tom_tclove_order')->fetch_all_sun_pay_price(" AND order_status=2 ");

if(!empty($whereStr)){
    $searchAllPayPrice = C::t('#tom_tclove#tom_tclove_order')->fetch_all_sun_pay_price($whereStr);
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/order");