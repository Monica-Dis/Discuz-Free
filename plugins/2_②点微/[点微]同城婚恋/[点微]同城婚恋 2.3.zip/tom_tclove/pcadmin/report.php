<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=report";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('report_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $report_id      = intval($_GET['report_id'])>0 ? intval($_GET['report_id']):0;
    
    C::t('#tom_tclove#tom_tclove_report')->delete($report_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'fenghao' && submitcheck('report_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $report_id      = intval($_GET['report_id'])>0 ? intval($_GET['report_id']):0;
    $report_user_id = intval($_GET['report_user_id'])>0 ? intval($_GET['report_user_id']):0;
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tclove#tom_tclove_report')->update($report_id,$updateData);
    
    $updateData = array();
    $updateData['status'] = 2;
    $userInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($report_user_id);
    C::t('#tom_tclove#tom_tclove')->update($userInfo['id'],$updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$page              = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize          = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tclove#tom_tclove_report')->fetch_all_count("");
$reportListTmp = C::t('#tom_tclove#tom_tclove_report')->fetch_all_list("","ORDER BY report_time DESC,id DESC",$start,$pagesize);
$reportList = array();
if(!empty($reportListTmp)){
    foreach ($reportListTmp as $key => $value) {
        $reportList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($value['user_id']);
        $reportUserInfoTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($value['report_user_id']);
        
        $reportList[$key]['userInfo']          = $userInfoTmp;
        $reportList[$key]['reportUserInfo']    = $reportUserInfoTmp;
        $reportList[$key]['report_pic_1']      = get_file_url($value['report_pic_1']);
        $reportList[$key]['report_pic_2']      = get_file_url($value['report_pic_2']);
        $reportList[$key]['report_time']       = dgmdate($value['report_time'],"Y-m-d H:i:s",$tomSysOffset) ;
      
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/report");