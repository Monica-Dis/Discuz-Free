<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=hongniang_shenqing";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('shenqing_id')){
    $outArr = array(
        'code'=> 1,
    );

    $shenqing_id  = intval($_GET['shenqing_id'])>0 ? intval($_GET['shenqing_id']):0;
    
    C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->delete_by_id($shenqing_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'shenhe' && submitcheck('shenqing_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $shenqing_id    = intval($_GET['shenqing_id'])>0 ? intval($_GET['shenqing_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $hongniang_sqInfo = C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->fetch_by_id($shenqing_id);
    $hongniangInfo = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_user_id($hongniang_sqInfo['user_id']);
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($hongniang_sqInfo['user_id']);
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status']     = 1;
        C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->update($shenqing_id,$updateData);
        
        if(is_array($hongniangInfo) && !empty($hongniangInfo)){}else{
            $insertData = array();
            $insertData['user_id']      = $hongniang_sqInfo['user_id'];
            $insertData['name']         = $hongniang_sqInfo['name'];
            $insertData['tel']          = $hongniang_sqInfo['tel'];
            $insertData['wx']           = $hongniang_sqInfo['wx'];
            $insertData['desc']         = $hongniang_sqInfo['desc'];
            $insertData['picurl']       = $hongniang_sqInfo['picurl'];
            $insertData['qrcode']       = $hongniang_sqInfo['qrcode'];
            C::t('#tom_tclove#tom_tclove_hongniang')->insert($insertData);
        }
        
        $shenhe   = $Lang['template_hongniang_shenhe_ok'];
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tclove&site='.$hongniang_sqInfo['site_id'].'&mod=managerHongniang">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$hongniang_sqInfo['site_id']}&mod=managerHongniang");
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcloveConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }

        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->update($shenqing_id,$updateData);
        
        $shenhe   = $Lang['template_hongniang_shenhe_no'];
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tclove&site='.$hongniang_sqInfo['site_id'].'&mod=managerHongniang_edit">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$hongniang_sqInfo['site_id']}&mod=managerHongniang_edit");
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcloveConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}

$shenhe_status     = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$page              = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize          = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = '';

if(!empty($shenhe_status)){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}

$order = "ORDER BY add_time DESC,id DESC";

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->fetch_all_count($whereStr);
$shenqingListTmp = C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->fetch_all_list($whereStr,$order,$start,$pagesize);

$shenqingList = array();
if(!empty($shenqingListTmp)){
    foreach ($shenqingListTmp as $key => $value) {
        $shenqingList[$key] = $value;
        
        $shenqingList[$key]['picurl']      = get_file_url($value['picurl']);
        $shenqingList[$key]['qrcode']      = get_file_url($value['qrcode']);
      
    }
}

$pageUrl = $modPcadminUrl."&shenhe_status={$shenhe_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/hongniang_shenqing");