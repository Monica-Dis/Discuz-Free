<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=tui_phb";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('phb_id')){
    $outArr = array(
        'code'=> 1,
    );

    $phb_id  = intval($_GET['phb_id'])>0 ? intval($_GET['phb_id']):0;
    
    C::t('#tom_tclove#tom_tclove_tui_phb')->delete_by_id($phb_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('phb_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $phbIdsArr = array();
    if(is_array($_GET['phb_ids'])){
        foreach($_GET['phb_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $phbIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($phbIdsArr)){
        foreach($phbIdsArr as $key => $value){
            
           C::t('#tom_tclove#tom_tclove_tui_phb')->delete_by_id($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'addphb' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $phb_type     = isset($_GET['phb_type'])? intval($_GET['phb_type']):0;
    $user_id      = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $shouyi       = isset($_GET['shouyi'])? floatval($_GET['shouyi']):0.00;
    
    $phbListTmp = C::t('#tom_tclove#tom_tclove_tui_phb')->fetch_all_list("AND phb_type={$phb_type} AND user_id = {$user_id}","",0,1);
    if(is_array($phbListTmp) && !empty($phbListTmp)){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['tui_phb_add_error'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }else{
        if($phb_type==2){
            $month_id = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
        }else if($phb_type==3){
            $week_id = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);
        }

        $insertData = array();
        $insertData['user_id']    = $user_id;
        $insertData['phb_type']   = $phb_type;
        $insertData['month_id']   = $month_id;
        $insertData['week_id']    = $week_id;
        $insertData['shouyi']     = $shouyi;
        C::t('#tom_tclove#tom_tclove_tui_phb')->insert($insertData);

        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
}else if($act == 'edit_shouyi' && submitcheck('shouyi')){
    $outArr = array(
        'code'=> 1,
    );
    
    $phb_id       = isset($_GET['phb_id'])? intval($_GET['phb_id']):0;
    $shouyi       = isset($_GET['shouyi'])? floatval($_GET['shouyi']):0.00;
    
    $updateData = array();
    
    $updateData['shouyi']   = $shouyi;
    
    C::t('#tom_tclove#tom_tclove_tui_phb')->update($phb_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$phb_id            = isset($_GET['phb_id'])? intval($_GET['phb_id']):0;
$user_id           = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$phb_type          = isset($_GET['phb_type'])? intval($_GET['phb_type']):0;
$page              = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize          = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = "";
if($phb_type == 2){
    $whereStr.= " AND phb_type= 2";
    $month_id = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
    $whereStr.= " AND month_id= {$month_id}";
}else if($phb_type == 3){
    $whereStr.= " AND phb_type= 3";
    $week_id = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);
    $whereStr.= " AND week_id= {$week_id}";
}else{
    $whereStr.= " AND phb_type= 1";
}
if(!empty($phb_id)){
    $whereStr.= " AND id= {$phb_id}";
}
if(!empty($user_id)){
    $whereStr.= " AND user_id= {$user_id}";
}
$order = "ORDER BY shouyi DESC,id DESC";

$start  = ($page - 1)*$pagesize;
$count = C::t('#tom_tclove#tom_tclove_tui_phb')->fetch_all_count($whereStr);
$phbListTmp = C::t('#tom_tclove#tom_tclove_tui_phb')->fetch_all_list($whereStr,$order,$start,$pagesize);
$phbList = array();
if(!empty($phbListTmp)){
    foreach ($phbListTmp as $key => $value) {
        $phbList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $phbList[$key]['userInfo']           = $userInfoTmp;
    }
}

$pageUrl = $modPcadminUrl;
$modPcadminUrl."&phb_type={$phb_type}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/tui_phb");