<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=list";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'award' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $tclove_id   = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    $user_id     = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    
    $tuiInfo = C::t('#tom_tclove#tom_tclove_tui')->fetch_by_user_id($user_id);
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
    
    if($tcloveInfo['sex'] == 2 && $tcloveConfig['tui_new_user_girl_award'] > 0){
        $tcloveConfig['tui_new_user_award'] = $tcloveConfig['tui_new_user_girl_award'];
    }
    
    if($tcloveConfig['tui_new_user_award'] > 0 && $tcloveInfo['tui_award_status'] == 0 && $tuiInfo['id'] > 0){
        
        DB::query("UPDATE ".DB::table('tom_tclove_tui')." SET total_shouyi= total_shouyi + {$tcloveConfig['tui_new_user_award']} WHERE id='{$tuiInfo['id']}' ", 'UNBUFFERED');   
        
        update_tui_phb($user_id,$tcloveConfig['tui_new_user_award']);
        
        $insertData = array();
        $insertData['tui_id']         = $tuiInfo['id'];
        $insertData['tclove_id']      = $tclove_id;
        $insertData['type']           = 1;
        $insertData['change_shouyi']  = $tcloveConfig['tui_new_user_award'];
        $insertData['old_shouyi']     = $tuiInfo['total_shouyi'];
        $insertData['log_time']       = TIMESTAMP;
        C::t('#tom_tclove#tom_tclove_tui_shouyi_log')->insert($insertData);

        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);

        DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$tcloveConfig['tui_new_user_award']} WHERE id='{$userInfo['id']}'", 'UNBUFFERED');
        
        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['type_id']          = 2;
        $insertData['change_money']     = $tcloveConfig['tui_new_user_award'];
        $insertData['old_money']        = $userInfo['money'];
        $insertData['tag']              = lang('plugin/tom_tclove', 'love_money_log_tag');
        $insertData['beizu']            = lang('plugin/tom_tclove', 'love_money_log_tui_title');
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
        
        DB::query("UPDATE ".DB::table('tom_tclove')." SET tui_award_status=1 WHERE id='{$tclove_id}' ", 'UNBUFFERED');
        
        if($tcloveInfo['site_id'] == 1){
            $sitename = $tcloveConfig['plugin_name'];
        }else{
            $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcloveInfo['site_id']);
            $sitename = $siteInfo['name'];
        }
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);

        $shouyiText = str_replace("{NICKNAME}",$tcloveInfo['xm'], lang('plugin/tom_tclove', 'template_tclove_tui'));
        $shouyiText = str_replace("{MONEY}",$tcloveConfig['tui_new_user_award'], $shouyiText); 
        
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        
        $cpmsg = $Lang['tclove_shenhe_tz_succ'];
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=tui");
            $smsData = array(
                'first'         => $shouyiText,
                'keyword1'      => $sitename,
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );
           
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
            }else{
                $outArr = array(
                    'code'=> 200,
                    'send_status'=> 301,
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
    
}else if($act == 'edittop' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tclove_id   = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    $top_time    = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
    $top_time    = strtotime($top_time);
    
    $updateData = array();
    
    if($top_time <= TIMESTAMP){
        $updateData['top_status']   = 0;
        $updateData['top_time']     = 0;
        $updateData['top_do_time']  = 0;
    }else{
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        $updateData['top_do_time']  = TIMESTAMP;
    }
    
    C::t('#tom_tclove#tom_tclove')->update($tclove_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'hongniang_list' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );

    $hongniangListTmp = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_all_list(""," ORDER BY paixu ASC ,id DESC ",0,100);
    $hongniangList = array();
    if(is_array($hongniangListTmp) && !empty($hongniangListTmp)){
        foreach ($hongniangListTmp as $key => $value){
            $hongniangList[$key] = $value;
        }
    }
    
    $hongniangList = iconv_to_utf8($hongniangList);
    
    $outArr = array(
        'code'  => 200,
        'list'  => $hongniangList,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'change_hongniang' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tclove_id        = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0; 
    $hongniang_id     = intval($_GET['hongniang_id'])>0? intval($_GET['hongniang_id']):0;
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
    
    $updateData = array();
    $updateData['hongniang_id']   = $hongniang_id;
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
    
    if($hongniang_id > 0){
        $insertData = array();
        $insertData['hongniang_id']      = $hongniang_id;
        $insertData['tclove_id']         = $tcloveInfo['id'];
        $insertData['renling_time_key']  = $nowDayTime;
        $insertData['renling_time']      = TIMESTAMP;
        C::t('#tom_tclove#tom_tclove_hongniang_renling_log')->insert($insertData);

        $hongninagInfo = C::t("#tom_tclove#tom_tclove_hongniang")->fetch_by_id($hongniang_id);
        $toUser = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcloveInfo['user_id']);
        
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($toUser['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");
            $renlingText = str_replace("{NICKNAME}",$tcloveInfo['xm'], lang('plugin/tom_tclove', 'template_renling_hongniang_msg_1'));
            $renlingText = str_replace("{HONGNIANGNAME}",$hongninagInfo['name'],$renlingText);
            $smsData = array(
                'first'         => $renlingText,
                'keyword1'      => $tcloveConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'vip_list' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $vipListTmp = C::t('#tom_tclove#tom_tclove_vip')->fetch_all_list(""," ORDER BY vsort ASC,id DESC ",0,100);
    $vipList = array();
    if(is_array($vipListTmp) && !empty($vipListTmp)){
        foreach ($vipListTmp as $key => $value){
            $vipList[$key] = $value;
        }
    }
    
    $vipList = iconv_to_utf8($vipList);
    
    $outArr = array(
        'code'  => 200,
        'list'  => $vipList,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'editvip' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tclove_id        = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0; 
    $vip_id           = intval($_GET['vip_id'])>0? intval($_GET['vip_id']):0;
    $vip_time         = isset($_GET['vip_time'])? addslashes($_GET['vip_time']):'';
    $vip_time         = strtotime($vip_time);
        
    $updateData = array();
    $updateData['vip_id']   = $vip_id;
    if($vip_id > 0){
        $updateData['vip_time'] = $vip_time;
    }else{
        $updateData['vip_time'] = 0;
    }
    
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'close_tel_1' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tclove_id  = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    
    $updateData = array();
    $updateData['close_tel'] = 1;
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
   
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'close_tel_0' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tclove_id  = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    
    $updateData = array();
    $updateData['close_tel'] = 0;
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'is_open_1' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tclove_id  = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    
    $updateData = array();
    $updateData['is_open'] = 1;
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
   
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'is_open_0' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tclove_id  = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    
    $updateData = array();
    $updateData['is_open'] = 0;
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'visitor_visit_0' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tclove_id  = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    
    $updateData = array();
    $updateData['visitor_visit'] = 0;
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
   
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'visitor_visit_1' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tclove_id  = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    
    $updateData = array();
    $updateData['visitor_visit'] = 1;
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tclove_id  = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
   
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tclove_id  = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tclove_id  = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
    
    C::t('#tom_tclove#tom_tclove')->delete_by_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_collect')->delete_by_user_id($tcloveInfo['user_id']);
    C::t('#tom_tclove#tom_tclove_collect')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_chakan')->delete_by_user_id($tcloveInfo['user_id']);
    C::t('#tom_tclove#tom_tclove_look')->delete_by_user_id($tcloveInfo['user_id']);
    C::t('#tom_tclove#tom_tclove_look')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_xihuan')->delete_by_user_id($tcloveInfo['user_id']);
    C::t('#tom_tclove#tom_tclove_xihuan')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_photo')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_video')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_talk')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_talk_pinglun')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_zan')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_talk_zan')->delete_by_tclove_id($tclove_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'shenhe' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tclove_id      = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
    if($tcloveInfo['site_id'] == 1){
        $sitename = $tcloveConfig['plugin_name'];
    }else{
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcloveInfo['site_id']);
        $sitename = $siteInfo['name'];
    }
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status']    = 1;
        C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
        
        $shenhe = str_replace('{CONTENT}', $tcloveInfo['xm'], $Lang['template_tclove_shenhe_ok']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tclove&site='.$tcloveInfo['site_id'].'&mod=info&tclove_id='.$tcloveInfo['id'].'">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=info&tclove_id=".$tcloveInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $sitename,
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }

        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
        
        $shenhe = str_replace('{CONTENT}', $tcloveInfo['xm'], $Lang['template_tclove_shenhe_no']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tclove&site='.$tcloveInfo['site_id'].'&mod=edit">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=edit");
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcloveConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}else if($act == 'batch_shenhe1' && submitcheck('tclove_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcloveIdsArr = array();
    if(is_array($_GET['tclove_ids'])){
        foreach($_GET['tclove_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcloveIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcloveIdsArr)){
        $tcloveIdsStr = implode(',', $tcloveIdsArr);
        $tcloveListTmp = C::t("#tom_tclove#tom_tclove")->fetch_all_list(" AND id IN({$tcloveIdsStr}) ", 'ORDER BY id DESC', 0, 100);
        $userIdsArr = array();
        foreach($tcloveListTmp as $key => $value){
            
            $userIdsArr[] = $value['user_id'];
            
            $updateData = array();
            $updateData['shenhe_status'] = 1;
            C::t('#tom_tclove#tom_tclove')->update($value['id'], $updateData);
            
        }
        
        if(!empty($tongchengConfig['template_id'])){
            $userIdsStr = implode(',', $userIdsArr);
            $userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            foreach($userListTmp as $key => $value){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($value['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=my");
                    $smsData = array(
                        'first'         => $Lang['shenhe_tclove_succ_msg'],
                        'keyword1'      => $tcloveConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($value['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_shenhe3' && submitcheck('tclove_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcloveIdsArr = array();
    if(is_array($_GET['tclove_ids'])){
        foreach($_GET['tclove_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcloveIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcloveIdsArr)){
        $tcloveIdsStr = implode(',', $tcloveIdsArr);
        $tcloveListTmp = C::t("#tom_tclove#tom_tclove")->fetch_all_list(" AND id IN({$tcloveIdsStr}) ", 'ORDER BY id DESC', 0, 100);
        $userIdsArr = array();
        foreach($tcloveListTmp as $key => $value){
            
            $userIdsArr[] = $value['user_id'];
            
            $updateData = array();
            $updateData['shenhe_status'] = 3;
            C::t('#tom_tclove#tom_tclove')->update($value['id'], $updateData);
        }
        
        if(!empty($tongchengConfig['template_id'])){
            $userIdsStr = implode(',', $userIdsArr);
            $userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            foreach($userListTmp as $key => $value){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($value['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=my");
                    $smsData = array(
                        'first'         => $Lang['shenhe_tclove_fail_msg'],
                        'keyword1'      => $tcloveConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($value['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_show' && submitcheck('tclove_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcloveIdsArr = array();
    if(is_array($_GET['tclove_ids'])){
        foreach($_GET['tclove_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcloveIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcloveIdsArr)){
        foreach($tcloveIdsArr as $key => $value){
            
            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tclove#tom_tclove')->update($value,$updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_hide' && submitcheck('tclove_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcloveIdsArr = array();
    if(is_array($_GET['tclove_ids'])){
        foreach($_GET['tclove_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcloveIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcloveIdsArr)){
        foreach($tcloveIdsArr as $key => $value){
            
            $updateData = array();
            $updateData['status'] = 0;
            C::t('#tom_tclove#tom_tclove')->update($value,$updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_close_tel_1' && submitcheck('tclove_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcloveIdsArr = array();
    if(is_array($_GET['tclove_ids'])){
        foreach($_GET['tclove_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcloveIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcloveIdsArr)){
        foreach($tcloveIdsArr as $key => $value){
            
            $updateData = array();
            $updateData['close_tel'] = 0;
            C::t('#tom_tclove#tom_tclove')->update($value,$updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_close_tel_0' && submitcheck('tclove_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcloveIdsArr = array();
    if(is_array($_GET['tclove_ids'])){
        foreach($_GET['tclove_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcloveIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcloveIdsArr)){
        foreach($tcloveIdsArr as $key => $value){
            
            $updateData = array();
            $updateData['close_tel'] = 1;
            C::t('#tom_tclove#tom_tclove')->update($value,$updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_is_open_1' && submitcheck('tclove_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcloveIdsArr = array();
    if(is_array($_GET['tclove_ids'])){
        foreach($_GET['tclove_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcloveIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcloveIdsArr)){
        foreach($tcloveIdsArr as $key => $value){
            
            $updateData = array();
            $updateData['is_open'] = 1;
            C::t('#tom_tclove#tom_tclove')->update($value,$updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_is_open_0' && submitcheck('tclove_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcloveIdsArr = array();
    if(is_array($_GET['tclove_ids'])){
        foreach($_GET['tclove_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcloveIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcloveIdsArr)){
        foreach($tcloveIdsArr as $key => $value){
            
            $updateData = array();
            $updateData['is_open'] = 0;
            C::t('#tom_tclove#tom_tclove')->update($value,$updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_visitor_visit_1' && submitcheck('tclove_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcloveIdsArr = array();
    if(is_array($_GET['tclove_ids'])){
        foreach($_GET['tclove_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcloveIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcloveIdsArr)){
        foreach($tcloveIdsArr as $key => $value){
            
            $updateData = array();
            $updateData['visitor_visit'] = 1;
            C::t('#tom_tclove#tom_tclove')->update($value,$updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_visitor_visit_0' && submitcheck('tclove_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcloveIdsArr = array();
    if(is_array($_GET['tclove_ids'])){
        foreach($_GET['tclove_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcloveIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcloveIdsArr)){
        foreach($tcloveIdsArr as $key => $value){
            
            $updateData = array();
            $updateData['visitor_visit'] = 0;
            C::t('#tom_tclove#tom_tclove')->update($value,$updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('tclove_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcloveIdsArr = array();
    if(is_array($_GET['tclove_ids'])){
        foreach($_GET['tclove_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcloveIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcloveIdsArr)){
        foreach($tcloveIdsArr as $key => $value){
            $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value);
            
            C::t('#tom_tclove#tom_tclove')->delete_by_id($value);
            C::t('#tom_tclove#tom_tclove_collect')->delete_by_user_id($tcloveInfo['user_id']);
            C::t('#tom_tclove#tom_tclove_collect')->delete_by_tclove_id($value);
            C::t('#tom_tclove#tom_tclove_chakan')->delete_by_user_id($tcloveInfo['user_id']);
            C::t('#tom_tclove#tom_tclove_look')->delete_by_user_id($tcloveInfo['user_id']);
            C::t('#tom_tclove#tom_tclove_look')->delete_by_tclove_id($value);
            C::t('#tom_tclove#tom_tclove_xihuan')->delete_by_user_id($tcloveInfo['user_id']);
            C::t('#tom_tclove#tom_tclove_xihuan')->delete_by_tclove_id($value);
            C::t('#tom_tclove#tom_tclove_photo')->delete_by_tclove_id($value);
            C::t('#tom_tclove#tom_tclove_video')->delete_by_tclove_id($value);
            C::t('#tom_tclove#tom_tclove_talk')->delete_by_tclove_id($value);
            C::t('#tom_tclove#tom_tclove_talk_pinglun')->delete_by_tclove_id($value);
            C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_tclove_id($value);
            C::t('#tom_tclove#tom_tclove_talk_pinglun_zan')->delete_by_tclove_id($value);
            C::t('#tom_tclove#tom_tclove_talk_zan')->delete_by_tclove_id($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('tclove_id')){
    $outArr = array(
        'code'=> 1,
    );
        
    $tclove_id = intval($_GET['tclove_id'])>0? intval($_GET['tclove_id']):0;
    
    $tcloveInfoTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
    $tcloveInfo = array();
    if(!empty($tcloveInfoTmp)){
        
        $tcloveInfo = $tcloveInfoTmp;
        
        $userInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);
        
        if($tcloveInfo['birth_year'] > 0){    
            if($tcloveConfig['age_type_id'] == 1){
                $age = $nowYear - $tcloveInfo['birth_year'];
            }else{
                $age = $nowYear - $tcloveInfo['birth_year'] + 1;
            }
        }else{
            $age = '';
        }
        
        $xingzuo         = $xingzuoArray[$tcloveInfo['xingzuo_id']];
        $shuxiang        = $shuxiangArray[$tcloveInfo['shuxiang_id']];
        $minzu           = $minzuArray[$tcloveInfo['minzu_id']];
        $marital         = $maritalArray[$tcloveInfo['marital_id']];
        $edu             = $eduArray[$tcloveInfo['edu_id']];
        $house           = $houseArray[$tcloveInfo['house_id']];
        $car             = $carArray[$tcloveInfo['che_id']];
        $zheou_marital   = $maritalArray[$tcloveInfo['zheou_marital_id']];
        $zheou_edu       = $eduArray[$tcloveInfo['zheou_edu_id']];
        $zheou_minzu     = $minzuArray[$tcloveInfo['zheou_minzu_id']];
        
        $hujiCityInfoTmp        = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($tcloveInfo['hjcity_id']);
        $hujiAreaInfoTmp        = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($tcloveInfo['hjarea_id']);
        
        $videoList  = C::t('#tom_tclove#tom_tclove_video')->fetch_all_list(" AND tclove_id = {$tcloveInfo['id']} ", 'ORDER BY id DESC',0,1);
        $video_pic = '';
        if(!preg_match('/^http/', $videoList[0]['video_pic']) ){
            if(strpos($videoList[0]['video_pic'], 'source/plugin/tom_') === FALSE){
                $video_pic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$videoList[0]['video_pic'];
            }else{
                $video_pic = $videoList[0]['video_pic'];
            }
        }else{
            $video_pic = $videoList[0]['video_pic'];
        }
        
        $avatar_status = 0;
        $photoDataTmp = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list(" AND tclove_id = {$tcloveInfo['id']} AND type = 1 AND is_avatar = 1", 'ORDER BY id DESC', 0, 1);
        if(is_array($photoDataTmp) && !empty($photoDataTmp)){
            $avatar_status = 1;
        }

        $photoData = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list(" AND tclove_id = {$tcloveInfo['id']} AND type = 1", 'ORDER BY id DESC', 0, 10000);
        $photoList = array();
        $avatar = '';
        $i = 0;
        if(is_array($photoData) && !empty($photoData)){
            foreach($photoData as $key => $value){
                $picurlTmp = $value['picurlTmp'];
                if($avatar_status == 1){
                    if($value['is_avatar'] == 1){
                        $avatar = $picurlTmp;
                    }else{
                        $photoList[] = $picurlTmp;
                    }
                }else{
                    $i++;
                    if($i == 1){
                        $avatar = $photoData[0]['picurlTmp'];
                    }else{
                        $photoList[] = $picurlTmp;
                    }
                }
            }
        }

        $tcloveInfo['userInfo']             = $userInfoTmp;
        $tcloveInfo['hujiCityInfo']         = $hujiCityInfoTmp;
        $tcloveInfo['hujiAreaInfo']         = $hujiAreaInfoTmp;
        $tcloveInfo['age']                  = $age;
        $tcloveInfo['xingzuo']              = $xingzuo;
        $tcloveInfo['shuxiang']             = $shuxiang;
        $tcloveInfo['minzu']                = $minzu;
        $tcloveInfo['marital']              = $marital;
        $tcloveInfo['edu']                  = $edu;
        $tcloveInfo['house']                = $house;
        $tcloveInfo['car']                  = $car;
        $tcloveInfo['zheou_marital']        = $zheou_marital;
        $tcloveInfo['zheou_edu']            = $zheou_edu;
        $tcloveInfo['zheou_minzu']          = $zheou_minzu;
        $tcloveInfo['video_pic']            = $video_pic;
        $tcloveInfo['avatar']               = $avatar;
        $tcloveInfo['photoList']            = $photoList;
    }
    
    $tcloveInfo = iconv_to_utf8($tcloveInfo);
    
    $outArr = array(
        'code'  => 200,
        "msg"   => "",
        "data"  => $tcloveInfo,
    );
    echo json_encode($outArr); exit;
}

$site_id           = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$user_id           = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$tclove_id         = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):'';
$xm                = isset($_GET['xm'])? addslashes(urldecode($_GET['xm'])):'';
$user_no           = isset($_GET['user_no'])? intval($_GET['user_no']):'';
$tui_id            = isset($_GET['tui_id'])? intval($_GET['tui_id']):'';
$sex               = isset($_GET['sex'])? intval($_GET['sex']):0;
$vip_id            = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
$top_status        = isset($_GET['top_status'])? intval($_GET['top_status']):0;
$hongniang_id      = isset($_GET['hongniang_id'])? intval($_GET['hongniang_id']):0;
$is_ok             = isset($_GET['is_ok'])? intval($_GET['is_ok']):2;
$shenhe_status     = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$tui_award_status  = isset($_GET['tui_award_status'])? intval($_GET['tui_award_status']):2;
$page              = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize          = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$vipListTmp = C::t('#tom_tclove#tom_tclove_vip')->fetch_all_list(""," ORDER BY id DESC ",0,20);
$vipList = array();
if(is_array($vipListTmp) && !empty($vipListTmp)){
    foreach ($vipListTmp as $key => $value){
        $vipList[$value['id']] = $value;
    }
}

$hongniangListTmp = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_all_list(""," ORDER BY paixu ASC ,id DESC ",0,100);
$hongniangList = array();
if(is_array($hongniangListTmp) && !empty($hongniangListTmp)){
    foreach ($hongniangListTmp as $key => $value){
        $hongniangList[$value['id']] = $value;
    }
}

$whereStr = '';
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}
if(!empty($tclove_id)){
    $whereStr.= " AND id={$tclove_id} ";
}
if(!empty($user_no)){
    $whereStr.= " AND user_no={$user_no} ";
}
if($tui_id > 0){
    $whereStr.= " AND tui_id={$tui_id} ";
}
if(!empty($sex)){
    if($sex == 1){
        $whereStr.= " AND sex=1 ";
    }
    if($sex == 2){
        $whereStr.= " AND sex=2 ";
    }
}
if($vip_id > 0){
    $whereStr.= " AND vip_id= {$vip_id} ";
}
if(!empty($top_status)){
    if($top_status == 1){
        $whereStr.= " AND top_status=0 ";
    }
    if($top_status == 2){
        $whereStr.= " AND top_status=1 ";
    }
}
if($hongniang_id > 0 && $hongniang_id != 999999 ){
    $whereStr.= " AND hongniang_id= {$hongniang_id}";
}else if($hongniang_id == 999999){
    $whereStr.= " AND hongniang_id= 0";
}
if(!empty($is_ok)){
    if($is_ok == 1){
        $whereStr.= " AND is_ok=0 ";
    }
    if($is_ok == 2){
        $whereStr.= " AND is_ok=1 ";
    }
}
if(!empty($shenhe_status)){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}
if($tui_award_status == 0){
    $whereStr.= " AND tui_award_status=0 AND tui_id > 0 AND shenhe_status = 1 AND status = 1 AND is_ok = 1 ";
}

$order = "ORDER BY add_time DESC,id DESC";

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tclove#tom_tclove')->fetch_all_count($whereStr,$xm);
$userListTmp  = C::t('#tom_tclove#tom_tclove')->fetch_all_list($whereStr,$order,$start,$pagesize,$xm);
$userList = array();
if(!empty($userListTmp)){
    foreach ($userListTmp as $key => $value) {
        $userList[$key] = $value;
        
        if($value['birth_year'] > 0){
            if($tcloveConfig['age_type_id'] == 1){
                $age = $nowYear - $value['birth_year'];
            }else{
                $age = $nowYear - $value['birth_year'] + 1;
            }
        }else{
            $age = '-';
        }
        
        $avatar = tom_tclove_avatar($value['id']);
        
        $marital   = $maritalArray[$value['marital_id']];
        $edu       = $eduArray[$value['edu_id']];
        
        $tuiInfoTmp        = C::t('#tom_tclove#tom_tclove_tui')->fetch_by_id($value['tui_id']);
        $userInfoTmp       = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tuiInfoTmp['user_id']);
        $siteInfoTmp       = $sitesList[$value['site_id']];
        $vipInfoTmp        = $vipList[$value['vip_id']];
        $hongniangInfoTmp  = $hongniangList[$value['hongniang_id']];
        $hujiCityInfoTmp   = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($value['hjcity_id']);
        $hujiAreaInfoTmp   = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($value['hjarea_id']);
        
        $userList[$key]['age']                = $age;
        $userList[$key]['avatar']             = $avatar;
        $userList[$key]['marital']            = $marital;
        $userList[$key]['edu']                = $edu;
        $userList[$key]['userInfo']           = $userInfoTmp;
        $userList[$key]['siteInfo']           = $siteInfoTmp;
        $userList[$key]['vipInfo']            = $vipInfoTmp;
        $userList[$key]['hongniangInfo']      = $hongniangInfoTmp;
        $userList[$key]['hujiCityInfo']       = $hujiCityInfoTmp;
        $userList[$key]['hujiAreaInfo']       = $hujiAreaInfoTmp;
        $userList[$key]['vip_time']           = dgmdate($value['vip_time'],"Y-m-d H:i",$tomSysOffset);
        $userList[$key]['top_time']           = dgmdate($value['top_time'],"Y-m-d H:i",$tomSysOffset);
        $userList[$key]['add_time']           = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$countShenheStatus2     = C::t('#tom_tclove#tom_tclove')->fetch_all_count(" AND shenhe_status = 2 ");
$countShenheStatus3     = C::t('#tom_tclove#tom_tclove')->fetch_all_count(" AND shenhe_status = 3 ");
$counttui_award_status0 = C::t('#tom_tclove#tom_tclove')->fetch_all_count(" AND tui_award_status = 0 AND shenhe_status = 1 AND status = 1 AND is_ok = 1 AND tui_id > 0 ");

$pageUrl = $modPcadminUrl."&site_id={$site_id}&xm={$xm}&tui_id={$tui_id}&sex={$sex}&vip_id={$vip_id}&top_status={$top_status}&hongniang_id={$hongniang_id}&is_ok={$is_ok}&shenhe_status={$shenhe_status}&tui_award_status={$tui_award_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/list");