<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=talk";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'is_jingxuan_0' && submitcheck('talk_id')){
    $outArr = array(
        'code'=> 1,
    );

    $talk_id  = intval($_GET['talk_id'])>0 ? intval($_GET['talk_id']):0;
    
    $updateData = array();
    $updateData['is_jingxuan'] = 0;
    C::t('#tom_tclove#tom_tclove_talk')->update($talk_id,$updateData);
   
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'is_jingxuan_1' && submitcheck('talk_id')){
    $outArr = array(
        'code'=> 1,
    );

    $talk_id  = intval($_GET['talk_id'])>0 ? intval($_GET['talk_id']):0;
    
    $updateData = array();
    $updateData['is_jingxuan'] = 1;
    C::t('#tom_tclove#tom_tclove_talk')->update($talk_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('talk_id')){
    $outArr = array(
        'code'=> 1,
    );

    $talk_id  = intval($_GET['talk_id'])>0 ? intval($_GET['talk_id']):0;
    
    C::t('#tom_tclove#tom_tclove_talk')->delete_by_id($talk_id);
    C::t('#tom_tclove#tom_tclove_talk_pinglun')->delete_by_talk_id($talk_id);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_talk_id($talk_id);
    C::t('#tom_tclove#tom_tclove_talk_zan')->delete_by_talk_id($talk_id);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_zan')->delete_by_talk_id($talk_id);
    C::t('#tom_tclove#tom_tclove_photo')->delete_by_talk_id($talk_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'shenhe' && submitcheck('talk_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $talk_id        = intval($_GET['talk_id'])>0 ? intval($_GET['talk_id']):0;
    $tclove_id      = intval($_GET['tclove_id'])>0 ? intval($_GET['tclove_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $talkInfo = C::t('#tom_tclove#tom_tclove_talk')->fetch_by_id($talk_id);
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
    
    if($tcloveInfo['site_id'] == 1){
        $sitename = $tcloveConfig['plugin_name'];
    }else{
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcloveInfo['site_id']);
        $sitename = $siteInfo['name'];
    }
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status']    = 1;
        C::t('#tom_tclove#tom_tclove_talk')->update($talk_id,$updateData);
        
        $shenhe = str_replace('{CONTENT}', $talkInfo['content'], $Lang['template_tclove_talk_shenhe_ok']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tclove&site='.$tcloveInfo['site_id'].'&mod=talkinfo&talk_id='.$talkInfo['id'].'">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=talkinfo&talk_id=".$talkInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $sitename,
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }

        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tclove#tom_tclove_talk')->update($talk_id,$updateData);
        
        $shenhe = str_replace('{CONTENT}', $talkInfo['content'], $Lang['template_tclove_talk_shenhe_no']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tclove&site='.$tcloveInfo['site_id'].'&mod=mytalkList">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=mytalkList");
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcloveConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}else if($act == 'batch_shenhe1' && submitcheck('talk_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $talkIdsArr = array();
    if(is_array($_GET['talk_ids'])){
        foreach($_GET['talk_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $talkIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($talkIdsArr)){
        $talkIdsStr = implode(',', $talkIdsArr);
        $talkListTmp = C::t("#tom_tclove#tom_tclove_talk")->fetch_all_list(" AND id IN({$talkIdsStr}) ", 'ORDER BY id DESC', 0, 100);
        $userIdsArr = array();
        foreach($talkListTmp as $key => $value){
            $tcloveInfoTmp     = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
            $userIdsArr[] = $tcloveInfoTmp['user_id'];
            
            $updateData = array();
            $updateData['shenhe_status'] = 1;
            C::t('#tom_tclove#tom_tclove_talk')->update($value['id'], $updateData);
            
        }
        
        $userIdsArr = array_unique($userIdsArr);
        
        if(!empty($tongchengConfig['template_id'])){
            $userIdsStr = implode(',', $userIdsArr);
            $userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            foreach($userListTmp as $key => $value){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($value['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=mytalkList");
                    $smsData = array(
                        'first'         => $Lang['shenhe_talk_succ_msg'],
                        'keyword1'      => $tcloveConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($value['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_shenhe3' && submitcheck('talk_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $talkIdsArr = array();
    if(is_array($_GET['talk_ids'])){
        foreach($_GET['talk_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $talkIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($talkIdsArr)){
        $talkIdsStr = implode(',', $talkIdsArr);
        $talkListTmp = C::t("#tom_tclove#tom_tclove_talk")->fetch_all_list(" AND id IN({$talkIdsStr}) ", 'ORDER BY id DESC', 0, 100);
        $userIdsArr = array();
        foreach($talkListTmp as $key => $value){
            $tcloveInfoTmp     = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
            $userIdsArr[] = $tcloveInfoTmp['user_id'];
            
            $updateData = array();
            $updateData['shenhe_status'] = 3;
            C::t('#tom_tclove#tom_tclove_talk')->update($value['id'], $updateData);
        }
        
        $userIdsArr = array_unique($userIdsArr);
        
        if(!empty($tongchengConfig['template_id'])){
            $userIdsStr = implode(',', $userIdsArr);
            $userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            foreach($userListTmp as $key => $value){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($value['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=mytalkList");
                    $smsData = array(
                        'first'         => $Lang['shenhe_tclove_fail_msg'],
                        'keyword1'      => $tcloveConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($value['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_is_jingxuan_0' && submitcheck('talk_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $talkIdsArr = array();
    if(is_array($_GET['talk_ids'])){
        foreach($_GET['talk_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $talkIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($talkIdsArr)){
        foreach($talkIdsArr as $key => $value){
            
            $updateData = array();
            $updateData['is_jingxuan'] = 0;
            C::t('#tom_tclove#tom_tclove_talk')->update($value,$updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_is_jingxuan_1' && submitcheck('talk_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $talkIdsArr = array();
    if(is_array($_GET['talk_ids'])){
        foreach($_GET['talk_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $talkIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($talkIdsArr)){
        foreach($talkIdsArr as $key => $value){
            
            $updateData = array();
            $updateData['is_jingxuan'] = 1;
            C::t('#tom_tclove#tom_tclove_talk')->update($value,$updateData);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('talk_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $talkIdsArr = array();
    if(is_array($_GET['talk_ids'])){
        foreach($_GET['talk_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $talkIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($talkIdsArr)){
        foreach($talkIdsArr as $key => $value){
            
            C::t('#tom_tclove#tom_tclove_talk')->delete_by_id($value);
            C::t('#tom_tclove#tom_tclove_talk_pinglun')->delete_by_talk_id($value);
            C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_talk_id($value);
            C::t('#tom_tclove#tom_tclove_talk_zan')->delete_by_talk_id($value);
            C::t('#tom_tclove#tom_tclove_talk_pinglun_zan')->delete_by_talk_id($value);
            C::t('#tom_tclove#tom_tclove_photo')->delete_by_talk_id($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$site_id           = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$user_id           = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$talk_id           = isset($_GET['talk_id'])? intval($_GET['talk_id']):0;
$shenhe_status     = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$is_jingxuan       = isset($_GET['is_jingxuan'])? intval($_GET['is_jingxuan']):0;
$page              = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize          = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$whereStr = '';
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}
if($user_id > 0){
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($user_id);
    if(is_array($tcloveInfo) && !empty($tcloveInfo)){
        $tclove_id = $tcloveInfo['id'];
    }else{
        $tclove_id = 9999999;
    }
    $whereStr.= " AND tclove_id={$tclove_id} ";
}
if($talk_id > 0){
    $whereStr.= " AND id={$talk_id} ";
}
if($is_jingxuan == 1){
    $whereStr.= " AND is_jingxuan=0 ";
}else if($is_jingxuan == 2){
    $whereStr.= " AND is_jingxuan=1 ";
}
if($shenhe_status > 0){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}

$order = "ORDER BY talk_time DESC,id DESC";

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tclove#tom_tclove_talk')->fetch_all_count($whereStr);
$talkListTmp  = C::t('#tom_tclove#tom_tclove_talk')->fetch_all_list($whereStr,$order,$start,$pagesize);
$talkList = array();
if(!empty($talkListTmp)){
    foreach ($talkListTmp as $key => $value) {
        $talkList[$key] = $value;
        
        $siteInfoTmp       = $sitesList[$value['site_id']];
        $tcloveInfoTmp     = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
        $userInfoTmp       =  C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfoTmp['user_id']);
        $photoListTmp      = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list("AND type = 2 AND talk_id = {$value['id']} ", "ORDER BY id ASC",0,100);
        $photoList = array();
        if(is_array($photoListTmp) && !empty($photoListTmp)){
            foreach ($photoListTmp as $k => $v){
                $photoList[$k] = $v;
                if(!preg_match('/^http/', $v['pic_url']) ){
                    if(strpos($v['pic_url'], 'source/plugin/') === FALSE){
                        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$v['pic_url'];
                    }else{
                        $picurl = $v['pic_url'];
                    }
                }else{
                    $picurl = $v['pic_url'];
                }
                $photoList[$k]['pic_url'] = $picurl;
            }
        }
        $videoInfoTmp = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list("AND type = 3 AND talk_id = {$value['id']} ", "ORDER BY id ASC",0,1);
        
        $talkPinglunCount  = C::t('#tom_tclove#tom_tclove_talk_pinglun')->fetch_all_count("AND talk_id = {$value['id']}");
        
        $talkPinglunListTmpTmp   = C::t('#tom_tclove#tom_tclove_talk_pinglun')->fetch_all_list("AND talk_id = {$value['id']}", "ORDER BY pinglun_time DESC",0,3);
        $talkPinglunListTmp = array();
        if(is_array($talkPinglunListTmpTmp) && !empty($talkPinglunListTmpTmp)){
            foreach ($talkPinglunListTmpTmp as $k => $v){
                $talkPinglunListTmp[$k] = $v;
                $tcloveInfoPinglunTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_id($v['tclove_id']);
                $userInfoPinglunTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcloveInfoPinglunTmp['user_id']);
                
                $avatar = tom_tclove_avatar($v['tclove_id']);

                $talkReplyListTmpTmp   = C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->fetch_all_list("AND pinglun_id = {$v['id']}", "ORDER BY reply_time DESC",0,2);

                $talkReplyListTmp = array();

                if(is_array($talkReplyListTmpTmp) && !empty($talkReplyListTmpTmp)){
                    foreach ($talkReplyListTmpTmp as $kk => $vv){
                        $talkReplyListTmp[$kk] = $vv;
                        
                        $tcloveInfoReplyTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_id($vv['tclove_id']);
                        $userInfoReplyTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcloveInfoReplyTmp['user_id']);
                        
                        $talkReplyListTmp[$kk]['userInfoReply']     = $userInfoReplyTmp;
                    }
                }
                
                $talkPinglunListTmp[$k]['talkPinglunCount']     = $talkPinglunCount;
                $talkPinglunListTmp[$k]['tcloveInfoPinglun']    = $tcloveInfoPinglunTmp;
                $talkPinglunListTmp[$k]['talkReplyList']        = $talkReplyListTmp;
                $talkPinglunListTmp[$k]['userInfoPinglun']      = $userInfoPinglunTmp;
                $talkPinglunListTmp[$k]['avatar']     = $avatar;
            }
        }
        
        $talkList[$key]['siteInfo']           = $siteInfoTmp;
        $talkList[$key]['tcloveInfo']         = $tcloveInfoTmp;
        $talkList[$key]['userInfo']           = $userInfoTmp;
        $talkList[$key]['photoList']          = $photoList;
        $talkList[$key]['videoInfo']          = $videoInfoTmp;
        $talkList[$key]['talkPinglunList']    = $talkPinglunListTmp;
        $talkList[$key]['talk_time']          = dgmdate($value['talk_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&user_id={$user_id}&is_jingxuan={$is_jingxuan}&shenhe_status={$shenhe_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/talk");