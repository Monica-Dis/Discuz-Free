<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=pinglun";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('pinglun_id')){
    $outArr = array(
        'code'=> 1,
    );

    $pinglun_id  = intval($_GET['pinglun_id'])>0 ? intval($_GET['pinglun_id']):0;
    
    C::t('#tom_tclove#tom_tclove_talk_pinglun')->delete($pinglun_id);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_pinglun_id($pinglun_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('pinglun_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $pinglunIdsArr = array();
    if(is_array($_GET['pinglun_ids'])){
        foreach($_GET['pinglun_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $pinglunIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($pinglunIdsArr)){
        foreach($pinglunIdsArr as $key => $value){
            
            C::t('#tom_tclove#tom_tclove_talk_pinglun')->delete($value);
            C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_pinglun_id($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$user_id           = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$talk_id           = isset($_GET['talk_id'])? intval($_GET['talk_id']):0;
$page              = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize          = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = '';
if($user_id > 0){
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($user_id);
    if(is_array($tcloveInfo) && !empty($tcloveInfo)){
        $tclove_id = $tcloveInfo['id'];
    }else{
        $tclove_id = 9999999;
    }
    $whereStr.= " AND tclove_id={$tclove_id} ";
}
if($talk_id > 0){
    $whereStr.= " AND talk_id={$talk_id} ";
}

$order = "ORDER BY pinglun_time DESC,id DESC";

$start  = ($page - 1)*$pagesize;
$count = C::t('#tom_tclove#tom_tclove_talk_pinglun')->fetch_all_count($whereStr);
$pinglunListTmp = C::t('#tom_tclove#tom_tclove_talk_pinglun')->fetch_all_list($whereStr,$order,$start,$pagesize);
$pinglunList = array();
if(!empty($pinglunListTmp)){
    foreach ($pinglunListTmp as $key => $value) {
        $pinglunList[$key] = $value;
        
        $tcloveInfoTmp     = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
        
        $avatar = tom_tclove_avatar($value['tclove_id']);
        
        $pinglunList[$key]['tcloveInfo']         = $tcloveInfoTmp;
        $pinglunList[$key]['avatar']             = $avatar;
        $pinglunList[$key]['pinglun_time']       = dgmdate($value['pinglun_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&talk_id={$talk_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/pinglun");