<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=hongniangadd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $wx                 = isset($_GET['wx'])? addslashes($_GET['wx']):0;
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):0;
    $desc               = isset($_GET['desc'])? addslashes($_GET['desc']):'';
    $paixu              = isset($_GET['paixu'])? intval($_GET['paixu']):0;
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $qrcode             = isset($_GET['qrcode'])? addslashes($_GET['qrcode']):'';
    
    $tcloveInfo  = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($user_id);
    $userInfo    = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    if(!$tcloveInfo || !$userInfo){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['hongniangadd_error_301'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    
    $hongniangInfoTmp  = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_user_id($user_id);
    if($hongniangInfoTmp['id'] > 0){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['hongniangadd_error_302'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    
    $insertData = array();
    $insertData['user_id']          = $user_id;
    $insertData['name']             = $name;
    $insertData['wx']               = $wx;
    $insertData['tel']              = $tel;
    $insertData['picurl']           = $picurl;
    $insertData['qrcode']           = $qrcode;
    $insertData['desc']             = $desc;
    $insertData['paixu']            = $paixu;
    if(C::t('#tom_tclove#tom_tclove_hongniang')->insert($insertData)){
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }  
    
}

$addUrl = $modPcadminUrl."&act=add";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/hongniangadd");