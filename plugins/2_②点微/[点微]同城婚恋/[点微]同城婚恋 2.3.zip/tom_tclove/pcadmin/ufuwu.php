<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tclove_id  = intval($_GET['tclove_id'])>0? intval($_GET['tclove_id']):0;

$tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);

$modPcadminUrl  = $pcadminUrl."&tmod=ufuwu&tclove_id={$tclove_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('fuwu_type')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $fuwu_id    = isset($_GET['fuwu_id'])? intval($_GET['fuwu_id']):0;
    $fuwu_type  = isset($_GET['fuwu_type'])? intval($_GET['fuwu_type']):0;
    $fuwu_times = isset($_GET['fuwu_times'])? intval($_GET['fuwu_times']):0;
    $beizu      = isset($_GET['beizu'])? addslashes($_GET['beizu']):'';
    
    $fuwuInfo = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_by_id($fuwu_id);
    $ufuwuInfo = C::t('#tom_tclove#tom_tclove_ufuwu')->fetch_all_list("AND fuwu_id = {$fuwu_id} AND tclove_id ={$tclove_id}"," ORDER BY id DESC ",0,1);
    
    if($fuwu_id <= 0){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['fuwu_name_error_msg'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    
    if($fuwu_times <= 0){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['fuwu_times_error_0_msg'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    if($fuwu_type == 1){
        if(is_array($ufuwuInfo) && $ufuwuInfo[0]['id'] > 0){
            if($ufuwuInfo[0]['fuwu_times'] < $fuwu_times){
                $outArr = array(
                    'code'=> 1001,
                    'msg'=> diconv($Lang['fuwu_times_error_msg'],CHARSET,'utf-8'),
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['fuwu_times_error_msg'],CHARSET,'utf-8'),
            );
            echo json_encode($outArr); exit;
        }
    }
    if(is_array($ufuwuInfo) && $ufuwuInfo[0]['id'] > 0){
        $updateData = array();
        if($fuwu_type == 1){
            $updateData['fuwu_times']   = $ufuwuInfo[0]['fuwu_times'] - $fuwu_times;
        }else if($fuwu_type == 2){
            $updateData['fuwu_times']   = $ufuwuInfo[0]['fuwu_times'] + $fuwu_times;
        }
        C::t('#tom_tclove#tom_tclove_ufuwu')->update($ufuwuInfo[0]['id'], $updateData);
    }else{
        $insertData = array();
        $insertData['tclove_id']        = $tclove_id;
        $insertData['fuwu_id']          = $fuwu_id;
        $insertData['fuwu_name']        = $fuwuInfo['fuwu_name'];
        $insertData['fuwu_times']       = $fuwu_times;
        C::t('#tom_tclove#tom_tclove_ufuwu')->insert($insertData);
    }
    
    $insertData = array();
    $insertData['tclove_id']        = $tclove_id;
    $insertData['fuwu_id']          = $fuwu_id;
    $insertData['change_times']     = $fuwu_times;
    if(is_array($ufuwuInfo) && $ufuwuInfo[0]['id'] > 0){
        $insertData['old_times']        = $ufuwuInfo[0]['fuwu_times'];
    }else{
        $insertData['old_times']        = 0;
    }
    $insertData['op_type']          = 1;
    $insertData['beizu']            = $beizu;
    $insertData['op_time']         = TIMESTAMP;
    C::t('#tom_tclove#tom_tclove_ufuwu_log')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'del' && submitcheck('ufuwu_log_id')){
    $outArr = array(
        'code'=> 1,
    );

    $ufuwu_log_id  = intval($_GET['ufuwu_log_id'])>0 ? intval($_GET['ufuwu_log_id']):0;
    
    C::t('#tom_tclove#tom_tclove_ufuwu_log')->delete_by_id($ufuwu_log_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$fuwuListTmp    = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_all_list("","  ORDER BY fsort ASC,id DESC ",0,100);
$fuwuList = array();
if(is_array($fuwuListTmp) && !empty($fuwuListTmp)){
    foreach ($fuwuListTmp as $key => $value){
        $fuwuList[$key] = $value;
        $ufuwuInfoTmp = C::t('#tom_tclove#tom_tclove_ufuwu')->fetch_all_list("AND fuwu_id = {$value['id']} AND tclove_id ={$tclove_id}"," ORDER BY id DESC ",0,1);
        
        if(is_array($ufuwuInfoTmp) && $ufuwuInfoTmp[0]['id'] > 0){
            $fuwuList[$key]['status'] = 1;
            $fuwuList[$key]['ufuwuInfo'] = $ufuwuInfoTmp;
        }else{
            $fuwuList[$key]['status'] = 0;
        }
    }
}

$avatar = tom_tclove_avatar($tclove_id);

$page              = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize          = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = " AND tclove_id={$tclove_id} ";
    
$start = ($page-1)*$pagesize;
$count = C::t('#tom_tclove#tom_tclove_ufuwu_log')->fetch_all_count($where);
$ufuwulogListTmp = C::t('#tom_tclove#tom_tclove_ufuwu_log')->fetch_all_list($where," ORDER BY op_time DESC,id DESC ",$start,$pagesize);
$ufuwulogList = array();
if(!empty($ufuwulogListTmp)){
    foreach($ufuwulogListTmp as $key => $value){
        $ufuwulogList[$key] = $value;

        $fuwuInfoTmp      = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_by_id($value['fuwu_id']);
        $tongchengInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['op_user_id']);

        $ufuwulogList[$key]['fuwuInfo'] = $fuwuInfoTmp;
        $ufuwulogList[$key]['tongchengInfo'] = $tongchengInfoTmp;
        $ufuwulogList[$key]['op_time'] = dgmdate($value['op_time'],"Y-m-d H:i",$tomSysOffset);
    }
}
    
$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/ufuwu");