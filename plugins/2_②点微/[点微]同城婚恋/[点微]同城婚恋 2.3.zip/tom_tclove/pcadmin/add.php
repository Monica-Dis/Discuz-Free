<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=add";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $user_id            = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $xm                 = isset($_GET['xm'])? daddslashes($_GET['xm']):'';
    $sex                = isset($_GET['sex'])? intval($_GET['sex']):0;
    $birthday           = isset($_GET['birthday'])? daddslashes($_GET['birthday']):'';
    $birth_year         = isset($_GET['birth_year'])? daddslashes($_GET['birth_year']):'';
    $birth_month        = isset($_GET['birth_month'])? daddslashes($_GET['birth_month']):'';
    $birth_day          = isset($_GET['birth_day'])? daddslashes($_GET['birth_day']):'';
    $ymdArr             = explode('-', $birthday);
    $birth_year         = $ymdArr[0];
    $birth_month        = $ymdArr[1];
    $birth_day          = $ymdArr[2];
    $height             = isset($_GET['height'])? intval($_GET['height']):0;
    $weight             = isset($_GET['weight'])? intval($_GET['weight']):0;
    $xingzuo_id         = isset($_GET['xingzuo_id'])? intval($_GET['xingzuo_id']):0;
    $shuxiang_id        = isset($_GET['shuxiang_id'])? intval($_GET['shuxiang_id']):0;
    $xuexing_id         = isset($_GET['xuexing_id'])? intval($_GET['xuexing_id']):0;
    $minzu_id           = isset($_GET['minzu_id'])? intval($_GET['minzu_id']):0;
    $marital_id         = isset($_GET['marital_id'])? intval($_GET['marital_id']):0;
    $child_id           = isset($_GET['child_id'])? intval($_GET['child_id']):0;
    $job                = isset($_GET['job'])? daddslashes($_GET['job']):0;
    $edu_id             = isset($_GET['edu_id'])? intval($_GET['edu_id']):0;
    $province_id        = isset($_GET['province_id'])? intval($_GET['province_id']):0;
    $city_id            = isset($_GET['city_id'])? intval($_GET['city_id']):0;
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $towns_id           = isset($_GET['towns_id'])? intval($_GET['towns_id']):0;
    $hjprovince_id      = isset($_GET['hjprovince_id'])? intval($_GET['hjprovince_id']):0;
    $hjcity_id          = isset($_GET['hjcity_id'])? intval($_GET['hjcity_id']):0;
    $hjarea_id          = isset($_GET['hjarea_id'])? intval($_GET['hjarea_id']):0;
    $hjtowns_id         = isset($_GET['hjtowns_id'])? intval($_GET['hjtowns_id']):0;
    $tel                = isset($_GET['tel'])? daddslashes($_GET['tel']):'';
    $wx                 = isset($_GET['wx'])? daddslashes($_GET['wx']):0;
    $qq                 = isset($_GET['qq'])? daddslashes($_GET['qq']):0;
    $shouru             = isset($_GET['shouru'])? daddslashes($_GET['shouru']):0;
    $house_id           = isset($_GET['house_id'])? intval($_GET['house_id']):0;
    $che_id             = isset($_GET['che_id'])? intval($_GET['che_id']):0;
    $zheou_min_age      = isset($_GET['zheou_min_age'])? intval($_GET['zheou_min_age']):0;
    $zheou_max_age      = isset($_GET['zheou_max_age'])? intval($_GET['zheou_max_age']):0;
    $zheou_min_height   = isset($_GET['zheou_min_height'])? intval($_GET['zheou_min_height']):0;
    $zheou_max_height   = isset($_GET['zheou_max_height'])? intval($_GET['zheou_max_height']):0;
    $zheou_marital_id   = isset($_GET['zheou_marital_id'])? intval($_GET['zheou_marital_id']):0;
    $zheou_minzu_id     = isset($_GET['zheou_minzu_id'])? intval($_GET['zheou_minzu_id']):0;
    $zheou_edu_id       = isset($_GET['zheou_edu_id'])? intval($_GET['zheou_edu_id']):0;
    $zheou_desc         = isset($_GET['zheou_desc'])? daddslashes($_GET['zheou_desc']):'';
    $describe           = isset($_GET['describe'])? daddslashes($_GET['describe']):'';
    $avatar             = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    
    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($userInfo['id']);
    
    if($tcloveInfo['id'] > 0){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['add_user_id_tishi'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    
    $auto_id = 0;
    $autoidTmp  = C::t('#tom_tclove#tom_tclove_autoid')->fetch_all_list(""," ORDER BY id DESC ",0,1);
    if(is_array($autoidTmp) && !empty($autoidTmp) && !empty($autoidTmp[0]['id'])){
        if($autoidTmp[0]['id'] > 9990 && $autoidTmp[0]['id'] < 101010 ){
            $insertData = array();
            $insertData['id']               = 101011;
            $insertData['add_time']         = TIMESTAMP;
            if(C::t('#tom_tclove#tom_tclove_autoid')->insert($insertData)){
                $auto_id = C::t('#tom_tclove#tom_tclove_autoid')->insert_id();
            }
        }else{
            $insertData = array();
            $insertData['add_time']         = TIMESTAMP;
            if(C::t('#tom_tclove#tom_tclove_autoid')->insert($insertData)){
                $auto_id = C::t('#tom_tclove#tom_tclove_autoid')->insert_id();
            }
        }
    }else{
        $insertData = array();
        $insertData['id']               = 1011;
        $insertData['add_time']         = TIMESTAMP;
        if(C::t('#tom_tclove#tom_tclove_autoid')->insert($insertData)){
            $auto_id = C::t('#tom_tclove#tom_tclove_autoid')->insert_id();
        }
    }
    $user_no = '';
    $auto_id_str = strval($auto_id);
    if($auto_id > 101010){
        $rand_num1 = mt_rand(1, 9);
        $user_no.= $auto_id_str[0].$auto_id_str[1].$rand_num1;
        $rand_num2 = mt_rand(1, 9);
        $user_no.= $auto_id_str[2].$auto_id_str[3].$rand_num2;
        $rand_num3 = mt_rand(1, 9);
        $user_no.= $auto_id_str[4].$auto_id_str[5].$rand_num3;
    }else{
        $rand_num1 = mt_rand(1, 9);
        $user_no.= $auto_id_str[0].$auto_id_str[1].$rand_num1;
        $rand_num2 = mt_rand(1, 9);
        $user_no.= $auto_id_str[2].$auto_id_str[3].$rand_num2;
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
    }
    
    $provinceStr = "";
    $cityStr = "";
    $areaStr = "";
    $townsStr = "";
    $provinceInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($province_id);
    $cityInfo  = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($city_id);
    $areaInfo  = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($area_id);
    $townsInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($towns_id);
    if($provinceInfo){
        $provinceStr = $provinceInfo['name'];
    }
    if($cityInfo){
        $cityStr = $cityInfo['name'];
    }
    if($areaInfo){
        $areaStr = $areaInfo['name'];
    }
    if($townsInfo){
        $townsStr = $townsInfo['name'];
    }
    
    $hjprovinceStr = "";
    $hjcityStr = "";
    $hjareaStr = "";
    $hjtownsStr = "";
    $hjprovinceInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($hjprovince_id);
    $hjcityInfo  = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($hjcity_id);
    $hjareaInfo  = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($hjarea_id);
    $hjtownsInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($hjtowns_id);
    if($hjprovinceInfo){
        $hjprovinceStr = $hjprovinceInfo['name'];
    }
    if($hjcityInfo){
        $hjcityStr = $hjcityInfo['name'];
    }
    if($hjareaInfo){
        $hjareaStr = $hjareaInfo['name'];
    }
    if($hjtownsInfo){
        $hjtownsStr = $hjtownsInfo['name'];
    }
    
    $insertData = array();
    $insertData['site_id']              = $site_id;
    $insertData['user_id']              = $user_id;
    $insertData['user_no']              = $user_no;
    $insertData['province_id']          = $province_id;
    $insertData['city_id']              = $city_id;
    $insertData['area_id']              = $area_id;
    $insertData['towns_id']             = $towns_id;
    $insertData['hjprovince_id']        = $hjprovince_id;
    $insertData['hjcity_id']            = $hjcity_id;
    $insertData['hjarea_id']            = $hjarea_id;
    $insertData['hjtowns_id']           = $hjtowns_id;
    $insertData['xm']                   = $xm;
    $insertData['wx']                   = $wx;
    $insertData['qq']                   = $qq;
    $insertData['tel']                  = $tel;
    $insertData['sex']                  = $sex;
    $insertData['height']               = $height;
    $insertData['weight']               = $weight;
    $insertData['xingzuo_id']           = $xingzuo_id;
    $insertData['shuxiang_id']          = $shuxiang_id;
    $insertData['xuexing_id']           = $xuexing_id;
    $insertData['minzu_id']             = $minzu_id;
    $insertData['job']                  = $job;
    $insertData['shouru']               = $shouru;
    $insertData['edu_id']               = $edu_id;
    $insertData['marital_id']           = $marital_id;
    $insertData['child_id']             = $child_id;
    $insertData['house_id']             = $house_id;
    $insertData['che_id']               = $che_id;
    $insertData['birth_year']           = $birth_year;
    $insertData['birth_month']          = $birth_month;
    $insertData['birth_day']            = $birth_day;
    $insertData['zheou_min_age']        = $zheou_min_age;
    $insertData['zheou_max_age']        = $zheou_max_age;
    $insertData['zheou_min_height']     = $zheou_min_height;
    $insertData['zheou_max_height']     = $zheou_max_height;
    $insertData['zheou_marital_id']     = $zheou_marital_id;
    $insertData['zheou_minzu_id']       = $zheou_minzu_id;
    $insertData['zheou_edu_id']         = $zheou_edu_id;
    $insertData['zheou_desc']           = $zheou_desc;
    $insertData['describe']             = $describe;
    $insertData['area']                 = $provinceStr." ".$cityStr." ".$areaStr." ".$townsStr;
    $insertData['hjarea']               = $hjprovinceStr." ".$hjcityStr." ".$hjareaStr." ".$hjtownsStr;
    $insertData['is_ok']                = 1;
    if($tcloveConfig['close_tel'] == 1){
        $insertData['close_tel']   = 1;
    }
    $insertData['add_time']     = TIMESTAMP;
    
    $tclove_id = C::t("#tom_tclove#tom_tclove")->insert($insertData, true);
    
    if(!empty($photoArr)){
        foreach($photoArr as $key => $value){
            $insertData = array();
            $insertData['tclove_id']    = $tclove_id;
            $insertData['type']         = 1;
            $insertData['pic_url']      = $value['picurl'];
            C::t('#tom_tclove#tom_tclove_photo')->insert($insertData);
        }
    }
    
    if(!empty($avatar)){
        $insertData = array();
        $insertData['tclove_id']        = $tclove_id;
        $insertData['is_avatar']        = 1;
        $insertData['type']             = 1;
        $insertData['pic_url']          = $avatar;
        C::t("#tom_tclove#tom_tclove_photo")->insert($insertData);
    }
    
    if($tclove_id > 0){
        $outArr = array(
            'code'=> 200,
            'id'=> $tclove_id,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == 'check_user_id' && $_GET['formhash'] == FORMHASH ){
    $outArr = array(
        'code'=> 1,
    );
    
    $user_id  = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($userInfo['id']);
    
    $user_status = 0;
    if($tcloveInfo && $tcloveInfo['id'] > 0){
        $user_status = 1;
    }
    
    $outArr = array(
        'code'  => 200,
        'user_status'  => $user_status,
    );
    
    echo json_encode($outArr); exit;
    
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$majiUserListTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_like_list(' AND is_majia = 1 ',"ORDER BY id DESC",0,100,'');
$majiUserList = array();
if(is_array($majiUserListTmp) && !empty($majiUserListTmp)){
    foreach($majiUserListTmp as $key => $value){
        $majiUserList[$key] = $value;
    }
}

$hobby_listStr = str_replace("\r\n","{n}",$tcloveConfig['hobby']); 
$hobby_listStr = str_replace("\n","{n}",$hobby_listStr);
$hobby_listStr = str_replace("\r","{n}",$hobby_listStr);
$hobby_listTmpArr = explode("{n}", $hobby_listStr);

$provinceList   = $hjprovinceList   = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_level(1);
    
$addUrl = $modPcadminUrl."&act=add";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:pcadmin/add");