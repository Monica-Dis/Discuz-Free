<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = '';

$tom_tclove_photo_field = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_field();
if (!isset($tom_tclove_photo_field['qiniu_status'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tclove_photo')." ADD `qiniu_status` int(11) DEFAULT '0';\n";
}

$tom_tclove_field = C::t('#tom_tclove#tom_tclove')->fetch_all_field();
if (!isset($tom_tclove_field['sms_times'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tclove')." ADD `sms_times` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tclove_field['visitor_visit'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tclove')." ADD `visitor_visit` int(11) DEFAULT '1';\n";
}

$tom_tclove_vip_field = C::t('#tom_tclove#tom_tclove_vip')->fetch_all_field();
if (!isset($tom_tclove_vip_field['sms_times'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tclove_vip')." ADD `sms_times` int(11) DEFAULT '0';\n";
}

$tom_tclove_order_field = C::t('#tom_tclove#tom_tclove_order')->fetch_all_field();
if (!isset($tom_tclove_order_field['sms_times'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tclove_order')." ADD `sms_times` int(11) DEFAULT '0';\n";
}

if (!empty($sql)) {
	runquery($sql);
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_tom_tclove_pm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `pm_lists_id` int(11) DEFAULT '0',
  `new_num` int(11) DEFAULT '0',
  `last_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tclove_pm_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `min_use_id` int(11) DEFAULT '0',
  `max_use_id` int(11) DEFAULT '0',
  `last_content` text,
  `last_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tclove_pm_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `change_times` int(11) DEFAULT '0',
  `old_times` int(11) DEFAULT '0',
  `op_type` int(11) DEFAULT '0',
  `op_user_id` int(11) DEFAULT '0',
  `op_time` int(11) DEFAULT '0',
  `part1` varchar(255) NOT NULL,
  `part2` varchar(255) NOT NULL,
  `part3` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tclove_pm_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pm_lists_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `content` text,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;

if (!empty($sql)) {
	runquery($sql);
}

$finish = TRUE;