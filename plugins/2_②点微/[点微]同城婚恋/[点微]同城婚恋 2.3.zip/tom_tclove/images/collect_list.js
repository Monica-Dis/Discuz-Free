$container = $('#index-list');
var loadPage = 1;
function indexLoadList(){
    loadPage = 1;
    loadList(1);
}

var loadListStatus = 0;
var no_list_html = $("#no-list-html").html();
var load_html = $("#load-html").html();
function loadList(Page) {
    if(loadListStatus == 1){
        return false;
    }
    loadListStatus = 1;
    $("#index-list").html(load_html);
    $.ajax({
        type: "GET",
        url: ajaxLoadcllectListUrl,
        data: {page:Page},
        success: function(msg){
            $('#load-html').hide();
            loadListStatus = 0;
            var data = eval('('+msg+')');
            if(data == 205){
                $("#index-list").html(no_list_html);
                return false;
            }else{
                loadPage += 1;
                var $data = $( data );
                $container.html($data);
                $container.masonry({
                    itemSelector: '.item_big',
                    gutter:10,
                    isAnimated: true,
                    animationOptions: {
						duration: 800,
						easing: 'easeInOutBack',//�����������jQeasing����Ϳ������Ӷ�Ӧ�Ķ�̬����Ч�������û����ɾ�����У�Ĭ�������ٱ仯
						queue: false//�Ƿ���У���һ������ٲ���
					}
                });
                $container.imagesLoaded(function() {
                    $container.masonry( "layout" );
                });
            }
        }
    });
}

$(document).ready(function(){
   indexLoadList();
});

$(window).scroll(function () {
    var scrollTop       = $(this).scrollTop();
    var scrollHeight    = $(document).height();
    var windowHeight    = $(this).height();
    if ((scrollTop + windowHeight) >= (scrollHeight * 0.9)) {
        scrollLoadList();
    }
    if ((scrollTop + windowHeight) >= 1000) {
        $('#go-top').show();
    }else{
        $('#go-top').hide();
    }
});

$(document).on('click','#go-top', function () {
    $('body,html').animate({scrollTop: 0}, 500);
    return false;
});

function scrollLoadList() {
    if(loadListStatus == 1){
        return false;
    }
    if(loadPage > 50){
        return false;
    }
    $('#load-html').show();
	$('#no-load-html').hide();
    loadListStatus = 1;
    $.ajax({
        type: "GET",
        url: ajaxLoadcllectListUrl,
        data: {page:loadPage},
        success: function(msg){
            loadListStatus = 0;
            var data = eval('('+msg+')');
            if(data == 205){
                $('#load-html').hide();
                $('#no-load-html').show();
                return false;
            }else{
                loadPage += 1;
                var $data = $( data );
                $('#load-html').hide();
                $container.append($data);
                $container.imagesLoaded(function() {		
                    $container.masonry('appended',$data);						
                    $container.masonry( "reloadItems" );
                    $container.masonry( "layout" );
                });
            }
        }
    });
}