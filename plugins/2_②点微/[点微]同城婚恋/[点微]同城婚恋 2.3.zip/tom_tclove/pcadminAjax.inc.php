<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
if($_GET['act'] == 'city' && submitcheck('parent_id')){
    $outArr = array(
        'code'=> 1,
    );

    $parent_id = intval($_GET['parent_id'])>0 ? intval($_GET['parent_id']):0;
    
    $cityListTmp = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($parent_id);
    $cityList = array();
    if(is_array($cityListTmp) && !empty($cityListTmp)){
        foreach ($cityListTmp as $key => $value){
            
            $arrTmp = array();
            $arrTmp['id'] = $value['id'];
            $arrTmp['name'] = diconv($value['name'],CHARSET,'utf-8');
            
            $cityList[] = $arrTmp;
        }
    }
    
    $outArr = array(
        'code'  => 200,
        'list'  => $cityList,
    );    
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'area' && submitcheck('parent_id')){
    $outArr = array(
        'code'=> 1,
    );

    $parent_id = intval($_GET['parent_id'])>0 ? intval($_GET['parent_id']):0;
    
    $areaListTmp = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($parent_id);
    $areaList = array();
    if(is_array($areaListTmp) && !empty($areaListTmp)){
        foreach ($areaListTmp as $key => $value){
            
            $arrTmp = array();
            $arrTmp['id'] = $value['id'];
            $arrTmp['name'] = diconv($value['name'],CHARSET,'utf-8');
            
            $areaList[] = $arrTmp;
        }
    }
    
    $outArr = array(
        'code'  => 200,
        'list'  => $areaList,
    );    
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'towns' && submitcheck('parent_id')){
    $outArr = array(
        'code'=> 1,
    );

    $parent_id = intval($_GET['parent_id'])>0 ? intval($_GET['parent_id']):0;
    
    $areaListTmp = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($parent_id);
    $areaList = array();
    if(is_array($areaListTmp) && !empty($areaListTmp)){
        foreach ($areaListTmp as $key => $value){
            
            $arrTmp = array();
            $arrTmp['id'] = $value['id'];
            $arrTmp['name'] = diconv($value['name'],CHARSET,'utf-8');
            
            $areaList[] = $arrTmp;
        }
    }
    
    $outArr = array(
        'code'  => 200,
        'list'  => $areaList,
    );    
    echo json_encode($outArr); exit;
}else{
    echo 'error';exit;
}