<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS pre_tom_tclove;
DROP TABLE IF EXISTS pre_tom_tclove_autoid;
DROP TABLE IF EXISTS pre_tom_tclove_chakan;
DROP TABLE IF EXISTS pre_tom_tclove_clicks;
DROP TABLE IF EXISTS pre_tom_tclove_collect;
DROP TABLE IF EXISTS pre_tom_tclove_common;
DROP TABLE IF EXISTS pre_tom_tclove_diynav;
DROP TABLE IF EXISTS pre_tom_tclove_focuspic;
DROP TABLE IF EXISTS pre_tom_tclove_fuwu;
DROP TABLE IF EXISTS pre_tom_tclove_hongniang;
DROP TABLE IF EXISTS pre_tom_tclove_hongniang_renling_log;
DROP TABLE IF EXISTS pre_tom_tclove_hongniang_shenqing;
DROP TABLE IF EXISTS pre_tom_tclove_hongniang_shouyi_log;
DROP TABLE IF EXISTS pre_tom_tclove_look;
DROP TABLE IF EXISTS pre_tom_tclove_order;
DROP TABLE IF EXISTS pre_tom_tclove_photo;
DROP TABLE IF EXISTS pre_tom_tclove_report;
DROP TABLE IF EXISTS pre_tom_tclove_talk;
DROP TABLE IF EXISTS pre_tom_tclove_talk_pinglun;
DROP TABLE IF EXISTS pre_tom_tclove_talk_pinglun_reply;
DROP TABLE IF EXISTS pre_tom_tclove_talk_pinglun_zan;
DROP TABLE IF EXISTS pre_tom_tclove_talk_zan;
DROP TABLE IF EXISTS pre_tom_tclove_tui;
DROP TABLE IF EXISTS pre_tom_tclove_tui_phb;
DROP TABLE IF EXISTS pre_tom_tclove_tui_shouyi_log;
DROP TABLE IF EXISTS pre_tom_tclove_ufuwu;
DROP TABLE IF EXISTS pre_tom_tclove_ufuwu_log;
DROP TABLE IF EXISTS pre_tom_tclove_video;
DROP TABLE IF EXISTS pre_tom_tclove_vip;
DROP TABLE IF EXISTS pre_tom_tclove_vip_fuwu;
DROP TABLE IF EXISTS pre_tom_tclove_xihuan;
DROP TABLE IF EXISTS pre_tom_tclove_pm;
DROP TABLE IF EXISTS pre_tom_tclove_pm_lists;
DROP TABLE IF EXISTS pre_tom_tclove_pm_log;
DROP TABLE IF EXISTS pre_tom_tclove_pm_message;
    
EOF;

runquery($sql);

$finish = TRUE;