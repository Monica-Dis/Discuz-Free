<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function tom_tclove_avatar($tclove_id){
    global $_G,$tongchengConfig;
    $photoData = array();
    $photoDataTmp = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list(" AND tclove_id = {$tclove_id} AND is_avatar =1 AND type = 1", 'ORDER BY id DESC', 0, 1);
    if(is_array($photoDataTmp) && !empty($photoDataTmp[0]['pic_url'])){
        $photoData = $photoDataTmp;
    }else{
        $photoData = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list(" AND tclove_id = {$tclove_id} AND type = 1", 'ORDER BY id DESC', 0, 1);
    }
    
    if(is_array($photoData) && !empty($photoData)){
        $picurl = $photoData[0]['pic_url'];
        if($tongchengConfig['open_yun'] == 2 && !empty($photoData[0]['oss_picurl']) && $photoData[0]['oss_status'] == 1){
            $picurl = $photoData[0]['oss_picurl'];
        }else if($tongchengConfig['open_yun'] == 3 && !empty($photoData[0]['qiniu_picurl']) && $photoData[0]['qiniu_status'] == 1){
            $picurl = $photoData[0]['qiniu_picurl'];
        }else{
            if(!preg_match('/^http/', $picurl)){
                if(strpos($picurl, 'source/plugin/tom_') === FALSE){
                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$picurl;
                }else{
                    $picurl  = $_G['siteurl'].$picurl;
                }
            }
        }
    }else{
        $loveInfoTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($loveInfoTmp['user_id']);
        $picurl = $userInfoTmp['picurl'];
    }
    
    return $picurl;
}

function tom_num_replace($string){
    $match = "/\d{5}/";
	if(!empty($string)){
		$string = preg_replace($match, '*****', $string);
	}
    return $string;
}

function wx_iconv_recurrence($value) {
	if(is_array($value)) {
		foreach($value AS $key => $val) {
			$value[$key] = wx_iconv_recurrence($val);
		}
	} else {
		$value = diconv($value, 'utf-8', CHARSET);
	}
	return $value;
}

/**
 * ���������������֮��ľ���
 * @param  Decimal $longitude1 ��㾭��
 * @param  Decimal $latitude1  ���γ��
 * @param  Decimal $longitude2 �յ㾭��
 * @param  Decimal $latitude2  �յ�γ��
 * @param  Int     $unit       ��λ 1:�� 2:����
 * @param  Int     $decimal    ���� ����С��λ��
 * @return Decimal
 */
function tomGetDistance($longitude1, $latitude1, $longitude2, $latitude2, $unit=2, $decimal=1){

    $EARTH_RADIUS = 6370.996; // ����뾶ϵ��
    $PI = 3.1415926;

    $radLat1 = $latitude1 * $PI / 180.0;
    $radLat2 = $latitude2 * $PI / 180.0;

    $radLng1 = $longitude1 * $PI / 180.0;
    $radLng2 = $longitude2 * $PI / 180.0;

    $a = $radLat1 - $radLat2;
    $b = $radLng1 - $radLng2;

    $distance = 2 * asin(sqrt(pow(sin($a/2),2) + cos($radLat1) * cos($radLat2) * pow(sin($b/2),2)));
    $distance = $distance * $EARTH_RADIUS * 1000;

    if($unit==2){
        $distance = $distance / 1000;
    }

    return round($distance, $decimal);

}

/**
 * ��ɫ16���� ת RGB
 */
function hex2rgbstr($hexColor){
    
    $color = str_replace('#','',$hexColor);
    if (strlen($color)> 3){
         $rgb = array(
              'r'=>hexdec(substr($color,0,2)),
              'g'=>hexdec(substr($color,2,2)),
              'b'=>hexdec(substr($color,4,2))
         );
    }else{
         $r = substr($color,0,1). substr($color,0,1);
         $g = substr($color,1,1). substr($color,1,1);
         $b = substr($color,2,1). substr($color,2,1);
         $rgb = array( 
              'r'=>hexdec($r),
              'g'=>hexdec($g),
              'b'=>hexdec($b)
         );
    }
    return $rgb['r'].','.$rgb['g'].','.$rgb['b'];
 
}