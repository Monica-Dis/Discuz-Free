<?php
	
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function get_month_phb_id($user_id) {
    global $_G;
    static $_use_month_phb_ids = array();
    $tomSysOffset = getglobal('setting/timeoffset');
    
    if(isset($_use_month_phb_ids[$user_id])){
        return $_use_month_phb_ids[$user_id];
    }
    
    $month_id = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
    $phbInfo = C::t('#tom_tclove#tom_tclove_tui_phb')->fetch_all_list(" AND user_id = {$user_id} AND phb_type = 2 AND month_id = {$month_id}", " ORDER BY id DESC", 0, 1);
    if (is_array($phbInfo) && !empty($phbInfo)){
        $_use_month_phb_ids[$user_id] = $phbInfo[0]['id'];
		return $phbInfo[0]['id'];
    }else{
        $insertData = array();
        $insertData['user_id']   = $user_id;
        $insertData['phb_type']  = 2;
        $insertData['month_id']  = $month_id;
        C::t('#tom_tclove#tom_tclove_tui_phb')->insert($insertData);
        $phb_id = C::t('#tom_tclove#tom_tclove_tui_phb')->insert_id();
        $_use_month_phb_ids[$user_id] = $phb_id;
        return $phb_id;
    }
}

function get_week_phb_id($user_id) {
    global $_G;
    static $_use_week_phb_ids = array();
    $tomSysOffset = getglobal('setting/timeoffset');
    
    if(isset($_use_week_phb_ids[$user_id])){
        return $_use_week_phb_ids[$user_id];
    }
    
    $week_id = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);
    $phbInfo = C::t('#tom_tclove#tom_tclove_tui_phb')->fetch_all_list(" AND user_id = {$user_id} AND phb_type = 3 AND week_id = {$week_id}", " ORDER BY id DESC", 0, 1);
    if (is_array($phbInfo) && !empty($phbInfo)){
        $_use_week_phb_ids[$user_id] = $phbInfo[0]['id'];
		return $phbInfo[0]['id'];
    }else{
        $insertData = array();
        $insertData['user_id']    = $user_id;
        $insertData['phb_type']   = 3;
        $insertData['week_id']   = $week_id;
        C::t('#tom_tclove#tom_tclove_tui_phb')->insert($insertData);
        $phb_id = C::t('#tom_tclove#tom_tclove_tui_phb')->insert_id();
        $_use_week_phb_ids[$user_id] = $phb_id;
        return $phb_id;
    }
}

function update_tui_phb($user_id,$money){
    $money = isset($money)? floatval($money): 0;
    if($money == 0){
        return false;
    }
    
    $month_phb_id = get_month_phb_id($user_id);
    $week_phb_id = get_week_phb_id($user_id);
    if(!$month_phb_id || !$week_phb_id){
        return false;
    }
    
    DB::query("UPDATE ".DB::table('tom_tclove_tui_phb')." SET shouyi=shouyi+{$money} WHERE id='{$month_phb_id}'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tclove_tui_phb')." SET shouyi=shouyi+{$money} WHERE id='{$week_phb_id}'", 'UNBUFFERED');
    
    $tcphbInfo = C::t('#tom_tclove#tom_tclove_tui_phb')->fetch_all_list("AND user_id={$user_id} AND phb_type=1","ORDER BY shouyi DESC,id DESC",0,1);
    if(is_array($tcphbInfo) && !empty($tcphbInfo)){
        DB::query("UPDATE ".DB::table('tom_tclove_tui_phb')." SET shouyi=shouyi+{$money} WHERE id='{$tcphbInfo[0]['id']}'", 'UNBUFFERED');
    }else{
        $insertData = array();
        $insertData['user_id']    = $user_id;
        $insertData['phb_type']   = 1;
        $insertData['shouyi']     = $money;
        C::t('#tom_tclove#tom_tclove_tui_phb')->insert($insertData);
    }
    
	return true;
}