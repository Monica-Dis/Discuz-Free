<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

$hongniangInfo  = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_user_id($__UserInfo['id']);

if($hongniangInfo['id'] > 0 ){
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");exit;
}

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;

$pagesize = 10;
$start = ($page-1)*$pagesize;

$whereStr = " AND hongniang_id={$hongniangInfo['id']} ";

$hongniangshouyilogCount  = C::t('#tom_tclove#tom_tclove_hongniang_shouyi_log')->fetch_all_count(" {$whereStr} ");

$hongniangshouyilogData  = C::t('#tom_tclove#tom_tclove_hongniang_shouyi_log')->fetch_all_list(" {$whereStr} ","ORDER BY log_time DESC, id DESC",$start,$pagesize);
$hongniangshouyilogList = array();
if(is_array($hongniangshouyilogData) && !empty($hongniangshouyilogData)){
    foreach ($hongniangshouyilogData as $key => $value){
        $hongniangshouyilogList[$key] = $value;
        
        $tcloveInfoTmp = C::t("#tom_tclove#tom_tclove")->fetch_by_id("{$value['tclove_id']}");
        $hongniangshouyilogList[$key]['tcloveInfoTmp'] = $tcloveInfoTmp;
        $hongniangshouyilogList[$key]['tcloveInfoTmp']['pic_url'] = tom_tclove_avatar($value['tclove_id']);
        $hongniangshouyilogList[$key]['log_time']   = dgmdate($value['log_time'], 'm-d H:i',$tomSysOffset);
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $tuishouyilogCount){
    $showNextPage = 0;
}
$allPageNum     = ceil($tuishouyilogCount/$pagesize);
$prePage        = $page - 1;
$nextPage       = $page + 1;
$prePageUrl     = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerHongniang_shouyi_log&page={$prePage}";
$nextPageUrl    = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerHongniang_shouyi_log&page={$nextPage}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:managerHongniang_shouyi_log");