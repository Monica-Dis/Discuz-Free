<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$myhongniangInfo = array();
if($__TcloveInfo['hongniang_id'] > 0){
    $myhongniangInfo =  C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_id($__TcloveInfo['hongniang_id']);
    if(!preg_match('/^http/', $myhongniangInfo['picurl']) ){
        if(strpos($myhongniangInfo['picurl'], 'source/plugin/tom_') === FALSE){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$myhongniangInfo['picurl'];
        }else{
            $picurl = $_G['siteurl'].$myhongniangInfo['picurl'];
        }
    }else{
        $picurl = $myhongniangInfo['picurl'];
    }
    if(!preg_match('/^http/', $myhongniangInfo['qrcode']) ){
        if(strpos($myhongniangInfo['qrcode'], 'source/plugin/tom_') === FALSE){
            $qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$myhongniangInfo['qrcode'];
        }else{
            $qrcode = $_G['siteurl'].$myhongniangInfo['qrcode'];
        }
    }else{
        $qrcode = $myhongniangInfo['qrcode'];
    }
}

if(is_array($myhongniangInfo) && !empty($myhongniangInfo)){
    $hongniangListTmp =  C::t('#tom_tclove#tom_tclove_hongniang')->fetch_all_list("AND id != {$myhongniangInfo['id']}", 'ORDER BY paixu ASC,id DESC', 0, 50);
}else{
    $hongniangListTmp =  C::t('#tom_tclove#tom_tclove_hongniang')->fetch_all_list("", 'ORDER BY paixu ASC,id DESC', 0, 50);
}
$hongniangList = array();
if(is_array($hongniangListTmp) && !empty($hongniangListTmp)){
    foreach($hongniangListTmp as $key => $value){
        $hongniangList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $hongniangList[$key]['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $hongniangList[$key]['picurl'] = $_G['siteurl'].$value['picurl'];
            }
        }
        if(!preg_match('/^http/', $value['qrcode']) ){
            if(strpos($value['qrcode'], 'source/plugin/tom_') === FALSE){
                $hongniangList[$key]['qrcode'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['qrcode'];
            }else{
                $hongniangList[$key]['qrcode'] = $_G['siteurl'].$value['qrcode'];
            }
        }
    }
}

$ajaxXuanzehongniangUrl = "plugin.php?id=tom_tclove:ajax&site={$site_id}&act=xuanze_hongniang&&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:myhongniang");