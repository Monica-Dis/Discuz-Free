<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
if($_GET['act'] == 'pic' && $_GET['formhash'] == FORMHASH){
    $tclove_id = isset($_GET['tclove_id'])? daddslashes($_GET['tclove_id']): 0;
    $pic_num = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_count(" AND tclove_id = {$tclove_id} AND type = 1");
    if($pic_num < $tcloveConfig['pic_num']){
    }else{
        echo 'OVER|url';exit;
    }
    
   $upload = new tom_upload();
    $_FILES["uploaderInput"]['name'] = addslashes(diconv(urldecode($_FILES["uploaderInput"]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['uploaderInput'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
//    require_once libfile('class/image');
//    $image = new image();
//    $image->Thumb($upload->attach['target'], '', 720, 720, 1, 1);
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    
    $insertData = array();
    $insertData['tclove_id']        = $tclove_id;
    $insertData['type']             = 1;
    $insertData['pic_url']          = $upload->attach['attachment'];
    C::t('#tom_tclove#tom_tclove_photo')->insert($insertData,true);
    $picid = C::t('#tom_tclove#tom_tclove_photo')->insert_id();
    
    $updateData = array();
    echo 'OK|'.$picurl.'|'.$picid.'|'.$tclove_id;exit;
    
}else if($_GET['act'] == 'report' && $_GET['formhash'] == FORMHASH){

    $upload = new tom_upload();
    $_FILES["Filedata"]['name'] = addslashes(diconv(urldecode($_FILES["Filedata"]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['Filedata'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    require_once libfile('class/image');
    $image = new image();
    $image->Thumb($upload->attach['target'], '', 720, 720, 1, 1);
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'talk_photo' && $_GET['formhash'] == FORMHASH){

    $upload = new tom_upload();
    $_FILES["filedata1"]['name'] = addslashes(diconv(urldecode($_FILES["filedata1"]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata1'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'hongniang_photo' && $_GET['formhash'] == FORMHASH){
    
    $upload = new tom_upload();
    $suffix = isset($_GET['suffix'])>0 ? addslashes($_GET['suffix']):'';
    $name = "filename".$suffix;

    $_FILES[$name]['name'] = addslashes(diconv(urldecode($_FILES[$name]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES[$name], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}