<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tuiInfo  = C::t('#tom_tclove#tom_tclove_tui')->fetch_by_user_id($__UserInfo['id']);

if($tcloveConfig['tui_phb_type'] == 1){
    $phb_type = 1;
    $where = "AND phb_type=1";
}else if($tcloveConfig['tui_phb_type'] == 3){
    $phb_type = 3;
    $week_id = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);
    $where = "AND phb_type=3 AND week_id={$week_id}";
}else{
    $phb_type = 2;
    $month_id = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
    $where = "AND phb_type=2 AND month_id={$month_id}";
}

$phbCount  = C::t('#tom_tclove#tom_tclove_tui_phb')->fetch_all_count($where);

$phbData  = C::t('#tom_tclove#tom_tclove_tui_phb')->fetch_all_list($where,"ORDER BY shouyi DESC,id DESC",0,10);
$phbList  = $phbbigList = array();
if(is_array($phbData) && !empty($phbData)){
    foreach ($phbData as $key => $value){
        $key++;
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id("{$value['user_id']}");
        
        if($key > 3){
            $phbList[$key] = $value;
            $phbList[$key]['userInfoTmp'] = $userInfoTmp;
        }else{
            $phbbigList[$key] = $value;
            $phbbigList[$key]['userInfoTmp'] = $userInfoTmp;
        }
    }
}

$tuishouyilogData  = C::t('#tom_tclove#tom_tclove_tui_shouyi_log')->fetch_all_list("", 'ORDER BY log_time DESC,id DESC',0,5);
$tuishouyilogList = array();
if(is_array($tuishouyilogData) && !empty($tuishouyilogData)){
    foreach ($tuishouyilogData as $key => $value){
        $tuishouyilogList[$key] = $value;
        
        $tuiInfoTmp  = C::t("#tom_tclove#tom_tclove_tui")->fetch_by_id("{$value['tui_id']}");
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id("{$tuiInfoTmp['user_id']}");
        $tuishouyilogList[$key]['userInfoTmp'] = $userInfoTmp;
    }
}

$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index&tui_id={$__TclovetuiInfo['id']}";

$haibaoShareUrl  = $shareUrl;
$haibaoQrcodeImg = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($shareUrl);
$haibaoNickname = cutstr($__TcloveInfo['xm'], 12, '...');

$tui_guize_txt = discuzcode($tcloveConfig['tui_guize_txt'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);

$ajaxLoadshouyiPhbListUrl    = 'plugin.php?id=tom_tclove:ajax&act=shouyiphblist&phb_type='.$phb_type.'&formhash='.$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:tui");