<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$outStr = '';
    
$tclove_id   = isset($_GET['tclove_id'])? intval($_GET['tclove_id']):0;
$tab         = isset($_GET['tab'])? intval($_GET['tab']):1;
$page        = isset($_GET['page'])? intval($_GET['page']):1;

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

if($tab == 4){
    $where = " AND  shenhe_status = 1 AND must_vip = 1";
}else{
    $where = " AND  shenhe_status = 1 AND must_vip = 0";
}

if(!empty($sql_in_site_ids) && $tcloveConfig['show_all_sites'] == 0){
    $where.= " AND site_id IN({$sql_in_site_ids}) ";
}

if($tclove_id > 0){
    $where.= " AND tclove_id = {$tclove_id} ";
}

if($tab == 1){
    $orderStr = " ORDER BY talk_time DESC,id DESC ";
}else if($tab == 2){
    $orderStr = " ORDER BY clicks DESC,talk_time DESC,id DESC ";
}else{
    $orderStr = " ORDER BY is_jingxuan DESC,talk_time DESC,id DESC";
}

$pagesize = 8;
$start = ($page-1)*$pagesize;
if($tab == 3 && !empty($latitude) && !empty($longitude)){
    $talkData  = C::t('#tom_tclove#tom_tclove_talk')->fetch_all_nearby_list($where,$start,$pagesize,$latitude,$longitude);
}else{
    $talkData  = C::t('#tom_tclove#tom_tclove_talk')->fetch_all_list($where,$orderStr,$start,$pagesize);
}
$talkList = array();
if(is_array($talkData) && !empty($talkData)){
    foreach ($talkData as $key => $value){

        $userTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
        
        $talkList[$key] = $value;
        $talkList[$key]['user'] = $userTmp;
        $talkList[$key]['user']['pic_url'] = tom_tclove_avatar($userTmp['id']);
        
        $talkphotoListTmp = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list("AND type = 2 AND talk_id = {$value['id']} ","ORDER BY id ASC",0,100);
        $talkphotoList = array();
        $talkphotoListStr = '';
        if(is_array($talkphotoListTmp) && !empty($talkphotoListTmp)){
            foreach($talkphotoListTmp as $kk => $vv){
                $talkphotoList[] = $vv['picurlTmp'];
            }
            $talkphotoListStr = implode('|', $talkphotoList);
        }

        $talkvideoInfoTmp =  C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list("AND type = 3 AND talk_id = {$value['id']}","ORDER BY id DESC",0,1);
        $talkvideoInfo = array();
        if(is_array($talkvideoInfoTmp) && !empty($talkvideoInfoTmp[0])){
            $talkvideoInfo = $talkvideoInfoTmp[0];
            $talkvideoInfo['pic_url'] = $talkvideoInfo['picurlTmp'];
        }

        $talkZanInfoTmp = C::t('#tom_tclove#tom_tclove_talk_zan')->fetch_all_list(" AND talk_id={$value['id']} AND tclove_id = {$__TcloveInfo['id']} ","ORDER BY id DESC",0,20);

        $talkList[$key]['content']            = tom_num_replace(dhtmlspecialchars($value['content']));
        $talkList[$key]['talkphotoList']      = $talkphotoList;
        $talkList[$key]['talkphotoListStr']   = $talkphotoListStr;
        $talkList[$key]['talkvideoInfo']      = $talkvideoInfo;
        $talkList[$key]['talkZanInfo']        = $talkZanInfoTmp;
        $talkList[$key]['link']               = 'plugin.php?id=tom_tclove&site='.$value['site_id'].'&mod=talkinfo&talk_id='.$value['id'];
    }
}

if(is_array($talkList) && !empty($talkList)){
    foreach ($talkList as $key => $value){
        $talkphotoCount = count($value['talkphotoList']);
        $talkvideoCount = count($value['talkvideoInfo']);
        $talkAllphotoCount = $talkphotoCount + $talkvideoCount;
        $outStr .= '<div class="talk_item" id="talk_item_'.$value['id'].'" data-id='.$value['id'].'>';
            $outStr .= '<div class="talk_item_avatar dislay-flex">';
                $outStr.= '<a href="plugin.php?id=tom_tclove&site='.$site_id.'&mod=info&tclove_id='.$value['tclove_id'].'">';
                $outStr .= '<img class="avatar" src="'.$value['user']['pic_url'].'"/>';
                $outStr.= '</a>';
                $outStr.= '<a href="'.$value['link'].'" class="flex" >';
                $outStr .= '<div class="talk_item_avatar_right">';
                    $outStr .= '<div class="talk_item_avatar_right_top">';
                    $outStr .= '<span>'.$value['user']['xm'].'</span>';
                    if($value['user']['sex'] == 1 ){
                        $outStr .= '<img src="source/plugin/tom_tclove/images/boy.png">';
                    }else{
                        $outStr .= '<img src="source/plugin/tom_tclove/images/girl.png">';
                    }
                    $outStr .= '</div>';
                    $outStr .= '<div class="talk_item_avatar_right_bottom">';
                        $outStr .= '<span>'.dgmdate($value['talk_time'],"m-d H:i",$tomSysOffset).'</span>';
                    $outStr .= '</div>';
                $outStr .= '</div>';
                $outStr.= '</a>';
                $outStr .= '<div class="talk_link">';
                    $outStr.= '<a href="'.$value['link'].'">';
                        $outStr .= '<i class="tciconfont tcicon-yanjing"></i>'.lang('plugin/tom_tclove', 'talk_more_btn');
                    $outStr.= '</a>';
                $outStr .= '</div>';
            $outStr .= '</div>';
            $outStr.= '<a href="'.$value['link'].'">';
            $outStr .= '<div class="talk_item_content">';
                if($value['is_jingxuan'] == 1){
                    $outStr .= '<span class="left"><i class="tciconfont tcicon-jingxuan"></i>'.lang('plugin/tom_tclove', 'talk_jingxuan').'</span>';
                }
                $outStr .= '<span class="right">'.$value['content'].'</span>';
            $outStr .= '</div>';
            $outStr.= '</a>';
            if($talkAllphotoCount > 0){
                if($talkphotoCount == 1 && $talkvideoCount < 1){
                    $outStr.= '<div class="talk_item_pic one clearfix">';
                }else if($talkAllphotoCount == 2){
                    $outStr.= '<div class="talk_item_pic two clearfix">';
                }else if($talkAllphotoCount > 2){
                    $outStr.= '<div class="talk_item_pic three clearfix">';
                }else if($talkvideoCount > 0 && $talkphotoCount < 1){
                    $outStr.= '<div class="talk_item_video clearfix">';
                }
                $outStr.= '<input type="hidden" name="photo_list" class="photo_list" value="'.$value['talkphotoListStr'].'">';
                if(is_array($value['talkvideoInfo']) && !empty($value['talkvideoInfo'])){
                    $outStr.= '<a href="'.$value['link'].'">';
                        $outStr .= '<img src="'.$value['talkvideoInfo']['pic_url'].'"><span class="play"></span>';
                    $outStr.= '</a>';
                }
                foreach ($value['talkphotoList'] as $k3 => $v3){
                    $outStr.= '<a href="javascript:void(0);" onclick="showPicList($(this),'.$k3.');"><img src="'.$v3.'"></a>';
                }
                $outStr.= '</div>';
            }
            if(!empty($value['address'])){
                $outStr .= '<div class="talk_item_address dislay-flex">';
                    $outStr .= '<div class="left flex">';
                        $outStr.= '<i class="tciconfont tcicon-love_dingwei"></i>'.$value['address'];
                    $outStr.= '</div>';
                    if(isset($value['distance'])){
                        $juli = tomGetDistance($longitude, $latitude, $value['longitude'], $value['latitude']);
                        $outStr.= '<div class="right">'.$juli.'km</div>';
                    }
                $outStr.= '</div>';
            }
            $outStr .= '<div class="talk_item_bottom dislay-flex">';
                $outStr .= '<div class="talk_item_bottom_num clicks">';
                $outStr.= '<a href="'.$value['link'].'">';
                    $outStr.= '<i class="tciconfont tcicon-yanjing"></i>';
                    $outStr .= '<span>'.$value['clicks'].'</span>';
                    $outStr.= '</a>';
                $outStr.= '</div>';
                $outStr .= '<div class="talk_item_bottom_num ping">';
                    $outStr.= '<a href="'.$value['link'].'">';
                    $outStr.= '<i class="tciconfont tcicon-xinxi"></i>';
                    $outStr .= '<span>'.$value['pinglun_count'].'</span>';
                    $outStr.= '</a>';
                $outStr.= '</div>';
                $outStr .= '<div class="talk_item_bottom_num zan " data-talk_id='.$value['id'].' style="cursor: pointer;">';
                    $outStr .= '<span class="zan zan_on">';
                        if(is_array($value['talkZanInfo']) && !empty($value['talkZanInfo'])){
                            $outStr .= '<i class="tciconfont tcicon-tcdianzan__on"><span>'.$value['zan_count'].'</span></i>';
                        }else{
                            $outStr .= '<i class="tciconfont tcicon-tcdianzan"><span>'.$value['zan_count'].'</span></i>';
                        }
                    $outStr .= '</span>';
                $outStr.= '</div>';
            $outStr.= '</div>';
        $outStr .= '</div>';
    }
}else{
    $outStr = '205';
}
$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;