<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$isHongniangCount = 0;
if($__UserInfo['id'] > 0){
    $isHongniangCount =  C::t('#tom_tclove#tom_tclove_hongniang')->fetch_all_count("AND user_id = {$__UserInfo['id']}");
}

$outStr = '';

$user_no            = isset($_GET['user_no'])? intval($_GET['user_no']):0;
$xm                 = isset($_GET['xm'])? daddslashes(urldecode($_GET['xm'])):'';
$edu                = isset($_GET['edu'])? daddslashes(urldecode($_GET['edu'])):'';
$shouru             = isset($_GET['shouru'])? intval($_GET['shouru']):0;
$sex                = isset($_GET['sex'])? intval($_GET['sex']):0;
$height             = isset($_GET['height'])? intval($_GET['height']):0;
$age                = isset($_GET['age'])? intval($_GET['age']):0;
$marital            = isset($_GET['marital'])? intval($_GET['marital']):0;
$job                = isset($_GET['job'])? intval($_GET['job']):0;
$province_id        = isset($_GET['province_id'])? intval($_GET['province_id']):0;
$city_id            = isset($_GET['city_id'])? intval($_GET['city_id']):0;
$area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
$towns_id           = isset($_GET['towns_id'])? intval($_GET['towns_id']):0;
$ordertype          = !empty($_GET['ordertype'])? addslashes($_GET['ordertype']):'default';
$video_status       = isset($_GET['video_status'])? intval($_GET['video_status']):0;
$page               = isset($_GET['page'])? intval($_GET['page']):1;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$where = " AND is_ok = 1 AND shenhe_status = 1 AND status = 1 AND is_open = 1 ";

if(!empty($sql_in_site_ids) && $tcloveConfig['show_all_sites'] == 0){
    $where.= " AND site_id IN({$sql_in_site_ids}) ";
}

if($sex == 1){
    $where.=" AND sex = 1 ";
}else if($sex == 2){
    $where.=" AND sex = 2 ";
}
if($marital > 0){
    $where.=" AND marital_id = {$marital}";
}
if(!empty($user_no)){
    $where.=" AND user_no = {$user_no}";
}
if($age > 0){
    if($age == 1){
        if($tcloveConfig['age_type_id'] == 1){
            $startYear = $nowYear - 22;
            $endYear = $nowYear - 18;
        }else{
            $startYear = $nowYear - 22 + 1;
            $endYear = $nowYear - 18 + 1;
        }
        $where.=" AND birth_year >= {$startYear} AND birth_year <= {$endYear}";
    }else if($age == 2){
        if($tcloveConfig['age_type_id'] == 1){
            $startYear = $nowYear - 25;
            $endYear = $nowYear - 23;
        }else{
            $startYear = $nowYear - 25 + 1;
            $endYear = $nowYear - 23 + 1;
        }
        $where.=" AND birth_year >= {$startYear} AND birth_year <= {$endYear}";
    }else if($age == 3){
        if($tcloveConfig['age_type_id'] == 1){
            $startYear = $nowYear - 30;
            $endYear = $nowYear - 26;
        }else{
            $startYear = $nowYear - 30 + 1;
            $endYear = $nowYear - 26 + 1;
        }
        $where.=" AND birth_year >= {$startYear} AND birth_year <= {$endYear}";
    }else if($age == 4){
        if($tcloveConfig['age_type_id'] == 1){
            $startYear = $nowYear - 35;
            $endYear = $nowYear - 31;
        }else{
            $startYear = $nowYear - 35 + 1;
            $endYear = $nowYear - 31 + 1;
        }
        $where.=" AND birth_year >= {$startYear} AND birth_year <= {$endYear}";
    }else if($age == 5){
        if($tcloveConfig['age_type_id'] == 1){
            $startYear = $nowYear - 36;
        }else{
            $startYear = $nowYear - 36 + 1;
        }
        $where.=" AND birth_year <= {$startYear} ";
    }
}
if($height > 0){
    if($height == 1){
       $where.=" AND height < 155";
    }else if($height == 2){
        $where.=" AND height >= 156 AND height <= 160" ;
    }else if($height == 3){
        $where.=" AND height >=161 AND height <= 165" ;
    }else if($height == 4){
        $where.=" AND height >= 166 AND height <= 170" ;
    }else if($height == 5){
        $where.=" AND height >= 171 AND height <= 175" ;
    }else if($height == 6){
        $where.=" AND height >= 176 AND height <= 180" ;
    }else if($height == 7){
        $where.=" AND height > 180" ;
    }
}
if($shouru > 0){
    if($shouru == 1){
       $where.=" AND shouru < 5000";
    }else if($shouru == 2){
        $where.=" AND shouru >= 5000 AND shouru <= 10000 " ;
    }else if($shouru == 3){
        $where.=" AND shouru >10000 AND shouru <= 20000 " ;
    }else if($shouru == 4){
        $where.=" AND shouru > 20000 AND shouru <= 30000 " ;
    }else if($shouru == 5){
        $where.=" AND shouru > 30000 AND shouru <= 50000 " ;
    }else if($shouru == 6){
        $where.=" AND shouru > 50000 " ;
    }
}
if($edu > 0){
    if($edu == 1){
       $where.=" AND edu_id = 3";
    }else if($edu == 2){
        $where.=" AND edu_id = 4 " ;
    }else if($edu == 3){
        $where.=" AND edu_id = 5 " ;
    }else if($edu == 4){
        $where.=" AND edu_id = 6 " ;
    }else if($edu == 5){
        $where.=" AND edu_id = 7 " ;
    }else if($edu == 6){
        $where.=" AND edu_id = 8 " ;
    }
}
if($province_id > 0){
    $where.=" AND province_id = {$province_id} ";
}
if($city_id > 0){
    $where.=" AND city_id = {$city_id} ";
}
if($area_id > 0){
    $where.=" AND area_id = {$area_id} ";
}
if($towns_id > 0){
    $where.=" AND towns_id = {$towns_id} ";
}
if($video_status == 1){
    $where.=" AND video_status = 1";
}else if($video_status == 2){
    $where.=" AND video_status = 0";
}

if($ordertype == 'new'){
    $orderStr = " ORDER BY id DESC";
}else{
    $orderStr = " ORDER BY top_status DESC,top_time DESC, id DESC";
}

if($ordertype == 'lbs'){
    $where.=" AND open_fujin_status = 1 ";
}

$pagesize = 8;
$start = ($page-1)*$pagesize;

if($ordertype == 'lbs' && !empty($latitude) && !empty($longitude)){
    $userListTmp  = C::t('#tom_tclove#tom_tclove')->fetch_all_nearby_list($where,$start,$pagesize,$latitude,$longitude);
}else{
    $userListTmp  = C::t('#tom_tclove#tom_tclove')->fetch_all_list($where,$orderStr,$start,$pagesize,$xm);
}

$userList = array();
if(is_array($userListTmp) && !empty($userListTmp)){
    foreach ($userListTmp as $key => $value){
        $userList[$key] = $value;
        $userList[$key]['describe'] = tom_num_replace(cutstr(dhtmlspecialchars($value['describe']),58,"..."));
        if($value['birth_year'] > 0){
            if($tcloveConfig['age_type_id'] == 1){
                $userList[$key]['age'] = $nowYear - $value['birth_year'];
            }else{
                $userList[$key]['age'] = $nowYear - $value['birth_year'] + 1;
            }
        }else{
            $userList[$key]['age'] = '';
        }
        $userTongchengInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id("{$value['user_id']}");
        $userList[$key]['userTongchengInfoTmp'] = $userTongchengInfoTmp;
        $xihuanCount = C::t('#tom_tclove#tom_tclove_xihuan')->fetch_all_count("AND tclove_id ={$value['id']}");
        $isXihuan = array();
        if($__UserInfo['id'] > 0){
            $isXihuan = C::t('#tom_tclove#tom_tclove_xihuan')->fetch_all_list("AND user_id = {$__UserInfo['id']} AND tclove_id ={$value['id']}"," ORDER BY id DESC ",0,1);
        }
        $userList[$key]['xihuanCount'] = $xihuanCount;
        $userList[$key]['isXihuan']    = $isXihuan;
        $userList[$key]['pic_url']     = tom_tclove_avatar($value['id']);
        $renzhengPersonalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_all_list(" AND user_id = {$value['user_id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1 );
        $userList[$key]['renzhengPersonalInfoTmp'] = $renzhengPersonalInfoTmp;
        
        $userList[$key]['close_visitor_visit'] = 0;
        if($tcloveConfig['open_visitor_set'] == 1 && $value['visitor_visit'] == 0){
            if($__TcloveInfo['is_ok'] == 1 || $isHongniangCount > 0 || $tcloveConfig['must_wanshan'] == 0){
            }else{
                $userList[$key]['close_visitor_visit'] = 1;
                if($value['sex'] == 1){
                    $userList[$key]['xm'] = cutstr($value['xm'], 2,'').lang('plugin/tom_tclove','list_man');
                }else if($value['sex'] == 2){
                    $userList[$key]['xm'] = cutstr($value['xm'], 2,'').lang('plugin/tom_tclove','list_woman');
                }
            }
        }
        
    }
}

if(is_array($userList) && !empty($userList)){
    foreach ($userList as $key => $value){
        $outStr .= '<div class="item_big animated fadeIn clearfix"  data-id="'.$value['id'].'">';
            if($__TcloveInfo['is_ok'] == 1 || $isHongniangCount > 0 || $tcloveConfig['must_wanshan'] == 0){
                $outStr .= '<a href="plugin.php?id=tom_tclove&site='.$site_id.'&mod=info&tclove_id='.$value['id'].'">';
            }else if($__TcloveInfo['id'] > 0){
                $outStr .= '<a onclick="wanshan();" href="javascript:void;">';
            }else{
                $outStr .= '<a href="plugin.php?id=tom_tclove&&site='.$site_id.'&mod=my">';
            }
            if($value['close_visitor_visit'] == 1){
                $outStr .= '<div class="visitor_visit"><img src="source/plugin/tom_tclove/images/visitor_visit_list_ico.png"></div>';
            }else{
                if (is_array($value['renzhengPersonalInfoTmp']) && !empty($value['renzhengPersonalInfoTmp'][0])){
                    $outStr .= '<div class="renzheng"><img src="source/plugin/tom_tclove/images/renzheng_list_ico.png"></div>';
                }
            }
            if($value['top_status'] == 1){
                $outStr .= '<div class="listtop"><img src="source/plugin/tom_tclove/images/listtop_ico.png"></div>';
            }
            $outStr .= '<div class="pictop clearfix">';
                if($value['close_visitor_visit'] == 1){
                    $outStr .= '<img class="avatar img_blur" src="'.$value['pic_url'].'"/>';
                }else{
                    $outStr .= '<img class="avatar" src="'.$value['pic_url'].'"/>';
                }
                if($value['video_status'] == 1){
                    $outStr .= '<img class="video" src="source/plugin/tom_tongcheng/images/icon_play.png"/>';
                }
                $outStr .= '</div>';
            if($value['vip_id'] > 0 || (($value['house_id'] == 3 || $value['house_id'] == 4) && $showHouse == 1) || (($value['che_id'] == 2 || $value['che_id'] == 3 || $value['che_id'] == 4) && $showCar == 1 ) || (!empty($value['userTongchengInfoTmp']['tel']))){
                $outStr .= '<div class="user_icon clearfix">';
                    if($value['vip_id'] > 0){
                        $outStr .= '<img src="source/plugin/tom_tclove/images/vip.png">&nbsp;';
                    }
                    if(($value['house_id'] == 3 || $value['house_id'] == 4) && $showHouse == 1){
                        $outStr .= '<img src="source/plugin/tom_tclove/images/house.png">&nbsp;';
                    }
                    if(($value['che_id'] == 2 || $value['che_id'] == 3 || $value['che_id'] == 4) && $showCar == 1 ){
                        $outStr .= '<img src="source/plugin/tom_tclove/images/car.png">&nbsp;';
                    }
                    if(!empty($value['userTongchengInfoTmp']['tel'])){
                        $outStr .= '<img src="source/plugin/tom_tclove/images/mobile.png">&nbsp;';
                    }
                $outStr .= '</div>';
            }
            $outStr .= '<div class="picmiddle clearfix">';
                $outStr .='<div class="left">'.$value['xm'].'</div>';
                if($value['sex'] == 1){
                    $outStr .= '<div class="right"><img src="source/plugin/tom_tclove/images/boy.png"></div>';
                }else if($value['sex'] == 2){
                    $outStr .= '<div class="right"><img src="source/plugin/tom_tclove/images/girl.png"></div>';
                }
                $outStr .= '<span class="sui">'.$value['age'].''.lang('plugin/tom_tclove','sui').'</span>';
            $outStr .= '</div>';
            $outStr .= '<div class="shoucang clearfix">';
                $outStr .= '<div class="left">';
                    $outStr .= '<span>'.$value['shouru'].'/'.lang('plugin/tom_tclove','yue').'</span>';
                $outStr .= '</div>';
                if(isset($value['distance'])){
                    $juli = tomGetDistance($longitude, $latitude, $value['longitude'], $value['latitude']);
                    $outStr.= '<div class="right">'.$juli.'km</div>';
                }else{
                    $outStr .= '<div class="right">';
                        if($value['xihuanCount'] > 0){
                            $outStr .= '<span id="xihuan_num">'.$value['xihuanCount'].'</span>';
                            $outStr .= '<span class="qi">'.lang('plugin/tom_tclove','xihuan_num_msg').'</span>';
                        }
                    $outStr .= '</div>';
                }
            $outStr .= '</div>';
            $outStr .= '</a>';
            if($value['top_status'] == 1){
                $outStr .= '<div class="xihuan" style="top: 28px;">';
            }else{
                $outStr .= '<div class="xihuan">';
            }
                if(is_array($value['isXihuan']) && !empty($value['isXihuan'])){
                    $outStr .= '<i class="tciconfont tcicon-xihuan_b" style="color: #fd719b;font-size: 1.5em;"></i>';
                }else{
                    $outStr .= '<i class="tciconfont tcicon-xihuan_a" style="color: #fd719b;font-size: 1.5em;"></i>';
                }
            $outStr .= '</div>';
        $outStr .= '</div>';
    }
}else{
    $outStr = '205';
}
$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;