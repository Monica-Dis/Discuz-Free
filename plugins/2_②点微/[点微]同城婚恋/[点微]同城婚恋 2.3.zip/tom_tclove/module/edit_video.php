<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

if($__TcloveInfo['vip_id'] > 0){
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=vip");exit;
}

if($_GET['act'] == 'save' && submitcheck('video_form')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $video_url      = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_url      = dhtmlspecialchars($video_url);
    $video_pic      = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic      = dhtmlspecialchars($video_pic);
    
    $videoList  = C::t('#tom_tclove#tom_tclove_video')->fetch_all_list(" AND tclove_id = {$__TcloveInfo['id']} ","ORDER BY id DESC",0,1);
    if(is_array($videoList) && !empty($videoList)){
        foreach($videoList as $key => $value){
            if(empty($video_url) || empty($video_pic)){
                
                C::t('#tom_tclove#tom_tclove_video')->delete_by_id($value['id']);
                DB::query("UPDATE ".DB::table('tom_tclove')." SET video_status=0 WHERE id='{$value['tclove_id']}' ", 'UNBUFFERED');
                
            }else{
                $updateData = array();
                $updateData['site_id']      = $site_id;
                $updateData['tclove_id']    = $__TcloveInfo['id'];
                $updateData['video_url']    = $video_url;
                $updateData['video_pic']    = $video_pic;

                C::t('#tom_tclove#tom_tclove_video')->update($value['id'],$updateData);

                DB::query("UPDATE ".DB::table('tom_tclove')." SET video_status=1 WHERE id='{$value['tclove_id']}' ", 'UNBUFFERED');
            }
        }
    }else{
        $insertData = array();
        $insertData['site_id']      = $site_id;
        $insertData['tclove_id']    = $__TcloveInfo['id'];
        $insertData['video_url']    = $video_url;
        $insertData['video_pic']    = $video_pic;
        C::t('#tom_tclove#tom_tclove_video')->insert($insertData);
        
        DB::query("UPDATE ".DB::table('tom_tclove')." SET video_status=1 WHERE id='{$__TcloveInfo['id']}' ", 'UNBUFFERED');
    }
    
    $outArr = array(
        'status'        => 200,
    );
    echo json_encode($outArr); exit;
}      
   
$videoInfo  = C::t('#tom_tclove#tom_tclove_video')->fetch_all_list(" AND tclove_id = {$__TcloveInfo['id']} ", 'ORDER BY id DESC',0,1);

$video_pic = '';
if(!preg_match('/^http/', $videoInfo[0]['video_pic']) ){
    if(strpos($videoInfo[0]['video_pic'], 'source/plugin/tom_') === FALSE){
        $video_pic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$videoInfo[0]['video_pic'];
    }else{
        $video_pic = $videoInfo[0]['video_pic'];
    }
}else{
    $video_pic = $videoInfo[0]['video_pic'];
}

$saveUrl   = "plugin.php?id=tom_tclove&site={$site_id}&mod=edit_video&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:edit_video");