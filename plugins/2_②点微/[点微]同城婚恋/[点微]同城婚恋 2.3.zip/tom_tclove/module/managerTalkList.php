<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    if($__UserInfo['id'] != $tcloveConfig['tclovemanage_user_id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");exit;
    }
}
# check end

if($_GET['act'] == 'shenhe_ok' && submitcheck('talk_id')){
    
    $talk_id = intval($_GET['talk_id'])>0? intval($_GET['talk_id']):0;
    
    $updateData = array();
    $updateData['shenhe_status']     = 1;
    C::t('#tom_tclove#tom_tclove_talk')->update($talk_id,$updateData);
    
    $talkInfo = C::t('#tom_tclove#tom_tclove_talk')->fetch_by_id($talk_id);
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($talkInfo['tclove_id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);
    
    $shenhe = str_replace('{CONTENT}', $talkInfo['content'], lang("plugin/tom_tclove", "template_tclove_talk_shenhe_ok"));

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=talkinfo&talk_id=".$talk_id);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcloveConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
    }
    
    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    echo 200;exit;
    
}else if($_GET['act'] == 'shenhe_no' && submitcheck('talk_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $talk_id        = intval($_GET['talk_id'])>0? intval($_GET['talk_id']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $talkInfo = C::t('#tom_tclove#tom_tclove_talk')->fetch_by_id($talk_id);
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($talkInfo['tclove_id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);

    $updateData = array();
    $updateData['shenhe_status']     = 3;
    C::t('#tom_tclove#tom_tclove_talk')->update($talk_id,$updateData);

    $shenhe = str_replace('{CONTENT}', $talkInfo['content'], lang("plugin/tom_tclove", "template_tclove_talk_shenhe_no"));
    
    $content = str_replace("\r\n","",$content);
    $content = str_replace("\n","",$content);
    $content = str_replace("\r","",$content);
    
    if($tcloveInfo['site_id'] == 1){
        $sitename = $tcloveConfig['plugin_name'];
    }else{
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcloveInfo['site_id']);
        $sitename = $siteInfo['name'];
    }

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=mytalkList");
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $sitename,
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
    }
    
    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    $url = $_G['siteurl']."plugin.php?id=tom_tclove&mod=managerTalkList&keyword=".urlencode(trim($keyword));
    echo $url;exit;
    
}else if($_GET['act'] == 'shenhe_show'){
    
    $shenhe_type  = intval($_GET['shenhe_type'])>0? intval($_GET['shenhe_type']):0;
    $talk_id      = intval($_GET['talk_id'])>0? intval($_GET['talk_id']):0;
    
    $tclove_shenhe_fail_str = str_replace("\r\n","{n}",$tcloveConfig['tclove_shenhe_fail_text']); 
    $tclove_shenhe_fail_str = str_replace("\n","{n}",$tclove_shenhe_fail_str);
    $tcloveShenheFailArray  = explode("{n}", $tclove_shenhe_fail_str);
    
    $ajaxShenheUrl = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerTalkList&act=shenhe_no";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tclove:managerShenhe");exit;
    
}

$keyword  = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page  = intval($_GET['page'])>0? intval($_GET['page']):1;
$type  = intval($_GET['type'])>0? intval($_GET['type']):0;

if($type == 1){
    $where.= " AND shenhe_status=1 ";
}
if($type == 2){
    $where.= " AND shenhe_status=2 ";
}
if($type == 3){
    $where.= " AND shenhe_status=3 ";
}
if($__UserInfo['groupid'] == 2){
    $where.= " AND site_id={$site_id} ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;
$order = " ORDER BY id DESC ";

$count = C::t('#tom_tclove#tom_tclove_talk')->fetch_all_count($where,$keyword);
$talkListTmp = C::t('#tom_tclove#tom_tclove_talk')->fetch_all_list($where,$order,$start,$pagesize,$keyword);
$talkList = array();
foreach ($talkListTmp as $key => $value) {
    $userTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
    $talkList[$key] = $value;
    $talkList[$key]['user'] = $userTmp;

    $talkList[$key]['user']['pic_url'] = tom_tclove_avatar($userTmp['id']);
    $talkphotoListTmp = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list("AND type = 2 AND talk_id = {$value['id']} ", "ORDER BY id ASC",0,100);
    $talkphotoList = array();
    $talkphotoListStr = '';
    if(is_array($talkphotoListTmp) && !empty($talkphotoListTmp)){
        foreach($talkphotoListTmp as $kk => $vv){
            $picurlTmp = $vv['picurlTmp'];
            $talkphotoList[] = $picurlTmp;
        }
        $talkphotoListStr = implode('|', $talkphotoList);
    }
    
    $talkvideoInfoTmp =  C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list("AND type = 3 AND talk_id = {$value['id']}","ORDER BY id DESC",0,1);
    $talkvideoInfo = array();
    if(is_array($talkvideoInfoTmp) && !empty($talkvideoInfoTmp[0])){
        $talkvideoInfo = $talkvideoInfoTmp[0];
        $talkvideoInfo['pic_url'] = $talkvideoInfo['picurlTmp'];
    }
    
    $talkZanInfoTmp = C::t('#tom_tclove#tom_tclove_talk_zan')->fetch_all_list(" AND talk_id={$value['id']} AND tclove_id = {$__TcloveInfo['id']} ","ORDER BY id DESC",0,1);

    $talkList[$key]['content']          = tom_num_replace(dhtmlspecialchars($value['content']));
    $talkList[$key]['talkphotoList']    = $talkphotoList;
    $talkList[$key]['talkphotoListStr'] = $talkphotoListStr;
    $talkList[$key]['talkvideoInfo']    = $talkvideoInfo;
    $talkList[$key]['talkZanInfo']      = $talkZanInfoTmp;
    $talkList[$key]['clicks']           = $value['clicks'] + $value['virtual_clicks'];
    $talkList[$key]['talk_time']        = dgmdate($value['talk_time'],"m-d H:i",$tomSysOffset);
    $talkList[$key]['link']             = 'plugin.php?id=tom_tclove&site='.$value['site_id'].'&mod=talkinfo&talk_id='.$value['id'];
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum  = ceil($count/$pagesize);
$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerTalkList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerTalkList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];

$ajaxShenheOkUrl       = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerTalkList&act=shenhe_ok&formhash=".$formhash;
$ajaxShenheNoUrl       = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerTalkList&act=shenhe_no&formhash=".$formhash;
$talkZanAjaxUrl        = "plugin.php?id=tom_tclove:ajax&site={$site_id}&act=talkZan&formhash=".FORMHASH;
$deltalkUrl            = "plugin.php?id=tom_tclove:ajax&site={$site_id}&act=del_talk&formhash=".FORMHASH;
$searchUrl             = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerTalkList&act=get_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:managerTalkList");