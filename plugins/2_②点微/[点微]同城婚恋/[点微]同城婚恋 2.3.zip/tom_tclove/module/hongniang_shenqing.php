<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

$hongniangShenqingTmp  = C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->fetch_by_user_id($__UserInfo['id']);

if($__ShowTcrenzheng == 1 ){
    $personalRenzhengStatus = 0;
    $renzhengPersonalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($renzhengPersonalInfoTmp) && !empty($renzhengPersonalInfoTmp[0])){
        $personalRenzhengStatus = 1;
    }
}

$showMustPhoneBtn = 0;
if(empty($__UserInfo['tel'])){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$uploadUrl2   = "plugin.php?id=tom_tclove&site={$site_id}&mod=upload&act=hongniang_photo&formhash={$formhash}&suffix=";
$wxUploadUrl3 = "plugin.php?id=tom_tclove:wxMediaDownload&site={$site_id}&act=pic&formhash={$formhash}&suffix=";
$payUrl       = "plugin.php?id=tom_tclove:pay&site={$site_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:hongniang_shenqing");