<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$act  = isset($_GET['act'])? addslashes($_GET['act']):'list';

if($act == 'create' && $_GET['formhash'] == FORMHASH){
    
    $to_user_id      = isset($_GET['to_user_id'])? intval($_GET['to_user_id']):0;
    
    $max_use_id = $min_use_id = 0;
    if($to_user_id == $__UserInfo['id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=message");exit;
    }else if($to_user_id > $__UserInfo['id']){
        $max_use_id = $to_user_id;
        $min_use_id = $__UserInfo['id'];
    }else if($to_user_id < $__UserInfo['id']){
        $max_use_id = $__UserInfo['id'];
        $min_use_id = $to_user_id;
    }
    $pmListTmp = C::t('#tom_tclove#tom_tclove_pm_lists')->fetch_all_list(" AND min_use_id={$min_use_id} AND max_use_id={$max_use_id} "," ORDER BY id DESC ",0,1);
    
    if(is_array($pmListTmp) && !empty($pmListTmp[0]['id']) ){
        $pm_lists_id = $pmListTmp[0]['id'];
    }else{
        $insertData = array();
        $insertData['user_id']      = $__UserInfo['id'];
        $insertData['min_use_id']   = $min_use_id;
        $insertData['max_use_id']   = $max_use_id;
        $insertData['last_content'] = 'NULL-NULL-NULL-NULL-NULL-NULL';
        $insertData['last_time']    = TIMESTAMP;
        $insertData['last_time']    = TIMESTAMP;
        C::t('#tom_tclove#tom_tclove_pm_lists')->insert($insertData);
        $pm_lists_id = C::t('#tom_tclove#tom_tclove_pm_lists')->insert_id();
        
        $insertData = array();
        $insertData['user_id']      = $__UserInfo['id'];
        $insertData['pm_lists_id']  = $pm_lists_id;
        $insertData['new_num']      = 0;
        $insertData['last_time']    = TIMESTAMP;
        C::t('#tom_tclove#tom_tclove_pm')->insert($insertData);
        
        $insertData = array();
        $insertData['user_id']      = $to_user_id;
        $insertData['pm_lists_id']  = $pm_lists_id;
        $insertData['new_num']      = 0;
        $insertData['last_time']     = TIMESTAMP;
        C::t('#tom_tclove#tom_tclove_pm')->insert($insertData);
        
    }
    
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=message&act=sms&pm_lists_id=".$pm_lists_id);exit;
    
}else if($act == 'send' && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    if($tcloveConfig['open_sms_vip'] == 1 && $__TcloveInfo['vip_id'] <= 0){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tcloveConfig['open_girl_sms_free'] == 1 && $__TcloveInfo['sex'] == 2){
    }else{
        if($__TcloveInfo['sms_times'] <= 0){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $content = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content = dhtmlspecialchars($content);
    $content = strip_tags($content);
    $pm_lists_id = isset($_GET['pm_lists_id'])? intval($_GET['pm_lists_id']):0;
    $to_user_id = isset($_GET['to_user_id'])? intval($_GET['to_user_id']):0;
    
    $__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
    if(!empty($__CommonInfo['forbid_word'])){
        $forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
        $forbid_word = str_replace(array("\\*"), array('.*'), $forbid_word);
        $forbid_word = '.*('.$forbid_word.').*';
        $forbid_word = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word).')$/i';
        $contentTmpTmp = $content;
        $contentTmpTmp = str_replace("\r\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\r","",$contentTmpTmp);
        if(@preg_match($forbid_word, $contentTmpTmp,$matches)) {
            $i = count($matches)-1;
            $word = '';
            if(isset($matches[$i]) && !empty($matches[$i])){
                $word = diconv($matches[$i],CHARSET,'utf-8');
            }
            $outArr = array(
                'status'=> 505,
                'word'=> $word,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($__ShowXiaofenlei == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php';
        if($xiaofenleiConfig['open_msgseccheck'] == 1){
            @$s_m_r = wx_msgSecCheck($content);
            if($s_m_r['code'] == 100 || $s_m_r['code'] == 500){
                $outArr = array(
                    'status'=> 505,
                    'word'=> $s_m_r['word'],
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    
    $insertData = array();
    $insertData['user_id']      = $__UserInfo['id'];
    $insertData['pm_lists_id']  = $pm_lists_id;
    $insertData['content']      = $content;
    $insertData['add_time']     = TIMESTAMP;
    if(C::t('#tom_tclove#tom_tclove_pm_message')->insert($insertData)){
        
        $updateData = array();
        $updateData['last_content'] = $content;
        $updateData['last_time'] = TIMESTAMP;
        C::t('#tom_tclove#tom_tclove_pm_lists')->update($pm_lists_id,$updateData);
        
        DB::query("UPDATE ".DB::table('tom_tclove_pm')." SET new_num=new_num+1,last_time='".TIMESTAMP."' WHERE user_id='$to_user_id' AND pm_lists_id='$pm_lists_id' ", 'UNBUFFERED');
        
        if($tcloveConfig['open_girl_sms_free'] == 1 && $__TcloveInfo['sex'] == 2){}else{
            DB::query("UPDATE ".DB::table('tom_tclove')." SET sms_times=sms_times-1 WHERE user_id={$__UserInfo['id']}", 'UNBUFFERED');
        
            $insertData = array();
            $insertData['user_id']       = $__UserInfo['id'];
            $insertData['change_times']  = 1;
            $insertData['old_times']     = $__TcloveInfo['sms_times'];
            $insertData['op_type']       = 2;
            $insertData['op_user_id']    = $__UserInfo['id'];
            $insertData['op_time']       = TIMESTAMP;
            C::t('#tom_tclove#tom_tclove_pm_log')->insert($insertData);
        }
        
        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($to_user_id);
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        $nextSmsTime = $toUser['last_smstp_time'] + 60;
        
        if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=message");
            $message_template_first = str_replace("{NICKNAME}",$__TcloveInfo['xm'], lang('plugin/tom_tclove','message_template_first'));
            $smsData = array(
                'first'         => $message_template_first,
                'keyword1'      => $tcloveConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => $content
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            
            if($r){
                $updateData = array();
                $updateData['last_smstp_time'] = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
            }

        }

        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 100,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == 'sms'){
    
    $pm_lists_id    = intval($_GET['pm_lists_id'])>0? intval($_GET['pm_lists_id']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $pmListsInfo = C::t('#tom_tclove#tom_tclove_pm_lists')->fetch_by_id($pm_lists_id);
    
    if($pmListsInfo['max_use_id'] == $__UserInfo['id'] || $pmListsInfo['min_use_id'] == $__UserInfo['id']){}else{
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");exit;
    }
    
    if($pmListsInfo['min_use_id'] == $__UserInfo['id']){
        $toUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($pmListsInfo['max_use_id']);
    }else{
        $toUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($pmListsInfo['min_use_id']);
    }
    
    $toTcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($toUserInfo['id']);
    
    $pagesize = 10;
    $start = ($page-1)*$pagesize;
    
    $messageListTmp = C::t('#tom_tclove#tom_tclove_pm_message')->fetch_all_list(" AND pm_lists_id={$pm_lists_id} "," ORDER BY add_time DESC,id DESC ",$start,$pagesize);
    $count = C::t('#tom_tclove#tom_tclove_pm_message')->fetch_all_count(" AND pm_lists_id={$pm_lists_id} ");
    $messageList = array();
    if(is_array($messageListTmp) && !empty($messageListTmp)){
        asort($messageListTmp);
        foreach ($messageListTmp as $key => $value){
            $messageList[$key] = $value;
            if($tcloveConfig['open_sms_number_hidden'] == 1){
                $messageList[$key]['content'] = tom_num_replace(strip_tags($value['content'],'<a><br/>'));
            }else{
                $messageList[$key]['content'] = strip_tags($value['content'],'<a><br/>');
            }
            
            $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
            $tcloveInfoTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($value['user_id']);
            $messageList[$key]['userInfo'] = $userInfoTmp;
            $messageList[$key]['avatar'] = tom_tclove_avatar($tcloveInfoTmp['id']);
        }
    }
    
    DB::query("UPDATE ".DB::table('tom_tclove_pm')." SET new_num=0 WHERE user_id='{$__UserInfo['id']}' AND pm_lists_id='$pm_lists_id' ", 'UNBUFFERED');
    
    $showNextPage = 1;
    if(($start + $pagesize) >= $count){
        $showNextPage = 0;
    }
    $allPageNum = ceil($count/$pagesize);
    $prePage = $page - 1;
    $nextPage = $page + 1;
    $prePageUrl = "plugin.php?id=tom_tclove&site={$site_id}&mod=message&act=sms&pm_lists_id={$pm_lists_id}&page={$prePage}";
    $nextPageUrl = "plugin.php?id=tom_tclove&site={$site_id}&mod=message&act=sms&pm_lists_id={$pm_lists_id}&page={$nextPage}";
   
    $smsUrl = "plugin.php?id=tom_tclove&site={$site_id}&mod=message";
    
}else{

    $ajaxLoadPmListUrl = 'plugin.php?id=tom_tclove:ajax&site='.$site_id.'&act=loadPmlist&formhash='.$formhash;
    
    $subscribeFlag = 0;
    $access_token = $weixinClass->get_access_token();
    if(!empty($__UserInfo['openid']) && !empty($access_token)){
        $get_user_info_url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token={$access_token}&openid={$__UserInfo['openid']}&lang=zh_CN";
        $return = get_html($get_user_info_url);
        if(!empty($return)){
            $content = json_decode($return,true);
            if(is_array($content) && !empty($content) && isset($content['subscribe'])){
                if($content['subscribe'] == 1){
                    $subscribeFlag = 1;
                }else{
                    $subscribeFlag = 2;
                }
            }
        }
    }
    
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:message");