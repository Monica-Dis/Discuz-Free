<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$hongniangInfo  = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_user_id($__UserInfo['id']);

# check start
if($hongniangInfo['id'] > 0 ){
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");exit;
}
# check end

if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $xm              = isset($_GET['xm'])? daddslashes(diconv(urldecode($_GET['xm']),'utf-8')):'';
    $user_no         = isset($_GET['user_no'])? intval($_GET['user_no']):'';
    $site_id         = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $sex             = isset($_GET['sex'])? intval($_GET['sex']):0;
    $vip_id          = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $shenhe_status   = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $top_status      = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $order_type      = isset($_GET['order_type'])? intval($_GET['order_type']):0;
    
    $url = $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=managerHongniangList&site_id={$site_id}&vip_id={$vip_id}&user_no={$user_no}&sex={$sex}&shenhe_status={$shenhe_status}&top_status={$top_status}&order_type={$order_type}&xm=".urlencode(trim($xm));
    
    echo $url;exit;
    
}

$vipList = C::t('#tom_tclove#tom_tclove_vip')->fetch_all_list("");
$sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,2000);

$xm              = !empty($_GET['xm'])? addslashes($_GET['xm']):'';
$user_no         = isset($_GET['user_no'])? intval($_GET['user_no']):'';
$site_id         = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$sex             = isset($_GET['sex'])? intval($_GET['sex']):0;
$vip_id          = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
$shenhe_status   = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$top_status      = isset($_GET['top_status'])? intval($_GET['top_status']):0;
$order_type      = isset($_GET['order_type'])? intval($_GET['order_type']):0;
$hongniang_type  = isset($_GET['hongniang_type'])? intval($_GET['hongniang_type']):0;
$page            = intval($_GET['page'])>0? intval($_GET['page']):1;

$where = " AND is_ok=1 ";

if($site_id > 0){
    $where.= " AND site_id={$site_id} ";
}
if(!empty($user_no)){
    $where.= " AND user_no={$user_no} ";
}
if(!empty($sex)){
    if($sex == 1){
        $where.= " AND sex=1 ";
    }
    if($sex == 2){
        $where.= " AND sex=2 ";
    }
}
if(!empty($vip_id)){
    $where.= " AND vip_id= {$vip_id}";
}
if(!empty($shenhe_status)){
    $where.= " AND shenhe_status = {$shenhe_status}";
}
if(!empty($top_status)){
    if($top_status == 1){
        $where.= " AND top_status=0 ";
    }
    if($top_status == 2){
        $where.= " AND top_status=1 ";
    }
}
if($hongniang_type > 0){
    $where.= " AND hongniang_id= {$hongniangInfo['id']}";
}
if($order_type > 0){
    $order = " ORDER BY last_login_time DESC ,id DESC";
}else{
    $order = " ORDER BY id DESC";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count = C::t('#tom_tclove#tom_tclove')->fetch_all_count(" {$where} ",$xm);
$userListTmp = C::t('#tom_tclove#tom_tclove')->fetch_all_list(" {$where} ",$order,$start,$pagesize,$xm);
$userList = array();
foreach ($userListTmp as $key => $value) {
    $userList[$key] = $value;
    $vipInfo = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($value['vip_id']);
    $hongniangInfoTmp = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_id($value['hongniang_id']);
    if(!preg_match('/^http/', $vipInfo['vip_picurl']) ){
        if(strpos($vipInfo['vip_picurl'], 'source/plugin/tom_') === FALSE){
            $vip_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vipInfo['vip_picurl'];
        }else{
            $vip_picurl = $_G['siteurl'].$vipInfo['vip_picurl'];
        }
    }else{
        $vip_picurl = $vipInfo['vip_picurl'];
    }
    if(!preg_match('/^http/', $hongniangInfoTmp['picurl']) ){
        if(strpos($hongniangInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
            $hongniang_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$hongniangInfoTmp['picurl'];
        }else{
            $hongniang_picurl = $_G['siteurl'].$hongniangInfoTmp['picurl'];
        }
    }else{
        $hongniang_picurl = $hongniangInfoTmp['picurl'];
    }
    $userList[$key]['vip_picurl']    = $vip_picurl;
    $userList[$key]['vipInfo']       = $vipInfo;
    $userList[$key]['hongniang_picurl'] = $hongniang_picurl;
    $userList[$key]['hongniangInfo'] = $hongniangInfoTmp;
    $userList[$key]['pic_url']       = tom_tclove_avatar($value['id']);
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage  = $page - 1;
$nextPage = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerHongniangList&page={$prePage}&site_id={$site_id}&vip_id={$vip_id}&user_no={$user_no}&sex={$sex}&shenhe_status={$shenhe_status}&top_status={$top_status}&order_type={$order_type}&hongniang_type={$hongniang_type}&xm=".urlencode(trim($xm));
$nextPageUrl = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerHongniangList&page={$nextPage}&site_id={$site_id}&vip_id={$vip_id}&user_no={$user_no}&sex={$sex}&shenhe_status={$shenhe_status}&top_status={$top_status}&order_type={$order_type}&hongniang_type={$hongniang_type}&xm=".urlencode(trim($xm));

$ajaxDelUrl    = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerHongniangList&act=del&formhash=".$formhash;
$searchUrl     = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerHongniangList&act=get_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:managerHongniangList");