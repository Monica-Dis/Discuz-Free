<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

$vip_time = dgmdate($__TcloveInfo['vip_time'], 'Y-m-d',$tomSysOffset);

$pic_num = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_count(" AND tclove_id = {$__TcloveInfo['id']} AND type = 1");
if($pic_num > 0){
    $pic_url = tom_tclove_avatar($__TcloveInfo['id']);
}else{
    $pic_url = $__UserInfo['picurl'];
}

if($__ShowTcrenzheng == 1 && $tcloveConfig['open_sfz_renzheng'] == 1){
    $personalRenzhengStatus = 0;
    $renzhengPersonalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($renzhengPersonalInfoTmp) && !empty($renzhengPersonalInfoTmp[0])){
        $personalRenzhengStatus = 1;
    }
}

$vipInfo = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($__TcloveInfo['vip_id']);
if(!preg_match('/^http/', $vipInfo['vip_picurl']) ){
    if(strpos($vipInfo['vip_picurl'], 'source/plugin/tom_') === FALSE){
        $vip_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vipInfo['vip_picurl'];
    }else{
        $vip_picurl = $vipInfo['vip_picurl'];
    }
}else{
    $vip_picurl = $vipInfo['vip_picurl'];
}

$chakanwoCount  = C::t('#tom_tclove#tom_tclove_look')->fetch_all_count("AND tclove_id = {$__TcloveInfo['id']} AND user_id != {$__UserInfo['id']}");
$wochakanCount  = C::t('#tom_tclove#tom_tclove_look')->fetch_all_count("AND user_id = {$__UserInfo['id']} AND tclove_id !={$__TcloveInfo['id']}");
$smsnewCount = C::t('#tom_tclove#tom_tclove_pm')->fetch_all_newnum(" AND user_id='{$__UserInfo['id']}' ");
$smsnewCount = intval($smsnewCount);
$xihuanwoCount  = C::t('#tom_tclove#tom_tclove_xihuan')->fetch_all_count("AND tclove_id = {$__TcloveInfo['id']} AND user_id != {$__UserInfo['id']}");
$woxihuanCount  = C::t('#tom_tclove#tom_tclove_xihuan')->fetch_all_count("AND user_id = {$__UserInfo['id']} AND tclove_id !={$__TcloveInfo['id']}");

$isHongniangCount = C::t("#tom_tclove#tom_tclove_hongniang")->fetch_all_count("AND user_id = {$__UserInfo['id']}");

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:my");