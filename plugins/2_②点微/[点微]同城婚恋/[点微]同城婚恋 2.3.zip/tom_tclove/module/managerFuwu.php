<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

$tclove_id     = isset($_GET['tclove_id'])? intval($_GET['tclove_id']):0;

$tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
$hongniangInfo  = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_user_id($__UserInfo['id']);

if($hongniangInfo['id'] > 0 ){
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && submitcheck('tclove_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $fuwu_id      = isset($_GET['fuwu_id'])? intval($_GET['fuwu_id']):0;
    $beizu        = isset($_GET['beizu'])? addslashes($_GET['beizu']):'';
    
    $ufuwuInfo = C::t('#tom_tclove#tom_tclove_ufuwu')->fetch_all_list("AND fuwu_id = {$fuwu_id} AND tclove_id ={$tclove_id}", 'ORDER BY id DESC',0,1);
  
    if($ufuwuInfo[0]['fuwu_times'] < 1){
        echo 301; exit;
    }

    $updateData = array();
    $updateData['fuwu_times']   = $ufuwuInfo[0]['fuwu_times'] - 1;
    C::t('#tom_tclove#tom_tclove_ufuwu')->update($ufuwuInfo[0]['id'], $updateData);
    
    $insertData = array();
    $insertData['tclove_id']        = $tclove_id;
    $insertData['fuwu_id']          = $fuwu_id;
    $insertData['change_times']     = 1;
    $insertData['old_times']        = $ufuwuInfo[0]['fuwu_times'];
    $insertData['op_type']          = 2;
    $insertData['op_user_id']       = $__UserInfo['id'];
    $insertData['beizu']            = $beizu;
    $insertData['op_time']          = TIMESTAMP;
    C::t('#tom_tclove#tom_tclove_ufuwu_log')->insert($insertData);
    
    $fuwuInfo = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_by_id($fuwu_id);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);
    
    $fuwuText = str_replace("{FUWUNAME}",$fuwuInfo['name'], lang('plugin/tom_tclove', 'template_tclove_fuwu_msg'));
    $fuwuText = str_replace("{HONGNIANGNAME}",$hongniangInfo['name'], $fuwuText);

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=myfuwu");
        $smsData = array(
            'first'         => $fuwuText,
            'keyword1'      => $tcloveConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
    }
    
    echo 200; exit;
    
}

$ufuwuList = C::t('#tom_tclove#tom_tclove_ufuwu')->fetch_all_list("AND tclove_id = {$tclove_id}", 'ORDER BY id DESC',0,100);
if(is_array($ufuwuList) && !empty($ufuwuList)){
    foreach ($ufuwuList as $key => $value){
        $ufuwuList[$key] = $value;
        $fuwuInfo = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_by_id("{$value['fuwu_id']}");
        $ufuwuList[$key]['fuwuInfo'] = $fuwuInfo;
        
    }
}

$saveUrl    = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerFuwu&act=save";
$ajaxfuwuloglistUrl  = "plugin.php?id=tom_tclove:ajax&site={$site_id}&tclove_id={$tclove_id}&act=fuwuloglist";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:managerFuwu");