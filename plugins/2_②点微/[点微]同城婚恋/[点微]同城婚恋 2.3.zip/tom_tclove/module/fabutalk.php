<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['act'] == 'save' && submitcheck('content')){

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $content            = isset($_GET['content'])? daddslashes($_GET['content']):'';
    $video_url          = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_url          = dhtmlspecialchars($video_url);
    $video_pic          = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic          = dhtmlspecialchars($video_pic);
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $must_vip           = isset($_GET['must_vip'])? intval($_GET['must_vip']):0;
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $insertData = array();
    $insertData['site_id']           = $site_id;
    $insertData['tclove_id']         = $__TcloveInfo['id'];
    $insertData['content']           = $content;
    $insertData['address']           = $address;
    $insertData['latitude']          = $latitude;
    $insertData['longitude']         = $longitude;
    $insertData['must_vip']          = $must_vip;
    $insertData['talk_time']         = TIMESTAMP;
    if($tcloveConfig['open_talk_shenhe'] == 1){
        $insertData['shenhe_status']     = 2;
    }else{
        $insertData['shenhe_status']     = 1;
    }
    
    if(C::t('#tom_tclove#tom_tclove_talk')->insert($insertData)){
        $talkId = C::t('#tom_tclove#tom_tclove_talk')->insert_id();
        foreach ($photoArr as $key => $value){
            $insertData = array();
            $insertData['type']      = 2;
            $insertData['talk_id']   = $talkId;
            $insertData['tclove_id'] = $__TcloveInfo['id'];
            $insertData['pic_url'] = $value;
            C::t('#tom_tclove#tom_tclove_photo')->insert($insertData);
        }
        if(!empty($video_url) || !empty($video_pic)){
            $insertData = array();
            $insertData['type']         = 3;
            $insertData['talk_id']      = $talkId;
            $insertData['tclove_id']    = $__TcloveInfo['id'];
            $insertData['video_url']    = $video_url;
            $insertData['pic_url']       = $video_pic;
            C::t('#tom_tclove#tom_tclove_photo')->insert($insertData);
        }
    }
    
    
    if($tcloveConfig['open_talk_shenhe'] == 1){
        
        if(!empty($tongchengConfig['template_id'])){
            
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                        
            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=managerTalkList&type=2");
                $template_first = str_replace('{NICKNAME}', $__TcloveInfo['xm'], lang("plugin/tom_tclove", "template_talk_shenhe_msg"));
                $smsData = array(
                    'first'         => $template_first,
                    'keyword1'      => $tcloveConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $tclovemanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcloveConfig['tclovemanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($tclovemanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=managerTalkList&type=2");
                $template_first = str_replace('{NICKNAME}', $__TcloveInfo['xm'], lang("plugin/tom_tclove", "template_talk_shenhe_msg"));
                $smsData = array(
                    'first'         => $template_first,
                    'keyword1'      => $tcloveConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($tclovemanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
    }
    
    $outArr = array(
        'status'        => 200,
    );
    echo json_encode($outArr); exit;
}     

$saveUrl      = "plugin.php?id=tom_tclove&site={$site_id}&mod=fabutalk&act=save&formhash=".FORMHASH;
$uploadUrl1   = "plugin.php?id=tom_tclove&site={$site_id}&mod=upload&act=talk_photo&formhash=".FORMHASH;
$wxUploadUrl1 = "plugin.php?id=tom_tclove:wxMediaDownload&site={$site_id}&act=pic&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:fabutalk");