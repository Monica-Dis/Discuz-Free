<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

$act           = !empty($_GET['act'])? addslashes($_GET['act']):'';


$hongniangInfo  = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_user_id($__UserInfo['id']);

if($hongniangInfo['id'] > 0 ){
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");exit;
}

if($act == "save" && submitcheck('tel')){

    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name                   = dhtmlspecialchars($name);
    $tel                    = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                    = dhtmlspecialchars($tel);
    $wx                     = isset($_GET['wx'])? addslashes($_GET['wx']):'';
    $wx                     = dhtmlspecialchars($wx);
    $desc                   = isset($_GET['desc'])? addslashes($_GET['desc']):'';
    $desc                   = dhtmlspecialchars($desc);
    $picurl                 = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $picurl                 = dhtmlspecialchars($picurl);
    $qrcode                 = isset($_GET['qrcode'])? addslashes($_GET['qrcode']):'';
    $qrcode                 = dhtmlspecialchars($qrcode);

    $updateData = array();
    $updateData['name']                 = $name;  
    $updateData['tel']                  = $tel;
    $updateData['wx']                   = $wx;
    $updateData['desc']                 = $desc;
    $updateData['picurl']               = $picurl;
    $updateData['qrcode']               = $qrcode;
    C::t("#tom_tclove#tom_tclove_hongniang")->update($hongniangInfo['id'], $updateData);
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}

if(!preg_match('/^http/', $hongniangInfo['picurl']) ){
    if(strpos($hongniangInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$hongniangInfo['picurl'];
    }else{
        $picurl = $_G['siteurl'].$hongniangInfo['picurl'];
    }
}else{
    $picurl = $hongniangInfo['picurl'];
}

if(!preg_match('/^http/', $hongniangInfo['qrcode']) ){
    if(strpos($hongniangInfo['qrcode'], 'source/plugin/tom_') === FALSE){
        $qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$hongniangInfo['qrcode'];
    }else{
        $qrcode = $_G['siteurl'].$hongniangInfo['qrcode'];
    }
}else{
    $qrcode = $hongniangInfo['qrcode'];
}

$wxUploadUrl3 = "plugin.php?id=tom_tclove:wxMediaDownload&site={$site_id}&act=pic&formhash={$formhash}&suffix=";
$uploadUrl2   = "plugin.php?id=tom_tclove&site={$site_id}&mod=upload&act=hongniang_photo&formhash={$formhash}&suffix=";
$saveUrl      = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerHongniang_edit";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:managerHongniang_edit");