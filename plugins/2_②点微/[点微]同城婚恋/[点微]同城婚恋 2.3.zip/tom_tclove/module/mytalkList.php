<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$keyword  = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page     = intval($_GET['page'])>0? intval($_GET['page']):1;
$type     = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = " AND tclove_id= {$__TcloveInfo['id']} ";

if($type == 1){
    $where.= " AND shenhe_status=1 ";
}
if($type == 2){
    $where.= " AND shenhe_status=2 ";
}
if($type == 3){
    $where.= " AND shenhe_status=3 ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;
$order = " ORDER BY id DESC ";

$count = C::t('#tom_tclove#tom_tclove_talk')->fetch_all_count($where,$keyword);
$talkListTmp = C::t('#tom_tclove#tom_tclove_talk')->fetch_all_list($where,$order,$start,$pagesize,$keyword);
$talkList = array();
foreach ($talkListTmp as $key => $value) {
    
    $userTmp = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
    
    $talkList[$key] = $value;
    $talkList[$key]['user'] = $userTmp;

    $talkList[$key]['user']['pic_url'] = tom_tclove_avatar($userTmp['id']);
    $talkphotoListTmp = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list("AND type = 2 AND talk_id = {$value['id']}", "ORDER BY id ASC",0,100);
    $talkphotoList = array();
    $talkphotoListStr = '';
    if(is_array($talkphotoListTmp) && !empty($talkphotoListTmp)){
        foreach($talkphotoListTmp as $kk => $vv){
            $picurlTmp = $vv['picurlTmp'];
            $talkphotoList[] = $picurlTmp;
        }
        $talkphotoListStr = implode('|', $talkphotoList);
    }

    $talkvideoInfoTmp =  C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list("AND type = 3 AND talk_id = {$value['id']}","ORDER BY id DESC",0,1);
    $talkvideoInfo = array();
    if(is_array($talkvideoInfoTmp) && !empty($talkvideoInfoTmp[0])){
        $talkvideoInfo = $talkvideoInfoTmp[0];
        $talkvideoInfo['pic_url'] = $talkvideoInfo['picurlTmp'];
    }

    $talkList[$key]['content']          = tom_num_replace(dhtmlspecialchars($value['content']));
    $talkList[$key]['talkphotoList']    = $talkphotoList;
    $talkList[$key]['talkphotoListStr'] = $talkphotoListStr;
    $talkList[$key]['talkvideoInfo']    = $talkvideoInfo;
    $talkList[$key]['talk_time']        = dgmdate($value['talk_time'],"m-d H:i",$tomSysOffset);
    $talkList[$key]['link']             = 'plugin.php?id=tom_tclove&site='.$value['site_id'].'&mod=talkinfo&talk_id='.$value['id'];
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tclove&site={$site_id}&mod=mytalkList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tclove&site={$site_id}&mod=mytalkList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];

$deltalkUrl        = "plugin.php?id=tom_tclove:ajax&site={$site_id}&act=del_talk&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:mytalkList");