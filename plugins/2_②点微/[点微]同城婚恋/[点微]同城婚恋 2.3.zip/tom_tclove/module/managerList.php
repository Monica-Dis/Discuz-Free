<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    if($__UserInfo['id'] != $tcloveConfig['tclovemanage_user_id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");exit;
    }
}
# check end

if($_GET['act'] == 'shenhe_ok' && submitcheck('tclove_id')){
    
    $tclove_id = intval($_GET['tclove_id'])>0? intval($_GET['tclove_id']):0;
    
    $updateData = array();
    $updateData['shenhe_status']     = 1;
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);
    
    $shenhe = str_replace('{CONTENT}', $tcloveInfo['xm'], lang("plugin/tom_tclove", "template_tclove_shenhe_ok"));

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=info&tclove_id=".$tcloveInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcloveConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
    }
    
    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    echo 200;exit;
    
}else if($_GET['act'] == 'shenhe_no' && submitcheck('tclove_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $tclove_id      = intval($_GET['tclove_id'])>0? intval($_GET['tclove_id']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);

    $updateData = array();
    $updateData['shenhe_status']     = 3;
    C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);

    $shenhe = str_replace('{CONTENT}', $tcloveInfo['xm'], lang("plugin/tom_tclove", "template_tclove_shenhe_no"));
    $content = str_replace("\r\n","",$content);
    $content = str_replace("\n","",$content);
    $content = str_replace("\r","",$content);

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=edit");
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcloveConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.lang("plugin/tom_tclove", "tclove_shenhe_fail_title").$content.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    echo 200;exit;
    
}else if($_GET['act'] == 'updateStatus' && submitcheck('tclove_id')){
    
    $tclove_id   = intval($_GET['tclove_id'])>0? intval($_GET['tclove_id']):0;
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
    
    if($_GET['status'] == 1){
        $updateData = array();
        $updateData['status'] = 1;
        C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
    }else if($_GET['status'] == 2){
        $updateData = array();
        $updateData['status'] = 2;
        C::t('#tom_tclove#tom_tclove')->update($tclove_id,$updateData);
    }
    
    echo 200;exit;
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=managerList&keyword=".urlencode(trim($keyword));
    
    echo $url;exit;
    
}else if($_GET['act'] == 'del' && submitcheck('tclove_id')){
    
    $tclove_id = intval($_GET['tclove_id'])>0? intval($_GET['tclove_id']):0;
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
    
    C::t('#tom_tclove#tom_tclove')->delete_by_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_chakan')->delete_by_user_id($tcloveInfo['user_id']);
    C::t('#tom_tclove#tom_tclove_collect')->delete_by_user_id($tcloveInfo['user_id']);
    C::t('#tom_tclove#tom_tclove_collect')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_look')->delete_by_user_id($tcloveInfo['user_id']);
    C::t('#tom_tclove#tom_tclove_look')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_xihuan')->delete_by_user_id($tcloveInfo['user_id']);
    C::t('#tom_tclove#tom_tclove_xihuan')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_photo')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_video')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_talk')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_talk_pinglun')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_zan')->delete_by_tclove_id($tclove_id);
    C::t('#tom_tclove#tom_tclove_talk_zan')->delete_by_tclove_id($tclove_id);
    
    echo 200;exit;

}else if($_GET['act'] == 'fenghao' && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $tclove_id  = intval($_GET['tclove_id'])>0? intval($_GET['tclove_id']):0;
    
    DB::query("UPDATE ".DB::table('tom_tclove')." SET status=2 WHERE user_id='{$tclove_id}' ", 'UNBUFFERED');
        
    echo 200;exit;
    
}else if($_GET['act'] == 'shenhe_show'){
    
    $shenhe_type    = intval($_GET['shenhe_type'])>0? intval($_GET['shenhe_type']):0;
    $tclove_id      = intval($_GET['tclove_id'])>0? intval($_GET['tclove_id']):0;
    $frompage       = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
 
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
    
    $tclove_shenhe_fail_str = str_replace("\r\n","{n}",$tcloveConfig['tclove_shenhe_fail_text']); 
    $tclove_shenhe_fail_str = str_replace("\n","{n}",$tclove_shenhe_fail_str);
    $tcloveShenheFailArray = explode("{n}", $tclove_shenhe_fail_str);
    
    $ajaxShenheUrl = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerList&act=shenhe_no";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tclove:managerShenhe");exit;
    
}

$keyword  = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$user_no  = isset($_GET['user_no'])? intval($_GET['user_no']):0;
$page  = intval($_GET['page'])>0? intval($_GET['page']):1;
$type  = intval($_GET['type'])>0? intval($_GET['type']):0;

if(!is_numeric($keyword)) {
    $xm = $keyword;
}else{
    $user_no = $keyword;
}

$where = " AND is_ok=1 ";
if($type == 1){
    $where.= " AND shenhe_status=2 ";
}
if($type == 2){
    $where.= " AND shenhe_status=3 ";
}
if($__UserInfo['groupid'] == 2){
    $where.= " AND site_id={$site_id} ";
}
if(!empty($user_no)){
    $where.=" AND user_no = {$user_no}";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;
$order = " ORDER BY id DESC ";

$count = C::t('#tom_tclove#tom_tclove')->fetch_all_count(" {$where} ",$xm);
$userListTmp = C::t('#tom_tclove#tom_tclove')->fetch_all_list(" {$where} ",$order,$start,$pagesize,$xm);
$userList = array();
foreach ($userListTmp as $key => $value) {
    $userList[$key] = $value;
    $hongniangInfo = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_id($value['hongniang_id']);
    $vipInfo = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($value['vip_id']);
    if(!preg_match('/^http/', $vipInfo['vip_picurl']) ){
        if(strpos($vipInfo['vip_picurl'], 'source/plugin/tom_') === FALSE){
            $vip_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vipInfo['vip_picurl'];
        }else{
            $vip_picurl = $_G['siteurl'].$vipInfo['vip_picurl'];
        }
    }else{
        $vip_picurl = $vipInfo['vip_picurl'];
    }
    if(!preg_match('/^http/', $hongniangInfo['picurl']) ){
        if(strpos($hongniangInfo['picurl'], 'source/plugin/tom_') === FALSE){
            $hongniang_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$hongniangInfo['picurl'];
        }else{
            $hongniang_picurl = $_G['siteurl'].$hongniangInfo['picurl'];
        }
    }else{
        $hongniang_picurl = $hongniangInfo['picurl'];
    }
    $userList[$key]['vip_picurl']       = $vip_picurl;
    $userList[$key]['vipInfo']          = $vipInfo;
    $userList[$key]['hongniang_picurl'] = $hongniang_picurl;
    $userList[$key]['hongniangInfo']    = $hongniangInfo;
    $userList[$key]['picurl']          = tom_tclove_avatar($value['id']);

}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];

$ajaxShenheOkUrl       = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerList&act=shenhe_ok&formhash=".$formhash;
$ajaxUpdateStatusUrl   = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerList&act=updateStatus&formhash=".$formhash;
$ajaxDelUrl            = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerList&act=del&formhash=".$formhash;
$searchUrl             = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerList&act=get_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:managerList");