<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$hongniangInfo  = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_user_id($__UserInfo['id']);

if($hongniangInfo['id'] > 0 ){
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");exit;
}

$hongniang_renlingCount = C::t("#tom_tclove#tom_tclove_hongniang_renling_log")->fetch_all_count("AND hongniang_id = {$hongniangInfo['id']} AND renling_time_key ={$nowDayTime}");

$sy_renling_num = $tcloveConfig['hongniang_renling_xz_num'] - $hongniang_renlingCount;

if($_GET['act'] == 'renling' && submitcheck('tclove_id')){
    
    $tclove_id = intval($_GET['tclove_id'])>0? intval($_GET['tclove_id']):0;
    
    $hongniang_renlingInfo = C::t("#tom_tclove#tom_tclove_hongniang_renling_log")->fetch_all_list("AND hongniang_id = {$hongniangInfo['id']} "," ORDER BY id DESC",0,1);
    
    if($sy_renling_num < 1){
        echo 301;exit;
    }
    
    $nextRenlingTime = $hongniang_renlingInfo[0]['renling_time'] + $tcloveConfig['hongniang_renling_next_minute']*60;
    if($nextRenlingTime > TIMESTAMP){
         echo 302;exit;
    }
    
    DB::query("UPDATE ".DB::table('tom_tclove')." SET hongniang_id={$hongniangInfo['id']} WHERE id='{$tclove_id}' ", 'UNBUFFERED');
    
    $insertData = array();
    $insertData['hongniang_id']      = $hongniangInfo['id'];
    $insertData['tclove_id']         = $tclove_id;
    $insertData['renling_time_key']  = $nowDayTime;
    $insertData['renling_time']      = TIMESTAMP;
    C::t('#tom_tclove#tom_tclove_hongniang_renling_log')->insert($insertData);
    
    $tcloveInfo = C::t("#tom_tclove#tom_tclove")->fetch_by_id($tclove_id);
    
    $toUser = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcloveInfo['user_id']);
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($toUser['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=myhongniang");
        $renlingText = str_replace("{NICKNAME}",$tcloveInfo['xm'], lang('plugin/tom_tclove', 'template_renling_hongniang_msg_1'));
        $renlingText = str_replace("{HONGNIANGNAME}",$hongniangInfo['name'],$renlingText);
        $smsData = array(
            'first'         => $renlingText,
            'keyword1'      => $tcloveConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
    }
    
    $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($manageUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");
        $renlingText = str_replace("{NICKNAME}",$tcloveInfo['xm'], lang('plugin/tom_tclove', 'template_renling_hongniang_msg_2'));
        $renlingText = str_replace("{HONGNIANGNAME}",$hongniangInfo['name'],$renlingText);
        $smsData = array(
            'first'         => $renlingText,
            'keyword1'      => $tcloveConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
    }

    $tclovemanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcloveConfig['tclovemanage_user_id']);
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tclovemanageUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");
        $renlingText = str_replace("{NICKNAME}",$tcloveInfo['xm'], lang('plugin/tom_tclove', 'template_renling_hongniang_msg_2'));
        $renlingText = str_replace("{HONGNIANGNAME}",$hongniangInfo['name'],$renlingText);
        $smsData = array(
            'first'         => $renlingText,
            'keyword1'      => $tcloveConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tclovemanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
    }
    
    echo 200;exit;
    
}

$page            = intval($_GET['page'])>0? intval($_GET['page']):1;

$where = " AND is_ok = 1 AND shenhe_status = 1 AND status = 1 AND hongniang_id = 0 ";

$order = " ORDER BY id DESC";

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count = C::t('#tom_tclove#tom_tclove')->fetch_all_count($where);
$userListTmp = C::t('#tom_tclove#tom_tclove')->fetch_all_list($where,$order,$start,$pagesize);
$userList = array();
foreach ($userListTmp as $key => $value) {
    $userList[$key] = $value;
    $vipInfo = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($value['vip_id']);
    if(!preg_match('/^http/', $vipInfo['vip_picurl']) ){
        if(strpos($vipInfo['vip_picurl'], 'source/plugin/tom_') === FALSE){
            $vip_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vipInfo['vip_picurl'];
        }else{
            $vip_picurl = $_G['siteurl'].$vipInfo['vip_picurl'];
        }
    }else{
        $vip_picurl = $vipInfo['vip_picurl'];
    }
    $userList[$key]['vip_picurl']    = $vip_picurl;
    $userList[$key]['vipInfo']       = $vipInfo;
    $userList[$key]['pic_url']       = tom_tclove_avatar($value['id']);
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage  = $page - 1;
$nextPage = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerHongniangList&page={$prePage}&site_id={$site_id}&vip_id={$vip_id}&user_no={$user_no}&sex={$sex}&shenhe_status={$shenhe_status}&top_status={$top_status}&order_type={$order_type}&hongniang_type={$hongniang_type}&xm=".urlencode(trim($xm));
$nextPageUrl = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerHongniangList&page={$nextPage}&site_id={$site_id}&vip_id={$vip_id}&user_no={$user_no}&sex={$sex}&shenhe_status={$shenhe_status}&top_status={$top_status}&order_type={$order_type}&hongniang_type={$hongniang_type}&xm=".urlencode(trim($xm));

$ajaxRenlingUrl   = "plugin.php?id=tom_tclove&site={$site_id}&mod=managerHongniang_renling&act=renling&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:managerHongniang_renling");