<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

$tuiInfo  = C::t('#tom_tclove#tom_tclove_tui')->fetch_by_user_id($__UserInfo['id']);

$page     = intval($_GET['page'])>0? intval($_GET['page']):1;

$pagesize = 10;
$start = ($page-1)*$pagesize;

$whereStr = " AND tui_id={$tuiInfo['id']} ";

$tuishouyilogCount  = C::t('#tom_tclove#tom_tclove_tui_shouyi_log')->fetch_all_count(" {$whereStr} ");

$tuishouyilogData  = C::t('#tom_tclove#tom_tclove_tui_shouyi_log')->fetch_all_list(" {$whereStr} ","ORDER BY log_time DESC, id DESC",$start,$pagesize);
$tuishouyilogList = array();
if(is_array($tuishouyilogData) && !empty($tuishouyilogData)){
    foreach ($tuishouyilogData as $key => $value){
        $tuishouyilogList[$key] = $value;
        
        $tcloveInfoTmp = C::t("#tom_tclove#tom_tclove")->fetch_by_id("{$value['tclove_id']}");
        $tuishouyilogList[$key]['tcloveInfoTmp'] = $tcloveInfoTmp;
        $tuishouyilogList[$key]['tcloveInfoTmp']['pic_url'] = tom_tclove_avatar($value['tclove_id']);
        $tuishouyilogList[$key]['log_time']   = dgmdate($value['log_time'], 'm-d H:i',$tomSysOffset);
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $tuishouyilogCount){
    $showNextPage = 0;
}
$allPageNum     = ceil($tuishouyilogCount/$pagesize);
$prePage        = $page - 1;
$nextPage       = $page + 1;
$prePageUrl     = "plugin.php?id=tom_tclove&site={$site_id}&mod=tui_shouyi_log&page={$prePage}";
$nextPageUrl    = "plugin.php?id=tom_tclove&site={$site_id}&mod=tui_shouyi_log&page={$nextPage}";

$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index&tui_id={$__TclovetuiInfo['id']}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:tui_shouyi_log");