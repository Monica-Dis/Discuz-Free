<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

/**
   1 ��֧�� 2 ��֧��
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$tcloveConfig       = $_G['cache']['plugin']['tom_tclove'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
$tomSysOffset       = getglobal('setting/timeoffset');
$nowDayTime         = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

include DISCUZ_ROOT.'./source/plugin/tom_tclove/class/tclove.func.php';

$act = isset($_GET['act'])? addslashes($_GET['act']):"vip";

if($act == "top" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );

    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):'';
    $days           = intval($_GET['days'])>0? intval($_GET['days']):0;
   
    $tcloveInfo     = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($user_id);
    $userInfo       = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);
    
    if(empty($tcloveInfo) || empty($userInfo)){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $top_money_listStr = str_replace("\r\n","{n}",$tcloveConfig['top_money_list']); 
    $top_money_listStr = str_replace("\n","{n}",$top_money_listStr);
    $top_money_listTmpArr = explode("{n}", $top_money_listStr);
    
    $top_moneyArr = array();
    if(is_array($top_money_listTmpArr) && !empty($top_money_listTmpArr)){
        foreach ($top_money_listTmpArr as $key => $value){
            if(!empty($value)){
                list($day, $price) = explode("|", $value);
                $day    = intval($day);
                $price  = floatval($price);
                if(!empty($day) && !empty($price)){
                    $top_moneyArr[$day] = $price;
                }
            }
        }
    }

    if(!isset($top_moneyArr[$days])){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    $pay_price  = $top_moneyArr[$days];
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }

    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['order_no']         = $order_no;
    $insertData['order_type']       = 1;
    $insertData['user_id']          = $user_id;
    $insertData['tclove_id']        = $tcloveInfo['id'];
    $insertData['time_value']       = $days;
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tclove#tom_tclove_order')->insert($insertData)){
        $order_id = C::t('#tom_tclove#tom_tclove_order')->insert_id();
        
        $insertData = array();
        $insertData['plugin_id']       = 'tom_tclove';      
        $insertData['order_no']        = $order_no;            
        $insertData['goods_id']        = $tclove_id;
        $insertData['goods_name']      = lang('plugin/tom_tclove','wxpay_top_order');
        $insertData['goods_beizu']     = lang('plugin/tom_tclove','wxpay_top_order');
        $insertData['goods_url']       = "plugin.php?id=tom_tclove&site={$site_id}&mod=top";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tclove&site={$site_id}&mod=top";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tclove&site={$site_id}&mod=top";
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $pay_price;    
        $insertData['order_status']    = 1;             
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'pay_status' => 1,
                'status'    => 200,
                'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "fuwu" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );

    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):'';
    $fuwu_id        = isset($_GET['fuwu_id'])? intval($_GET['fuwu_id']):'';
    $fuwu_times     = intval($_GET['fuwu_times'])>0? intval($_GET['fuwu_times']):0;
    
    $fuwuInfo       = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_by_id($fuwu_id);
    $tcloveInfo     = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($user_id);
    $userInfo       = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);
    
    if(!$tcloveInfo || !$userInfo || !$fuwuInfo){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $fuwu_price_listStr = str_replace("\r\n","{n}",$fuwuInfo['price_list']); 
    $fuwu_price_listStr = str_replace("\n","{n}",$fuwu_price_listStr);
    $fuwu_money_listTmpArr = explode("{n}", $fuwu_price_listStr);
    
    $fuwu_moneyArr = array();
    if(is_array($fuwu_money_listTmpArr) && !empty($fuwu_money_listTmpArr)){
        foreach ($fuwu_money_listTmpArr as $key => $value){
            if(!empty($value)){
                list($times, $price) = explode("|", $value);
                $times = intval($times);
                if(!empty($times) && !empty($price)){
                    $fuwu_moneyArr[$times] = $price;
                }
            }
        }
    }

    if(!isset($fuwu_moneyArr[$fuwu_times])){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    $pay_price  = $fuwu_moneyArr[$fuwu_times];
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }

    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['order_no']         = $order_no;
    $insertData['order_type']       = 3;
    $insertData['user_id']          = $user_id;
    $insertData['tclove_id']        = $tcloveInfo['id'];
    $insertData['fuwu_id']          = $fuwu_id;
    $insertData['fuwu_times']       = $fuwu_times;
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tclove#tom_tclove_order')->insert($insertData)){
        $order_id = C::t('#tom_tclove#tom_tclove_order')->insert_id();
        
        $insertData = array();
        $insertData['plugin_id']       = 'tom_tclove';      
        $insertData['order_no']        = $order_no;            
        $insertData['goods_id']        = $tclove_id;
        $insertData['goods_name']      = lang('plugin/tom_tclove','wxpay_fuwutimes_order');
        $insertData['goods_beizu']     = lang('plugin/tom_tclove','wxpay_fuwutimes_order');
        $insertData['goods_url']       = "plugin.php?id=tom_tclove&site={$site_id}&mod=myfuwu";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tclove&site={$site_id}&mod=myfuwu";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tclove&site={$site_id}&mod=myfuwu";
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $pay_price;    
        $insertData['order_status']    = 1;             
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'pay_status' => 1,
                'status'    => 200,
                'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "vip" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $vip_id         = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):'';
    
    $tcloveInfo     = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($user_id);
    $userInfo       = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);
    $vipinfo        = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($vip_id);
    
    if(!$tcloveInfo || !$userInfo){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    $pay_price  = $vipinfo['price'];
    if($pay_price <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['order_no']         = $order_no;
    $insertData['order_type']       = 2;
    $insertData['user_id']          = $user_id;
    $insertData['tclove_id']        = $tcloveInfo['id'];
    $insertData['vip_id']           = $vip_id;
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tclove#tom_tclove_order')->insert($insertData)){
        
        $insertData = array();
        $insertData['plugin_id']       = 'tom_tclove';      
        $insertData['order_no']        = $order_no;            
        $insertData['goods_id']        = $tclove_id;           
        $insertData['goods_name']      = lang('plugin/tom_tclove','wxpay_vip_order');
        $insertData['goods_beizu']     = lang('plugin/tom_tclove','wxpay_vip_order');
        $insertData['goods_url']       = "plugin.php?id=tom_tclove&site={$site_id}&mod=vip";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tclove&site={$site_id}&mod=vip";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tclove&site={$site_id}&mod=vip";
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $pay_price;    
        $insertData['order_status']    = 1;             
        $insertData['add_time']        = TIMESTAMP;     
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'pay_status' => 1,
                'status'    => 200,
                'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
}else if($act == "hongniang_shenqing" && submitcheck('user_id')){

    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name                   = dhtmlspecialchars($name);
    $tel                    = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                    = dhtmlspecialchars($tel);
    $wx                     = isset($_GET['wx'])? addslashes($_GET['wx']):'';
    $wx                     = dhtmlspecialchars($wx);
    $desc                   = isset($_GET['desc'])? addslashes($_GET['desc']):'';
    $desc                   = dhtmlspecialchars($desc);
    $picurl                 = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $picurl                 = dhtmlspecialchars($picurl);
    $qrcode                 = isset($_GET['qrcode'])? addslashes($_GET['qrcode']):'';
    $qrcode                 = dhtmlspecialchars($qrcode);
    $user_id                = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;

    $tcloveInfo  = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($user_id);
    $userInfo    = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    if(!$tcloveInfo || !$userInfo){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $hongniangInfoTmp  = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_user_id($user_id);
    if($hongniangInfoTmp['id'] > 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $shenqingPayStatus = 0;
    if ($tcloveConfig['open_shenqing_hongniang_money'] == 1 && $tcloveConfig['shenqing_hongniang_price'] > 0){
        $shenqingPayStatus = 1;
        $pay_price = $tcloveConfig['shenqing_hongniang_price'];
    }else{
        $pay_price = 0;
    }
            
    $insertData = array();
    $insertData['site_id']              = $tcloveInfo['site_id'];;
    $insertData['user_id']              = $user_id;
    $insertData['name']                 = $name;
    $insertData['tel']                  = $tel;
    $insertData['wx']                   = $wx;
    $insertData['picurl']               = $picurl;
    $insertData['qrcode']               = $qrcode;
    $insertData['desc']                 = $desc;
    if($shenqingPayStatus == 1){
        $insertData['pay_status']       = 0;
    }else{
        $insertData['pay_status']       = 1;
    }
    $insertData['shenhe_status']        = 2;
    $insertData['add_time']             = TIMESTAMP;
    if(C::t("#tom_tclove#tom_tclove_hongniang_shenqing")->insert($insertData)){
        $hongniang_sq_id = C::t("#tom_tclove#tom_tclove_hongniang_shenqing")->insert_id();
        
        if($shenqingPayStatus == 1){
            
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

            $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

            $insertData = array();
            $insertData['order_no']         = $order_no;
            $insertData['order_type']       = 4;
            $insertData['user_id']          = $user_id;
            $insertData['tclove_id']        = $tcloveInfo['id'];
            $insertData['hongniang_sq_id']  = $hongniang_sq_id;
            $insertData['pay_price']        = $pay_price;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tclove#tom_tclove_order')->insert($insertData)){
                $order_id = C::t('#tom_tclove#tom_tclove_order')->insert_id();

                $insertData = array();
                $insertData['plugin_id']       = 'tom_tclove';          
                $insertData['order_no']        = $order_no;                 
                $insertData['goods_id']        = $order_id;         
                $insertData['goods_name']      = lang('plugin/tom_tclove', 'wxpay_shenqing_hongniang_order');
                $insertData['goods_beizu']     = lang('plugin/tom_tclove','wxpay_shenqing_hongniang_order');
                $insertData['goods_url']       = "plugin.php?id=tom_tclove&site={$site_id}&mod=my";
                $insertData['succ_back_url']   = "plugin.php?id=tom_tclove&site={$site_id}&mod=my";
                $insertData['fail_back_url']   = "plugin.php?id=tom_tclove&site={$site_id}&mod=hongniang_shenqing";
                $insertData['allow_alipay']    = 1;
                $insertData['pay_price']       = $pay_price;
                $insertData['order_status']    = 1;
                $insertData['add_time']        = TIMESTAMP;
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    $outArr = array(
                        'status'        => 200,
                        'pay_status'    => 1,
                        'payurl'        => "plugin.php?id=tom_pay&order_no=".$order_no,
                    );
                    echo json_encode($outArr); exit;
                }else{
                    $outArr = array(
                        'status'=> 304,
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
        }else{
            
            if(!empty($tongchengConfig['template_id'])){
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
                $weixinClass = new weixinClass($appid,$appsecret);

                $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($manageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tclove', 'template_shenqing_hongniang_shenhe_msg'),
                        'keyword1'      => $tcloveConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }

                $tclovemanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcloveConfig['tclovemanage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($tclovemanageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tclove', 'template_shenqing_hongniang_shenhe_msg'),
                        'keyword1'      => $tcloveConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($tclovemanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }
            $outArr = array(
                'status'=> 200,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "buysms" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );

    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):'';
    $sms_times      = intval($_GET['sms_times'])>0? intval($_GET['sms_times']):0;
    
    $tcloveInfo     = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($user_id);
    $userInfo       = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);
    
    if(!$tcloveInfo || !$userInfo ){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $send_sms_listStr = str_replace("\r\n","{n}",$tcloveConfig['send_sms_list']); 
    $send_sms_listStr = str_replace("\n","{n}",$send_sms_listStr);
    $send_sms_listTmpArr = explode("{n}", $send_sms_listStr);
    
    $send_sms_moneyArr = array();
    if(is_array($send_sms_listTmpArr) && !empty($send_sms_listTmpArr)){
        foreach ($send_sms_listTmpArr as $key => $value){
            if(!empty($value)){
                list($times, $price) = explode("|", $value);
                $times = intval($times);
                if(!empty($times) && !empty($price)){
                    $send_sms_moneyArr[$times] = $price;
                }
            }
        }
    }

    if(!isset($send_sms_moneyArr[$sms_times])){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    $pay_price  = $send_sms_moneyArr[$sms_times];
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }

    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['order_no']         = $order_no;
    $insertData['order_type']       = 5;
    $insertData['user_id']          = $user_id;
    $insertData['tclove_id']        = $tcloveInfo['id'];
    $insertData['sms_times']        = $sms_times;
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tclove#tom_tclove_order')->insert($insertData)){
        $order_id = C::t('#tom_tclove#tom_tclove_order')->insert_id();
        
        $insertData = array();
        $insertData['plugin_id']       = 'tom_tclove';      
        $insertData['order_no']        = $order_no;            
        $insertData['goods_id']        = $tcloveInfo['id'];
        $insertData['goods_name']      = lang('plugin/tom_tclove','wxpay_smstimes_order');
        $insertData['goods_beizu']     = lang('plugin/tom_tclove','wxpay_smstimes_order');
        $insertData['goods_url']       = "plugin.php?id=tom_tclove&site={$site_id}&mod=buysms";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tclove&site={$site_id}&mod=buysms";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tclove&site={$site_id}&mod=buysms";
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $pay_price;    
        $insertData['order_status']    = 1;             
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'pay_status' => 1,
                'status'    => 200,
                'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}