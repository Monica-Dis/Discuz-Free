<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
loaducenter();
define('TPL_DEFAULT', true);
$tcloveConfig = $_G['cache']['plugin']['tom_tclove'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$Lang = $scriptlang['tom_tclove'];
$nowYear = dgmdate($_G['timestamp'], 'Y',$tomSysOffset);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$formhash = FORMHASH;
$cssJsVersion = "20200302";

include DISCUZ_ROOT.'./source/plugin/tom_tclove/class/tclove.func.php';
if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/config/works.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/config/works.utf.php';
}
if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    if($_GET['mod'] == 'add'){
        include DISCUZ_ROOT.'./source/plugin/tom_tclove/manage/add.php';
    }else if($_GET['mod'] == 'edit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tclove/manage/edit.php';
    }
}else{
    dheader('location:'.$_G['siteurl']);exit;
}