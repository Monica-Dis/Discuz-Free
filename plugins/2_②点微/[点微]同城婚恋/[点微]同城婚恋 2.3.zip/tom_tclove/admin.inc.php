<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tclove'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowYear = dgmdate($_G['timestamp'], 'Y',$tomSysOffset);
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tclove&pmod=admin'; 
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tclove&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tclove&pmod=admin';
$manageUrl = $_G['siteurl'].'plugin.php?id=tom_tclove:manage';

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){
}else{
    echo '<a href="https://dism.taobao.com/?@tom_tongcheng.plugin">https://dism.taobao.com/?@tom_tongcheng.plugin</a>';exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tclove/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tclove/class/function.a.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tclove/class/tclove.func.php';
include DISCUZ_ROOT.'./source/plugin/tom_tclove/class/tui_phb.func.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';

$tcloveConfig = get_tclove_config($pluginid);
$tongchengPlugin = C::t('#tom_tclove#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
$Lang = formatLang($Lang);

$xiangqinFlag = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiangqin/tom_xiangqin.inc.php')){
    $xiangqinFlag = 1;
}

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/config/works.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/config/works.utf.php';
}

if($_GET['tmod'] == 'index'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/index.php';
    
}else if($_GET['tmod'] == 'viptype'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/viptype.php';

}else if($_GET['tmod'] == 'talk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/talk.php';

}else if($_GET['tmod'] == 'pinglun'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/pinglun.php';
    
}else if($_GET['tmod'] == 'pinglunReply'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/pinglunReply.php';
    
}else if($_GET['tmod'] == 'hongniang'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/hongniang.php';

}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/order.php';

}else if($_GET['tmod'] == 'doDao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/doDao.php';
    
}else if($_GET['tmod'] == 'diynav'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/diynav.php';
    
}else if($_GET['tmod'] == 'common'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/common.php';
    
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/addon.php';
    
}else if($_GET['tmod'] == 'ufuwu'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/ufuwu.php';
    
}else if($_GET['tmod'] == 'fuwu'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/fuwu.php';
    
}else if($_GET['tmod'] == 'tui_shouyi_log'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/tui_shouyi_log.php';
    
}else if($_GET['tmod'] == 'hongniang_shouyi_log'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/hongniang_shouyi_log.php';
    
}else if($_GET['tmod'] == 'tui_phb'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/tui_phb.php';
    
}else if($_GET['tmod'] == 'tuilist'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/tuilist.php';
    
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/focuspic.php';
    
}else if($_GET['tmod'] == 'hongniang_shenqing'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/hongniang_shenqing.php';
    
}else if($_GET['tmod'] == 'report'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/report.php';
    
}else if($_GET['tmod'] == 'pmMessage'){
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/pmMessage.php';
    
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/admin/index.php';
}