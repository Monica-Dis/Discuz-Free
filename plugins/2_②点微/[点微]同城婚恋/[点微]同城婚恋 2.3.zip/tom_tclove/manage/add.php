<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tclove/module/set.php';

if($_GET['act'] == 'save' && submitcheck('user_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):1;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($userInfo['id']);
    if($tcloveInfo['id'] > 0){
    }else{
        $insertData = array();
        $insertData['site_id']      = 1;
        $insertData['user_id']      = $user_id;
        $insertData['xm']           = $userInfo['nickname'];
        if($tcloveConfig['close_tel'] == 1){
            $insertData['close_tel']   = 1;
        }
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tclove#tom_tclove')->insert($insertData);
        $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($userInfo['id']);
    }

    $outArr = array(
        'tclove_id'=> $tcloveInfo['id'],
    );
    echo json_encode($outArr); exit;
}

$userList = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_like_list(' AND is_majia = 1 ',"ORDER BY id DESC",0,1000,'');


$saveUrl        = "plugin.php?id=tom_tclove:manage&site={$site_id}&mod=add&act=save&formhash=".FORMHASH;
$nextUrl        = "plugin.php?id=tom_tclove:manage&site={$site_id}&mod=edit&tclove_id=";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tclove:admin/adduser");