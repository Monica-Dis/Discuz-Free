<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=viptype';
$modListUrl = $adminListUrl.'&tmod=viptype';
$modFromUrl = $adminFromUrl.'&tmod=viptype';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tclove#tom_tclove_vip')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    
    $vipInfo = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($vipInfo);
        C::t('#tom_tclove#tom_tclove_vip')->update($vipInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($vipInfo);
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tclove#tom_tclove_vip')->delete_by_id($_GET['id']);
    C::t('#tom_tclove#tom_tclove_vip_fuwu')->delete_by_vip_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del_vipfuwu'){
    
    C::t('#tom_tclove#tom_tclove_vip_fuwu')->delete_by_id($_GET['vip_fuwu_id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'import'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tclove/config/import.data.php';
    
    foreach ($vipArr as $key => $value){
        $insertData = array();
        $insertData['name']             = $value['name'];
        $insertData['price']            = $value['price'];
        $insertData['days']             = $value['days'];
        $insertData['chakan_times']     = $value['chakan_times'];
        $insertData['vip_picurl']       = $value['vip_picurl'];
        $insertData['vsort']            = $key;
        C::t('#tom_tclove#tom_tclove_vip')->insert($insertData);
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'add_fuwu'){
    
    $vip_id      = intval($_GET['id']);
    
    if(submitcheck('submit')){
        $fuwu_id      = intval($_GET['fuwu_id']);
        $fuwu_times   = isset($_GET['fuwu_times'])? intval($_GET['fuwu_times']):0;
        
        $fuwuInfo   = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_by_id($fuwu_id);

        $insertData = array();
        $insertData['vip_id']     = $vip_id;
        $insertData['fuwu_id']    = $fuwu_id;
        $insertData['fuwu_times'] = $fuwu_times;
        $insertData['fuwu_name']  = $fuwuInfo['name'];
        C::t('#tom_tclove#tom_tclove_vip_fuwu')->insert($insertData);

        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
    
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=add_fuwu&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        $vipInfo  = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($vip_id);
        $fuwuList = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_all_list("AND is_hidden = 0","ORDER BY id DESC",0,100);
        echo '<tr><th colspan="15" class="partition">' . $vipInfo['name'] .'>' . $Lang['add_fuwu'] .'</th></tr>';
        echo '<tr><td><select name="fuwu_id" >';
        echo '<option value="0">'.$Lang['fuwu_id_0'].'</option>';
        if(is_array($fuwuList) && !empty($fuwuList)){
        foreach ($fuwuList as $key => $value){
                echo  '<option value='.$value['id'].'>'.$value['name'].'</option>';
            }
        }
    }
    echo '</select></td>';
    tomshowsetting(true,array('title'=>$Lang['edit_fuwu_times'],'name'=>'fuwu_times','value'=>$options['fuwu_times'],'msg'=>$Lang['fuwu_times_msg']),"input");
    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();
    
    $pagesize = 10;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tclove#tom_tclove_vip_fuwu')->fetch_all_count("AND vip_id = {$vip_id}");
    $fuwuVipList = C::t('#tom_tclove#tom_tclove_vip_fuwu')->fetch_all_list("AND vip_id = {$vip_id}","ORDER BY id DESC",$start,$pagesize);
   
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $vipInfo['name'] .'>' . $Lang['fuwu_vip_list'] .'</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['fuwu_name'] . '</th>';
    echo '<th>' . $Lang['fuwu_times'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    foreach ($fuwuVipList as $key => $value){
        
        echo '<tr>';
        echo '<td>'.$value['fuwu_name'].'</td>';
        echo '<td>' . $value['fuwu_times'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=del_vipfuwu&vip_fuwu_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);

    showformfooter();
    
}else {
    
  $pagesize   = 10;
  $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
  $start      = ($page-1)*$pagesize;	
  $count      = C::t('#tom_tclove#tom_tclove_vip')->fetch_all_count("");
  $vipList    = C::t('#tom_tclove#tom_tclove_vip')->fetch_all_list(""," ",$start,$pagesize);
  
  showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['vip_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=import&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['vip_import_1'].'</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter();
  
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['vip_name'] . '</th>';
    echo '<th>' . $Lang['vip_picurl'] . '</th>';
    echo '<th>' . $Lang['vip_price'] . '</th>';
    echo '<th>' . $Lang['vip_days'] . '</th>';
    echo '<th>' . $Lang['vip_chakan_times'] . '</th>';
    echo '<th>' . $Lang['vip_sms_times'] . '</th>';
    echo '<th>' . $Lang['vip_fuwu'] . '</th>';
    echo '<th>' . $Lang['paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    $i = 1;
    foreach ($vipList as $key => $value) {
        $vipfuwuCount = C::t('#tom_tclove#tom_tclove_vip_fuwu')->fetch_all_count("AND vip_id ={$value['id']}");
        if(!preg_match('/^http/', $value['vip_picurl'])){
            if(strpos($value['vip_picurl'], 'source/plugin/') === false){
                $vip_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['vip_picurl'];
            }else{
                $vip_picurl = $_G['siteurl'].$value['vip_picurl'];
            }
        }else{
            $vip_picurl = $value['vip_picurl'];
        }
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . '<img style="height:40px;width:40px;" src="' .$vip_picurl. '">' . '</td>';
        echo '<td>' . $value['price'] . '</td>';
        echo '<td>' . $value['days'] . '</td>';
        if($value['chakan_times'] > 0){
            echo '<td><font color="#fd0d0d">' . $value['chakan_times'] . '</font></td>';
        }else{
            echo '<td><font color="#8e8e8e">' . $Lang['vip_chakan_times_0'] . '</font></td>';
        }
        echo '<td><font color="#fd0d0d">' . $value['sms_times'] . '</font></td>';
        echo '<td style="line-height: 25px;">';
        if($vipfuwuCount > 0){
            $vipfuwuList = C::t('#tom_tclove#tom_tclove_vip_fuwu')->fetch_all_list("AND vip_id ={$value['id']}","ORDER BY id DESC",0,100);
            foreach ($vipfuwuList as $k => $v) {
                echo ''.$v['fuwu_name'].'<font color="#fd0d0d">(' . $Lang['fuwu_times'] .':&nbsp;'.$v['fuwu_times'].')</font><br/>';
            }
        }else{
            echo '<a href="'.$modBaseUrl.'&act=add_fuwu&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['vip_add_fuwu'] . '</a><br/>';
        }
        echo '</td>';
        echo '<td>' . $value['vsort'] . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['vip_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=add_fuwu&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_fuwu_vip'] . '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    
    $jsstr = <<<EOF
<script type="text/javascript">
            
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
  function import_confirm(url){
  var r = confirm("{$Lang['vip_import_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;

}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $price          = isset($_GET['price'])? floatval($_GET['price']):0.00;
    $days           = isset($_GET['days'])? intval($_GET['days']):0;
    $chakan_times   = isset($_GET['chakan_times'])? intval($_GET['chakan_times']):0;
    $sms_times      = isset($_GET['sms_times'])? intval($_GET['sms_times']):0;
    $vsort          = isset($_GET['vsort'])? intval($_GET['vsort']):100;
    
    $vip_picurl     = "";
    if($_GET['act'] == 'add'){
        $vip_picurl        = tomuploadFile("vip_picurl");
    }else if($_GET['act'] == 'edit'){
        $vip_picurl        = tomuploadFile("vip_picurl",$infoArr['vip_picurl']);
    }
    
    $data['name']               = $name;
    $data['vip_picurl']         = $vip_picurl;
    $data['price']              = $price;
    $data['days']               = $days;
    $data['chakan_times']       = $chakan_times;
    $data['sms_times']          = $sms_times;
    $data['vsort']              = $vsort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'           => '',
        'vip_picurl'     => '',
        'price'          => 0.00,
        'days'           => 0,
        'chakan_times'   => 0,
        'sms_times'      => 0,
        'vsort'          => 0,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['vip_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['vip_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_picurl'],'name'=>'vip_picurl','value'=>$options['vip_picurl'],'msg'=>$Lang['vip_vip_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['vip_price'],'name'=>'price','value'=>$options['price'],'msg'=>$Lang['vip_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_days'],'name'=>'days','value'=>$options['days'],'msg'=>$Lang['vip_days_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_chakan_times'],'name'=>'chakan_times','value'=>$options['chakan_times'],'msg'=>$Lang['vip_chakan_times_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_sms_times'],'name'=>'sms_times','value'=>$options['sms_times'],'msg'=>$Lang['vip_sms_times_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_vsort'],'name'=>'vsort','value'=>$options['vsort'],'msg'=>$Lang['vip_vsort_msg']),"input");
    return;
}
function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['vip_type'],$modBaseUrl,false);
        tomshownavli($Lang['vip_add_type'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['vip_type'],$modBaseUrl,false);
        tomshownavli($Lang['vip_add_type'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['vip_edit_type'],"",true);
    }else{
        tomshownavli($Lang['vip_type'],$modBaseUrl,true);
        tomshownavli($Lang['vip_add_type'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}