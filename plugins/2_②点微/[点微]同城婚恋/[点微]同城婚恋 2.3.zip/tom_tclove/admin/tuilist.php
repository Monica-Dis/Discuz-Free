<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=tuilist';
$modListUrl = $adminListUrl.'&tmod=tuilist';
$modFromUrl = $adminFromUrl.'&tmod=tuilist';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
//if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
//    C::t('#tom_tclove#tom_tclove_tui')->delete_by_id($_GET['id']);
//    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
//    
//}else{
    
    $id         = isset($_GET['id'])? intval($_GET['id']):0;
    $user_id    = isset($_GET['user_id'])? intval($_GET['user_id']):0;

    $pagesize   = 10;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start      = ($page-1)*$pagesize;	

    $where = " AND num > 0";

    if(!empty($id)){
        $where.= " AND id= {$id}";
    }
    if(!empty($user_id)){
        $where.= " AND user_id= {$user_id}";
    }

    $count = C::t('#tom_tclove#tom_tclove_tui')->fetch_all_count($where);
    $tuiList = C::t('#tom_tclove#tom_tclove_tui')->fetch_all_list($where,"ORDER BY total_shouyi DESC,id DESC",$start,$pagesize);

    $modBasePageUrl = $modBaseUrl."&id={$id}&user_id={$user_id}";

    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['tuilist_search'] . '</th></tr>';

    echo '<tr><td width="100" align="right"><b>'.$Lang['shouyi_phb_id'].'</b></td><td><input name="id" type="text" value="'.$id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['tongcheng_id'].'</b></td><td><input name="user_id" type="text" value="'.$user_id.'" size="40" /></td></tr>';

    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();

    tomshownavheader();
    tomshownavli($Lang['shouyi_phb'],$adminBaseUrl.'&tmod=tui_phb',false);
    tomshownavfooter();

    showtableheader();
   
    echo '<tr class="header">';
    echo '<th>' . $Lang['tuilist_id'] . '</th>';
    echo '<th>' . $Lang['tuilist_user_avatar'] . '</th>';
    echo '<th>' . $Lang['xm'] . '</th>';
    echo '<th>' . $Lang['tuilist_num'] . '</th>';
    echo '<th>' . $Lang['tuilist_shouyi'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($tuiList as $key => $value){

        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);

        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' .'<img style="height:40px;width:40px;padding-right:10px;" src="' .$userInfo['picurl']. '">'.'</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f70404">(UID:' .$value['user_id']. ')</font></td>'; 
        echo '<td>' . $value['num'] . '</td>';
         echo '<td>' . $value['total_shouyi'] . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$adminBaseUrl.'&tmod=tui_shouyi_log&tui_id='.$value['id'].'">' . $Lang['tui_shouyi_log'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp';
        echo '<a href="'.$modBaseUrl.'&tmod=index&tui_id='.$value['id'].'">' . $Lang['tui_list'] . '</a><br/>';
//        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
//}