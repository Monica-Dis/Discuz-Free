<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=tui_phb';
$modListUrl = $adminListUrl.'&tmod=tui_phb';
$modFromUrl = $adminFromUrl.'&tmod=tui_phb';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $phb_type     = isset($_GET['phb_type'])? intval($_GET['phb_type']):0;
        $user_id      = isset($_GET['user_id'])? intval($_GET['user_id']):0;
        $shouyi       = isset($_GET['shouyi'])? floatval($_GET['shouyi']):0.00;
        
        $phbListTmp = C::t('#tom_tclove#tom_tclove_tui_phb')->fetch_all_list("AND phb_type={$phb_type} AND user_id = {$user_id}","",0,1);
        if(is_array($phbListTmp) && !empty($phbListTmp)){
            cpmsg($Lang['shouyi_phb_add_error'], $modListUrl.'&act=add', 'error');
        }else{
            if($phb_type==2){
                $month_id = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
            }else if($phb_type==3){
                $week_id = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);
            }
            
            $insertData = array();
            $insertData['user_id']    = $user_id;
            $insertData['phb_type']   = $phb_type;
            $insertData['month_id']   = $month_id;
            $insertData['week_id']    = $week_id;
            $insertData['shouyi']     = $shouyi;
            if(C::t('#tom_tclove#tom_tclove_tui_phb')->insert($insertData)){
                $tcphb_id = C::t('#tom_tclove#tom_tclove_tui_phb')->insert_id();
            }
            
            cpmsg($Lang['act_success'], $modListUrl.'&phb_type='.$phb_type.'', 'succeed');
        }
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['shouyi_phb_add'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['tongcheng_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['tongcheng_id_msg']),"input");
        $phb_type_item = array(1=>$Lang['phb_type_1'],2=>$Lang['phb_type_2'],3=>$Lang['phb_type_3']);
        tomshowsetting(true,array('title'=>$Lang['phb_type'],'name'=>'phb_type','value'=>$options['phb_type'],'msg'=>$Lang['phb_type_msg'],'item'=>$phb_type_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['shouyi_phb_shouyi'],'name'=>'shouyi','value'=>$options['shouyi'],'msg'=>$Lang['shouyi_phb_shouyi_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    C::t('#tom_tclove#tom_tclove_tui_phb')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'edit_shouyi'){
    
    $phb_type    = isset($_GET['phb_type'])? intval($_GET['phb_type']):0;
    
    $phbInfo = C::t('#tom_tclove#tom_tclove_tui_phb')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $shouyi   = isset($_GET['shouyi'])? floatval($_GET['shouyi']):0;
        
        DB::query("UPDATE ".DB::table('tom_tclove_tui_phb')." SET shouyi={$shouyi} WHERE id='{$phbInfo['id']}' ", 'UNBUFFERED');
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        showformheader($modFromUrl.'&act=edit_shouyi&phb_type='.$phb_type.'&id='.$_GET['id'].'&formhash='.$formhash,'enctype');
        showtableheader();
        
        tomshowsetting(true,array('title'=>$Lang['phb_shouyi'],'name'=>'shouyi','value'=>$phbInfo['shouyi'],'msg'=>$Lang['phb_shouyi_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
  
}else{
    
    $id         = isset($_GET['id'])? intval($_GET['id']):0;
    $user_id    = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $phb_type   = isset($_GET['phb_type'])? intval($_GET['phb_type']):0;

    $pagesize   = 10;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start      = ($page-1)*$pagesize;	

    $where = "";

    if($phb_type == 2){
        $where.= " AND phb_type= 2";
        $month_id = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
        $where.= " AND month_id= {$month_id}";
    }else if($phb_type == 3){
        $where.= " AND phb_type= 3";
        $week_id = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);
        $where.= " AND week_id= {$week_id}";
    }else{
        $where.= " AND phb_type= 1";
    }
    if(!empty($id)){
        $where.= " AND id= {$id}";
    }
    if(!empty($user_id)){
        $where.= " AND user_id= {$user_id}";
    }

    $count = C::t('#tom_tclove#tom_tclove_tui_phb')->fetch_all_count($where);
    $phbList = C::t('#tom_tclove#tom_tclove_tui_phb')->fetch_all_list($where,"ORDER BY shouyi DESC,id DESC",$start,$pagesize);

    $modBasePageUrl = $modBaseUrl."&id={$id}&user_id={$user_id}&phb_type={$phb_type}";

    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search_phb_list'] . '</th></tr>';

    echo '<tr><td width="100" align="right"><b>'.$Lang['shouyi_phb_id'].'</b></td><td><input name="id" type="text" value="'.$id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['tongcheng_id'].'</b></td><td><input name="user_id" type="text" value="'.$user_id.'" size="40" /></td></tr>';
    $phb_type_2 = $phb_type_3 ="";
    if($phb_type == 2){ $phb_type_2 = "selected";}
    if($phb_type == 3){ $phb_type_3 = "selected";}
    echo '<tr><td width="100" align="right"><b>' . $Lang['phb_type'] . '</b></td><td><select name="phb_type" >';
    echo '<option value="1">'.$Lang['phb_type_1'].'</option>';
    echo '<option value="2" '.$phb_type_2.'>'.$Lang['phb_type_2'].'</option>';
    echo '<option value="3" '.$phb_type_3.'>'.$Lang['phb_type_3'].'</option>';
    echo '</select></td></tr>';

    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();

    tomshownavheader();
    if($phb_type == 2){
        tomshownavli($Lang['phb_type_1'],$adminBaseUrl.'&tmod=tui_phb&phb_type=1',false);
        tomshownavli($Lang['phb_type_2'],$adminBaseUrl.'&tmod=tui_phb&phb_type=2',true);
        tomshownavli($Lang['phb_type_3'],$adminBaseUrl.'&tmod=tui_phb&phb_type=3',false);
        tomshownavli($Lang['shouyi_phb_add'],$adminBaseUrl.'&tmod=tui_phb&act=add',false);
        
    }else if($phb_type == 3){
        tomshownavli($Lang['phb_type_1'],$adminBaseUrl.'&tmod=tui_phb&phb_type=1',false);
        tomshownavli($Lang['phb_type_2'],$adminBaseUrl.'&tmod=tui_phb&phb_type=2',false);
        tomshownavli($Lang['phb_type_3'],$adminBaseUrl.'&tmod=tui_phb&phb_type=3',true);
        tomshownavli($Lang['shouyi_phb_add'],$adminBaseUrl.'&tmod=tui_phb&act=add',false);
    }else{
        tomshownavli($Lang['phb_type_1'],$adminBaseUrl.'&tmod=tui_phb&phb_type=1',true);
        tomshownavli($Lang['phb_type_2'],$adminBaseUrl.'&tmod=tui_phb&phb_type=2',false);
        tomshownavli($Lang['phb_type_3'],$adminBaseUrl.'&tmod=tui_phb&phb_type=3',false);
        tomshownavli($Lang['shouyi_phb_add'],$adminBaseUrl.'&tmod=tui_phb&act=add',false);
    }
    
    tomshownavfooter();

    showtableheader();
    if($phb_type ==2){
        echo '<tr><th colspan="15" class="partition">' . $Lang['phb_type_2'] . '</th></tr>';
    }else if($phb_type ==3){
        echo '<tr><th colspan="15" class="partition">' . $Lang['phb_type_3'] . '</th></tr>';
    }else{
        echo '<tr><th colspan="15" class="partition">' . $Lang['phb_type_1'] . '</th></tr>';
    }
    echo '<tr class="header">';
    echo '<th>ID</th>';
    echo '<th>' . $Lang['phb_type'] . '</th>';
    echo '<th>' . $Lang['shouyi_phb_user_avatar'] . '</th>';
    echo '<th>' . $Lang['xm'] . '</th>';
    echo '<th>' . $Lang['phb_shouyi'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($phbList as $key => $value){

        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);

        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['phb_type'] ==1){
            echo '<td>' . $Lang['phb_type_1'] . '</td>';
        }else if($value['phb_type'] ==2){
            echo '<td>' . $Lang['phb_type_2'] . '</td>';
        }else if($value['phb_type'] ==3){
            echo '<td>' . $Lang['phb_type_3'] . '</td>';
        }
        echo '<td>' .'<img style="height:40px;width:40px;padding-right:10px;" src="' .$userInfo['picurl']. '">'.'</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f70404">(UID:' .$value['user_id']. ')</font></td>'; 
        echo '<td>' . $value['shouyi'] . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit_shouyi&phb_type='.$value['phb_type'].'&id='.$value['id'].'">' . $Lang['shouyi_phb_edit'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}