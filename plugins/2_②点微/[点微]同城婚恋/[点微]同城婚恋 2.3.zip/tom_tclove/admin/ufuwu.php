<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=ufuwu&tclove_id='.$_GET['tclove_id'];
$modListUrl = $adminListUrl.'&tmod=ufuwu&tclove_id='.$_GET['tclove_id'];
$modFromUrl = $adminFromUrl.'&tmod=ufuwu&tclove_id='.$_GET['tclove_id'];

$tclove_id    = isset($_GET['tclove_id'])? intval($_GET['tclove_id']):0;

$tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $fuwu_id    = isset($_GET['fuwu_id'])? intval($_GET['fuwu_id']):0;
    $fuwu_type  = isset($_GET['fuwu_type'])? intval($_GET['fuwu_type']):0;
    $fuwu_times = isset($_GET['fuwu_times'])? intval($_GET['fuwu_times']):0;
    $beizu      = isset($_GET['beizu'])? addslashes($_GET['beizu']):'';
    
    $fuwuInfo = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_by_id($fuwu_id);
    $ufuwuInfo = C::t('#tom_tclove#tom_tclove_ufuwu')->fetch_all_list("AND fuwu_id = {$fuwu_id} AND tclove_id ={$tclove_id}"," ORDER BY id DESC ",0,1);
    
    if($fuwu_id <= 0){
        cpmsg($Lang['fuwu_name_error_msg'], $modListUrl, 'error');exit;
    }
    
    if($fuwu_times <= 0){
        cpmsg($Lang['fuwu_times_error_0_msg'], $modListUrl, 'error');exit;
    }
    if($fuwu_type == 1){
        if(is_array($ufuwuInfo) && $ufuwuInfo[0]['id'] > 0){
            if($ufuwuInfo[0]['fuwu_times'] < $fuwu_times){
                cpmsg($Lang['fuwu_times_error_msg'], $modListUrl, 'error');exit;
            }
        }else{
            cpmsg($Lang['fuwu_times_error_msg'], $modListUrl, 'error');exit;
        }
    }
    if(is_array($ufuwuInfo) && $ufuwuInfo[0]['id'] > 0){
        $updateData = array();
        if($fuwu_type == 1){
            $updateData['fuwu_times']   = $ufuwuInfo[0]['fuwu_times'] - $fuwu_times;
        }else if($fuwu_type == 2){
            $updateData['fuwu_times']   = $ufuwuInfo[0]['fuwu_times'] + $fuwu_times;
        }
        C::t('#tom_tclove#tom_tclove_ufuwu')->update($ufuwuInfo[0]['id'], $updateData);
    }else{
        $insertData = array();
        $insertData['tclove_id']        = $tclove_id;
        $insertData['fuwu_id']          = $fuwu_id;
        $insertData['fuwu_name']        = $fuwuInfo['fuwu_name'];
        $insertData['fuwu_times']       = $fuwu_times;
        C::t('#tom_tclove#tom_tclove_ufuwu')->insert($insertData);
    }
    
    $insertData = array();
    $insertData['tclove_id']        = $tclove_id;
    $insertData['fuwu_id']          = $fuwu_id;
    $insertData['change_times']     = $fuwu_times;
    if(is_array($ufuwuInfo) && $ufuwuInfo[0]['id'] > 0){
        $insertData['old_times']        = $ufuwuInfo[0]['fuwu_times'];
    }else{
        $insertData['old_times']        = 0;
    }
    $insertData['op_type']          = 1;
    $insertData['beizu']            = $beizu;
    $insertData['op_time']         = TIMESTAMP;
    C::t('#tom_tclove#tom_tclove_ufuwu_log')->insert($insertData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tclove#tom_tclove_ufuwu_log')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    tomshownavheader();
    tomshownavli($tcloveInfo['xm'].' > ',"",true);
    tomshownavfooter();
    showformheader($modFromUrl.'&act=save&formhash='.$formhash,'enctype');
    showtableheader();
    
    echo '<tr><td width="100" ><b>' . $Lang['yonghu_fuwu'] . '</b><tr></tr><td><select name="fuwu_id" >';
    echo '<option value="0">'.$Lang['yonghu_fuwu_msg'].'</option>';
    $fuwuList    = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_all_list("","  ORDER BY fsort ASC,id DESC ",0,100);
    if(is_array($fuwuList) && !empty($fuwuList)){
        foreach ($fuwuList as $key => $value){
            $ufuwuInfo = C::t('#tom_tclove#tom_tclove_ufuwu')->fetch_all_list("AND fuwu_id = {$value['id']} AND tclove_id ={$tclove_id}"," ORDER BY id DESC ",0,1);
            if(is_array($ufuwuInfo) && $ufuwuInfo[0]['id'] > 0){
                echo  '<option value='.$value['id'].'>'.$value['name'].$Lang['kuohao_left'].$Lang['sy_fuwu_times'].$ufuwuInfo[0]['fuwu_times'].$Lang['kuohao_right'].'</option>';
            }else{
                echo  '<option value='.$value['id'].'>'.$value['name'].$Lang['kuohao_left'].$Lang['sy_fuwu_times'].'0'.$Lang['kuohao_right'].'</option>';
            }
        }
    }
    echo '</select></td>';
    $type_item = array(1=>$Lang['fuwu_type_1'],2=>$Lang['fuwu_type_2']);
    tomshowsetting(true,array('title'=>$Lang['fuwu_type'],'name'=>'fuwu_type','value'=>1,'msg'=>$Lang['fuwu_type_msg'],'item'=>$type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['fuwu_times_change'],'name'=>'fuwu_times','value'=>1,'msg'=>''),"input");
    tomshowsetting(true,array('title'=>$Lang['fuwu_beizu'],'name'=>'beizu','value'=>$options['beizu'],'msg'=>''),"textarea");
    
    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();
    
    tomshownavheader();
    tomshownavli($Lang['back_title'],$adminBaseUrl.'&tmod=index&user_no='.$tcloveInfo['user_no'].'&formhash='.FORMHASH,false);
    tomshownavfooter();
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 1000;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tclove#tom_tclove_ufuwu_log')->fetch_all_count("AND tclove_id={$tclove_id}");
    $ufuwulogList = C::t('#tom_tclove#tom_tclove_ufuwu_log')->fetch_all_list("AND tclove_id={$tclove_id}"," ORDER BY op_time DESC,id DESC ",$start,$pagesize);
    
    tomshownavheader();
    tomshownavli($tcloveInfo['xm'].' > ',"",true);
    tomshownavfooter();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['tclove_id'] . '</th>';
    echo '<th>' . $Lang['fuwu_name'] . '</th>';
    echo '<th>' . $Lang['change_times'] . '</th>';
    echo '<th>' . $Lang['old_times'] . '</th>';
    echo '<th>' . $Lang['op_user_id'] . '</th>';
    echo '<th>' . $Lang['fuwu_op_type'] . '</th>';
    echo '<th>' . $Lang['fuwu_beizu'] . '</th>';
    echo '<th>' . $Lang['fuwu_op_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    foreach ($ufuwulogList as $key => $value) {
        
        $fuwuInfo = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_by_id($value['fuwu_id']);
        $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['op_user_id']);
        
        echo '<tr>';
        echo '<td>' . $value['tclove_id'] . '</td>';
        echo '<td>' . $fuwuInfo['name'] . '&nbsp;</td>';
        echo '<td>' . $value['change_times'] . '&nbsp;</td>';
        echo '<td>' . $value['old_times'] . '&nbsp;</td>';
        
        if($value['op_type'] == 1){
            echo '<td>' . '-' . '</td>';
            echo '<td>' . $Lang['fuwu_op_type_1'] . '&nbsp;</td>';
        }else if($value['op_type'] == 2){
            echo '<td>' .$tongchengInfo['nickname'] .'<font color="#f70404">('.$Lang['user_id'] .':'. $value['op_user_id'] . ')</font>'.'</td>';
            echo '<td>' . $Lang['fuwu_op_type_2'] . '&nbsp;</td>';
        }else if($value['op_type'] == 3){
            echo '<td>' .$tongchengInfo['nickname'] .'<font color="#f70404">('.$Lang['user_id'] .':'. $value['op_user_id'] . ')</font>'.'</td>';
            echo '<td>' . $Lang['fuwu_op_type_3'] . '&nbsp;</td>';
        }else if($value['op_type'] == 4){
            echo '<td>' .$tongchengInfo['nickname'] .'<font color="#f70404">('.$Lang['user_id'] .':'. $value['op_user_id'] . ')</font>'.'</td>';
            echo '<td>' . $Lang['fuwu_op_type_4'] . '&nbsp;</td>';
        }
        echo '<td>' . $value['beizu'] . '</td>';
        echo '<td>' . dgmdate($value['op_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    
    $jsstr = <<<EOF
<script type="text/javascript">
            
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;

}