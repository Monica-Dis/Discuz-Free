<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=order';
$modListUrl = $adminListUrl.'&tmod=order';
$modFromUrl = $adminFromUrl.'&tmod=order';

$tclove_id    = isset($_GET['tclove_id'])? intval($_GET['tclove_id']):0;
$site_id      = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$where = " AND order_status=2 ";
if(!empty($site_id)){
    $where.= " AND site_id={$site_id} ";
}
if($tclove_id > 0){
    $where.= " AND tclove_id={$tclove_id} ";
}

$pagesize = 100;
$start = ($page-1)*$pagesize;	
$count = C::t('#tom_tclove#tom_tclove_order')->fetch_all_count($where);
$orderList = C::t('#tom_tclove#tom_tclove_order')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);

$modBasePageUrl = $modBaseUrl."&site_id={$site_id}&tclove_id={$tclove_id}";

showformheader($modFromUrl.'&formhash='.FORMHASH);
showtableheader();
$sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
$sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
$sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
$sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
foreach ($sitesList as $key => $value){
    $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
}
$sitesStr.= '</select></td></tr>';
echo $sitesStr;
showsubmit('submit', 'submit');
showtablefooter();
showformfooter();

$todayPayPrice = C::t('#tom_tclove#tom_tclove_order')->fetch_all_sun_pay_price(" AND pay_time > $nowDayTime AND order_status=2 ");
$monthPayPrice = C::t('#tom_tclove#tom_tclove_order')->fetch_all_sun_pay_price(" AND pay_time > $nowMonthTime AND order_status=2 ");
$allPayPrice = C::t('#tom_tclove#tom_tclove_order')->fetch_all_sun_pay_price(" AND order_status=2 ");
echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
echo $Lang['today_pay_price_title'].'<font color="#fd0d0d">('.$todayPayPrice.')</font>&nbsp;&nbsp;';
echo $Lang['month_pay_price_title'].'<font color="#fd0d0d">('.$monthPayPrice.')</font>&nbsp;&nbsp;';
echo $Lang['all_pay_price_title'].'<font color="#fd0d0d">('.$allPayPrice.')</font>&nbsp;&nbsp;';
echo '</div>';

showtableheader();
echo '<tr><th colspan="15" class="partition">' . $Lang['order_list'] . '</th></tr>';
echo '<tr class="header">';
echo '<th>' . $Lang['user_no'] . '</th>';
echo '<th>' . $Lang['xm'] . '</th>';
echo '<th>' . $Lang['order_order_type'] . '</th>';
echo '<th>' . $Lang['order_pay_price'] . '</th>';
echo '<th>' . $Lang['order_pay_time'] . '</th>';
echo '</tr>';
foreach ($orderList as $key => $value){
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
    $vipInfo = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($value['vip_id']);
    $fuwuInfo = C::t('#tom_tclove#tom_tclove_fuwu')->fetch_by_id($value['fuwu_id']);
    echo '<tr>';
    echo '<td>' . $tcloveInfo['user_no'] . '</td>';
    echo '<td><a target="_blank" href="'.$adminBaseUrl.'&tmod=index&user_no='.$tcloveInfo['user_no'].'&formhash='.FORMHASH.'">' . $tcloveInfo['xm'] . '<font color="#f70404">(ID:' .$value['user_id']. ')</font></a></td>';
    if($value['order_type'] == 1){
        echo '<td>' . $Lang['order_top_type'] .'<font color="#238206">(' . $value['time_value'] . '' . $Lang['order_days']  .')</font></td>';
    }else if($value['order_type'] == 2){
        echo '<td>' . $Lang['order_vip_type']  .'<font color="#238206">(' . $vipInfo['name'] . ')</font></td>';
    }else if($value['order_type'] == 3){
        echo '<td>' . $Lang['order_fuwu_type']  .'<font color="#238206">(' . $fuwuInfo['name'] . ')</font></td>';
    }else if($value['order_type'] == 4){
        echo '<td>' . $Lang['order_hongniang_type']  .'</td>';
    }else if($value['order_type'] == 5){
        echo '<td>' . $Lang['order_sms_type']  .'<font color="#238206">(' . $value['sms_times']. $Lang['tiao']  . ')</font></td>';
    }
    echo '<td><font color="#fd0d0d">' . $value['pay_price'] . '</font></td>';
    echo '<td>' . dgmdate($value['pay_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
    echo '</tr>';
}
showtablefooter();
$multi = multi($count, $pagesize, $page, $modBaseUrl);	
showsubmit('', '', '', '', $multi, false);