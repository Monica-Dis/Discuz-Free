<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=hongniang_shenqing';
$modListUrl = $adminListUrl.'&tmod=hongniang_shenqing';
$modFromUrl = $adminFromUrl.'&tmod=hongniang_shenqing';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status']     = 1;
    C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->update($_GET['id'],$updateData);
        
    $hongniang_sqInfo = C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->fetch_by_id($_GET['id']);
    $hongniangInfo = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_user_id($hongniang_sqInfo['user_id']);
    
    if(is_array($hongniangInfo) && !empty($hongniangInfo)){}else{
        $insertData = array();
        $insertData['user_id']      = $hongniang_sqInfo['user_id'];
        $insertData['name']         = $hongniang_sqInfo['name'];
        $insertData['tel']          = $hongniang_sqInfo['tel'];
        $insertData['wx']           = $hongniang_sqInfo['wx'];
        $insertData['desc']         = $hongniang_sqInfo['desc'];
        $insertData['picurl']       = $hongniang_sqInfo['picurl'];
        $insertData['qrcode']       = $hongniang_sqInfo['qrcode'];
        C::t('#tom_tclove#tom_tclove_hongniang')->insert($insertData);
    }
    
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($hongniang_sqInfo['user_id']);

    $shenhe   = $Lang['hongniang_template_shenhe_ok'];
    
    $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tclove&site='.$hongniang_sqInfo['site_id'].'&mod=my">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$hongniang_sqInfo['site_id']}&mod=managerHongniang");
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcloveConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['tclove_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['tclove_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $hongniang_sqInfo = C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->fetch_by_id($_GET['id']);
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($hongniang_sqInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->update($_GET['id'],$updateData);

        $shenhe   = $Lang['hongniang_template_shenhe_no'];
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tclove&site='.$hongniang_sqInfo['site_id'].'&mod=myhongniang_shenqing">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        
        $cpmsg = $Lang['act_success'];
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$hongniang_sqInfo['site_id']}&mod=myhongniang_shenqing");
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcloveConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tclove_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tclove_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.$Lang['tclove_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tclove_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tclove_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
    
}else{
    $page = intval($_GET['page'])> 0 ? intval($_GET['page']) : 1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $hongniangList = C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->fetch_all_list("","ORDER BY add_time DESC,id DESC",$start,$pagesize);
    
    showtableheader();
    showtablefooter();
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>ID</th>';
    echo '<th>' . $Lang['xm'] . '</th>';
    echo '<th>' . $Lang['hongniang_user_id'] . '</th>';
    echo '<th>' . $Lang['wx'] . '</th>';
    echo '<th>' . $Lang['tel'] . '</th>';
    echo '<th>' . $Lang['hongniang_avatar'] . '</th>';
    echo '<th>' . $Lang['hongniang_qrcode'] . '</th>';
    echo '<th>' . $Lang['hongniang_desc'] . '</th>';
    echo '<th>' . $Lang['hongniang_shenhe_status'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($hongniangList as $key => $value){
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        if(!preg_match('/^http/', $value['qrcode']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['qrcode'];
            }else{
                $qrcode = $value['qrcode'];
            }
        }else{
            $qrcode = $value['qrcode'];
        }
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $value['name'] . '</td>'; 
        echo '<td>' . $value['user_id'] . '</td>'; 
        echo '<td>' . $value ['wx']. '</td>';
        echo '<td>' . $value['tel'] . '</td>';
        if(empty($value['picurl'])){
          echo '<td>' .'---'. '</td>';
        }else{
           echo '<td>' . '<img style="height:40px;width:40px;" src="' .$picurl. '">' . '</td>'; 
        }
        if(empty($value['qrcode'])){
          echo '<td>' .'---'. '</td>'; 
        }else{
           echo '<td>' . '<img style="height:40px;width:40px;" src="' .$qrcode. '">' . '</td>'; 
        }
        echo '<td>' . $value['desc'] . '</td>';
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['hongniang_shenhe_status_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['hongniang_shenhe_status_3']. '</a>)';
        if($value['shenhe_status'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['hongniang_shenhe_status_1']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 2){
            echo '<td><font color="#f70404">' . $Lang['hongniang_shenhe_status_2']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 3){
            echo '<td><font color="#f70404">' . $Lang['hongniang_shenhe_status_3']. '</font>'.$sheheBtnStr.'</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td style="line-height: 25px;">';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>&nbsp;&nbsp;';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function pay_confirm(url){
  var r = confirm("{$Lang['makesure_pay_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $user_id          = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name             = isset($_GET['name'])? addslashes($_GET['name']):'';
    $wx               = isset($_GET['wx'])? addslashes($_GET['wx']):0;
    $tel              = isset($_GET['tel'])? addslashes($_GET['tel']):0;
    $desc             = isset($_GET['desc'])? addslashes($_GET['desc']):'';
    
    $picurl = "";
    $qrcode = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }
    if($_GET['act'] == 'add'){
        $qrcode        = tomuploadFile("qrcode");
    }else if($_GET['act'] == 'edit'){
        $qrcode        = tomuploadFile("qrcode",$infoArr['qrcode']);
    }
    
    $data['user_id']   = $user_id;
    $data['name']      = $name;
    $data['wx']        = $wx;
    $data['tel']       = $tel;
    $data['picurl']    = $picurl;
    $data['qrcode']    = $qrcode;
    $data['desc']      = $desc;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'user_id'    => 0,
        'name'       => '',
        'wx'         => '',
        'tel'        => '',
        'picurl'     => '',
        'qrcode'     => '',
        'desc'       => '',
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['hongniang_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['hongniang_user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['xm'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['hongniang_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['wx'],'name'=>'wx','value'=>$options['wx'],'msg'=>$Lang['hongniang_wx_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['tel'],'name'=>'tel','value'=>$options['tel'],'msg'=>$Lang['hongniang_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['hongniang_avatar'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['hongniang_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['hongniang_qrcode'],'name'=>'qrcode','value'=>$options['qrcode'],'msg'=>$Lang['hongniang_qrcode_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['hongniang_desc'],'name'=>'desc','value'=>$options['desc'],'msg'=>$Lang['hongniang_desc_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    tomshownavli($Lang['hongniang_list_title'],$adminBaseUrl.'&tmod=hongniang',false);
    tomshownavli($Lang['hongniang_shenqing_list'],$modBaseUrl,true);
    tomshownavfooter();
}