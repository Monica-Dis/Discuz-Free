<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=report';
$modListUrl = $adminListUrl.'&tmod=report';
$modFromUrl = $adminFromUrl.'&tmod=report';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
if($formhash == FORMHASH && $act == 'del'){
    C::t('#tom_tclove#tom_tclove_report')->delete($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($formhash == FORMHASH && $act == 'fenghao'){
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tclove#tom_tclove_report')->update($_GET['id'],$updateData);
    
    $updateData = array();
    $updateData['status'] = 2;
    $userInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($_GET['report_user_id']);
    C::t('#tom_tclove#tom_tclove')->update($userInfo['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    $pagesize = 10;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tclove#tom_tclove_report')->fetch_all_count("");
    $reportList = C::t('#tom_tclove#tom_tclove_report')->fetch_all_list("","ORDER BY report_time DESC",$start,$pagesize);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['report_list'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>ID</th>';
    echo '<th>' . $Lang['re_user_id'] . '</th>';
    echo '<th>' . $Lang['report_user_id'] . '</th>';
    echo '<th>' . $Lang['report_content'] . '</th>';
    echo '<th>' . $Lang['report_pic'] . '</th>';
    echo '<th>' . $Lang['report_status'] . '</th>';
    echo '<th>' . $Lang['report_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($reportList as $key => $value){
        $__UserInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($value['user_id']);
        $reportUserInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($value['report_user_id']);
        
        if(!empty($value['report_pic_1'])){
            if(!preg_match('/^http/', $value['report_pic_1'])){
                if(strpos($value['report_pic_1'], 'source/plugin/tom_tclove') === false){
                    $report_pic_1 = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['report_pic_1'];
                }else{
                    $report_pic_1 = $value['report_pic_1'];
                }
            }else{
                $report_pic_1 = $value['report_pic_1'];
            }
            $report_pic_1 = '<a target="_blank" href="'.$report_pic_1.'"><img src="'.$report_pic_1.'" width="40" height="40"></a>';
        }else{
            $report_pic_1 = '';
        }
            
        if(!empty($value['report_pic_2'])){
            if(!preg_match('/^http/', $value['report_pic_2'])){
                if(strpos($value['report_pic_2'], 'source/plugin/tom_tclove') === false){
                    $report_pic_2 = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['report_pic_2'];
                }else{
                    $report_pic_2 = $value['report_pic_2'];
                }
            }else{
                $report_pic_2 = $value['report_pic_2'];
            }
            $report_pic_2 = '<a target="_blank" href="'.$report_pic_2.'"><img src="'.$report_pic_2.'" width="40" height="40"></a>';
        }else{
            $report_pic_2 = '';
        }
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a target="_blank" href="'.$adminBaseUrl.'&tmod=index&act=show&tclove_id='.$__UserInfo['id'].'&formhash='.FORMHASH.'">' . $__UserInfo['xm'] . '</a></td>';
        echo '<td><a target="_blank" href="'.$adminBaseUrl.'&tmod=index&act=show&tclove_id='.$reportUserInfo['id'].'&formhash='.FORMHASH.'">' . $reportUserInfo['xm'] . '</a></td>';
        echo '<td>' . $value['report_content'] . '</td>';
        echo '<td>' . $report_pic_1 .'-'. $report_pic_2 . '</td>';
        if($value['status'] == 1){
            echo '<td>' . $Lang['report_status_1'] . '</td>';
        }else{
            echo '<td>' . $Lang['report_status_0'] . '</td>';
        }
        echo '<td>' . dgmdate($value['report_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=fenghao&id='.$value['id'].'&report_user_id='.$value['report_user_id'].'&formhash='.FORMHASH.'">' . $Lang['envelope'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
}