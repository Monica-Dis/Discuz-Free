<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_tclove_admin_user_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
if($formhash == FORMHASH && $act == 'show'){
}else if($formhash == FORMHASH && $act == 'del'){
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($_GET['tclove_id']);
    
    C::t('#tom_tclove#tom_tclove')->delete_by_id($_GET['tclove_id']);
    C::t('#tom_tclove#tom_tclove_collect')->delete_by_user_id($tcloveInfo['user_id']);
    C::t('#tom_tclove#tom_tclove_collect')->delete_by_tclove_id($_GET['tclove_id']);
    C::t('#tom_tclove#tom_tclove_chakan')->delete_by_user_id($tcloveInfo['user_id']);
    C::t('#tom_tclove#tom_tclove_look')->delete_by_user_id($tcloveInfo['user_id']);
    C::t('#tom_tclove#tom_tclove_look')->delete_by_tclove_id($_GET['tclove_id']);
    C::t('#tom_tclove#tom_tclove_xihuan')->delete_by_user_id($tcloveInfo['user_id']);
    C::t('#tom_tclove#tom_tclove_xihuan')->delete_by_tclove_id($_GET['tclove_id']);
    C::t('#tom_tclove#tom_tclove_photo')->delete_by_tclove_id($_GET['tclove_id']);
    C::t('#tom_tclove#tom_tclove_video')->delete_by_tclove_id($_GET['tclove_id']);
    C::t('#tom_tclove#tom_tclove_talk')->delete_by_tclove_id($_GET['tclove_id']);
    C::t('#tom_tclove#tom_tclove_talk_pinglun')->delete_by_tclove_id($_GET['tclove_id']);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_tclove_id($_GET['tclove_id']);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_zan')->delete_by_tclove_id($_GET['tclove_id']);
    C::t('#tom_tclove#tom_tclove_talk_zan')->delete_by_tclove_id($_GET['tclove_id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($formhash == FORMHASH && $act == 'editvip'){
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($_GET['tclove_id']);
    if(submitcheck('submit')){
        $vip_id       = intval($_GET['vip_id']);
        $vip_time     = isset($_GET['vip_time'])? addslashes($_GET['vip_time']):'';
        if($vip_id == 0){
            $vip_time = 0;
        }else{
            $vip_time   = strtotime($vip_time);
        }
        $updateData = array();
        $updateData['vip_id']   = $vip_id;
        $updateData['vip_time'] = $vip_time;
        C::t('#tom_tclove#tom_tclove')->update($_GET['tclove_id'],$updateData);

        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editvip&tclove_id='.$_GET['tclove_id'].'&formhash='.FORMHASH);
        showtableheader();
        $vipList = C::t('#tom_tclove#tom_tclove_vip')->fetch_all_list("");
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_vip_title'] .'('.$tcloveInfo['xm']. ')</th></tr>';
        echo '<tr><td width="100" ><b>' . $Lang['vip_id'] . '</b><tr></tr><td><select name="vip_id" >';
        echo '<option value="0">'.$Lang['edit_vip_id_0'].'</option>';
        if(is_array($vipList) && !empty($vipList)){
            foreach ($vipList as $key => $value){
                if($value['id'] == $tcloveInfo['vip_id']){
                    echo  '<option value='.$value['id'].' selected>'.$value['name'].'</option>';
                }else{
                    echo  '<option value='.$value['id'].'>'.$value['name'].'</option>';
                }
            }
        }
        echo '</select></td>';
        tomshowsetting(true,array('title'=>$Lang['edit_vip_time'],'name'=>'vip_time','value'=>$tcloveInfo['vip_time'],'msg'=>$Lang['edit_vip_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
}else if($formhash == FORMHASH && $act == 'edittop'){
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($_GET['tclove_id']);

    if(submitcheck('submit')){
        $top_status       = intval($_GET['top_status']);
        $top_time         = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
        
        if($top_status == 0){
            $top_time   = 0;
            $top_do_time= 0;
        }else{
            if(strtotime($top_time) > TIMESTAMP){
                $top_time         = strtotime($top_time);
                $top_do_time      = TIMESTAMP;
            }else{
                $top_time   = 0;
                $top_do_time= 0;
            }
        }
        $updateData = array();
        $updateData['top_status']  = $top_status;
        $updateData['top_time']    = $top_time;
        $updateData['top_do_time'] = $top_do_time;
        C::t('#tom_tclove#tom_tclove')->update($_GET['tclove_id'],$updateData);

        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edittop&tclove_id='.$_GET['tclove_id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_top_status'] .'('.$tcloveInfo['xm']. ')</th></tr>';
        $vip_id_item = array(0=>$Lang['edit_top_status_0'],1=>$Lang['edit_top_status_1']);
        tomshowsetting(true,array('title'=>$Lang['top_status'],'name'=>'top_status','value'=>$tcloveInfo['top_status'],'msg'=>$Lang['edit_vip_id_msg'],'item'=>$vip_id_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['edit_vip_time'],'name'=>'top_time','value'=>$tcloveInfo['top_time'],'msg'=>$Lang['edit_vip_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
}else if($formhash == FORMHASH && $act == 'shenheok'){

    DB::query("UPDATE ".DB::table('tom_tclove')." SET shenhe_status=1 WHERE id='{$_GET['tclove_id']}' ", 'UNBUFFERED');
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($_GET['tclove_id']);
    
    if($tcloveInfo['site_id'] == 1){
        $sitename = $tcloveConfig['plugin_name'];
    }else{
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcloveInfo['site_id']);
        $sitename = $siteInfo['name'];
    }
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);

    $shenhe = str_replace('{CONTENT}', $tcloveInfo['xm'], $Lang['template_tclove_shenhe_ok']);
    $cpmsg = $Lang['tclove_shenhe_tz_succ'];
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=info&tclove_id={$tcloveInfo['id']}");
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $sitename,
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
        }else{
            $cpmsg = $Lang['tclove_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
}else if($formhash == FORMHASH && $act == 'shenheno'){
    
    if(submitcheck('submit')){
        
        $content    = isset($_GET['content'])? addslashes($_GET['content']):'';
  
        DB::query("UPDATE ".DB::table('tom_tclove')." SET shenhe_status=3 WHERE id='{$_GET['tclove_id']}' ", 'UNBUFFERED'); 
        
        $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($_GET['tclove_id']);
        if($tcloveInfo['site_id'] == 1){
            $sitename = $tongchengConfig['plugin_name'];
        }else{
            $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcloveInfo['site_id']);
            $sitename = $siteInfo['name'];
        }
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);
        
        $shenhe = str_replace('{CONTENT}', $tcloveInfo['xm'], $Lang['template_tclove_shenhe_no']);
        $cpmsg = $Lang['tclove_shenhe_tz_succ'];
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=edit");
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $sitename,
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $content
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
            }else{
                $cpmsg = $Lang['tclove_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tclove_shenhe_fail_title'].$content.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        showformheader($modFromUrl.'&act=shenheno&tclove_id='.$_GET['tclove_id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['shenhe_no_title'] . '</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['shenhe_no_msg'],'name'=>'content','value'=>'','msg'=>''),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
    
}else if($formhash == FORMHASH && $act == 'shangjia'){
    
    DB::query("UPDATE ".DB::table('tom_tclove')." SET status=1 WHERE id='{$_GET['tclove_id']}' ", 'UNBUFFERED');    

    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
}else if($formhash == FORMHASH && $act == 'xiajia'){
    
    DB::query("UPDATE ".DB::table('tom_tclove')." SET status=2 WHERE id='{$_GET['tclove_id']}' ", 'UNBUFFERED');    

    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($formhash == FORMHASH && $act == 'is_open_1'){
    
    DB::query("UPDATE ".DB::table('tom_tclove')." SET is_open=1 WHERE id='{$_GET['tclove_id']}' ", 'UNBUFFERED');    

    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
}else if($formhash == FORMHASH && $act == 'is_open_0'){
    
    DB::query("UPDATE ".DB::table('tom_tclove')." SET is_open=0 WHERE id='{$_GET['tclove_id']}' ", 'UNBUFFERED');    

    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($formhash == FORMHASH && $act == 'close_tel_1'){
    
    DB::query("UPDATE ".DB::table('tom_tclove')." SET close_tel=1 WHERE id='{$_GET['tclove_id']}' ", 'UNBUFFERED');    

    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
}else if($formhash == FORMHASH && $act == 'close_tel_0'){
    
    DB::query("UPDATE ".DB::table('tom_tclove')." SET close_tel=0 WHERE id='{$_GET['tclove_id']}' ", 'UNBUFFERED');    

    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($formhash == FORMHASH && $act == 'visitor_visit_1'){
    
    DB::query("UPDATE ".DB::table('tom_tclove')." SET visitor_visit=1 WHERE id='{$_GET['tclove_id']}' ", 'UNBUFFERED');    

    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
}else if($formhash == FORMHASH && $act == 'visitor_visit_0'){
    
    DB::query("UPDATE ".DB::table('tom_tclove')." SET visitor_visit=0 WHERE id='{$_GET['tclove_id']}' ", 'UNBUFFERED');    

    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($formhash == FORMHASH && $act == 'import_xiangqin'){
    
    $page     = isset($_GET['page'])? intval($_GET['page']):1;
    $nextpage = $page + 1;
    
    $pagesize = 10;
    $start = ($page-1)*$pagesize;	
    
    $where = " AND is_ok = 1";
    
    $count = C::t('#tom_xiangqin#tom_xiangqin')->fetch_all_count($where);
    $allPageNum = ceil($count/$pagesize);
    
    if($page <= $allPageNum){
        
        $xiangqinListTmp  = C::t('#tom_xiangqin#tom_xiangqin')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
        $xiangqinList = array();
        if(is_array($xiangqinListTmp) && !empty($xiangqinListTmp)){
            foreach ($xiangqinListTmp as $key => $value){
                $loveInfoTmp  = C::t('#tom_love#tom_love')->fetch_by_id("{$value['user_id']}");
                $tongchenguserInfoTmp  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid("{$loveInfoTmp['openid']}");
                if($tongchenguserInfoTmp['id'] > 0 && !empty($tongchenguserInfoTmp['openid'])){
                    $tcloveInfoTmp  = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id("{$tongchenguserInfoTmp['id']}");
                    if($tcloveInfoTmp['id'] > 0){}else{
                        $auto_id = 0;
                        $autoidTmp  = C::t('#tom_tclove#tom_tclove_autoid')->fetch_all_list(""," ORDER BY id DESC ",0,1);
                        if(is_array($autoidTmp) && !empty($autoidTmp) && !empty($autoidTmp[0]['id'])){
                            if($autoidTmp[0]['id'] > 9990 && $autoidTmp[0]['id'] < 101010 ){
                                $insertData = array();
                                $insertData['id']               = 101011;
                                $insertData['add_time']         = TIMESTAMP;
                                if(C::t('#tom_tclove#tom_tclove_autoid')->insert($insertData)){
                                    $auto_id = C::t('#tom_tclove#tom_tclove_autoid')->insert_id();
                                }
                            }else{
                                $insertData = array();
                                $insertData['add_time']         = TIMESTAMP;
                                if(C::t('#tom_tclove#tom_tclove_autoid')->insert($insertData)){
                                    $auto_id = C::t('#tom_tclove#tom_tclove_autoid')->insert_id();
                                }
                            }
                        }else{
                            $insertData = array();
                            $insertData['id']               = 1011;
                            $insertData['add_time']         = TIMESTAMP;
                            if(C::t('#tom_tclove#tom_tclove_autoid')->insert($insertData)){
                                $auto_id = C::t('#tom_tclove#tom_tclove_autoid')->insert_id();
                            }
                        }
                        $user_no = '';
                        $auto_id_str = strval($auto_id);
                        if($auto_id > 101010){
                            $rand_num1 = mt_rand(1, 9);
                            $user_no.= $auto_id_str[0].$auto_id_str[1].$rand_num1;
                            $rand_num2 = mt_rand(1, 9);
                            $user_no.= $auto_id_str[2].$auto_id_str[3].$rand_num2;
                            $rand_num3 = mt_rand(1, 9);
                            $user_no.= $auto_id_str[4].$auto_id_str[5].$rand_num3;
                        }else{
                            $rand_num1 = mt_rand(1, 9);
                            $user_no.= $auto_id_str[0].$auto_id_str[1].$rand_num1;
                            $rand_num2 = mt_rand(1, 9);
                            $user_no.= $auto_id_str[2].$auto_id_str[3].$rand_num2;
                        }
                        $insertData = array();
                        $insertData['site_id']              = 1;
                        $insertData['user_id']              = $tongchenguserInfoTmp['id'];
                        $insertData['user_no']              = $user_no;
                        $insertData['xm']                   = $value['xm'];
                        $insertData['sex']                  = $value['sex'];
                        $insertData['birth_year']           = $value['birth_year'];
                        $insertData['birth_month']          = $value['birth_month'];
                        $insertData['birth_day']            = $value['birth_day'];
                        $insertData['height']               = $value['height'];
                        $insertData['weight']               = $value['weight'];
                        $insertData['xingzuo_id']           = $value['xingzuo_id'];
                        $insertData['shuxiang_id']          = $value['shuxiang_id'];
                        $insertData['xuexing_id']           = $value['xuexing_id'];
                        $insertData['minzu_id']             = $value['minzu_id'];
                        $insertData['job`']                 = $value['job'];
                        $insertData['edu_id']               = $value['edu_id'];
                        $insertData['wx`']                  = $value['wx'];
                        $insertData['qq']                   = $value['qq'];
                        $insertData['tel']                  = $value['tel'];
                        $insertData['province_id']          = $value['province_id'];
                        $insertData['city_id']              = $value['city_id'];
                        $insertData['area_id`']             = $value['area_id'];
                        $insertData['towns_id']             = $value['towns_id'];
                        $insertData['area`']                = $value['area'];
                        $insertData['hjprovince_id']        = $value['hjprovince_id'];
                        $insertData['hjcity_id']            = $value['hjcity_id'];
                        $insertData['hjarea_id']            = $value['hjarea_id'];
                        $insertData['hjtowns_id']           = $value['hjtowns_id'];
                        $insertData['hjarea`']              = $value['hjarea'];
                        $insertData['marital_id']           = $value['marital_id'];
                        $insertData['child_id`']            = $value['child_id'];
                        $insertData['shouru']               = $value['shouru'];
                        $insertData['house_id']             = $value['house_id'];
                        $insertData['che_id']               = $value['che_id'];
                        $insertData['zheou_min_age']        = $value['zheou_min_age'];
                        $insertData['zheou_max_age']        = $value['zheou_max_age'];
                        $insertData['zheou_min_height`']    = $value['zheou_min_height'];
                        $insertData['zheou_max_height']     = $value['zheou_max_height'];
                        $insertData['zheou_minzu_id']       = $value['zheou_minzu_id'];
                        $insertData['zheou_edu_id']         = $value['zheou_edu_id'];
                        $insertData['zheou_desc`']          = $value['zheou_desc'];
                        $insertData['describe']             = $value['describe'];
                        $insertData['close_tel`']           = $value['closed'];
                        $insertData['is_open']              = $value['is_open'];
                        $insertData['add_time']             = $value['add_time'];
                        $insertData['is_ok']                = $value['is_ok'];
                        $insertData['ok_time']              = $value['ok_time'];
                        $insertData['agree_safe']           = $value['agree_safe'];
                        $insertData['status']               = $value['status'];
                        $insertData['shenhe_status']        = $value['shenhe_status'];
                        $insertData['clicks']               = $value['clicks'];
                        C::t('#tom_tclove#tom_tclove')->insert($insertData);
                        $tcloveId = C::t('#tom_tclove#tom_tclove')->insert_id();

                        $xiangqinPhotoTmp = C::t('#tom_xiangqin#tom_xiangqin_photo')->fetch_all_list(" AND xiangqin_id = {$value['id']}", 'ORDER BY id DESC', 0, 100);
                        $xiangqinPhotoList = array();
                        if(is_array($xiangqinPhotoTmp) && !empty($xiangqinPhotoTmp)){
                            foreach ($xiangqinPhotoTmp as $kp => $vp){
                                $xiangqinPhotoList[$kp] = $vp;
                                if(!preg_match('/^http/', $vp['pic_url']) ){
                                    if(strpos($vp['pic_url'], 'source/plugin/tom_') === FALSE){
                                        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'common/'.$vp['pic_url'];
                                    }else{
                                        $picurl = $_G['siteurl'].$vp['pic_url'];
                                    }
                                }else{
                                    $picurl = $vp['pic_url'];
                                }

                                $picurl_content = tom_html_get($picurl);

                                $imageDir = "/source/plugin/tom_tclove/data/photo/".date("Ym")."/".date("d")."/";
                                $imageName = "source/plugin/tom_tclove/data/photo/".date("Ym")."/".date("d")."/".md5($picurl).".jpg";
                                $tomDir = DISCUZ_ROOT.'.'.$imageDir;
                                if(!is_dir($tomDir)){
                                    mkdir($tomDir, 0777,true);
                                }else{
                                    chmod($tomDir, 0777);
                                }
                                if(false !== file_put_contents(DISCUZ_ROOT.'./'.$imageName, $picurl_content)){
                                    $picurl = $imageName;
                                }

                                $insertData = array();
                                $insertData['tclove_id']            = $tcloveId;
                                $insertData['type']                 = 1;
                                $insertData['is_avatar']            = $vp['is_avatar'];
                                $insertData['pic_url']              = $picurl;
                                C::t('#tom_tclove#tom_tclove_photo')->insert($insertData);

                            }
                        }
                    }
                }
            }
        }
        $xiangqin_do_msg = str_replace("{PAGES}", $page, $Lang['upxiangqin_do_msg']);
        $xiangqin_do_msg = str_replace("{COUNT}", $allPageNum, $xiangqin_do_msg);
    
        $modDaoxiangqinListUrl = $modListUrl.'&act=import_xiangqin&page='.$nextpage.'&formhash='.FORMHASH;
        cpmsg($xiangqin_do_msg, $modDaoxiangqinListUrl, 'loadingform');
    }else{
        
        cpmsg($Lang['upxiangqin_do_success'], $modListUrl, 'succeed');
        
    }
}else if($formhash == FORMHASH && $act == 'award'){
    
    $user_id    = intval($_GET['user_id']);
    $tclove_id  = intval($_GET['tclove_id']);
    
    $tuiInfo = C::t('#tom_tclove#tom_tclove_tui')->fetch_by_user_id($user_id);
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($tclove_id);
    
    if($tcloveInfo['sex'] == 2 && $tcloveConfig['tui_new_user_girl_award'] > 0){
        $tcloveConfig['tui_new_user_award'] = $tcloveConfig['tui_new_user_girl_award'];
    }
    
    if($tcloveConfig['tui_new_user_award'] > 0 && $tcloveInfo['tui_award_status'] == 0 && $tuiInfo['id'] > 0){
        
        DB::query("UPDATE ".DB::table('tom_tclove_tui')." SET total_shouyi= total_shouyi + {$tcloveConfig['tui_new_user_award']} WHERE id='{$tuiInfo['id']}' ", 'UNBUFFERED');   
        
        update_tui_phb($user_id,$tcloveConfig['tui_new_user_award']);
        
        $insertData = array();
        $insertData['tui_id']         = $tuiInfo['id'];
        $insertData['tclove_id']      = $tclove_id;
        $insertData['type']           = 1;
        $insertData['change_shouyi']  = $tcloveConfig['tui_new_user_award'];
        $insertData['old_shouyi']     = $tuiInfo['total_shouyi'];
        $insertData['log_time']       = TIMESTAMP;
        C::t('#tom_tclove#tom_tclove_tui_shouyi_log')->insert($insertData);

        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);

        DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$tcloveConfig['tui_new_user_award']} WHERE id='{$userInfo['id']}'", 'UNBUFFERED');
        
        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['type_id']          = 2;
        $insertData['change_money']     = $tcloveConfig['tui_new_user_award'];
        $insertData['old_money']        = $userInfo['money'];
        $insertData['tag']              = lang('plugin/tom_tclove', 'love_money_log_tag');
        $insertData['beizu']            = lang('plugin/tom_tclove', 'love_money_log_tui_title');
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
        
        DB::query("UPDATE ".DB::table('tom_tclove')." SET tui_award_status=1 WHERE id='{$tclove_id}' ", 'UNBUFFERED');
        
        if($tcloveInfo['site_id'] == 1){
            $sitename = $tcloveConfig['plugin_name'];
        }else{
            $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcloveInfo['site_id']);
            $sitename = $siteInfo['name'];
        }
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);

        $shouyiText = str_replace("{NICKNAME}",$tcloveInfo['xm'], lang('plugin/tom_tclove', 'template_tclove_tui'));
        $shouyiText = str_replace("{MONEY}",$tcloveConfig['tui_new_user_award'], $shouyiText);
        
        $cpmsg = $Lang['tclove_shenhe_tz_succ'];
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=tui");
            $smsData = array(
                'first'         => $shouyiText,
                'keyword1'      => $sitename,
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
            }else{
                $cpmsg = $Lang['tclove_shenhe_tz_fail'];
            }
        }
    }

    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($formhash == FORMHASH && $act == 'change_hongniang'){
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($_GET['tclove_id']);
    
    if(submitcheck('submit')){
        
        $hongniang_id       = intval($_GET['hongniang_id']);
        
        $updateData = array();
        $updateData['hongniang_id']   = $hongniang_id;
        C::t('#tom_tclove#tom_tclove')->update($_GET['tclove_id'],$updateData);
        
        if($hongniang_id > 0){
            $insertData = array();
            $insertData['hongniang_id']      = $hongniang_id;
            $insertData['tclove_id']         = $tcloveInfo['id'];
            $insertData['renling_time_key']  = $nowDayTime;
            $insertData['renling_time']      = TIMESTAMP;
            C::t('#tom_tclove#tom_tclove_hongniang_renling_log')->insert($insertData);

            $hongninagInfo = C::t("#tom_tclove#tom_tclove_hongniang")->fetch_by_id($hongniang_id);
            $toUser = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcloveInfo['user_id']);

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($toUser['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$site_id}&mod=index");
                $renlingText = str_replace("{NICKNAME}",$tcloveInfo['xm'], lang('plugin/tom_tclove', 'template_renling_hongniang_msg_1'));
                $renlingText = str_replace("{HONGNIANGNAME}",$hongninagInfo['name'],$renlingText);
                $smsData = array(
                    'first'         => $renlingText,
                    'keyword1'      => $tcloveConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }

        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=change_hongniang&tclove_id='.$_GET['tclove_id'].'&formhash='.FORMHASH);
        showtableheader();
        $hongniangList = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_all_list(""," ORDER BY paixu ASC ,id DESC ",0,100);
        echo '<tr><th colspan="15" class="partition">' . $Lang['change_hongniang'] .'</th></tr>';
        echo '<tr><td width="100" ><b>' . $Lang['hongniang_list'] . '</b><tr></tr><td><select name="hongniang_id" >';
        echo '<option value="0">'.$Lang['change_hongniang_0'].'</option>';
        if(is_array($hongniangList) && !empty($hongniangList)){
            foreach ($hongniangList as $key => $value){
                if($value['id'] == $tcloveInfo['hongniang_id']){
                    echo  '<option value='.$value['id'].' selected>'.$value['name'].'</option>';
                }else{
                    echo  '<option value='.$value['id'].'>'.$value['name'].'</option>';
                }
            }
        }
        echo '</select></td>';
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
}else if($formhash == FORMHASH && $act == 'edit_sms_times'){
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($_GET['tclove_id']);
    if(submitcheck('submit')){
        
        $sms_times     = isset($_GET['sms_times'])? intval($_GET['sms_times']):0;
        
        $updateData = array();
        $updateData['sms_times'] = $sms_times;
        C::t('#tom_tclove#tom_tclove')->update($_GET['tclove_id'],$updateData);
        
        $insertData = array();
        $insertData['user_id']        = $tcloveInfo['user_id'];
        $insertData['old_times']      = $tcloveInfo['sms_times'];
        $insertData['change_times']   = $sms_times;
        $insertData['op_user_id']     = $tcloveInfo['user_id'];
        $insertData['op_type']        = 1;
        $insertData['op_time']        = TIMESTAMP;
        C::t('#tom_tclove#tom_tclove_pm_log')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edit_sms_times&tclove_id='.$_GET['tclove_id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_sms_times'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['sms_times'],'name'=>'sms_times','value'=>$tcloveInfo['sms_times'],'msg'=>$Lang['sms_times_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
        
        tomshownavheader();
        tomshownavli($Lang['sms_times_log_list_title'],"",true);
        tomshownavfooter();

        $smsLogList = C::t('#tom_tclove#tom_tclove_pm_log')->fetch_all_list(" AND user_id={$tcloveInfo['user_id']} "," ORDER BY id DESC ",0,100);
        showtableheader();
        echo '<tr class="header">';
        echo '<th>' . $Lang['tclove_id'] . '</th>';
        echo '<th>' . $Lang['sms_times_change_times'] . '</th>';
        echo '<th>' . $Lang['sms_times_old_times'] . '</th>';
        echo '<th>' . $Lang['sms_op_user_id'] . '</th>';
        echo '<th>' . $Lang['sms_times_op_type'] . '</th>';
        echo '<th>' . $Lang['sms_times_op_time'] . '</th>';
        echo '</tr>';

        $i = 1;
        foreach ($smsLogList as $key => $value) {
            
            $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_user_id($value['user_id']);
            $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['op_user_id']);
            echo '<tr>';
            echo '<td>' . $tcloveInfo['id'] . '</td>';
            echo '<td>' . $value['change_times'] . '</td>';
            echo '<td>' . $value['old_times'] . '</td>';
            if($value['op_type'] == 1){
                echo '<td>' . '-' . '</td>';
                echo '<td>' . $Lang['sms_op_type_1'] . '&nbsp;</td>';
            }else if($value['op_type'] == 2){
                echo '<td>' .$tongchengInfo['nickname'] .'<font color="#f70404">('.$Lang['user_id'] .':'. $value['op_user_id'] . ')</font>'.'</td>';
                echo '<td>' . $Lang['sms_op_type_2'] . '&nbsp;</td>';
            }else if($value['op_type'] == 3){
                echo '<td>' .$tongchengInfo['nickname'] .'<font color="#f70404">('.$Lang['user_id'] .':'. $value['op_user_id'] . ')</font>'.'</td>';
                echo '<td>' . $Lang['sms_op_type_3'] . '&nbsp;</td>';
            }else if($value['op_type'] == 4){
                echo '<td>' .$tongchengInfo['nickname'] .'<font color="#f70404">('.$Lang['user_id'] .':'. $value['op_user_id'] . ')</font>'.'</td>';
                echo '<td>' . $Lang['sms_op_type_4'] . '&nbsp;</td>';
            }
            echo '<td>' . dgmdate($value['op_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
            echo '</tr>';
            $i++;
        }
        showtablefooter();
    }
    
}else{
    set_list_url("tom_tclove_admin_user_list");
    
    $site_id           = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_no           = isset($_GET['user_no'])? intval($_GET['user_no']):'';
    $xm                = !empty($_GET['xm'])? addslashes($_GET['xm']):'';
    $vip_id            = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $top_status        = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $is_ok             = isset($_GET['is_ok'])? intval($_GET['is_ok']):2;
    $sex               = isset($_GET['sex'])? intval($_GET['sex']):0;
    $shenhe_status     = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $tui_award_status  = isset($_GET['tui_award_status'])? intval($_GET['tui_award_status']):2;
    $hongniang_id      = isset($_GET['hongniang_id'])? intval($_GET['hongniang_id']):0;
    $tui_id            = isset($_GET['tui_id'])? intval($_GET['tui_id']):'';
   
    $pagesize   = 15;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start      = ($page-1)*$pagesize;	
    
    $where = "";

    if($site_id > 0){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($user_no)){
        $where.= " AND user_no={$user_no} ";
    }
    if(!empty($vip_id)){
        $where.= " AND vip_id= {$vip_id}";
    }
    if(!empty($top_status)){
        if($top_status == 1){
            $where.= " AND top_status=0 ";
        }
        if($top_status == 2){
            $where.= " AND top_status=1 ";
        }
    }
    if(!empty($sex)){
        if($sex == 1){
            $where.= " AND sex=1 ";
        }
        if($sex == 2){
            $where.= " AND sex=2 ";
        }
    }
    if(!empty($shenhe_status)){
        if($shenhe_status == 2){
            $where.= " AND shenhe_status=2 ";
        }
        if($shenhe_status == 3){
            $where.= " AND shenhe_status=3 ";
        }
    }
    
    if($tui_award_status == 0){
        $where.= " AND tui_award_status=0 AND tui_id > 0 AND shenhe_status = 1 AND status = 1 AND is_ok = 1 ";
    }
   
    if(!empty($is_ok)){
        if($is_ok == 1){
            $where.= " AND is_ok=0 ";
        }
        if($is_ok == 2){
            $where.= " AND is_ok=1 ";
        }
    }
    
    if($tui_id > 0){
        $where.= " AND tui_id={$tui_id} ";
    }
    
    if($hongniang_id > 0 && $hongniang_id != 999999 ){
        $where.= " AND hongniang_id= {$hongniang_id}";
    }else if($hongniang_id == 999999){
        $where.= " AND hongniang_id= 0";
    }

    $count = C::t('#tom_tclove#tom_tclove')->fetch_all_count($where,$xm);
    $userList = C::t('#tom_tclove#tom_tclove')->fetch_all_list($where,"ORDER BY add_time DESC",$start,$pagesize,$xm);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&vip_id={$vip_id}&top_status={$top_status}&sex={$sex}&shenhe_status={$shenhe_status}&is_ok={$is_ok}&tui_award_status={$tui_award_status}&hongniang_id={$hongniang_id}&tui_id={$tui_id}";
    
    showtableheader();
    $Lang['tclove_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tclove_help_1']);
    $Lang['tclove_help_5']  = $Lang['tclove_help_5'].'<a href="'.$modBaseUrl.'&act=import_xiangqin&page=1&formhash='.FORMHASH.'">' . $Lang['tclove_help_5_msg'] . '</a>';
    $Lang['tclove_help_2']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tclove_help_2']);
    $Lang['tclove_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tclove_help_3']);
    $Lang['tclove_help_4']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tclove_help_4']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['tclove_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['tclove_help_1'] . '</li>';
    if($xiangqinFlag == 1){
        echo '<li>' . $Lang['tclove_help_5'] . '</li>';
    }
    echo '<li>' . $Lang['tclove_help_2'] . '</li>';
    if($tongchengConfig['open_yun'] == 2){
        echo '<li>' . $Lang['tclove_help_3'] . '</li>';
    }
    if($tongchengConfig['open_yun'] == 3){
        echo '<li>' . $Lang['tclove_help_4'] . '</li>';
    }
    echo '</ul></td></tr>';
    showtablefooter();
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search_list'] . '</th></tr>';
    $selected_1 = '';
    if($site_id == 1){
        $selected_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$selected_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    echo '<tr><td width="100" align="right"><b>'.$Lang['xm'].'</b></td><td><input name="xm" type="text" value="'.$xm.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['user_no'].'</b></td><td><input name="user_no" type="text" value="'.$user_no.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['user_tui_id'].'</b></td><td><input name="tui_id" type="text" value="'.$tui_id.'" size="40" /></td></tr>';
    $sex_0 = $sex_1 = $sex_2 ="";
    if($sex == 0){ $sex_0 = "selected";}
    if($sex == 1){ $sex_1 = "selected";}
    if($sex == 2){ $sex_2 = "selected";}
    echo '<tr><td width="100" align="right"><b>' . $Lang['sex'] . '</b></td><td><select name="sex" >';
    echo '<option value="0">'.$Lang['sex'].'</option>';
    echo '<option value="1" '.$sex_1.'>'.$Lang['man'].'</option>';
    echo '<option value="2" '.$sex_2.'>'.$Lang['woman'].'</option>';
    echo '</select></td></tr>';
    
    $vipList = C::t('#tom_tclove#tom_tclove_vip')->fetch_all_list(""," ORDER BY id DESC ",0,20);
    echo '<tr><td width="100" align="right"><b>' . $Lang['vip_id'] . '</b></td><td><select name="vip_id" >';
    echo '<option value="0">'.$Lang['edit_vip_id_0'].'</option>';
    if(is_array($vipList) && !empty($vipList)){
        foreach ($vipList as $key => $value){
            if($value['id'] == $vip_id){
                echo  '<option value='.$value['id'].' selected>'.$value['name'].'</option>';
            }else{
                echo  '<option value='.$value['id'].'>'.$value['name'].'</option>';
            }
        }
    }
    echo '</select></td></tr>';
    
    $top_0 = $top_1 = $top_2 ="";
    if($top_status == 0){ $top_0 = "selected";}
    if($top_status == 1){ $top_1 = "selected";}
    if($top_status == 2){ $top_2 = "selected";}
    echo '<tr><td width="100" align="right"><b>' . $Lang['top_status'] . '</b></td><td><select name="top_status" >';
    echo '<option value="0">'.$Lang['top_status'].'</option>';
    echo '<option value="1" '.$top_1.'>'.$Lang['edit_top_status_0'].'</option>';
    echo '<option value="2" '.$top_2.'>'.$Lang['edit_top_status_1'].'</option>';
    echo '</select></td></tr>';
    
    $hongniangList = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_all_list(""," ORDER BY id DESC ",0,100);
    echo '<tr><td width="100" align="right"><b>' . $Lang['hongniang_id'] . '</b></td><td><select name="hongniang_id" >';
    echo '<option value="0">'.$Lang['hongniang_id_0'].'</option>';
    if(is_array($hongniangList) && !empty($hongniangList)){
        foreach ($hongniangList as $key => $value){
            if($value['id'] == $hongniang_id){
                echo  '<option value='.$value['id'].' selected>'.$value['name'].'</option>';
            }else{
                echo  '<option value='.$value['id'].'>'.$value['name'].'</option>';
            }
        }
    }
    echo '<option value="999999">'.$Lang['hongniang_id_999999'].'</option>';
    echo '</select></td></tr>';
       
    $is_ok_1 = $is_ok_2 ="";
    if($is_ok == 1){ $is_ok_1 = "selected";}
    if($is_ok == 2){ $is_ok_2 = "selected";}
    echo '<tr><td width="100" align="right"><b>' . $Lang['is_ok'] . '</b></td><td><select name="is_ok" >';
    echo '<option value="3">'.$Lang['is_ok'].'</option>';
    echo '<option value="1" '.$is_ok_1.'>'.$Lang['is_ok_0'].'</option>';
    echo '<option value="2" '.$is_ok_2.'>'.$Lang['is_ok_1'].'</option>';
    echo '</select></td></tr>';
    
    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();
    
    $countShenheStatus2     = C::t('#tom_tclove#tom_tclove')->fetch_all_count(" AND shenhe_status = 2 ");
    $countShenheStatus3     = C::t('#tom_tclove#tom_tclove')->fetch_all_count(" AND shenhe_status = 3 ");
    $counttui_award_status0 = C::t('#tom_tclove#tom_tclove')->fetch_all_count(" AND tui_award_status = 0 AND shenhe_status = 1 AND status = 1 AND is_ok = 1 AND tui_id > 0 ");
    
    echo '<div class="order_nav">';
    echo '<a style="border-color: #f0962a;color: #f0962a;" href="'.$modBaseUrl.'&shenhe_status=2'.'">'.$Lang['usershenhe_ing'].'&nbsp;<span>('.$countShenheStatus2.')</span></a>';
    echo '<a style="border-color: #1fbf8c;color: #1fbf8c;" href="'.$modBaseUrl.'&shenhe_status=3'.'">'.$Lang['usershenhe_status_3'].'&nbsp;<span>('.$countShenheStatus3.')</span></a>';
    echo '<a style="border-color: #1f74bf;color: #1f74bf;" href="'.$modBaseUrl.'&tui_award_status=0&sheneh_status=1&status=1&is_ok=2'.'">'.$Lang['tui_award_status_0'].'&nbsp;<span>('.$counttui_award_status0.')</span></a>';
    echo '</div>';
    
    tomshownavheader();
    tomshownavli($Lang['add_user'],$manageUrl.'&mod=add',false,true);
    if($_G['uid'] == 1){
        tomshownavli($Lang['daochu'],$adminBaseUrl.'&tmod=doDao',false);
    }
    tomshownavli($Lang['xieyi_title'],$adminBaseUrl.'&tmod=common',false);
    tomshownavli($Lang['vip_title'],$adminBaseUrl.'&tmod=common',false);
    tomshownavli($Lang['sms_title'],$adminBaseUrl.'&tmod=pmMessage',false);
    tomshownavfooter();
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['user_list'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>ID</th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['xm'] . '</th>';
    echo '<th>' . $Lang['user_no'] . '</th>';
    echo '<th>' . $Lang['sex'] . '</th>';
    echo '<th>' . $Lang['age'] . '</th>';
    echo '<th>' . $Lang['vip_id'] . '</th>';
    echo '<th>' . $Lang['top_status'] . '</th>';
    echo '<th>' . $Lang['user_hongniang'] . '</th>';
    echo '<th>' . $Lang['user_tui'] . '</th>';
    echo '<th>' . $Lang['user_status'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($userList as $key => $value){
        
        $addTime = dgmdate($value['add_time'], 'Y-m-d H:i',$tomSysOffset);
        $closeName = "";
        if($value['close_tel'] == 1){
            $closeName = '<font color="#fd0d0d">'.$Lang['close'].'</font>(</font><a href="'.$modBaseUrl.'&act=close_tel_0&tclove_id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#238206">' . $Lang['open'] . '</font></a>)';
        }else{
            $closeName = '<font color="#238206">'.$Lang['open'].'</font>(</font><a href="'.$modBaseUrl.'&act=close_tel_1&tclove_id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#fd0d0d">' . $Lang['close'] . '</font></a>)';
        }
        
        $sexName = '';
        if($value['sex'] == 1){
            $sexName = $Lang['man'];
        }else if($value['sex'] == 2){
            $sexName = $Lang['woman'];
        }else{
            $sexName = '-';
        }
        
        $vipInfo = C::t('#tom_tclove#tom_tclove_vip')->fetch_by_id($value['vip_id']);
        if($value['vip_id'] < 1){
            $vip = $Lang['edit_vip_id_0'];
        }else{
            $vip = $vipInfo['name'];
        }
        
        $top = '';
        if($value['top_status'] == 0){
            $top = $Lang['edit_top_status_0'];
        }else if($value['top_status'] == 1){
            $top = $Lang['edit_top_status_1'];
        }else{
            $top = '-';
        }
        if($value['birth_year'] > 0){
            if($tcloveConfig['age_type_id'] == 1){
                $age = $nowYear - $value['birth_year'];
            }else{
                $age = $nowYear - $value['birth_year'] + 1;
            }
        }else{
            $age = '-';
        }
        $shenhe_status = '';
        if($value['shenhe_status'] == 1){
            $shenhe_status = $Lang['usershenhe_ok'];
        }else if($value['shenhe_status'] == 2){
            $shenhe_status = $Lang['usershenhe_ing'];
        }else if($value['shenhe_status'] == 3){
            $shenhe_status = $Lang['usershenhe_no'];
        }else{
            $shenhe_status = '-';
        }
        $status = '';
        if($value['status'] == 1){
            $status = $Lang['status_yes'];
        }else{
            $status = $Lang['status_no'];
        }
        $is_ok = '';
        if($value['is_ok'] == 0){
            $is_ok = '<font color="#fd0d0d">' .$Lang['is_ok_0'].'</font>';
        }else{
            $is_ok = '<font color="#238206">' .$Lang['is_ok_1'].'</font>';
        }
        $tuiInfo          = C::t('#tom_tclove#tom_tclove_tui')->fetch_by_id($value['tui_id']);
        $userInfo         = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tuiInfo['user_id']);
        $hongniangInfo    = C::t('#tom_tclove#tom_tclove_hongniang')->fetch_by_id($value['hongniang_id']);
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 0){
            if($value['site_id'] > 1){
                echo '<td>' . $siteInfo['name'] . '</td>';
            }else{
                echo '<td>' . $Lang['sites_one'] . '</td>';
            }
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $value['xm'] .'<font color="#f70404">(UID:' .$value['user_id']. ')</font></td>'; 
        echo '<td>' . $value['user_no'] . '</td>';
        echo '<td>' . $sexName . '</td>';
        echo '<td>' . $age . '</td>';
        echo '<td>' . $vip . '</td>';
        echo '<td>' . $top . '</td>';
        if($value['hongniang_id'] > 0){
            echo '<td>'.$hongniangInfo['name'].'(<a href="'.$modBaseUrl.'&act=change_hongniang&tclove_id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#f70404">' . $Lang['change_hongniang_msg'] . '</a></font>)</td>';
        }else{
            echo '<td><a href="'.$modBaseUrl.'&act=change_hongniang&tclove_id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#f70404">' . $Lang['hongniang_add'] . '</a></font></td>';
        }
        if($value['tui_id'] > 0){
            if($value['tui_award_status'] == 0 && $value['shenhe_status'] == 1 && $value['status'] == 1 &&$value['is_ok'] == 1){
                echo '<td>'.$userInfo['nickname'].'<font color="#f70404">(UID:' .$userInfo['id']. ')</font>(<a href="javascript:void(0);" onclick="award_confirm(\''.$modBaseUrl.'&act=award&user_id='.$userInfo['id'].'&tclove_id='.$value['id'].'&formhash='.FORMHASH.'\');"><font color="#f70404">' . $Lang['user_award'] . '</a></font>)</td>';
            }else{
                echo '<td>'.$userInfo['nickname'].'<font color="#f70404">(UID:' .$userInfo['id']. ')</font></td>';
            }
        }else{
            echo '<td>' .'--' . '</td>';
        }
        echo '<td style="line-height: 25px;">';
        echo $Lang['is_ok']." : ".$is_ok."<br/>";
        echo $Lang['closed']." : ".$closeName."<br/>";
        echo $Lang['is_open']." : ";
        if($value['is_open'] == 1){
            echo '<font color="#238206">' . $Lang['is_open_1'] . '</font>(</font><a href="'.$modBaseUrl.'&act=is_open_0&tclove_id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#fd0d0d">' . $Lang['is_open_0'] . '</font></a>)<br/>';
        }else{
            echo '<font color="#fd0d0d">' . $Lang['is_open_0'] . '</font>(</font><a href="'.$modBaseUrl.'&act=is_open_1&tclove_id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#238206">' . $Lang['is_open_1'] . '</font></a>)<br/>';
        }
        echo $Lang['visitor_visit']." : ";
        if($value['visitor_visit'] == 1){
            echo '<font color="#238206">' . $Lang['visitor_visit_1'] . '</font>(</font><a href="'.$modBaseUrl.'&act=visitor_visit_0&tclove_id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#fd0d0d">' . $Lang['visitor_visit_0'] . '</font></a>)<br/>';
        }else{
            echo '<font color="#fd0d0d">' . $Lang['visitor_visit_0'] . '</font>(</font><a href="'.$modBaseUrl.'&act=visitor_visit_1&tclove_id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#238206">' . $Lang['visitor_visit_1'] . '</font></a>)<br/>';
        }
        echo $Lang['shenhe_status']." : ";
        if($value['shenhe_status'] == 1){
            echo ''.$shenhe_status.'(</font><a href="'.$modBaseUrl.'&act=shenheno&tclove_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['usershenhe_no'] . '</a>)<br/>';
        }else if($value['shenhe_status'] == 2){
            echo ''.$shenhe_status.'(</font><a href="'.$modBaseUrl.'&act=shenheok&tclove_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['usershenhe_ok'] . '</a>)(<a href="'.$modBaseUrl.'&act=shenheno&tclove_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['usershenhe_no'] . '</a>)<br/>';
        }else{
            echo ''.$shenhe_status.'(</font><a href="'.$modBaseUrl.'&act=shenheok&tclove_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['usershenhe_ok'] . '</a>)<br/>';
        }
        echo $Lang['status_show']." : ";
        if($value['status'] == 1){
            echo ''.$status.'(</font><a href="'.$modBaseUrl.'&act=xiajia&tclove_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['status_no'] . '</a>)<br/>';
        }else{
            echo ''.$status.'(</font><a href="'.$modBaseUrl.'&act=shangjia&tclove_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['status_yes'] . '</a>)<br/>';
        }
        echo $Lang['add_time']." : ";
        echo '<font>' . $addTime . '</font><br/>';
        echo '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$manageUrl.'&mod=edit&tclove_id='.$value['id'].'" target="_blank">' . $Lang['edit_user'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&tmod=ufuwu&tclove_id='.$value['id'].'">' . $Lang['yonghu_title'] . '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edit_sms_times&tclove_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_sms_times'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp';
        echo '<a href="'.$modBaseUrl.'&act=editvip&tclove_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_vip_title'] . '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edittop&tclove_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_top_status'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp';
        echo '<a href="'.$adminBaseUrl.'&tmod=order&tclove_id='.$value['id'].'">' . $Lang['edit_order_title'] . '</a><br/>';
        if($_G['uid'] == 1){
            echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&tclove_id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        }
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}

function award_confirm(url){
  var r = confirm("{$Lang['makesure_award_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}