<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=talk';
$modListUrl = $adminListUrl.'&tmod=talk';
$modFromUrl = $adminFromUrl.'&tmod=talk';

$get_list_url_value = get_list_url("tom_tclove_admin_user_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
if($formhash == FORMHASH && $act == 'show'){
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box_photo li{ list-style-type: none; height: 40px; line-height: 25px; width: 40px; margin: 5px; float: left; position: relative;}
.tc_content_box_photo li i{width: 20px;height: 20px;top: 10px;left: 10px;background-image: url(source/plugin/tom_tongcheng/images/icon_play.png);background-size: contain;position: absolute;}
</style>
EOF;
    echo $csstr;
    
    $talkInfo = C::t('#tom_tclove#tom_tclove_talk')->fetch_by_id($_GET['id']);
  
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['talk_pinglun_list'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>ID</th>';
    echo '<th>' . $Lang['xm'] . '</th>';
    echo '<th>' . $Lang['talk_pinglun_content'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';

    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($talkInfo['tclove_id']);
    
    $talkPinglunList   = C::t('#tom_tclove#tom_tclove_talk_pinglun')->fetch_all_list("AND talk_id = {$_GET['id']}", "ORDER BY pinglun_time DESC",0,100);
    if(is_array($talkPinglunList) && !empty($talkPinglunList)){
        foreach ($talkPinglunList as $key => $value){
            $talkPinglunList[$key] = $value;
            $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
            echo '<tr style="background:#FCFAFA;">';
            echo '<td>' . $value['id'] . '</td>';
            echo '<td><a target="_blank" href="'.$adminBaseUrl.'&tmod=index&act=show&tclove_id='.$value['tclove_id'].'&formhash='.FORMHASH.'">' . $tcloveInfo['xm'] . '</a></td>';
            echo '<td>' . $value['content'] . '</td>';
            echo '<td>';
            echo '<a href="'.$modBaseUrl.'&act=delpinglun&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['talk_pinglun_delete'] . '</a>';
            echo '</td>';
            echo '</tr>';
            
            $talkReplyList   = C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->fetch_all_list("AND pinglun_id = {$value['id']}", "ORDER BY reply_time DESC",0,100);
            if(is_array($talkReplyList) && !empty($talkReplyList)){
                foreach ($talkReplyList as $k => $v){
                    $talkReplyList[$k] = $v;
                    echo '<tr style="background:#eaeaea;">';
                    echo '<td>-</td>';
                    echo '<td><img src="source/plugin/tom_tclove/images/talk_admin_ico.png"/ style="width:20px;height:20px;vertical-align: -5px;padding-right:5px;"><a target="_blank" href="'.$adminBaseUrl.'&tmod=index&act=show&tclove_id='.$v['tclove_id'].'&formhash='.FORMHASH.'">' . $v['user_nickname'] . '</a></td>';
                    echo '<td>' . $v['content'] . '</td>';
                    echo '<td>';
                    echo '<a href="'.$modBaseUrl.'&act=delreply&id='.$v['id'].'&formhash='.FORMHASH.'">' . $Lang['talk_reply_delete'] . '</a>';
                    echo '</td>';
                    echo '</tr>';
                }
            }
        }
    }
    showtablefooter();
}else if($formhash == FORMHASH && $act == 'shenheok'){

    DB::query("UPDATE ".DB::table('tom_tclove_talk')." SET shenhe_status=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    $talkInfo = C::t('#tom_tclove#tom_tclove_talk')->fetch_by_id($_GET['id']);
    
    $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($_GET['tclove_id']);
    
    if($tcloveInfo['site_id'] == 1){
        $sitename = $tcloveConfig['plugin_name'];
    }else{
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcloveInfo['site_id']);
        $sitename = $siteInfo['name'];
    }
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);

    $shenhe = str_replace('{CONTENT}', $talkInfo['content'], $Lang['template_tclove_talk_shenhe_ok']);
    $cpmsg = $Lang['tclove_shenhe_tz_succ'];
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=talkinfo&talk_id={$talkInfo['id']}");
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $sitename,
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
        }else{
            $cpmsg = $Lang['tclove_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
}else if($formhash == FORMHASH && $act == 'shenheno'){
    
    if(submitcheck('submit')){
        
        $content    = isset($_GET['content'])? addslashes($_GET['content']):'';
  
        DB::query("UPDATE ".DB::table('tom_tclove_talk')." SET shenhe_status=3 WHERE id='{$_GET['id']}' ", 'UNBUFFERED'); 
        
        $talkInfo = C::t('#tom_tclove#tom_tclove_talk')->fetch_by_id($_GET['id']);
        
        $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($_GET['tclove_id']);
        if($tcloveInfo['site_id'] == 1){
            $sitename = $tongchengConfig['plugin_name'];
        }else{
            $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcloveInfo['site_id']);
            $sitename = $siteInfo['name'];
        }
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcloveInfo['user_id']);
        
        $shenhe = str_replace('{CONTENT}', $talkInfo['content'], $Lang['template_tclove_talk_shenhe_no']);
        $cpmsg = $Lang['tclove_shenhe_tz_succ'];
       
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tclove&site={$tcloveInfo['site_id']}&mod=mytalkList");
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $sitename,
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $content
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
            }else{
                $cpmsg = $Lang['tclove_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcloveConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tclove_shenhe_fail_title'].$content.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        showformheader($modFromUrl.'&act=shenheno&id='.$_GET['id'].'&tclove_id='.$_GET['tclove_id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['shenhe_no_title'] . '</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['shenhe_no_msg'],'name'=>'content','value'=>'','msg'=>''),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'jingxuan'){
    
    DB::query("UPDATE ".DB::table('tom_tclove_talk')." SET is_jingxuan=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'nojingxuan'){
    
    DB::query("UPDATE ".DB::table('tom_tclove_talk')." SET is_jingxuan=0 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($formhash == FORMHASH && $act == 'del'){

    C::t('#tom_tclove#tom_tclove_talk')->delete_by_id($_GET['id']);
    C::t('#tom_tclove#tom_tclove_talk_pinglun')->delete_by_talk_id($_GET['id']);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_talk_id($_GET['id']);
    C::t('#tom_tclove#tom_tclove_talk_zan')->delete_by_talk_id($_GET['id']);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_zan')->delete_by_talk_id($_GET['id']);
    C::t('#tom_tclove#tom_tclove_photo')->delete_by_talk_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($formhash == FORMHASH && $act == 'delpinglun'){
    
    $pinglunInfo = C::t('#tom_tclove#tom_tclove_talk_pinglun')->fetch_by_id($_GET['id']);
    
    C::t('#tom_tclove#tom_tclove_talk_pinglun')->delete_by_id($_GET['id']);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_pinglun_id($_GET['id']);
    C::t('#tom_tclove#tom_tclove_talk_pinglun_zan')->delete_by_pinglun_id($_GET['id']);

    $pinglunCount = C::t('#tom_tclove#tom_tclove_talk_pinglun')->fetch_all_count(" AND talk_id={$pinglunInfo['talk_id']}");
    
    DB::query("UPDATE ".DB::table('tom_tclove_talk')." SET pinglun_count={$pinglunCount} WHERE id='{$pinglunInfo['talk_id']}' ", 'UNBUFFERED'); 
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($formhash == FORMHASH && $act == 'delreply'){

    C::t('#tom_tclove#tom_tclove_talk_pinglun_reply')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    set_list_url("tom_tclove_admin_user_list");
    
    
        $csstr = <<<EOF
<style type="text/css">
.tc_content_box_photo li{ list-style-type: none; height: 40px; line-height: 25px; width: 40px; margin: 5px; float: left; position: relative;}
.tc_content_box_photo li i{width: 20px;height: 20px;top: 10px;left: 10px;background-image: url(source/plugin/tom_tongcheng/images/icon_play.png);background-size: contain;position: absolute;}
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ list-style-type: none; height: 25px; line-height: 25px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;padding: 3px 10px;color: #6a6d6a; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
</style>
EOF;
    echo $csstr;
    
    $site_id         = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $id              = isset($_GET['id'])? intval($_GET['id']):0;
    $shenhe_status   = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $is_jingxuan     = isset($_GET['is_jingxuan'])? intval($_GET['is_jingxuan']):0;
    
    $pagesize   = 10;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start      = ($page-1)*$pagesize;	
    
    $where = "";

    if($site_id > 0){
        $where.= " AND site_id={$site_id} ";
    }
    
    if($id > 0){
        $where.= " AND id={$id} ";
    }
    
    if($shenhe_status > 0){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    
    if($is_jingxuan == 1){
        $where.= " AND is_jingxuan=0 ";
    }else if($is_jingxuan == 2){
        $where.= " AND is_jingxuan=1 ";
    }

    $count = C::t('#tom_tclove#tom_tclove_talk')->fetch_all_count($where);
    $talkList = C::t('#tom_tclove#tom_tclove_talk')->fetch_all_list($where,"ORDER BY talk_time DESC",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&shenhe_status={$shenhe_status}&is_jingxuan={$is_jingxuan}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search_talklist'] . '</th></tr>';
    $selected_1 = '';
    if($site_id == 1){
        $selected_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$selected_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    echo '<tr><td width="100" align="right"><b>'.$Lang['talk_id'].'</b></td><td><input name="id" type="text" value="'.$id.'" size="40" /></td></tr>';
    
    echo '<tr><td width="100" align="right"><b>' . $Lang['talk_is_jingxuan'] . '</b></td><td><select style="width: 260px;" name="is_jingxuan" >';
    echo '<option value="0">'.$Lang['quanbu'].'</option>';
    $is_jingxuan1_selected = $is_jingxuan2_selected = "";
    if(1 == $is_jingxuan){
        $is_jingxuan1_selected = "selected";
    }
    if(2 == $is_jingxuan){
        $is_jingxuan2_selected = "selected";
    }
    echo '<option value="1" '.$is_jingxuan1_selected.'>'.$Lang['talk_is_jingxuan_0'].'</option>';
    echo '<option value="2" '.$is_jingxuan2_selected.'>'.$Lang['talk_is_jingxuan_1'].'</option>';
    echo '</select></td></tr>';
    
    $shenhe_status_1 = $shenhe_status_2 = $shenhe_status_3 = "";
    if($shenhe_status == 1){ $shenhe_status_1 = "selected";}
    if($shenhe_status == 2){ $shenhe_status_2 = "selected";}
    if($shenhe_status == 3){ $shenhe_status_3 = "selected";}
    echo '<tr><td width="100" align="right"><b>' .$Lang['shenhe_status'] . '</b></td><td><select name="shenhe_status" >';
    echo '<option value="0">'.$Lang['shenhe_status'].'</option>';
    echo '<option value="1" '.$shenhe_status_1.'>'.$Lang['shenhe_ok'].'</option>';
    echo '<option value="2" '.$shenhe_status_2.'>'.$Lang['usershenhe_ing'].'</option>';
    echo '<option value="3" '.$shenhe_status_3.'>'.$Lang['shenhe_no'].'</option>';
    echo '</select></td></tr>';
    
    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();
  
    tomshownavheader();
    tomshownavli($Lang['pinglun_list'],$adminBaseUrl.'&tmod=pinglun',false);
    tomshownavli($Lang['pinglun_reply_list'],$adminBaseUrl.'&tmod=pinglunReply',false);
    tomshownavfooter();
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['talk_list'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>ID</th>';
    echo '<th>' . $Lang['xm'] . '</th>';
    echo '<th>' . $Lang['talk_content'] . '</th>';
    echo '<th>' . $Lang['talk_pic'] . '</th>';
    echo '<th>' . $Lang['talk_video'] . '</th>';
    echo '<th>' . $Lang['talk_status'] . '</th>';
    echo '<th>' . $Lang['talk_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($talkList as $key => $value){
        
        $talkTime = dgmdate($value['talk_time'], 'Y-m-d H:i',$tomSysOffset);
        
        $shenhe_status = '';
        if($value['shenhe_status'] == 1){
            $shenhe_status = $Lang['usershenhe_ok'];
        }else if($value['shenhe_status'] == 2){
            $shenhe_status = $Lang['usershenhe_ing'];
        }else if($value['shenhe_status'] == 3){
            $shenhe_status = $Lang['usershenhe_no'];
        }else{
            $shenhe_status = '-';
        }
        
        $tcloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
        $photoList = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list("AND type = 2 AND talk_id = {$value['id']} ", "ORDER BY id ASC",0,100);
        $videoInfo = C::t('#tom_tclove#tom_tclove_photo')->fetch_all_list("AND type = 3 AND talk_id = {$value['id']} ", "ORDER BY id ASC",0,1);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a target="_blank" href="'.$adminBaseUrl.'&tmod=index&act=show&tclove_id='.$value['tclove_id'].'&formhash='.FORMHASH.'">' . $tcloveInfo['xm'] . '</a></td>';
        echo '<td style="max-width:300px";>' . $value['content'] . '</td>';
        echo '<td>';
        if(is_array($photoList) && !empty($photoList)){
            foreach ($photoList as $k => $v){
                $photoList[$k] = $v;
                if(!preg_match('/^http/', $v['pic_url']) ){
                    if(strpos($v['pic_url'], 'source/plugin/') === FALSE){
                        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$v['pic_url'];
                    }else{
                        $picurl = $v['pic_url'];
                    }
                }else{
                    $picurl = $v['pic_url'];
                }
                $photoList[$k]['pic_url'] = $picurl;
                echo '<a style="display:inline-block;" href="'.$picurl.'" target="_blank"><img style="height:40px;width:40px;" src="' . $picurl . '"></a>&nbsp;&nbsp;';
            }
        }else{
            echo ' -- ';
        }
        echo '</td>';
        echo '<td>';
        if((is_array($videoInfo) && !empty($videoInfo)) ){
            echo '<div class="tc_content_box_photo"><ul>';
            echo '<li><a href="'.$videoInfo[0]['video_url'].'" target="_blank"><i></i><img src="'.$videoInfo[0]['pic_url'].'" width="40" height="40" /></a></li>';
            echo '</ul></div>';
        }else{
            echo ' -- ';
        }
        echo '</div></td>';
        echo '<td><div class="tc_content_box"><ul>';
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenheok&id='.$value['id'].'&tclove_id='.$value['tclove_id'].'&formhash='.FORMHASH.'">' . $Lang['usershenhe_ok']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenheno&id='.$value['id'].'&tclove_id='.$value['tclove_id'].'&formhash='.FORMHASH.'">' . $Lang['usershenhe_no']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<li><b>'.$Lang['talk_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['talk_shenhe_status_1'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 2){
            echo '<li><b>'.$Lang['talk_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['talk_shenhe_status_2'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 3){
            echo '<li><b>'.$Lang['talk_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['talk_shenhe_status_3'] . '</font>'.$sheheBtnStr.'</li>';
        }
        $jingxuanBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=jingxuan&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['talk_is_jingxuan_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=nojingxuan&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['talk_is_jingxuan_0']. '</a>)';
        if($value['is_jingxuan'] == 1 ){
            echo '<li><b>'.$Lang['talk_is_jingxuan'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['talk_is_jingxuan_1'] . '</font>'.$jingxuanBtnStr.'</li>';
        }else if($value['is_jingxuan'] == 0){
            echo '<li><b>'.$Lang['talk_is_jingxuan'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['talk_is_jingxuan_0'] . '</font>'.$jingxuanBtnStr.'</li>';
        }
        echo '</ul></div></td>';
        echo '<td>' . $talkTime . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['talk_pinglun'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}