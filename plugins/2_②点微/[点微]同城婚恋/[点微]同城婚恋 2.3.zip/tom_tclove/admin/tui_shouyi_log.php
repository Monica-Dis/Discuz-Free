<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=tui_shouyi_log';
$modListUrl = $adminListUrl.'&tmod=tui_shouyi_log';
$modFromUrl = $adminFromUrl.'&tmod=tui_shouyi_log';

$tui_id       = isset($_GET['tui_id'])? intval($_GET['tui_id']):0;

$where.= " AND tui_id={$tui_id} ";

$pagesize = 100;
$page = intval($_GET['page'])>0? intval($_GET['page']):1;
$start = ($page-1)*$pagesize;	
$count = C::t('#tom_tclove#tom_tclove_tui_shouyi_log')->fetch_all_count(" {$where} ");
$tui_shouyi_logList = C::t('#tom_tclove#tom_tclove_tui_shouyi_log')->fetch_all_list(" {$where} ","ORDER BY id DESC",$start,$pagesize);

showtableheader();
echo '<tr><th colspan="15" class="partition">' . $Lang['tui_shouyi_log'] . '</th></tr>';
echo '<tr class="header">';
echo '<th>' . $Lang['tui_shouyi_log_type'] . '</th>';
echo '<th>' . $Lang['tui_shouyi_log_source'] . '</th>';
echo '<th>' . $Lang['tui_shouyi_log_type_money'] . '</th>';
echo '<th>' . $Lang['tui_shouyi_log_time'] . '</th>';
echo '</tr>';
foreach ($tui_shouyi_logList as $key => $value){
    $tuiloveInfo = C::t('#tom_tclove#tom_tclove')->fetch_by_id($value['tclove_id']);
    echo '<tr>';
    if($value['type'] == 1){
        echo '<td>' . $Lang['tui_shouyi_log_type_1'] . '</td>';
    }else if($value['type'] == 2){
        echo '<td>' . $Lang['tui_shouyi_log_type_2'] . '</td>';
    }else if($value['type'] == 3){
        echo '<td>' . $Lang['tui_shouyi_log_type_3'] . '</td>';
    }else if($value['type'] == 4){
        echo '<td>' . $Lang['tui_shouyi_log_type_4'] . '</td>';
    }
    echo '<td>' .$tuiloveInfo['xm'].'<font color="#f70404">(ID:' .$tuiloveInfo['id'].')</font><br/></td>';
    echo '<td>' . $value['change_shouyi'] . '</td>';
    echo '<td>' . dgmdate($value['log_time'], 'Y-m-d H:i',$tomSysOffset) . '</td>';
    echo '</tr>';
}
showtablefooter();
$multi = multi($count, $pagesize, $page, $modBaseUrl);	
showsubmit('', '', '', '', $multi, false);