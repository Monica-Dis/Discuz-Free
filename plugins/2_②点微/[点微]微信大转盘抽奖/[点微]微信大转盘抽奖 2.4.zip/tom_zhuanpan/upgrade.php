<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = '';
$tom_zhuanpan_field = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_all_field();
if (!isset($tom_zhuanpan_field['open_code'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_zhuanpan')." ADD `open_code` int(11) NOT NULL DEFAULT '2';\n";
}

$tom_zhuanpan_user_field = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_all_field();
if (!isset($tom_zhuanpan_user_field['mytimes'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_zhuanpan_user')." ADD `mytimes` int(11) NOT NULL DEFAULT '0';\n";
}
if (!isset($tom_zhuanpan_user_field['mytimes_time'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_zhuanpan_user')." ADD `mytimes_time` int(11) NOT NULL DEFAULT '0';\n";
}

if(!empty($sql)){
    runquery($sql);
}
$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_tom_zhuanpan_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zp_id` int(11) DEFAULT '0',
  `no` int(11) DEFAULT '0',
  `code` varchar(255) DEFAULT NULL,
  `times` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `user_xm` varchar(255) DEFAULT NULL,
  `user_tel` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
EOF;

if(!empty($sql)){
    runquery($sql);
}

$finish = TRUE;
