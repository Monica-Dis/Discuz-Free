
$(function(){
	var bili=960/640;  
	var width=$(document).outerWidth();
	var Height=bili*width;
	console.log($(document.body).width());
	
	for(var i=0;i<$(".activity").length;i++){
		Height+=$(".activity").eq(i).outerHeight(true);
	}
	$(".login-d").css({"height":Height+"px"});
	})