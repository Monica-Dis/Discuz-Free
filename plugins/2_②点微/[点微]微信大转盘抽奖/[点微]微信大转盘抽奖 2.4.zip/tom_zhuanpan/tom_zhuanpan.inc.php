<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
session_start();
define('TPL_DEFAULT',true);
$formhash = FORMHASH;
$zhuanConfig = $_G['cache']['plugin']['tom_zhuanpan'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$prand = rand(1,1000);
$appid = trim($zhuanConfig['zhuan_appid']);
$appsecret = trim($zhuanConfig['zhuan_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
$wxJssdkConfig = $weixinClass->get_jssdk_config();

$_G['siteshareurl'] = $_G['siteurl'];

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_hosts/hosts.php') && $zhuanConfig['open_hosts'] == 1){
    include DISCUZ_ROOT.'./source/plugin/tom_hosts/hosts.php';
}
include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/link.func.php';
$prize_list = array(
    1 => lang('plugin/tom_zhuanpan','prize_ranking_1'),
    2 => lang('plugin/tom_zhuanpan','prize_ranking_2'),
    3 => lang('plugin/tom_zhuanpan','prize_ranking_3'),
    4 => lang('plugin/tom_zhuanpan','prize_ranking_4'),
    5 => lang('plugin/tom_zhuanpan','prize_ranking_5'),
    6 => lang('plugin/tom_zhuanpan','prize_ranking_6'),
    7 => lang('plugin/tom_zhuanpan','prize_ranking_7'),
    8 => lang('plugin/tom_zhuanpan','prize_ranking_8'),
    9 => lang('plugin/tom_zhuanpan','prize_ranking_9'),
);

if($_GET['mod'] == 'index'){
    include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/module/index.php';
}else if($_GET['mod'] == 'ajax'){
    include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/module/ajax.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/module/index.php';
}
