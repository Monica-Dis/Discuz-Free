<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
    exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=zj&zhuan_id='.$_GET['zhuan_id'];
$modListUrl = $adminListUrl.'&tmod=zj&zhuan_id='.$_GET['zhuan_id'];
$modFromUrl = $adminFromUrl.'&tmod=zj&zhuan_id='.$_GET['zhuan_id'];
$doDaoUrl = $_G['siteurl'].'plugin.php?id=tom_zhuanpan:daDao&zhuan_id='.$_GET['zhuan_id'];

$get_list_url_value = get_list_url("tom_zhuanpan_admin_zj_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'duihuan'){
    $updateData = array();
    $updateData['dh_status'] = 1;
    $updateData['dh_time'] = TIMESTAMP;
    C::t('#tom_zhuanpan#tom_zhuanpan_zj')->update($_GET['id'], $updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delete'){
    C::t('#tom_zhuanpan#tom_zhuanpan_zj')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    set_list_url("tom_zhuanpan_admin_zj_list");
    
    $zhuan_id = $_GET['zhuan_id'];
    $zhuanpanInfo = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_by_id($_GET['zhuan_id']);
    $pagesize = 15;
    $page = intval($_GET['page'])>0 ? intval($_GET['page']) : 1;
    $start = ($page-1)*$pagesize;
    $counts = C::t('#tom_zhuanpan#tom_zhuanpan_zj')->fetch_all_count(" AND zp_id={$zhuan_id}");
    $zjList = C::t('#tom_zhuanpan#tom_zhuanpan_zj')->fetch_all_list(" AND zp_id={$zhuan_id}", "ORDER BY zj_time DESC", $start, $pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr><th colspan="15">';
    echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'">' . $Lang['zj_list_dao'] . '(0-10000)</a>';
    if($counts > 10000){
        echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&page=2">' . $Lang['zj_list_dao'] . '(10000-20000)</a>';
    }
    if($counts > 20000){
        echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&page=3">' . $Lang['zj_list_dao'] . '(20000-30000)</a>';
    }
    if($counts > 30000){
        echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&page=4">' . $Lang['zj_list_dao'] . '(30000-40000)</a>';
    }
    if($counts > 40000){
        echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&page=5">' . $Lang['zj_list_dao'] . '(40000-50000)</a>';
    }
    echo '</th></tr>';
    echo '<tr class="header">';
    echo '<th>'. $Lang['user_xm'].'</th>';
    echo '<th>'. $Lang['user_tel'].'</th>';
    echo '<th>'. $Lang['prize_no'].'</th>';
    echo '<th>'. $Lang['prize_desc'].'</th>';
    echo '<th>'. $Lang['zj_time'].'</th>';
    echo '<th>'. $Lang['dh_time'].'</th>';
    echo '<th>'. $Lang['dh_status'].'</th>';
    echo '<th>'. $Lang['handle'].'</th>';
    $i = 1;
    foreach ($zjList as $key => $value) {
        $userInfo = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_id($value['user_id']);
        $prizeInfo = C::t('#tom_zhuanpan#tom_zhuanpan_prize')->fetch_by_id($value['prize_id']);
        echo '<tr>';
        echo '<td>'. $userInfo['xm'].'</td>';
        echo '<td>'. $userInfo['tel'].'</td>';
        echo '<td>'. $prize_list[$prizeInfo['prize_no']].'</td>';
        echo '<td>'. $prizeInfo['prize_desc'].'</td>';
        echo '<td>' . dgmdate($value['zj_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '<td>' . dgmdate($value['dh_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        if($value['dh_status'] == 1){
            echo '<td>' . $Lang['dh_status_ok'] . '</td>';
        }else{
            echo '<td>' . $Lang['dh_status_no'] . '</td>';
        }
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=duihuan&id='.$value['id'].'&zhuan_id='.$zhuan_id.'&formhash='.FORMHASH.'">' . $Lang['duihuan'] . '</a>&nbsp;|&nbsp';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delete&zhuan_id='.$zhuan_id.'&id='.$value['id'].'&formhash='.FORMHASH.'\')">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();
    $multi = multi($counts, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['make_zj_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl,$doDaoUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
    }else{
        tomshownavli($Lang['zj_list_title'],$modBaseUrl,true);
        
    }
    tomshownavfooter();
}
