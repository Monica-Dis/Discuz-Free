<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=code';
$modListUrl = $adminListUrl.'&tmod=code';
$modFromUrl = $adminFromUrl.'&tmod=code';
$doDaoUrl = $_G['siteurl'].'plugin.php?id=tom_zhuanpan:codeDaDao&zhuan_id='.$_GET['zhuan_id'];

$zhuan_id = isset($_GET['zhuan_id']) ? intval($_GET['zhuan_id']) : '';
if($_GET['act'] == 'addzd'){
    $codeList = C::t('#tom_zhuanpan#tom_zhuanpan_code')->fetch_all_list(" AND zp_id = {$zhuan_id}", " ORDER BY id DESC", 0, 1);
    $max_no = 1111;
    if(is_array($codeList) && !empty($codeList['0'])){
            $max_no = $codeList['0']['no'] + 1;
    }
    
    if(submitcheck('submit')){
        $no = intval($max_no);
        $add_num = intval($_GET['add_num']) <= 50 ? intval($_GET['add_num']) : 50;
        $times = isset($_GET['times']) ? intval($_GET['times']) : 1;
        for($i=0; $i<$add_num; $i++){
            $len = strlen($max_no);
            $inviteCode = tom_random($len, 'QWERTYUPASDFGHJKZXCVBNM');
            $code = '';
            $max_no = strval($max_no);
            for($j=0;$j<$len;$j++){
                $code.=$inviteCode[$j].$max_no[$j];
            }
            $insertData = array();
            $insertData['zp_id'] = $zhuan_id;
            $insertData['no'] = $no++;
            $insertData['code'] = $code;
            $insertData['times'] = $times;
            $insertData['type'] = 2;
            C::t('#tom_zhuanpan#tom_zhuanpan_code')->insert($insertData);
            $max_no++;
        }
        cpmsg($Lang['act_success'], $modListUrl.'&zhuan_id='.$zhuan_id, 'succeed');
    }else{
        __create_nav_html();
        showformheader($modFromUrl.'&act=addzd&zhuan_id='.$zhuan_id);
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
        
    }
    
}else if($_GET['act'] == 'addsd'){    
    $codeList = C::t('#tom_zhuanpan#tom_zhuanpan_code')->fetch_all_list(" AND zp_id = {$zhuan_id}", " ORDER BY id DESC", 0, 1);
    $max_no = 1111;
    if(is_array($codeList) && !empty($codeList['0'])){
        $max_no = $codeList['0']['no'] + 1;
    }
    if(submitcheck('submit')){
        $times = isset($_GET['times']) ? intval($_GET['times']) : 1;
        $add_code = isset($_GET['add_code']) ? addslashes($_GET['add_code']) :'';
        $codeListStr = str_replace("\r\n","{n}",trim($add_code));
        $codeListStr = str_replace("\n","{n}",$codeListStr);
        $codeListStr = explode("{n}", $codeListStr);
        foreach($codeListStr as $key => $value){
            $insertData = array();
            $insertData['zp_id'] = $zhuan_id;
            $insertData['no'] = $max_no++;
            $insertData['code'] = trim($value);
            $insertData['times'] = $times;
            $insertData['type'] = 1;
            C::t('#tom_zhuanpan#tom_zhuanpan_code')->insert($insertData);
        }
        cpmsg($Lang['act_success'], $modListUrl.'&zhuan_id='.$zhuan_id, 'succeed');
        
    }else{
        __create_nav_html();
        showformheader($modFromUrl.'&act=addsd&zhuan_id='.$zhuan_id);
        showtableheader();
        tomshowsetting(array('title'=>$Lang['code_add_code'],'name'=>'add_code','value'=>"",'msg'=>$Lang['code_add_code_msg']),"textarea");
        tomshowsetting(array('title'=>$Lang['code_add_times'],'name'=>'times','value'=>"",'msg'=>$Lang['code_add_times_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
    }
}else if($_GET['act'] == 'del' && $_GET['formhash'] == FORMHASH){  
    $code_id = isset($_GET['code_id']) ? intval($_GET['code_id']) : 0;
    C::t('#tom_zhuanpan#tom_zhuanpan_code')->delete_by_id($code_id);
    cpmsg($Lang['act_success'], $modListUrl.'&zhuan_id='.$zhuan_id, 'succeed');
}else{
    $codeType = isset($_GET['codeType']) ? addslashes($_GET['codeType']) : '';
    $code = isset($_GET['code']) ? addslashes($_GET['code']) :'';
    $times = isset($_GET['times']) ? addslashes($_GET['times']) : '';
    $type = isset($_GET['type']) ? addslashes($_GET['type']) : 0;
    $user_tel = isset($_GET['user_tel']) ? addslashes($_GET['user_tel']) : '';
    
    $where = " AND zp_id = {$zhuan_id}";
    if(!empty($codeType)){
        if($codeType == 1){
            $where .= " AND user_id != 0 AND user_xm IS NOT NULL  AND user_tel IS NOT NULL";
        }else if($codeType == 2){
            $where.= " AND user_tel IS NULL  AND user_xm IS NULL  AND user_id = 0";
        }
    }
    if(!empty($code)){
        $where.=" AND code = '{$code}'";
    }
    if(!empty($times)){
        $where.=" AND times = {$times}";
    }
    if(!empty($type)){
        $where.=" AND type = {$type}";
    }
    if(!empty($user_tel)){
        $where.=" AND user_tel = {$user_tel}";
    }

    $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
    $pagesize = 50;
    $start = ($page-1) * $pagesize;
    $codeList = C::t('#tom_zhuanpan#tom_zhuanpan_code')->fetch_all_list($where, " ORDER BY id DESC", $start, $pagesize);
    $counts = C::t('#tom_zhuanpan#tom_zhuanpan_code')->fetch_all_count($where);
    
    showformheader($modFromUrl.'&formhash='.FORMHASH.'&zhuan_id='.$zhuan_id);
    showtableheader();
    echo '<tr bgcolor="#DEEFFA"><th colspan="15"><font style="color:#2366A8; padding:0 5px; font-weight:900;">'.$Lang['code_search_su'].'</font></th></tr>';
    $codeType_1 = $codeType_2 = "";
    if($codeType == 1){ $codeType_1 = "selected";}
    if($codeType == 2){ $codeType_2 = "selected";}
    echo '<tr><td align="right">'.$Lang['code_search'].'</td><td><select name="codeType">';
    echo '<option value="0">'.$Lang['code_search_0'].'</option>';
    echo '<option value="1" '.$codeType_1.'>'.$Lang['code_search_1'].'</option>';
    echo '<option value="2" '.$codeType_2.'>'.$Lang['code_search_2'].'</option>';
    echo '</select></td></tr>';
    echo '<tr><td width="100" align="right">'.$Lang['code_search_ma'].'</td><td><input type="text" name="code" value="'.$code.'"></td></tr>';
    echo '<tr><td width="100" align="right">'.$Lang['code_search_num'].'</td><td><input type="text" name="times" value="'.$times.'"></td></tr>';
    $type_1 = $type_2 = "";
    if($type == 1){ $type_1 = "selected";}
    if($type == 2){ $type_2 = "selected";}
    echo '<tr><td align="right">'.$Lang['code_search_method'].'</td><td><select name="type">';
    echo '<option value="0">'.$Lang['code_search_method_0'].'</option>';
    echo '<option value="1" '.$type_1.'>'.$Lang['code_search_method_1'].'</option>';
    echo '<option value="2" '.$type_2.'>'.$Lang['code_search_method_2'].'</option>';
    echo '</select></td></tr>';
    echo '<tr><td width="100" align="right">'.$Lang['code_search_tel'].'</td><td><input type="text" name="user_tel" value="'.$user_tel.'"></td></tr>';
    
    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
    __create_nav_html();
    showtableheader();
    echo '<tr><th colspan="15">';
    echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&change=1">' . $Lang['code_no_list_dao'] . '(0-10000)</a>';
    if($counts > 10000){
        echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&page=2&change=1">' . $Lang['code_no_list_dao'] . '(10000-20000)</a>';
    }
    if($counts > 20000){
        echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&page=3&change=1">' . $Lang['code_no_list_dao'] . '(20000-30000)</a>';
    }
    if($counts > 30000){
        echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&page=4&change=1">' . $Lang['code_no_list_dao'] . '(30000-40000)</a>';
    }
    if($counts > 40000){
        echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&page=5&change=1">' . $Lang['code_no_list_dao'] . '(40000-50000)</a>';
    }
    
    echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&change=2">' . $Lang['code_yes_list_dao'] . '(0-10000)</a>';
    if($counts > 10000){
        echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&page=2&change=2">' . $Lang['code_yes_list_dao'] . '(10000-20000)</a>';
    }
    if($counts > 20000){
        echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&page=3&change=2">' . $Lang['code_yes_list_dao'] . '(20000-30000)</a>';
    }
    if($counts > 30000){
        echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&page=4&change=2">' . $Lang['code_yes_list_dao'] . '(30000-40000)</a>';
    }
    if($counts > 40000){
        echo '&nbsp;&nbsp;<a class="addtr" target="_blank" href="'.$doDaoUrl.'&page=5&change=2">' . $Lang['code_yes_list_dao'] . '(40000-50000)</a>';
    }
    echo '</th></tr>';
    echo '<tr class="header">';
    echo '<th>'.$Lang['code_id'].'</th>';
    echo '<th>'.$Lang['code_ma'].'</th>';
    echo '<th>'.$Lang['code_ma_num'].'</th>';
    echo '<th>'.$Lang['code_method'].'</th>';
    echo '<th>'.$Lang['code_uid'].'</th>';
    echo '<th>'.$Lang['code_xm'].'</th>';
    echo '<th>'.$Lang['code_tel'].'</th>';
    echo '<th>'.$Lang['code_add_time'].'</th>';
    echo '<th>'.$Lang['handle'].'</th>';
    echo '</tr>';
    foreach($codeList as $key => $value){
        echo '<tr>';
        echo '<td>'.$value['id'].'</td>';
        echo '<td>'.$value['code'].'</td>';
        echo '<td>'.$value['times'].'</td>';
        $type = '';
        if($value['type'] == 1){
            $type = $Lang['code_type_1'];
        }else if($value['type'] == 2){
            $type = $Lang['code_type_2'];
        }
        echo '<td>'.$type.'</td>';
        if(empty($value['user_id'])){
            $value['user_id'] = '-';
        }
        echo '<td>'.$value['user_id'].'</td>';
        echo '<td>'.$value['user_xm'].'</td>';
        echo '<td>'.$value['user_tel'].'</td>';
        if(empty($value['add_time'])){
            $value['add_time'] = '- -';
        }else{
            $value['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        }
        echo '<td>'.$value['add_time'].'</td>';
        echo '<td><a href="'.$modBaseUrl.'&code_id='.$value['id'].'&act=del&formhash='.FORMHASH.'">'.$Lang['code_delete'].'</a></td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($counts, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
}

function __create_info_html(){
    global $Lang;
    tomshowsetting(array('title'=>$Lang['code_add_num'],'name'=>'add_num','value'=>"",'msg'=>$Lang['code_add_num_msg']),"input");
    tomshowsetting(array('title'=>$Lang['code_add_times'],'name'=>'times','value'=>"",'msg'=>$Lang['code_add_times_msg']),"input");
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl,$zhuan_id;
    $modBaseUrl = $modBaseUrl."&zhuan_id=".$zhuan_id;
    tomshownavheader();
    if($_GET['act'] == 'addzd'){
        tomshownavli($Lang['code_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['code_add_zd'],"",true);
        tomshownavli($Lang['code_add_sd'],$modBaseUrl."&act=addsd",false);
    }else if($_GET['act'] == 'addsd'){
        tomshownavli($Lang['code_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['code_add_zd'],$modBaseUrl."&act=addzd",false);
        tomshownavli($Lang['code_add_sd'],"",true);
    }else{
        tomshownavli($Lang['code_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['code_add_zd'],$modBaseUrl."&act=addzd",false);
        tomshownavli($Lang['code_add_sd'],$modBaseUrl."&act=addsd",false);
    }
    tomshownavfooter();
}