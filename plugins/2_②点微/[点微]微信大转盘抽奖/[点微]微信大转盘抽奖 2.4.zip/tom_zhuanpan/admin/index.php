<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */  
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_zhuanpan#tom_zhuanpan')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add', 'enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
    }
}else if($_GET['act'] == 'edit'){  
    $zhuanpanInfo = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($zhuanpanInfo);
        C::t('#tom_zhuanpan#tom_zhuanpan')->update($zhuanpanInfo['id'], $updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($zhuanpanInfo);
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){  
    C::t('#tom_zhuanpan#tom_zhuanpan')->delete_by_id($_GET['id']);
    C::t('#tom_zhuanpan#tom_zhuanpan_log')->delete_by_zhuan_id($_GET['id']);
    C::t('#tom_zhuanpan#tom_zhuanpan_prize')->delete_by_zhuan_id($_GET['id']);
    C::t('#tom_zhuanpan#tom_zhuanpan_share')->delete_by_zhuan_id($_GET['id']);
    C::t('#tom_zhuanpan#tom_zhuanpan_user')->delete_by_zhuan_id($_GET['id']);
    C::t('#tom_zhuanpan#tom_zhuanpan_zj')->delete_by_zhuan_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'suceed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'url'){
    $zhuanpanInfo = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_by_id($_GET['id']);
    $url = "{SITEURL}plugin.php?id=tom_zhuanpan&zhuan_id=".$_GET['id'];
    $url = str_replace("{SITEURL}", $_G['siteurl'], $url);
    $url = tom_link_replace($url);
    __create_nav_html();
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' .$zhuanpanInfo['title'].'>>'. $Lang['url_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['url_title'] . '<input name="" readonly="readonly" type="text" value="'.$url.'" size="100" />' . $Lang['url_title_msg'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();
    
}else{
    $pagesize = 15;
    $page = intval($_GET['page'])>0 ? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_all_count("");
    $zhuanpanList = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_all_list("", "ORDER BY add_time DESC", $start, $pagesize);
    echo '<script src="source/plugin/tom_zhuanpan/images/admin.js"></script>';
    showtableheader();
    $Lang['zhuan_help_1'] = str_replace("{SITEURL}", $_G['siteurl'], $Lang['zhuan_help_1']);
    $Lang['zhuan_help_2'] = str_replace("{SITEURL}", $_G['siteurl'], $Lang['zhuan_help_2']);
    echo '<tr><th colspan="15" class="partition">'.$Lang['zhuan_help_title'].'</th></tr>';
    echo '<tr><td class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>'.$Lang['zhuan_help_1'].'</li>';
    echo '<li>'.$Lang['zhuan_help_2'].'</li>';
    echo '</ul></td></tr>';
    showtablefooter();
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th width="10%">'.$Lang['zhuan_id'].'</th>';
    echo '<th>'.$Lang['zhuan_title'].'</th>';
    echo '<th>'.$Lang['zhuan_start_time'].'</th>';
    echo '<th>'.$Lang['zhuan_end_time'].'</th>';
    echo '<th>'.$Lang['handle'].'</th>';
    echo '</tr>';
    $i = 1;
    foreach ($zhuanpanList as $key => $value){
        echo '<tr>';
        echo '<td>'.$value['id'].'</td>';
        echo '<td>'.$value['title'].'</td>';
        echo '<td>'.dgmdate($value['start_time'], "Y-m-d H:i", $tomSysOffset).'</td>';
        echo '<td>'.dgmdate($value['end_time'], "Y-m-d H:i", $tomSysOffset).'</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=url&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['url_title']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['zhuan_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&tmod=prize&zhuan_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['prize_list_title']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&tmod=user&zhuan_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['user_list_title']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&tmod=code&zhuan_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['code_list_title']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&tmod=zj&zhuan_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['zj_list_title']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
     $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")  
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}
function __get_post_data($infoArr = array()){
    $data = array();
    
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $type_id        = isset($_GET['type_id'])? intval($_GET['type_id']):1;
    $must_gz        = isset($_GET['must_gz'])? intval($_GET['must_gz']):1;
    $cj_times       = isset($_GET['cj_times'])? intval($_GET['cj_times']):0;
    $start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time     = strtotime($start_time);
    $end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time       = strtotime($end_time);
    $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
    $share_title    = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc     = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $guanzu_desc    = isset($_GET['guanzu_desc'])? addslashes($_GET['guanzu_desc']):'';
    $guanzu_url     = isset($_GET['guanzu_url'])? addslashes($_GET['guanzu_url']):'';
    $open_code      = isset($_GET['open_code'])? intval($_GET['open_code']):2;
    
    $share_logo = "";
    $guanzu_qrcode = '';
    if($_GET['act'] == 'add'){
        $share_logo    = tomuploadFile("share_logo");
        $guanzu_qrcode = tomuploadFile("guanzu_qrcode");
    }else if($_GET['act'] == 'edit'){
        $share_logo    = tomuploadFile("share_logo",$infoArr['share_logo']);
        $guanzu_qrcode = tomuploadFile("guanzu_qrcode", $infoArr['guauzu_qrcode']);
    }

    $data['title']        = $title;
    $data['type_id']      = $type_id;
    $data['must_gz']      = $must_gz;
    $data['cj_times']     = $cj_times;
    $data['start_time']   = $start_time;
    $data['end_time']     = $end_time;
    $data['content']      = $content;
    $data['share_logo']   = $share_logo;
    $data['share_title']  = $share_title;
    $data['share_desc']   = $share_desc;
    $data['guanzu_qrcode'] = $guanzu_qrcode;
    $data['guanzu_desc']  = $guanzu_desc;
    $data['guanzu_url']   = $guanzu_url;
    $data['open_code']   = $open_code;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'title'         => '',
        'type_id'       => 1,
        'must_gz'       => 1,
        'cj_times'      => 0,
        'start_time'    => time(),
        'end_time'      => time(),
        'pic_url'       => "",
        'content'       => "",
        'share_logo'    => "",
        'share_title'   => "",
        'share_desc'    => "",
        'guznzu_qrcode' => '',
        'guanzu_desc'    => $Lang['zhuan_guanzu_desc_value'],
        'guanzu_url'    => "",
        "open_code"     => 2,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(array('title'=>$Lang['zhuan_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['zhuan_title_msg']),"input");
    $type_id_item = array(1=>$Lang['zhuan_type_id_1'],2=>$Lang['zhuan_type_id_2']);
    tomshowsetting(array('title'=>$Lang['zhuan_type_id'],'name'=>'type_id','value'=>$options['type_id'],'msg'=>$Lang['zhuan_type_id_msg'],'item'=>$type_id_item),"radio");
    $must_gz_item = array(1=>$Lang['zhuan_must_gz_1'],2=>$Lang['zhuan_must_gz_2']);
    tomshowsetting(array('title'=>$Lang['zhuan_must_gz'],'name'=>'must_gz','value'=>$options['must_gz'],'msg'=>$Lang['zhuan_must_gz_msg'],'item'=>$must_gz_item),"radio");
    $must_open_code = array(1=>$Lang['zhuan_open_code_1'],2=>$Lang['zhuan_open_code_2']);
    tomshowsetting(array('title'=>$Lang['zhuan_open_code'],'name'=>'open_code','value'=>$options['open_code'],'msg'=>$Lang['zhuan_open_code_msg'],'item'=>$must_open_code),"radio");
    tomshowsetting(array('title'=>$Lang['zhuan_cj_times'],'name'=>'cj_times','value'=>$options['cj_times'],'msg'=>$Lang['zhuan_cj_times_msg']),"input");
    tomshowsetting(array('title'=>$Lang['zhuan_start_time'],'name'=>'start_time','value'=>$options['start_time'],'msg'=>$Lang['zhuan_start_time_msg']),"calendar");
    tomshowsetting(array('title'=>$Lang['zhuan_end_time'],'name'=>'end_time','value'=>$options['end_time'],'msg'=>$Lang['zhuan_end_time_msg']),"calendar");
    tomshowsetting(array('title'=>$Lang['zhuan_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['zhuan_content_msg']),"text");
    tomshowsetting(array('title'=>$Lang['zhuan_share_logo'],'name'=>'share_logo','value'=>$options['share_logo'],'msg'=>$Lang['zhuan_share_logo_msg']),"file");
    tomshowsetting(array('title'=>$Lang['zhuan_share_title'],'name'=>'share_title','value'=>$options['share_title'],'msg'=>$Lang['zhuan_share_title_msg']),"input");
    tomshowsetting(array('title'=>$Lang['zhuan_share_desc'],'name'=>'share_desc','value'=>$options['share_desc'],'msg'=>$Lang['zhuan_share_desc_msg']),"input");
    tomshowsetting(array('title'=>$Lang['zhuan_guanzu_qrcode'],'name'=>'guanzu_qrcode','value'=>$options['guanzu_qrcode'],'msg'=>$Lang['zhuan_guznzu_qrcode_msg']),"file");
    tomshowsetting(array('title'=>$Lang['zhuan_guanzu_desc'],'name'=>'guanzu_desc','value'=>$options['guanzu_desc'],'msg'=>$Lang['zhuan_guanzu_desc_msg']),"textarea");
    tomshowsetting(array('title'=>$Lang['zhuan_guanzu_url'],'name'=>'guanzu_url','value'=>$options['guanzu_url'],'msg'=>$Lang['zhuan_guanzu_url_msg']),"input");
    return;
}
function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['zhuan_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['zhuan_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['zhuan_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['zhuan_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['zhuan_edit'],"",true);
    }else if($_GET['act'] == 'url'){
        tomshownavli($Lang['zhuan_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['url_title'],"",true);
    }else{
        tomshownavli($Lang['zhuan_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['zhuan_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}
