<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=user&zhuan_id='.$_GET['zhuan_id'];
$modListUrl = $adminListUrl.'&tmod=user&zhuan_id='.$_GET['zhuan_id'];
$modFromUrl = $adminFromUrl.'&tmod=user&zhuan_id='.$_GET['zhuan_id'];

if($_GET['act'] == 'addzj'){
    $zhuanpan = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_by_id($_GET['zhuan_id']);
    $userInfo = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
       $insertData = array();
       $insertData = __get_post_data();
       $insertData['zp_id'] = $_GET['zhuan_id'];
       $insertData['user_id'] = $_GET['id'];
       C::t('#tom_zhuanpan#tom_zhuanpan_zj')->insert($insertData);
       cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=addzj&id='.$_GET['id'], 'enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delete'){
    C::t('#tom_zhuanpan#tom_zhuanpan_user')->delete_by_id($_GET['id']);
    C::t('#tom_zhuanpan#tom_zhuanpan_zj')->delete_by_user_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    $zhuan_id = $_GET['zhuan_id'];
    $zhuanpanInfo = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_by_id($_GET['zhuan_id']);
    
    if(!empty($_GET['item_tel'])){
        $where = " AND tel = {$_GET['item_tel']}";
    }
    $pagesize = 15;
    $page = intval($_GET['page'])>0 ? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_all_count("AND zp_id={$zhuan_id} {$where}");
    $userList = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_all_list("AND zp_id={$zhuan_id} {$where} ","ORDER BY add_time DESC", $start, $pagesize);
    
    __create_nav_html();
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><td width="100" align="right"><b>'.$Lang['search_item_no'].'</b></td><td><input name="item_tel" type="text" value="'.$_GET['item_tel'].'" size="40" /></td></tr>';
    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th width="10%">uid</th>';
    echo '<th>'. $Lang['user_xm'].'</th>';
    echo '<th>'. $Lang['user_tel'].'</th>';
    echo '<th>'. $Lang['handle'].'</th>';
    echo '</tr>';
    $i = 1;
    foreach ($userList as $key => $value) {
        echo '<tr>';
        echo '<td>'. $value['id'].'</td>';
        echo '<td>'. $value['xm'].'</td>';
        echo '<td>'. $value['tel'].'</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=addzj&id='.$value['id'].'&zhuan_id='.$zhuan_id.'&formhash='.FORMHASH.'">'.$Lang['zj_add'].'</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delete&zhuan_id='.$zhuan_id.'&id='.$value['id'].'&formhash='.FORMHASH.'\');">'.$Lang['delete'].'</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi,false );
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['make_user_del_msg']}")  
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}
function __get_post_data($infoArr = array()){
    $data = array();
    $prize_id        = isset($_GET['prize_id'])? intval($_GET['prize_id']):1;
    $zj_time       = isset($_GET['zj_time'])? addslashes($_GET['zj_time']):'';
    $zj_time       = strtotime($zj_time);
    
    $tomSysOffset = getglobal('setting/timeoffset');
    $nowDayTime = gmmktime(0,0,0,dgmdate($zj_time, 'n',$tomSysOffset),dgmdate($zj_time, 'j',$tomSysOffset),dgmdate($zj_time, 'Y',$tomSysOffset)) - $tomSysOffset*3600;
    
    $data['zp_id']          = $_GET['zhuan_id'];
    $data['prize_id']      = $prize_id;
    $data['time_id']      = $nowDayTime;
    $data['zj_time']      = $zj_time;
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$prize_list;
    $options = array(
        'prize_id'     => "",
        'zl_time'     => "",
    );
    $options = array_merge($options, $infoArr);
    
    $prizeList = C::t('#tom_zhuanpan#tom_zhuanpan_prize')->fetch_all_list(" AND zp_id={$_GET['zhuan_id']} ","ORDER BY paixu ASC",0,100);

    echo '<tr class="header"><th>'.$Lang['zj_prize'].'</th><th></th></tr>';
    echo '<tr><td width="300"><select name="prize_id">';
    foreach ($prizeList as $pk => $pv){
        echo '<option value="'.$pv['id'].'">'.$prize_list[$pv['prize_no']].'</option>';
    }
    tomshowsetting(array('title'=>$Lang['zj_time'],'name'=>'zj_time','value'=>$options['zj_time'],'msg'=>$Lang['zj_time_msg']),"calendar");
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl,$doDaoUrl;
    tomshownavheader();
    if($_GET['act'] == 'addzj'){
        tomshownavli($Lang['user_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['user_add'],"",true);
    }else{
        tomshownavli($Lang['user_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['user_add'],$modBaseUrl."&act=addzj",false);
    }
    tomshownavfooter();
}
