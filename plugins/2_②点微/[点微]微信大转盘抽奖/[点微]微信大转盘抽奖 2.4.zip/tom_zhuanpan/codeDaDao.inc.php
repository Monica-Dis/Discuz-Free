<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$zhuanpanInfo = $_G['cache']['plugin']['tom_zhuanpan'];
$zhuan_id = isset($_GET['zhuan_id'])? intval($_GET['zhuan_id']):0;
$page   = isset($_GET['page'])? intval($_GET['page']):1;
$change = isset($_GET['change']) ? intval($_GET['change']) :'';

$pagesize = 10000;
$start = ($page-1)*$pagesize;

$tomSysOffset = getglobal('setting/timeoffset');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    $where = "";
    if($change == 1){
        $where = " AND user_tel IS NULL  AND user_xm IS NULL  AND user_id = 0";
    }
    if($change == 2){
        $where = " AND user_id != 0 AND user_xm IS NOT NULL  AND user_tel IS NOT NULL";
    }
    $codeListTmp = C::t('#tom_zhuanpan#tom_zhuanpan_code')->fetch_all_list(" AND zp_id = {$zhuan_id} {$where}"," ORDER BY id DESC ",$start,$pagesize);
    
    $codeList = array();
    foreach ($codeListTmp as $key => $value) {
        $codeList[$key] = $value;
        
        if(empty($codeList[$key]['add_time'])){
            $codeList[$key]['add_time'] = '- -';
        }else{
            $codeList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        }
        
        if(empty($codeList[$key]['user_id'])){
            $codeList[$key]['user_id'] = '-';
        }
        
        if($value['type'] == 1){
            $codeList[$key]['type'] = lang('plugin/tom_zhuanpan','code_type_1');
        }else if($value['type'] == 2){
            $codeList[$key]['type'] = lang('plugin/tom_zhuanpan','code_type_2');
        }
        
    }

    $code = lang('plugin/tom_zhuanpan','code_ma');
    $times = lang('plugin/tom_zhuanpan','code_ma_num');
    $type = lang('plugin/tom_zhuanpan','code_method');
    $user_id = lang('plugin/tom_zhuanpan','code_uid');
    $user_xm = lang('plugin/tom_zhuanpan','code_xm');
    $user_tel = lang('plugin/tom_zhuanpan','code_tel');
    $add_time = lang('plugin/tom_zhuanpan','code_add_time');

    $listData[] = array($code,$times,$type,$user_id,$user_xm,$user_tel,$add_time); 
    foreach ($codeList as $v){
        $lineData = array();
        $lineData[] = $v['code'];
        $lineData[] = $v['times'];
        $lineData[] = $v['type'];
        $lineData[] = $v['user_id'];
        $lineData[] = $v['user_xm'];
        $lineData[] = $v['user_tel'];
        $lineData[] = $v['add_time'];
        $listData[] = $lineData;
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=exportZhuan.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}

