<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$zhuanpanInfo = $_G['cache']['plugin']['tom_zhuanpan'];
$zhuan_id = isset($_GET['zhuan_id'])? intval($_GET['zhuan_id']):0;
$page   = isset($_GET['page'])? intval($_GET['page']):1;

$pagesize = 10000;
$start = ($page-1)*$pagesize;

$tomSysOffset = getglobal('setting/timeoffset');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    $zjListTmp = C::t('#tom_zhuanpan#tom_zhuanpan_zj')->fetch_all_list(" AND zp_id = {$zhuan_id} "," ORDER BY id DESC ",$start,$pagesize);
    $zjList = array();
    foreach ($zjListTmp as $key => $value) {
        $userInfo = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_id($value['user_id']);
        $prizeInfo = C::t('#tom_zhuanpan#tom_zhuanpan_prize')->fetch_by_id($value['prize_id']);
        $zjList[$key]['xm'] = $userInfo['xm'];
        $zjList[$key]['tel'] = $userInfo['tel'];
        $zjList[$key]['prize_no'] = $prizeInfo['prize_no'];
        $zjList[$key]['prize_desc'] = $prizeInfo['prize_desc'];
        $zjList[$key]['zj_time'] = dgmdate($value['zj_time'],"Y-m-d H:i",$tomSysOffset);
        
        if($value['dh_status'] == 0){
            $zjList[$key]['dh_status'] = lang('plugin/tom_zhuanpan','dh_status_no');
        }else if($value['dh_status'] == 1){
            $zjList[$key]['dh_status'] = lang('plugin/tom_zhuanpan','dh_status_ok');
        }
        
    }

    $user_xm = lang('plugin/tom_zhuanpan','user_xm');
    $user_tel = lang('plugin/tom_zhuanpan','user_tel');
    $prize_no = lang('plugin/tom_zhuanpan','prize_no');
    $prize_desc = lang('plugin/tom_zhuanpan','prize_desc');
    $zj_time = lang('plugin/tom_zhuanpan','zj_time');
    $dh_status = lang('plugin/tom_zhuanpan','dh_status');

    $listData[] = array($user_xm,$user_tel,$prize_no,$prize_desc,$zj_time,$dh_status); 
    foreach ($zjList as $v){
        $lineData = array();
        $lineData[] = $v['xm'];
        $lineData[] = $v['tel'];
        $lineData[] = $v['prize_no'];
        $lineData[] = $v['prize_desc'];
        $lineData[] = $v['zj_time'];
        $lineData[] = $v['dh_status'];
        $listData[] = $lineData;
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=exportZhuan.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}

