<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$zhuan_id = isset($_GET['zhuan_id'])? intval($_GET['zhuan_id']):0;
$zhuanpanInfo = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_by_id($zhuan_id);
if(!$zhuanpanInfo){
    $zhuanpanList = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_all_list("","ORDER BY id DESC",0,1);
    $zhuanpanInfo = $zhuanpanList['0'];
    $zhuan_id = $zhuanpanInfo['id'];
}

$openid = '';
if($zhuanConfig['oauth2_check'] == 1){
    include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/oauth2.php';
}

$user_id = 0;
$bmStatus = 0;
$userInfo = array();
$mytimes = 0;
$cookieUserid = getcookie('tomwx_zhuanpan_user_zhuanid'.$zhuan_id);
if(!$cookieUserid){
    if($_SESSION['tomwx_zhuanpan_user_zhuanid'.$zhuan_id]){
        $cookieUserid = $_SESSION['tomwx_zhuanpan_user_zhuanid'.$zhuan_id];
    }
}
if($cookieUserid && $cookieUserid > 0){
    $userInfo = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_id($cookieUserid);
    if($userInfo){
        $user_id = $userInfo['id'];
        $bmStatus = 1;
        $mytimes = $userInfo['mytimes'];
    }
}else{
    if($zhuanConfig['oauth2_check'] == 1 && !empty($openid)){
        $userInfoOpenidTmp = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_zhuan_id_openid($zhuan_id,$openid);
        if($userInfoOpenidTmp){
            $lifeTime = 86400*30;
            $_SESSION['tomwx_zhuanpan_user_zhuanid'.$zhuan_id] = $userInfoOpenidTmp['id'];
            dsetcookie('tomwx_zhuanpan_user_zhuanid'.$zhuan_id,$userInfoOpenidTmp['id'],$lifeTime);
            tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_zhuanpan&mod=index&zhuan_id={$zhuan_id}&user_id={$userInfoOpenidTmp['id']}");
            exit;
        }
    }
}

if(!preg_match('/^http:/',$zhuanpanInfo['share_logo'])){
    $share_logo_url = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'common/'.$zhuanpanInfo['share_logo'];
}else{
    $share_logo_url = $zhuanpanInfo['share_logo'];
}
if(!preg_match('/^http:/',$zhuanpanInfo['guanzu_qrcode']) && !empty($zhuanpanInfo['guanzu_qrcode'])){
    $guanzu_qrcode_url = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'common/'.$zhuanpanInfo['guanzu_qrcode'];
}else{
    $guanzu_qrcode_url = $zhuanpanInfo['guanzu_qrcode'];
}

$showBthBox = 1;
if(TIMESTAMP < $zhuanpanInfo['start_time']){
    $showBthBox = 2;
}
if(TIMESTAMP > $zhuanpanInfo['end_time']){
    $showBthBox = 3;
}
$zksTime = dgmdate($zhuanpanInfo['start_time'], 'Y/m/d H:i:s');
$zjsTime = dgmdate($zhuanpanInfo['end_time'], 'Y/m/d H:i:s');
if(!empty($zhuanpanInfo['guanzu_desc'])){
    $zhuanpanInfo['guanzu_desc'] = discuzcode($zhuanpanInfo['guanzu_desc'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);
}
$zhuanContent = stripslashes($zhuanpanInfo['content']);
$zhuanpan_user_count = C::t("#tom_zhuanpan#tom_zhuanpan_user")->fetch_all_count(" AND zp_id = {$zhuan_id}");

$allTimes = $zhuanpanInfo['cj_times'];
$useTimes = 0;
$zjStatus = 0;
$syTimes = 0;
if($zhuanpanInfo['type_id'] == 1 && $user_id){
    if($userInfo && !empty($userInfo)){
        if($userInfo['mytimes_time'] != $nowDayTime){
            $updateData = array();
            $updateData['mytimes'] = 0;
            C::t('#tom_zhuanpan#tom_zhuanpan_user')->update($user_id, $updateData);
        }
    }
    $useTimes = C::t('#tom_zhuanpan#tom_zhuanpan_log')->fetch_all_count(" AND zp_id={$zhuan_id} AND user_id = {$user_id} AND time_id = {$nowDayTime}");
    $zjPrizeListTmp = C::t('#tom_zhuanpan#tom_zhuanpan_zj')->fetch_all_list(" AND zp_id = {$zhuan_id} AND user_id = {$user_id} AND time_id = {$nowDayTime} ","ORDER BY id ASC",0,50);
    if($zjPrizeListTmp){
        $zjStatus = 1;
    }
}else if ($zhuanpanInfo['type_id'] == 2 && $user_id){
    $useTimes = C::t('#tom_zhuanpan#tom_zhuanpan_log')->fetch_all_count(" AND zp_id = {$zhuan_id} AND user_id = {$user_id} ");
    $zjPrizeListTmp = C::t('#tom_zhuanpan#tom_zhuanpan_zj')->fetch_all_list(" AND zp_id = {$zhuan_id} AND user_id = {$user_id} ","ORDER BY id ASC",0,50);
    if($zjPrizeListTmp){
        $zjStatus = 1;
    }
}
if($zjStatus == 1){
    $user_prize_zj = C::t('#tom_zhuanpan#tom_zhuanpan_prize')->fetch_by_id($zjPrizeListTmp[0]['prize_id']);
    $zhuanpan_deg = $user_prize_zj['prize_no'] * 36;
}
if($zhuanpanInfo['open_code'] == 2){
    $syTimes = $allTimes - $useTimes;
}else if($zhuanpanInfo['open_code'] == 1){
    $syTimes = $allTimes - $useTimes + $mytimes;
}

if($zjStatus > 0){
    $syTimes = 0;
}

$myZjList = array();
if($user_id){
    $myZjListTmp = C::t('#tom_zhuanpan#tom_zhuanpan_zj')->fetch_all_list(" AND zp_id = {$zhuan_id} AND user_id={$user_id} "," ORDER BY id DESC ",0,50);
    if(is_array($myZjListTmp) && !empty($myZjListTmp)){
        foreach ($myZjListTmp as $key => $value){
            $prizeInfoTmp = C::t('#tom_zhuanpan#tom_zhuanpan_prize')->fetch_by_id($value['prize_id']);
            if($prizeInfoTmp['prize_status'] == 1){
                $myZjList[$key] = $value;
                $myZjList[$key]['time'] = dgmdate($value['zj_time'],"Y-m-d H:i",$tomSysOffset);
                $myZjList[$key]['prize_no'] = $prizeInfoTmp['prize_no'];
                $myZjList[$key]['prize_desc'] = $prizeInfoTmp['prize_desc'];
                $myZjList[$key]['prize_id'] = $prizeInfoTmp['id'];
            }
        }
    }
}
$mypage        = isset($_GET['mypage'])? intval($_GET['mypage']):1;
$mypagesize = 10;
$mystart = ($mypage-1)*$mypagesize;
$zjListTmp = C::t('#tom_zhuanpan#tom_zhuanpan_zj')->fetch_all_list(" AND zp_id = {$zhuan_id} "," ORDER BY id DESC ",$mystart,$mypagesize);
$zjListCount = C::t('#tom_zhuanpan#tom_zhuanpan_zj')->fetch_all_count(" AND zp_id = {$zhuan_id} ");
$zjList = array();
if(is_array($zjListTmp) && !empty($zjListTmp)){
    foreach ($zjListTmp as $key => $value){
        $userInfoTmp = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_id($value['user_id']);
        $prizeInfoTmp = C::t('#tom_zhuanpan#tom_zhuanpan_prize')->fetch_by_id($value['prize_id']);
        $zjList[$key] = $value;
        $zjList[$key]['time'] = dgmdate($value['zj_time'],"Y-m-d H:i",$tomSysOffset);
        $zjList[$key]['tel'] = substr($userInfoTmp['tel'], 0, 3)."****".substr($userInfoTmp['tel'], -4);
        $zjList[$key]['prize_desc'] = $prizeInfoTmp['prize_desc'];
    }
}
$myShowNextPage = 1;
if(($mystart + $mypagesize) >= $zjListCount){
    $myShowNextPage = 0;
}

$allPageNum = ceil($zjListCount/$mypagesize);
$myprePage = $mypage - 1;
$mynextPage = $mypage + 1;

$myShowPrvePage =1 ;
if($myprePage < 1){
    $myShowPrvePage = 0;
}
$myprePageUrl = "plugin.php?id=tom_zhuanpan&mod=index&zhuan_id={$zhuan_id}&mypage={$myprePage}";
$mynextPageUrl = "plugin.php?id=tom_zhuanpan&mod=index&zhuan_id={$zhuan_id}&mypage={$mynextPage}";


$prizeList = array();
for($i=1;$i<=9;$i++){
    $prizeList[$i] = array(
        'id'      => 0,
        'prize_no'   => lang('plugin/tom_zhuanpan','prize_kong'),
        'prize_desc'    => lang('plugin/tom_zhuanpan','prize_kong_desc'),
        'prize_num'     => 0,
        'prize_pic'     => '',
        'prize_chance'  => 0,
    );
}
$prizeList[10] = array(
        'id'      => 0,
        'prize_no'   => lang('plugin/tom_zhuanpan','prize_xinyun'),
        'prize_desc'    => lang('plugin/tom_zhuanpan','prize_xinyun_desc'),
        'prize_num'     => 0,
        'prize_pic'     => '',
        'prize_chance'  => 0,
    );
$prizeListTmp = C::t('#tom_zhuanpan#tom_zhuanpan_prize')->fetch_all_list(" AND zp_id = {$zhuan_id} ","ORDER BY prize_no ASC",0,50);
if(is_array($prizeListTmp) && !empty($prizeListTmp)){
    foreach ($prizeListTmp as $key => $value) {
        if(!preg_match('/^http:/', $value['prize_pic_url']) ){
            $prize_pic = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'common/'.$value['prize_pic_url'];
        }else{
            $prize_pic = $value['prize_pic_url'];
        }
        if(isset($prizeList[$value['prize_no']])){
            $prizeList[$value['prize_no']] = $value;
            $prizeList[$value['prize_no']]['prize_pic_url'] = $prize_pic;
        }
    }
}

$ajaxUrl = "plugin.php?id=tom_zhuanpan&mod=ajax";
$tomkey = md5($zhuanConfig['md5_key']."+++".$user_id);
$ajaxCjUrl = "plugin.php?id=tom_zhuanpan&mod=ajax&act=cj&zhuan_id={$zhuan_id}&user_id={$user_id}&tomkey={$tomkey}&formhash=".FORMHASH;
$infoUrl = "plugin.php?id=tom_zhuanpan&mod=ajax&zhuan_id={$zhuan_id}&randstr=".rand(111111, 999999);
$bmUrl = "plugin.php?id=tom_zhuanpan&mod=ajax&act=add&zhuan_id={$zhuan_id}";
$ajaxShareUrl = $_G['siteurl']."plugin.php?id=tom_zhuanpan&mod=ajax&act=share&zhuan_id={$zhuan_id}&user_id={$user_id}&formhash=".FORMHASH;

$showGuanzuBox = 0;
if(isset($_GET['from']) && !empty($_GET['from']) && $zhuanpanInfo['must_gz'] == 1 ){
    $showGuanzuBox = 1;
}
$shareTitle = $zhuanpanInfo['share_title'];
$shareDesc = $zhuanpanInfo['share_desc'];
$shareLogo = $share_logo_url;
$shareUrl = $_G['siteshareurl']."plugin.php?id=tom_zhuanpan&mod=index&zhuan_id={$zhuan_id}";
$check_r = mt_rand(1, 2);
$isGbk = false;
if(CHARSET == 'gbk') $isGbk = true;
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false && $zhuanConfig['open_in_wx'] == 1) {
    include template("tom_zhuanpan:weixin");
}else{
    include template("tom_zhuanpan:index");
}
tomoutput();