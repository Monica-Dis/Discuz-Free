<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$formhash = isset($_GET['formhash'])? daddslashes($_GET['formhash']):'';

if($_GET['act'] == 'add' && $formhash == FORMHASH){
    
    $xm = isset($_GET['username'])? daddslashes(diconv(urldecode($_GET['username']),'utf-8')):'';
    $tel = isset($_GET['tel'])? daddslashes($_GET['tel']):'';
    $zhuan_id = isset($_GET['zhuan_id'])? intval($_GET['zhuan_id']):'';
    $openid   = isset($_GET['openid'])? daddslashes(diconv(urldecode($_GET['openid']),'utf-8')):'';
    
    if(empty($xm) || empty($tel)){
        echo 404;exit;
    }
    
    $userInfo = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_zhuan_id_tel($zhuan_id,$tel);
    if($userInfo){
        if(!empty($openid) && empty($userInfo['openid'])){
            $updateData = array();
            $updateData['openid'] = $openid;
            C::t('#tom_zhuanpan#tom_zhuanpan_user')->update($userInfo['id'],$updateData);
        }
        $lifeTime = 86400*30;
        $_SESSION['tomwx_zhuanpan_user_zhuanid'.$zhuan_id] = $userInfo['id'];
        dsetcookie('tomwx_zhuanpan_user_zhuanid'.$zhuan_id,$userInfo['id'],$lifeTime);
        echo 100;exit;
    }else{
        $insertData = array();
        $insertData['zp_id']           = $zhuan_id;
        $insertData['openid']           = $openid;
        $insertData['xm']               = $xm;
        $insertData['tel']              = $tel;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_zhuanpan#tom_zhuanpan_user')->insert($insertData);
        $userInfo = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_zhuan_id_tel($zhuan_id,$tel);
        if($userInfo){
            $lifeTime = 86400*30;
            $_SESSION['tomwx_zhuanpan_user_zhuanid'.$zhuan_id] = $userInfo['id'];
            dsetcookie('tomwx_zhuanpan_user_zhuanid'.$zhuan_id,$userInfo['id'],$lifeTime);
            echo 200;exit;
        }
    }
    echo 404;exit;
}else if($_GET['act'] == 'getzj' && $formhash == FORMHASH) {
    $outArr = array(
        'status'=> 1,
    );
   
    $tel = isset($_GET['gettel'])? daddslashes($_GET['gettel']):'';
    $zhuan_id = isset($_GET['zhuan_id'])? intval($_GET['zhuan_id']):'';
    
    if(empty($tel)){
        echo json_encode($outArr); exit;
    }
    
    $userInfo = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_zhuan_id_tel($zhuan_id,$tel);
    if($userInfo){
        $lifeTime = 86400*30;
        $_SESSION['tomwx_zhuanpan_user_zhuanid'.$zhuan_id] = $userInfo['id'];
        dsetcookie('tomwx_zhuanpan_user_zhuanid'.$zhuan_id,$userInfo['id'],$lifeTime);
        $outArr['status'] = 200;
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'pwd' && $formhash == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    $zhuan_id     = isset($_GET['zhuan_id'])? intval($_GET['zhuan_id']):0;
    $zj_id      = isset($_GET['zj_id'])? intval($_GET['zj_id']):0;
    $prizepwd   = isset($_GET['prizepwd'])? daddslashes($_GET['prizepwd']):'';
    
    $zjInfo = C::t('#tom_zhuanpan#tom_zhuanpan_zj')->fetch_by_id($zj_id);
    $zhuanInfo = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_by_id($zjInfo['zp_id']);
    $userInfo = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_id($zjInfo['user_id']);
    $prizeInfo = C::t('#tom_zhuanpan#tom_zhuanpan_prize')->fetch_by_id($zjInfo['prize_id']);
    
    if($zjInfo && $zhuanInfo && $userInfo && $prizeInfo){
        if($zjInfo['dh_status'] == 0){
            if(isset($prizeInfo['prize_pwd']) && !empty($prizeInfo['prize_pwd'])){
                if($prizeInfo['prize_pwd'] == $prizepwd){
                    $updateData = array();
                    $updateData['dh_status'] = 1;
                    $updateData['dh_time'] = TIMESTAMP;
                    C::t('#tom_zhuanpan#tom_zhuanpan_zj')->update($zj_id,$updateData);
                    $outArr['status'] = 200;
                    echo json_encode($outArr); exit;
                }else{
                    $outArr['status'] = 100;
                    echo json_encode($outArr); exit;
                }
            }
        }
    }
    
    $outArr['status'] = 1;
    echo json_encode($outArr); exit;
}else if($_GET["act"] == 'share' && $formhash == FORMHASH){
    $zhuan_id = isset($_GET['zhuan_id']) ? intval($_GET['zhuan_id']) : '';
    $user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
    $userInfo = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_id($user_id);
    $zhuanInfo = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_by_id($zhuan_id);
    if($userInfo && $zhuanInfo['id'] == $userInfo['zp_id']){
        
        if($zhuanConfig['open_share_time'] == 1){
           if($zhuanInfo['type_id'] == 1){
               $shareTimes = C::t('#tom_zhuanpan#tom_zhuanpan_share')->fetch_all_count(" AND zp_id = {$zhuan_id} AND user_id = {$user_id} AND time_id = {$nowDayTime}");
               if($shareTimes < $zhuanConfig['open_share_times']){
                   C::t('#tom_zhuanpan#tom_zhuanpan_log')->delete_by_condition(" AND zp_id = {$zhuan_id} AND user_id = {$user_id} AND time_id = {$nowDayTime}");
                   $insertData = array();
                   $insertData['zp_id'] = $zhuan_id;
                   $insertData['user_id'] = $user_id;
                   $insertData['share_time'] = TIMESTAMP;
                   $insertData['time_id'] = $nowDayTime;
                   C::t('#tom_zhuanpan#tom_zhuanpan_share')->insert($insertData);
               }
            }else if($zhuanInfo['type_id'] == 2){
                $shareTimes = C::t('#tom_zhuanpan#tom_zhuanpan_share')->fetch_all_count(" AND zp_id = {$zhuan_id} AND user_id = {$user_id}");
                if($shareTimes < $zhuanConfig['open_share_times']){
                    C::t('#tom_zhuanpan#tom_zhuanpan_log')->delete_by_condition(" AND zp_id = {$zhuan_id} AND user_id = {$user_id}");
                    $insertData = array();
                    $insertData['zp_id'] = $zhuan_id;
                    $insertData['user_id'] = $user_id;
                    $insertData['share_time'] = TIMESTAMP;
                    $insertData['time_id'] = $nowDayTime;
                    C::t('#tom_zhuanpna#tom_zhuanpan_share')->insert($insertData);
                }
            }  
        }
    }
    echo 1;exit;
    
}else if($_GET['act'] == 'cj' && $formhash == FORMHASH) { 
    
    $_SESSION['tomhash'] = 0;
    $outArr = array(
        'status'=> 1,
        'prize' => 10,
    );
    $zhuan_id = isset($_GET['zhuan_id'])? intval($_GET['zhuan_id']):0;
    $user_id = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $tomkey   = isset($_GET['tomkey'])? daddslashes($_GET['tomkey']):'';
    
    $userInfo = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_id($user_id);
    $zhuanInfo = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_by_id($zhuan_id);
    if(!$zhuanInfo){
        echo json_encode($outArr); exit;
    }
    $tomkeyCheck = md5($zhuanConfig['md5_key']."+++".$user_id);
    if($tomkeyCheck != $tomkey){
        $outArr['status'] = 404;
        echo json_encode($outArr); exit;
    }
    if(TIMESTAMP > $zhuanInfo['end_time']){
        $outArr['status'] = 301;
        echo json_encode($outArr); exit;
    }
    if(TIMESTAMP < $zhuanInfo['start_time']){
        $outArr['status'] = 302;
        echo json_encode($outArr); exit;
    }
    # IP
    $zhuanConfig['xz_area_id'] = trim($zhuanConfig['xz_area_id']);
    $xzArea = 1;
    if($zhuanConfig['open_area_ip'] == 1){
        $ipdata = file_get_contents("http://ip.taobao.com/service/getIpInfo.php?ip=".$_G['clientip']);
        $ipInfo = json_decode($ipdata, true);
        if(is_array($ipInfo) && $ipInfo['code'] == 0){
            if($zhuanConfig['xz_area_type'] == 1){
                if($ipInfo['data']['region_id'] != $zhuanConfig['xz_area_id']){
                    $xzArea = 0;
                    $outArr['status'] = 303;
                    echo json_encode($outArr); exit;
                }
            }else if($zhuanConfig['xz_area_type'] == 2){
                if($ipInfo['data']['city_id'] != $zhuanConfig['xz_area_id']){
                    $xzArea = 0;
                    $outArr['status'] = 303;
                    echo json_encode($outArr); exit;
                }
            }
        }else{
            $xzArea = 0;
            $outArr['status'] = 304;
            echo json_encode($outArr); exit;
        }
    }
    # IP
    $allTimes = $zhuanInfo['cj_times'];
    $useTimes = 0;
    $zjStatus = 0;
    if($zhuanInfo['type_id'] == 1 && $user_id){
        $useTimes = C::t('#tom_zhuanpan#tom_zhuanpan_log')->fetch_all_count(" AND zp_id = {$zhuan_id} AND user_id = {$user_id} AND time_id = {$nowDayTime} ");
        
        $zjPrizeListTmp = C::t('#tom_zhuanpan#tom_zhuanpan_zj')->fetch_all_list(" AND zp_id = {$zhuan_id} AND user_id = {$user_id} AND time_id = {$nowDayTime} ","ORDER BY id ASC",0,50);
        if($zjPrizeListTmp){
            $zjStatus = 1;
        }
    }else if ($zhuanInfo['type_id'] == 2 && $user_id){
        $useTimes = C::t('#tom_zhuanpan#tom_zhuanpan_log')->fetch_all_count(" AND zp_id = {$zhuan_id} AND user_id = {$user_id} ");
        $zjPrizeListTmp = C::t('#tom_zhuanpan#tom_zhuanpan_zj')->fetch_all_list(" AND zp_id = {$zhuan_id} AND user_id = {$user_id} ","ORDER BY id ASC",0,50);
        if($zjPrizeListTmp){
            $zjStatus = 1;
        }
     
    }
    if($zjStatus){
        $outArr['status'] = 305;
        echo json_encode($outArr); exit;
    }

    
    if($useTimes >= ($allTimes + $userInfo['mytimes'])){
        $outArr['status'] = 306;
        echo json_encode($outArr); exit;
    }

    $prizeList = array();
    for($i=1;$i<=9;$i++){
        $prizeList[$i] = array(
            'prize_no'   => lang('plugin/tom_zhuanpan','prize_xinyun'),
            'prize_desc'    => lang('plugin/tom_zhuanpan','prize_xinyun_desc'),
            'prize_num'     => 0,
            'prize_pic'     => '',
            'prize_chance'  => 0,
        );
    }
    $prizeListTmp = C::t('#tom_zhuanpan#tom_zhuanpan_prize')->fetch_all_list(" AND zp_id = {$zhuan_id} AND prize_status = 1 ","ORDER BY prize_no ASC",0,50);
   
    if(is_array($prizeListTmp) && !empty($prizeListTmp)){
        foreach ($prizeListTmp as $key => $value) {
            if(isset($prizeList[$value['prize_no']])){
                $prizeList[$value['prize_no']] = $value;
                if(!preg_match('/^http:/',$prizeList[$value['prize_no']]['prize_pic_url']) && !empty($prizeList[$value['prize_no']]['prize_pic_url']) ){
                    $prizeList[$value['prize_no']]['prize_pic_url'] = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'common/'.$prizeList[$value['prize_no']]['prize_pic_url'];
                }else{
                    $prizeList[$value['prize_no']]['prize_pic_url'] = $prizeList[$value['prize_no']]['prize_pic_url'];
                }
            }
        }
    }
    
    $prizeArr = array();
    foreach ($prizeList as $key => $value){
        if($value['prize_chance'] !== 0 && $value['prize_num']>0 ){
            $prizeArr[$key] = $value['prize_chance'];
        }
    }
    
    $prizeArr[10] = 10000 - array_sum($prizeArr);
    if($prizeArr[10] < 0){
        $prizeArr[10] = 0;
    }
    $randPrize = get_rand($prizeArr);
    if($randPrize <=10 && $randPrize>=1){ 
        if( $prizeList[$randPrize]['id']  && $prizeList[$randPrize]['prize_num'] > 0  && $prizeList[$randPrize]['prize_chance'] != 0){
            $insertData = array();
            $insertData['zp_id']     = $zhuan_id;
            $insertData['user_id']         = $user_id;
            $insertData['prize_id']        = $prizeList[$randPrize]['id'];
            $insertData['zj_time']         = TIMESTAMP;
            $insertData['time_id']         = $nowDayTime;
            C::t('#tom_zhuanpan#tom_zhuanpan_zj')->insert($insertData);
            
            $updateData = array();
            $updateData['prize_num']       = $prizeList[$randPrize]['prize_num']-1;
            C::t('#tom_zhuanpan#tom_zhuanpan_prize')->update($prizeList[$randPrize]['id'],$updateData);
            
            $insertData = array();
            $insertData['zp_id']     = $zhuan_id;
            $insertData['user_id']         = $user_id;
            $insertData['log_time']        = TIMESTAMP;
            $insertData['time_id']         = $nowDayTime;
            C::t('#tom_zhuanpan#tom_zhuanpan_log')->insert($insertData);
            
        }else{
            $insertData = array();
            $insertData['zp_id']     = $zhuan_id;
            $insertData['user_id']         = $user_id;
            $insertData['log_time']        = TIMESTAMP;
            $insertData['time_id']         = $nowDayTime;
            C::t('#tom_zhuanpan#tom_zhuanpan_log')->insert($insertData);
            
            $randPrize = 10;
        }
        
        $outArr = array(
            'status'    => 200,
            'prize'     => $randPrize,
        );
    }
    
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'code' && $formhash == FORMHASH){
    $user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : '';
    $zhuan_id = isset($_GET['zhuan_id']) ? intval($_GET['zhuan_id']) : '';
    $code = isset($_GET['code']) ? daddslashes($_GET['code']) : '';
    
    $zhuanpanInfo = C::t('#tom_zhuanpan#tom_zhuanpan')->fetch_by_id($zhuan_id);
    $codeInfo = C::t('#tom_zhuanpan#tom_zhuanpan_code')->fetch_all_list(" AND code = '{$code}' AND zp_id = {$zhuan_id}" , "ORDER BY id DESC", 0, 1);
    $userInfo = C::t('#tom_zhuanpan#tom_zhuanpan_user')->fetch_by_id($user_id);

    if(!$zhuanpanInfo || $zhuanpanInfo['open_code'] != 1){
        echo '202';exit;
    }
    if($codeInfo && isset($codeInfo['0']) && empty($codeInfo['0']['user_id'])){
        $updateData = array();
        $updateData['user_id'] = $user_id;
        $updateData['user_xm'] = $userInfo['xm'];
        $updateData['user_tel'] = $userInfo['tel'];
        $updateData['add_time'] = TIMESTAMP;
        C::t('#tom_zhuanpan#tom_zhuanpan_code')->update($codeInfo['0']['id'], $updateData);
        $updateData = array();
        $updateData['mytimes'] = $codeInfo['0']['times'] + $userInfo['mytimes'];
        $updateData['mytimes_time'] = $nowDayTime;
        C::t('#tom_zhuanpan#tom_zhuanpan_user')->update($user_id, $updateData);
        
        echo '200';exit;
    }else{
        echo '201';exit;
    }
    
}else{
        exit('Access Denied 101');
}

function get_rand($dataArr){ 
    $result = ''; 
    $dataSum = array_sum($dataArr); 
    $randNum = mt_rand(1, 10000); 
    foreach ($dataArr as $key => $dataCur) { 
        $nextSum = $dataSum-$dataCur;
        if($nextSum < $randNum && $randNum <= $dataSum) { 
            $result = $key; 
            break; 
        }
        $dataSum -= $dataCur;                     
    } 
    unset ($dataArr); 
    return $result; 
}
