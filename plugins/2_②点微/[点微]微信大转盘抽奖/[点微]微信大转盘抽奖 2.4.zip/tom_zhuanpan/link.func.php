<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function tomoutput(){
    if(file_exists(DISCUZ_ROOT."./source/plugin/tom_link/data/rule.php")){
        $tom_link_rule = include DISCUZ_ROOT."./source/plugin/tom_link/data/rule.php";
        if(isset($tom_link_rule['tom_zhuanpan'])){
            $content = ob_get_contents();
            $content = str_replace("plugin.php?id=tom_zhuanpan", $tom_link_rule['tom_zhuanpan']['rk']."?id=".$tom_link_rule['tom_zhuanpan']['bs'], $content);
            ob_end_clean();
            $_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
            echo $content;
        }
    }
    exit;
}

function tomheader($string){
    if(file_exists(DISCUZ_ROOT."./source/plugin/tom_link/data/rule.php")){
        $tom_link_rule = include DISCUZ_ROOT."./source/plugin/tom_link/data/rule.php";
        if(isset($tom_link_rule['tom_zhuanpan'])){
            $string = str_replace("plugin.php?id=tom_zhuanpan", $tom_link_rule['tom_zhuanpan']['rk']."?id=".$tom_link_rule['tom_zhuanpan']['bs'], $string);
        }
    }
    dheader($string);
    
    return;
}

function tom_link_replace($string){
    if(file_exists(DISCUZ_ROOT."./source/plugin/tom_link/data/rule.php")){
        $tom_link_rule = include DISCUZ_ROOT."./source/plugin/tom_link/data/rule.php";
        if(isset($tom_link_rule['tom_zhuanpan'])){
            $string = str_replace("plugin.php?id=tom_zhuanpan", $tom_link_rule['tom_zhuanpan']['rk']."?id=".$tom_link_rule['tom_zhuanpan']['bs'], $string);
        }
    }
    return $string;
}

