<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$LangTmp = $scriptlang['tom_zhuanpan'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_zhuanpan&pmod=admin';
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_zhuanpan&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do='.$pluginid.'&identifier=tom_zhuanpan&pmod=admin';
$tomSysOffset = getglobal('setting/timeoffset');
include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/tom.func.php';
include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/link.func.php';
$Lang  = array();
if(is_array($LangTmp) && !empty($LangTmp)){
    foreach ($LangTmp as $key => $value){
        $Lang[$key] = htmlspecialchars_decode($value);
    }
}
$prize_list = array(
    1 => $Lang['prize_ranking_1'],
    2 => $Lang['prize_ranking_2'],
    3 => $Lang['prize_ranking_3'],
    4 => $Lang['prize_ranking_4'],
    5 => $Lang['prize_ranking_5'],
    6 => $Lang['prize_ranking_6'],
    7 => $Lang['prize_ranking_7'],
    8 => $Lang['prize_ranking_8'],
    9 => $Lang['prize_ranking_9'],
);
if($_GET['tmod'] == 'index') {
    include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/admin/index.php';
}else if($_GET['tmod'] == 'prize'){
    include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/admin/prize.php';
}else if($_GET['tmod'] == 'user'){
    include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/admin/user.php';
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/admin/addon.php';
}else if($_GET['tmod'] == 'user'){
    include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/admin/user.php';
}else if($_GET['tmod'] == 'zj'){
    include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/admin/zj.php';
}else if($_GET['tmod'] == 'code'){
    include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/admin/code.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_zhuanpan/admin/index.php';
}
