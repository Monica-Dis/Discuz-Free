<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_print_admin_index_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_print#tom_print')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $printInfo = C::t('#tom_print#tom_print')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($printInfo);
        C::t('#tom_print#tom_print')->update($printInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($printInfo);
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_print#tom_print')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_print_admin_index_list");
    
    $page   = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    
    $order = "ORDER BY id DESC";
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_print#tom_print')->fetch_all_count($where);
    $printList  = C::t('#tom_print#tom_print')->fetch_all_list($where,$order,$start,$pagesize);

    showtableheader();
    $Lang['index_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_1']);
    $Lang['index_help_2']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_2']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_1_a'] . '<a target="_blank" href="http://www.tomwx.cn/index.php?m=help&t=plugin&pluginid=tom_print"><font color="#FF0000"><b>' . $Lang['index_help_1_b'] . '</b></font></a></li>';
    echo '<li>' . $Lang['index_help_2'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();

    $modBasePageUrl = $modBaseUrl;
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['index_name'] . '</th>';
    echo '<th>' . $Lang['index_tcshop_id'] . '</th>';
    echo '<th>' . $Lang['index_size_type'] . '</th>';
    echo '<th>' . $Lang['index_feie_pr_sn'] . '</th>';
    echo '<th>' . $Lang['index_status'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    $i = 1;
    foreach ($printList as $key => $value) {
        
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $tcshopInfoTmp['name'].' <font color="#fd0d0d">(ID:'.$tcshopInfoTmp['id'].')' . '</font></td>';
        echo '<td>' . $printSizeArr[$value['size_type']]['name'] . '</td>';
        echo '<td>' . $value['feie_pr_sn'] . '</td>';
        if($value['status'] == 1){
            echo '<td><font color="#238206">' . $Lang['index_status_1'] . '</font></td>';
        }else{
            echo '<td><font color="#fd0d0d">' . $Lang['index_status_0'] . '</font></td>';
        }
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d",$tomSysOffset) . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'">' . $Lang['edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a><br/>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tcshop_id      = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $size_type      = isset($_GET['size_type'])? intval($_GET['size_type']):0;
    $feie_pr_sn     = isset($_GET['feie_pr_sn'])? addslashes($_GET['feie_pr_sn']):'';
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    
    $data['name']           = $name;
    $data['tcshop_id']      = $tcshop_id;
    $data['size_type']      = $size_type;
    $data['feie_pr_sn']     = $feie_pr_sn;
    $data['status']         = $status;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$printSizeArr;
    $options = array(
        'name'          => '',
        'tcshop_id'     => '',
        'size_type'     => 1,
        'feie_pr_sn'    => '',
        'status'        => 1,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['index_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['index_tcshop_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['index_name_msg']),"input");
    $size_type_item = array(1=>$printSizeArr[1]['name'],2=>$printSizeArr[2]['name']);
    tomshowsetting(true,array('title'=>$Lang['index_size_type'],'name'=>'size_type','value'=>$options['size_type'],'msg'=>$Lang['index_size_type_msg'],'item'=>$size_type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_feie_pr_sn'],'name'=>'feie_pr_sn','value'=>$options['feie_pr_sn'],'msg'=>$Lang['index_feie_pr_sn_msg']),"input");
    $status_item = array(1=>$Lang['index_status_1'],0=>$Lang['index_status_0']);
    tomshowsetting(true,array('title'=>$Lang['index_status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['index_status_msg'],'item'=>$status_item),"radio");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',false);
        tomshownavli($Lang['edit'],$modBaseUrl.'&act=edit',true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',false);
    }
    tomshownavfooter();
}