<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';


if($_GET['act'] == 'add'){
}else{
    
    $order_no       = isset($_GET['order_no'])? addslashes($_GET['order_no']):'';
    $print_sn       = isset($_GET['print_sn'])? addslashes($_GET['print_sn']):'';
    $print_status   = isset($_GET['print_status'])? intval($_GET['print_status']):0;
    
    $page   = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($order_no)){
        $where.= " AND order_no='{$order_no}'  ";
    }
    if(!empty($print_sn)){
        $where.= " AND print_sn='{$print_sn}'  ";
    }
    if(!empty($print_status)){
        $where.= " AND print_status={$print_status}  ";
    }
    
    $order = "ORDER BY id DESC";
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_print#tom_print_log')->fetch_all_count($where);
    $logList  = C::t('#tom_print#tom_print_log')->fetch_all_list($where,$order,$start,$pagesize);

    showtableheader();
    $Lang['log_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['log_help_1']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['log_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['log_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();

    $modBasePageUrl = $modBaseUrl;
    
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['log_search_title'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['log_order_no'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="order_no" value="'.$order_no.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['log_print_sn'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="print_sn" value="'.$print_sn.'"></td></tr>';
    $log_print_status_1 = $log_print_status_0 = '';
    if($print_status == 1){
        $log_print_status_1 = 'selected';
    }else if($print_status == 2){
        $log_print_status_0 = 'selected';
    }
    $printStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['log_print_status'].'</b></td>';
    $printStatusStr.= '<td><select style="width: 260px;" name="print_status" id="print_status">';
    $printStatusStr.=  '<option value="0">'.$Lang['log_print_status'].'</option>';
    $printStatusStr.=  '<option value="1" '.$log_print_status_1.'>'.$Lang['log_print_status_1'].'</option>';
    $printStatusStr.=  '<option value="2" '.$log_print_status_0.'>'.$Lang['log_print_status_0'].'</option>';
    $printStatusStr.= '</select></td></tr>';
    echo $printStatusStr;
    showsubmit('submit', 'submit');
    showtablefooter();
    showformfooter();
    
    tomshownavheader();
    tomshownavli($Lang['log_list_title'],$modBaseUrl,true);
    tomshownavfooter();
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['log_plugin_id'] . '</th>';
    echo '<th>' . $Lang['log_order_no'] . '</th>';
    echo '<th>' . $Lang['log_print_name'] . '</th>';
    echo '<th>' . $Lang['log_print_sn'] . '</th>';
    echo '<th>' . $Lang['log_print_status'] . '</th>';
    echo '<th>' . $Lang['log_print_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($logList as $key => $value) {
        
        echo '<tr>';
        if($value['plugin_id'] == 'tom_tcqianggou'){
            echo '<td>' . $Lang['log_plugin_tcqianggou'] . '</td>';
        }else if($value['plugin_id'] == 'tom_tcmall'){
            echo '<td>' . $Lang['log_plugin_tcmall'] . '</td>';
        }else if($value['plugin_id'] == 'tom_tcptuan'){
            echo '<td>' . $Lang['log_plugin_tcptuan'] . '</td>';
        }
        echo '<td>' . $value['order_no'] . '</td>';
        if(!empty($value['print_name'])){
            echo '<td>' . $value['print_name'] . '</td>';
        }else{
            echo '<td>-</td>';
        }
        if(!empty($value['print_sn'])){
            echo '<td>' . $value['print_sn'] . '</td>';
        }else{
            echo '<td>-</td>';
        }
        if($value['print_status'] == 1){
            echo '<td><font color="#238206">' . $Lang['log_print_status_1'] . '</font></td>';
        }else{
            echo '<td><font color="#fd0d0d">' . $Lang['log_print_status_0'] . '</font></td>';
        }
        echo '<td>' . dgmdate($value['print_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td style="line-height: 25px;">';
        if($value['print_status'] == 1){
            echo '-';
        }else{
            echo '<a href="plugin.php?id=tom_print:auto&log_id='.$value['id'].'" target="_blank">' . $Lang['log_print_btn']. '</a>';
        }
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
}