<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('FEIEYUN_PR_USER', $_G['cache']['plugin']['tom_print']['feieyun_user']);	//*����*���ɶ��ƺ�̨ע���˺�
define('FEIEYUN_PR_UKEY', $_G['cache']['plugin']['tom_print']['feieyun_ukey']);	//*����*: �ɶ���ע���˺ź����ɵ�UKEY
define('FEIEYUN_PR_STIME', time());			    //��������������ʱ��
define('FEIEYUN_PR_SIG', sha1(FEIEYUN_PR_USER.FEIEYUN_PR_UKEY.FEIEYUN_PR_STIME));   //��������������Կ

function feieyun_print($printer_sn,$content,$times = 1){
	
    $content = array(			
        'user'      => FEIEYUN_PR_USER,
        'stime'     => FEIEYUN_PR_STIME,
        'sig'       => FEIEYUN_PR_SIG,
        'apiname'   => 'Open_printMsg',
        'sn'        => $printer_sn,
        'content'   => $content,
        'times'     => $times // ��ӡ����
    );
		
	$client = new FeieyunClient('api.feieyun.cn',80);
	if(!$client->post('/Api/Open/',$content)){
		return false;
	}else{
		$content = $client->getContent();
        $data = json_decode($content,true);
        return $data;
	}
}

function feieyun_format($data,$A,$B,$C,$D){
  
  $printTitleArr = get_config_print_title();
    
  $orderInfo = '<CB>'.$data['pr_name'].'</CB><BR>';
  $orderInfo .= ''.$printTitleArr['goods_title'].'         '.$printTitleArr['price'].'  '.$printTitleArr['num'].'  '.$printTitleArr['pay_price'].'<BR>';
  $orderInfo .= '--------------------------------<BR>';
  foreach ($data['goodslist'] as $k5 => $v5) {
    $name = $v5['title'];
    $price = $v5['price'];
    $num = $v5['num'];
    $pay_price = $v5['pay_price'];
    $kw3 = '';
    $kw1 = '';
    $kw2 = '';
    $kw4 = '';
    $str = $name;
    $blankNum = $A;//���ƿ���Ϊ14���ֽ�
    $lan = mb_strlen($str,'utf-8');
    $m = 0;
    $j=1;
    $blankNum++;
    $result = array();
    if(strlen($price) < $B){
          $k1 = $B - strlen($price);
          for($q=0;$q<$k1;$q++){
                $kw1 .= ' ';
          }
          $price = $price.$kw1;
    }
    if(strlen($num) < $C){
          $k2 = $C - strlen($num);
          for($q=0;$q<$k2;$q++){
                $kw2 .= ' ';
          }
          $num = $num.$kw2;
    }
    if(strlen($pay_price) < $D){
          $k3 = $D - strlen($pay_price);
          for($q=0;$q<$k3;$q++){
                $kw4 .= ' ';
          }
          $pay_price = $pay_price.$kw4;
    }
    for ($i=0;$i<$lan;$i++){
      $new = mb_substr($str,$m,$j,'utf-8');
      $j++;
      if(mb_strwidth($new,'utf-8')<$blankNum) {
        if($m+$j>$lan) {
          $m = $m+$j;
          $tail = $new;
          $lenght = iconv("UTF-8", "GBK//IGNORE", $new);
          $k = $A - strlen($lenght);
          for($q=0;$q<$k;$q++){
            $kw3 .= ' ';
          }
          if($m==$j){
            $tail .= $kw3.' '.$price.' '.$num.' '.$pay_price;
          }else{
            $tail .= $kw3.'<BR>';
          }
          break;
        }else{
          $next_new = mb_substr($str,$m,$j,'utf-8');
          if(mb_strwidth($next_new,'utf-8')<$blankNum) continue;
          else{
            $m = $i+1;
            $result[] = $new;
            $j=1;
          }
        }
      }
    }
    $head = '';
    foreach ($result as $key=>$value) {
      if($key < 1){
        $v_lenght = iconv("UTF-8", "GBK//IGNORE", $value);
        $v_lenght = strlen($v_lenght);
        if($v_lenght == 11 || $v_lenght == 27) $value = $value." ";
        $head .= $value.' '.$price.' '.$num.' '.$pay_price;
      }else{
        $head .= $value.'<BR>';
      } 
    }
    $orderInfo .= $head.$tail;
  }
  $time = date('Y-m-d H:i:s',time());
  $orderInfo .= '--------------------------------<BR>';
  $orderInfo .= ''.$printTitleArr['dispatch_price'].''.number_format($data['dispatch_price'], 2).''.$printTitleArr['yuan'].'<BR>';
  $orderInfo .= ''.$printTitleArr['all_pay_price'].''.number_format($data['pay_price'], 2).''.$printTitleArr['yuan'].'<BR>';
  $orderInfo .= ''.$printTitleArr['address_xm'].''.$data['address_xm'].'<BR>';
  $orderInfo .= ''.$printTitleArr['address_tel'].''.$data['address_tel'].'<BR>';
  $orderInfo .= ''.$printTitleArr['address'].''.$data['address'].'<BR>';
  $orderInfo .= ''.$printTitleArr['peisong_type'].''.$data['peisong_type'].'<BR>';
  $orderInfo .= ''.$printTitleArr['times'].''.$time.'<BR>';
  $orderInfo .= ''.$printTitleArr['order_no'].''.$data['order_no'].'<BR>';
  $orderInfo .= ''.$printTitleArr['order_beizu'].''.$data['order_beizu'].'<BR><BR>';
  $orderInfo .= '<QR>'.$data['order_link'].'</QR>';//�ѽ�����Ķ�ά�����ɵ��ַ����ñ�ǩ���ϼ����Զ����ɶ�ά��
  
  return $orderInfo;
  
}

function feieyun_iconv($data, $in_charset, $out_charset){
    if(is_array($data)) {
        foreach($data AS $key => $val) {
            $data[$key] = feieyun_iconv($val, $in_charset, $out_charset);
        }
    } else {
        $data = diconv($data, $in_charset, $out_charset);
    }
    return $data;
}