<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_print/config/config.php';
include DISCUZ_ROOT.'./source/plugin/tom_print/class/feieyunClient.class.php';
include DISCUZ_ROOT.'./source/plugin/tom_print/class/feieyun.function.php';


function add_qianggou_print($order_no){
    $logInfo = C::t('#tom_print#tom_print_log')->fetch_by_order_no($order_no);
    if($logInfo && $logInfo['id'] > 0){
    }else{
        
        $orderInfo = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_by_order_no($order_no);
        if($orderInfo && $orderInfo['id'] > 0){}else{
            return false;
        }

        $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($orderInfo['goods_id']);
        if($goodsInfo && $goodsInfo['id'] > 0){}else{
            return false;
        }

        $printList  = C::t('#tom_print#tom_print')->fetch_all_list(" AND tcshop_id = {$goodsInfo['tcshop_id']} AND status = 1 ","ORDER BY id DESC",0,1);
        if(is_array($printList) && !empty($printList) && $printList[0]['id'] > 0){
        }else{
            return false;
        }
        
        $insertData = array();
        $insertData['plugin_id']    = 'tom_tcqianggou';
        $insertData['order_no']     = $order_no;
        $insertData['print_time']   = TIMESTAMP;
        C::t('#tom_print#tom_print_log')->insert($insertData);
    }
    return true;
}
function qianggou_print($order_no){
    global $_G;
    
    $printSizeArr = get_config_print_size();
    
    $orderInfo = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_by_order_no($order_no);
    if($orderInfo && $orderInfo['id'] > 0){}else{
        return false;
    }
    
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($orderInfo['goods_id']);
    if($goodsInfo && $goodsInfo['id'] > 0){}else{
        return false;
    }
    
    $logInfo = C::t('#tom_print#tom_print_log')->fetch_by_order_no($order_no);
    if($logInfo && $logInfo['id'] > 0 && $logInfo['print_status'] != 1){}else{
        return false;
    }
    
    $printInfo = array();
    $printList  = C::t('#tom_print#tom_print')->fetch_all_list(" AND tcshop_id = {$goodsInfo['tcshop_id']} AND status = 1 ","ORDER BY id DESC",0,1);
    if(is_array($printList) && !empty($printList) && $printList[0]['id'] > 0){
        $printInfo = $printList[0];
    }else{
        return false;
    }
    
    if(!empty($orderInfo['option_name'])){
        $orderInfo['goods_title'] = $orderInfo['goods_title'].'('.$orderInfo['option_name'].')';
    }
    
    $data = array(
        'order_no'          => $order_no,
        'pr_name'           => $printInfo['name'],
        'dispatch_price'    => '0.00',
        'pay_price'         => $orderInfo['pay_price'],
        'address'           => $orderInfo['address'],
        'address_xm'        => $orderInfo['xm'],
        'address_tel'       => $orderInfo['tel'],
        'order_beizu'       => $orderInfo['order_beizu'],
        'order_link'        => $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$orderInfo['site_id']}&mod=orderinfo&order_no=".$order_no,
    );
        
    if($orderInfo['peisong_type'] == 1){
        $data['peisong_type'] = lang('plugin/tom_tcqianggou','goods_peisong_type_1');
    }else if($orderInfo['peisong_type'] == 2){
        $data['peisong_type'] = lang('plugin/tom_tcqianggou','goods_peisong_type_2');
    }else if($orderInfo['peisong_type'] == 3){
        $data['peisong_type'] = lang('plugin/tom_tcqianggou','goods_peisong_type_3');
    }
    $data['goodslist'][0] = array('title'=>$orderInfo['goods_title'],'price'=>$orderInfo['one_price'],'num'=>$orderInfo['goods_num'],'pay_price'=>$orderInfo['pay_price']);
    
    if (CHARSET == 'gbk') {
        $data = feieyun_iconv($data,'gbk','utf-8');
    }

    $content = feieyun_format($data,$printSizeArr[$printInfo['size_type']]['a'],$printSizeArr[$printInfo['size_type']]['b'],$printSizeArr[$printInfo['size_type']]['c'],$printSizeArr[$printInfo['size_type']]['d']);
    
    @$r = feieyun_print($printInfo['feie_pr_sn'],$content,1);
    
    if(is_array($r) && !empty($r) && $r['msg'] == 'ok'){
        $updateData = array();
        $updateData['print_name']   = $printInfo['name'];
        $updateData['print_sn']     = $printInfo['feie_pr_sn'];
        $updateData['print_status'] = 1;
        $updateData['print_time']   = TIMESTAMP;
        C::t('#tom_print#tom_print_log')->update($logInfo['id'],$updateData);
        return true;
    }else{
        return false;
    }
    
}

function add_mall_print($order_no){
    $logInfo = C::t('#tom_print#tom_print_log')->fetch_by_order_no($order_no);
    if($logInfo && $logInfo['id'] > 0){
    }else{
        
        $orderInfo = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_order_no($order_no);
        if($orderInfo && $orderInfo['id'] > 0){}else{
            return false;
        }

        $printList  = C::t('#tom_print#tom_print')->fetch_all_list(" AND tcshop_id = {$orderInfo['tcshop_id']} AND status = 1 ","ORDER BY id DESC",0,1);
        if(is_array($printList) && !empty($printList) && $printList[0]['id'] > 0){
        }else{
            return false;
        }
        
        $insertData = array();
        $insertData['plugin_id']    = 'tom_tcmall';
        $insertData['order_no']     = $order_no;
        $insertData['print_time']   = TIMESTAMP;
        C::t('#tom_print#tom_print_log')->insert($insertData);
    }
    return true;
}
function mall_print($order_no){
    global $_G;
    
    $printSizeArr = get_config_print_size();
    
    $orderInfo = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_order_no($order_no);
    if($orderInfo && $orderInfo['id'] > 0){}else{
        return false;
    }
    
    $logInfo = C::t('#tom_print#tom_print_log')->fetch_by_order_no($order_no);
    if($logInfo && $logInfo['id'] > 0 && $logInfo['print_status'] != 1){}else{
        return false;
    }
    
    $printInfo = array();
    $printList  = C::t('#tom_print#tom_print')->fetch_all_list(" AND tcshop_id = {$orderInfo['tcshop_id']} AND status = 1 ","ORDER BY id DESC",0,1);
    if(is_array($printList) && !empty($printList) && $printList[0]['id'] > 0){
        $printInfo = $printList[0];
    }else{
        return false;
    }
    
    $data = array(
        'order_no'          => $order_no,
        'pr_name'           => $printInfo['name'],
        'dispatch_price'    => $orderInfo['dispatch_price'],
        'pay_price'         => $orderInfo['pay_price'],
        'address'           => $orderInfo['address_str'],
        'address_xm'        => $orderInfo['address_xm'],
        'address_tel'       => $orderInfo['address_tel'],
        'order_beizu'       => $orderInfo['order_beizu'],
        'order_link'        => $_G['siteurl']."plugin.php?id=tom_tcmall&site={$orderInfo['site_id']}&mod=myorderinfo&order_no=".$order_no,
    );
        
    if($orderInfo['peisong_type'] == 1){
        $data['peisong_type'] = lang('plugin/tom_tcmall','goods_peisong_type_1');
    }else if($orderInfo['peisong_type'] == 2){
        $data['peisong_type'] = lang('plugin/tom_tcmall','goods_peisong_type_2');
    }else if($orderInfo['peisong_type'] == 3){
        $data['peisong_type'] = lang('plugin/tom_tcmall','goods_peisong_type_3');
    }
    
    $goodsListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 1000);
    if(is_array($goodsListTmp) && !empty($goodsListTmp)){
        foreach($goodsListTmp as $gk => $gv){
            $goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($gv['goods_id']);
            
            if(!empty($gv['option_name'])){
                $goodsInfoTmp['title'] = $goodsInfoTmp['title'].'('.$gv['option_name'].')';
            }
            
            $data['goodslist'][] = array('title'=>$goodsInfoTmp['title'],'price'=>$gv['price'],'num'=>$gv['goods_num'],'pay_price'=>$gv['real_price']);
            
        }
    }
                        
    
    
    if (CHARSET == 'gbk') {
        $data = feieyun_iconv($data,'gbk','utf-8');
    }

    $content = feieyun_format($data,$printSizeArr[$printInfo['size_type']]['a'],$printSizeArr[$printInfo['size_type']]['b'],$printSizeArr[$printInfo['size_type']]['c'],$printSizeArr[$printInfo['size_type']]['d']);
    
    @$r = feieyun_print($printInfo['feie_pr_sn'],$content,1);
    
    if(is_array($r) && !empty($r) && $r['msg'] == 'ok'){
        $updateData = array();
        $updateData['print_name']   = $printInfo['name'];
        $updateData['print_sn']     = $printInfo['feie_pr_sn'];
        $updateData['print_status'] = 1;
        $updateData['print_time']   = TIMESTAMP;
        C::t('#tom_print#tom_print_log')->update($logInfo['id'],$updateData);
        return true;
    }else{
        return false;
    }
    
}

function add_ptuan_print($order_no){
    $logInfo = C::t('#tom_print#tom_print_log')->fetch_by_order_no($order_no);
    if($logInfo && $logInfo['id'] > 0){
    }else{
        
        $orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_order_no($order_no);
        if($orderInfo && $orderInfo['id'] > 0){}else{
            return false;
        }

        $goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($orderInfo['goods_id']);
        if($goodsInfo && $goodsInfo['id'] > 0){}else{
            return false;
        }

        $printList  = C::t('#tom_print#tom_print')->fetch_all_list(" AND tcshop_id = {$goodsInfo['tcshop_id']} AND status = 1 ","ORDER BY id DESC",0,1);
        if(is_array($printList) && !empty($printList) && $printList[0]['id'] > 0){
        }else{
            return false;
        }
        
        $insertData = array();
        $insertData['plugin_id']    = 'tom_tcptuan';
        $insertData['order_no']     = $order_no;
        $insertData['print_time']   = TIMESTAMP;
        C::t('#tom_print#tom_print_log')->insert($insertData);
    }
    return true;
}
function ptuan_print($order_no){
    global $_G;
    
    $printSizeArr = get_config_print_size();
    
    $orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_order_no($order_no);
    if($orderInfo && $orderInfo['id'] > 0){}else{
        return false;
    }
    
    $goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($orderInfo['goods_id']);
    if($goodsInfo && $goodsInfo['id'] > 0){}else{
        return false;
    }
    
    $logInfo = C::t('#tom_print#tom_print_log')->fetch_by_order_no($order_no);
    if($logInfo && $logInfo['id'] > 0 && $logInfo['print_status'] != 1){}else{
        return false;
    }
    
    $printInfo = array();
    $printList  = C::t('#tom_print#tom_print')->fetch_all_list(" AND tcshop_id = {$goodsInfo['tcshop_id']} AND status = 1 ","ORDER BY id DESC",0,1);
    if(is_array($printList) && !empty($printList) && $printList[0]['id'] > 0){
        $printInfo = $printList[0];
    }else{
        return false;
    }
    
    if(!empty($orderInfo['option_name'])){
        $orderInfo['goods_name'] = $orderInfo['goods_name'].'('.$orderInfo['option_name'].')';
    }
    
    $data = array(
        'order_no'          => $order_no,
        'pr_name'           => $printInfo['name'],
        'dispatch_price'    => '0.00',
        'pay_price'         => $orderInfo['pay_price'],
        'address'           => $orderInfo['address'],
        'address_xm'        => $orderInfo['xm'],
        'address_tel'       => $orderInfo['tel'],
        'order_beizu'       => $orderInfo['order_beizu'],
        'order_link'        => $_G['siteurl']."plugin.php?id=tom_tcptuan&site={$orderInfo['site_id']}&mod=myorderinfo&order_no=".$order_no,
    );
        
    if($orderInfo['peisong_type'] == 1){
        $data['peisong_type'] = lang('plugin/tom_tcptuan','goods_peisong_type_1');
    }else if($orderInfo['peisong_type'] == 2){
        $data['peisong_type'] = lang('plugin/tom_tcptuan','goods_peisong_type_2');
    }else if($orderInfo['peisong_type'] == 3){
        $data['peisong_type'] = lang('plugin/tom_tcptuan','goods_peisong_type_3');
    }
    $orderInfo['one_price'] = $orderInfo['pay_price']/$orderInfo['goods_num'];
    $data['goodslist'][0] = array('title'=>$orderInfo['goods_name'],'price'=>$orderInfo['one_price'],'num'=>$orderInfo['goods_num'],'pay_price'=>$orderInfo['pay_price']);
    
    if (CHARSET == 'gbk') {
        $data = feieyun_iconv($data,'gbk','utf-8');
    }

    $content = feieyun_format($data,$printSizeArr[$printInfo['size_type']]['a'],$printSizeArr[$printInfo['size_type']]['b'],$printSizeArr[$printInfo['size_type']]['c'],$printSizeArr[$printInfo['size_type']]['d']);
    
    @$r = feieyun_print($printInfo['feie_pr_sn'],$content,1);
    
    if(is_array($r) && !empty($r) && $r['msg'] == 'ok'){
        $updateData = array();
        $updateData['print_name']   = $printInfo['name'];
        $updateData['print_sn']     = $printInfo['feie_pr_sn'];
        $updateData['print_status'] = 1;
        $updateData['print_time']   = TIMESTAMP;
        C::t('#tom_print#tom_print_log')->update($logInfo['id'],$updateData);
        return true;
    }else{
        return false;
    }
    
}