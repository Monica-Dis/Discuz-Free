/**
   This is NOT a freeware, use is subject to license terms
   版权所有：TOM微信 www.tomwx.cn
*/

const app       = getApp();
const $         = require('underscore');
const _TomData  = require('../config/data');

const REQUEST_ID = {};

module.exports = {

    /**
     * 获取公共请求配置
     */
    getRequestOptions: function (options, pageObj) {
        const that = this;
        options = $.extend({
            method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
            header: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'client': 'XCX',
            },
            success: function (res) {
                try {
                    res = res.data;
                    const code = res.code;
                    if (code == 1) {
                        var data = null;
                        if (res.data !== undefined) data = res.data;
                        options.callback.apply(pageObj, [data, res]); // 在 pageObj 环境下 执行 callback 方法 传递 data, res 参数
                    } else if (code == 2) {
                        wx.showModal({ content: '未登录', showCancel: false });
                        return;
                    } else {
                        var msg = undefined;
                        if (res.msg !== undefined) msg = res.msg;
                        if (msg !== undefined) {
                            wx.showModal({
                                content: msg,
                                showCancel: false,
                                success: function () {
                                    options.error && options.error.call(pageObj, code, msg);
                                }
                            });
                        }
                    }
                } catch (err) {
                    console.error(err.stack);
                }
            },
            fail: function (res) {
                console.error(res);
                options.failAfter && options.failAfter.apply(pageObj, [res]);
                console.error(res, options.url);
            },
            complete: function (res) {
                setTimeout(function () {
                    if (options.isShowLoading) wx.hideToast();
                    delete REQUEST_ID[options.requestId];
                }, options.delay);
                options.completeAfter && options.completeAfter.call(pageObj, res, options);
            },
        }, options);

        //必须配置
        options.isShowLoading = options.isShowLoading !== false;
        options.loadingText = options.loadingText || "加载中...";
        options.delay = options.delay || 500;
        options.data = options.data || {};
        options.requestId = options.requestId || $.uniqueId("RQ");//生成全局唯一ID "RQ" + new Date().getTime();
        REQUEST_ID[options.requestId] = 1;
        return options;
    },

    /**
     * get 请求数据
     */
    get: function (url, data, callback, pageObj, extend) {
        extend = extend || {};
        const options = this.getRequestOptions($.extend({ url: url, data: data, callback: callback }, extend), pageObj);
        if (options.isShowLoading)
            wx.showToast({ icon: "loading", title: options.loadingText, duration: 10000 })
        wx.request(options);
        return options.requestId;
    },

	/**
     * post 请求数据
     */
    post: function (url, data, callback, pageObj, extend) {
        extend = extend || {};
        const options = this.getRequestOptions($.extend({ url: url, data: data, callback: callback, method: "POST" }, extend), pageObj);
        if (options.isShowLoading)
            wx.showToast({ icon: "loading", title: options.loadingText, duration: 10000 })
        wx.request(options);
        return options.requestId;
    },

    /**
     * 上传文件
     */
    upload: function (url, filepath, name, data, callback, pageObj, extend) {
        extend = extend || {};
        wx.showToast({ title: '上传中...', icon: 'loading', duration: 10000 });
        const options = $.extend({
            url: url, filePath: filepath, name: name, formData: data,
            success: function (res) {
                res = JSON.parse(res.data);
                if (res.code == 1){
                    callback.apply(pageObj, [res.data, res]);
                }else {
                    wx.showModal({ content: res.msg, showCancel: false });
                }
            },
            fail: function (res) {
                console.error(res);
                wx.showModal({ content: res.errMsg, showCancel: false });
            },
            complete: function (res) {
                wx.hideToast();
                setTimeout(function () { delete REQUEST_ID[options.requestId]; }, options.delay);
                options.completeAfter && options.completeAfter.apply(pageObj, [res]);
            }
        }, extend);
        options.delay = options.delay || 1000;
        options.formData = options.formData || {};
        options.requestId = $.uniqueId("RQ");//生成全局唯一ID "RQ" + new Date().getTime();
        REQUEST_ID[options.requestId] = 1;
        wx.uploadFile(options);
        return options.requestId;
    },

    /**
     * 根据requestId检查是否正在请求
     */
    isLoading: function (requestId) {
        if (!requestId) return false;
        return REQUEST_ID[requestId] !== undefined;
    },

}