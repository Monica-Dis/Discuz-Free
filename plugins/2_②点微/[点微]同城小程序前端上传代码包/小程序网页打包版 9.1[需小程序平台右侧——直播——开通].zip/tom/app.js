/**
   This is NOT a freeware, use is subject to license terms
   版权所有：TOM微信 www.tomwx.cn
*/

var _TomData = require('./config/data.js');
App({
    onLaunch: function () {
    },
    onShow: function () {
    },
    globalData: {
        loginStatus: false,
        userInfo: '',
        utoken: ''
    }
})