/**
   This is NOT a freeware, use is subject to license terms
   版权所有：TOM微信 www.tomwx.cn
*/

const app           = getApp();
const _TomData      = require('../../config/data');
const $             = require('../../utils/underscore');
const util          = require('../../utils/util');
const requestUtil   = require('../../utils/requestUtil');

Page({
  code:'',
  data: {
    siteurl: _TomData.tom_host_api_url,
    site_id: _TomData.tom_app_site_id,
  },
  /**
   * 页面初始化
   */
  onLoad: function (options) {
    var that = this;

    if (wx.canIUse('web-view')) {
    } else {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能。（苹果手机微信请升级到 6.5.22 以上版本，安卓版微信请升级到 6.5.19 以上版本）'
      })
    }
  },

  /**
   * 获取网页传值
  */
  bindGetMsg: function (e) {
    var dd = e.detail.data;
    var newtitle = dd[dd.length - 1].title;
    var newlink = dd[dd.length - 1].link;
    console.log(newtitle);
    console.log(newlink);
    this.setData({
      title: newtitle,
      url: newlink,
    });
  },
  
  /**
  * 分享页面
  */
  onShareAppMessage(options) {
    return {
      title: this.data.title,
      path: 'pages/module/tcqianggou'
    };
  }

})