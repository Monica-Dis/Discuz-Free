/**
   This is NOT a freeware, use is subject to license terms
   版权所有：TOM微信 www.tomwx.cn
*/

const app           = getApp();
const _TomData      = require('../../config/data');
const $             = require('../../utils/underscore');
const util          = require('../../utils/util');
const requestUtil   = require('../../utils/requestUtil');

Page({
  data: {
  },
  /**
   * 页面初始化
   */
  onLoad: function (options) {
    
    // 获取配置
    this.setData({
      config: wx.getStorageSync('fenlei_config'),
    });

    // 加载数据
    this.onPullDownRefresh();
  },
  /**
     * 刷新信息
     */
  onPullDownRefresh: function () {
    // 配置
    requestUtil.get(_TomData.tom_get_config_url, {}, (data) => {
      wx.setStorage({ key: 'fenlei_config', data: data, });
      this.setData({ config: data });
    }, this);

    wx.stopPullDownRefresh();
  },

})