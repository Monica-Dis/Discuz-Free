/**
   This is NOT a freeware, use is subject to license terms
   版权所有：TOM微信 www.tomwx.cn
*/

const app           = getApp();
const _TomData      = require('../../config/data');
const $             = require('../../utils/underscore');
const util          = require('../../utils/util');
const requestUtil   = require('../../utils/requestUtil');

Page({
  code:'',
  data: {
    order_no: '',
    viewurl: '',
  },
  /**
   * 页面初始化
   */
  onLoad: function (options) {

    var newviewurl = encodeURIComponent(_TomData.tom_get_index_pay_viewurl + options.order_no);

    this.setData({
      order_no: options.order_no,
      viewurl: newviewurl,
    });
    this.onPay();
  },
  /**
  * 设置标题
  */
  onPay: function () {
    var that = this
    wx.login({
      success: function (res) {
        var code     = res.code;
        var order_no = that.data.order_no;
        wx.request({
          url: _TomData.tom_get_index_pay_url,
          method: "POST",
          header: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'client': 'XCX',
          },
          data: {
            code: code,
            order_no: order_no
          },
          fail: function (res) {
            console.dir(res);
          },
          success: function (res) {
            console.log(res);
            var status = res.data.status;
            var parameters = res.data.parameters;
            if (status == 200) {
              wx.requestPayment({
                'timeStamp': parameters.timeStamp,
                'nonceStr': parameters.nonceStr,
                'package': parameters.package,
                'signType': parameters.signType,
                'paySign': parameters.paySign,
                'success': function (res) {
                  wx.redirectTo({ url: 'view?viewurl=' + that.data.viewurl, });
                },
                'fail': function (res) {
                  wx.showModal({
                    title: '支付错误',
                    content: '支付失败',
                    showCancel: false,
                    success: function () {
                      wx.redirectTo({ url: 'view?viewurl=' + that.data.viewurl, });
                    }
                  });
                }
              })
            } else if (status == 100) {
              wx.showModal({
                title: '支付错误',
                content: '当前订单已经完成支付，请勿重复支付',
                showCancel: false,
                success: function () {
                  wx.redirectTo({ url: 'view?viewurl=' + that.data.viewurl, });
                }
              });
            } else if (status == 101) {
              wx.showModal({
                title: '支付错误',
                content: '订单状态异常',
                showCancel: false,
                success: function () {
                  wx.redirectTo({ url: 'view?viewurl=' + that.data.viewurl, });
                }
              });
            } else if (status == 500) {
              wx.showModal({
                title: '支付错误',
                content: '生成微信订单失败',
                showCancel: false,
                success: function () {
                  wx.redirectTo({ url: 'view?viewurl=' + that.data.viewurl, });
                }
              });
            } else if (status == 404) {
              wx.showModal({
                title: '支付错误',
                content: '订单不存在',
                showCancel: false,
                success: function () {
                  wx.redirectTo({ url: 'view?viewurl=' + that.data.viewurl, });
                }
              });
            } else if (status == 301) {
              wx.showModal({
                title: '支付错误',
                content: '支付标示获取失败',
                showCancel: false,
                success: function () {
                  wx.redirectTo({ url: 'view?viewurl=' + that.data.viewurl, });
                }
              });
            } else if (status == 601) {
              wx.showModal({
                title: '支付错误',
                content: '获取openid失败',
                showCancel: false,
                success: function () {
                  wx.redirectTo({ url: 'view?viewurl=' + that.data.viewurl, });
                }
              });
            } else {
              wx.showModal({
                title: '支付错误',
                content: '支付错误',
                showCancel: false,
                success: function () {
                  wx.redirectTo({ url: 'view?viewurl=' + that.data.viewurl, });
                }
              });
            }
          }
        })
      }, fail: function (res) {
        console.log(res);
      }
    })
  },
  /**
  * 分享页面
  */
  onShareAppMessage(options) {
    return {
      path: 'pages/index/index'
    };
  }

})