/**
   This is NOT a freeware, use is subject to license terms
   版权所有：TOM微信 www.tomwx.cn
*/

const app           = getApp();
const _TomData      = require('../../config/data');
const $             = require('../../utils/underscore');
const util          = require('../../utils/util');
const requestUtil   = require('../../utils/requestUtil');

Page({
  data: {
  },

  /**
   * 页面初始化
   */
  onLoad: function (options) {
    wx.redirectTo({
        url: `plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=${options.roomid}`
    })
  },
  
})