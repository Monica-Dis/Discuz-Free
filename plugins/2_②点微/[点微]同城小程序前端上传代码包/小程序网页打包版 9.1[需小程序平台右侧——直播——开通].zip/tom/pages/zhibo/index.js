/**
   This is NOT a freeware, use is subject to license terms
   版权所有：TOM微信 www.tomwx.cn
*/

const app           = getApp();
const _TomData      = require('../../config/data');
const $             = require('../../utils/underscore');
const util          = require('../../utils/util');
const requestUtil   = require('../../utils/requestUtil');

Page({
  data: {
    isEmpty: false,// 数据是否为空
    hasMore: true,// 是否还有更多数据
    page: 1,// 当前请求的页数
  },

  /**
   * 页面初始化
   */
  onLoad: function (options) {
    
    // 加载数据
    this.onPullDownRefresh();
  },
/**
   * 刷新信息
   */
  onPullDownRefresh: function () {
    var that = this;

    // 配置
    requestUtil.get(_TomData.tom_get_config_url, {}, (data) => {
      wx.setStorage({ key: 'fenlei_config', data: data, });
      this.setData({ config: data });
      // 设置标题
      wx.setNavigationBarTitle({ title: this.data.config.zhibo_name });
    }, this);

    // 加载列表 
    requestUtil.get(_TomData.tom_get_zhibo_list_url, this.data.param, (data) => {
      this.onSetData(data, 1);
    }, this, { completeAfter: wx.stopPullDownRefresh });

    wx.stopPullDownRefresh();
  },

  /**
   * 下拉加载
   */
  onReachBottom: function () {
    if (!this.data.hasMore) {
      wx.stopPullDownRefresh();
      return;
    }
    // 加载数据 
    requestUtil.get(_TomData.tom_get_zhibo_list_url, $.extend({}, this.data.param, { page: this.data.page + 1  }), (data) => {
      this.onSetData(data, this.data.page + 1);
    }, this, { completeAfter: wx.stopPullDownRefresh, isShowLoading: true });
  },

    /**
   * 设置数据
   */
  onSetData: function (data, page) {
    data = data || [];
    this.setData({
      page: page !== undefined ? page : this.data.page,
      list: page === 1 || page === undefined ? data : this.data.list.concat(data),
      hasMore: page !== undefined && data.length > 0,
      isEmpty: page === 1 || page === undefined ? data.length === 0 : false
    });
  },
    /**
  * 分享页面
  */
 onShareAppMessage(options) {
  const title = this.data.config.zhibo_name;
  const desc = this.data.config.share_desc;
  return {
    title: title,
    desc: desc,
    path: 'pages/zhibo/index'
  };
}
  
})