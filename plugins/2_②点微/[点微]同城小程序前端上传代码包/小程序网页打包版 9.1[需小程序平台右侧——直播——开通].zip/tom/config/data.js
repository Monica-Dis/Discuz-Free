/**
 * 应用更新支持：https://dism.taobao.com
 * 最新小程序获取：http://t.cn/Aiux1Qh0
 * 
 * 小程序配置
 */

// 接口论坛域名(注意域名必须已 / 结尾  不能有空格)
var TOM_HOST_URL = "https://dism.taobao.com/";
// 小程序版本
var app_version = '9.1';
// 站点ID
var app_site_id = '1';
// 多小程序SID（小程序插件后台 》》 多小程序菜单 》》 点击进去获取）
var app_sid = '0';

// API 接口设置，请勿修改,任何修改都可能到小程序错误
module.exports = {
  tom_host_api_url: TOM_HOST_URL,
  tom_app_sid: app_sid,
  tom_app_site_id: app_site_id,
  tom_auth_login_url: TOM_HOST_URL + "plugin.php?id=tom_xiaofenlei:login&act=login",
  tom_auth_token_url: TOM_HOST_URL + "plugin.php?id=tom_xiaofenlei:login&act=token",
  tom_auth_check_union_url: TOM_HOST_URL + "plugin.php?id=tom_xiaofenlei:login&act=check_union",
  tom_auth_union_url: TOM_HOST_URL + "plugin.php?id=tom_xiaofenlei:login&act=union",
  tom_get_userinfo_url: TOM_HOST_URL + "plugin.php?id=tom_xiaofenlei&mod=get_userinfo",
  tom_get_config_url: TOM_HOST_URL + "plugin.php?id=tom_xiaofenlei&mod=get_config",
  tom_get_phone_url: TOM_HOST_URL + "plugin.php?id=tom_xiaofenlei:login&act=phone",
  tom_get_check_phone_url: TOM_HOST_URL + "plugin.php?id=tom_xiaofenlei:login&act=check_phone",
  tom_get_index_pay_url: TOM_HOST_URL + "plugin.php?id=tom_pay:pay&payment=wxpay_xiao&sid=" + app_sid,
  tom_get_index_pay_viewurl: TOM_HOST_URL + "plugin.php?id=tom_pay&order_no=",
  tom_get_zhibo_list_url: TOM_HOST_URL + "plugin.php?id=tom_xiaofenlei&mod=get_zhibo_list",
}