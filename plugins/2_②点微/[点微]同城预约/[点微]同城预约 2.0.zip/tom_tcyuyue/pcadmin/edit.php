<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcyuyue_id = intval($_GET['tcyuyue_id'])>0 ? intval($_GET['tcyuyue_id']):0;

$tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyue_id);
if(empty($tcyuyueInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($__UserInfo['id'] != $tcyuyueInfo['user_id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=edit&tcyuyue_id={$tcyuyue_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('title')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcshop_id                  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    $title                      = isset($_GET['title'])? addslashes($_GET['title']):'';
    $total_renshu               = intval($_GET['total_renshu'])>0? intval($_GET['total_renshu']):0;
    $before_time                = isset($_GET['before_time'])? intval($_GET['before_time']):0;
    $before_time_unit           = isset($_GET['before_time_unit'])? intval($_GET['before_time_unit']):0;
    $cancel_before_time         = isset($_GET['cancel_before_time'])? intval($_GET['cancel_before_time']):0;
    $cancel_before_time_unit    = isset($_GET['cancel_before_time_unit'])? intval($_GET['cancel_before_time_unit']):0;
    $open_yuyue_queren          = isset($_GET['open_yuyue_queren'])? intval($_GET['open_yuyue_queren']):0;
    $open_clerk                 = isset($_GET['open_clerk'])? intval($_GET['open_clerk']):0;
    $open_clerk_must            = isset($_GET['open_clerk_must'])? intval($_GET['open_clerk_must']):0;
    $clerk_name                 = isset($_GET['clerk_name'])? addslashes($_GET['clerk_name']):'';
    $date_type                  = intval($_GET['date_type'])>0? intval($_GET['date_type']):1;
    $model_time_type_id         = intval($_GET['model_time_type_id'])>0? intval($_GET['model_time_type_id']):0;
    $time_renshu                = intval($_GET['time_renshu'])>0? intval($_GET['time_renshu']):0;
    $yuyue_days                 = intval($_GET['yuyue_days'])>0? intval($_GET['yuyue_days']):$tcyuyueConfig['yuyue_days'];
    $tongzhi_clerk_id           = intval($_GET['tongzhi_clerk_id'])>0? intval($_GET['tongzhi_clerk_id']):0;
    
    $weeksStr = '';
    if(is_array($_GET['weeks']) && !empty($_GET['weeks'])){
        $weeksList = array();
        foreach($_GET['weeks'] as $key => $value){
            $weekTmp = intval($value);
            if(!empty($weekTmp)){
                $weeksList[] = $weekTmp;
            }
        }
        if(is_array($weeksList) && !empty($weeksList)){
            $weeksStr = implode('|', $weeksList);
        }
    }
    
    $daysStr = '';
    if(is_array($_GET['days']) && !empty($_GET['days'])){
        $daysList = array();
        foreach($_GET['days'] as $key => $value){
            $dayTmp = intval($value);
            if(!empty($dayTmp)){
                $daysList[] = $dayTmp;
            }
        }
        if(is_array($daysList) && !empty($daysList)){
            $daysStr = implode('|', $daysList);
        }
    }
    
    $modelTimeIdsArr = array();
    if(is_array($_GET['times']) && !empty($_GET['times'])){
        foreach($_GET['times'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $modelTimeIdsArr[] = $idTmp;
            }
        }
    }
    
    $notDateList = array();
    if(is_array($_GET['notdates']) && !empty($_GET['notdates'])){
        foreach($_GET['notdates'] as $key => $value){
            $dateTmp = addslashes($value);
            
            if(!empty($dateTmp)){
                $dateTimeStampTmp = strtotime($dateTmp);
                
                $year = dgmdate($dateTimeStampTmp, 'Y',$tomSysOffset);
                $month = dgmdate($dateTimeStampTmp, 'n',$tomSysOffset);
                $day = dgmdate($dateTimeStampTmp, 'j',$tomSysOffset);
                
                $time_stamp = mktime(0, 0, 0, $month, $day, $year);
                
                $notDateList[$key]['notdate_stamp'] = $time_stamp;
            }
        }
    }
    
    if($__Admin['admin'] == 'shopadmin'){
        if($tcyuyueInfo['user_id'] != $__UserInfo['id']){
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    }
    
    $updateData = array();
    if($__Admin['admin'] == 'admin'){
        $updateData['site_id']                  = $tcshopInfo['site_id'];
        $updateData['user_id']                  = $tcshopInfo['user_id'];
        $updateData['tcshop_id']                = $tcshop_id;
    }
    $updateData['tongzhi_clerk_id']         = $tongzhi_clerk_id;
    $updateData['title']                    = $title;
    $updateData['date_type']                = $date_type;
    if($date_type == 1){
        $updateData['yuyue_dates']              = $weeksStr;
    }else if($date_type == 2){
        $updateData['yuyue_dates']              = $daysStr;
    }
    $updateData['model_time_type_id']       = $model_time_type_id;
    $updateData['total_renshu']             = $total_renshu;
    $updateData['time_renshu']              = $time_renshu;
    $updateData['before_time']              = $before_time;
    $updateData['before_time_unit']         = $before_time_unit;
    $updateData['cancel_before_time']       = $cancel_before_time;
    $updateData['cancel_before_time_unit']  = $cancel_before_time_unit;
    $updateData['yuyue_days']               = $yuyue_days;
    $updateData['open_yuyue_queren']        = $open_yuyue_queren;
    $updateData['open_clerk']               = $open_clerk;
    if($open_clerk == 1){
        $updateData['open_clerk_must']          = $open_clerk_must;
        $updateData['clerk_name']               = $clerk_name;
    }else{
        $updateData['open_clerk_must']          = 0;
        $updateData['clerk_name']               = '';
    }
    if($__Admin['admin'] == 'shopadmin'){
        if($tcyuyueConfig['must_shenhe'] == 1){
            $updateData['shenhe_status']              = 2;
        }else{
            $updateData['shenhe_status']              = 1;
        }
    }else{
        $updateData['shenhe_status']              = 1;
    }
    $updateData['update_time']              = TIMESTAMP;
    if(C::t('#tom_tcyuyue#tom_tcyuyue')->update($tcyuyue_id, $updateData)){
        
        C::t('#tom_tcyuyue#tom_tcyuyue_notdate')->delete_by_tcyuyue_id($tcyuyue_id);
        
        $timeListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_time")->fetch_all_list(" AND tcyuyue_id = {$tcyuyue_id} ", 'ORDER BY id ASC');
        $timeIdArr = array();
        if(is_array($timeListTmp) && !empty($timeListTmp)){
            foreach($timeListTmp as $key => $value){
                $timeIdArr[$value['model_time_id']] = $value['id'];
            }
        }
        
        if(is_array($modelTimeIdsArr) && !empty($modelTimeIdsArr)){
            foreach($modelTimeIdsArr as $key => $value){
                
                $modelTimeInfo = C::t("#tom_tcyuyue#tom_tcyuyue_model_time")->fetch_by_id($value);
                if(isset($timeIdArr[$value]) && !empty($timeIdArr[$value])){
                    
                    $updateData = array();
                    $updateData['time_name']        = $modelTimeInfo['name'];
                    $updateData['time_start_stamp'] = $modelTimeInfo['start_stamp'];
                    $updateData['time_end_stamp']   = $modelTimeInfo['end_stamp'];
                    $updateData['tsort']            = $modelTimeInfo['tsort'];
                    C::t('#tom_tcyuyue#tom_tcyuyue_time')->update($timeIdArr[$value], $updateData);
                    unset($timeIdArr[$value]);
                }else{
                    
                    $insertData = array();
                    $insertData['tcyuyue_id']       = $tcyuyue_id;
                    $insertData['model_time_id']    = $modelTimeInfo['id'];
                    $insertData['time_name']        = $modelTimeInfo['name'];
                    $insertData['time_start_stamp'] = $modelTimeInfo['start_stamp'];
                    $insertData['time_end_stamp']   = $modelTimeInfo['end_stamp'];
                    $insertData['tsort']            = $modelTimeInfo['tsort'];
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tcyuyue#tom_tcyuyue_time')->insert($insertData);
                }
            }
        }
        
        if(is_array($timeIdArr) && !empty($timeIdArr)){
            foreach($timeIdArr as $key => $value){
                C::t('#tom_tcyuyue#tom_tcyuyue_time')->delete_by_id($value);
            }
        }
        
        if(is_array($notDateList) && !empty($notDateList)){
            foreach($notDateList as $key => $value){
                $insertData = array();
                $insertData['tcyuyue_id']       = $tcyuyue_id;
                $insertData['notdate_stamp']    = $value['notdate_stamp'];
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_tcyuyue#tom_tcyuyue_notdate')->insert($insertData);
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcyuyueInfo['tcshop_id']);
$clerkListTmp = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(" AND tcshop_id = {$tcyuyueInfo['tcshop_id']} ",'ORDER BY id DESC', 0, 100);
$clerkList = array();
if(is_array($clerkListTmp) && !empty($clerkListTmp)){
    foreach($clerkListTmp as $key => $value){
        $clerkList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $clerkList[$key]['userInfo'] = $userInfoTmp;
    }
}

$timeTypeListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_model_time_type")->fetch_all_list("", 'ORDER BY tsort ASC,id DESC');
$timeTypeList = array();
if(is_array($timeTypeListTmp) && !empty($timeTypeListTmp)){
    foreach($timeTypeListTmp as $key => $value){
        $timeTypeList[$value['id']] = $value;
    }
}

$timeListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_time")->fetch_all_list(" AND tcyuyue_id = {$tcyuyueInfo['id']} ", 'ORDER BY id ASC');
$timeIdArr = array();
if(is_array($timeListTmp) && !empty($timeListTmp)){
    foreach($timeListTmp as $key => $value){
        $timeIdArr[] = $value['model_time_id'];
    }
}

$modelTimeListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_model_time")->fetch_all_list("", 'ORDER BY tsort ASC,id DESC');
$modelTimeList = $timeArr = array();
if(is_array($modelTimeListTmp) && !empty($modelTimeListTmp)){
    foreach ($modelTimeListTmp as $key => $value){
        $modelTimeList[$value['model_time_type_id']][$key] = $value;
        $modelTimeList[$value['model_time_type_id']][$key]['status'] = 0;
        
        if(in_array($value['id'], $timeIdArr)){
            $modelTimeList[$value['model_time_type_id']][$key]['status'] = 1;
        }
        
        $timeArr[$value['model_time_type_id']][$key]['id'] = $value['id'];
        $timeArr[$value['model_time_type_id']][$key]['name'] = diconv($value['name'],CHARSET,'utf-8');
    }
}

$timeData[0] = $timeArr;
$timeArrStr = urlencode(json_encode($timeData));

$yuyueDatesListTmp = explode('|', $tcyuyueInfo['yuyue_dates']);
$weeksList = array();
if(is_array($weeksArr) && !empty($weeksArr)){
    foreach($weeksArr as $key => $value){
        $weeksList[$key]['id'] = $key;
        $weeksList[$key]['name'] = $value;
        $weeksList[$key]['status'] = 0;
        if($tcyuyueInfo['date_type'] == 1 && in_array($key, $yuyueDatesListTmp)){
            $weeksList[$key]['status'] = 1;
        }
    }
}

$daysArr = array();
for($i = 1; $i <= 31; $i++){
    $daysArr[] = $i;
}
$daysList = array();
if(is_array($daysArr) && !empty($daysArr)){
    foreach($daysArr as $key => $value){
        $daysList[$key]['value'] = $value;
        $daysList[$key]['status'] = 0;
        if($tcyuyueInfo['date_type'] == 2 && in_array($value, $yuyueDatesListTmp)){
            $daysList[$key]['status'] = 1;
        }
    }
}

$notDateListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_notdate")->fetch_all_list(" AND tcyuyue_id = {$tcyuyueInfo['id']} ", 'ORDER BY notdate_stamp ASC,id ASC');
$notDateList = array();
if(is_array($notDateListTmp) && !empty($notDateListTmp)){
    foreach($notDateListTmp as $key => $value){
        $notDateList[$key] = $value;
        $notDateList[$key]['notDateStamp'] = dgmdate($value['notdate_stamp'], "Y-m-d",$tomSysOffset);
    }
}

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:pcadmin/edit");