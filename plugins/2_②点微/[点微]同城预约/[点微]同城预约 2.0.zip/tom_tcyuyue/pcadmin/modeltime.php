<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$model_time_type_id = intval($_GET['model_time_type_id'])>0 ? intval($_GET['model_time_type_id']):0;
$modelTimeTypeInfo = C::t('#tom_tcyuyue#tom_tcyuyue_model_time_type')->fetch_by_id($model_time_type_id);

$modPcadminUrl = $pcadminUrl."&tmod=modeltime&model_time_type_id={$model_time_type_id}"; 

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('model_time_type_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name       = isset($_GET['name'])? addslashes($_GET['name']):'';
    $start_time = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $end_time   = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $tsort      = intval($_GET['tsort'])>0 ? intval($_GET['tsort']):10;
    
    $start_stamp    = strtotime($start_time);
    $start_stamp    = $start_stamp - $nowDayTime;
    $end_stamp      = strtotime($end_time);
    $end_stamp      = $end_stamp - $nowDayTime;
    
    $insertData = array();
    $insertData['model_time_type_id']   = $model_time_type_id;
    $insertData['name']                 = $name;
    $insertData['start_stamp']          = $start_stamp;
    $insertData['end_stamp']            = $end_stamp;
    $insertData['tsort']                = $tsort;
    $insertData['add_time']             = TIMESTAMP;
    C::t('#tom_tcyuyue#tom_tcyuyue_model_time')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && submitcheck('model_time_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $tsort          = intval($_GET['tsort'])>0 ? intval($_GET['tsort']):10;
    $model_time_id  = intval($_GET['model_time_id'])>0 ? intval($_GET['model_time_id']):0;
    
    $start_stamp    = strtotime($start_time);
    $start_stamp    = $start_stamp - $nowDayTime;
    $end_stamp      = strtotime($end_time);
    $end_stamp      = $end_stamp - $nowDayTime;
    
    $updateData = array();
    $updateData['name']         = $name;
    $updateData['start_stamp']  = $start_stamp;
    $updateData['end_stamp']    = $end_stamp;
    $updateData['tsort']        = $tsort;
    C::t('#tom_tcyuyue#tom_tcyuyue_model_time')->update($model_time_id, $updateData);
    
    DB::query("UPDATE ".DB::table('tom_tcyuyue_time')." SET time_name='{$name}',time_start_stamp='{$start_stamp}',time_end_stamp='{$end_stamp}',tsort={$tsort} WHERE model_time_id='{$model_time_id}' ", 'UNBUFFERED');
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('model_time_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $model_time_id = intval($_GET['model_time_id'])>0 ? intval($_GET['model_time_id']):0;
    
    C::t('#tom_tcyuyue#tom_tcyuyue_model_time')->delete_by_id($model_time_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):100;

$modelTimeTypeListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_model_time_type')->fetch_all_list(""," ORDER BY tsort ASC,id DESC ");
$modelTimeTypeList = array();
if(!empty($modelTimeTypeListTmp)){
    foreach ($modelTimeTypeListTmp as $key => $value) {
        $modelTimeTypeList[$value['id']] = $value;
    }
}

$where = "AND model_time_type_id={$model_time_type_id}";
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcyuyue#tom_tcyuyue_model_time')->fetch_all_count($where);
$modelTimeListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_model_time')->fetch_all_list($where," ORDER BY tsort ASC,id DESC ",$start,$pagesize);
$modelTimeList = array();
if(!empty($modelTimeListTmp)){
    foreach ($modelTimeListTmp as $key => $value) {
        $value['start_stamp'] = dgmdate($value['start_stamp'],"H:i",0);
        $value['end_stamp']   = dgmdate($value['end_stamp'],"H:i",0);
        
        $modelTimeList[$key] = $value;
        $modelTimeList[$key]['add_time']    = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:pcadmin/modeltime"); 