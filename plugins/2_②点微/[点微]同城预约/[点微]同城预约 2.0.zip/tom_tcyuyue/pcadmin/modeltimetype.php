<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=modeltimetype";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name       = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tsort      = intval($_GET['tsort'])>0 ? intval($_GET['tsort']):10;
    
    $insertData = array();
    $insertData['name']         = $name;
    $insertData['tsort']        = $tsort;
    $insertData['add_time']     = TIMESTAMP;
    C::t('#tom_tcyuyue#tom_tcyuyue_model_time_type')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tsort          = intval($_GET['tsort'])>0 ? intval($_GET['tsort']):10;
    $model_type_id  = intval($_GET['model_type_id'])>0 ? intval($_GET['model_type_id']):0;
    
    $updateData = array();
    $updateData['name']         = $name;
    $updateData['tsort']        = $tsort;
    $updateData['add_time']     = TIMESTAMP;
    C::t('#tom_tcyuyue#tom_tcyuyue_model_time_type')->update($model_type_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('model_time_type_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $model_time_type_id = intval($_GET['model_time_type_id'])>0 ? intval($_GET['model_time_type_id']):0; 
    
    C::t('#tom_tcyuyue#tom_tcyuyue_model_time_type')->delete_by_id($model_time_type_id);
    C::t('#tom_tcyuyue#tom_tcyuyue_model_time')->delete_by_model_time_type_id($model_time_type_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = "";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcyuyue#tom_tcyuyue_model_time_type')->fetch_all_count($where);
$modelTimeTypeListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_model_time_type')->fetch_all_list($where," ORDER BY tsort ASC,id DESC ",$start,$pagesize);
$modelTimeTypeList = array();
if(!empty($modelTimeTypeListTmp)){
    foreach ($modelTimeTypeListTmp as $key => $value) {
        $modelTimeTypeList[$key] = $value;
        
        $modelTimeTypeList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:pcadmin/modeltimetype");