<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcyuyue_id = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']): 0;
$tcyuyueInfo = C::t("#tom_tcyuyue#tom_tcyuyue")->fetch_by_id($tcyuyue_id);
if(empty($tcyuyueInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($__UserInfo['id'] != $tcyuyueInfo['user_id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=attradd&tcyuyue_id={$tcyuyue_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $type           = intval($_GET['type'])>0? intval($_GET['type']):0;
    $is_must        = intval($_GET['is_must'])>0? intval($_GET['is_must']):0;
    $unit           = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $msg            = isset($_GET['msg'])? addslashes($_GET['msg']):'';
    $is_hidden      = intval($_GET['is_hidden'])>0? intval($_GET['is_hidden']):0;
    $paixu          = intval($_GET['paixu'])>0? intval($_GET['paixu']):10;
    $value          = isset($_GET['value'])? addslashes($_GET['value']):'';
    
    
    $insertData = array();
    $insertData['tcyuyue_id']       = $tcyuyue_id;
    $insertData['name']             = $name;
    $insertData['type']             = $type;
    $insertData['value']            = $value;
    $insertData['is_must']          = $is_must;
    $insertData['is_hidden']        = $is_hidden;
    $insertData['unit']             = $unit;
    $insertData['msg']              = $msg;
    $insertData['paixu']            = $paixu;
    $insertData['add_time']         = TIMESTAMP;
    if(C::t('#tom_tcyuyue#tom_tcyuyue_attr')->insert($insertData)){
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:pcadmin/attradd");