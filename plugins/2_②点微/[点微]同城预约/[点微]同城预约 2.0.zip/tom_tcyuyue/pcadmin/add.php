<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=add";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('title')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcshop_id                  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    $title                      = isset($_GET['title'])? addslashes($_GET['title']):'';
    $type                       = intval($_GET['type'])>0? intval($_GET['type']):1;
    $total_renshu               = intval($_GET['total_renshu'])>0? intval($_GET['total_renshu']):0;
    $before_time                = isset($_GET['before_time'])? intval($_GET['before_time']):0;
    $before_time_unit           = isset($_GET['before_time_unit'])? intval($_GET['before_time_unit']):0;
    $cancel_before_time         = isset($_GET['cancel_before_time'])? intval($_GET['cancel_before_time']):0;
    $cancel_before_time_unit    = isset($_GET['cancel_before_time_unit'])? intval($_GET['cancel_before_time_unit']):0;
    $open_yuyue_queren          = isset($_GET['open_yuyue_queren'])? intval($_GET['open_yuyue_queren']):0;
    $open_clerk                 = isset($_GET['open_clerk'])? intval($_GET['open_clerk']):0;
    $open_clerk_must            = isset($_GET['open_clerk_must'])? intval($_GET['open_clerk_must']):0;
    $clerk_name                 = isset($_GET['clerk_name'])? addslashes($_GET['clerk_name']):'';
    $date_type                  = intval($_GET['date_type'])>0? intval($_GET['date_type']):1;
    $model_time_type_id         = intval($_GET['model_time_type_id'])>0? intval($_GET['model_time_type_id']):0;
    $time_renshu                = intval($_GET['time_renshu'])>0? intval($_GET['time_renshu']):0;
    $yuyue_days                 = intval($_GET['yuyue_days'])>0? intval($_GET['yuyue_days']):$tcyuyueConfig['yuyue_days'];
    $tongzhi_clerk_id           = intval($_GET['tongzhi_clerk_id'])>0? intval($_GET['tongzhi_clerk_id']):0;
    
    $weeksStr = '';
    if(is_array($_GET['weeks']) && !empty($_GET['weeks'])){
        $weeksList = array();
        foreach($_GET['weeks'] as $key => $value){
            $weekTmp = intval($value);
            if(!empty($weekTmp)){
                $weeksList[] = $weekTmp;
            }
        }
        if(is_array($weeksList) && !empty($weeksList)){
            $weeksStr = implode('|', $weeksList);
        }
    }
    
    $daysStr = '';
    if(is_array($_GET['days']) && !empty($_GET['days'])){
        $daysList = array();
        foreach($_GET['days'] as $key => $value){
            $dayTmp = intval($value);
            if(!empty($dayTmp)){
                $daysList[] = $dayTmp;
            }
        }
        if(is_array($daysList) && !empty($daysList)){
            $daysStr = implode('|', $daysList);
        }
    }
    
    $timeIdsArr = array();
    if(is_array($_GET['times']) && !empty($_GET['times'])){
        foreach($_GET['times'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $timeIdsArr[] = $idTmp;
            }
        }
    }
    
    $notDateList = array();
    if(is_array($_GET['notdates']) && !empty($_GET['notdates'])){
        foreach($_GET['notdates'] as $key => $value){
            $dateTmp = addslashes($value);
            
            if(!empty($dateTmp)){
                $dateTimeStampTmp = strtotime($dateTmp);
                
                $year = dgmdate($dateTimeStampTmp, 'Y',$tomSysOffset);
                $month = dgmdate($dateTimeStampTmp, 'n',$tomSysOffset);
                $day = dgmdate($dateTimeStampTmp, 'j',$tomSysOffset);
                
                $time_stamp = mktime(0, 0, 0, $month, $day, $year);
                
                $notDateList[$key]['notdate_stamp'] = $time_stamp;
            }
        }
    }
    
    $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
    if($__Admin['admin'] == 'shopadmin'){
        if($tcshopInfo['user_id'] != $__UserInfo['id']){
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $insertData = array();
    $insertData['site_id']                  = $tcshopInfo['site_id'];
    $insertData['tcshop_id']                = $tcshop_id;
    $insertData['tongzhi_clerk_id']         = $tongzhi_clerk_id;
    $insertData['title']                    = $title;
    $insertData['user_id']                  = $tcshopInfo['user_id'];
    $insertData['type']                     = $type;
    $insertData['date_type']                = $date_type;
    if($date_type == 1){
        $insertData['yuyue_dates']              = $weeksStr;
    }else if($date_type == 2){
        $insertData['yuyue_dates']              = $daysStr;
    }
    $insertData['model_time_type_id']       = $model_time_type_id;
    $insertData['total_renshu']             = $total_renshu;
    $insertData['time_renshu']              = $time_renshu;
    $insertData['before_time']              = $before_time;
    $insertData['before_time_unit']         = $before_time_unit;
    $insertData['cancel_before_time']       = $cancel_before_time;
    $insertData['cancel_before_time_unit']  = $cancel_before_time_unit;
    $insertData['yuyue_days']               = $yuyue_days;
    $insertData['open_yuyue_queren']        = $open_yuyue_queren;
    $insertData['open_clerk']               = $open_clerk;
    if($open_clerk == 1){
        $insertData['open_clerk_must']          = $open_clerk_must;
        $insertData['clerk_name']               = $clerk_name;
    }
    if($__Admin['admin'] == 'shopadmin'){
        if($tcyuyueConfig['must_shenhe'] == 1){
            $insertData['shenhe_status']              = 2;
        }else{
            $insertData['shenhe_status']              = 1;
        }
    }else{
        $insertData['shenhe_status']              = 1;
    }
    $insertData['update_time']              = TIMESTAMP;
    $insertData['add_time']                 = TIMESTAMP;
    if(C::t('#tom_tcyuyue#tom_tcyuyue')->insert($insertData)){
        $tcyuyue_id = C::t('#tom_tcyuyue#tom_tcyuyue')->insert_id();
        
        if(is_array($timeIdsArr) && !empty($timeIdsArr)){
            foreach($timeIdsArr as $key => $value){
                
                $timeInfo = C::t("#tom_tcyuyue#tom_tcyuyue_model_time")->fetch_by_id($value);
                
                $insertData = array();
                $insertData['tcyuyue_id']       = $tcyuyue_id;
                $insertData['model_time_id']    = $timeInfo['id'];
                $insertData['time_name']        = $timeInfo['name'];
                $insertData['time_start_stamp'] = $timeInfo['start_stamp'];
                $insertData['time_end_stamp']   = $timeInfo['end_stamp'];
                $insertData['tsort']            = $timeInfo['tsort'];
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_tcyuyue#tom_tcyuyue_time')->insert($insertData);
            }
        }
        
        if(is_array($notDateList) && !empty($notDateList)){
            foreach($notDateList as $key => $value){
                
                $insertData = array();
                $insertData['tcyuyue_id']       = $tcyuyue_id;
                $insertData['notdate_stamp']    = $value['notdate_stamp'];
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_tcyuyue#tom_tcyuyue_notdate')->insert($insertData);
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

if($__Admin['admin'] == 'shopadmin'){
    $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND vip_status=1 AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,100);
    $tcshopList = array();
    if(!empty($tcshopListTmp)){
        foreach($tcshopListTmp as $key => $value){
            $tcshopList[$value['id']] = $value;
        }
    }
}

$timeTypeListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_model_time_type")->fetch_all_list("", 'ORDER BY tsort ASC,id DESC');
$timeTypeList = array();
$firstTimeTypeId = 0;
if(is_array($timeTypeListTmp) && !empty($timeTypeListTmp)){
    foreach($timeTypeListTmp as $key => $value){
        $timeTypeList[$value['id']] = $value;
        
        if($firstTimeTypeId == 0){
            $firstTimeTypeId = $value['id'];
        }
    }
}

$timeListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_model_time")->fetch_all_list("", 'ORDER BY tsort ASC,id DESC');
$timeList = $timeArr = array();
if(is_array($timeListTmp) && !empty($timeListTmp)){
    foreach ($timeListTmp as $key => $value){
        $timeList[$value['model_time_type_id']][$key] = $value;
        
        $timeArr[$value['model_time_type_id']][$key]['id'] = $value['id'];
        $timeArr[$value['model_time_type_id']][$key]['name'] = diconv($value['name'],CHARSET,'utf-8');
    }
}
$timeData[0] = $timeArr;
$timeArrStr = urlencode(json_encode($timeData));

$daysArr = array();
for($i = 1; $i <= 31; $i++){
    $daysArr[] = $i;
}

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:pcadmin/add");