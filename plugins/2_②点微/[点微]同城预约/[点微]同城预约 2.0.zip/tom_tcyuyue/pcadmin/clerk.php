<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$tcyuyue_id = intval($_GET['tcyuyue_id'])>0 ? intval($_GET['tcyuyue_id']):0;
$tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyue_id);

$modPcadminUrl = $pcadminUrl."&tmod=clerk&tcyuyue_id={$tcyuyue_id}"; 

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $total_renshu       = isset($_GET['total_renshu'])? intval($_GET['total_renshu']):0;
    $time_renshu        = isset($_GET['time_renshu'])? intval($_GET['time_renshu']):0;
    $csort              = isset($_GET['csort'])? intval($_GET['csort']):10;
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    
    $clerkInfoTmp = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_all_list(" AND tcshop_id = {$tcyuyueInfo['tcshop_id']} AND user_id = {$user_id} ", 'ORDER BY id ASC', 0, 1);
    if(is_array($clerkInfoTmp) && !empty($clerkInfoTmp[0])){ }else{
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $yuyueCherkInfoTmp = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_all_list(" AND tcyuyue_id = {$tcyuyue_id} AND user_id = {$user_id} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($yuyueCherkInfoTmp) && !empty($yuyueCherkInfoTmp[0])){
        $outArr = array(
            'code'=> 200,
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $insertData = array();
    $insertData['user_id']          = $user_id;
    $insertData['tcyuyue_id']       = $tcyuyue_id;
    $insertData['total_renshu']     = $total_renshu;
    $insertData['time_renshu']      = $time_renshu;
    $insertData['name']             = $name;
    $insertData['picurl']           = $picurl;
    $insertData['csort']            = $csort;
    $insertData['status']           = 1;
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
        'status'=> 0,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $clerk_id           = isset($_GET['clerk_id'])? intval($_GET['clerk_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $total_renshu       = isset($_GET['total_renshu'])? intval($_GET['total_renshu']):0;
    $time_renshu        = isset($_GET['time_renshu'])? intval($_GET['time_renshu']):0;
    $csort              = isset($_GET['csort'])? intval($_GET['csort']):10;
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    
    $clerkInfo = C::t("#tom_tcyuyue#tom_tcyuyue_clerk")->fetch_by_id($clerk_id);
    $clerkInfoTmp = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_all_list(" AND tcshop_id = {$tcyuyueInfo['tcshop_id']} AND user_id = {$user_id} ", 'ORDER BY id ASC', 0, 1);
    if(is_array($clerkInfoTmp) && !empty($clerkInfoTmp[0])){ }else{
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    
    if($clerkInfo['user_id'] != $user_id){
        $yuyueCherkInfoTmp = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_all_list(" AND tcyuyue_id = {$tcyuyue_id} AND user_id = {$user_id} ", 'ORDER BY id DESC', 0, 1);
        if(is_array($yuyueCherkInfoTmp) && !empty($yuyueCherkInfoTmp[0])){
            $outArr = array(
                'code'=> 200,
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $updateData = array();
    $updateData['user_id']          = $user_id;
    $updateData['total_renshu']     = $total_renshu;
    $updateData['time_renshu']      = $time_renshu;
    $updateData['name']             = $name;
    $updateData['picurl']           = $picurl;
    $updateData['csort']            = $csort;
    C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->update($clerk_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('clerk_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $clerk_id = intval($_GET['clerk_id'])>0 ? intval($_GET['clerk_id']):0;
    
    C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->delete_by_id($clerk_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('clerk_id')){
    $outArr = array(
        'code'=> 1,
    );

    $clerk_id = intval($_GET['clerk_id'])>0 ? intval($_GET['clerk_id']):0;

    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->update($clerk_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('clerk_id')){
    $outArr = array(
        'code'=> 1,
    );

    $clerk_id = intval($_GET['clerk_id'])>0 ? intval($_GET['clerk_id']):0;

    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->update($clerk_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$shopClerkListTmp = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_all_list(" AND tcshop_id = {$tcyuyueInfo['tcshop_id']} ", 'ORDER BY id ASC', 0, 100);
$shopClerkList = array();
if(is_array($shopClerkListTmp) && !empty($shopClerkListTmp)){
    foreach($shopClerkListTmp as $key => $value){
        $shopClerkList[$key] = $value;

        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $shopClerkList[$key]['userInfo'] = $userInfoTmp;
    }
}

$where = "AND tcyuyue_id={$tcyuyue_id}";
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_all_count($where);
$clerkListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$clerkList = array();
if(is_array($clerkListTmp) && !empty($clerkListTmp)){
    foreach ($clerkListTmp as $key => $value) {
        $value['start_stamp'] = dgmdate($value['start_stamp'],"H:i",0);
        $value['end_stamp']   = dgmdate($value['end_stamp'],"H:i",0);
        
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        
        $clerkList[$key] = $value;
        $clerkList[$key]['picurl']      = get_file_url($value['picurl']);
        $clerkList[$key]['userInfo']    = $userInfoTmp;
        $clerkList[$key]['add_time']    = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:pcadmin/clerk"); 