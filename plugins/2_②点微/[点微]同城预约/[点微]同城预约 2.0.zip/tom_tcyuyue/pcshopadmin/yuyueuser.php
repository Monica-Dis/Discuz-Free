<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=yuyueuser";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if(!empty($act) && submitcheck('tcyuyue_log_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcyuyue_log_id = intval($_GET['tcyuyue_log_id'])>0 ? intval($_GET['tcyuyue_log_id']):0;
    
    $tcyuyueLogInfo = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_by_id($tcyuyue_log_id);
    if($tcyuyueLogInfo){
        $tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyueLogInfo['tcyuyue_id']);
        if($__UserInfo['id'] != $tcyuyueInfo['user_id']){
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['no_quanxian_error'],CHARSET,'utf-8'),
            );    
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
        );    
        echo json_encode($outArr); exit;
    }
    
    if($act == 'info'){
        
        $userAttrListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_log_attr')->fetch_all_list(" AND tcyuyue_log_id={$tcyuyueLogInfo['id']} "," ORDER BY paixu ASC,id DESC ");
        $userAttrList = array();
        if(!empty($userAttrListTmp)){
            foreach($userAttrListTmp as $key => $value){
                $userAttrList[$key] = $value;

                if($value['attr_type'] == 4){
                    $userAttrList[$key]['valueList'] = explode('|', $value['value']);
                }
            }
        }
        
        $tcyuyueLogInfo['userAttrList'] = $userAttrList;
        
        $list = iconv_to_utf8($tcyuyueLogInfo);
        $outArr = array(
            'code'  => 200,
            "data"  => $list
        );
        echo json_encode($outArr); exit;
    }else if($act == 'queren'){

        $updateData = array();
        $updateData['yuyue_status'] = 1;
        C::t('#tom_tcyuyue#tom_tcyuyue_log')->update($tcyuyue_log_id, $updateData);
        
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcyuyueLogInfo['user_id']);
        $tcyuyueInfo = C::t("#tom_tcyuyue#tom_tcyuyue")->fetch_by_id($tcyuyueLogInfo['tcyuyue_id']);
        
        $yuyueMsg = str_replace('{TITLE}', $tcyuyueInfo['title'], $Lang['yuyueuser_yuyue_status_ok']);
        $yuyueMsgTz = $yuyueMsg.'<br/><a href="plugin.php?id=tom_tcyuyue&site='.$tcyuyueInfo['site_id'].'&mod=yuyue">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcyuyueConfig['plugin_name'].'</font><br/>'.$yuyueMsgTz.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$tcyuyueInfo['site_id']}&mod=yuyue");
                $smsData = array(
                    'first'         => $yuyueMsg,
                    'keyword1'      => $tcyuyueConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($act == 'fail'){
        
        if('utf-8' != CHARSET) {
            if(defined('IN_MOBILE')){
            }else{
                foreach($_POST AS $pk => $pv) {
                    if(!is_numeric($pv)) {
                        $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                    }
                }
            }
        }

        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $updateData = array();
        $updateData['yuyue_status'] = 4;
        $updateData['shenhe_msg']   = $text;
        C::t('#tom_tcyuyue#tom_tcyuyue_log')->update($tcyuyue_log_id, $updateData);
        
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcyuyueLogInfo['user_id']);
        $tcyuyueInfo = C::t("#tom_tcyuyue#tom_tcyuyue")->fetch_by_id($tcyuyueLogInfo['tcyuyue_id']);
        
        $yuyueMsg = str_replace('{TITLE}', $tcyuyueInfo['title'], $Lang['yuyueuser_yuyue_status_no']);
        $yuyueMsgTz = $yuyueMsg.'<br/><a href="plugin.php?id=tom_tcyuyue&site='.$tcyuyueInfo['site_id'].'&mod=yuyue">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcyuyueConfig['plugin_name'].'</font><br/>'.$yuyueMsgTz.'<br/>'.$Lang['yuyueuser_yuyue_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$tcyuyueInfo['site_id']}&mod=yuyue");
                $smsData = array(
                    'first'         => $yuyueMsg,
                    'keyword1'      => $tcyuyueConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
}

$tcyuyue_id         = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
$yuyue_time         = isset($_GET['yuyue_time'])? addslashes($_GET['yuyue_time']):'';
$time_id            = isset($_GET['time_id'])? intval($_GET['time_id']):0;
$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$yuyue_status       = isset($_GET['yuyue_status'])? intval($_GET['yuyue_status']):0;

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$yuyueTimeStamp = strtotime($yuyue_time);
$yuyueTimeStamp = gmmktime(0,0,0,dgmdate($yuyueTimeStamp, 'n',$tomSysOffset),dgmdate($yuyueTimeStamp, 'j',$tomSysOffset),dgmdate($yuyueTimeStamp, 'Y',$tomSysOffset)) - $tomSysOffset*3600;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$tcyuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list(" AND user_id = {$__UserInfo['id']} ");
$tcyuyueIdsArr = array();
if(!empty($tcyuyueListTmp)){
    foreach($tcyuyueListTmp as $key => $value){
        $tcyuyueIdsArr[] = $value['id'];
    }
}

if($tcyuyue_id > 0){
    $timeListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_time")->fetch_all_list(" AND tcyuyue_id = {$tcyuyue_id} ", 'ORDER BY id ASC');
    $timeList = array();
    if(is_array($timeListTmp) && !empty($timeListTmp)){
        foreach($timeListTmp as $key => $value){
            $timeList[$key] = $value;
        }
    }
}

if(!empty($tcyuyueIdsArr)){
    $tcyuyueIdsStr = implode(',', $tcyuyueIdsArr);
    $where = " AND tcyuyue_id IN({$tcyuyueIdsStr}) ";
}else{
    $where = " AND tcyuyue_id = 0 ";
}
if($tcyuyue_id > 0){
    $where.= " AND tcyuyue_id={$tcyuyue_id} ";
}
if(!empty($yuyue_time)){
    $where.= " AND yuyue_daytime={$yuyueTimeStamp} ";
}
if($time_id > 0){
    $where.= " AND time_id={$time_id} ";
}
if($user_id > 0){
    $where.= " AND user_id={$user_id} ";
}
if($yuyue_status > 0){
    $where.= " AND yuyue_status={$yuyue_status} ";
}else{
    $where.= " AND yuyue_status > 0 ";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_all_count($where);
$tcyuyueLogListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$tcyuyueLogList = array();
if(is_array($tcyuyueLogListTmp) && !empty($tcyuyueLogListTmp)){
    foreach ($tcyuyueLogListTmp as $key => $value) {
        $tcyuyueLogList[$key] = $value;
        
        $tcyuyueInfoTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($value['tcyuyue_id']);
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        
        $goodsInfoTmp = array();
        if($value['yuyue_type'] == 'ptuan'){
            $goodsInfoTmp = C::t("#tom_tcptuan#tom_tcptuan_goods")->fetch_by_id($value['goods_id']);
        }else if($value['yuyue_type'] == 'qianggou'){
            $goodsInfoTmp = C::t("#tom_tcqianggou#tom_tcqianggou_goods")->fetch_by_id($value['goods_id']);
        }else if($value['yuyue_type'] == 'shop'){
            $goodsInfoTmp = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($value['goods_id']);
        }
        
        $hexiaoUserInfoTmp = array();
        if($value['yuyue_status'] == 2){
            $hexiaoUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']); 
        }
        
        $value['time_start_stamp'] = $value['time_start_stamp'] + $value['yuyue_daytime'];
        $value['time_end_stamp'] = $value['time_end_stamp'] + $value['yuyue_daytime'];
        
        $tcyuyueLogList[$key]['tcyuyueInfo']     = $tcyuyueInfoTmp;
        $tcyuyueLogList[$key]['userInfo']        = $userInfoTmp;
        $tcyuyueLogList[$key]['hexiaoUserInfo']  = $hexiaoUserInfoTmp;
        $tcyuyueLogList[$key]['goodsInfo']       = $goodsInfoTmp;
        $tcyuyueLogList[$key]['start_time']      = dgmdate($value['time_start_stamp'],"Y-m-d H:i",$tomSysOffset);
        $tcyuyueLogList[$key]['end_time']        = dgmdate($value['time_end_stamp'],"H:i",$tomSysOffset);
        $tcyuyueLogList[$key]['add_time']        = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $tcyuyueLogList[$key]['hexiao_time']     = dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&tcyuyue_id={$tcyuyue_id}&user_id={$user_id}&yuyue_status={$yuyue_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:pcshopadmin/yuyueuser");