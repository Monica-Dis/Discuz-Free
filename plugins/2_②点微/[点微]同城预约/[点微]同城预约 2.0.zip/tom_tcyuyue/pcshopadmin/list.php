<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=list";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';
if(!empty($act) && submitcheck('tcyuyue_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcyuyue_id = intval($_GET['tcyuyue_id'])>0 ? intval($_GET['tcyuyue_id']):0;
    
    $tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyue_id);
    if($tcyuyueInfo){
        if($__UserInfo['id'] != $tcyuyueInfo['user_id']){
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['no_quanxian_error'],CHARSET,'utf-8'),
            );    
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
        );    
        echo json_encode($outArr); exit;
    }
    
    if($act == 'show'){

        $updateData = array();
        $updateData['status'] = 1;
        C::t('#tom_tcyuyue#tom_tcyuyue')->update($tcyuyue_id, $updateData);
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($act == 'hide'){
        
        $updateData = array();
        $updateData['status'] = 2;
        C::t('#tom_tcyuyue#tom_tcyuyue')->update($tcyuyue_id, $updateData);
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($act == 'update_open_yuyue_queren'){
        
        $open_yuyue_queren  = intval($_GET['open_yuyue_queren'])>0 ? intval($_GET['open_yuyue_queren']):0;

        $updateData = array();
        $updateData['open_yuyue_queren'] = $open_yuyue_queren;
        C::t('#tom_tcyuyue#tom_tcyuyue')->update($tcyuyue_id, $updateData);
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
}

$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$tcyuyue_id         = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
$title              = isset($_GET['title'])? addslashes($_GET['title']):'';
$status             = isset($_GET['status'])? intval($_GET['status']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = " AND user_id = {$__UserInfo['id']} ";
if(!empty($site_id)){
    $where.= " AND site_id={$site_id} ";
}
if($tcyuyue_id > 0){
    $where.= " AND id={$tcyuyue_id} ";
}
if(!empty($status)){
    if($status == 1){
        $where.= " AND status={$status} ";
    }else{
        $where.= " AND status=0 ";
    }
}
if(!empty($shenhe_status)){
    $where.= " AND shenhe_status={$shenhe_status} ";
}

if(!empty($title)){
    $title = str_replace(array('%', '_'),'',$title);
    $where .= " AND title LIKE '%{$title}%'";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_count($where);
$yuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$yuyueList = array();
if(!empty($yuyueListTmp)){
    foreach ($yuyueListTmp as $key => $value) {
        $yuyueList[$key] = $value;
        
        $siteInfoTmp        = $sitesList[$value['site_id']];
        
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $tcshopUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfoTmp['user_id']); 
        
        $yuyueList[$key]['picurl']          = get_file_url($value['picurl']);
        $yuyueList[$key]['siteInfo']        = $siteInfoTmp;
        $yuyueList[$key]['tcshopInfo']      = $tcshopInfoTmp;
        $yuyueList[$key]['tcshopUserInfo']  = $tcshopUserInfoTmp;
        $yuyueList[$key]['add_time']        = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&title={$title}&tcyuyue_id={$tcyuyue_id}&status={$status}&shenhe_status={$shenhe_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:pcshopadmin/list");