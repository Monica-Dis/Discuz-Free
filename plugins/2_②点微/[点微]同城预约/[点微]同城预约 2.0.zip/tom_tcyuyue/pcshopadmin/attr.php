<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcyuyue_id = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']): 0;
$tcyuyueInfo = C::t("#tom_tcyuyue#tom_tcyuyue")->fetch_by_id($tcyuyue_id);
if(empty($tcyuyueInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__UserInfo['id'] != $tcyuyueInfo['user_id']){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=attr&tcyuyue_id={$tcyuyue_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if(!empty($act) && submitcheck('attr_id')){
    $outArr = array(
        'code'=> 1,
    );

    $attr_id = intval($_GET['attr_id'])>0 ? intval($_GET['attr_id']):0;
    
    $attrInfo = C::t('#tom_tcyuyue#tom_tcyuyue_attr')->fetch_by_id($attr_id);
    if($attrInfo){
        if($tcyuyue_id != $attrInfo['tcyuyue_id']){
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['no_quanxian_error'],CHARSET,'utf-8'),
            );    
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
        );    
        echo json_encode($outArr); exit;
    }
    
    if($act == 'update_is_must'){

        $is_must = intval($_GET['is_must'])>0 ? intval($_GET['is_must']):0;

        $updateData = array();
        $updateData['is_must'] = $is_must;
        C::t('#tom_tcyuyue#tom_tcyuyue_attr')->update($attr_id, $updateData);
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($act == 'update_is_hidden' && submitcheck('attr_id')){

        $is_hidden   = intval($_GET['is_hidden'])>0 ? intval($_GET['is_hidden']):0;

        $updateData = array();
        $updateData['is_hidden'] = $is_hidden;
        C::t('#tom_tcyuyue#tom_tcyuyue_attr')->update($attr_id, $updateData);
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($act == 'del'){

        C::t('#tom_tcyuyue#tom_tcyuyue_attr')->delete_by_id($attr_id);

        $outArr = array(
            'code'=> 200,
        );    
        echo json_encode($outArr); exit;
    }
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = " AND tcyuyue_id={$tcyuyue_id} ";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcyuyue#tom_tcyuyue_attr')->fetch_all_count($where);
$attrListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_attr')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$attrList = array();
if(!empty($attrListTmp)){
    foreach ($attrListTmp as $key => $value) {
        $attrList[$key] = $value;
        
        $attrList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:pcshopadmin/attr");