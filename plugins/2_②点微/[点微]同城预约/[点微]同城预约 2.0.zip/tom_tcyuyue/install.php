<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcyuyue`;
CREATE TABLE `pre_tom_tcyuyue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '1',
  `date_type` tinyint(4) DEFAULT '0',
  `model_time_type_id` int(11) DEFAULT '0',
  `yuyue_dates` varchar(255) DEFAULT NULL,
  `total_renshu` int(11) DEFAULT '0',
  `time_renshu` int(11) DEFAULT '0',
  `before_time` int(11) DEFAULT '0',
  `before_time_unit` tinyint(4) DEFAULT '0',
  `cancel_before_time` int(11) DEFAULT '0',
  `cancel_before_time_unit` tinyint(4) DEFAULT '0',
  `yuyue_days` int(11) DEFAULT '0',
  `open_yuyue_queren` tinyint(4) DEFAULT '0',
  `open_clerk` int(11) DEFAULT '0',
  `open_clerk_must` tinyint(4) DEFAULT '0',
  `clerk_name` varchar(255) DEFAULT NULL,
  `tongzhi_clerk_id` int(11) DEFAULT '0',
  `shenhe_status` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `update_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_tcshop_id` (`tcshop_id`),
  KEY `idx_type` (`type`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyuyue_attr`;
CREATE TABLE `pre_tom_tcyuyue_attr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcyuyue_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '1',
  `value` text,
  `is_must` int(11) DEFAULT '0',
  `is_hidden` tinyint(4) DEFAULT '0',
  `unit` varchar(255) DEFAULT NULL,
  `msg` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '10',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyuyue_clerk`;
CREATE TABLE `pre_tom_tcyuyue_clerk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tcyuyue_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `total_renshu` int(11) DEFAULT '0',
  `time_renshu` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `csort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyuyue_log`;
CREATE TABLE `pre_tom_tcyuyue_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcyuyue_id` int(11) DEFAULT '0',
  `clerk_id` int(11) DEFAULT '0',
  `yuyue_type` varchar(255) DEFAULT NULL,
  `goods_id` int(11) DEFAULT '0',
  `order_no` varchar(255) DEFAULT NULL,
  `time_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `beizu` varchar(255) DEFAULT NULL,
  `time_name` varchar(255) DEFAULT NULL,
  `time_start_stamp` int(11) unsigned DEFAULT '0',
  `time_end_stamp` int(11) unsigned DEFAULT '0',
  `yuyue_status` tinyint(4) DEFAULT '0',
  `yuyue_daytime` int(11) unsigned DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_time` int(11) unsigned DEFAULT '0',
  `shenhe_msg` varchar(255) DEFAULT NULL,
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tcyuyue_id` (`tcyuyue_id`) USING BTREE,
  KEY `idx_clerk_id` (`clerk_id`),
  KEY `idx_yuyue_type` (`yuyue_type`),
  KEY `idx_goods_id` (`goods_id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_time_id` (`time_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_yuyue_status` (`yuyue_status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyuyue_log_attr`;
CREATE TABLE `pre_tom_tcyuyue_log_attr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcyuyue_log_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `tcyuyue_id` int(11) DEFAULT '0',
  `attr_id` int(11) DEFAULT '0',
  `attr_type` int(11) DEFAULT '0',
  `attr_name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyuyue_model_time`;
CREATE TABLE `pre_tom_tcyuyue_model_time` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_time_type_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `start_stamp` int(11) unsigned DEFAULT '0',
  `end_stamp` int(11) unsigned DEFAULT '0',
  `tsort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyuyue_model_time_type`;
CREATE TABLE `pre_tom_tcyuyue_model_time_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `tsort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyuyue_notdate`;
CREATE TABLE `pre_tom_tcyuyue_notdate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcyuyue_id` int(11) DEFAULT '0',
  `notdate_stamp` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyuyue_time`;
CREATE TABLE `pre_tom_tcyuyue_time` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcyuyue_id` int(11) DEFAULT '0',
  `model_time_id` int(11) DEFAULT '0',
  `time_name` varchar(255) DEFAULT NULL,
  `time_start_stamp` int(11) unsigned DEFAULT '0',
  `time_end_stamp` int(11) unsigned DEFAULT '0',
  `tsort` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;