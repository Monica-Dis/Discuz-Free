<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcyuyue'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcyuyue&pmod=admin';
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcyuyue&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcyuyue&pmod=admin';

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){
}else{
    echo '<a href="https://dism.taobao.com/?@tom_tongcheng.plugin">https://dism.taobao.com/?@tom_tongcheng.plugin</a>';exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/class/function.a.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/config/config.data.php';
$tcyuyueConfig = get_plugin_config($pluginid);
$Lang = formatLang($Lang);

$tongchengPlugin = C::t('#tom_tcyuyue#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

if($_GET['tmod'] == 'index'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/admin/index.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/admin/index.php';
}