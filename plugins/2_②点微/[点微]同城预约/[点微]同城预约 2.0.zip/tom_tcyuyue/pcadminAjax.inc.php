<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
if($_GET['act'] == 'modeltimeinfo' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );

    $model_time_id = intval($_GET['model_time_id'])>0 ? intval($_GET['model_time_id']):0;
    
    $modelTimeInfo = C::t('#tom_tcyuyue#tom_tcyuyue_model_time')->fetch_by_id($model_time_id);
    $modelTimeInfo['start_stamp'] = dgmdate($modelTimeInfo['start_stamp'],"H:i",0);
    $modelTimeInfo['end_stamp']   = dgmdate($modelTimeInfo['end_stamp'],"H:i",0);
    
    $list = iconv_to_utf8($modelTimeInfo);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'clerkinfo' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );

    $clerk_id = intval($_GET['clerk_id'])>0 ? intval($_GET['clerk_id']):0;
    
    $clerkInfo = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_by_id($clerk_id);
    $clerkInfo['picurlTmp'] = get_file_url($clerkInfo['picurl']);
    
    $list = iconv_to_utf8($clerkInfo);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'tcyuyue_time' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );

    $tcyuyue_id = intval($_GET['tcyuyue_id'])>0 ? intval($_GET['tcyuyue_id']):0;
    
    $timeListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_time")->fetch_all_list(" AND tcyuyue_id = {$tcyuyue_id} ", 'ORDER BY id ASC');
    $timeList = array();
    if(is_array($timeListTmp) && !empty($timeListTmp)){
        foreach($timeListTmp as $key => $value){
            $timeList[$key] = $value;
        }
    }
    
    $list = iconv_to_utf8($timeList);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'model_type_import' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/config/import.data.php';
    
    foreach($modelTypeArr as $key => $value){
        $insertData = array();
        $insertData['name']     = $value['name'];
        $insertData['tsort']    = $key;
        $insertData['add_time'] = TIMESTAMP;
        $model_time_type_id = C::t("#tom_tcyuyue#tom_tcyuyue_model_time_type")->insert($insertData, true);
        if($model_time_type_id > 0){
            foreach ($value['list'] as $k => $v){
                $insertData = array();
                $insertData['model_time_type_id']   = $model_time_type_id;
                $insertData['name']                 = $v['name'];
                $insertData['start_stamp']          = $v['start_stamp'];
                $insertData['end_stamp']            = $v['end_stamp'];
                $insertData['tsort']                = $k;
                $insertData['add_time']             = TIMESTAMP;
                C::t("#tom_tcyuyue#tom_tcyuyue_model_time")->insert($insertData);
            }
        }
    }
    
    $outArr = array(
        'code'  => 200,
    );
    echo json_encode($outArr); exit;
    
}else{
    echo 'error';exit;
}