<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tcyuyueConfig = $_G['cache']['plugin']['tom_tcyuyue'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tcqianggou start
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
    $tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
    if($tcqianggouConfig['open_tcqianggou'] == 1){
        $__ShowTcqianggou = 1;
    }
}
## tcqianggou end
## tcptuan start
$__ShowTcptuan = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcptuan/tom_tcptuan.inc.php')){
    $tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
    if($tcptuanConfig['open_tcptuan'] == 1){
        $__ShowTcptuan = 1;
    }
}
## tcptuan end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesinfo.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/class/function.core.php';

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

if($_GET['act'] == 'load_time' && $_GET['formhash'] == FORMHASH){
    
    $outStr = '';

    $time_stamp         = intval($_GET['time_stamp'])>0? intval($_GET['time_stamp']):0;
    $tcyuyue_id         = intval($_GET['tcyuyue_id'])>0? intval($_GET['tcyuyue_id']):0;
    $tcyuyue_log_id     = intval($_GET['tcyuyue_log_id'])>0? intval($_GET['tcyuyue_log_id']):0;
    $hexiao_time        = intval($_GET['hexiao_time'])? intval($_GET['hexiao_time']):'';
    
    $tcyuyueInfo = C::t("#tom_tcyuyue#tom_tcyuyue")->fetch_by_id($tcyuyue_id);
    $datesArr = array();
    if(!empty($tcyuyueInfo['yuyue_dates'])){
        $datesArr = explode('|', $tcyuyueInfo['yuyue_dates']);
    }
    
    $week = dgmdate($time_stamp, 'N',$tomSysOffset);
    $day = dgmdate($time_stamp, 'j',$tomSysOffset);
    $dayTime = gmmktime(0,0,0,dgmdate($time_stamp, 'n',$tomSysOffset),dgmdate($time_stamp, 'j',$tomSysOffset),dgmdate($time_stamp, 'Y',$tomSysOffset)) - $tomSysOffset*3600;
    
    $notDateListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_notdate")->fetch_all_list(" AND tcyuyue_id = {$tcyuyue_id} AND notdate_stamp = {$dayTime} ", 'ORDER BY id ASC');
    $allNotDateStatus = 0;
    if(is_array($notDateListTmp) && !empty($notDateListTmp[0])){
        $allNotDateStatus = 1;
    }
    
    if($tcyuyue_log_id > 0){
        $tcyuyueLogInfo = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_by_id($tcyuyue_log_id);
    }
    
    $xianzhiYuyueStamp = 0;
    if($tcyuyueInfo['before_time_unit'] == 1){
        $xianzhiYuyueStamp = $tcyuyueInfo['before_time'] * 60 + TIMESTAMP;
    }else if($tcyuyueInfo['before_time_unit'] == 2){
        $xianzhiYuyueStamp = $tcyuyueInfo['before_time'] * 3600 + TIMESTAMP;
    }else if($tcyuyueInfo['before_time_unit'] == 3){
        $xianzhiYuyueStamp = $tcyuyueInfo['before_time'] * 86400 + TIMESTAMP;
    }
    
    $tcyuyueLogTotalCount = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_all_count(" AND tcyuyue_id = {$tcyuyue_id} AND yuyue_status IN(1,2,3) AND yuyue_daytime = {$dayTime} AND id != {$tcyuyue_log_id} ");
    
    $timeListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_time")->fetch_all_list(" AND tcyuyue_id = {$tcyuyue_id} ", 'ORDER BY tsort ASC,id ASC');
    $timeList = array();
    if(is_array($timeListTmp) && !empty($timeListTmp)){
        foreach($timeListTmp as $key => $value){
            $timeList[$key] = $value;
            
            $yuyueStatus = 1;
            if($tcyuyueInfo['date_type'] == 1){
                if(!in_array($week, $datesArr)){
                    $yuyueStatus = 2;
                }
            }else{
                if(!in_array($day, $datesArr)){
                    $yuyueStatus = 2;
                }
            }
            
            if($yuyueStatus == 1){
                if($allNotDateStatus == 1){
                    $yuyueStatus = 2;
                }
            }
            
            $startTimeStampTmp = $value['time_start_stamp'] + $dayTime;
            if($yuyueStatus == 1 && $xianzhiYuyueStamp >= $startTimeStampTmp){
                $yuyueStatus = 2;
            }
            
            $endTimeStampTmp = $value['time_end_stamp'] + $dayTime;
            if($hexiao_time > 0 && $endTimeStampTmp > $hexiao_time){
                $yuyueStatus = 2;
            }
            
            if($yuyueStatus == 1){
                if($tcyuyueLogTotalCount > 0 && $tcyuyueInfo['total_renshu'] > 0 && $tcyuyueLogTotalCount >= $tcyuyueInfo['total_renshu']){
                    $yuyueStatus = 3;
                }
            }
            if($yuyueStatus == 1 && $tcyuyueInfo['time_renshu'] > 0){
                $tcyuyueLogCount = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_all_count(" AND time_id = {$value['id']} AND yuyue_status IN(1,2,3) AND yuyue_daytime = {$dayTime} AND id != {$tcyuyue_log_id} ");
                if($tcyuyueLogCount > 0 && $tcyuyueLogCount >= $tcyuyueInfo['time_renshu']){
                    $yuyueStatus = 3;
                }
            }
            
            $yuyueUserSeleted = 0;
            if($tcyuyue_log_id > 0 && $tcyuyueLogInfo['yuyue_daytime'] == $dayTime && $value['id'] == $tcyuyueLogInfo['time_id']){
                $yuyueUserSeleted = 1;
            }
            
            $timeList[$key]['yuyueStatus']      = $yuyueStatus;
            $timeList[$key]['yuyueUserSeleted'] = $yuyueUserSeleted;
            $timeList[$key]['startStamp']       = dgmdate($value['time_start_stamp'], 'H:i',0);
        }
    }

    if(is_array($timeList) && !empty($timeList)){
        foreach ($timeList as $key => $val){
            if($val['yuyueUserSeleted'] == 1){
                $outStr .= '<a class="yuyue-time__item yuyue_time__btn on" href="javascript:void(0);" data-daytime="'.$dayTime.'" data-id="'.$val['id'].'">';
            }else{
                if($val['yuyueStatus'] == 1){
                    $outStr .= '<a class="yuyue-time__item yuyue_time__btn " href="javascript:void(0);" data-daytime="'.$dayTime.'" data-id="'.$val['id'].'">';
                }else if($val['yuyueStatus'] == 2 || $val['yuyueStatus'] == 3){
                    $outStr .= '<a class="yuyue-time__item yuyue-time__status2" href="javascript:void(0);">';
                }
            }
                $outStr .= '<div class="time-box">';
                    $outStr .= '<div class="time">'.$val['time_name'].'</div>';
                    if($val['yuyueUserSeleted'] == 0){
                        if($val['yuyueStatus'] == 1){
                        }else if($val['yuyueStatus'] == 2){
                            $outStr .= '<div class="status">'.lang('plugin/tom_tcyuyue', 'ajax_yuyue_time_status_2').'</div>';
                        }else if($val['yuyueStatus'] == 3){
                            $outStr .= '<div class="status">'.lang('plugin/tom_tcyuyue', 'ajax_yuyue_time_status_3').'</div>';
                        }
                    }
                $outStr .= '</div>';
            $outStr .= '</div>';
        }

    }else{
        $outStr = '205';
    }
    
    $outStr = tom_link_replace($outStr);
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($_GET['act'] == 'load_clerk' && $_GET['formhash'] == FORMHASH){
    
    $outStr = '';

    $daytime            = intval($_GET['daytime'])>0? intval($_GET['daytime']):0;
    $time_id            = intval($_GET['time_id'])>0? intval($_GET['time_id']):0;
    $tcyuyue_id         = intval($_GET['tcyuyue_id'])>0? intval($_GET['tcyuyue_id']):0;
    $tcyuyue_log_id     = intval($_GET['tcyuyue_log_id'])>0? intval($_GET['tcyuyue_log_id']):0;
    
    $tcyuyueInfo = C::t("#tom_tcyuyue#tom_tcyuyue")->fetch_by_id($tcyuyue_id);
    
    if($tcyuyue_log_id > 0){
        $tcyuyueLogInfo = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_by_id($tcyuyue_log_id);
    }
    
    $clerkListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_clerk")->fetch_all_list(" AND tcyuyue_id = {$tcyuyueInfo['id']} AND status = 1 ", 'ORDER BY csort ASC, id DESC');
    $clerkList = array();
    if(is_array($clerkListTmp) && !empty($clerkListTmp)){
        foreach($clerkListTmp as $key => $value){
            $clerkList[$key] = $value;

            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                    $value['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $value['picurl'] = $_G['siteurl'].$value['picurl'];
                }
            }else{
                $value['picurl'] = $value['picurl'];
            }
            $clerkList[$key]['picurl'] = $value['picurl'];
            $clerkList[$key]['yuyue_status'] = 0;
            
            if($time_id > 0){
                $tcyuyueTimeLogCount = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_all_count(" AND clerk_id = {$value['id']} AND tcyuyue_id = {$tcyuyueInfo['id']} AND time_id = {$time_id} AND yuyue_daytime = {$daytime} AND yuyue_status IN(1,2,3) AND id !={$tcyuyue_log_id} ");
                if($value['time_renshu'] > 0 && $tcyuyueTimeLogCount >= $value['time_renshu']){
                    $clerkList[$key]['yuyue_status'] = 2;
                }else{
                    $tcyuyueTotalLogCount = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_all_count(" AND clerk_id = {$value['id']} AND tcyuyue_id = {$tcyuyueInfo['id']} AND yuyue_daytime = {$daytime} AND yuyue_status IN(1,2,3) AND id !={$tcyuyue_log_id}");
                    if($value['total_renshu'] > 0 && $tcyuyueTotalLogCount >= $value['total_renshu']){
                        $clerkList[$key]['yuyue_status'] = 2;
                    }else{
                        $clerkList[$key]['yuyue_status'] = 1;
                    }
                }
            }
        }
    }
    
    if(is_array($clerkList) && !empty($clerkList)){
        foreach ($clerkList as $key => $val){
            if($val['yuyue_status'] == 1){
                if($tcyuyue_log_id > 0 && $tcyuyueLogInfo['clerk_id'] == $val['id']){
                    $outStr .= '<div class="clerk_item clerk_item_btn on" data-id='.$val['id'].'>';
                }else{
                    $outStr .= '<div class="clerk_item clerk_item_btn" data-id='.$val['id'].'>';
                }
            }else{
                $outStr .= '<div class="clerk_item clerk_item_no_btn" data-status="'.$val['yuyue_status'].'">';
            }
                $outStr .= '<div class="clerk_pic">';
                    $outStr .= '<img src="'.$val['picurl'].'">';
                $outStr .= '</div>';
                $outStr .= '<div class="clerk_name">'.$val['name'].'</div>';
                $outStr .= '<div class="clerk_status">';
                    if($val['yuyue_status'] == 1){
                        $outStr .= '<span class="status_1">'.lang('plugin/tom_tcyuyue', 'ajax_info_cherk_yuyue_status_1').'</span>';
                    }else if($val['yuyue_status'] == 2){
                        $outStr .= '<span class="status_2">'.lang('plugin/tom_tcyuyue', 'ajax_info_cherk_yuyue_status_2').'</span>';
                    }
                $outStr .= '</div>';
                $outStr .= '<div class="clerk_quan"><i></i></div>';
            $outStr .= '</div>';
        }

    }else{
        $outStr = '205';
    }
    
    $outStr = tom_link_replace($outStr);
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
}else if($_GET['act'] == 'updateStatus' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $tcyuyue_id = intval($_GET['tcyuyue_id'])>0? intval($_GET['tcyuyue_id']):0;
    
    $tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyue_id);
    
    if($tcyuyueInfo['user_id'] != $__UserInfo['id']){
        echo '404';exit;
    }
    
    if($_GET['status'] == 1){
        $updateData = array();
        $updateData['status'] = 1;
        C::t('#tom_tcyuyue#tom_tcyuyue')->update($tcyuyue_id,$updateData);
    }else{
        $updateData = array();
        $updateData['status'] = 0;
        C::t('#tom_tcyuyue#tom_tcyuyue')->update($tcyuyue_id,$updateData);
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'querenYuyue' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $tcyuyue_log_id     = intval($_GET['tcyuyue_log_id'])>0? intval($_GET['tcyuyue_log_id']):0;
    
    $tcyuyueLogInfo = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_by_id($tcyuyue_log_id);
    $tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyueLogInfo['tcyuyue_id']);
    
    if($tcyuyueInfo['user_id'] != $__UserInfo['id']){
        $clerkInfoTmp = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_all_list(" AND tcshop_id = {$tcyuyueInfo['tcshop_id']} AND user_id = {$__UserInfo['id']} ", 'ORDER BY id DESC', 0, 1);
        if(is_array($clerkInfoTmp) && !empty($clerkInfoTmp[0])){ }else{
            echo '404';exit;
        }
    }
    
    if($tcyuyueLogInfo['yuyue_status'] == 3 || $tcyuyueLogInfo['yuyue_status'] == 4){ }else{
        echo '301';exit;
    }
    
    $updateData = array();
    $updateData['yuyue_status'] = 1;
    C::t('#tom_tcyuyue#tom_tcyuyue_log')->update($tcyuyue_log_id,$updateData);
    
    if(!empty($tongchengConfig['template_id'])){
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        
        if($site_id > 1){
            $site_name = $siteInfo['name'];
        }else{
            $site_name = $tongchengConfig['plugin_name'];
        }

        $template_sms = str_replace("{TITLE}",$tcyuyueInfo['title'], lang('plugin/tom_tcyuyue','shenhe_yuyue_queren_ok_template'));

        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcyuyueLogInfo['user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($toUser['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=yuyue&tcyuyue_log_id={$tcyuyue_log_id}");
            $smsData = array(
                'first'         => $template_sms,
                'keyword1'      => $site_name,
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'cancelYuyue' && $_GET['formhash'] == FORMHASH && $userStatus){

    
    $tcyuyue_log_id = intval($_GET['tcyuyue_log_id'])>0? intval($_GET['tcyuyue_log_id']):0;
    
    $tcyuyueLogInfo = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_by_id($tcyuyue_log_id);
    $tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyueLogInfo['tcyuyue_id']);
    
    if($tcyuyueLogInfo['user_id'] != $__UserInfo['id']){
        echo '404';exit;
    }
    
    if($tcyuyueLogInfo['yuyue_status'] == 3 || $tcyuyueLogInfo['yuyue_status'] == 1){ }else{
        echo '301';exit;
    }
    
    $cancelBeforeTime = 0;
    if($tcyuyueInfo['cancel_before_time_unit'] == 1){
        $cancelBeforeTime = $tcyuyueInfo['cancel_before_time'] * 60 + TIMESTAMP;
    }else if($tcyuyueInfo['cancel_before_time_unit'] == 2){
        $cancelBeforeTime = $tcyuyueInfo['cancel_before_time'] * 3600 + TIMESTAMP;
    }else if($tcyuyueInfo['cancel_before_time_unit'] == 3){
        $cancelBeforeTime = $tcyuyueInfo['cancel_before_time'] * 86400 + TIMESTAMP;
    }
    $yuyueTime = $tcyuyueLogInfo['time_start_stamp'] + $tcyuyueLogInfo['yuyue_daytime'];
    if($cancelBeforeTime >= $yuyueTime){
        echo '302';exit;
    }
    
    $updateData = array();
    $updateData['yuyue_status'] = 6;
    C::t('#tom_tcyuyue#tom_tcyuyue_log')->update($tcyuyue_log_id,$updateData);
    
    if(!empty($tongchengConfig['template_id']) && $tcyuyueLogInfo['yuyue_status'] == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        
        $plugin_name = $tcyuyueConfig['plugin_name'];
        if($tcyuyueLogInfo['yuyue_type'] == 'qianggou'){
            $plugin_name = $tcqianggouConfig['plugin_name'];
        }else if($tcyuyueLogInfo['yuyue_type'] == 'qianggou'){
            $plugin_name = $tcptuanConfig['plugin_name'];
        }
        
        $template_sms = str_replace("{NAME}",$__UserInfo['nickname'], lang('plugin/tom_tcyuyue','cancel_yuyue_template'));
        $template_sms = str_replace("{TITLE}",$tcyuyueInfo['title'], $template_sms);

        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcyuyueInfo['user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($toUser['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyueInfo['id']}&tcyuyue_log_id={$tcyuyue_log_id}");
            $smsData = array(
                'first'         => $template_sms,
                'keyword1'      => $plugin_name,
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        }
        
        if($tcyuyueInfo['tongzhi_clerk_id'] > 0){
            $shopClerkInfoTmp = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_all_list(" AND tcshop_id = {$tcyuyueInfo['tcshop_id']} AND id = {$tcyuyueInfo['tongzhi_clerk_id']} ", 'ORDER BY id DESC', 0, 1);
            if(is_array($shopClerkInfoTmp) && !empty($shopClerkInfoTmp[0])){
                $clerkUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($shopClerkInfoTmp[0]['user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($clerkUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyueInfo['id']}&tcyuyue_log_id={$tcyuyue_log_id}");
                    $smsData = array(
                        'first'         => $template_sms,
                        'keyword1'      => $plugin_name,
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($clerkUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }
        }
        
        if($tcyuyueInfo['open_clerk'] == 1 && $clerk_id > 0){
            $clerkInfoTmp = C::t("#tom_tcyuyue#tom_tcyuyue_clerk")->fetch_by_id($clerk_id);
            $clerkUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($clerkInfoTmp['user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($clerkUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyueInfo['id']}&tcyuyue_log_id={$tcyuyue_log_id}");
                $smsData = array(
                    'first'         => $template_sms,
                    'keyword1'      => $plugin_name,
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($clerkUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'load_tcshop_clerk' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $outStr = '';

    $tcshop_id = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    
    $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
    if($tcshopInfo['user_id'] != $__UserInfo['id']){
        echo 404;exit;
    }
    $clerkListTmp = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_all_list(" AND tcshop_id = {$tcshop_id} ", 'ORDER BY id ASC', 0, 100);
    $clerkList = array();
    if(is_array($clerkListTmp) && !empty($clerkListTmp)){
        foreach($clerkListTmp as $key => $value){
            $clerkList[$key] = $value;
            
            $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
            $clerkList[$key]['userInfo'] = $userInfoTmp;
        }
    }

    if(is_array($clerkList) && !empty($clerkList)){
        foreach ($clerkList as $key => $val){
            $outStr .= '<option value="'.$val['id'].'">'.$val['userInfo']['nickname'].'</option>';
        }
    }else{
        $outStr = '205';
    }
    
    $outStr = tom_link_replace($outStr);
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($_GET['act'] == 'load_select_yuyue' && $_GET['formhash'] == FORMHASH && $userStatus){
    
    $outStr = '';

    $tcshop_id = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    
    $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
    if($tcshopInfo['user_id'] != $__UserInfo['id']){
        echo 404;exit;
    }
    $tcyuyueListTmp = C::t("#tom_tcyuyue#tom_tcyuyue")->fetch_all_list(" AND tcshop_id = {$tcshop_id} AND status=1 AND shenhe_status=1 ", 'ORDER BY id ASC', 0, 100);
    $tcyuyueList = array();
    if(is_array($tcyuyueListTmp) && !empty($tcyuyueListTmp)){
        foreach($tcyuyueListTmp as $key => $value){
            $tcyuyueList[$key] = $value;
        }
    }

    if(is_array($tcyuyueList) && !empty($tcyuyueList)){
        foreach ($tcyuyueList as $key => $val){
            $outStr .= '<option value="'.$val['id'].'">'.$val['title'].'</option>';
        }

    }else{
        $outStr = '205';
    }
    
    $outStr = tom_link_replace($outStr);
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;

}else if($_GET['act'] == 'get_myyuyue_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword    = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    $tcyuyue_id = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
    $back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
    
    $backUrl = urlencode($back_url);

    $url = $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyue_id}&back_url={$backUrl}&keyword=".urlencode(trim($keyword));
    $url = tom_link_replace($url);
    echo $url;exit;

}else if($_GET['act'] == 'get_yuyue_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword    = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    $back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
    
    $backUrl = urlencode($back_url);

    $url = $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=yuyue&back_url={$backUrl}&keyword=".urlencode(trim($keyword));
    $url = tom_link_replace($url);
    echo $url;exit;
    
}else if($_GET['act'] == 'delattr' && submitcheck('attr_id') && $userStatus){
    
    $attr_id     = isset($_GET['attr_id'])? intval($_GET['attr_id']):0;
    
    $attrInfo   = C::t('#tom_tcyuyue#tom_tcyuyue_attr')->fetch_by_id($attr_id);
    $yuyueInfo  = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($attrInfo['tcyuyue_id']);
    
    if($yuyueInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr);exit;
    }
    
    C::t('#tom_tcyuyue#tom_tcyuyue_attr')->delete_by_id($attr_id);
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'updateAttrStatus' && submitcheck('attr_id') && $userStatus){
    
    $attr_id        = isset($_GET['attr_id'])? intval($_GET['attr_id']):0;
    $is_hidden      = isset($_GET['is_hidden'])? intval($_GET['is_hidden']):0;
    
    $attrInfo   = C::t('#tom_tcyuyue#tom_tcyuyue_attr')->fetch_by_id($attr_id);
    $yuyueInfo  = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($attrInfo['tcyuyue_id']);
    
    if($yuyueInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr);exit;
    }
    
    DB::query("UPDATE ".DB::table('tom_tcyuyue_attr')." SET is_hidden={$is_hidden} WHERE id='{$attr_id}' ", 'UNBUFFERED');
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'delclerk' && submitcheck('clerk_id') && $userStatus){
    
    $clerk_id = isset($_GET['clerk_id'])? intval($_GET['clerk_id']):0;
    
    $clerkInfo   = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_by_id($clerk_id);
    $yuyueInfo  = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($clerkInfo['tcyuyue_id']);
    
    if($yuyueInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr);exit;
    }
    
    C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->delete_by_id($clerk_id);
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'updateClerkStatus' && submitcheck('clerk_id') && $userStatus){
    
    $clerk_id   = isset($_GET['clerk_id'])? intval($_GET['clerk_id']):0;
    $status     = isset($_GET['status'])? intval($_GET['status']):0;
    
    $clerkInfo   = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_by_id($clerk_id);
    $yuyueInfo  = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($clerkInfo['tcyuyue_id']);
    
    if($yuyueInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr);exit;
    }
    
    DB::query("UPDATE ".DB::table('tom_tcyuyue_clerk')." SET status={$status} WHERE id='{$clerk_id}' ", 'UNBUFFERED');
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'update_yuyue_status' && $_GET['formhash'] == FORMHASH){
    
    $cookiesYuyueStatus = getcookie('tom_tcqun_update_yuyue_status');
    if(!empty($cookiesYuyueStatus) && $cookiesYuyueStatus == 1){
    }else{
        $timeStamp = TIMESTAMP - $nowDayTime;
        DB::query("UPDATE ".DB::table('tom_tcyuyue_log')." SET yuyue_status = 5 WHERE yuyue_status IN(1,3,4) AND ((time_end_stamp <= {$timeStamp} AND yuyue_daytime = {$nowDayTime}) OR (yuyue_daytime < {$nowDayTime})) ", 'UNBUFFERED');
        
        dsetcookie('tom_tcqun_update_yuyue_status',1,300);
    }
    echo 200;exit;
    
}else{
    echo 'error';exit;
}