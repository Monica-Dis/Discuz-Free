<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tcyuyueConfig = $_G['cache']['plugin']['tom_tcyuyue'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

$sql_in_site_ids = $site_id;

## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tcqianggou start
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
    $tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
    if($tcqianggouConfig['open_tcqianggou'] == 1){
        $__ShowTcqianggou = 1;
    }
}
## tcqianggou end
## tcptuan start
$__ShowTcptuan = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcptuan/tom_tcptuan.inc.php')){
    $tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
    if($tcptuanConfig['open_tcptuan'] == 1){
        $__ShowTcptuan = 1;
    }
}
## tcptuan end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesinfo.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/class/function.core.php';

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

if($_GET['act'] == 'yuyue' && submitcheck('tcyuyue_id') && $userStatus){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcyuyue_log_id     = intval($_GET['tcyuyue_log_id'])>0? intval($_GET['tcyuyue_log_id']):0;
    $tcyuyue_id         = intval($_GET['tcyuyue_id'])>0? intval($_GET['tcyuyue_id']):0;
    $goods_id           = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    $order_no           = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
    $yuyue_type         = isset($_GET['yuyue_type'])? addslashes($_GET['yuyue_type']):'';
    $daytime            = intval($_GET['daytime'])>0? intval($_GET['daytime']):0;
    $time_id            = intval($_GET['time_id'])>0? intval($_GET['time_id']):0;
    $xm                 = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $beizu              = isset($_GET['beizu'])? addslashes($_GET['beizu']):'';
    $clerk_id           = intval($_GET['clerk_id'])>0? intval($_GET['clerk_id']):0;
    $buy_status         = intval($_GET['buy_status'])>0? intval($_GET['buy_status']):0;  // 1 ����ǰԤԼ  2 �����ԤԼ
    
    $yuyuePayStatus = 0;
    $goodsInfo = $orderInfo = array();
    if($yuyue_type == 'qianggou'){
        if($buy_status == 1){
            $yuyuePayStatus = 1;
            $goodsInfo = C::t("#tom_tcqianggou#tom_tcqianggou_goods")->fetch_by_id($goods_id);
        }else if($buy_status == 2){
            $orderInfo = C::t("#tom_tcqianggou#tom_tcqianggou_order")->fetch_by_order_no($order_no);
            if($orderInfo && $orderInfo['order_status'] == 2 && $orderInfo['user_id'] == $__UserInfo['id']){
                $yuyuePayStatus = 2;
                $goodsInfo = C::t("#tom_tcqianggou#tom_tcqianggou_goods")->fetch_by_id($orderInfo['goods_id']);
                $goods_id = $orderInfo['goods_id'];
            }else{
                $outArr = array(
                    'status'=> 404,
                );
                echo json_encode($outArr); exit;
            }
        }
        if($goodsInfo['peisong_type'] == 1 && $goodsInfo['open_yuyue'] == 1 && ($goodsInfo['yuyue_type'] == 2 || $goodsInfo['yuyue_type'] == 3) && $goodsInfo['tcyuyue_id'] > 0){}else{
            $outArr = array(
                'status'=> 309,
            );
            echo json_encode($outArr); exit;
        }
    }else if($yuyue_type == 'ptuan'){
        if($buy_status == 2){
            $orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_order_no($order_no);
            if($orderInfo && $orderInfo['order_status'] == 2 && $orderInfo['user_id'] == $__UserInfo['id']){
                $yuyuePayStatus = 2;
                $goodsInfo = C::t("#tom_tcptuan#tom_tcptuan_goods")->fetch_by_id($orderInfo['goods_id']);
                $goods_id = $orderInfo['goods_id'];
            }else{
                $outArr = array(
                    'status'=> 404,
                );
                echo json_encode($outArr); exit;
            }
        }
        if($goodsInfo['peisong_type'] == 1 && $goodsInfo['open_yuyue'] == 1 && $goodsInfo['yuyue_type'] == 3 && $goodsInfo['tcyuyue_id'] > 0){}else{
            $outArr = array(
                'status'=> 309,
            );
            echo json_encode($outArr); exit;
        }
        
    }else if($yuyue_type == 'shop'){
        $yuyuePayStatus = 3;
        $goodsInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($goods_id);
        if($goodsInfo['open_yuyue'] == 1 && $goodsInfo['tcyuyue_id'] > 0){}else{
            $outArr = array(
                'status'=> 309,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($yuyuePayStatus == 1 || $yuyuePayStatus == 2 || $yuyuePayStatus == 3){}else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tcyuyue_id > 0){
        if($goodsInfo['tcyuyue_id'] != $tcyuyue_id){
            $outArr = array(
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $tcyuyue_id = $goodsInfo['tcyuyue_id'];
    }
    
    $tcyuyueLogInfo = array();
    if($tcyuyue_log_id > 0){
        $tcyuyueLogInfo = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_by_id($tcyuyue_log_id);
        if($tcyuyueLogInfo['user_id'] != $__UserInfo['id'] || $tcyuyueLogInfo['tcyuyue_id'] != $tcyuyue_id){
            $outArr = array(
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $tcyuyueInfo = C::t("#tom_tcyuyue#tom_tcyuyue")->fetch_by_id($tcyuyue_id);
    $timeInfo = C::t("#tom_tcyuyue#tom_tcyuyue_time")->fetch_by_id($time_id);
    
    if(empty($daytime) || empty($timeInfo)){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(empty($tcyuyueInfo)){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($timeInfo['tcyuyue_id'] != $tcyuyueInfo['id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $yuyuedayTime = gmmktime(0,0,0,dgmdate($daytime, 'n',$tomSysOffset),dgmdate($daytime, 'j',$tomSysOffset),dgmdate($daytime, 'Y',$tomSysOffset)) - $tomSysOffset*3600;
    
    $datesArr = explode('|', $tcyuyueInfo['yuyue_dates']);
    
    if($tcyuyueInfo['date_type'] == 1){
        $week = dgmdate($yuyuedayTime, 'N',$tomSysOffset);
        if(!in_array($week, $datesArr)){
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }else if($tcyuyueInfo['date_type'] == 2){
        $day = dgmdate($yuyuedayTime, 'j',$tomSysOffset);
        if(!in_array($day, $datesArr)){
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $notDateInfoTmp = C::t("#tom_tcyuyue#tom_tcyuyue_notdate")->fetch_all_list(" AND tcyuyue_id = {$tcyuyue_id} AND notdate_stamp = {$yuyuedayTime} ", 'ORDER BY id ASC');
    $allNotDateStatus = 0;
    if(is_array($notDateInfoTmp) && !empty($notDateInfoTmp[0])){
        $allNotDateStatus = 1;
    }
    
    if($allNotDateStatus == 1){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    // ����ԤԼʱ��㣨�����֮�����ԤԼ��
    $xianzhiYuyueStamp = 0;
    if($tcyuyueInfo['before_time_unit'] == 1){
        $xianzhiYuyueStamp = $tcyuyueInfo['before_time'] * 60 + TIMESTAMP;
    }else if($tcyuyueInfo['before_time_unit'] == 2){
        $xianzhiYuyueStamp = $tcyuyueInfo['before_time'] * 3600 + TIMESTAMP;
    }else if($tcyuyueInfo['before_time_unit'] == 3){
        $xianzhiYuyueStamp = $tcyuyueInfo['before_time'] * 86400 + TIMESTAMP;
    }
    
    // ��ȡ��ԤԼ��ԤԼʱ��㣨�����֮���ԤԼ������ȡ����
    $cancelYuyueStamp = 0;
    if($tcyuyueInfo['cancel_before_time_unit'] == 1){
        $cancelYuyueStamp = $tcyuyueInfo['cancel_before_time'] * 60 + TIMESTAMP;
    }else if($tcyuyueInfo['cancel_before_time_unit'] == 2){
        $cancelYuyueStamp = $tcyuyueInfo['cancel_before_time'] * 3600 + TIMESTAMP;
    }else if($tcyuyueInfo['cancel_before_time_unit'] == 3){
        $cancelYuyueStamp = $tcyuyueInfo['cancel_before_time'] * 86400 + TIMESTAMP;
    }
    
    if($tcyuyueLogInfo['id'] > 0){
        
        // �ж�ԤԼʱ���Ƿ����
        if($tcyuyueLogInfo['yuyue_daytime'] == $yuyuedayTime && $timeInfo['id'] == $tcyuyueLogInfo['time_id']){
            
        }else{
            
            // ��ԤԼʱ��
            $startYuyueStamp = $tcyuyueLogInfo['time_start_stamp'] + $tcyuyueLogInfo['yuyue_daytime'];
            
            // ��ԤԼʱ�䲻�ڿ�ȡ��ԤԼʱ�䷶Χ�ڣ����ܸ���
            if($startYuyueStamp < $cancelYuyueStamp){
                $outArr = array(
                    'status'=> 310,
                );
                echo json_encode($outArr); exit;
            }
            
            // ��ԤԼʱ��������ԤԼʱ��֮ǰ�����ܸ���ԤԼ
            if($startYuyueStamp <= $xianzhiYuyueStamp){
//                $outArr = array(
//                    'status'=> 311,
//                );
//                echo json_encode($outArr); exit;
            }
            
            // ԤԼ��ʼʱ��
            $startTimeYuyueStamp = $timeInfo['time_start_stamp'] + $yuyuedayTime;
            // �ж���ǰԤԼʱ������
            if($xianzhiYuyueStamp >= $startTimeYuyueStamp){
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }
            
            // ԤԼ����ʱ��
            $endTimeYuyueStamp = $timeInfo['time_end_stamp'] + $yuyuedayTime;
            if($yuyue_type == 'qianggou' || $yuyue_type == 'ptuan'){
                if($goodsInfo['hexiao_time'] > 0 && $endTimeYuyueStamp > $goodsInfo['hexiao_time']){
                    $outArr = array(
                        'status'=> 312,
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
            
        }
        
    }else{
        
        // ԤԼ��ʼʱ��
        $startTimeYuyueStamp = $timeInfo['time_start_stamp'] + $yuyuedayTime;
        // �ж���ǰԤԼʱ������
        if($xianzhiYuyueStamp >= $startTimeYuyueStamp){
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }
        
        // ԤԼ����ʱ��
        $endTimeYuyueStamp = $timeInfo['time_end_stamp'] + $yuyuedayTime;
        if($yuyue_type == 'qianggou' || $yuyue_type == 'ptuan'){
            if($goodsInfo['hexiao_time'] > 0 && $endTimeYuyueStamp > $goodsInfo['hexiao_time']){
                $outArr = array(
                    'status'=> 312,
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    
    $tcyuyueLogCount = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_all_count(" AND tcyuyue_id = {$tcyuyueInfo['id']} AND yuyue_status IN(1,2,3) AND yuyue_daytime = {$yuyuedayTime} AND id != {$tcyuyue_log_id} ");
    if($tcyuyueLogCount > 0 && $tcyuyueInfo['total_renshu'] > 0 && $tcyuyueLogCount >= $tcyuyueInfo['total_renshu']){
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tcyuyueInfo['time_renshu'] > 0){
        $tcyuyueTimeLogCount = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_all_count(" AND time_id = {$timeInfo['id']} AND yuyue_status IN(1,2,3) AND yuyue_daytime = {$yuyuedayTime} AND id != {$tcyuyue_log_id} ");
        if($tcyuyueTimeLogCount > 0 && $tcyuyueTimeLogCount >= $tcyuyueInfo['time_renshu']){
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($tcyuyueInfo['open_clerk'] == 1 && $clerk_id > 0){
        $clerkInfo = C::t("#tom_tcyuyue#tom_tcyuyue_clerk")->fetch_by_id($clerk_id);
        if($clerkInfo && $clerkInfo['tcyuyue_id'] == $tcyuyueInfo['id']){ }else{
            $outArr = array(
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }
        
        $tcyuyueClerkTimeLogCount = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_all_count(" AND clerk_id = {$clerk_id} AND tcyuyue_id = {$tcyuyueInfo['id']} AND time_id = {$time_id} AND yuyue_daytime = {$yuyuedayTime} AND yuyue_status IN(1,2,3) AND id != {$tcyuyue_log_id}");
        if($clerkInfo['time_renshu'] > 0 && $tcyuyueClerkTimeLogCount >= $clerkInfo['time_renshu']){
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
        
        $tcyuyueClerkTotalLogCount = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_all_count(" AND clerk_id = {$clerk_id} AND tcyuyue_id = {$tcyuyueInfo['id']} AND yuyue_daytime = {$yuyuedayTime} AND yuyue_status IN(1,2,3) AND id != {$tcyuyue_log_id}");
        if($clerkInfo['total_renshu'] > 0 && $tcyuyueClerkTotalLogCount >= $clerkInfo['total_renshu']){
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }

    $attrListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_attr")->fetch_all_list(" AND tcyuyue_id = {$tcyuyue_id} AND is_hidden = 0 ", 'ORDER BY paixu ASC, id DESC');
    $attrList = array();
    if(is_array($attrListTmp) && !empty($attrListTmp)){
        foreach($attrListTmp as $key => $value){
            $attrList[$key] = $value;
            if($value['type'] == 1){
                $attrList[$key]['attr_value'] = isset($_GET['attr_'.$value['id']])? addslashes($_GET['attr_'.$value['id']]):'';
            }else if($value['type'] == 2){
                $attrList[$key]['attr_value'] = intval($_GET['attr_'.$value['id']])>0? intval($_GET['attr_'.$value['id']]):0;
            }else if($value['type'] == 3){
                $attrList[$key]['attr_value'] = isset($_GET['attr_'.$value['id']])? addslashes($_GET['attr_'.$value['id']]):'';
            }else if($value['type'] == 4){
                $attrList[$key]['attr_value'] = '';
                if(is_array($_GET['attr_'.$value['id']]) && !empty($_GET['attr_'.$value['id']])){
                    $attrValueArr = array();
                    foreach($_GET['attr_'.$value['id']] as $k => $v){
                        $attrValueTmp = isset($v)? addslashes($v):'';
                        if(!empty($attrValueTmp)){
                            $attrValueArr[] = $attrValueTmp;
                        }
                    }
                    $attrList[$key]['attr_value'] = implode('|', $attrValueArr);
                }
            }
        }
    }
    
    $isEdit = 0;
    if($tcyuyue_log_id > 0){
        $isEdit = 1;
        
        $updateData = array();
        if($tcyuyueInfo['open_clerk'] == 1 && $clerk_id > 0){
            $updateData['clerk_id']             = $clerk_id;
        }else{
            $updateData['clerk_id']             = 0;
        }
        $updateData['xm']                   = $xm;
        $updateData['tel']                  = $tel;
        $updateData['beizu']                = $beizu;
        $updateData['time_id']              = $time_id;
        $updateData['time_name']            = $timeInfo['time_name'];
        $updateData['time_start_stamp']     = $timeInfo['time_start_stamp'];
        $updateData['time_end_stamp']       = $timeInfo['time_end_stamp'];
        if($yuyuePayStatus == 2 || $yuyuePayStatus == 3){
            if($tcyuyueInfo['open_yuyue_queren'] == 1){
                $updateData['yuyue_status']         = 3;
            }else{
                $updateData['yuyue_status']         = 1;
            }
        }else{
            $updateData['yuyue_status']         = 0;
        }
        $updateData['yuyue_daytime']        = $yuyuedayTime;
        $updateData['add_time']             = TIMESTAMP;
        C::t('#tom_tcyuyue#tom_tcyuyue_log')->update($tcyuyue_log_id, $updateData);
        C::t('#tom_tcyuyue#tom_tcyuyue_log_attr')->delete_by_tcyuyue_log_id($tcyuyue_log_id);

        if(is_array($attrList) && !empty($attrList)){
            foreach($attrList as $key => $value){

                $insertData = array();
                $insertData['tcyuyue_log_id']   = $tcyuyue_log_id;
                $insertData['user_id']          = $__UserInfo['id'];
                $insertData['tcyuyue_id']       = $tcyuyue_id;
                $insertData['attr_id']          = $value['id'];
                $insertData['attr_name']        = $value['name'];
                $insertData['attr_type']        = $value['type'];
                $insertData['value']            = $value['attr_value'];
                $insertData['unit']             = $value['unit'];
                $insertData['paixu']            = $value['paixu'];
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_tcyuyue#tom_tcyuyue_log_attr')->insert($insertData);
            }
        }
        
    }else{
        
        $insertData = array();
        $insertData['tcyuyue_id']           = $tcyuyue_id;
        $insertData['yuyue_type']           = $yuyue_type;
        $insertData['goods_id']             = $goodsInfo['id'];
        $insertData['order_no']             = $order_no;
        if($tcyuyueInfo['open_clerk'] == 1 && $clerk_id > 0){
            $insertData['clerk_id']             = $clerk_id;
        }
        $insertData['xm']                   = $xm;
        $insertData['tel']                  = $tel;
        $insertData['beizu']                = $beizu;
        $insertData['time_id']              = $time_id;
        $insertData['user_id']              = $__UserInfo['id'];
        $insertData['time_name']            = $timeInfo['time_name'];
        $insertData['time_start_stamp']     = $timeInfo['time_start_stamp'];
        $insertData['time_end_stamp']       = $timeInfo['time_end_stamp'];
        if($yuyuePayStatus == 2 || $yuyuePayStatus == 3){
            if($tcyuyueInfo['open_yuyue_queren'] == 1){
                $insertData['yuyue_status']         = 3;
            }else{
                $insertData['yuyue_status']         = 1;
            }
        }else{
            $insertData['yuyue_status']         = 0;
        }
        $insertData['yuyue_daytime']        = $yuyuedayTime;
        $insertData['add_time']             = TIMESTAMP;
        $tcyuyue_log_id = C::t('#tom_tcyuyue#tom_tcyuyue_log')->insert($insertData, true);
        
        if(is_array($attrList) && !empty($attrList)){
            foreach($attrList as $key => $value){
                
                $insertData = array();
                $insertData['tcyuyue_log_id']   = $tcyuyue_log_id;
                $insertData['user_id']          = $__UserInfo['id'];
                $insertData['tcyuyue_id']       = $tcyuyue_id;
                $insertData['attr_id']          = $value['id'];
                $insertData['attr_name']        = $value['name'];
                $insertData['attr_type']        = $value['type'];
                $insertData['value']            = $value['attr_value'];
                $insertData['unit']             = $value['unit'];
                $insertData['paixu']            = $value['paixu'];
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_tcyuyue#tom_tcyuyue_log_attr')->insert($insertData);
            }
        }
    }

    if($tcyuyue_log_id > 0 && $yuyuePayStatus == 2){
        $updateData = array();
        $updateData['tcyuyue_log_id']   = $tcyuyue_log_id;
        $updateData['xm']               = $xm;
        $updateData['tel']              = $tel;
        $updateData['order_beizu']      = $beizu;
        if($yuyue_type == 'qianggou'){
            C::t("#tom_tcqianggou#tom_tcqianggou_order")->update($orderInfo['id'], $updateData);
        }else if($yuyue_type == 'ptuan'){
            C::t("#tom_tcptuan#tom_tcptuan_order")->update($orderInfo['id'], $updateData);
        }
    }
    
    if($tcyuyue_log_id > 0){
        if($yuyuePayStatus == 2 || $yuyuePayStatus == 3){
            if(!empty($tongchengConfig['template_id'])){
                
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

                $plugin_name = $tcyuyueConfig['plugin_name'];
                if($yuyue_type == 'qianggou'){
                    $plugin_name = $tcqianggouConfig['plugin_name'];
                }else if($yuyue_type == 'ptuan'){
                    $plugin_name = $tcptuanConfig['plugin_name'];
                }else if($yuyue_type == 'shop'){
                    $plugin_name = $tcshopConfig['plugin_name'];
                }

                $template_sms = '';
                if($tcyuyueInfo['open_yuyue_queren'] == 1){
                    if($isEdit == 1){
                        $template_sms = str_replace("{NAME}",$__UserInfo['nickname'], lang('plugin/tom_tcyuyue','shenhe_yuyue_edit_queren_template'));
                    }else{
                        $template_sms = str_replace("{NAME}",$__UserInfo['nickname'], lang('plugin/tom_tcyuyue','shenhe_yuyue_queren_template'));
                    }
                }else{
                    if($isEdit == 1){
                        $template_sms = str_replace("{NAME}",$__UserInfo['nickname'], lang('plugin/tom_tcyuyue','shenhe_yuyue_edit_template'));
                    }else{
                        $template_sms = str_replace("{NAME}",$__UserInfo['nickname'], lang('plugin/tom_tcyuyue','shenhe_yuyue_template'));
                    }
                }
                $template_sms = str_replace("{TITLE}",$tcyuyueInfo['title'], $template_sms);

                $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcyuyueInfo['user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($toUser['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyueInfo['id']}");
                    $smsData = array(
                        'first'         => $template_sms,
                        'keyword1'      => $plugin_name,
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );
                    @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
                }
                if($tcyuyueInfo['tongzhi_clerk_id'] > 0){
                    $shopClerkInfoTmp = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_all_list(" AND tcshop_id = {$tcyuyueInfo['tcshop_id']} AND id = {$tcyuyueInfo['tongzhi_clerk_id']} ", 'ORDER BY id DESC', 0, 1);
                    if(is_array($shopClerkInfoTmp) && !empty($shopClerkInfoTmp[0])){
                        $shopClerkUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($shopClerkInfoTmp[0]['user_id']);
                        $access_token = $weixinClass->get_access_token();
                        if($access_token && !empty($shopClerkUserInfo['openid'])){
                            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyueInfo['id']}");
                            $smsData = array(
                                'first'         => $template_sms,
                                'keyword1'      => $plugin_name,
                                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                                'remark'        => ''
                            );
                            @$r = $templateSmsClass->sendSms01($shopClerkUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                        }
                    }
                }
                if($tcyuyueInfo['open_clerk'] == 1 && $clerk_id > 0){
                    $clerkUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($clerkInfo['user_id']);
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($clerkUserInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyueInfo['id']}");
                        $smsData = array(
                            'first'         => $template_sms,
                            'keyword1'      => $plugin_name,
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );
                        @$r = $templateSmsClass->sendSms01($clerkUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                    }
                }
                
            }
        }
        $outArr = array(
            'status'=> 200,
            'tcyuyue_log_id' => $tcyuyue_log_id,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }

}else{
    echo 'error';exit;
}