<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['act'] == 'fabu' && submitcheck('title')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $tcshop_id                  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    $tongzhi_clerk_id           = intval($_GET['tongzhi_clerk_id'])>0? intval($_GET['tongzhi_clerk_id']):0;
    $title                      = isset($_GET['title'])? addslashes($_GET['title']):'';
    $type                       = intval($_GET['type'])>0? intval($_GET['type']):1;
    $total_renshu               = intval($_GET['total_renshu'])>0? intval($_GET['total_renshu']):0;
    $time_renshu                = intval($_GET['time_renshu'])>0? intval($_GET['time_renshu']):0;
    $yuyue_days                 = intval($_GET['yuyue_days'])>0? intval($_GET['yuyue_days']):$tcyuyueConfig['yuyue_days'];
    $open_yuyue_queren          = isset($_GET['open_yuyue_queren'])? intval($_GET['open_yuyue_queren']):0;
    $open_clerk                 = isset($_GET['open_clerk'])? intval($_GET['open_clerk']):0;
    $open_clerk_must            = isset($_GET['open_clerk_must'])? intval($_GET['open_clerk_must']):0;
    $clerk_name                 = isset($_GET['clerk_name'])? addslashes($_GET['clerk_name']):'';
    $before_time                = isset($_GET['before_time'])? intval($_GET['before_time']):0;
    $before_time_unit           = isset($_GET['before_time_unit'])? intval($_GET['before_time_unit']):0;
    $cancel_before_time         = isset($_GET['cancel_before_time'])? intval($_GET['cancel_before_time']):0;
    $cancel_before_time_unit    = isset($_GET['cancel_before_time_unit'])? intval($_GET['cancel_before_time_unit']):0;
    $date_type                  = intval($_GET['date_type'])>0? intval($_GET['date_type']):1;
    $model_time_type_id         = intval($_GET['model_time_type_id'])>0? intval($_GET['model_time_type_id']):0;
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    if($__UserInfo['id'] != $tcshopInfo['user_id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $weeksStr = '';
    if(is_array($_GET['weeks']) && !empty($_GET['weeks'])){
        $weeksList = array();
        foreach($_GET['weeks'] as $key => $value){
            $weekTmp = intval($value);
            if(!empty($weekTmp)){
                $weeksList[] = $weekTmp;
            }
        }
        if(is_array($weeksList) && !empty($weeksList)){
            $weeksStr = implode('|', $weeksList);
        }
    }
    
    $daysStr = '';
    if(is_array($_GET['days']) && !empty($_GET['days'])){
        $daysList = array();
        foreach($_GET['days'] as $key => $value){
            $dayTmp = intval($value);
            if(!empty($dayTmp)){
                $daysList[] = $dayTmp;
            }
        }
        if(is_array($daysList) && !empty($daysList)){
            $daysStr = implode('|', $daysList);
        }
    }
    
    $timeIdsArr = array();
    if(is_array($_GET['timeid']) && !empty($_GET['timeid'])){
        foreach($_GET['timeid'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $timeIdsArr[] = $idTmp;
            }
        }
    }
    
    $notDateList = array();
    if(is_array($_GET['notdate']) && !empty($_GET['notdate'])){
        foreach($_GET['notdate'] as $key => $value){
            $notdateTmp = intval($value);
            if(!empty($notdateTmp)){
                $year = intval($_GET['notdate_year_'.$notdateTmp]);
                $month = intval($_GET['notdate_month_'.$notdateTmp]);
                $day = intval($_GET['notdate_day_'.$notdateTmp]);
                $time_stamp = mktime(0, 0, 0, $month, $day, $year);
                
                $notDateList[$key]['notdate_stamp'] = $time_stamp;
            }
        }
    }
    
    $insertData = array();
    $insertData['site_id']                  = $site_id;
    $insertData['tcshop_id']                = $tcshop_id;
    $insertData['tongzhi_clerk_id']         = $tongzhi_clerk_id;
    $insertData['title']                    = $title;
    $insertData['type']                     = $type;
    $insertData['user_id']                  = $__UserInfo['id'];
    $insertData['date_type']                = $date_type;
    if($date_type == 1){
        $insertData['yuyue_dates']              = $weeksStr;
    }else if($date_type == 2){
        $insertData['yuyue_dates']              = $daysStr;
    }
    $insertData['model_time_type_id']       = $model_time_type_id;
    $insertData['total_renshu']             = $total_renshu;
    $insertData['time_renshu']              = $time_renshu;
    $insertData['before_time']              = $before_time;
    $insertData['before_time_unit']         = $before_time_unit;
    $insertData['cancel_before_time']       = $cancel_before_time;
    $insertData['cancel_before_time_unit']  = $cancel_before_time_unit;
    $insertData['yuyue_days']               = $yuyue_days;
    $insertData['open_yuyue_queren']        = $open_yuyue_queren;
    $insertData['open_clerk']               = $open_clerk;
    if($open_clerk == 1){
        $insertData['open_clerk_must']          = $open_clerk_must;
        $insertData['clerk_name']               = $clerk_name;
    }
    $insertData['status']                   = 1;
    if($tcyuyueConfig['must_shenhe'] == 1){
        $insertData['shenhe_status']              = 2;
    }else{
        $insertData['shenhe_status']              = 1;
    }
    $insertData['update_time']      = TIMESTAMP;
    $insertData['add_time']         = TIMESTAMP;
    if(C::t('#tom_tcyuyue#tom_tcyuyue')->insert($insertData)){
        $tcyuyue_id = C::t('#tom_tcyuyue#tom_tcyuyue')->insert_id();
        
        if(is_array($timeIdsArr) && !empty($timeIdsArr)){
            foreach($timeIdsArr as $key => $value){
                
                $timeInfo = C::t("#tom_tcyuyue#tom_tcyuyue_model_time")->fetch_by_id($value);
                
                $insertData = array();
                $insertData['tcyuyue_id']       = $tcyuyue_id;
                $insertData['model_time_id']    = $timeInfo['id'];
                $insertData['time_name']        = $timeInfo['name'];
                $insertData['time_start_stamp'] = $timeInfo['start_stamp'];
                $insertData['time_end_stamp']   = $timeInfo['end_stamp'];
                $insertData['tsort']            = $timeInfo['tsort'];
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_tcyuyue#tom_tcyuyue_time')->insert($insertData);
            }
        }
        
        if(is_array($notDateList) && !empty($notDateList)){
            foreach($notDateList as $key => $value){
                
                $insertData = array();
                $insertData['tcyuyue_id']       = $tcyuyue_id;
                $insertData['notdate_stamp']    = $value['notdate_stamp'];
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_tcyuyue#tom_tcyuyue_notdate')->insert($insertData);
            }
        }
        
        if(!empty($tongchengConfig['template_id']) && $tcyuyueConfig['must_shenhe'] == 1){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

            if($site_id > 1){
                $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
                $manage_user_id = $siteInfo['manage_user_id'];
                $site_name = $siteInfo['name'];
            }else{
                $manage_user_id = $tongchengConfig['manage_user_id'];
                $site_name = $tongchengConfig['plugin_name'];
            }

            $template_first = str_replace("{TITLE}",$title, lang('plugin/tom_tcyuyue','shenhe_template_first'));

            $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($manage_user_id);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($toUser['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => $template_first,
                    'keyword1'      => $site_name,
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,100);
$tcshopList = array();
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach ($tcshopListTmp as $key => $value){
        $tcshopList[$key] = $value;
    }
}
$tcshopCount = count($tcshopList);

$timeTypeListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_model_time_type")->fetch_all_list("", 'ORDER BY tsort ASC,id DESC');
$timeTypeList = array();
$firstTimeTypeId = 0;
if(is_array($timeTypeListTmp) && !empty($timeTypeListTmp)){
    foreach($timeTypeListTmp as $key => $value){
        $timeTypeList[$value['id']] = $value;
        
        if($firstTimeTypeId == 0){
            $firstTimeTypeId = $value['id'];
        }
    }
}

$timeListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_model_time")->fetch_all_list("", 'ORDER BY tsort ASC,id DESC');
$timeList = $timeArr = array();
if(is_array($timeListTmp) && !empty($timeListTmp)){
    foreach ($timeListTmp as $key => $value){
        $timeList[$value['model_time_type_id']][$key] = $value;
        
        $timeArr[$value['model_time_type_id']][$key]['id'] = $value['id'];
        $timeArr[$value['model_time_type_id']][$key]['value'] = diconv($value['name'],CHARSET,'utf-8');
    }
}
$timeData[0] = $timeArr;
$timeArrStr = urlencode(json_encode($timeData));

$daysArr = array();
for($i = 1; $i <= 31; $i++){
    $daysArr[] = $i;
}

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=add";

$fabuUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=add";
$backLinkUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=mylist&fromlist=mylist";
$ajaxLoadTcshopClerkUrl = "plugin.php?id=tom_tcyuyue:ajax&site={$site_id}&act=load_tcshop_clerk&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:add");