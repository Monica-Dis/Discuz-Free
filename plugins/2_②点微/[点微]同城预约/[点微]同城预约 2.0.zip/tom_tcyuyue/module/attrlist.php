<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcyuyue_id = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$tcyuyueInfo = C::t("#tom_tcyuyue#tom_tcyuyue")->fetch_by_id($tcyuyue_id);

if($__UserInfo['id'] != $tcyuyueInfo['user_id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=mylist");exit;
}

$attrListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_attr')->fetch_all_list(" AND tcyuyue_id={$tcyuyue_id}"," ORDER BY paixu ASC,id ASC ",0,50);
$attrList = array();
foreach ($attrListTmp as $key => $value){
    $attrList[$key] = $value;
    $attrCount = C::t('#tom_tcyuyue#tom_tcyuyue_log_attr')->fetch_all_count(" AND attr_id={$value['id']}");
    $attrList[$key]['attrCount'] = $attrCount;
}

$backUrl = urlencode($back_url);

$ajaxDelattrUrl          = "plugin.php?id=tom_tcyuyue:ajax&site={$site_id}&act=delattr&formhash=".$formhash;
$ajaxUpdateAttrStatusUrl = "plugin.php?id=tom_tcyuyue:ajax&site={$site_id}&act=updateAttrStatus&&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:attrlist");