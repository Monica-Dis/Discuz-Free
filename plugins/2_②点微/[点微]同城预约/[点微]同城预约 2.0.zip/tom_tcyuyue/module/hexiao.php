<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcyuyue_log_id = intval($_GET['tcyuyue_log_id'])>0? intval($_GET['tcyuyue_log_id']):0;

$tcyuyueLogInfo = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_by_id($tcyuyue_log_id);
$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcyuyueLogInfo['goods_id']);
$tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyueLogInfo['tcyuyue_id']);

$clerkListTmp  = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_all_list(" AND tcyuyue_id={$tcyuyueLogInfo['tcyuyue_id']} AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,1);
if(!empty($clerkListTmp[0]['id']) || $tcshopInfo['user_id'] == $__UserInfo['id'] ){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'hexiao' && $_GET['formhash'] == FORMHASH){
    
    $updateData = array();
    $updateData['yuyue_status']     = 2;
    $updateData['hexiao_user_id']   = $__UserInfo['id'];
    $updateData['hexiao_time']      = TIMESTAMP;
    C::t('#tom_tcyuyue#tom_tcyuyue_log')->update($tcyuyue_log_id,$updateData);

    echo 200;exit;
}

if(!preg_match('/^http/', $tcshopInfo['picurl'])){
    if(strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $tcshopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['picurl'];
    }else{
        $tcshopPicurl = $tcshopInfo['picurl'];
    }
}else{
    $tcshopPicurl = $tcshopInfo['picurl'];
}

$attrListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_log_attr')->fetch_all_list(" AND tcyuyue_log_id = {$tcyuyueLogInfo['id']} ", " ORDER BY paixu ASC,id DESC ");
$attrList = array();
if(is_array($attrListTmp) && !empty($attrListTmp)){
    foreach($attrListTmp as $k => $v){
        $attrList[$k] = $v;
        if($v['attr_type'] == 4){
            $attrList[$k]['valueList'] = explode('|', $v['value']);
        }
    }
}

$clerkInfoTmp = array();
if($tcyuyueLogInfo['clerk_id'] > 0){
    $clerkInfoTmp = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_by_id($tcyuyueLogInfo['clerk_id']);
}

$hexiaoUserInfo = array();
if($tcyuyueLogInfo['yuyue_status'] == 2){
    $hexiaoUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcyuyueLogInfo['hexiao_user_id']);
}

$tcyuyueLogInfo['time_start_stamp'] = $tcyuyueLogInfo['time_start_stamp'] + $tcyuyueLogInfo['yuyue_daytime'];
$tcyuyueLogInfo['time_end_stamp'] = $tcyuyueLogInfo['time_end_stamp'] + $tcyuyueLogInfo['yuyue_daytime'];

$tcyuyueLogInfo['start_time']        = dgmdate($tcyuyueLogInfo['time_start_stamp'],"Y-m-d H:i",$tomSysOffset);
$tcyuyueLogInfo['end_time']          = dgmdate($tcyuyueLogInfo['time_end_stamp'],"H:i",$tomSysOffset);

$hexiaoUrl = 'plugin.php?id=tom_tcyuyue&site='.$site_id.'&mod=hexiao&act=hexiao&tcyuyue_log_id='.$tcyuyue_log_id.'&formhash='.$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:hexiao");