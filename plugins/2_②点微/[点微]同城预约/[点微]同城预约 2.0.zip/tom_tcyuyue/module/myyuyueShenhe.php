<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcyuyue_log_id     = intval($_GET['tcyuyue_log_id'])>0? intval($_GET['tcyuyue_log_id']):0;

$tcyuyueLogInfo = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_by_id($tcyuyue_log_id);

$tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyueLogInfo['tcyuyue_id']);
if($__UserInfo['id'] == $tcyuyueInfo['user_id']){ 
}else{
    $clerkInfoTmp = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_all_list(" AND tcshop_id = {$tcyuyueInfo['tcshop_id']} AND user_id = {$__UserInfo['id']} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($clerkInfoTmp) && !empty($clerkInfoTmp[0])){ 
    }else{
        dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=mylist");exit;
    }
}

if($_GET['act'] == 'shenhe' && submitcheck('tcyuyue_log_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $content = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $updateData = array();
    $updateData['yuyue_status'] = 4;
    $updateData['shenhe_msg']   = $content;
    C::t('#tom_tcyuyue#tom_tcyuyue_log')->update($tcyuyueLogInfo['id'],$updateData);
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcyuyueLogInfo['user_id']);
    
    if($tcyuyueLogInfo){
        
        $shenhe = str_replace('{TITLE}', $tcyuyueInfo['title'], lang('plugin/tom_tcyuyue', 'shenhe_yuyue_queren_no_template'));
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcyuyue&site='.$site_id.'&mod=yuyue&tcyuyue_log_id='.$tcyuyueLogInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        
        $insertData = array();
        $insertData['user_id']      = $toUser['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcyuyueConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    
    if($access_token && !empty($toUser['openid'])){
        
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$tcyuyueInfo['site_id']}&mod=yuyue&tcyuyue_log_id=".$tcyuyueLogInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcyuyueConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
    }
    
    echo 200;exit;
    
}

$yuyue_queren_fail_str = str_replace("\r\n","{n}",$tcyuyueConfig['yuyue_queren_fail_text']); 
$yuyue_queren_fail_str = str_replace("\n","{n}",$yuyue_queren_fail_str);
$yuyueQuerenFailArray = explode("{n}", $yuyue_queren_fail_str);

$ajaxShenheUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyueShenhe&act=shenhe&";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:myyuyueShenhe");