<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcyuyue_id = intval($_GET['tcyuyue_id'])>0? intval($_GET['tcyuyue_id']):0;
$yuyue_stamp = intval($_GET['yuyue_stamp'])>0? intval($_GET['yuyue_stamp']):0;
$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
$backUrl    = urlencode($back_url);

$userPower = 0;
if($tcyuyue_id > 0){
    $tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyue_id);
    if($__UserInfo['id'] == $tcyuyueInfo['user_id']){
        $userPower = 1;
    }else{
        if($tcyuyueInfo['tongzhi_clerk_id'] > 0){
            $shopClerkInfo = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_by_id($tcyuyueInfo['tongzhi_clerk_id']);
            if($shopClerkInfo && $shopClerkInfo['user_id'] == $__UserInfo['id']){
                $userPower = 2;
            }
        }
        if($userPower == 0 && $tcyuyueInfo['open_clerk'] == 1){
            $clerkInfoTmp = C::t("#tom_tcyuyue#tom_tcyuyue_clerk")->fetch_all_list(" AND tcyuyue_id = {$tcyuyueInfo['id']} AND user_id = {$__UserInfo['id']} ", 'ORDER BY id DESC', 0, 1);
            if(is_array($clerkInfoTmp) && !empty($clerkInfoTmp[0])){
                $clerkInfo = $clerkInfoTmp[0];
                $userPower = 3;
            }
        }
    }
    if($userPower == 0){
        dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=mylist");exit;
    }
}else{
    $tcyuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list(" AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,100);
    $tcyuyue_ids_arr = array();
    if(is_array($tcyuyueListTmp) && !empty($tcyuyueListTmp)){
        foreach ($tcyuyueListTmp as $key => $value){
            $tcyuyue_ids_arr[] = $value['id'];
        }
    }
    $tcyuyue_ids = '';
    if(!empty($tcyuyue_ids_arr)){
        $tcyuyue_ids = implode(",", $tcyuyue_ids_arr);
    }else{
        dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=mylist");exit;
    }
}

$month = dgmdate(TIMESTAMP, 'm',$tomSysOffset);
$month = intval($month);

$notDateList = array();
$yuyueDatesArr = array();
if($tcyuyue_id > 0){
    $notDateListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_notdate")->fetch_all_list(" AND tcyuyue_id = {$tcyuyueInfo['id']} ", 'ORDER BY id ASC');
    if(is_array($notDateListTmp) && !empty($notDateListTmp)){
        foreach($notDateListTmp as $key => $value){
            $notDateList[] = $value['notdate_stamp'];
        }
    }
    $yuyueDatesArr = explode('|', $tcyuyueInfo['yuyue_dates']);
}

$yuyue_days = 30;
if($tcyuyue_id > 0){
    $yuyue_days = $tcyuyueInfo['yuyue_days'];
}

$datesList = array();
for($i = 0; $i < $yuyue_days; $i++){
    
    $stampTmp = $i * 86400 + $nowDayTime;
    $dayTmp = date("d",strtotime(dgmdate($stampTmp, 'Y-m-d H:i:s',$tomSysOffset)));
    $weekTmp = dgmdate($stampTmp, 'N',$tomSysOffset);
    $timeStampTmp = gmmktime(0,0,0,dgmdate($stampTmp, 'n',$tomSysOffset),dgmdate($stampTmp, 'j',$tomSysOffset),dgmdate($stampTmp, 'Y',$tomSysOffset)) - $tomSysOffset*3600;
    
    $showDateStatus = 0;
    if($tcyuyue_id > 0){
        if($tcyuyueInfo['date_type'] == 1 && in_array($weekTmp, $yuyueDatesArr)){
            $showDateStatus = 1;
        }else if($tcyuyueInfo['date_type'] == 2 && in_array($dayTmp, $yuyueDatesArr)){
            $showDateStatus = 1;
        }
        if($showDateStatus == 1 && in_array($timeStampTmp, $notDateList)){
            $showDateStatus = 0;
        }
    }else{
        $showDateStatus = 1;
    }
    
    if($showDateStatus == 1){
        
        if($tcyuyue_id > 0){
            $whereTmp = "AND tcyuyue_id={$tcyuyue_id}";
        }else{
            $whereTmp = "AND tcyuyue_id IN({$tcyuyue_ids}) ";
        }

        if($type > 0){
            if($type == 5){
                $whereTmp .= " AND yuyue_status IN(5,6) ";
            }else{
                $whereTmp .= " AND yuyue_status = {$type} ";
            }
        }

        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            if(is_numeric($keyword)){
                $whereTmp .= " AND tel LIKE '%{$keyword}%' ";
            }else{
                $whereTmp .= " AND xm LIKE '%{$keyword}%' ";
            }
        }

        $whereTmp .= " AND yuyue_daytime = {$stampTmp} ";

        $tcyuyueLogCountTmp = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_all_count($whereTmp);
        
        $datesList[$i]['day']               = $dayTmp;
        $datesList[$i]['week']              = $weekTmp;
        $datesList[$i]['time_stamp']        = $stampTmp;
        $datesList[$i]['link']              = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyue_id}&type={$type}&yuyue_stamp={$stampTmp}&back_url={$backUrl}";
        $datesList[$i]['tcyuyueLogCount']   = $tcyuyueLogCountTmp;
    }
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

if($tcyuyue_id > 0){
    $yuyueLogCountWhere = $where = " AND tcyuyue_id={$tcyuyue_id} ";
}else{
    $yuyueLogCountWhere = $where = " AND tcyuyue_id IN({$tcyuyue_ids}) ";
}
if($tcyuyue_id > 0 && $userPower == 3){
    $where .= " AND clerk_id = {$clerkInfo['id']}";
    $yuyueLogCountWhere .= " AND clerk_id = {$clerkInfo['id']}";
}
if($type > 0){
    $where.= " AND yuyue_status = {$type} ";
}else{
    $where.= " AND yuyue_status > 0 ";
}
if($yuyue_stamp > 0){
    $where .= " AND yuyue_daytime = {$yuyue_stamp} ";
    $yuyueLogCountWhere .= " AND yuyue_daytime = {$yuyue_stamp} ";
}
if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    if(is_numeric($keyword)){
        $where .= " AND tel LIKE '%{$keyword}%' ";
        $yuyueLogCountWhere .= " AND tel LIKE '%{$keyword}%' ";
    }else{
        $where .= " AND xm LIKE '%{$keyword}%' ";
        $yuyueLogCountWhere .= " AND xm LIKE '%{$keyword}%' ";
    }
}

if($type == 0){
    $tcyuyueLogCount1 = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_all_count($yuyueLogCountWhere.' AND yuyue_status = 1 ');
    $tcyuyueLogCount2 = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_all_count($yuyueLogCountWhere.' AND yuyue_status = 2 ');
    $tcyuyueLogCount3 = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_all_count($yuyueLogCountWhere.' AND yuyue_status = 3 ');
}

$order = " ORDER BY id DESC ";

$count = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_all_count($where);
$tcyuyueLogListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_all_list($where,$order,$start,$pagesize);
$tcyuyueLogList = array();
if(is_array($tcyuyueLogListTmp) && !empty($tcyuyueLogListTmp)){
    foreach ($tcyuyueLogListTmp as $key => $value){
        $tcyuyueLogList[$key] = $value;
        
        $tcyuyueInfoTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($value['tcyuyue_id']);
        
        $goodsUrlTmp = '';
        $goodsInfoTmp = array();
        if($value['yuyue_type'] == 'qianggou'){
            $goodsInfoTmp = C::t("#tom_tcqianggou#tom_tcqianggou_goods")->fetch_by_id($value['goods_id']);
            $goodsUrlTmp = "plugin.php?id=tom_tcqianggou&site={$goodsInfoTmp['site_id']}&mod=details&goods_id={$goodsInfoTmp['id']}";
            $goodsInfoTmp['goods_name']     = $goodsInfoTmp['title'];
        }else if($value['yuyue_type'] == 'ptuan'){
            $goodsInfoTmp = C::t("#tom_tcptuan#tom_tcptuan_goods")->fetch_by_id($value['goods_id']);
            $goodsUrlTmp = "plugin.php?id=tom_tcptuan&site={$goodsInfoTmp['site_id']}&mod=goodsinfo&goods_id={$goodsInfoTmp['id']}";
            $goodsInfoTmp['goods_name']     = $goodsInfoTmp['name'];
        }else if($value['yuyue_type'] == 'shop'){
            $goodsInfoTmp = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($value['goods_id']);
            $goodsUrlTmp = "plugin.php?id=tom_tcshop&site={$goodsInfoTmp['site_id']}&mod=details&dpid={$goodsInfoTmp['id']}";
            $goodsInfoTmp['goods_name']     = $goodsInfoTmp['name'];
        }
        
        if(!preg_match('/^http/', $goodsInfoTmp['picurl']) ){
            if(strpos($goodsInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfoTmp['picurl'];
            }else{
                $picurlTmp = $_G['siteurl'].$goodsInfoTmp['picurl'];
            }
        }else{
            $picurlTmp = $goodsInfoTmp['picurl'];
        }
        
        $goodsInfoTmp['goodsUrl']   = $goodsUrlTmp;
        $goodsInfoTmp['picurl']     = $picurlTmp;
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $attrListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_log_attr')->fetch_all_list(" AND tcyuyue_log_id = {$value['id']} ", " ORDER BY paixu ASC,id DESC ");
        $attrList = array();
        if(is_array($attrListTmp) && !empty($attrListTmp)){
            foreach($attrListTmp as $k => $v){
                $attrList[$k] = $v;
                if($v['attr_type'] == 4){
                    $attrList[$k]['valueList'] = explode('|', $v['value']);
                }
            }
        }
        
        $clerkInfoTmp = array();
        if($value['clerk_id'] > 0){
            $clerkInfoTmp = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_by_id($value['clerk_id']);
            if(!preg_match('/^http/', $clerkInfoTmp['picurl']) ){
                if(strpos($clerkInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                    $clerkPicurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$clerkInfoTmp['picurl'];
                }else{
                    $clerkPicurlTmp = $_G['siteurl'].$clerkInfoTmp['picurl'];
                }
            }else{
                $clerkPicurlTmp = $clerkInfoTmp['picurl'];
            }
            $clerkInfoTmp['picurl'] = $clerkPicurlTmp;
        }
        
        $hexiaoUserInfoTmp = array();
        if($value['yuyue_status'] == 2){
            $hexiaoUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        }
        
        $value['time_start_stamp'] = $value['time_start_stamp'] + $value['yuyue_daytime'];
        $value['time_end_stamp'] = $value['time_end_stamp'] + $value['yuyue_daytime'];
        
        $tcyuyueLogList[$key]['yuyueInfo']         = $tcyuyueInfoTmp;
        $tcyuyueLogList[$key]['start_time']        = dgmdate($value['time_start_stamp'],"Y-m-d H:i",$tomSysOffset);
        $tcyuyueLogList[$key]['end_time']          = dgmdate($value['time_end_stamp'],"H:i",$tomSysOffset);
        $tcyuyueLogList[$key]['goodsInfo']         = $goodsInfoTmp;
        $tcyuyueLogList[$key]['userInfo']          = $userInfo;
        $tcyuyueLogList[$key]['attrList']          = $attrList;
        $tcyuyueLogList[$key]['clerkInfo']         = $clerkInfoTmp;
        $tcyuyueLogList[$key]['hexiaoUserInfo']    = $hexiaoUserInfoTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyue_id}&type={$type}&yuyue_stamp={$yuyue_stamp}&page={$prePage}&back_url={$backUrl}";
$nextPageUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyue_id}&type={$type}&yuyue_stamp={$yuyue_stamp}&page={$nextPage}&back_url={$backUrl}";

$navUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyue_id}&yuyue_stamp={$yuyue_stamp}&back_url={$backUrl}";

$searchUrl = "plugin.php?id=tom_tcyuyue:ajax&site={$site_id}&act=get_myyuyue_search_url&tcyuyue_id={$tcyuyue_id}&back_url={$backUrl}";
$ajaxQuerenYuyueStatusUrl = "plugin.php?id=tom_tcyuyue:ajax&site={$site_id}&act=querenYuyue&tcyuyue_id={$tcyuyue_id}&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:myyuyue");