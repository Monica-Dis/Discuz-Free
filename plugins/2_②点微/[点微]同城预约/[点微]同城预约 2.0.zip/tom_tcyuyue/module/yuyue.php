<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$keyword            = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$tcyuyue_log_id     = intval($_GET['tcyuyue_log_id'])>0? intval($_GET['tcyuyue_log_id']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$type               = intval($_GET['type'])>0? intval($_GET['type']):0;
$back_url           = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$backUrl = urlencode($back_url);

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND user_id = {$__UserInfo['id']} ";
$order = " ORDER BY id DESC ";

if($type > 0){
    $where.= " AND yuyue_status = {$type} ";
}else{
    $where.= " AND yuyue_status > 0 ";
}
if($tcyuyue_log_id > 0){
    $where.= " AND id = {$tcyuyue_log_id} ";
}
if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    if(is_numeric($keyword)){
        $where .= " AND tel LIKE '%{$keyword}%' ";
    }else{
        $where .= " AND xm LIKE '%{$keyword}%' ";
    }
}

$count = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_all_count($where);
$tcyuyueLogListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_all_list($where,$order,$start,$pagesize);
$tcyuyueLogList = array();
if(is_array($tcyuyueLogListTmp) && !empty($tcyuyueLogListTmp)){
    foreach ($tcyuyueLogListTmp as $key => $value){
        $tcyuyueLogList[$key] = $value;
        
        $tcyuyueInfoTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($value['tcyuyue_id']);
        $tcshopInfoTmp = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcyuyueInfoTmp['tcshop_id']);
        if(!preg_match('/^http/', $tcshopInfoTmp['picurl']) ){
            if(strpos($tcshopInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                $tcshopInfoTmp['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfoTmp['picurl'];
            }else{
                $tcshopInfoTmp['picurl'] = $_G['siteurl'].$tcshopInfoTmp['picurl'];
            }
        }else{
            $tcshopInfoTmp['picurl'] = $tcshopInfoTmp['picurl'];
        }
        
        $picurlTmp = $hexiaoUrlTmp = $goodsUrlTmp = $goodsTitleTmp = '';
        $againYuyueStatusTmp = 0;
        $goodsInfoTmp = array();
        if($value['yuyue_type'] == 'qianggou'){
            $orderInfoTmp = C::t("#tom_tcqianggou#tom_tcqianggou_order")->fetch_by_order_no($value['order_no']);
            $goodsInfoTmp = C::t("#tom_tcqianggou#tom_tcqianggou_goods")->fetch_by_id($value['goods_id']);
            if($orderInfoTmp['order_status'] == 2 && $goodsInfoTmp['peisong_type'] == 1 && $goodsInfoTmp['open_yuyue'] == 1 && ($goodsInfoTmp['yuyue_type'] == 2 || $goodsInfoTmp['yuyue_type'] == 3) && $goodsInfoTmp['tcyuyue_id'] > 0){
                $againYuyueStatusTmp = 1;
            }
            if(!preg_match('/^http/', $goodsInfoTmp['picurl']) ){
                if(strpos($goodsInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfoTmp['picurl'];
                }else{
                    $picurlTmp = $_G['siteurl'].$goodsInfoTmp['picurl'];
                }
            }else{
                $picurlTmp = $goodsInfoTmp['picurl'];
            }
            $goodsTitleTmp = $goodsInfoTmp['title'];
            $hexiaoUrlTmp = "plugin.php?id=tom_tcqianggou&site={$goodsInfoTmp['site_id']}&mod=hexiao&order_no={$value['order_no']}";
            $goodsUrlTmp = "plugin.php?id=tom_tcqianggou&site={$goodsInfoTmp['site_id']}&mod=details&goods_id={$goodsInfoTmp['id']}";
        }else if($value['yuyue_type'] == 'ptuan'){
            $orderInfoTmp = C::t("#tom_tcptuan#tom_tcptuan_order")->fetch_by_order_no($value['order_no']);
            $goodsInfoTmp = C::t("#tom_tcptuan#tom_tcptuan_goods")->fetch_by_id($value['goods_id']);
            if($orderInfoTmp['order_status'] == 2 && $goodsInfoTmp['peisong_type'] == 1 && $goodsInfoTmp['open_yuyue'] == 1 && $goodsInfoTmp['yuyue_type'] == 3 && $goodsInfoTmp['tcyuyue_id'] > 0){
                $againYuyueStatusTmp = 1;
            }
            if(!preg_match('/^http/', $goodsInfoTmp['picurl']) ){
                if(strpos($goodsInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfoTmp['picurl'];
                }else{
                    $picurlTmp = $_G['siteurl'].$goodsInfoTmp['picurl'];
                }
            }else{
                $picurlTmp = $goodsInfoTmp['picurl'];
            }
            $goodsTitleTmp = $goodsInfoTmp['name'];
            $hexiaoUrlTmp = "plugin.php?id=tom_tcptuan&site={$goodsInfoTmp['site_id']}&mod=orderinfo&order_no={$value['order_no']}";
            $goodsUrlTmp = "plugin.php?id=tom_tcptuan&site={$goodsInfoTmp['site_id']}&mod=goodsinfo&goods_id={$goodsInfoTmp['id']}";
        }else if($value['yuyue_type'] == 'shop'){
            $goodsInfoTmp = $tcshopInfoTmp;
            if($goodsInfoTmp['open_yuyue'] == 1 && $goodsInfoTmp['tcyuyue_id'] > 0){
                $againYuyueStatusTmp = 1;
            }
            $goodsTitleTmp = $goodsInfoTmp['name'];
            $hexiaoUrlTmp = $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$goodsInfoTmp['site_id']}&mod=hexiao&tcyuyue_log_id={$value['id']}";
            $hexiaoUrlTmp = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($hexiaoUrlTmp);
            $goodsUrlTmp = "plugin.php?id=tom_tcshop&site={$goodsInfoTmp['site_id']}&mod=details&dpid={$goodsInfoTmp['id']}";
        }
        
        $attrArrTmp = C::t('#tom_tcyuyue#tom_tcyuyue_log_attr')->fetch_all_list(" AND tcyuyue_log_id = {$value['id']} ", " ORDER BY paixu ASC,id DESC ");
        $attrListTmp = array();
        if(is_array($attrArrTmp) && !empty($attrArrTmp)){
            foreach($attrArrTmp as $k => $v){
                $attrListTmp[$k] = $v;
                if($v['attr_type'] == 4){
                    $attrListTmp[$k]['valueList'] = explode('|', $v['value']);
                }
            }
        }
        
        $editYuyueStatusTmp = $cancelYuyueStatusTmp = 0;
        if($value['yuyue_status'] == 1 || $value['yuyue_status'] == 3){
            $againYuyueStatusTmp = 0;
            $editYuyueStatusTmp = $cancelYuyueStatusTmp = 1;
            if($tcyuyueInfoTmp['cancel_before_time_unit'] == 1){
                $cancelBeforeTimeTmp = $tcyuyueInfoTmp['cancel_before_time'] * 60 + TIMESTAMP;
            }else if($tcyuyueInfoTmp['cancel_before_time_unit'] == 2){
                $cancelBeforeTimeTmp = $tcyuyueInfoTmp['cancel_before_time'] * 3600 + TIMESTAMP;
            }else if($tcyuyueInfoTmp['cancel_before_time_unit'] == 3){
                $cancelBeforeTimeTmp = $tcyuyueInfoTmp['cancel_before_time'] * 86400 + TIMESTAMP;
            }
            if($cancelBeforeTimeTmp >= ($value['time_start_stamp'] + $value['yuyue_daytime'])){
                $cancelYuyueStatusTmp = $editYuyueStatusTmp = 0;
            }
        }
        
        $clerkInfoTmp = array();
        if($value['clerk_id'] > 0){
            $clerkInfoTmp = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_by_id($value['clerk_id']);
            if(!preg_match('/^http/', $clerkInfoTmp['picurl']) ){
                if(strpos($clerkInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                    $clerkPicurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$clerkInfoTmp['picurl'];
                }else{
                    $clerkPicurlTmp = $_G['siteurl'].$clerkInfoTmp['picurl'];
                }
            }else{
                $clerkPicurlTmp = $clerkInfoTmp['picurl'];
            }
            $clerkInfoTmp['picurl'] = $clerkPicurlTmp;
        }
        
        $value['time_start_stamp'] = $value['time_start_stamp'] + $value['yuyue_daytime'];
        $value['time_end_stamp'] = $value['time_end_stamp'] + $value['yuyue_daytime'];
        
        $tcyuyueLogList[$key]['start_time']         = dgmdate($value['time_start_stamp'],"Y-m-d H:i",$tomSysOffset);
        $tcyuyueLogList[$key]['end_time']           = dgmdate($value['time_end_stamp'],"H:i",$tomSysOffset);
        $tcyuyueLogList[$key]['tcyuyueInfo']       = $tcyuyueInfoTmp;
        $tcyuyueLogList[$key]['tcshopInfo']        = $tcshopInfoTmp;
        $tcyuyueLogList[$key]['tcshopUrl']         = "plugin.php?id=tom_tcshop&site={$tcshopInfoTmp['site_id']}&mod=details&dpid={$tcshopInfoTmp['id']}";
        $tcyuyueLogList[$key]['clerkInfo']         = $clerkInfoTmp;
        $tcyuyueLogList[$key]['picurl']            = $picurlTmp;
        $tcyuyueLogList[$key]['attrList']          = $attrListTmp;
        $tcyuyueLogList[$key]['againYuyueStatus']  = $againYuyueStatusTmp;
        $tcyuyueLogList[$key]['cancelYuyueStatus'] = $cancelYuyueStatusTmp;
        $tcyuyueLogList[$key]['editYuyueStatus']   = $editYuyueStatusTmp;
        $tcyuyueLogList[$key]['goods_title']       = $goodsTitleTmp;
        $tcyuyueLogList[$key]['goodsInfo']         = $goodsInfoTmp;
        $tcyuyueLogList[$key]['hexiaoUrl']          = $hexiaoUrlTmp;
        $tcyuyueLogList[$key]['goodsUrl']          = $goodsUrlTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=yuyue&type={$type}&page={$prePage}&back_url={$backUrl}";
$nextPageUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=yuyue&type={$type}&page={$nextPage}&back_url={$backUrl}";

$yuyue_back_url = $weixinClass->get_url();
$yuyue_back_url = urlencode($yuyue_back_url);

$navUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=yuyue&back_url={$backUrl}";
$searchUrl = "plugin.php?id=tom_tcyuyue:ajax&site={$site_id}&act=get_yuyue_search_url&back_url={$backUrl}";
$ajaxCancelYuyueStatusUrl = "plugin.php?id=tom_tcyuyue:ajax&site={$site_id}&act=cancelYuyue&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:yuyue");