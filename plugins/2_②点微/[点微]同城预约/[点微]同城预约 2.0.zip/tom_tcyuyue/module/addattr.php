<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcyuyue_id     = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
$back_url       = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
$type           = isset($_GET['type'])? intval($_GET['type']):0;

$tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyue_id);

if($__UserInfo['id'] != $tcyuyueInfo['user_id']){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=mylist");exit;
}

if($_GET['act'] == 'save' && submitcheck('tcyuyue_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $value              = isset($_GET['value'])? addslashes($_GET['value']):'';
    $is_must            = isset($_GET['is_must'])? intval($_GET['is_must']):0;
    $unit               = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $msg                = isset($_GET['msg'])? addslashes($_GET['msg']):'';
    $paixu              = isset($_GET['paixu'])? intval($_GET['paixu']):100;
  
    $insertData = array();
    $insertData['tcyuyue_id']         = $tcyuyue_id;
    $insertData['name']               = $name;
    $insertData['type']               = $type;
    $insertData['value']              = $value;
    $insertData['is_must']            = $is_must;
    $insertData['unit']               = $unit;
    $insertData['msg']                = $msg;
    $insertData['paixu']              = $paixu;
    $insertData['add_time']           = TIMESTAMP;
    if(C::t('#tom_tcyuyue#tom_tcyuyue_attr')->insert($insertData)){
        echo 200; exit;
    }else{
        echo 404; exit;
    }
}

$back_url = urlencode($back_url);
$saveUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=addattr&act=save";
$jumpUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=attrlist&tcyuyue_id={$tcyuyueInfo['id']}&back_url={$back_url}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:addattr");