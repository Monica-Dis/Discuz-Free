<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page  = intval($_GET['page'])>0? intval($_GET['page']):1;
$type  = intval($_GET['type'])>0? intval($_GET['type']):0;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND user_id={$__UserInfo['id']} ";
$order = " ORDER BY id DESC ";

if($type == 1){
    $where.= " AND status=1 AND shenhe_status=1 ";
}
if($type == 2){
    $where.= " AND shenhe_status = 2 ";
}
if($type == 3){
    $where.= " AND shenhe_status = 3 ";
}

$count = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_count($where);
$tcyuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list($where,$order,$start,$pagesize);
$tcyuyueList = array();
if(is_array($tcyuyueListTmp) && !empty($tcyuyueListTmp)){
    foreach ($tcyuyueListTmp as $key => $value){
        $tcyuyueList[$key] = $value;

        $tcyuyueLogCountTmp = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_all_count(" AND tcyuyue_id = {$value['id']} AND yuyue_status IN(1,3) ");

        $tcshopInfoTmp = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($value['tcshop_id']);
        if(!preg_match('/^http/', $tcshopInfoTmp['picurl']) ){
            if(strpos($tcshopInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfoTmp['picurl'];
            }else{
                $picurlTmp = $_G['siteurl'].$tcshopInfoTmp['picurl'];
            }
        }else{
            $picurlTmp = $tcshopInfoTmp['picurl'];
        }
        $tcshopInfoTmp['picurl'] = $picurlTmp;
       
        $clerkTsStatusTmp = 0;
        if($value['open_clerk'] == 1){
            $clerkCountTmp = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_all_count(" AND tcyuyue_id={$value['id']}");
            if($clerkCountTmp <= 0){
                $clerkTsStatusTmp = 1;
            }
        }

        $tcyuyueList[$key]['clerkTsStatus']     = $clerkTsStatusTmp;
        $tcyuyueList[$key]['tcshopInfo']        = $tcshopInfoTmp;
        $tcyuyueList[$key]['tcyuyueLogCount']   = $tcyuyueLogCountTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=mylist&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=mylist&type={$type}&page={$nextPage}";

$back_url = $weixinClass->get_url();
$back_url = urlencode($back_url);

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tcyuyue:ajax&site={$site_id}&act=updateStatus&&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:mylist");