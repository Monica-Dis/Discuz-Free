<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$clerk_id   = isset($_GET['clerk_id'])? intval($_GET['clerk_id']):0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$clerkInfo      = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_by_id($clerk_id);
$tcyuyueInfo    = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($clerkInfo['tcyuyue_id']);

if($__UserInfo['id'] != $tcyuyueInfo['user_id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=mylist");exit;
}

if($_GET['act'] == 'save' && submitcheck('clerk_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $total_renshu       = isset($_GET['total_renshu'])? intval($_GET['total_renshu']):0;
    $time_renshu        = isset($_GET['time_renshu'])? intval($_GET['time_renshu']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $csort              = isset($_GET['csort'])? intval($_GET['csort']):10;
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    
    $clerkInfoTmp = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_all_list(" AND tcshop_id = {$tcyuyueInfo['tcshop_id']} AND user_id = {$user_id} ", 'ORDER BY id ASC', 0, 1);
    if(is_array($clerkInfoTmp) && !empty($clerkInfoTmp[0])){ }else{
        echo 301; exit;
    }
    
    if($clerkInfo['user_id'] != $user_id){
        $yuyueCherkInfoTmp = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_all_list(" AND tcyuyue_id = {$tcyuyueInfo['id']} AND user_id = {$user_id} ", 'ORDER BY id DESC', 0, 1);
        if(is_array($yuyueCherkInfoTmp) && !empty($yuyueCherkInfoTmp[0])){
            echo 302; exit;
        }
    }
    
    $updateData = array();
    $updateData['user_id']          = $user_id;
    $updateData['total_renshu']     = $total_renshu;
    $updateData['time_renshu']      = $time_renshu;
    $updateData['name']             = $name;
    $updateData['picurl']           = $picurl;
    $updateData['csort']            = $csort;
    $updateData['status']           = 1;
    C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->update($clerk_id, $updateData);
    echo 200; exit;
}

$shopClerkListTmp = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_all_list(" AND tcshop_id = {$tcyuyueInfo['tcshop_id']} ", 'ORDER BY id ASC', 0, 100);
$shopClerkList = array();
if(is_array($shopClerkListTmp) && !empty($shopClerkListTmp)){
    foreach($shopClerkListTmp as $key => $value){
        $shopClerkList[$key] = $value;

        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $shopClerkList[$key]['userInfo'] = $userInfoTmp;
    }
}

if(!preg_match('/^http/', $clerkInfo['picurl']) ){
    if(strpos($clerkInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$clerkInfo['picurl'];
    }else{
        $picurl = $_G['siteurl'].$clerkInfo['picurl'];
    }
}else{
    $picurl = $clerkInfo['picurl'];
}

$backUrl = urlencode($back_url);
$jumpUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=clerklist&tcyuyue_id={$tcyuyueInfo['id']}&back_url={$backUrl}";
$saveUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=editclerk&act=save";
$wxUploadUrl = "plugin.php?id=tom_tcyuyue:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}";
$uploadUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=upload&act=photo&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcyuyue:editclerk");