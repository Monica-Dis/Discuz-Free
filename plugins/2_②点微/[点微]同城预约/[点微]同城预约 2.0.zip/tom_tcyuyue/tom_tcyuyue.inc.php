<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcyuyueConfig = $_G['cache']['plugin']['tom_tcyuyue'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = "20210508";

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){
}else{
    echo '<a href="https://dism.taobao.com/?@tom_tongcheng.plugin">https://dism.taobao.com/?@tom_tongcheng.plugin</a>';exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/nofind.php';

$wxJssdkConfig = array();
$wxJssdkConfig["appId"]     = "";
$wxJssdkConfig["timestamp"] = time();
$wxJssdkConfig["nonceStr"]  = "";
$wxJssdkConfig["signature"] = "";
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcyuyueConfig['wx_share_title'];
$shareDesc  = $tcyuyueConfig['wx_share_desc'];
$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=yuyue";
$shareLogo  = $tcyuyueConfig['wx_share_pic'];

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesinfo.php';

## tcadmin start
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
## tcadmin end
## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tcqianggou start
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
    $tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
    if($tcqianggouConfig['open_tcqianggou'] == 1){
        $__ShowTcqianggou = 1;
    }
}
## tcqianggou end
## tcptuan start
$__ShowTcptuan = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcptuan/tom_tcptuan.inc.php')){
    $tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
    if($tcptuanConfig['open_tcptuan'] == 1){
        $__ShowTcptuan = 1;
    }
}
## tcptuan end
## tctoutiao start
$__ShowTctoutiao = 0;
$tctoutiaoConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/tom_tctoutiao.inc.php')){
    $tctoutiaoConfig = $_G['cache']['plugin']['tom_tctoutiao'];
    if($tctoutiaoConfig['open_tctoutiao'] == 1){
        $__ShowTctoutiao = 1;
    }
}
## tctoutiao end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/config/config.data.php';

$footer_nav1_content_name = $footer_nav1_content_link = $footer_nav1_content_ico = '';
if($tongchengConfig['footer_nav1_mod'] == 2){
    if(!empty($tongchengConfig['footer_nav1_content'])){
        $footer_nav1_content = explode("|", $tongchengConfig['footer_nav1_content']);
        $footer_nav1_content_name = $footer_nav1_content[0];
        $footer_nav1_content_link = $footer_nav1_content[1];
        $footer_nav1_content_link = str_replace("{site}",$site_id, $footer_nav1_content_link);
        if(isset($footer_nav1_content[2]) && !empty($footer_nav1_content[2])){
            $footer_nav1_content_ico = $footer_nav1_content[2];
        }
    }
}

$footer_nav_content_name = $footer_nav_content_link = $footer_nav_content_ico = '';
if($tongchengConfig['footer_nav_mod'] == 1){
    if(!empty($tongchengConfig['footer_nav_content'])){
        $footer_nav_content = explode("|", $tongchengConfig['footer_nav_content']);
        $footer_nav_content_name = $footer_nav_content[0];
        $footer_nav_content_link = $footer_nav_content[1];
        $footer_nav_content_link = str_replace("{site}",$site_id, $footer_nav_content_link);
        if(isset($footer_nav_content[2]) && !empty($footer_nav_content[2])){
            $footer_nav_content_ico = $footer_nav_content[2];
        }
    }
}

if($tongchengConfig['footer_nav_mod'] == 7 && $__IsMiniprogram == 1 && $tctoutiaoConfig['closed_xiao'] == 1){
    $tongchengConfig['footer_nav_mod'] = 0;
}

$ajaxLoadListUrl            = 'plugin.php?id=tom_tcyuyue:ajax&site='.$site_id.'&act=list&formhash='.$formhash;
$ajaxUpdateYuyueStatusUrl   = 'plugin.php?id=tom_tcyuyue:ajax&site='.$site_id.'&act=update_yuyue_status&formhash='.$formhash;

/********************* info ***********************/
if($_GET['mod'] == 'info'){
    
    $goods_id           = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    $tcyuyue_log_id     = intval($_GET['tcyuyue_log_id'])>0? intval($_GET['tcyuyue_log_id']):0;
    $order_no           = isset($_GET['order_no'])? addslashes($_GET['order_no']):'';
    $yuyue_type         = isset($_GET['yuyue_type'])? addslashes($_GET['yuyue_type']):'';
    $buy_status         = intval($_GET['buy_status'])>0? intval($_GET['buy_status']):0;  // 1 ����ǰԤԼ  2 �����ԤԼ
    $back_url           = isset($_GET['back_url'])? addslashes($_GET['back_url']):"";
    
    $defaultYuyueUserInfo = $tcyuyueLogInfo = array();
    if($tcyuyue_log_id > 0){
        $tcyuyueLogInfo = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_by_id($tcyuyue_log_id);
        if($tcyuyueLogInfo['id'] > 0 && $tcyuyueLogInfo['user_id'] == $__UserInfo['id']){ }else{
            tomheader('location:'.$back_url);exit;
        }
        
        $goods_id = $tcyuyueLogInfo['goods_id'];
        $order_no = $tcyuyueLogInfo['order_no'];
        $yuyue_type = $tcyuyueLogInfo['yuyue_type'];
        
        $defaultYuyueUserInfo['xm']         = $tcyuyueLogInfo['xm'];
        $defaultYuyueUserInfo['tel']        = $tcyuyueLogInfo['tel'];
        $defaultYuyueUserInfo['beizu']      = $tcyuyueLogInfo['beizu'];
        $defaultYuyueUserInfo['clerk_id']   = $tcyuyueLogInfo['clerk_id'];
        
        $tcyuyueLogInfo['yuyue_days'] = dgmdate($tcyuyueLogInfo['yuyue_daytime'], 'j',$tomSysOffset);
        
        $tcyuyueLogAttrListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_log_attr")->fetch_all_list("AND tcyuyue_log_id = {$tcyuyue_log_id}");
        $tcyuyueLogAttrList = array();
        if(is_array($tcyuyueLogAttrListTmp) && !empty($tcyuyueLogAttrListTmp)){
            foreach($tcyuyueLogAttrListTmp as $key => $value){
                $tcyuyueLogAttrList[$value['attr_id']] = $value;
                if($value['attr_type'] == 4){
                    $tcyuyueLogAttrList[$value['attr_id']]['valueList'] = explode('|', $value['value']);
                }
            }
        }
    }
    
    $showYuyueUserBox  = 1;
    $goodsInfo = $tcyuyueInfo = $orderInfo = array();
    if($yuyue_type == 'qianggou'){
        if($buy_status == 1){
            $showYuyueUserBox = 0;
            $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
        }else if($buy_status == 2){
            $orderInfo = C::t("#tom_tcqianggou#tom_tcqianggou_order")->fetch_by_order_no($order_no);
            $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($orderInfo['goods_id']);
            $defaultYuyueUserInfo['xm']         = $orderInfo['xm'];
            $defaultYuyueUserInfo['tel']        = $orderInfo['tel'];
            $defaultYuyueUserInfo['beizu']      = $orderInfo['order_beizu'];
        }
    }else if($yuyue_type == 'ptuan'){
        if($buy_status == 2){
            $orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_order_no($order_no);
            $goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($orderInfo['goods_id']);
            $defaultYuyueUserInfo['xm']         = $orderInfo['xm'];
            $defaultYuyueUserInfo['tel']        = $orderInfo['tel'];
            $defaultYuyueUserInfo['beizu']      = $orderInfo['order_beizu'];
        }
    }else if($yuyue_type == 'shop'){
        $goodsInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goods_id);
    }
    
    if(!preg_match('/^http/', $goodsInfo['picurl']) ){
        if(strpos($goodsInfo['picurl'], 'source/plugin/tom_') === FALSE){
            $goodsInfo['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['picurl'];
        }else{
            $goodsInfo['picurl'] = $_G['siteurl'].$goodsInfo['picurl'];
        }
    }else{
        $goodsInfo['picurl'] = $goodsInfo['picurl'];
    }
    $tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($goodsInfo['tcyuyue_id']);
    if($tcyuyueInfo['id'] > 0 && $tcyuyueInfo['status'] == 1 && $tcyuyueInfo['shenhe_status'] == 1){
    }else{
        tomheader('location:'.$back_url);exit;
    }
    
    $showYuyueTipsStatus = 0;
    if($tcyuyueLogInfo['id'] > 0 || $buy_status == 1){ }else{
        $userWhere = "AND yuyue_type = '{$yuyue_type}' AND user_id = {$__UserInfo['id']} AND tcyuyue_id = {$tcyuyueInfo['id']} AND yuyue_status IN (1,3)";
        if($buy_status == 2){
            $userWhere .= " AND order_no = '{$order_no}' "; 
        }
        $tcyuyueLogInfoTmp = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_all_list($userWhere, 'ORDER BY id DESC', 0, 1);
        if(is_array($tcyuyueLogInfoTmp) && !empty($tcyuyueLogInfoTmp[0])){
            $tcyuyueLogInfo = $tcyuyueLogInfoTmp[0];
            $showYuyueTipsStatus = 1;
        }
    }
    
    $notDateListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_notdate")->fetch_all_list(" AND tcyuyue_id = {$tcyuyueInfo['id']} ", 'ORDER BY id ASC');
    $notDateList = array();
    if(is_array($notDateListTmp) && !empty($notDateListTmp)){
        foreach($notDateListTmp as $key => $value){
            $notDateList[] = $value['notdate_stamp'];
        }
    }
    
    $yuyueDatesArr = explode('|', $tcyuyueInfo['yuyue_dates']);
    
    $beforeDayTime = 0;
    if($tcyuyueInfo['before_time_unit'] == 3){
        $beforeTime = $tcyuyueInfo['before_time'] * 86400 + TIMESTAMP;
        $beforeDayTime = gmmktime(0,0,0,dgmdate($beforeTime, 'n',$tomSysOffset),dgmdate($beforeTime, 'j',$tomSysOffset),dgmdate($beforeTime, 'Y',$tomSysOffset)) - $tomSysOffset*3600;
    }
    
    $datesList = array();
    for($i = 0; $i < $tcyuyueInfo['yuyue_days']; $i++){
        $stampTmp = $i * 86400 + TIMESTAMP;
        $monthTmp = dgmdate($stampTmp, 'm',$tomSysOffset);
        $dayTmp = dgmdate($stampTmp, 'j',$tomSysOffset);
        $weekTmp = dgmdate($stampTmp, 'N',$tomSysOffset);
        $timeStampTmp = gmmktime(0,0,0,dgmdate($stampTmp, 'n',$tomSysOffset),dgmdate($stampTmp, 'j',$tomSysOffset),dgmdate($stampTmp, 'Y',$tomSysOffset)) - $tomSysOffset*3600;
        
        $showDateStatus = 0;
        if($tcyuyueInfo['date_type'] == 1 && in_array($weekTmp, $yuyueDatesArr)){
            $showDateStatus = 1;
        }else if($tcyuyueInfo['date_type'] == 2 && in_array($dayTmp, $yuyueDatesArr)){
            $showDateStatus = 1;
        }
        
        if($showDateStatus == 1 && in_array($timeStampTmp, $notDateList)){
            $showDateStatus = 0;
        }
        
        if($showDateStatus == 1 && $timeStampTmp < $beforeDayTime){
            $showDateStatus = 0;
        }
        
        if($yuyue_type == 'qianggou' || $yuyue_type == 'ptuan'){
            if($showDateStatus == 1 && $goodsInfo['hexiao_time'] > 0 && $timeStampTmp > $goodsInfo['hexiao_time']){
                $showDateStatus = 0;
            }
        }
        
        if($showDateStatus == 0 && $tcyuyue_log_id > 0 && $tcyuyueLogInfo['yuyue_daytime'] == $timeStampTmp){
            $showDateStatus = 1;
        }
        
        if($showDateStatus == 1){
            $datesList[$i]['month']         = $monthTmp;
            $datesList[$i]['day']           = $dayTmp;
            $datesList[$i]['week']          = $weekTmp;
            $datesList[$i]['time_stamp']    = $timeStampTmp;
        }
    }
    
    $attrListTmp = C::t("#tom_tcyuyue#tom_tcyuyue_attr")->fetch_all_list(" AND tcyuyue_id = {$tcyuyueInfo['id']} AND is_hidden = 0 ", 'ORDER BY paixu ASC, id ASC');
    $attrList = array();
    if(is_array($attrListTmp) && !empty($attrListTmp)){
        foreach($attrListTmp as $key => $value){
            $attrList[$key] = $value;
            
            if($value['type'] == 3 || $value['type'] == 4){
                $valueArrStr = str_replace("\r\n","{n}",$value['value']); 
                $valueArrStr = str_replace("\n","{n}",$valueArrStr);
                $attrList[$key]['list'] = explode("{n}", $valueArrStr);
            }
            
            $attrList[$key]['logAttrInfo'] = array();
            if($tcyuyue_log_id > 0){
                $attrList[$key]['logAttrInfo'] = $tcyuyueLogAttrList[$value['id']];
                $valueArrTmp = array();
                foreach($attrList[$key]['list'] as $k => $v){
                    $valueArrTmp[$k]['value'] = $v; 
                    $valueArrTmp[$k]['checked'] = 0; 
                    if(in_array($v, $tcyuyueLogAttrList[$value['id']]['valueList'])){
                        $valueArrTmp[$k]['checked'] = 1; 
                    }
                }
                $attrList[$key]['logAttrInfo']['valueList'] = $valueArrTmp;
            }
        }
    }
    $attrCount = count($attrList);
    
    $jinzhiSelectTimeStatus = 0;
    if($tcyuyueLogInfo['id'] > 0){
        $xianzhiYuyueStamp = 0;
        if($tcyuyueInfo['before_time_unit'] == 1){
            $xianzhiYuyueStamp = $tcyuyueInfo['before_time'] * 60 + TIMESTAMP;
        }else if($tcyuyueInfo['before_time_unit'] == 2){
            $xianzhiYuyueStamp = $tcyuyueInfo['before_time'] * 3600 + TIMESTAMP;
        }else if($tcyuyueInfo['before_time_unit'] == 3){
            $xianzhiYuyueStamp = $tcyuyueInfo['before_time'] * 86400 + TIMESTAMP;
        }
        
        $startYuyueStamp = $tcyuyueLogInfo['time_start_stamp'] + $tcyuyueLogInfo['yuyue_daytime'];
        if($startYuyueStamp <= $xianzhiYuyueStamp){
            $jinzhiSelectTimeStatus = 1;
        }
    }
    
    $weiyueStatus = 0;
    $weiyueMsg = $tcyuyueConfig['weiyue_msg'];
    if($tcyuyueConfig['open_weiyue'] == 1){
        $weiyueWhere = " AND yuyue_status = 5 ";
        if($tcyuyueConfig['weiyue_type'] == 2){
            $weiyueWhere .= " AND tcyuyue_id = {$tcyuyueInfo['id']} ";
        }
        $weiyueDate = 0;
        if($tcyuyueConfig['weiyue_date'] == 1){
            $weiyueDate = TIMESTAMP - 86400*7;
            $weiyueMsg = str_replace("{DATE}",lang('plugin/tom_tcyuyue','weiyue_date_1'), $weiyueMsg);
        }else if($tcyuyueConfig['weiyue_date'] == 2){
            $weiyueDate = TIMESTAMP - 86400*30;
            $weiyueMsg = str_replace("{DATE}",lang('plugin/tom_tcyuyue','weiyue_date_2'), $weiyueMsg);
        }else if($tcyuyueConfig['weiyue_date'] == 3){
            $weiyueDate = TIMESTAMP - 86400*90;
            $weiyueMsg = str_replace("{DATE}",lang('plugin/tom_tcyuyue','weiyue_date_3'), $weiyueMsg);
        }else if($tcyuyueConfig['weiyue_date'] == 4){
            $weiyueDate = TIMESTAMP - 86400*180;
            $weiyueMsg = str_replace("{DATE}",lang('plugin/tom_tcyuyue','weiyue_date_4'), $weiyueMsg);
        }else if($tcyuyueConfig['weiyue_date'] == 5){
            $weiyueDate = TIMESTAMP - 86400*365;
            $weiyueMsg = str_replace("{DATE}",lang('plugin/tom_tcyuyue','weiyue_date_5'), $weiyueMsg);
        }
        $weiyueWhere .= " AND add_time > {$weiyueDate} ";
        $weiyueLogCount = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_all_count($weiyueWhere);
        if($weiyueLogCount >= $tcyuyueConfig['weiyue_num'] && $tcyuyueConfig['weiyue_num'] > 0){
            $weiyueStatus = 1;
        }
        $weiyueMsg = str_replace("{NUM}",$tcyuyueConfig['weiyue_num'], $weiyueMsg);
    }
    
    $url = $weixinClass->get_url();
    
    $ajaxLoadTimeUrl = "plugin.php?id=tom_tcyuyue:ajax&site={$site_id}&act=load_time&tcyuyue_id={$tcyuyueInfo['id']}&tcyuyue_log_id={$tcyuyue_log_id}&hexiao_time={$goodsInfo['hexiao_time']}&formhash=".$formhash;
    $ajaxLoadClerkUrl = "plugin.php?id=tom_tcyuyue:ajax&site={$site_id}&act=load_clerk&tcyuyue_id={$tcyuyueInfo['id']}&tcyuyue_log_id={$tcyuyue_log_id}&formhash=".$formhash;
    $ajaxYuyueUrl = "plugin.php?id=tom_tcyuyue:yuyue&site={$site_id}&act=yuyue";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
    include template("tom_tcyuyue:info");
    
    
    
/********************* mylist ***********************/
}else if($_GET['mod'] == 'mylist'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/mylist.php';
    
/********************* add ***********************/
}else if($_GET['mod'] == 'add'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/add.php';
    
/********************* edit ***********************/
}else if($_GET['mod'] == 'edit'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/edit.php';
    
/********************* attrlist ***********************/
}else if($_GET['mod'] == 'attrlist'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/attrlist.php';
    
/********************* addattr ***********************/
}else if($_GET['mod'] == 'addattr'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/addattr.php';
    
/********************* editattr ***********************/
}else if($_GET['mod'] == 'editattr'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/editattr.php';
    
/********************* clerklist ***********************/
}else if($_GET['mod'] == 'clerklist'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/clerklist.php';
    
/********************* addclerk ***********************/
}else if($_GET['mod'] == 'addclerk'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/addclerk.php';
    
/********************* editclerk ***********************/
}else if($_GET['mod'] == 'editclerk'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/editclerk.php';
    
/********************* myyuyue ***********************/
}else if($_GET['mod'] == 'myyuyue'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/myyuyue.php';
    
/********************* myyuyueShenhe ***********************/
}else if($_GET['mod'] == 'myyuyueShenhe'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/myyuyueShenhe.php';
    
/********************* yuyue ***********************/
}else if($_GET['mod'] == 'yuyue'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/yuyue.php';
    
/********************* hexiao ***********************/
}else if($_GET['mod'] == 'hexiao'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/hexiao.php';
    
/********************* upload ***********************/
}else if($_GET['mod'] == 'upload'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/module/upload.php';
    
}else{
    
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=yuyue");exit;
    
}
tomoutput();