<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modelTypeArr = array();

$modelTypeArr[1] = array(
    'name' => '������',
    'list' => array(
        1 => array(
            'name' => '����',
            'start_stamp' => 32400,
            'end_stamp' => 41400,
        ),
        2 => array(
            'name' => '����',
            'start_stamp' => 45000,
            'end_stamp' => 64800,
        ),
    ),
);

$modelTypeArr[2] = array(
    'name' => 'ʱ���',
    'list' => array(
        1 => array(
            'name' => '9:00',
            'start_stamp' => 32400,
            'end_stamp' => 34200,
        ),
        2 => array(
            'name' => '9:30',
            'start_stamp' => 34200,
            'end_stamp' => 36000,
        ),
        3 => array(
            'name' => '10:00',
            'start_stamp' => 36000,
            'end_stamp' => 37800,
        ),
        4 => array(
            'name' => '10:30',
            'start_stamp' => 37800,
            'end_stamp' => 39600,
        ),
        5 => array(
            'name' => '11:00',
            'start_stamp' => 39600,
            'end_stamp' => 41400,
        ),
        6 => array(
            'name' => '11:30',
            'start_stamp' => 41400,
            'end_stamp' => 43200,
        ),
        7 => array(
            'name' => '12:00',
            'start_stamp' => 43200,
            'end_stamp' => 45000,
        ),
        8 => array(
            'name' => '12:30',
            'start_stamp' => 45000,
            'end_stamp' => 46800,
        ),
        9 => array(
            'name' => '13:00',
            'start_stamp' => 46800,
            'end_stamp' => 48600,
        ),
        10 => array(
            'name' => '13:30',
            'start_stamp' => 48600,
            'end_stamp' => 50400,
        ),
        11 => array(
            'name' => '14:00',
            'start_stamp' => 50400,
            'end_stamp' => 52200,
        ),
        12 => array(
            'name' => '14:30',
            'start_stamp' => 52200,
            'end_stamp' => 54000,
        ),
        13 => array(
            'name' => '15:00',
            'start_stamp' => 54000,
            'end_stamp' => 55800,
        ),
        14 => array(
            'name' => '15:30',
            'start_stamp' => 55800,
            'end_stamp' => 57600,
        ),
        15 => array(
            'name' => '16:00',
            'start_stamp' => 57600,
            'end_stamp' => 59400,
        ),
        16 => array(
            'name' => '16:30',
            'start_stamp' => 59400,
            'end_stamp' => 61200,
        ),
        17 => array(
            'name' => '17:00',
            'start_stamp' => 61200,
            'end_stamp' => 63000,
        ),
        18 => array(
            'name' => '17:30',
            'start_stamp' => 63000,
            'end_stamp' => 64800,
        ),
        19 => array(
            'name' => '18:00',
            'start_stamp' => 64800,
            'end_stamp' => 66600,
        ),
    ),
);


if (CHARSET == 'utf-8') {
    $modelTypeArr = tom_iconv_import($modelTypeArr,'gbk','utf-8');
}

function tom_iconv_import($data, $in_charset, $out_charset) {
    if(is_array($data)) {
        foreach($data AS $key => $val) {
            $data[$key] = tom_iconv_import($val, $in_charset, $out_charset);
        }
    } else {
        $data = diconv($data, $in_charset, $out_charset);
    }
    return $data;
}