<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_weixin_activity`;
CREATE TABLE `pre_tom_weixin_activity` (
  `openid` varchar(100) NOT NULL,
  `act_cmd` varchar(100) NOT NULL,
  `act_text` text NOT NULL,
  `act_type` tinyint(2) NOT NULL,
  `act_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`openid`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_hook`;
CREATE TABLE `pre_tom_weixin_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hook_type` tinyint(4) NOT NULL,
  `hook_script` varchar(255) DEFAULT NULL,
  `obj_id` varchar(255) DEFAULT NULL,
  `obj_type` tinyint(4) DEFAULT '1',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_log`;
CREATE TABLE `pre_tom_weixin_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `open_id` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `msg_type` varchar(255) DEFAULT NULL,
  `log_time` int(11) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_module`;
CREATE TABLE `pre_tom_weixin_module` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` varchar(50) NOT NULL,
  `module_cmd` varchar(50) NOT NULL,
  `module_desc` varchar(100) NOT NULL,
  `module_setting` text NOT NULL,
  `power_id` tinyint(4) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '100',
  `is_menu` tinyint(4) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_plugin`;
CREATE TABLE `pre_tom_weixin_plugin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plugin_id` varchar(50) NOT NULL,
  `plugin_cmd` varchar(50) NOT NULL,
  `plugin_desc` varchar(100) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '100',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_user`;
CREATE TABLE `pre_tom_weixin_user` (
  `openid` varchar(100) NOT NULL,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100) NOT NULL,
  `bind_time` int(11) NOT NULL DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`openid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_subuser`;
CREATE TABLE `pre_tom_weixin_subuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `open_id` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `headimgurl` varchar(255) DEFAULT NULL,
  `sex` int(11) DEFAULT '0',
  `country` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `up_time` int(11) DEFAULT '0',
  `sub_time` int(11) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_menu`;
CREATE TABLE `pre_tom_weixin_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_id` int(11) DEFAULT '0',
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `media_id` varchar(255) DEFAULT NULL,
  `appid` varchar(255) DEFAULT NULL,
  `pagepath` varchar(255) DEFAULT NULL,
  `msort` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_qrcode`;
CREATE TABLE `pre_tom_weixin_qrcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `qkey` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `extend` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `tcchoujiang_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qkey` (`qkey`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_fqrcode`;
CREATE TABLE `pre_tom_weixin_fqrcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `qkey` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `extend` varchar(255) DEFAULT NULL,
  `tcshop_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qkey` (`qkey`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$finish = TRUE;
