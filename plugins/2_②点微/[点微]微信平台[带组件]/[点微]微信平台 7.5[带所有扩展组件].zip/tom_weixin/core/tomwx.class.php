<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class tom_weixin{
    
    var $openid = '';
    var $msgtype = '';
    
    public function __construct(){}
    
    public static function getInstance(){
        return new self();
    }
    
    public function set_openid($openid = ''){
        $openid = addslashes(dhtmlspecialchars($openid));
        $this->openid = $openid;
        return;
    }
    
    public function set_msgtype($msgtype = ''){
        $this->msgtype = addslashes(dhtmlspecialchars($msgtype));
        return;
    }
    
    public function get_openid(){
        return $this->openid;
    }

    public function subscribe(){
        global $_G,$tomConfig,$moduleClass;
        $openid = $this->openid;
        $msgtype = $this->msgtype;
        $outArr = array(
            'type'      => 'text',
            'content'   => '',
        );
        $outArr['content'] = str_replace("{n}", "\n", $tomConfig['wx_subscribe']);
        
        $subData = array();
        $subData['open_id'] = $openid;
        $subData['sub_time'] = TIMESTAMP;
        C::t('#tom_weixin#tom_weixin_subuser')->insert($subData);
        
        $isDoHookContent = false;
        $hookFilename = DISCUZ_ROOT.'./source/plugin/tom_weixin/hook/subscribe.hook.php';
        if(file_exists($hookFilename)){
            include $hookFilename;
        }
        return $outArr;
    }
    public function unsubscribe(){
        global $_G,$tomConfig,$moduleClass;
        $openid = $this->openid;
        $msgtype = $this->msgtype;
        $this->delActivity();
        
        C::t('#tom_weixin#tom_weixin_log')->delete_by_openid($openid);
        C::t('#tom_weixin#tom_weixin_subuser')->delete_by_openid($openid);
        
        $isDoHookContent = false;
        $hookFilename = DISCUZ_ROOT.'./source/plugin/tom_weixin/hook/unsubscribe.hook.php';
        if(file_exists($hookFilename)){
            include $hookFilename;
        }
    }
    
    public function click($keyword){
        global $_G,$tomConfig;
        $openid = $this->openid;
        $msgtype = $this->msgtype;
        $outArr = array();
        
        $this->delActivity();
        $outArr = $this->doCmd($keyword);
        
        return $outArr;
    }
    
    public function msg($keyword){
        global $_G,$tomConfig,$moduleClass;
        $openid = $this->openid;
        $msgtype = $this->msgtype;
        $keyword = addslashes(dhtmlspecialchars($keyword));
        
        $subuser = C::t('#tom_weixin#tom_weixin_subuser')->fetch_by_openid($openid);
        if(!$subuser){
            $subData = array();
            $subData['open_id'] = $openid;
            $subData['sub_time'] = TIMESTAMP;
            C::t('#tom_weixin#tom_weixin_subuser')->insert($subData);
        }
        
        $isDoHookContent = false;
        $hookFilename = DISCUZ_ROOT.'./source/plugin/tom_weixin/hook/msg.hook.php';
        if(file_exists($hookFilename)){
            include $hookFilename;
        }
        
        return true;
    }
    
    public function view($keyword){
        global $_G,$tomConfig,$moduleClass;
        $openid = $this->openid;
        $msgtype = $this->msgtype;
        $outArr = array(
            'type'      => 'text',
            'content'   => '',
        );
        $keyword = addslashes(dhtmlspecialchars($keyword));
        
        $isDoHookContent = false;
        $hookFilename = DISCUZ_ROOT.'./source/plugin/tom_weixin/hook/view.hook.php';
        if(file_exists($hookFilename)){
            include $hookFilename;
        }
        return $outArr;
    }
    
    public function location($keyword){
        global $_G,$tomConfig,$moduleClass;
        $openid = $this->openid;
        $msgtype = $this->msgtype;
        $outArr = array(
            'type'      => 'text',
            'content'   => '',
        );
        $keyword = addslashes(dhtmlspecialchars($keyword));
        
        $isDoHookContent = false;
        $hookFilename = DISCUZ_ROOT.'./source/plugin/tom_weixin/hook/location.hook.php';
        if(file_exists($hookFilename)){
            include $hookFilename;
        }
        
        return $outArr;
    }
    
    public function scan($keyword){
        global $_G,$tomConfig,$moduleClass;
        $openid = $this->openid;
        $msgtype = $this->msgtype;
        $outArr = array(
            'type'      => 'text',
            'content'   => '',
        );
        $keyword = addslashes(dhtmlspecialchars($keyword));
        $keyword = trim($keyword);
        
        if(is_string($keyword) && strpos($keyword,'scan_') !== false){
            $qrcodeInfo = C::t('#tom_weixin#tom_weixin_fqrcode')->fetch_by_qkey($keyword);
            if($qrcodeInfo){
                $outArr = array(
                    'type'      => 'news',
                    'content'   => array(),
                );
                $newsItem = array(
                    'title'         => $qrcodeInfo['title'],
                    'description'   => $qrcodeInfo['desc'],
                    'picUrl'        => $qrcodeInfo['picurl'],
                    'url'           => $qrcodeInfo['link'],
                );
                $outArr['content'][] = $newsItem;

                if($qrcodeInfo['extend'] == 'tcshop'){
                    
                    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcmall/tom_tcmall.inc.php') && $_G['cache']['plugin']['tom_tcmall']['open_tcmall'] == 1){
                        $mallGoodsListTmp  = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND tcshop_id={$qrcodeInfo['tcshop_id']} "," ORDER BY gsort ASC,id DESC ",0,2);
                        foreach ($mallGoodsListTmp as $key => $value){
                            $picurl = '';
                            $link = '';
                            if(!preg_match('/^http/', $value['picurl']) ){
                                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                                }else{
                                    $picurl = $_G['siteurl'].$value['picurl'];
                                }
                            }else{
                                $picurl = $value['picurl'];
                            }
                            $link = $_G['siteurl'].'plugin.php?id=tom_tcmall&site='.$value['site_id'].'&mod=goodsinfo&goods_id='.$value['id'];
                            $newsItem = array(
                                'title'         => $value['title'],
                                'description'   => $value['title'],
                                'picUrl'        => $picurl,
                                'url'           => $link,
                            );
                            $outArr['content'][] = $newsItem;
                        }
                    }
                    
                    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php') && $_G['cache']['plugin']['tom_tcqianggou']['open_tcqianggou'] == 1){
                        $qgGoodsListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND qiang_status IN (1,2) AND tcshop_id={$qrcodeInfo['tcshop_id']} "," ORDER BY qiang_status ASC, id DESC ",0,2);
                        foreach ($qgGoodsListTmp as $key => $value){
                            $picurl = '';
                            $link = '';
                            if(!preg_match('/^http/', $value['picurl']) ){
                                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                                }else{
                                    $picurl = $_G['siteurl'].$value['picurl'];
                                }
                            }else{
                                $picurl = $value['picurl'];
                            }
                            if($value['type_id'] == 1){
                                $link = $_G['siteurl'].'plugin.php?id=tom_tcqianggou&site='.$value['site_id'].'&mod=details&goods_id='.$value['id'];
                            }else{
                                $link = $_G['siteurl'].'plugin.php?id=tom_tcqianggou&site='.$value['site_id'].'&mod=coupon&goods_id='.$value['id'];
                            }
                            $newsItem = array(
                                'title'         => $value['title'],
                                'description'   => $value['title'],
                                'picUrl'        => $picurl,
                                'url'           => $link,
                            );
                            $outArr['content'][] = $newsItem;
                        }
                    }
                    
                    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcptuan/tom_tcptuan.inc.php') && $_G['cache']['plugin']['tom_tcptuan']['open_tcptuan'] == 1){
                        $ptGoodsListTmp   = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND ptuan_status=1 AND tcshop_id={$qrcodeInfo['tcshop_id']} "," ORDER BY ptuan_status ASC,paixu ASC,id DESC ",0,2);
                        foreach ($ptGoodsListTmp as $key => $value){
                            $goodsList[$key] = $value;
                            $picurl = '';
                            $link = '';
                            if(!preg_match('/^http/', $value['picurl']) ){
                                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                                }else{
                                    $picurl = $_G['siteurl'].$value['picurl'];
                                }
                            }else{
                                $picurl = $value['picurl'];
                            }
                            $link = $_G['siteurl'].'plugin.php?id=tom_tcptuan&site='.$value['site_id'].'&mod=goodsinfo&goods_id='.$value['id'];
                            $newsItem = array(
                                'title'         => $value['name'],
                                'description'   => $value['name'],
                                'picUrl'        => $picurl,
                                'url'           => $link,
                            );
                            $outArr['content'][] = $newsItem;
                        }
                    }
                    
                    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tckjia/tom_tckjia.inc.php') && $_G['cache']['plugin']['tom_tckjia']['open_tckjia'] == 1){
                        $kjGoodsListTmp   = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND kanjia_status IN (1,2) AND tcshop_id={$qrcodeInfo['tcshop_id']} "," ORDER BY kanjia_status ASC, id DESC ",0,2);
                        foreach ($kjGoodsListTmp as $key => $value){
                            $picurl = '';
                            $link = '';
                            if(!preg_match('/^http/', $value['picurl']) ){
                                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                                }else{
                                    $picurl = $_G['siteurl'].$value['picurl'];
                                }
                            }else{
                                $picurl = $value['picurl'];
                            }
                            $link = $_G['siteurl'].'plugin.php?id=tom_tckjia&site='.$value['site_id'].'&mod=details&goods_id='.$value['id'];
                            $newsItem = array(
                                'title'         => $value['title'],
                                'description'   => $value['title'],
                                'picUrl'        => $picurl,
                                'url'           => $link,
                            );
                            $outArr['content'][] = $newsItem;
                        }
                    }
                    
                    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php') && $_G['cache']['plugin']['tom_tcchoujiang']['open_tcchoujiang'] == 1){
                        $cjGoodsListTmp   = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_all_list(" AND type = 2 AND status = 1 AND shenhe_status = 1 AND tcshop_id={$qrcodeInfo['tcshop_id']} "," ORDER BY chou_status ASC,paixu ASC,id DESC ",0,2);
                        foreach ($cjGoodsListTmp as $key => $value){
                            $picurl = '';
                            $link = '';
                            if(!preg_match('/^http/', $value['picurl']) ){
                                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                                }else{
                                    $picurl = $_G['siteurl'].$value['picurl'];
                                }
                            }else{
                                $picurl = $value['picurl'];
                            }
                            $link = $_G['siteurl'].'plugin.php?id=tom_tcchoujiang&site='.$value['site_id'].'&mod=details&cjid='.$value['id'];
                            $newsItem = array(
                                'title'         => $value['title'],
                                'description'   => $value['title'],
                                'picUrl'        => $picurl,
                                'url'           => $link,
                            );
                            $outArr['content'][] = $newsItem;
                        }
                    }
                    
                }
                return $outArr;

            }
        }else{
            $qrcodeInfo = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_by_id($keyword);
            if($qrcodeInfo){
                $outArr = array(
                    'type'      => 'news',
                    'content'   => array(),
                );
                $newsItem = array(
                    'title'         => $qrcodeInfo['title'],
                    'description'   => $qrcodeInfo['desc'],
                    'picUrl'        => $qrcodeInfo['picurl'],
                    'url'           => $qrcodeInfo['link'],
                );
                $outArr['content'][] = $newsItem;

                if($qrcodeInfo['extend'] == 'tcshopguanzu'){
                    $guanzuListTmp = C::t('#tom_tcshop#tom_tcshop_guanzu')->fetch_all_list(" AND user_id={$qrcodeInfo['user_id']} AND tcshop_id={$qrcodeInfo['tcshop_id']} "," ORDER BY id DESC ",0,1);
                    if(is_array($guanzuListTmp) && !empty($guanzuListTmp)){}else{
                        $insertData = array();
                        $insertData['user_id']      = $qrcodeInfo['user_id'];
                        $insertData['tcshop_id']    = $qrcodeInfo['tcshop_id'];
                        $insertData['add_time']     = TIMESTAMP;
                        if(C::t('#tom_tcshop#tom_tcshop_guanzu')->insert($insertData)){
                            DB::query("UPDATE ".DB::table('tom_tcshop')." SET guanzu=guanzu+1 WHERE id='".$qrcodeInfo['tcshop_id']."' ", 'UNBUFFERED');
                        }
                    }
                }

                if($qrcodeInfo['extend'] == 'tcchoujiangguanzu'){
                    $bmListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_all_list(" AND user_id={$qrcodeInfo['user_id']} AND tcchoujiang_id={$qrcodeInfo['tcchoujiang_id']} AND guanzu_status=0 "," ORDER BY id DESC ",0,1);
                    if(is_array($bmListTmp) && !empty($bmListTmp)){
                        DB::query("UPDATE ".DB::table('tom_tcchoujiang_bm')." SET cj_times=cj_times+1,guanzu_status=1 WHERE id='".$bmListTmp[0]['id']."' ", 'UNBUFFERED');
                    }
                }

                return $outArr;

            }
        }
        
        $isDoHookContent = false;
        $hookFilename = DISCUZ_ROOT.'./source/plugin/tom_weixin/hook/scan.hook.php';
        if(file_exists($hookFilename)){
            include $hookFilename;
        }
        
        return $outArr;
    }

    public function text($keyword = ''){
        global $_G,$tomConfig;
        $openid = $this->openid;
        $msgtype = $this->msgtype;
        $outArr = array();
        $outArr = $this->doCmd($keyword);
        return $outArr;
    }
    
    public function doCmd($keyword){
        global $_G,$tomConfig,$moduleClass;
        $openid = $this->openid;
        $msgtype = $this->msgtype;
        $outArr = array(
            'type'      => '',
            'content'   => '',
        );
        
        $keyword = addslashes(dhtmlspecialchars($keyword));
        
        if($keyword == $tomConfig['exit_cmd']){
             $outArr = $this->exitActivity();
             return $outArr;
        }
        
        $isDoHookContent = false;
        $hookFilename = DISCUZ_ROOT.'./source/plugin/tom_weixin/hook/docmd.hook.php';
        if(file_exists($hookFilename)){
            include $hookFilename;
        }
        if($isDoHookContent){
            return $outArr;
        }
        
        $activityClass = new tom_activity($openid,$keyword);
        
        $exitMsg = "\n".str_replace('{exit}',$tomConfig['exit_cmd'],lang('plugin/tom_weixin','exit_msg'));
        $activityClass->delete_by_acttime();
        $tomActivity = $activityClass->getActivity();
        $tomActivityStatus = false;
        if($tomActivity){
            $tomActivityStatus = true;
            if($tomActivity['act_type'] == 1){
                $moduleInfo = $moduleClass->getOneByModuleCmd($tomActivity['act_cmd']);
                if($moduleInfo){
                    $moduleSetting = array();
                    if(!empty($moduleInfo['module_setting'])){
                        $moduleSetting = $moduleClass->decodeSetting($moduleInfo['module_setting']);
                    }
                    $moduleConfigName = $moduleClass->getConfigName($moduleInfo['module_id']);
                    if($moduleConfigName){
                        include $moduleConfigName;
                    }
                    $moduleFilename = $moduleClass->getWeixinName($moduleInfo['module_id']);
                    if($moduleFilename){
                        include $moduleFilename;
                    }
                }
            }
        }else{
            $moduleInfo = $moduleClass->getOneByModuleCmd($keyword);
            if($moduleInfo){
                $activityClass->setActtype(1);
                $moduleSetting = array();
                if(!empty($moduleInfo['module_setting'])){
                    $moduleSetting = $moduleClass->decodeSetting($moduleInfo['module_setting']);
                }
                $moduleConfigName = $moduleClass->getConfigName($moduleInfo['module_id']);
                if($moduleConfigName){
                    include $moduleConfigName;
                }
                $moduleFilename = $moduleClass->getWeixinName($moduleInfo['module_id']);
                if(file_exists($moduleFilename)){
                    include $moduleFilename;
                }
            }
        }
        $isDoHookContent = false;
        $hookFilenameEnd = DISCUZ_ROOT.'./source/plugin/tom_weixin/hook/doend.hook.php';
        if(file_exists($hookFilenameEnd)){
            include $hookFilenameEnd;
        }
        if(empty($outArr['type']) || empty($outArr['content'])){
            if(!empty($tomConfig['cmd_err_msg'])){
                $errorMsg = lang('plugin/tom_weixin','errorcmd');
                $outArr = array(
                    'type'      => 'text',
                    'content'   => $errorMsg.$tomConfig['cmd_err_msg'],
                );
            }else{
                echo 'success';exit;
            }
        }
        return $outArr;
    }
    
    public function exitActivity(){
        global $_G,$tomConfig;
        $outArr = array(
            'type'      => 'text',
            'content'   => lang('plugin/tom_weixin','exit_ok_msg'),
        );
        C::t('#tom_weixin#tom_weixin_activity')->delete($this->openid);
        return $outArr;
    }
    public function delActivity(){
        C::t('#tom_weixin#tom_weixin_activity')->delete($this->openid);
    }
    
}