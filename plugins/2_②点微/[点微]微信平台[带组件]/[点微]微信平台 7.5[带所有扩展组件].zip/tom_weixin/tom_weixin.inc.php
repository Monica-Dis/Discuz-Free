<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_WEIXINAPP')) {
    exit('Access Denied');
}

$tomConfig = $_G['cache']['plugin']['tom_weixin'];

define("TOM_SITEURL", $_G['siteurl']);
define("TOM_TOKEN", $tomConfig['wx_token']);
define("TOM_TOKEN_CHECK", $tomConfig['token_check']);
define("TOM_WX_APPID", $tomConfig['wx_appid']);
define("TOM_WX_APPSECRET", $tomConfig['wx_appsecret']);
define("TOM_ICOVN", 0);

include DISCUZ_ROOT.'./source/plugin/tom_weixin/core/tomwx.class.php';
include DISCUZ_ROOT.'./source/plugin/tom_weixin/core/weixin.class.php';
include DISCUZ_ROOT.'./source/plugin/tom_weixin/core/module.class.php';
include DISCUZ_ROOT.'./source/plugin/tom_weixin/core/activity.class.php';
include DISCUZ_ROOT.'./source/plugin/tom_weixin/function/common.php';
$weixinObj   = new weixinCallbackApi();
$moduleClass = new tom_module();
if (isset($_GET['echostr'])) {
    $weixinObj->check();
} else {
    $weixinObj->runCheck();
}