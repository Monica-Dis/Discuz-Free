<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$kanjiaNoStr = strtolower(trim($keyword));

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_kanjia/tom_kanjia.inc.php')){
    
    $kanjiaModuleInfo = $moduleClass->getOneByModuleId("kanjia");
    $kanjiaModuleSetting = $moduleClass->decodeSetting($kanjiaModuleInfo['module_setting']);
    $kanjiaModuleConfigName = $moduleClass->getConfigName($kanjiaModuleInfo['module_id']);
    if($kanjiaModuleConfigName){
        include $kanjiaModuleConfigName;
    }
    
    $userInfo = $kanjiaInfo = 0;
    $kanjiaConfig = $_G['cache']['plugin']['tom_kanjia'];
    
    $kjNoCheck = false;
    $uid = 0;
    if(strpos($kanjiaNoStr,"k") === 0){
        $kanjiaNo = ltrim($kanjiaNoStr, "k");
        if(is_numeric($kanjiaNo)){
            $userInfo = C::t('#tom_kanjia#tom_kanjia_user')->fetch_by_id($kanjiaNo);
            if($userInfo){
                $uid = $userInfo['id'];
                $kjNoCheck = true;
            }
        }
    }
    $kjCheck = false;
    $kid = 0;
    if($kjNoCheck){
        $kanjiaInfo = C::t('#tom_kanjia#tom_kanjia')->fetch_by_id($userInfo['kj_id']);
        if($kanjiaInfo && $kanjiaInfo['open_bianhao'] == 1){
            $kid = $kanjiaInfo['id'];
            $kjCheck = true;
        }
    }
    
    $kjGo = false;
    if($kjNoCheck){
        $isDoHookContent = true;
        $kjGo = true;
        $outArr = array(
                'type'      => 'text',
                'content'   => '',
            );
    }
    
    $subuser = C::t('#tom_weixin#tom_weixin_subuser')->fetch_by_openid($openid);
    if(!$subuser){
        $kjGo = false;
        $outArr['content'] = $moduleLang['first'].$kanjiaNoStr;
    }
    
    if($kjGo && TIMESTAMP < $kanjiaInfo['start_time']){
        $kjGo = false;
        $outArr['content'] = $moduleLang['nostart'].$kanjiaInfo['title'];
    }
    

    if($kjGo && TIMESTAMP > $kanjiaInfo['end_time']){
        $kjGo = false;
        $outArr['content'] = $moduleLang['over'].$kanjiaInfo['title'];
    }
    
    if($kjGo && $userInfo['status'] == 1){
        $kjGo = false;
        $outArr['content'] = $moduleLang['fenhao'];
    }
    
    if($kjGo && $userInfo['dh_status'] == 1){
        $kjGo = false;
        $outArr['content'] = $moduleLang['duihuan'];
    }
    
    if($kjGo && $userInfo['price'] <= $kanjiaInfo['base_price']){
        $kjGo = false;
        $outArr['content'] = $moduleLang['kanjia_100'];
    }
    
    if($kjGo){
        $logInfo = C::t('#tom_kanjia#tom_kanjia_log')->fetch_by_openid($kid,$uid,$openid);
        if($logInfo){
            $kjGo = false;
            $outArr['content'] = $moduleLang['kanjia_201'];
        }
    }
    
    if($kjGo){
        $userBangKanjiacount = C::t('#tom_kanjia#tom_kanjia_log')->fetch_all_count(" AND kj_id={$kid} AND openid='{$openid}' ");
        if($userBangKanjiacount >= $kanjiaConfig['bangkanjia_num']){
            $kjGo = false;
            $outArr['content'] = $moduleLang['kanjia_302'];
        }
    }
    
    if($kjGo && !empty($kanjiaInfo['goods_num'])){
        $userBasePricecount1 = C::t('#tom_kanjia#tom_kanjia_user')->fetch_all_count(" AND kj_id={$kid} AND price<={$kanjiaInfo['base_price']} AND status=0 ");
        $userBasePricecount2 = C::t('#tom_kanjia#tom_kanjia_user')->fetch_all_count(" AND kj_id={$kid} AND price>{$kanjiaInfo['base_price']} AND dh_status=1 ");
        $userBasePricecount = $userBasePricecount1 + $userBasePricecount2;
        if($userBasePricecount >= $kanjiaInfo['goods_num']){
            $kjGo = false;
            $outArr['content'] = $moduleLang['no_goods_num'].$kanjiaInfo['title'];
        }
    }
    
    if($kjGo){
        $priceListTmp = C::t('#tom_kanjia#tom_kanjia_price')->fetch_all_list(" AND kj_id={$kid} AND start_price<={$userInfo['price']} AND end_price>{$userInfo['price']} ","ORDER BY add_time DESC",0,1);
        $randPrice = 0.01;
        if($priceListTmp && $priceListTmp[0]){
            if($priceListTmp[0]['min_price'] == $priceListTmp[0]['max_price']){
                $randPrice = $priceListTmp[0]['min_price'];
            }else{
                $min_price = $priceListTmp[0]['min_price']*100;
                $max_price = $priceListTmp[0]['max_price']*100;
                $randPriceTmp = mt_rand($min_price,$max_price);
                $randPrice = $randPriceTmp/100;
            }
        }
        $kanjiaPrice = 0;
        $kanjiaJia = false;
        if($kanjiaInfo['kj_type'] == 1){
            $kanjiaPrice = $randPrice;
        }else if($kanjiaInfo['kj_type'] == 2){
            $randNum = mt_rand(1, 10);
            if($randNum > 5){
                $kanjiaPrice = $randPrice;
            }else{
                $kanjiaPrice = 0;
            }
        }else if($kanjiaInfo['kj_type'] == 3){
            $kanjiaPrice = $randPrice;
            $randNum = mt_rand(1, 10);
            if($randNum > 5){
                $kanjiaJia = true;
            }
        }

        $newPrice = 0;
        if($kanjiaJia){
            $newPrice = $userInfo['price'] + $kanjiaPrice;
        }else{
            if($userInfo['price'] > $kanjiaPrice){
                $newPrice = $userInfo['price'] - $kanjiaPrice;
            }else{
                $newPrice = 0;
            }
        }
        
        if($newPrice <= $kanjiaInfo['base_price']){
            $newPrice = $kanjiaInfo['base_price'];
            $kanjiaPrice = $userInfo['price'] - $kanjiaInfo['base_price'];
        }

        $updateData = array();
        $updateData['price'] = $newPrice;
        $updateData['kanjia_time'] = TIMESTAMP;
        C::t('#tom_kanjia#tom_kanjia_user')->update($uid,$updateData);
        
        $name = cutstr($openid,10,"");
        if(!empty($subuser['nickname'])){
            $name = $subuser['nickname'];
        }
        
        $insertData = array();
        $insertData['kj_id']        = $kid;
        $insertData['user_id']      = $uid;
        $insertData['name']         = $name;
        $insertData['openid']       = $openid;
        if($kanjiaJia){
            $insertData['price']        = "+".$kanjiaPrice;
        }else{
            $insertData['price']        = $kanjiaPrice;
        }
        $insertData['price_after']  = $newPrice;
        $insertData['ip']           = bindec(decbin(ip2long($_G['clientip'])));
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_kanjia#tom_kanjia_log')->insert($insertData);
        
        $url = $_G['siteurl']."plugin.php?id=tom_kanjia&mod=index&kid={$kid}&uid={$uid}";
        
        $kjGo = false;
        $moduleLang['success'] = str_replace("{NAME}", $userInfo['name'], $moduleLang['success']);
        $moduleLang['success'] = str_replace("{NO}", $uid, $moduleLang['success']);
        $moduleLang['success'] = str_replace("{PRICE}", $insertData['price'], $moduleLang['success']);
        $moduleLang['success'] = str_replace("{URL}", $url, $moduleLang['success']);
        $outArr['content'] = $moduleLang['success'];
    }
    
}

