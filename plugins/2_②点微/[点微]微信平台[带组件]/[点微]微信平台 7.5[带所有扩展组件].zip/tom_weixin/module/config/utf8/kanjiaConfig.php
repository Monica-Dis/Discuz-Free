<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$moduleConfig = array(
    'module_cmd'       => "kanjia",
    'module_desc'      => "砍价活动",
	'power_id'         => '0',
	'module_ver'       => '1.0',
    'is_menu'          => '2',
);

$moduleLang = array(
    'success'           => "【帮砍成功】\n编号：K{NO}\n选手：{NAME}\n砍掉价格：{PRICE} \n<a href='{URL}'>点击查看详情</a>",
    'nostart'           => "【活动未开始】",
    'over'              => "【活动已经结束】",
    'no_goods_num'      => "【砍价结束】商品已经被抢完了",
    'fenhao'            => "用户被封号",
    'duihuan'           => "用户已经兑换",
    'first'             => "感谢你参与砍价，系统正在获取你的昵称，请重新发送：",
    'kanjia_100'        => "已经最低价了",
    'kanjia_201'        => "已经帮砍过",
    'kanjia_302'        => "超过帮砍次数限制",
);

$moduleSettingExt = array(
);

?>