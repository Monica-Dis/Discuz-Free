<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
?>