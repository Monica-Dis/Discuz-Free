<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id  = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $guize              = isset($_GET['guize'])? addslashes($_GET['guize']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $stock_num          = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
    $goods_price        = isset($_GET['goods_price'])? floatval($_GET['goods_price']):0;
    $base_price         = isset($_GET['base_price'])? floatval($_GET['base_price']):0;
    $open_tiqian_pay    = isset($_GET['open_tiqian_pay'])? intval($_GET['open_tiqian_pay']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):1;
    $kanjia_num         = isset($_GET['kanjia_num'])? intval($_GET['kanjia_num']):0;
    $kanjia_min_price   = isset($_GET['kanjia_min_price'])? floatval($_GET['kanjia_min_price']):0;
    $kanjia_max_price   = isset($_GET['kanjia_max_price'])? floatval($_GET['kanjia_max_price']):0;
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? floatval($_GET['ding_price']):0;
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = str_replace("T", " ", $start_time);
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = str_replace("T", " ", $end_time);
    $end_time           = strtotime($end_time);
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = str_replace("T", " ", $hexiao_time);
    $hexiao_time        = strtotime($hexiao_time);
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    $mp3_link           = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $peisong_type       = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $open_yuyue         = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $yuyue_xm           = isset($_GET['yuyue_xm'])? addslashes($_GET['yuyue_xm']):'';
    $yuyue_tel          = isset($_GET['yuyue_tel'])? addslashes($_GET['yuyue_tel']):'';
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    if($type == 1){
        if($kanjia_num <= 0){
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($base_price < 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    if($goods_price <= 0){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    if($stock_num <= 0){
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $insertData = array();
    $insertData['site_id']          = $tcshopInfo['site_id'];
    $insertData['tcshop_id']        = $tcshop_id;
    $insertData['user_id']          = $user_id;
    $insertData['cate_id']          = $cate_id;
    $insertData['title']            = $title;
    $insertData['start_time']       = $start_time;
    $insertData['end_time']         = $end_time;
    $insertData['hexiao_time']      = $hexiao_time;
    $insertData['type']             = $type;
    $insertData['kanjia_num']       = $kanjia_num;
    $insertData['kanjia_min_price'] = $kanjia_min_price;
    $insertData['kanjia_max_price'] = $kanjia_max_price;
    $insertData['base_price']       = $base_price;
    $insertData['goods_price']      = $goods_price;
    $insertData['open_tiqian_pay']  = $open_tiqian_pay;
    $insertData['open_ding_pay']    = $open_ding_pay;
    $insertData['ding_price']       = $ding_price;
    $insertData['stock_num']        = $stock_num;
    $insertData['guize']            = $guize;
    $insertData['content']          = $content;
    $insertData['peisong_type']     = $peisong_type;
    $insertData['open_yuyue']       = $open_yuyue;
    $insertData['yuyue_xm']         = $yuyue_xm;
    $insertData['yuyue_tel']        = $yuyue_tel;
    $insertData['toppic']           = $toppic;
    $insertData['picurl']           = $picurl;
    $insertData['status']           = 1;
    if($tckjiaConfig['must_shenhe'] == 1){
        $insertData['shenhe_status']       = 2;
    }else{
        $insertData['shenhe_status']       = 1;
    }
    $insertData['add_time']          = TIMESTAMP;
    if(C::t('#tom_tckjia#tom_tckjia_goods')->insert($insertData)){
        
        $goods_id = C::t('#tom_tckjia#tom_tckjia_goods')->insert_id();
        $goodsInfoTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($goods_id);
        update_kanjia_status($goodsInfoTmp);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']  = $goods_id;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tckjia#tom_tckjia_goods_photo')->insert($insertData);
            }
        }
        
        $insertData = array();
        $insertData['is_admin']     = 0;
        $insertData['goods_id']     = $goods_id;
        $insertData['change_num']   = $stock_num;
        $insertData['change_time']  = TIMESTAMP;
        C::t('#tom_tckjia#tom_tckjia_stock_log')->insert($insertData);
        
        if($tckjiaConfig['must_shenhe'] == 1){
            $toUser = array();
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $toUser = $toUserTmp;
            }

            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();

            if($access_token && !empty($toUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl'].$__TckjiaApp."&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => '['.$tcshopInfo['name'].']'.lang('plugin/tom_tckjia','shenhe_template_first'),
                    'keyword1'      => $tongchengConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
            'goods_id'=> $goods_id,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}

$allTcshopCount = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count(" AND user_id={$__UserInfo['id']} ");

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$__UserInfo['id']} AND v.open_tckjia=1 "," ORDER BY s.id DESC ",0,100);
$tcshopList = array();
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach ($tcshopListTmp as $key => $value){
        $tcshopList[$key] = $value;
    }
}
$tcshopCount = count($tcshopList);

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);

$cateList = C::t('#tom_tckjia#tom_tckjia_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,10);

$uploadUrl = $__TckjiaApp."&site={$site_id}&mod=upload&act=toppic&formhash=".FORMHASH;
$uploadUrl1 = $__TckjiaApp."&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2 = $__TckjiaApp."&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;
$saveUrl = $__TckjiaApp."&site={$site_id}&mod=fabu&act=save";
$myListUrl = $__TckjiaApp."&site={$site_id}&mod=myfabu";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tckjia:fabu");