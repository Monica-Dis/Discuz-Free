<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($goods_id);
$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    dheader('location:'.$_G['siteurl'].$__TckjiaApp."&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $guize              = isset($_GET['guize'])? addslashes($_GET['guize']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $goods_price        = isset($_GET['goods_price'])? floatval($_GET['goods_price']):0;
    $base_price         = isset($_GET['base_price'])? floatval($_GET['base_price']):0;
    $open_tiqian_pay    = isset($_GET['open_tiqian_pay'])? intval($_GET['open_tiqian_pay']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):1;
    $kanjia_num         = isset($_GET['kanjia_num'])? intval($_GET['kanjia_num']):0;
    $kanjia_min_price   = isset($_GET['kanjia_min_price'])? floatval($_GET['kanjia_min_price']):0;
    $kanjia_max_price   = isset($_GET['kanjia_max_price'])? floatval($_GET['kanjia_max_price']):0;
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? addslashes($_GET['ding_price']):'';
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = str_replace("T", " ", $start_time);
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = str_replace("T", " ", $end_time);
    $end_time           = strtotime($end_time);
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = str_replace("T", " ", $hexiao_time);
    $hexiao_time        = strtotime($hexiao_time);
    $mp3_link           = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $peisong_type       = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $open_yuyue         = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $yuyue_xm           = isset($_GET['yuyue_xm'])? addslashes($_GET['yuyue_xm']):'';
    $yuyue_tel          = isset($_GET['yuyue_tel'])? addslashes($_GET['yuyue_tel']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    $share_title        = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc         = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $updateData = array();
    $updateData['cate_id']          = $cate_id;
    $updateData['title']            = $title;
    if($goodsInfo['admin_edit'] == 0){
        $updateData['guize']        = dhtmlspecialchars($guize);
        $updateData['content']      = dhtmlspecialchars($content);
    }
    $updateData['goods_price']      = $goods_price;
    $updateData['base_price']       = $base_price;
    $updateData['open_tiqian_pay']  = $open_tiqian_pay;
    $updateData['type']             = $type;
    $updateData['kanjia_num']       = $kanjia_num;
    $updateData['kanjia_min_price'] = $kanjia_min_price;
    $updateData['kanjia_max_price'] = $kanjia_max_price;
    $updateData['open_ding_pay']    = $open_ding_pay;
    $updateData['ding_price']       = $ding_price;
    $updateData['start_time']       = $start_time;
    $updateData['end_time']         = $end_time;
    $updateData['hexiao_time']      = $hexiao_time;
    $updateData['mp3_link']         = $mp3_link;
    $updateData['peisong_type']     = $peisong_type;
    $updateData['open_yuyue']       = $open_yuyue;
    $updateData['yuyue_xm']         = $yuyue_xm;
    $updateData['yuyue_tel']        = $yuyue_tel;
    $updateData['toppic']           = $toppic;
    $updateData['picurl']           = $picurl;
    $updateData['share_title']      = $share_title;
    $updateData['share_desc']       = $share_desc;
    $updateData['part1']            = TIMESTAMP;
    
    if(C::t('#tom_tckjia#tom_tckjia_goods')->update($goods_id,$updateData)){
        
        $goodsInfoTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($goods_id);
        update_kanjia_status($goodsInfoTmp);
        
        C::t('#tom_tckjia#tom_tckjia_goods_photo')->delete_by_goods_id($goods_id);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id'] = $goods_id;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tckjia#tom_tckjia_goods_photo')->insert($insertData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
            'goods_id'=> $goods_id,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

if(!preg_match('/^http/', $goodsInfo['toppic']) ){
    if(strpos($goodsInfo['toppic'], 'source/plugin/tom_tckjia/') === FALSE){
        $toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['toppic'];
    }else{
        $toppic = $goodsInfo['toppic'];
    }
}else{
    $toppic = $goodsInfo['toppic'];
}

if(!preg_match('/^http/', $goodsInfo['picurl']) ){
    if(strpos($goodsInfo['picurl'], 'source/plugin/tom_tckjia/') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['picurl'];
    }else{
        $picurl = $goodsInfo['picurl'];
    }
}else{
    $picurl = $goodsInfo['picurl'];
}

$goodsPhotoListTmp = C::t('#tom_tckjia#tom_tckjia_goods_photo')->fetcH_all_list(" AND goods_id = {$goods_id} ", 'ORDER BY add_time DESC,id DESC', 0, 20);
$goodsPhotoList = array();
$photoCount = 0;
if(is_array($goodsPhotoListTmp) && !empty($goodsPhotoListTmp[0])){
    foreach($goodsPhotoListTmp as $key => $value){
        $photoCount++;
        $goodsPhotoList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_tckjia/') === FALSE){
                $photo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $photo = $value['picurl'];
            }
        }else{
            $photo = $value['picurl'];
        }
        
        $goodsPhotoList[$key]['src'] = $photo;
        $goodsPhotoList[$key]['li_i'] = $photoCount;
    }
}


$start_time = dgmdate($goodsInfo['start_time'],'Y-m-d H:i:s',$tomSysOffset);
$start_time         = str_replace(" ", "T", $start_time);
$end_time = dgmdate($goodsInfo['end_time'],'Y-m-d H:i:s',$tomSysOffset);
$end_time         = str_replace(" ", "T", $end_time);
$hexiao_time = dgmdate($goodsInfo['hexiao_time'],'Y-m-d H:i:s',$tomSysOffset);
$hexiao_time         = str_replace(" ", "T", $hexiao_time);

$cateList = C::t('#tom_tckjia#tom_tckjia_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,10);

$uploadUrl = $__TckjiaApp."&site={$site_id}&mod=upload&act=toppic&formhash=".FORMHASH;
$uploadUrl1 = $__TckjiaApp."&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2 = $__TckjiaApp."&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;
$saveUrl = $__TckjiaApp."&site={$site_id}&mod=edit&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tckjia:edit");