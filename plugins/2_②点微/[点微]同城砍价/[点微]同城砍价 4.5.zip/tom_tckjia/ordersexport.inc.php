<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tckjia/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tckjia/config/config.utf8.php';
}

$tckjiaConfig = $_G['cache']['plugin']['tom_tckjia'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
$tomSysOffset = getglobal('setting/timeoffset');

$page           = isset($_GET['page'])? intval($_GET['page']):1;
$goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;

$pagesize = 5000;
$start = ($page-1)*$pagesize;

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $where = "";
    if(!empty($goods_id)){
        $where.=" AND goods_id={$goods_id} ";
    }
    
    $ordersListTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
    $orderList = array();
    foreach ($ordersListTmp as $key => $value) {
        $orderList[$key] = $value;
        
        $orderList[$key]['order_status'] = $orderStatusArray[$value['order_status']];
        if($value['peisong_type'] == 1){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tckjia','goods_peisong_type_1');
        }else if($value['peisong_type'] == 2){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tckjia','goods_peisong_type_2');
        }else if($value['peisong_type'] == 3){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tckjia','goods_peisong_type_3');
        }else{
            $orderList[$key]['peisong_type'] = '-';
        }
        
        $orderList[$key]['order_time'] = dgmdate($value['order_time'],"Y-m-d H:i:s",$tomSysOffset);
        if($value['pay_time'] > 0){
            $orderList[$key]['pay_time'] = dgmdate($value['pay_time'],"Y-m-d H:i:s",$tomSysOffset);
        }else{
            $orderList[$key]['pay_time'] = '-';
        }
        if($value['hexiao_time'] > 0){
            $orderList[$key]['hexiao_time'] = dgmdate($value['hexiao_time'],"Y-m-d H:i:s",$tomSysOffset);
        }else{
            $orderList[$key]['hexiao_time'] = '-';
        }
        
    }

    $order_no = lang('plugin/tom_tckjia','order_order_no');
    $goods_id = lang('plugin/tom_tckjia','order_goods_id');
    $goods_title = lang('plugin/tom_tckjia','order_goods_title');
    $user_xm = lang('plugin/tom_tckjia','order_user_xm');
    $user_tel = lang('plugin/tom_tckjia','order_user_tel');
    $user_order_beizu = lang('plugin/tom_tckjia','order_user_order_beizu');
    $user_address = lang('plugin/tom_tckjia','order_user_address');
    //$goods_num = lang('plugin/tom_tckjia','order_goods_num');
    $pay_price = lang('plugin/tom_tckjia','order_pay_price');
    $order_status = lang('plugin/tom_tckjia','order_order_status');
    $peisong_type = lang('plugin/tom_tckjia','goods_peisong_type');
    $order_time = lang('plugin/tom_tckjia','order_order_time');
    $pay_time = lang('plugin/tom_tckjia','order_pay_time');
    $hexiao_time = lang('plugin/tom_tckjia','order_hexiao_time');

    $listData[] = array(
        $order_no,
        $goods_id,
        $goods_title,
        $user_xm,
        $user_tel,
        $user_order_beizu,
        $user_address,
        //$goods_num,
        $pay_price,
        $order_status,
        $peisong_type,
        $order_time,
        $pay_time,
        $hexiao_time,
    ); 
    foreach ($orderList as $v){
        $lineData = array();
        $lineData[] = $v['order_no'];
        $lineData[] = $v['goods_id'];
        $lineData[] = $v['goods_title'];
        $lineData[] = $v['xm'];
        $lineData[] = "'".$v['tel'];
        $lineData[] = "'".$v['order_beizu'];
        $lineData[] = $v['address'];
        $v['address'] = str_replace("\r\n", "", $v['address']);
        $v['address'] = str_replace("\n", "", $v['address']);
        //$lineData[] = $v['goods_num'];
        $lineData[] = $v['pay_price'];
        $lineData[] = $v['order_status'];
        $lineData[] = $v['peisong_type'];
        $lineData[] = $v['order_time'];
        $lineData[] = $v['pay_time'];
        $lineData[] = $v['hexiao_time'];
        $listData[] = $lineData;
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=exportKjiaOrders.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}