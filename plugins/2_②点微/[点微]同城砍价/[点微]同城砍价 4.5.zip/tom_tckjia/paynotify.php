<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.cn
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tckjiaConfig = $_G['cache']['plugin']['tom_tckjia'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

$appid = trim($tongchengConfig['wxpay_appid']);  
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tckjia/class/function.core.php';

## tcchoujiang start
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')){
    $tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
    if($tcchoujiangConfig['open_tcchoujiang'] == 1){
        $__ShowTcchoujiang = 1;
    }
}
## tcchoujiang end

$orderInfo = C::t('#tom_tckjia#tom_tckjia_order')->fetch_by_order_no($order_no);
if($orderInfo && $orderInfo['order_status'] == 1){
    $updateData = array();
    $updateData['order_status'] = 2;
    $updateData['pay_time'] = TIMESTAMP;
    C::t('#tom_tckjia#tom_tckjia_order')->update($orderInfo['id'],$updateData);

    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($orderInfo['order_no'])));

    $goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($orderInfo['goods_id']);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 

    if($tckjiaConfig['open_back_score'] == 1){
        
        $score_yuan = $tongchengConfig['score_yuan'];
        if(!empty($tckjiaConfig['score_yuan'])){
            $score_yuan = $tckjiaConfig['score_yuan'];
        }
        
        $score = ceil($orderInfo['pay_price']*$score_yuan);
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] + $score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $orderInfo['user_id'];
        $insertData['score_value']      = $score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 12;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);

    }
    
    if($__ShowTcchoujiang == 1 && $goodsInfo['tcchoujiang_id'] > 0){
        $choujiangInfo    = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($goodsInfo['tcchoujiang_id']);
        if($choujiangInfo['status'] == 1 && $choujiangInfo['shenhe_status'] == 1 && $choujiangInfo['type'] == 3){
            $choujiangBmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($goodsInfo['tcchoujiang_id'],$userInfo['id']);
            if($choujiangBmInfo){
                DB::query("UPDATE ".DB::table('tom_tcchoujiang_bm')." SET cj_times=cj_times+1 WHERE id='".$choujiangBmInfo['id']."' ", 'UNBUFFERED');
            }else{
                $insertData = array();
                $insertData['tcchoujiang_id']          = $goodsInfo['tcchoujiang_id'];
                $insertData['user_id']                 = $userInfo['id'];
                $insertData['xm']                      = $userInfo['nickname'];
                $insertData['tel']                     = $userInfo['tel'];
                $insertData['cj_times']                = 1;
                $insertData['time_key']                = $nowDayTime;
                $insertData['add_time']                = TIMESTAMP;
                C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->insert($insertData);
            }
        }
    }

    if($tckjiaConfig['balance_type'] == 2 && $orderInfo['balance_status'] == 0){
        include DISCUZ_ROOT.'./source/plugin/tom_tckjia/module/balance.php';
    }
    
    if(!empty($tckjiaConfig['template_neworder'])){
        include DISCUZ_ROOT.'./source/plugin/tom_tckjia/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();

        $orderTcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);
        $orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderTcshopInfoTmp['user_id']); 

        if($access_token && !empty($orderUserInfoTmp['openid']) ){
            $tomSysOffset = getglobal('setting/timeoffset');
            $templateSmsClass = new kjTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=personal&act=shop");
            $smsData = array(
                'first'         => lang('plugin/tom_tckjia','template_neworder_first'),
                'keyword1'      => $orderInfo['goods_title'],
                'keyword2'      => $orderInfo['pay_price'],
                'keyword3'      => $orderInfo['xm'],
                'keyword4'      => $orderInfo['tel'],
                'keyword5'      => $orderInfo['order_no'],
                'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
            );
            $r = $templateSmsClass->sendSmsNewOrder($orderUserInfoTmp['openid'],$tckjiaConfig['template_neworder'],$smsData);
        }
    }

}