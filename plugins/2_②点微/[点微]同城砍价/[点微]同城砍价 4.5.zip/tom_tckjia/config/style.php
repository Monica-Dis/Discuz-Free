<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$styleArray = array(
    'baise' => array(
        'id'                => 'baise',
        'name'              => '��ɫ����',
        'bodyColor'         => '#fff',
        'titleWhite'        => 0,
        'topBoxBg'          => 'background: rgb(255, 249, 244);',
        'shopBox'           => 'border: 1px solid #d7d8d8;',
        'boxBg'             => 'background: rgba(255, 255, 255, 0.4);',
        'boxPadding'        => 'padding: 10px 0;',
        'fontColor'         => 'color: #484848;',
        'haibaoFontColor'   => 'color: #484848;',
    ),
    'lanse' => array(
        'id'                => 'lanse',
        'name'              => '��ɫ����',
        'bodyColor'         => '#00acf8',
        'titleWhite'        => 1,
        'topBoxBg'          => 'background: rgba(255, 255, 255, 0.8);',
        'shopBox'           => '',
        'boxBg'             => 'background: rgba(255, 255, 255, 0.3);',
        'boxPadding'        => 'padding: 10px;',
        'fontColor'         => 'color: #fff;',
        'haibaoFontColor'   => 'color: #fff;',
    ),
    'huangse' => array(
        'id'                => 'huangse',
        'name'              => '��ɫ����',
        'bodyColor'         => '#fce300',
        'titleWhite'        => 1,
        'topBoxBg'          => 'background: rgba(255, 255, 255, 0.8);',
        'shopBox'           => '',
        'boxBg'             => 'background: rgba(255, 255, 255, 0.4);',
        'boxPadding'        => 'padding: 10px;',
        'fontColor'         => 'color: #565656;',
        'haibaoFontColor'   => 'color: #565656;',
    ),
    'kafei' => array(
        'id'                => 'kafei',
        'name'              => '��������',
        'bodyColor'         => '#64381b',
        'titleWhite'        => 1,
        'topBoxBg'          => 'background: rgba(255, 255, 255, 0.8);',
        'shopBox'           => '',
        'boxBg'             => 'background: rgba(255, 255, 255, 0.1);',
        'boxPadding'        => 'padding: 10px;',
        'fontColor'         => 'color: #fff;',
        'haibaoFontColor'   => 'color: #fff;',
    ),
    'fenhuang' => array(
        'id'                => 'fenhuang',
        'name'              => '�ۻ�����',
        'bodyColor'         => '#FFF6D7',
        'titleWhite'        => 0,
        'topBoxBg'          => 'background: rgba(255, 255, 255, 0.8);',
        'shopBox'           => '',
        'boxBg'             => 'background: rgba(255, 255, 255, 0.5);',
        'boxPadding'        => 'padding: 10px;',
        'fontColor'         => 'color: #484848;',
        'haibaoFontColor'   => 'color: #484848;',
    ),
    'fenhong' => array(
        'id'                => 'fenhong',
        'name'              => '�ۺ�����',
        'bodyColor'         => '#ffd7d7',
        'titleWhite'        => 0,
        'topBoxBg'          => 'background: rgba(255, 255, 255, 0.8);',
        'shopBox'           => '',
        'boxBg'             => 'background: rgba(255, 255, 255, 0.5);',
        'boxPadding'        => 'padding: 10px;',
        'fontColor'         => 'color: #484848;',
        'haibaoFontColor'   => 'color: #484848;',
    ),
    'heise' => array(
        'id'                => 'heise',
        'name'              => '��ɫ����',
        'bodyColor'         => '#01081A',
        'titleWhite'        => 1,
        'topBoxBg'          => 'background: rgba(255, 255, 255, 0.8);',
        'shopBox'           => '',
        'boxBg'             => 'background: rgba(255, 255, 255, 0.1);',
        'boxPadding'        => 'padding: 10px;',
        'fontColor'         => 'color: #fff;',
        'haibaoFontColor'   => 'color: #fff;',
    ),
);

if (CHARSET == 'utf-8') {
    $styleArray = tom_style_iconv($styleArray,'gbk','utf-8');
}

function tom_style_iconv($data, $in_charset, $out_charset) {
    if(is_array($data)) {
        foreach($data AS $key => $val) {
            $data[$key] = tom_style_iconv($val, $in_charset, $out_charset);
        }
    } else {
        $data = diconv($data, $in_charset, $out_charset);
    }
    return $data;
}