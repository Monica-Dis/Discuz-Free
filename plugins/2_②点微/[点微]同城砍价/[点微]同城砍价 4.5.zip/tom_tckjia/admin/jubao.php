<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=jubao';
$modListUrl = $adminListUrl.'&tmod=jubao';
$modFromUrl = $adminFromUrl.'&tmod=jubao';

$get_list_url_value = get_list_url("tom_tckjia_admin_jubao_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tckjia#tom_tckjia_jubao')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else{
    
    set_list_url("tom_tckjia_admin_jubao_list");

    $goods_id           = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if($goods_id > 0){
        $where.= " AND goods_id={$goods_id} ";
    }
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;
    $jubaoList = C::t('#tom_tckjia#tom_tckjia_jubao')->fetch_all_list("{$where}"," ORDER BY id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&goods_id={$goods_id}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['tckjia_search_title'] . '</th></tr>';
    $statusStr = '<td width="100" align="right"><b>'.$Lang['jubao_goods_id'].'</b></td>';
    $statusStr.= '<td><input type="text" name="goods_id" value="'.$goods_id.'"></tr>';
    echo $statusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism_taobao_com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['jubao_user'] . '</th>';
    echo '<th>' . $Lang['jubao_activity'] . '</th>';
    echo '<th>' . $Lang['jubao_tel'] . '</th>';
    echo '<th>' . $Lang['jubao_type'] . '</th>';
    echo '<th>' . $Lang['jubao_content'] . '</th>';
    echo '<th>' . $Lang['jubao_time'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($jubaoList as $key => $value) {
        
        $jubaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($value['goods_id']);
        
        echo '<tr>';
        echo '<td> '.$value['id'].' </td>';
        echo '<td> '.$jubaoUserInfo['nickname'].'('.$value['user_id'].') </td>';
        echo '<td> '.$goodsInfo['title'].'('.$value['goods_id'].') </td>';
        echo '<td> '.$value['tel'].' </td>';
        echo '<td> '.$jubaoStatusArray[$value['type']].' </td>';
        echo '<td> '.$value['content'].' </td>';
        echo '<td> '.dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset).' </td>';
        echo '<td><a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a></td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    
    tomshownavli($Lang['jubao_list_title'],$modBaseUrl,true);
    
    tomshownavfooter();
}