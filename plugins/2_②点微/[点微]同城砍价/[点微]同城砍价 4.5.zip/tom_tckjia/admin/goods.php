<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=goods';
$modListUrl = $adminListUrl.'&tmod=goods';
$modFromUrl = $adminFromUrl.'&tmod=goods';

$get_list_url_value = get_list_url("tom_tckjia_admin_goods_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tckjia#tom_tckjia_goods')->insert($insertData);
        $goods_id = C::t('#tom_tckjia#tom_tckjia_goods')->insert_id();
        $goodsInfoTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($goods_id);
        update_kanjia_status($goodsInfoTmp);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
        
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism_taobao_com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($goodsInfo);
        C::t('#tom_tckjia#tom_tckjia_goods')->update($goodsInfo['id'],$updateData);
        
        $goodsInfoTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($goodsInfo['id']);
        update_kanjia_status($goodsInfoTmp);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($goodsInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism_taobao_com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe'){
    
    $shenhe_status     = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):1;
    
    $updateData = array();
    $updateData['shenhe_status']     = $shenhe_status;
    C::t('#tom_tckjia#tom_tckjia_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tckjia#tom_tckjia_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status']     = 2;
    C::t('#tom_tckjia#tom_tckjia_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $goods_id  = isset($_GET['id'])? intval($_GET['id']):0;
    $count = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND goods_id={$goods_id} ");
    if($count > 0){
        cpmsg($Lang['act_del_goods_error'], $modListUrl, 'error');
    }
    
    $countKj = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_count(" AND goods_id={$goods_id} ");
    if($countKj > 0){
        cpmsg($Lang['act_del_goods_error2'], $modListUrl, 'error');
    }
    
    C::t('#tom_tckjia#tom_tckjia_goods')->delete_by_id($_GET['id']);
    C::t('#tom_tckjia#tom_tckjia_goods_photo')->delete_by_goods_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editstock'){
    $info = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $stock_num     = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
        
        if($stock_num < $info['sale_num']){
            $stock_num = $info['sale_num'];
        }
        
        $updateData = array();
        $updateData['stock_num'] = $stock_num;
        C::t('#tom_tckjia#tom_tckjia_goods')->update($_GET['id'],$updateData);
        
        $goodsInfoTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($_GET['id']);
        update_kanjia_status($goodsInfoTmp);
        
        $insertData = array();
        $insertData['is_admin']     = 1;
        $insertData['goods_id']     = $_GET['id'];
        $insertData['change_num']   = $stock_num;
        $insertData['change_time']  = TIMESTAMP;
        C::t('#tom_tckjia#tom_tckjia_stock_log')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editstock&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_stock_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_stock_num'],'name'=>'stock_num','value'=>$info['stock_num'],'msg'=>$Lang['edit_stock_num_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism_taobao_com*/
        
        tomshownavheader();
        tomshownavli($Lang['stocklog_list_title'],"",true);
        tomshownavfooter();

        $stockyLogList = C::t('#tom_tckjia#tom_tckjia_stock_log')->fetch_all_list(" AND goods_id={$info['id']} "," ORDER BY id DESC ",0,500);
        showtableheader();
        echo '<tr class="header">';
        echo '<th>' . $Lang['stocklog_is_admin'] . '</th>';
        echo '<th>' . $Lang['stocklog_change_num'] . '</th>';
        echo '<th>' . $Lang['stocklog_change_time'] . '</th>';
        echo '</tr>';

        $i = 1;
        foreach ($stockyLogList as $key => $value) {
            echo '<tr>';
            if($value['is_admin'] == 1){
                echo '<td>' . $Lang['stocklog_is_admin_1'] . '</td>';
            }else{
                echo '<td>' . $Lang['stocklog_is_admin_0'] . '</td>';
            }
            echo '<td>' . $value['change_num'] . '</td>';
            echo '<td>' . dgmdate($value['change_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
            echo '</tr>';
            $i++;
        }
        showtablefooter();/*Dism��taobao��com*/
    }
}else if($_GET['act'] == 'photo'){
    
    $goods_id = $_GET['goods_id'];
    
    if(submitcheck('submit')){
        
        if($_FILES["picurl"]['tmp_name']) {
            $upload = new tom_upload();
            if(!$upload->init($_FILES["picurl"], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }

            $picurl = $upload->attach['attachment'];
        }else{
            $picurl = addslashes($_GET["picurl"]);
        }
        
        $insertData = array();
        $insertData['goods_id']     = $goods_id;
        $insertData['picurl']       = $picurl;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tckjia#tom_tckjia_goods_photo')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl."&act=photo&goods_id=".$_GET['goods_id'], 'succeed');
    }
    
    $goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($_GET['goods_id']);
    
    $photoList = C::t('#tom_tckjia#tom_tckjia_goods_photo')->fetch_all_list(" AND goods_id={$goods_id} ","ORDER BY id ASC",0,100);
    __create_nav_html();
    showformheader($modFromUrl.'&act=photo&goods_id='.$goods_id,'enctype');
    showtableheader();
    tomshowsetting(true,array('title'=>$Lang['goods_photo_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['goods_photo_picurl_msg']),"file");
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism_taobao_com*/
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['goods_photo_picurl'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($photoList as $key => $value) {
        echo '<tr>';
        echo '<td><img src="' . tomgetfileurl($value['picurl']) . '" width="60" /></td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&goods_id='.$goods_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tckjia#tom_tckjia_goods_photo')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl."&act=photo&goods_id=".$_GET['goods_id'], 'succeed');
    
}else{
    
    set_list_url("tom_tckjia_admin_goods_list");
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ list-style-type: none; height: 25px; line-height: 25px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;padding: 3px 10px;color: #6a6d6a; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
</style>
EOF;
    echo $csstr;
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $goods_title        = isset($_GET['goods_title'])? addslashes($_GET['goods_title']):'';
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($status)){
        $where.= " AND status={$status} ";
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count     = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_like_count($where,$goods_title);
    $goodsList = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_like_list("{$where}"," ORDER BY id DESC ",$start,$pagesize,$goods_title);

    showtableheader();
    $Lang['tckjia_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tckjia_help_3']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['tckjia_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['tckjia_help_1'] . '</li>';
    echo '<li><a target="_blank" href="http://www.tomwx.cn/index.php?m=help&t=plugin&pluginid=tom_tckjia&faqid=175"><font color="#0894fb">' . $Lang['tckjia_help_2'] . '</font></a></li>';
    echo '<li>' . $Lang['tckjia_help_3'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();/*Dism��taobao��com*/

    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&type_id={$type_id}&status={$status}&shenhe_status={$shenhe_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['tckjia_search_title'] . '</th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    echo '<tr><td width="100" align="right"><b>' . $Lang['goods_title'] . '</b></td><td><input name="goods_title" type="text" value="'.$goods_title.'" style="width: 260px;" /></td></tr>';
    
    $statusStr = '<td width="100" align="right"><b>'.$Lang['goods_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['goods_status'].'</option>';
    $statusStr.=  '<option value="1">'.$Lang['goods_status_1'].'</option>';
    $statusStr.=  '<option value="2">'.$Lang['goods_status_2'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['goods_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1">'.$Lang['goods_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2">'.$Lang['goods_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3">'.$Lang['goods_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism_taobao_com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 60px;">' . $Lang['sites_title'] . '</th>';
    echo '<th style="width: 60px;">' . $Lang['goods_picurl'] . '</th>';
    echo '<th style="width: 180px;">' . $Lang['goods_info'] . '</th>';
    echo '<th style="width: 150px;">' . $Lang['shop_info'] . '</th>';
    echo '<th>' . $Lang['goods_stock_num'] . '</th>';
    echo '<th>' . $Lang['goods_sale_num'] . '</th>';
    echo '<th>' . $Lang['goods_price'] . '</th>';
    echo '<th>' . $Lang['goods_status2'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($goodsList as $key => $value) {
        
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $tcshopUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfoTmp['user_id']); 

        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $cateInfo = C::t('#tom_tckjia#tom_tckjia_cate')->fetch_by_id($value['cate_id']);
        echo '<tr style="border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #70b4e6;">';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td><img src="'.tomgetfileurl($value['picurl']).'" width="40" /></td>';
        
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['goods_cate_id'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $cateInfo['name'] . '</font></li>';
        echo '<li><b>'.$Lang['order_goods_id'].'&nbsp;:&nbsp;</b>' . $value['id'] . '</li>';
        echo '<li><b>'.$Lang['goods_title'].'&nbsp;:&nbsp;</b>' . $value['title'] . '</li>';
        echo '</ul></div></td>';
        
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['goods_tcshop_id'].'&nbsp;:&nbsp;</b>' . $tcshopInfoTmp['id'] . '</li>';
        echo '<li><b>'.$Lang['goods_tcshop_name'].'&nbsp;:&nbsp;</b>' . $tcshopInfoTmp['name'] . '</li>';
        echo '<li><b>'.$Lang['goods_tcshop_balance_user_id'].'&nbsp;:&nbsp;</b>' . $tcshopUserInfo['id'] . '</li>';
        echo '<li><b>'.$Lang['goods_tcshop_balance_nickname'].'&nbsp;:&nbsp;</b>' . $tcshopUserInfo['nickname'] . '</li>';
        echo '</ul></div></td>';
        
        echo '<td><font color="#fd0d0d">' . $value['stock_num'] . '</font></td>';
        echo '<td><font color="#238206">' . $value['sale_num'] . '</font></td>';
        
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li>'.$Lang['goods_goods_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['goods_price']. '</font></li>';
        echo '<li>'.$Lang['goods_base_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['base_price']. '</font></li>';
        if($value['open_ding_pay'] == 1){
            echo '<li>'.$Lang['goods_ding_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['ding_price']. '</font></li>';
        }
        echo '</ul></div></td>';
        
        echo '<td><div class="tc_content_box"><ul>';
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe&id='.$value['id'].'&shenhe_status=1&formhash='.FORMHASH.'">' . $Lang['goods_shenhe_btn_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe&id='.$value['id'].'&shenhe_status=3&formhash='.FORMHASH.'">' . $Lang['goods_shenhe_btn_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<li><b>'.$Lang['goods_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['goods_shenhe_status_1'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 2){
            echo '<li><b>'.$Lang['goods_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['goods_shenhe_status_2'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 3){
            echo '<li><b>'.$Lang['goods_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['goods_shenhe_status_3'] . '</font>'.$sheheBtnStr.'</li>';
        }
        if($value['status'] == 1 ){
            echo '<li><b>'.$Lang['goods_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['goods_status_1'] . '</font></li>';
        }else{
            echo '<li><b>'.$Lang['goods_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['goods_status_2'] . '</font></li>';
        }

        echo '<li><b>'.$Lang['goods_start_time'].'&nbsp;:&nbsp;</b>' . dgmdate($value['start_time'],"Y-m-d H:i",$tomSysOffset) . '</li>';
        echo '<li><b>'.$Lang['goods_end_time'].'&nbsp;:&nbsp;</b>' . dgmdate($value['end_time'],"Y-m-d H:i",$tomSysOffset) . '</li>';
        echo '<li><b>'.$Lang['goods_hexiao_time'].'&nbsp;:&nbsp;</b>' . dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset) . '</li>';
        echo '</ul></div></td>';
        
        echo '<td><div class="tc_content_box_handle"><ul>';
        if($value['status'] == 1 ){
            echo '<li><a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_status_2']. '</a></li>';
        }else{
            echo '<li><a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_status_1']. '</a></li>';
        }
        echo '<li><a href="'.$modBaseUrl.'&act=editstock&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_stock_title']. '</a></li>';
        echo '<li><a href="'.$modBaseUrl.'&act=photo&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_photo']. '</a></li>';
        echo '<li><a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_edit']. '</a></li>';
        echo '<li><a href="'.$adminBaseUrl.'&tmod=kanjia&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_kanjia']. '</a></li>';
        echo '<li><a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a></li>';
        echo '</ul></div></td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $style_id           = isset($_GET['style_id'])? addslashes($_GET['style_id']):'baise';
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $yongjin_bili       = isset($_GET['yongjin_bili'])? intval($_GET['yongjin_bili']):0;
    $tcchoujiang_id     = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):0;
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = strtotime($end_time);
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = strtotime($hexiao_time);
    $type               = isset($_GET['type'])? intval($_GET['type']):1;
    $kanjia_num         = isset($_GET['kanjia_num'])? intval($_GET['kanjia_num']):0;
    $kanjia_min_price   = isset($_GET['kanjia_min_price'])? floatval($_GET['kanjia_min_price']):0;
    $kanjia_max_price   = isset($_GET['kanjia_max_price'])? floatval($_GET['kanjia_max_price']):0;
    $goods_price        = isset($_GET['goods_price'])? floatval($_GET['goods_price']):0.00;
    $base_price         = isset($_GET['base_price'])? floatval($_GET['base_price']):0.00;
    $open_tiqian_pay    = isset($_GET['open_tiqian_pay'])? intval($_GET['open_tiqian_pay']):0;
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? addslashes($_GET['ding_price']):'';
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $peisong_type       = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $open_yuyue         = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $yuyue_xm           = isset($_GET['yuyue_xm'])? addslashes($_GET['yuyue_xm']):'';
    $yuyue_tel          = isset($_GET['yuyue_tel'])? addslashes($_GET['yuyue_tel']):'';
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $guize              = isset($_GET['guize'])? addslashes($_GET['guize']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $virtual_clicks     = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $virtual_user       = isset($_GET['virtual_user'])? intval($_GET['virtual_user']):0;
    //$virtual_shares     = isset($_GET['virtual_shares'])? intval($_GET['virtual_shares']):0;
    
    $mp3_link           = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $share_title        = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc         = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $paixu              = isset($_GET['paixu'])? intval($_GET['paixu']):1000;

    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $picurl = $toppic = $share_logo = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
        $toppic        = tomuploadFile("toppic");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
        $toppic        = tomuploadFile("toppic",$infoArr['toppic']);
    }
    
    $data['site_id']            = $site_id;
    $data['user_id']            = $tcshopInfo['user_id'];
    $data['tcshop_id']          = $tcshopInfo['id'];
    $data['style_id']           = $style_id;
    $data['cate_id']            = $cate_id;
    $data['title']              = $title;
    $data['yongjin_bili']       = $yongjin_bili;
    $data['tcchoujiang_id']     = $tcchoujiang_id;
    $data['picurl']             = $picurl;
    $data['toppic']             = $toppic;
    $data['start_time']         = $start_time;
    $data['end_time']           = $end_time;
    $data['hexiao_time']        = $hexiao_time;
    $data['hexiao_pwd']         = $hexiao_pwd;
    $data['type']               = $type;
    $data['kanjia_num']         = $kanjia_num;
    $data['kanjia_min_price']   = $kanjia_min_price;
    $data['kanjia_max_price']   = $kanjia_max_price;
    $data['goods_price']        = $goods_price;
    $data['base_price']         = $base_price;
    $data['open_tiqian_pay']    = $open_tiqian_pay;
    $data['open_ding_pay']      = $open_ding_pay;
    $data['ding_price']         = $ding_price;
    $data['peisong_type']       = $peisong_type;
    //$data['open_yuyue']         = $open_yuyue;
    //$data['yuyue_xm']           = $yuyue_xm;
    //$data['yuyue_tel']          = $yuyue_tel;
    $data['admin_edit']         = $admin_edit;
    $data['guize']              = $guize; 
    $data['content']            = $content;
    $data['virtual_clicks']     = $virtual_clicks;
    $data['virtual_user']       = $virtual_user;
    //$data['virtual_shares']     = $virtual_shares;
    $data['mp3_link']           = $mp3_link;
    $data['share_title']        = $share_title;
    $data['share_desc']         = $share_desc;
    $data['shenhe_status']      = 1;
    $data['paixu']              = $paixu;
    $data['add_time']           = TIMESTAMP;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$styleArray;
    $options = array(
        'site_id'           => 1,
        'tcshop_id'         => 0,
        'style_id'          => 'baise',
        'cate_id'           => 0,
        'title'             => '',
        'yongjin_bili'      => 0,
        'tcchoujiang_id'    => 0,
        'picurl'            => '',
        'toppic'            => '',
        'start_time'        => time(),
        'end_time'          => time(),
        'hexiao_time'       => time(),
        'type'              => 1,
        'kanjia_num'        => 0,
        'kanjia_min_price'  => 0.00,
        'kanjia_max_price'  => 0.00,
        'goods_price'       => 0.00,
        'base_price'        => 0.00,
        'open_tiqian_pay'   => 0,
        'open_ding_pay'     => 0,
        'ding_price'        => 0.00,
        'hexiao_pwd'        => '',
        'peisong_type'      => 1,
        'open_yuyue'        => 0,
        'yuyue_xm'          => '',
        'yuyue_tel'         => '',
        'admin_edit'        => '0',
        'guize'             => '',
        'content'           => '',
        'virtual_clicks'    => '',
        'virtual_user'      => '',
        'virtual_shares'    => '',
        'mp3_link'          => '',
        'share_title'       => '',
        'share_desc'        => '',
        'paixu'             => 1000,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['goods_site_id'],'name'=>'site_id','value'=>$options['site_id'],'msg'=>$Lang['goods_site_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['goods_tcshop_id_msg2']),"input");
    
    $styleStr = '<tr class="header"><th>'.$Lang['goods_style_id'].'</th><th></th></tr>';
    $styleStr.= '<tr><td width="300"><select style="width: 260px;" name="style_id" id="style_id">';
    foreach ($styleArray as $key => $value){
        if($value['id'] == $options['style_id']){
            $styleStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $styleStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $styleStr.= '</select></td><td></td></tr>';
    echo $styleStr;
    
    $cateList = C::t('#tom_tckjia#tom_tckjia_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,100);
    $cateStr = '<tr class="header"><th>'.$Lang['goods_cate_id'].'</th><th></th></tr>';
    $cateStr.= '<tr><td width="300"><select style="width: 260px;" name="cate_id" id="cate_id">';
    foreach ($cateList as $key => $value){
        if($value['id'] == $options['cate_id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select></td><td></td></tr>';
    echo $cateStr;
    
    tomshowsetting(true,array('title'=>$Lang['goods_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['goods_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_yongjin_bili'],'name'=>'yongjin_bili','value'=>$options['yongjin_bili'],'msg'=>$Lang['goods_yongjin_bili_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_tcchoujiang_id'],'name'=>'tcchoujiang_id','value'=>$options['tcchoujiang_id'],'msg'=>$Lang['goods_tcchoujiang_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['goods_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['goods_toppic'],'name'=>'toppic','value'=>$options['toppic'],'msg'=>$Lang['goods_toppic_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['goods_start_time'],'name'=>'start_time','value'=>$options['start_time'],'msg'=>$Lang['goods_start_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['goods_end_time'],'name'=>'end_time','value'=>$options['end_time'],'msg'=>$Lang['goods_end_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['goods_hexiao_time'],'name'=>'hexiao_time','value'=>$options['hexiao_time'],'msg'=>$Lang['goods_hexiao_time_msg']),"calendar");
    
    tomshowsetting(true,array('title'=>$Lang['goods_goods_price'],'name'=>'goods_price','value'=>$options['goods_price'],'msg'=>$Lang['goods_goods_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_base_price'],'name'=>'base_price','value'=>$options['base_price'],'msg'=>$Lang['goods_base_price_msg']),"input");
    $open_tiqian_pay_item = array(0=>$Lang['close'],1=>$Lang['open']);
    tomshowsetting(true,array('title'=>$Lang['goods_open_tiqian_pay'],'name'=>'open_tiqian_pay','value'=>$options['open_tiqian_pay'],'msg'=>$Lang['goods_open_tiqian_pay_msg'],'item'=>$open_tiqian_pay_item),"radio");
    $open_ding_pay_item = array(0=>$Lang['goods_open_ding_pay_0'],1=>$Lang['goods_open_ding_pay_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_open_ding_pay'],'name'=>'open_ding_pay','value'=>$options['open_ding_pay'],'msg'=>$Lang['goods_open_ding_pay_msg'],'item'=>$open_ding_pay_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_ding_price'],'name'=>'ding_price','value'=>$options['ding_price'],'msg'=>$Lang['goods_ding_price_msg']),"input");
    
    $goods_type_item = array(1=>$Lang['goods_type_1'],2=>$Lang['goods_type_2']);
    tomshowsetting(true,array('title'=>$Lang['goods_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['goods_type_msg'],'item'=>$goods_type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_kanjia_num'],'name'=>'kanjia_num','value'=>$options['kanjia_num'],'msg'=>$Lang['goods_kanjia_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_kanjia_min_price'],'name'=>'kanjia_min_price','value'=>$options['kanjia_min_price'],'msg'=>$Lang['goods_kanjia_min_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_kanjia_max_price'],'name'=>'kanjia_max_price','value'=>$options['kanjia_max_price'],'msg'=>$Lang['goods_kanjia_max_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_hexiao_pwd'],'name'=>'hexiao_pwd','value'=>$options['hexiao_pwd'],'msg'=>$Lang['goods_hexiao_pwd_msg']),"input");
    
    $peisong_type_item = array(1=>$Lang['goods_peisong_type_1'],2=>$Lang['goods_peisong_type_2'],3=>$Lang['goods_peisong_type_3']);
    tomshowsetting(true,array('title'=>$Lang['goods_peisong_type'],'name'=>'peisong_type','value'=>$options['peisong_type'],'msg'=>$Lang['goods_peisong_type_msg'],'item'=>$peisong_type_item),"radio");
    $open_yuyue_item = array(0=>$Lang['goods_open_yuyue_0'],1=>$Lang['goods_open_yuyue_1']);
    //tomshowsetting(true,array('title'=>$Lang['goods_open_yuyue'],'name'=>'open_yuyue','value'=>$options['open_yuyue'],'msg'=>$Lang['goods_open_yuyue_msg'],'item'=>$open_yuyue_item),"radio");
    //tomshowsetting(true,array('title'=>$Lang['goods_yuyue_xm'],'name'=>'yuyue_xm','value'=>$options['yuyue_xm'],'msg'=>$Lang['goods_yuyue_xm_msg']),"input");
    //tomshowsetting(true,array('title'=>$Lang['goods_yuyue_tel'],'name'=>'yuyue_tel','value'=>$options['yuyue_tel'],'msg'=>$Lang['goods_yuyue_tel_msg']),"input");
    
    tomshowsetting(true,array('title'=>$Lang['goods_virtual_clicks'],'name'=>'virtual_clicks','value'=>$options['virtual_clicks'],'msg'=>$Lang['goods_virtual_clicks_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_virtual_user'],'name'=>'virtual_user','value'=>$options['virtual_user'],'msg'=>$Lang['goods_virtual_user_msg']),"input");
    //tomshowsetting(true,array('title'=>$Lang['goods_virtual_shares'],'name'=>'virtual_shares','value'=>$options['virtual_shares'],'msg'=>$Lang['goods_virtual_shares_msg']),"input");
    
    tomshowsetting(true,array('title'=>$Lang['goods_mp3_link'],'name'=>'mp3_link','value'=>$options['mp3_link'],'msg'=>$Lang['goods_mp3_link_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_share_title'],'name'=>'share_title','value'=>$options['share_title'],'msg'=>$Lang['goods_share_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_share_desc'],'name'=>'share_desc','value'=>$options['share_desc'],'msg'=>$Lang['goods_share_desc_msg']),"input");
    
    tomshowsetting(true,array('title'=>$Lang['goods_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['goods_paixu_msg']),"input");
    
    $admin_edit_item = array(0=>$Lang['goods_admin_edit_0'],1=>$Lang['goods_admin_edit_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_admin_edit'],'name'=>'admin_edit','value'=>$options['admin_edit'],'msg'=>$Lang['goods_admin_edit_msg'],'item'=>$admin_edit_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_guize'],'name'=>'guize','value'=>$options['guize'],'msg'=>$Lang['goods_guize_msg']),"text");
    tomshowsetting(true,array('title'=>$Lang['goods_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['goods_content_msg']),"text");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['goods_edit'],"",true);
    }else if($_GET['act'] == 'photo'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_photo'],"",true);
    }else{
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}