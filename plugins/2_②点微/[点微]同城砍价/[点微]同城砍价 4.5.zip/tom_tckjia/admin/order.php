<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=order';
$modListUrl = $adminListUrl.'&tmod=order';
$modFromUrl = $adminFromUrl.'&tmod=order';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

$get_list_url_value = get_list_url("tom_tckjia_admin_orders_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($formhash == FORMHASH && $act == 'info'){
    
    $info = C::t('#tom_tckjia#tom_tckjia_order')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $order_status = intval($_GET['order_status']);
        $updateData = array();
        $updateData['order_status'] = $order_status;
        $updateData['admin_edit']   = 1;
        C::t('#tom_tckjia#tom_tckjia_order')->update($_GET['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        showformheader($modFromUrl.'&act=info&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_order_order_status'] . '</th></tr>';
        showtablefooter();/*Dism��taobao��com*/
        showtableheader();
        echo '<tr><td align="right"><b>'.$Lang['order_order_status'].'</b></td><td>';
        foreach ($orderStatusArray as $key => $value){
            if($key == $info['order_status']){
                echo '<input type="radio" name="order_status" value="'.$key.'" checked><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }else{
                echo '<input type="radio" name="order_status" value="'.$key.'" ><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }
        }
        echo '</td></tr>';
        echo '<tr><td>&nbsp;</td><td colspan="14" ><b><font color="#fd0303">(' . $Lang['order_order_status_msg'] . ')</font></b></td></tr>';
        tomshowsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism_taobao_com*/
    }
    
}else{
    
    set_list_url("tom_tckjia_admin_orders_list");
    
    $id  = isset($_GET['id'])? intval($_GET['id']):0;
    $site_id  = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $goods_id  = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $tel = !empty($_GET['tel'])? trim(addslashes($_GET['tel'])):'';
    $order_status  = isset($_GET['order_status'])? intval($_GET['order_status']):0;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($id)){
        $where.= " AND id='{$id}' ";
    }
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($goods_id)){
        $where.= " AND goods_id={$goods_id} ";
    }
    if(!empty($tel)){
        $where.= " AND tel='{$tel}' ";
    }
    if(!empty($order_status)){
        $where.= " AND order_status={$order_status} ";
    }
    $pagesize = 15;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count($where);
    $orderList = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&goods_id={$goods_id}&order_status={$order_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_goods_id'] . '</b></td><td><input name="goods_id" type="text" value="'.$goods_id.'" size="40" /><font color="#fd0d0d">' . $Lang['order_goods_id_msg'] . '</font></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_user_tel'] . '</b></td><td><input name="tel" type="text" value="'.$tel.'" size="40" /></td></tr>';
    $orderStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['order_order_status'].'</b></td>';
    $orderStatusStr.= '<td><select style="width: 260px;" name="order_status" id="order_status">';
    $orderStatusStr.=  '<option value="0">'.$Lang['order_order_status'].'</option>';
    foreach ($orderStatusArray as $key => $value){
        $orderStatusStr.=  '<option value="'.$key.'">'.$value.'</option>';
    }
    $orderStatusStr.= '</select></td></tr>';
    echo $orderStatusStr;
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism_taobao_com*/
    
    if($goods_id > 0){
        $countOrderStatus1 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=1 ");
        $countOrderStatus2 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=2 ");
        $countOrderStatus3 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=3 ");
        $countOrderStatus4 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=4 ");
        $countOrderStatus5 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=5 ");
        echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
        echo $orderStatusArray[1].'<font color="#fd0d0d">('.$countOrderStatus1.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[2].'<font color="#fd0d0d">('.$countOrderStatus2.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[3].'<font color="#fd0d0d">('.$countOrderStatus3.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[4].'<font color="#fd0d0d">('.$countOrderStatus4.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[5].'<font color="#fd0d0d">('.$countOrderStatus5.')</font>&nbsp;&nbsp;';
        echo '</div>';
        tomshownavheader();
        tomshownavli($Lang['order_export'],$_G['siteurl']."plugin.php?id=tom_tckjia:ordersexport&goods_id={$goods_id}",false);
        if($count > 5000){
            tomshownavli($Lang['order_export'].'(page:2)',$_G['siteurl']."plugin.php?id=tom_tckjia:ordersexport&goods_id={$goods_id}&page=2",false);
        }
        if($count > 10000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tckjia:ordersexport&goods_id={$goods_id}&page=3",false);
        }
        if($count > 15000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tckjia:ordersexport&goods_id={$goods_id}&page=4",false);
        }
        if($count > 20000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tckjia:ordersexport&goods_id={$goods_id}&page=5",false);
        }
        if($count > 25000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tckjia:ordersexport&goods_id={$goods_id}&page=6",false);
        }
        tomshownavfooter();
    }
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['order_order_no'] . '</th>';
    echo '<th>' . $Lang['order_goods_title'] . '</th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['order_user_picurl'] .'</th>';
    echo '<th>' . $Lang['order_pay_price'] . '</th>';
    echo '<th>' . $Lang['order_order_status'] . '</th>';
    echo '<th>' . $Lang['order_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($orderList as $key => $value){
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        
        echo '<tr>';
        echo '<td>'.$value['order_no'].'</td>';
        echo '<td>'.$value['goods_title'].'(ID:'.$value['goods_id'].')</td>';
        if($value['site_id'] > 1){
            echo '<td><font color="#0894fb"><b>' . $siteInfoTmp['name'] . '</b></font></td>';
        }else{
            echo '<td><font color="#0894fb"><b>' . $Lang['sites_one'] . '</b></font></td>';
        }
        echo '<td style="line-height: 20px;">';
        echo '<b>'.$Lang['order_user_picurl'].' : </b><img src="'.$userInfo['picurl'].'" width="40" /><br/>';
        echo '<b>'.$Lang['order_user_nickname'].' : </b>'.$userInfo['nickname'].'<br/>';
        echo '<b>'.$Lang['order_user_xm'].' : </b>'.$value['xm'].'<br/>';
        echo '<b>'.$Lang['order_user_tel'].' : </b>'.$value['tel'].'<br/>';
        echo '<b>'.$Lang['order_user_order_beizu'].' : </b>'.$value['order_beizu'].'<br/>';
        echo '<b>'.$Lang['order_user_address'].' : </b>'.$value['address'].'<br/>';
        echo '</td>';
        echo '<td><font color="#0a9409">'.$value['pay_price'].'</font></td>';
        echo '<td style="line-height: 20px;">';
        echo '<b><font color="'.$orderStatusColorArray[$value['order_status']].'">' . $orderStatusArray[$value['order_status']] . '</font></b><br/>';
        if($value['peisong_type'] == 1){
            echo '<font color="#0894fb">('.$Lang['goods_peisong_type_1'].')</font>';
        }else if($value['peisong_type'] == 2){
            echo '<font color="#0894fb">('.$Lang['goods_peisong_type_2'].')</font>';
        }else if($value['peisong_type'] == 3){
            echo '<font color="#0894fb">('.$Lang['goods_peisong_type_3'].')</font>';
        }
        if($value['admin_edit'] == 1){
            echo '<br/><font color="#f00">('.$Lang['orders_admin_edit_1'].')</font>';
        }
        echo '</td>';
        echo '<td>';
        if($value['order_time'] > 0){
            echo $Lang['order_order_time'].dgmdate($value['order_time'],"Y-m-d H:i",$tomSysOffset).'<br/>';
        }else{
            echo $Lang['order_order_time'].'-<br/>';
        }
        if($value['pay_time'] > 0){
            echo $Lang['order_pay_time'].dgmdate($value['pay_time'],"Y-m-d H:i",$tomSysOffset).'<br/>';
        }else{
            echo $Lang['order_pay_time'].'-<br/>';
        }
        if($value['hexiao_time'] > 0){
            echo $Lang['order_hexiao_time'].dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset).'<br/>';
        }else{
            echo $Lang['order_hexiao_time'].'-<br/>';
        }
        if($value['hexiao_time'] > 0){
            echo '<br/><font color="#fd0d0d">('.$hexiaoUserInfo['nickname'].' ID:'.$hexiaoUserInfo['id'].')</font><br/>';
        }
        echo '</td>';
        echo '<td style="line-height: 22px;">';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_order_order_status'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
}