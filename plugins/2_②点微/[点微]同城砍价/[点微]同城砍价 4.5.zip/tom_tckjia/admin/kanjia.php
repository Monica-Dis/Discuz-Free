<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=kanjia';
$modListUrl = $adminListUrl.'&tmod=kanjia';
$modFromUrl = $adminFromUrl.'&tmod=kanjia';

$get_list_url_value = get_list_url("tom_tckjia_admin_kanjia");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'bang_list'){

    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $kanjia_id = intval($_GET['kanjia_id'])>0? intval($_GET['kanjia_id']):0;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $tckjiaInfo = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_by_id($kanjia_id);
    $goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($tckjiaInfo['goods_id']);
    $count = C::t('#tom_tckjia#tom_tckjia_kanjia_log')->fetch_all_count(" AND kanjia_id = {$kanjia_id} ");
    $logList = C::t('#tom_tckjia#tom_tckjia_kanjia_log')->fetch_all_list(" AND kanjia_id = {$kanjia_id} "," ORDER BY add_time DESC,id DESC ",$start,$pagesize);

    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $tckjiaInfo['xm'] . '-' .$Lang['kanjia_bang_list']. ' </th></tr>';
    showtablefooter();/*Dism��taobao��com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['kanjia_user'] . '</th>';
    echo '<th>' . $Lang['bang_list_price'] . '</th>';
    echo '<th>' . $Lang['kanjia_add_time'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($logList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        echo '<tr>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#0a9409">('.$value['user_id']. ')</font></td>';
        echo '<td>' . $value['price'] . '</td>';
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset). '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl."&act=bang_list&kanjia_id={$kanjia_id}&formhash=".FORMHASH);	
    showsubmit('', '', '', '', $multi, false);

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $kanjia_id  = isset($_GET['id'])? intval($_GET['id']):0;
    $count = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND kanjia_id={$kanjia_id} ");
    if($count > 0){
        cpmsg($Lang['act_del_kanjia_error'], $modListUrl, 'error');
    }
    
    C::t('#tom_tckjia#tom_tckjia_kanjia')->delete_by_id($_GET['id']);
    C::t('#tom_tckjia#tom_tckjia_kanjia_log')->delete_by_kanjia_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_tckjia_admin_kanjia");
    
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $goods_id   = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    $user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    
    $where = '';
    if($goods_id > 0){
        $where .= " AND goods_id = {$goods_id} ";
    }
    if($user_id > 0){
        $where .= " AND user_id = {$user_id} ";
    }
    
    $pagesize = 20;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_count($where);
    $tckjiaList = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_list($where," ORDER BY add_time DESC,id DESC ",$start,$pagesize);
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><td width="100" align="right"><b>' . $Lang['kanjia_goods_id'] . '</b></td><td><input name="goods_id" type="text" value="'.$goods_id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['kanjia_user_id'] . '</b></td><td><input name="user_id" type="text" value="'.$user_id.'" size="40" /></td></tr>';
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism_taobao_com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['kanjia_user'] . '</th>';
    echo '<th>' . $Lang['kanjia_yikan_price'] . '</th>';
    echo '<th>' . $Lang['kanjia_order_status'] . '</th>';
    echo '<th>' . $Lang['kanjia_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tckjiaList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $orderInfoTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list(" AND kanjia_id = {$value['id']}", 'ORDER BY id DESC', 0, 1);
        $priceSum = C::t('#tom_tckjia#tom_tckjia_kanjia_log')->fetch_all_price_sum(" AND kanjia_id = {$value['id']}");
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#0a9409">('.$value['user_id']. ')</font></td>';
        echo '<td>' . $priceSum . '</td>';
        if(is_array($orderInfoTmp) && !empty($orderInfoTmp[0])){

            if($orderInfoTmp[0]['order_status'] == 1){
                echo '<td><font color="#0a9409">' . $Lang['kanjia_order_status_1'] . '</font><a href="'.$adminBaseUrl.'&tmod=order&id='.$orderInfoTmp[0]['id'].'&formhash='.FORMHASH.'" style="color:#f00">('.$Lang['order_order_status_1'] .')</a></td>';
            }else if($orderInfoTmp[0]['order_status'] == 2){
                echo '<td><font color="#0a9409">' . $Lang['kanjia_order_status_1'] . '</font><a href="'.$adminBaseUrl.'&tmod=order&id='.$orderInfoTmp[0]['id'].'&formhash='.FORMHASH.'" style="color:#0a9409">('.$Lang['order_order_status_2'] .')</a></td>';
            }else if($orderInfoTmp[0]['order_status'] == 3){
                echo '<td><font color="#0a9409">' . $Lang['kanjia_order_status_1'] . '</font><a href="'.$adminBaseUrl.'&tmod=order&id='.$orderInfoTmp[0]['id'].'&formhash='.FORMHASH.'" style="color:#0a9409">('.$Lang['order_order_status_3'] .')</a></td>';
            }else if($orderInfoTmp[0]['order_status'] == 4){
                echo '<td><font color="#0a9409">' . $Lang['kanjia_order_status_2'] . '</font><a href="'.$adminBaseUrl.'&tmod=order&id='.$orderInfoTmp[0]['id'].'&formhash='.FORMHASH.'" style="color:#0a9409">('.$Lang['order_order_status_4'] .')</a></td>';
            }else if($orderInfoTmp[0]['order_status'] == 5){
                echo '<td><font color="#0a9409">' . $Lang['kanjia_order_status_2'] . '</font><a href="'.$adminBaseUrl.'&tmod=order&id='.$orderInfoTmp[0]['id'].'&formhash='.FORMHASH.'" style="color:#0a9409">('.$Lang['order_order_status_5'] .')</a></td>';
            }
            
        }else{
            echo '<td><font color="#f00">' . $Lang['kanjia_order_status_0'] . '</font></td>';
        }
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset). '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=bang_list&kanjia_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['kanjia_bang_list']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl."&goods_id={$goods_id}");
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'edit'){
        tomshownavli($Lang['kanjia_title'],$modBaseUrl,false);
        tomshownavli($Lang['kanjia_edit'],"",true);
    }else{
        tomshownavli($Lang['kanjia_title'],$modBaseUrl,true);
    }
    tomshownavfooter();
}