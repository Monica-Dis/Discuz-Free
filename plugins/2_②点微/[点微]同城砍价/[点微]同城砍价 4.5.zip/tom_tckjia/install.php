<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tckjia_cate`;
CREATE TABLE `pre_tom_tckjia_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `csort` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tckjia_focuspic`;
CREATE TABLE `pre_tom_tckjia_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tckjia_goods`;
CREATE TABLE `pre_tom_tckjia_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `style_id` varchar(255) DEFAULT 'baise',
  `cate_id` int(11) DEFAULT '0',
  `tcchoujiang_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `yongjin_bili` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `toppic` varchar(255) DEFAULT NULL,
  `start_time` int(11) DEFAULT '0',
  `end_time` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `hexiao_pwd` varchar(255) DEFAULT NULL,
  `goods_price` decimal(10,2) DEFAULT '0.00',
  `base_price` decimal(10,2) DEFAULT '0.00',
  `open_tiqian_pay` tinyint(4) DEFAULT '0',
  `type` tinyint(4) DEFAULT '1',
  `kanjia_num` int(11) DEFAULT '0',
  `kanjia_min_price` decimal(10,2) DEFAULT '0.00',
  `kanjia_max_price` decimal(10,2) DEFAULT '0.00',
  `open_ding_pay` tinyint(4) DEFAULT '0',
  `ding_price` decimal(10,2) DEFAULT '0.00',
  `stock_num` int(11) DEFAULT '0',
  `sale_num` int(11) DEFAULT '0',
  `admin_edit` tinyint(4) DEFAULT '0',
  `guize` text,
  `content` text,
  `peisong_type` tinyint(4) DEFAULT '1',
  `open_yuyue` tinyint(4) DEFAULT '0',
  `yuyue_xm` varchar(255) DEFAULT NULL,
  `yuyue_tel` varchar(255) DEFAULT NULL,
  `clicks` int(11) DEFAULT '0',
  `virtual_clicks` int(11) DEFAULT '0',
  `virtual_user` int(11) DEFAULT '0',
  `shares` int(11) DEFAULT '0',
  `virtual_shares` int(11) DEFAULT '0',
  `shenhe_status` tinyint(4) NOT NULL DEFAULT '0',
  `kanjia_status` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT '1',
  `mp3_link` varchar(255) DEFAULT NULL,
  `share_title` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '1000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tckjia_goods_photo`;
CREATE TABLE `pre_tom_tckjia_goods_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tckjia_jubao`;
CREATE TABLE `pre_tom_tckjia_jubao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `tel` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `content` text,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tckjia_kanjia`;
CREATE TABLE `pre_tom_tckjia_kanjia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `is_zikan` int(11) DEFAULT '0',
  `kan_status` int(11) DEFAULT '0',
  `kan_time` int(11) DEFAULT '0',
  `template_status` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tckjia_kanjia_log`;
CREATE TABLE `pre_tom_tckjia_kanjia_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `kanjia_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tckjia_order`;
CREATE TABLE `pre_tom_tckjia_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `order_no` varchar(255) DEFAULT NULL,
  `hexiao_no` varchar(255) DEFAULT NULL,
  `kanjia_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `goods_title` varchar(255) DEFAULT NULL,
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `order_beizu` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `openid` varchar(255) DEFAULT NULL,
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `order_time` int(11) DEFAULT '0',
  `pay_time` int(11) DEFAULT '0',
  `peisong_type` int(11) DEFAULT '1',
  `peisong_status` int(11) DEFAULT '0',
  `peisong_info` varchar(255) DEFAULT NULL,
  `peisong_time` int(11) DEFAULT '0',
  `order_status` int(11) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `balance_status` int(11) DEFAULT '0',
  `admin_edit` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tckjia_stock_log`;
CREATE TABLE `pre_tom_tckjia_stock_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_admin` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '1',
  `change_num` int(11) DEFAULT '0',
  `change_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;