<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


function wx_iconv_recurrence($value) {
    if(is_array($value)) {
        foreach($value AS $key => $val) {
            $value[$key] = wx_iconv_recurrence($val);
        }
    } else {
        $value = diconv($value, 'utf-8', CHARSET);
    }
    return $value;
}

function update_kanjia_status($goodsInfo = array()){
    
    $kanjia_status = 1;
    
    if(TIMESTAMP < $goodsInfo['start_time']){
        $kanjia_status = 2;
    }
    
    if(TIMESTAMP > $goodsInfo['end_time']){
        $kanjia_status = 3;
    }

    if($goodsInfo['stock_num'] <= $goodsInfo['sale_num']){
        $kanjia_status= 3;
    }

    if($goodsInfo['status'] != 1){
        $kanjia_status= 3;
    }
    
    if($kanjia_status != $goodsInfo['kanjia_status']){
        $updateData  = array();
        $updateData['kanjia_status']  = $kanjia_status;
        C::t('#tom_tckjia#tom_tckjia_goods')->update($goodsInfo['id'],$updateData);
    }
    
    return $kanjia_status;
}

function tom_number_float($number=0.00 , $num=2){
    if($number > 0){
        $number = floatval(number_format($number, $num, '.' ,''));
    }
    return $number;
}

function check_region(){
    global $_G;
    
    $tckjiaConfig = $_G['cache']['plugin']['tom_tckjia'];
    
    # PC start
    if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false){
        if(!empty($tckjiaConfig['region_jump_link'])){
            dheader('location:'.$tckjiaConfig['region_jump_link']);exit;
        }else{
            dheader('location:'.$_G['siteurl'].'404.php');exit;
        }
    }
    # PC end
    
    $host       = "https://api01.aliyun.venuscn.com";
    $path       = "/ip";
    $appcode    = trim($tckjiaConfig['region_appcode']);
    $headers    = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys     = "ip=".$_G['clientip'];
    $bodys      = "";
    $url        = $host . $path . "?" . $querys;
    
    $start_time = time();
    
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    $return = curl_exec($curl);
    $content = json_decode($return,true);
    $content = wx_iconv_recurrence($content);
    
    $end_time = time();
    
    if($tckjiaConfig['region_debug'] == 1){
        echo $start_time.'--'.$end_time.'<hr>';
        print_r($content);exit;
    }
    
    $ip_region = '';
    if(is_array($content) && !empty($content) && $content['msg'] == 'success' && is_array($content['data']) && !empty($content['data'])){
        
        $ip_region = $content['data']['region'].' '.$content['data']['city'];
        
        $region_list = preg_quote(trim($tckjiaConfig['region_list']), '/');
        $region_list = str_replace(array("\\*"), array('.*'), $region_list);
        $region_list = '.*('.$region_list.').*';
        $region_list = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $region_list).')$/i';
        if(@preg_match($region_list, $ip_region,$matches)) {
            return true;
        }
    }
    
    if(!empty($tckjiaConfig['region_jump_link'])){
        dheader('location:'.$tckjiaConfig['region_jump_link']);exit;
    }else{
        dheader('location:'.$_G['siteurl'].'404.php');exit;
    }
    
    return false;
}