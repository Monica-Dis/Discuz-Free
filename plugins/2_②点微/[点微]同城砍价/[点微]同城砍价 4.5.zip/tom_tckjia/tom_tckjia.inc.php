<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tckjiaConfig = $_G['cache']['plugin']['tom_tckjia'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
$tomSysOffset = getglobal('setting/timeoffset');
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = '20190216';
$__TckjiaApp = 'plugin.php?id=tom_tckjia';
if (CHARSET == 'gbk') {
	include DISCUZ_ROOT . './source/plugin/tom_tckjia/config/config.gbk.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tckjia/config/config.utf8.php';
}
include DISCUZ_ROOT . './source/plugin/tom_tckjia/config/style.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$tckjiaConfig['tongcheng_hosts'] = trim($tckjiaConfig['tongcheng_hosts']);
$tckjiaConfig['kjia_hosts'] = trim($tckjiaConfig['kjia_hosts']);
$tckjiaConfig['haibao_hosts'] = trim($tckjiaConfig['haibao_hosts']);
if (!empty($tckjiaConfig['tongcheng_hosts']) && !empty($tckjiaConfig['kjia_hosts']) && !empty($tckjiaConfig['haibao_hosts'])) {
	if ($tckjiaConfig['tongcheng_hosts'] != $tckjiaConfig['haibao_hosts'] && $tckjiaConfig['kjia_hosts'] != $tckjiaConfig['haibao_hosts']) {
		$urlTmp = $weixinClass->get_url();
		if ($tckjiaConfig['haibao_hosts_test'] == 1) {
			echo '[From] <br/><br/>' . $urlTmp . '<br/><br/><br/>';
		}
		if (strpos($urlTmp, $tckjiaConfig['kjia_hosts']) === false && strpos($urlTmp, $tckjiaConfig['haibao_hosts']) !== false) {
			$newUrlTmp = str_replace($tckjiaConfig['haibao_hosts'], $tckjiaConfig['kjia_hosts'], $urlTmp);
			if ($tckjiaConfig['haibao_hosts_test'] == 1) {
				echo '[Jump]<br/><br/> ' . $newUrlTmp;
				exit(0);
			}
			tomheader('location:' . $newUrlTmp);
			exit(0);
		}
	}
}
$__OnlyHosts = 0;
$__TongchengHost = '';
if ($tckjiaConfig['open_only_hosts'] == 1 && !empty($tckjiaConfig['tongcheng_hosts']) && !empty($tckjiaConfig['kjia_hosts'])) {
	$__OnlyHosts = 1;
	$urlTmp = $weixinClass->get_url();
	if (strpos($urlTmp, $tckjiaConfig['kjia_hosts']) === false && strpos($urlTmp, $tckjiaConfig['tongcheng_hosts']) !== false) {
		$newUrlTmp = str_replace($tckjiaConfig['tongcheng_hosts'], $tckjiaConfig['kjia_hosts'], $urlTmp);
		if ($tckjiaConfig['must_http'] == 1) {
			$newUrlTmp = str_replace('https', 'http', $newUrlTmp);
		}
		tomheader('location:' . $newUrlTmp);
		exit(0);
	}
	preg_match('#((http|https)://([^?]*)/)([a-z_0-9]*.php)#', $urlTmp, $urlmatches2);
	if (strpos($urlmatches2['0'], $tckjiaConfig['tongcheng_hosts']) === false && strpos($urlTmp, $tckjiaConfig['kjia_hosts']) !== false) {
		$__TongchengHost = str_replace($tckjiaConfig['kjia_hosts'], $tckjiaConfig['tongcheng_hosts'], $urlmatches2['0']);
		$__TongchengHost = rtrim($__TongchengHost, $urlmatches2['4']);
		if ($tckjiaConfig['must_http'] == 1) {
			if (strpos($__TongchengHost, 'https') === false) {
				$__TongchengHost = str_replace('http', 'https', $__TongchengHost);
			}
		}
	}
}
include DISCUZ_ROOT . './source/plugin/tom_tckjia/class/function.core.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tckjiaConfig['wx_share_title'];
$shareDesc = $tckjiaConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . $__TckjiaApp . ('&site=' . $site_id . '&mod=index');
$shareLogo = $tckjiaConfig['wx_share_pic'];
$guanzQrcode = $tongchengConfig['fwh_qrcode'];
if (!empty($tckjiaConfig['guanzu_qrcode'])) {
	$guanzQrcode = $tckjiaConfig['guanzu_qrcode'];
}
$__ShowTchongbao = 0;
$tchongbaoConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchongbao/tom_tchongbao.inc.php')) {
	if ($tongchengConfig['open_tchongbao'] == 1) {
		$__ShowTchongbao = 1;
		$tchongbaoConfig = $_G['cache']['plugin']['tom_tchongbao'];
	}
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$__ShowTcmall = 0;
$tcmallConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcmall/tom_tcmall.inc.php')) {
	$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
	if ($tcmallConfig['open_tcmall'] == 1) {
		$__ShowTcmall = 1;
	}
}
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')) {
	$tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
	if ($tcchoujiangConfig['open_tcchoujiang'] == 1) {
		$__ShowTcchoujiang = 1;
	}
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$ajaxCommonClicksUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=commonClicks&formhash=' . $formhash;
if ($_GET['mod'] == 'index') {
	if ($tckjiaConfig['open_region'] == 1) {
		check_region();
	}
	$cate_id = isset($_GET['cate_id']) ? intval($_GET['cate_id']) : 0;
	$tab_id = isset($_GET['tab_id']) ? intval($_GET['tab_id']) : 1;
	$focuspicListTmp = C::t('#tom_tckjia#tom_tckjia_focuspic')->fetch_all_list(' AND site_id = ' . $site_id . ' ', 'ORDER BY fsort ASC', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tckjia#tom_tckjia_focuspic')->fetch_all_list(' AND site_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	foreach ($focuspicListTmp as $key => $value) {
		$focuspicList[$key] = $value;
		if (!preg_match('/^http/', $value['picurl'])) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
		} else {
			$picurl = $value['picurl'];
		}
		$focuspicList[$key]['picurl'] = $picurl;
	}
	$cateListTmp = C::t('#tom_tckjia#tom_tckjia_cate')->fetch_all_list(' ', ' ORDER BY csort ASC,id DESC ', 0, 50);
	$cateList = array();
	$i = 1;
	$cateCount = 0;
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tckjia/') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$cateList[$key]['picurl'] = $picurl;
			$cateList[$key]['i'] = $i;
			$cateList[$key]['link'] = $__TckjiaApp . ('&site=' . $site_id . '&mod=index&cate_id=' . $value['id']);
			$i++;
			$cateCount++;
		}
	}
	$orderListTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list(' AND order_status IN(2,3) ', ' ORDER BY pay_time DESC,id DESC ', 0, 10);
	$orderList = array();
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			$orderList[$key] = $value;
			$orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$ordergoodsInfoTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($value['goods_id']);
			$orderList[$key]['userInfo'] = $orderUserInfoTmp;
			$orderList[$key]['goodsInfo'] = $ordergoodsInfoTmp;
		}
	}
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tckjia/images/index.js';
	$ajaxIndexLoadListUrl = $__TckjiaApp . (':ajax&site=' . $site_id . '&act=list&tab_id=' . $tab_id . '&cate_id=' . $cate_id . '&formhash=') . $formhash;
	$tabIdUrl = $__TckjiaApp . ('&mod=index&site=' . $site_id . '&cate_id=' . $cate_id . '&tab_id=');
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:index');
	echo '<script src="source/plugin/tom_tckjia/images/index.js"></script>';
} elseif ($_GET['mod'] == 'details') {
	if ($tckjiaConfig['open_region'] == 1) {
		check_region();
	}
	$goods_id = isset($_GET['goods_id']) ? intval($_GET['goods_id']) : 0;
	$tj_hehuoren_id = isset($_GET['tj_hehuoren_id']) ? intval($_GET['tj_hehuoren_id']) : 0;
	$goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($goods_id);
	if (!is_array($goodsInfo) || empty($goodsInfo)) {
		tomheader('location:' . $_G['siteurl'] . $__TckjiaApp . ('&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$isKanjiaStatus = 0;
	$isKanjiaUrl = '';
	if ($__UserInfo['id'] > 0) {
		$kanjiaInfoTmp = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND goods_id = ' . $goods_id . ' ', 'ORDER BY id DESC', 0, 1);
		if (is_array($kanjiaInfoTmp) && !empty($kanjiaInfoTmp[0])) {
			if ($__IsMiniprogram == 1) {
				$isKanjiaStatus = 1;
				$isKanjiaUrl = $_G['siteurl'] . $__TckjiaApp . ('&site=' . $site_id . '&mod=jian&goods_id=' . $goods_id . '&kid=' . $kanjiaInfoTmp[0]['id']);
			} else {
				tomheader('location:' . $_G['siteurl'] . $__TckjiaApp . ('&site=' . $site_id . '&mod=jian&goods_id=' . $goods_id . '&kid=' . $kanjiaInfoTmp[0]['id']));
				exit(0);
			}
		}
	}
	$goodsInfo['kanjia_status'] = update_kanjia_status($goodsInfo);
	if (!preg_match('/^http/', $goodsInfo['toppic'])) {
		if (strpos($goodsInfo['toppic'], 'source/plugin/tom_tckjia/') === false) {
			$toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['toppic'];
		} else {
			$toppic = $goodsInfo['toppic'];
		}
	} else {
		$toppic = $goodsInfo['toppic'];
	}
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/tom_tckjia/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$picurl = $_G['siteurl'] . $goodsInfo['picurl'];
		}
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	$tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	$tcshopInfo = array();
	if (is_array($tcshopInfoTmp) && !empty($tcshopInfoTmp)) {
		$tcshopInfo = $tcshopInfoTmp;
		if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
			if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_tcshop/') === false) {
				$tcshopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
			} else {
				$tcshopPicurl = $tcshopInfo['picurl'];
			}
		} else {
			$tcshopPicurl = $tcshopInfo['picurl'];
		}
		$tcshopInfo['picurl'] = $tcshopPicurl;
	}
	$photoListTmp = C::t('#tom_tckjia#tom_tckjia_goods_photo')->fetch_all_list(' AND goods_id = ' . $goodsInfo['id'] . ' ', 'ORDER BY add_time DESC,id DESC', 0, 20);
	$photoList = array();
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			$photoList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tckjia/') === false) {
					$photoPic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$photoPic = $value['picurl'];
				}
			} else {
				$photoPic = $value['picurl'];
			}
			$photoList[$key]['picurl'] = $photoPic;
		}
	}
	$kanjiaCount = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_count(' AND goods_id = ' . $goods_id . ' ');
	$clicks = $goodsInfo['clicks'] + $goodsInfo['virtual_clicks'];
	$userCount = $kanjiaCount + $goodsInfo['virtual_user'];
	$shares = $goodsInfo['shares'] + $goodsInfo['virtual_shares'];
	$noStartSyTime = ($goodsInfo['start_time'] - TIMESTAMP) * 1000;
	$syTime = ($goodsInfo['end_time'] - TIMESTAMP) * 1000;
	$syGoodsNum = $goodsInfo['stock_num'] - $goodsInfo['sale_num'];
	$hexiaoTime = dgmdate($goodsInfo['hexiao_time'], 'Y-m-d H:i', $tomSysOffset);
	$style = $styleArray[$goodsInfo['style_id']];
	$guize = stripslashes($goodsInfo['guize']);
	$content = stripslashes($goodsInfo['content']);
	$contentTmp = strip_tags($content);
	$contentTmp = str_replace("\r\n", '', $contentTmp);
	$contentTmp = str_replace("\n", '', $contentTmp);
	$contentTmp = str_replace("\r", '', $contentTmp);
	if ($goodsInfo['admin_edit'] == 0) {
		$content = str_replace("\r\n", '<br/>', $content);
		$content = str_replace("\n", '<br/>', $content);
		$content = str_replace("\r", '<br/>', $content);
		$guize = str_replace("\r\n", '<br/>', $guize);
		$guize = str_replace("\n", '<br/>', $guize);
		$guize = str_replace("\r", '<br/>', $guize);
	}
	$kanjiaSuccListTmp = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_list(' AND goods_id = ' . $goods_id . ' AND kan_status = 1 ', 'ORDER BY id DESC', 0, 10);
	$kanjiaSuccList = array();
	if (is_array($kanjiaSuccListTmp) && !empty($kanjiaSuccListTmp[0])) {
		foreach ($kanjiaSuccListTmp as $key => $value) {
			$kanjiaSuccList[$key] = $value;
			$kanjiaSuccUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$kanjiaSuccList[$key]['userInfo'] = $kanjiaSuccUserInfo;
		}
	}
	$ajaxClicksUrl = $__TckjiaApp . (':ajax&site=' . $site_id . '&act=clicks&goods_id=' . $goods_id . '&formhash=') . $formhash;
	$ajaxSharesUrl = $__TckjiaApp . (':ajax&site=' . $site_id . '&act=shares&goods_id=' . $goods_id . '&formhash=') . $formhash;
	$ajaxAddUrl = $__TckjiaApp . (':ajax&site=' . $site_id . '&act=add_kanjia_user&tj_hehuoren_id=' . $tj_hehuoren_id . '&formhash=') . $formhash;
	$jianUrl = $_G['siteurl'] . $__TckjiaApp . ('&mod=jian&site=' . $site_id . '&goods_id=' . $goods_id . '&kid=');
	$ajaxLoadJianListUrl = $__TckjiaApp . (':ajax&site=' . $site_id . '&act=jianlist&goods_id=' . $goodsInfo['id'] . '&formhash=') . $formhash;
	$shareTitle = $goodsInfo['title'];
	$shareDesc = cutstr($contentTmp, 80, '...');
	$shareLogo = $picurl;
	$shareUrl = $_G['siteurl'] . $__TckjiaApp . ('&mod=details&site=' . $site_id . '&goods_id=' . $goods_id);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:details');
} elseif ($_GET['mod'] == 'jian') {
	if ($tckjiaConfig['open_region'] == 1) {
		check_region();
	}
	$kid = isset($_GET['kid']) ? intval($_GET['kid']) : 0;
	$kanjiaInfo = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_by_id($kid);
	if (!is_array($kanjiaInfo) || empty($kanjiaInfo)) {
		tomheader('location:' . $_G['siteurl'] . $__TckjiaApp . ('&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($kanjiaInfo['goods_id']);
	$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($kanjiaInfo['user_id']);
	$kanjiaInfo['userInfo'] = $userInfoTmp;
	$goodsInfo['kanjia_status'] = update_kanjia_status($goodsInfo);
	if (!preg_match('/^http/', $goodsInfo['toppic'])) {
		if (strpos($goodsInfo['toppic'], 'source/plugin/tom_tckjia/') === false) {
			$toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['toppic'];
		} else {
			$toppic = $goodsInfo['toppic'];
		}
	} else {
		$toppic = $goodsInfo['toppic'];
	}
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/tom_tckjia/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$picurl = $_G['siteurl'] . $goodsInfo['picurl'];
		}
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	$tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	$tcshopInfo = array();
	if (is_array($tcshopInfoTmp) && !empty($tcshopInfoTmp)) {
		$tcshopInfo = $tcshopInfoTmp;
		if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
			if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_tcshop/') === false) {
				$tcshopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
			} else {
				$tcshopPicurl = $tcshopInfo['picurl'];
			}
		} else {
			$tcshopPicurl = $tcshopInfo['picurl'];
		}
		$tcshopInfo['picurl'] = $tcshopPicurl;
	}
	$photoListTmp = C::t('#tom_tckjia#tom_tckjia_goods_photo')->fetch_all_list(' AND goods_id = ' . $goodsInfo['id'] . ' ', 'ORDER BY add_time DESC,id DESC', 0, 20);
	$photoList = array();
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			$photoList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tckjia/') === false) {
					$photoPic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$photoPic = $value['picurl'];
				}
			} else {
				$photoPic = $value['picurl'];
			}
			$photoList[$key]['picurl'] = $photoPic;
		}
	}
	$kanjiaCount = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_count(' AND goods_id = ' . $goodsInfo['id'] . ' ');
	$clicks = $goodsInfo['clicks'] + $goodsInfo['virtual_clicks'];
	$userCount = $kanjiaCount + $goodsInfo['virtual_user'];
	$shares = $goodsInfo['shares'] + $goodsInfo['virtual_shares'];
	$syTime = ($goodsInfo['end_time'] - TIMESTAMP) * 1000;
	$syGoodsNum = $goodsInfo['stock_num'] - $goodsInfo['sale_num'];
	$hexiaoTime = dgmdate($goodsInfo['hexiao_time'], 'Y-m-d H:i', $tomSysOffset);
	$style = $styleArray[$goodsInfo['style_id']];
	$guize = stripslashes($goodsInfo['guize']);
	$content = stripslashes($goodsInfo['content']);
	$contentTmp = strip_tags($content);
	$contentTmp = str_replace("\r\n", '', $contentTmp);
	$contentTmp = str_replace("\n", '', $contentTmp);
	$contentTmp = str_replace("\r", '', $contentTmp);
	if ($goodsInfo['admin_edit'] == 0) {
		$content = str_replace("\r\n", '<br/>', $content);
		$content = str_replace("\n", '<br/>', $content);
		$content = str_replace("\r", '<br/>', $content);
		$guize = str_replace("\r\n", '<br/>', $guize);
		$guize = str_replace("\n", '<br/>', $guize);
		$guize = str_replace("\r", '<br/>', $guize);
	}
	$orderListTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list(' AND goods_id=' . $goodsInfo['id'] . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 3);
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tckjia_goods') . (' SET sale_num=sale_num - 1 WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tckjia_order') . (' SET order_status=4 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
				}
			}
		}
	}
	$kanjiaSuccListTmp = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_list(' AND goods_id = ' . $goodsInfo['id'] . ' AND kan_status = 1 ', 'ORDER BY id DESC', 0, 10);
	$kanjiaSuccList = array();
	if (is_array($kanjiaSuccListTmp) && !empty($kanjiaSuccListTmp[0])) {
		foreach ($kanjiaSuccListTmp as $key => $value) {
			$kanjiaSuccList[$key] = $value;
			$kanjiaSuccUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$kanjiaSuccList[$key]['userInfo'] = $kanjiaSuccUserInfo;
		}
	}
	$bangKanUserListTmp = C::t('#tom_tckjia#tom_tckjia_kanjia_log')->fetch_all_list(' AND kanjia_id = ' . $kanjiaInfo['id'] . ' ', 'ORDER BY id DESC', 0, 8);
	$bangKanUserList = array();
	if (is_array($bangKanUserListTmp) && !empty($bangKanUserListTmp)) {
		foreach ($bangKanUserListTmp as $key => $value) {
			$bangKanUserList[$key] = $value;
			$bangKanUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$bangKanUserList[$key]['userInfo'] = $bangKanUserInfo;
		}
	}
	$bangKanCount = C::t('#tom_tckjia#tom_tckjia_kanjia_log')->fetch_all_count(' AND kanjia_id = ' . $kanjiaInfo['id'] . ' ');
	$bangKanPrice = C::t('#tom_tckjia#tom_tckjia_kanjia_log')->fetch_all_price_sum(' AND kanjia_id = ' . $kanjiaInfo['id'] . ' ');
	$syBangKanPrice = tom_number_float($goodsInfo['goods_price'] - $bangKanPrice - $goodsInfo['base_price']);
	$bangKanBili = tom_number_float($syBangKanPrice / ($goodsInfo['goods_price'] - $goodsInfo['base_price']), 4) * 100;
	$price = tom_number_float($goodsInfo['goods_price'] - $bangKanPrice);
	if ($price <= $goodsInfo['base_price']) {
		$price = $goodsInfo['base_price'];
		$updateData = array();
		$updateData['kan_status'] = 1;
		$updateData['kan_time'] = TIMESTAMP;
		C::t('#tom_tckjia#tom_tckjia_kanjia')->update($kanjiaInfo['id'], $updateData);
		$kanjiaInfo['kan_status'] = 1;
	}
	$sendTemplateSmsAjax = 0;
	if ($kanjiaInfo['template_status'] == 0 && $kanjiaInfo['kan_status'] == 1) {
		$sendTemplateSmsAjax = 1;
	}
	$templateSmsAjaxUrl = 'plugin.php?id=tom_tckjia:ajax&site=' . $site_id . '&act=kan_ok_sms&kid=' . $kanjiaInfo['id'] . '&formhash=' . FORMHASH;
	$kanjiaInfo['bangKanCount'] = $bangKanCount;
	$kanjiaInfo['bangKanPrice'] = tom_number_float($bangKanPrice);
	$kanjiaInfo['syBangKanPrice'] = tom_number_float($syBangKanPrice);
	$kanjiaInfo['price'] = $price;
	$isShowRandBtn = 0;
	$randSecond = rand(3, 5);
	if ($goodsInfo['type'] == 1) {
		$syBangKangNum = $goodsInfo['kanjia_num'] - $bangKanCount;
		if ($syBangKangNum <= 3) {
			$isShowRandBtn = 1;
		}
	} elseif ($goodsInfo['type'] == 2) {
		$pjBangKanPrice = ($goodsInfo['kanjia_min_price'] + $goodsInfo['kanjia_max_price']) / 2;
		if ($syBangKanPrice <= $pjBangKanPrice * 3) {
			$isShowRandBtn = 1;
		}
	}
	$is_self = 0;
	if ($__UserInfo['id'] > 0) {
		if ($kanjiaInfo['user_id'] == $__UserInfo['id']) {
			$is_self = 1;
			$orderInfoTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND kanjia_id = ' . $kanjiaInfo['id'] . ' AND order_status IN(1,2,3)', 'ORDER BY id DESC', 0, 1);
			$orderInfo = array();
			if (is_array($orderInfoTmp) && !empty($orderInfoTmp[0])) {
				$orderInfo = $orderInfoTmp[0];
			}
		} else {
			$myBangkanStatus = 0;
			$myBangkanLogInfoTmp = C::t('#tom_tckjia#tom_tckjia_kanjia_log')->fetch_all_list(' AND kanjia_id = ' . $kanjiaInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY add_time DESC, id DESC', 0, 1);
			if (is_array($myBangkanLogInfoTmp) && !empty($myBangkanLogInfoTmp[0])) {
				$myBangkanStatus = 1;
			}
		}
	}
	$ajaxUrl = $__TckjiaApp . (':ajax&site=' . $site_id . '&formhash=') . $formhash;
	$ajaxClicksUrl = $__TckjiaApp . (':ajax&site=' . $site_id . '&act=clicks&goods_id=' . $goodsInfo['id'] . '&formhash=') . $formhash;
	$ajaxSharesUrl = $__TckjiaApp . (':ajax&site=' . $site_id . '&act=shares&goods_id=' . $goodsInfo['id'] . '&formhash=') . $formhash;
	$buyUrl = $__TckjiaApp . ('&mod=buy&site=' . $site_id . '&kanjia_id=' . $kanjiaInfo['id'] . '&formhash=') . $formhash;
	$addUrl = $__TckjiaApp . ('&mod=details&site=' . $site_id . '&goods_id=' . $goodsInfo['id']);
	$ajaxLoadJianListUrl = $__TckjiaApp . (':ajax&site=' . $site_id . '&act=jianlist&goods_id=' . $goodsInfo['id'] . '&formhash=') . $formhash;
	if (!empty($goodsInfo['share_title'])) {
		$shareTitle = str_replace('{NAME}', $userInfoTmp['nickname'], $goodsInfo['share_title']);
	} else {
		$shareTitle = $userInfoTmp['nickname'] . '' . lang('plugin/tom_tckjia', 'zhengzaicanjia') . '' . $goodsInfo['title'];
	}
	if (!empty($goodsInfo['share_desc'])) {
		$shareDesc = str_replace('{NAME}', $userInfoTmp['nickname'], $goodsInfo['share_desc']);
	} else {
		$shareDesc = cutstr($contentTmp, 80, '...');
	}
	$shareLogo = $picurl;
	$shareUrl = $_G['siteurl'] . $__TckjiaApp . ('&mod=jian&site=' . $site_id . '&goods_id=' . $goodsInfo['id'] . '&kid=' . $kid);
	if (!empty($tckjiaConfig['tongcheng_hosts']) && !empty($tckjiaConfig['kjia_hosts']) && !empty($tckjiaConfig['haibao_hosts'])) {
		$haibaoUrl = $_G['siteurl'] . $__TckjiaApp . ('&mod=jian&site=' . $site_id . '&goods_id=' . $goodsInfo['id'] . '&kid=' . $kid);
		$haibaoUrl = str_replace($tckjiaConfig['kjia_hosts'], $tckjiaConfig['haibao_hosts'], $haibaoUrl);
	} else {
		$haibaoUrl = $_G['siteurl'] . $__TckjiaApp . ('&mod=jian&site=' . $site_id . '&goods_id=' . $goodsInfo['id'] . '&kid=' . $kid);
	}
	$haibaoQrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($haibaoUrl);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:jian');
} elseif ($_GET['mod'] == 'bangjianlist') {
	$kanjia_id = isset($_GET['kanjia_id']) ? intval($_GET['kanjia_id']) : 0;
	$kanjiaInfo = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_by_id($kanjia_id);
	$loadMoreUrl = $__TckjiaApp . (':ajax&site=' . $site_id . '&act=bangjianlist&kanjia_id=' . $kanjiaInfo['id'] . '&formhash=') . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:bangjianlist');
} elseif ($_GET['mod'] == 'buy') {
	$kanjia_id = intval($_GET['kanjia_id']) > 0 ? intval($_GET['kanjia_id']) : 0;
	$address_id = isset($_GET['address_id']) ? intval($_GET['address_id']) : 0;
	$address_back_url = $weixinClass->get_url();
	$address_back_url = preg_replace('/&address_id=[0-9]*/', '', $address_back_url);
	$address_back_url = urlencode($address_back_url);
	$kanjiaInfo = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_by_id($kanjia_id);
	$goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($kanjiaInfo['goods_id']);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($kanjiaInfo['tcshop_id']);
	if ($kanjiaInfo['user_id'] !== $__UserInfo['id']) {
		tomheader('location:' . $_G['siteurl'] . $__TckjiaApp . ('&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$goodsInfo['kanjia_status'] = update_kanjia_status($goodsInfo);
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/tom_tckjia/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$picurl = $goodsInfo['picurl'];
		}
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	$setAddressStatus = 0;
	$setAddressUrl = '';
	$addressListCount = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_count(' AND uid=' . $__MemberInfo['uid'] . ' ');
	if ($addressListCount == 0) {
		$setAddressStatus = 1;
		$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $address_back_url);
	}
	$addressInfo = array();
	$addressInfoTmp = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
	if ($addressInfoTmp && !empty($addressInfoTmp['id'])) {
		$address_id = $addressInfoTmp['id'];
		$addressInfo = $addressInfoTmp;
	} else {
		$defaultAddressList = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_list(' AND uid=' . $__MemberInfo['uid'] . ' AND default_id=1 ', 'ORDER BY id DESC', 0, 1);
		if ($defaultAddressList && !empty($defaultAddressList['0']['id'])) {
			$address_id = $defaultAddressList['0']['id'];
			$addressInfo = $defaultAddressList['0'];
		} else {
			$setAddressStatus = 1;
			$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $address_back_url);
		}
	}
	$changeAddressUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&buying=1&address_id=' . $address_id . '&address_back_url=' . $address_back_url;
	$bangKanPrice = C::t('#tom_tckjia#tom_tckjia_kanjia_log')->fetch_all_price_sum(' AND kanjia_id = ' . $kanjiaInfo['id'] . ' ');
	$goods_pay_price = tom_number_float($goodsInfo['goods_price'] - $bangKanPrice);
	if ($goods_pay_price < $goodsInfo['base_price']) {
		$goods_pay_price = $goodsInfo['base_price'];
	}
	$pay_price = 0;
	$ding_price_status = 0;
	if ($tckjiaConfig['open_ding_price'] == 1 && $goodsInfo['open_ding_pay'] == 1) {
		$ding_price_status = 1;
		$pay_price = $goodsInfo['ding_price'];
		$shenyu_price = $goods_pay_price - $pay_price;
	} else {
		$pay_price = $goods_pay_price;
	}
	$orderListTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list(' AND goods_id=' . $goodsInfo['id'] . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 20);
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tckjia_goods') . (' SET sale_num=sale_num - 1 WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tckjia_order') . (' SET order_status=4 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
				}
			}
		}
	}
	$noPayOrderListTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list(' AND kanjia_id=' . $kanjiaInfo['id'] . ' AND goods_id=' . $goodsInfo['id'] . ' AND user_id=' . $__UserInfo['id'] . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 10);
	$isHaveNoPay = 0;
	if (is_array($noPayOrderListTmp) && !empty($noPayOrderListTmp)) {
		foreach ($noPayOrderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tckjia_goods') . (' SET sale_num=sale_num - 1 WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tckjia_order') . (' SET order_status=4 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
				} else {
					$isHaveNoPay = 1;
				}
			}
		}
	}
	$xm = $address = '';
	$tel = $__UserInfo['tel'];
	if ($goodsInfo['peisong_type'] == 2 || $goodsInfo['peisong_type'] == 3) {
		$userOrderTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' AND peisong_type IN(2,3)  AND order_status IN(2,3) ', ' ORDER BY id DESC ', 0, 1);
	} else {
		$userOrderTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' AND order_status IN(2,3) ', ' ORDER BY id DESC ', 0, 1);
	}
	if (is_array($userOrderTmp) && !empty($userOrderTmp) && !empty($userOrderTmp[0]['tel'])) {
		$xm = $userOrderTmp[0]['xm'];
		$tel = $userOrderTmp[0]['tel'];
		$address = $userOrderTmp[0]['address'];
	}
	$payUrl = $__TckjiaApp . (':pay&site=' . $site_id . '&act=order');
	$mylistUrl = $__TckjiaApp . ('&site=' . $site_id . '&mod=mylist');
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:buy');
} elseif ($_GET['mod'] == 'myfabu') {
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$whereStr = ' AND user_id = ' . $__UserInfo['id'] . ' ';
	$orderStr = ' ORDER BY add_time DESC, id DESC ';
	if ($type == 1) {
		$whereStr .= ' AND status = 1 AND shenhe_status = 1 ';
	} elseif ($type == 2) {
		$whereStr .= ' AND (shenhe_status = 2 OR shenhe_status = 3)';
		$orderStr = ' ORDER BY shenhe_status ASC, id DESC ';
	}
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_count(' ' . $whereStr . ' ');
	$goodsListTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_list($whereStr, $orderStr, $start, $pagesize);
	$goodsList = array();
	foreach ($goodsListTmp as $key => $value) {
		$goodsList[$key] = $value;
		if (!preg_match('/^http/', $value['picurl'])) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
		} else {
			$picurl = $value['picurl'];
		}
		$goodsList[$key]['picurl'] = $picurl;
		$goodsList[$key]['hexiao_time'] = dgmdate($value['hexiao_time'], 'Y-m-d', $tomSysOffset);
		$goodsList[$key]['link'] = $__TckjiaApp . '&site=' . $value['site_id'] . '&mod=details&goods_id=' . $value['id'];
		update_kanjia_status($value);
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = $__TckjiaApp . ('&site=' . $site_id . '&mod=myfabu&type=' . $type . '&page=' . $prePage);
	$nextPageUrl = $__TckjiaApp . ('&site=' . $site_id . '&mod=myfabu&type=' . $type . '&page=' . $nextPage);
	$ajaxUpdateStatusUrl = $__TckjiaApp . (':ajax&site=' . $site_id . '&act=updateStatus&&formhash=') . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:myfabu');
} elseif ($_GET['mod'] == 'order') {
	$goods_id = isset($_GET['goods_id']) ? intval($_GET['goods_id']) : 0;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 100);
	$tcshopListId = array();
	if (is_array($tcshopListTmp) && !empty($tcshopListTmp)) {
		foreach ($tcshopListTmp as $key => $value) {
			$tcshopListId[] = $value['id'];
		}
	}
	$tcshopListIdStr = '99999999999';
	if (is_array($tcshopListId) && !empty($tcshopListId)) {
		$tcshopListIdStr = implode(',', $tcshopListId);
	}
	$whereStr = ' AND tcshop_id IN(' . $tcshopListIdStr . ') ';
	$whereTjStr = ' AND tcshop_id IN(' . $tcshopListIdStr . ') ';
	$orderStr = ' ORDER BY id DESC ';
	if (!empty($goods_id)) {
		$whereStr .= ' AND goods_id=' . $goods_id . ' ';
		$whereTjStr .= ' AND goods_id=' . $goods_id . ' ';
	}
	if ($type == 1) {
		$whereStr .= ' AND order_status=2 ';
	} elseif ($type == 2) {
		$whereStr .= ' AND order_status=1 ';
	} elseif ($type == 3) {
		$whereStr .= ' AND order_status=3 ';
	} else {
		$whereStr .= ' AND order_status IN(1,2,3) ';
	}
	if (!empty($keyword)) {
		$whereStr .= ' AND tel=\'' . $keyword . '\' ';
		$whereTjStr .= ' AND tel=\'' . $keyword . '\' ';
	}
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(' ' . $whereStr . ' ');
	$count2 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(' ' . $whereTjStr . ' AND order_status=2 ');
	$count3 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(' ' . $whereTjStr . ' AND order_status=3 ');
	$orderListTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list($whereStr, $orderStr, $start, $pagesize);
	$orderList = array();
	foreach ($orderListTmp as $key => $value) {
		$orderList[$key] = $value;
		$goodsInfoTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($value['goods_id']);
		if (!preg_match('/^http/', $goodsInfoTmp['picurl'])) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfoTmp['picurl'];
		} else {
			$picurl = $goodsInfoTmp['picurl'];
		}
		$orderList[$key]['goodsInfo'] = $goodsInfoTmp;
		$orderList[$key]['goodsInfo']['picurl'] = $picurl;
		$orderList[$key]['pay_time'] = dgmdate($goodsInfoTmp['pay_time'], 'Y-m-d H:i', $tomSysOffset);
		$orderList[$key]['goodsInfo']['link'] = $__TckjiaApp . '&site=' . $value['site_id'] . '&mod=details&goods_id=' . $goodsInfoTmp['id'];
		$orderList[$key]['url'] = $__TckjiaApp . '&site=' . $value['site_id'] . '&mod=orderinfo&order_no=' . $value['order_no'];
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = $__TckjiaApp . ('&site=' . $site_id . '&mod=order&goods_id=' . $goods_id . '&type=' . $type . '&page=' . $prePage);
	$nextPageUrl = $__TckjiaApp . ('&site=' . $site_id . '&mod=order&goods_id=' . $goods_id . '&type=' . $type . '&page=' . $nextPage);
	$searchUrl = $__TckjiaApp . ':ajax&site=' . $site_id . '&act=get_order_search_url';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:order');
} elseif ($_GET['mod'] == 'orderinfo') {
	$order_no = !empty($_GET['order_no']) ? addslashes($_GET['order_no']) : '';
	$orderInfo = C::t('#tom_tckjia#tom_tckjia_order')->fetch_by_order_no($order_no);
	$goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($orderInfo['goods_id']);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	if ($_GET['act'] == 'fahuo' && $_GET['formhash'] == FORMHASH) {
		$outArr = array('status' => 1, 'code' => 1);
		if ('utf-8' != CHARSET) {
			if (!defined('IN_MOBILE')) {
				foreach ($_POST as $pk => $pv) {
					if (!is_numeric($pv)) {
						$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
					}
				}
			}
		}
		$peisong_info = isset($_GET['peisong_info']) ? addslashes($_GET['peisong_info']) : '';
		$updateData = array();
		$updateData['peisong_info'] = $peisong_info;
		$updateData['peisong_status'] = 1;
		$updateData['peisong_time'] = TIMESTAMP;
		C::t('#tom_tckjia#tom_tckjia_order')->update($orderInfo['id'], $updateData);
		if (!empty($tckjiaConfig['template_fahuo'])) {
			include DISCUZ_ROOT . './source/plugin/tom_tckjia/class/templatesms.class.php';
			$access_token = $weixinClass->get_access_token();
			$orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
			if ($access_token && !empty($orderUserInfoTmp['openid'])) {
				$templateSmsClass = new kjTemplateSms($access_token, $_G['siteurl'] . $__TckjiaApp . ('&site=' . $site_id . '&mod=hexiao&order_no=' . $order_no));
				$smsData = array('first' => lang('plugin/tom_tckjia', 'template_fahuo_first'), 'keyword1' => $orderInfo['order_no'], 'keyword2' => $orderInfo['goods_title'], 'keyword3' => '1', 'keyword4' => $orderInfo['pay_price'], 'remark' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s', $tomSysOffset));
				$r = $templateSmsClass->sendSmsFahuo($orderUserInfoTmp['openid'], $tckjiaConfig['template_fahuo'], $smsData);
			}
		}
		$outArr = array('status' => 200, 'code' => 200);
		echo json_encode($outArr);
		exit(0);
	} elseif ($_GET['act'] == 'qianshou' && $_GET['formhash'] == FORMHASH) {
		$outArr = array('status' => 1, 'code' => 1);
		if ($orderInfo['peisong_type'] != 3) {
			$outArr = array('status' => 500, 'code' => 500);
			echo json_encode($outArr);
			exit(0);
		}
		if ($orderInfo['peisong_status'] != 1) {
			$outArr = array('status' => 501, 'code' => 501);
			echo json_encode($outArr);
			exit(0);
		}
		$updateData = array();
		$updateData['order_status'] = 3;
		$updateData['peisong_status'] = 2;
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['hexiao_time'] = TIMESTAMP;
		C::t('#tom_tckjia#tom_tckjia_order')->update($orderInfo['id'], $updateData);
		if ($tckjiaConfig['balance_type'] == 1 && $orderInfo['balance_status'] == 0) {
			include DISCUZ_ROOT . './source/plugin/tom_tckjia/module/balance.php';
		}
		$outArr = array('status' => 200, 'code' => 200);
		echo json_encode($outArr);
		exit(0);
	}
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/tom_tckjia/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$picurl = $goodsInfo['picurl'];
		}
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	$hexiaoTimeStatus = 1;
	if (TIMESTAMP > $goodsInfo['hexiao_time']) {
		$hexiaoTimeStatus = 2;
	}
	$state = 0;
	if ($orderInfo['order_status'] == 2) {
		$state = 2;
	} elseif ($orderInfo['order_status'] == 3) {
		$state = 3;
	}
	$hexiaoUserInfo = array();
	if ($orderInfo['order_status'] == 3) {
		$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);
	}
	$allowQianshou = 0;
	if ($orderInfo['peisong_status'] == 1 && $orderInfo['peisong_time'] > 0) {
		if (TIMESTAMP > $orderInfo['peisong_time'] + 86400 * $tckjiaConfig['shop_qianshou_days']) {
			$allowQianshou = 1;
		}
	}
	$fahuoUrl = $__TckjiaApp . '&site=' . $site_id . '&mod=orderinfo&act=fahuo&formhash=' . $formhash;
	$qianshouUrl = $__TckjiaApp . '&site=' . $site_id . '&mod=orderinfo&act=qianshou&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:orderinfo');
} elseif ($_GET['mod'] == 'mylist') {
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$whereStr = ' AND user_id = ' . $__UserInfo['id'] . ' ';
	$orderStr = ' ORDER BY id DESC ';
	if ($type == 1) {
		$whereStr .= ' AND order_status=2 ';
	} elseif ($type == 2) {
		$whereStr .= ' AND order_status=1 ';
	} elseif ($type == 3) {
		$whereStr .= ' AND order_status=3 ';
	} else {
		$whereStr .= ' AND order_status IN(1,2,3) ';
	}
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count($whereStr);
	$orderListTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list($whereStr, $orderStr, $start, $pagesize);
	$orderList = array();
	$choujiangIdArr = array();
	foreach ($orderListTmp as $key => $value) {
		$orderList[$key] = $value;
		$goodsInfoTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($value['goods_id']);
		$kanjiaInfoTmp = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_by_id($value['kanjia_id']);
		if (!preg_match('/^http/', $goodsInfoTmp['picurl'])) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfoTmp['picurl'];
		} else {
			$picurl = $goodsInfoTmp['picurl'];
		}
		$bangKanPrice = C::t('#tom_tckjia#tom_tckjia_kanjia_log')->fetch_all_price_sum(' AND kanjia_id = ' . $kanjiaInfoTmp['id'] . ' ');
		$allow_cancel = 0;
		if (tom_number_float($goodsInfoTmp['goods_price'] - $bangKanPrice) > $goodsInfoTmp['base_price']) {
			$allow_cancel = 1;
		}
		$orderList[$key]['kanjiaInfo'] = $kanjiaInfoTmp;
		$orderList[$key]['kanjiaInfo']['allow_cancel'] = $allow_cancel;
		$orderList[$key]['goodsInfo'] = $goodsInfoTmp;
		$orderList[$key]['goodsInfo']['picurl'] = $picurl;
		$orderList[$key]['goodsInfo']['hexiao_time'] = dgmdate($goodsInfoTmp['hexiao_time'], 'Y-m-d H:i', $tomSysOffset);
		$orderList[$key]['goodsInfo']['link'] = $__TckjiaApp . '&site=' . $value['site_id'] . '&mod=details&goods_id=' . $goodsInfoTmp['id'];
		$orderList[$key]['hexiao'] = $__TckjiaApp . '&site=' . $value['site_id'] . '&mod=hexiao&order_no=' . $value['order_no'];
		$orderList[$key]['choujiang'] = 0;
		if ($__ShowTcchoujiang == 1 && $goodsInfoTmp['tcchoujiang_id'] > 0) {
			$choujiangBmInfoTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($goodsInfoTmp['tcchoujiang_id'], $value['user_id']);
			if ($choujiangBmInfoTmp['id'] > 0 && $choujiangBmInfoTmp['cj_times'] > 0) {
				if (!in_array($goodsInfoTmp['tcchoujiang_id'], $choujiangIdArr)) {
					$orderList[$key]['choujiang'] = 1;
					$choujiangIdArr[] = $goodsInfoTmp['tcchoujiang_id'];
				}
			}
		}
		if ($value['order_status'] == 1) {
			if (TIMESTAMP - $value['order_time'] > 3590) {
				DB::query('UPDATE ' . DB::table('tom_tckjia_goods') . (' SET sale_num=sale_num-1 WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
				DB::query('UPDATE ' . DB::table('tom_tckjia_order') . (' SET order_status=4 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
				$orderList[$key]['order_status'] = 4;
			}
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = $__TckjiaApp . ('&site=' . $site_id . '&mod=mylist&type=' . $type . '&page=' . $prePage);
	$nextPageUrl = $__TckjiaApp . ('&site=' . $site_id . '&mod=mylist&type=' . $type . '&page=' . $nextPage);
	$ajaxCancelOrderUrl = $__TckjiaApp . (':ajax&site=' . $site_id . '&act=cancel_order&formhash=' . $formhash);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:mylist');
} elseif ($_GET['mod'] == 'hexiao') {
	$order_no = !empty($_GET['order_no']) ? addslashes($_GET['order_no']) : '';
	$orderInfo = C::t('#tom_tckjia#tom_tckjia_order')->fetch_by_order_no($order_no);
	$goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($orderInfo['goods_id']);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	if ($_GET['act'] == 'qianshou' && $_GET['formhash'] == FORMHASH) {
		if ($orderInfo['peisong_type'] != 3 && $orderInfo['peisong_type'] != 2) {
			echo 500;
			exit(0);
		}
		if ($orderInfo['peisong_status'] != 1) {
			echo 500;
			exit(0);
		}
		$updateData = array();
		$updateData['order_status'] = 3;
		$updateData['peisong_status'] = 2;
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['hexiao_time'] = TIMESTAMP;
		C::t('#tom_tckjia#tom_tckjia_order')->update($orderInfo['id'], $updateData);
		if ($tckjiaConfig['balance_type'] == 1 && $orderInfo['balance_status'] == 0) {
			include DISCUZ_ROOT . './source/plugin/tom_tckjia/module/balance.php';
		}
		echo 200;
		exit(0);
	}
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/tom_tckjia/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$picurl = $goodsInfo['picurl'];
		}
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	$stateStr = '';
	if ($orderInfo['order_status'] == 2) {
		$stateStr = 'state_2';
	} elseif ($orderInfo['order_status'] == 3) {
		$stateStr = 'state_3';
	}
	$showQrcodeBox = 0;
	if ($orderInfo['order_status'] == 2) {
		$showQrcodeBox = 1;
	}
	$qrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($_G['siteurl'] . $__TckjiaApp . ('&site=' . $site_id . '&mod=orderhexiao&hexiao_no=' . $orderInfo['hexiao_no']));
	$content = stripslashes($goodsInfo['content']);
	$hexiao_time = dgmdate($goodsInfo['hexiao_time'], 'Y' . lang('plugin/tom_tckjia', 'year') . 'm' . lang('plugin/tom_tckjia', 'month') . 'd' . lang('plugin/tom_tckjia', 'day'), $tomSysOffset);
	$hexiaoTimeStatus = 1;
	if (TIMESTAMP > $goodsInfo['hexiao_time']) {
		$hexiaoTimeStatus = 2;
	}
	$hexiaoUserInfo = array();
	if ($orderInfo['order_status'] == 3) {
		$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);
	}
	$showChoujiang = 0;
	if ($__ShowTcchoujiang == 1 && $goodsInfo['tcchoujiang_id'] > 0) {
		$choujiangBmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($goodsInfo['tcchoujiang_id'], $__UserInfo['id']);
		if ($choujiangBmInfo['id'] > 0 && $choujiangBmInfo['cj_times'] > 0) {
			$showChoujiang = 1;
		}
	}
	$qianshouUrl = $__TckjiaApp . '&site=' . $site_id . '&mod=hexiao&act=qianshou&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:hexiao');
} elseif ($_GET['mod'] == 'orderhexiao') {
	$hexiao_no = !empty($_GET['hexiao_no']) ? addslashes($_GET['hexiao_no']) : '';
	$orderInfo = C::t('#tom_tckjia#tom_tckjia_order')->fetch_by_hexiao_no($hexiao_no);
	$goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($orderInfo['goods_id']);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	$bangKanPrice = C::t('#tom_tckjia#tom_tckjia_kanjia_log')->fetch_all_price_sum(' AND kanjia_id = ' . $orderInfo['kanjia_id'] . ' ');
	$now_kan_price = tom_number_float($goodsInfo['goods_price'] - $bangKanPrice);
	if ($now_kan_price < $goodsInfo['base_price']) {
		$now_kan_price = $goodsInfo['base_price'];
	}
	if ($_GET['act'] == 'hexiao' && $_GET['formhash'] == FORMHASH) {
		$hexiao_pwd = isset($_GET['hexiao_pwd']) ? addslashes($_GET['hexiao_pwd']) : '';
		if ($tckjiaConfig['hexiao_type'] == 2) {
			if (empty($goodsInfo['hexiao_pwd'])) {
				echo 301;
				exit(0);
			}
			if ($goodsInfo['hexiao_pwd'] != $hexiao_pwd) {
				echo 302;
				exit(0);
			}
		}
		$updateData = array();
		$updateData['order_status'] = 3;
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['hexiao_time'] = TIMESTAMP;
		C::t('#tom_tckjia#tom_tckjia_order')->update($orderInfo['id'], $updateData);
		if ($tckjiaConfig['balance_type'] == 1 && $orderInfo['balance_status'] == 0) {
			include DISCUZ_ROOT . './source/plugin/tom_tckjia/module/balance.php';
		}
		echo 200;
		exit(0);
	}
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/tom_tckjia/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$picurl = $goodsInfo['picurl'];
		}
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	$isTcshopClerk = 0;
	$clerkListTmp = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(' AND tcshop_id=' . $orderInfo['tcshop_id'] . ' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 1);
	if (!empty($clerkListTmp[0]['id']) || $tcshopInfo['user_id'] == $__UserInfo['id']) {
		$isTcshopClerk = 1;
	}
	$hexiaoUserInfo = array();
	if ($orderInfo['order_status'] == 3) {
		$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);
	}
	$showHexiaoBox = 1;
	if ($tckjiaConfig['hexiao_type'] == 1 && $isTcshopClerk == 0) {
		$showHexiaoBox = 2;
	}
	$showBtnBox = 0;
	if ($orderInfo['order_status'] == 2) {
		$showBtnBox = 1;
	}
	$hexiaoTimeStatus = 1;
	if (TIMESTAMP > $goodsInfo['hexiao_time']) {
		$hexiaoTimeStatus = 2;
	}
	$hexiaoUrl = $__TckjiaApp . '&site=' . $site_id . '&mod=orderhexiao&act=hexiao&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:orderhexiao');
} elseif ($_GET['mod'] == 'mykjialist') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$pagesize = 10;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_count(' AND user_id = ' . $__UserInfo['id'] . ' ');
	$kanjiaListTmp = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, $pagesize);
	$kanjiaList = array();
	foreach ($kanjiaListTmp as $key => $value) {
		$kanjiaList[$key] = $value;
		$goodsInfoTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($value['goods_id']);
		if (!preg_match('/^http/', $goodsInfoTmp['picurl'])) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfoTmp['picurl'];
		} else {
			$picurl = $goodsInfoTmp['picurl'];
		}
		$kanjiaList[$key]['goodsInfo'] = $goodsInfoTmp;
		$kanjiaList[$key]['goodsInfo']['picurl'] = $picurl;
		$kanjiaList[$key]['goodsInfo']['hexiao_time'] = dgmdate($goodsInfoTmp['hexiao_time'], 'Y-m-d', $tomSysOffset);
		$kanjiaList[$key]['goodsInfo']['link'] = $__TckjiaApp . '&site=' . $value['site_id'] . '&mod=details&goods_id=' . $goodsInfoTmp['id'];
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = $__TckjiaApp . ('&site=' . $site_id . '&mod=mykjialist&page=' . $prePage);
	$nextPageUrl = $__TckjiaApp . ('&site=' . $site_id . '&mod=mykjialist&page=' . $nextPage);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:mykjialist');
} elseif ($_GET['mod'] == 'jubao') {
	$jian_id = intval($_GET['jian_id']) > 0 ? intval($_GET['jian_id']) : 0;
	$goods_id = intval($_GET['goods_id']) > 0 ? intval($_GET['goods_id']) : 0;
	$backUrl = $__TckjiaApp . '&site=' . $site_id . '&mod=jian&kid=' . $jian_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:jubao');
} elseif ($_GET['mod'] == 'jubaoinfo') {
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 1;
	$jian_id = intval($_GET['jian_id']) > 0 ? intval($_GET['jian_id']) : 0;
	$goods_id = intval($_GET['goods_id']) > 0 ? intval($_GET['goods_id']) : 0;
	if ($_GET['act'] == 'jubao' && $_GET['formhash'] == FORMHASH) {
		$tel = isset($_GET['tel']) ? daddslashes($_GET['tel']) : '';
		$content = isset($_GET['content']) ? daddslashes(diconv(urldecode($_GET['content']), 'utf-8')) : '';
		$insertData = array();
		$insertData['user_id'] = $__UserInfo['id'];
		$insertData['goods_id'] = $goods_id;
		$insertData['type'] = $type;
		$insertData['content'] = $content;
		$insertData['tel'] = $tel;
		$insertData['add_time'] = TIMESTAMP;
		C::t('#tom_tckjia#tom_tckjia_jubao')->insert($insertData);
		echo 200;
		exit(0);
	}
	$jubaoInfoUrl = $__TckjiaApp . '&site=' . $site_id . '&mod=jubaoinfo';
	$succBackUrl = $__TckjiaApp . '&site=' . $site_id . '&mod=jian&kid=' . $jian_id;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tckjia:jubaoinfo');
} elseif ($_GET['mod'] == 'fabu') {
	include DISCUZ_ROOT . './source/plugin/tom_tckjia/module/fabu.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tckjia/module/edit.php';
} elseif ($_GET['mod'] == 'editstock') {
	include DISCUZ_ROOT . './source/plugin/tom_tckjia/module/editstock.php';
} elseif ($_GET['mod'] == 'editpwd') {
	include DISCUZ_ROOT . './source/plugin/tom_tckjia/module/editpwd.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tckjia/module/upload.php';
} else {
	tomheader('location:' . $_G['siteurl'] . $__TckjiaApp . ('&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();