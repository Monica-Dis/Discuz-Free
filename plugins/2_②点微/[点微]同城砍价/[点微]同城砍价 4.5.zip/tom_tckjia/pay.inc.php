<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tckjiaConfig = $_G['cache']['plugin']['tom_tckjia'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

include DISCUZ_ROOT.'./source/plugin/tom_tckjia/class/function.core.php';

$act = isset($_GET['act'])? addslashes($_GET['act']):"";

$__TckjiaApp = 'plugin.php?id=tom_tckjia';

if($act == "order" && $_GET['formhash'] == FORMHASH){
   
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $goods_id           = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $kanjia_id          = isset($_GET['kanjia_id'])? intval($_GET['kanjia_id']):0;
    $address_id         = isset($_GET['address_id'])? intval($_GET['address_id']):0;
    $xm                 = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $order_beizu        = isset($_GET['order_beizu'])? daddslashes($_GET['order_beizu']):'';
    
    $addressInfo = array('xm'=>'','tel'=>'','area_str'=>'','info'=>'');
    
    $userInfo       = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $goodsInfo      = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($goods_id);
    $tcshopInfo     = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
    $kanjiaInfo     = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_by_id($kanjia_id);
    
    if($address_id > 0){
        $addressInfo = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
    }

    if(empty($userInfo) || empty($goodsInfo) || empty($tcshopInfo) || empty($kanjiaInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    if($kanjiaInfo['user_id'] != $userInfo['id'] || $kanjiaInfo['goods_id'] != $goodsInfo['id']){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $isHaveOrderListTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list(" AND kanjia_id={$kanjiaInfo['id']} AND goods_id={$goodsInfo['id']} AND user_id={$userInfo['id']} AND order_status IN(1,2,3) "," ORDER BY id DESC ",0,10);
    if(is_array($isHaveOrderListTmp) && !empty($isHaveOrderListTmp)){
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['stock_num'] <= $goodsInfo['sale_num']){
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
    $pay_price = 0;
    if($tckjiaConfig['open_ding_price'] == 1 && $goodsInfo['open_ding_pay'] == 1 ){
        $pay_price = $goodsInfo['ding_price'];
    }else{
        $bangKanPrice = C::t('#tom_tckjia#tom_tckjia_kanjia_log')->fetch_all_price_sum(" AND kanjia_id = {$kanjiaInfo['id']} ");
        $pay_price = tom_number_float($goodsInfo['goods_price'] - $bangKanPrice);
        if($pay_price < $goodsInfo['base_price']){
            $pay_price = $goodsInfo['base_price'];
        }
    }
    
    if($pay_price > 0){
        
        $order_no  = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        $hexiao_no = date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['user_id']          = $user_id;
        $insertData['tj_hehuoren_id']   = $kanjiaInfo['tj_hehuoren_id'];
        $insertData['order_no']         = $order_no;
        $insertData['hexiao_no']        = $hexiao_no;
        $insertData['kanjia_id']        = $kanjia_id;
        $insertData['goods_id']         = $goodsInfo['id'];
        $insertData['tcshop_id']        = $tcshopInfo['id'];
        $insertData['goods_title']      = $goodsInfo['title'];
        if($goodsInfo['peisong_type'] == 2 || $goodsInfo['peisong_type'] == 3){
            $insertData['xm']             = $addressInfo['xm'];
            $insertData['tel']            = $addressInfo['tel'];
            $insertData['address']        = $addressInfo['area_str']." ".$addressInfo['info'];  
        }else{
            $insertData['xm']               = $xm;
            $insertData['tel']              = $tel;
            $insertData['address']          = '';
        }
        $insertData['openid']           = $userInfo['openid'];
        $insertData['pay_price']        = $pay_price;
        $insertData['peisong_type']     = $goodsInfo['peisong_type'];
        $insertData['peisong_status']   = 0;
        $insertData['order_beizu']      = $order_beizu;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tckjia#tom_tckjia_order')->insert($insertData)){
            $orderId = C::t('#tom_tckjia#tom_tckjia_order')->insert_id();
            
            DB::query("UPDATE ".DB::table('tom_tckjia_goods')." SET sale_num=sale_num+1 WHERE id='{$goodsInfo['id']}' ", 'UNBUFFERED');
            
            if($kanjiaInfo['kan_status'] != 1){
                $updateData = array();
                $updateData['kan_status'] = 1;
                C::t('#tom_tckjia#tom_tckjia_kanjia')->update($kanjiaInfo['id'], $updateData);
            }
            
            $pay_hosts = '';
            $tckjiaConfig['tongcheng_hosts'] = trim($tckjiaConfig['tongcheng_hosts']);
            $tckjiaConfig['kjia_hosts']      = trim($tckjiaConfig['kjia_hosts']);
            if($tckjiaConfig['open_only_hosts'] == 1 && !empty($tckjiaConfig['tongcheng_hosts']) && !empty($tckjiaConfig['kjia_hosts'])){
                if(strpos($_G['siteurl'],$tckjiaConfig['tongcheng_hosts']) === FALSE && strpos($_G['siteurl'],$tckjiaConfig['kjia_hosts']) !== FALSE){
                    $pay_hosts = str_replace($tckjiaConfig['kjia_hosts'], $tckjiaConfig['tongcheng_hosts'], $_G['siteurl']);
                    if($tckjiaConfig['must_http'] == 1){
                        if(strpos($pay_hosts,'https') === FALSE){
                            $pay_hosts = str_replace("http", "https", $pay_hosts);
                        }
                    }
                }
            }

            $goods_url = $__TckjiaApp.'&site='.$site_id.'&mod=details&goods_id='.$goodsInfo['id'];
            $back_url  = $__TckjiaApp."&site={$site_id}&mod=mylist";

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tckjia';          
            $insertData['order_no']        = $order_no;                 
            $insertData['goods_id']        = $goodsInfo['id'];         
            $insertData['goods_name']      = $goodsInfo['title'];      
            $insertData['goods_beizu']     = $goodsInfo['title'];      
            $insertData['goods_url']       = $goods_url;               
            $insertData['succ_back_url']   = $back_url; 
            $insertData['fail_back_url']   = $back_url;  
            $insertData['allow_alipay']    = 1;             
            $insertData['pay_price']       = $pay_price;    
            $insertData['order_status']    = 1;             
            $insertData['add_time']        = TIMESTAMP;     
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'    => 200,
                    'payurl'    => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }
        
    }else{
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        $hexiao_no = date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['user_id']          = $user_id;
        $insertData['tj_hehuoren_id']   = $kanjiaInfo['tj_hehuoren_id'];
        $insertData['order_no']         = $order_no;
        $insertData['hexiao_no']        = $hexiao_no;
        $insertData['kanjia_id']        = $kanjia_id;
        $insertData['goods_id']         = $goodsInfo['id'];
        $insertData['tcshop_id']        = $tcshopInfo['id'];
        $insertData['goods_title']      = $goodsInfo['title'];
        if($goodsInfo['peisong_type'] == 2 || $goodsInfo['peisong_type'] == 3){
            $insertData['xm']             = $addressInfo['xm'];
            $insertData['tel']            = $addressInfo['tel'];
            $insertData['address']        = $addressInfo['area_str']." ".$addressInfo['info'];  
        }else{
            $insertData['xm']               = $xm;
            $insertData['tel']              = $tel;
            $insertData['address']          = '';
        }
        $insertData['openid']           = $userInfo['openid'];
        $insertData['pay_price']        = 0;
        $insertData['peisong_type']     = $goodsInfo['peisong_type'];
        $insertData['peisong_status']   = 0;
        $insertData['order_beizu']      = $order_beizu;
        $insertData['order_status']     = 2;
        $insertData['order_time']       = TIMESTAMP;
        $insertData['pay_time']         = TIMESTAMP;
        if(C::t('#tom_tckjia#tom_tckjia_order')->insert($insertData)){
            
            $orderId = C::t('#tom_tckjia#tom_tckjia_order')->insert_id();

            DB::query("UPDATE ".DB::table('tom_tckjia_goods')." SET sale_num=sale_num+1 WHERE id='{$goodsInfo['id']}' ", 'UNBUFFERED');

            $outArr = array(
                'status'    => 200,
                'jump_url'  => $__TckjiaApp."&site={$site_id}&mod=mylist",
            );
            echo json_encode($outArr); exit;

        }else{
            $outArr = array(
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }
        
    }    
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}