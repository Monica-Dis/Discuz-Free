<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=kanjia";

$goods_id       = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
$user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = "";
if($goods_id > 0){
    $goodsInfoTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($goods_id);
    if(!empty($goodsInfoTmp) && $goodsInfoTmp['user_id'] == $__UserInfo['id']){
        $where .= " AND goods_id = {$goods_id} ";
    }else{
        $where .= " AND goods_id = 999999999 ";
    }
}else{
    $tcshopIdsListTmp = C::t("#tom_tcshop#tom_tcshop")->fetch_all_field_list(" AND user_id = {$__UserInfo['id']} ", 'id');
    $tcshopIdsList = array();
    if(!empty($tcshopIdsListTmp)){
        foreach($tcshopIdsListTmp as $key => $value){
            $tcshopIdsList[] = $value['id'];
        }
    }
    if(!empty($tcshopIdsList)){
        $tcshopIdsStr = implode(',', $tcshopIdsList);
        $where .= " AND tcshop_id IN({$tcshopIdsStr}) ";
    }else{
        $where .= " AND tcshop_id = 999999999 ";
    }
}

if($user_id > 0){
    $where .= " AND user_id = {$user_id} ";
};

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_count($where);
$tckjiaListTmp = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_list($where," ORDER BY add_time DESC,id DESC ",$start,$pagesize);
$tckjiaList = array();
if(!empty($tckjiaListTmp)){
    foreach ($tckjiaListTmp as $key => $value) {
        $tckjiaList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $orderInfoTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list(" AND kanjia_id = {$value['id']}", 'ORDER BY id DESC', 0, 1);
        $priceSumTmp = C::t('#tom_tckjia#tom_tckjia_kanjia_log')->fetch_all_price_sum(" AND kanjia_id = {$value['id']}");
        $goodsInfoTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($value['goods_id']);
        $goodsInfoTmp['picurl'] = get_file_url($goodsInfoTmp['picurl']);
        
        $tckjiaList[$key]['userInfo']           = $userInfoTmp;
        $tckjiaList[$key]['orderInfo']          = $orderInfoTmp[0];
        $tckjiaList[$key]['priceSum']           = $priceSumTmp;
        $tckjiaList[$key]['goodsInfo']          = $goodsInfoTmp;
        $tckjiaList[$key]['add_time']           = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&goods_id={$goods_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tckjia:pcshopadmin/kanjia");