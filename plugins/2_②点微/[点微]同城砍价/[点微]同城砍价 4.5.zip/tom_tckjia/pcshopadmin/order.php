<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=order";

$order_id       = isset($_GET['order_id'])? intval($_GET['order_id']):0;
$site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
$user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$tel            = !empty($_GET['tel'])? trim(addslashes($_GET['tel'])):'';
$start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
$end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$tcshopIdsListTmp = C::t("#tom_tcshop#tom_tcshop")->fetch_all_field_list(" AND user_id = {$__UserInfo['id']} ", 'id');
$tcshopIdsList = array();
if(!empty($tcshopIdsListTmp)){
    foreach($tcshopIdsListTmp as $key => $value){
        $tcshopIdsList[] = $value['id'];
    }
}
$where = "";
if(!empty($tcshopIdsList)){
    $tcshopIdsStr = implode(',', $tcshopIdsList);
    $where .= " AND tcshop_id IN({$tcshopIdsStr}) ";
}else{
    $where .= " AND tcshop_id = 999999999 ";
}

if(!empty($order_id)){
    $where.= " AND id='{$order_id}' ";
}
if(!empty($site_id)){
    $where.= " AND site_id={$site_id} ";
}
if(!empty($goods_id)){
    $where.= " AND goods_id={$goods_id} ";
}
if(!empty($user_id)){
    $where.= " AND user_id={$user_id} ";
}
if(!empty($tel)){
    $where.= " AND tel='{$tel}' ";
}
if(!empty($start_time)){
    $startTime = strtotime($start_time);
    $where.=" AND order_time >=  {$startTime} ";
}
if(!empty($end_time)){
    $endTime = strtotime($end_time);
    $where.=" AND order_time < {$endTime} ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count($where);
$orderListTmp = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
$orderList = array();
if(!empty($orderListTmp)){
    foreach($orderListTmp as $key => $value){
        $orderList[$key] = $value;
        
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $hexiaoUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        $goodsInfoTmp = C::t("#tom_tckjia#tom_tckjia_goods")->fetch_by_id($value['goods_id']);
        $goodsInfoTmp['picurl'] = get_file_url($goodsInfoTmp['picurl']);
        
        $site_name_tmp = $Lang['sites_one'];
        if($value['site_id'] > 1){
            $siteInfoTmp = $sitesList[$value['site_id']];
            $site_name_tmp = $siteInfoTmp['name'];
        }
        
        $allowQianshouTmp = 0;
        if($value['peisong_status'] == 1 && $value['peisong_time'] > 0){
            if(TIMESTAMP > ($value['peisong_time'] + 86400*$tckjiaConfig['shop_qianshou_days'])){
                $allowQianshouTmp = 1;
            }
        }
        
        $orderList[$key]['userInfo']            = $userInfoTmp;
        $orderList[$key]['hexiaoUserInfo']      = $hexiaoUserInfoTmp;
        $orderList[$key]['goodsInfo']           = $goodsInfoTmp;
        $orderList[$key]['site_name']           = $site_name_tmp;
        $orderList[$key]['allowQianshou']       = $allowQianshouTmp;
        $orderList[$key]['orderTime']           = dgmdate($value['order_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $orderList[$key]['payTime']             = dgmdate($value['pay_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $orderList[$key]['hexiaoTime']          = dgmdate($value['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&order_id={$order_id}&site_id={$site_id}&goods_id={$goods_id}&user_id={$user_id}"
           ."&tel={$tel}&start_time={$start_time}&end_time={$end_time}";

if($goods_id > 0 && !empty($orderList)){
    $countOrderStatus1 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=1 ");
    $countOrderStatus2 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=2 ");
    $countOrderStatus3 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=3 ");
    $countOrderStatus4 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=4 ");
    $countOrderStatus5 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=5 ");
}

$fahuoUrl    = $__TckjiaApp.'&site='.$site_id.'&mod=orderinfo&act=fahuo&formhash='.$formhash;
$qianshouUrl = $__TckjiaApp.'&site='.$site_id.'&mod=orderinfo&act=qianshou&formhash='.$formhash;
    
$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tckjia:pcshopadmin/order");