<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($goods_id);
if(empty($goodsInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($__UserInfo['id'] != $goodsInfo['user_id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=edit&goods_id={$goods_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('title')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $style_id           = isset($_GET['style_id'])? addslashes($_GET['style_id']):'baise';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $tcchoujiang_id     = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):0;
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = strtotime($end_time);
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = strtotime($hexiao_time);
    $goods_price        = isset($_GET['goods_price'])? floatval($_GET['goods_price']):0.00;
    $base_price         = isset($_GET['base_price'])? floatval($_GET['base_price']):0.00;
    $stock_num          = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
    $open_tiqian_pay    = isset($_GET['open_tiqian_pay'])? intval($_GET['open_tiqian_pay']):0;
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? addslashes($_GET['ding_price']):'';
    $type               = isset($_GET['type'])? intval($_GET['type']):1;
    $kanjia_num         = isset($_GET['kanjia_num'])? intval($_GET['kanjia_num']):0;
    $kanjia_min_price   = isset($_GET['kanjia_min_price'])? floatval($_GET['kanjia_min_price']):0;
    $kanjia_max_price   = isset($_GET['kanjia_max_price'])? floatval($_GET['kanjia_max_price']):0;
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $peisong_type       = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $guize              = isset($_GET['guize'])? addslashes($_GET['guize']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    
    $virtual_clicks     = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $virtual_user       = isset($_GET['virtual_user'])? intval($_GET['virtual_user']):0;
    $mp3_link           = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $share_title        = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc         = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $paixu              = isset($_GET['paixu'])? intval($_GET['paixu']):1000;
    
    $yongjin_bili       = isset($_GET['yongjin_bili'])? intval($_GET['yongjin_bili']):0;
    
    $photoArr = array();
    foreach($_GET['photo'] as $key => $value){
        $value = addslashes($value);
        if(!empty($value)){
            $photoArr[] = $value;
        }
    }
    
    if($stock_num < $goodsInfo['sale_num']){
        $stock_num = $goodsInfo['sale_num'];
    }
    
    if($__Admin['admin'] == 'admin'){
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    }else if($__Admin['admin'] == 'shopadmin'){
        $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($goodsInfo['tcshop_id']);
    }
    
    $updateData = array();
    if($__Admin['admin'] == 'admin'){
        $updateData['site_id']            = $tcshopInfo['site_id'];
        $updateData['user_id']            = $tcshopInfo['user_id'];
        $updateData['tcshop_id']          = $tcshopInfo['id'];
    }
    $updateData['style_id']           = $style_id;
    $updateData['cate_id']            = $cate_id;
    $updateData['title']              = $title;
    $updateData['start_time']         = $start_time;
    $updateData['end_time']           = $end_time;
    $updateData['hexiao_time']        = $hexiao_time;
    $updateData['goods_price']        = $goods_price;
    $updateData['base_price']         = $base_price;
    $updateData['stock_num']          = $stock_num;
    $updateData['open_tiqian_pay']    = $open_tiqian_pay;
    if($tckjiaConfig['open_ding_price'] == 1){
        $updateData['open_ding_pay']      = $open_ding_pay;
        $updateData['ding_price']         = $ding_price;
    }
    $updateData['type']               = $type;
    $updateData['kanjia_num']         = $kanjia_num;
    $updateData['kanjia_min_price']   = $kanjia_min_price;
    $updateData['kanjia_max_price']   = $kanjia_max_price;
    $updateData['hexiao_pwd']         = $hexiao_pwd;
    if($tckjiaConfig['open_peisong_type'] == 1){
        $updateData['peisong_type']       = $peisong_type;
    }
    $updateData['admin_edit']         = $admin_edit;
    $updateData['guize']              = $guize; 
    $updateData['content']            = $content;
    $updateData['picurl']             = $picurl;
    $updateData['toppic']             = $toppic;
    $updateData['mp3_link']           = $mp3_link;
    $updateData['share_title']        = $share_title;
    $updateData['share_desc']         = $share_desc;
    
    if($__Admin['admin'] == 'admin'){
        $updateData['tcchoujiang_id']     = $tcchoujiang_id;
        $updateData['virtual_clicks']     = $virtual_clicks;
        $updateData['virtual_user']       = $virtual_user;
        $updateData['paixu']              = $paixu;
        $updateData['yongjin_bili']       = $yongjin_bili;
    }
    
    if($__Admin['admin'] == 'shopadmin' && $tckjiaConfig['must_shenhe'] == 1){
        $updateData['shenhe_status']       = 2;
    }
    
    $updateData['part1']            = TIMESTAMP;
    if(C::t('#tom_tckjia#tom_tckjia_goods')->update($goods_id, $updateData)){
        
        C::t('#tom_tckjia#tom_tckjia_goods_photo')->delete_by_goods_id($goods_id);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']     = $goods_id;
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tckjia#tom_tckjia_goods_photo')->insert($insertData);
            }
        }
        
        $insertData = array();
        if($__Admin['admin'] == 'admin'){
            $insertData['is_admin']     = 1;
        }
        $insertData['goods_id']     = $goods_id;
        $insertData['change_num']   = $stock_num;
        $insertData['change_time']  = TIMESTAMP;
        C::t('#tom_tckjia#tom_tckjia_stock_log')->insert($insertData);
        
        $goodsInfoTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($goods_id);
        update_kanjia_status($goodsInfoTmp);
        
        if($__Admin['admin'] == 'shopadmin' && $tckjiaConfig['must_shenhe'] == 1){
            $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUser && !empty($toUser['openid'])){

                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                $access_token = $weixinClass->get_access_token();

                if($access_token && !empty($toUser['openid'])  ){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl'].$__TckjiaApp."&site={$site_id}&mod=index");
                    $smsData = array(
                        'first'         => '['.$tcshopInfo['name'].']'.$Lang['shenhe_template_edit'],
                        'keyword1'      => $tongchengConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                        'remark'        => ''
                    );
                    $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($goodsInfo['tcshop_id']);

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tckjia#tom_tckjia_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$value['id']] = $value;
    }
}

$photoListTmp = C::t('#tom_tckjia#tom_tckjia_goods_photo')->fetcH_all_list(" AND goods_id = {$goods_id} ", 'ORDER BY add_time DESC,id DESC', 0, 20);
$photoList = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $photoList[$key] = $value;
        $photoList[$key]['picurlTmp'] = get_file_url($value['picurl']);
    }
}

$picurl         = get_file_url($goodsInfo['picurl']);
$toppic         = get_file_url($goodsInfo['toppic']);

$goodsInfo['guize'] = stripcslashes($goodsInfo['guize']);
$goodsInfo['content'] = stripcslashes($goodsInfo['content']);

$start_time     = dgmdate($goodsInfo['start_time'],"Y-m-d H:i:s",$tomSysOffset);
$end_time       = dgmdate($goodsInfo['end_time'],"Y-m-d H:i:s",$tomSysOffset);
$hexiao_time    = dgmdate($goodsInfo['hexiao_time'],"Y-m-d H:i:s",$tomSysOffset);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tckjia:pcadmin/edit");