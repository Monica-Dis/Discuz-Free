<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=list";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'show' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );

    $goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;

    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tckjia#tom_tckjia_goods')->update($goods_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );

    $goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;

    $updateData = array();
    $updateData['status'] = 2;
    C::t('#tom_tckjia#tom_tckjia_goods')->update($goods_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'shenhe' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $goods_id       = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $goodsInfo = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_by_id($goods_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']);
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status'] = 1;
        C::t('#tom_tckjia#tom_tckjia_goods')->update($goods_id, $updateData);

        $shenhe = str_replace('{TITLE}', $goodsInfo['title'], $Lang['template_tckjia_shenhe_ok']);
        
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tckjiaConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tckjia&site={$goodsInfo['site_id']}&mod=jian&goods_id=".$goodsInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tckjiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tckjia#tom_tckjia_goods')->update($goods_id, $updateData);
        
        $shenhe = str_replace('{TITLE}', $goodsInfo['title'], $Lang['template_tckjia_shenhe_no']);
        
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tckjiaConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tckjia_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tckjia&site={$goodsInfo['site_id']}&mod=edit&goods_id=".$goodsInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tckjiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0; 
    
    $count = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND goods_id={$goods_id} ");
    if($orderGoodsCount > 0){
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );    
        echo json_encode($outArr); exit;
    }
    
    $countKj = C::t('#tom_tckjia#tom_tckjia_kanjia')->fetch_all_count(" AND goods_id={$goods_id} ");
    if($countKj > 0){
        $outArr = array(
            'code'=> 200,
            'status'=> 302,
        );    
        echo json_encode($outArr); exit;
    }
    
    C::t('#tom_tckjia#tom_tckjia_goods')->delete_by_id($goods_id);
    C::t('#tom_tckjia#tom_tckjia_goods_photo')->delete_by_goods_id($goods_id);

    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$goods_title        = isset($_GET['goods_title'])? addslashes($_GET['goods_title']):'';
$cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
$status             = isset($_GET['status'])? intval($_GET['status']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tckjia#tom_tckjia_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$value['id']] = $value;
    }
}

$where = "";
if(!empty($site_id)){
    $where.= " AND site_id={$site_id} ";
}
if($cate_id > 0){
    $where.= " AND cate_id={$cate_id} ";
}
if(!empty($status)){
    $where.= " AND status={$status} ";
}
if(!empty($shenhe_status)){
    $where.= " AND shenhe_status={$shenhe_status} ";
}

$start = ($page - 1)*$pagesize;
$count     = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_like_count($where,$goods_title);
$goodsListTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_like_list($where," ORDER BY id DESC ",$start,$pagesize,$goods_title);
$goodsList = array();
if(!empty($goodsListTmp)){
    foreach ($goodsListTmp as $key => $value) {
        $goodsList[$key] = $value;
        
        $siteInfoTmp        = $sitesList[$value['site_id']];
        $cateInfoTmp        = $cateList[$value['cate_id']];
        
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $tcshopUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfoTmp['user_id']); 
        
        
        $goodsList[$key]['picurl']          = get_file_url($value['picurl']);
        $goodsList[$key]['siteInfo']        = $siteInfoTmp;
        $goodsList[$key]['cateInfo']        = $cateInfoTmp;
        $goodsList[$key]['tcshopInfo']      = $tcshopInfoTmp;
        $goodsList[$key]['tcshopUserInfo']  = $tcshopUserInfoTmp;
        $goodsList[$key]['start_time']      = dgmdate($value['start_time'],"Y-m-d H:i",$tomSysOffset);
        $goodsList[$key]['end_time']        = dgmdate($value['end_time'],"Y-m-d H:i",$tomSysOffset);
        $goodsList[$key]['hexiao_time']     = dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
        $goodsList[$key]['add_time']        = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&goods_title={$goods_title}"
           ."&cate_id={$cate_id}&status={$status}&shenhe_status={$shenhe_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tckjia:pcadmin/list");