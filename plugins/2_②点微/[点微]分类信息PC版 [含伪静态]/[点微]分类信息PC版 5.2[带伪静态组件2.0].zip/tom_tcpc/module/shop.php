<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($__Mobile == 1 && $tcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=index");exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list_shop.php';

$cateListTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list(" AND parent_id=0 "," ORDER BY csort ASC,id DESC ",0,500);
$cateList = $cateIndexList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        
        $picurlTmp = '';
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurlTmp = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurlTmp = $value['picurl'];
        }
        $value['picurl'] = $picurlTmp;
        
        $value['link'] = tom_tcpc_url('shoplist',$site_id,array('cate_id'=>$value['id']));
        
        $cateList[$value['id']] = $value;
        $cateIndexList[$value['id']] = $value;
    }
}

$cateChildListTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list(" AND parent_id > 0 "," ORDER BY csort ASC,id DESC ",0,500);
$cateChildList = array();
if(is_array($cateChildListTmp) && !empty($cateChildListTmp)){
    foreach($cateChildListTmp as $key => $value){
        $value['link'] = tom_tcpc_url('shoplist',$site_id,array('cate_id'=>$value['parent_id'],'cate_child_id'=>$value['id']));
        
        $cateChildList[$value['id']] = $value;
        $cateList[$value['parent_id']]['cateChildList'][$value['id']] = $value;
    }
}

if(is_array($cateIndexList) && !empty($cateIndexList)){
    foreach($cateIndexList as $key => $value){
        $i = 1;
        foreach($cateList[$value['id']]['cateChildList'] as $k => $v){
            if($i <= 2){
                $cateIndexList[$value['id']]['cateChildList'][] = $v;
            }
            $i++;
        }
    }
}

$indexShowCateList = array();
$shopCatesStr = trim($tcpcConfig['shop_cates_str']);
$shopCatesStr = trim($shopCatesStr, '|');
if(!empty($shopCatesStr)){
    $shopCatesArr = explode('|', $shopCatesStr);
    foreach ($shopCatesArr as $key => $value){
        $value = intval($value);
        if($value > 0 && isset($cateList[$value])){
            $indexShowCateList[$value] = $cateList[$value];
        }
    }
}
if(empty($indexShowCateList)){
    $indexShowCateList = $cateList;
}

$shopCatesNum = 6;
if($tcpcConfig['shop_cates_num'] > 0){
    $shopCatesNum = $tcpcConfig['shop_cates_num'];
}
$tcshopListTmp = array();
if(is_array($indexShowCateList) && !empty($indexShowCateList)){
    foreach($indexShowCateList as $key => $value){
        if($value['id'] > 0){
            $where = " AND status=1 AND shenhe_status=1 AND cate_id = {$value['id']} ";
            if(!empty($sql_in_site_ids)){
                $where .= " AND site_id IN({$sql_in_site_ids}) ";
            }
            $order = " ORDER BY topstatus DESC, toprand DESC,vip_rank DESC,clicks DESC,id DESC ";
            $cateTcshopList = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list($where,$order,0,$shopCatesNum);
            if(is_array($cateTcshopList) && !empty($cateTcshopList)){
                foreach($cateTcshopList as $k => $v){
                    $tcshopListTmp[] = $v;
                }
            }
        }
    }
}
$tcshopList = tom_handle_shop($tcshopListTmp);

$indexTcshopList = array();
if(is_array($tcshopList) && !empty($tcshopList)){
    foreach($tcshopList as $key => $value){
        $indexTcshopList[$value['cate_id']][] = $value;
    }
}

$focuspicListTmp = C::t('#tom_tcpc#tom_tcpc_focuspic')->fetch_all_list(" AND site_id={$site_id} AND type=3 "," ORDER BY fsort ASC,id DESC ");
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
}else if($site_id > 1){
    $focuspicListTmp = C::t('#tom_tcpc#tom_tcpc_focuspic')->fetch_all_list(" AND site_id=1 AND type=3 "," ORDER BY fsort ASC,id DESC ");
}
$focuspicList = array();
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
    foreach($focuspicListTmp as $key => $value){
        $focuspicList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $focuspicList[$key]['picurl'] = $picurl;
        $focuspicList[$key]['link'] = str_replace("{site}",$site_id, $value['link']);
    }
}
$focuspicCount = count($focuspicList);

$newWhere = " AND status=1 AND shenhe_status=1 ";
if(!empty($sql_in_site_ids)){
    $newWhere .= " AND site_id IN({$sql_in_site_ids}) ";
}
$newTcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list($newWhere," ORDER BY id DESC ",0,4);
$newTcshopList = tom_handle_shop($newTcshopListTmp);

$seo_title          = $tcpcConfig['seo_shop_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);

$seo_keywords       = $tcpcConfig['seo_shop_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);

$seo_description    = $tcpcConfig['seo_shop_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcpc:shop");