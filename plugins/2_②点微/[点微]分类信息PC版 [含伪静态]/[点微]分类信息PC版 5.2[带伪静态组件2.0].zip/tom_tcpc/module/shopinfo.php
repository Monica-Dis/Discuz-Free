<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list_shop.php';

if(isset($_GET['dpid'])){
    $tcshop_id = intval($_GET['dpid'])>0? intval($_GET['dpid']):0;
}else{
    $tcshop_id = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
}

if($__Mobile == 1 && $tcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=details&dpid={$tcshop_id}");exit;
}

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);

if($tcshopInfo['status'] == 1 && $tcshopInfo['shenhe_status'] == 1){
}else{
    dheader('location:'."{$shopUrl}");exit;
}

$vipInfo = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_by_id($tcshopInfo['vip_id']);
$cateInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($tcshopInfo['cate_id']);
$cateChildInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($tcshopInfo['cate_child_id']);

$photoListTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(" AND tcshop_id={$tcshop_id} AND type_id IN (1,2) ","ORDER BY type_id DESC,paixu ASC,id ASC",0,100);
$photoCount = count($photoListTmp);
$photoList = $topPhotoList = array();
$videoPicurl = '';
$i = 1;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach ($photoListTmp as $key => $value){
        if($tongchengConfig['open_yun'] == 2 && !empty($value['oss_picurl']) && $value['oss_status'] == 1){
            $picurlTmp = $value['oss_picurl'];
        }else if($tongchengConfig['open_yun'] == 3 && !empty($value['qiniu_picurl'])  && $value['qiniu_status'] == 1){
            $picurlTmp = $value['qiniu_picurl'];
        }else{
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurlTmp = $_G['siteurl'].$value['picurl'];
                }
            }else{
                $picurlTmp = $value['picurl'];
            }
        }
        if($value['type_id'] == 1){
            $photoList[$key] = $value;
            $photoList[$key]['picurl'] = $picurlTmp;
        }
        if($value['type_id'] == 1 && empty($videoPicurl)){
            $videoPicurl = $picurlTmp;
        }
        if($i <= 5){
            $topPhotoList[] = $picurlTmp;
        }
        $i++;
    }
}

if(!empty($tcshopInfo['video_pic'])){
    if(!preg_match('/^http/', $tcshopInfo['video_pic']) ){
        if(strpos($tcshopInfo['video_pic'], 'source/plugin/tom_') === FALSE){
            $videoPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['video_pic'];
        }else{
            $videoPicurl = $_G['siteurl'].$tcshopInfo['video_pic'];
        }
    }else{
        $videoPicurl = $tcshopInfo['video_pic'];
    }
}

if(!preg_match('/^http/', $vipInfo['picurl']) ){
    if(strpos($vipInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $vipPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vipInfo['picurl'];
    }else{
        $vipPicurl = $_G['siteurl'].$vipInfo['picurl'];
    }
}else{
    $vipPicurl = $vipInfo['picurl'];
}

$content = stripslashes($tcshopInfo['content']);

if($tcshopInfo['admin_edit'] == 0){
    $content = str_replace("\r\n","<br/>",$content);
    $content = str_replace("\n","<br/>",$content);
    $content = str_replace("\r","<br/>",$content);
}
$content = str_replace('src="source/plugin/', 'src="'.$_G['siteurl'].'source/plugin/', $content);
$content = str_replace('src="data/attachment/', 'src="'.$_G['siteurl'].'data/attachment/', $content);

$tabsStr = str_replace("    "," ",$tcshopInfo['tabs']);
$tabsStr = str_replace("   "," ",$tabsStr);
$tabsStr = str_replace("  "," ",$tabsStr);
$tabsArrTmp = explode(' ', $tabsStr);
$tabsArr = array();
if(is_array($tabsArrTmp) && !empty($tabsArrTmp)){
    foreach ($tabsArrTmp as $kk => $vv){
        $vv = trim($vv);
        if(!empty($vv)){
            $tabsArr[$kk]['txt'] = cutstr($vv, 20, '');
            $tabsArr[$kk]['url'] = $_G['siteurl']."plugin.php?id=tom_tcpc&site={$site_id}&mod=shoplist&keyword=".urlencode(trim($vv));
            $i++;
        }
    }
}

if(!preg_match('/^http/', $tcshopInfo['picurl']) ){
    if(strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['picurl'];
    }else{
        $picurl = $_G['siteurl'].$tcshopInfo['picurl'];
    }
}else{
    $picurl = $tcshopInfo['picurl'];
}

## video vr start
$video_flag = $vr_flag = 0;
$video_type = '';
$video_id   = '';
if(strpos($tcshopInfo['video_url'], 'youku.com') !== FALSE){
    preg_match("#sid/(.*)/v.swf#", $tcshopInfo['video_url'], $matches);
    if(is_array($matches) && !empty($matches['1'])){
        $video_type = 'youku';
        $video_id = trim($matches['1']);
        $video_flag = 1;
    }
}else if(strpos($tcshopInfo['video_url'], 'qq.com') !== FALSE){
    preg_match("#vid=([0-9a-zA-Z]*)#", $tcshopInfo['video_url'], $matches);
    if(is_array($matches) && !empty($matches['1'])){
        $video_type = 'qq';
        $video_id = trim($matches['1']);
        $video_flag = 1;
    }
}else if(strpos($tcshopInfo['video_url'], '.mp4') !== FALSE){
    $video_type = 'mp4';
    $video_flag = 1;
}else if(strpos($tcshopInfo['video_url'], '.MOV') !== FALSE){
    $video_type = 'mp4';
    $video_flag = 1;
}else if(!empty($tcshopInfo['video_url'])){
    if(empty($tcshopInfo['vr_url'])){
        $tcshopInfo['vr_url'] = $tcshopInfo['video_url'];
    }
    $tcshopInfo['video_url'] = '';
}
if(!empty($tcshopInfo['vr_url'])){
    $vr_flag = 1;
}
## video vr end
$vrShowBox = $videoShowBox = 0;
if($vipInfo['open_vr'] == 1 && $vr_flag == 1){
    $vrShowBox  = 1;
}
if($vipInfo['open_video'] == 1 && $video_flag == 1){
    $videoShowBox  = 1;
}

$tcshopInfo['tel'] = substr($tcshopInfo['tel'], 0, 3)."*******";

## pinglun start
$pinglunListTmp = C::t('#tom_tcshop#tom_tcshop_pinglun')->fetch_all_list(" AND tcshop_id = {$tcshop_id} ", 'ORDER BY ping_time DESC,id DESC', 0, 20);
$pinglunList = array();
if(is_array($pinglunListTmp) && !empty($pinglunListTmp)){
    
    $pinglunIdsArr = $userIdsArr = array();
    foreach($pinglunListTmp as $key => $value){
        $pinglunIdsArr[] = $value['id'];
        $userIdsArr[] = $value['user_id'];
    }
    
    $pinglunPicListTmp = $replyListTmp = array();
    if(is_array($pinglunIdsArr) && !empty($pinglunIdsArr)){
        $pinglunIdsStr = implode(',', $pinglunIdsArr);
        $pinglunPicArrTmp = C::t('#tom_tcshop#tom_tcshop_pinglun_photo')->fetch_all_list(" AND pinglun_id IN({$pinglunIdsStr}) ", 'ORDER BY id DESC',0,1000);
        if(is_array($pinglunPicArrTmp) && !empty($pinglunPicArrTmp)){
            foreach($pinglunPicArrTmp as $key => $value){
                if(!preg_match('/^http/', $value['picurl']) ){
                    if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                        $value['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                    }else{
                        $value['picurl'] = $_G['siteurl'].$value['picurl'];
                    }

                }else{
                    $value['picurl'] = $value['picurl'];
                }
                
                $pinglunPicListTmp[$value['pinglun_id']][] = $value;
            }
        }
        
        $replyArrTmp = C::t('#tom_tcshop#tom_tcshop_pinglun_reply')->fetch_all_list(" AND ping_id IN({$pinglunIdsStr}) ", "ORDER BY reply_time ASC,id ASC", 0, 1000);
        if(is_array($replyArrTmp) && !empty($replyArrTmp)){
            foreach($replyArrTmp as $key => $value){
                $value['content'] = qqface_replace(dhtmlspecialchars($value['content']));
        
                $replyListTmp[$value['ping_id']][] = $value;
            }
        }
    }
    
    $userListTmp = array();
    if(is_array($userIdsArr) && !empty($userIdsArr)){
        $userIdsStr = implode(',', $userIdsArr);
        $userArrTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC',0, 100);
        if(is_array($userArrTmp) && !empty($userArrTmp)){
            foreach($userArrTmp as $key => $value){
                if(!preg_match('/^http/', $value['picurl']) ){
                    $value['picurl'] = $_G['siteurl'].$value['picurl'];
                }
                $userListTmp[$value['id']] = $value;
            }
        }
    }
    
    foreach($pinglunListTmp as $key => $value){
        $pinglunList[$key] = $value;
        
        $pinglunPicCount = count($pinglunPicListTmp[$value['id']]);
        
        if($pinglunPicCount > $tcshopConfig['pinglun_pic_num']){
            $i = 0;
            foreach($pinglunPicListTmp[$value['id']] as $k => $v){
                if($i < $tcshopConfig['pinglun_pic_num']){
                    $pinglunList[$key]['photoList'][] = $v;
                }
                $i++;
            }
        }else{
            $pinglunList[$key]['photoList'] = $pinglunPicListTmp[$value['id']];
        }
        
        $contentTmp = qqface_replace(dhtmlspecialchars($value['content']));
        
        $contentTmp = str_replace('src="source/plugin/tom_tongcheng/images/pinglun/', 'src="'.$_G['siteurl'].'source/plugin/tom_tongcheng/images/pinglun/', $contentTmp);
        
        $pinglunList[$key]['content'] = $contentTmp;
        $pinglunList[$key]['userInfo'] = $userListTmp[$value['user_id']];
        $pinglunList[$key]['replyList'] = $replyListTmp[$value['id']];
        
    }

}

$pinglunCount = C::t('#tom_tcshop#tom_tcshop_pinglun')->fetch_all_count(" AND tcshop_id = {$tcshopInfo['id']} ");

 ## pinglun end

$baiduMapToName = $tcshopInfo['name'];
$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
$baiduMapToName = urlencode($baiduMapToName);
$baiduMapUrl = "http://api.map.baidu.com/marker?location={$tcshopInfo['latitude']},{$tcshopInfo['longitude']}&title={$baiduMapToName}&content=&output=html";

$ajaxClicksUrl = $_G['siteurl']."plugin.php?id=tom_tcshop:ajax&site={$site_id}&act=clicks&tcshop_id={$tcshop_id}&formhash=".FORMHASH;;

$companyRenzhengStatus = $depositStatus = 0;
if($__ShowTcrenzheng == 1){
    $companyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($tcshopInfo['user_id']);
    if(is_array($companyInfoTmp) && $companyInfoTmp['shenhe_status'] == 1){
        $companyRenzhengStatus = 1;
    }

    $depositInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_by_user_id($tcshopInfo['user_id']);
    if(is_array($depositInfoTmp) && $depositInfoTmp['order_status'] == 2 && $depositInfoTmp['type'] == 2){
        $depositStatus = 1;
    }
}

$tjWhere = " AND status=1 AND shenhe_status=1 AND id != {$tcshopInfo['id']} ";
if(!empty($sql_in_site_ids)){
    $tjWhere .= " AND site_id IN({$sql_in_site_ids}) ";
}
$tjTcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list($tjWhere," ORDER BY topstatus DESC, toprand DESC,vip_rank DESC,clicks DESC,id DESC ",0,4);
$tjTcshopList = tom_handle_shop($tjTcshopListTmp);
$tjTcshopCount = count($tjTcshopList);

$guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 6 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 6 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurlTmp = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurlTmp = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurlTmp;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$mInfoUrl = $_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=details&dpid={$tcshopInfo['id']}";

$infoUrl        = tom_tcpc_url('shopinfo',$site_id,array('tcshop_id'=>$tcshopInfo['id']));
$cateUrl        = tom_tcpc_url('shoplist',$site_id,array('cate_id'=>$tcshopInfo['cate_id']));
$cateChildUrl   = tom_tcpc_url('shoplist',$site_id,array('cate_id'=>$tcshopInfo['cate_id'], 'cate_child_id'=>$tcshopInfo['cate_child_id']));

$seo_title          = $tcpcConfig['seo_shopinfo_title'];
$seo_title          = str_replace("{SHOPNAME}",$tcshopInfo['name'], $seo_title);
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);

$seo_keywords       = $tcpcConfig['seo_shopinfo_keywords'];
$seo_keywords       = str_replace("{SHOPNAME}",$tcshopInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);

$seo_description    = $tcpcConfig['seo_shopinfo_description'];
$seo_description    = str_replace("{SHOPNAME}",$tcshopInfo['name'], $seo_description);
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcpc:shopinfo");