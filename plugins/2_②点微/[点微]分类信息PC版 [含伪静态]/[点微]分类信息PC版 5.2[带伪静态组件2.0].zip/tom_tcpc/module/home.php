<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$user_id = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;

if($__Mobile == 1 && $tcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=home&uid={$user_id}");exit;
}

$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);

if(!$userInfo){
    dheader('location:'."{$indexUrl}");exit;
}

if(!preg_match('/^http/', $userInfo['picurl']) ){
    $userInfo['picurl'] = $_G['siteurl'].$userInfo['picurl'];
}

$tcCount = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count(" AND user_id={$user_id} AND status=1 ");

$companyRenzhengStatus = $personalRenzhengStatus = $depositStatus = 0;
$companyInfo = array();
if($__ShowTcrenzheng == 1){
    $companyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($userInfo['id']);
    if(is_array($companyInfoTmp) && $companyInfoTmp['shenhe_status'] == 1){
        $companyRenzhengStatus = 1;
    }
    $personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_user_id($userInfo['id']);
    if(is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1){
        $personalRenzhengStatus = 1;
    }
    $depositInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_by_user_id($userInfo['id']);
    if(is_array($depositInfoTmp) && $depositInfoTmp['order_status'] == 2){
        $depositStatus = 1;
    }
}

#list start
$page = intval($_GET['page'])>0 ? intval($_GET['page']):1;
$where = " AND status=1 AND shenhe_status=1 AND user_id = {$userInfo['id']} AND model_id IN ({$showModelIdsStr})  ";
$pagesize = 20;
$start = ($page - 1) * $pagesize;
$count = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count($where);
$tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list($where," ORDER BY topstatus DESC,id DESC ",$start,$pagesize);
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list_tongcheng.php';

$pageArr['link'] = tom_tcpc_url('home',$site_id,array('user_id'=>$userInfo['id'],'page'=>'{page}'));
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);
#list end

$guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi=4 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi=4 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$fenleiYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        if($value['weizhi'] == 4){
            $fenleiYouList[] = $guanggaoItemTmp;
        }
    }
}


$seo_title          = $tcpcConfig['seo_home_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{NICKNAME}",$userInfo['nickname'], $seo_title);

$seo_keywords       = $tcpcConfig['seo_home_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{NICKNAME}",$userInfo['nickname'], $seo_keywords);

$seo_description    = $tcpcConfig['seo_home_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{NICKNAME}",$userInfo['nickname'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcpc:home");  