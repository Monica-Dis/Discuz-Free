<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list_shop.php';

$page           = intval($_GET['page'])>0 ? intval($_GET['page']):1;
$cate_id        = intval($_GET['cate_id'])>0 ? intval($_GET['cate_id']):0;
$cate_child_id  = intval($_GET['cate_child_id'])>0 ? intval($_GET['cate_child_id']):0;
$area_id        = intval($_GET['area_id'])>0 ? intval($_GET['area_id']):0;
$street_id      = intval($_GET['street_id'])>0 ? intval($_GET['street_id']):0;
$keyword        = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$keyword    = dhtmlspecialchars($keyword);

if($__Mobile == 1 && $tcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=list&cate_id={$cate_id}&cate_child_id={$cate_child_id}");exit;
}

$cateListTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list(" AND parent_id=0 "," ORDER BY csort ASC,id DESC ",0,500);
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $value['link'] = tom_tcpc_url('shoplist',$site_id,array('cate_id'=>$value['id']));
        
        $cateList[$value['id']] = $value;
    }
}

$cateUrl = '';
if($cate_id > 0){
    $cateChildListTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list(" AND parent_id = {$cate_id} "," ORDER BY csort ASC,id DESC ",0,500);
    $cateChildList = array();
    if(is_array($cateChildListTmp) && !empty($cateChildListTmp)){
        foreach($cateChildListTmp as $key => $value){
            $value['link'] = tom_tcpc_url('shoplist',$site_id,array('cate_id'=>$value['parent_id'],'cate_child_id'=>$value['id']));
            
            $cateChildList[$value['id']] = $value;
        }
    }
    
    $cateUrl = tom_tcpc_url('shoplist',$site_id,array('cate_id'=>$cate_id));
    if($cate_child_id > 0){
        $cateChildUrl = tom_tcpc_url('shoplist',$site_id,array('cate_id'=>$cate_id,'cate_child_id'=>$cate_child_id));
    }
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$areaList = array();
if(is_array($areaListTmp) && !empty($areaListTmp)){
    $areaList = $areaListTmp;
}

$streetList = array();
if($area_id > 0){
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
}

$where = ' AND status=1 AND shenhe_status=1  ';
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}
if($cate_id > 0){
    $where .= " AND cate_id = {$cate_id} ";
}
if($cate_child_id > 0){
    $where .= " AND cate_child_id = {$cate_child_id} ";
}
if($area_id > 0){
    $where .= " AND area_id = {$area_id} ";
}
if($street_id > 0){
    $where .= " AND street_id = {$street_id} ";
}
if(!empty($keyword)){
    $keywordTmp = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND (name LIKE '%{$keywordTmp}%' OR content LIKE '%{$keywordTmp}%' OR tabs LIKE '%{$keywordTmp}%') ";
}

$order = " ORDER BY topstatus DESC, toprand DESC,vip_rank DESC,clicks DESC,id DESC ";

$pagesize = 20;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count($where);
$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list($where,$order,$start,$pagesize);
$tcshopList = tom_handle_shop($tcshopListTmp);

$pageArr['link'] = tom_tcpc_url('shoplist',$site_id,array('cate_id'=>$cate_id,'cate_child_id'=>$cate_child_id,'page'=>'{page}'));
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$cateName = $cateChildName = '';
if($cate_id > 0){
    $cateName = $cateList[$cate_id]['name'];
}
if($cate_child_id > 0){
    $cateChildName = $cateChildList[$cate_child_id]['name'];
}

$guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 6 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_tcpc#tom_tcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 6 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$seo_cate_name = $seo_cate_child_name = '';
if(!empty($cateName)){
    $seo_cate_name = $cateName;
}else{
    $seo_cate_name = lang('plugin/tom_tcpc', 'list_shop_title');
}
if(!empty($cateChildName)){
    $seo_cate_child_name = $cateChildName;
}

$seo_title          = $tcpcConfig['seo_shoplist_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{CATENAME}",$seo_cate_name, $seo_title);
$seo_title          = str_replace("{CATECHILDNAME}",$seo_cate_child_name, $seo_title);
$seo_title          = str_replace("{PAGE}",$page, $seo_title);

$seo_keywords       = $tcpcConfig['seo_shoplist_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CATENAME}",$seo_cate_name, $seo_keywords);
$seo_keywords       = str_replace("{CATECHILDNAME}",$seo_cate_child_name, $seo_keywords);
$seo_keywords       = str_replace("{PAGE}",$page, $seo_keywords);

$seo_description    = $tcpcConfig['seo_shoplist_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{CATENAME}",$seo_cate_name, $seo_description);
$seo_description    = str_replace("{CATECHILDNAME}",$seo_cate_child_name, $seo_description);
$seo_description    = str_replace("{PAGE}",$page, $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcpc:shoplist");