<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=diy';
$modListUrl = $adminListUrl.'&tmod=diy';
$modFromUrl = $adminFromUrl.'&tmod=diy';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcpc#tom_tcpc_diy')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); /*Dism_taobao_com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter();  /*d'.'is'.'m.ta'.'obao.com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $diyInfo = C::t('#tom_tcpc#tom_tcpc_diy')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($diyInfo);
        C::t('#tom_tcpc#tom_tcpc_diy')->update($diyInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*Dism_taobao_com*/
        __create_info_html($diyInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter();  /*d'.'is'.'m.ta'.'obao.com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'status'){
    
    $status = intval($_GET['status'])>0 ? intval($_GET['status']) : 0;
    
    $updateData = array();
    $updateData['status'] = $status;
    C::t('#tom_tcpc#tom_tcpc_diy')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcpc#tom_tcpc_diy')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $site_id    = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcpc#tom_tcpc_diy')->fetch_all_count($where);
    $diyList = C::t('#tom_tcpc#tom_tcpc_diy')->fetch_all_list($where," ORDER BY site_id ASC,id DESC ",$start,$pagesize);
    
    showtableheader(); /*Dism_taobao_com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['diy_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['diy_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*Dism��taobao��com*/
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); /*Dism_taobao_com*/
    
    $site_select_1 = '';
    if($site_id == 1){
        $site_select_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_select_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter();  /*d'.'is'.'m.ta'.'obao.com*/
    
    __create_nav_html();
    showtableheader(); /*Dism_taobao_com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['diy_name'] . '</th>';
    echo '<th>' . $Lang['diy_status'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($diyList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else if($value['site_id'] == 1){
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }else{
            echo '<td>--</td>';
        }
        echo '<td>' . $value['name'] . '</td>';
        if($value['status'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['diy_status_1'] . '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=status&id='.$value['id'].'&status=0&formhash='.FORMHASH.'">' . $Lang['diy_status_0']. '</a>)</td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['diy_status_0'] . '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=status&id='.$value['id'].'&status=1&formhash='.FORMHASH.'">' . $Lang['diy_status_1']. '</a>)</td>';
        }
        
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content        = dhtmlspecialchars($content);
    $status         = isset($_GET['status'])? intval($_GET['status']):1;
    
    $data['site_id']    = $site_id;
    $data['name']       = $name;
    $data['content']    = $content;
    $data['status']     = $status;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'site_id'       => 1,
        'name'          => '',
        'content'       => '',
        'status'        => 1,
    );
    $options = array_merge($options, $infoArr);
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    tomshowsetting(true,array('title'=>$Lang['diy_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['diy_name_msg']),"input");
    
    $options['content'] = stripslashes($options['content']);
    
    echo '<tr class="header"><th>'.$Lang['diy_content'].'</th><th></th></tr>';
    echo '<tr><td width="300"><textarea rows="10" name="content" cols="60" >'.$options['content'].'</textarea></td><td>'.$Lang['diy_content_msg'].'</td></tr>';
    
    $status_item = array(0=>$Lang['diy_status_0'],1=>$Lang['diy_status_1']);
    tomshowsetting(true,array('title'=>$Lang['diy_status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['diy_status_msg'],'item'=>$status_item),"radio");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader(); /*dism _taobao _com*/
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['diy_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['diy_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['diy_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['diy_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['diy_edit'],"",true);
    }else{
        tomshownavli($Lang['diy_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['diy_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter(); /*dism - taobao - com*/
}