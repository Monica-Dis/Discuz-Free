<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=about';
$modListUrl = $adminListUrl.'&tmod=about';
$modFromUrl = $adminFromUrl.'&tmod=about';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcpc#tom_tcpc_about')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); /*Dism_taobao_com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter();  /*d'.'is'.'m.ta'.'obao.com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $info = C::t('#tom_tcpc#tom_tcpc_about')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($info);
        C::t('#tom_tcpc#tom_tcpc_about')->update($info['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*Dism_taobao_com*/
        __create_info_html($info);
        showsubmit('submit', 'submit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter();  /*d'.'is'.'m.ta'.'obao.com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcpc#tom_tcpc_about')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcpc#tom_tcpc_about')->fetch_all_count("");
    $aboutList = C::t('#tom_tcpc#tom_tcpc_about')->fetch_all_list(""," ORDER BY asort ASC,id DESC ",$start,$pagesize);
    
    showtableheader(); /*Dism_taobao_com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['about_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*Dism��taobao��com*/
    
    $modBasePageUrl = $modBaseUrl;
    
    __create_nav_html();
    showtableheader(); /*Dism_taobao_com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['about_title'] . '</th>';
    echo '<th>' . $Lang['sort'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($aboutList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['title'] . '</td>';
        echo '<td>' . $value['asort'] . '</td>';
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
    $asort          = isset($_GET['asort'])? intval($_GET['asort']):10;
    
    $data['title']      = $title;
    $data['content']    = $content;
    $data['asort']      = $asort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'title'           => '',
        'content'           => '',
        'asort'          => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['about_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['about_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['about_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['about_content_msg']),"text");
    tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'asort','value'=>$options['asort'],'msg'=>$Lang['sort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader(); /*dism _taobao _com*/
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['about_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['about_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['about_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['about_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['about_edit'],"",true);
    }else{
        tomshownavli($Lang['about_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['about_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter(); /*dism - taobao - com*/
}