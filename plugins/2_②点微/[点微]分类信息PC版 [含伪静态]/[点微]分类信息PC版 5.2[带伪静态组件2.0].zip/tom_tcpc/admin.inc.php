<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcpc'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcpc&pmod=admin';
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcpc&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcpc&pmod=admin';

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){}else{
    echo " no install https://dism.taobao.com/?@tom_tongcheng.plugin";exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/class/function.a.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$tcpcConfig = get_plugin_config($pluginid);
$Lang = formatLang($Lang);

$tongchengPlugin = C::t('#tom_tcpc#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';


if($_GET['tmod'] == 'index'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/admin/index.php';
}else if($_GET['tmod'] == 'guanggao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/admin/guanggao.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/admin/focuspic.php';
}else if($_GET['tmod'] == 'nav'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/admin/nav.php';
}else if($_GET['tmod'] == 'links'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/admin/links.php';
}else if($_GET['tmod'] == 'about'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/admin/about.php';
}else if($_GET['tmod'] == 'rewrite'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/admin/rewrite.php';
}else if($_GET['tmod'] == 'diy'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/admin/diy.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/admin/index.php';
}