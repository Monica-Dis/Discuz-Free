<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$timestamp = TIMESTAMP;
$tcpcConfig = $_G['cache']['plugin']['tom_tcpc'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20201017";

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){}else{
    echo " no install https://dism.taobao.com/?@tom_tongcheng.plugin";exit;
}

## rewrite start
$__ShowTcpcRewrite = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcpc/rewrite.rule.php')){
    $__ShowTcpcRewrite = 1;
}
## rewrite end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/qqface.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/sitesinfo.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/class/function.page.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/class/function.url.php';

$__IsWeixin = $__Ios = $__Android = $__Mobile = 0;
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){ $__IsWeixin = 1;$__Mobile = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') !== false){$__Ios = 1;$__Mobile = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false){$__Android = 1;$__Mobile = 1;}

## tcadmin start
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
## tcadmin end
## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tctoutiao start
$__ShowTctoutiao = 0;
$tctoutiaoConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/tom_tctoutiao.inc.php')){
    $tctoutiaoConfig = $_G['cache']['plugin']['tom_tctoutiao'];
    if($tctoutiaoConfig['open_tctoutiao'] == 1){
        $__ShowTctoutiao = 1;
    }
}
## tctoutiao end
## tcrenzheng start
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')){
    $tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
    if($tcrenzhengConfig['open_tcrenzheng'] == 1){
        $__ShowTcrenzheng = 1;
    }
}
## tcrenzheng end
## tczhaopin start
$__ShowTczhaopin = 0;
$tczhaopinConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')){
    $tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
    if($tczhaopinConfig['open_tczhaopin'] == 1){
        $__ShowTczhaopin = 1;
    }
}
## tczhaopin end
## tcpinche start
$__ShowTcpinche = 0;
$tcpincheConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcpinche/tom_tcpinche.inc.php')){
    $tcpincheConfig = $_G['cache']['plugin']['tom_tcpinche'];
    $__ShowTcpinche = 1;
}
## tcpinche end
## tcfangchan start
$__ShowFangchan = 0;
$tcfangchanConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/tom_tcfangchan.inc.php')){
    $tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
    if($tcfangchanConfig['open_tcfangchan'] == 1){
        $__ShowFangchan = 1;
    }
}
## tcfangchan end
## video start
$__ShowVideo = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/video.inc.php')){
    $__ShowVideo = 1;
}
## video end
## tchongbao start
$__ShowTchongbao = 0;
$tchongbaoConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchongbao/tom_tchongbao.inc.php')){
    $tchongbaoConfig = $_G['cache']['plugin']['tom_tchongbao'];
    if($tchongbaoConfig['open_tchongbao'] == 1){
        $__ShowTchongbao = 1;
        $tchongbaoConfig['hb_lq_type'] = 1;
    }
}
## tchongbao end
## tcqianggou start
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
    $tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
    if($tcqianggouConfig['open_tcqianggou'] == 1){
        $__ShowTcqianggou = 1;
    }
}
## tcqianggou end
## tcptuan start
$__ShowTcptuan = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcptuan/tom_tcptuan.inc.php')){
    $tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
    if($tcptuanConfig['open_tcptuan'] == 1){
        $__ShowTcptuan = 1;
    }
}
## tcptuan end
## tckjia start
$__ShowTckjia = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tckjia/tom_tckjia.inc.php')){
    $tckjiaConfig = $_G['cache']['plugin']['tom_tckjia'];
    if($tckjiaConfig['open_tckjia'] == 1){
        $__ShowTckjia = 1;
    }
}
## tckjia end
## tcchoujiang start
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')){
    $tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
    if($tcchoujiangConfig['open_tcchoujiang'] == 1){
        $__ShowTcchoujiang = 1;
    }
}
## tcchoujiang end
## tchuodong start
$__ShowTchuodong = 0;
$tchuodongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchuodong/tom_tchuodong.inc.php')){
    $tchuodongConfig = $_G['cache']['plugin']['tom_tchuodong'];
    if($tchuodongConfig['open_tchuodong'] == 1){
        $__ShowTchuodong = 1;
    }
}
## tchuodong end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/site_lbs.php';

$__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
if(!$__CommonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tongcheng#tom_tongcheng_common')->insert($insertData);
}
if($site_id > 1){
    $__siteCommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id($site_id);
    if(!$__siteCommonInfo){
        $insertData = array();
        $insertData['id']      = $site_id;
        C::t('#tom_tongcheng#tom_tongcheng_common')->insert($insertData);
    }
}

$navListTmp = C::t('#tom_tcpc#tom_tcpc_nav')->fetch_all_list(" AND site_id={$site_id} "," ORDER BY nsort ASC,id DESC ", 0, 9);
if(is_array($navListTmp) && !empty($navListTmp)){
}else if($site_id > 1){
    $navListTmp = C::t('#tom_tcpc#tom_tcpc_nav')->fetch_all_list(" AND site_id=1 "," ORDER BY nsort ASC,id DESC ", 0, 9);
}
$navList = array();
if(is_array($navListTmp) && !empty($navListTmp)){
    foreach($navListTmp as $key => $value){
        $navList[$key] = $value;
        $navList[$key]['link'] = str_replace("{site}",$site_id, $value['link']);
        if($value['type'] == 1){
            $navList[$key]['link'] = tom_tcpc_url('list',$site_id,array('model_id'=>$value['model_id']));;
        }
    }
}else{
    $navModelWhereStr = " AND is_show=1 ";
    if($site_id > 1){
        if(!empty($__SitesInfo['model_ids'])){
            $navModelWhereStr.= " AND id IN({$__SitesInfo['model_ids']}) ";
        }
    }else{
        $navModelWhereStr.= " AND sites_show=0 ";
    }
    $navModelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(" {$navModelWhereStr} "," ORDER BY paixu ASC,id DESC ",0,7);
    $navModelList = array();
    if(is_array($navModelListTmp) && !empty($navModelListTmp)){
        foreach($navModelListTmp as $key => $value){
            $navModelList[$key] = $value;
            $navModelList[$key]['link'] = tom_tcpc_url('list',$site_id,array('model_id'=>$value['id']));
        }
    }
}
$navCount = count($navList);

$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
if($__SitesInfo['id'] > 1 && !empty($__SitesInfo['kefu_qrcode'])){
    if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])){
        if(strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_') === FALSE){
            $kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
        }else{
            $kefuQrcodeSrc = $_G['siteurl'].$__SitesInfo['kefu_qrcode'];
        }
    }else{
        $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
    }
}

$aboutListTmp = C::t('#tom_tcpc#tom_tcpc_about')->fetch_all_list(""," ORDER BY asort ASC,id DESC ",0,50);
$aboutList = array();
$about_i = 1;
if(is_array($aboutListTmp) && !empty($aboutListTmp)){
    foreach ($aboutListTmp as $key => $value){
        $aboutList[$key] = $value;
        $aboutList[$key]['i'] = $about_i;
        $aboutList[$key]['link'] = tom_tcpc_url('about',$site_id,array('about_id'=>$value['id']));
        $about_i++;
    }
}
$aboutCount = count($aboutList);

$showModelIdsStr = '99999999';
$showModelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(" AND is_show = 1 "," ORDER BY id DESC ",0,1000);
if(is_array($showModelListTmp) && !empty($showModelListTmp)){
    $showModelIdsArr = array();
    foreach ($showModelListTmp as $key => $value){
        $showModelIdsArr[] = $value['id'];
    }
    if(is_array($showModelIdsArr) && !empty($showModelIdsArr)){
        $showModelIdsStr = implode(',', $showModelIdsArr);
    }
}

$sfcModelInfo = array();
$sfcTypeArr = array();
$sfcModelInfoTmp  = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list("AND type=2 ","ORDER BY id DESC",0,1);
if(is_array($sfcModelInfoTmp) && $sfcModelInfoTmp[0]['id'] > 0){
    $sfcModelInfo = $sfcModelInfoTmp[0];
    if($sfcModelInfo && $sfcModelInfo['id'] > 0){
        $sfcTypeArrTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_all_list(" AND model_id = {$sfcModelInfo['id']} "," ORDER BY paixu ASC,id DESC ",0,100);
        if(is_array($sfcTypeArrTmp) && !empty($sfcTypeArrTmp)){
            foreach ($sfcTypeArrTmp as $key => $value){
                $sfcTypeArr[$value['id']] = $value;
            }
        }
    }
}

$tcpcConfig['pc_logo'] = trim($tcpcConfig['pc_logo']);
if(!empty($tcpcConfig['pc_logo']) && !preg_match('/^http/', $tcpcConfig['pc_logo']) ){
    $tcpcConfig['pc_logo'] = $_G['siteurl'].$tcpcConfig['pc_logo'];
}
$tcpcConfig['default_pic'] = trim($tcpcConfig['default_pic']);
if(!empty($tcpcConfig['default_pic']) && !preg_match('/^http/', $tcpcConfig['default_pic']) ){
    $tcpcConfig['default_pic'] = $_G['siteurl'].$tcpcConfig['default_pic'];
}
$tongchengConfig['wxqrcode_src'] = trim($tongchengConfig['wxqrcode_src']);
if(!empty($tongchengConfig['wxqrcode_src']) && !preg_match('/^http/', $tongchengConfig['wxqrcode_src']) ){
    $tongchengConfig['wxqrcode_src'] = $_G['siteurl'].$tongchengConfig['wxqrcode_src'];
}
$tcpcConfig['wxqrcode_fabu_pic'] = trim($tcpcConfig['wxqrcode_fabu_pic']);
if(!empty($tcpcConfig['wxqrcode_fabu_pic']) && !preg_match('/^http/', $tcpcConfig['wxqrcode_fabu_pic']) ){
    $tcpcConfig['wxqrcode_fabu_pic'] = $_G['siteurl'].$tcpcConfig['wxqrcode_fabu_pic'];
}
$tcpcConfig['wxqrcode_shop_ruzhu_pic'] = trim($tcpcConfig['wxqrcode_shop_ruzhu_pic']);
if(!empty($tcpcConfig['wxqrcode_shop_ruzhu_pic']) && !preg_match('/^http/', $tcpcConfig['wxqrcode_shop_ruzhu_pic']) ){
    $tcpcConfig['wxqrcode_shop_ruzhu_pic'] = $_G['siteurl'].$tcpcConfig['wxqrcode_shop_ruzhu_pic'];
}
$tcpcConfig['wxqrcode_m_pic'] = trim($tcpcConfig['wxqrcode_m_pic']);
if(!empty($tcpcConfig['wxqrcode_m_pic']) && !preg_match('/^http/', $tcpcConfig['wxqrcode_m_pic']) ){
    $tcpcConfig['wxqrcode_m_pic'] = $_G['siteurl'].$tcpcConfig['wxqrcode_m_pic'];
}
if(empty($tcpcConfig['wxqrcode_fabu_pic'])){
    $tcpcConfig['wxqrcode_fabu_pic'] = $tongchengConfig['wxqrcode_src'];
}
if(empty($tcpcConfig['wxqrcode_shop_ruzhu_pic'])){
    $tcpcConfig['wxqrcode_shop_ruzhu_pic'] = $tongchengConfig['wxqrcode_src'];
}
if(empty($tcpcConfig['wxqrcode_m_pic'])){
    $tcpcConfig['wxqrcode_m_pic'] = $tongchengConfig['wxqrcode_src'];
}

$index1Url      = tom_tcpc_url('index',1);
$indexUrl       = tom_tcpc_url('index',$site_id);
$toutiaoUrl     = tom_tcpc_url('toutiao',$site_id);
$listUrl        = tom_tcpc_url('list',$site_id);
$shopUrl        = tom_tcpc_url('shop',$site_id);
$shoplistUrl    = tom_tcpc_url('shoplist',$site_id);

$mUrl                   = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=index";
$fabuUrl                = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=fabu";
$shopRuzhuUrl           = $_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=ruzhu";
$ajaxUpdateTongchengUrl = $_G['siteurl']."plugin.php?id=tom_tcpc:ajax&site={$site_id}&act=update_tongcheng&formhash={$formhash}";

if($_GET['mod'] == 'index'){
    
    $search_type = 'tongcheng';
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/index.php';
    
}else if($_GET['mod'] == 'list'){
    
    $search_type = 'tongcheng';

    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/list.php';
    
}else if($_GET['mod'] == 'info'){
    
    $search_type = 'tongcheng';

    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/info.php';
    
}else if($_GET['mod'] == 'home'){
    
    $search_type = 'tongcheng';

    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/home.php';
    
}else if($_GET['mod'] == 'about'){
    
    $search_type = 'tongcheng';

    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/about.php';
    
}else if($_GET['mod'] == 'toutiao' && $__ShowTctoutiao == 1){
    
    $search_type = 'toutiao';
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/toutiao.php';
    
}else if($_GET['mod'] == 'toutiaoinfo' && $__ShowTctoutiao == 1){
    
    $search_type = 'toutiao';
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/toutiaoinfo.php';
    
}else if($_GET['mod'] == 'toutiaozuozhe' && $__ShowTctoutiao == 1){
    
    $search_type = 'toutiao';
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/toutiaozuozhe.php';
    
}else if($_GET['mod'] == 'shop' && $__ShowTcshop == 1){
    
    $search_type = 'shop';
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/shop.php';
    
}else if($_GET['mod'] == 'shoplist' && $__ShowTcshop == 1){
    
    $search_type = 'shop';
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/shoplist.php';
    
}else if($_GET['mod'] == 'shopinfo' && $__ShowTcshop == 1){
    
    $search_type = 'shop';
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/shopinfo.php';
    
}else{
    
    $search_type = 'tongcheng';
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcpc/module/index.php';
}