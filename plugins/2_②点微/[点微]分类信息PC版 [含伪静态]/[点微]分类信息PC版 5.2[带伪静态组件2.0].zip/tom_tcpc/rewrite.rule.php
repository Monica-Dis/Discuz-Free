<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$rewritedata = array(
	'rulesearch' => array(
        'index'         => $tcpcConfig['rewrite_index_name'].'.html',
        'site'          => $tcpcConfig['rewrite_site_name'].'-{site}.html',
		'list'          => $tcpcConfig['rewrite_fenlei_name'].'/list-{site}-{model_id}-{type_id}-{page}.html',
        'info'          => $tcpcConfig['rewrite_fenlei_name'].'/info-{site}-{tongcheng_id}.html',
        'home'          => $tcpcConfig['rewrite_fenlei_name'].'/home-{site}-{user_id}-{page}.html',
        'about'         => $tcpcConfig['rewrite_fenlei_name'].'/about-{site}-{about_id}.html',
        'toutiao'       => $tcpcConfig['rewrite_toutiao_name'].'/list-{site}-{cate_id}-{page}.html',
        'toutiaoinfo'   => $tcpcConfig['rewrite_toutiao_name'].'/info-{site}-{tctoutiao_id}.html',
        'toutiaozuozhe' => $tcpcConfig['rewrite_toutiao_name'].'/zuozhe-{site}-{zuozhe_id}-{type}-{page}.html',
        'shop'          => $tcpcConfig['rewrite_shop_name'].'/shop-{site}.html',
        'shoplist'      => $tcpcConfig['rewrite_shop_name'].'/list-{site}-{cate_id}-{cate_child_id}-{page}.html',
        'shopinfo'      => $tcpcConfig['rewrite_shop_name'].'/info-{site}-{tcshop_id}.html',
	),
	'rulereplace' => array(
        'index'         => 'plugin.php?id=tom_tcpc&site=1&mod=index',
        'site'          => 'plugin.php?id=tom_tcpc&site={site}&mod=index',
		'list'          => 'plugin.php?id=tom_tcpc&site={site}&mod=list&model_id={model_id}&type_id={type_id}&page={page}',
        'info'          => 'plugin.php?id=tom_tcpc&site={site}&mod=info&xxid={tongcheng_id}',
        'home'          => 'plugin.php?id=tom_tcpc&site={site}&mod=home&user_id={user_id}&page={page}',
        'about'         => 'plugin.php?id=tom_tcpc&site={site}&mod=about&about_id={about_id}',
        'toutiao'       => 'plugin.php?id=tom_tcpc&site={site}&mod=toutiao&cate_id={cate_id}&page={page}',
        'toutiaoinfo'   => 'plugin.php?id=tom_tcpc&site={site}&mod=toutiaoinfo&aid={tctoutiao_id}',
        'toutiaozuozhe' => 'plugin.php?id=tom_tcpc&site={site}&mod=toutiaozuozhe&zuozhe_id={zuozhe_id}&type={type}&page={page}',
        'shop'          => 'plugin.php?id=tom_tcpc&site={site}&mod=shop',
        'shoplist'      => 'plugin.php?id=tom_tcpc&site={site}&mod=shoplist&cate_id={cate_id}&cate_child_id={cate_child_id}&page={page}',
        'shopinfo'      => 'plugin.php?id=tom_tcpc&site={site}&mod=shopinfo&dpid={tcshop_id}',
	),
	'rulevars' => array(
        'index'         => array(),
        'site'          => array('{site}' => '([0-9]+)'),
		'list'          => array('{site}' => '([0-9]+)', '{model_id}' => '([0-9]+)', '{type_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'info'          => array('{site}' => '([0-9]+)', '{tongcheng_id}' => '([0-9]+)'),
        'home'          => array('{site}' => '([0-9]+)', '{user_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'about'         => array('{site}' => '([0-9]+)', '{about_id}' => '([0-9]+)'),
        'toutiao'       => array('{site}' => '([0-9]+)', '{cate_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'toutiaoinfo'   => array('{site}' => '([0-9]+)', '{tctoutiao_id}' => '([0-9]+)'),
        'toutiaozuozhe' => array('{site}' => '([0-9]+)', '{zuozhe_id}' => '([0-9]+)', '{type}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'shop'          => array('{site}' => '([0-9]+)'),
        'shoplist'      => array('{site}' => '([0-9]+)', '{cate_id}' => '([0-9]+)', '{cate_child_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'shopinfo'      => array('{site}' => '([0-9]+)', '{tcshop_id}' => '([0-9]+)'),
	)
);


$rule['{apache1}'] = $rule['{apache2}'] = $rule['{iis}'] = $rule['{iis7}'] = $rule['{zeus}'] = $rule['{nginx}'] = '';
foreach($rewritedata['rulesearch'] as $k => $v) {
    $pvmaxv = count($rewritedata['rulevars'][$k]) + 2;
    $vkeys = array_keys($rewritedata['rulevars'][$k]);
    $rewritedata['rulereplace'][$k] = pvsort($vkeys, $v, $rewritedata['rulereplace'][$k]);
    $v = str_replace($vkeys, $rewritedata['rulevars'][$k], addcslashes($v, '?*+^$.[]()|'));
    $rule['{apache1}'] .= "\t".'RewriteCond %{QUERY_STRING} ^(.*)$'."\n\t".'RewriteRule ^(.*)/'.$v.'$ $1/'.pvadd($rewritedata['rulereplace'][$k])."&%1\n";
    if($k != 'forum_archiver') {
        $rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^'.$v.'$ '.$rewritedata['rulereplace'][$k]."&%1\n";
    } else {
        $rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^archiver/'.$v.'$ archiver/'.$rewritedata['rulereplace'][$k]."&%1\n";
    }
    $rule['{iis}'] .= 'RewriteRule ^(.*)/'.$v.'(\?(.*))*$ $1/'.addcslashes(pvadd($rewritedata['rulereplace'][$k]).'&$'.($pvmaxv + 1), '.?')."\n";
    $rule['{iis7}'] .= "\t\t".'&lt;rule name="'.$k.'"&gt;'."\n\t\t\t".'&lt;match url="^(.*/)*'.str_replace('\.', '.', $v).'\?*(.*)$" /&gt;'."\n\t\t\t".'&lt;action type="Rewrite" url="{R:1}/'.str_replace(array('&', 'page\%3D'), array('&amp;amp;', 'page%3D'), addcslashes(pvadd($rewritedata['rulereplace'][$k], 1).'&{R:'.$pvmaxv.'}', '?')).'" /&gt;'."\n\t\t".'&lt;/rule&gt;'."\n";
    $rule['{zeus}'] .= 'match URL into $ with ^(.*)/'.$v.'\?*(.*)$'."\n".'if matched then'."\n\t".'set URL = $1/'.pvadd($rewritedata['rulereplace'][$k]).'&$'.$pvmaxv."\nendif\n";
    $rule['{nginx}'] .= 'rewrite ^([^\.]*)/'.$v.'$ $1/'.stripslashes(pvadd($rewritedata['rulereplace'][$k]))." last;\n";
}
$rule['{nginx}'] .= "if (!-e \$request_filename) {\n\treturn 404;\n}";
echo str_replace(array_keys($rule), $rule, $scriptlang['tom_tcpc']['rewrite_message']);
    
function pvsort($key, $v, $s) {
	$r = '/';
	$p = '';
	foreach($key as $k) {
		$r .= $p.preg_quote($k);
		$p = '|';
	}
	$r .= '/';
	preg_match_all($r, $v, $a);
	$a = $a[0];
	$a = array_flip($a);
	foreach($a as $key => $value) {
		$s = str_replace($key, '$'.($value + 1), $s);
	}
	return $s;
}

function pvadd($s, $t = 0) {
	$s = str_replace(array('$6','$5','$4', '$3', '$2', '$1'), array('~7', '~6', '~5', '~4', '~3', '~2'), $s);
	if(!$t) {
		return str_replace(array('~7','~6','~5', '~4', '~3', '~2'), array('$7','$6','$5', '$4', '$3', '$2'), $s);
	} else {
		return str_replace(array('~7','~6','~5', '~4', '~3', '~2'), array('{R:7}','{R:6}','{R:5}','{R:4}', '{R:3}', '{R:2}'), $s);
	}

}