<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$orderCount1 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND order_status = 1 ");
$orderCount2 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND order_status IN (2,8) ");
$orderCount3 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND order_status = 3 ");
$orderCount4 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND order_status = 4 AND pinglun_status = 0 ");

$refundCount = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND refund_status = 1");

$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
if($__SitesInfo['id'] > 1){
    if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])){
        if(strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_') === FALSE){
            $kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
        }else{
            $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
        }
    }else{
        $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
    }
}

$tcmallConfig['kefu_qrcode'] = trim($tcmallConfig['kefu_qrcode']);
if(!empty($tcmallConfig['kefu_qrcode'])){
    $kefuQrcodeSrc = $tcmallConfig['kefu_qrcode'];
}

$back_url = $weixinClass->get_url();
$back_url = urlencode($back_url);

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=my";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:my");