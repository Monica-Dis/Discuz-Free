<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type = intval($_GET['type'])> 0? intval($_GET['type']):0;
$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$whereStr = " AND user_id = {$__UserInfo['id']} ";
if($type == 1){
    $whereStr .= " AND order_status = 1 ";
}else if($type == 2){
    $whereStr .= " AND order_status IN (2,8) ";
}else if($type == 3){
    $whereStr .= " AND order_status = 3 ";
}else if($type == 4){
    $whereStr .= " AND order_status = 4 AND pinglun_status = 0 ";
}

$orderStr = " ORDER BY order_time DESC,id DESC ";

$pagesize = 10;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count($whereStr);
$orderListTmp = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);
$orderList = array();
foreach ($orderListTmp as $key => $value) {
    $orderList[$key] = $value;

    $orderGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$value['id']} ","ORDER BY id DESC",0,100);
    $orderGoodsList = array();
    if(is_array($orderGoodsListTmp) && !empty($orderGoodsListTmp)){
        foreach($orderGoodsListTmp as $gk => $gv){
            $orderGoodsList[$gk] = $gv;

            $goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($gv['goods_id']);
            if(!preg_match('/^http/', $goodsInfoTmp['picurl']) ){
                if(strpos($goodsInfoTmp['picurl'], 'source/plugin/tom_tcmall/') === false){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfoTmp['picurl'];
                }else{
                    $picurlTmp = $_G['siteurl'].$goodsInfoTmp['picurl'];
                }
            }else{
                $picurlTmp = $goodsInfoTmp['picurl'];
            }

            $goodsInfoTmp['picurl'] = $picurlTmp;
            $orderGoodsList[$gk]['goodsInfo'] = $goodsInfoTmp;
        }
    }

    if($value['order_status'] == 1){
        if(TIMESTAMP - $value['order_time'] >= 3600){
            $updateData = array();
            $updateData['order_status'] = 5;
            if(C::t('#tom_tcmall#tom_tcmall_order')->update($value['id'], $updateData)){
                if(is_array($orderGoodsListTmp) && !empty($orderGoodsListTmp)){
                    foreach($orderGoodsListTmp as $gk => $gv){

                        $updateData = array();
                        $updateData['order_status'] = 5;
                        if(C::t('#tom_tcmall#tom_tcmall_order_goods')->update($gv['id'], $updateData)){

                            DB::query("UPDATE ".DB::table('tom_tcmall_goods')." SET stock=stock+{$gv['goods_num']}, sales=sales-{$gv['goods_num']} WHERE id={$gv['goods_id']}", 'UNBUFFERED');
                            if($gv['option_id'] > 0){
                                DB::query("UPDATE ".DB::table('tom_tcmall_goods_option')." SET stock=stock+{$gv['goods_num']} WHERE id={$gv['option_id']}", 'UNBUFFERED');
                            }
                        }
                    }
                }
            }
            $orderList[$key]['order_status'] = 5;
        }
    }

    $orderList[$key]['orderGoodsList'] = $orderGoodsList;
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=order&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=order&type={$type}&page={$nextPage}";

$showChoujiang = 0;
if($payOrderInfo['site_id'] > 1){
    $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($payOrderInfo['site_id']);
    $tcmallConfig['tcchoujiang_id'] = $sitesInfoTmp['tcmall_tcchoujiang_id'];
}
if($__ShowTcchoujiang == 1 && $tcmallConfig['tcchoujiang_id'] > 0){
    $choujiangBmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($tcmallConfig['tcchoujiang_id'],$__UserInfo['id']);
    if($choujiangBmInfo['id'] > 0 && $choujiangBmInfo['cj_times'] > 0){
        $showChoujiang = 1;
    }
}

$payUrl = "plugin.php?id=tom_tcmall:pay&site={$site_id}&act=order_pay&user_id={$__UserInfo['id']}&formhash={$formhash}";
$ajaxCancelUrl = "plugin.php?id=tom_tcmall:pay&site={$site_id}&act=order_cancel&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:order");