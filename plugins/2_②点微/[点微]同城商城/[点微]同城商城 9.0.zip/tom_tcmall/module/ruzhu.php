<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['act'] == 'ruzhu' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcshop_id          = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $sub_title          = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $cate_id            = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
    $cate_child_id      = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
    $shop_cate_id       = intval($_GET['shop_cate_id'])>0? intval($_GET['shop_cate_id']):0;
    $province           = isset($_GET['province'])? addslashes($_GET['province']):'';
    $city               = isset($_GET['city'])? addslashes($_GET['city']):'';
    $unit               = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $market_price       = floatval($_GET['market_price'])>0? floatval($_GET['market_price']):0.00;
    $buy_price          = floatval($_GET['buy_price'])>0? floatval($_GET['buy_price']):0.00;
    $open_vip           = intval($_GET['open_vip'])>0? intval($_GET['open_vip']):0;
    $vip_price          = floatval($_GET['vip_price'])>0? floatval($_GET['vip_price']):0.00;
    $open_score_dikou   = intval($_GET['open_score_dikou'])>0? intval($_GET['open_score_dikou']):0;
    $score_num          = intval($_GET['score_num'])>0? intval($_GET['score_num']):0;
    $score_dikou_price  = floatval($_GET['score_dikou_price'])>0? floatval($_GET['score_dikou_price']):0.00;
    $show_stock         = intval($_GET['show_stock'])>0? intval($_GET['show_stock']):0;
    $show_sales         = intval($_GET['show_sales'])>0? intval($_GET['show_sales']):0;
    $weight             = intval($_GET['weight'])>0? intval($_GET['weight']):0;
    $max_buy            = intval($_GET['max_buy'])>0? intval($_GET['max_buy']):0;
    $hasoption          = intval($_GET['hasoption'])>0? intval($_GET['hasoption']):0;
    $isrecommand        = intval($_GET['isrecommand'])>0? intval($_GET['isrecommand']):0;
    $isnew              = intval($_GET['isnew'])>0? intval($_GET['isnew']):0;
    $ishot              = intval($_GET['ishot'])>0? intval($_GET['ishot']):0;
    $seven              = intval($_GET['seven'])>0? intval($_GET['seven']):0;
    $labelname          = isset($_GET['labelname'])? addslashes($_GET['labelname']):'';
    $open_express       = intval($_GET['open_express'])>0? intval($_GET['open_express']):0;
    $express_id         = intval($_GET['express_id'])>0? intval($_GET['express_id']):0;
    $issendfree         = intval($_GET['issendfree'])>0? intval($_GET['issendfree']):0;
    $dispatch_price     = floatval($_GET['dispatch_price'])>0? floatval($_GET['dispatch_price']):0.00;
    $dispatch_type      = intval($_GET['dispatch_type'])>0? intval($_GET['dispatch_type']):1;
    $ednum              = intval($_GET['ednum'])>0? intval($_GET['ednum']):0;
    $edmoney            = floatval($_GET['edmoney'])>0? floatval($_GET['edmoney']):0;
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $keywords           = isset($_GET['keywords'])? addslashes($_GET['keywords']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $allow_refund       = intval($_GET['allow_refund'])>0? intval($_GET['allow_refund']):0;

    if($market_price <= 0){
        $market_price = $buy_price;
    }
    
    $photoArr = $photoSortArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
        if(strpos($key, "photosort_") !== false){
            $kk = intval(ltrim($key, "photosort_"));
            $photoSortArr[$kk] = addslashes($value);
        }
    }
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $insertData = array();
    $insertData['site_id']              = $tcshopInfo['site_id'];
    $insertData['tcshop_id']            = $tcshopInfo['id'];
    $insertData['user_id']              = $tcshopInfo['user_id'];
    $insertData['title']                = $title;
    $insertData['sub_title']            = $sub_title;
    $insertData['picurl']               = $picurl;
    $insertData['cate_id']              = $cate_id;
    $insertData['cate_child_id']        = $cate_child_id;
    $insertData['shop_cate_id']         = $shop_cate_id;
    $insertData['unit']                 = $unit;
    $insertData['content']              = $content;
    $insertData['market_price']         = $market_price;
    $insertData['buy_price']            = $buy_price;
    if($tcshopInfo['open_vip_price_set'] == 1){
        $insertData['open_vip']             = $open_vip;
        $insertData['vip_price']            = $vip_price;
    }
    $insertData['open_score_dikou']     = $open_score_dikou;
    $insertData['score_num']            = $score_num;
    $insertData['score_dikou_price']    = $score_dikou_price;
    if($hasoption == 0){
        $insertData['show_market_price']        = $market_price;
        $insertData['show_buy_price']           = $buy_price;
        if($tcshopInfo['open_vip_price_set'] == 1){
            $insertData['show_vip_price']           = $vip_price;
        }
        $insertData['show_score_num']           = $score_num;
        $insertData['show_score_dikou_price']   = $score_dikou_price;
    }
    $insertData['show_stock']           = $show_stock;
    $insertData['show_sales']           = $show_sales;
    $insertData['weight']               = $weight;
    $insertData['max_buy']              = $max_buy;
    $insertData['hasoption']            = $hasoption;
    $insertData['isnew']                = $isnew;
    $insertData['ishot']                = $ishot;
    $insertData['isrecommand']          = $isrecommand;
    $insertData['seven']                = $seven;
    $insertData['open_express']         = $open_express;
    $insertData['express_id']           = $express_id;
    $insertData['issendfree']           = $issendfree;
    $insertData['dispatch_price']       = $dispatch_price;
    $insertData['dispatch_type']        = $dispatch_type;
    $insertData['ednum']                = $ednum;
    $insertData['edmoney']              = $edmoney;
    $insertData['province']             = $province;
    $insertData['city']                 = $city;
    $insertData['hexiao_pwd']           = $hexiao_pwd;
    $insertData['keywords']             = $keywords;
    $insertData['labelname']            = $labelname;
    $insertData['search_txt']           = $title.'|'.$keywords.'|'.$labelname;
    if($tcmallConfig['must_shenhe'] == 1){
        $insertData['shenhe_status']        = 2;
    }else{
        $insertData['shenhe_status']        = 1;
    }
    $insertData['status']               = 0;
    $insertData['allow_refund']         = $allow_refund;
    $insertData['add_time']             = TIMESTAMP;
    if(C::t("#tom_tcmall#tom_tcmall_goods")->insert($insertData)){
        $goods_id = C::t('#tom_tcmall#tom_tcmall_goods')->insert_id();
        
        if(!empty($picurl)){
            $insertData = array();
            $insertData['goods_id']  = $goods_id;
            $insertData['type']      = 2;
            $insertData['picurl']    = $picurl;
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcmall#tom_tcmall_goods_photo')->insert($insertData);
        }
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']  = $goods_id;
                $insertData['type']      = 1;
                $insertData['picurl']    = $value;
                $insertData['psort']     = $photoSortArr[$key];
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcmall#tom_tcmall_goods_photo')->insert($insertData);
            }
        }
        
        if($tcmallConfig['must_shenhe'] == 1){
            $toUser = array();
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $toUser = $toUserTmp;
            }

            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();

            if($access_token && !empty($toUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => '['.$tcshopInfo['name'].']'.lang('plugin/tom_tcmall','shenhe_template_first'),
                    'keyword1'      => $tcmallConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}

$allTcshopCount = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count(" AND user_id={$__UserInfo['id']} ");

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$__UserInfo['id']} AND v.open_tcmall=1 "," ORDER BY s.id DESC ",0,100);
$tcshopList = array();
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach($tcshopListTmp as $key => $value){
        $tcshopList[$key] = $value;
    }
}
$tcshopCount = count($tcshopList);

$cateArr = array();
$cateList = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,100);
$i = 0;
if(is_array($cateList) && !empty($cateList)){
    foreach ($cateList as $key => $value){
        $cateArr[$i]['id'] = $value['id'];
        $cateArr[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $childCateList = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(" AND pid={$value['id']} "," ORDER BY csort ASC,id DESC ",0,100);
        $j = 0;
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $kk => $vv){
                $cateArr[$i]['sub'][$j]['id'] = $vv['id'];
                $cateArr[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cateData = urlencode(json_encode($cateArr));

$areaList = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid(0);
$cityList = array();
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$is_weixin = 0;
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
    $is_weixin = 1;
}

if($__Ios == 0 && $__Android == 0){
    $tongchengConfig['open_many_pic_upload'] = 0;
}

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=ruzhu";
$ruzhuUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=ruzhu";
$backLinkUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=mylist&fromlist=mylist";
$uploadUrl1 = "plugin.php?id=tom_tcmall&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2 = "plugin.php?id=tom_tcmall&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;
$ossBatchUrl = 'plugin.php?id=tom_tcmall:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcmall:qiniuBatch';
$wxUploadUrl = "plugin.php?id=tom_tcmall:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:ruzhu");