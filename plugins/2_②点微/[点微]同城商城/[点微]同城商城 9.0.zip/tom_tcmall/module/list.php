<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';
    
$keyword        = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$tcshop_id      = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$goodstype      = isset($_GET['goodstype'])? daddslashes($_GET['goodstype']):'';
$cate_id        = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$cate_child_id  = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
$shop_cate_id   = intval($_GET['shop_cate_id'])>0? intval($_GET['shop_cate_id']):0;
$is_vip         = intval($_GET['is_vip'])>0? intval($_GET['is_vip']):0;
$is_tg          = intval($_GET['is_tg'])>0? intval($_GET['is_tg']):0;
$is_score       = intval($_GET['is_score'])>0? intval($_GET['is_score']):0;
$mini_cart      = intval($_GET['mini_cart'])>0? intval($_GET['mini_cart']):0;
$coupon_id      = intval($_GET['coupon_id'])>0? intval($_GET['coupon_id']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):20;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND status=1 AND shenhe_status=1';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($tcshop_id)){
    $whereStr.= " AND tcshop_id={$tcshop_id} ";
}
if(!empty($cate_id)){
    $whereStr.= " AND cate_id={$cate_id} ";
}
if(!empty($cate_child_id)){
    $whereStr.= " AND cate_child_id={$cate_child_id} ";
}
if(!empty($shop_cate_id)){
    $whereStr.= " AND shop_cate_id={$shop_cate_id} ";
}
if($__ShowTcyikatong == 1 && $is_vip == 1){
    $whereStr.= " AND open_vip=1 ";
}
if($__ShowTchehuoren == 1 && $is_tg == 1){
    $whereStr.= " AND hehuoren_tg_open=1 ";
}
if($tcmallConfig['open_only_rec'] == 1 && $goodstype == 'rec' && $cate_id == 0){
    $whereStr.= " AND isrecommand=1 ";
}
if($coupon_id > 0){
    $couponInfo = C::t('#tom_tcmall#tom_tcmall_coupon')->fetch_by_id($coupon_id);
    if($couponInfo){
        if($couponInfo['coupon_type'] == 1){
            $whereStr.= " AND tcshop_id = {$couponInfo['tcshop_id']} ";
        }else if($couponInfo['coupon_type'] == 2){
            $goodsIdsArr = explode('|', $couponInfo['goods_ids']);
            $goodsIdsStr = implode(',', $goodsIdsArr);
            $whereStr.= " AND id IN({$goodsIdsStr}) ";
        }
    }
}

if($is_score == 1){
    $whereStr.= " AND open_score_dikou=1 ";
}

$goodsStr = " ORDER BY gsort DESC ,add_time DESC,id DESC ";
if($goodstype == 'new'){
    $goodsStr = " ORDER BY add_time DESC,id DESC ";
}else if($goodstype == 'hot'){
    $goodsStr = " ORDER BY sales DESC,id DESC ";
}else if($goodstype == 'rec'){
    $goodsStr = " ORDER BY isrecommand DESC,gsort DESC ,id DESC ";
}else if($goodstype == 'sale'){
    $goodsStr = " ORDER BY sales DESC ,id DESC ";
}else if($goodstype == 'price_asc'){
    $goodsStr = " ORDER BY show_buy_price ASC ,id DESC ";
}else if($goodstype == 'price_desc'){
    $goodsStr = " ORDER BY show_buy_price DESC ,id DESC ";
}

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
$goodsListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list($whereStr,$goodsStr,$start,$pagesize,$keyword);
$goodsList = array();
if(is_array($goodsListTmp) && !empty($goodsListTmp)){
    foreach ($goodsListTmp as $key => $value) {
        $goodsList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_tcmall/') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        $photoInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods_photo')->fetch_all_list(" AND goods_id = {$value['id']} AND type = 2 "," ORDER BY id ASC ",0,1);
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurl = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $buyGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list("AND goods_id = {$value['id']} AND order_status IN(2,3,4,8)", 'ORDER BY id DESC', 0, 3);
        $buyGoodsUserListTmp = array();
        if(is_array($buyGoodsListTmp) && !empty($buyGoodsListTmp)){
            foreach($buyGoodsListTmp as $bk => $bv){
                $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($bv['user_id']);
                $buyGoodsUserListTmp[$bk] = $bv;
                $buyGoodsUserListTmp[$bk]['userInfo'] = $userInfoTmp;
            }
        }
        
        $goodsSpecCountTmp = 0;
        if($value['hasoption'] == 1){
            $goodsSpecCountTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec')->fetch_all_count(" AND goods_id={$value['id']} ");
        }
        
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);

        $goodsList[$key]['picurl']              = $picurl;
        $goodsList[$key]['buyGoodsUserList']    = $buyGoodsUserListTmp;
        $goodsList[$key]['specCount']           = $goodsSpecCountTmp;
        $goodsList[$key]['tcshopInfo']          = $tcshopInfoTmp;
    }
}

if(is_array($goodsList) && !empty($goodsList)){
    foreach ($goodsList as $key => $val){
        $sales = $val['virtual_sales'] + $val['sales'];

        $outStr .= '<div class="good-item">';
            $outStr .= '<div class="goods-pic">';
                $outStr .= '<a href="plugin.php?id=tom_tcmall&site='.$site_id.'&mod=goodsinfo&goods_id='.$val['id'].'">';
                    $outStr .= '<img src="'.$val['picurl'].'">';
                $outStr .= '</a>';
            $outStr .= '</div>';
            $outStr .= '<div class="goods-cont">';
                $outStr .= '<a href="plugin.php?id=tom_tcmall&site='.$site_id.'&mod=goodsinfo&goods_id='.$val['id'].'">';
                $outStr .= '<div class="goods-cont__title">';
                    if($__ShowTcyikatong && $val['open_vip'] == 1){
                        $outStr .= '<span class="vip">'.$tcyikatongConfig['card_name'].'</span>';
                    }
                    if($__ShowTchehuoren == 1 && $is_tg == 1 && $val['hehuoren_tg_open'] == 1){
                        $outStr .= '<span class="tg">'.lang('plugin/tom_tcmall', 'ajax_list_tuiguang').'</span>';
                    }
                    $outStr .= $val['title'];
                $outStr .= '</div>';
                $outStr .= '<div class="goods-cont__pay">';
                    $outStr .= '<span class="old-price">'.lang('plugin/tom_tcmall', 'yuan_ico').$val['show_market_price'].'</span>';
                    $outStr .= '<span class="pay">';
                        if(is_array($val['buyGoodsUserList']) && !empty($val['buyGoodsUserList'])){
                            foreach($val['buyGoodsUserList'] as $bk => $bv){
                                $outStr .= '<span class="pay-box"><img src="'.$bv['userInfo']['picurl'].'"></span>';
                            }
                        }
                    $outStr .= '</span>';
                $outStr .= '</div>';
                $outStr .= '</a>';
                $outStr .= '<div class="goods-cont__price">';
                    if($is_score == 1){
                        $outStr .= '<span class="price"><span class="yuan_ico">'.lang('plugin/tom_tcmall', 'yuan_ico').'</span>'.$val['show_buy_price'].'</span>';
                        $outStr .= '<span class="score"><i class="tciconfont tcicon-score"></i>'.$val['show_score_num'].lang("plugin/tom_tcmall", 'ajax_list_dikou').lang("plugin/tom_tcmall", 'yuan_ico').$val['show_score_dikou_price'].'</span>';
                    }else{
                        $outStr .= '<span class="price"><span class="yuan_ico">'.lang('plugin/tom_tcmall', 'yuan_ico').'</span>'.$val['show_buy_price'].'</span>';
                        if($tcmallConfig['open_mini_cart'] == 1 && $mini_cart == 1 && $__UserInfo['id'] > 0 && $val['specCount'] <= 1 && $val['tcshopInfo']['peisong_type'] > 0){
                            $outStr .= '<a href="javascript:void(0);" class="cart id_mini_cart_btn" data-id="'.$val['id'].'"><i class="tciconfont tcicon-mall__cart"></i></a>';
                        }else{
                            $outStr .= '<span class="volume">'.lang('plugin/tom_tcmall', 'ajax_list_sales').$sales.'</span>';
                        }
                    }
                $outStr .= '</div>';
            $outStr .= '</div>';
        $outStr .= '</div>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;