<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
$goodsInfo = C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($goods_id);
$tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($goodsInfo['tcshop_id']);

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $sub_title          = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $cate_id            = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
    $cate_child_id      = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
    $shop_cate_id       = intval($_GET['shop_cate_id'])>0? intval($_GET['shop_cate_id']):0;
    $province           = isset($_GET['province'])? addslashes($_GET['province']):'';
    $city               = isset($_GET['city'])? addslashes($_GET['city']):'';
    $unit               = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $market_price       = floatval($_GET['market_price'])>0? floatval($_GET['market_price']):0.00;
    $buy_price          = floatval($_GET['buy_price'])>0? floatval($_GET['buy_price']):0.00;
    $open_vip           = intval($_GET['open_vip'])>0? intval($_GET['open_vip']):0;
    $vip_price          = floatval($_GET['vip_price'])>0? floatval($_GET['vip_price']):0.00;
    $open_score_dikou   = intval($_GET['open_score_dikou'])>0? intval($_GET['open_score_dikou']):0;
    $score_num          = intval($_GET['score_num'])>0? intval($_GET['score_num']):0;
    $score_dikou_price  = floatval($_GET['score_dikou_price'])>0? floatval($_GET['score_dikou_price']):0.00;
    $show_stock         = intval($_GET['show_stock'])>0? intval($_GET['show_stock']):0;
    $show_sales         = intval($_GET['show_sales'])>0? intval($_GET['show_sales']):0;
    $weight             = intval($_GET['weight'])>0? intval($_GET['weight']):0;
    $max_buy            = intval($_GET['max_buy'])>0? intval($_GET['max_buy']):0;
    $hasoption          = intval($_GET['hasoption'])>0? intval($_GET['hasoption']):0;
    $isnew              = intval($_GET['isnew'])>0? intval($_GET['isnew']):0;
    $ishot              = intval($_GET['ishot'])>0? intval($_GET['ishot']):0;
    $seven              = intval($_GET['seven'])>0? intval($_GET['seven']):0;
    $labelname          = isset($_GET['labelname'])? addslashes($_GET['labelname']):'';
    $issendfree         = intval($_GET['issendfree'])>0? intval($_GET['issendfree']):0;
    $open_express       = intval($_GET['open_express'])>0? intval($_GET['open_express']):0;
    $express_id         = intval($_GET['express_id'])>0? intval($_GET['express_id']):0;
    $dispatch_price     = floatval($_GET['dispatch_price'])>0? floatval($_GET['dispatch_price']):0.00;
    $dispatch_type      = intval($_GET['dispatch_type'])>0? intval($_GET['dispatch_type']):1;
    $ednum              = intval($_GET['ednum'])>0? intval($_GET['ednum']):0;
    $edmoney            = floatval($_GET['edmoney'])>0? floatval($_GET['edmoney']):0;
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $keywords           = isset($_GET['keywords'])? addslashes($_GET['keywords']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $allow_refund       = intval($_GET['allow_refund'])>0? intval($_GET['allow_refund']):0;
    
    if($market_price <= 0){
        $market_price = $buy_price;
    }
    
    $photoArr = $photoSortArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
        if(strpos($key, "photosort_") !== false){
            $kk = intval(ltrim($key, "photosort_"));
            $photoSortArr[$kk] = addslashes($value);
        }
    }
    
    $updateData = array();
    $updateData['title']                = $title;
    $updateData['sub_title']            = $sub_title;
    $updateData['picurl']               = $picurl;
    $updateData['cate_id']              = $cate_id;
    $updateData['cate_child_id']        = $cate_child_id;
    $updateData['shop_cate_id']         = $shop_cate_id;
    $updateData['unit']                 = $unit;
    if($goodsInfo['admin_edit'] == 0){
        $updateData['content']          = dhtmlspecialchars($content);
    }
    $updateData['market_price']         = $market_price;
    $updateData['buy_price']            = $buy_price;
    if($tcshopInfo['open_vip_price_set'] == 1){
        $updateData['open_vip']             = $open_vip;
        $updateData['vip_price']            = $vip_price;
    }
    $updateData['open_score_dikou']     = $open_score_dikou;
    $updateData['score_num']            = $score_num;
    $updateData['score_dikou_price']    = $score_dikou_price;
    if($hasoption == 0){
        $updateData['show_market_price']        = $market_price;
        $updateData['show_buy_price']           = $buy_price;
        if($tcshopInfo['open_vip_price_set'] == 1){
            $updateData['show_vip_price']           = $vip_price;
        }
        $updateData['show_score_num']           = $score_num;
        $updateData['show_score_dikou_price']   = $score_dikou_price;
    }
    $updateData['show_stock']           = $show_stock;
    $updateData['show_sales']           = $show_sales;
    $updateData['weight']               = $weight;
    $updateData['max_buy']              = $max_buy;
    $updateData['hasoption']            = $hasoption;
    $updateData['isnew']                = $isnew;
    $updateData['ishot']                = $ishot;
    $updateData['seven']                = $seven;
    $updateData['issendfree']           = $issendfree;
    $updateData['open_express']         = $open_express;
    $updateData['express_id']           = $express_id;
    $updateData['dispatch_price']       = $dispatch_price;
    $updateData['dispatch_type']        = $dispatch_type;
    $updateData['ednum']                = $ednum;
    $updateData['edmoney']              = $edmoney;
    $updateData['province']             = $province;
    $updateData['city']                 = $city;
    $updateData['keywords']             = $keywords;
    $updateData['hexiao_pwd']           = $hexiao_pwd;
    $updateData['labelname']            = $labelname;
    $updateData['search_txt']           = $title.'|'.$keywords.'|'.$labelname;
    $updateData['allow_refund']         = $allow_refund;
    $updateData['part1']                = TIMESTAMP;
    if(C::t("#tom_tcmall#tom_tcmall_goods")->update($goods_id, $updateData)){
        C::t('#tom_tcmall#tom_tcmall_goods_photo')->delete_by_goods_id($goods_id);
        
        if(!empty($picurl)){
            $insertData = array();
            $insertData['goods_id']  = $goods_id;
            $insertData['type']      = 2;
            $insertData['picurl']    = $picurl;
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcmall#tom_tcmall_goods_photo')->insert($insertData);
        }
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']  = $goods_id;
                $insertData['type']      = 1;
                $insertData['picurl']    = $value;
                $insertData['psort']     = $photoSortArr[$key];
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcmall#tom_tcmall_goods_photo')->insert($insertData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    
}

$cateInfo = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_by_id($goodsInfo['cate_id']);
$cateChildInfo = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_by_id($goodsInfo['cate_child_id']);

$cateArr = array();
$cateList = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,100);
$i = 0;
if(is_array($cateList) && !empty($cateList)){
    foreach ($cateList as $key => $value){
        $cateArr[$i]['id'] = $value['id'];
        $cateArr[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $childCateList = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(" AND pid={$value['id']} "," ORDER BY csort ASC,id DESC ",0,100);
        $j = 0;
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $kk => $vv){
                $cateArr[$i]['sub'][$j]['id'] = $vv['id'];
                $cateArr[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cateData = urlencode(json_encode($cateArr));

$areaList = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid(0);
$cityList = array();
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

if(!preg_match('/^http/', $goodsInfo['picurl']) ){
    if(strpos($goodsInfo['picurl'], 'source/plugin/tom_tcmall/') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['picurl'];
    }else{
        $picurl = $goodsInfo['picurl'];
    }
}else{
    $picurl = $goodsInfo['picurl'];
}

$photoListTmp = C::t('#tom_tcmall#tom_tcmall_goods_photo')->fetch_all_list(" AND goods_id = {$goods_id} AND type = 1 ", "ORDER BY psort ASC,id ASC", 0, 100);
$photoList = array();
$i = 1;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $photoList[$key] = $value;
        
        $photoList[$key]['pic_url'] = $value['picurlTmp'];;
        $photoList[$key]['i'] = $i;
        $i++;
    }
}
$photoCount = Count($photoList);

$shopCateList = C::t('#tom_tcshop#tom_tcshop_mall_cate')->fetch_all_list(" AND tcshop_id={$goodsInfo['tcshop_id']} "," ORDER BY csort ASC,id DESC ",0,100);

$expressListTmp = C::t('#tom_tcshop#tom_tcshop_express')->fetch_all_list(" AND tcshop_id={$goodsInfo['tcshop_id']} "," ORDER BY id DESC ");
$expressList = array();
if(is_array($expressListTmp) && !empty($expressListTmp)){
    foreach ($expressListTmp as $key => $value) {
        $expressList[$key] = $value;
    }
}

$is_weixin = 0;
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
    $is_weixin = 1;
}

if($__Ios == 0 && $__Android == 0){
    $tongchengConfig['open_many_pic_upload'] = 0;
}

$ossBatchUrl = 'plugin.php?id=tom_tcmall:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcmall:qiniuBatch';
$saveUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=edit&goods_id={$goods_id}";
$backLinkUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=mylist&fromlist=mylist";
$uploadUrl1 = "plugin.php?id=tom_tcmall&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2 = "plugin.php?id=tom_tcmall&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tcmall:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:edit");