<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';

$whereStr = " AND user_id = {$__UserInfo['id']} ";
if($type == 1){
    $whereStr.=" AND status = 1 AND shenhe_status = 1 ";
}else if($type == 2){
    $whereStr.=" AND status = 1 AND shenhe_status = 1 AND stock = 0 ";
}else if($type == 3){
    $whereStr.=" AND status != 1 AND shenhe_status = 1 ";
}else if($type == 4){
    $whereStr.=" AND shenhe_status = 2 ";
}else if($type == 5){
    $whereStr.=" AND shenhe_status = 3 ";
}

$pagesize       = 8;
$start          = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count($whereStr,$keyword);
$goodsListTmp  = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list($whereStr," ORDER BY id DESC ",$start,$pagesize,$keyword);
$goodsList = array();
if(is_array($goodsListTmp) && !empty($goodsListTmp)){
    foreach ($goodsListTmp as $key => $value){
        $goodsList[$key] = $value;

        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_tcmall/') === false){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurlTmp = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurlTmp = $value['picurl'];
        }
        
        $orderCount = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_count(" AND goods_id={$value['id']} AND order_status IN(2,3,4,8) ");
        
        $goodsList[$key]['picurl'] = $picurlTmp;
        $goodsList[$key]['orderCount'] = $orderCount;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=mylist&type={$type}&page={$prePage}&keyword={$keyword}";
$nextPageUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=mylist&type={$type}&page={$nextPage}&keyword={$keyword}";

$pageUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=mylist&type={$type}&keyword={$keyword}";

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tcmall:ajax&site={$site_id}&act=updateStatus&formhash={$formhash}";
$searchUrl = "plugin.php?id=tom_tcmall:ajax&site={$site_id}&act=get_mylist_search_url&type={$type}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:mylist");