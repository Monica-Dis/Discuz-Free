<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

$pagesize   = 8;
$start      = ($page - 1)*$pagesize;

$whereStr = " AND user_id = {$__UserInfo['id']} ";
if($type == 1){
    $whereStr .= " AND status = 1 AND start_time <= {$timeStamp} AND end_time > {$timeStamp} ";
}
if($type == 2){
    $whereStr .= " AND start_time > {$timeStamp} ";
}
if($type == 3){
    $whereStr .= " AND status = 0 ";
}

$count  = C::t('#tom_tcmall#tom_tcmall_coupon')->fetch_all_count($whereStr);
$couponListTmp = C::t("#tom_tcmall#tom_tcmall_coupon")->fetch_all_list($whereStr, "ORDER BY id DESC", $start, $pagesize);
$couponList = array();
if(is_array($couponListTmp) && !empty($couponListTmp)){
    foreach ($couponListTmp as $key => $value){
        $couponList[$key] = $value;
        $couponList[$key]['goodsIdsArr'] = explode("|", $value['goods_ids']);
        $couponList[$key]['shengyu_num'] = $value['total_num'] - $value['lingqu_num'];
        if($value['status'] == 1){
            if($value['total_num'] <= $value['lingqu_num'] || $value['end_time'] <= TIMESTAMP){
                $updateData = array();
                $updateData['status'] = 0;
                C::t('#tom_tcmall#tom_tcmall_coupon')->update($value['id'], $updateData);
            }
        }
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=mycouponlist&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=mycouponlist&type={$type}&page={$nextPage}";

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tcmall:ajax&site={$site_id}&act=updateCouponStatus&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:mycouponlist");