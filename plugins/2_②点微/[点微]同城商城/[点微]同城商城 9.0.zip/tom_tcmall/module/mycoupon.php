<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       = intval($_GET['type'])>0? intval($_GET['type']):1;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

$pagesize   = 8;
$start      = ($page - 1)*$pagesize;

$whereStr = " AND t.user_id = {$__UserInfo['id']}";
if($type == 1){
    $whereStr .= " AND t.status = 0  AND c.status = 1 AND c.start_time <= {$timeStamp} AND c.end_time > {$timeStamp} ";
}
if($type == 2){
    $whereStr .= " AND t.status = 1  ";
}
if($type == 3){
    $whereStr .= " AND t.status = 0 AND (c.status = 0 OR c.end_time <= {$timeStamp}) ";
}

$count  = C::t('#tom_tcmall#tom_tcmall_coupon_lingqu')->fetch_all_lingqu_coupon_count($whereStr);
$lingquListTmp = C::t("#tom_tcmall#tom_tcmall_coupon_lingqu")->fetch_all_lingqu_coupon_list($whereStr, "ORDER BY id DESC", $start, $pagesize);
$lingquList = array();
if(is_array($lingquListTmp) && !empty($lingquListTmp)){
    foreach ($lingquListTmp as $key => $value){
        $lingquList[$key] = $value;
        if($value['coupon_type'] == 1){
            $lingquList[$key]['link'] = "plugin.php?id=tom_tcmall&site={$site_id}&mod=shop&tcshop_id={$value['tcshop_id']}";
        }else if($value['coupon_type'] == 2){
            $lingquList[$key]['link'] = "plugin.php?id=tom_tcmall&site={$site_id}&mod=list&coupon_id={$value['coupon_id']}";
        }
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=mycoupon&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=mycoupon&type={$type}&page={$nextPage}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:mycoupon");