<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$hexiao_no  = isset($_GET['hexiao_no'])? addslashes($_GET['hexiao_no']):'';

$orderInfo  = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_hexiao_no($hexiao_no);
$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);

if($_GET['act'] == 'hexiao' && $_GET['formhash'] == FORMHASH){

    $hexiao_pwd  = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';

    $goodsOrderListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 1000);

    if($tcmallConfig['hexiao_type'] == 2){
        if(empty($hexiao_pwd)){
            echo 301;exit;
        }

        $hexiaoMateStatus = 0;
        if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
            foreach($goodsOrderListTmp as $key => $value){
                $goodsInfoTmp  = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($value['goods_id']);
                if($goodsInfoTmp['hexiao_pwd'] == $hexiao_pwd){
                    $hexiaoMateStatus = 1;
                }
            }
        }

        if($hexiaoMateStatus == 0){
            echo 302;exit;
        }
    }

    $updateData = array();
    $updateData['order_status']     = 4;
    $updateData['hexiao_user_id']   = $__UserInfo['id'];
    $updateData['hexiao_time']      = TIMESTAMP;
    if(C::t('#tom_tcmall#tom_tcmall_order')->update($orderInfo['id'],$updateData)){

        if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
            foreach($goodsOrderListTmp as $gk => $gv){
                if($gv['order_status'] == 2){
                    $updateData = array();
                    $updateData['order_status'] = 4;
                    if(C::t('#tom_tcmall#tom_tcmall_order_goods')->update($gv['id'],$updateData)){
                        $refundInfoTmp = C::t("#tom_tcmall#tom_tcmall_refund")->fetch_all_list("AND order_id = {$orderInfo['id']} AND order_goods_id = {$gv['id']} AND refund_status = 1", 'ORDER BY id DESC', 0, 1);
                        if(is_array($refundInfoTmp) && !empty($refundInfoTmp[0])){
                            $updateData = array();
                            $updateData['refund_status'] = 3;
                            $updateData['refund_time']   = TIMESTAMP;
                            C::t("#tom_tcmall#tom_tcmall_refund")->update($refundInfoTmp[0]['id'], $updateData);
                        }
                    }
                }
            }
        }
    }

    if($orderInfo['balance_status'] == 0 && $orderInfo['huodao_pay_status'] == 0){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/module/balance.php';
    }

    echo 200;exit;
}

$orderGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 100);
$orderGoodsList = array();
if(is_array($orderGoodsListTmp) && !empty($orderGoodsListTmp)){
    foreach($orderGoodsListTmp as $key => $value){
        $orderGoodsList[$key] = $value;
        $goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($value['goods_id']);
        if(!preg_match('/^http/', $goodsInfoTmp['picurl']) ){
            if(strpos($goodsInfoTmp['picurl'], 'source/plugin/tom_tcmall/') === false){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfoTmp['picurl'];
            }else{
                $picurlTmp = $_G['siteurl'].$goodsInfoTmp['picurl'];
            }
        }else{
            $picurlTmp = $goodsInfoTmp['picurl'];
        }

        $orderGoodsList[$key]['goodsInfo'] = $goodsInfoTmp;
        $orderGoodsList[$key]['goodsInfo']['picurl'] = $picurlTmp;

        if($value['order_status'] == 2 || $value['order_status'] == 3 || $value['order_status'] == 7){
            $goodsRefundInfoTmp = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_all_list("AND order_id = {$orderInfo['id']} AND order_goods_id = {$value['id']} AND refund_status IN(1,2) ", 'ORDER BY id DESC', 0, 1);
            if(is_array($goodsRefundInfoTmp) && !empty($goodsRefundInfoTmp[0])){
                $orderGoodsList[$key]['refundInfo'] = $goodsRefundInfoTmp[0];
            }
        }

    }
}

$isTcshopClerk = 0;
$clerkListTmp  = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(" AND tcshop_id={$orderInfo['tcshop_id']} AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,1);
if(!empty($clerkListTmp[0]['id']) || $tcshopInfo['user_id'] == $__UserInfo['id'] ){
    $isTcshopClerk = 1;
}

$hexiaoUserInfo = array();
if($orderInfo['order_status'] == 4){
    $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']); 
}

$showHexiaoBox = 1;
if($tcmallConfig['hexiao_type'] == 1 && $isTcshopClerk == 0){
    $showHexiaoBox = 2;
}

$hexiaoUrl = 'plugin.php?id=tom_tcmall&site='.$site_id.'&mod=orderhexiao&act=hexiao&formhash='.$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:orderhexiao");