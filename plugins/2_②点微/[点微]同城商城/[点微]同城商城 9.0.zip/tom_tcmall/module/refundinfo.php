<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$refund_id = intval($_GET['refund_id'])> 0? intval($_GET['refund_id']):0;

$refundInfo = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_by_id($refund_id);
$orderInfo = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_id($refundInfo['order_id']);
$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($refundInfo['tcshop_id']);

if($refundInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=index");exit;
}

$orderGoodsInfo = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_by_id($refundInfo['order_goods_id']);
$maxRefundPrice = $orderGoodsInfo['real_price'];
$dispatchPrice = $orderGoodsInfo['dispatch_price'];

$goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($orderGoodsInfo['goods_id']);
if(!preg_match('/^http/', $goodsInfoTmp['picurl']) ){
    if(strpos($goodsInfoTmp['picurl'], 'source/plugin/tom_tcmall/') === false){
        $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfoTmp['picurl'];
    }else{
        $picurlTmp = $_G['siteurl'].$goodsInfoTmp['picurl'];
    }
}else{
    $picurlTmp = $goodsInfoTmp['picurl'];
}
$goodsInfoTmp['picurl'] = $picurlTmp;
$orderGoodsInfo['goodsInfo'] = $goodsInfoTmp; 

$photoListTmp = C::t('#tom_tcmall#tom_tcmall_refund_photo')->fetch_all_list(" AND refund_id={$refundInfo['id']} ", 'ORDER BY id ASC', 0, 3);
$photoList = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_tcmall/') === false){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurlTmp = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurlTmp = $value['picurl'];
        }

        $photoList[] = $picurlTmp;
    }
}
$photoListStr = implode('|', $photoList);
$photoCount = count($photoList);

if(!preg_match('/^http/', $tcshopInfo['kefu_qrcode']) ){
    if(strpos($tcshopInfo['kefu_qrcode'], 'source/plugin/tom_tcshop/') === false){
        $kefu_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['kefu_qrcode'];
    }else{
        $kefu_qrcode = $_G['siteurl'].$tcshopInfo['kefu_qrcode'];
    }
}else{
    $kefu_qrcode = $tcshopInfo['kefu_qrcode'];
}

$kefuSmsUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=message&act=create&&to_user_id=".$tcshopInfo['user_id'].'&formhash='.FORMHASH;
$ajaxCancelUrl = "plugin.php?id=tom_tcmall:ajax&site={$site_id}&act=refund_cancel&refund_id={$refundInfo['id']}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:refundinfo");