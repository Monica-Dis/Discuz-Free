<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcshop_id  = intval($_GET['tcshop_id'])? intval($_GET['tcshop_id']): 0;
$tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';

if(!preg_match('/^http/', $tcshopInfo['picurl']) ){
    if(strpos($tcshopInfo['picurl'], 'source/plugin/tom_tcshop/') === FALSE){
        $tcshopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['picurl'];
    }else{
        $tcshopPicurl = $_G['siteurl'].$tcshopInfo['picurl'];
    }
}else{
    $tcshopPicurl = $tcshopInfo['picurl'];
}

$tcshopTopPicurl = $tcshopPicurl;
$photoListTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(" AND tcshop_id={$tcshop_id} AND type_id = 1 ","ORDER BY paixu ASC,id ASC",0,1);
if($photoListTmp[0]['id'] > 0){
    if(!preg_match('/^http/', $photoListTmp[0]['picurl']) ){
        if(strpos($photoListTmp[0]['picurl'], 'source/plugin/tom_') === FALSE){
            $tcshopTopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$photoListTmp[0]['picurl'];
        }else{
            $tcshopTopPicurl = $photoListTmp[0]['picurl'];
        }
    }else{
        $tcshopTopPicurl = $photoListTmp[0]['picurl'];
    }
}
if(!empty($tcshopInfo['mall_shop_picurl'])){
    if(!preg_match('/^http/', $tcshopInfo['mall_shop_picurl'])){
        if(strpos($tcshopInfo['mall_shop_picurl'], 'source/plugin/tom_') === FALSE){
            $tcshopTopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['mall_shop_picurl'];
        }else{
            $tcshopTopPicurl = $tcshopInfo['mall_shop_picurl'];
        }
    }else{
        $tcshopTopPicurl = $tcshopInfo['mall_shop_picurl'];
    }
}

if(!preg_match('/^http/', $tcshopInfo['kefu_qrcode']) ){
    if(strpos($tcshopInfo['kefu_qrcode'], 'source/plugin/tom_tcshop/') === FALSE){
        $kefu_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['kefu_qrcode'];
    }else{
        $kefu_qrcode = $tcshopInfo['kefu_qrcode'];
    }
}else{
    $kefu_qrcode = $tcshopInfo['kefu_qrcode'];
}

$mallCateList = C::t('#tom_tcshop#tom_tcshop_mall_cate')->fetch_all_list("AND tcshop_id={$tcshop_id} "," ORDER BY csort ASC,id DESC ",0,100);
$mallCateListCount = count($mallCateList);

$isGuanzu = 0;
if(!empty($__UserInfo['id'])){
    $guanzuListTmp = C::t('#tom_tcshop#tom_tcshop_guanzu')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND tcshop_id={$tcshop_id} "," ORDER BY id DESC ",0,1);
    if(is_array($guanzuListTmp) && !empty($guanzuListTmp)){
        $isGuanzu = 1;
    }
}

$md5HostUrl = md5($_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=shop&tcshop_id={$tcshop_id}");

$kefuSmsUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=message&act=create&&to_user_id=".$tcshopInfo['user_id'].'&formhash='.FORMHASH;
$searchUrl = "plugin.php?id=tom_tcmall:ajax&site={$site_id}&tcshop_id={$tcshop_id}&act=get_shop_search_url";
$ajaxGuanzuUrl = 'plugin.php?id=tom_tcshop:ajax&site='.$site_id.'&act=guanzu&formhash='.$formhash;
$ajaxLoadListUrl = "plugin.php?id=tom_tcmall:ajax&site={$site_id}&act=list&tcshop_id={$tcshop_id}&formhash={$formhash}";
$ajaxLoadListUrl2 = "plugin.php?id=tom_tcmall:ajax&site={$site_id}&act=shop_good_list&tcshop_id={$tcshop_id}&formhash={$formhash}";

$shareTitle = $tcshopInfo['name'].lang('plugin/tom_tcmall','shop_share_title');
$shareLogo = $tcshopPicurl;
$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=shop&tcshop_id={$tcshop_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
//include template("tom_tcmall:shop");
include template("tom_tcmall:shop2");