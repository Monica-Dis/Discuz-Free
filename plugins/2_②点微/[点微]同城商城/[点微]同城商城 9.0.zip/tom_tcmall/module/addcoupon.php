<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['act'] == 'add' && submitcheck('tcshop_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcshop_id          = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $coupon_type        = intval($_GET['coupon_type'])>0? intval($_GET['coupon_type']):0;
    $total_num          = intval($_GET['total_num'])>0? intval($_GET['total_num']):0;
    $full_price         = floatval($_GET['full_price'])>0? floatval($_GET['full_price']):0.00;
    $reduce_price       = floatval($_GET['reduce_price'])>0? floatval($_GET['reduce_price']):0.00;
    $max_lingqu_num     = intval($_GET['max_lingqu_num'])>0? intval($_GET['max_lingqu_num']):0;
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = str_replace("T", " ", $start_time);
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = str_replace("T", " ", $end_time);
    $end_time           = strtotime($end_time);
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $open_score         = intval($_GET['open_score'])>0? intval($_GET['open_score']):0;
    $pay_score          = intval($_GET['pay_score'])>0? intval($_GET['pay_score']):0;
    
    $goodsIdsArr = array();
    $goodsIdsStr = '';
    if(is_array($_GET['goods_ids']) && !empty($_GET['goods_ids'])){
        foreach($_GET['goods_ids'] as $key => $value){
            if(!empty($value)){
                $goodsIdsArr[$key] = intval($value);
            }
        }
        $goodsIdsStr = implode('|', $goodsIdsArr);
    }
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    if($tcshopInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }

    $insertData = array();
    $insertData['site_id']              = $tcshopInfo['site_id'];
    $insertData['tcshop_id']            = $tcshopInfo['id'];
    $insertData['user_id']              = $tcshopInfo['user_id'];
    $insertData['title']                = $title;
    $insertData['coupon_type']          = $coupon_type;
    if($coupon_type == 2){
        $insertData['goods_ids']            = $goodsIdsStr;
    }
    $insertData['total_num']            = $total_num;
    $insertData['lingqu_num']           = $lingqu_num;
    $insertData['full_price']           = $full_price;
    $insertData['reduce_price']         = $reduce_price;
    $insertData['max_lingqu_num']       = $max_lingqu_num;
    $insertData['start_time']           = $start_time;
    $insertData['end_time']             = $end_time;
    $insertData['content']              = $content;
    $insertData['open_score']           = $open_score;
    $insertData['pay_score']            = $pay_score;
    if($total_num > 0 && $start_time <= TIMESTAMP && $end_time > TIMESTAMP){
        $insertData['status']               = 1;
    }
    $insertData['add_time']             = TIMESTAMP;
    if(C::t("#tom_tcmall#tom_tcmall_coupon")->insert($insertData)){
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}

$allTcshopCount = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count(" AND user_id={$__UserInfo['id']} ");

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$__UserInfo['id']} AND v.open_tcmall=1 "," ORDER BY s.id DESC ",0,100);
$tcshopList = array();
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach($tcshopListTmp as $key => $value){
        $tcshopList[$key] = $value;
    }
}
$tcshopCount = count($tcshopList);

$addcouponUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=addcoupon";
$backLinkUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=mycouponlist";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:addcoupon");