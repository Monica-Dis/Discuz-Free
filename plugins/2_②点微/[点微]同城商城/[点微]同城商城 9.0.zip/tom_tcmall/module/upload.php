<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
$upload = new tom_upload();

if($_GET['act'] == 'item_pic' && $_GET['formhash'] == FORMHASH){

    $item_id = intval($_GET['item_id'])>0 ? intval($_GET['item_id']):0;
    $name = "spec_item_pic_".$item_id;
    
    $_FILES[$name]['name'] = addslashes(diconv(urldecode($_FILES[$name]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES[$name], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    require_once libfile('class/image');
    $image = new image();
    $image->Thumb($upload->attach['target'], '', 1000, 1000, 1, 1);
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    $updateData = array();
    $updateData['picurl'] = $upload->attach['attachment'];
    C::t("#tom_tcmall#tom_tcmall_goods_spec_item")->update($item_id, $updateData);
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'picurl' && $_GET['formhash'] == FORMHASH){
    
    $_FILES['filedata1']['name'] = addslashes(diconv(urldecode($_FILES['filedata1']['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata1'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'photo' && $_GET['formhash'] == FORMHASH){
    
    $_FILES['filedata2']['name'] = addslashes(diconv(urldecode($_FILES['filedata2']['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata2'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'pinglun_pic' && $_GET['formhash'] == FORMHASH){

    $order_goods_id = intval($_GET['order_goods_id'])>0 ? intval($_GET['order_goods_id']):0;
    $name = "filedata_".$order_goods_id;

    $_FILES[$name]['name'] = addslashes(diconv(urldecode($_FILES[$name]['name']), 'UTF-8'));

    if(!$upload->init($_FILES[$name], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'refund_picurl' && $_GET['formhash'] == FORMHASH){
    
    $_FILES['filedata']['name'] = addslashes(diconv(urldecode($_FILES['filedata']['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}