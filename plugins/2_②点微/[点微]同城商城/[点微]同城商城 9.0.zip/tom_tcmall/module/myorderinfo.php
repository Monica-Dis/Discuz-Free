<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_no      = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';

$orderInfo  = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_order_no($order_no);
$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);

if($tcshopInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'fahuo' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 1,
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $peisong_name = isset($_GET['peisong_name'])? addslashes($_GET['peisong_name']):'';
    $peisong_info = isset($_GET['peisong_info'])? addslashes($_GET['peisong_info']):'';
    $kuaidi_type  = isset($_GET['kuaidi_type'])? addslashes($_GET['kuaidi_type']):'';
    $kuaidi_no    = isset($_GET['kuaidi_no'])? addslashes($_GET['kuaidi_no']):'';
    
    if($orderInfo['peisong_type'] == 3 && $__ShowKuaidi == 1 && !empty($kuaidi_type)){
        $kuaidiInfo = C::t("#tom_kuaidi#tom_kuaidi")->fetch_by_type($kuaidi_type);
        if(is_array($kuaidiInfo) && !empty($kuaidiInfo)){
            $peisong_name = $kuaidiInfo['name'];
            $peisong_info = $kuaidi_no;
        }
    }
    
    $updateData = array();
    $updateData['peisong_name']     = $peisong_name;
    $updateData['peisong_info']     = $peisong_info;
    if($orderInfo['peisong_type'] == 3){
        $updateData['kuaidi_type']      = $kuaidi_type;
        $updateData['kuaidi_no']        = $kuaidi_no;
    }
    $updateData['order_status']     = 3;
    $updateData['peisong_time']     = TIMESTAMP;
    if(C::t('#tom_tcmall#tom_tcmall_order')->update($orderInfo['id'],$updateData)){
        $goodsOrderListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 1000);
        if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
            foreach($goodsOrderListTmp as $gk => $gv){
                if($gv['order_status'] == 2){
                    $updateData = array();
                    $updateData['order_status'] = 3;
                    C::t('#tom_tcmall#tom_tcmall_order_goods')->update($gv['id'],$updateData);
                }
            }
        }
    }

    if(!empty($tcmallConfig['template_fahuo'])){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        
        $goodsOrderListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 1000);
        $goods_title_arr = array();
        $goods_title_str = '';
        $goods_num = 0;
        if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
            foreach($goodsOrderListTmp as $gk => $gv){
                $goods_title_arr[] = $gv['goods_title'];
                $goods_num = $goods_num + $gv['goods_num'];
            }
        }
        $goods_title_str = implode('|', $goods_title_arr);

        $orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
        if($access_token && !empty($orderUserInfoTmp['openid']) ){
            $templateSmsClass = new mTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=orderinfo&order_no={$order_no}");
            $smsData = array(
                'first'         => lang('plugin/tom_tcmall','template_sms_fahuo'),
                'keyword1'      => $orderInfo['order_no'],
                'keyword2'      => $goods_title_str,
                'keyword3'      => $goods_num,
                'keyword4'      => $orderInfo['pay_price'],
                'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
            );
            $r = $templateSmsClass->sendSmsFahuo($orderUserInfoTmp['openid'],$tcmallConfig['template_fahuo'],$smsData);
        }
    }
    
    $outArr = array(
        'code'=> 200,
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'qianshou' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
        'status'=> 1,
    );

    if($orderInfo['peisong_type'] == 1){
        echo 500;exit;
    }
    if($orderInfo['order_status'] == 1){
        echo 501;exit;
    }
    $updateData = array();
    $updateData['order_status']     = 4;
    $updateData['hexiao_user_id']   = $__UserInfo['id'];
    $updateData['hexiao_time']      = TIMESTAMP;
    if(C::t('#tom_tcmall#tom_tcmall_order')->update($orderInfo['id'],$updateData)){
        $goodsOrderListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 1000);
        if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
            foreach($goodsOrderListTmp as $gk => $gv){
                if($gv['order_status'] == 3 || $gv['order_status'] == 2 || $gv['order_status'] == 8){
                    $updateData = array();
                    $updateData['order_status'] = 4;
                    C::t('#tom_tcmall#tom_tcmall_order_goods')->update($gv['id'],$updateData);
                }
            }
        }
    }

    if($orderInfo['balance_status'] == 0 && $orderInfo['huodao_pay_status'] == 0){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/module/balance.php';
    }

    $outArr = array(
        'code'=> 200,
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
}

$refundStatus = 0;
$orderGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 100);
$orderGoodsList = array();
if(is_array($orderGoodsListTmp) && !empty($orderGoodsListTmp)){
    foreach($orderGoodsListTmp as $key => $value){
        $orderGoodsList[$key] = $value;
        $goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($value['goods_id']);
        if(!preg_match('/^http/', $goodsInfoTmp['picurl']) ){
            if(strpos($goodsInfoTmp['picurl'], 'source/plugin/tom_tcmall/') === false){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfoTmp['picurl'];
            }else{
                $picurlTmp = $_G['siteurl'].$goodsInfoTmp['picurl'];
            }
        }else{
            $picurlTmp = $goodsInfoTmp['picurl'];
        }

        $refundInfoTmp = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_all_list(" AND order_id = {$orderInfo['id']} AND order_goods_id = {$value['id']} AND refund_status IN(1,2) ", 'ORDER BY id DESC', 0, 1);
        if(is_array($refundInfoTmp) && !empty($refundInfoTmp[0])){
            if($refundInfoTmp[0]['refund_status'] == 1){
                $refundStatus = 1;
            }
            $orderGoodsList[$key]['refundInfo'] = $refundInfoTmp[0];
        }

        $orderGoodsList[$key]['goodsInfo'] = $goodsInfoTmp;
        $orderGoodsList[$key]['goodsInfo']['picurl'] = $picurlTmp;
    }
}

$stateStr = "";
if( $orderInfo['order_status'] == 1 || $orderInfo['order_status'] == 2 || $orderInfo['order_status'] == 8){
    $stateStr = "state_1";
}
if( $orderInfo['order_status'] == 3){
    $stateStr = "state_2";
}
if( $orderInfo['order_status'] == 4){
    $stateStr = "state_3";
}

$hexiaoUserInfo = array();
if($orderInfo['order_status'] == 4){
    $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']); 
}

$showQianshouBtn = 0;
if($orderInfo['order_status'] == 3 && $orderInfo['peisong_time'] > 0){
    if(TIMESTAMP > ($orderInfo['peisong_time'] + 86400 * $tcmallConfig['goods_autoreceive'])){
        $showQianshouBtn = 1;
    }
}

$showFahuoBox = 0;
if($orderInfo['order_status'] == 2 || $orderInfo['order_status'] == 3 || $orderInfo['order_status'] == 8){
    $showFahuoBox = 1;
}

$kuaidiList = array();
if($orderInfo['peisong_type'] == 3 && $__ShowKuaidi == 1){
    $kuaidiListTmp = C::t("#tom_kuaidi#tom_kuaidi")->fetch_all_list(" ", 'ORDER BY sort ASC, id DESC');
    if(is_array($kuaidiListTmp) && !empty($kuaidiListTmp)){
        foreach($kuaidiListTmp as $key => $value){
            $kuaidiList[$key] = $value;
        }
    }
}

if($orderInfo['peisong_type'] == 2 && empty($orderInfo['peisong_name'])){
    $orderPeisongListTmp  = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_list(" AND tcshop_id = {$orderInfo['tcshop_id']} AND peisong_type = 2 AND order_status IN (3,4) "," ORDER BY peisong_time DESC,id DESC ",0,1, '');
    if(is_array($orderPeisongListTmp) && !empty($orderPeisongListTmp[0])){
        $orderInfo['peisong_name'] = $orderPeisongListTmp[0]['peisong_name'];
        $orderInfo['peisong_info'] = $orderPeisongListTmp[0]['peisong_info'];
    }
}

$showPeisongBox = 1;
if($orderInfo['peisong_type'] == 3){
    if($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList) && empty($orderInfo['peisong_name']) && empty($orderInfo['peisong_info'])){
        $showPeisongBox = 2;
    }
    if($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList) && !empty($orderInfo['kuaidi_no']) && !empty($orderInfo['kuaidi_type'])){
        $showPeisongBox = 2;
    }
    
    $kuaidiSmsList = array();
    if(!empty($orderInfo['kuaidi_no']) && !empty($orderInfo['kuaidi_type']) && $__ShowKuaidi == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_kuaidi/kuaidi.func.php';
        $kuaidiNoArr = explode(' ', $orderInfo['kuaidi_no']);
        if(is_array($kuaidiNoArr) && !empty($kuaidiNoArr)){
            foreach($kuaidiNoArr as $key => $value){
                $value = trim($value);
                if(!empty($value)){
                    $kuaidiArr = query_kuaidi($value, $orderInfo['kuaidi_type']);
                    if($kuaidiArr){
                        $kuaidiSmsList[$key] = $kuaidiArr;
                        $kuaidiSmsList[$key]['kuaidi_no'] = $value;
                    }
                }
            }
        }
    }
}

if($orderInfo['peisong_type'] == 1 && $orderInfo['tcshop_place_id'] > 0){
    $tcshopPlaceInfo = C::t("#tom_tcshop#tom_tcshop_place")->fetch_by_id($orderInfo['tcshop_place_id']);
}

$fahuoUrl       = 'plugin.php?id=tom_tcmall&site='.$site_id.'&mod=myorderinfo&act=fahuo&formhash='.$formhash;
$qianshouUrl    = 'plugin.php?id=tom_tcmall&site='.$site_id.'&mod=myorderinfo&act=qianshou&formhash='.$formhash;


$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:myorderinfo");