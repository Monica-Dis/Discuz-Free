<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_no = isset($_GET['order_no'])? addslashes($_GET['order_no']):'';
$order_goods_id = intval($_GET['order_goods_id'])> 0? intval($_GET['order_goods_id']):0;

$orderInfo = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_order_no($order_no);

if($orderInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=index");exit;
}

$orderGoodsInfo = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_by_id($order_goods_id);
$goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($orderGoodsInfo['goods_id']);

$maxRefundPrice = $orderGoodsInfo['real_price'];
$dispatchPrice = $orderGoodsInfo['dispatch_price'];

if(!preg_match('/^http/', $goodsInfo['picurl']) ){
    if(strpos($goodsInfo['picurl'], 'source/plugin/tom_tcmall/') === false){
        $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['picurl'];
    }else{
        $picurlTmp = $_G['siteurl'].$goodsInfo['picurl'];
    }
}else{
    $picurlTmp = $goodsInfo['picurl'];
}

$succbackUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=refundinfo&form=refund&refund_id=";
$ajaxSaveUrl = "plugin.php?id=tom_tcmall:ajax&site={$site_id}&act=refund_save";
$uploadUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=upload&act=refund_picurl&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:refund");