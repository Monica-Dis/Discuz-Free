<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

$tcshopListTmp = C::t("#tom_tcshop#tom_tcshop")->fetch_all_list("  AND user_id = {$__UserInfo['id']} ", "ORDER BY id DESC", 0, 1000);
$tcshopIdsArr = array();
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach($tcshopListTmp as $key => $value){
        $tcshopIdsArr[] = $value['id'];
    }
}

$tcshopIdsStr = implode(',', $tcshopIdsArr);

$whereStr = " AND tcshop_id IN({$tcshopIdsStr}) AND refund_status IN(1,2,3,4) ";
if($type == 1){
    $whereStr .= " AND refund_status = 1 ";
}else if($type == 2){
    $whereStr .= " AND refund_status = 2 ";
}else{
    $whereStr .= " AND refund_status IN(1,2,3,4) ";
}

$pagesize   = 8;
$start      = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_all_count($whereStr);
$refundListTmp  = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_all_list($whereStr," ORDER BY id DESC ",$start,$pagesize);
$refundList = array();
if(is_array($refundListTmp) && !empty($refundListTmp)){
    foreach ($refundListTmp as $key => $value){
        $refundList[$key] = $value;

        $orderGoodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_by_id($value['order_goods_id']);
        $goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($orderGoodsInfoTmp['goods_id']);

        if(!preg_match('/^http/', $goodsInfoTmp['picurl']) ){
            if(strpos($goodsInfoTmp['picurl'], 'source/plugin/tom_tcmall/') === false){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfoTmp['picurl'];
            }else{
                $picurlTmp = $_G['siteurl'].$goodsInfoTmp['picurl'];
            }
        }else{
            $picurlTmp = $goodsInfoTmp['picurl'];
        }
        $goodsInfoTmp['picurl'] = $picurlTmp;

        $refundList[$key]['orderGoodsInfo'] = $orderGoodsInfoTmp;
        $refundList[$key]['goodsInfo'] = $goodsInfoTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=myrefundlist&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=myrefundlist&type={$type}&page={$nextPage}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:myrefundlist");