<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_no = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
$orderInfo = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_order_no($order_no);
$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);

if($orderInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'qianshou' && $_GET['formhash'] == FORMHASH){

    if($orderInfo['peisong_type'] == 1){
        echo 500;exit;
    }
    if($orderInfo['order_status'] == 1){
        echo 501;exit;
    }
    $updateData = array();
    $updateData['order_status']     = 4;
    $updateData['hexiao_user_id']   = $__UserInfo['id'];
    $updateData['hexiao_time']      = TIMESTAMP;
    if(C::t('#tom_tcmall#tom_tcmall_order')->update($orderInfo['id'],$updateData)){
        $goodsOrderListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 1000);
        if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
            foreach($goodsOrderListTmp as $gk => $gv){
                if($gv['order_status'] == 3 || $gv['order_status'] == 2 || $gv['order_status'] == 8){
                    $updateData = array();
                    $updateData['order_status'] = 4;
                    if(C::t('#tom_tcmall#tom_tcmall_order_goods')->update($gv['id'],$updateData)){
                        $refundInfoTmp = C::t("#tom_tcmall#tom_tcmall_refund")->fetch_all_list("AND order_id = {$orderInfo['id']} AND order_goods_id = {$gv['id']} AND refund_status = 1", 'ORDER BY id DESC', 0, 1);
                        if(is_array($refundInfoTmp) && !empty($refundInfoTmp[0])){
                            $updateData = array();
                            $updateData['refund_status'] = 3;
                            $updateData['refund_time']   = TIMESTAMP;
                            C::t("#tom_tcmall#tom_tcmall_refund")->update($refundInfoTmp[0]['id'], $updateData);
                        }
                    }
                }
            }
        }
    }

    if($orderInfo['balance_status'] == 0 && $orderInfo['huodao_pay_status'] == 0){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/module/balance.php';
    }

    echo 200;exit;
}

$refundStatus = 0;
$goodsListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id={$orderInfo['id']} ", 'ORDER BY id DESC', 0, 100);
$goodsList = array();
if(is_array($goodsListTmp) && !empty($goodsListTmp)){
    foreach($goodsListTmp as $key => $value){
        $goodsList[$key] = $value;

        $goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($value['goods_id']);
        if(!preg_match('/^http/', $goodsInfoTmp['picurl']) ){
            if(strpos($goodsInfoTmp['picurl'], 'source/plugin/tom_tcmall/') === false){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfoTmp['picurl'];
            }else{
                $picurlTmp = $_G['siteurl'].$goodsInfoTmp['picurl'];
            }
        }else{
            $picurlTmp = $goodsInfoTmp['picurl'];
        }
        $goodsInfoTmp['picurl'] = $picurlTmp;
        if($value['order_status'] == 2 || $value['order_status'] == 3 || $value['order_status'] == 7){
            $goodsRefundInfoTmp = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_all_list("AND order_id = {$orderInfo['id']} AND order_goods_id = {$value['id']} AND refund_status IN(1,2) ", 'ORDER BY id DESC', 0, 1);
            if(is_array($goodsRefundInfoTmp) && !empty($goodsRefundInfoTmp[0])){
                if($goodsRefundInfoTmp[0]['refund_status'] == 1){
                    $refundStatus = 1;
                }
                $goodsList[$key]['refundInfo'] = $goodsRefundInfoTmp[0];
            }
        }

        $goodsList[$key]['goodsInfo'] = $goodsInfoTmp;
    }
}

$open_wx_map = 0;
if($__IsWeixin == 1 && $tcshopConfig['open_wx_map'] == 1){
    $open_wx_map = 1;
}

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

if($orderInfo['peisong_type'] == 1){
    $qrcodeImg = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=orderhexiao&hexiao_no={$orderInfo['hexiao_no']}");
    
    $placeInfo = array();
    if($orderInfo['tcshop_place_id'] > 0){
        $tcshopPlaceInfo = C::t("#tom_tcshop#tom_tcshop_place")->fetch_by_id($orderInfo['tcshop_place_id']);
        
        $baiduMapToName = $tcshopPlaceInfo['name'];
        $baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
        $baiduMapToName = urlencode($baiduMapToName);
        $baiduMapUrl = "http://api.map.baidu.com/marker?location={$tcshopPlaceInfo['latitude']},{$tcshopPlaceInfo['longitude']}&title={$baiduMapToName}&content=&output=html";
        
        $juliTmp = 0;
        if(!empty($longitude) && !empty($latitude) && !empty($tcshopPlaceInfo['longitude']) && !empty($tcshopPlaceInfo['latitude'])){
            $juliTmp = tomGetDistance($longitude, $latitude, $tcshopPlaceInfo['longitude'], $tcshopPlaceInfo['latitude']);
        }
        
        $placeInfo = $tcshopPlaceInfo;
        $placeInfo['baiduMapUrl']   = $baiduMapUrl;
        $placeInfo['juli']          = $juliTmp;
        
    }else{
        
        $baiduMapToName = $tcshopInfo['name'];
        $baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
        $baiduMapToName = urlencode($baiduMapToName);
        $baiduMapUrl = "http://api.map.baidu.com/marker?location={$tcshopInfo['latitude']},{$tcshopInfo['longitude']}&title={$baiduMapToName}&content=&output=html";
        
        $juliTmp = 0;
        if(!empty($longitude) && !empty($latitude) && !empty($tcshopInfo['longitude']) && !empty($tcshopInfo['latitude'])){
            $juliTmp = tomGetDistance($longitude, $latitude, $tcshopInfo['longitude'], $tcshopInfo['latitude']);
        }
        
        $placeInfo = $tcshopInfo;
        $placeInfo['baiduMapUrl']   = $baiduMapUrl;
        $placeInfo['juli']          = $juliTmp;
    }
    
}else if($orderInfo['peisong_type'] == 3){
    $kuaidiSmsList = array();
    if(!empty($orderInfo['kuaidi_no']) && !empty($orderInfo['kuaidi_type']) && $__ShowKuaidi == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_kuaidi/kuaidi.func.php';
        $kuaidiNoArr = explode(' ', $orderInfo['kuaidi_no']);
        if(is_array($kuaidiNoArr) && !empty($kuaidiNoArr)){
            foreach($kuaidiNoArr as $key => $value){
                $value = trim($value);
                if(!empty($value)){
                    if($orderInfo['kuaidi_type'] == 'SFEXPRESS' && preg_match('/[0-9]{11}/', $orderInfo['address_tel'])){
                        $value.= ":".substr($orderInfo['address_tel'],-4);
                    }
                    $kuaidiArr = query_kuaidi($value, $orderInfo['kuaidi_type']);
                    if($kuaidiArr){
                        $kuaidiSmsList[$key] = $kuaidiArr;
                        $kuaidiSmsList[$key]['kuaidi_no'] = $value;
                    }
                }
            }
        }
    }
}

$payUrl = "plugin.php?id=tom_tcmall:pay&site={$site_id}&act=order_pay&user_id={$__UserInfo['id']}&order_id={$orderInfo['id']}&formhash={$formhash}";
$ajaxCancelUrl = "plugin.php?id=tom_tcmall:pay&site={$site_id}&act=order_cancel&order_id={$orderInfo['id']}&formhash={$formhash}";
$qianshouUrl    = 'plugin.php?id=tom_tcmall&site='.$site_id.'&mod=orderinfo&act=qianshou&order_no='.$order_no.'&formhash='.$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:orderinfo");