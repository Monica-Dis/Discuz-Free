<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($goods_id);
$tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($goodsInfo['tcshop_id']);

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $stock = isset($_GET['stock'])? intval($_GET['stock']):0;
    
    $updateData = array();
    $updateData['stock'] = $stock;
    $updateData['part1'] = TIMESTAMP;
    if(C::t('#tom_tcmall#tom_tcmall_goods')->update($goods_id,$updateData)){
            
        $insertData = array();
        $insertData['is_admin']     = 0;
        $insertData['is_option']    = 0;
        $insertData['goods_id']     = $goods_id;
        $insertData['change_num']   = $stock;
        $insertData['change_time']  = TIMESTAMP;
        C::t('#tom_tcmall#tom_tcmall_goods_stock_log')->insert($insertData);

        $outArr = array(
            'status'=> 200,
            'goods_id'=> $goods_id,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }

}

$saveUrl = "plugin.php?id=tom_tcmall&site={$site_id}&mod=editstock&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:editstock");