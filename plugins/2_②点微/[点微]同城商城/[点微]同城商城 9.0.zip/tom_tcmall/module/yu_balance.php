<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

$sendTemplateTchehuorenList = $sendTemplateTchehuorenParentList = array();

## foreach start
foreach ($yu_balance_orders as $key => $orderInfo){
    
    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
    $orderTcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);
    $orderUserInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderTcshopInfo['user_id']);

    if($orderInfo['pay_price'] >= 0.1){

        $default_yongjin_bili = $tcmallConfig['yongjin_bili'];

        $orderGoodsList = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 100);
        if(is_array($orderGoodsList) && !empty($orderGoodsList)){
            foreach($orderGoodsList as $key => $value){

                $goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($value['goods_id']);

                if($goodsInfoTmp['yongjin_bili'] > 0){
                    $yongjin_bili = $goodsInfoTmp['yongjin_bili'];
                }else{
                    $yongjin_bili = $default_yongjin_bili;
                }

                if($yongjin_bili <= 100){

                    $pt_money = $value['real_price']*($yongjin_bili/100);
                    $pt_money = number_format($pt_money,2, '.', '');

                    if($pt_money >= 0.1){
                        # fc start
                        if($__ShowTchehuoren == 1 && $value['tj_hehuoren_id'] > 0 && $goodsInfoTmp['hehuoren_tg_open'] == 1){

                            $shenyu_money = $pt_money;
                            $child_site_fc_money = $tchehuoren_fc_money = $tctchehuorenParent_fc_money = 0;

                            $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($value['tj_hehuoren_id']);
                            if($tchehuorenInfo){
                                $tchehuorenDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
                                $tchehuorenUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tchehuorenInfo['openid']);
                            }

                            $tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
                            if($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1){
                                $tctchehuorenParentInfo = C::t("#tom_tchehuoren#tom_tchehuoren")->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
                                $tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
                                $tctchehuorenParentUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tctchehuorenParentInfo['openid']);
                            }

                            if($tchehuorenInfo && $tchehuorenInfo['status'] == 1 && $tchehuorenDengji['mall_fc_open'] == 1){
                                if($orderInfo['site_id'] > 1 && $tcmallConfig['zizhandi_fc'] == 1){
                                    $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                                    $sitename = $sitesInfo['name'];
                                    if($__ShowTcadmin && $sitesInfo['hehuoren_fc_open'] == 1){

                                        if($tchehuorenDengji['level'] == 1){
                                            $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['chuji_fc_scale']/100);
                                        }else if($tchehuorenDengji['level'] == 2){
                                            $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['zhongji_fc_scale']/100);
                                        }else if($tchehuorenDengji['level'] == 3){
                                            $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['gaoji_fc_scale']/100);
                                        }
                                        $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2, '.', '');

                                        $fc_scale = $sitesInfo['mall_fc_scale'];
                                        if($fc_scale > 0){
                                            $child_site_fc_money = $pt_money * ($fc_scale/100);
                                            $child_site_fc_money = number_format($child_site_fc_money,2, '.', '');
                                            $child_site_fc_money = $child_site_fc_money - $tchehuoren_fc_money;
                                        }
                                        if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                                            $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                                            $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                                            if($tchehuorenConfig['subordinate_moneytype'] == 1){
                                                $child_site_fc_money   = $child_site_fc_money - $tctchehuorenParent_fc_money;
                                            }else{
                                                $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                                            }
                                        }

                                        $shenyu_money = $shenyu_money - $child_site_fc_money - $tchehuoren_fc_money - $tctchehuorenParent_fc_money;

                                    }else{
                                        if($__ShowTcadmin == 1 && $tcmallConfig['zizhandi_fc'] == 1){
                                            $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                                            $fc_scale = $sitesInfo['mall_fc_scale'];
                                            if($fc_scale > 0){
                                                $child_site_fc_money = $pt_money * ($fc_scale/100);
                                                $child_site_fc_money = number_format($child_site_fc_money,2, '.', '');
                                            }
                                        }

                                        $shenyu_money = $shenyu_money - $child_site_fc_money;

                                    }

                                }else{
                                    $sitename = $tongchengConfig['plugin_name'];
                                    if($tchehuorenDengji['level'] == 1){
                                        $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['chuji_fc_scale']/100);
                                    }else if($tchehuorenDengji['level'] == 2){
                                        $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['zhongji_fc_scale']/100);
                                    }else if($tchehuorenDengji['level'] == 3){
                                        $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['gaoji_fc_scale']/100);
                                    }
                                    $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2, '.', '');

                                    if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                                        $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                                        if($tchehuorenConfig['subordinate_moneytype'] == 1){
                                        }else{
                                            $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                                        }
                                    }

                                    $shenyu_money = $shenyu_money - $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                                }

                                if($pt_money >= ($child_site_fc_money +  $tchehuoren_fc_money + $tctchehuorenParent_fc_money)){  

                                    $sendTemplateTchehuoren = false;
                                    if($tchehuoren_fc_money > 0){
                                        $sendTemplateTchehuoren = true;

                                        $insertData = array();
                                        $insertData['order_no']         = $orderInfo['order_no'];
                                        $insertData['hehuoren_id']      = $tchehuorenInfo['id'];
                                        $insertData['ly_user_id']       = $userInfoTmp['id'];
                                        $insertData['child_hehuoren_id'] = 0;
                                        $insertData['today_time']       = $nowDayTime;
                                        $insertData['week_time']        = $nowWeekTime;
                                        $insertData['month_time']       = $nowMonthTime;
                                        $insertData['title']            = $goodsInfoTmp['title'];
                                        $insertData['type']             = lang('plugin/tom_tcmall', 'hehuoren_tag_mall');
                                        $insertData['shouyi_price']     = $tchehuoren_fc_money;
                                        $insertData['content']          = lang('plugin/tom_tcmall', 'hehuoren_beizu_1') . $orderInfo['order_no'] . lang('plugin/tom_tcmall', 'hehuoren_beizu_2') . $userInfoTmp['nickname'];
                                        $insertData['shouyi_status']    = 1;
                                        $insertData['add_time']         = TIMESTAMP;
                                        C::t('#tom_tchehuoren#tom_tchehuoren_yushouyi')->insert($insertData);
                                    }

                                    $sendTemplateTchehuorenParent = false;
                                    if($tctchehuorenParent_fc_money > 0){
                                        $sendTemplateTchehuorenParent = true;

                                        $insertData = array();
                                        $insertData['order_no']         = $orderInfo['order_no'];
                                        $insertData['hehuoren_id']      = $tctchehuorenParentInfo['id'];
                                        $insertData['ly_user_id']       = $userInfoTmp['id'];
                                        $insertData['child_hehuoren_id'] = $tchehuorenInfo['id'];
                                        $insertData['today_time']       = $nowDayTime;
                                        $insertData['week_time']        = $nowWeekTime;
                                        $insertData['month_time']       = $nowMonthTime;
                                        $insertData['title']            = $goodsInfoTmp['title'];
                                        $insertData['type']             = lang('plugin/tom_tcmall', 'hehuoren_tag_mall');
                                        $insertData['shouyi_price']     = $tctchehuorenParent_fc_money;
                                        $insertData['content']          = lang('plugin/tom_tcmall', 'hehuoren_beizu_1') . $orderInfo['order_no'] . lang('plugin/tom_tcmall', 'hehuoren_beizu_2') . $userInfoTmp['nickname'];
                                        $insertData['shouyi_status']    = 1;
                                        $insertData['add_time']         = TIMESTAMP;
                                        C::t('#tom_tchehuoren#tom_tchehuoren_yushouyi')->insert($insertData);
                                    }
                                }

                            }
                        }
                        # fc end

                        if($sendTemplateTchehuoren == true){
                            $sendTemplateTchehuorenTmp = array();
                            $sendTemplateTchehuorenTmp['tchehuorenInfo']        = $tchehuorenInfo;
                            $sendTemplateTchehuorenTmp['orderInfo']             = $orderInfo;
                            $sendTemplateTchehuorenTmp['userInfoTmp']           = $userInfoTmp;
                            $sendTemplateTchehuorenTmp['sitename']              = $sitename;
                            $sendTemplateTchehuorenTmp['tchehuoren_fc_money']   = $tchehuoren_fc_money;
                            $sendTemplateTchehuorenList[]                       = $sendTemplateTchehuorenTmp;
                        }
                        if($sendTemplateTchehuorenParent == true){
                            $sendTemplateTchehuorenParentTmp = array();
                            $sendTemplateTchehuorenParentTmp['tchehuorenInfo']          = $tchehuorenInfo;
                            $sendTemplateTchehuorenParentTmp['tctchehuorenParentInfo']  = $tctchehuorenParentInfo;
                            $sendTemplateTchehuorenParentTmp['orderInfo']               = $orderInfo;
                            $sendTemplateTchehuorenParentTmp['userInfoTmp']             = $userInfoTmp;
                            $sendTemplateTchehuorenParentTmp['sitename']                = $sitename;
                            $sendTemplateTchehuorenParentTmp['tctchehuorenParent_fc_money']     = $tctchehuorenParent_fc_money;
                            $sendTemplateTchehuorenParentList[]                         = $sendTemplateTchehuorenParentTmp;
                        }

                    }
                }
            }
        }
    }
    
}
## foreach end

if(!empty($tchehuorenConfig['template_id'])){
    $template_id = $tchehuorenConfig['template_id'];
}else{
    $template_id = $tongchengConfig['template_id'];
}
if(is_array($sendTemplateTchehuorenList) && !empty($sendTemplateTchehuorenList)){
    foreach ($sendTemplateTchehuorenList as $key => $value){
        $access_token = @$weixinClass->get_access_token();
        if($access_token && !empty($value['tchehuorenInfo']['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$value['orderInfo']['site_id']}&mod=index");
            $shouyiText = str_replace("{NICKNAME}",$value['userInfoTmp']['nickname'], lang('plugin/tom_tongcheng', 'paynotify_hehuoren_template'));
            $shouyiText = str_replace("{TONGCHNEG}",$value['sitename'], $shouyiText);
            $shouyiText = str_replace("{TYPE}",lang('plugin/tom_tcmall', 'hehuoren_tag_mall'), $shouyiText);
            $shouyiText = str_replace("{MONEY}",$value['tchehuoren_fc_money'], $shouyiText);
            $smsData = array(
                'first'         => lang('plugin/tom_tchehuoren', 'yujishouyi').$shouyiText,
                'keyword1'      => $tchehuorenConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );
            $r = @$templateSmsClass->sendSms01($value['tchehuorenInfo']['openid'], $template_id, $smsData);
        }
    }
}

if(is_array($sendTemplateTchehuorenParentList) && !empty($sendTemplateTchehuorenParentList)){
    foreach ($sendTemplateTchehuorenParentList as $key => $value){
        $access_token = @$weixinClass->get_access_token();
        if($access_token && !empty($value['tctchehuorenParentInfo']['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$value['orderInfo']['site_id']}&mod=index");
            $shouyiText = str_replace("{TCHEHUOREN}",$value['tchehuorenInfo']['xm'], lang('plugin/tom_tongcheng', 'paynotify_hehuorenparent_template'));
            $shouyiText = str_replace("{NICKNAME}",$value['userInfoTmp']['nickname'], $shouyiText);
            $shouyiText = str_replace("{TONGCHNEG}",$value['sitename'], $shouyiText);
            $shouyiText = str_replace("{TYPE}",lang('plugin/tom_tcmall', 'hehuoren_tag_mall'), $shouyiText);
            $shouyiText = str_replace("{MONEY}",$value['tctchehuorenParent_fc_money'], $shouyiText);
            $smsData = array(
                'first'         => lang('plugin/tom_tchehuoren', 'yujishouyi').$shouyiText,
                'keyword1'      => $tchehuorenConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            $r = @$templateSmsClass->sendSms01($value['tctchehuorenParentInfo']['openid'], $template_id, $smsData);
        }
    }
}