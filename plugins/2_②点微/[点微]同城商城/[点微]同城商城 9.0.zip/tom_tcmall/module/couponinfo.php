<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$s          = intval($_GET['s'])>0?intval($_GET['s']):0;
$coupon_id  = intval($_GET['coupon_id'])>0?intval($_GET['coupon_id']):0;

$couponInfo = C::t("#tom_tcmall#tom_tcmall_coupon")->fetch_by_id($coupon_id);
if(is_array($couponInfo) && !empty($couponInfo) && $couponInfo['status'] == 1){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=couponlist");exit;
}

$couponInfo['reduce_price'] = floatval($couponInfo['reduce_price']);
$couponInfo['full_price'] = floatval($couponInfo['full_price']);

$tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($couponInfo['tcshop_id']);
if(!preg_match('/^http/', $tcshopInfo['picurl']) ){
    if(strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $tcshopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['picurl'];
    }else{
        $tcshopPicurl = $_G['siteurl'].$tcshopInfo['picurl'];
    }
}else{
    $tcshopPicurl = $tcshopInfo['picurl'];
}

$lingquStatus = 1;
if($couponInfo['start_time'] > TIMESTAMP){
    $lingquStatus = 2;
}

if($couponInfo['end_time'] <= TIMESTAMP){
    $lingquStatus = 3;
}

if($couponInfo['total_num'] <= $couponInfo['lingqu_num']){

    $updateData = array();
    $updateData['status'] = 0;
    C::t("#tom_tcmall#tom_tcmall_coupon")->update($couponInfo['id'], $updateData);
    $lingquStatus = 4;
}

$lingquCount = C::t("#tom_tcmall#tom_tcmall_coupon_lingqu")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND coupon_id = {$couponInfo['id']} ");
if($lingquCount > 0 && $lingquCount >= $couponInfo['max_lingqu_num']){
    $lingquStatus = 5;
}

$lingquInfoTmp = C::t("#tom_tcmall#tom_tcmall_coupon_lingqu")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND coupon_id = {$couponInfo['id']} AND status = 0 ", 'ORDER BY id ASC', 0, 1);
if(is_array($lingquInfoTmp) && !empty($lingquInfoTmp[0])){
    $lingquStatus = 6;
}

if($couponInfo['coupon_type'] == 2){
    $whereStr = ' AND status=1 AND shenhe_status=1';
    $goodsIdsArr = explode('|', $couponInfo['goods_ids']);
    $goodsIdsStr = implode(',', $goodsIdsArr);
    $whereStr.= " AND id IN({$goodsIdsStr}) ";
    $goodsListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list($whereStr, "ORDER BY gsort DESC ,add_time DESC,id DESC", 0, 3);
    $goodsList = array();
    if(is_array($goodsListTmp) && !empty($goodsListTmp)){
        foreach ($goodsListTmp as $key => $value) {
            $goodsList[$key] = $value;
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurl = $_G['siteurl'].$value['picurl'];
                }
            }else{
                $picurl = $value['picurl'];
            }

            $goodsList[$key]['picurl'] = $picurl;
        }
    }
    $goodsCount = count($goodsList);
}

$ajaxLingquCouponUrl = "plugin.php?id=tom_tcmall:ajax&site={$site_id}&act=lingqu_coupon&user_id={$__UserInfo['id']}&coupon_id={$couponInfo['id']}&formhash={$formhash}";

$shareLogo = $tcshopPicurl;
$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=couponinfo&coupon_id={$couponInfo['id']}&s=1";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:couponinfo");