<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';
    
$keyword        = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$tcshop_id      = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$goodstype      = isset($_GET['goodstype'])? daddslashes($_GET['goodstype']):'';
$shop_cate_id   = intval($_GET['shop_cate_id'])>0? intval($_GET['shop_cate_id']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):20;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND status=1 AND shenhe_status=1';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($tcshop_id)){
    $whereStr.= " AND tcshop_id={$tcshop_id} ";
}
if(!empty($shop_cate_id)){
    $whereStr.= " AND shop_cate_id={$shop_cate_id} ";
}

$goodsStr = " ORDER BY gsort DESC ,add_time DESC,id DESC ";
if($goodstype == 'new'){
    $goodsStr = " ORDER BY add_time DESC,id DESC ";
}else if($goodstype == 'hot'){
    $goodsStr = " ORDER BY sales DESC,id DESC ";
}else if($goodstype == 'rec'){
    $goodsStr = " ORDER BY isrecommand DESC,gsort DESC ,id DESC ";
}
$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
$goodsListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list($whereStr,$goodsStr,$start,$pagesize,$keyword);
$goodsList = array();
if(is_array($goodsListTmp) && !empty($goodsListTmp)){
    foreach ($goodsListTmp as $key => $value) {
        $goodsList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }

        $photoInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods_photo')->fetch_all_list(" AND goods_id = {$value['id']} AND type = 2 "," ORDER BY id ASC ",0,1);
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurl = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $goodsSpecCountTmp = 0;
        if($value['hasoption'] == 1){
            $goodsSpecCountTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec')->fetch_all_count(" AND goods_id={$value['id']} ");
        }

        $goodsList[$key]['picurl']      = $picurl;
        $goodsList[$key]['sales']       = $value['virtual_sales'] + $value['sales'];
        $goodsList[$key]['specCount']   = $goodsSpecCountTmp;
    }
}

if(is_array($goodsList) && !empty($goodsList)){
    foreach ($goodsList as $key => $val){
        $outStr .= '<div class="shop-list__item dislay-flex">';
            $outStr .= '<a href="plugin.php?id=tom_tcmall&site='.$site_id.'&mod=goodsinfo&goods_id='.$val['id'].'" class="goods-pic"><img src="'.$val['picurl'].'"></a>';
            $outStr .= '<div class="goods-content flex">';
                $outStr .= '<a href="plugin.php?id=tom_tcmall&site='.$site_id.'&mod=goodsinfo&goods_id='.$val['id'].'" class="goods-title">'.$val['title'].'</a>';
                $outStr .= '<div class="goods-xq">';
                    $outStr .= '<a class="price" href="plugin.php?id=tom_tcmall&site='.$site_id.'&mod=goodsinfo&goods_id='.$val['id'].'">'.lang('plugin/tom_tcmall', 'yuan_ico').$val['show_buy_price'].'</a>';
                    if($tcshopInfo['open_shop_list_cart'] == 1 && $val['specCount'] <= 1){
                        $outStr .= '<a href="javascript:void(0);" class="cart id_mini_cart_btn" data-id="'.$val['id'].'"><i class="tciconfont tcicon-mall__cart"></i></a>';
                    }else{
                        $outStr .= '<a class="volume" href="plugin.php?id=tom_tcmall&site='.$site_id.'&mod=goodsinfo&goods_id='.$val['id'].'">'.lang('plugin/tom_tcmall', 'ajax_goods_yishou').$val['sales'].'</a>';
                    }
                $outStr .= '</div>';
            $outStr .= '</div>';
        $outStr .= '</div>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;