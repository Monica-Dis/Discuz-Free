<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$timeStamp          = TIMESTAMP;
$tcmallConfig       = $_G['cache']['plugin']['tom_tcmall'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset       = getglobal('setting/timeoffset');

$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass        = new weixinClass($appid,$appsecret);

## tcyikatong start
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
    $tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $__ShowTcyikatong = 1;
    }
}
## tcyikatong end#
## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## print start
$__ShowPrint = 0;
$printConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_print/tom_print.inc.php')){
    $printConfig = $_G['cache']['plugin']['tom_print'];
    if($printConfig['open_print'] == 1){
        $__ShowPrint = 1;
    }
}
## print end


include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcshop/class/function.express.php';

$act = isset($_GET['act'])? addslashes($_GET['act']):"order";

if($act == "order" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $cart_buy_ids   = isset($_GET['cart_buy_ids'])? daddslashes($_GET['cart_buy_ids']):'';
    $address_id     = intval($_GET['address_id'])>0? intval($_GET['address_id']):0;
    $zq_address_xm  = isset($_GET['zq_address_xm'])? daddslashes($_GET['zq_address_xm']):'';
    $zq_address_tel = isset($_GET['zq_address_tel'])? daddslashes($_GET['zq_address_tel']):'';
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $beizu          = isset($_GET['beizu'])? daddslashes($_GET['beizu']):'';

    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    $addressInfo = array();
    if($address_id > 0){
        $addressInfo = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
    }

    if(!empty($addressInfo) && $addressInfo['id'] > 0){
        $zq_address_xm = $addressInfo['xm'];
        $zq_address_tel = $addressInfo['tel'];
    }
    
    if(!$userInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $__CardInfo = array();
    if($__ShowTcyikatong == 1 && $user_id > 0){
        $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($user_id);
        if(is_array($cardInfoTmp) && !empty($cardInfoTmp)){
            $__CardInfo = $cardInfoTmp;
        }
    }
    
    $cartBuyIdsArrTmp = explode(',', $cart_buy_ids);
    $cartBuyIdsArr = array();
    if(is_array($cartBuyIdsArrTmp) && !empty($cartBuyIdsArrTmp)){
        foreach($cartBuyIdsArrTmp as $key => $value){
            if(!empty($value)){
                $cartBuyIdsArr[] = intval($value);
            }
        }
    }
    $cartBuyIds = implode(',', $cartBuyIdsArr);

    $cartListTmp = C::t('#tom_tcmall#tom_tcmall_cart')->fetch_all_list(" AND id IN({$cartBuyIds}) ", 'ORDER BY id DESC', 0, 100);
    $orderShopList = $orderGoodsArr = $cartGoodsArr = $cartShopArr = $lingquCouponList = array();
    $total_tcshop_score_num = 0;
    if(is_array($cartListTmp) && !empty($cartListTmp)){
        foreach($cartListTmp as $key => $value){
            $buy_price_tmp = 0;
            $goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($value['goods_id']);
            $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfoTmp['tcshop_id']);
            if($goodsInfoTmp['shenhe_status'] == 1 && $goodsInfoTmp['status'] == 1){}else{
                $outArr = array(
                    'status'=> 302,
                    'title' => diconv($goodsInfoTmp['title'],CHARSET,'utf-8'),
                );
                echo json_encode($outArr); exit;
            }
            
            $peisong_type_tmp   = intval($_GET['peisong_type_'.$goodsInfoTmp['tcshop_id']])>0? intval($_GET['peisong_type_'.$goodsInfoTmp['tcshop_id']]):0;
            $place_id_tmp       = intval($_GET['place_id_'.$goodsInfoTmp['tcshop_id']])>0? intval($_GET['place_id_'.$goodsInfoTmp['tcshop_id']]):0;
            
            if($tcshopInfoTmp['peisong_type'] > 0){
                if($tcshopInfoTmp['peisong_type'] == 4){
                    if($peisong_type_tmp == 1 || $peisong_type_tmp == 3){ }else{
                        $outArr = array(
                            'status'=> 312,
                            'name' => diconv($tcshopInfoTmp['name'],CHARSET,'utf-8'),
                        );
                        echo json_encode($outArr); exit;
                    }
                }else if($tcshopInfoTmp['peisong_type'] == 5){
                    if($peisong_type_tmp == 1 || $peisong_type_tmp == 2){ }else{
                        $outArr = array(
                            'status'=> 312,
                            'name' => diconv($tcshopInfoTmp['name'],CHARSET,'utf-8'),
                        );
                        echo json_encode($outArr); exit;
                    }
                }else if($tcshopInfoTmp['peisong_type'] == 6){
                    if($peisong_type_tmp == 1 || $peisong_type_tmp == 2 || $peisong_type_tmp == 3){ }else{
                        $outArr = array(
                            'status'=> 312,
                            'name' => diconv($tcshopInfoTmp['name'],CHARSET,'utf-8'),
                        );
                        echo json_encode($outArr); exit;
                    }
                }else if($tcshopInfoTmp['peisong_type'] == $peisong_type_tmp){
                }else{
                    $outArr = array(
                        'status'=> 312,
                        'name' => diconv($tcshopInfoTmp['name'],CHARSET,'utf-8'),
                    );
                    echo json_encode($outArr); exit;
                }
            }else{
                $outArr = array(
                    'status'=> 311,
                    'name' => diconv($tcshopInfoTmp['name'],CHARSET,'utf-8'),
                );
                echo json_encode($outArr); exit;
            }
            
            if($peisong_type_tmp == 1 && $place_id_tmp > 0){
                $tcshopPlaceInfo = C::t("#tom_tcshop#tom_tcshop_place")->fetch_by_id($place_id_tmp);
                if($tcshopPlaceInfo && $tcshopInfoTmp['id'] == $tcshopPlaceInfo['tcshop_id'] && $tcshopPlaceInfo['status'] == 1){ }else{
                    $outArr = array(
                        'status'=> 315,
                        'name' => diconv($tcshopInfoTmp['name'],CHARSET,'utf-8'),
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
            $showVipPriceStatus = 0;
            if($__CardInfo['status'] == 1 && $goodsInfoTmp['open_vip'] == 1){
                $showVipPriceStatus = 1;
            }
            
            if($showVipPriceStatus == 1){
                $buy_price_tmp = $goodsInfoTmp['vip_price'];
            }else{
                $buy_price_tmp = $goodsInfoTmp['buy_price'];
            }
            
            $optionInfoTmp = array();
            if($goodsInfoTmp['hasoption'] == 1){
                if($value['option_id'] > 0){
                    $optionInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_by_id($value['option_id']);
                    if($optionInfoTmp && $optionInfoTmp['goods_id'] == $goodsInfoTmp['id']){
                        if($showVipPriceStatus == 1){
                            $buy_price_tmp = $optionInfoTmp['vip_price'];
                        }else{
                            $buy_price_tmp = $optionInfoTmp['buy_price'];
                        }
                        if($value['goods_num'] > $optionInfoTmp['stock']){
                            $outArr = array(
                                'status'=> 303,
                                'title' => diconv($goodsInfoTmp['title'],CHARSET,'utf-8'),
                            );
                            echo json_encode($outArr); exit;
                        }

                    }else{
                        $outArr = array(
                            'status'=> 302,
                            'title' => diconv($goodsInfoTmp['title'],CHARSET,'utf-8'),
                        );
                        echo json_encode($outArr); exit;
                    }
                }else{
                    $outArr = array(
                        'status'=> 302,
                        'title' => diconv($goodsInfoTmp['title'],CHARSET,'utf-8'),
                    );
                    echo json_encode($outArr); exit;
                }
            }else{
                if($value['goods_num'] > $goodsInfoTmp['stock']){
                    $outArr = array(
                        'status'=> 303,
                        'title' => diconv($goodsInfoTmp['title'],CHARSET,'utf-8'),
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
            $user_open_dikou_tmp = intval($_GET['user_open_dikou_'.$goodsInfoTmp['tcshop_id']])>0? intval($_GET['user_open_dikou_'.$goodsInfoTmp['tcshop_id']]):0;
            $score_num = $score_dikou_price = 0;
            if($user_open_dikou_tmp == 1){
                if($goodsInfoTmp['open_score_dikou'] == 1){
                    $score_goods_num = 1;
                    if($tcmallConfig['open_goods_num_dikou_score'] == 1){
                        $score_goods_num = $value['goods_num'];
                    }
                    
                    $score_num = $goodsInfoTmp['score_num'] * $score_goods_num;
                    $score_dikou_price = $goodsInfoTmp['score_dikou_price'] * $score_goods_num;
                    if($value['option_id'] > 0){
                        $score_num = $optionInfoTmp['score_num'] * $score_goods_num;
                        $score_dikou_price = $optionInfoTmp['score_dikou_price'] * $score_goods_num;
                    }
                    $total_tcshop_score_num = $total_tcshop_score_num + $score_num;
                    if($score_num <= 0 || $score_dikou_price <= 0){
                        $outArr = array(
                            'status'=> 313,
                        );
                        echo json_encode($outArr); exit;
                    }

                    if($userInfo['score'] < $total_tcshop_score_num){
                        $outArr = array(
                            'status'=> 314,
                        );
                        echo json_encode($outArr); exit;
                    }
                }
            }
            
            if($goodsInfoTmp['max_buy'] > 0){
                $buyGoodsCount = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_goods_num("AND goods_id = {$goodsInfoTmp['id']} AND user_id = {$user_id} AND order_status IN(1,2,3,4,8)");
                $cartByCount = C::t('#tom_tcmall#tom_tcmall_cart')->fetch_goods_num(" AND id IN({$cartBuyIds}) AND goods_id = {$goodsInfoTmp['id']} ", 'ORDER BY id DESC', 0, 100);
                $syBuyGoodsCount = $goodsInfoTmp['max_buy'] - $buyGoodsCount;
                if($cartByCount > $syBuyGoodsCount){
                    $outArr = array(
                        'status'=> 304,
                        'title' => diconv($goodsInfoTmp['title'],CHARSET,'utf-8'),
                        'num' => $syBuyGoodsCount,
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
            $tcshopIdTmp = $goodsInfoTmp['tcshop_id'];
            $goodsIdTmp = $value['goods_id'];
            
            $cartGoodsArr[$goodsIdTmp]['goods_num'] = $cartGoodsArr[$goodsIdTmp]['goods_num'] + $value['goods_num'];
            $cartGoodsArr[$goodsIdTmp]['buy_price'] = $cartGoodsArr[$goodsIdTmp]['buy_price'] + $buy_price_tmp * $value['goods_num'];
            $cartGoodsArr[$goodsIdTmp]['dispatch_status'] = 1;
            if($value['option_id'] > 0){
                $cartGoodsArr[$goodsIdTmp][$value['option_id']]['buy_price'] = $cartGoodsArr[$goodsIdTmp][$value['option_id']]['buy_price'] + $buy_price_tmp * $value['goods_num'];
            }
            $cartGoodsArr[$goodsIdTmp]['score_num'] = $cartGoodsArr[$goodsIdTmp]['score_num'] + $score_num;
            $cartGoodsArr[$goodsIdTmp]['score_dikou_price'] = $cartGoodsArr[$goodsIdTmp]['score_dikou_price'] + $score_dikou_price;
            
            $cartShopArr[$tcshopIdTmp]['buy_price'] = $cartShopArr[$tcshopIdTmp]['buy_price'] + $buy_price_tmp * $value['goods_num'];
            $cartShopArr[$tcshopIdTmp]['dispatch_status'] = 1;
            $cartShopArr[$tcshopIdTmp]['score_num'] = $cartShopArr[$tcshopIdTmp]['score_num'] + $score_num;
            $cartShopArr[$tcshopIdTmp]['score_dikou_price'] = $cartShopArr[$tcshopIdTmp]['score_dikou_price'] + $score_dikou_price;
            
            $huodao_pay_status = 0;
            if($tcshopInfoTmp['huodao_pay'] == 1){
                $huodao_pay_status = 1;
            }
            
            $orderGoodsInfo = array();
            $orderGoodsInfo['cartInfo']             = $value;
            $orderGoodsInfo['goodsInfo']            = $goodsInfoTmp;
            //$orderGoodsInfo['tcshopInfo']           = $tcshopInfoTmp;
            $orderGoodsInfo['showVipPriceStatus']   = $showVipPriceStatus;
            $orderGoodsInfo['buy_price']            = $buy_price_tmp;
            $orderGoodsInfo['goods_num']            = $value['goods_num'];
            $orderGoodsInfo['optionInfo']           = $optionInfoTmp;
            //$orderGoodsInfo['peisong_type']         = $peisong_type_tmp;
            $orderGoodsInfo['tj_hehuoren_id']       = $value['tj_hehuoren_id'];

            $orderShopList[$tcshopIdTmp]['goodsList'][]     = $orderGoodsInfo;
            $orderShopList[$tcshopIdTmp]['tcshopInfo']      = $tcshopInfoTmp;
            $orderShopList[$tcshopIdTmp]['huodao_pay_status'] = $huodao_pay_status;
            $orderShopList[$tcshopIdTmp]['peisong_type']    = $peisong_type_tmp;
            $orderShopList[$tcshopIdTmp]['place_id']        = $place_id_tmp;
            
            $orderGoodsArr[$key]                        = $value;
            $orderGoodsArr[$key]['goodsInfo']           = $goodsInfoTmp;
            $orderGoodsArr[$key]['huodao_pay_status']   = $huodao_pay_status;
        }
        
        foreach($orderGoodsArr as $key => $value){
            $goodsIdTmp = $value['goodsInfo']['id'];
            $tcshopIdTmp = $value['goodsInfo']['tcshop_id'];
            
            $lingquCouponList[$tcshopIdTmp]['huodao_pay_status'] = $value['huodao_pay_status'];;
            
            $lingqu_id = intval($_GET['lingqu_id_'.$tcshopIdTmp])>0? intval($_GET['lingqu_id_'.$tcshopIdTmp]):0;
            if($lingqu_id > 0){
                $lingquInfo = C::t("#tom_tcmall#tom_tcmall_coupon_lingqu")->fetch_by_id($lingqu_id);
                if(!$lingquInfo || $lingquInfo['tcshop_id'] != $tcshopIdTmp){
                    $outArr = array(
                        'status'=> 404,
                    );
                    echo json_encode($outArr); exit;
                }
                
                if($lingquInfo['user_id'] != $user_id){
                    $outArr = array(
                        'status'=> 404,
                    );
                    echo json_encode($outArr); exit;
                }

                if($lingquInfo['status'] == 1){
                    $outArr = array(
                        'status'=> 308,
                    );
                    echo json_encode($outArr); exit;
                }

                $couponInfo = C::t("#tom_tcmall#tom_tcmall_coupon")->fetch_by_id($lingquInfo['coupon_id']);
                if(!$couponInfo){
                    $outArr = array(
                        'status'=> 404,
                    );
                    echo json_encode($outArr); exit;
                }
                if($couponInfo['start_time'] > $timeStamp){
                    $outArr = array(
                        'status'=> 309,
                    );
                    echo json_encode($outArr); exit;
                }
                if($couponInfo['end_time'] < $timeStamp){
                    $outArr = array(
                        'status'=> 310,
                    );
                    echo json_encode($outArr); exit;
                }
                
                if($couponInfo['coupon_type'] == 1){
                    if($cartShopArr[$tcshopIdTmp]['buy_price'] < $couponInfo['full_price']){
                        $outArr = array(
                            'status'=> 404,
                        );
                        echo json_encode($outArr); exit;
                    }
                    $lingquCouponList[$tcshopIdTmp]['lingqu_id']          = $lingqu_id;
                    $lingquCouponList[$tcshopIdTmp]['reduce_price']       = $couponInfo['reduce_price'];
                    
                    $cartShopArr[$tcshopIdTmp]['reduce_price'] = $couponInfo['reduce_price'];
                    
                    if($value['option_id'] > 0){
                        $biliTmp = $cartGoodsArr[$goodsIdTmp][$value['option_id']]['buy_price']/$cartShopArr[$tcshopIdTmp]['buy_price'];
                        $reduce_price_tmp = $couponInfo['reduce_price'] * $biliTmp;
                        $cartGoodsArr[$goodsIdTmp][$value['option_id']]['reduce_price'] = number_format($reduce_price_tmp,2, '.', '');
                    }else{
                        $biliTmp = $cartGoodsArr[$goodsIdTmp]['buy_price']/$cartShopArr[$tcshopIdTmp]['buy_price'];
                        $reduce_price_tmp = $couponInfo['reduce_price'] * $biliTmp;
                        $cartGoodsArr[$goodsIdTmp]['reduce_price'] = number_format($reduce_price_tmp,2, '.', '');
                    }
                }
                
                if($couponInfo['coupon_type'] == 2){
                    
                    $goodsIdsArr = explode("|", $couponInfo['goods_ids']);
                    $allGoodsPrice = 0;
                    if(is_array($goodsIdsArr) && !empty($goodsIdsArr)){
                        foreach($goodsIdsArr as $kg => $vg){
                            if(isset($cartGoodsArr[$vg]['buy_price']) && !empty($cartGoodsArr[$vg]['buy_price'])){
                                $allGoodsPrice = $allGoodsPrice + floatval($cartGoodsArr[$vg]['buy_price']);
                            }
                        }
                    }

                    if($allGoodsPrice < $couponInfo['full_price']){
                        $outArr = array(
                            'status'=> 404,
                        );
                        echo json_encode($outArr); exit;
                    }
                    
                    if(in_array($goodsIdTmp, $goodsIdsArr)){
                        
                        $lingquCouponList[$tcshopIdTmp]['lingqu_id']          = $lingqu_id;
                        $lingquCouponList[$tcshopIdTmp]['reduce_price']       = $couponInfo['reduce_price'];
                        
                        $cartShopArr[$tcshopIdTmp]['reduce_price'] = $couponInfo['reduce_price'];
                        
                        if($value['option_id'] > 0){
                            $biliTmp = $cartGoodsArr[$goodsIdTmp][$value['option_id']]['buy_price']/$allGoodsPrice;
                            $reduce_price_tmp = $couponInfo['reduce_price'] * $biliTmp;
                            $cartGoodsArr[$goodsIdTmp][$value['option_id']]['reduce_price'] = number_format($reduce_price_tmp,2, '.', '');
                        }else{
                            $biliTmp = $cartGoodsArr[$goodsIdTmp]['buy_price']/$allGoodsPrice;
                            $reduce_price_tmp = $couponInfo['reduce_price'] * $biliTmp;
                            $cartGoodsArr[$goodsIdTmp]['reduce_price'] = number_format($reduce_price_tmp,2, '.', '');
                        }
                    }
                    
                }
            }
        }
    }

    $orderNoArr = $orderIdsArr = array();
    $total_goods_price = $total_dispatch_price = $total_score_dikou_price = 0;
    $total_goods_title = '';
    if(is_array($orderShopList) && !empty($orderShopList)){
        foreach($orderShopList as $key => $value){
            $tcshopInfoTmp = $value['tcshopInfo'];
            $tcshop_id_tmp = $tcshopInfoTmp['id'];
            $peisong_type_tmp = $value['peisong_type'];
            $huodao_pay_status = $value['huodao_pay_status'];
            
            $order_no_tmp   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
            $hexiao_no_tmp  = date("YmdHis")."-".mt_rand(111111, 666666);
            $orderNoArr[] = $order_no_tmp;

            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['tcshop_id']        = $tcshop_id_tmp;
            $insertData['user_id']          = $userInfo['id'];
            $insertData['openid']           = $userInfo['openid'];
            $insertData['order_no']         = $order_no_tmp;
            $insertData['hexiao_no']        = $hexiao_no_tmp;
            $insertData['pay_price']        = 0;
            $insertData['goods_price']      = 0;
            $insertData['dispatch_price']   = 0;
            if($huodao_pay_status == 1){
                $insertData['order_status']      = 8;
                $insertData['huodao_pay_status'] = 1;
            }else{
                $insertData['order_status']     = 1;
            }
            $insertData['order_beizu']      = $beizu;
            $insertData['peisong_type']     = $peisong_type_tmp;
            if($peisong_type_tmp == 1){
                $insertData['address_xm']       = $zq_address_xm;
                $insertData['address_tel']      = $zq_address_tel;
                $insertData['tcshop_place_id']  = $value['place_id'];
            }else{
                $insertData['address_id']       = $addressInfo['id'];
                $insertData['address_xm']       = $addressInfo['xm'];
                $insertData['address_tel']      = $addressInfo['tel'];
                $insertData['address_str']      = $addressInfo['area_str'].$addressInfo['info'];
                $insertData['address']          = serialize($addressInfo);
            }
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tcmall#tom_tcmall_order')->insert($insertData)){
                $order_id = C::t('#tom_tcmall#tom_tcmall_order')->insert_id();
                $orderIdsArr[] = $order_id;
                
                $tcshop_goods_price_tmp = $tcshop_dispatch_price_tmp = 0;
                $goods_site_id = 1;
                if(is_array($value['goodsList']) && !empty($value['goodsList'])){
                    foreach($value['goodsList'] as $gk => $gv){
                        
                        $goods_site_id = $gv['goodsInfo']['site_id'];
                        
                        $total_goods_title.= $gv['goodsInfo']['title'];
                        
                        $goods_dispatch_price_tmp = $goods_price_tmp = 0;
                        
                        $goods_price_tmp = $gv['goods_num'] * $gv['buy_price'];
                        $tcshop_goods_price_tmp = $tcshop_goods_price_tmp + $goods_price_tmp;
                        
                        if($huodao_pay_status == 0){
                            $total_goods_price = $total_goods_price + $goods_price_tmp;
                        }
                        
                        $issendfreeTmp = $gv['goodsInfo']['issendfree'];
                        
                        if($gv['goodsInfo']['open_express'] == 1){
                            $expressArrTmp = tom_express($gv['goodsInfo']['express_id'], $address_id);
                            if(is_array($expressArrTmp) && !empty($expressArrTmp)){
                                $issendfreeTmp = $expressArrTmp['issendfree'];
                                $gv['goodsInfo']['dispatch_price'] = $expressArrTmp['express_price'];
                            }
                        }
                        
                        if($gv['goodsInfo']['edmoney'] > 0 && $cartGoodsArr[$gv['goodsInfo']['id']]['buy_price'] >= $gv['goodsInfo']['edmoney']){
                            $issendfreeTmp = 1;
                        }
                        if($gv['goodsInfo']['ednum'] > 0 && $cartGoodsArr[$gv['goodsInfo']['id']]['goods_num'] >= $gv['goodsInfo']['ednum']){
                            $issendfreeTmp = 1;
                        }
                        if($tcshopInfoTmp['edmoney'] > 0 && $cartShopArr[$tcshopInfoTmp['id']]['buy_price'] >= $tcshopInfoTmp['edmoney']){
                            $issendfreeTmp = 1;
                        }
                        
                        if(($peisong_type_tmp == 2 || $peisong_type_tmp == 3) &&  $issendfreeTmp == 0){
                            if($tcshopInfoTmp['dispatch_type'] == 1){
                                if($cartShopArr[$tcshopInfoTmp['id']]['dispatch_status'] == 1){
                                    $goods_dispatch_price_tmp = $gv['goodsInfo']['dispatch_price'];
                                    $cartShopArr[$tcshopInfoTmp['id']]['dispatch_status'] = 2;
                                }
                            }else{
                                if($gv['goodsInfo']['dispatch_type'] == 2){
                                    $goods_dispatch_price_tmp = $gv['goodsInfo']['dispatch_price'] * $gv['goods_num'];
                                }else{
                                    if($cartGoodsArr[$gv['goodsInfo']['id']]['dispatch_status'] == 1){
                                        $goods_dispatch_price_tmp = $gv['goodsInfo']['dispatch_price'];
                                        $cartGoodsArr[$gv['goodsInfo']['id']]['dispatch_status'] = 2;
                                    }
                                }
                            }
                            $tcshop_dispatch_price_tmp = $tcshop_dispatch_price_tmp + $goods_dispatch_price_tmp;
                            
                            if($huodao_pay_status == 0){
                                $total_dispatch_price = $total_dispatch_price + $goods_dispatch_price_tmp;
                            }
                        }

                        $insertData = array();
                        $insertData['order_id']         = $order_id;
                        $insertData['user_id']          = $userInfo['id'];
                        if($gv['goodsInfo']['hehuoren_tg_open'] == 1){
                            $insertData['tj_hehuoren_id']   = $gv['tj_hehuoren_id'];
                        }
                        $insertData['goods_id']         = $gv['goodsInfo']['id'];
                        $insertData['goods_title']      = $gv['goodsInfo']['title'];
                        if($gv['showVipPriceStatus'] == 1){
                            $insertData['is_vip']          = 1;
                        }
                        $insertData['goods_num']        = $gv['goods_num'];
                        $insertData['price']            = $gv['buy_price'];
                        $goods_coupon_reduce_price_tmp = 0;
                        if(is_array($lingquCouponList[$tcshop_id_tmp]) && !empty($lingquCouponList[$tcshop_id_tmp])){
                            if(is_array($gv['optionInfo']) && !empty($gv['optionInfo'])){
                                $goods_coupon_reduce_price_tmp = floatval($cartGoodsArr[$gv['goodsInfo']['id']][$gv['optionInfo']['id']]['reduce_price']);
                            }else{
                                $goods_coupon_reduce_price_tmp = floatval($cartGoodsArr[$gv['goodsInfo']['id']]['reduce_price']);
                            }
                        }
                        $goods_score_dikou_price_tmp = 0;
                        if($cartGoodsArr[$gv['goodsInfo']['id']]['score_dikou_price'] > 0){
                            $insertData['score_num']            = $cartGoodsArr[$gv['goodsInfo']['id']]['score_num'];
                            $insertData['score_dikou_price']    = $cartGoodsArr[$gv['goodsInfo']['id']]['score_dikou_price'];
                            $goods_score_dikou_price_tmp        = $cartGoodsArr[$gv['goodsInfo']['id']]['score_dikou_price'];
                        }
                        $insertData['real_price']       = $goods_price_tmp - $goods_coupon_reduce_price_tmp - $goods_score_dikou_price_tmp;
                        $insertData['dispatch_price']   = $goods_dispatch_price_tmp;
                        if(is_array($gv['optionInfo']) && !empty($gv['optionInfo'])){
                            $insertData['option_id']    = $gv['optionInfo']['id'];
                            $insertData['option_name']  = $gv['optionInfo']['name'];
                        }
                        if($huodao_pay_status == 1){
                            $insertData['order_status']     = 8;
                        }else{
                            $insertData['order_status']     = 1;
                        }
                        $insertData['add_time']         = TIMESTAMP;
                        C::t('#tom_tcmall#tom_tcmall_order_goods')->insert($insertData);
                        
                        if(is_array($gv['optionInfo']) && !empty($gv['optionInfo'])){
                            DB::query("UPDATE ".DB::table('tom_tcmall_goods_option')." SET stock=stock-{$gv['goods_num']} WHERE id={$gv['optionInfo']['id']}", 'UNBUFFERED');
                            DB::query("UPDATE ".DB::table('tom_tcmall_goods')." SET stock=stock-{$gv['goods_num']}, sales=sales+{$gv['goods_num']} WHERE id={$gv['goodsInfo']['id']}", 'UNBUFFERED');
                        }else{
                            DB::query("UPDATE ".DB::table('tom_tcmall_goods')." SET stock=stock-{$gv['goods_num']}, sales=sales+{$gv['goods_num']} WHERE id={$gv['goodsInfo']['id']}", 'UNBUFFERED');
                        }

                        C::t('#tom_tcmall#tom_tcmall_cart')->delete_by_id($gv['cartInfo']['id']);
                    }
                }
                
                if($huodao_pay_status == 0){
                    $total_score_dikou_price = $total_score_dikou_price + $cartShopArr[$tcshop_id_tmp]['score_dikou_price'];
                }
                
                $updateData = array();
                $updateData['site_id']          = $goods_site_id;
                $updateData['goods_price']      = $tcshop_goods_price_tmp;
                $updateData['dispatch_price']   = $tcshop_dispatch_price_tmp;

                $coupon_reduce_price_tmp = 0;
                if(is_array($lingquCouponList[$tcshop_id_tmp]) && !empty($lingquCouponList[$tcshop_id_tmp]) && $cartShopArr[$tcshop_id_tmp]['reduce_price'] > 0){
                    $updateData['coupon_lingqu_id']     = $lingquCouponList[$tcshop_id_tmp]['lingqu_id'];
                    $updateData['coupon_reduce_price']  = $cartShopArr[$tcshop_id_tmp]['reduce_price'];
                    $coupon_reduce_price_tmp            = $cartShopArr[$tcshop_id_tmp]['reduce_price'];
                }
                $score_dikou_price_tmp = 0;
                if($cartShopArr[$tcshop_id_tmp]['score_dikou_price'] > 0){
                    $updateData['score_num']            = $cartShopArr[$tcshop_id_tmp]['score_num'];
                    $updateData['score_dikou_price']    = $cartShopArr[$tcshop_id_tmp]['score_dikou_price'];
                    $score_dikou_price_tmp              = $cartShopArr[$tcshop_id_tmp]['score_dikou_price'];
                }
                $updateData['pay_price']        = $tcshop_goods_price_tmp + $tcshop_dispatch_price_tmp - $coupon_reduce_price_tmp - $score_dikou_price_tmp;
                C::t('#tom_tcmall#tom_tcmall_order')->update($order_id, $updateData);
            }
        }
    }
    
    $total_pay_price = $total_goods_price + $total_dispatch_price - $total_score_dikou_price;

    if(is_array($lingquCouponList) && !empty($lingquCouponList)){
        foreach($lingquCouponList as $key => $value){
            if($value['huodao_pay_status'] == 0){
                $total_pay_price = $total_pay_price - $value['reduce_price'];
            }
            $updateData = array();
            $updateData['status'] = 1;
            $updateData['use_time'] = TIMESTAMP;
            C::t("#tom_tcmall#tom_tcmall_coupon_lingqu")->update($value['lingqu_id'], $updateData);
        }
    }
    
    $openid = $userInfo['openid'];
    if(count($orderNoArr) == 1){
        $type = 2;
        $pay_order_no   = $orderNoArr[0];
        $order_no_str   = implode(',', $orderNoArr);
    }else{
        $type = 1;
        $pay_order_no   = "ALLTC".date("YmdHis")."-".mt_rand(111111, 666666);
        $order_no_str   = implode(',', $orderNoArr);
    }

    if($total_pay_price > 0){
        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['type']             = $type;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $openid;
        $insertData['pay_order_no']     = $pay_order_no;
        $insertData['order_no_str']     = $order_no_str;
        $insertData['order_status']     = 1;
        $insertData['pay_price']        = $total_pay_price;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcmall#tom_tcmall_order_pay')->insert($insertData)){
            $pay_order_id = C::t('#tom_tcmall#tom_tcmall_order_pay')->insert_id();

            if(is_array($orderIdsArr) && !empty($orderIdsArr)){
                foreach($orderIdsArr as $key => $value){
                    $updateData = array();
                    $updateData['pay_order_no'] = $pay_order_no;
                    C::t('#tom_tcmall#tom_tcmall_order')->update($value,$updateData);
                }
            }

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcmall';
            $insertData['order_no']        = $pay_order_no;
            $insertData['goods_id']        = $pay_order_id;
            $insertData['goods_name']      = $total_goods_title;
            $insertData['goods_beizu']     = $beizu;
            $insertData['goods_url']       = 'plugin.php?id=tom_tcmall&site='.$site_id.'&mod=cart';
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcmall&site='.$site_id.'&mod=order';
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcmall&site={$site_id}&mod=order&type=1";
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $total_pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'    => 200,
                    'payurl' => $pay_hosts."plugin.php?id=tom_pay&order_no=".$pay_order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        
        if(!empty($tcmallConfig['template_neworder']) && is_array($orderIdsArr) && !empty($orderIdsArr)){
        
            include DISCUZ_ROOT.'./source/plugin/tom_tcmall/class/templatesms.class.php';
            if($__ShowPrint == 1){
                include DISCUZ_ROOT.'./source/plugin/tom_print/print.func.php';
            }
            foreach($orderIdsArr as $key => $value){
                $orderInfoTmp = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_id($value);
                if($__ShowPrint == 1){
                    @add_mall_print($orderInfoTmp['order_no']);
                }
            }
            foreach($orderIdsArr as $key => $value){
                
                $access_token = $weixinClass->get_access_token();
                $orderInfoTmp = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_id($value);
                
                if($__ShowPrint == 1){
                    @mall_print($orderInfoTmp['order_no']);
                }
                
                $orderTcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfoTmp['tcshop_id']);
                $orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderTcshopInfoTmp['user_id']); 

                $goodsOrderListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$value} ", 'ORDER BY id DESC', 0, 1000);
                $goods_title_arr = array();
                $goods_title_str = '';
                if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
                    foreach($goodsOrderListTmp as $gk => $gv){
                        $goods_title_arr[]=$gv['goods_title'];
                    }
                }
                $goods_title_str = implode('|', $goods_title_arr);

                if($access_token && !empty($orderUserInfoTmp['openid']) ){

                    $templateSmsClass = new mTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcmall&site=".$payOrderInfo['site_id']."&mod=myorder");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcmall','template_neworder_huodao_first'),
                        'keyword1'      => $goods_title_str,
                        'keyword2'      => $orderInfoTmp['pay_price'],
                        'keyword3'      => $orderInfoTmp['address_xm'],
                        'keyword4'      => $orderInfoTmp['address_tel'],
                        'keyword5'      => $orderInfoTmp['order_no'],
                        'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
                    );
                    @$r = $templateSmsClass->sendSmsNewOrder($orderUserInfoTmp['openid'],$tcmallConfig['template_neworder'],$smsData);
                    
                }
            }
        }
        
        $outArr = array(
            'status'    => 201,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "goods_pay" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $number         = intval($_GET['number'])>0? intval($_GET['number']):0;
    $goods_id       = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    $option_id      = intval($_GET['option_id'])>0? intval($_GET['option_id']):0;
    $peisong_type   = intval($_GET['peisong_type'])>0? intval($_GET['peisong_type']):0;
    $address_id     = intval($_GET['address_id'])>0? intval($_GET['address_id']):0;
    $place_id       = intval($_GET['place_id'])>0? intval($_GET['place_id']):0;
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $tj_hehuoren_id = intval($_GET['tj_hehuoren_id'])>0? intval($_GET['tj_hehuoren_id']):0;
    $address_xm     = isset($_GET['address_xm'])? daddslashes($_GET['address_xm']):'';
    $address_tel    = isset($_GET['address_tel'])? daddslashes($_GET['address_tel']):'';
    $beizu          = isset($_GET['beizu'])? daddslashes($_GET['beizu']):'';
    $lingqu_id      = intval($_GET['lingqu_id'])>0? intval($_GET['lingqu_id']):0;
    $user_open_dikou = intval($_GET['user_open_dikou'])>0? intval($_GET['user_open_dikou']):0;

    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    $addressInfo = array();
    if($address_id > 0){
        $addressInfo = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
    }
    
    $__CardInfo = array();
    if($__ShowTcyikatong == 1 && $user_id > 0){
        $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($user_id);
        if(is_array($cardInfoTmp) && !empty($cardInfoTmp)){
            $__CardInfo = $cardInfoTmp;
        }
    }
    
    if(!$userInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    $goodsInfo   = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($goods_id);
    if($goodsInfo && $goodsInfo['status'] == 1 && $goodsInfo['shenhe_status'] == 1){}else{
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($peisong_type == 1 && $place_id > 0){
        $tcshopPlaceInfo = C::t("#tom_tcshop#tom_tcshop_place")->fetch_by_id($place_id);
        if($tcshopPlaceInfo && $goodsInfo['tcshop_id'] == $tcshopPlaceInfo['tcshop_id'] && $tcshopPlaceInfo['status'] == 1){ }else{
            $outArr = array(
                'status'=> 314,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $tcshopInfo   = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
    
    $showVipPriceStatus = 0;
    if($goodsInfo['open_vip'] == 1 && $__CardInfo['status'] == 1){
        $showVipPriceStatus = 1;
    }
    
    if($showVipPriceStatus == 1){
        $buy_price = $goodsInfo['vip_price'];
    }else{
        $buy_price = $goodsInfo['buy_price'];
    }
    $stock = $goodsInfo['stock'];
    if($goodsInfo['hasoption'] == 1){
        if(!empty($option_id)){
            $optionInfo = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_by_id($option_id);
            if($optionInfo && $optionInfo['goods_id'] == $goodsInfo['id']){

                $stock = $optionInfo['stock'];

                if($showVipPriceStatus == 1){
                    $buy_price = $optionInfo['vip_price'];
                }else{
                    $buy_price = $optionInfo['buy_price'];
                }

            }else{

                $outArr = array(
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($number > $stock){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['max_buy'] > 0){
        $buyGoodsCount = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_goods_num("AND goods_id = {$goodsInfo['id']} AND user_id = {$user_id} AND order_status IN(1,2,3,4,8)");
        $syBuyGoodsCount = $goodsInfo['max_buy'] - $buyGoodsCount;
        if($goods_num > $syBuyGoodsCount){
            $outArr = array(
                'status'=> 304,
                'num'=> $syBuyGoodsCount,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $goods_price = $buy_price * $number;
    
    $coupon_reduce_price = 0;
    if($lingqu_id > 0){
        $lingquInfo = C::t("#tom_tcmall#tom_tcmall_coupon_lingqu")->fetch_by_id($lingqu_id);
        if(!$lingquInfo || $lingquInfo['tcshop_id'] != $goodsInfo['tcshop_id']){
            $outArr = array(
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }
        if($lingquInfo['status'] == 1){
            $outArr = array(
                'status'=> 308,
            );
            echo json_encode($outArr); exit;
        }
        
        if($lingquInfo['user_id'] != $user_id){
            $outArr = array(
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }

        $couponInfo = C::t("#tom_tcmall#tom_tcmall_coupon")->fetch_by_id($lingquInfo['coupon_id']);
        if(!$couponInfo){
            $outArr = array(
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }
        if($couponInfo['start_time'] > $timeStamp){
            $outArr = array(
                'status'=> 309,
            );
            echo json_encode($outArr); exit;
        }
        if($couponInfo['end_time'] < $timeStamp){
            $outArr = array(
                'status'=> 310,
            );
            echo json_encode($outArr); exit;
        }

        if($goods_price < $couponInfo['full_price']){
            $outArr = array(
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }
        if($couponInfo['coupon_type'] == 2){
            $goodsIdsArr = explode("|", $couponInfo['goods_ids']);
            if(!in_array($goodsInfo['id'], $goodsIdsArr)){
                $outArr = array(
                    'status'=> 404,
                );
                echo json_encode($outArr); exit;
            }
        }
        
        $coupon_reduce_price = $couponInfo['reduce_price'];
        
    }
    
    $score_num = $score_dikou_price = 0;
    if($user_open_dikou == 1){
        if($goodsInfo['open_score_dikou'] == 1){
            $score_goods_num = 1;
            if($tcmallConfig['open_goods_num_dikou_score'] == 1){
                $score_goods_num = $number;
            }
            
            $score_num = $goodsInfo['score_num'] * $score_goods_num;
            $score_dikou_price = $goodsInfo['score_dikou_price'] * $score_goods_num;
            if($option_id > 0){
                $score_num = $optionInfo['score_num'] * $score_goods_num;
                $score_dikou_price = $optionInfo['score_dikou_price'] * $score_goods_num;
            }
            
            if($score_num <= 0 || $score_dikou_price <= 0){
                $outArr = array(
                    'status'=> 312,
                );
                echo json_encode($outArr); exit;
            }
            
            if($userInfo['score'] < $score_num){
                $outArr = array(
                    'status'=> 313,
                );
                echo json_encode($outArr); exit;
            }
            
        }else{
            $outArr = array(
                'status'=> 311,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $dispatch_price = 0;
    
    if($goodsInfo['open_express'] == 1){
        $expressArrTmp = tom_express($goodsInfo['express_id'], $address_id);
        if(is_array($expressArrTmp) && !empty($expressArrTmp)){
            $goodsInfo['issendfree'] = $expressArrTmp['issendfree'];
            $goodsInfo['dispatch_price'] = $expressArrTmp['express_price'];
        }
    }
    
    if($goodsInfo['ednum'] > 0 && $number >= $goodsInfo['ednum'] ){
        $goodsInfo['issendfree'] = 1;
    }
    if($goodsInfo['edmoney'] > 0 && $goods_price >= $goodsInfo['edmoney']){
        $goodsInfo['issendfree'] = 1;
    }
    if($tcshopInfo['edmoney'] > 0 && $goods_price >= $tcshopInfo['edmoney']){
        $goodsInfo['issendfree'] = 1;
    }
    if(($peisong_type == 2 || $peisong_type == 3) && $goodsInfo['issendfree'] == 0){
        if($goodsInfo['dispatch_type'] == 2){
            $dispatch_price = $goodsInfo['dispatch_price'] * $number;
        }else{
            $dispatch_price = $goodsInfo['dispatch_price'];
        }
    }
    
    $payStatus = 1;
    if($tcshopInfo['huodao_pay'] == 1){
        $payStatus = 2;
    }
    
    $pay_price = $goods_price + $dispatch_price - $coupon_reduce_price - $score_dikou_price;
    $openid = $userInfo['openid'];
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    $hexiao_no  = date("YmdHis")."-".mt_rand(111111, 666666);

    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['tcshop_id']        = $goodsInfo['tcshop_id'];
    $insertData['user_id']          = $userInfo['id'];
    $insertData['openid']           = $userInfo['openid'];
    $insertData['pay_order_no']     = $order_no;
    $insertData['order_no']         = $order_no;
    $insertData['hexiao_no']        = $hexiao_no;
    $insertData['pay_price']        = $pay_price;
    $insertData['goods_price']      = $goods_price;
    $insertData['dispatch_price']   = $dispatch_price;
    if($coupon_reduce_price > 0){
        $insertData['coupon_lingqu_id']     = $lingquInfo['id'];
        $insertData['coupon_reduce_price']  = $couponInfo['reduce_price'];
    }
    if($score_dikou_price > 0){
        $insertData['score_num']            = $score_num;
        $insertData['score_dikou_price']    = $score_dikou_price;
    }
    $insertData['order_beizu']      = $beizu;
    if($peisong_type == 1){
        $insertData['address_xm']       = $address_xm;
        $insertData['address_tel']      = $address_tel;
        $insertData['tcshop_place_id']  = $place_id;
    }else{
        $insertData['address_id']       = $addressInfo['id'];
        $insertData['address_xm']       = $addressInfo['xm'];
        $insertData['address_tel']      = $addressInfo['tel'];
        $insertData['address_str']      = $addressInfo['area_str'].$addressInfo['info'];
        $insertData['address']          = serialize($addressInfo);
    }
    $insertData['peisong_type']     = $peisong_type;
    if($payStatus == 2){
        $insertData['order_status']         = 8;
        $insertData['huodao_pay_status']    = 1;
    }else{
        $insertData['order_status']     = 1;
    }
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcmall#tom_tcmall_order')->insert($insertData)){
        $order_id = C::t('#tom_tcmall#tom_tcmall_order')->insert_id();

        $insertData = array();
        $insertData['order_id']         = $order_id;
        $insertData['user_id']          = $userInfo['id'];
        if($goodsInfo['hehuoren_tg_open'] == 1){
            $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
        }
        $insertData['goods_id']         = $goodsInfo['id'];
        $insertData['goods_title']      = $goodsInfo['title'];
        if($goodsInfo['open_vip'] == 1 && $__CardInfo['status'] == 1){
            $insertData['is_vip']       = 1;
        }
        $insertData['goods_num']        = $number;
        $insertData['price']            = $buy_price;
        $insertData['real_price']       = $goods_price - $coupon_reduce_price - $score_dikou_price;
        $insertData['dispatch_price']   = $dispatch_price;
        if(!empty($option_id)){
            $insertData['option_id']    = $optionInfo['id'];
            $insertData['option_name']  = $optionInfo['name'];
        }
        if($score_dikou_price > 0){
            $insertData['score_num']            = $score_num;
            $insertData['score_dikou_price']    = $score_dikou_price;
        }
        if($payStatus == 2){
            $insertData['order_status']     = 8;
        }else{
            $insertData['order_status']     = 1;
        }
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcmall#tom_tcmall_order_goods')->insert($insertData);
        
        if($coupon_reduce_price > 0){
            $updateData = array();
            $updateData['status'] = 1;
            $updateData['use_time'] = TIMESTAMP;
            C::t("#tom_tcmall#tom_tcmall_coupon_lingqu")->update($lingquInfo['id'], $updateData);
        }
        
        if(!empty($option_id)){
            DB::query("UPDATE ".DB::table('tom_tcmall_goods_option')." SET stock=stock-{$number} WHERE id={$option_id}", 'UNBUFFERED');
            DB::query("UPDATE ".DB::table('tom_tcmall_goods')." SET stock=stock-{$number}, sales=sales+{$number} WHERE id={$goodsInfo['id']}", 'UNBUFFERED');
        }else{
            DB::query("UPDATE ".DB::table('tom_tcmall_goods')." SET stock=stock-{$number}, sales=sales+{$number} WHERE id={$goodsInfo['id']}", 'UNBUFFERED');
        }
    }
    
    if($payStatus == 1){
        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['type']             = 2;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $openid;
        $insertData['pay_order_no']     = $order_no;
        $insertData['order_no_str']     = $order_no;
        $insertData['order_status']     = 1;
        $insertData['pay_price']        = $pay_price;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcmall#tom_tcmall_order_pay')->insert($insertData)){
            $pay_order_id = C::t('#tom_tcmall#tom_tcmall_order_pay')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcmall';          
            $insertData['order_no']        = $order_no;                 
            $insertData['goods_id']        = $goodsInfo['id'];         
            $insertData['goods_name']      = $goodsInfo['title'];      
            $insertData['goods_beizu']     = $beizu;
            $insertData['goods_url']       = 'plugin.php?id=tom_tcmall&site='.$site_id.'&mod=cart';
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcmall&site='.$site_id.'&mod=order';
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcmall&site={$site_id}&mod=order&type=1"; 
            $insertData['allow_alipay']    = 1;    
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'    => 200,
                    'payurl' => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        
        if(!empty($tcmallConfig['template_neworder'])){
        
            include DISCUZ_ROOT.'./source/plugin/tom_tcmall/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            
            $orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfo['user_id']); 

            $goods_title_str = $goodsInfo['title'];
            
            $order_xm = $order_tel = '';
            if($peisong_type == 1){
                $order_xm   = $address_xm;
                $order_tel  = $address_tel;
            }else{
                $order_xm   = $addressInfo['xm'];
                $order_tel  = $addressInfo['tel'];
            }
            
            if($__ShowPrint == 1){
                include DISCUZ_ROOT.'./source/plugin/tom_print/print.func.php';
                @add_mall_print($order_no);
                @mall_print($order_no);
            }

            if($access_token && !empty($orderUserInfoTmp['openid']) ){
                
                $templateSmsClass = new mTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcmall&site=".$payOrderInfo['site_id']."&mod=myorder");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcmall','template_neworder_huodao_first'),
                    'keyword1'      => $goods_title_str,
                    'keyword2'      => $pay_price,
                    'keyword3'      => $order_xm,
                    'keyword4'      => $order_tel,
                    'keyword5'      => $order_no,
                    'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
                );
                @$r = $templateSmsClass->sendSmsNewOrder($orderUserInfoTmp['openid'],$tcmallConfig['template_neworder'],$smsData);

            }
        
        }
        
        $outArr = array(
            'status'    => 201,
        );
        echo json_encode($outArr); exit;
    }

}else if($act == "order_pay" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $order_id = intval($_GET['order_id'])>0? intval($_GET['order_id']):0;
    
    $orderInfo = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_id($order_id);
    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    if(!$userInfo || $userInfo['id'] != $orderInfo['user_id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($orderInfo['pay_order_no'] === $orderInfo['order_no']){
        $payOrderInfo = C::t('#tom_tcmall#tom_tcmall_order_pay')->fetch_by_pay_order_no($orderInfo['pay_order_no']);
        $pay_order_id = $payOrderInfo['id'];
        $order_no = $payOrderInfo['pay_order_no'];
    }else{
        
        $order_no = $orderInfo['order_no'];
        
        $insertData = array();
        $insertData['site_id']          = $orderInfo['site_id'];
        $insertData['type']             = 2;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['pay_order_no']     = $order_no;
        $insertData['order_no_str']     = $order_no;
        $insertData['order_status']     = 1;
        $insertData['pay_price']        = $orderInfo['pay_price'];
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcmall#tom_tcmall_order_pay')->insert($insertData)){
            $pay_order_id = C::t('#tom_tcmall#tom_tcmall_order_pay')->insert_id();
            
            $updateData = array();
            $updateData['pay_order_no'] = $order_no;
            C::t('#tom_tcmall#tom_tcmall_order')->update($orderInfo['id'],$updateData);
        }
    }
    
    if($pay_order_id > 0){
        
        $goodsOrderListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$order_id} ", 'ORDER BY id DESC', 0, 1000);
        $goods_title_arr = array();
        $goods_title_str = '';
        if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
            foreach($goodsOrderListTmp as $gk => $gv){
                $goods_title_arr[]=$gv['goods_title'];
            }
        }
        $goods_title_str = implode('|', $goods_title_arr);
        
        $tomPayOrder = C::t('#tom_pay#tom_pay_order')->fetch_by_order_no($order_no);
        if(!$tomPayOrder){
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcmall';          
            $insertData['order_no']        = $order_no;                 
            $insertData['goods_id']        = $pay_order_id;         
            $insertData['goods_name']      = $goods_title_str;      
            $insertData['goods_beizu']     = $orderInfo['beizu'];
            $insertData['goods_url']       = 'plugin.php?id=tom_tcmall&site='.$site_id.'&mod=order';
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcmall&site='.$site_id.'&mod=order';
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcmall&site={$site_id}&mod=order&type=1"; 
            $insertData['allow_alipay']    = 1;    
            $insertData['pay_price']       = $orderInfo['pay_price'];
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            C::t('#tom_pay#tom_pay_order')->insert($insertData);
            $tomPayOrder = C::t('#tom_pay#tom_pay_order')->fetch_by_order_no($order_no);
        }
        
        if($tomPayOrder && $tomPayOrder['id'] > 0){
            $outArr = array(
                'status'    => 200,
                'payurl' => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }

}else if($_GET['act'] == 'order_cancel' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $order_id = intval($_GET['order_id'])>0? intval($_GET['order_id']):0;
    $orderInfo = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_id($order_id);

    if($orderInfo['order_status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['order_status'] = 5;
    if(C::t('#tom_tcmall#tom_tcmall_order')->update($order_id, $updateData)){
        $orderGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$order_id} ", "ORDER BY id DESC", 0, 100);
        if(is_array($orderGoodsListTmp) && !empty($orderGoodsListTmp)){
            foreach($orderGoodsListTmp as $key => $value){
                $updateData = array();
                $updateData['order_status'] = 5;
                if(C::t('#tom_tcmall#tom_tcmall_order_goods')->update($value['id'], $updateData)){
                    DB::query("UPDATE ".DB::table('tom_tcmall_goods')." SET stock=stock+{$value['goods_num']}, sales=sales-{$value['goods_num']} WHERE id={$value['goods_id']}", 'UNBUFFERED');
                    if($value['option_id'] > 0){
                        DB::query("UPDATE ".DB::table('tom_tcmall_goods_option')." SET stock=stock+{$value['goods_num']} WHERE id={$value['option_id']}", 'UNBUFFERED');
                    }
                }  
            }
        }
    }
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}