<?php

/**
   Copyright 2001-2099 DisM!Ӧ������.
   This is NOT a freeware, use is subject to license terms
   Ӧ�ø���֧�֣�https://dism.taobao.com
   ���²����http://t.cn/Aiux1Jx1
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tcmallConfig       = $_G['cache']['plugin']['tom_tcmall'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset       = getglobal('setting/timeoffset');
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
$nowDayTime         = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime       = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime        = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcmall/class/templatesms.class.php';
$weixinClass        = new weixinClass($appid,$appsecret);

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/config.utf8.php';
}

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcchoujiang start
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')){
    $tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
    if($tcchoujiangConfig['open_tcchoujiang'] == 1){
        $__ShowTcchoujiang = 1;
    }
}
## tcchoujiang end
## tcadmin start
$__ShowTcadmin = 0;
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
    if($tcadminConfig['open_fc'] == 1){
        $__ShowTcadmin = 1;
    }
}
## tcadmin end
## print start
$__ShowPrint = 0;
$printConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_print/tom_print.inc.php')){
    $printConfig = $_G['cache']['plugin']['tom_print'];
    if($printConfig['open_print'] == 1){
        $__ShowPrint = 1;
    }
}
## print end

$payOrderInfo = C::t('#tom_tcmall#tom_tcmall_order_pay')->fetch_by_pay_order_no($order_no);
if($payOrderInfo && $payOrderInfo['order_status'] == 1){
    
    $pushTemplateList = array();
    $huodaoTemplateList = array();
    $yu_balance_orders = array();
    $printList = array();
    $tj_hehuoren_id = 0;
    $pay_dikou_score_num = 0;
    
    $updateData = array();
    $updateData['order_status'] = 2;
    $updateData['pay_time'] = TIMESTAMP;
    if(C::t('#tom_tcmall#tom_tcmall_order_pay')->update($payOrderInfo['id'],$updateData)){
        if($payOrderInfo['type'] == 2){
            $orderInfoTmp = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_order_no($order_no);
            if($orderInfoTmp && $orderInfoTmp['order_status'] == 1){
                $updateData = array();
                $updateData['order_status'] = 2;
                $updateData['pay_time'] = TIMESTAMP;
                C::t('#tom_tcmall#tom_tcmall_order')->update($orderInfoTmp['id'],$updateData);
                $pushTemplateList[] = $orderInfoTmp;
                $yu_balance_orders[] = $orderInfoTmp;
                $pay_dikou_score_num = $pay_dikou_score_num + $orderInfoTmp['score_num'];
                
                $printList[] = $orderInfoTmp['order_no'];
                
                $goodsOrderListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$orderInfoTmp['id']} ", 'ORDER BY id DESC', 0, 1000);
                if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
                    foreach($goodsOrderListTmp as $gk => $gv){
                        if($gv['tj_hehuoren_id'] > 0){
                            $tj_hehuoren_id = $gv['tj_hehuoren_id'];
                        }
                        if($gv['order_status'] == 1){
                            $updateData = array();
                            $updateData['order_status'] = 2;
                            C::t('#tom_tcmall#tom_tcmall_order_goods')->update($gv['id'],$updateData);
                        }
                    }
                }
            }
            
        }else{
            
            $orderNoArr = explode(',', $payOrderInfo['order_no_str']);
            if(is_array($orderNoArr) && !empty($orderNoArr)){
                foreach($orderNoArr as $key => $value){
                    $orderInfoTmp = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_order_no($value);
                    if($orderInfoTmp && $orderInfoTmp['order_status'] == 1){
                        $updateData = array();
                        $updateData['order_status'] = 2;
                        $updateData['pay_time'] = TIMESTAMP;
                        C::t('#tom_tcmall#tom_tcmall_order')->update($orderInfoTmp['id'],$updateData);
                        $pushTemplateList[] = $orderInfoTmp;
                        $yu_balance_orders[] = $orderInfoTmp;
                        $pay_dikou_score_num = $pay_dikou_score_num + $orderInfoTmp['score_num'];
                        
                        $printList[] = $orderInfoTmp['order_no'];
                        
                        $goodsOrderListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$orderInfoTmp['id']} ", 'ORDER BY id DESC', 0, 1000);
                        if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
                            foreach($goodsOrderListTmp as $gk => $gv){
                                if($gv['tj_hehuoren_id'] > 0){
                                    $tj_hehuoren_id = $gv['tj_hehuoren_id'];
                                }
                                if($gv['order_status'] == 1){
                                    $updateData = array();
                                    $updateData['order_status'] = 2;
                                    C::t('#tom_tcmall#tom_tcmall_order_goods')->update($gv['id'],$updateData);
                                }
                            }
                        }
                    }else if($orderInfoTmp && $orderInfoTmp['order_status'] == 8){
                        $huodaoTemplateList[] = $orderInfoTmp;
                    }
                }
            }
        }
    }
    
    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($payOrderInfo['pay_order_no'])));
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($payOrderInfo['user_id']); 
    
    if($pay_dikou_score_num > 0){
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_dikou_score_num;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_dikou_score_num;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 35;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    }
    
    if($payOrderInfo['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($payOrderInfo['site_id']);
        $tcmallConfig['tcchoujiang_id'] = $sitesInfoTmp['tcmall_tcchoujiang_id'];
    }
    
    if($__ShowTcchoujiang == 1 && $tcmallConfig['tcchoujiang_id'] > 0){
        $choujiangInfo    = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcmallConfig['tcchoujiang_id']);
        if($choujiangInfo['status'] == 1 && $choujiangInfo['shenhe_status'] == 1 && $choujiangInfo['type'] == 3){
            $choujiangBmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($tcmallConfig['tcchoujiang_id'],$userInfo['id']);
            if($choujiangBmInfo){
                DB::query("UPDATE ".DB::table('tom_tcchoujiang_bm')." SET cj_times=cj_times+1 WHERE id='".$choujiangBmInfo['id']."' ", 'UNBUFFERED');
            }else{
                $insertData = array();
                $insertData['tcchoujiang_id']          = $tcmallConfig['tcchoujiang_id'];
                $insertData['user_id']                 = $userInfo['id'];
                $insertData['xm']                      = $userInfo['nickname'];
                $insertData['tel']                     = $userInfo['tel'];
                $insertData['cj_times']                = 1;
                $insertData['time_key']                = $nowDayTime;
                $insertData['add_time']                = TIMESTAMP;
                C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->insert($insertData);
            }
        }
    }
    
    if($__ShowTchehuoren == 1 && $tcmallConfig['open_buy_hehuoren'] == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/class/function.hehuoren.php';
        add_hehuoren($payOrderInfo['user_id'], $tj_hehuoren_id);
    }
    
    if($__ShowPrint == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_print/print.func.php';
        foreach ($printList AS $key => $value){
            @add_mall_print($value);
        }
        foreach ($printList AS $key => $value){
            @mall_print($value);
        }
    }
    
    if(is_array($yu_balance_orders) && !empty($yu_balance_orders)){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/module/yu_balance.php';
    }

    if(!empty($tcmallConfig['template_neworder']) && is_array($pushTemplateList) && !empty($pushTemplateList)){
        
        foreach($pushTemplateList as $key => $value){
            $access_token = $weixinClass->get_access_token();
            $orderTcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
            $orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderTcshopInfoTmp['user_id']); 
            
            $goodsOrderListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$value['id']} ", 'ORDER BY id DESC', 0, 1000);
            $goods_title_arr = array();
            $goods_title_str = '';
            if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
                foreach($goodsOrderListTmp as $gk => $gv){
                    $goods_title_arr[]=$gv['goods_title'];
                }
            }
            $goods_title_str = implode('|', $goods_title_arr);
            
            if($access_token && !empty($orderUserInfoTmp['openid']) ){
                
                $templateSmsClass = new mTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcmall&site=".$payOrderInfo['site_id']."&mod=myorder");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcmall','template_neworder_first'),
                    'keyword1'      => $goods_title_str,
                    'keyword2'      => $value['pay_price'],
                    'keyword3'      => $value['address_xm'],
                    'keyword4'      => $value['address_tel'],
                    'keyword5'      => $value['order_no'],
                    'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
                );
                $r = $templateSmsClass->sendSmsNewOrder($orderUserInfoTmp['openid'],$tcmallConfig['template_neworder'],$smsData);
                if($r){
                    Log::DEBUG("template sms manage_1_openid:" . json_encode($smsData));
                }
            }
        }
    }
    
    if(!empty($tcmallConfig['template_neworder']) && is_array($huodaoTemplateList) && !empty($huodaoTemplateList)){
        
        foreach($huodaoTemplateList as $key => $value){
            $access_token = $weixinClass->get_access_token();
            $orderTcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
            $orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderTcshopInfoTmp['user_id']); 
            
            $goodsOrderListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$value['id']} ", 'ORDER BY id DESC', 0, 1000);
            $goods_title_arr = array();
            $goods_title_str = '';
            if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
                foreach($goodsOrderListTmp as $gk => $gv){
                    $goods_title_arr[]=$gv['goods_title'];
                }
            }
            $goods_title_str = implode('|', $goods_title_arr);
            
            if($access_token && !empty($orderUserInfoTmp['openid']) ){
                
                $templateSmsClass = new mTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcmall&site=".$payOrderInfo['site_id']."&mod=myorder");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcmall','template_neworder_huodao_first'),
                    'keyword1'      => $goods_title_str,
                    'keyword2'      => $value['pay_price'],
                    'keyword3'      => $value['address_xm'],
                    'keyword4'      => $value['address_tel'],
                    'keyword5'      => $value['order_no'],
                    'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
                );
                $r = $templateSmsClass->sendSmsNewOrder($orderUserInfoTmp['openid'],$tcmallConfig['template_neworder'],$smsData);
                if($r){
                    Log::DEBUG("template sms manage_huodao_pay1_openid:" . json_encode($smsData));
                }
            }
        }
    }
    
}