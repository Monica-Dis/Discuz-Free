<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20201029";

$pcadminUrl = 'plugin.php?id=tom_tcmall:pcadmin';
$ajaxUrl = 'plugin.php?id=tom_admin:ajax';
$mallAjaxUrl = 'plugin.php?id=tom_tcmall:pcadminAjax';
$uploadUrl = 'plugin.php?id=tom_admin:upload';
$baidumapUrl = 'plugin.php?id=tom_admin:baidumap';

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcmall/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/pcadmin.lang.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

$Lang = $pcadminLang;

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/config.utf8.php';
}

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcyikatong start
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
    $tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $__ShowTcyikatong = 1;
    }
}
## tcyikatong end
## kuaidi start
$__ShowKuaidi = 0;
$kuaidiConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_kuaidi/tom_kuaidi.inc.php')){
    $__ShowKuaidi = 1;
    $kuaidiConfig = $_G['cache']['plugin']['tom_kuaidi'];
}
## kuaidi end

include DISCUZ_ROOT.'./source/plugin/tom_admin/login_check.php';

if($__Admin['admin'] == 'shopadmin'){
    
    if($_GET['tmod'] == 'list'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcshopadmin/list.php';
    }else if($_GET['tmod'] == 'goodsorder'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/goodsorder.php';
    }else if($_GET['tmod'] == 'goodsorderinfo'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/goodsorderinfo.php';
    }else if($_GET['tmod'] == 'add'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/add.php';
    }else if($_GET['tmod'] == 'edit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/edit.php';
    }else if($_GET['tmod'] == 'pinglun'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/pinglun.php';
    }else if($_GET['tmod'] == 'stocklog'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/stocklog.php';
    }else if($_GET['tmod'] == 'optionlog'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/optionlog.php';
    }else if($_GET['tmod'] == 'order'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcshopadmin/order.php';
    }else if($_GET['tmod'] == 'orderinfo'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcshopadmin/orderinfo.php';
    }else if($_GET['tmod'] == 'orderprint'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/orderprint.php';
    }else if($_GET['tmod'] == 'coupon'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcshopadmin/coupon.php';
    }else if($_GET['tmod'] == 'couponadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/couponadd.php';
    }else if($_GET['tmod'] == 'couponedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/couponedit.php';
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcshopadmin/list.php';
    }
    
}else if($__Admin['admin'] == 'admin'){
    
    if($_GET['tmod'] == 'list'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/list.php';
    }else if($_GET['tmod'] == 'add'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/add.php';
    }else if($_GET['tmod'] == 'edit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/edit.php';
    }else if($_GET['tmod'] == 'optionlog'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/optionlog.php';
    }else if($_GET['tmod'] == 'stocklog'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/stocklog.php';
    }else if($_GET['tmod'] == 'pinglun'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/pinglun.php';
    }else if($_GET['tmod'] == 'goodsorder'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/goodsorder.php';
    }else if($_GET['tmod'] == 'goodsorderinfo'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/goodsorderinfo.php';
    }else if($_GET['tmod'] == 'order'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/order.php';
    }else if($_GET['tmod'] == 'orderinfo'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/orderinfo.php';
    }else if($_GET['tmod'] == 'orderprint'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/orderprint.php';
    }else if($_GET['tmod'] == 'coupon'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/coupon.php';
    }else if($_GET['tmod'] == 'couponadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/couponadd.php';
    }else if($_GET['tmod'] == 'couponedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/couponedit.php';
    }else if($_GET['tmod'] == 'lingqulist'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/lingqulist.php';
    }else if($_GET['tmod'] == 'shoprecom'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/shoprecom.php';
    }else if($_GET['tmod'] == 'focuspic'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/focuspic.php';
    }else if($_GET['tmod'] == 'focuspicadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/focuspicadd.php';
    }else if($_GET['tmod'] == 'focuspicedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/focuspicedit.php';
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tcmall/pcadmin/list.php';
    }
}