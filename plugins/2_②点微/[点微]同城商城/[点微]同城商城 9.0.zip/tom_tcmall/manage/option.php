<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
$goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($_GET['goods_id']);

$act = isset($_GET['act'])? addslashes($_GET['act']):'';
if($act == 'add_spec' && $_GET['formhash'] == FORMHASH){
    $outStr = '';
     
    $insertData= array();
    $insertData['goods_id'] = $goods_id;
    C::t("#tom_tcmall#tom_tcmall_goods_spec")->insert($insertData);
    $spec_id = C::t("#tom_tcmall#tom_tcmall_goods_spec")->insert_id();
    
    C::t("#tom_tcmall#tom_tcmall_goods_option")->delete_by_goods_id($goods_id);
    
    $outStr = $spec_id;
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($act == 'add_item' && $_GET['formhash'] == FORMHASH){
    $outStr = '';
    
    $spec_id = intval($_GET['spec_id'])>0? intval($_GET['spec_id']): 0;
    $insertData = array();
    $insertData['spec_id'] = $spec_id;
    C::t("#tom_tcmall#tom_tcmall_goods_spec_item")->insert($insertData);
    $item_id = C::t("#tom_tcmall#tom_tcmall_goods_spec_item")->insert_id();
    
    $outStr = $item_id;
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($act == 'save_spec' && $_GET['formhash'] == FORMHASH){
    
    $spec_id    = intval($_GET['spec_id'])>0? intval($_GET['spec_id']): 0;
    $ssort      = intval($_GET['ssort'])>0? intval($_GET['ssort']): 10;
    $name       = !empty($_GET['name'])? addslashes(urldecode($_GET['name'])):'';
    $updateData = array();
    $insertData['name']     = $name;
    $insertData['ssort']    = $ssort;
    C::t("#tom_tcmall#tom_tcmall_goods_spec")->update($spec_id, $insertData);
    echo 1;exit;
    
}else if($act == 'save_item' && $_GET['formhash'] == FORMHASH){
    
    $item_id    = intval($_GET['item_id'])>0? intval($_GET['item_id']): 0;
    $name       = !empty($_GET['name'])? addslashes(urldecode($_GET['name'])):'';
    
    $name = str_replace(" ","+",$name);

    $updateData = array();
    $updateData['name']     = $name;
    C::t("#tom_tcmall#tom_tcmall_goods_spec_item")->update($item_id, $updateData);
    echo 1;exit;
}else if($act == 'remove_spec' && $_GET['formhash'] == FORMHASH){
    
    $spec_id = intval($_GET['spec_id'])>0? intval($_GET['spec_id']): 0;
    
    C::t("#tom_tcmall#tom_tcmall_goods_spec")->delete_by_id($spec_id);
    C::t("#tom_tcmall#tom_tcmall_goods_spec_item")->delete_by_spec_id($spec_id);
    C::t("#tom_tcmall#tom_tcmall_goods_option")->delete_by_goods_id($goods_id);
    
    echo 1;exit;

}else if($act == 'remove_item' && $_GET['formhash'] == FORMHASH){
    
    $item_id = intval($_GET['item_id'])>0? intval($_GET['item_id']): 0;
    
    C::t("#tom_tcmall#tom_tcmall_goods_spec_item")->delete_by_id($item_id);
    
    echo 1;exit;

}else if($act == 'save_option' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $itemIdsArr = array();
    if(isset($_GET['spec_item_ids']) && is_array($_GET['spec_item_ids']) && !empty($_GET['spec_item_ids'])){
        foreach($_GET['spec_item_ids'] as $key => $value){
            $itemIdsArr[] = addslashes($value);
        }
    }
    
    $stock_num = $show_market_price = $show_buy_price = $show_vip_price = $show_score_num = $show_score_dikou_price = 0;
    $beizu = '';
    $optionIdsArr = array();
    if(is_array($itemIdsArr) && !empty($itemIdsArr)){
        foreach($itemIdsArr as $key => $value){
            $id                 = intval($_GET['option_id_'.$value])>0? intval($_GET['option_id_'.$value]):0;
            $name               = isset($_GET['option_name_'.$value])? addslashes($_GET['option_name_'.$value]):'';
            $stock              = intval($_GET['option_stock_'.$value])>0? intval($_GET['option_stock_'.$value]):0;
            $market_price       = floatval($_GET['option_market_price_'.$value])>0? floatval($_GET['option_market_price_'.$value]):0.00;
            $buy_price          = floatval($_GET['option_buy_price_'.$value])>0? floatval($_GET['option_buy_price_'.$value]):0.00;
            $vip_price          = floatval($_GET['option_vip_price_'.$value])>0? floatval($_GET['option_vip_price_'.$value]):0.00;
            $score_num          = intval($_GET['option_score_num_'.$value])>0? intval($_GET['option_score_num_'.$value]):0;
            $score_dikou_price  = floatval($_GET['option_score_dikou_price_'.$value])>0? floatval($_GET['option_score_dikou_price_'.$value]):0.00;
            $weight             = intval($_GET['option_weight_'.$value])>0? intval($_GET['option_weight_'.$value]):0;
            
            if($market_price <= 0){
                $market_price = $buy_price;
            }
            
            $optionInfo = array();
            if($id > 0){
                $optionInfo = C::t("#tom_tcmall#tom_tcmall_goods_option")->fetch_by_id($id);
            }
            if(is_array($optionInfo) && !empty($optionInfo)){
                $updateData = array();
                $updateData['goods_id']         = $goods_id;
                $updateData['name']             = $name;
                $updateData['market_price']     = $market_price;
                $updateData['buy_price']        = $buy_price;
                $updateData['vip_price']        = $vip_price;
                $updateData['score_num']        = $score_num;
                $updateData['score_dikou_price'] = $score_dikou_price;
                $updateData['stock']            = $stock;
                $updateData['weight']           = $weight;
                $updateData['spec_item_ids']    = $value;
                C::t("#tom_tcmall#tom_tcmall_goods_option")->update($id, $updateData);
                $option_id = $id;
            }else{
                $insertData = array();
                $insertData['goods_id']         = $goods_id;
                $insertData['name']             = $name;
                $insertData['market_price']     = $market_price;
                $insertData['buy_price']        = $buy_price;
                $insertData['vip_price']        = $vip_price;
                $insertData['score_num']        = $score_num;
                $insertData['score_dikou_price'] = $score_dikou_price;
                $insertData['stock']            = $stock;
                $insertData['weight']           = $weight;
                $insertData['spec_item_ids']    = $value;
                C::t("#tom_tcmall#tom_tcmall_goods_option")->insert($insertData);
                $option_id = C::t("#tom_tcmall#tom_tcmall_goods_option")->insert_id();
            }
            $optionIdsArr[] = $option_id;
            
            if($show_buy_price == 0){
                $show_market_price      = $market_price;
                $show_buy_price         = $buy_price;
                $show_vip_price         = $vip_price;
                $show_score_num         = $score_num;
                $show_score_dikou_price = $score_dikou_price;
            }else if($show_buy_price > $buy_price && $buy_price > 0){
                $show_market_price      = $market_price;
                $show_buy_price         = $buy_price;
                $show_vip_price         = $vip_price;
                $show_score_num         = $score_num;
                $show_score_dikou_price = $score_dikou_price;
            }
            
            $stock_num = $stock_num + $stock;
            $beizu .= 'ID:&nbsp;<span>'.$option_id.'</span> '.lang('plugin/tom_tcmall', 'option_name').'<span>'.$name.'</span>'.lang('plugin/tom_tcmall', 'option_stock').'<span>'.$stock.'</span> '.lang('plugin/tom_tcmall', 'option_market_price').'<span>'.$market_price.'</span> '.lang('plugin/tom_tcmall', 'option_buy_price').'<span>'.$buy_price.'</span> '.lang('plugin/tom_tcmall', 'option_vip_price').'<span>'.$vip_price.'</span> '.lang('plugin/tom_tcmall', 'option_weight').'<span>'.$weight.'</span>';
            if($goodsInfo['open_vip'] == 1){
                $beizu .= lang('plugin/tom_tcmall', 'option_vip_price').'<span>'.$vip_price.'</span>';
            }
            if($goodsInfo['open_score_dikou'] == 1){
                $beizu .= lang('plugin/tom_tcmall', 'option_score_num').'<span>'.$score_num.'</span>'.lang('plugin/tom_tcmall', 'option_score_dikou_price').'<span>'.$score_dikou_price.'</span>';
            }
            $beizu .= '<br/>';
        }
    }

    if(!empty($optionIdsArr)){
        $optionIdsStr = implode(',', $optionIdsArr);
        C::t("#tom_tcmall#tom_tcmall_goods_option")->delete_by_goods_id_not_id($goods_id, $optionIdsStr);
    }
    
    $updateData = array();
    $updateData['stock']                = $stock_num;
    $updateData['show_market_price']    = $show_market_price;
    $updateData['show_buy_price']       = $show_buy_price;
    $updateData['show_vip_price']       = $show_vip_price;
    $updateData['show_score_num']       = $show_score_num;
    $updateData['show_score_dikou_price'] = $show_score_dikou_price;
    C::t("#tom_tcmall#tom_tcmall_goods")->update($goods_id, $updateData);
    
    $insertData = array();
    $insertData['is_admin']     = 1;
    $insertData['is_option']    = 1;
    $insertData['goods_id']     = $goods_id;
    $insertData['beizu']        = $beizu;
    $insertData['change_num']   = $stock_num;
    $insertData['change_time']  = TIMESTAMP;
    C::t("#tom_tcmall#tom_tcmall_goods_stock_log")->insert($insertData);
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
}

$goodsSpecListTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec')->fetch_all_list(" AND goods_id = {$goods_id} ", 'ORDER BY ssort ASC ,id ASC', 0, 1000);
$goodsSpecList = array();
if(is_array($goodsSpecListTmp) && !empty($goodsSpecListTmp)){
    foreach($goodsSpecListTmp as $key => $value){
        $goodsSpecList[$key] = $value;
        $itemListTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec_item')->fetch_all_list(" AND spec_id = {$value['id']} ", 'ORDER BY id ASC', 0, 1000);
        $itemList = array();
        $itemCount = count($itemListTmp);
        if(is_array($itemListTmp) && !empty($itemListTmp)){
            foreach($itemListTmp as $k => $v){
                $itemList[$k] = $v;
                $picurl = '';
                if(!empty($v['picurl'])){
                    if(!preg_match('/^http/', $v['picurl']) ){
                        if(strpos($v['picurl'], 'source/plugin/tom_tcmall/') === FALSE){
                            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$v['picurl'];
                        }else{
                            $picurl = $v['picurl'];
                        }
                    }else{
                        $picurl = $v['picurl'];
                    }
                }
                $itemList[$k]['picurl'] = $picurl;
            }
        }
        $goodsSpecList[$key]['itemList'] = $itemList;
        $goodsSpecList[$key]['itemCount'] = $itemCount;
    }
}

$goodsSpecListTmpTmp = $goodsSpecList;
$goodsSpecListTmpTmp = array_spec_count_sort($goodsSpecListTmpTmp, 'itemCount');

$optionData = $optionNameList = array();
if(is_array($goodsSpecListTmpTmp) && !empty($goodsSpecListTmpTmp)){
    foreach($goodsSpecListTmpTmp as $key => $value){
        $itemListTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec_item')->fetch_all_list(" AND spec_id = {$value['id']} ", 'ORDER BY id ASC', 0, 1000);
        $itemList = array();
        if(is_array($itemListTmp) && !empty($itemListTmp)){
            foreach($itemListTmp as $k => $v){
                $itemList[$k]['id'] = $v['id'];
                $itemList[$k]['name'] = $v['name'];
            }
        }
        $optionNameList[] = $value['name'];
        $optionData[] = $itemList;
    }
}

$len = count($optionData);
$newlen = 1;
$h = array();
$rowspans = array();
for ($i = 0; $i < $len; $i++) {
    $itemlen = count($optionData[$i]);
    if($itemlen <= 0){
        $itemlen = 1;
    }
    $newlen = $newlen*$itemlen;
    
    $h[$i] = array();
    for ($j = 0; $j < $newlen; $j++) {
        $h[$i][$j] = array();
    }
    $rowspans[$i] = 1;
    for ($j = $i + 1; $j < $len; $j++) {
        $rowspans[$i] *= count($optionData[$j]);
    }
}

for ($m = 0; $m < $len; $m++) {
    $k = 0;
    $kid = 0;
    $n = 0;
    for ($j = 0; $j < $newlen; $j++) {
        $rowspan = $rowspans[$m];
        if ($rowspan > 0 && $j % $rowspan == 0) {
            $h[$m][$j] = $optionData[$m][$kid];
            $h[$m][$j]['tb'] = '<td rowspan="'.$rowspan.'">'.$optionData[$m][$kid]['name'].'</td>';
        }else{
            $h[$m][$j] = $optionData[$m][$kid];
            $h[$m][$j]['tb'] = '';
        }
        $n++;
        if ($n == $rowspan) {
            $kid++;
            if ($kid > count($optionData[$m]) - 1) {
                $kid = 0;
            }
            $n = 0;
        }
    }
}

$optionListTmp = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_all_list(" AND goods_id = {$goods_id} ");
$matchOptionData = $optionData = array();
if(!empty($optionListTmp)){
    foreach($optionListTmp as $key => $value){
        $optionData[$value['spec_item_ids']] = $value;
        
        $specItemIdsArrTmp = explode('-', $value['spec_item_ids']);
        sort($specItemIdsArrTmp);
        $specItemIdsStrTmp = implode('-', $specItemIdsArrTmp);
        $matchOptionData[$specItemIdsStrTmp] = $value;
    }
}

for ($i = 0; $i < $newlen; $i++) {
    $html.= "<tr>";
    $ids = array();
    $name = array();
    for ($j = 0; $j < $len; $j++) {
        $html.= $h[$j][$i]['tb'];
        $ids[] = $h[$j][$i]['id'];
        $name[] = $h[$j][$i]['name'];
    }
    $ids = implode('-', $ids);
    $name = implode('+', $name);
    
    $optionInfo = array();
    if(isset($optionData[$ids]) && !empty($optionData[$ids])){
        $optionInfo = $optionData[$ids];
    }else{
        $specItemIdsArrTmp = explode('-', $ids);
        sort($specItemIdsArrTmp);
        $specItemIdsStrTmp = implode('-', $specItemIdsArrTmp);
        
        if(isset($matchOptionData[$specItemIdsStrTmp]) && !empty($matchOptionData[$specItemIdsStrTmp])){
            $optionInfo = $matchOptionData[$specItemIdsStrTmp];
        }
    }
    
    $html.= "<td>";
    $html.= '<input name="option_stock_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['stock'].'"/></td>';
    $html.= '<input name="option_id_'.$ids.'" type="hidden"  value="'.$optionInfo['id'].'"/></td>';
    $html.= '<input name="spec_item_ids[]" type="hidden"  value="'.$ids.'"/></td>';
    $html.= '<input name="option_name_'.$ids.'" type="hidden"  value="'.$name.'"/></td>';
    $html.= '</td>';
    $html.= "<td>";
    $html.= '<input name="option_market_price_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['market_price'].'"/></td>';
    $html.= '</td>';
    $html.= "<td>";
    $html.= '<input name="option_buy_price_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['buy_price'].'"/></td>';
    $html.= '</td>';
    if($goodsInfo['open_vip'] == 1){
        $html.= "<td>";
        $html.= '<input name="option_vip_price_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['vip_price'].'"/></td>';
        $html.= '</td>';
    }
    if($goodsInfo['open_score_dikou'] == 1){
        $html.= "<td>";
        $html.= '<input name="option_score_num_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['score_num'].'"/></td>';
        $html.= '</td>';
        $html.= "<td>";
        $html.= '<input name="option_score_dikou_price_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['score_dikou_price'].'"/></td>';
        $html.= '</td>';
    }
    //$html.= "<td>";
    //$html.= '<input name="option_weight_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['weight'].'"/></td>';
    //$html.= '</td>';
    $html.= "</tr>";
}

$specCount = count($goodsSpecList);

$addSpecUrl = "plugin.php?id=tom_tcmall:manage&mod=option&act=add_spec&goods_id={$goods_id}&formhash={$formhash}";
$addItemUrl = "plugin.php?id=tom_tcmall:manage&mod=option&act=add_item&goods_id={$goods_id}&formhash={$formhash}";
$saveOptionUrl = "plugin.php?id=tom_tcmall:manage&mod=option&act=save_option&goods_id={$goods_id}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:manage/option");