<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/config.utf8.php';
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcmall/class/function.core.php';

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

if($_GET['act'] == 'save_cart' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $goods_id           = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    $user_id            = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $tj_hehuoren_id     = intval($_GET['tj_hehuoren_id'])>0? intval($_GET['tj_hehuoren_id']):0;
    $goods_num          = intval($_GET['number'])>0? intval($_GET['number']):1;
    
    if($__UserInfo['id'] <= 0 || $user_id != $__UserInfo['id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    $goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($goods_id);
    
    $cartCount = C::t('#tom_tcmall#tom_tcmall_cart')->fetch_all_count(" AND user_id={$user_id}");
    if($cartCount >= 30){
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['max_buy'] > 0){
        $buyGoodsCount = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_goods_num("AND goods_id = {$goods_id} AND user_id = {$user_id} AND order_status IN(1,2,3,4,8)");
        $syBuyGoodsCount = $goodsInfo['max_buy'] - $buyGoodsCount;
        if($goods_num > $syBuyGoodsCount){
            $outArr = array(
                'status'=> 302,
                'num'=> $syBuyGoodsCount,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $buy_price = $option_id = $stock = 0;
    if($goodsInfo['hasoption'] == 1){
        $goodsSpecListTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec')->fetch_all_list(" AND goods_id={$goods_id} "," ORDER BY ssort ASC,id ASC ",0,20);

        $goodsSpecList = array();
        if(is_array($goodsSpecListTmp) && !empty($goodsSpecListTmp)){
            foreach($goodsSpecListTmp as $key => $value){
                $goodsSpecList[$key] = $value;
                $itemCount = C::t('#tom_tcmall#tom_tcmall_goods_spec_item')->fetch_all_count(" AND spec_id = {$value['id']} ");
                $goodsSpecList[$key]['itemCount'] = $itemCount;
            }
        }

        $goodsSpecList = array_spec_count_sort($goodsSpecList, 'itemCount');
        $itemArr = array();
        if(is_array($goodsSpecList) && !empty($goodsSpecList)){
            foreach($goodsSpecList as $key => $value){
                $itemArr[] = intval($_GET['spec'.$value['id'].'_item_id'])>0? intval($_GET['spec'.$value['id'].'_item_id']):0;
            }
        }

        $itemIdStr = implode('-', $itemArr);
        $optionInfo = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_by_spec_item_ids($itemIdStr);
        if(is_array($optionInfo) && !empty($optionInfo)){ 
            $stock = $optionInfo['stock'];
            $option_id = $optionInfo['id'];
            $buy_price = $optionInfo['buy_price'];
        }else{
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $stock = $goodsInfo['stock'];
        $buy_price = $goodsInfo['buy_price'];
    }
    
    if($goods_num > $stock){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    $where = "AND user_id={$user_id} AND goods_id = {$goods_id} ";
    if($option_id > 0){
        $where .= " AND option_id = {$option_id} ";
    }
    
    $cartInfoTmp = C::t('#tom_tcmall#tom_tcmall_cart')->fetch_all_list($where, 'ORDER BY id DESC', 0, 1);
    if(is_array($cartInfoTmp) && !empty($cartInfoTmp[0])){

        DB::query("UPDATE ".DB::table('tom_tcmall_cart')." SET goods_num=goods_num+{$goods_num} WHERE id='{$cartInfoTmp[0]['id']}'", 'UNBUFFERED');
    }else{
        $insertData                     = array();
        $insertData['user_id']          = $user_id;
        $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
        $insertData['goods_id']         = $goods_id;
        $insertData['goods_num']        = $goods_num;
        $insertData['buy_price']        = $buy_price;
        $insertData['option_id']        = $option_id;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcmall#tom_tcmall_cart')->insert($insertData);
    }

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'mini_save_cart' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $goods_id           = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    $user_id            = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $spec_item_ids      = intval($_GET['spec_item_ids'])>0? intval($_GET['spec_item_ids']):0;
    $tj_hehuoren_id     = intval($_GET['tj_hehuoren_id'])>0? intval($_GET['tj_hehuoren_id']):0;
    $goods_num          = intval($_GET['number'])>0? intval($_GET['number']):1;
    
    if($tchehuorenConfig['tcmall_type'] == 2  && $__UserInfo['tj_hehuoren_id'] > 0){
        $tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
    }
    if($tchehuorenConfig['tcmall_type'] == 3 && $__UserInfo['tj_hehuoren_id'] > 0 && $tj_hehuoren_id == 0){
        $tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
    }
    if($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0 && $tcmallConfig['open_hehuoren_self_sheng'] == 1){
        $tchehuorenInfoTmpTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
        if($tchehuorenInfoTmpTmp && $tchehuorenInfoTmpTmp['status'] == 1){
            $tj_hehuoren_id = $tchehuorenInfoTmpTmp['id'];
        }
    }

    if($__UserInfo['id'] <= 0 || $user_id != $__UserInfo['id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    $goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($goods_id);
    
    $cartCount = C::t('#tom_tcmall#tom_tcmall_cart')->fetch_all_count(" AND user_id={$user_id}");
    if($cartCount >= 30){
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['max_buy'] > 0){
        $buyGoodsCount = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_goods_num("AND goods_id = {$goods_id} AND user_id = {$user_id} AND order_status IN(1,2,3,4,8)");
        $syBuyGoodsCount = $goodsInfo['max_buy'] - $buyGoodsCount;
        if($goods_num > $syBuyGoodsCount){
            $outArr = array(
                'status'=> 302,
                'num'=> $syBuyGoodsCount,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $buy_price = $option_id = $stock = 0;
    if($goodsInfo['hasoption'] == 1){
        $optionInfo = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_by_spec_item_ids($spec_item_ids);
        
        if(is_array($optionInfo) && !empty($optionInfo)){ 
            $stock = $optionInfo['stock'];
            $option_id = $optionInfo['id'];
            $buy_price = $optionInfo['buy_price'];
        }else{
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $stock = $goodsInfo['stock'];
        $buy_price = $goodsInfo['buy_price'];
    }
    
    if($goods_num > $stock){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    $where = "AND user_id={$user_id} AND goods_id = {$goods_id} ";
    if($option_id > 0){
        $where .= " AND option_id = {$option_id} ";
    }
    
    $cartInfoTmp = C::t('#tom_tcmall#tom_tcmall_cart')->fetch_all_list($where, 'ORDER BY id DESC', 0, 1);
    if(is_array($cartInfoTmp) && !empty($cartInfoTmp[0])){

        DB::query("UPDATE ".DB::table('tom_tcmall_cart')." SET goods_num=goods_num+{$goods_num} WHERE id='{$cartInfoTmp[0]['id']}'", 'UNBUFFERED');
    }else{
        $insertData                     = array();
        $insertData['user_id']          = $user_id;
        $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
        $insertData['goods_id']         = $goods_id;
        $insertData['goods_num']        = $goods_num;
        $insertData['buy_price']        = $buy_price;
        $insertData['option_id']        = $option_id;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcmall#tom_tcmall_cart')->insert($insertData);
    }

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'remove_cart' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $cart_id = intval($_GET['cart_id'])>0? intval($_GET['cart_id']):0;
    
    C::t('#tom_tcmall#tom_tcmall_cart')->delete_by_id($cart_id);
    $outArr = array(
       'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'update_cart_total' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $cart_id = intval($_GET['cart_id'])>0? intval($_GET['cart_id']):0;
    $number = intval($_GET['number'])>0? intval($_GET['number']):1;
    
    $cartInfo = C::t("#tom_tcmall#tom_tcmall_cart")->fetch_by_id($cart_id);
    $goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($cartInfo['goods_id']);
    
    $stock = $goodsInfo['stock'];
    if($cartInfo['option_id'] > 0){
        $optionInfo = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_by_id($cartInfo['option_id']);
        $stock = $optionInfo['stock'];
    }
    
    $no_add = 0;
    if($number > $stock){
        $outArr = array(
            'status'=> 301,
            'no_add'=> 1,
         );
         echo json_encode($outArr); exit;
    }else if($number == $stock){
        $no_add = 1;
    }
    
    if($goodsInfo['max_buy'] > 0){
        $buyGoodsCount = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_goods_num("AND goods_id = {$goodsInfo['id']} AND user_id = {$cartInfo['user_id']} AND order_status IN(1,2,3,4,8)");
        $syBuyGoodsCount = $goodsInfo['max_buy'] - $buyGoodsCount;
        if($number > $syBuyGoodsCount){
            $unit = diconv($goodsInfo['unit'],CHARSET,'utf-8');
            $outArr = array(
                'status'=> 302,
                'num'=> $syBuyGoodsCount.$unit,
                'no_add'=> 1,
            );
            echo json_encode($outArr); exit;
        }else if($number == $syBuyGoodsCount){
            $no_add = 1;
        }
    }
    
    $updateData = array();
    $updateData['goods_num'] = $number;
    C::t('#tom_tcmall#tom_tcmall_cart')->update($cart_id, $updateData);
    $outArr = array(
       'status'=> 200,
        'no_add' => $no_add,
    );
    echo json_encode($outArr); exit;
    
}else{
    echo 'error';exit;
}