<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tcmall_coupon_lingqu extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dism �� taobao �� com*/
		$this->_table = 'tom_tcmall_coupon_lingqu';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
    public function fetch_all_list($condition,$orders = '',$start = 0,$limit = 10) {
		$data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
		return $data;
	}
    
    public function fetch_all_lingqu_coupon_list($condition='',$orders = '',$start = 0,$limit = 10) {
        $data = DB::fetch_all("SELECT t.*,c.title,c.tcshop_id,c.coupon_type,c.full_price,c.reduce_price,c.start_time,c.end_time,c.status AS coupon_status,c.content,c.is_yikatong,c.is_hehuoren  FROM %t t LEFT JOIN ".DB::table("tom_tcmall_coupon")." c on c.id=t.coupon_id  WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition) {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
    
    public function fetch_all_lingqu_coupon_count($condition='') {
        $return = DB::fetch_first("SELECT count(*) AS num FROM %t t LEFT JOIN ".DB::table("tom_tcmall_coupon")." c on c.id=t.coupon_id  WHERE 1 $condition",array($this->_table));
        return $return['num'];
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_coupon_id($coupon_id) {
		return DB::query("DELETE FROM %t WHERE coupon_id=%d", array($this->_table, $coupon_id));
	}

}