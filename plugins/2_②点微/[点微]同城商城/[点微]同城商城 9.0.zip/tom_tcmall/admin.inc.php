<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcmall'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcmall&pmod=admin'; 
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcmall&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcmall&pmod=admin';
$tomSysOffset = getglobal('setting/timeoffset');

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/config.utf8.php';
}

include DISCUZ_ROOT.'./source/plugin/tom_tcmall/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcmall/class/function.admin.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
$tcmallConfig = get_plugin_config($pluginid);
$Lang = formatLang($Lang);

$tongchengPlugin = C::t('#tom_tcshop#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);

if($_GET['tmod'] == 'goods'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/admin/goods.php';
}else if($_GET['tmod'] == 'goodsorder'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/admin/goodsorder.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/admin/order.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/admin/focuspic.php';
}else if($_GET['tmod'] == 'cate'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/admin/cate.php';
}else if($_GET['tmod'] == 'shoprecom'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/admin/shoprecom.php';
}else if($_GET['tmod'] == 'refund'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/admin/refund.php';
}else if($_GET['tmod'] == 'coupon'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/admin/coupon.php';
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/admin/addon.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/admin/goods.php';
}