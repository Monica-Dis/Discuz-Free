<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/plugin');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $sql = '';
    
    $tom_tcmall_goods_field = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_field();
    if (!isset($tom_tcmall_goods_field['dispatch_type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `dispatch_type` tinyint(4) DEFAULT '1';\n";
    }
    if (!isset($tom_tcmall_goods_field['shop_cate_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `shop_cate_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcmall_goods_field['edmoney'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `edmoney` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcmall_goods_field['allow_refund'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `allow_refund` int(11) DEFAULT '1';\n";
    }
    if (!isset($tom_tcmall_goods_field['sub_title'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `sub_title` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcmall_goods_field['open_score_dikou'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `open_score_dikou` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcmall_goods_field['score_num'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `score_num` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcmall_goods_field['score_dikou_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `score_dikou_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcmall_goods_field['show_score_num'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `show_score_num` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcmall_goods_field['show_score_dikou_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `show_score_dikou_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcmall_goods_field['zhibo_roomid'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `zhibo_roomid` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcmall_goods_field['open_express'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `open_express` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcmall_goods_field['express_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` ADD `express_id` int(11) DEFAULT '0';\n";
    }

    $tom_tcmall_order_goods_field = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_field();
    if (!isset($tom_tcmall_order_goods_field['goods_title'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_order_goods` ADD `goods_title` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcmall_order_goods_field['score_num'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_order_goods` ADD `score_num` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcmall_order_goods_field['score_dikou_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_order_goods` ADD `score_dikou_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    
    $tom_tcmall_focuspic_field = C::t('#tom_tcmall#tom_tcmall_focuspic')->fetch_all_field();
    if (!isset($tom_tcmall_focuspic_field['type_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_focuspic` ADD `type_id` int(11) DEFAULT '1';\n";
    }
    
    $tom_tcmall_cart_field = C::t('#tom_tcmall#tom_tcmall_cart')->fetch_all_field();
    if (!isset($tom_tcmall_cart_field['peisong_type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_cart` ADD `peisong_type` tinyint(4) DEFAULT '0';\n";
    }
    
    $tom_tcmall_cate_field = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_field();
    if (!isset($tom_tcmall_cate_field['sub_name'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_cate` ADD `sub_name` varchar(255) DEFAULT NULL;\n";
    }

    $tom_tcmall_order_field = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_field();
    if (!isset($tom_tcmall_order_field['coupon_lingqu_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_order` ADD `coupon_lingqu_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcmall_order_field['coupon_reduce_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_order` ADD `coupon_reduce_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcmall_order_field['score_num'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_order` ADD `score_num` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcmall_order_field['score_dikou_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_order` ADD `score_dikou_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcmall_order_field['huodao_pay_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_order` ADD `huodao_pay_status` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcmall_order_field['kuaidi_no'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_order` ADD `kuaidi_no` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcmall_order_field['kuaidi_type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_order` ADD `kuaidi_type` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcmall_order_field['tcshop_place_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_order` ADD `tcshop_place_id` int(11) DEFAULT '0';\n";
    }

    $tom_tcmall_goods_option_field = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_all_field();
    if (!isset($tom_tcmall_goods_option_field['score_num'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods_option` ADD `score_num` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcmall_goods_option_field['score_dikou_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods_option` ADD `score_dikou_price` decimal(10,2) DEFAULT '0.00';\n";
    }

    $tom_tcmall_goods_photo_field = C::t('#tom_tcmall#tom_tcmall_goods_photo')->fetch_all_field();
    if (!isset($tom_tcmall_goods_photo_field['type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods_photo` ADD `type` tinyint(4) DEFAULT '1';\n";
    }
    
    if (!empty($sql)) {
        runquery($sql);
    }
    
    $sql = <<<EOF
    CREATE TABLE IF NOT EXISTS `pre_tom_tcmall_refund` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `site_id` int(11) DEFAULT '1',
        `tcshop_id` int(11) DEFAULT '0',
        `order_id` int(11) DEFAULT '0',
        `pay_order_no` varchar(255) DEFAULT NULL,
        `order_goods_id` int(11) DEFAULT '0',
        `user_id` int(11) DEFAULT '0',
        `user_desc` text,
        `refund_no` varchar(255) DEFAULT NULL,
        `refund_price` decimal(10,2) DEFAULT '0.00',
        `refund_beizu` text,
        `refund_type` tinyint(4) unsigned DEFAULT '0',
        `refund_status` tinyint(4) DEFAULT '0',
        `wx_refund_status` tinyint(4) DEFAULT '0',
        `shop_shenhe_status` tinyint(4) DEFAULT '0',
        `refund_time` int(11) unsigned DEFAULT '0',
        `shop_shenhe_time` int(11) unsigned DEFAULT '0',
        `add_time` int(11) unsigned DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_tcmall_refund_photo` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `refund_id` int(11) DEFAULT '0',
        `picurl` varchar(255) DEFAULT NULL,
        `add_time` int(11) DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_tcmall_coupon` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `site_id` int(11) DEFAULT '1',
        `user_id` int(11) DEFAULT '0',
        `title` varchar(255) DEFAULT NULL,
        `goods_ids` text,
        `tcshop_id` int(11) DEFAULT '0',
        `coupon_type` int(11) DEFAULT '0',
        `total_num` int(11) DEFAULT '0',
        `lingqu_num` int(11) DEFAULT '0',
        `full_price` decimal(10,2) DEFAULT '0.00',
        `reduce_price` decimal(10,2) DEFAULT '0.00',
        `max_lingqu_num` int(11) DEFAULT '0',
        `start_time` int(11) unsigned DEFAULT '0',
        `end_time` int(11) unsigned DEFAULT '0',
        `content` text,
        `is_yikatong` int(11) DEFAULT '0',
        `is_hehuoren` int(11) DEFAULT '0',
        `open_score` int(11) DEFAULT '0',
        `pay_score` int(11) DEFAULT '0',
        `status` int(11) DEFAULT '0',
        `add_time` int(11) DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_tcmall_coupon_lingqu` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) DEFAULT '0',
        `coupon_id` int(11) DEFAULT '0',
        `tcshop_id` int(11) DEFAULT '0',
        `status` int(11) DEFAULT '0',
        `use_time` int(11) unsigned DEFAULT '0',
        `add_time` int(11) unsigned DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

EOF;

    runquery($sql);
    
    $sql = '';
    $tom_tcmall_goods_field = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_field();
    if (isset($tom_tcmall_goods_field['yongjin_bili']) && $tom_tcmall_goods_field['yongjin_bili']['Type'] == 'int(11)') {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` CHANGE `yongjin_bili` `yongjin_bili` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (isset($tom_tcmall_goods_field['chuji_fc_scale']) && $tom_tcmall_goods_field['chuji_fc_scale']['Type'] == 'int(11)') {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` CHANGE `chuji_fc_scale` `chuji_fc_scale` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (isset($tom_tcmall_goods_field['zhongji_fc_scale']) && $tom_tcmall_goods_field['zhongji_fc_scale']['Type'] == 'int(11)') {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` CHANGE `zhongji_fc_scale` `zhongji_fc_scale` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (isset($tom_tcmall_goods_field['gaoji_fc_scale']) && $tom_tcmall_goods_field['gaoji_fc_scale']['Type'] == 'int(11)') {
        $sql .= "ALTER TABLE `pre_tom_tcmall_goods` CHANGE `gaoji_fc_scale` `gaoji_fc_scale` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!empty($sql)) {
        runquery($sql);
    }
    
    echo 'OK';exit;
    
}else{
    exit('Access Denied');
}