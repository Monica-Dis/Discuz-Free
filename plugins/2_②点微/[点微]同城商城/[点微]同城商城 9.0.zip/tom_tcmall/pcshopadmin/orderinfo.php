<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_id = intval($_GET['order_id'])>0? intval($_GET['order_id']):0;

$orderInfo = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_id($order_id);
if(empty($orderInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);
if($__UserInfo['id'] != $tcshopInfo['user_id']){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=orderinfo&order_id={$order_id}";

$userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($orderInfo['user_id']);
$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);

$orderGoodsListTmp = C::t("#tom_tcmall#tom_tcmall_order_goods")->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 100);
$orderGoodsList = array();
if(!empty($orderGoodsListTmp)){
    foreach($orderGoodsListTmp as $k => $v){
        $orderGoodsList[$k] = $v;
        
        $goodsInfoTmp =  C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($v['goods_id']);
        $goodsInfoTmp['picurl'] = get_file_url($goodsInfoTmp['picurl']);
        
        $orderGoodsList[$k]['goodsInfo'] = $goodsInfoTmp;
    }
}

$site_name_tmp = $Lang['sites_one'];
if($orderInfo['site_id'] > 1){
    $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
    $site_name_tmp = $siteInfoTmp['name'];
}

if($orderInfo['coupon_lingqu_id'] > 0){
    $lingquInfo = C::t("#tom_tcmall#tom_tcmall_coupon_lingqu")->fetch_by_id($orderInfo['coupon_lingqu_id']);
    $couponInfo = C::t("#tom_tcmall#tom_tcmall_coupon")->fetch_by_id($lingquInfo['coupon_id']);
}

if($orderInfo['peisong_type'] == 1 && $orderInfo['tcshop_place_id'] > 0){
    $placeInfo = C::t("#tom_tcshop#tom_tcshop_place")->fetch_by_id($orderInfo['tcshop_place_id']);
}

$orderInfo['site_name']       = $site_name_tmp;
$orderInfo['dispatch_price']  = floatval($orderInfo['dispatch_price']);
$orderInfo['orderTime']       = dgmdate($orderInfo['order_time'], 'Y-m-d H:i:s',$tomSysOffset);
$orderInfo['hexiaoTime']      = dgmdate($orderInfo['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset);
$orderInfo['peisongTime']     = dgmdate($orderInfo['peisong_time'], 'Y-m-d H:i:s',$tomSysOffset);
$orderInfo['payTime']         = dgmdate($orderInfo['pay_time'], 'Y-m-d H:i:s',$tomSysOffset);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:pcshopadmin/orderinfo");