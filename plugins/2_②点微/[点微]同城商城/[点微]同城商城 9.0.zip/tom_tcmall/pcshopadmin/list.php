<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=list";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if(!empty($act) && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );

    $goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;
    
    $goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($goods_id);
    if($goodsInfo){
        if($__UserInfo['id'] != $goodsInfo['user_id']){
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['no_quanxian_error'],CHARSET,'utf-8'),
            );    
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
        );    
        echo json_encode($outArr); exit;
    }
    
    if($act == 'show'){

        $updateData = array();
        $updateData['status']     = 1;
        C::t('#tom_tcmall#tom_tcmall_goods')->update($goods_id, $updateData);
        $outArr = array(
            'code'=> 200,
        );    
        echo json_encode($outArr); exit;
    }else if($act == 'hide'){

        $updateData = array();
        $updateData['status']     = 0;
        C::t('#tom_tcmall#tom_tcmall_goods')->update($goods_id, $updateData);
        $outArr = array(
            'code'=> 200,
        );    
        echo json_encode($outArr); exit;
    }else if($act == 'clone'){

        $clone_goods_id = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
        $cloneGoodsInfo = C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($clone_goods_id);
        $clonePhotoListTmp = C::t('#tom_tcmall#tom_tcmall_goods_photo')->fetch_all_list(" AND goods_id = {$clone_goods_id} "," ORDER BY psort ASC,id ASC ",0,100);

        $insertData = array();
        $insertData = $cloneGoodsInfo;
        unset($insertData['id']);

        $insertData['title'] = $Lang['list_clone_title'].$cloneGoodsInfo['title'];
        $insertData['add_time'] = TIMESTAMP;
        $goods_id = C::t('#tom_tcmall#tom_tcmall_goods')->insert($insertData, true);
        if($goods_id > 0){

            if(!empty($clonePhotoListTmp)){
                foreach($clonePhotoListTmp as $key => $value){
                    $insertData = array();
                    $insertData = $value;
                    unset($insertData['id']);
                    unset($insertData['picurlTmp']);

                    $insertData['goods_id']     = $goods_id;
                    $insertData['add_time']     = TIMESTAMP;
                    C::t('#tom_tcmall#tom_tcmall_goods_photo')->insert($insertData);
                }
            }

            if($cloneGoodsInfo['hasoption'] == 1){

                $specListTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec')->fetch_all_list(" AND goods_id = {$clone_goods_id} ", 'ORDER BY ssort ASC ,id ASC', 0, 1000);
                $itemList = array();
                if(is_array($specListTmp) && !empty($specListTmp)){
                    foreach($specListTmp as $key => $value){

                        $insertData = array();
                        $insertData = $value;
                        unset($insertData['id']);
                        $insertData['goods_id'] = $goods_id;
                        $spec_id = C::t('#tom_tcmall#tom_tcmall_goods_spec')->insert($insertData, true);

                        $itemListTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec_item')->fetch_all_list(" AND spec_id = {$value['id']} ", 'ORDER BY id ASC', 0, 1000);
                        if(is_array($itemListTmp) && !empty($itemListTmp)){
                            foreach($itemListTmp as $k => $v){

                                $insertData = array();  
                                $insertData = $v;
                                unset($insertData['id']);
                                $insertData['spec_id']  = $spec_id;
                                $spec_item_id = C::t('#tom_tcmall#tom_tcmall_goods_spec_item')->insert($insertData, true);

                                $itemList[$v['id']] = $v;
                                $itemList[$v['id']]['spec_item_id'] = $spec_item_id;
                            }
                        }

                    }
                }

                $optionListTmp = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_all_list(" AND goods_id={$clone_goods_id} "," ORDER BY id ASC ",0,1000);

                $stock_num = 0;
                $beizu = '';
                foreach($optionListTmp as $key => $value){

                    $idsArrTmp = explode('-', $value['spec_item_ids']);
                    $specItemIdsArr = array();
                    foreach($idsArrTmp as $k => $v){
                        $specItemIdsArr[] = $itemList[$v]['spec_item_id'];
                    }
                    $specItemIdsStr = implode('-', $specItemIdsArr);

                    $insertData = array();
                    $insertData = $value;
                    unset($insertData['id']);
                    $insertData['goods_id']         = $goods_id;
                    $insertData['spec_item_ids']    = $specItemIdsStr;
                    C::t("#tom_tcmall#tom_tcmall_goods_option")->insert($insertData);
                    $option_id = C::t("#tom_tcmall#tom_tcmall_goods_option")->insert_id();

                    $stock_num = $stock_num + $value['stock'];
                    $beizu .= 'ID:&nbsp;<span>'.$option_id.'</span> '.$Lang['option_name'].'<span>'.$value['name'].'</span>'
                            .$Lang['option_stock'].'<span>'.$value['stock'].'</span> '
                            .$Lang['option_market_price'].'<span>'.$value['market_price'].'</span> '
                            .$Lang['option_buy_price'].'<span>'.$value['buy_price'].'</span> ';
                    if($open_vip == 1){
                        $beizu .= $Lang['option_vip_price'].'<span>'.$value['vip_price'].'</span>';
                    }
                    if($open_score_dikou == 1){
                        $beizu .= $Lang['option_score_num'].'<span>'.$value['score_num'].'</span>'.$Lang['option_score_dikou_price'].'<span>'.$value['score_dikou_price'].'</span>';
                    }
                    $beizu .= '<br/>';

                }

                $insertData = array();
                $insertData['is_admin']     = 1;
                $insertData['is_option']    = 1;
                $insertData['goods_id']     = $goods_id;
                $insertData['beizu']        = $beizu;
                $insertData['change_num']   = $stock_num;
                $insertData['change_time']  = TIMESTAMP;
                C::t("#tom_tcmall#tom_tcmall_goods_stock_log")->insert($insertData);
            }else{
                $insertData = array();
                $insertData['is_admin']     = 1;
                $insertData['goods_id']     = $goods_id;
                $insertData['change_num']   = $cloneGoodsInfo['stock'];
                $insertData['change_time']  = TIMESTAMP;
                C::t('#tom_tcmall#tom_tcmall_goods_stock_log')->insert($insertData);
            }

            $outArr = array(
                'code'=> 200,
            );
            echo json_encode($outArr); exit;

        }else{
            $outArr = array(
                'code'=> 404,
            );
            echo json_encode($outArr); exit;
        }
    }
}

$title          = !empty($_GET['title'])? addslashes($_GET['title']):'';
$site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$tcshop_id      = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
$cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
$cate_child_id  = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
$status         = isset($_GET['status'])? intval($_GET['status']):0;
$shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$goods_num_low  = isset($_GET['goods_num_low'])? intval($_GET['goods_num_low']):0;
$goods_sell_out = isset($_GET['goods_sell_out'])? intval($_GET['goods_sell_out']):0;
$isrecommand    = isset($_GET['isrecommand'])? intval($_GET['isrecommand']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$tcshopListTmp = C::t("#tom_tcshop#tom_tcshop")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND (pay_status = 0 OR pay_status = 2) ", "ORDER BY id DESC", 0, 1000);
$tcshopList = array();
if(!empty($tcshopListTmp)){
    foreach($tcshopListTmp as $key => $value){
        $tcshopList[$value['id']] = $value;
    }
}

$where = "AND user_id = {$__UserInfo['id']}";
if(!empty($site_id)){
    $where.= " AND site_id={$site_id} ";
}
if(!empty($tcshop_id)){
    $where.= " AND tcshop_id={$tcshop_id} ";
}
if($status == 1){
    $where.= " AND status=1 ";
}else if($status == 2){
    $where.= " AND status=0 ";
}
if(!empty($cate_id)){
    $where.= " AND cate_id={$cate_id} ";
}
if(!empty($cate_child_id)){
    $where.= " AND cate_child_id={$cate_child_id} ";
}
if($shenhe_status > 0){
    $where.= " AND shenhe_status={$shenhe_status} ";
}
if($goods_num_low == 1){
    $where.= " AND stock < 10 ";
}
if($goods_sell_out == 1){
    $where.= " AND stock = 0 ";
}
if($isrecommand == 1){
    $where.= " AND isrecommand = 1 ";
}

$sort = " ORDER BY id DESC ";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count($where,$title);
$goodsListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list($where,$sort,$start,$pagesize,$title);
$goodsList = array();
if(!empty($goodsListTmp)){
    foreach ($goodsListTmp as $key => $value) {
        $goodsList[$key] = $value;
        
        $goodsList[$key]['picurl'] = get_file_url($value['picurl']);
        
        $siteInfoTmp        = $sitesList[$value['site_id']];
        $cateInfoTmp        = $cateList[$value['cate_id']];
        $cateChildInfoTmp   = $cateList[$value['cate_id']]['cateChildList'][$value['cate_child_id']];
        $tcshopInfoTmp      = $tcshopList[$value['tcshop_id']];
        
        $goodsList[$key]['siteInfo']        = $siteInfoTmp;
        $goodsList[$key]['cateInfo']        = $cateInfoTmp;
        $goodsList[$key]['cateChildInfo']   = $cateChildInfoTmp;
        $goodsList[$key]['tcshopInfo']      = $tcshopInfoTmp;
        $goodsList[$key]['add_time']        = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&title={$title}&site_id={$site_id}&tcshop_id={$tcshop_id}&cate_id={$cate_id}&cate_child_id={$cate_child_id}"
           ."&status={$status}&shenhe_status={$shenhe_status}&goods_num_low={$goods_num_low}&goods_sell_out={$goods_sell_out}&isrecommand={$isrecommand}";

$countGoodsNumLow = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND stock < 10 AND status=1 AND shenhe_status = 2 ");
$countGoodsSellOut = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND stock = 0 AND status=1 AND shenhe_status = 2");
$countShenheStatus2 = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND shenhe_status=2");
$countShenheStatus3 = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND shenhe_status=3");
$countIsrecommand = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND isrecommand=1");

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:pcshopadmin/list");