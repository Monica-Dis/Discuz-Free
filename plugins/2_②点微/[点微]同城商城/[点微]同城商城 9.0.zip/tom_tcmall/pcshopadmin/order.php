<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=order";

$order_no       = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
$pay_order_no   = !empty($_GET['pay_order_no'])? addslashes($_GET['pay_order_no']):'';
$order_tel      = !empty($_GET['order_tel'])? trim(addslashes($_GET['order_tel'])):'';
$order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;
$tcshop_id      = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
$start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
$end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$kuaidiList = array();
if($__ShowKuaidi == 1){
    include DISCUZ_ROOT.'./source/plugin/tom_kuaidi/kuaidi.func.php';
    
    $kuaidiListTmp = C::t("#tom_kuaidi#tom_kuaidi")->fetch_all_list(" ", 'ORDER BY sort ASC, id DESC');
    if(is_array($kuaidiListTmp) && !empty($kuaidiListTmp)){
        foreach($kuaidiListTmp as $key => $value){
            $kuaidiList[$key] = $value;
        }
    }
}

$where = "";

if(!empty($tcshop_id)){
    $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
    if($tcshopInfo['user_id']  != $__UserInfo['id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
    $where.=" AND tcshop_id={$tcshop_id} ";
}else{
    $tcshopIdsListTmp = C::t("#tom_tcshop#tom_tcshop")->fetch_all_field_list(" AND user_id = {$__UserInfo['id']} ", 'id');
    $tcshopIdsList = array();
    if(!empty($tcshopIdsListTmp)){
        foreach($tcshopIdsListTmp as $key => $value){
            $tcshopIdsList[] = $value['id'];
        }
    }
    if(!empty($tcshopIdsList)){
        $tcshopIdsStr = implode(',', $tcshopIdsList);
        $where .= " AND tcshop_id IN({$tcshopIdsStr}) ";
    }else{
        $where .= " AND tcshop_id = 999999999 ";
    }
}

if(!empty($order_no)){
    $where.=" AND order_no='{$order_no}' ";
}
if(!empty($pay_order_no)){
    $where.=" AND pay_order_no='{$pay_order_no}' ";
}
if(!empty($order_status)){
    $where.=" AND order_status={$order_status} ";
}
if(!empty($order_tel)){
    $where.=" AND address_tel={$order_tel} ";
}
if(!empty($start_time)){
    $startTime = strtotime($start_time);
    $where.=" AND order_time >=  {$startTime} ";
}
if(!empty($end_time)){
    $endTime = strtotime($end_time);
    $where.=" AND order_time < {$endTime} ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count($where,$order_tel);
$orderListTmp = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_list($where,"ORDER BY order_time DESC",$start,$pagesize,$order_tel);
$orderList = array();
if(!empty($orderListTmp)){
    foreach($orderListTmp as $key => $value){
        $orderList[$key] = $value;
        
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $hexiaoUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        
        $refundStatus = 0;
        $orderGoodsListTmpTmp = C::t("#tom_tcmall#tom_tcmall_order_goods")->fetch_all_list(" AND order_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);
        $orderGoodsListTmp = array();
        if(!empty($orderGoodsListTmpTmp)){
            foreach($orderGoodsListTmpTmp as $k => $v){
                $orderGoodsListTmp[$k] = $v;
                
                $goodsInfoTmp =  C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($v['goods_id']);
                $goodsInfoTmp['picurl'] = get_file_url($goodsInfoTmp['picurl']);
                
                $refundInfoTmp = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_all_list(" AND order_id = {$value['id']} AND order_goods_id = {$v['id']} AND refund_status IN(1,2) ", 'ORDER BY id DESC', 0, 1);
                if(is_array($refundInfoTmp) && !empty($refundInfoTmp[0])){
                    if($refundInfoTmp[0]['refund_status'] == 1){
                        $refundStatus = 1;
                    }
                }
                
                $orderGoodsListTmp[$k]['goodsInfo'] = $goodsInfoTmp;
            }
        }
        
        $site_name_tmp = $Lang['sites_one'];
        if($value['site_id'] > 1){
            $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
            $site_name_tmp = $siteInfoTmp['name'];
        }
        
        $showPeisongBoxTmp = 1;
        if($value['peisong_type'] == 3){
            if($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList) && empty($value['peisong_name']) && empty($value['peisong_info'])){
                $showPeisongBoxTmp = 2;
            }
            if($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList) && !empty($value['kuaidi_no']) && !empty($value['kuaidi_type'])){
                $showPeisongBoxTmp = 2;
            }

        }
        $showFahuoBox = 0;
        if($value['order_status'] == 2 || $value['order_status'] == 3 || $value['order_status'] == 8){
            $showFahuoBox = 1;
        }

        $showQianshouBtn = 0;
        if($value['order_status'] == 3 && $value['peisong_time'] > 0){
            if(TIMESTAMP > ($value['peisong_time'] + 86400 * $tcmallConfig['goods_autoreceive'])){
                $showQianshouBtn = 1;
            }
        }
        
        $orderList[$key]['userInfo']        = $userInfoTmp;
        $orderList[$key]['hexiaoUserInfo']  = $hexiaoUserInfoTmp;
        $orderList[$key]['orderGoodsList']  = $orderGoodsListTmp;
        $orderList[$key]['rowspan']         = count($orderGoodsListTmp);
        $orderList[$key]['site_name']       = $site_name_tmp;
        $orderList[$key]['showPeisongBox']  = $showPeisongBoxTmp;
        $orderList[$key]['showFahuoBox']    = $showFahuoBox;
        $orderList[$key]['showQianshouBtn'] = $showQianshouBtn;
        $orderList[$key]['refundStatus']    = $refundStatus;
        $orderList[$key]['dispatch_price']  = floatval($value['dispatch_price']);
        $orderList[$key]['order_time']      = dgmdate($value['order_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $orderList[$key]['hexiaoTime']      = dgmdate($value['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $orderList[$key]['payTime']         = dgmdate($value['pay_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&order_no={$order_no}&pay_order_no={$pay_order_no}&order_tel={$order_tel}&order_status={$order_status}&tcshop_id={$tcshop_id}&start_time={$start_time}&end_time={$end_time}";

if($tcshop_id > 0){
    $countOrderStatus1 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id={$tcshop_id} AND order_status=1 ");
    $countOrderStatus2 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id={$tcshop_id} AND order_status=2 ");
    $countOrderStatus4 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id={$tcshop_id} AND order_status=4 ");
    $countOrderStatus5 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id={$tcshop_id} AND order_status=5 ");
    $countOrderStatus6 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id={$tcshop_id} AND order_status=6 ");
    $countOrderStatus7 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id={$tcshop_id} AND order_status=7 ");
    
    $countOrderStatus1 = intval($countOrderStatus1);
    $countOrderStatus2 = intval($countOrderStatus2);
    $countOrderStatus4 = intval($countOrderStatus4);
    $countOrderStatus5 = intval($countOrderStatus5);
    $countOrderStatus6 = intval($countOrderStatus6);
    $countOrderStatus7 = intval($countOrderStatus7);
}

$fahuoUrl       = 'plugin.php?id=tom_tcmall&site='.$site_id.'&mod=myorderinfo&act=fahuo&formhash='.$formhash;
$qianshouUrl    = 'plugin.php?id=tom_tcmall&site='.$site_id.'&mod=myorderinfo&act=qianshou&formhash='.$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:pcshopadmin/order");