<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=refund';
$modListUrl = $adminListUrl.'&tmod=refund';
$modFromUrl = $adminFromUrl.'&tmod=refund';

$get_list_url_value = get_list_url("tom_tcmall_admin_refund_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'info'){
    
    $csstr = <<<EOF
<style type="text/css">
.dislay-box { }
.dislay-box .box {	float:left; width:33%;;}
</style>
EOF;
    echo $csstr;
    
    $info = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_by_id($_GET['id']);
    
    $orderInfo = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_id($info['order_id']);
    $infoGoodsList = C::t("#tom_tcmall#tom_tcmall_order_goods")->fetch_all_list(" AND order_id = {$info['order_id']} ", 'ORDER BY id DESC', 0, 100);
    $infoGoodsInfo = C::t("#tom_tcmall#tom_tcmall_order_goods")->fetch_by_id($info['order_goods_id']);
    
    $goodsRefundPrice = $infoGoodsInfo['real_price'];
    
    $refundPhotoListTmp = C::t('#tom_tcmall#tom_tcmall_refund_photo')->fetch_all_list(" AND refund_id = {$info['id']} ", 'ORDER BY id DESC', 0, 3);
    $refundPhotoList = array();
    if(is_array($refundPhotoListTmp) && !empty($refundPhotoListTmp)){
        foreach($refundPhotoListTmp as $key => $value){
            $refundPhotoList[$key] = $value;
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_tcmall/') === false){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurlTmp = $_G['siteurl'].$value['picurl'];
                }
            }else{
                $picurlTmp = $value['picurl'];
            }
            $refundPhotoList[$key]['picurl'] = $picurlTmp;
        }
    }

    $fenghao = $Lang['fenghao'];
    showtableheader();
    echo '<tr><th colspan="15" class="partition"><font color="#238206">' . $Lang['refund_info_goods_title'] . '</font></th></tr>';
    echo '<tr>';
    echo '<th><b>'.$Lang['order_goods_name'].'</b></th>';
    echo '<th><b>'.$Lang['order_goods_num'].'</b></th>';
    echo '<th><b>'.$Lang['order_is_vip'].'</b></th>';
    echo '<th><b>'.$Lang['order_goods_price'].'</b></th>';
    echo '<th><b>'.$Lang['order_dispatch_price'].'</b></th>';
    echo '<th><b>'.$Lang['order_refund_status'].'</b></th>';
    echo '</tr>';

    foreach($infoGoodsList as $key => $value){
        $goodsInfoTmp = C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($value['goods_id']);

        $option_name = '';
        if(!empty($value['option_name'])){
            $option_name = '<font color="#009900">['.$value['option_name'].']</font>';
        }
        
        echo '<tr>';
        echo '<th>'.$goodsInfoTmp['title'].$option_name.'</th>';
        echo '<th>'.$value['goods_num'].'</th>';
        if($value['is_vip'] == 1){
            echo '<th>'.$Lang['order_is_vip_1'].'</th>';
        }else{
            echo '<th>'.$Lang['order_is_vip_0'].'</th>';
        }
        echo '<th>'.$value['real_price'].'</th>';
        echo '<th>'.$value['dispatch_price'].'</th>';
        if($value['order_status'] == 7){
            echo '<th><font color="#f00">'.$Lang['order_refund_status_1'].'</font></th>';
        }else{
            echo '<th> -- </th>';
        }
        echo '</tr>';
    }
    
    echo '<tr><th colspan="15" class="partition"><font color="#fd0d0d">' . $Lang['refund_info_refund_goods_title'] . '</font></th></tr>';
    echo '<tr>';
    echo '<th><b>'.$Lang['order_goods_name'].'</b></th>';
    echo '<th><b>'.$Lang['order_goods_num'].'</b></th>';
    echo '<th><b>'.$Lang['order_is_vip'].'</b></th>';
    echo '<th><b>'.$Lang['order_goods_price'].'</b></th>';
    echo '<th><b>'.$Lang['order_dispatch_price'].'</b></th>';
    echo '</tr>';

    if($infoGoodsInfo){
        $goodsInfoTmp = C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($value['goods_id']);
        
        $option_name = '';
        if(!empty($infoGoodsInfo['option_name'])){
            $option_name = '<font color="#009900">['.$infoGoodsInfo['option_name'].']</font>';
        }
        
        echo '<tr>';
        echo '<th>'.$goodsInfoTmp['title'].$option_name.'</th>';
        echo '<th>'.$infoGoodsInfo['goods_num'].'</th>';
        if($infoGoodsInfo['is_vip'] == 1){
            echo '<th>'.$Lang['order_is_vip_1'].'</th>';
        }else{
            echo '<th>'.$Lang['order_is_vip_0'].'</th>';
        }
        echo '<th>'.$infoGoodsInfo['real_price'].'</th>';
        echo '<th>'.$infoGoodsInfo['dispatch_price'].'</th>';
        echo '</tr>';
    }

    echo '<tr><th colspan="15" class="partition"><font color="#fd0d0d">' . $Lang['refund_refund_sq_title'] . '</font></th></tr>';
    echo '<tr><td class="dislay-box" colspan="15">';
    echo '<div class="box"><b>'.$Lang['order_order_no'].$fenghao.'</b>'.$orderInfo['order_no'].'</div>';
    echo '<div class="box"><b>'.$Lang['refund_goods_refund_price'].$fenghao.'</b><font color="#f00">'.$goodsRefundPrice.'</font></div>';
    echo '<div class="box"><b>'.$Lang['refund_yunfei_refund_price'].$fenghao.'</b><font color="#f00">'.$infoGoodsInfo['dispatch_price'].'</font></div>';
    echo '</td></tr>';
    
    echo '<tr><td class="dislay-box" colspan="15">';
    echo '<div class="box"><b>'.$Lang['order_order_status'].$fenghao.'</b><b><font color="#0894fb">' . $orderStatusArray[$orderInfo['order_status']] . '</font></b></div>';
    echo '<div class="box"><b>'.$Lang['order_order_time'].$fenghao.'</b>'.dgmdate($orderInfo['order_time'], 'm-d H:i:s',$tomSysOffset).'</div>';
    if($orderInfo['pay_time'] > 0){
        echo '<div class="box"><b>'.$Lang['order_pay_time'].$fenghao.'</b>'.dgmdate($orderInfo['pay_time'], 'm-d H:i:s',$tomSysOffset).'</div>';
    }else{
        echo '<div class="box"><b>'.$Lang['order_pay_time'].$fenghao.'</b>-</div>';
    }
    echo '</td></tr>';
    
    echo '<tr><td class="dislay-box" colspan="15">';
    echo '<div class="box"><b>'.$Lang['refund_add_time'].$fenghao.'</b>'.dgmdate($info['add_time'], 'Y-m-d H:i:s',$tomSysOffset).'</div>';
    echo '<div class="box"><b>'.$Lang['refund_user_desc'].$fenghao.'</b>'.$info['user_desc'].'</div>';
    if(count($refundPhotoList) > 0){
        echo '<div class="box" style="dis"><b>'.$Lang['refund_user_photo'].$fenghao.'</b>';
        foreach($refundPhotoList as $key => $value){
            echo '&nbsp;&nbsp;<a href="'.$value['picurl'].'" target="_blank"><img width="40" height="40" style="vertical-align: top;" src="'.$value['picurl'].'"></a>&nbsp;';
        }
        echo '</div>';
    }
    echo '</td></tr>';
    echo '<tr><th colspan="15" class="partition"><font color="#fd0d0d">' . $Lang['refund_refund_cl_title'] . '</font></th></tr>';
    if(!empty($info['refund_no'])){
        echo '<tr><td class="dislay-box" colspan="15">';
        echo '<div class="box"><b>'.$Lang['refund_refund_no'].$fenghao.'</b>'.$info['refund_no'].'</div>';
        if($info['refund_type'] == 1){
            echo '<div class="box"><b>'.$Lang['refund_refund_type'].$fenghao.'</b><font color="#f00">'.$Lang['refund_refund_type_1'].'</font></div>';
            
            if($info['wx_refund_status'] == 1){
                echo '<div class="box"><b>'.$Lang['refund_refund_status'].$fenghao.'</b><font color="#f00">'.$Lang['refund_wx_refund_status_1'].'</font></div>';
            }else if($info['wx_refund_status'] == 2){
                echo '<div class="box"><b>'.$Lang['refund_refund_status'].$fenghao.'</b><font color="#009900">'.$Lang['refund_wx_refund_status_2'].'</font></div>';
            }
        }else if($info['refund_type'] == 2){
            echo '<div class="box"><b>'.$Lang['refund_refund_type'].$fenghao.'</b><font color="#f00">'.$Lang['refund_refund_type_2'].'</font></div>';
        }
        echo '</td></tr>';
    }
    
    if($info['refund_status'] == 1){
        echo '<tr><td class="dislay-box" colspan="15"><b>'.$Lang['refund_refund_status'].$fenghao.'</b><font color="#f00">'.$Lang['refund_refund_status_1'].'</font>';
        if($info['shop_shenhe_status'] == 0){
            echo '<b><font color="#0894fb">(' . $Lang['refund_refund_shop_shenhe_ok_0'] . ')</font></b>';
        }else if($info['shop_shenhe_status'] == 1){
            echo '<b><font color="#0894fb">(' . $Lang['refund_refund_shop_shenhe_ok_1'] . ')</font></b>';
        }
        echo '</td></tr>';
    }
    if($info['refund_status'] == 2){
        echo '<tr><td class="dislay-box" colspan="15">';
        echo '<div class="box"><b>'.$Lang['refund_refund_status'].$fenghao.'</b><font color="#f00">'.$Lang['refund_refund_status_2'].'</font></div>';
        echo '<div class="box"><b>'.$Lang['refund_refund_price'].$fenghao.'</b><font color="#f00">'.$info['refund_price'].'</font></div>';
        echo '<div class="box"><b>'.$Lang['refund_refund_time'].$fenghao.'</b>'.dgmdate($info['refund_time'], 'm-d H:i:s',$tomSysOffset).'</div>';
        echo '</td></tr>';
        echo '<tr><td class="dislay-box" colspan="15"><b>'.$Lang['refund_refund_beizu'].$fenghao.'</b>'.$info['refund_beizu'].'</td></tr>';
    }
    if($info['refund_status'] == 3){
        echo '<tr><td class="dislay-box" colspan="15">';
        echo '<div class="box"><b>'.$Lang['refund_refund_status'].$fenghao.'</b><font color="#f00">'.$Lang['refund_refund_status_3'].'</font></div>';
        echo '<div class="box"><b>'.$Lang['refund_refund_beizu'].$fenghao.'</b>'.$info['refund_beizu'].'</div>';
        echo '</td></tr>';
    }
    if($info['refund_status'] == 4){
        echo '<tr><td class="dislay-box" colspan="15">';
        echo '<div class="box"><b>'.$Lang['refund_refund_status'].$fenghao.'</b><font color="#f00">'.$Lang['refund_refund_status_4'].'</font></div>';
        echo '<div class="box"><b>'.$Lang['refund_refund_beizu'].$fenghao.'</b>'.$info['refund_beizu'].'</div>';
        echo '</td></tr>';
    }

    echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_user_title'] . '</th></tr>';
    echo '<tr><td class="dislay-box" colspan="15">';
    echo '<div class="box"><b>'.$Lang['order_xm'].$fenghao.'</b>'.$orderInfo['address_xm'].'</div>';
    echo '<div class="box"><b>'.$Lang['order_tel'].$fenghao.'</b>'.$orderInfo['address_tel'].'</div>';
    echo '<div class="box"><b>'.$Lang['order_address'].$fenghao.'</b>'.$orderInfo['address_str'].'</div>';
    echo '</td></tr>';
    echo '<tr><td class="dislay-box" colspan="15"><b>'.$Lang['order_order_beizu'].$fenghao.'</b>'.$orderInfo['order_beizu'].'</td></tr>';
    
    if($orderInfo['peisong_type'] == 1){
        echo '<tr><td class="dislay-box" colspan="15"><b>'.$Lang['goods_peisong_type'].$fenghao.'</b>'.$Lang['goods_peisong_type_1'].'</td></tr>';
    }else if($orderInfo['peisong_type'] == 2){
        echo '<tr><td class="dislay-box" colspan="15">';
        echo '<div class="box"><b>'.$Lang['goods_peisong_type'].$fenghao.'</b>'.$Lang['goods_peisong_type_2'].'</div>';
        echo '<div class="box"><b>'.$Lang['order_peisong_name2'].$fenghao.'</b>'.$orderInfo['peisong_name'].'</div>';
        echo '<div class="box"><b>'.$Lang['order_peisong_info2'].$fenghao.'</b>'.$orderInfo['peisong_info'].'</div>';
        echo '</td></tr>';
    }else if($orderInfo['peisong_type'] == 3){
        echo '<tr><td class="dislay-box" colspan="15">';
        echo '<div class="box"><b>'.$Lang['goods_peisong_type'].$fenghao.'</b>'.$Lang['goods_peisong_type_3'].'</div>';
        echo '<div class="box"><b>'.$Lang['order_peisong_name3'].$fenghao.'</b>'.$orderInfo['peisong_name'].'</div>';
        echo '<div class="box"><b>'.$Lang['order_peisong_info3'].$fenghao.'</b>'.$orderInfo['peisong_info'].'</div>';
        echo '</td></tr>';
    }
    
    if($info['refund_status'] == 1){
        $num1 = mt_rand(1, 20);
        $num2 = mt_rand(1, 20);

        showtablefooter(); /*dism��taobao��com*/
        showformheader($modFromUrl.'&act=refund&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['refund_handle_refund'] . '</th></tr>';
        showtablefooter(); /*dism��taobao��com*/
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['refund_refund_price'],'name'=>'refund_price','value'=>$goodsRefundPrice,'msg'=>$Lang['refund_refund_price_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['refund_refund_beizu'],'name'=>'refund_beizu','value'=>'','msg'=>''),"textarea");
        echo '<tr><td><b>'.$Lang['refund_jisuan'].$fenghao.'</b>'.$num1.'+'.$num2.'=<input type="text" name="number" value=""></td><td><input type="hidden" name="num1" value="'.$num1.'"><input type="hidden" name="num2" value="'.$num2.'"></td></tr>';
        tomshowsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refund'){
    
    $refund_id = intval($_GET['id'])>0? intval($_GET['id']):0;
    $refund_price = floatval($_GET['refund_price'])>0? floatval($_GET['refund_price']):0.00;
    $refund_beizu = addslashes($_GET['refund_beizu'])? addslashes($_GET['refund_beizu']):'';
    $num1 = intval($_GET['num1'])>0? intval($_GET['num1']):0;
    $num2 = intval($_GET['num2'])>0? intval($_GET['num2']):0;
    $number = intval($_GET['number'])>0? intval($_GET['number']):0;
    
    if($number != ($num1 + $num2)){
        cpmsg($Lang['refund_jisuan_err'], $modListUrl.'&act=info&id='.$refund_id.'&formhash='.FORMHASH, 'error');
        exit;
    }
    
    $refundInfo = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_by_id($refund_id);
    $orderInfo = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_id($refundInfo['order_id']);
    $mallPayOrderInfo = C::t('#tom_tcmall#tom_tcmall_order_pay')->fetch_by_pay_order_no($orderInfo['pay_order_no']);
    $refundGoodsInfo = C::t("#tom_tcmall#tom_tcmall_order_goods")->fetch_by_id($refundInfo['order_goods_id']);

    $maxRefundPrice = $refundGoodsInfo['real_price'] + $refundGoodsInfo['dispatch_price'] + 0.01;
    if($refund_price >= $maxRefundPrice){
        cpmsg($Lang['refund_chaoguo_pay_price_err'], $modListUrl.'&act=info&id='.$refund_id.'&formhash='.FORMHASH, 'succeed');
        exit;
    }
    
    $wxpay_appid        = trim($tongchengConfig['wxpay_appid']);
    $wxpay_mchid        = trim($tongchengConfig['wxpay_mchid']);
    $wxpay_key          = trim($tongchengConfig['wxpay_key']);
    $wxpay_appsecret    = trim($tongchengConfig['wxpay_appsecret']);

    define("TOM_WXPAY_APPID", $wxpay_appid);
    define("TOM_WXPAY_MCHID", $wxpay_mchid);
    define("TOM_WXPAY_KEY", $wxpay_key);
    define("TOM_WXPAY_APPSECRET", $wxpay_appsecret);
    define("TOM_WXPAY_SSLCERT_PATH", DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_cert.pem');
    define("TOM_WXPAY_SSLKEY_PATH", DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_key.pem');
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/wxpay/lib/WxPay.Api.php';
    
    $template_sms = $template_url = '';
    $payOrderInfo = C::t('#tom_pay#tom_pay_order')->fetch_by_order_no($refundInfo['pay_order_no']);
    if($payOrderInfo['payment'] == 'wxpay_jsapi' || $payOrderInfo['payment'] == 'wxpay_h5'){
        if($orderInfo && !empty($orderInfo['pay_order_no']) && ($refundGoodsInfo['order_status'] = 2 || $refundGoodsInfo['order_status'] = 3) && !empty($refund_price) && $refundInfo['refund_status'] == 1){
            $pay_price = $mallPayOrderInfo['pay_price']*100;
            $pay_refund_price = $refund_price*100;
            $refund_no = 'T'.WxPayConfig::MCHID.date("YmdHis");
            
            $input = new WxPayRefund();
            $input->SetOut_trade_no($orderInfo['pay_order_no']);
            $input->SetTotal_fee($pay_price);                       
            $input->SetRefund_fee($pay_refund_price);                      
            $input->SetOut_refund_no($refund_no);
            $input->SetOp_user_id(WxPayConfig::MCHID);
            $return = WxPayApi::refund($input);
            if(is_array($return) && $return['result_code'] == 'SUCCESS'){
                $template_sms = $Lang['refund_refund_price_succ_template_1'];
                $template_url = $_G['siteurl']."plugin.php?id=tom_tcmall&site={$refundInfo['site_id']}&mod=refundinfo&refund_id={$refund_id}&from=templatesms";
                
                $updateData = array();
                $updateData['refund_no']        = $refund_no;
                $updateData['refund_price']     = $refund_price;
                $updateData['refund_beizu']     = $refund_beizu;
                $updateData['refund_status']    = 2;
                $updateData['refund_type']      = 1;
                $updateData['wx_refund_status'] = 1;
                $updateData['refund_time']      = TIMESTAMP;
                if(C::t('#tom_tcmall#tom_tcmall_refund')->update($refundInfo['id'], $updateData)){

                    $updateData = array();
                    $updateData['order_status'] = 7;
                    if(C::t('#tom_tcmall#tom_tcmall_order_goods')->update($refundGoodsInfo['id'], $updateData)){

                        DB::query("UPDATE ".DB::table('tom_tcmall_goods')." SET stock=stock+{$refundGoodsInfo['goods_num']}, sales=sales-{$refundGoodsInfo['goods_num']} WHERE id={$refundGoodsInfo['goods_id']}", 'UNBUFFERED');
                        if($refundGoodsInfo['option_id'] > 0){
                            DB::query("UPDATE ".DB::table('tom_tcmall_goods_option')." SET stock=stock+{$refundGoodsInfo['goods_num']} WHERE id={$refundGoodsInfo['option_id']}", 'UNBUFFERED');
                        }
                        
                        if($refundGoodsInfo['score_num'] > 0){
                            
                            $orderUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($refundGoodsInfo['user_id']);
                            
                            $updateData = array();
                            $updateData['score'] = $orderUserInfo['score'] + $refundGoodsInfo['score_num'];
                            C::t('#tom_tongcheng#tom_tongcheng_user')->update($orderUserInfo['id'],$updateData);

                            $insertData = array();
                            $insertData['user_id']          = $refundGoodsInfo['user_id'];
                            $insertData['score_value']      = $refundGoodsInfo['score_num'];
                            $insertData['old_value']        = $orderUserInfo['score'];
                            $insertData['log_type']         = 36;
                            $insertData['log_time']         = TIMESTAMP;
                            C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
                        }
                    }

                    $orderGoodsCount = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_count(" AND order_id = {$orderInfo['id']} AND order_status IN(2,3) ");
                    if(intval($orderGoodsCount) == 0){
                        $updateData = array();
                        $updateData['order_status'] = 7;
                        C::t('#tom_tcmall#tom_tcmall_order')->update($orderInfo['id'], $updateData);
                    }
                }
            }else{
                $err_code_des = diconv($return['err_code_des'], 'utf-8', CHARSET);
                cpmsg($err_code_des, $modListUrl, 'error');
            }
        }
    }else{
        
        if($orderInfo && !empty($orderInfo['pay_order_no']) && !empty($refund_price) && ($refundGoodsInfo['order_status'] = 2 || $refundGoodsInfo['order_status'] = 3) && $refundInfo['refund_status'] == 1){
            $orderUserInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
            $insertData = array();
            $insertData['user_id']          = $orderInfo['user_id'];
            $insertData['type_id']          = 2;
            $insertData['change_money']     = $refund_price;
            $insertData['old_money']        = $orderUserInfo['money'];
            $insertData['tag']              = lang('plugin/tom_tcmall', 'refund_money_log_tag');
            $insertData['beizu']            = lang('plugin/tom_tcmall', 'beizu_order_no') . $orderInfo['order_no'];
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);

            DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$refund_price} WHERE id='{$orderUserInfo['id']}'", 'UNBUFFERED');

            $updateData = array();
            $updateData['refund_price']     = $refund_price;
            $updateData['refund_beizu']     = $refund_beizu;
            $updateData['refund_status']    = 2;
            $updateData['refund_type']      = 2;
            $updateData['refund_time']      = TIMESTAMP;
            if(C::t('#tom_tcmall#tom_tcmall_refund')->update($refundInfo['id'], $updateData)){
                
                $updateData = array();
                $updateData['order_status'] = 7;
                if(C::t('#tom_tcmall#tom_tcmall_order_goods')->update($refundGoodsInfo['id'], $updateData)){
                    DB::query("UPDATE ".DB::table('tom_tcmall_goods')." SET stock=stock+{$refundGoodsInfo['goods_num']}, sales=sales-{$refundGoodsInfo['goods_num']} WHERE id={$refundGoodsInfo['goods_id']}", 'UNBUFFERED');
                    if($refundGoodsInfo['option_id'] > 0){
                        DB::query("UPDATE ".DB::table('tom_tcmall_goods_option')." SET stock=stock+{$refundGoodsInfo['goods_num']} WHERE id={$refundGoodsInfo['option_id']}", 'UNBUFFERED');
                    }
                }
                
                if($refundGoodsInfo['score_num'] > 0){

                    $orderUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($refundGoodsInfo['user_id']);

                    $updateData = array();
                    $updateData['score'] = $orderUserInfo['score'] + $refundGoodsInfo['score_num'];
                    C::t('#tom_tongcheng#tom_tongcheng_user')->update($orderUserInfo['id'],$updateData);

                    $insertData = array();
                    $insertData['user_id']          = $refundGoodsInfo['user_id'];
                    $insertData['score_value']      = $refundGoodsInfo['score_num'];
                    $insertData['old_value']        = $orderUserInfo['score'];
                    $insertData['log_type']         = 36;
                    $insertData['log_time']         = TIMESTAMP;
                    C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
                }
                
                $orderGoodsCount = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_count(" AND order_id = {$orderInfo['id']} AND order_status IN(2,3) ");
                if(intval($orderGoodsCount) == 0){
                    $updateData = array();
                    $updateData['order_status'] = 7;
                    C::t('#tom_tcmall#tom_tcmall_order')->update($orderInfo['id'], $updateData);
                }
            }
            $template_sms = $Lang['refund_refund_price_succ_template_2'];
            $template_url = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$refundInfo['site_id']}&mod=money";
        }
    }
    
    if(!empty($template_sms) && !empty($template_url)){
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($orderInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $template_url);
            $smsData = array(
                'first'         => $template_sms,
                'keyword1'      => $tcmallConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($orderInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }

        $insertData = array();
        $insertData['user_id']      = $orderInfo['user_id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcmallConfig['plugin_name'].'</font><br/>'.$template_sms.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'cancel_refund'){

    $refund_id = intval($_GET['id'])>0? intval($_GET['id']):0;
    $refundInfo = C::t("#tom_tcmall#tom_tcmall_refund")->fetch_by_id($refund_id);
    
    if(submitcheck('submit')){
        $refund_beizu = addslashes($_GET['refund_beizu'])? addslashes($_GET['refund_beizu']):'';

        $updateData = array();
        $updateData['refund_beizu']     = $refund_beizu;
        $updateData['refund_status']    = 4;
        $updateData['refund_time']      = TIMESTAMP;
        if(C::t('#tom_tcmall#tom_tcmall_refund')->update($refundInfo['id'], $updateData)){

            $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($refundInfo['user_id']);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
            $weixinClass = new weixinClass($appid,$appsecret);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcmall&site={$refundInfo['site_id']}&mod=refundinfo&refund_id={$refundInfo['id']}&from=templatesms");
                $smsData = array(
                    'first'         => $Lang['refund_refund_price_err_template_1'],
                    'keyword1'      => $tcmallConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $refund_beizu
                );

                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        
        tomloadcalendarjs();
        loadeditorjs();
        showtablefooter(); /*dism��taobao��com*/
        showformheader($modFromUrl.'&act=cancel_refund&id='.$refund_id.'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['refund_handle_cancel_refund'] . '</th></tr>';
        showtablefooter(); /*dism��taobao��com*/
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['refund_refund_cancel_beizu'],'name'=>'refund_beizu','value'=>'','msg'=>''),"textarea");
        tomshowsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else{
    
    set_list_url("tom_tcmall_admin_refund_list");
    
    $file_apiclient_cert = DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_cert.pem';
    $file_apiclient_key = DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_key.pem';
    if(!file_exists($file_apiclient_cert) || !file_exists($file_apiclient_key)){
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['refund_error_title'] . '</th></tr>';
        echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
        echo '<li><font color="#FF0000"><b>' . $Lang['refund_error_1'] . '</b></font></a></li>';
        echo '</ul></td></tr>';
        showtablefooter(); /*dism��taobao��com*/
    }
    
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    $refund_status      = isset($_GET['refund_status'])? intval($_GET['refund_status']):0;
    $shop_shenhe_status = isset($_GET['shop_shenhe_status'])? intval($_GET['shop_shenhe_status']):0;
    $wx_refund_status   = isset($_GET['wx_refund_status'])? intval($_GET['wx_refund_status']):0;
    $order_no           = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
    
    $where = "";
    if(!empty($order_no)){
        $where.=" AND pay_order_no='{$order_no}' ";
    }
    if(!empty($refund_status)){
        $where.=" AND refund_status={$refund_status} ";
    }
    if($shop_shenhe_status == 1){
        $where.=" AND shop_shenhe_status=0 ";
    }else if($shop_shenhe_status == 2){
        $where.=" AND shop_shenhe_status=1 ";
    }
    if($wx_refund_status > 0){
        $where.=" AND refund_type=1 AND wx_refund_status={$wx_refund_status} ";
    }
    
    $modBasePageUrl = $modBaseUrl."&order_no={$order_no}&refund_status={$refund_status}&wx_refund_status={$wx_refund_status}";
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_all_count($where);
    $refundList = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_all_list($where,"ORDER BY add_time DESC",$start,$pagesize);
    $fenghao = $Lang['fenghao'];
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    $refund_status_1 = $refund_status_2 = $refund_status_3 = $refund_status_4 = '';
    if($refund_status == 1){
        $refund_status_1 = 'selected';
    }else if($refund_status == 2){
        $refund_status_2 = 'selected';
    }else if($refund_status == 3){
        $refund_status_3 = 'selected';
    }else if($refund_status == 4){
        $refund_status_4 = 'selected';
    }
    
    $shop_shenhe_status_1 = $shop_shenhe_status_2 = '';
    if($shop_shenhe_status == 1){
        $shop_shenhe_status_1 = 'selected';
    }else if($shop_shenhe_status == 2){
        $shop_shenhe_status_2 = 'selected';
    }
    
    $wx_refund_status_1 = $wx_refund_status_2 = '';
    if($wx_refund_status == 1){
        $wx_refund_status_1 = 'selected';
    }else if($wx_refund_status == 2){
        $wx_refund_status_2 = 'selected';
    }
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['refund_search_list'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_pay_order_no'] . '</b></td><td><input name="order_no" type="text" value="'.$order_no.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['refund_refund_status'] . '</b></td><td><select name="refund_status" >';
    echo '<option value="0">'.$Lang['refund_refund_status'].'</option>';
    echo '<option value="1" '.$refund_status_1.'>'.$Lang['refund_refund_status_1'].'</option>';
    echo '<option value="2" '.$refund_status_2.'>'.$Lang['refund_refund_status_2'].'</option>';
    echo '<option value="3" '.$refund_status_3.'>'.$Lang['refund_refund_status_3'].'</option>';
    echo '<option value="4" '.$refund_status_4.'>'.$Lang['refund_refund_status_4'].'</option>';
    echo '</select></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['refund_refund_shop_shenhe_ok'] . '</b></td><td><select name="shop_shenhe_status" >';
    echo '<option value="0">'.$Lang['refund_refund_shop_shenhe_ok_all'].'</option>';
    echo '<option value="1" '.$shop_shenhe_status_1.'>'.$Lang['refund_refund_shop_shenhe_ok_0'].'</option>';
    echo '<option value="2" '.$shop_shenhe_status_2.'>'.$Lang['refund_refund_shop_shenhe_ok_1'].'</option>';
    echo '</select></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['refund_wx_refund_status'] . '</b></td><td><select name="wx_refund_status" >';
    echo '<option value="0">'.$Lang['refund_wx_refund_status_all'].'</option>';
    echo '<option value="1" '.$wx_refund_status_1.'>'.$Lang['refund_wx_refund_status_1'].'</option>';
    echo '<option value="2" '.$wx_refund_status_2.'>'.$Lang['refund_wx_refund_status_2'].'</option>';
    echo '</select></td></tr>';
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return refund_form();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />'.
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['refund_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th width="240">' . $Lang['order_goods_name'] . '</th>';
    echo '<th>' . $Lang['refund_refund_price'] . '</th>';
    echo '<th>' . $Lang['order_user_nickname'] . '</th>';
    echo '<th>' . $Lang['refund_refund_status'] . '</th>';
    echo '<th width="120">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($refundList as $key => $value){
        
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $orderInfo = C::t("#tom_tcmall#tom_tcmall_order")->fetch_by_id($value['order_id']);
        $orderGoodsInfo = C::t("#tom_tcmall#tom_tcmall_order_goods")->fetch_by_id($value['order_goods_id']);
        
        echo '<tr style="background-color:#E4FAF7;">';
        echo '<td colspan="1">' . $Lang['order_order_no'] . '&nbsp;:&nbsp;' . $orderInfo['order_no'] . '<br/>' . $Lang['order_pay_order_no'] . '&nbsp;:&nbsp;' . $orderInfo['pay_order_no'] . '</td>';
        if($value['refund_type'] == 1){
            if($value['wx_refund_status'] == 1){
                echo '<td colspan="2">' . $Lang['refund_wx_refund_status'] . '&nbsp;:&nbsp;<b><font color="#f00">' . $Lang['refund_wx_refund_status_1'] . '</font></b></td>';
            }else if($value['wx_refund_status'] == 2){
                echo '<td colspan="2">' . $Lang['refund_wx_refund_status'] . '&nbsp;:&nbsp;<b><font color="#009900">' . $Lang['refund_wx_refund_status_2'] . '</font></b></td>';
            }
        }else if($value['refund_type'] == 2){
            echo '<td colspan="2">' . $Lang['refund_refund_type'] . '&nbsp;:&nbsp;<b>' . $Lang['refund_refund_type_2'] . '</b></td>';
        }else{
            echo '<td colspan="2">' . $Lang['refund_refund_type'] . '&nbsp;:&nbsp; -- </td>';
        }
        echo '<td colspan="3">' . $Lang['refund_add_time'] . '&nbsp;:&nbsp;' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        echo '</tr>';
        
        echo '<tr style="height: 60px;">';
        echo '<td ><ul>';
        if($orderGoodsInfo){
            $goodsInfoTmp =  C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($orderGoodsInfo['goods_id']);
            $option_name_tmp = '';
            if(!empty($orderGoodsInfo['option_name'])){
                $option_name_tmp = '<font color="#0894fb">(' . $orderGoodsInfo['option_name'] . ')</font>';
            }
            echo '<li style="width: 400px;line-height: 20px;padding: 5px 5px;margin-bottom: 5px;border-left: 2px solid #f1f1f1;">' . $goodsInfoTmp['title'] .$option_name_tmp.'(ID:' . $orderGoodsInfo['goods_id'] . ')&nbsp;&nbsp;&nbsp;'.$orderGoodsInfo['price'].'&nbsp;&nbsp;&nbsp; x'.$orderGoodsInfo['goods_num'].'</li>';
        }
        echo '</ul></td>';
        
        if($value['refund_status'] == 2){
            echo '<td><font color="#009900">' . $value['refund_price'] . '</font></td>';
        }else{
            echo '<td><font color="#009900"> -- </font></td>';
        }
        echo '<td>' . $userInfo['nickname'] . '(UID:'.$value['user_id'].')</td>';
        echo '<td>';
        if($value['refund_status'] == 1){
            echo '<b><font color="#f00">' . $Lang['refund_refund_status_1'] . '</font></b>';
        }else if($value['refund_status'] == 2){
            echo '<b><font color="#009900">' . $Lang['refund_refund_status_2'] . '</font></b>';
        }else if($value['refund_status'] == 3){
            echo '<b><font color="#009900">' . $Lang['refund_refund_status_3'] . '</font></b>';
        }else if($value['refund_status'] == 4){
            echo '<b><font color="#009900">' . $Lang['refund_refund_status_4'] . '</font></b>';
        }
        if($value['shop_shenhe_status'] == 0){
            echo '<b><font color="#0894fb">(' . $Lang['refund_refund_shop_shenhe_ok_0'] . ')</font></b>';
        }else if($value['shop_shenhe_status'] == 1){
            echo '<b><font color="#0894fb">(' . $Lang['refund_refund_shop_shenhe_ok_1'] . ')</font></b>';
        }
        echo '</td>';
        echo '<td style="line-height: 30px;">';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['order_info'] . '</a>';
        if($value['refund_status'] == 1){
            echo '&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.$modBaseUrl.'&act=cancel_refund&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['refund_cancel_refund'] . '</a>';
        }
        echo '</td>';
        echo '</tr>';
    }
    
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
}