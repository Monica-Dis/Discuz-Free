<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=shoprecom';
$modListUrl = $adminListUrl.'&tmod=shoprecom';
$modFromUrl = $adminFromUrl.'&tmod=shoprecom';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcmall#tom_tcmall_shop_recommend')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $recomInfo = C::t('#tom_tcmall#tom_tcmall_shop_recommend')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($recomInfo);
        C::t('#tom_tcmall#tom_tcmall_shop_recommend')->update($recomInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($recomInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcmall#tom_tcmall_shop_recommend')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'status'){
    
    $updateData = array();
    $updateData['status'] = $_GET['status'];
    C::t('#tom_tcmall#tom_tcmall_shop_recommend')->update($_GET['id'], $updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['cate_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>'.$Lang['shoprecom_help_1'].'</li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $recomList = C::t('#tom_tcmall#tom_tcmall_shop_recommend')->fetch_all_list(" "," ORDER BY id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['shoprecom_site'] . '</th>';
    echo '<th>' . $Lang['shoprecom_picurl'] . '</th>';
    echo '<th>' . $Lang['shoprecom_name'] . '</th>';
    echo '<th>' . $Lang['shoprecom_status'] . '</th>';
    echo '<th>' . $Lang['shoprecom_paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($recomList as $key => $value) {
        
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        if(!preg_match('/^http/', $tcshopInfo['picurl']) ){
            if(strpos($tcshopInfo['picurl'], 'source/plugin/tom_tcshop/') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['picurl'];
            }else{
                $picurl = $tcshopInfo['picurl'];
            }
        }else{
            $picurl = $tcshopInfo['picurl'];
        }
        
        $siteInfo       = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td><img src="'.$picurl.'" width="40" /></td>';
        echo '<td>' . $tcshopInfo['name'] . '</td>';
        
        $statusBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=status&id='.$value['id'].'&status=1&formhash='.FORMHASH.'">' . $Lang['shoprecom_status_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=status&id='.$value['id'].'&status=0&formhash='.FORMHASH.'">' . $Lang['shoprecom_status_0']. '</a>)';
        if($value['status'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['shoprecom_status_1'] . '</font>'.$statusBtnStr.'</td>';
        }else{
            echo '<td><font color="#f00">' . $Lang['shoprecom_status_0'] . '</font>'.$statusBtnStr.'</td>';
        }
        echo '<td>' . $value['rsort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shoprecom_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $tcshop_id      = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $rsort          = isset($_GET['rsort'])? intval($_GET['rsort']):10;

    $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
    
    $data['site_id']    = $tcshopInfo['site_id'];
    $data['tcshop_id']  = $tcshopInfo['id'];
    $data['status']     = $status;
    $data['rsort']      = $rsort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'tcshop_id'      => 0,
        'status'         => 0,
        'rsort'          => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['shoprecom_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['shoprecom_tcshop_id_msg']),"input");
    $status_item = array(1=>$Lang['shoprecom_status_1'],0=>$Lang['shoprecom_status_0']);
    tomshowsetting(true,array('title'=>$Lang['shoprecom_status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['shoprecom_status_msg'],'item'=>$status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['shoprecom_rsort'],'name'=>'rsort','value'=>$options['rsort'],'msg'=>$Lang['shoprecom_rsort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['shoprecom_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['shoprecom_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['shoprecom_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['shoprecom_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['shoprecom_edit'],"",true);
    }else{
        tomshownavli($Lang['shoprecom_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['shoprecom_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}