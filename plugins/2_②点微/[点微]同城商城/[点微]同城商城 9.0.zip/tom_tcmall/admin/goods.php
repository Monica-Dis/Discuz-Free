<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=goods';
$modListUrl = $adminListUrl.'&tmod=goods';
$modFromUrl = $adminFromUrl.'&tmod=goods';

$get_list_url_value = get_list_url("tom_tcmall_admin_goods_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $data = __get_post_data();
        
        $insertData = array();
        $insertData = $data;
        $insertData['shenhe_status'] = 1;
        $insertData['add_time']      = TIMESTAMP;
        $goods_id = C::t('#tom_tcmall#tom_tcmall_goods')->insert($insertData, true);
        
        if(!empty($data['picurl'])){
            $insertData = array();
            $insertData['goods_id']  = $goods_id;
            $insertData['type']      = 2;
            $insertData['picurl']    = $data['picurl'];
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcmall#tom_tcmall_goods_photo')->insert($insertData);
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        tomshowsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }

}else if($_GET['act'] == 'edit'){
    $goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $data = __get_post_data($goodsInfo);
        
        $updateData = array();
        //$updateData['edit_time']     = TIMESTAMP;
        $updateData = $data;
        if(C::t('#tom_tcmall#tom_tcmall_goods')->update($goodsInfo['id'],$updateData)){
            C::t('#tom_tcmall#tom_tcmall_goods_photo')->delete_by_goods_avatar($goodsInfo['id']);
            
            if(!empty($data['picurl'])){
                $insertData = array();
                $insertData['goods_id']  = $goodsInfo['id'];
                $insertData['type']      = 2;
                $insertData['picurl']    = $data['picurl'];
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcmall#tom_tcmall_goods_photo')->insert($insertData);
            }
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($goodsInfo);
        tomshowsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tcmall#tom_tcmall_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status']     = 0;
    C::t('#tom_tcmall#tom_tcmall_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status'] = 1;
    $updateData['status']     = 1;
    C::t('#tom_tcmall#tom_tcmall_goods')->update($_GET['id'],$updateData);
    
    $goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']);

    $shenhe = str_replace('{TITLE}', $goodsInfo['title'], $Lang['template_tcmall_shenhe_ok']);

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $weixinClass = new weixinClass($appid,$appsecret);
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcmall&site={$goodsInfo['site_id']}&mod=goodsinfo&goods_id=".$goodsInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcmallConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['tcmall_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['tcmall_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcmallConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        $updateData['status']     = 0;
        C::t('#tom_tcmall#tom_tcmall_goods')->update($_GET['id'],$updateData);
        
        $shenhe = str_replace('{TITLE}', $goodsInfo['title'], $Lang['template_tcmall_shenhe_no']);
        
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcmall&site={$goodsInfo['site_id']}&mod=edit&goods_id=".$goodsInfo['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcmallConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tcmall_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tcmall_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcmallConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tcmall_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tcmall_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcmall_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editstock'){
    
    $info = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $stock     = isset($_GET['stock'])? intval($_GET['stock']):0;
        
        $updateData = array();
        $updateData['stock'] = $stock;
        C::t('#tom_tcmall#tom_tcmall_goods')->update($_GET['id'],$updateData);
        
        $insertData = array();
        $insertData['is_admin']     = 1;
        $insertData['goods_id']     = $_GET['id'];
        $insertData['change_num']   = $stock;
        $insertData['change_time']  = TIMESTAMP;
        C::t('#tom_tcmall#tom_tcmall_goods_stock_log')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editstock&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_stock_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_stock'],'name'=>'stock','value'=>$info['stock'],'msg'=>$Lang['edit_stock_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
        
        tomshownavheader();
        tomshownavli($Lang['stocklog_list_title'],"",true);
        tomshownavfooter();

        $stockyLogList = C::t('#tom_tcmall#tom_tcmall_goods_stock_log')->fetch_all_list(" AND goods_id={$info['id']} "," ORDER BY id DESC ",0,500);
        showtableheader();
        echo '<tr class="header">';
        echo '<th>' . $Lang['stocklog_is_admin'] . '</th>';
        echo '<th>' . $Lang['stocklog_is_option'] . '</th>';
        echo '<th>' . $Lang['stocklog_change_num'] . '</th>';
        echo '<th>' . $Lang['stocklog_beizu'] . '</th>';
        echo '<th>' . $Lang['stocklog_change_time'] . '</th>';
        echo '</tr>';

        $i = 1;
        foreach ($stockyLogList as $key => $value) {
            echo '<tr>';
            if($value['is_admin'] == 1){
                echo '<td>' . $Lang['stocklog_is_admin_1'] . '</td>';
            }else{
                echo '<td>' . $Lang['stocklog_is_admin_0'] . '</td>';
            }
            if($value['is_option'] == 1){
                echo '<td>' . $Lang['stocklog_is_option_yes'] . '</td>';
            }else{
                echo '<td>' . $Lang['stocklog_is_option_no'] . '</td>';
            }
            echo '<td>' . $value['change_num'] . '</td>';
            echo '<td>' . $value['beizu'] . '</td>';
            echo '<td>' . dgmdate($value['change_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
            echo '</tr>';
            $i++;
        }
        showtablefooter(); /*dism��taobao��com*/
    }
}else if($_GET['act'] == 'photo'){
    
    $goods_id = $_GET['goods_id'];
    
    if(submitcheck('submit')){
        
        if($_FILES["picurl"]['tmp_name']) {
            $upload = new tom_upload();
            if(!$upload->init($_FILES["picurl"], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }
            $picurl = $upload->attach['attachment'];
        }else{
            $picurl = addslashes($_GET["picurl"]);
        }
        
        $insertData = array();
        $insertData['goods_id']     = $goods_id;
        $insertData['type']         = 1;
        $insertData['picurl']       = $picurl;
        $insertData['psort']        = 10;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tcmall#tom_tcmall_goods_photo')->insert($insertData);
        
        cpmsg($Lang['act_success'], $adminListUrl.'&tmod=goods'."&act=photo&goods_id=".$_GET['goods_id'], 'succeed');
    }
    
    $goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($_GET['goods_id']);
    
    $photoList = C::t('#tom_tcmall#tom_tcmall_goods_photo')->fetch_all_list(" AND goods_id={$goods_id} AND type = 1 ","ORDER BY psort ASC ,id ASC",0,100);
    __create_nav_html();
    showformheader($modFromUrl.'&act=photo&goods_id='.$goods_id,'enctype');
    showtableheader();
    tomshowsetting(true,array('title'=>$Lang['goods_photo_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['goods_photo_picurl_msg']),"file");
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&act=photopaixu&goods_id='.$goods_id.'&formhash='.FORMHASH.'">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />';
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['paixu'] . '</th>';
    echo '<th>' . $Lang['goods_photo_picurl'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($photoList as $key => $value) {
        
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_tcmall/') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        echo '<tr>';
        echo '<td><input type="hidden" name="ids[]" value="' . $value['id'] . '" ><input name="psorts[]" type="text" value="'.$value['psort'].'" size="5" /></td>';
        echo '<td><img src="' . $picurl . '" width="60" /></td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&goods_id='.$goods_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    $formstr = <<<EOF
        <tr>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['goods_photo_paixu_btn']}" /></div>
            </td>
        </tr>
EOF;
    echo $formstr;
    showformfooter();
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'photopaixu'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['psort']        = $_GET['psorts'][$key];
            C::t('#tom_tcmall#tom_tcmall_goods_photo')->update($value,$updateData);
        }
    }
    cpmsg($Lang['act_success'], $adminListUrl.'&tmod=goods'."&act=photo&goods_id=".$_GET['goods_id'], 'succeed');
    
}else if($_GET['act'] == 'pinglun_list'){

    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $goods_id = $_GET['goods_id'];
    $goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($_GET['goods_id']);
    
    $modBasePageUrl = $modBaseUrl."&act=pinglun_list&goods_id={$goods_id}";
    
    $pagesize = 20;
    $start = ($page - 1) * $pagesize;
    $count = C::t('#tom_tcmall#tom_tcmall_pinglun')->fetch_all_count(" AND goods_id={$goods_id} ");
    $pinglunList = C::t('#tom_tcmall#tom_tcmall_pinglun')->fetch_all_list(" AND goods_id={$goods_id} ","ORDER BY id ASC", $start, $pagesize);

    showtableheader();
    echo '<tr><th colspan="15" class="partition">'.$goodsInfo['title'] ."&nbsp;&nbsp;--&gt;&gt;&nbsp;&nbsp;" . $Lang['goods_pinglun_list'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['pinglun_user_id'] . '</th>';
    echo '<th>' . $Lang['pinglun_score'] . '</th>';
    echo '<th width="240px">' . $Lang['pinglun_content'] . '</th>';
    echo '<th>' . $Lang['pinglun_photo'] . '</th>';
    echo '<th>' . $Lang['pinglun_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($pinglunList as $key => $value) {
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $replyList = C::t('#tom_tcmall#tom_tcmall_pinglun_reply')->fetch_all_list(" AND pinglun_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);
        $pinglunPhotoListTmpTmp = C::t('#tom_tcmall#tom_tcmall_pinglun_photo')->fetch_all_list(" AND pinglun_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);
        $pinglunPhotoListTmp = array();
        if(is_array($pinglunPhotoListTmpTmp) && !empty($pinglunPhotoListTmpTmp)){
            foreach($pinglunPhotoListTmpTmp as $pk => $pv){
                if(!preg_match('/^http/', $pv['picurl']) ){
                    if(strpos($pv['picurl'], 'source/plugin/tom_tcmall/') === FALSE){
                        $pinglunPhotoListTmp[] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$pv['picurl'];
                    }else{
                        $pinglunPhotoListTmp[] = $pv['picurl'];
                    }
                }else{
                    $pinglunPhotoListTmp[] = $pv['picurl'];
                }

            }
        }
        
        echo '<tr>';
        echo '<td>' .$userInfo['nickname'].'('.$value['user_id']. ')</td>';
        echo '<td><font color="#009900">' .$value['score'].$Lang['score_unit'].'('.$pinglunStatusArray[$value['score']].')</font></td>';
        echo '<td>' .$value['content'].'</td>';
        echo '<td>';
        if(is_array($pinglunPhotoListTmp) && !empty($pinglunPhotoListTmp)){
            foreach ($pinglunPhotoListTmp as $k3 => $v3){
                echo '<a href="'.$v3.'" target="_blank"><img src="'.$v3.'" width="40" height="40" />&nbsp;</a>';
            }
        }
        echo '</td>';
        echo '<td>' .dgmdate($value['pinglun_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delpinglun&id='.$value['id'].'&goods_id='.$goods_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        foreach($replyList as $rk => $rv){
            echo '<tr>';
            echo '<td style="text-align:right;"> --&gt;&gt;&nbsp;&nbsp; </td>';
            echo '<td colspan="2">'.$rv['reply_user_nickname'].' '.$Lang['pinglun_kefu_reply'].$rv['content'].'</td>';
            echo '<td> &nbsp; </td>';
            echo '<td>' .dgmdate($rv['reply_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td>';
            echo '<td>';
            echo '<a href="'.$modBaseUrl.'&act=delpinglun_reply&id='.$value['id'].'&goods_id='.$goods_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
            echo '</td>';
            echo '</tr>';
        }
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delpinglun'){
    
    C::t('#tom_tcmall#tom_tcmall_pinglun')->delete_by_id($_GET['id']);
    C::t('#tom_tcmall#tom_tcmall_pinglun_photo')->delete_by_pinglun_id($_GET['id']);
    C::t('#tom_tcmall#tom_tcmall_pinglun_reply')->delete_by_pinglun_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $adminListUrl.'&tmod=goods'."&act=pinglun_list&goods_id=".$_GET['goods_id'], 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delpinglun_reply'){
    
    C::t('#tom_tcmall#tom_tcmall_pinglun_reply')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $adminListUrl.'&tmod=goods'."&act=pinglun_list&goods_id=".$_GET['goods_id'], 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tcmall#tom_tcmall_goods_photo')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $adminListUrl.'&tmod=goods'."&act=photo&goods_id=".$_GET['goods_id'], 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $orderGoodsCount = C::t("#tom_tcmall#tom_tcmall_order_goods")->fetch_all_count(" AND goods_id = {$_GET['id']} ");
    if($orderGoodsCount > 0){
        cpmsg($Lang['goods_no_del_msg'], $modListUrl, 'succeed');
    }else{
        C::t('#tom_tcmall#tom_tcmall_goods')->delete_by_id($_GET['id']);
        C::t('#tom_tcmall#tom_tcmall_goods_photo')->delete_by_goods_id($_GET['id']);
        C::t('#tom_tcmall#tom_tcmall_goods_option')->delete_by_goods_id($_GET['id']);
        C::t('#tom_tcmall#tom_tcmall_goods_spec')->delete_by_goods_id($_GET['id']);
        C::t('#tom_tcmall#tom_tcmall_goods_stock_log')->delete_by_goods_id($_GET['id']);

        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }
}else{
    
    set_list_url("tom_tcmall_admin_goods_list");
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ list-style-type: none; height: 25px; line-height: 25px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;padding: 3px 10px;color: #6a6d6a; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
.order_nav a{ margin-bottom: 10px;margin-right: 20px;font-size: 16px; color: #797575; display: block; float: left; width: 150px; height: 30px; border: 1px solid #d0d0d0; line-height: 30px; text-align: center; text-decoration: none;}
</style>
EOF;
    echo $csstr;
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $title          = !empty($_GET['title'])? addslashes($_GET['title']):'';
    $tcshop_id      = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id  = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $goods_num_low  = isset($_GET['goods_num_low'])? intval($_GET['goods_num_low']):0;
    $goods_sell_out = isset($_GET['goods_sell_out'])? intval($_GET['goods_sell_out']):0;
    $isrecommand    = isset($_GET['isrecommand'])? intval($_GET['isrecommand']):0;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($tcshop_id)){
        $where.= " AND tcshop_id={$tcshop_id} ";
    }
    if($status == 1){
        $where.= " AND status=1 ";
    }else if($status == 2){
        $where.= " AND status=0 ";
    }
    if(!empty($cate_id)){
        $where.= " AND cate_id={$cate_id} ";
    }
    if(!empty($cate_child_id)){
        $where.= " AND cate_child_id={$cate_child_id} ";
    }
    if($shenhe_status > 0){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    if($goods_num_low == 1){
        $where.= "  AND stock < 10 ";
    }
    if($goods_sell_out == 1){
        $where.= "  AND stock = 0 ";
    }
    if($isrecommand == 1){
        $where.= "  AND isrecommand = 1 ";
    }
    
    $sort = " ORDER BY id DESC ";
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&title={$title}&tcshop_id={$tcshop_id}&status={$status}&cate_id={$cate_id}&cate_child_id={$cate_child_id}&shenhe_status={$shenhe_status}&isrecommand={$isrecommand}";
    
    $pagesize   = 10;
    $start      = ($page-1)*$pagesize;	
    $count      = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count($where,$title);
    $goodsList  = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list($where,$sort,$start,$pagesize,$title);
    showtableheader();
    $Lang['tcmall_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcmall_help_1']);
    $Lang['tcmall_help_2']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcmall_help_2']);
    $Lang['tcmall_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcmall_help_3']);
    $Lang['tcmall_help_4']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcmall_help_4']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['tcmall_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['tcmall_help_1'] . '</li>';
    echo '<li>' . $Lang['tcmall_help_2'] . '</li>';
    if($tongchengConfig['open_yun'] == 2){
        echo '<li>' . $Lang['tcmall_help_3'] . '</li>';
    }
    if($tongchengConfig['open_yun'] == 3){
        echo '<li>' . $Lang['tcmall_help_4'] . '</li>';
    }
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['goods_search_title'] . '</th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td>';
    echo $sitesStr;
    echo '<tr><td width="100" align="right"><b>' . $Lang['goods_title'] . '</b></td><td><input name="title" type="text" value="'.$title.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['goods_tcshop_id'] . '</b></td><td><input name="tcshop_id" type="text" value="'.$tcshop_id.'" size="40" /></td></tr>';
    
    $cateList = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,100);
    $cate_list_item = array();
    if(is_array($cateList) && !empty($cateList)){
        foreach ($cateList as $key => $value){
            $cate_list_item[$value['id']] = $value['name'];
        }
    }
    echo '<tr><td width="100" align="right"><b>' . $Lang['goods_cate_id'] . '</b></td><td><select name="cate_id" id="cate_id" onchange="getChild();" >';
    echo '<option value="0">'.$Lang['goods_cate_id'].'</option>';
    foreach ($cate_list_item as $key => $value){
        if($key == $cate_id){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select>&nbsp;&nbsp;<select name="cate_child_id" id="cate_child_id">';
    echo '<option value="0">'.$Lang['goods_cate_child_id'].'</option>';
    if($cate_id > 0){
        $childCateList = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(" AND pid={$cate_id} "," ORDER BY csort ASC,id DESC ",0,50);
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $key => $value) {
                if($value['id'] == $cate_child_id){
                    echo  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
                }else{
                    echo  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                }
            }
        }
    }
    echo '</select></td></tr>';
    
    echo '<tr><td width="100" align="right"><b>' . $Lang['goods_status'] . '</b></td><td><select name="status" >';
    echo '<option value="0">'.$Lang['goods_status'].'</option>';
    $status1_selected = $status2_selected = "";
    if(1 == $status){
        $status1_selected = "selected";
    }
    if(2 == $status){
        $status2_selected = "selected";
    }
    echo '<option value="1" '.$status1_selected.'>'.$Lang['goods_status_1'].'</option>';
    echo '<option value="2" '.$status2_selected.'>'.$Lang['goods_status_2'].'</option>';
    echo '</select></td></tr>';
    
    $shenhe_status_1 = $shenhe_status_2 = $shenhe_status_3 = '';
    if($shenhe_status == 1){
        $shenhe_status_1 = 'selected';
    }else if($shenhe_status == 2){
        $shenhe_status_2 = 'selected';
    }else if($shenhe_status == 3){
        $shenhe_status_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['goods_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$shenhe_status_1.'>'.$Lang['goods_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$shenhe_status_2.'>'.$Lang['goods_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$shenhe_status_3.'>'.$Lang['goods_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    $countGoodsNumLow = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND stock < 10 AND status=1 AND shenhe_status = 2 ");
    $countGoodsSellOut = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND stock = 0 AND status=1 AND shenhe_status = 2");
    $countShenheStatus2 = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND shenhe_status=2");
    $countShenheStatus3 = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND shenhe_status=3");
    $countIsrecommand = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND isrecommand=1");
    
    echo '<div class="order_nav">';
    echo '<a style="border-color: #35a6ee;color: #35a6ee;" href="'.$modBaseUrl.'&goods_num_low=1'.'">'.$Lang['goods_num_low_title'].'&nbsp;<span>('.$countGoodsNumLow.')</span></a>';
    echo '<a style="border-color: #35a6ee;color: #35a6ee;" href="'.$modBaseUrl.'&goods_sell_out=1'.'">'.$Lang['goods_sell_out_title'].'&nbsp;<span>('.$countGoodsSellOut.')</span></a>';
    echo '<a style="border-color: #f0962a;color: #f0962a;" href="'.$modBaseUrl.'&shenhe_status=2'.'">'.$Lang['goods_shenhe_status2_title'].'&nbsp;<span>('.$countShenheStatus2.')</span></a>';
    echo '<a style="border-color: #1fbf8c;color: #1fbf8c;" href="'.$modBaseUrl.'&shenhe_status=3'.'">'.$Lang['goods_shenhe_status3_title'].'&nbsp;<span>('.$countShenheStatus3.')</span></a>';
    echo '<a style="border-color: #f60;color: #f60;" href="'.$modBaseUrl.'&isrecommand=1'.'">'.$Lang['goods_isrecommand'].'&nbsp;<span>('.$countIsrecommand.')</span></a>';
    echo '</div>';
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header" style="color: #3d7eb7;background-color: #f2f9fd;">';
    echo '<th style="width: 60px;">' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['goods_picurl'] . '</th>';
    echo '<th width="200">' . $Lang['goods_info'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['shop_info'] . '</th>';
    echo '<th>' . $Lang['goods_stock'] . '</th>';
    echo '<th>' . $Lang['goods_sales'] . '</th>';
    echo '<th>' . $Lang['goods_price'] . '</th>';
    echo '<th>' . $Lang['goods_status2'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($goodsList as $key => $value) {
        
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_tcmall/') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        $siteInfo       = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $cateInfo       = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_by_id($value['cate_id']);
        $cateChildInfo  = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_by_id($value['cate_child_id']);
        $tcshopInfo     = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $tcshopUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfo['user_id']); 
        
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td><img src="'.$picurl.'" width="40" /></td>';
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['goods_cate_id'].'&nbsp;:&nbsp;</b>' . $cateInfo['name'] . '&nbsp;&nbsp;&nbsp;'.$cateChildInfo['name'] . '</li>';
        echo '<li><b>'.$Lang['goods_id'].'&nbsp;:&nbsp;</b>' . $value['id'] . '</li>';
        echo '<li><b>'.$Lang['goods_title'].'&nbsp;:&nbsp;</b>' . $value['title'] . '</li>';
        echo '<li><b>'.$Lang['goods_area'].'&nbsp;:&nbsp;</b>' . $value['province'] .' -- '. $value['city'] . '</li>';
        echo '</ul></div></td>';
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li>'.$Lang['goods_tcshop_id'].'&nbsp;:&nbsp;' . $tcshopInfo['id'] . '</li>';
        echo '<li>'.$Lang['goods_tcshop_name'].'&nbsp;:&nbsp;' . $tcshopInfo['name'] . '</li>';
        echo '<li>'.$Lang['goods_tcshop_balance_user_id'].'&nbsp;:&nbsp;<font color="#0894fb">' . $tcshopUserInfo['id'] . '</font></li>';
        echo '<li>'.$Lang['goods_tcshop_balance_nickname'].'&nbsp;:&nbsp;<font color="#0894fb">' . $tcshopUserInfo['nickname'] . '</font></li>';
        echo '</ul></div></td>';
        echo '<td><font color="#fd0d0d">' . $value['stock'] . '</td>';
        echo '<td><font color="#238206">' . $value['sales'] . '</td>';
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li>'.$Lang['goods_market_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['market_price'] . '</font></li>';
        echo '<li>'.$Lang['goods_buy_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['buy_price'] . '</font></li>';
        if($value['open_vip'] == 1){
            echo '<li>'.$Lang['goods_vip_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['vip_price'] . '</font></li>';
        }
        
        echo '</ul></div></td>';
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['goods_sort_title'].'&nbsp;:&nbsp;</b>' . $value['gsort'] . '</li>';
        echo '<li><b>'.$Lang['goods_clicks'].'&nbsp;:&nbsp;</b>' . $value['clicks'] . '</li>';
        //echo '<li><b>'.$Lang['goods_virtual_clicks'].'&nbsp;:&nbsp;</b>' . $value['virtual_clicks'] . '</li>';
        echo '<li><b>'.$Lang['goods_virtual_sales'].'&nbsp;:&nbsp;</b>' . $value['virtual_sales'] . '</li>';
        
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_shenhe_btn_2']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_shenhe_btn_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<li><b>'.$Lang['goods_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['goods_shenhe_status_1'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 2){
            echo '<li><b>'.$Lang['goods_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['goods_shenhe_status_2'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 3){
            echo '<li><b>'.$Lang['goods_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['goods_shenhe_status_3'] . '</font>'.$sheheBtnStr.'</li>';
        }
        
        $statusBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_status_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_status_2']. '</a>)';
        if($value['status'] == 1 ){
            echo '<li><b>'.$Lang['goods_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['goods_status_1'] . '</font>'.$statusBtnStr.'</li>';
        }else{
            echo '<li><b>'.$Lang['goods_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['goods_status_2'] . '</font>'.$statusBtnStr.'</li>';
        }
        
        echo '</ul></div></td>';
        echo '<td style="line-height: 30px;">';
        echo '<a href="'.$adminBaseUrl.'&tmod=goodsorder&goods_id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#238206">' . $Lang['goods_order_title'] . '</font></a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_edit']. '</a><br/>';
        if($value['hasoption'] == 1){
            echo '<a href="'.$_G['siteurl'].'plugin.php?id=tom_tcmall:manage&act=option&goods_id='.$value['id'].'" target="_blank"><font color="#fd0d0d">' . $Lang['goods_hasoption_title']. '</font></a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        }else{
            echo '<a href="'.$modBaseUrl.'&act=editstock&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#fd0d0d">' . $Lang['edit_stock_title']. '</font></a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        }
        echo '<a href="'.$modBaseUrl.'&act=photo&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_photo']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=pinglun_list&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_pinglun_list']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}

function getChild(){
  var cate_id = jq("#cate_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcmall:ajax",
        data: "act=childcates&pid="+cate_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var cateChildHtml = '<option value="0">{$Lang['goods_cate_child_id']}</option>';
            jq.each(json,function(k,v){
                cateChildHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#cate_child_id").html(cateChildHtml);
            jq("#cate_child_id").show();
        }
    });
}
</script>
EOF;
    echo $jsstr;
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $sub_title          = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $shop_cate_id       = isset($_GET['shop_cate_id'])? intval($_GET['shop_cate_id']):0;
    $unit               = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $market_price       = isset($_GET['market_price'])? floatval($_GET['market_price']):0.00;
    $buy_price          = isset($_GET['buy_price'])? floatval($_GET['buy_price']):0.00;
    $open_vip           = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $vip_price          = isset($_GET['vip_price'])? floatval($_GET['vip_price']):0.00;
    $open_score_dikou   = isset($_GET['open_score_dikou'])? intval($_GET['open_score_dikou']):0;
    $score_num          = isset($_GET['score_num'])? intval($_GET['score_num']):0;
    $score_dikou_price  = isset($_GET['score_dikou_price'])? floatval($_GET['score_dikou_price']):0.00;
    $show_stock         = isset($_GET['show_stock'])? intval($_GET['show_stock']):0;
    $show_sales         = isset($_GET['show_sales'])? intval($_GET['show_sales']):0;
    $virtual_sales      = isset($_GET['virtual_sales'])? intval($_GET['virtual_sales']):0;
    $virtual_clicks     = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $max_buy            = isset($_GET['max_buy'])? intval($_GET['max_buy']):0;
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    $weight             = isset($_GET['weight'])? intval($_GET['weight']):0;
    $isnew              = isset($_GET['isnew'])? intval($_GET['isnew']):0;
    $ishot              = isset($_GET['ishot'])? intval($_GET['ishot']):0;
    $isrecommand        = isset($_GET['isrecommand'])? intval($_GET['isrecommand']):0;
    $seven              = isset($_GET['seven'])? intval($_GET['seven']):0;
    $issendfree         = isset($_GET['issendfree'])? intval($_GET['issendfree']):0;
    $dispatch_price     = isset($_GET['dispatch_price'])? floatval($_GET['dispatch_price']):0.00;
    $dispatch_type      = isset($_GET['dispatch_type'])? intval($_GET['dispatch_type']):1;
    $ednum              = isset($_GET['ednum'])? intval($_GET['ednum']):0;
    $edmoney            = isset($_GET['edmoney'])? floatval($_GET['edmoney']):0;
    $province           = isset($_GET['province'])? addslashes($_GET['province']):'';
    $city               = isset($_GET['city'])? addslashes($_GET['city']):'';
    $keywords           = isset($_GET['keywords'])? addslashes($_GET['keywords']):'';
    $labelname          = isset($_GET['labelname'])? addslashes($_GET['labelname']):'';
    $yongjin_bili       = isset($_GET['yongjin_bili'])? floatval($_GET['yongjin_bili']):0;
    $hehuoren_tg_open   = isset($_GET['hehuoren_tg_open'])? intval($_GET['hehuoren_tg_open']):0;
    $chuji_fc_scale     = isset($_GET['chuji_fc_scale'])? floatval($_GET['chuji_fc_scale']):0;
    $zhongji_fc_scale   = isset($_GET['zhongji_fc_scale'])? floatval($_GET['zhongji_fc_scale']):0;
    $gaoji_fc_scale     = isset($_GET['gaoji_fc_scale'])? floatval($_GET['gaoji_fc_scale']):0;
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $gsort              = isset($_GET['gsort'])? intval($_GET['gsort']):10;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $allow_refund       = isset($_GET['allow_refund'])? intval($_GET['allow_refund']):0;
    $zhibo_roomid       = isset($_GET['zhibo_roomid'])? intval($_GET['zhibo_roomid']):0;
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    
    if($market_price <= 0){
        $market_price = $buy_price;
    }
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }

    $data['site_id']            = $site_id;
    $data['tcshop_id']          = $tcshopInfo['id'];
    $data['user_id']            = $tcshopInfo['user_id'];
    $data['title']              = $title;
    $data['sub_title']          = $sub_title;
    $data['picurl']             = $picurl;
    $data['cate_id']            = $cate_id;
    $data['cate_child_id']      = $cate_child_id;
    $data['shop_cate_id']       = $shop_cate_id;
    $data['unit']               = $unit;
    $data['content']            = $content;
    $data['market_price']       = $market_price;
    $data['buy_price']          = $buy_price;
    $data['open_vip']           = $open_vip;
    $data['vip_price']          = $vip_price;
    $data['open_score_dikou']   = $open_score_dikou;
    $data['score_num']          = $score_num;
    $data['score_dikou_price']  = $score_dikou_price;
    $data['show_stock']         = $show_stock;
    $data['show_sales']         = $show_sales;
    $data['virtual_sales']      = $virtual_sales;
    $data['virtual_clicks']     = $virtual_clicks;
    $data['weight']             = $weight;
    $data['max_buy']            = $max_buy;
    $data['hasoption']          = $hasoption;
    $data['isnew']              = $isnew;
    $data['ishot']              = $ishot;
    $data['isrecommand']        = $isrecommand;
    $data['seven']              = $seven;
    $data['issendfree']         = $issendfree;
    $data['dispatch_price']     = $dispatch_price;
    $data['dispatch_type']      = $dispatch_type;
    $data['ednum']              = $ednum;
    $data['edmoney']            = $edmoney;
    $data['province']           = $province;
    $data['city']               = $city;
    $data['keywords']           = $keywords;
    $data['labelname']          = $labelname;
    $data['yongjin_bili']       = $yongjin_bili;
    $data['hehuoren_tg_open']   = $hehuoren_tg_open;
    $data['chuji_fc_scale']     = $chuji_fc_scale;
    $data['zhongji_fc_scale']   = $zhongji_fc_scale;
    $data['gaoji_fc_scale']     = $gaoji_fc_scale;
    if($hasoption == 0){
        $data['show_market_price']      = $market_price;
        $data['show_buy_price']         = $buy_price;
        $data['show_vip_price']         = $vip_price;
        $data['show_score_num']         = $score_num;
        $data['show_score_dikou_price'] = $score_dikou_price;
    }
    $data['admin_edit']         = $admin_edit;
    $data['hexiao_pwd']         = $hexiao_pwd;
    $data['gsort']              = $gsort;
    $data['status']             = $status;
    $data['search_txt']         = $title.'|'.$keywords.'|'.$labelname;
    $data['allow_refund']       = $allow_refund;
    $data['zhibo_roomid']       = $zhibo_roomid;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$tcmallConfig;
    $options = array(
        'site_id'                   => 0,
        'tcshop_id'                 => 0,
        'title'                     => '',
        'sub_title'                 => '',
        'picurl'                    => '',
        'cate_id'                   => 0,
        'cate_child_id'             => 0,
        'shop_cate_id'              => 0,
        'unit'                      => '',
        'admin_edit'                => 0,
        'content'                   => '',
        'market_price'              => 0.00,
        'buy_price'                 => 0.00,
        'open_vip'                  => 0,
        'vip_price'                 => 0.00,
        'open_score_dikou'          => 0,
        'score_num'                 => 0,
        'score_dikou_price'         => 0.00,
        'show_stock'                => 0,
        'show_sales'                => 0,
        'virtual_sales'             => 0,
        'virtual_clicks'            => 0,
        'max_buy'                   => 0,
        'hasoption'                 => 0,
        'weight'                    => 0,
        'isnew'                     => 0,
        'ishot'                     => 0,
        'isrecommand'               => 0,
        'seven'                     => 0,
        'issendfree'                => 0,
        'dispatch_price'            => 0.00,
        'dispatch_type'             => 1,
        'ednum'                     => 0,
        'edmoney'                   => 0.00,
        'province'                  => "",
        'city'                      => '',
        'keywords'                  => "",
        'labelname'                 => "",
        'yongjin_bili'              => 0,
        'hexiao_pwd'                => '',
        'gsort'                     => 10,
        'hehuoren_tg_open'          => 0,
        'chuji_fc_scale'            => 0,
        'zhongji_fc_scale'          => 0,
        'gaoji_fc_scale'            => 0,
        'status'                    => 0,
        'allow_refund'              => 1,
        'zhibo_roomid'              => 0,
    );
    $options = array_merge($options, $infoArr);
    
           $tabstr = <<<EOF
    <style>
    .tab-ul{margin-top:10px;border-color:#C5D0DC;margin-bottom:0!important;margin-left:0;position:relative;top:1px;border-bottom:1px solid #ddd;padding-left:0;list-style:none;}
    .tab-ul>li{position:relative;display:block;float:left;margin-bottom:-1px;}
    .tab-ul>li>a { position: relative; display: block; padding: 10px 15px; margin-right: 2px; line-height: 1.42857; border: 0px solid transparent; border-radius: 4px 4px 0 0; padding: 7px 12px 8px; min-width: 100px; text-align: center; }
    .tab-ul>li>a, .tab-ul>li>a:focus { border-radius: 0!important; border-color: #c5d0dc; color: #999; margin-right: -1px; line-height: 18px; position: relative; }
    .tab-ul>li>a:focus, .tab-ul>li>a:hover {text-decoration: none;background-color: #eee;}
    .tab-ul>li>a:hover {border-color: #eee #eee #ddd;}
    .tab-ul>li.active>a, .tab-ul>li.active>a:focus, .tab-ul>li.active>a:hover {color: #555;background-color: #fff;border: 1px solid #ddd;border-bottom-color: transparent;cursor: default;}
    .tab-ul>li>a:hover {background-color: #FFF;color: #f25656;border-color: #c5d0dc;}
    .tab-ul>li:first-child>a {margin-left: 0;}
    .tab-ul>li.active>a, .tab-ul>li.active>a:focus, .tab-ul>li.active>a:hover {color: #576373;border-color: #c5d0dc #c5d0dc transparent;border-top: 2px solid #f25656;background-color: #FFF;z-index: 1;line-height: 18px;margin-top: -1px;}
    .tab-ul>li.active>a, .tab-ul>li.active>a:focus, .tab-ul>li.active>a:hover {color: #555;background-color: #fff;border: 1px solid #ddd;border-bottom-color: transparent;cursor: default;}
    .tab-ul>li.active>a, .tab-ul>li.active>a:focus, .tab-ul>li.active>a:hover {color: #576373;border-color: #c5d0dc #c5d0dc transparent;border-top: 2px solid #f25656;background-color: #FFF;z-index: 1;line-height: 18px;margin-top: -1px;}
    .tab-ul:before,.tab-ul:after{content: " ";display: table;}
    .tab-ul:after{clear: both;}

    .order_nav{margin-top: 10px;    height: 40px;}
    .order_nav a{ margin-right: 20px; font-size: 16px; color: #797575; display: block; float: left; width: 150px; height: 30px; border: 1px solid #d0d0d0; line-height: 30px; text-align: center;text-decoration: none;}
    .order_nav span{color: #F00;}
    </style>
    <ul class="tab-ul">
        <li class="active"><a data-toggle="tab" tabid="#tab_base">{$Lang['goods_tab_base']}</a></li>
        <li ><a data-toggle="tab" tabid="#tab_content">{$Lang['goods_tab_content']}</a></li>
        <li ><a data-toggle="tab" tabid="#tab_taketype">{$Lang['goods_tab_taketype']}</a></li>
        <li ><a data-toggle="tab" tabid="#tab_fencheng">{$Lang['goods_tab_fencheng']}</a></li>
    </ul>
EOF;
    echo $tabstr;
    
    // ********************************* tab_base start *********************************
    echo '<table class="tb tb2 table-form"  id="tab_base">';
    tomshowsetting(true,array('title'=>$Lang['sites_title'].'ID','name'=>'site_id','value'=>$options['site_id'],'msg'=>''),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['goods_tcshop_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['goods_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_sub_title'],'name'=>'sub_title','value'=>$options['sub_title'],'msg'=>$Lang['goods_sub_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['goods_picurl_msg']),"file");
    
    $cateList = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,100);
    $catesStr = '<tr class="header"><th>'.$Lang['goods_cate_id'].'</th><th></th></tr>';
    $catesStr.= '<tr><td width="300"><select style="width: 150px;" name="cate_id" id="cate_id" onchange="getChild();">';
    $catesStr.=  '<option value="0">'.$Lang['goods_cate_id'].'</option>';
    foreach ($cateList as $key => $value){
        if($value['id'] == $options['cate_id']){
            $catesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $catesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $catesStr.= '</select>&nbsp;&nbsp;<select style="width: 150px;" name="cate_child_id" id="cate_child_id">';
    $catesStr.=  '<option value="0">'.$Lang['goods_cate_child_id'].'</option>';
    if($options['cate_id'] > 0){
        $childCateList = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(" AND pid={$options['cate_id']} "," ORDER BY csort ASC,id DESC ",0,100);
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $key => $value) {
                if($value['id'] == $options['cate_child_id']){
                    $catesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
                }else{
                    $catesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                }
            }
        }
    }
    $catesStr.= '</select></td><td>'.$Lang['goods_cate_id_msg'].'</td></tr>';
    echo $catesStr;
    
    if($_GET['act'] == 'edit'){
        $shopCateList = C::t('#tom_tcshop#tom_tcshop_mall_cate')->fetch_all_list(" AND tcshop_id={$options['tcshop_id']} "," ORDER BY csort ASC,id DESC ",0,100);
        if(is_array($shopCateList) && !empty($shopCateList)){
            $shopcatesStr = '<tr class="header"><th>'.$Lang['goods_shop_cate_id'].'</th><th></th></tr>';
            $shopcatesStr.= '<tr><td width="300"><select style="width: 150px;" name="shop_cate_id" id="shop_cate_id">';
            $shopcatesStr.=  '<option value="0">'.$Lang['goods_shop_cate_id'].'</option>';
            foreach ($shopCateList as $key => $value){
                if($value['id'] == $options['shop_cate_id']){
                    $shopcatesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
                }else{
                    $shopcatesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                }
            }
            $shopcatesStr.= '</select></td><td>'.$Lang['goods_shop_cate_id_msg'].'</td></tr>';
            echo $shopcatesStr;
        }
    }

    tomshowsetting(true,array('title'=>$Lang['goods_unit'],'name'=>'unit','value'=>$options['unit'],'msg'=>$Lang['goods_unit_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_market_price'],'name'=>'market_price','value'=>$options['market_price'],'msg'=>$Lang['goods_market_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_buy_price'],'name'=>'buy_price','value'=>$options['buy_price'],'msg'=>$Lang['goods_buy_price_msg']),"input");
    $open_vip_item = array(1=>$Lang['goods_open_vip_1'],0=>$Lang['goods_open_vip_0']);
    tomshowsetting(true,array('title'=>$Lang['goods_open_vip'],'name'=>'open_vip','value'=>$options['open_vip'],'msg'=>$Lang['goods_open_vip_msg'],'item'=>$open_vip_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_vip_price'],'name'=>'vip_price','value'=>$options['vip_price'],'msg'=>$Lang['goods_vip_price_msg']),"input");
    
    $open_score_dikou_item = array(1=>$Lang['goods_open_score_dikou_1'],0=>$Lang['goods_open_score_dikou_0']);
    tomshowsetting(true,array('title'=>$Lang['goods_open_score_dikou'],'name'=>'open_score_dikou','value'=>$options['open_score_dikou'],'msg'=>$Lang['goods_open_score_dikou_msg'],'item'=>$open_score_dikou_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_score_num'],'name'=>'score_num','value'=>$options['score_num'],'msg'=>$Lang['goods_score_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_score_dikou_price'],'name'=>'score_dikou_price','value'=>$options['score_dikou_price'],'msg'=>$Lang['goods_score_dikou_price_msg']),"input");
    
    $show_stock_item = array(1=>$Lang['goods_show_stock_1'],0=>$Lang['goods_show_stock_0']);
    //tomshowsetting(true,array('title'=>$Lang['goods_show_stock'],'name'=>'show_stock','value'=>$options['show_stock'],'msg'=>$Lang['goods_show_stock_msg'],'item'=>$show_stock_item),"radio");
    $show_sales_item = array(1=>$Lang['goods_show_sales_1'],0=>$Lang['goods_show_sales_0']);
    //tomshowsetting(true,array('title'=>$Lang['goods_show_sales'],'name'=>'show_sales','value'=>$options['show_sales'],'msg'=>$Lang['goods_show_sales_msg'],'item'=>$show_sales_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_virtual_sales'],'name'=>'virtual_sales','value'=>$options['virtual_sales'],'msg'=>$Lang['goods_virtual_sales_msg']),"input");
    //tomshowsetting(true,array('title'=>$Lang['goods_virtual_clicks'],'name'=>'virtual_clicks','value'=>$options['virtual_clicks'],'msg'=>$Lang['goods_virtual_clicks_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_max_buy'],'name'=>'max_buy','value'=>$options['max_buy'],'msg'=>$Lang['goods_max_buy_msg']),"input");
    $hasoption_item = array(1=>$Lang['goods_hasoption_1'],0=>$Lang['goods_hasoption_0']);
    tomshowsetting(true,array('title'=>$Lang['goods_hasoption'],'name'=>'hasoption','value'=>$options['hasoption'],'msg'=>$Lang['goods_hasoption_msg'],'item'=>$hasoption_item),"radio");
    //tomshowsetting(true,array('title'=>$Lang['goods_weight'],'name'=>'weight','value'=>$options['weight'],'msg'=>$Lang['goods_weight_msg']),"input");

    $districtList = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid(0);
    $districtsStr = '<tr class="header"><th>'.$Lang['goods_district'].'</th><th></th></tr>';
    $districtsStr.= '<tr><td width="300"><select style="width: 150px;" name="province" id="province" onchange="getCity();">';
    if(!empty($options['province'])){
        $districtsStr.=  '<option value="'.$options['province'].'" selected>'.$options['province'].'</option>';
    }else{
        $districtsStr.= '<option value="">'.$Lang['goods_province'].'</option>';
    }
    foreach ($districtList as $key => $value){
        $districtsStr.=  '<option value="'.$value['name'].'">'.$value['name'].'</option>';
    }
    $districtsStr.= '</select>&nbsp;&nbsp;<select style="width: 150px;" name="city" id="city">';
    if(!empty($options['city'])){
        $districtsStr.=  '<option value="'.$options['city'].'">'.$options['city'].'</option>';
    }else{
        $districtsStr.=  '<option value="">'.$Lang['goods_city'].'</option>';
    }
    if(!empty($options['province'])){
        $cityList = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_list(" AND name='{$options['province']}' "," ORDER BY displayorder ASC,id DESC ",0,50);
        if(is_array($cityList) && !empty($cityList)){
            foreach ($cityList as $key => $value) {
                $districtsStr.=  '<option value="'.$value['name'].'">'.$value['name'].'</option>';
            }
        }
    }
    $districtsStr.= '</select></td><td>'.$Lang['goods_district_msg'].'</td></tr>';
    echo $districtsStr;
    
    tomshowsetting(true,array('title'=>$Lang['goods_keywords'],'name'=>'keywords','value'=>$options['keywords'],'msg'=>$Lang['goods_keywords_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_hexiao_pwd'],'name'=>'hexiao_pwd','value'=>$options['hexiao_pwd'],'msg'=>$Lang['goods_hexiao_pwd_msg']),"input");
    $allow_refund_item = array(1=>$Lang['open'],0=>$Lang['close']);
    tomshowsetting(true,array('title'=>$Lang['goods_allow_refund'],'name'=>'allow_refund','value'=>$options['allow_refund'],'msg'=>$Lang['goods_allow_refund_msg'],'item'=>$allow_refund_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_zhibo_roomid'],'name'=>'zhibo_roomid','value'=>$options['zhibo_roomid'],'msg'=>$Lang['goods_zhibo_roomid_msg']),"input");
    $status_item = array(1=>$Lang['goods_status_1'],0=>$Lang['goods_status_2']);
    tomshowsetting(true,array('title'=>$Lang['goods_status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['goods_status_msg'],'item'=>$status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['paixu'],'name'=>'gsort','value'=>$options['gsort'],'msg'=>$Lang['goods_paixu_msg']),"input");
    
    echo '</table>';
    // ********************************* tab_base end *********************************
    // ********************************* tab_content start *********************************
    echo '<table class="tb tb2 table-form" style="display:none;" id="tab_content">';
    
    echo '<tr><th>'.$Lang['goods_attr'].'</th></tr>'; 
    echo '<tr><td>'; 
    if($options['isrecommand'] == 1){
        echo '<label><input type="checkbox" name="isrecommand" value="1" checked>'.$Lang['goods_isrecommand'].'</label>';
    }else{
        echo '<label><input type="checkbox" name="isrecommand" value="1">'.$Lang['goods_isrecommand'].'</label>';
    }
    /*
    if($options['isnew'] == 1){
        echo '<label><input type="checkbox" name="isnew" value="1" checked>'.$Lang['goods_isnew'].'</label>';
    }else{
        echo '<label><input type="checkbox" name="isnew" value="1">'.$Lang['goods_isnew'].'</label>';
    }
    if($options['ishot'] == 1){
        echo '<label><input type="checkbox" name="ishot" value="1" checked>'.$Lang['goods_ishot'].'</label>';
    }else{
        echo '<label><input type="checkbox" name="ishot" value="1">'.$Lang['goods_ishot'].'</label>';
    }
    echo '</td><td>'.$Lang['goods_attr_msg'].'</td></tr>';
    
    echo '<tr><th>'.$Lang['goods_biaoqian'].'</th></tr>'; 
    if($options['seven'] == 1){
        echo '<tr><td><label><input type="checkbox" name="seven" value="1" checked>'.$Lang['goods_seven'].'</label>';
    }else{
        echo '<tr><td><label><input type="checkbox" name="seven" value="1">'.$Lang['goods_seven'].'</label>';
    }
    */
    echo '</td><td>'.$Lang['goods_attr_msg'].'</td></tr>';
    
    //tomshowsetting(true,array('title'=>$Lang['goods_labelname'],'name'=>'labelname','value'=>$options['labelname'],'msg'=>$Lang['goods_labelname_msg']),"textarea");
    
    $admin_edit_item = array(0=>$Lang['goods_admin_edit_0'],1=>$Lang['goods_admin_edit_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_admin_edit'],'name'=>'admin_edit','value'=>$options['admin_edit'],'msg'=>$Lang['goods_admin_edit_msg'],'item'=>$admin_edit_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['goods_content_msg']),"text");
    
    echo '</table>';
    // ********************************* tab_content end *********************************
    // ********************************* tab_taketype start *********************************

    echo '<table class="tb tb2 table-form" style="display:none;" id="tab_taketype">';
    $issendfree_item = array(0=>$Lang['goods_issendfree_0'],1=>$Lang['goods_issendfree_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_issendfree'],'name'=>'issendfree','value'=>$options['issendfree'],'msg'=>$Lang['goods_issendfree_msg'],'item'=>$issendfree_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_ednum'],'name'=>'ednum','value'=>$options['ednum'],'msg'=>$Lang['goods_ednum_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_edmoney'],'name'=>'edmoney','value'=>$options['edmoney'],'msg'=>$Lang['goods_edmoney_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_dispatch_price'],'name'=>'dispatch_price','value'=>$options['dispatch_price'],'msg'=>$Lang['goods_dispatch_price_msg']),"input");
    $dispatch_type_item = array(1=>$Lang['goods_dispatch_type_1'],2=>$Lang['goods_dispatch_type_2']);
    tomshowsetting(true,array('title'=>$Lang['goods_dispatch_type'],'name'=>'dispatch_type','value'=>$options['dispatch_type'],'msg'=>$Lang['goods_dispatch_type_msg'],'item'=>$dispatch_type_item),"radio");
    echo '</table>';
    // ********************************* tab_taketype end *********************************
    // ********************************* tab_fencheng start *********************************

    echo '<table class="tb tb2 table-form" style="display:none;" id="tab_fencheng">';
    tomshowsetting(true,array('title'=>$Lang['goods_yongjin_bili'],'name'=>'yongjin_bili','value'=>$options['yongjin_bili'],'msg'=>$Lang['goods_yongjin_bili_msg']),"input");
    $hehuoren_tg_open_item = array(0=>$Lang['goods_hehuoren_tg_open_0'],1=>$Lang['goods_hehuoren_tg_open_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_hehuoren_tg_open'],'name'=>'hehuoren_tg_open','value'=>$options['hehuoren_tg_open'],'msg'=>$Lang['goods_hehuoren_tg_open_msg'],'item'=>$hehuoren_tg_open_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_chuji_fc_scale'],'name'=>'chuji_fc_scale','value'=>$options['chuji_fc_scale'],'msg'=>$Lang['goods_chuji_fc_scale_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_zhongji_fc_scale'],'name'=>'zhongji_fc_scale','value'=>$options['zhongji_fc_scale'],'msg'=>$Lang['goods_zhongji_fc_scale_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_gaoji_fc_scale'],'name'=>'gaoji_fc_scale','value'=>$options['gaoji_fc_scale'],'msg'=>$Lang['goods_gaoji_fc_scale_msg']),"input");
    
    echo '</table>';
    // ********************************* tab_fencheng end *********************************
    
    $jsstr = <<<EOF
<script type="text/javascript">
function getChild(){
  var cate_id = jq("#cate_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcmall:ajax",
        data: "act=childcates&pid="+cate_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var cateChildHtml = '<option value="0">{$Lang['goods_cate_child_id']}</option>';
            jq.each(json,function(k,v){
                cateChildHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#cate_child_id").html(cateChildHtml);
            jq("#cate_child_id").show();
        }
    });
}
            
function getCity(){
  var province = jq("#province").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcmall:ajax",
        data: "act=childcitys&province="+province,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var cateChildHtml = '<option value="0">{$Lang['goods_city']}</option>';
            jq.each(json,function(k,v){
                cateChildHtml+= '<option value="'+v.name+'">'+v.name+'</option>';
            })
            jq("#city").html(cateChildHtml);
            jq("#city").show();
        }
    });
}

jq('.tab-ul li a').click(function(){
    jq(this).closest('li').addClass('active').siblings('li').removeClass('active');
    jq(jq(this).attr('tabid')).show().siblings('.table-form').hide();
});
</script>
EOF;
    echo $jsstr;
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['goods_edit'],"",true);
    }else{
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}