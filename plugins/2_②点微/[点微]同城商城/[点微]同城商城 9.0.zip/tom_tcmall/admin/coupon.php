<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=coupon'; 
$modListUrl = $adminListUrl.'&tmod=coupon';
$modFromUrl = $adminFromUrl.'&tmod=coupon';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcmall#tom_tcmall_coupon')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $couponInfo = C::t('#tom_tcmall#tom_tcmall_coupon')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($couponInfo);
        
        if($updateData['total_num'] < $couponInfo['lingqu_num']){
            cpmsg($Lang['coupon_edit_total_error'], $modListUrl, 'error');
        }
        
        C::t('#tom_tcmall#tom_tcmall_coupon')->update($couponInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($couponInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcmall#tom_tcmall_coupon')->delete_by_id($_GET['id']);
    C::t('#tom_tcmall#tom_tcmall_coupon_lingqu')->delete_by_coupon_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'coupon_lingqu'){
    
    $coupon_id  = intval($_GET['coupon_id'])>0? intval($_GET['coupon_id']):0;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $couponInfo = C::t("#tom_tcmall#tom_tcmall_coupon")->fetch_by_id($coupon_id);
    
    $where = " AND coupon_id = {$coupon_id} ";
    
    $pagesize = 20;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcmall#tom_tcmall_coupon_lingqu')->fetch_all_count($where);
    $lingquList = C::t('#tom_tcmall#tom_tcmall_coupon_lingqu')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&act=coupon_lingqu&coupon_id={$coupon_id}";
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $couponInfo['title'] .'&nbsp;&gt;&gt;&nbsp;'. $Lang['coupon_lingqu_list_title']. '</th></tr>';
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['coupon_lingqu_user'] . '</th>';
    echo '<th>' . $Lang['coupon_lingqu_status'] . '</th>';
    echo '<th>' . $Lang['coupon_lingqu_use_time'] . '</th>';
    echo '<th>' . $Lang['coupon_lingqu_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($lingquList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f00">(ID:'. $value['user_id'] .')</font></td>';
        
        if($value['status'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['coupon_lingqu_status_1'] . '</font></td>';
            echo '<td>' . dgmdate($value['use_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['coupon_lingqu_status_0'] . '</font></td>';
            echo '<td> -- </td>';
        }
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        
        echo '<td> -- </td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $id             = isset($_GET['id'])? intval($_GET['id']):0;
    $title          = !empty($_GET['title'])? addslashes($_GET['title']):'';
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = '';
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id}";
    }
    if(!empty($id)){
        $where.= " AND id={$id}";
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcmall#tom_tcmall_coupon')->fetch_all_count($where,$title);
    $couponList = C::t('#tom_tcmall#tom_tcmall_coupon')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize,$title);
    
//    showtableheader();
//    echo '<tr><th colspan="15" class="partition">' . $Lang['coupon_help_title'] . '</th></tr>';
//    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
//    echo '<li>' . $Lang['coupon_help_1'] . '</li>';
//    echo '</ul></td></tr>';
//    showtablefooter(); /*dism��taobao��com*/
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    if($site_id == 1){
        $sitesStr.=  '<option value="1" selected>'.$Lang['sites_one'].'</option>';
    }else{
        $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    }
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    echo '<tr><td width="100" align="right"><b>ID</b></td><td><input name="title" type="text" value="'.$id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['coupon_title'] . '</b></td><td><input name="title" type="text" value="'.$title.'" size="40" /></td></tr>';
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['coupon_title'] . '</th>';
    echo '<th>' . $Lang['coupon_tcshop'] . '</th>';
    echo '<th>' . $Lang['coupon_coupon_type'] . '</th>';
    echo '<th>' . $Lang['coupon_total_num'] . '</th>';
    echo '<th>' . $Lang['coupon_lingqu_num'] . '</th>';
    echo '<th>' . $Lang['coupon_full_price'] . '</th>';
    echo '<th>' . $Lang['coupon_reduce_price'] . '</th>';
    echo '<th>' . $Lang['coupon_max_lingqu_num'] . '</th>';
    echo '<th>' . $Lang['coupon_open_score'] . '</th>';
    echo '<th>' . $Lang['coupon_is_yikatong'] . '</th>';
    echo '<th>' . $Lang['coupon_is_hehuoren'] . '</th>';
    echo '<th>' . $Lang['coupon_start_time'] . '</th>';
    echo '<th>' . $Lang['coupon_end_time'] . '</th>';
    echo '<th>' . $Lang['coupon_status'] . '</th>';
    echo '<th>' . $Lang['coupon_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($couponList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $value['title'] . '<font color="#fd0d0d">(ID:' . $value['id'] . ')</font></td>';
        echo '<td>' . $tcshopInfo['name'] .'<font color="#f00">(ID:'. $value['tcshop_id'] .')</font></td>';
        if($value['coupon_type'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['coupon_coupon_type_1'] . '</font></td>';
        }else if($value['coupon_type'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['coupon_coupon_type_2'] . '</font></td>';
        }
        echo '<td><font color="#238206">' . $value['total_num'] . '</font></td>';
        echo '<td><font color="#238206">' . $value['lingqu_num'] . '</font></td>';
        echo '<td><font color="#f00">' . $value['full_price'] . '</font></td>';
        echo '<td><font color="#f00">' . $value['reduce_price'] . '</font></td>';
        echo '<td><font color="#f00">' . $value['max_lingqu_num'] . '</font></td>';
        if($value['open_score'] == 1){
            echo '<td><font color="#fd0d0d">' . $value['pay_score'] .$Lang['coupon_score'] . '</font></td>';
        }else{
            echo '<td><font color="#8e8e8e">' . $Lang['coupon_open_score_0'] . '</font></td>';
        }
        if($value['is_yikatong'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['coupon_yes'] . '</font></td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['coupon_no'] . '</font></td>';
        }
        if($value['is_hehuoren'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['coupon_yes'] . '</font></td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['coupon_no'] . '</font></td>';
        }
        echo '<td>' . dgmdate($value['start_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '<td>' . dgmdate($value['end_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        if($value['status'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['coupon_status_1'] . '</font></td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['coupon_status_0'] . '</font></td>';
        }
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['coupon_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=coupon_lingqu&coupon_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['coupon_lingqu_list_title']. '</a><br/>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    if($_GET['act'] == 'add'){
        $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    }
    $coupon_type        = isset($_GET['coupon_type'])? intval($_GET['coupon_type']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $total_num          = isset($_GET['total_num'])? intval($_GET['total_num']):0;
    $full_price         = isset($_GET['full_price'])? floatval($_GET['full_price']):0.00;
    $reduce_price       = isset($_GET['reduce_price'])? floatval($_GET['reduce_price']):0.00;
    $max_lingqu_num     = isset($_GET['max_lingqu_num'])? intval($_GET['max_lingqu_num']):0;
    $is_yikatong        = isset($_GET['is_yikatong'])? intval($_GET['is_yikatong']):0;
    $is_hehuoren        = isset($_GET['is_hehuoren'])? intval($_GET['is_hehuoren']):0;
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = strtotime($end_time);
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $open_score         = isset($_GET['open_score'])? intval($_GET['open_score']):0;
    $pay_score          = isset($_GET['pay_score'])? intval($_GET['pay_score']):0;

    $goodsIdsArr = array();
    if(is_array($_GET['goods_ids']) && !empty($_GET['goods_ids'])){
        foreach($_GET['goods_ids'] as $key => $value){
            if(!empty($value)){
                $goodsIdsArr[] = intval($value);
            }
        }
    }
    $goodsIdsStr = '';
    if(is_array($goodsIdsArr) && !empty($goodsIdsArr)){
        $goodsIdsStr = implode('|', $goodsIdsArr);
    }

    if($_GET['act'] == 'add'){
        
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
        
        $data['site_id']            = $tcshopInfo['site_id'];
        $data['user_id']            = $tcshopInfo['user_id'];
        $data['tcshop_id']          = $tcshopInfo['id'];
    }
    $data['coupon_type']        = $coupon_type;
    if($coupon_type == 2){
        $data['goods_ids']          = $goodsIdsStr;
    }else{
        $data['goods_ids']          = '';
    }
    $data['title']              = $title;
    $data['total_num']          = $total_num;
    $data['full_price']         = $full_price;
    $data['reduce_price']       = $reduce_price;
    $data['max_lingqu_num']     = $max_lingqu_num;
    $data['is_yikatong']        = $is_yikatong;
    $data['is_hehuoren']        = $is_hehuoren;
    $data['start_time']         = $start_time;
    $data['end_time']           = $end_time;
    $data['status']             = $status;
    $data['content']            = $content;
    
    $data['open_score']         = $open_score;
    $data['pay_score']          = $pay_score;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'title'             => '',
        'tcshop_id'         => 0,
        'goods_ids'         => '',
        'coupon_type'       => 1,
        'total_num'         => 0,
        'full_price'        => 0.00,
        'reduce_price'      => 0.00,
        'max_lingqu_num'    => 0,
        'is_yikatong'       => 0,
        'is_hehuoren'       => 0,
        'start_time'        => time(),
        'end_time'          => time(),
        'open_score'        => 0,
        'pay_score'         => 0,
        'status'            => 0,
        'content'           => '',
    );
    $options = array_merge($options, $infoArr);
    
    if($_GET['act'] == 'add'){
        tomshowsetting(true,array('title'=>$Lang['tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['tcshop_id_msg']),"input");
    }
    tomshowsetting(true,array('title'=>$Lang['coupon_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['coupon_title_msg']),"input");
    $coupon_type_item = array(1=>$Lang['coupon_coupon_type_1'],2=>$Lang['coupon_coupon_type_2']);
    tomshowsetting(true,array('title'=>$Lang['coupon_coupon_type'],'name'=>'coupon_type','value'=>$options['coupon_type'],'msg'=>$Lang['coupon_coupon_type_msg'],'item'=>$coupon_type_item),"radio");
    
    $goodsList = array();
    if($options['tcshop_id'] > 0){
        $goodsList = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND tcshop_id={$options['tcshop_id']} "," ORDER BY id DESC ",0,1000);
        $goodsIdsArr = array();
        if(!empty($options['goods_ids'])){
            $goodsIdsArr = explode('|', $options['goods_ids']);
        }
    }
    $goodsStr = '<tr class="header"><th>'.$Lang['coupon_goods_ids'].'</th><th></th></tr>';
    $goodsStr.= '<tr><td width="300" colspan="2" ><div id="goods_ids">';
    foreach ($goodsList as $key => $value){
        if(in_array($value['id'], $goodsIdsArr)){
            $goodsStr.=  '<label><input type="checkbox" name="goods_ids[]" value="'.$value['id'].'" checked>'.$value['title'].'</label><br/>';
        }else{
            $goodsStr.=  '<label><input type="checkbox" name="goods_ids[]" value="'.$value['id'].'">'.$value['title'].'</label><br/>';
        }
    }
    $goodsStr.= '</div></td></tr>';
    echo $goodsStr;
    
    tomshowsetting(true,array('title'=>$Lang['coupon_total_num'],'name'=>'total_num','value'=>$options['total_num'],'msg'=>$Lang['coupon_total_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['coupon_full_price'],'name'=>'full_price','value'=>$options['full_price'],'msg'=>$Lang['coupon_full_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['coupon_reduce_price'],'name'=>'reduce_price','value'=>$options['reduce_price'],'msg'=>$Lang['coupon_reduce_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['coupon_max_lingqu_num'],'name'=>'max_lingqu_num','value'=>$options['max_lingqu_num'],'msg'=>$Lang['coupon_max_lingqu_msg']),"input");
    
    $coupon_item = array(0=>$Lang['coupon_no'],1=>$Lang['coupon_yes']);
    tomshowsetting(true,array('title'=>$Lang['coupon_is_yikatong'],'name'=>'is_yikatong','value'=>$options['is_yikatong'],'msg'=>$Lang['coupon_is_yikatong_msg'],'item'=>$coupon_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['coupon_is_hehuoren'],'name'=>'is_hehuoren','value'=>$options['is_hehuoren'],'msg'=>$Lang['coupon_is_hehuoren_msg'],'item'=>$coupon_item),"radio");
    
    tomshowsetting(true,array('title'=>$Lang['coupon_start_time'],'name'=>'start_time','value'=>$options['start_time'],'msg'=>$Lang['coupon_start_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['coupon_end_time'],'name'=>'end_time','value'=>$options['end_time'],'msg'=>$Lang['coupon_end_time_msg']),"calendar");
    $coupon_status_item = array(0=>$Lang['coupon_status_0'],1=>$Lang['coupon_status_1']);
    tomshowsetting(true,array('title'=>$Lang['coupon_status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['coupon_status_msg'],'item'=>$coupon_status_item),"radio");
    $coupon_open_score_item = array(0=>$Lang['coupon_open_score_0'],1=>$Lang['coupon_open_score_1']);
    tomshowsetting(true,array('title'=>$Lang['coupon_open_score'],'name'=>'open_score','value'=>$options['open_score'],'msg'=>$Lang['coupon_open_score_msg'],'item'=>$coupon_open_score_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['coupon_pay_score'],'name'=>'pay_score','value'=>$options['pay_score'],'msg'=>$Lang['coupon_pay_score_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['coupon_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['coupon_content_msg']),"textarea");
    
    $jsstr = <<<EOF
<script type="text/javascript">
jq(document).on("blur", 'input[name="tcshop_id"]', function(){
    var tcshop_id = jq('input[name="tcshop_id"]').val();
    jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcmall:ajax",
        data: "act=admin_shopgoods&tcshop_id="+tcshop_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var goodsHtml = '';
            jq.each(json,function(k,v){ 
                goodsHtml+= '<label><input type="checkbox" name="goods_ids[]" value="'+v.id+'">'+v.title+'</label><br/>';
            })
            jq("#goods_ids").html(goodsHtml);
            //jq("#goods_ids").show();
        }
    });
   
})
function getChild(){
  
}
</script>
EOF;
    echo $jsstr;
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['coupon_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['coupon_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['coupon_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['coupon_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['coupon_edit'],"",true);
    }else{
        tomshownavli($Lang['coupon_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['coupon_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}