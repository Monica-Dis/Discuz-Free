<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=order';
$modListUrl = $adminListUrl.'&tmod=order';
$modFromUrl = $adminFromUrl.'&tmod=order';

$get_list_url_value = get_list_url("tom_tcmall_admin_order_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'info'){
    
    $info = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_id($_GET['id']);
    $infoGoodsList = C::t("#tom_tcmall#tom_tcmall_order_goods")->fetch_all_list(" AND order_id = {$info['id']} ", 'ORDER BY id DESC', 0, 100);
    if(submitcheck('submit')){
        $order_status = intval($_GET['order_status']);
        $updateData = array();
        $updateData['order_status'] = $order_status;
        C::t('#tom_tcmall#tom_tcmall_order')->update($_GET['id'],$updateData);
        
        DB::query("UPDATE ".DB::table('tom_tcmall_order_goods')." SET order_status={$order_status} WHERE order_id={$_GET['id']} AND order_status != 7", 'UNBUFFERED');
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        
        $address = unserialize($info['address']);
        $fenghao = $Lang['fenghao'];
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_goods_title'] . '</th></tr>';
        echo '<tr>';
        echo '<th><b>'.$Lang['order_goods_name'].'</b></th>';
        echo '<th><b>'.$Lang['order_goods_num'].'</b></th>';
        echo '<th><b>'.$Lang['order_is_vip'].'</b></th>';
        echo '<th><b>'.$Lang['order_goods_price'].'</b></th>';
        echo '<th><b>'.$Lang['order_dispatch_price'].'</b></th>';
        echo '<th><b>'.$Lang['order_refund_status'].'</b></th>';
        echo '</tr>';
        
        foreach($infoGoodsList as $key => $value){
            $goodsInfoTmp = C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($value['goods_id']);
            
            echo '<tr>';
            echo '<th>'.$goodsInfoTmp['title'].'</th>';
            echo '<th>'.$value['goods_num'].'</th>';
            if($value['is_vip'] == 1){
                echo '<th>'.$Lang['order_is_vip_1'].'</th>';
            }else{
                echo '<th>'.$Lang['order_is_vip_0'].'</th>';
            }
            echo '<th>'.$value['real_price'].'</th>';
            echo '<th>'.$value['dispatch_price'].'</th>';
            if($value['order_status'] == 7){
                echo '<th><font color="#f00">'.$Lang['order_refund_status_1'].'</font></th>';
            }else{
                echo '<th> -- </th>';
            }
            echo '</tr>';
        }
        
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_order_title'] . '</th></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_no'].$fenghao.'</b></td><td>'.$info['order_no'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_pay_price'].$fenghao.'</b></td><td>'.$info['pay_price'].'</td></tr>';
        if($info['coupon_lingqu_id'] > 0){
            $lingquInfo = C::t("#tom_tcmall#tom_tcmall_coupon_lingqu")->fetch_by_id($info['coupon_lingqu_id']);
            $couponInfo = C::t("#tom_tcmall#tom_tcmall_coupon")->fetch_by_id($lingquInfo['coupon_id']);
            echo '<tr><td align="right"><b>'.$Lang['order_coupon'].$fenghao.'</b></td><td>'.$couponInfo['title'].' (ID:'.$lingquInfo['coupon_id'].')</td></tr>';
            echo '<tr><td align="right"><b>'.$Lang['order_coupon_reduce_price'].$fenghao.'</b></td><td>-'.$info['coupon_reduce_price'].'</td></tr>';
        }
        if($info['score_dikou_price'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['order_score_num'].$fenghao.'</b></td><td>'.$info['score_num'].'</td></tr>';
            echo '<tr><td align="right"><b>'.$Lang['order_score_dikou_price'].$fenghao.'</b></td><td>-'.$info['score_dikou_price'].'</td></tr>';
        }
        
        if($info['huodao_pay_status'] == 1){
            if($info['order_status'] == 8){
                echo '<tr><td align="right"><b>'.$Lang['order_order_status'].$fenghao.'</b></td><td><b><font color="'.$orderStatusColorArray[$info['order_status']].'">' .$orderStatusArray[$info['order_status']]. '</font></b></td></tr>';
            }else{
                echo '<tr><td align="right"><b>'.$Lang['order_order_status'].$fenghao.'</b></td><td><b><font color="'.$orderStatusColorArray[$info['order_status']].'">' .$orderStatusArray[$info['order_status']].'('. $Lang['order_huodao_pay_status'] .')'. '</font></b></td></tr>';
            }
        }else{
            echo '<tr><td align="right"><b>'.$Lang['order_order_status'].$fenghao.'</b></td><td><b><font color="'.$orderStatusColorArray[$info['order_status']].'">' . $orderStatusArray[$info['order_status']] . '</font></b></td></tr>';
        }
        
        if($info['order_status'] == 3){
            echo '<tr><td align="right"><b>'.$Lang['order_fahuo_time'].$fenghao.'</b></td><td>'.dgmdate($info['peisong_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
        }
        echo '<tr><td align="right"><b>'.$Lang['order_order_time'].$fenghao.'</b></td><td>'.dgmdate($info['order_time'], 'm-d H:i:s',$tomSysOffset).'</td></tr>';
        if($info['pay_time'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['order_pay_time'].$fenghao.'</b></td><td>'.dgmdate($info['pay_time'], 'm-d H:i:s',$tomSysOffset).'</td></tr>';
        }else{
            echo '<tr><td align="right"><b>'.$Lang['order_pay_time'].$fenghao.'</b></td><td>-</td></tr>';
        }
        
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_user_title'] . '</th></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_xm'].$fenghao.'</b></td><td>'.$info['address_xm'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_tel'].$fenghao.'</b></td><td>'.$info['address_tel'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_address'].$fenghao.'</b></td><td>'.$info['address_str'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_beizu'].$fenghao.'</b></td><td>'.$info['order_beizu'].'</td></tr>';
        if($info['peisong_type'] == 1){
            echo '<tr><td align="right"><b>'.$Lang['goods_peisong_type'].$fenghao.'</b></td><td>'.$Lang['goods_peisong_type_1'].'</td></tr>';
        }else if($info['peisong_type'] == 2){
            echo '<tr><td align="right"><b>'.$Lang['goods_peisong_type'].$fenghao.'</b></td><td>'.$Lang['goods_peisong_type_2'].'</td></tr>';
            echo '<tr><td align="right"><b>'.$Lang['order_peisong_name2'].$fenghao.'</b></td><td>'.$info['peisong_name'].'</td></tr>';
            echo '<tr><td align="right"><b>'.$Lang['order_peisong_info2'].$fenghao.'</b></td><td>'.$info['peisong_info'].'</td></tr>';
        }else if($info['peisong_type'] == 3){
            echo '<tr><td align="right"><b>'.$Lang['goods_peisong_type'].$fenghao.'</b></td><td>'.$Lang['goods_peisong_type_3'].'</td></tr>';
            echo '<tr><td align="right"><b>'.$Lang['order_peisong_name3'].$fenghao.'</b></td><td>'.$info['peisong_name'].'</td></tr>';
            echo '<tr><td align="right"><b>'.$Lang['order_peisong_info3'].$fenghao.'</b></td><td>'.$info['peisong_info'].'</td></tr>';
        }
        if($info['hexiao_time'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['order_hexiao_time'].$fenghao.'</b></td><td>'.dgmdate($info['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
        }else{
            echo '<tr><td align="right"><b>'.$Lang['order_hexiao_time'].$fenghao.'</b></td><td>-</td></tr>';
        }
        
        showtablefooter(); /*dism��taobao��com*/
        showformheader($modFromUrl.'&act=info&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_edit'] . '</th></tr>';
        showtablefooter(); /*dism��taobao��com*/
        showtableheader();
        echo '<tr><td align="right"><b>'.$Lang['order_order_status'].$fenghao.'</b></td><td>';
        foreach ($orderStatusArray as $key => $value){
            if($key == $info['order_status']){
                echo '<label><input type="radio" name="order_status" value="'.$key.'" checked><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b></label>&nbsp;';
            }else{
                echo '<label><input type="radio" name="order_status" value="'.$key.'" ><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b></label>&nbsp;';
            }
        }
        echo '</td></tr>';
        echo '<tr><td>&nbsp;</td><td colspan="14" ><b><font color="#fd0303">(' . $Lang['order_order_status_msg'] . ')</font></b></td></tr>';
        tomshowsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcmall#tom_tcmall_order')->delete_by_id($_GET['id']);
    C::t('#tom_tcmall#tom_tcmall_order_goods')->delete_by_order_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'all_qianshou'){
    
    $type   = isset($_GET['type'])? intval($_GET['type']):1;
    $page   = isset($_GET['page'])? intval($_GET['page']):1;
    $nextpage = $page + 1;
    
    $tomPlugin = C::t('#tom_tcshop#common_plugin')->fetch_by_identifier('tom_tchehuoren');
    $_G['cache']['plugin']['tom_tchehuoren'] = get_plugin_config($tomPlugin['pluginid']);
    
    $tomPlugin = C::t('#tom_tcshop#common_plugin')->fetch_by_identifier('tom_tcadmin');
    $_G['cache']['plugin']['tom_tcadmin'] = get_plugin_config($tomPlugin['pluginid']);
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $weixinClass = new weixinClass($appid,$appsecret);
    
    $qianshouTime = TIMESTAMP - (86400 * $tcmallConfig['goods_autoreceive']);
    $where = " AND order_status = 3 AND peisong_time <= {$qianshouTime}";
    
    $count = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count($where);
    $orderInfoTmp = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_list($where, "ORDER BY order_time DESC,id DESC", 0, 1);
    if($count > 0 && is_array($orderInfoTmp) && !empty($orderInfoTmp[0])){
        $orderInfo = $orderInfoTmp[0];
        
        $goodsOrderListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 1000);
        if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
            foreach($goodsOrderListTmp as $key => $value){
                if($value['order_status'] == 2 || $value['order_status'] == 3){
                    $goodsRefundInfoTmp = C::t('#tom_tcmall#tom_tcmall_refund')->fetch_all_list("AND order_id = {$orderInfo['id']} AND order_goods_id = {$value['id']} AND refund_status = 1 ", 'ORDER BY id DESC', 0, 1);
                    if(is_array($goodsRefundInfoTmp) && !empty($goodsRefundInfoTmp[0])){
                        $orderInfoUrl = $modListUrl.'&order_no='.$orderInfo['order_no'];
                        cpmsg($Lang['order_refund_msg'], $orderInfoUrl, 'error');exit;
                    }
                }
            }
        }
        
        $updateData = array();
        $updateData['order_status']     = 4;
        $updateData['hexiao_user_id']   = $tongchengConfig['manage_user_id'];
        $updateData['hexiao_time']      = TIMESTAMP;
        if(C::t('#tom_tcmall#tom_tcmall_order')->update($orderInfo['id'],$updateData)){
            if(is_array($goodsOrderListTmp) && !empty($goodsOrderListTmp)){
                foreach($goodsOrderListTmp as $gk => $gv){
                    if($gv['order_status'] == 3 || $gv['order_status'] == 2){
                        $updateData = array();
                        $updateData['order_status'] = 4;
                        C::t('#tom_tcmall#tom_tcmall_order_goods')->update($gv['id'],$updateData);
                    }
                }
            }
        }

        if($orderInfo['balance_status'] == 0 && $orderInfo['huodao_pay_status'] == 0){
            include DISCUZ_ROOT.'./source/plugin/tom_tcmall/module/balance.php';
        }
        $count--;
        $qianshou_do_msg = str_replace("{PAGES}", $page, $Lang['qianshou_do_msg']);
        $qianshou_do_msg = str_replace("{COUNT}", $count, $qianshou_do_msg);
        
        $modQianshouListUrl = $modListUrl.'&act=all_qianshou&page='.$nextpage.'&formhash='.FORMHASH;
        cpmsg($qianshou_do_msg, $modQianshouListUrl, 'loadingform');
        
    }else{
        cpmsg($Lang['qianshou_do_success'], $modListUrl, 'succeed');
    }
    
}else{
    
    tomloadcalendarjs();
    set_list_url("tom_tcmall_admin_order_list");
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $order_no       = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
    $pay_order_no   = !empty($_GET['pay_order_no'])? addslashes($_GET['pay_order_no']):'';
    $order_tel      = !empty($_GET['order_tel'])? trim(addslashes($_GET['order_tel'])):'';
    $order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;
    $tcshop_id      = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $hexiao_user_id = isset($_GET['hexiao_user_id'])? intval($_GET['hexiao_user_id']):0;
    $start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    
    $where = "";
    if(!empty($order_no)){
        $where.=" AND order_no='{$order_no}' ";
    }
    if(!empty($pay_order_no)){
        $where.=" AND pay_order_no='{$pay_order_no}' ";
    }
    if(!empty($order_status)){
        $where.=" AND order_status={$order_status} ";
    }
    if(!empty($tcshop_id)){
        $where.=" AND tcshop_id={$tcshop_id} ";
    }
    if(!empty($order_tel)){
        $where.=" AND address_tel={$order_tel} ";
    }
    if(!empty($hexiao_user_id)){
        $where.=" AND hexiao_user_id={$hexiao_user_id} ";
    }
    if(!empty($start_time)){
        $startTime = strtotime($start_time);
        $where.=" AND order_time >=  {$startTime} ";
    }
    if(!empty($end_time)){
        $endTime = strtotime($end_time);
        $where.=" AND order_time < {$endTime} ";
    }

    $modBasePageUrl = $modBaseUrl."&order_no={$order_no}&order_tel={$order_tel}&order_status={$order_status}&tcshop_id={$tcshop_id}&hexiao_user_id={$hexiao_user_id}&start_time={$start_time}&end_time={$end_time}";
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count($where,'');
    $orderCount = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count($where);
    $orderList = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_list($where,"ORDER BY order_time DESC",$start,$pagesize,'');
    $fenghao = $Lang['fenghao'];
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_search_list'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_tcshop_id'] . '</b></td><td><input name="tcshop_id" type="text" value="'.$tcshop_id.'" size="40" /><font color="#fd0d0d">' . $Lang['order_tcshop_id_msg'] . '</font></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_order_no'] . '</b></td><td><input name="order_no" type="text" value="'.$order_no.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_pay_order_no'] . '</b></td><td><input name="pay_order_no" type="text" value="'.$pay_order_no.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_tel'] . '</b></td><td><input name="order_tel" type="text" value="'.$order_tel.'" size="40" /></td></tr>';
    //echo '<tr><td width="100" align="right"><b>hexiao_user_id</b></td><td><input name="hexiao_user_id" type="text" value="'.$hexiao_user_id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_order_status'] . '</b></td><td><select name="order_status" >';
    echo '<option value="0">'.$Lang['order_order_status'].'</option>';
    foreach ($orderStatusArray as $key => $value){
        if($key == $order_status){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select></td></tr>';
    
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_start_time'] . '</b></td><td width="300"><input name="start_time" type="text" value="'.$start_time.'" onclick="showcalendar(event, this, 1)" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_end_time'] . '</b></td><td width="300"><input name="end_time" type="text" value="'.$end_time.'" onclick="showcalendar(event, this, 1)" size="40" /></td></tr>';
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    if($tcshop_id > 0){
        $countOrderStatus1 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id={$tcshop_id} AND order_status=1 ");
        $countOrderStatus2 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id={$tcshop_id} AND order_status=2 ");
        $countOrderStatus4 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id={$tcshop_id} AND order_status=4 ");
        $countOrderStatus5 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id={$tcshop_id} AND order_status=5 ");
        $countOrderStatus6 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id={$tcshop_id} AND order_status=6 ");
        $countOrderStatus7 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id={$tcshop_id} AND order_status=7 ");
        echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
        echo $orderStatusArray[1].'<font color="#fd0d0d">('.$countOrderStatus1.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[2].'<font color="#fd0d0d">('.$countOrderStatus2.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[4].'<font color="#fd0d0d">('.$countOrderStatus4.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[5].'<font color="#fd0d0d">('.$countOrderStatus5.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[6].'<font color="#fd0d0d">('.$countOrderStatus6.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[7].'<font color="#fd0d0d">('.$countOrderStatus7.')</font>&nbsp;&nbsp;';
        echo '</div>';
        if(!empty($order_status)){
            echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
            echo '<b>'.$Lang['order_search_count_msg1'].'</b>'.$Lang['order_search_count_msg2'].'<font color="#fd0d0d">('.$count.')</font>';
            echo '</div>';
        }
        tomshownavheader();
        tomshownavli($Lang['order_export'],$_G['siteurl']."plugin.php?id=tom_tcmall:ordersexport&order_no={$order_no}&order_tel={$order_tel}&order_status={$order_status}&tcshop_id={$tcshop_id}&start_time={$start_time}&end_time={$end_time}",false);
        if($count > 5000){
            tomshownavli($Lang['order_export'].'(page:2)',$_G['siteurl']."plugin.php?id=tom_tcmall:ordersexport&order_no={$order_no}&order_tel={$order_tel}&order_status={$order_status}&tcshop_id={$tcshop_id}&start_time={$start_time}&end_time={$end_time}&page=2",false);
        }
        if($count > 10000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcmall:ordersexport&order_no={$order_no}&order_tel={$order_tel}&order_status={$order_status}&tcshop_id={$tcshop_id}&start_time={$start_time}&end_time={$end_time}&page=3",false);
        }
        if($count > 15000){
            tomshownavli($Lang['order_export'].'(page:4)',$_G['siteurl']."plugin.php?id=tom_tcmall:ordersexport&order_no={$order_no}&order_tel={$order_tel}&order_status={$order_status}&tcshop_id={$tcshop_id}&start_time={$start_time}&end_time={$end_time}&page=4",false);
        }
        if($count > 20000){
            tomshownavli($Lang['order_export'].'(page:5)',$_G['siteurl']."plugin.php?id=tom_tcmall:ordersexport&order_no={$order_no}&order_tel={$order_tel}&order_status={$order_status}&tcshop_id={$tcshop_id}&start_time={$start_time}&end_time={$end_time}&page=5",false);
        }
        if($count > 25000){
            tomshownavli($Lang['order_export'].'(page:6)',$_G['siteurl']."plugin.php?id=tom_tcmall:ordersexport&order_no={$order_no}&order_tel={$order_tel}&order_status={$order_status}&tcshop_id={$tcshop_id}&start_time={$start_time}&end_time={$end_time}&page=6",false);
        }
        tomshownavfooter();
    }
    tomshownavheader();
    $qianshouTime = TIMESTAMP - (86400 * $tcmallConfig['goods_autoreceive']);
    $qianshouCount = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND order_status = 3 AND peisong_time <= {$qianshouTime}");
    tomshownavli($Lang['order_all_qianshou']."({$qianshouCount})", $modBaseUrl."&act=all_qianshou&formhash=".FORMHASH, false);
    tomshownavfooter();
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return order_form();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />'.
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    //echo '<th width="10">&nbsp;</th>';
    echo '<th width="240">' . $Lang['order_goods_name'] . '</th>';
    echo '<th>' . $Lang['order_pay_price'] . '</th>';
    echo '<th>' . $Lang['order_user_nickname'] . '</th>';
    echo '<th>' . $Lang['order_order_status'] . '</th>';
    echo '<th>' . $Lang['goods_peisong_type'] . '</th>';
    echo '<th width="120">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($orderList as $key => $value){
        
        $orderGoodsList = C::t("#tom_tcmall#tom_tcmall_order_goods")->fetch_all_list(" AND order_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);
        $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        
        $site_name_tmp = $Lang['sites_one'];
        if($value['site_id'] > 1){
            $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
            $site_name_tmp = $siteInfoTmp['name'];
        }

        echo '<tr style="background-color: #E4FAF7;">';
        echo '<td colspan="2">' . $Lang['order_order_no'] . '&nbsp;:&nbsp;' . $value['order_no'] . '<br/>' . $Lang['order_pay_order_no'] . '&nbsp;:&nbsp;' . $value['pay_order_no'] . '</td>';
        echo '<td colspan="3">' . $Lang['order_order_time'] . '&nbsp;:&nbsp;' . dgmdate($value['order_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        if($value['hexiao_time'] > 0){
            echo '<td colspan="3">' . $Lang['order_hexiao_time'] . '&nbsp;:&nbsp;' . dgmdate($value['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset). '</td>';
        }else{
            echo '<td colspan="3">' . $Lang['order_hexiao_time'] . '&nbsp;:&nbsp; - </td>';
        }
        /*
        if($value['tj_hehuoren_id'] > 0){
            echo '<td colspan="10">' . $Lang['order_tj_hehuoren_id'] . '&nbsp;:&nbsp; ' . $value['tj_hehuoren_id'] . ' </td>';
        }else{
            echo '<td colspan="10">' . $Lang['order_tj_hehuoren_id'] . '&nbsp;:&nbsp; - </td>';
        }*/
        echo '</tr>';
        
        echo '<tr style="height: 60px;">';
        //echo '<td><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" ></td>';
        
        echo '<td ><ul>';
        foreach($orderGoodsList as $gk => $gv){
            $goodsInfoTmp =  C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($gv['goods_id']);
            $option_name_tmp = '';
            if(!empty($gv['option_name'])){
                $option_name_tmp = '<font color="#0894fb">(' . $gv['option_name'] . ')</font>';
            }
            $tj_hehuoren_id_str = '';
            if($gv['tj_hehuoren_id'] > 0){
                $tj_hehuoren_id_str = '<font color="#0894fb">('.$Lang['order_tj_hehuoren_id']. ':'.$gv['tj_hehuoren_id'].')</font>';
            }
            echo '<li style="width: 400px;line-height: 20px;padding: 5px 5px;margin-bottom: 5px;border-left: 2px solid #FF9800;">' .'<font color="#0894fb">['.$site_name_tmp.']</font> '. $goodsInfoTmp['title'] .$option_name_tmp.'(ID:' . $gv['goods_id'] . ')&nbsp;&nbsp;&nbsp;'.$gv['price'].'&nbsp;&nbsp;&nbsp; x'.$gv['goods_num'].'&nbsp;&nbsp;&nbsp;'.$tj_hehuoren_id_str.'</li>';
        }
        echo '</ul></td>';
        
        if($value['coupon_lingqu_id'] > 0){
            $lingquInfo = C::t("#tom_tcmall#tom_tcmall_coupon_lingqu")->fetch_by_id($value['coupon_lingqu_id']);
            $couponInfo = C::t("#tom_tcmall#tom_tcmall_coupon")->fetch_by_id($lingquInfo['coupon_id']);
            echo '<td><font color="#009900">' . $value['pay_price'] .'</font><font color="#f00">(-'.$value['coupon_reduce_price']. ' '.$Lang['order_coupon'].'ID:'.$lingquInfo['coupon_id'].')</font></td>';
        }else{
            echo '<td><font color="#009900">' . $value['pay_price'] . '</font></td>';
        }
        echo '<td>' . $userInfo['nickname'] . '(UID:'.$value['user_id'].')</td>';
        echo '<td>';
        echo '<b><font color="'.$orderStatusColorArray[$value['order_status']].'">' . $orderStatusArray[$value['order_status']] . '</font></b>';
        if($value['hexiao_time'] > 0){
            echo '<br/><font color="#fd0d0d">'.$hexiaoUserInfo['nickname'].'(ID:'.$hexiaoUserInfo['id'].')</font><br/>';
        }
        echo '</td>';
        if($value['peisong_type'] == 1){
            echo '<td>' . $Lang['goods_peisong_type_1'] . '</td>'; 
        }else if($value['peisong_type'] == 2){
            echo '<td><b>' . $Lang['goods_peisong_type_2'] . '</b></td>'; 
        }else if($value['peisong_type'] == 3){
            echo '<td><b>' . $Lang['goods_peisong_type_3'] .'<font color="#f00">('.$Lang['order_dispatch_price']. '&nbsp;:&nbsp;' .floatval($value['dispatch_price']). ')</font></b></td>'; 
        }
        echo '<td style="line-height: 30px;">';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['order_info'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    
    $formstr = <<<EOF
        <!--<tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="refund">{$Lang['batch_refund']}</option>
                    <option value="refundquery">{$Lang['batch_refundquery']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>-->
        <script type="text/javascript">
        function order_form(){
          var r = confirm("{$Lang['batch_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
        </script>
EOF;
    
    echo $formstr;
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
}