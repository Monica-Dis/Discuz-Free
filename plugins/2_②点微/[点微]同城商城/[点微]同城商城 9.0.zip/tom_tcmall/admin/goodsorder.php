<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=goodsorder';
$modListUrl = $adminListUrl.'&tmod=goodsorder';
$modFromUrl = $adminFromUrl.'&tmod=goodsorder';

$get_list_url_value = get_list_url("tom_tcmall_admin_order_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'info'){

    $info = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_by_id($_GET['id']);
    $infoGoodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($info['goods_id']); 
    $infoOrderInfo = C::t("#tom_tcmall#tom_tcmall_order")->fetch_by_id($info['order_id']);
    if(submitcheck('submit')){
        $order_status = intval($_GET['order_status']);
        $updateData = array();
        $updateData['order_status'] = $order_status;
        C::t('#tom_tcmall#tom_tcmall_order')->update($_GET['id'],$updateData);
        
        DB::query("UPDATE ".DB::table('tom_tcmall_order_goods')." SET order_status={$order_status} WHERE order_id={$_GET['id']}", 'UNBUFFERED');
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        
        $fenghao = $Lang['fenghao'];
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_goods_title'] . '</th></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_goods_name'].$fenghao.'</b></td><td>'.$infoGoodsInfo['title'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_goods_num'].$fenghao.'</b></td><td>'.$info['goods_num'].'</td></tr>';
        if($info['is_vip'] == 1){
            echo '<tr><td align="right"><b>'.$Lang['order_is_vip'].$fenghao.'</b></td><td>'.$Lang['order_is_vip_1'].'</td></tr>';
        }else{
            echo '<tr><td align="right"><b>'.$Lang['order_is_vip'].$fenghao.'</b></td><td>'.$Lang['order_is_vip_0'].'</td></tr>';
        }
        echo '<tr><td align="right"><b>'.$Lang['order_goods_price'].$fenghao.'</b></td><td>'.$info['price'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['goodsorder_dispatch_price'].$fenghao.'</b></td><td>'.$info['dispatch_price'].'</td></tr>';
        
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_order_title'] . '</th></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_no'].$fenghao.'</b></td><td>'.$infoOrderInfo['order_no'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_pay_price'].$fenghao.'</b></td><td>'.$infoOrderInfo['pay_price'].'</td></tr>';
        
        if($infoOrderInfo['huodao_pay_status'] == 1){
            if($info['order_status'] == 8){
                echo '<tr><td align="right"><b>'.$Lang['order_order_status'].$fenghao.'</b></td><td><b><font color="'.$orderStatusColorArray[$info['order_status']].'">' . $orderStatusArray[$info['order_status']] . '</font></b></td></tr>';
            }else{
                echo '<tr><td align="right"><b>'.$Lang['order_order_status'].$fenghao.'</b></td><td><b><font color="'.$orderStatusColorArray[$info['order_status']].'">' . $orderStatusArray[$info['order_status']].'(' .$orderStatusArray[8]. ')</font></b></td></tr>';
            }
        }else{
            echo '<tr><td align="right"><b>'.$Lang['order_order_status'].$fenghao.'</b></td><td><b><font color="'.$orderStatusColorArray[$infoOrderInfo['order_status']].'">' . $orderStatusArray[$infoOrderInfo['order_status']] . '</font></b></td></tr>';
        }
        
        echo '<tr><td align="right"><b>'.$Lang['order_order_time'].$fenghao.'</b></td><td>'.dgmdate($infoOrderInfo['order_time'], 'm-d H:i:s',$tomSysOffset).'</td></tr>';
        if($infoOrderInfo['pay_time'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['order_pay_time'].$fenghao.'</b></td><td>'.dgmdate($infoOrderInfo['pay_time'], 'm-d H:i:s',$tomSysOffset).'</td></tr>';
        }else{
            echo '<tr><td align="right"><b>'.$Lang['order_pay_time'].$fenghao.'</b></td><td>-</td></tr>';
        }
        
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_user_title'] . '</th></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_xm'].$fenghao.'</b></td><td>'.$infoOrderInfo['address_xm'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_tel'].$fenghao.'</b></td><td>'.$infoOrderInfo['address_tel'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_address'].$fenghao.'</b></td><td>'.$infoOrderInfo['address_str'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_beizu'].$fenghao.'</b></td><td>'.$infoOrderInfo['order_beizu'].'</td></tr>';
        if($infoOrderInfo['peisong_type'] == 1){
            echo '<tr><td align="right"><b>'.$Lang['goods_peisong_type'].$fenghao.'</b></td><td>'.$Lang['goods_peisong_type_1'].'</td></tr>';
        }else if($infoOrderInfo['peisong_type'] == 2){
            echo '<tr><td align="right"><b>'.$Lang['goods_peisong_type'].$fenghao.'</b></td><td>'.$Lang['goods_peisong_type_2'].'</td></tr>';
        }else if($infoOrderInfo['peisong_type'] == 3){
            echo '<tr><td align="right"><b>'.$Lang['goods_peisong_type'].$fenghao.'</b></td><td>'.$Lang['goods_peisong_type_3'].'</td></tr>';
        }
        echo '<tr><td align="right"><b>'.$Lang['order_peisong_info'].$fenghao.'</b></td><td>'.$infoOrderInfo['peisong_info'].'</td></tr>';
        if($infoOrderInfo['hexiao_time'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['order_hexiao_time'].$fenghao.'</b></td><td>'.dgmdate($infoOrderInfo['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
        }else{
            echo '<tr><td align="right"><b>'.$Lang['order_hexiao_time'].$fenghao.'</b></td><td>-</td></tr>';
        }
        
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcmall#tom_tcmall_order')->delete_by_id($_GET['id']);
    C::t('#tom_tcmall#tom_tcmall_order_goods')->delete_by_order_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    tomloadcalendarjs();
    set_list_url("tom_tcmall_admin_order_list");
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;
    $start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    
    $where = "";
    $urlStr = "";
    if(!empty($goods_id)){
        $where.=" AND goods_id={$goods_id} ";
        $urlStr.= "&goods_id={$goods_id}";
    }
    if(!empty($order_status)){
        $where.=" AND order_status={$order_status} ";
        $urlStr.= "&order_status={$order_status}";
    }
    if(!empty($start_time)){
        $startTime = strtotime($start_time);
        $where.=" AND add_time >=  {$startTime} ";
        $urlStr.="&start_time=".urlencode($start_time);
    }
    if(!empty($end_time)){
        $endTime = strtotime($end_time);
        $where.=" AND add_time < {$endTime} ";
        $urlStr.="&end_time=".urlencode($end_time);
    }

    $modBasePageUrl = $modBaseUrl.$urlStr;
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_count($where);
    $orderGoodsCount = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_goods_num($where);
    $orderGoodsList = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list($where,"ORDER BY add_time DESC",$start,$pagesize);
    $fenghao = $Lang['fenghao'];
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_search_list'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['goodsorder_goods_id'] . '</b></td><td><input name="goods_id" type="text" value="'.$goods_id.'" size="40" /><font color="#fd0d0d">' . $Lang['goodsorder_goods_id_msg'] . '</font></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_order_status'] . '</b></td><td><select name="order_status" >';
    echo '<option value="0">'.$Lang['order_order_status'].'</option>';
    foreach ($orderStatusArray as $key => $value){
        if($key == $order_status){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select></td></tr>';
    
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_start_time'] . '</b></td><td width="300"><input name="start_time" type="text" value="'.$start_time.'" onclick="showcalendar(event, this, 1)" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_end_time'] . '</b></td><td width="300"><input name="end_time" type="text" value="'.$end_time.'" onclick="showcalendar(event, this, 1)" size="40" /></td></tr>';
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    if($goods_id > 0){
        $countOrderStatus1 = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=1 ");
        $countOrderStatus2 = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=2 ");
        $countOrderStatus4 = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=4 ");
        $countOrderStatus5 = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=5 ");
        $countOrderStatus6 = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=6 ");
        $countOrderStatus7 = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_count(" AND goods_id={$goods_id} AND order_status=7 ");
        echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
        echo $orderStatusArray[1].'<font color="#fd0d0d">('.$countOrderStatus1.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[2].'<font color="#fd0d0d">('.$countOrderStatus2.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[4].'<font color="#fd0d0d">('.$countOrderStatus4.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[5].'<font color="#fd0d0d">('.$countOrderStatus5.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[6].'<font color="#fd0d0d">('.$countOrderStatus6.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[7].'<font color="#fd0d0d">('.$countOrderStatus7.')</font>&nbsp;&nbsp;';
        echo '</div>';
        if(!empty($order_status)){
            echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
            echo '<b>'.$Lang['order_search_count_msg1'].'</b>'.$Lang['order_search_count_msg2'].'<font color="#fd0d0d">('.$count.')</font>';
            echo '</div>';
        }
        tomshownavheader();
        tomshownavli($Lang['order_export'],$_G['siteurl']."plugin.php?id=tom_tcmall:goodsordersexport{$urlStr}",false);
        if($count > 5000){
            tomshownavli($Lang['order_export'].'(page:2)',$_G['siteurl']."plugin.php?id=tom_tcmall:goodsordersexport{$urlStr}&page=2",false);
        }
        if($count > 10000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcmall:goodsordersexport{$urlStr}&page=3",false);
        }
        if($count > 15000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcmall:goodsordersexport{$urlStr}&page=4",false);
        }
        if($count > 20000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcmall:goodsordersexport{$urlStr}&page=5",false);
        }
        if($count > 25000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcmall:goodsordersexport{$urlStr}&page=6",false);
        }
        tomshownavfooter();
    }
    
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return order_form();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />'.
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th width="10">&nbsp;</th>';
    echo '<th width="240">' . $Lang['order_goods_name'] . '</th>';
    echo '<th>' . $Lang['order_goods_num'] . '</th>';
    echo '<th>' . $Lang['order_goods_price'] . '</th>';
    echo '<th>' . $Lang['goodsorder_dispatch_price'] . '</th>';
    echo '<th>' . $Lang['order_user_nickname'] . '</th>';
    echo '<th>' . $Lang['order_order_status'] . '</th>';
    echo '<th>' . $Lang['goods_peisong_type'] . '</th>';
    echo '<th width="120">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($orderGoodsList as $key => $value){
        
        $orderInfo = C::t("#tom_tcmall#tom_tcmall_order")->fetch_by_id($value['order_id']);
        $goodsInfo = C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($value['goods_id']);
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        
        $option_name_tmp = '';
        if(!empty($value['option_name'])){
            $option_name_tmp = '<font color="#0894fb">(' . $value['option_name'] . ')</font>';
        }

        echo '<tr style="background-color: #E4FAF7;">';
        echo '<td colspan="2">' . $Lang['order_order_no'] . '&nbsp;:&nbsp;' . $orderInfo['order_no'] . '<br/>' . $Lang['order_pay_order_no'] . '&nbsp;:&nbsp;' . $orderInfo['pay_order_no'] . '</td>';
        echo '<td colspan="3">' . $Lang['order_order_time'] . '&nbsp;:&nbsp;' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        if($orderInfo['hexiao_time'] > 0){
            echo '<td colspan="2">' . $Lang['order_hexiao_time'] . '&nbsp;:&nbsp;' . dgmdate($orderInfo['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset). '</td>';
        }else{
            echo '<td colspan="2">' . $Lang['order_hexiao_time'] . '&nbsp;:&nbsp; - </td>';
        }
        if($value['tj_hehuoren_id'] > 0){
            echo '<td>' . $Lang['order_tj_hehuoren_id'] . '&nbsp;:&nbsp; ' . $value['tj_hehuoren_id'] . ' </td>';
        }else{
            echo '<td>' . $Lang['order_tj_hehuoren_id'] . '&nbsp;:&nbsp; - </td>';
        }
        if($value['is_vip'] == 1){
            echo '<td >' . $Lang['order_is_vip'] . '&nbsp;:&nbsp;<font color="">' . $Lang['order_is_vip_1'] . '</font></td>';
        }else{
            echo '<td >' . $Lang['order_is_vip'] . '&nbsp;:&nbsp;<font color="">' . $Lang['order_is_vip_0'] . '</font></td>';
        }
        echo '</tr>';
        
        echo '<tr style="height: 60px;">';
        echo '<td><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" ></td>';
        echo '<td><font color="#009900">' . $goodsInfo['title'] .$option_name_tmp. '</font></td>';
        echo '<td><font color="#009900">' . $value['goods_num'] . '</font></td>';
        echo '<td><font color="#009900">' . $value['price'] . '</font></td>';
        echo '<td><font color="#009900">' . $value['dispatch_price'] . '</font></td>';
        
        echo '<td>' . $userInfo['nickname'] . '(UID:'.$value['user_id'].')</td>';
        if($orderInfo['huodao_pay_status'] == 1){
            if($value['order_status'] == 8){
                echo '<td><b><font color="'.$orderStatusColorArray[$value['order_status']].'">' . $orderStatusArray[$value['order_status']] . '</font></b></td>';
            }else{
                echo '<td><b><font color="'.$orderStatusColorArray[$value['order_status']].'">' . $orderStatusArray[$value['order_status']] .'(' .$orderStatusArray[8]. ')</font></b></td>';
            }
        }else{
            echo '<td><b><font color="'.$orderStatusColorArray[$value['order_status']].'">' . $orderStatusArray[$value['order_status']] . '</font></b></td>';
        }
        if($orderInfo['peisong_type'] == 1){
            echo '<td>' . $Lang['goods_peisong_type_1'] . '</td>'; 
        }else if($orderInfo['peisong_type'] == 2){
            echo '<td><b>' . $Lang['goods_peisong_type_2'] . '</b></td>'; 
        }else if($orderInfo['peisong_type'] == 3){
            echo '<td><b>' . $Lang['goods_peisong_type_3'] .'</b></td>'; 
        }
        echo '<td style="line-height: 30px;">';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['order_info'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    
    $formstr = <<<EOF
        <!--<tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="refund">{$Lang['batch_refund']}</option>
                    <option value="refundquery">{$Lang['batch_refundquery']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>-->
        <script type="text/javascript">
        function order_form(){
          var r = confirm("{$Lang['batch_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
        </script>
EOF;
    
    echo $formstr;
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
}