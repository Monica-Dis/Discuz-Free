<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tomSysOffset = getglobal('setting/timeoffset');
$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/config.utf8.php';
}

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$goods_id       = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
$order_status   = intval($_GET['order_status'])>0? intval($_GET['order_status']):0;
$start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
$end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
$from           = isset($_GET['from'])? addslashes($_GET['from']):'';

$pagesize = 10000;
$start = ($page-1)*$pagesize;

$daoQuanXianStatus = 0;
if($from == 'mylist'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';
    
    $goodsInfo = C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($goods_id);
    
    if($__UserInfo['id'] > 0 && $goodsInfo['user_id'] == $__UserInfo['id']){
        $daoQuanXianStatus = 1;
    }
    
}else{
    if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
        $daoQuanXianStatus = 1;
    }
}

if($daoQuanXianStatus == 1){
    
    $where = "";
    if(!empty($goods_id)){
        $where.=" AND goods_id={$goods_id} ";
    }
    if(!empty($order_status)){
        $where.=" AND order_status={$order_status} ";
    }
    if(!empty($start_time)){
        $startTime = strtotime($start_time);
        $where.=" AND add_time >=  {$startTime} ";
    }
    if(!empty($end_time)){
        $endTime = strtotime($end_time);
        $where.=" AND add_time < {$endTime} ";
    }
    
    $orderGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list($where,"ORDER BY add_time DESC",$start,$pagesize);
    $orderGoodsList = array();
    foreach ($orderGoodsListTmp as $key => $value) {
        $orderGoodsList[$key] = $value;
        $orderGoodsList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
        
        $orderInfo = C::t('#tom_tcmall#tom_tcmall_order')->fetch_by_id($value['order_id']);
        
        if($orderInfo['huodao_pay_status'] == 1 && $orderInfo['order_status'] != 8){
            $orderInfo['order_status'] = $orderStatusArray[$orderInfo['order_status']].'('.$orderStatusArray[8].')';
        }else{
            $orderInfo['order_status'] = $orderStatusArray[$orderInfo['order_status']];
        }
        
        if($orderInfo['peisong_type'] == 1){
            $orderInfo['peisong_type'] = lang('plugin/tom_tcmall','goods_peisong_type_1');
        }else if($orderInfo['peisong_type'] == 2){
            $orderInfo['peisong_type'] = lang('plugin/tom_tcmall','goods_peisong_type_2');
        }else if($orderInfo['peisong_type'] == 3){
            $orderInfo['peisong_type'] = lang('plugin/tom_tcmall','goods_peisong_type_3');
        }
        if($orderInfo['order_time'] > 0){
            $orderInfo['order_time'] = dgmdate($orderInfo['order_time'],"Y-m-d H:i:s",$tomSysOffset);
        }else{
            $orderInfo['order_time'] = '-';
        }
        if($orderInfo['hexiao_time'] > 0){
            $orderInfo['hexiao_time'] = dgmdate($orderInfo['hexiao_time'],"Y-m-d H:i:s",$tomSysOffset);
        }else{
            $orderInfo['hexiao_time'] = '-';
        }
        
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $goodsInfoTmp = C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($value['goods_id']);
        
        $orderGoodsList[$key]['orderInfo'] = $orderInfo;
        $orderGoodsList[$key]['userInfo'] = $userInfoTmp;
        $orderGoodsList[$key]['goodsInfo'] = $goodsInfoTmp;
    }

    $order_order_no             = lang('plugin/tom_tcmall','order_order_no');
    $order_goods_name           = lang('plugin/tom_tcmall','order_goods_name');
    $order_goods_price          = lang('plugin/tom_tcmall','order_goods_price');
    $order_goods_num            = lang('plugin/tom_tcmall','order_goods_num');
    $goodsorder_dispatch_price  = lang('plugin/tom_tcmall','goodsorder_dispatch_price');
    $order_is_vip               = lang('plugin/tom_tcmall','order_is_vip');
    $order_user_id              = lang('plugin/tom_tcmall','order_user_id');
    $order_user_openid          = lang('plugin/tom_tcmall','order_user_openid');
    $order_xm                   = lang('plugin/tom_tcmall','order_xm');
    $order_tel                  = lang('plugin/tom_tcmall','order_tel');
    $order_address              = lang('plugin/tom_tcmall','order_address');
    $order_order_beizu          = lang('plugin/tom_tcmall','order_order_beizu');
    $order_order_status         = lang('plugin/tom_tcmall','order_order_status');
    $goods_peisong_type         = lang('plugin/tom_tcmall','goods_peisong_type');
    $order_peisong_info         = lang('plugin/tom_tcmall','order_peisong_info');
    $order_order_time           = lang('plugin/tom_tcmall','order_order_time');
    $order_hexiao_time          = lang('plugin/tom_tcmall','order_hexiao_time');
        
    $listData[] = array(
        $order_order_no,
        $order_goods_name,
        $order_goods_price,
        $order_goods_num,
        $goodsorder_dispatch_price,
        $order_is_vip,
        $order_user_id,
        $order_user_openid,
        $order_xm,
        $order_tel,
        $order_address,
        $order_order_beizu,
        $order_order_status,
        $goods_peisong_type,
        $order_peisong_info,
        $order_order_time,
        $order_hexiao_time,
    ); 
    foreach ($orderGoodsList as $v){
        $option_name_tmp = '';
        if(!empty($v['option_name'])){
            $option_name_tmp = '(' . $v['option_name'] . ')';
        }
        $lineData = array();
        $lineData[] = $v['orderInfo']['order_no'];
        $lineData[] = $v['goodsInfo']['title'].$option_name_tmp;
        $lineData[] = $v['price'];
        $lineData[] = $v['goods_num'];
        $lineData[] = $v['dispatch_price'];
        if($v['is_vip'] == 1){
            $lineData[] = lang('plugin/tom_tcmall','order_is_vip_1');
        }else{
            $lineData[] = lang('plugin/tom_tcmall','order_is_vip_0');
        }
        $lineData[] = $v['user_id'];
        $lineData[] = $v['userInfo']['openid'];
        $lineData[] = $v['orderInfo']['address_xm'];
        $lineData[] = $v['orderInfo']['address_tel'];
        $v['orderInfo']['address_str'] = str_replace("\r\n", "", $v['orderInfo']['address_str']);
        $v['orderInfo']['address_str'] = str_replace("\n", "", $v['orderInfo']['address_str']);
        $lineData[] = $v['orderInfo']['address_str'];
        $order_beizu = str_replace("\r\n", "", $v['orderInfo']['order_beizu']);
        $order_beizu = str_replace("\n", "", $order_beizu);
        $lineData[] = $order_beizu;
        $lineData[] = $v['orderInfo']['order_status'];
        $lineData[] = $v['orderInfo']['peisong_type'];
        $peisong_info = str_replace("\r\n", "", $v['orderInfo']['peisong_info']);
        $peisong_info = str_replace("\n", "", $peisong_info);
        $lineData[] = "'".$peisong_info;
        $lineData[] = $v['orderInfo']['order_time'];
        $lineData[] = $v['orderInfo']['hexiao_time'];
        
        $listData[] = $lineData;
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=goodsExportOrders.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}