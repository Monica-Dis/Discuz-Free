<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcmall_cart`;
CREATE TABLE `pre_tom_tcmall_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `goods_num` int(11) DEFAULT '0',
  `buy_price` decimal(10,2) DEFAULT '0.00',
  `option_id` int(11) DEFAULT '0',
  `peisong_type` tinyint(4) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_cate`;
CREATE TABLE `pre_tom_tcmall_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `sub_name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `pid` int(11) DEFAULT '0',
  `csort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_focuspic`;
CREATE TABLE `pre_tom_tcmall_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_goods`;
CREATE TABLE `pre_tom_tcmall_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tcshop_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `cate_id` int(11) DEFAULT '0',
  `cate_child_id` int(11) DEFAULT '0',
  `shop_cate_id` int(11) DEFAULT '0',
  `unit` varchar(255) DEFAULT NULL,
  `content` text,
  `market_price` decimal(10,2) DEFAULT '0.00',
  `buy_price` decimal(10,2) DEFAULT '0.00',
  `open_vip` tinyint(4) DEFAULT '0',
  `vip_price` decimal(10,2) DEFAULT '0.00',
  `stock` int(11) DEFAULT '0',
  `show_stock` tinyint(4) DEFAULT '0',
  `sales` int(11) DEFAULT '0',
  `virtual_sales` int(11) DEFAULT '0',
  `show_sales` tinyint(4) DEFAULT '0',
  `weight` int(11) DEFAULT '0',
  `max_buy` int(11) DEFAULT '0',
  `hasoption` tinyint(4) DEFAULT '0',
  `isnew` tinyint(4) DEFAULT '0',
  `ishot` tinyint(4) DEFAULT '0',
  `isrecommand` tinyint(4) DEFAULT '0',
  `seven` tinyint(4) DEFAULT '0',
  `peisong_type` tinyint(4) DEFAULT '1',
  `issendfree` tinyint(4) DEFAULT '0',
  `dispatch_type` tinyint(4) DEFAULT '1',
  `dispatch_price` decimal(10,2) DEFAULT '0.00',
  `ednum` int(11) DEFAULT '0',
  `edmoney` decimal(10,2) DEFAULT '0.00',
  `open_express` tinyint(4) DEFAULT '0',
  `express_id` int(11) DEFAULT '0',
  `isdiscount_discounts` int(11) DEFAULT NULL,
  `isdiscount_time` int(11) DEFAULT '0',
  `show_market_price` decimal(10,2) DEFAULT '0.00',
  `show_buy_price` decimal(10,2) DEFAULT '0.00',
  `show_vip_price` decimal(10,2) DEFAULT '0.00',
  `province` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `labelname` text,
  `hexiao_pwd` varchar(255) DEFAULT NULL,
  `gsort` int(11) DEFAULT '10',
  `clicks` int(11) DEFAULT '0',
  `virtual_clicks` int(11) DEFAULT '0',
  `search_txt` text,
  `yongjin_bili` decimal(10,2) DEFAULT '0.00',
  `hehuoren_tg_open` tinyint(4) DEFAULT '0',
  `chuji_fc_scale` decimal(10,2) DEFAULT '0.00',
  `zhongji_fc_scale` decimal(10,2) DEFAULT '0.00',
  `gaoji_fc_scale` decimal(10,2) DEFAULT '0.00',
  `open_score_dikou` tinyint(4) DEFAULT '0',
  `score_num` int(11) DEFAULT '0',
  `score_dikou_price` decimal(10,2) DEFAULT '0.00',
  `show_score_num` int(11) DEFAULT '0',
  `show_score_dikou_price` decimal(10,2) DEFAULT '0.00',
  `shenhe_status` int(11) DEFAULT '0',
  `admin_edit` int(11) DEFAULT '0',
  `allow_refund` int(11) DEFAULT '1',
  `zhibo_roomid` int(11) DEFAULT '0',
  `status` int(11) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_goods_collect`;
CREATE TABLE `pre_tom_tcmall_goods_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_goods_option`;
CREATE TABLE `pre_tom_tcmall_goods_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `market_price` decimal(10,2) DEFAULT '0.00',
  `buy_price` decimal(10,2) DEFAULT '0.00',
  `vip_price` decimal(10,2) DEFAULT '0.00',
  `stock` int(11) DEFAULT '0',
  `score_num` int(11) DEFAULT '0',
  `score_dikou_price` decimal(10,2) DEFAULT '0.00',
  `weight` int(11) DEFAULT '0',
  `spec_item_ids` text,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_goods_photo`;
CREATE TABLE `pre_tom_tcmall_goods_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '1',
  `picurl` varchar(255) DEFAULT NULL,
  `oss_picurl` varchar(255) DEFAULT NULL,
  `oss_status` int(11) DEFAULT '0',
  `qiniu_picurl` varchar(255) DEFAULT NULL,
  `qiniu_status` int(11) DEFAULT '0',
  `psort` int(11) DEFAULT '10',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_goods_spec`;
CREATE TABLE `pre_tom_tcmall_goods_spec` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `ssort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_goods_spec_item`;
CREATE TABLE `pre_tom_tcmall_goods_spec_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spec_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `isort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_goods_stock_log`;
CREATE TABLE `pre_tom_tcmall_goods_stock_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_admin` int(11) DEFAULT '0',
  `is_option` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `beizu` text,
  `change_num` int(11) DEFAULT '0',
  `change_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_order`;
CREATE TABLE `pre_tom_tcmall_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `pay_order_no` varchar(255) DEFAULT NULL,
  `tcshop_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `order_no` varchar(255) DEFAULT NULL,
  `hexiao_no` varchar(255) DEFAULT NULL,
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `pay_time` int(11) DEFAULT '0',
  `goods_price` decimal(10,2) DEFAULT '0.00',
  `peisong_type` int(11) DEFAULT '1',
  `peisong_name` varchar(255) DEFAULT NULL,
  `peisong_info` varchar(255) DEFAULT NULL,
  `peisong_time` int(11) DEFAULT '0',
  `tcshop_place_id` int(11) DEFAULT '0',
  `kuaidi_no` varchar(255) DEFAULT NULL,
  `kuaidi_type` varchar(255) DEFAULT NULL,
  `coupon_lingqu_id` int(11) DEFAULT '0',
  `coupon_reduce_price` decimal(10,2) DEFAULT '0.00',
  `score_num` int(11) DEFAULT '0',
  `score_dikou_price` decimal(10,2) DEFAULT '0.00',
  `order_status` tinyint(4) DEFAULT '0',
  `pinglun_status` tinyint(4) DEFAULT '0',
  `order_beizu` text,
  `address_id` int(11) DEFAULT '0',
  `dispatch_price` decimal(10,2) DEFAULT '0.00',
  `order_time` int(11) DEFAULT '0',
  `address` text,
  `address_xm` varchar(255) DEFAULT NULL,
  `address_tel` varchar(255) DEFAULT NULL,
  `address_str` varchar(255) DEFAULT NULL,
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `balance_status` tinyint(4) DEFAULT '0',
  `huodao_pay_status` tinyint(4) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_hexiao_no` (`hexiao_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_order_goods`;
CREATE TABLE `pre_tom_tcmall_order_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `goods_title` varchar(255) DEFAULT NULL,
  `is_vip` tinyint(4) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `goods_num` int(11) DEFAULT '0',
  `option_id` int(11) DEFAULT '0',
  `option_name` varchar(255) DEFAULT NULL,
  `order_status` tinyint(4) DEFAULT '0',
  `pinglun_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `real_price` decimal(10,2) DEFAULT '0.00',
  `dispatch_price` decimal(10,2) DEFAULT '0.00',
  `score_num` int(11) DEFAULT '0',
  `score_dikou_price` decimal(10,2) DEFAULT '0.00',
  `balance_status` tinyint(4) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_order_pay`;
CREATE TABLE `pre_tom_tcmall_order_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `type` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `pay_order_no` varchar(255) DEFAULT NULL,
  `order_no_str` text,
  `order_status` tinyint(4) DEFAULT '0',
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `pay_time` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_pinglun`;
CREATE TABLE `pre_tom_tcmall_pinglun` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_goods_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `option_name` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `score` tinyint(4) DEFAULT '0',
  `content` text,
  `pinglun_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_pinglun_photo`;
CREATE TABLE `pre_tom_tcmall_pinglun_photo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pinglun_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_pinglun_reply`;
CREATE TABLE `pre_tom_tcmall_pinglun_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pinglun_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `reply_user_id` int(11) DEFAULT '0',
  `reply_user_nickname` varchar(255) DEFAULT NULL,
  `reply_user_avatar` varchar(255) DEFAULT NULL,
  `content` text,
  `reply_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_refund`;
CREATE TABLE `pre_tom_tcmall_refund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tcshop_id` int(11) DEFAULT '0',
  `order_id` int(11) DEFAULT '0',
  `pay_order_no` varchar(255) DEFAULT NULL,
  `order_goods_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `user_desc` text,
  `refund_no` varchar(255) DEFAULT NULL,
  `refund_price` decimal(10,2) DEFAULT '0.00',
  `refund_beizu` text,
  `refund_type` tinyint(4) unsigned DEFAULT '0',
  `refund_status` tinyint(4) DEFAULT '0',
  `wx_refund_status` tinyint(4) DEFAULT '0',
  `shop_shenhe_status` tinyint(4) DEFAULT '0',
  `refund_time` int(11) unsigned DEFAULT '0',
  `shop_shenhe_time` int(10) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_refund_photo`;
CREATE TABLE `pre_tom_tcmall_refund_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refund_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_shop_recommend`;
CREATE TABLE `pre_tom_tcmall_shop_recommend` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tcshop_id` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `rsort` int(11) DEFAULT '10',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_coupon`;
CREATE TABLE `pre_tom_tcmall_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `goods_ids` text,
  `tcshop_id` int(11) DEFAULT '0',
  `coupon_type` int(11) DEFAULT '0',
  `total_num` int(11) DEFAULT '0',
  `lingqu_num` int(11) DEFAULT '0',
  `full_price` decimal(10,2) DEFAULT '0.00',
  `reduce_price` decimal(10,2) DEFAULT '0.00',
  `max_lingqu_num` int(11) DEFAULT '0',
  `start_time` int(11) unsigned DEFAULT '0',
  `end_time` int(11) unsigned DEFAULT '0',
  `content` text,
  `is_yikatong` int(11) DEFAULT '0',
  `is_hehuoren` int(11) DEFAULT '0',
  `open_score` int(11) DEFAULT '0',
  `pay_score` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcmall_coupon_lingqu`;
CREATE TABLE `pre_tom_tcmall_coupon_lingqu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `coupon_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `use_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        

EOF;

runquery($sql);

$finish = TRUE;