<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
$goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($goods_id);

if($__Admin['admin'] == 'shopadmin'){
    if($__UserInfo['id'] != $goodsInfo['user_id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=pinglun&goods_id={$goods_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('pinglun_id')){
    $outArr = array(
        'code'=> 1,
    );

    $pinglun_id = intval($_GET['pinglun_id'])>0? intval($_GET['pinglun_id']):0;

    C::t('#tom_tcmall#tom_tcmall_pinglun')->delete_by_id($pinglun_id);
    C::t('#tom_tcmall#tom_tcmall_pinglun_photo')->delete_by_pinglun_id($pinglun_id);
    C::t('#tom_tcmall#tom_tcmall_pinglun_reply')->delete_by_pinglun_id($pinglun_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;

}else if($act == 'del_reply' && submitcheck('reply_id')){
    $outArr = array(
        'code'=> 1,
    );

    $reply_id = intval($_GET['reply_id'])>0? intval($_GET['reply_id']):0;

    C::t('#tom_tcmall#tom_tcmall_pinglun_reply')->delete_by_id($reply_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('pinglun_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $pinglunIdsArr = array();
    if(is_array($_GET['pinglun_ids'])){
        foreach($_GET['pinglun_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $pinglunIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($pinglunIdsArr)){
        foreach ($pinglunIdsArr as $key => $value){
            C::t('#tom_tcmall#tom_tcmall_pinglun')->delete_by_id($value);
            C::t('#tom_tcmall#tom_tcmall_pinglun_photo')->delete_by_pinglun_id($value);
            C::t('#tom_tcmall#tom_tcmall_pinglun_reply')->delete_by_pinglun_id($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = "AND goods_id={$goods_id}";
if($user_id > 0){
    $where .= " AND user_id={$user_id} ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcmall#tom_tcmall_pinglun')->fetch_all_count($where);
$pinglunListTmp = C::t('#tom_tcmall#tom_tcmall_pinglun')->fetch_all_list($where, "ORDER BY id ASC", $start, $pagesize);
$pinglunList = array();
if(!empty($pinglunListTmp)){
    foreach($pinglunListTmp as $key => $value){
        $pinglunList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $pinglunPhotoListTmpTmp = C::t('#tom_tcmall#tom_tcmall_pinglun_photo')->fetch_all_list(" AND pinglun_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);
        $photoListTmp = array();
        if(!empty($pinglunPhotoListTmpTmp)){
            foreach($pinglunPhotoListTmpTmp as $pk => $pv){
                $photoListTmp[] = get_file_url($pv['picurl']);
            }
        }
        
        $replyListTmpTmp = C::t('#tom_tcmall#tom_tcmall_pinglun_reply')->fetch_all_list(" AND pinglun_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);
        $replyListTmp = array();
        if(!empty($replyListTmpTmp)){
            foreach($replyListTmpTmp as $k => $v){
                $replyListTmp[$k] = $v;
                $replyListTmp[$k]['reply_time'] = dgmdate($v['reply_time'], 'Y-m-d H:i:s',$tomSysOffset);
            }
        }
        
        $pinglunList[$key]['userInfo']      = $userInfoTmp;
        $pinglunList[$key]['photoList']     = $photoListTmp;
        $pinglunList[$key]['replyList']     = $replyListTmp;
        $pinglunList[$key]['pinglun_time']  = dgmdate($value['pinglun_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:pcadmin/pinglun");