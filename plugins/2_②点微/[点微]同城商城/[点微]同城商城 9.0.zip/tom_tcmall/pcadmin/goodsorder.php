<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($goods_id);
if(empty($goodsInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($__UserInfo['id'] != $goodsInfo['user_id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=goodsorder&goods_id={$goods_id}";

$order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;
$start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
$end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = "AND goods_id={$goods_id}";
if(!empty($order_status)){
    $where .=" AND order_status={$order_status} ";
}
if(!empty($start_time)){
    $startTime = strtotime($start_time);
    $where .=" AND add_time >=  {$startTime} ";
}
if(!empty($end_time)){
    $endTime = strtotime($end_time);
    $where .=" AND add_time < {$endTime} ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_count($where);
$orderGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_all_list($where,"ORDER BY add_time DESC",$start,$pagesize);
$orderGoodsList = array();
if(!empty($orderGoodsListTmp)){
    foreach($orderGoodsListTmp as $key => $value){
        $orderGoodsList[$key] = $value;
        
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        
        $orderInfoTmp = C::t("#tom_tcmall#tom_tcmall_order")->fetch_by_id($value['order_id']);
        $orderInfoTmp['hexiao_time'] = dgmdate($orderInfoTmp['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $orderInfoTmp['payTime']     = dgmdate($orderInfoTmp['pay_time'], 'Y-m-d H:i:s',$tomSysOffset);
        
        $goodsInfoTmp = C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($value['goods_id']);
        $goodsInfoTmp['picurl'] = get_file_url($goodsInfoTmp['picurl']);
        
        $site_name_tmp = $Lang['sites_one'];
        if($value['site_id'] > 1){
            $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
            $site_name_tmp = $siteInfoTmp['name'];
        }
        
        $orderGoodsList[$key]['userInfo']       = $userInfoTmp;
        $orderGoodsList[$key]['orderInfo']      = $orderInfoTmp;
        $orderGoodsList[$key]['goodsInfo']      = $goodsInfoTmp;
        $orderGoodsList[$key]['site_name']      = $site_name_tmp;
        $orderGoodsList[$key]['add_time']       = dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&order_status={$order_status}&start_time={$start_time}&end_time={$end_time}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:pcadmin/goodsorder");