<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=coupon";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'show' && submitcheck('coupon_id')){
    $outArr = array(
        'code'=> 1,
    );

    $coupon_id = intval($_GET['coupon_id'])>0 ? intval($_GET['coupon_id']):0;

    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcmall#tom_tcmall_coupon')->update($coupon_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('coupon_id')){
    $outArr = array(
        'code'=> 1,
    );

    $coupon_id = intval($_GET['coupon_id'])>0 ? intval($_GET['coupon_id']):0;

    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcmall#tom_tcmall_coupon')->update($coupon_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('coupon_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $coupon_id = intval($_GET['coupon_id'])>0 ? intval($_GET['coupon_id']):0; 
    
    C::t('#tom_tcmall#tom_tcmall_coupon')->delete_by_id($coupon_id);
    C::t('#tom_tcmall#tom_tcmall_coupon_lingqu')->delete_by_coupon_id($coupon_id);
        
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$coupon_id      = isset($_GET['coupon_id'])? intval($_GET['coupon_id']):0;
$tcshop_id      = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
$title          = !empty($_GET['title'])? addslashes($_GET['title']):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = "";
if($site_id > 0){
    $where.= " AND site_id={$site_id}";
}
if($coupon_id > 0){
    $where.= " AND id={$coupon_id}";
}
if($tcshop_id > 0){
    $where.= " AND tcshop_id={$tcshop_id}";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcmall#tom_tcmall_coupon')->fetch_all_count($where,$title);
$couponListTmp = C::t('#tom_tcmall#tom_tcmall_coupon')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize,$title);
$couponList = array();
if(!empty($couponListTmp)){
    foreach ($couponListTmp as $key => $value) {
        $couponList[$key] = $value;
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        
        $couponList[$key]['siteInfo']       = $siteInfoTmp;
        $couponList[$key]['tcshopInfo']     = $tcshopInfoTmp;
        $couponList[$key]['start_time']     = dgmdate($value['start_time'],"Y-m-d H:i",$tomSysOffset);
        $couponList[$key]['end_time']       = dgmdate($value['end_time'],"Y-m-d H:i",$tomSysOffset);
        $couponList[$key]['add_time']       = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&coupon_id={$coupon_id}&tcshop_id={$tcshop_id}&title={$title}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:pcadmin/coupon");