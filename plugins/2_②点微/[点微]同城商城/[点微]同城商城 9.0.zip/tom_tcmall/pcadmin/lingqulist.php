<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$coupon_id = intval($_GET['coupon_id'])>0? intval($_GET['coupon_id']):0;
$couponInfo = C::t("#tom_tcmall#tom_tcmall_coupon")->fetch_by_id($coupon_id);

if($__Admin['admin'] == 'shopadmin'){
    if($__UserInfo['id'] != $couponInfo['user_id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=lingqulist&coupon_id={$coupon_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'list' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $page       = intval($_GET['page'])>0 ? intval($_GET['page']) :1;
    $pagesize   = intval($_GET['pagesize'])>0 ? intval($_GET['pagesize']) :10;
    
    $where = " AND coupon_id = {$coupon_id} ";
    
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcmall#tom_tcmall_coupon_lingqu')->fetch_all_count($where);
    $lingquListTmp = C::t('#tom_tcmall#tom_tcmall_coupon_lingqu')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    $lingquList = array();
    if(!empty($lingquListTmp)){
        foreach($lingquListTmp as $key => $value){
            $lingquList[$key] = $value;
            
            $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
            
            $lingquList[$key]['userInfo'] = $userInfoTmp;
            $lingquList[$key]['use_time'] = dgmdate($value['use_time'],"Y-m-d H:i",$tomSysOffset);
            $lingquList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        }
    }
    
    $list = iconv_to_utf8($lingquList);
    
    $outArr = array(
        'code'  => 0,
        'msg'   => '',
        'count' => $count,
        'data'  => $list,
    );
    echo json_encode($outArr); exit;
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:pcadmin/lingqulist");