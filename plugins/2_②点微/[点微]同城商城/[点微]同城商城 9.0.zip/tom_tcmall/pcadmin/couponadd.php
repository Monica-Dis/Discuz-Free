<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=couponadd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $coupon_type        = isset($_GET['coupon_type'])? intval($_GET['coupon_type']):0;
    $total_num          = isset($_GET['total_num'])? intval($_GET['total_num']):0;
    $full_price         = isset($_GET['full_price'])? floatval($_GET['full_price']):0.00;
    $reduce_price       = isset($_GET['reduce_price'])? floatval($_GET['reduce_price']):0.00;
    $max_lingqu_num     = isset($_GET['max_lingqu_num'])? intval($_GET['max_lingqu_num']):0;
    $is_yikatong        = isset($_GET['is_yikatong'])? intval($_GET['is_yikatong']):0;
    $is_hehuoren        = isset($_GET['is_hehuoren'])? intval($_GET['is_hehuoren']):0;
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = strtotime($end_time);
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $open_score         = isset($_GET['open_score'])? intval($_GET['open_score']):0;
    $pay_score          = isset($_GET['pay_score'])? intval($_GET['pay_score']):0;
    
    $goodsIdsArr = array();
    if(is_array($_GET['goods_ids']) && !empty($_GET['goods_ids'])){
        foreach($_GET['goods_ids'] as $key => $value){
            if(!empty($value)){
                $goodsIdsArr[] = intval($value);
            }
        }
    }
    $goodsIdsStr = '';
    if(is_array($goodsIdsArr) && !empty($goodsIdsArr)){
        $goodsIdsStr = implode('|', $goodsIdsArr);
    }
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    if($__Admin['admin'] == 'shopadmin' && $tcshopInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    
    $insertData = array();
    $insertData['site_id']              = $tcshopInfo['site_id'];
    $insertData['user_id']              = $tcshopInfo['user_id'];
    $insertData['tcshop_id']            = $tcshopInfo['id'];
    $insertData['title']                = $title;
    $insertData['coupon_type']          = $coupon_type;
    if($coupon_type == 2){
        $insertData['goods_ids']            = $goodsIdsStr;
    }else{
        $insertData['goods_ids']            = '';
    }
    $insertData['total_num']            = $total_num;
    $insertData['full_price']           = $full_price;
    $insertData['reduce_price']         = $reduce_price;
    $insertData['max_lingqu_num']       = $max_lingqu_num;
    if($__Admin['admin'] == 'admin'){
        $insertData['is_yikatong']          = $is_yikatong;
        $insertData['is_hehuoren']          = $is_hehuoren;
    }
    $insertData['start_time']           = $start_time;
    $insertData['end_time']             = $end_time;
    $insertData['status']               = $status;
    $insertData['content']              = $content;
    $insertData['open_score']           = $open_score;
    $insertData['pay_score']            = $pay_score;
    $insertData['add_time']             = TIMESTAMP;
    $coupon_id = C::t('#tom_tcmall#tom_tcmall_coupon')->insert($insertData, true);
    if($coupon_id > 0){
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}else if($act == 'load_goods' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcshop_id = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']) :0;
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    if($__Admin['admin'] == 'shopadmin' && $tcshopInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    
    $goodsListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND tcshop_id={$tcshop_id} "," ORDER BY gsort DESC ,add_time DESC,id DESC ",0,50);
    $goodsList = array();
    if(is_array($goodsListTmp) && !empty($goodsListTmp)){
        foreach ($goodsListTmp as $key => $value) {
            $goodsList[$key] = $value;
        }
    }
    
    $list = iconv_to_utf8($goodsList);
    
    $outArr = array(
        'code' => 200,
        'list' => $list,
    );
    echo json_encode($outArr); exit;
}

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$__UserInfo['id']} AND v.open_tcmall=1 "," ORDER BY s.id DESC ",0,100);
$tcshopList = array();
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach($tcshopListTmp as $key => $value){
        $tcshopList[$key] = $value;
    }
}

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:pcadmin/couponadd");