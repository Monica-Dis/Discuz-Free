<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($goods_id);
if(empty($goodsInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($__UserInfo['id'] != $goodsInfo['user_id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=edit&goods_id={$goods_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $sub_title          = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $shop_cate_id       = isset($_GET['shop_cate_id'])? intval($_GET['shop_cate_id']):0;
    $unit               = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $market_price       = isset($_GET['market_price'])? floatval($_GET['market_price']):0.00;
    $buy_price          = isset($_GET['buy_price'])? floatval($_GET['buy_price']):0.00;
    $open_vip           = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $vip_price          = isset($_GET['vip_price'])? floatval($_GET['vip_price']):0.00;
    $open_score_dikou   = isset($_GET['open_score_dikou'])? intval($_GET['open_score_dikou']):0;
    $score_num          = isset($_GET['score_num'])? intval($_GET['score_num']):0;
    $score_dikou_price  = isset($_GET['score_dikou_price'])? floatval($_GET['score_dikou_price']):0.00;
    $virtual_sales      = isset($_GET['virtual_sales'])? intval($_GET['virtual_sales']):0;
    $max_buy            = isset($_GET['max_buy'])? intval($_GET['max_buy']):0;
    $province           = isset($_GET['province'])? intval($_GET['province']):0;
    $city               = isset($_GET['city'])? intval($_GET['city']):0;
    $keywords           = isset($_GET['keywords'])? addslashes($_GET['keywords']):'';
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $allow_refund       = isset($_GET['allow_refund'])? intval($_GET['allow_refund']):0;
    $gsort              = isset($_GET['gsort'])? intval($_GET['gsort']):10;
    $isrecommand        = isset($_GET['isrecommand'])? intval($_GET['isrecommand']):0;
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $open_express       = isset($_GET['open_express'])? intval($_GET['open_express']):0;
    $express_id         = isset($_GET['express_id'])? intval($_GET['express_id']):0;
    $issendfree         = isset($_GET['issendfree'])? intval($_GET['issendfree']):0;
    $ednum              = isset($_GET['ednum'])? intval($_GET['ednum']):0;
    $edmoney            = isset($_GET['edmoney'])? floatval($_GET['edmoney']):0;
    $dispatch_price     = isset($_GET['dispatch_price'])? floatval($_GET['dispatch_price']):0.00;
    $dispatch_type      = isset($_GET['dispatch_type'])? intval($_GET['dispatch_type']):1;
    $yongjin_bili       = isset($_GET['yongjin_bili'])? floatval($_GET['yongjin_bili']):0;
    $hehuoren_tg_open   = isset($_GET['hehuoren_tg_open'])? intval($_GET['hehuoren_tg_open']):0;
    $chuji_fc_scale     = isset($_GET['chuji_fc_scale'])? floatval($_GET['chuji_fc_scale']):0;
    $zhongji_fc_scale   = isset($_GET['zhongji_fc_scale'])? floatval($_GET['zhongji_fc_scale']):0;
    $gaoji_fc_scale     = isset($_GET['gaoji_fc_scale'])? floatval($_GET['gaoji_fc_scale']):0;
    $zhibo_roomid       = isset($_GET['zhibo_roomid'])? intval($_GET['zhibo_roomid']):0;
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    $stock              = isset($_GET['stock'])? intval($_GET['stock']):0;
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photosort_") !== false){
            $kk = intval(ltrim($key, "photosort_"));
            $photoArr[$kk]['sort'] = addslashes($value);
        }
    }
    
    if($hasoption == 1){
        $specArr = array();
        foreach($_GET as $key => $value){
            if(strpos($key, "spec_id_") !== false){
                $key = intval(ltrim($key, "spec_id_"));
                $specArr[$key]['spec_id'] = intval($value);
            }
            if(strpos($key, "spec_name_") !== false){
                $key = intval(ltrim($key, "spec_name_"));
                $specArr[$key]['name'] = addslashes($value);
            }
            if(strpos($key, "spec_ssort_") !== false){
                $key = intval(ltrim($key, "spec_ssort_"));
                $specArr[$key]['ssort'] = intval($value);
            }
            if(strpos($key, "spec_item_id_") !== false){
                $key = addslashes(ltrim($key, "spec_item_id_"));
                if(strpos($key, "_")){
                    list($key, $kk) = explode('_', $key);
                    $specArr[$key]['itemList'][$kk]['spec_item_id'] = intval($value);
                }
            }
            if(strpos($key, "spec_item_name_") !== false){
                $key = addslashes(ltrim($key, "spec_item_name_"));
                if(strpos($key, "_")){
                    list($key, $kk) = explode('_', $key);
                    $specArr[$key]['itemList'][$kk]['name'] = addslashes($value);
                }
            }
            if(strpos($key, "spec_item_picurl_") !== false){
                $key = addslashes(ltrim($key, "spec_item_picurl_"));
                if(strpos($key, "_")){
                    list($key, $kk) = explode('_', $key);
                    $specArr[$key]['itemList'][$kk]['picurl'] = addslashes($value);
                }
            }
        }
        
        if(empty($specArr)){
            $outArr = array(
                'code'=> 200,
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
        
        foreach($specArr as $key => $value){
            if(empty($value['name'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }
            
            foreach($value['itemList'] as $k => $v){
                if(empty($v['name'])){
                    $outArr = array(
                        'code'=> 200,
                        'status'=> 302,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        
        $optionArr = array();
        foreach($_GET as $key => $value){
            if(strpos($key, "option_id_") !== false){
                $key = addslashes(ltrim($key, "option_id_"));
                $optionArr[$key]['id'] = intval($value);
            }
            if(strpos($key, "option_market_price_") !== false){
                $key = addslashes(ltrim($key, "option_market_price_"));
                $optionArr[$key]['market_price'] = floatval($value);
            }
            if(strpos($key, "option_buy_price_") !== false){
                $key = addslashes(ltrim($key, "option_buy_price_"));
                $optionArr[$key]['buy_price'] = floatval($value);
            }
            if(strpos($key, "option_vip_price_") !== false){
                $key = addslashes(ltrim($key, "option_vip_price_"));
                $optionArr[$key]['vip_price'] = floatval($value);
            }
            if(strpos($key, "option_stock_") !== false){
                $key = addslashes(ltrim($key, "option_stock_"));
                $optionArr[$key]['stock'] = intval($value);
            }
            if(strpos($key, "option_score_num_") !== false){
                $key = addslashes(ltrim($key, "option_score_num_"));
                $optionArr[$key]['score_num'] = intval($value);
            }
            if(strpos($key, "option_score_dikou_price_") !== false){
                $key = addslashes(ltrim($key, "option_score_dikou_price_"));
                $optionArr[$key]['score_dikou_price'] = floatval($value);
            }
        }
        
        if(empty($optionArr)){
            $outArr = array(
                'code'=> 200,
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }
        
        foreach($optionArr as $key => $value){
            if(empty($value['market_price'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 305,
                );
                echo json_encode($outArr); exit;
            }
            if(empty($value['buy_price'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
            if($tcshopInfo['open_vip_price_set'] == 1 || $__Admin['admin'] == 'admin'){
                if($open_vip == 1){
                    if(empty($value['vip_price'])){
                        $outArr = array(
                            'code'=> 200,
                            'status'=> 307,
                        );
                        echo json_encode($outArr); exit;
                    }
                }
            }
            if($open_score_dikou == 1){
                if(empty($value['score_num'])){
                    $outArr = array(
                        'code'=> 200,
                        'status'=> 308,
                    );
                    echo json_encode($outArr); exit;
                }
                
                if(empty($value['score_dikou_price'])){
                    $outArr = array(
                        'code'=> 200,
                        'status'=> 309,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
    }
    
    if($__Admin['admin'] == 'admin'){
        $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
    }else if($__Admin['admin'] == 'shopadmin'){
        $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($goodsInfo['tcshop_id']);
    }
    
    $provinceInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($province);
    $cityInfo = C::t('#tom_ucenter#tom_ucenter_district')->fetch_by_id($city);
    
    $updateData = array();
    if($__Admin['admin'] == 'admin'){
        $updateData['site_id']              = $tcshopInfo['site_id'];
        $updateData['tcshop_id']            = $tcshopInfo['id'];
        $updateData['user_id']              = $tcshopInfo['user_id'];
    }
    $updateData['title']                = $title;
    $updateData['sub_title']            = $sub_title;
    $updateData['cate_id']              = $cate_id;
    $updateData['cate_child_id']        = $cate_child_id;
    $updateData['shop_cate_id']         = $shop_cate_id;
    $updateData['unit']                 = $unit;
    $updateData['market_price']         = $market_price;
    $updateData['buy_price']            = $buy_price;
    
    if($tcshopInfo['open_vip_price_set'] == 1 || $__Admin['admin'] == 'admin'){
        $updateData['open_vip']             = $open_vip;
        if($open_vip == 1){
            $updateData['vip_price']            = $vip_price;
        }
    }else{
        $updateData['open_vip']             = 0;
    }
    
    $updateData['max_buy']              = $max_buy;
    $updateData['province']             = $provinceInfo['name'];
    $updateData['city']                 = $cityInfo['name'];
    $updateData['keywords']             = $keywords;
    $updateData['hexiao_pwd']           = $hexiao_pwd;
    $updateData['picurl']               = $picurl;
    $updateData['admin_edit']           = $admin_edit;
    $updateData['content']              = $content;
    $updateData['open_express']         = $open_express;
    $updateData['express_id']           = $express_id;
    $updateData['issendfree']           = $issendfree;
    $updateData['ednum']                = $ednum;
    $updateData['edmoney']              = $edmoney;
    $updateData['dispatch_price']       = $dispatch_price;
    $updateData['dispatch_type']        = $dispatch_type;
    $updateData['hasoption']            = $hasoption;
    if($hasoption == 0){
        $updateData['stock']                  = $stock;
        $updateData['show_market_price']      = $market_price;
        $updateData['show_buy_price']         = $buy_price;
        $updateData['show_vip_price']         = $vip_price;
        $updateData['show_score_num']         = $score_num;
        $updateData['show_score_dikou_price'] = $score_dikou_price;
    }
    $updateData['open_score_dikou']     = $open_score_dikou;
    if($open_score_dikou == 1){
        $updateData['score_num']            = $score_num;
        $updateData['score_dikou_price']    = $score_dikou_price;
    }
    if($__Admin['admin'] == 'admin'){
        $updateData['yongjin_bili']         = $yongjin_bili;
        $updateData['hehuoren_tg_open']     = $hehuoren_tg_open;
        if($hehuoren_tg_open == 1){
            $updateData['chuji_fc_scale']       = $chuji_fc_scale;
            $updateData['zhongji_fc_scale']     = $zhongji_fc_scale;
            $updateData['gaoji_fc_scale']       = $gaoji_fc_scale;
        }
        $updateData['isrecommand']          = $isrecommand;
        $updateData['zhibo_roomid']         = $zhibo_roomid;
        $updateData['virtual_sales']        = $virtual_sales;
        $updateData['allow_refund']         = $allow_refund;
        $updateData['gsort']                = $gsort;
        $updateData['shenhe_status']        = 1;
    }
    if($__Admin['admin'] == 'shopadmin'){
        if($tcmallConfig['must_shenhe'] == 1){
            $updateData['shenhe_status']        = 2;
        }else{
            $updateData['shenhe_status']        = 1;
        }
    }
    
    $updateData['search_txt']           = $title.'|'.$keywords.'|'.$labelname;
    $updateData['add_time']             = TIMESTAMP;
    if(C::t('#tom_tcmall#tom_tcmall_goods')->update($goods_id, $updateData)){
        
        C::t('#tom_tcmall#tom_tcmall_goods_photo')->delete_by_goods_id($goods_id);
        
        if(!empty($data['picurl'])){
            $insertData = array();
            $insertData['goods_id']  = $goods_id;
            $insertData['type']      = 2;
            $insertData['picurl']    = $picurl;
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcmall#tom_tcmall_goods_photo')->insert($insertData);
        }
        
        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']     = $goods_id;
                $insertData['type']         = 1;
                $insertData['picurl']       = $value['picurl'];
                $insertData['psort']        = $value['sort'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tcmall#tom_tcmall_goods_photo')->insert($insertData);
            }
        }
        
        if($hasoption == 1){
            
            $specItemList = array();
            foreach($specArr as $key => $value){
                
                if(isset($value['spec_id']) && $value['spec_id'] > 0){
                    $updateData = array();
                    $updateData['name']     = $value['name'];
                    $updateData['ssort']    = $value['ssort'];
                    C::t('#tom_tcmall#tom_tcmall_goods_spec')->update($value['spec_id'], $updateData);
                    $spec_id = $value['spec_id'];
                }else{
                    $insertData = array();
                    $insertData['goods_id'] = $goods_id;
                    $insertData['name']     = $value['name'];
                    $insertData['ssort']    = $value['ssort'];
                    $spec_id = C::t('#tom_tcmall#tom_tcmall_goods_spec')->insert($insertData, true);
                }
                
                foreach($value['itemList'] as $k => $v){
                    $specItemList[$k] = $v;
                    
                    if(isset($v['spec_item_id']) && $v['spec_item_id'] > 0){
                        $updateData = array();
                        $updateData['spec_id']  = $spec_id;
                        $updateData['name']     = $v['name'];
                        $updateData['picurl']   = $v['picurl'];
                        C::t('#tom_tcmall#tom_tcmall_goods_spec_item')->update($v['spec_item_id'], $updateData);
                        $spec_item_id = $v['spec_item_id'];
                    }else{
                        $insertData = array();
                        $insertData['spec_id']  = $spec_id;
                        $insertData['name']     = $v['name'];
                        $insertData['picurl']   = $v['picurl'];
                        $spec_item_id = C::t('#tom_tcmall#tom_tcmall_goods_spec_item')->insert($insertData, true);
                    }
                    
                    $specItemList[$k]['spec_item_id'] = $spec_item_id;
                }
            }
            
            $stock_num = $show_market_price = $show_buy_price = $show_vip_price = $show_score_num = $show_score_dikou_price = 0;
            $beizu = '';
            $optionIdsArr = array();
            foreach($optionArr as $key => $value){
                
                $idsArrTmp = explode('-', $key);
                $specItemIdsArr = $specItemNameArr = array();
                foreach($idsArrTmp as $k => $v){
                    $specItemIdsArr[] = $specItemList[$v]['spec_item_id'];
                    $specItemNameArr[] = $specItemList[$v]['name'];
                }
                $specItemIdsStr = implode('-', $specItemIdsArr);
                $specItemNameStr = implode('+', $specItemNameArr);
                
                $optionInfo = array();
                if($value['id'] > 0){
                    $optionInfo = C::t("#tom_tcmall#tom_tcmall_goods_option")->fetch_by_id($value['id']);
                }

                if(is_array($optionInfo) && !empty($optionInfo)){
                    $updateData = array();
                    $updateData['goods_id']             = $goods_id;
                    $updateData['name']                 = $specItemNameStr;
                    $updateData['market_price']         = $value['market_price'];
                    $updateData['buy_price']            = $value['buy_price'];
                    $updateData['vip_price']            = $value['vip_price'];
                    $updateData['score_num']            = $value['score_num'];
                    $updateData['score_dikou_price']    = $value['score_dikou_price'];
                    $updateData['stock']                = $value['stock'];
                    $updateData['spec_item_ids']        = $specItemIdsStr;
                    C::t("#tom_tcmall#tom_tcmall_goods_option")->update($value['id'], $updateData);
                    $option_id = $value['id'];
                }else{
                    $insertData = array();
                    $insertData['goods_id']             = $goods_id;
                    $insertData['name']                 = $specItemNameStr;
                    $insertData['market_price']         = $value['market_price'];
                    $insertData['buy_price']            = $value['buy_price'];
                    $insertData['vip_price']            = $value['vip_price'];
                    $insertData['stock']                = $value['stock'];
                    $insertData['score_num']            = $value['score_num'];
                    $insertData['score_dikou_price']    = $value['score_dikou_price'];
                    $insertData['spec_item_ids']        = $specItemIdsStr;
                    $option_id = C::t("#tom_tcmall#tom_tcmall_goods_option")->insert($insertData, true);
                }
                $optionIdsArr[] = $option_id;
                if($show_buy_price == 0){
                    $show_market_price      = $value['market_price'];
                    $show_buy_price         = $value['buy_price'];
                    $show_vip_price         = $value['vip_price'];
                    $show_score_num         = $value['score_num'];
                    $show_score_dikou_price = $value['score_dikou_price'];
                }else if($show_buy_price > $value['buy_price'] && $value['buy_price'] > 0){
                    $show_market_price      = $value['market_price'];
                    $show_buy_price         = $value['buy_price'];
                    $show_vip_price         = $value['vip_price'];
                    $show_score_num         = $value['score_num'];
                    $show_score_dikou_price = $value['score_dikou_price'];
                }

                $stock_num = $stock_num + $value['stock'];
                $beizu .= 'ID:&nbsp;<span>'.$option_id.'</span> '.$Lang['option_name'].'<span>'.$specItemNameStr.'</span>'
                        .$Lang['option_stock'].'<span>'.$value['stock'].'</span> '
                        .$Lang['option_market_price'].'<span>'.$value['market_price'].'</span> '
                        .$Lang['option_buy_price'].'<span>'.$value['buy_price'].'</span> ';
                
                if($open_vip == 1){
                    $beizu .= $Lang['option_vip_price'].'<span>'.$value['vip_price'].'</span>';
                }
                if($open_score_dikou == 1){
                    $beizu .= $Lang['option_score_num'].'<span>'.$value['score_num'].'</span>'.$Lang['option_score_dikou_price'].'<span>'.$value['score_dikou_price'].'</span>';
                }
                $beizu .= '<br/>';
                
            }
            
            if(!empty($optionIdsArr)){
                $optionIdsStr = implode(',', $optionIdsArr);
                C::t("#tom_tcmall#tom_tcmall_goods_option")->delete_by_goods_id_not_id($goods_id, $optionIdsStr);
            }
            
            $updateData = array();
            $updateData['stock']                    = $stock_num;
            $updateData['show_market_price']        = $show_market_price;
            $updateData['show_buy_price']           = $show_buy_price;
            $updateData['show_vip_price']           = $show_vip_price;
            $updateData['show_score_num']           = $show_score_num;
            $updateData['show_score_dikou_price']   = $show_score_dikou_price;
            C::t("#tom_tcmall#tom_tcmall_goods")->update($goods_id, $updateData);

            $insertData = array();
            if($__Admin['admin'] == 'admin'){
                $insertData['is_admin']     = 1;
            }
            $insertData['is_option']    = 1;
            $insertData['goods_id']     = $goods_id;
            $insertData['beizu']        = $beizu;
            $insertData['change_num']   = $stock_num;
            $insertData['change_time']  = TIMESTAMP;
            C::t("#tom_tcmall#tom_tcmall_goods_stock_log")->insert($insertData);
        }else{
            $insertData = array();
            if($__Admin['admin'] == 'admin'){
                $insertData['is_admin']     = 1;
            }
            $insertData['goods_id']     = $goods_id;
            $insertData['change_num']   = $stock;
            $insertData['change_time']  = TIMESTAMP;
            C::t('#tom_tcmall#tom_tcmall_goods_stock_log')->insert($insertData);
        }
        
        if($__Admin['admin'] == 'shopadmin' && $tcmallConfig['must_shenhe'] == 1){
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $toUser = $toUserTmp;
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                $access_token = $weixinClass->get_access_token();

                if($access_token && !empty($toUser['openid'])  ){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcmall&site={$site_id}&mod=index");
                    $smsData = array(
                        'first'         => '['.$tcshopInfo['name'].']'.$Lang['shenhe_template_edit'],
                        'keyword1'      => $tcmallConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                        'remark'        => ''
                    );
                    $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}else if($act == 'load_option' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $specArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "spec_id_") !== false){
            $key = intval(ltrim($key, "spec_id_"));
            $specArr[$key]['spec_id'] = intval($value);
        }
        if(strpos($key, "spec_name_") !== false){
            $key = intval(ltrim($key, "spec_name_"));
            $specArr[$key]['name'] = addslashes($value);
        }
        if(strpos($key, "spec_ssort_") !== false){
            $key = intval(ltrim($key, "spec_ssort_"));
            $specArr[$key]['ssort'] = addslashes($value);
        }
        if(strpos($key, "spec_item_id_") !== false){
            $key = addslashes(ltrim($key, "spec_item_id_"));
            if(strpos($key, "_")){
                list($key, $kk) = explode('_', $key);
                $specArr[$key]['itemList'][$kk]['spec_item_id'] = intval($value);
            }
        }
        if(strpos($key, "spec_item_name_") !== false){
            $key = addslashes(ltrim($key, "spec_item_name_"));
            if(strpos($key, "_")){
                list($key, $kk) = explode('_', $key);
                $specArr[$key]['itemList'][$kk]['name'] = addslashes($value);
            }
        }
    }
    
    $specList = array();
    if(!empty($specArr)){
        foreach($specArr as $key => $value){
            $itemCountTmp = count($specArr[$key]['itemList']);
            
            if($itemCountTmp > 0){
                $specList[$key] = $value;
                $specList[$key]['id'] = $key;
                $specList[$key]['itemCount'] = $itemCountTmp;
            }
        }
    }
    
    if(empty($specList)){
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $specList = array_spec_count_sort($specList, 'itemCount');
    
    $optionData = array();
    foreach($specList as $key => $value){
        $itemListTmp = array();
        if(is_array($value['itemList']) && !empty($value['itemList'])){
            foreach($value['itemList'] as $k => $v){
                $arrTmp['id'] = $k;
                $arrTmp['spec_item_id'] = $v['spec_item_id'];
                $arrTmp['name'] = $v['name'];
                
                $itemListTmp[] = $arrTmp;
            }
        }
        $optionData[] = $itemListTmp;
    }
    
    $len = count($optionData);
    $newlen = 1;
    $h = array();
    $rowspans = array();
    for ($i = 0; $i < $len; $i++) {
        $itemlen = count($optionData[$i]);
        if($itemlen <= 0){
            $itemlen = 1;
        }
        $newlen = $newlen*$itemlen;

        $h[$i] = array();
        for ($j = 0; $j < $newlen; $j++) {
            $h[$i][$j] = array();
        }
        $rowspans[$i] = 1;
        for ($j = $i + 1; $j < $len; $j++) {
            $rowspans[$i] *= count($optionData[$j]);
        }
    }

    for ($m = 0; $m < $len; $m++) {
        $k = 0;
        $kid = 0;
        $n = 0;
        for ($j = 0; $j < $newlen; $j++) {
            $rowspan = $rowspans[$m];
            if ($rowspan > 0 && $j % $rowspan == 0) {
                $h[$m][$j] = $optionData[$m][$kid];
                $h[$m][$j]['tb'] = '<td rowspan="'.$rowspan.'">'.$optionData[$m][$kid]['name'].'</td>';
            }else{
                $h[$m][$j] = $optionData[$m][$kid];
                $h[$m][$j]['tb'] = '';
            }
            $n++;
            if ($n == $rowspan) {
                $kid++;
                if ($kid > count($optionData[$m]) - 1) {
                    $kid = 0;
                }
                $n = 0;
            }
        }
    }

    $html = '<table><tr>';
    foreach($specList as $key => $value){
        $html .= '<th>'.$value['name'].'</th>';
    }
    
    $html .= '<th>'.$Lang['add_stock'].'</th>';
    $html .= '<th>'.$Lang['add_market_price'].'</th>';
    $html .= '<th>'.$Lang['add_buy_price'].'</th>';
    $html .= '<th>'.$Lang['add_vip_price'].'</th>';
    $html .= '<th>'.$Lang['add_score_num'].'</th>';
    $html .= '<th>'.$Lang['add_score_dikou_price'].'</th>';
    $html .= '</tr>';
    
    $optionListTmp = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_all_list(" AND goods_id = {$goods_id} ");
    $matchOptionData = $optionData = array();
    if(!empty($optionListTmp)){
        foreach($optionListTmp as $key => $value){
            $optionData[$value['spec_item_ids']] = $value;

            $specItemIdsArrTmp = explode('-', $value['spec_item_ids']);
            sort($specItemIdsArrTmp);
            $specItemIdsStrTmp = implode('-', $specItemIdsArrTmp);
            $matchOptionData[$specItemIdsStrTmp] = $value;
        }
    }
    
    for ($i = 0; $i < $newlen; $i++) {
        $html.= "<tr>";
        $ids = array();
        $itemIds = array();
        $name = array();
        for ($j = 0; $j < $len; $j++) {
            $html.= $h[$j][$i]['tb'];
            $ids[] = $h[$j][$i]['id'];
            $itemIds[] = $h[$j][$i]['spec_item_id'];
            $name[] = $h[$j][$i]['name'];
        }
        $ids = implode('-', $ids);
        $name = implode('+', $name);
        $itemIds = implode('-', $itemIds);
        
        $optionInfo = array();
        if(isset($optionData[$itemIds]) && !empty($optionData[$itemIds])){
            $optionInfo = $optionData[$itemIds];
        }else{
            $specItemIdsArrTmp = explode('-', $itemIds);
            sort($specItemIdsArrTmp);
            $specItemIdsStrTmp = implode('-', $specItemIdsArrTmp);
            if(isset($matchOptionData[$specItemIdsStrTmp]) && !empty($matchOptionData[$specItemIdsStrTmp])){
                $optionInfo = $matchOptionData[$specItemIdsStrTmp];
            }
        }
        
        $html.= "<td>";
        $html.= '<input name="option_stock_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['stock'].'"/></td>';
        $html.= '<input name="option_id_'.$ids.'" type="hidden"  value="'.$optionInfo['id'].'"/></td>';
        $html.= '<input name="spec_item_ids[]" type="hidden"  value="'.$itemIds.'"/></td>';
        $html.= '</td>';
        $html.= "<td>";
        $html.= '<input name="option_market_price_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['market_price'].'"/></td>';
        $html.= '</td>';
        $html.= "<td>";
        $html.= '<input name="option_buy_price_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['buy_price'].'"/></td>';
        $html.= '</td>';
        $html.= "<td>";
        $html.= '<input name="option_vip_price_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['vip_price'].'"/></td>';
        $html.= '</td>';
        $html.= "<td>";
        $html.= '<input name="option_score_num_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['score_num'].'"/></td>';
        $html.= '</td>';
        $html.= "<td>";
        $html.= '<input name="option_score_dikou_price_'.$ids.'" type="text" class="option-input"  value="'.$optionInfo['score_dikou_price'].'"/></td>';
        $html.= '</td>';
        $html.= "</tr>";
    }
    $html .= '</table>';
    
    $html = iconv_to_utf8($html);
    
    $outArr = array(
        'code' => 200,
        'data' => $html,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del_spec' && submitcheck('spec_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $spec_id = intval($_GET['spec_id'])>0? intval($_GET['spec_id']): 0;
    
    C::t("#tom_tcmall#tom_tcmall_goods_spec")->delete_by_id($spec_id);
    C::t("#tom_tcmall#tom_tcmall_goods_spec_item")->delete_by_spec_id($spec_id);
    C::t("#tom_tcmall#tom_tcmall_goods_option")->delete_by_goods_id($goods_id);
    
    $outArr = array(
        'code' => 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del_spec_item' && submitcheck('spec_item_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $spec_item_id = intval($_GET['spec_item_id'])>0? intval($_GET['spec_item_id']): 0;
    
    C::t("#tom_tcmall#tom_tcmall_goods_spec_item")->delete_by_id($spec_item_id);
    
    $outArr = array(
        'code' => 200,
    );
    echo json_encode($outArr); exit;
}

$cateListTmp = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['pid'] > 0){
            $cateChildList[$value['pid']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$goodsInfo['content'] = stripcslashes($goodsInfo['content']);

$tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($goodsInfo['tcshop_id']);

$shopCateListTmp = C::t('#tom_tcshop#tom_tcshop_mall_cate')->fetch_all_list(" AND tcshop_id={$goodsInfo['tcshop_id']} "," ORDER BY csort ASC,id DESC ",0,100);
$shopCateList = array();
if(!empty($shopCateListTmp)){
    foreach($shopCateListTmp as $key => $value){
        $shopCateList[$value['id']] = $value;
    }
}

$districtListTmp = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid(0);
$provinceList = array();
$province_id = 0;
if(!empty($districtListTmp)){
    foreach($districtListTmp as $key => $value){
        $provinceList[$value['id']] = $value;
        if($value['name'] == $goodsInfo['province']){
            $province_id = $value['id'];
        }
    }
}
$districtListTmp = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($province_id);
$cityList = array();
if(!empty($districtListTmp)){
    foreach($districtListTmp as $key => $value){
        $cityList[$value['id']] = $value;
    }
}

$picurl = get_file_url($goodsInfo['picurl']);

$photoListTmp = C::t('#tom_tcmall#tom_tcmall_goods_photo')->fetch_all_list(" AND goods_id = {$goods_id} AND type = 1 ", "ORDER BY psort ASC,id ASC", 0, 100);
$photoList = array();
$i = 1;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $photoList[$key] = $value;
        
        $photoList[$key]['pic_url'] = $value['picurlTmp'];;
        $photoList[$key]['i'] = $i;
        $i++;
    }
}
$photoCount = Count($photoList);

if($goodsInfo['hasoption'] == 1){
    $specListTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec')->fetch_all_list(" AND goods_id = {$goods_id} ", 'ORDER BY ssort ASC ,id ASC', 0, 1000);
    $specList = array();
    $spec_num = 1;
    $spec_item_num = 1;
    if(is_array($specListTmp) && !empty($specListTmp)){
        foreach($specListTmp as $key => $value){
            $specList[$key] = $value;
            $itemListTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec_item')->fetch_all_list(" AND spec_id = {$value['id']} ", 'ORDER BY id ASC', 0, 1000);
            $itemList = array();
            if(is_array($itemListTmp) && !empty($itemListTmp)){
                foreach($itemListTmp as $k => $v){
                    $itemList[$k] = $v;
                    $itemList[$k]['picurlTmp'] = get_file_url($v['picurl']);
                    $itemList[$k]['spec_item_num'] = $spec_item_num;
                    $spec_item_num++;
                }
            }
                    
            $specList[$key]['itemList']     = $itemList;
            $specList[$key]['itemCount']    = count($itemList);
            $specList[$key]['spec_num']     = $spec_num;
            $spec_num++;
        }
    }
}

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:pcadmin/edit");