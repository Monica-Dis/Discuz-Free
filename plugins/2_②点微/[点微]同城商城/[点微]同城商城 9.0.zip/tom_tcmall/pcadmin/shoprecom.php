<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=shoprecom";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcshop_id  = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
    $status     = intval($_GET['status'])>0 ? intval($_GET['status']):0;
    $rsort      = intval($_GET['rsort'])>0 ? intval($_GET['rsort']):0;
    
    $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
    
    $insertData = array();
    $insertData['site_id']      = $tcshopInfo['site_id'];
    $insertData['tcshop_id']    = $tcshopInfo['id'];
    $insertData['status']       = $status;
    $insertData['rsort']        = $rsort;
    $insertData['add_time']     = TIMESTAMP;
    C::t('#tom_tcmall#tom_tcmall_shop_recommend')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'edit' && submitcheck('shoprecom_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $shoprecom_id   = intval($_GET['shoprecom_id'])>0 ? intval($_GET['shoprecom_id']):0;
    $tcshop_id      = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
    $status         = intval($_GET['status'])>0 ? intval($_GET['status']):0;
    $rsort          = intval($_GET['rsort'])>0 ? intval($_GET['rsort']):0;
    
    $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
    
    $updateData = array();
    $updateData['site_id']      = $tcshopInfo['site_id'];
    $updateData['tcshop_id']    = $tcshopInfo['id'];
    $updateData['status']       = $status;
    $updateData['rsort']        = $rsort;
    C::t('#tom_tcmall#tom_tcmall_shop_recommend')->update($shoprecom_id, $updateData);
        
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('shoprecom_id')){
    $outArr = array(
        'code'=> 1,
    );

    $shoprecom_id = intval($_GET['shoprecom_id'])>0 ? intval($_GET['shoprecom_id']):0;

    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcmall#tom_tcmall_shop_recommend')->update($shoprecom_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('shoprecom_id')){
    $outArr = array(
        'code'=> 1,
    );

    $shoprecom_id = intval($_GET['shoprecom_id'])>0 ? intval($_GET['shoprecom_id']):0;

    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcmall#tom_tcmall_shop_recommend')->update($shoprecom_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('shoprecom_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $shoprecom_id = intval($_GET['shoprecom_id'])>0 ? intval($_GET['shoprecom_id']):0; 
    
    C::t('#tom_tcmall#tom_tcmall_shop_recommend')->delete_by_id($shoprecom_id);
        
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = "";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcmall#tom_tcmall_shop_recommend')->fetch_all_count($where,$title);
$recomListTmp = C::t('#tom_tcmall#tom_tcmall_shop_recommend')->fetch_all_list(" "," ORDER BY id DESC ",$start,$pagesize);
$recomList = array();
if(!empty($recomListTmp)){
    foreach ($recomListTmp as $key => $value) {
        $recomList[$key] = $value;
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $tcshopInfoTmp['picurl'] = get_file_url($tcshopInfoTmp['picurl']);
        
        $recomList[$key]['siteInfo']       = $siteInfoTmp;
        $recomList[$key]['tcshopInfo']     = $tcshopInfoTmp;
        $recomList[$key]['add_time']       = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcmall:pcadmin/shoprecom");