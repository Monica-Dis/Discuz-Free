<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$timeStamp = TIMESTAMP;
$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = '20210913';
$sql_in_site_ids = $site_id;
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
include DISCUZ_ROOT . './source/plugin/tom_tcmall/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tcshop/class/function.express.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcmallConfig['wx_share_title'];
$shareDesc = $tcmallConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . 'plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=index';
$shareLogo = $tcmallConfig['wx_share_pic'];
if (CHARSET == 'gbk') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/config/config.gbk.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/config/config.utf8.php';
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')) {
	$tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
	if ($tcyikatongConfig['open_tcyikatong'] == 1) {
		$__ShowTcyikatong = 1;
	}
}
$__ShowTcptuan = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcptuan/tom_tcptuan.inc.php')) {
	$tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
	if ($tcptuanConfig['open_tcptuan'] == 1) {
		$__ShowTcptuan = 1;
	}
}
$__ShowTckjia = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tckjia/tom_tckjia.inc.php')) {
	$tckjiaConfig = $_G['cache']['plugin']['tom_tckjia'];
	if ($tckjiaConfig['open_tckjia'] == 1) {
		$__ShowTckjia = 1;
	}
}
$__ShowKuaidi = 0;
$kuaidiConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_kuaidi/tom_kuaidi.inc.php')) {
	$__ShowKuaidi = 1;
	$kuaidiConfig = $_G['cache']['plugin']['tom_kuaidi'];
}
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')) {
	$tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
	if ($tcqianggouConfig['open_tcqianggou'] == 1) {
		$__ShowTcqianggou = 1;
	}
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$__ShowTcsign = 0;
$tcsignConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcsign/tom_tcsign.inc.php')) {
	$tcsignConfig = $_G['cache']['plugin']['tom_tcsign'];
	$__ShowTcsign = 1;
}
$tcadminConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcadmin/tom_tcadmin.inc.php')) {
	$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')) {
	$tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
	if ($tcchoujiangConfig['open_tcchoujiang'] == 1) {
		$__ShowTcchoujiang = 1;
	}
}
$__ShowZhibo = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_xiaofenlei/admin/zhibo.php')) {
	$__ShowZhibo = 1;
}
$cartGoodsCount = 0;
if ($__UserInfo['id'] > 0) {
	$cartGoodsCount = C::t('#tom_tcmall#tom_tcmall_cart')->fetch_goods_num(' AND user_id=' . $__UserInfo['id'] . ' ');
}
$__CardInfo = array();
if ($__ShowTcyikatong == 1 && $__UserInfo['id'] > 0) {
	$cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($__UserInfo['id']);
	if (is_array($cardInfoTmp) && !empty($cardInfoTmp)) {
		$__CardInfo = $cardInfoTmp;
	}
}
if ($__ShowTcyikatong == 1) {
	$card_name = cutstr($tcyikatongConfig['card_name'], 6, '');
	$buyVipUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=card';
	if ($tcmallConfig['open_one_mode'] == 1) {
		$buyVipUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=card&vfrom=mall';
	}
}
$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
$ajaxRefundqueryUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=refundquery&formhash=' . $formhash;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
$ajaxMiniCartUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=mini_good_list_cart&formhash=' . $formhash;
$ajaxAddMiniCartUrl = 'plugin.php?id=tom_tcmall:cart&site=' . $site_id . '&act=mini_save_cart&user_id=' . $__UserInfo['id'] . '&formhash=' . $formhash;
if ($_GET['mod'] == 'index') {
	if ($tcmallConfig['open_select_sites'] == 1 && $tcadminConfig['open_sites'] == 1) {
		include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/selectSites.php';
	}
	$focuspicListTmp = C::t('#tom_tcmall#tom_tcmall_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' AND type_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tcmall#tom_tcmall_focuspic')->fetch_all_list(' AND site_id=1 AND type_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	$focuspicCount = 0;
	if (is_array($focuspicListTmp) && !empty($focuspicListTmp)) {
		foreach ($focuspicListTmp as $key => $value) {
			$focuspicList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tcmall/') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$focuspicList[$key]['picurl'] = $picurl;
			$focuspicCount++;
		}
	}
	$str_replace_search_array = array('{YIKATONG}', '{KANJIA}', '{PINTUAN}', '{QIANGGOU}', '{HAODIAN}', '{HEHUOREN}', '{COUPON}', '{CHOUJIANG}');
	$str_replace_search_replace = array($buyVipUrl, 'plugin.php?id=tom_tckjia&site=' . $site_id . '&mod=index', 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=index', 'plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=index', 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=index', 'plugin.php?id=tom_tchehuoren&site=' . $site_id . '&mod=inlet', 'plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=couponlist', 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=index');
	$menuList = array();
	$i = 1;
	if (!empty($tcmallConfig['index_nav'])) {
		$index_menu_str = str_replace($str_replace_search_array, $str_replace_search_replace, $tcmallConfig['index_nav']);
		$index_menu_str = str_replace("\r\n", '{n}', $index_menu_str);
		$index_menu_str = str_replace("\n", '{n}', $index_menu_str);
		$index_menu_str = str_replace('{site}', $site_id, $index_menu_str);
		$index_menu_arr = explode('{n}', $index_menu_str);
		if (is_array($index_menu_arr) && !empty($index_menu_arr)) {
			foreach ($index_menu_arr as $key => $value) {
				$menuList[$i] = explode('|', $value);
				$i++;
			}
		}
	}
	$menuCount = count($menuList);
	if ($site_id > 1) {
		$__SitesInfo['tcmall_line2_nav'] = trim($__SitesInfo['tcmall_line2_nav']);
		$__SitesInfo['tcmall_line4_nav'] = trim($__SitesInfo['tcmall_line4_nav']);
		if (!empty($__SitesInfo['tcmall_line2_nav'])) {
			$tcmallConfig['index_line2_nav'] = $__SitesInfo['tcmall_line2_nav'];
		}
		if (!empty($__SitesInfo['tcmall_line4_nav'])) {
			$tcmallConfig['index_line4_nav'] = $__SitesInfo['tcmall_line4_nav'];
		}
	}
	$line2NavList = array();
	if (!empty($tcmallConfig['index_line2_nav'])) {
		$index_line2_str = str_replace("\r\n", '{n}', trim($tcmallConfig['index_line2_nav']));
		$index_line2_str = str_replace("\n", '{n}', $index_line2_str);
		$index_line2_str = str_replace('{site}', $site_id, $index_line2_str);
		$index_line2_arr = explode('{n}', $index_line2_str);
		if (is_array($index_line2_arr) && !empty($index_line2_arr)) {
			foreach ($index_line2_arr as $key => $value) {
				$line2NavList[] = explode('|', $value);
			}
		}
	}
	$line2NavCount = count($line2NavList);
	$line4NavList = array();
	if (!empty($tcmallConfig['index_line4_nav'])) {
		$index_line4_str = str_replace("\r\n", '{n}', trim($tcmallConfig['index_line4_nav']));
		$index_line4_str = str_replace("\n", '{n}', $index_line4_str);
		$index_line4_str = str_replace('{site}', $site_id, $index_line4_str);
		$index_line4_arr = explode('{n}', $index_line4_str);
		if (is_array($index_line4_arr) && !empty($index_line4_arr)) {
			foreach ($index_line4_arr as $key => $value) {
				$line4NavList[] = explode('|', $value);
			}
		}
	}
	$line4NavCount = count($line4NavList);
	$focuspicOneTmp = C::t('#tom_tcmall#tom_tcmall_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' AND type_id=2 ', ' ORDER BY fsort ASC,id DESC ', 0, 1);
	if (!is_array($focuspicOneTmp) || empty($focuspicOneTmp)) {
		$focuspicOneTmp = C::t('#tom_tcmall#tom_tcmall_focuspic')->fetch_all_list(' AND site_id=1 AND type_id=2 ', ' ORDER BY fsort ASC,id DESC ', 0, 1);
	}
	$focuspicOne = array();
	$focuspicOneCount = 0;
	if (is_array($focuspicOneTmp) && !empty($focuspicOneTmp)) {
		foreach ($focuspicOneTmp as $key => $value) {
			$focuspicOne = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$focuspicOne['picurl'] = $picurl;
			$focuspicOneCount++;
		}
	}
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	if ($tcmallConfig['show_tcshop_num'] > 0) {
		$show_tcshop_num = $tcmallConfig['show_tcshop_num'];
	} else {
		$show_tcshop_num = 10;
	}
	$recomListTmp = C::t('#tom_tcmall#tom_tcmall_shop_recommend')->fetch_all_list(' AND site_id IN (' . $sql_in_site_ids . ') ', ' ORDER BY rsort DESC,id DESC ', 0, $show_tcshop_num);
	$recomList = array();
	if (is_array($recomListTmp) && !empty($recomListTmp)) {
		foreach ($recomListTmp as $key => $value) {
			$recomList[$key] = $value;
			$tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
			if (!preg_match('/^http/', $tcshopInfoTmp['picurl'])) {
				if (strpos($tcshopInfoTmp['picurl'], 'source/plugin/tom_') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfoTmp['picurl'];
				} else {
					$picurlTmp = $tcshopInfoTmp['picurl'];
				}
			} else {
				$picurlTmp = $tcshopInfoTmp['picurl'];
			}
			$tcshopInfoTmp['picurl'] = $picurlTmp;
			$goodsCountTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(' AND tcshop_id = ' . $value['tcshop_id'] . ' AND status = 1 AND shenhe_status = 1 ');
			$recomList[$key]['tcshopInfo'] = $tcshopInfoTmp;
			$recomList[$key]['goodsCount'] = $goodsCountTmp;
		}
	}
	$recomCount = count($recomList);
	if ($__ShowTcqianggou == 1) {
		if ($tcmallConfig['index_qianggou_num'] > 0) {
			$qgListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND type_id=1 AND qiang_status IN(1,2) AND site_id IN (' . $sql_in_site_ids . ')  ', ' ORDER BY paixu ASC,id DESC ', 0, $tcmallConfig['index_qianggou_num']);
			$qgList = array();
			if (is_array($qgListTmp) && !empty($qgListTmp)) {
				foreach ($qgListTmp as $key => $value) {
					$qgList[$key] = $value;
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					if (floatval($value['show_buy_price']) <= 0) {
						$qgList[$key]['show_buy_price'] = $value['buy_price'];
						$qgList[$key]['show_vip_price'] = $value['vip_price'];
						$qgList[$key]['show_market_price'] = $value['market_price'];
						$qgList[$key]['show_before_price'] = $value['before_price'];
					}
					$qgList[$key]['picurl'] = $picurlTmp;
				}
			}
			$qgCount = count($qgList);
		}
	}
	if ($__ShowTcptuan == 1) {
		if ($tcmallConfig['index_ptuan_num'] > 0) {
			$ptuanListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND site_id IN (' . $sql_in_site_ids . ') ', ' ORDER BY paixu ASC,id DESC ', 0, $tcmallConfig['index_ptuan_num']);
			$ptuanList = array();
			if (is_array($ptuanListTmp) && !empty($ptuanListTmp)) {
				foreach ($ptuanListTmp as $key => $value) {
					$ptuanList[$key] = $value;
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					$ptuanList[$key]['picurl'] = $picurlTmp;
					if ($value['show_market_price'] <= 0) {
						$ptuanList[$key]['show_market_price'] = $value['market_price'];
						$ptuanList[$key]['show_tuan_price'] = $value['tuan_price'];
					}
					$ptuanList[$key]['sale_num'] = $value['sale_num'] + $value['virtual_sale_num'];
				}
			}
			$ptuanCount = count($ptuanList);
		}
	}
	if ($__ShowTckjia == 1) {
		if ($tcmallConfig['index_kjia_num'] > 0) {
			$kjiaListTmp = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND kanjia_status=1 AND site_id IN (' . $sql_in_site_ids . ')  ', ' ORDER BY kanjia_status ASC,paixu ASC,id DESC ', 0, $tcmallConfig['index_kjia_num']);
			$kjiaList = array();
			if (is_array($kjiaListTmp) && !empty($kjiaListTmp)) {
				foreach ($kjiaListTmp as $key => $value) {
					$kjiaList[$key] = $value;
					if (!preg_match('/^http/', $value['picurl'])) {
						$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
					} else {
						$picurl = $value['picurl'];
					}
					$kjiaList[$key]['picurl'] = $picurl;
				}
			}
			$kjiaCount = count($kjiaList);
		}
	}
	$cateListTmp = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(' AND pid = 0 ', 'ORDER BY csort ASC,id ASC', 0, 100);
	$cateList = array();
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
		}
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=index'));
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=list&goodstype=rec&mini_cart=1&formhash=' . $formhash;
	$searchUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=search');
	if ($__ShowTchehuoren == 1) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tcmall/images/index.js';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcmall:index');
	echo '<script src="source/plugin/tom_tcmall/images/index.js"></script>';
} elseif ($_GET['mod'] == 'cate') {
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$cateListTmp = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(' AND pid = 0 ', 'ORDER BY csort ASC,id ASC', 0, 100);
	$cateList = $cateRtList = array();
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tcmall/') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$cateList[$key]['picurl'] = $picurl;
			if ($cate_id == 0 || $cate_id == $value['id']) {
				$cateRtList[$key] = $value;
				$cateRtList[$key]['picurl'] = $picurl;
				$cateChildListTmp = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(' AND pid = ' . $value['id'], 'ORDER BY csort ASC,id ASC', 0, 100);
				$cateChildList = array();
				if (is_array($cateChildListTmp) && !empty($cateChildListTmp)) {
					foreach ($cateChildListTmp as $ck => $cv) {
						$cateChildList[$ck] = $cv;
						if (!preg_match('/^http/', $cv['picurl'])) {
							if (strpos($cv['picurl'], 'source/plugin/tom_tcmall/') === false) {
								$childPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $cv['picurl'];
							} else {
								$childPicurl = $cv['picurl'];
							}
						} else {
							$childPicurl = $cv['picurl'];
						}
						$cateChildList[$ck]['picurl'] = $childPicurl;
					}
				}
				$cateRtList[$key]['cateChildList'] = $cateChildList;
			}
		}
	}
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	if ($tcmallConfig['show_tcshop_num'] > 0) {
		$show_tcshop_num = $tcmallConfig['show_tcshop_num'];
	} else {
		$show_tcshop_num = 10;
	}
	$recomListTmp = C::t('#tom_tcmall#tom_tcmall_shop_recommend')->fetch_all_list(' AND site_id IN (' . $sql_in_site_ids . ') ', ' ORDER BY rsort DESC,id DESC ', 0, $show_tcshop_num);
	$recomList = array();
	if (is_array($recomListTmp) && !empty($recomListTmp)) {
		foreach ($recomListTmp as $key => $value) {
			$recomList[$key] = $value;
			$tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
			if (!preg_match('/^http/', $tcshopInfoTmp['picurl'])) {
				if (strpos($tcshopInfoTmp['picurl'], 'source/plugin/tom_tcshop/') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfoTmp['picurl'];
				} else {
					$picurlTmp = $tcshopInfoTmp['picurl'];
				}
			} else {
				$picurlTmp = $tcshopInfoTmp['picurl'];
			}
			$tcshopInfoTmp['picurl'] = $picurlTmp;
			$goodsCountTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(' AND tcshop_id = ' . $value['tcshop_id'] . ' AND status = 1 AND shenhe_status = 1 ');
			$recomList[$key]['tcshopInfo'] = $tcshopInfoTmp;
			$recomList[$key]['goodsCount'] = $goodsCountTmp;
		}
	}
	$recomCount = count($recomList);
	if ($tcmallConfig['open_cate_template'] == 1) {
		$where = 'AND site_id IN (' . $sql_in_site_ids . ') AND shenhe_status = 1 AND status = 1';
		if ($cate_id > 0) {
			$cateInfo = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_by_id($cate_id);
			$where .= ' AND cate_id = ' . $cate_id . ' ';
		}
		$goodsListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list($where, 'ORDER BY isrecommand DESC,gsort DESC ,id DESC', 0, 10);
		$goodsCount = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count($where);
		$goodsList = array();
		if (is_array($goodsListTmp) && !empty($goodsListTmp)) {
			foreach ($goodsListTmp as $key => $value) {
				$goodsList[$key] = $value;
				if (!preg_match('/^http/', $value['picurl'])) {
					if (strpos($value['picurl'], 'source/plugin/tom_tcmall/') === false) {
						$goodsPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
					} else {
						$goodsPicurl = $value['picurl'];
					}
				} else {
					$goodsPicurl = $value['picurl'];
				}
				$photoInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods_photo')->fetch_all_list(' AND goods_id = ' . $value['id'] . ' AND type = 2 ', ' ORDER BY id ASC ', 0, 1);
				if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
					$goodsPicurl = $photoInfoTmp[0]['picurlTmp'];
				}
				$goodsSpecCountTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec')->fetch_all_count(' AND goods_id=' . $value['id'] . ' ');
				$tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
				$goodsList[$key]['picurl'] = $goodsPicurl;
				$goodsList[$key]['sales'] = $value['virtual_sales'] + $value['sales'];
				$goodsList[$key]['specCount'] = $goodsSpecCountTmp;
				$goodsList[$key]['tcshopInfo'] = $tcshopInfoTmp;
			}
		}
	}
	$searchUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=search');
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=cate');
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	if ($tcmallConfig['open_cate_template'] == 1) {
		include template('tom_tcmall:cate1');
	} elseif ($tcmallConfig['open_cate_template'] == 2) {
		include template('tom_tcmall:cate2');
	}
} elseif ($_GET['mod'] == 'list') {
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$is_vip = intval($_GET['is_vip']) > 0 ? intval($_GET['is_vip']) : 0;
	$is_tg = intval($_GET['is_tg']) > 0 ? intval($_GET['is_tg']) : 0;
	$is_score = intval($_GET['is_score']) > 0 ? intval($_GET['is_score']) : 0;
	$coupon_id = intval($_GET['coupon_id']) > 0 ? intval($_GET['coupon_id']) : 0;
	$goodstype = isset($_GET['goodstype']) ? daddslashes($_GET['goodstype']) : '';
	$cateListTmp = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list('AND pid = 0', 'ORDER BY csort ASC,id ASC', 0, 100);
	$cateList = array();
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
		}
	}
	if ($cate_id > 0) {
		$cateChildListTmp = C::t('#tom_tcmall#tom_tcmall_cate')->fetch_all_list(' AND pid = ' . $cate_id . ' ', 'ORDER BY csort ASC,id ASC', 0, 100);
		$cateChildList = array();
		if (is_array($cateChildListTmp) && !empty($cateChildListTmp)) {
			foreach ($cateChildListTmp as $key => $value) {
				if (!preg_match('/^http/', $value['picurl'])) {
					if (strpos($value['picurl'], 'source/plugin/') === false) {
						$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
					} else {
						$picurlTmp = $_G['siteurl'] . $value['picurl'];
					}
				} else {
					$picurlTmp = $value['picurl'];
				}
				$cateChildList[$key] = $value;
				$cateChildList[$key]['picurl'] = $picurlTmp;
			}
		}
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=list&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&goodstype=' . $goodstype . '&is_vip=' . $is_vip . '&is_tg=' . $is_tg . '&coupon_id=' . $coupon_id . '&is_score=' . $is_score));
	$searchUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=search');
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=list&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&goodstype=' . $goodstype . '&is_vip=' . $is_vip . '&is_tg=' . $is_tg . '&coupon_id=' . $coupon_id . '&is_score=' . $is_score . '&mini_cart=1&formhash=' . $formhash;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=list&cate_id=' . $cate_id);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcmall:list');
} elseif ($_GET['mod'] == 'goodsinfo') {
	$goods_id = intval($_GET['goods_id']) > 0 ? intval($_GET['goods_id']) : 0;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		if ($tchehuorenConfig['tcmall_type'] == 1 || $tchehuorenConfig['tcmall_type'] == 3) {
			$tj_hehuoren_id = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
			if ($tj_hehuoren_id > 0) {
				$lifeTime = 86400;
				dsetcookie('tom_tcmall_tj_hehuoren_id_goods_' . $goods_id, $tj_hehuoren_id, $lifeTime);
			} else {
				$cookie_tj_hehuoren_id = getcookie('tom_tcmall_tj_hehuoren_id_goods_' . $goods_id);
				if ($cookie_tj_hehuoren_id > 0) {
					$tj_hehuoren_id = $cookie_tj_hehuoren_id;
				}
			}
		}
		if ($tchehuorenConfig['tcmall_type'] == 2 && $__UserInfo['tj_hehuoren_id'] > 0) {
			$tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
		}
		if ($tchehuorenConfig['tcmall_type'] == 3 && $__UserInfo['tj_hehuoren_id'] > 0 && $tj_hehuoren_id == 0) {
			$tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
		}
		if ($tcmallConfig['open_hehuoren_self_sheng'] == 1) {
			$tchehuorenInfoTmpTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
			if ($tchehuorenInfoTmpTmp && $tchehuorenInfoTmpTmp['status'] == 1) {
				$tj_hehuoren_id = $tchehuorenInfoTmpTmp['id'];
			}
		}
	}
	$goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($goods_id);
	if ($goodsInfo['id'] <= 0) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	if ($tcshopInfo['status'] != 1 || $tcshopInfo['shenhe_status'] != 1 || $tcshopInfo['vip_status'] != 1 || $tcshopInfo['vip_time'] <= TIMESTAMP) {
		if ($tcshopInfo['id'] > 0) {
			DB::query('UPDATE ' . DB::table('tom_tcmall_goods') . (' SET status=0 WHERE tcshop_id=' . $tcshopInfo['id'] . ' '), 'UNBUFFERED');
		} else {
			DB::query('UPDATE ' . DB::table('tom_tcmall_goods') . (' SET status=0 WHERE id=' . $goodsInfo['id'] . ' '), 'UNBUFFERED');
		}
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/tom_tcmall/') === false) {
			$goodsPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$goodsPicurl = $_G['siteurl'] . $goodsInfo['picurl'];
		}
	} else {
		$goodsPicurl = $goodsInfo['picurl'];
	}
	$sales = $goodsInfo['virtual_sales'] + $goodsInfo['sales'];
	if (!preg_match('/^http/', $tcshopInfo['kefu_qrcode'])) {
		if (strpos($tcshopInfo['kefu_qrcode'], 'source/plugin/tom_tcshop/') === false) {
			$kefu_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['kefu_qrcode'];
		} else {
			$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
		}
	} else {
		$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
	}
	$couponListTmp = C::t('#tom_tcmall#tom_tcmall_coupon')->fetch_all_list(' AND tcshop_id=' . $goodsInfo['tcshop_id'] . '  AND status = 1 AND start_time <= ' . $timeStamp . ' AND end_time > ' . $timeStamp . ' ', 'ORDER BY id DESC', 0, 10);
	$couponList = array();
	if (is_array($couponListTmp) && !empty($couponListTmp)) {
		foreach ($couponListTmp as $key => $value) {
			$couponStatus = 0;
			if ($value['coupon_type'] == 1) {
				$couponStatus = 1;
			} elseif ($value['coupon_type'] == 2) {
				$goodsIdsArr = explode('|', $value['goods_ids']);
				if (in_array($goods_id, $goodsIdsArr)) {
					$couponStatus = 1;
				}
			}
			if ($couponStatus == 1) {
				$lingquStatus = 1;
				if ($__UserInfo['id'] > 0) {
					$lingquCount = C::t('#tom_tcmall#tom_tcmall_coupon_lingqu')->fetch_all_count(' AND user_id = ' . $__UserInfo['id'] . ' AND coupon_id = ' . $value['id'] . ' ');
					if ($lingquCount > 0) {
						$lingquInfoTmp = C::t('#tom_tcmall#tom_tcmall_coupon_lingqu')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND coupon_id = ' . $value['id'] . ' AND status = 0 ', 'ORDER BY id ASC', 0, 1);
						if (is_array($lingquInfoTmp) && !empty($lingquInfoTmp[0])) {
							$lingquStatus = 2;
						} else {
							if ($lingquCount >= $value['max_lingqu_num']) {
								$lingquStatus = 3;
							}
						}
					}
				}
				$couponList[$key] = $value;
				$couponList[$key]['lingqu_status'] = $lingquStatus;
			}
		}
	}
	$couponCount = count($couponList);
	if ($goodsInfo['admin_edit'] == 1) {
		$content = stripslashes($goodsInfo['content']);
	} else {
		$content = stripslashes($goodsInfo['content']);
		$content = strip_tags($content);
		$content = str_replace("\r\n", '<br/>', $content);
		$content = str_replace("\n", '<br/>', $content);
		$content = str_replace("\r", '<br/>', $content);
	}
	$syBuyGoodsCount = $goodsInfo['max_buy'];
	if ($goodsInfo['max_buy'] > 0 && $__UserInfo['id'] > 0) {
		$buyGoodsCount = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_goods_num('AND goods_id = ' . $goods_id . ' AND user_id = ' . $__UserInfo['id'] . ' AND order_status IN(1,2,3,4,8) ');
		$syBuyGoodsCount = $goodsInfo['max_buy'] - $buyGoodsCount;
	}
	$showVipPriceStatus = 0;
	if ($__ShowTcyikatong == 1 && $goodsInfo['open_vip'] == 1) {
		$showVipPriceStatus = 1;
	}
	$photoListTmp = C::t('#tom_tcmall#tom_tcmall_goods_photo')->fetch_all_list(' AND goods_id = ' . $goods_id . ' AND type = 1 ', ' ORDER BY psort ASC,id ASC ', 0, 100);
	$photoList = $photoArr = $focuspicList = array();
	$photoCount = 0;
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			$photoArr[] = $value['picurlTmp'];
			if ($photoCount < 3) {
				$focuspicList[$key]['picurl'] = $value['picurlTmp'];
			} else {
				$photoList[$key]['picurl'] = $value['picurlTmp'];
			}
			$photoCount++;
		}
	}
	$photoListStr = implode('|', $photoArr);
	$goodsSpecListTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec')->fetch_all_list(' AND goods_id=' . $goods_id . ' ', ' ORDER BY ssort ASC,id ASC ', 0, 100);
	$goodsSpecList = $specArr = array();
	$i = 0;
	if (is_array($goodsSpecListTmp) && !empty($goodsSpecListTmp)) {
		foreach ($goodsSpecListTmp as $key => $value) {
			$goodsSpecList[$key] = $value;
			$specItemListTmp = C::t('#tom_tcmall#tom_tcmall_goods_spec_item')->fetch_all_list(' AND spec_id=' . $value['id'] . ' ', ' ORDER BY isort ASC,id ASC ', 0, 100);
			$specItemList = array();
			if (is_array($specItemListTmp) && !empty($specItemListTmp)) {
				foreach ($specItemListTmp as $k => $v) {
					$specItemList[$k] = $v;
					$picurl = '';
					if (!empty($v['picurl'])) {
						if (!preg_match('/^http/', $v['picurl'])) {
							if (strpos($v['picurl'], 'source/plugin/tom_tcmall/') === false) {
								$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $v['picurl'];
							} else {
								$picurl = $v['picurl'];
							}
						} else {
							$picurl = $v['picurl'];
						}
					}
					$specItemList[$k]['picurl'] = $picurl;
				}
			}
			$goodsSpecList[$key]['specItemList'] = $specItemList;
			if ($i < 2) {
				$specArr[] = $value['name'];
			}
			$i++;
		}
	}
	$specStr = implode(lang('plugin/tom_tcmall', 'goodsinfo_dian'), $specArr);
	$specCount = count($goodsSpecList);
	$show_max_buy_price = 0;
	$show_max_market_price = 0;
	$show_max_vip_price = 0;
	$optionListTmp = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_all_list(' AND goods_id=' . $goods_id . ' ', ' ORDER BY id ASC ', 0, 1000);
	$optionList = array();
	if (is_array($optionListTmp) && !empty($optionListTmp)) {
		foreach ($optionListTmp as $key => $value) {
			$optionList[$key]['spec_item_ids'] = $value['spec_item_ids'];
			$optionList[$key]['stock'] = $value['stock'];
			$optionList[$key]['buy_price'] = $value['buy_price'];
			$optionList[$key]['vip_price'] = $value['vip_price'];
			$optionList[$key]['name'] = diconv($value['name'], CHARSET, 'utf-8');
			if ($value['buy_price'] > $show_max_buy_price) {
				$show_max_buy_price = $value['buy_price'];
			}
			if ($value['market_price'] > $show_max_market_price) {
				$show_max_market_price = $value['market_price'];
			}
			if ($value['vip_price'] > $show_max_vip_price) {
				$show_max_vip_price = $value['vip_price'];
			}
		}
	}
	if ($goodsInfo['show_buy_price'] > 100) {
		$goodsInfo['show_buy_price'] = intval($goodsInfo['show_buy_price']);
	}
	if ($show_max_buy_price > 100) {
		$show_max_buy_price = intval($show_max_buy_price);
	}
	if ($goodsInfo['show_market_price'] > 100) {
		$goodsInfo['show_market_price'] = intval($goodsInfo['show_market_price']);
	}
	if ($show_max_market_price > 100) {
		$show_max_market_price = intval($show_max_market_price);
	}
	$optionArr = json_encode($optionList);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
		if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_tcshop/') === false) {
			$tcshopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
		} else {
			$tcshopPicurl = $tcshopInfo['picurl'];
		}
	} else {
		$tcshopPicurl = $tcshopInfo['picurl'];
	}
	$isTcshopClerk = 0;
	if ($__UserInfo['id'] > 0) {
		$clerkListTmp = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(' AND tcshop_id=' . $goodsInfo['tcshop_id'] . ' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 1);
		if (!empty($clerkListTmp[0]['id']) || $tcshopInfo['user_id'] == $__UserInfo['id']) {
			$isTcshopClerk = 1;
		}
	}
	$pinglunCount = C::t('#tom_tcmall#tom_tcmall_pinglun')->fetch_all_count(' AND goods_id = ' . $goods_id . ' ');
	$pinglunListTmp = C::t('#tom_tcmall#tom_tcmall_pinglun')->fetch_all_list(' AND goods_id = ' . $goods_id . ' ', 'ORDER BY id DESC', 0, 1);
	$pinglunList = array();
	if (is_array($pinglunListTmp) && !empty($pinglunListTmp)) {
		foreach ($pinglunListTmp as $key => $value) {
			$pinglunList[$key] = $value;
			$pinglunUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$pinglunPhotoListTmpTmp = C::t('#tom_tcmall#tom_tcmall_pinglun_photo')->fetch_all_list(' AND pinglun_id = ' . $value['id'] . ' ', 'ORDER BY id DESC', 0, 100);
			$pinglunPhotoListTmp = array();
			if (is_array($pinglunPhotoListTmpTmp) && !empty($pinglunPhotoListTmpTmp)) {
				foreach ($pinglunPhotoListTmpTmp as $pk => $pv) {
					if (!preg_match('/^http/', $pv['picurl'])) {
						if (strpos($pv['picurl'], 'source/plugin/tom_') === false) {
							$pinglunPhotoListTmp[] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $pv['picurl'];
						} else {
							$pinglunPhotoListTmp[] = $pv['picurl'];
						}
					} else {
						$pinglunPhotoListTmp[] = $pv['picurl'];
					}
				}
			}
			$replyPinglunListTmp = C::t('#tom_tcmall#tom_tcmall_pinglun_reply')->fetch_all_list(' AND pinglun_id = ' . $value['id'] . ' ', 'ORDER BY id ASC', 0, 10);
			$pinglunList[$key]['userInfo'] = $pinglunUserInfo;
			$pinglunList[$key]['photoList'] = $pinglunPhotoListTmp;
			$pinglunList[$key]['photoStr'] = implode('|', $pinglunPhotoListTmp);
			$pinglunList[$key]['replyList'] = $replyPinglunListTmp;
		}
	}
	$isShowCollectStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$collectInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods_collect')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND goods_id = ' . $goods_id, 'ORDER BY id DESC', 0, 1);
		if (is_array($collectInfoTmp) && !empty($collectInfoTmp[0])) {
			$isShowCollectStatus = 1;
		}
	}
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$tjWhere = ' AND status = 1 AND shenhe_status = 1 AND id != ' . $goods_id . '  AND site_id IN (' . $sql_in_site_ids . ') ';
	if ($tcmallConfig['goodsinfo_tj_shop'] == 1) {
		$tjWhere .= ' AND cate_id = ' . $goodsInfo['cate_id'] . ' ';
	}
	if ($tcmallConfig['open_shop_rec'] == 1) {
		$tjWhere .= ' AND tcshop_id = ' . $goodsInfo['tcshop_id'] . ' ';
	}
	$newGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list($tjWhere, 'ORDER BY id DESC', 0, 5);
	$newGoodsList = array();
	if (is_array($newGoodsListTmp) && !empty($newGoodsListTmp)) {
		foreach ($newGoodsListTmp as $key => $value) {
			$newGoodsList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tcmall/') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$photoInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods_photo')->fetch_all_list(' AND goods_id = ' . $value['id'] . ' AND type = 2 ', ' ORDER BY id ASC ', 0, 1);
			if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
				$picurlTmp = $photoInfoTmp[0]['picurlTmp'];
			}
			$newGoodsList[$key]['picurl'] = $picurlTmp;
		}
	}
	$newGoodsCount = count($newGoodsList);
	$hotGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list($tjWhere, 'ORDER BY sales DESC,id DESC', 0, 5);
	$hotGoodsList = array();
	if (is_array($hotGoodsListTmp) && !empty($hotGoodsListTmp)) {
		foreach ($hotGoodsListTmp as $key => $value) {
			$hotGoodsList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tcmall/') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$photoInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods_photo')->fetch_all_list(' AND goods_id = ' . $value['id'] . ' AND type = 2 ', ' ORDER BY id ASC ', 0, 1);
			if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
				$picurlTmp = $photoInfoTmp[0]['picurlTmp'];
			}
			$hotGoodsList[$key]['picurl'] = $picurlTmp;
		}
	}
	$hotGoodsCount = count($hotGoodsList);
	$showTgButton = 0;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0 && $goodsInfo['hehuoren_tg_open'] == 1) {
		$tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfo['status'] == 1) {
			$dengjiInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
			$dengjiInfo = array();
			if (is_array($dengjiInfoTmp) && !empty($dengjiInfoTmp)) {
				$dengjiInfo = $dengjiInfoTmp;
			}
			if ($dengjiInfo['mall_fc_open'] == 1) {
				if ($goodsInfo['site_id'] > 1) {
					$siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($goodsInfo['site_id']);
					if ($siteInfoTmp['hehuoren_fc_open'] == 1) {
						$showTgButton = 1;
					}
				} else {
					if ($goodsInfo['site_id'] == 1) {
						$showTgButton = 1;
					}
				}
			}
			if ($showTgButton == 1) {
				$needPrice = 0;
				$yongjin_bili = $tcmallConfig['yongjin_bili'];
				if ($goodsInfo['yongjin_bili'] > 0) {
					$yongjin_bili = $goodsInfo['yongjin_bili'];
				}
				$pay_price = $goodsInfo['buy_price'];
				$pt_money = $goodsInfo['show_buy_price'];
				$pt_money = $pt_money * ($yongjin_bili / 100);
				$pt_money = number_format($pt_money, 2, '.', '');
				if ($dengjiInfo['level'] == 1) {
					$needPrice = $pt_money * ($goodsInfo['chuji_fc_scale'] / 100);
				} elseif ($dengjiInfo['level'] == 2) {
					$needPrice = $pt_money * ($goodsInfo['zhongji_fc_scale'] / 100);
				} elseif ($dengjiInfo['level'] == 3) {
					$needPrice = $pt_money * ($goodsInfo['gaoji_fc_scale'] / 100);
				}
				$needPrice = number_format($needPrice, 2, '.', '');
				$tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
				if ($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1) {
					$tctchehuorenParentInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
					$tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
				}
				if (!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1) {
					$tctchehuorenParent_fc_money = $needPrice * ($tctchehuorenParentDengji['tuijian_fc_scale'] / 100);
					$tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money, 2, '.', '');
					if ($tchehuorenConfig['subordinate_moneytype'] != 1) {
						$needPrice = $needPrice - $tctchehuorenParent_fc_money;
					}
				}
			}
		}
	}
	if ($__ShowTcsign == 1) {
		include DISCUZ_ROOT . './source/plugin/tom_tcsign/renwu/mall.php';
	}
	$showZhiboBox = 0;
	if ($__ShowZhibo == 1 && $goodsInfo['zhibo_roomid'] > 0) {
		$zhiboInfo = C::t('#tom_xiaofenlei#tom_xiaofenlei_zhibo')->fetch_by_roomid($goodsInfo['zhibo_roomid']);
		if ($zhiboInfo && $zhiboInfo['id'] > 0 && $zhiboInfo['end_time'] > TIMESTAMP) {
			$showZhiboBox = 1;
			if (!preg_match('/^http/', $zhiboInfo['cover_img'])) {
				if (strpos($zhiboInfo['cover_img'], 'source/plugin/tom_') === false) {
					$zhiboInfo['cover_img'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $zhiboInfo['cover_img'];
				} else {
					$zhiboInfo['cover_img'] = rtrim($_G['siteurl'], '/') . '/' . $zhiboInfo['cover_img'];
				}
			}
		}
	}
	$ajaxLingquCouponUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=lingqu_coupon&user_id=' . $__UserInfo['id'] . '&formhash=' . $formhash;
	$kefuSmsUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&&to_user_id=' . $tcshopInfo['user_id'] . '&tcmall_goods_id=' . $goods_id . '&formhash=' . FORMHASH;
	$replyPinglunUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=reply_pinglun&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$ajaxGoodsItemUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=goods_item&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$ajaxClicksUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=goods_clicks&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$ajaxCollectUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=goods_collect&user_id=' . $__UserInfo['id'] . '&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$refreshOrderStatusUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=refresh_order_status&goods_id=' . $goods_id . '&formhash=' . $formhash;
	if ($tj_hehuoren_id > 0 && $goodsInfo['hehuoren_tg_open'] == 1) {
		$ajaxSaveCartUrl = 'plugin.php?id=tom_tcmall:cart&site=' . $site_id . '&act=save_cart&goods_id=' . $goods_id . '&tj_hehuoren_id=' . $tj_hehuoren_id . '&formhash=' . $formhash;
		$buyUrl = 'plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=goodsbuy&goods_id=' . $goods_id . '&tj_hehuoren_id=' . $tj_hehuoren_id . '&formhash=' . $formhash;
	} else {
		$ajaxSaveCartUrl = 'plugin.php?id=tom_tcmall:cart&site=' . $site_id . '&act=save_cart&goods_id=' . $goods_id . '&formhash=' . $formhash;
		$buyUrl = 'plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=goodsbuy&goods_id=' . $goods_id . '&formhash=' . $formhash;
	}
	$shareTitle = str_replace('{TITLE}', $goodsInfo['title'], $tcmallConfig['goodsinfo_share_title']);
	$shareTitle = str_replace('{SHOPNAME}', $tcshopInfo['name'], $shareTitle);
	$shareTitle = str_replace('{MALLNAME}', $tcmallConfig['plugin_name'], $shareTitle);
	$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	if (!empty($content)) {
		$contentTmp = strip_tags($content);
		$contentTmp = str_replace("\r\n", '', $contentTmp);
		$contentTmp = str_replace("\n", '', $contentTmp);
		$contentTmp = str_replace("\r", '', $contentTmp);
		$shareDesc = cutstr($contentTmp, 80, '...');
	}
	if (!empty($goodsInfo['sub_title'])) {
		$shareDesc = cutstr($goodsInfo['sub_title'], 80, '...');
	}
	$shareLogo = $goodsPicurl;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=goodsinfo&goods_id=' . $goods_id . '&tj_hehuoren_id=' . $tchehuorenInfo['id']);
	$haibaoQrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($shareUrl);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcmall:goodsinfo');
} elseif ($_GET['mod'] == 'pinglunlist') {
	$goods_id = intval($_GET['goods_id']) > 0 ? intval($_GET['goods_id']) : 0;
	$replyPinglunUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=reply_pinglun&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=pinglun_list&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcmall:pinglunlist');
} elseif ($_GET['mod'] == 'collect') {
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=collect_list&user_id=' . $__UserInfo['id'] . '&formhash=' . $formhash;
	$ajaxRemoveCollectUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=remove_collect&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcmall:collect');
} elseif ($_GET['mod'] == 'search') {
	$cookieKeywordsStr = getcookie('tom_tcmall_keywords_str');
	$keywordsArr = array();
	if (!empty($cookieKeywordsStr)) {
		$keywordsArr = explode('|', $cookieKeywordsStr);
	}
	$keywordsCount = count($keywordsArr);
	$defaultStr = $tcmallConfig['default_search_str'];
	$defaultArr = array();
	if (!empty($defaultStr)) {
		$defaultArr = explode('|', $defaultStr);
	}
	$defaultCount = count($defaultArr);
	$searchUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=get_search_url';
	$search2Url = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=get_search2_url&formhash=' . $formhash;
	$ajaxClearSearchUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=clear_search&formhash=' . $formhash;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=search');
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcmall:search');
} elseif ($_GET['mod'] == 'cart') {
	$cartListTmp = C::t('#tom_tcmall#tom_tcmall_cart')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 100);
	$cartList = array();
	if (is_array($cartListTmp) && !empty($cartListTmp)) {
		foreach ($cartListTmp as $key => $value) {
			$cartList[$key] = $value;
			$goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($value['goods_id']);
			$tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfoTmp['tcshop_id']);
			$goodsPicurl = '';
			if (is_array($goodsInfoTmp) && !empty($goodsInfoTmp)) {
				if (!preg_match('/^http/', $goodsInfoTmp['picurl'])) {
					if (strpos($goodsInfoTmp['picurl'], 'source/plugin/') === false) {
						$goodsPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfoTmp['picurl'];
					} else {
						$goodsPicurl = $goodsInfoTmp['picurl'];
					}
				} else {
					$goodsPicurl = $goodsInfoTmp['picurl'];
				}
			}
			$goodsInfoTmp['picurl'] = $goodsPicurl;
			$showVipPriceStatus = 0;
			if ($goodsInfoTmp['open_vip'] == 1 && $__CardInfo['status'] == 1) {
				$showVipPriceStatus = 1;
			}
			if ($showVipPriceStatus == 1) {
				$buy_price = $goodsInfoTmp['vip_price'];
			} else {
				$buy_price = $goodsInfoTmp['buy_price'];
			}
			$stock = $goodsInfoTmp['stock'];
			$status = 1;
			$optionInfo = array();
			if ($value['option_id'] > 0) {
				$optionInfo = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_by_id($value['option_id']);
				if ($optionInfo && $optionInfo['id'] > 0) {
					$stock = $optionInfo['stock'];
					if ($showVipPriceStatus == 1) {
						$buy_price = $optionInfo['vip_price'];
					} else {
						$buy_price = $optionInfo['buy_price'];
					}
				} else {
					$status = 3;
				}
			}
			if ($goodsInfoTmp['status'] != 1 || $goodsInfoTmp['shenhe_status'] != 1) {
				$status = 2;
			}
			if ($value['goods_num'] > $stock) {
				$status = 3;
			}
			if ($tcshopInfoTmp['peisong_type'] == 0) {
				$status = 4;
			}
			$cartList[$key]['goodsInfo'] = $goodsInfoTmp;
			$cartList[$key]['optionInfo'] = $optionInfo;
			$cartList[$key]['buy_price'] = $buy_price;
			$cartList[$key]['showVipPriceStatus'] = $showVipPriceStatus;
			$cartList[$key]['status'] = $status;
		}
	}
	$cartCount = count($cartList);
	$removeCartUrl = 'plugin.php?id=tom_tcmall:cart&site=' . $site_id . '&act=remove_cart&formhash=' . $formhash;
	$updateCartTotalUrl = 'plugin.php?id=tom_tcmall:cart&site=' . $site_id . '&act=update_cart_total&formhash=' . $formhash;
	$goBuyUrl = 'plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=cartbuy&ids=';
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=cart');
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcmall:cart');
} elseif ($_GET['mod'] == 'cartbuy') {
	$cart_ids = isset($_GET['ids']) ? daddslashes($_GET['ids']) : '';
	$address_id = isset($_GET['address_id']) ? intval($_GET['address_id']) : 0;
	$latitude = getcookie('tom_tongcheng_user_latitude');
	$longitude = getcookie('tom_tongcheng_user_longitude');
	$address_back_url = $weixinClass->get_url();
	$address_back_url = preg_replace('/&address_id=[0-9]*/', '', $address_back_url);
	$address_back_url = urlencode($address_back_url);
	$setAddressStatus = 0;
	$setAddressUrl = '';
	$addressListCount = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_count(' AND uid=' . $__MemberInfo['uid'] . ' ');
	if ($addressListCount == 0) {
		$setAddressStatus = 1;
		$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $address_back_url);
	}
	$addressInfo = array();
	$addressInfoTmp = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
	if ($addressInfoTmp) {
		$addressInfo = $addressInfoTmp;
	} else {
		$defaultAddressList = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_list(' AND uid=' . $__MemberInfo['uid'] . ' AND default_id=1 ', 'ORDER BY id DESC', 0, 1);
		if ($defaultAddressList && !empty($defaultAddressList['0']['id'])) {
			$address_id = $defaultAddressList['0']['id'];
			$addressInfo = $defaultAddressList['0'];
		} else {
			$setAddressStatus = 1;
			$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $address_back_url);
		}
	}
	$changeAddressUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&buying=1&address_id=' . $address_id . '&address_back_url=' . $address_back_url;
	$cartIdsArr = explode('_', trim($cart_ids, '_'));
	$cartIdsList = array();
	if (is_array($cartIdsArr) && !empty($cartIdsArr)) {
		foreach ($cartIdsArr as $key => $value) {
			$id = intval($value);
			if ($id > 0) {
				$cartIdsList[] = $id;
			}
		}
	}
	$cartIds = implode(',', $cartIdsList);
	$cartListTmp = C::t('#tom_tcmall#tom_tcmall_cart')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND id IN(' . $cartIds . ') ', 'ORDER BY id DESC', 0, 100);
	$cartListArr = $cartGoodsArr = $cartShopArr = array();
	if (is_array($cartListTmp) && !empty($cartListTmp)) {
		foreach ($cartListTmp as $key => $value) {
			$cartInfoTmp = $value;
			$goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($value['goods_id']);
			$goodsPicurl = '';
			$status = 1;
			$buy_price = $stock = $showVipPriceStatus = 0;
			if (!preg_match('/^http/', $goodsInfoTmp['picurl'])) {
				if (strpos($goodsInfoTmp['picurl'], 'source/plugin/') === false) {
					$goodsPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfoTmp['picurl'];
				} else {
					$goodsPicurl = $goodsInfoTmp['picurl'];
				}
			} else {
				$goodsPicurl = $goodsInfoTmp['picurl'];
			}
			$goodsInfoTmp['picurl'] = $goodsPicurl;
			if ($goodsInfoTmp['open_vip'] == 1 && $__CardInfo['status'] == 1) {
				$showVipPriceStatus = 1;
			}
			$stock = $goodsInfoTmp['stock'];
			if ($showVipPriceStatus == 1) {
				$buy_price = $goodsInfoTmp['vip_price'];
			} else {
				$buy_price = $goodsInfoTmp['buy_price'];
			}
			$optionInfo = array();
			if ($value['option_id'] > 0) {
				$optionInfo = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_by_id($value['option_id']);
				if ($optionInfo && $optionInfo['id'] > 0) {
					$stock = $optionInfo['stock'];
					if ($showVipPriceStatus == 1) {
						$buy_price = $optionInfo['vip_price'];
					} else {
						$buy_price = $optionInfo['buy_price'];
					}
				} else {
					$status = 2;
				}
			}
			if ($goodsInfoTmp['status'] != 1 || $goodsInfoTmp['shenhe_status'] != 1) {
				$status = 2;
			}
			if ($value['goods_num'] > $stock) {
				$status = 4;
			}
			if ($goodsInfoTmp['max_buy'] > 0) {
				$buyGoodsCount = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_goods_num('AND goods_id = ' . $value['goods_id'] . ' AND user_id = ' . $__UserInfo['id'] . ' AND order_status IN(1,2,3,4,8)');
				$goodsInfoTmp['buyGoodsCount'] = count($buyGoodsCount);
			}
			if ($status == 1) {
				$cartGoodsArr[$value['goods_id']]['goods_num'] = $cartGoodsArr[$value['goods_id']]['goods_num'] + $value['goods_num'];
				$cartGoodsArr[$value['goods_id']]['buy_price'] = $cartGoodsArr[$value['goods_id']]['buy_price'] + $buy_price * $value['goods_num'];
				$cartGoodsArr[$value['goods_id']]['dispatch_status'] = 1;
				$cartShopArr[$goodsInfoTmp['tcshop_id']]['buy_price'] = $cartShopArr[$goodsInfoTmp['tcshop_id']]['buy_price'] + $buy_price * $value['goods_num'];
				$cartShopArr[$goodsInfoTmp['tcshop_id']]['dispatch_price'] = 0;
				$cartShopArr[$goodsInfoTmp['tcshop_id']]['dispatch_status'] = 1;
			}
			$cartInfoTmp['optionInfo'] = $optionInfo;
			$cartInfoTmp['status'] = $status;
			$cartInfoTmp['buy_price'] = $buy_price;
			$cartInfoTmp['goodsInfo'] = $goodsInfoTmp;
			$cartInfoTmp['showVipPriceStatus'] = $showVipPriceStatus;
			$cartListArr[$goodsInfoTmp['tcshop_id']]['goodsList'][] = $cartInfoTmp;
		}
	}
	$cartList = $cartBuyIdsArr = array();
	$peisongTypeStatus1 = $peisongTypeStatus2 = $peisongTypeStatus3 = $totalPrice = $dispatch_price = 0;
	if (is_array($cartListArr) && !empty($cartListArr)) {
		foreach ($cartListArr as $key => $value) {
			$cartList[$key] = $value;
			$tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($key);
			$cartList[$key]['tcshopInfo'] = $tcshopInfoTmp;
			$huodao_pay_status = 0;
			if ($tcshopInfoTmp['huodao_pay'] == 1) {
				$huodao_pay_status = 1;
			}
			$cartShopArr[$tcshopInfoTmp['id']]['huodao_pay_status'] = $huodao_pay_status;
			if (!preg_match('/^http/', $tcshopInfoTmp['picurl'])) {
				if (strpos($tcshopInfoTmp['picurl'], 'source/plugin/tom_') === false) {
					$cartList[$key]['tcshopInfo']['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfoTmp['picurl'];
				} else {
					$cartList[$key]['tcshopInfo']['picurl'] = $tcshopInfoTmp['picurl'];
				}
			} else {
				$cartList[$key]['tcshopInfo']['picurl'] = $tcshopInfoTmp['picurl'];
			}
			$baiduMapToName = $tcshopInfoTmp['name'];
			$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
			$baiduMapToName = urlencode($baiduMapToName);
			$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tcshopInfoTmp['latitude'] . ',' . $tcshopInfoTmp['longitude'] . '&title=' . $baiduMapToName . '&content=&output=html';
			$cartList[$key]['baiduMapUrl'] = $baiduMapUrl;
			$tcshop_score_num = $tcshop_score_dikou_price = 0;
			$cartGoodsListTmp = array();
			if (is_array($value['goodsList']) && !empty($value['goodsList'])) {
				foreach ($value['goodsList'] as $k => $v) {
					$cartGoodsListTmp[$k] = $v;
					$status = $v['status'];
					if ($status == 1 && $tcshopInfoTmp['peisong_type'] > 0) {
						if ($v['goodsInfo']['max_buy'] > 0) {
							$syBuyGoodsCount = $v['goodsInfo']['max_buy'] - $v['goodsInfo']['buyGoodsCount'];
							if ($cartGoodsArr[$v['goodsInfo']['id']]['goods_num'] > $syBuyGoodsCount) {
								$status = 3;
							}
						}
						if ($v['goodsInfo']['open_score_dikou'] == 1) {
							$score_goods_num = 1;
							if ($tcmallConfig['open_goods_num_dikou_score'] == 1) {
								$score_goods_num = $v['goods_num'];
							}
							if ($v['optionInfo']['id'] > 0) {
								$tcshop_score_num = $tcshop_score_num + $v['optionInfo']['score_num'] * $score_goods_num;
								$tcshop_score_dikou_price = $tcshop_score_dikou_price + $v['optionInfo']['score_dikou_price'] * $score_goods_num;
							} else {
								$tcshop_score_num = $tcshop_score_num + $v['goodsInfo']['score_num'] * $score_goods_num;
								$tcshop_score_dikou_price = $tcshop_score_dikou_price + $v['goodsInfo']['score_dikou_price'] * $score_goods_num;
							}
						}
						$cartBuyIdsArr[] = $v['id'];
						$totalPrice = $totalPrice + $v['buy_price'] * $v['goods_num'];
						$issendfree = $v['goodsInfo']['issendfree'];
						if ($v['goodsInfo']['open_express'] == 1) {
							$expressArrTmp = tom_express($v['goodsInfo']['express_id'], $address_id);
							if (is_array($expressArrTmp) && !empty($expressArrTmp)) {
								$issendfree = $expressArrTmp['issendfree'];
								$v['goodsInfo']['dispatch_price'] = $expressArrTmp['express_price'];
							}
						}
						if ($v['goodsInfo']['ednum'] > 0 && $cartGoodsArr[$v['goodsInfo']['id']]['goods_num'] >= $v['goodsInfo']['ednum']) {
							$issendfree = 1;
						}
						if ($v['goodsInfo']['edmoney'] > 0 && $cartGoodsArr[$v['goodsInfo']['id']]['buy_price'] >= $v['goodsInfo']['edmoney']) {
							$issendfree = 1;
						}
						if ($tcshopInfoTmp['edmoney'] > 0 && $cartShopArr[$tcshopInfoTmp['id']]['buy_price'] >= $tcshopInfoTmp['edmoney']) {
							$issendfree = 1;
						}
						if ($issendfree == 0) {
							if ($tcshopInfoTmp['dispatch_type'] == 1) {
								if ($cartShopArr[$tcshopInfoTmp['id']]['dispatch_status'] == 1) {
									$dispatch_price = $dispatch_price + $v['goodsInfo']['dispatch_price'];
									$cartShopArr[$tcshopInfoTmp['id']]['dispatch_status'] = 2;
									$cartShopArr[$tcshopInfoTmp['id']]['dispatch_price'] = $v['goodsInfo']['dispatch_price'];
								}
							} else {
								if ($v['goodsInfo']['dispatch_type'] == 2) {
									$dispatch_price = $dispatch_price + $v['goodsInfo']['dispatch_price'] * $v['goods_num'];
									$cartShopArr[$tcshopInfoTmp['id']]['dispatch_price'] = $cartShopArr[$tcshopInfoTmp['id']]['dispatch_price'] + $v['goodsInfo']['dispatch_price'] * $v['goods_num'];
								} else {
									if ($cartGoodsArr[$v['goodsInfo']['id']]['dispatch_status'] == 1) {
										$dispatch_price = $dispatch_price + $v['goodsInfo']['dispatch_price'];
										$cartGoodsArr[$v['goodsInfo']['id']]['dispatch_status'] = 2;
										$cartShopArr[$tcshopInfoTmp['id']]['dispatch_price'] = $cartShopArr[$tcshopInfoTmp['id']]['dispatch_price'] + $v['goodsInfo']['dispatch_price'];
									}
								}
							}
						}
					}
					$cartGoodsListTmp[$k]['status'] = $status;
				}
			}
			if ($tcshopInfoTmp['peisong_type'] == 1) {
				$peisongTypeStatus1 = 1;
			}
			if ($tcshopInfoTmp['peisong_type'] == 2 || $tcshopInfoTmp['peisong_type'] == 3) {
				$peisongTypeStatus2 = 1;
			}
			if ($tcshopInfoTmp['peisong_type'] == 4) {
				$peisongTypeStatus3 = 1;
			}
			if ($tcshopInfoTmp['peisong_type'] == 5) {
				$peisongTypeStatus2 = 1;
			}
			if ($tcshopInfoTmp['peisong_type'] == 6) {
				$peisongTypeStatus2 = 1;
				$peisongTypeStatus3 = 1;
			}
			$showPlaceStatusTmp = 0;
			if ($tcshopInfoTmp['peisong_type'] == 1 || $tcshopInfoTmp['peisong_type'] == 4 || $tcshopInfoTmp['peisong_type'] == 5 || $tcshopInfoTmp['peisong_type'] == 6) {
				$showPlaceStatusTmp = 1;
				$placeCount = C::t('#tom_tcshop#tom_tcshop_place')->fetch_all_count(' AND tcshop_id = ' . $tcshopInfoTmp['id'] . ' AND status = 1 ');
				if ($placeCount > 0) {
					$showPlaceStatusTmp = 2;
					$placeInfoTmp = array();
					if (!empty($latitude) && !empty($longitude)) {
						$placeInfoTmpTmp = C::t('#tom_tcshop#tom_tcshop_place')->fetch_all_nearby_list(' AND tcshop_id = ' . $tcshopInfoTmp['id'] . ' AND status = 1 ', $latitude, $longitude, 0, 1);
						if (is_array($placeInfoTmpTmp) && !empty($placeInfoTmpTmp[0])) {
							$placeInfoTmp = $placeInfoTmpTmp[0];
						}
					}
				}
			}
			$cartList[$key]['goodsList'] = $cartGoodsListTmp;
			$cartList[$key]['tcshop_score_num'] = $tcshop_score_num;
			$cartList[$key]['tcshop_score_dikou_price'] = $tcshop_score_dikou_price;
			$cartList[$key]['showPlaceStatus'] = $showPlaceStatusTmp;
			if ($showPlaceStatusTmp == 2) {
				$cartList[$key]['tcshopPlaceInfo'] = $placeInfoTmp;
			}
			$cartShopArr[$tcshopInfoTmp['id']]['showPlaceStatus'] = $showPlaceStatusTmp;
			$cartShopArr[$tcshopInfoTmp['id']]['tcshop_score_num'] = $tcshop_score_num;
			$cartShopArr[$tcshopInfoTmp['id']]['tcshop_score_dikou_price'] = $tcshop_score_dikou_price;
		}
	}
	$lingquCouponList = array();
	if (is_array($cartList) && !empty($cartList)) {
		foreach ($cartList as $key => $value) {
			$tcshopIdTmp = $key;
			$defaultCouponLingquId = 0;
			$defaultCouponLingquPrice = 0;
			$lingquList = array();
			$lingquListTmp = C::t('#tom_tcmall#tom_tcmall_coupon_lingqu')->fetch_all_list(' AND status = 0 AND tcshop_id=' . $tcshopIdTmp . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 10);
			if (is_array($lingquListTmp) && !empty($lingquListTmp)) {
				foreach ($lingquListTmp as $kc => $vc) {
					$couponInfo = array();
					$couponStatus = 0;
					$goodsTotalPriceTmp = 0;
					$couponInfoTmp = C::t('#tom_tcmall#tom_tcmall_coupon')->fetch_all_list(' AND id=' . $vc['coupon_id'] . ' AND status = 1 AND start_time <= ' . $timeStamp . ' AND end_time > ' . $timeStamp . ' ', 'ORDER BY id DESC', 0, 1);
					if (is_array($couponInfoTmp) && !empty($couponInfoTmp[0])) {
						$couponInfo = $couponInfoTmp[0];
						if ($couponInfo['coupon_type'] == 1) {
							$couponStatus = 1;
							$goodsTotalPriceTmp = $cartShopArr[$tcshopIdTmp]['buy_price'];
						} elseif ($couponInfo['coupon_type'] == 2) {
							$goodsIdsArr = explode('|', $couponInfo['goods_ids']);
							if (is_array($value['goodsList']) && !empty($value['goodsList'])) {
								foreach ($value['goodsList'] as $k => $v) {
									if (in_array($v['goodsInfo']['id'], $goodsIdsArr)) {
										$couponStatus = 1;
										$allGoodsPrice = 0;
										if (is_array($goodsIdsArr) && !empty($goodsIdsArr)) {
											foreach ($goodsIdsArr as $kg => $vg) {
												if (isset($cartGoodsArr[$vg])) {
													$allGoodsPrice = $allGoodsPrice + floatval($cartGoodsArr[$vg]['buy_price']);
												}
											}
										}
										$goodsTotalPriceTmp = $allGoodsPrice;
									}
								}
							}
						}
					}
					if ($couponStatus == 1) {
						$lingquList[$kc] = $vc;
						$lingquList[$kc]['couponInfo'] = $couponInfo;
						if ($goodsTotalPriceTmp >= $couponInfo['full_price']) {
							$lingquList[$kc]['selected_status'] = 1;
							if ($lingquList[$kc]['selected_status'] == 1 && $couponInfo['reduce_price'] > $defaultCouponLingquPrice) {
								$defaultCouponLingquPrice = $couponInfo['reduce_price'];
								$defaultCouponLingquId = $vc['id'];
							}
						} else {
							$lingquList[$kc]['selected_status'] = 2;
						}
					}
				}
			}
			$lingquArr = array();
			$i = 0;
			if (is_array($lingquList) && !empty($lingquList)) {
				foreach ($lingquList as $key => $value) {
					$lingquArr[$i]['id'] = $value['id'];
					$lingquArr[$i]['title'] = diconv($value['couponInfo']['title'], CHARSET, 'utf-8');
					$lingquArr[$i]['full_price'] = $value['couponInfo']['full_price'];
					$lingquArr[$i]['reduce_price'] = $value['couponInfo']['reduce_price'];
					$lingquArr[$i]['start_time'] = dgmdate($value['couponInfo']['start_time'], 'Y-m-d', $tomSysOffset);
					$lingquArr[$i]['end_time'] = dgmdate($value['couponInfo']['end_time'], 'Y-m-d', $tomSysOffset);
					$lingquArr[$i]['selected_status'] = $value['selected_status'];
					$i++;
				}
			}
			$lingquCouponList[$tcshopIdTmp]['lingquList'] = urlencode(json_encode($lingquArr));
			$lingquCouponList[$tcshopIdTmp]['lingquCount'] = count($lingquList);
			$lingquCouponList[$tcshopIdTmp]['defaultCouponLingquId'] = $defaultCouponLingquId;
			$lingquCouponList[$tcshopIdTmp]['defaultCouponLingquPrice'] = $defaultCouponLingquPrice;
		}
	}
	$cartBuyIds = implode(',', $cartBuyIdsArr);
	$cartShopListStr = json_encode($cartShopArr);
	$goodsAllTotalPrice = $allTotalPrice = $totalPrice;
	$xm = $tel = '';
	$userOrderTmp = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' AND order_status IN(2,3,4,8) ', ' ORDER BY id DESC ', 0, 1);
	if (is_array($userOrderTmp) && !empty($userOrderTmp) && !empty($userOrderTmp[0]['address_tel'])) {
		$xm = $userOrderTmp[0]['address_xm'];
		$tel = $userOrderTmp[0]['address_tel'];
	}
	if (empty($tel)) {
		$tel = $__UserInfo['tel'];
	}
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tcshopConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$placeListAjaxUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=tcshop_place&open_wx_map=' . $open_wx_map . '&formhash=' . $formhash;
	$payUrl = 'plugin.php?id=tom_tcmall:pay&site=' . $site_id;
	$jumpUrl = 'plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=order';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcmall:cartbuy');
} elseif ($_GET['mod'] == 'goodsbuy') {
	$address_id = isset($_GET['address_id']) ? intval($_GET['address_id']) : 0;
	$goods_id = intval($_GET['goods_id']) > 0 ? intval($_GET['goods_id']) : 0;
	$tj_hehuoren_id = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
	$option_ids = isset($_GET['option_ids']) ? daddslashes($_GET['option_ids']) : '';
	$number = intval($_GET['number']) > 0 ? intval($_GET['number']) : 1;
	$latitude = getcookie('tom_tongcheng_user_latitude');
	$longitude = getcookie('tom_tongcheng_user_longitude');
	$goodsInfo = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($goods_id);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/tom_tcmall/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$picurl = $goodsInfo['picurl'];
		}
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	$address_back_url = $weixinClass->get_url();
	$address_back_url = preg_replace('/&address_id=[0-9]*/', '', $address_back_url);
	$address_back_url = urlencode($address_back_url);
	$setAddressStatus = 0;
	$setAddressUrl = '';
	$addressListCount = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_count(' AND uid=' . $__MemberInfo['uid'] . ' ');
	if ($addressListCount == 0) {
		$setAddressStatus = 1;
		$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $address_back_url);
	}
	$addressInfo = array();
	$addressInfoTmp = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
	if ($addressInfoTmp) {
		$addressInfo = $addressInfoTmp;
	} else {
		$defaultAddressList = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_list(' AND uid=' . $__MemberInfo['uid'] . ' AND default_id=1 ', 'ORDER BY id DESC', 0, 1);
		if ($defaultAddressList && !empty($defaultAddressList['0']['id'])) {
			$address_id = $defaultAddressList['0']['id'];
			$addressInfo = $defaultAddressList['0'];
		} else {
			$setAddressStatus = 1;
			$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $address_back_url);
		}
	}
	$changeAddressUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&buying=1&address_id=' . $address_id . '&address_back_url=' . $address_back_url;
	$showVipPriceStatus = 0;
	if ($goodsInfo['open_vip'] == 1 && $__CardInfo['status'] == 1) {
		$showVipPriceStatus = 1;
	}
	if ($showVipPriceStatus == 1) {
		$buy_price = $goodsInfo['vip_price'];
	} else {
		$buy_price = $goodsInfo['buy_price'];
	}
	$stock = $goodsInfo['stock'];
	$score_goods_num = 1;
	if ($tcmallConfig['open_goods_num_dikou_score'] == 1) {
		$score_goods_num = $number;
	}
	$score_num = $goodsInfo['score_num'] * $score_goods_num;
	$score_dikou_price = $goodsInfo['score_dikou_price'] * $score_goods_num;
	$totalPrice = $dispatch_price = 0;
	if (!empty($option_ids)) {
		$optionIdsArr = explode('-', trim($option_ids, '-'));
		$optionIdsList = array();
		if (is_array($optionIdsArr) && !empty($optionIdsArr)) {
			foreach ($optionIdsArr as $key => $value) {
				$id = intval($value);
				if ($id > 0) {
					$optionIdsList[] = $id;
				}
			}
		}
		$spec_item_ids = implode('-', $optionIdsList);
		$optionInfo = C::t('#tom_tcmall#tom_tcmall_goods_option')->fetch_by_spec_item_ids($spec_item_ids);
		if ($showVipPriceStatus == 1) {
			$buy_price = $optionInfo['vip_price'];
		} else {
			$buy_price = $optionInfo['buy_price'];
		}
		$stock = $optionInfo['stock'];
		$score_num = $optionInfo['score_num'] * $score_goods_num;
		$score_dikou_price = $optionInfo['score_dikou_price'] * $score_goods_num;
	}
	$totalPrice = $buy_price * $number;
	if ($goodsInfo['open_express'] == 1) {
		$expressArrTmp = tom_express($goodsInfo['express_id'], $address_id);
		if (is_array($expressArrTmp) && !empty($expressArrTmp)) {
			$goodsInfo['issendfree'] = $expressArrTmp['issendfree'];
			$goodsInfo['dispatch_price'] = $expressArrTmp['express_price'];
		}
	}
	if ($goodsInfo['ednum'] > 0 && $number >= $goodsInfo['ednum']) {
		$goodsInfo['issendfree'] = 1;
	}
	if ($goodsInfo['edmoney'] > 0 && $totalPrice >= $goodsInfo['edmoney']) {
		$goodsInfo['issendfree'] = 1;
	}
	if ($tcshopInfo['edmoney'] > 0 && $totalPrice >= $tcshopInfo['edmoney']) {
		$goodsInfo['issendfree'] = 1;
	}
	if ($goodsInfo['issendfree'] == 0) {
		if ($goodsInfo['dispatch_type'] == 2) {
			$dispatch_price = $goodsInfo['dispatch_price'] * $number;
		} else {
			$dispatch_price = $goodsInfo['dispatch_price'];
		}
	}
	$goodsAllTotalPrice = $allTotalPrice = $totalPrice;
	$goodsStatus = 1;
	if ($goodsInfo['status'] != 1 || $goodsInfo['shenhe_status'] != 1) {
		$goodsStatus = 2;
	}
	if ($goodsInfo['max_buy'] > 0) {
		$buyGoodsCount = C::t('#tom_tcmall#tom_tcmall_order_goods')->fetch_goods_num('AND goods_id = ' . $goodsInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' AND order_status IN(1,2,3,4,8)');
		$syBuyGoodsCount = $goodsInfo['max_buy'] - $buyGoodsCount;
		if ($number > $syBuyGoodsCount) {
			$goodsStatus = 3;
		}
	}
	if ($number > $stock) {
		$goodsStatus = 4;
	}
	$defaultCouponLingquId = 0;
	$defaultCouponLingquPrice = 0;
	$lingquListTmp = C::t('#tom_tcmall#tom_tcmall_coupon_lingqu')->fetch_all_list(' AND status = 0 AND tcshop_id=' . $goodsInfo['tcshop_id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 10);
	$lingquList = $mallLingquList = array();
	if (is_array($lingquListTmp) && !empty($lingquListTmp)) {
		foreach ($lingquListTmp as $key => $value) {
			$couponInfoTmp = C::t('#tom_tcmall#tom_tcmall_coupon')->fetch_all_list(' AND id=' . $value['coupon_id'] . ' AND status = 1 AND start_time <= ' . $timeStamp . ' AND end_time > ' . $timeStamp . ' ', 'ORDER BY id DESC', 0, 1);
			$couponInfo = array();
			$couponStatus = 0;
			if (is_array($couponInfoTmp) && !empty($couponInfoTmp[0])) {
				$couponInfo = $couponInfoTmp[0];
				if ($couponInfo['coupon_type'] == 1) {
					$couponStatus = 1;
				} elseif ($couponInfo['coupon_type'] == 2) {
					$goodsIdsArr = explode('|', $couponInfo['goods_ids']);
					if (in_array($goods_id, $goodsIdsArr)) {
						$couponStatus = 1;
					}
				}
			}
			if ($couponStatus == 1) {
				$selectedStatus = 1;
				if ($totalPrice >= $couponInfo['full_price']) {
					if ($selectedStatus == 1 && $couponInfo['reduce_price'] > $defaultCouponLingquPrice) {
						$defaultCouponLingquPrice = $couponInfo['reduce_price'];
						$defaultCouponLingquId = $value['id'];
					}
				} else {
					$selectedStatus = 2;
				}
				$lingquList[$key] = $value;
				$lingquList[$key]['couponInfo'] = $couponInfo;
				$lingquList[$key]['selected_status'] = $selectedStatus;
			}
		}
	}
	$lingquCount = count($lingquList);
	$mallLingquCount = count($mallLingquList);
	if ($defaultCouponLingquPrice > 0) {
		$allTotalPrice = ($allTotalPrice * 100 - $defaultCouponLingquPrice * 100) / 100;
	}
	$allTotalPrice = number_format($allTotalPrice, '2');
	$xm = $tel = '';
	$userOrderTmp = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' AND order_status IN(2,3,4,8) ', ' ORDER BY id DESC ', 0, 1);
	if (is_array($userOrderTmp) && !empty($userOrderTmp) && !empty($userOrderTmp[0]['address_tel'])) {
		$xm = $userOrderTmp[0]['address_xm'];
		$tel = $userOrderTmp[0]['address_tel'];
	}
	if (empty($tel)) {
		$tel = $__UserInfo['tel'];
	}
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tcshopConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$baiduMapToName = $tcshopInfo['name'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tcshopInfo['latitude'] . ',' . $tcshopInfo['longitude'] . '&title=' . $baiduMapToName . '&content=&output=html';
	$showPlaceStatus = 0;
	if ($tcshopInfo['peisong_type'] == 1 || $tcshopInfo['peisong_type'] == 4 || $tcshopInfo['peisong_type'] == 5 || $tcshopInfo['peisong_type'] == 6) {
		$showPlaceStatus = 1;
		$placeCount = C::t('#tom_tcshop#tom_tcshop_place')->fetch_all_count(' AND tcshop_id = ' . $tcshopInfo['id'] . ' AND status = 1 ');
		if ($placeCount > 0) {
			$showPlaceStatus = 2;
			$placeInfo = array();
			if (!empty($latitude) && !empty($longitude)) {
				$placeInfoTmp = C::t('#tom_tcshop#tom_tcshop_place')->fetch_all_nearby_list(' AND tcshop_id = ' . $tcshopInfo['id'] . ' AND status = 1 ', $latitude, $longitude, 0, 1);
				if (is_array($placeInfoTmp) && !empty($placeInfoTmp[0])) {
					$placeInfo = $placeInfoTmp[0];
				}
			}
		}
	}
	$placeListAjaxUrl = 'plugin.php?id=tom_tcmall:ajax&site=' . $site_id . '&act=tcshop_place&open_wx_map=' . $open_wx_map . '&tcshop_id=' . $tcshopInfo['id'] . '&formhash=' . $formhash;
	$payUrl = 'plugin.php?id=tom_tcmall:pay&site=' . $site_id . '&act=goods_pay';
	$jumpUrl = 'plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=order';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcmall:goodsbuy');
} elseif ($_GET['mod'] == 'pinglun') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/pinglun.php';
} elseif ($_GET['mod'] == 'couponlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/couponlist.php';
} elseif ($_GET['mod'] == 'couponinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/couponinfo.php';
} elseif ($_GET['mod'] == 'shop') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/shop.php';
} elseif ($_GET['mod'] == 'order') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/order.php';
} elseif ($_GET['mod'] == 'orderinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/orderinfo.php';
} elseif ($_GET['mod'] == 'orderhexiao') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/orderhexiao.php';
} elseif ($_GET['mod'] == 'mycoupon') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/mycoupon.php';
} elseif ($_GET['mod'] == 'myorder') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/myorder.php';
} elseif ($_GET['mod'] == 'myorderinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/myorderinfo.php';
} elseif ($_GET['mod'] == 'mylist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/mylist.php';
} elseif ($_GET['mod'] == 'daoorder') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/daoorder.php';
} elseif ($_GET['mod'] == 'refundselect') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/refundselect.php';
} elseif ($_GET['mod'] == 'refund') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/refund.php';
} elseif ($_GET['mod'] == 'refundlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/refundlist.php';
} elseif ($_GET['mod'] == 'refundinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/refundinfo.php';
} elseif ($_GET['mod'] == 'myrefundlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/myrefundlist.php';
} elseif ($_GET['mod'] == 'myrefundinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/myrefundinfo.php';
} elseif ($_GET['mod'] == 'ruzhu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/ruzhu.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/edit.php';
} elseif ($_GET['mod'] == 'editstock') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/editstock.php';
} elseif ($_GET['mod'] == 'editoption') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/editoption.php';
} elseif ($_GET['mod'] == 'mycouponlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/mycouponlist.php';
} elseif ($_GET['mod'] == 'addcoupon') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/addcoupon.php';
} elseif ($_GET['mod'] == 'editcoupon') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/editcoupon.php';
} elseif ($_GET['mod'] == 'my') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/my.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tcmall/module/upload.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();