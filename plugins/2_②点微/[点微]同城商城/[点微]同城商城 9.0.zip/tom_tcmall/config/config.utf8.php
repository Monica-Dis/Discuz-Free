<?php

/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$orderStatusArray = array(
    1 => '待支付',
    2 => '已支付',
    3 => '已发货',
    4 => '已签收',
    5 => '交易已取消',
    6 => '退款处理中',
    7 => '退款成功',
    8 => '货到付款',
);

$orderStatusColorArray = array(
    1 => '#fd0303',
    2 => '#1e9203',
    3 => '#0585d6',
    4 => '#ff6203',
    5 => '#fd0303',
    6 => '#777a77',
    7 => '#05a6ce',
);

$pinglunStatusArray = array(
    1 => '很不满意',
    2 => '不满意',
    3 => '一般',
    4 => '满意',
    5 => '很满意',
);