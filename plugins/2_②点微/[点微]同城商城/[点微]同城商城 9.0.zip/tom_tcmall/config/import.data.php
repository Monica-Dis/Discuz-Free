<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$catesArr = array();

$catesArr[1] = array(
    'name' => 'Ůװ',
    'sub'  => 'ʱ������',
    'childs' => array(
        1 => array(
            'name'   => 'T��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nvzhuang/nvzhuang_tx.jpg',
        ),
        2 => array(
            'name'   => '��װ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nvzhuang/nvzhuang_tz.jpg',
        ),
        3 => array(
            'name'   => '����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nvzhuang/nvzhuang_cs.jpg',
        ),
        4 => array(
            'name'   => '���п�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nvzhuang/nvzhuang_xxk.jpg',
        ),
        5 => array(
            'name'   => 'Ů��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nvzhuang/nvzhuang_nk.jpg',
        ),
        6 => array(
            'name'   => 'ȹװ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nvzhuang/nvzhuang_qz.jpg',
        ),
        7 => array(
            'name'   => '����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nvzhuang/nvzhuang_wt.jpg',
        ),
    )
);

$catesArr[2] = array(
    'name' => '��װ',
    'sub'  => 'Ʒ����װ',
    'childs' => array(
        1 => array(
            'name'   => 'T��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nanzhuang/nanzhuang_tx.jpg',
        ),
        2 => array(
            'name'   => 'POLO��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nanzhuang/nanzhuang_polos.jpg',
        ),
        3 => array(
            'name'   => '��װ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nanzhuang/nanzhuang_tz.jpg',
        ),
        4 => array(
            'name'   => '����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nanzhuang/nanzhuang_cs.jpg',
        ),
        5 => array(
            'name'   => '���п�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nanzhuang/nanzhuang_xxk.jpg',
        ),
        6 => array(
            'name'   => 'ţ�п�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nanzhuang/nanzhuang_nzk.jpg',
        ),
        7 => array(
            'name'   => '�̿�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nanzhuang/nanzhuang_dk.jpg',
        ),
        8 => array(
            'name'   => '�п�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/nanzhuang/nanzhuang_wt.jpg',
        ),
    )
);

$catesArr[3] = array(
    'name' => 'Ь��',
    'sub'  => '��Ƥ����',
    'childs' => array(
        1 => array(
            'name'   => '��Ь',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/xiebao/xiebao_lx.jpg',
        ),
        2 => array(
            'name'   => '����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/xiebao/xiebao_lt.jpg',
        ),
        3 => array(
            'name'   => '���',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/xiebao/xiebao_xb.jpg',
        ),
        4 => array(
            'name'   => 'ŮЬ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/xiebao/xiebao_nvx.jpg',
        ),
        5 => array(
            'name'   => '��Ь',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/xiebao/xiebao_nx.jpg',
        ),
        6 => array(
            'name'   => 'ƤЬ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/xiebao/xiebao_px.jpg',
        ),
        7 => array(
            'name'   => '����Ь',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/xiebao/xiebao_xxx.jpg',
        ),
        8 => array(
            'name'   => '˫���',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/xiebao/xiebao_sjb.jpg',
        ),
        9 => array(
            'name'   => '����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/xiebao/xiebao_ps.jpg',
        ),
    )
);

$catesArr[4] = array(
    'name' => '�ֻ�',
    'sub'  => '�������',
    'childs' => array(
        1 => array(
            'name'   => '�ֻ�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/moblie/moblie_sj.jpg',
        ),
        2 => array(
            'name'   => '��Ĥ/֧��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/moblie/moblie_kmzj.jpg',
        ),
        3 => array(
            'name'   => '�����/��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/moblie/moblie_cdqx.jpg',
        ),
        4 => array(
            'name'   => '��籦',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/moblie/moblie_cdb.jpg',
        ),
        5 => array(
            'name'   => '����/����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/moblie/moblie_ejem.jpg',
        ),
        6 => array(
            'name'   => '����/����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/moblie/moblie_yxyx.jpg',
        ),
        7 => array(
            'name'   => '�ֻ�/�ֱ�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/moblie/moblie_shsb.jpg',
        ),
        8 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/moblie/moblie_znsh.jpg',
        ),
        9 => array(
            'name'   => '���',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/moblie/moblie_xj.jpg',
        ),
    )
);

$catesArr[5] = array(
    'name' => '����',
    'sub'  => '��������',
    'childs' => array(
        1 => array(
            'name'   => '���ҵ��¯',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/dianqi/dianqi_fbdcl.jpg',
        ),
        2 => array(
            'name'   => '�յ�����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/dianqi/dianqi_ktfs.jpg',
        ),
        3 => array(
            'name'   => '���ӻ�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/dianqi/dianqi_dsj.jpg',
        ),
        4 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/dianqi/dianqi_cfdq.jpg',
        ),
        5 => array(
            'name'   => '���ݽ���',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/dianqi/dianqi_mrjk.jpg',
        ),
        6 => array(
            'name'   => '����ϴ�»�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/dianqi/dianqi_bxxyj.jpg',
        ),
        7 => array(
            'name'   => '�������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/dianqi/dianqi_shdq.jpg',
        ),
        8 => array(
            'name'   => 'ե֭������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/dianqi/dianqi_zjjcy.jpg',
        ),
        9 => array(
            'name'   => '�������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/dianqi/dianqi_cwdd.jpg',
        ),
    )
);

$catesArr[6] = array(
    'name' => '����',
    'sub'  => '��Ʒ�칫',
    'childs' => array(
        1 => array(
            'name'   => 'ƽ�����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/diannao/diannao_pbdn.jpg',
        ),
        2 => array(
            'name'   => '�ľ�ѧϰ��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/diannao/diannao_wjxxj.jpg',
        ),
        3 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/diannao/diannao_dnzj.jpg',
        ),
        4 => array(
            'name'   => '����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/diannao/diannao_bilei.jpg',
        ),
        5 => array(
            'name'   => '�������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/diannao/diannao_wspj.jpg',
        ),
        6 => array(
            'name'   => '�칫��Ʒ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/diannao/diannao_bgyp.jpg',
        ),
        7 => array(
            'name'   => '��Ϸ�豸',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/diannao/diannao_yxsb.jpg',
        ),
        8 => array(
            'name'   => '�칫�豸',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/diannao/diannao_bgsb.jpg',
        ),
        9 => array(
            'name'   => '�����豸',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/diannao/diannao_wlsb.jpg',
        ),
    )
);

$catesArr[7] = array(
    'name' => 'ʳƷ',
    'sub'  => '�Ի�����',
    'childs' => array(
        1 => array(
            'name'   => '������ʳ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/shipin/shipin_xxls.jpg',
        ),
        2 => array(
            'name'   => '����Ʒ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/shipin/shipin_rzp.jpg',
        ),
        3 => array(
            'name'   => '��ˮ����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/shipin/shipin_csyl.jpg',
        ),
        4 => array(
            'name'   => '���ɸ��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/shipin/shipin_bggd.jpg',
        ),
        5 => array(
            'name'   => '������ʳ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/shipin/shipin_lyss.jpg',
        ),
        6 => array(
            'name'   => '����۽�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/shipin/shipin_jgmj.jpg',
        ),
        7 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/shipin/shipin_zwmj.jpg',
        ),
        8 => array(
            'name'   => 'Ӫ������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/shipin/shipin_yybj.jpg',
        ),
    )
);

$catesArr[8] = array(
    'name' => '����',
    'sub'  => 'ȫ��ʱ��',
    'childs' => array(
        1 => array(
            'name'   => 'Ůʿ����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/neiyi/neiyi_nshiny.jpg',
        ),
        2 => array(
            'name'   => '��ʿ����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/neiyi/neiyi_nsny.jpg',
        ),
        3 => array(
            'name'   => '����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/neiyi/neiyi_wx.jpg',
        ),
        4 => array(
            'name'   => '����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/neiyi/neiyi_kw.jpg',
        ),
        5 => array(
            'name'   => '�ڿ�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/neiyi/neiyi_nk.jpg',
        ),
        6 => array(
            'name'   => '˯��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/neiyi/neiyi_sy.jpg',
        ),
    )
);

$catesArr[9] = array(
    'name' => '����',
    'sub'  => '�����ر�',
    'childs' => array(
        1 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/qiche/qiche_zdzt.jpg',
        ),
        2 => array(
            'name'   => '��������Ʒ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/qiche/qiche_qcns.jpg',
        ),
        3 => array(
            'name'   => '���õ���',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/qiche/qiche_cydz.jpg',
        ),
        4 => array(
            'name'   => '���������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/qiche/qiche_qcpj.jpg',
        ),
        5 => array(
            'name'   => '���η���',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/qiche/qiche_wsfh.jpg',
        ),
        6 => array(
            'name'   => '��ϴ����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/qiche/qiche_qxgj.jpg',
        ),
    )
);

$catesArr[10] = array(
    'name' => 'ĸӤ',
    'sub'  => 'ĸӤ����',
    'childs' => array(
        1 => array(
            'name'   => 'ͯװ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/muyin/muyin_tz.jpg',
        ),
        2 => array(
            'name'   => 'ͯЬ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/muyin/muyin_tx.jpg',
        ),
        3 => array(
            'name'   => '����ר��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/muyin/muyin_ymzq.jpg',
        ),
        4 => array(
            'name'   => '�̷�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/muyin/muyin_nf.jpg',
        ),
        5 => array(
            'name'   => '�������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/muyin/muyin_wjyq.jpg',
        ),
        6 => array(
            'name'   => '��ͯ�ľ�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/muyin/muyin_etwj.jpg',
        ),
        7 => array(
            'name'   => 'ͯ��ͯ��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/muyin/muyin_tctc.jpg',
        ),
        8 => array(
            'name'   => 'ֽ���',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/muyin/muyin_znk.jpg',
        ),
    )
);

$catesArr[11] = array(
    'name' => '�ٻ�',
    'sub'  => '��������',
    'childs' => array(
        1 => array(
            'name'   => 'ֽƷʪ��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/baihuo/baihuo_zjsp.jpg',
        ),
        2 => array(
            'name'   => '��ͥ���',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/baihuo/baihuo_jtqj.jpg',
        ),
        3 => array(
            'name'   => '���ðٻ�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/baihuo/baihuo_rybh.jpg',
        ),
        4 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/baihuo/baihuo_snzl.jpg',
        ),
        5 => array(
            'name'   => '��ֲ԰��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/baihuo/baihuo_lzyy.jpg',
        ),
        6 => array(
            'name'   => 'ϴ�����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/baihuo/baihuo_xhqj.jpg',
        ),
        7 => array(
            'name'   => '������Ʒ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/baihuo/baihuo_cfyp.jpg',
        ),
        8 => array(
            'name'   => '��Ʒ����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/baihuo/baihuo_spss.jpg',
        ),
        9 => array(
            'name'   => 'ˮ���;�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/baihuo/baihuo_sbcj.jpg',
        ),
    )
);

$catesArr[12] = array(
    'name' => '��װ',
    'sub'  => '��ܰ��װ',
    'childs' => array(
        1 => array(
            'name'   => '�ƾߵ���',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiazhuang/jiazhuang_djds.jpg',
        ),
        2 => array(
            'name'   => '��𹤾�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiazhuang/jiazhuang_wjgj.jpg',
        ),
        3 => array(
            'name'   => '�������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiazhuang/jiazhuang_gljl.jpg',
        ),
        4 => array(
            'name'   => 'ɳ���輸',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiazhuang/jiazhuang_sfcj.jpg',
        ),
        5 => array(
            'name'   => '���ʹ���',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiazhuang/jiazhuang_chcd.jpg',
        ),
        6 => array(
            'name'   => '������ԡ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiazhuang/jiazhuang_cfwy.jpg',
        ),
        7 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiazhuang/jiazhuang_zljl.jpg',
        ),
        8 => array(
            'name'   => '�칫����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiazhuang/jiazhuang_bghw.jpg',
        ),
        9 => array(
            'name'   => '��װ����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiazhuang/jiazhuang_jzjc.jpg',
        ),
    )
);

$catesArr[13] = array(
    'name' => '�˶�',
    'sub'  => '�����˶�',
    'childs' => array(
        1 => array(
            'name'   => '�˶�Ь',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/yundong/yundong_ydx.jpg',
        ),
        2 => array(
            'name'   => '�˶�����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/yundong/yundong_ydfs.jpg',
        ),
        3 => array(
            'name'   => '����װ��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/yundong/yundong_hwzb.jpg',
        ),
        4 => array(
            'name'   => '����Ь��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/yundong/yundong_hwxf.jpg',
        ),
        5 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/yundong/yundong_jsqc.jpg',
        ),
        6 => array(
            'name'   => '������Ʒ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/yundong/yundong_tyyp.jpg',
        ),
        7 => array(
            'name'   => '�����ֻ�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/yundong/yundong_qxhl.jpg',
        ),
        8 => array(
            'name'   => '����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/yundong/yundong_cd.jpg',
        ),
        9 => array(
            'name'   => '��Ӿ��Ʒ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/yundong/yundong_yyyp.jpg',
        ),
    )
);

$catesArr[14] = array(
    'name' => '�ҷ�',
    'sub'  => '��Ʒ����',
    'childs' => array(
        1 => array(
            'name'   => '��Ʒ�׼�',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiafang/jiafang_cptj.jpg',
        ),
        2 => array(
            'name'   => 'ë��ɳ����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiafang/jiafang_mjsfd.png',
        ),
        3 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiafang/jiafang_cdbz.jpg',
        ),
        4 => array(
            'name'   => '�ı���̺',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiafang/jiafang_xbxt.jpg',
        ),
        5 => array(
            'name'   => '����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiafang/jiafang_wz.jpg',
        ),
        6 => array(
            'name'   => '��ϯ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiafang/jiafang_lx.jpg',
        ),
        7 => array(
            'name'   => '��̺����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiafang/jiafang_dtcl.jpg',
        ),
        8 => array(
            'name'   => '�Ҿ���Ʒ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiafang/jiafang_jjsp.jpg',
        ),
        9 => array(
            'name'   => '��ͷ����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/jiafang/jiafang_ztcd.jpg',
        ),
    )
);

$catesArr[15] = array(
    'name' => '����',
    'sub'  => 'ˮ���ʺ�',
    'childs' => array(
        1 => array(
            'name'   => '����ˮ��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/guoshu/guoshu_xxsg.jpg',
        ),
        2 => array(
            'name'   => '����ˮ��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/guoshu/guoshu_hxsc.jpg',
        ),
        3 => array(
            'name'   => '�Ϲ�����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/guoshu/guoshu_ggtl.jpg',
        ),
        4 => array(
            'name'   => '�߲˼���Ʒ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/guoshu/guoshu_scjzp.jpg',
        ),
        5 => array(
            'name'   => '������ѡ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/guoshu/guoshu_jkyx.jpg',
        ),
        6 => array(
            'name'   => 'Ʒ������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/guoshu/guoshu_pzrq.jpg',
        ),
        7 => array(
            'name'   => '��������Ʒ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/guoshu/guoshu_djdzp.jpg',
        ),
        8 => array(
            'name'   => '��ʳ����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/guoshu/guoshu_sslc.jpg',
        ),
    )
);

$catesArr[16] = array(
    'name' => '��ױ',
    'sub'  => '��������',
    'childs' => array(
        1 => array(
            'name'   => '�沿����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/meizhuang/meizhuang_mbhl.jpg',
        ),
        2 => array(
            'name'   => '��Ĥ',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/meizhuang/meizhuang_mm.jpg',
        ),
        3 => array(
            'name'   => '��ױ���',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/meizhuang/meizhuang_czxf.jpg',
        ),
        4 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/meizhuang/meizhuang_mfhf.jpg',
        ),
        5 => array(
            'name'   => '�ں촽��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/meizhuang/meizhuang_khcg.jpg',
        ),
        6 => array(
            'name'   => 'ˬ��ˮ��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/meizhuang/meizhuang_sfsr.jpg',
        ),
        7 => array(
            'name'   => '����˪',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/meizhuang/meizhuang_hss.jpg',
        ),
        8 => array(
            'name'   => '���廤��',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/meizhuang/meizhuang_sthl.jpg',
        ),
        9 => array(
            'name'   => '��ױ����',
            'picurl' => 'source/plugin/tom_tcmall/images/cates/meizhuang/meizhuang_mzgj.jpg',
        ),
    )
);
if (CHARSET == 'utf-8') {
    $catesArr = tom_iconv($catesArr,'gbk','utf-8');
}