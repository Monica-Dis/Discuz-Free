<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tomSysOffset = getglobal('setting/timeoffset');
$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcmall/config/config.utf8.php';
}

$page           = isset($_GET['page'])? intval($_GET['page']):1;
$tcshop_id      = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
$order_no       = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
$order_tel      = !empty($_GET['order_tel'])? trim(addslashes($_GET['order_tel'])):'';
$order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;
$start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
$end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';

$pagesize = 10000;
$start = ($page-1)*$pagesize;

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $where = "";
    if(!empty($tcshop_id)){
        $where.=" AND tcshop_id={$tcshop_id} ";
    }
    if(!empty($order_no)){
        $where.=" AND order_no='{$order_no}' ";
    }
    if(!empty($order_status)){
        $where.=" AND order_status={$order_status} ";
    }
    if(!empty($start_time)){
        $startTime = strtotime($start_time);
        $where.=" AND order_time >=  {$startTime} ";
    }
    if(!empty($end_time)){
        $endTime = strtotime($end_time);
        $where.=" AND order_time < {$endTime} ";
    }
    
    $ordersListTmp = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_list($where,"ORDER BY order_time DESC",$start,$pagesize,$order_tel);
    $orderList = array();
    foreach ($ordersListTmp as $key => $value) {
        $orderList[$key] = $value;
        
        $orderList[$key]['order_status'] = $orderStatusArray[$value['order_status']];
        if($value['peisong_type'] == 1){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tcmall','goods_peisong_type_1');
        }else if($value['peisong_type'] == 2){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tcmall','goods_peisong_type_2');
        }else if($value['peisong_type'] == 3){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tcmall','goods_peisong_type_3');
        }
        $orderList[$key]['order_time'] = dgmdate($value['order_time'],"Y-m-d H:i:s",$tomSysOffset);
        if($value['hexiao_time'] > 0){
            $orderList[$key]['hexiao_time'] = dgmdate($value['hexiao_time'],"Y-m-d H:i:s",$tomSysOffset);
        }else{
            $orderList[$key]['hexiao_time'] = '-';
        }
        
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $orderGoodsListTmp = C::t("#tom_tcmall#tom_tcmall_order_goods")->fetch_all_list(" AND order_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);
        $orderGoodsList = array();
        foreach($orderGoodsListTmp as $gk => $gv){
            $orderGoodsList[$gk] = $gv;
            $option_name_tmp = '';
            if(!empty($gv['option_name'])){
                $option_name_tmp = '(' . $gv['option_name'] . ')';
            }
            $goodsInfo = C::t("#tom_tcmall#tom_tcmall_goods")->fetch_by_id($gv['goods_id']);
            $orderGoodsList[$gk]['goods_title'] = $goodsInfo['title'].$option_name_tmp;
        }
        
        $orderList[$key]['userInfo'] = $userInfoTmp;
        $orderList[$key]['goodsList'] = $orderGoodsList;
    }

    $order_order_no     = lang('plugin/tom_tcmall','order_order_no');
    $order_tcshop_id    = lang('plugin/tom_tcmall','order_tcshop_id');
    $order_pay_price    = lang('plugin/tom_tcmall','order_pay_price');
    $order_user_id      = lang('plugin/tom_tcmall','order_user_id');
    $order_user_openid  = lang('plugin/tom_tcmall','order_user_openid');
    $order_xm           = lang('plugin/tom_tcmall','order_xm');
    $order_tel          = lang('plugin/tom_tcmall','order_tel');
    $order_address      = lang('plugin/tom_tcmall','order_address');
    $order_order_beizu  = lang('plugin/tom_tcmall','order_order_beizu');
    $order_order_status = lang('plugin/tom_tcmall','order_order_status');
    $goods_peisong_type = lang('plugin/tom_tcmall','goods_peisong_type');
    $order_peisong_info = lang('plugin/tom_tcmall','order_peisong_info');
    $order_order_time   = lang('plugin/tom_tcmall','order_order_time');
    $order_hexiao_time  = lang('plugin/tom_tcmall','order_hexiao_time');
    
    $order_goods_name = lang('plugin/tom_tcmall','order_goods_name');
    $order_goods_num = lang('plugin/tom_tcmall','order_goods_num');
    $order_goods_price = lang('plugin/tom_tcmall','order_goods_price');
    $order_dispatch_price = lang('plugin/tom_tcmall','order_dispatch_price');
    $fenhao = lang('plugin/tom_tcmall','fenghao');
    
    $listData[] = array(
        $order_order_no,
        $order_tcshop_id,
        $order_pay_price,
        $order_user_id,
        $order_user_openid,
        $order_xm,
        $order_tel,
        $order_address,
        $order_order_beizu,
        $order_order_status,
        $goods_peisong_type,
        $order_peisong_info,
        $order_order_time,
        $order_hexiao_time,
    ); 
    foreach ($orderList as $v){
        $lineData = array();
        $lineData[] = $v['order_no'];
        $lineData[] = $v['tcshop_id'];
        $lineData[] = $v['pay_price'];
        $lineData[] = $v['user_id'];
        $lineData[] = $v['userInfo']['openid'];
        $lineData[] = $v['address_xm'];
        $lineData[] = "'".$v['address_tel'];
        $v['address_str'] = str_replace("\r\n", "", $v['address_str']);
        $v['address_str'] = str_replace("\n", "", $v['address_str']);
        $lineData[] = $v['address_str'];
        $v['order_beizu'] = str_replace("\r\n", "", $v['order_beizu']);
        $v['order_beizu'] = str_replace("\n", "", $v['order_beizu']);
        $lineData[] = $v['order_beizu'];
        $lineData[] = $v['order_status'];
        $lineData[] = $v['peisong_type'];
        $v['peisong_info'] = str_replace("\r\n", "", $v['peisong_info']);
        $v['peisong_info'] = str_replace("\n", "", $v['peisong_info']);
        $lineData[] = "'".$v['peisong_info'];
        $lineData[] = $v['order_time'];
        $lineData[] = $v['hexiao_time'];
        
        $listData[] = $lineData;
        
        foreach($v['goodsList'] as $gv){
            $lineData = array();
            $lineData[] = '------------';
            $lineData[] = $order_goods_name.$fenhao.$gv['goods_title'];
            $lineData[] = $order_goods_price.$fenhao.$gv['price'];
            $lineData[] = $order_goods_num.$fenhao.$gv['goods_num'];
            $lineData[] = $order_dispatch_price.$fenhao.$gv['dispatch_price'];
            
            $listData[] = $lineData;
        }
        
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=exportOrders.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}