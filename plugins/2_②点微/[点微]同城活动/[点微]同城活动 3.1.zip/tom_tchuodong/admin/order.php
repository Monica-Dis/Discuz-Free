<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=order';
$modListUrl = $adminListUrl.'&tmod=order';
$modFromUrl = $adminFromUrl.'&tmod=order';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

if($formhash == FORMHASH && $act == 'edit_order_status'){
    
    $info = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $order_status = intval($_GET['order_status']);
        $updateData = array();
        $updateData['order_status'] = $order_status;
        C::t('#tom_tchuodong#tom_tchuodong_order')->update($_GET['id'],$updateData);
        
        $bmIds = str_replace('|',',',$info['bm_ids']);
        DB::query("UPDATE ".DB::table('tom_tchuodong_bm')." SET bm_status={$order_status} WHERE id IN ({$bmIds}) ", 'UNBUFFERED');
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        showformheader($modFromUrl.'&act=edit_order_status&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_order_status'] . '</th></tr>';
        showtablefooter();/*Dism��taobao��com*/
        showtableheader();
        echo '<tr><td align="right"><b>'.$Lang['order_status'].'</b></td><td>';
        foreach ($orderStatusArray as $key => $value){
            if($key == $info['order_status']){
                echo '<input type="radio" name="order_status" value="'.$key.'" checked><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }else{
                echo '<input type="radio" name="order_status" value="'.$key.'" ><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }
        }
        echo '</td></tr>';
        echo '<tr><td>&nbsp;</td><td colspan="14" ><b><font color="#fd0303">(' . $Lang['order_order_status_msg'] . ')</font></b></td></tr>';
        tomshowsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refund'){
    
    $wxpay_appid        = trim($tongchengConfig['wxpay_appid']);
    $wxpay_mchid        = trim($tongchengConfig['wxpay_mchid']);
    $wxpay_key          = trim($tongchengConfig['wxpay_key']);
    $wxpay_appsecret    = trim($tongchengConfig['wxpay_appsecret']);

    define("TOM_WXPAY_APPID", $wxpay_appid);
    define("TOM_WXPAY_MCHID", $wxpay_mchid);
    define("TOM_WXPAY_KEY", $wxpay_key);
    define("TOM_WXPAY_APPSECRET", $wxpay_appsecret);
    define("TOM_WXPAY_SSLCERT_PATH", DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_cert.pem');
    define("TOM_WXPAY_SSLKEY_PATH", DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_key.pem');
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/wxpay/lib/WxPay.Api.php';
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $weixinClass = new weixinClass($appid,$appsecret);
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            
            $id = intval($value);
            $orderInfo = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_id($id);
            
            $template_sms   = '';
            
            $payOrderInfo = C::t('#tom_pay#tom_pay_order')->fetch_by_order_no($orderInfo['order_no']);
            $orderUserInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
            if($payOrderInfo['payment'] == 'wxpay_jsapi' || $payOrderInfo['payment'] == 'wxpay_h5'){
                
                if($orderInfo && !empty($orderInfo['order_no']) && !empty($orderInfo['pay_price']) && $orderInfo['pay_price'] > 0 && $orderInfo['order_status']==2){
                    $pay_price = $orderInfo['pay_price']*100;
                    $input = new WxPayRefund();
                    $input->SetOut_trade_no($orderInfo['order_no']);
                    $input->SetTotal_fee($pay_price);
                    $input->SetRefund_fee($pay_price);
                    $input->SetOut_refund_no(WxPayConfig::MCHID.date("YmdHis"));
                    $input->SetOp_user_id(WxPayConfig::MCHID);
                    $return = WxPayApi::refund($input);
                    if(is_array($return) && $return['result_code'] == 'SUCCESS'){
                        
                        $template_sms = $Lang['refund_succ_template_1'];
                        
                        DB::query("UPDATE ".DB::table('tom_tchuodong_order')." SET order_status=5, refund_type=1 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
                        
                        $bmIds = str_replace('|',',',$orderInfo['bm_ids']);
                        DB::query("UPDATE ".DB::table('tom_tchuodong_bm')." SET bm_status=5 WHERE id IN ({$bmIds}) ", 'UNBUFFERED');
                        if($orderInfo['option_id'] > 0){
                            DB::query("UPDATE ".DB::table('tom_tchuodong_option')." SET sale_num=sale_num-{$orderInfo['number']} WHERE id='{$orderInfo['option_id']}' ", 'UNBUFFERED');
                        }
                    }
                }
                
            }else{
                
                if($orderInfo && !empty($orderInfo['order_no']) && !empty($orderInfo['pay_price']) && $orderInfo['pay_price'] > 0 && $orderInfo['order_status']==2){
                    
                    $template_sms = $Lang['refund_succ_template_2'];
                    
                    $insertData = array();
                    $insertData['user_id']          = $orderInfo['user_id'];
                    $insertData['type_id']          = 2;
                    $insertData['change_money']     = $orderInfo['pay_price'];
                    $insertData['old_money']        = $orderUserInfo['money'];
                    $insertData['tag']              = lang('plugin/tom_tchuodong', 'refund_money_log_tag');
                    $insertData['beizu']            = lang('plugin/tom_tchuodong', 'beizu_order_no') . $orderInfo['order_no'];
                    $insertData['log_time']         = TIMESTAMP;
                    C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
                    
                    DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$orderInfo['pay_price']} WHERE id='{$orderUserInfo['id']}'", 'UNBUFFERED');
                    
                    DB::query("UPDATE ".DB::table('tom_tchuodong_order')." SET order_status=5, refund_type=2 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');

                    $bmIds = str_replace('|',',',$orderInfo['bm_ids']);
                    DB::query("UPDATE ".DB::table('tom_tchuodong_bm')." SET bm_status=5 WHERE id IN ({$bmIds}) ", 'UNBUFFERED');
                    if($orderInfo['option_id'] > 0){
                        DB::query("UPDATE ".DB::table('tom_tchuodong_option')." SET sale_num=sale_num-{$orderInfo['number']} WHERE id='{$orderInfo['option_id']}' ", 'UNBUFFERED');
                    }
                }
                
            }
            
            if(!empty($template_sms)){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($orderUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchuodong&site={$orderInfo['site_id']}&mod=myorderinfo&order_no=".$orderInfo['order_no']);
                    $smsData = array(
                        'first'         => $template_sms,
                        'keyword1'      => $tchuodongConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($orderUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }

                $insertData = array();
                $insertData['user_id']      = $orderInfo['user_id'];
                $insertData['type']         = 1;
                $insertData['content']      = '<font color="#238206">'.$tchuodongConfig['plugin_name'].'</font><br/>'.$template_sms.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
                $insertData['is_read']      = 0;
                $insertData['tz_time']      = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
            }
    
        }
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $tchuodong_id   = isset($_GET['tchuodong_id'])? intval($_GET['tchuodong_id']):'';
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):'';
    $order_no       = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
    $order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;
    $shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;

    $pagesize = 20;
    $page     = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start    = ($page-1)*$pagesize;	
    
    $where = "";
    if(!empty($tchuodong_id)){
        $where.= " AND tchuodong_id={$tchuodong_id} ";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    if(!empty($order_no)){
        $where.=" AND order_no='{$order_no}' ";
    }
    if(!empty($order_status)){
        $where.= " AND order_status={$order_status} ";
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    
    $count     = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_count($where);
    $orderList = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&tchuodong_id={$tchuodong_id}&order_no={$order_no}&order_status={$order_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_search_list'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['order_tchuodong_id'].'</b></td><td><input name="tchuodong_id" type="text" value="'.$tchuodong_id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['order_user_id'].'</b></td><td><input name="user_id" type="text" value="'.$user_id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['order_no'].'</b></td><td><input name="order_no" type="text" value="'.$order_no.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_status'] . '</b></td><td><select name="order_status" >';
    echo '<option value="0">'.$Lang['order_status'].'</option>';
    foreach ($orderStatusArray as $key => $value){
        if($key == $order_status){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['bm_shenhe_status'] . '</b></td><td><select name="shenhe_status" >';
    echo '<option value="0">'.$Lang['bm_shenhe_status'].'</option>';
    foreach ($ordershenheStatusArray as $key => $value){
        if($key == $shenhe_status){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select></td></tr>';
   
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism-taobao_com*/
   
    tomshownavheader();
    tomshownavli($Lang['daochu_order'],$adminBaseUrl.'&tmod=orderdoDao',false);
    tomshownavfooter();
    
    $anchor = isset($_GET['anchor']) ? dhtmlspecialchars($_GET['anchor']) : '';
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return order_form();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />'.
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>&nbsp;</th>';
    echo '<th>' . $Lang['order_no'] . '</th>';
    echo '<th>' . $Lang['order_tchuodong_id'] . '</th>';
    echo '<th>' . $Lang['order_option_id'] . '</th>';
    echo '<th>' . $Lang['order_user_id'] . '</th>';
    echo '<th>' . $Lang['order_pay_price'] . '</th>';
    echo '<th>' . $Lang['order_bm_num'] . '</th>';
    echo '<th>' . $Lang['order_use_num'] . '</th>';
    echo '<th>' . $Lang['order_shenhe_status'] . '</th>';
    echo '<th>' . $Lang['order_status'] . '</th>';
    echo '<th>' . $Lang['order_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($orderList as $key => $value){
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $huodongInfo    = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($value['tchuodong_id']);
        $optionInfo     = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($value['option_id']);
        echo '<tr>';
        echo '<td><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" ></td>';
        echo '<td>' . $value['order_no'] . '</td>';
        echo '<td>'.$huodongInfo['title'] .'<font color="#fd0d0d">(ID:'. $value['tchuodong_id'].')</font></td>';
        echo '<td>'.$optionInfo['name'] .'<font color="#fd0d0d">(ID:'. $value['option_id'].')</font></td>';
        echo '<td style="line-height: 20px;max-width: 150px;">' . $userInfo['nickname'].'<font color="#fd0d0d">(UID:'.$value['user_id'].')</font>'.'<br/>';
        if($value['tj_hehuoren_id'] > 0){
            echo '<font color="#fd0d0d">'.$Lang['order_tj_hehuoren_id'].' : '.$value['tj_hehuoren_id'].'</font><br/>';
        }
        echo '</td>';
        echo '<td><font color="#0a9409">'.$value['pay_price'].'</font><br/>';
        if($value['vip_pay_status'] == 1){
            echo '<font color="#0894fb">'.$tcyikatongConfig['card_name'].$Lang['order_vip_pay_status'].'</font>';
        }
        echo '</td>';
        echo '<td>' . $value['number'] . '</td>';
        if($value['use_num'] > 0){
            echo '<td><font color="#0a9409">'.$value['use_num'].'</font>';
        }else{
            echo '<td>0<br/>';
        }
        if($value['shenhe_status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['bm_shenhe_status_1'] . '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 2){
            echo '<td><font color="#f70404">' . $Lang['bm_shenhe_status_2'] . '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 3){
            echo '<td><font color="#f70404">' . $Lang['bm_shenhe_status_3'] . '</font>'.$sheheBtnStr.'</td>';
        }
        echo '<td style="line-height: 20px;">';
        echo '<b><font color="'.$orderStatusColorArray[$value['order_status']].'">' . $orderStatusArray[$value['order_status']] . '</font></b><br/>';
        if($value['refund_type'] == 1){
            echo '<font color="#238206">('.$Lang['refund_refund_type_1'].')</font><br/>';
        }else if($value['refund_type'] == 2){
            echo '<font color="#238206">('.$Lang['refund_refund_type_2'].')</font><br/>';
        }
        echo '</td>';
        echo '<td>';
        if($value['order_time'] > 0){
            echo $Lang['order_order_time'].dgmdate($value['order_time'],"Y-m-d H:i",$tomSysOffset).'<br/>';
        }else{
            echo $Lang['order_order_time'].'--<br/>';
        }
        if($value['pay_time'] > 0){
            echo $Lang['order_pay_time'].dgmdate($value['pay_time'],"Y-m-d H:i",$tomSysOffset).'<br/>';
        }else{
            echo $Lang['order_pay_time'].'--<br/>';
        }
        echo '</td>';
        echo '<td style="line-height: 22px;">';
        echo '<a href="'.$adminBaseUrl.'&tmod=bm&bm_ids='.$value['bm_ids'].'&tchuodong_id='.$value['tchuodong_id'].'&formhash='.FORMHASH.'">' . $Lang['order_bminfo']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit_order_status&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_order_status'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    $formstr = <<<EOF
        <tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="refund">{$Lang['batch_refund']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>
        <script type="text/javascript">
        function order_form(){
          var r = confirm("{$Lang['batch_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        </script>
EOF;
    
    echo $formstr;
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism-taobao_com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
}