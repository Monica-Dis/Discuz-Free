<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
    exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=orderdoDao';
$modListUrl = $adminListUrl.'&tmod=orderdoDao';
$modFromUrl = $adminFromUrl.'&tmod=orderdoDao';

$order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;
$shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$pagesize = 100;
$page     = intval($_GET['page'])>0? intval($_GET['page']):1;
$start    = ($page - 1)*$pagesize;	

$where = "";

if(!empty($order_status)){
    $where.= " AND order_status={$order_status} ";
}
if(!empty($shenhe_status)){
    $where.= " AND shenhe_status={$shenhe_status} ";
}

showformheader($modFromUrl.'&formhash='.FORMHASH);
showtableheader();

$orderStr = '<tr class="header"><th>'.$Lang['daochu_order_status'].'</th><th></th></tr>';
$orderStr.= '<tr><td width="100"><select style="width: 130px;" name="order_status" id="order_status" onchange="refreshterm();">';
$orderStr.=  '<option value="0">'.$Lang['quanbu'].'</option>';
if(is_array($orderStatusArray) && !empty($orderStatusArray)){
    foreach ($orderStatusArray as $key => $value){
        if($key == $order_status){
            $orderStr.=  '<option value='.$key.' selected>'.$value.'</option>';
        }else{
            $orderStr.=  '<option value='.$key.'>'.$value.'</option>';
        }
    }
}
$orderStr.= '</select></td><td></td></tr>';
echo $orderStr;

$shenheStr = '<tr class="header"><th>'.$Lang['daochu_shenhe_status'].'</th><th></th></tr>';
$shenheStr.= '<tr><td width="100"><select style="width: 130px;" name="shenhe_status" id="shenhe_status" onchange="refreshterm();">';
$shenheStr.=  '<option value="0">'.$Lang['quanbu'].'</option>';
if(is_array($ordershenheStatusArray) && !empty($ordershenheStatusArray)){
    foreach ($ordershenheStatusArray as $key => $value){
        if($key == $shenhe_status){
            $shenheStr.=  '<option value='.$key.' selected>'.$value.'</option>';
        }else{
            $shenheStr.=  '<option value='.$key.'>'.$value.'</option>';
        }
    }
}
$shenheStr.= '</select></td><td></td></tr>';
echo $shenheStr;

showformfooter();/*Dism-taobao_com*/
$count = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_count($where);
$num   = ceil($count/100);
$doDaoUrl = $_G['siteurl']."plugin.php?id=tom_tchuodong:orderdoDao&order_status={$order_status}&shenhe_status={$shenhe_status}";
echo '<tr>';
for($i = 1; $i <= $num; $i++){
    $max_number = $i * 100;
    $min_number = $max_number - 100;
    if($i%6 == 0){
        echo '<td><a href="'.$doDaoUrl.'&page='.$i.'" target="_blank" style="color: #FA6A03; padding:2px 7px; font-weight:600; margin-left: 10px; border-radius: 5px; border: 1px solid #FA6A03;">'.$Lang['daochu_order'].$min_number.'-'.$max_number.'</a></td></tr><tr>';
    }else{
        echo '<td><a href="'.$doDaoUrl.'&page='.$i.'" target="_blank" style="color: #FA6A03; padding:2px 7px; font-weight:600; margin-left: 10px; border-radius: 5px; border: 1px solid #FA6A03;">'.$Lang['daochu_order'].$min_number.'-'.$max_number.'</a></td>';
    }
}
echo '</tr>';
showtablefooter();/*Dism��taobao��com*/

$adminurl = $modBaseUrl.'&formhash='.FORMHASH;
echo <<<SCRIPT
<script type="text/javascript">
function refreshterm() {
    location.href = "$adminurl"+"&order_status="+jq('#order_status').val()+"&shenhe_status="+jq('#shenhe_status').val();;
}
</script>
SCRIPT;
