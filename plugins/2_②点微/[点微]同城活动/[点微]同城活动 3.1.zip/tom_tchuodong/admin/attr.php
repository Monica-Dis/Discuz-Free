<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=attr&tchuodong_id='.$_GET['tchuodong_id'];
$modListUrl = $adminListUrl.'&tmod=attr&tchuodong_id='.$_GET['tchuodong_id'];
$modFromUrl = $adminFromUrl.'&tmod=attr&tchuodong_id='.$_GET['tchuodong_id'];

$tchuodong_id   = isset($_GET['tchuodong_id'])? intval($_GET['tchuodong_id']):0;

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tchuodong#tom_tchuodong_attr')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','encattr');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
}else if($_GET['act'] == 'edit'){
    $attrInfo = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($attrInfo);
        C::t('#tom_tchuodong#tom_tchuodong_attr')->update($attrInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'encattr');
        showtableheader();
        __create_info_html($attrInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'showattr'){
    
    DB::query("UPDATE ".DB::table('tom_tchuodong_attr')." SET is_hidden=0 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hideattr'){
    
    DB::query("UPDATE ".DB::table('tom_tchuodong_attr')." SET is_hidden=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tchuodong#tom_tchuodong_attr')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $page     = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 1000;
    $start    = ($page - 1)*$pagesize;	
    
    $where = " AND tchuodong_id={$tchuodong_id} ";
    
    $count    = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_count($where);
    $attrList = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list($where," ORDER BY paixu ASC,id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}";
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['attr_tchuodong_id'] . '</th>';
    echo '<th>' . $Lang['attr_name'] . '</th>';
    echo '<th>' . $Lang['attr_type'] . '</th>';
    echo '<th>' . $Lang['attr_is_hidden'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($attrList as $key => $value) {
        $bmattrCount = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_count(" AND attr_id={$value['id']}");
        echo '<tr>';
        echo '<td>' .$value['tchuodong_id'] . '</td>';
        echo '<td>' .'(<font color="#fd0d0d">ID:'.$value['id'].'</font>) '.$value['name'] . '</td>';
        echo '<td>'. $attrTypeArray[$value['type']].'</td>';
        echo '<td><div class="tc_content_box"><ul>';
        $is_hiddenBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=hideattr&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['attr_is_hidden_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=showattr&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['attr_is_hidden_0']. '</a>)';
        if($value['is_hidden'] == 1 ){
            echo '<li><font color="#0a9409">' . $Lang['attr_is_hidden_1'] . '</font>'.$is_hiddenBtnStr.'</li>';
        }else if($value['is_hidden'] == 0){
            echo '<li><font color="#f70404">' . $Lang['attr_is_hidden_0'] . '</font>'.$is_hiddenBtnStr.'</li>';
        }
        echo '</ul></div></td>';
        echo '<td>';
        
        if($bmattrCount > 0){
            echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['attr_edit']. '</a>';
        }else{
            echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['attr_edit']. '</a>&nbsp;|&nbsp;';
            echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        }
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $type           = isset($_GET['type'])? intval($_GET['type']):1;
    $is_must        = isset($_GET['is_must'])? intval($_GET['is_must']):0;
    $value          = isset($_GET['value'])? addslashes($_GET['value']):'';
    $min_photo_num  = isset($_GET['min_photo_num'])? intval($_GET['min_photo_num']):0;
    $max_photo_num  = isset($_GET['max_photo_num'])? intval($_GET['max_photo_num']):0;
    $unit           = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $msg            = isset($_GET['msg'])? addslashes($_GET['msg']):'';
    $is_hidden      = isset($_GET['is_hidden'])? intval($_GET['is_hidden']):0;
    $paixu          = isset($_GET['paixu'])? intval($_GET['paixu']):100;
    
    $data['tchuodong_id']   = $_GET['tchuodong_id'];
    $data['name']           = $name;
    $data['type']           = $type;
    $data['is_must']        = $is_must;
    $data['value']          = $value;
    $data['min_photo_num']  = $min_photo_num;
    $data['max_photo_num']  = $max_photo_num;
    $data['unit']           = $unit;
    $data['msg']            = $msg;
    $data['is_hidden']      = $is_hidden;
    $data['paixu']          = $paixu;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'              => '',
        'type'              => 1,
        'is_must'           => 0,
        'value'             => '',
        'min_photo_num'     => '',
        'max_photo_num'     => '',
        'unit'              => '',
        'msg'               => '',
        'is_hidden'         => '',
        'paixu'             => 100,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['attr_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['attr_name_msg']),"input");
    $type_item = array(1=>$Lang['attr_type1'],2=>$Lang['attr_type2'],3=>$Lang['attr_type3'],4=>$Lang['attr_type4'],5=>$Lang['attr_type5'],6=>$Lang['attr_type6']);
    tomshowsetting(true,array('title'=>$Lang['attr_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['attr_type_msg'],'item'=>$type_item),"radio");
    $must_item = array(1=>$Lang['attr_must1'],0=>$Lang['attr_must0']);
    tomshowsetting(true,array('title'=>$Lang['attr_must'],'name'=>'is_must','value'=>$options['is_must'],'msg'=>$Lang['attr_must_msg'],'item'=>$must_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['attr_value'],'name'=>'value','value'=>$options['value'],'msg'=>$Lang['attr_value_msg']),"textarea");
    tomshowsetting(true,array('title'=>$Lang['attr_min_photo_num'],'name'=>'min_photo_num','value'=>$options['min_photo_num'],'msg'=>$Lang['attr_min_photo_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['attr_max_photo_num'],'name'=>'max_photo_num','value'=>$options['max_photo_num'],'msg'=>$Lang['attr_max_photo_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['attr_unit'],'name'=>'unit','value'=>$options['unit'],'msg'=>$Lang['attr_unit_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['attr_msg'],'name'=>'msg','value'=>$options['msg'],'msg'=>$Lang['attr_msg_msg']),"input");
    $is_hidden_item = array(0=>$Lang['attr_is_hidden_0'],1=>$Lang['attr_is_hidden_1']);
    tomshowsetting(true,array('title'=>$Lang['attr_is_hidden'],'name'=>'is_hidden','value'=>$options['is_hidden'],'msg'=>$Lang['attr_is_hidden_msg'],'item'=>$is_hidden_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['attr_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['attr_paixu_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl,$modListUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['attr_list'],$modBaseUrl,false);
        tomshownavli($Lang['attr_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['attr_list'],$modBaseUrl,false);
        tomshownavli($Lang['attr_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['attr_edit'],"",true);
    }else{
        tomshownavli($Lang['attr_list'],$modBaseUrl,true);
        tomshownavli($Lang['attr_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}