<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=bm&tchuodong_id='.$_GET['tchuodong_id'];
$modListUrl = $adminListUrl.'&tmod=bm&tchuodong_id='.$_GET['tchuodong_id'];
$modFromUrl = $adminFromUrl.'&tmod=bm&tchuodong_id='.$_GET['tchuodong_id'];

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'bminfo'){
  
    $bmInfo = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_by_id($_GET['id']);
    $hexiaoUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($bmInfo['hexiao_user_id']);
    
    if(submitcheck('submit')){
        $bm_status = intval($_GET['bm_status']);
        $updateData = array();
        $updateData['bm_status'] = $bm_status;
        C::t('#tom_tchuodong#tom_tchuodong_bm')->update($_GET['id'],$updateData);
        
        $orderInfo = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_id($bmInfo['order_id']);
        $bmIds = str_replace('|',',',$orderInfo['bm_ids']);
        
        $bmstatusCount = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_all_count("AND bm_status = {$bm_status} AND id IN ($bmIds)");
        if($orderInfo['is_fenkai_bm'] == 1){
            if(($orderInfo['number'] - $bmstatusCount) <= 1 ){
                DB::query("UPDATE ".DB::table('tom_tchuodong_order')." SET order_status={$bm_status} WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
            }
        }else{
            DB::query("UPDATE ".DB::table('tom_tchuodong_order')." SET order_status={$bm_status} WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        $attrbmListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_list("AND bm_id = {$_GET['id']} AND type_id != 6","ORDER BY paixu ASC,id DESC");
        $attrbmList = array();
        if(is_array($attrbmListTmp) && !empty($attrbmListTmp)){
            foreach ($attrbmListTmp as $key => $value){
                $attrbmList[$key] = $value;
            }
        }
        $attrpicListTmp = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list("AND tchuodong_id = {$bmInfo['tchuodong_id']} AND type = 6","ORDER BY paixu ASC,id DESC");
        $attrpicList = array();
        if(is_array($attrpicListTmp) && !empty($attrpicListTmp)){
            foreach ($attrpicListTmp as $key => $value){
                $attrpicList[$key] = $value;
                $attrbmpicListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_list("AND bm_id = {$_GET['id']} AND type_id = 6 AND attr_id = {$value['id']}","ORDER BY paixu ASC,id DESC");
                $attrbmpicList = array();
                if(is_array($attrbmpicListTmp) && !empty($attrbmpicListTmp)){
                    foreach($attrbmpicListTmp as $k => $v){
                        $attrbmpicList[$k] = $v;
                        if(!preg_match('/^http/', $value['picurl_value'])){
                            if(strpos($v['picurl_value'], 'source/plugin/') === false){
                                $attrbmpicList[$k]['picurl_value'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$v['picurl_value'];
                            }else{
                                $attrbmpicList[$k]['picurl_value'] = $v['picurl_value'];
                            }
                        }else{
                            $attrbmpicList[$k]['picurl_value'] = $v['picurl_value'];
                        }
                    }
                }
                $attrpicList[$key]['attrbmpicList']    = $attrbmpicList;
            }
        }

        $fenghao = $Lang['fenghao'];
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['bm_info'] . '</th></tr>';
        echo '<tr><td align="right"><b>'.$Lang['bm_xm'].$fenghao.'</b></td><td>'.$bmInfo['xm'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['bm_tel'].$fenghao.'</b></td><td>'.$bmInfo['tel'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['bm_add_time'].$fenghao.'</b></td><td>'.dgmdate($bmInfo['add_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
        if($bmInfo['hexiao_time'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['bm_hexiao_time'].$fenghao.'</b></td><td>'.dgmdate($bmInfo['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
            echo '<tr><td align="right"><b>'.$Lang['bm_hexiao_user_id'].$fenghao.'</b></td><td>'.$bmInfo['hexiao_user_id'].'('.$hexiaoUserInfo['nickname'].')'.'</td></tr>';
        }
       
        if(is_array($attrbmList) && !empty($attrbmList)){
            foreach ($attrbmList as $key => $value) {
                echo '<tr><td align="right"><b>'.$value['attr_name'].$fenghao.'</b></td>';
                echo '<td align="left">'. $value['value'].$value['unit'].'</td>';
                echo '</tr>';
            }
        }
        if(is_array($attrpicList) && !empty($attrpicList)){
            foreach ($attrpicList as $key => $value) {
                if(is_array($value['attrbmpicList']) && !empty($value['attrbmpicList'])){
                    echo '<tr><td align="right"><b>'.$value['name'].$fenghao.'</b></td>';
                    echo '<td align="left">';
                    foreach ($value['attrbmpicList'] as $k => $v) {
                        echo '<a href="'.$v['picurl_value'].'" target="_blank"><img src="' . ($v['picurl_value']) . '" width="80" /></a>&nbsp&nbsp&nbsp';
                    }
                    echo '</td></tr>';
                }
            }
        }
        showtablefooter();/*Dism��taobao��com*/

        showformheader($modFromUrl.'&act=bminfo&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_bm_status'] . '</th></tr>';
        showtablefooter();/*Dism��taobao��com*/
        showtableheader();
        echo '<tr><td align="right"><b>'.$Lang['bm_status'].'</b></td><td>';
        foreach ($bmStatusArray as $key => $value){
            if($key == $bmInfo['bm_status']){
                echo '<input type="radio" name="bm_status" value="'.$key.'" checked><b><font color="'.$bmStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }else{
                echo '<input type="radio" name="bm_status" value="'.$key.'" ><b><font color="'.$bmStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }
        }
        echo '</td></tr>';
        echo '<tr><td>&nbsp;</td><td colspan="14" ><b><font color="#fd0303">(' . $Lang['bm_bm_status_msg'] . ')</font></b></td></tr>';
        tomshowsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delete'){
    
    $bmInfo = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_by_id($_GET['id']);
    $orderInfo = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_id($bmInfo['order_id']);
    
    C::t('#tom_tchuodong#tom_tchuodong_bm')->delete_by_id($_GET['id']);
    
    C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->delete_by_bm_id($_GET['id']);
    
    if($orderInfo['is_fenkai_bm'] == 1){
        DB::query("UPDATE ".DB::table('tom_tchuodong_option')." SET sale_num=sale_num-1 WHERE id='{$orderInfo['option_id']}' ", 'UNBUFFERED');
    }else{
        DB::query("UPDATE ".DB::table('tom_tchuodong_option')." SET sale_num=sale_num-{$orderInfo['number']} WHERE id='{$orderInfo['option_id']}' ", 'UNBUFFERED');
    }
    
    $count    = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_all_count(" AND order_id={$bmInfo['order_id']} ");
    if($count > 0){}else{
        $updateData = array();
        $updateData['order_status'] = 4;
        C::t('#tom_tchuodong#tom_tchuodong_order')->update($bmInfo['order_id'],$updateData);
    }

    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenheok'){
    
    DB::query("UPDATE ".DB::table('tom_tchuodong_bm')." SET shenhe_status=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    $bmInfo = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_by_id($_GET['id']);
    $orderInfo = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_id($bmInfo['order_id']);
    
    $bmIds = str_replace('|',',',$orderInfo['bm_ids']);
    $shenheokCount = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_all_count("AND shenhe_status = 1 AND id IN ($bmIds)");
    if($orderInfo['is_fenkai_bm'] == 1){
        if(($orderInfo['number'] - $shenheokCount) <= 1 ){
            DB::query("UPDATE ".DB::table('tom_tchuodong_order')." SET shenhe_status=1 WHERE id='{$bmInfo['order_id']}' ", 'UNBUFFERED');
        }
    }else{
        DB::query("UPDATE ".DB::table('tom_tchuodong_order')." SET shenhe_status=1 WHERE id='{$bmInfo['order_id']}' ", 'UNBUFFERED');
    }
    
    $huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($bmInfo['tchuodong_id']);
    if($huodongInfo['site_id'] == 1){
        $sitename = $tongchengConfig['plugin_name'];
    }else{
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($huodongInfo['site_id']);
        $sitename = $siteInfo['name'];
    }
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($bmInfo['user_id']);

    $shenhe = str_replace('{TITLE}', $huodongInfo['title'], $Lang['template_tchuodong_bm_shenhe_ok']);
    $cpmsg = $Lang['tchuodong_shenhe_tz_succ'];
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $weixinClass = new weixinClass($appid,$appsecret);
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchuodong&site={$huodongInfo['site_id']}&mod=myorder");
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $sitename,
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
        }else{
            $cpmsg = $Lang['tchuodong_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tchuodongConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenheno'){
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        DB::query("UPDATE ".DB::table('tom_tchuodong_bm')." SET shenhe_status=3 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
        
        $bmInfo = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_by_id($_GET['id']);
        $orderInfo = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_id($bmInfo['order_id']);
        
        $bmIds = str_replace('|',',',$orderInfo['bm_ids']);
        $shenhenoCount = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_all_count("AND shenhe_status = 3 AND id IN ($bmIds)");
        if($orderInfo['is_fenkai_bm'] == 1){
            if(($orderInfo['number'] - $shenhenoCount) <= 1 ){
                DB::query("UPDATE ".DB::table('tom_tchuodong_order')." SET shenhe_status=3 WHERE id='{$bmInfo['order_id']}' ", 'UNBUFFERED');
            }
        }else{
            DB::query("UPDATE ".DB::table('tom_tchuodong_order')." SET shenhe_status=3 WHERE id='{$bmInfo['order_id']}' ", 'UNBUFFERED');
        }
    
        $huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($bmInfo['tchuodong_id']);
        if($huodongInfo['site_id'] == 1){
            $sitename = $tongchengConfig['plugin_name'];
        }else{
            $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($huodongInfo['site_id']);
            $sitename = $siteInfo['name'];
        }
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($huodongInfo['user_id']);
        
        $shenhe = str_replace('{TITLE}', $huodongInfo['title'], $Lang['template_tchuodong_bm_shenhe_no']);
        $cpmsg = $Lang['tchuodong_shenhe_tz_succ'];
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchuodong&site={$huodongInfo['site_id']}&mod=myorder");
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $sitename,
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
            }else{
                $cpmsg = $Lang['tchuodong_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tchuodongConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tchuodong_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        
        tomloadcalendarjs();
        loadeditorjs();
        showformheader($modFromUrl.'&act=shenheno&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tchuodong_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcchuodong_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else{
    $tchuodong_id   = isset($_GET['tchuodong_id'])? intval($_GET['tchuodong_id']):0;
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $xm             = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $bm_status      = isset($_GET['bm_status'])? intval($_GET['bm_status']):0;
    $shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $bm_ids         = isset($_GET['bm_ids'])? addslashes($_GET['bm_ids']):'';
   
    $huodongInfo  = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($_GET['tchuodong_id']);
    
    $pagesize = 15;
    $page     = intval($_GET['page'])>0 ? intval($_GET['page']):1;
    $start    = ($page - 1)*$pagesize;
    
    $where = "";
    if(!empty($tchuodong_id)){
        $where.= " AND tchuodong_id={$tchuodong_id} ";
    }
    if(!empty($tel)){
        $where.= " AND tel= '{$tel}'";
    }
    if(!empty($xm)){
        $where.= " AND xm= '{$xm}'";
    }
    if(!empty($bm_status)){
        $where.= " AND bm_status={$bm_status} ";
    }
    if($shenhe_status > 0){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    if(!empty($bm_ids)){
        $bm_ids = str_replace('|',',',$bm_ids);
        $where.= " AND id IN ({$bm_ids})";
    }
    
    $count    = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_all_count($where);
    $bmListTmp   = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_all_list($where,"ORDER BY add_time DESC,id DESC", $start, $pagesize);
   
    $bmList = array();
    foreach ($bmListTmp as $k => $v) {
        $bmList[$k] = $v;
        $attrListTmp = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list("AND tchuodong_id = {$v['tchuodong_id']} AND type != 6","ORDER BY paixu ASC,id DESC");
        $attrList = array();
        if(is_array($attrListTmp) && !empty($attrListTmp)){
            foreach ($attrListTmp as $key => $value){
                $attrList[$key] = $value;
                $attrbmListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_list("AND bm_id = {$v['id']} AND type_id != 6 AND attr_id = {$value['id']}","ORDER BY paixu ASC,id DESC");
                $attrbmList = array();
                if(is_array($attrbmListTmp) && !empty($attrbmListTmp)){
                    foreach($attrbmListTmp as $kk => $vv){
                        $attrbmList[] = $vv['value'];
                    }
                }
                $attrList[$key]['attrbmStr']      = implode('|',$attrbmList);
            }
        } 
        
        $attrpicListTmp = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list("AND tchuodong_id = {$v['tchuodong_id']} AND type = 6","ORDER BY paixu ASC,id DESC");
        $attrpicList = array();
        if(is_array($attrpicListTmp) && !empty($attrpicListTmp)){
            foreach ($attrpicListTmp as $key => $value){
                $attrpicList[$key] = $value;
                $attrbmpicListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_list("AND bm_id = {$v['id']} AND type_id = 6 AND attr_id = {$value['id']}","ORDER BY paixu ASC,id DESC");
                $attrbmpicList = array();
                if(is_array($attrbmpicListTmp) && !empty($attrbmpicListTmp)){
                    foreach($attrbmpicListTmp as $kk => $vv){
                        if(!preg_match('/^http/', $vv['picurl_value'])){
                            if(strpos($vv['picurl_value'], 'source/plugin/') === false){
                                $attrbmpicList[] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl_value'];
                            }else{
                                $attrbmpicList[] = $_G['siteurl'].$vv['picurl_value'];
                            }
                        }else{
                            $attrbmpicList[] = $vv['picurl_value'];
                        }
                    }
                }
                $attrpicList[$key]['attrbmpicList']   = $attrbmpicList;
            }
        } 
        $hexiaoUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($v['hexiao_user_id']);
       
        $bmList[$k]['attrList']        = $attrList;
        $bmList[$k]['attrpicList']     = $attrpicList;
        $bmList[$k]['hexiaoUserInfo']  = $hexiaoUserInfo;
    }

    $modBasePageUrl = $modBaseUrl."&tchuodong_id={$tchuodong_id}&tel={$tel}&bm_status={$bm_status}&shenhe_status={$shenhe_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['bm_search_list'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['bm_xm'].'</b></td><td><input name="xm" type="text" value="'.$xm.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['bm_tel'].'</b></td><td><input name="tel" type="text" value="'.$tel.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['bm_status'] . '</b></td><td><select style="width: 260px;"  name="bm_status" >';
    echo '<option value="0">'.$Lang['bm_status'].'</option>';
    foreach ($bmStatusArray as $key => $value){
        if($key == $bm_status){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select></td></tr>';
    $shenhe_status_1 = $shenhe_status_2 = $shenhe_status_3 = '';
    if($shenhe_status == 1){
        $shenhe_status_1 = 'selected';
    }else if($shenhe_status == 2){
        $shenhe_status_2 = 'selected';
    }else if($shenhe_status == 3){
        $shenhe_status_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['bm_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['bm_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$shenhe_status_1.'>'.$Lang['bm_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$shenhe_status_2.'>'.$Lang['bm_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$shenhe_status_3.'>'.$Lang['bm_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism-taobao_com*/
   
    tomshownavheader();
    tomshownavli($Lang['daochu_bmlist'],$adminBaseUrl."&tmod=doDao&tchuodong_id={$tchuodong_id}",false);
    tomshownavfooter();
        
    showtableheader();
    echo '<tr class="header">';
    echo '<th width="10%">'. $Lang['bm_id'].'</th>';
    echo '<th>'. $Lang['bm_option_name'].'</th>';
    echo '<th width="10%">'. $Lang['bm_user_id'].'</th>';
    echo '<th>'. $Lang['bm_xm'].'</th>';
    echo '<th>'. $Lang['bm_tel'].'</th>';
    
    $attrListTmp = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list("AND tchuodong_id = {$tchuodong_id} AND type != 6","ORDER BY paixu ASC,id DESC");
    $attrList = array();
    if(is_array($attrListTmp) && !empty($attrListTmp)){
        foreach ($attrListTmp as $key => $value){
            $attrList[$key] = $value;
            echo '<th>'. $value['name'].'</th>';
        }
    } 
    $attrpicListTmp = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list("AND tchuodong_id = {$tchuodong_id} AND type = 6","ORDER BY paixu ASC,id DESC");
    $attrpicList = array();
    if(is_array($attrpicListTmp) && !empty($attrpicListTmp)){
        foreach ($attrpicListTmp as $key => $value){
            $attrpicList[$key] = $value;
            echo '<th>'. $value['name'].'</th>';
        }
    } 
    echo '<th>'. $Lang['bm_shenhe_status'].'</th>';
    echo '<th>'. $Lang['bm_status'].'</th>';
    echo '<th>'. $Lang['handle'].'</th>';
    echo '</tr>';
    $i = 1;
    foreach ($bmList as $key => $value) {
        
        $optionInfo     = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($value['option_id']);
        
        $shenhe_status = '';
        if($value['shenhe_status'] == 1){
            $shenhe_status = $Lang['indexshenhe_ok'];
        }else if($value['shenhe_status'] == 2){
            $shenhe_status = $Lang['indexshenhe_ing'];
        }else if($value['shenhe_status'] == 3){
            $shenhe_status = $Lang['indexshenhe_no'];
        }else{
            $shenhe_status = '-';
        }
        
        echo '<tr>';
        echo '<td>'. $value['id'].'</td>';
        echo '<td>'. $optionInfo['name'].'</td>';
        echo '<td>'. $value['user_id'].'</td>';
        echo '<td>'. $value['xm'].'</td>';
        echo '<td>'. $value['tel'].'</td>';

        foreach($value['attrList'] as $av){
            if($av['attrbmStr']){
                echo '<td>'. $av['attrbmStr'].'</td>';
            }else{
                echo '<td>'.'--'.'</td>';
            }
        }
        foreach($value['attrpicList'] as $av){
            if($av['attrbmpicList']){
                echo '<td><ul>';
                foreach($av['attrbmpicList'] as $avv){
                echo '<a href="'.$avv.'" target="_blank"><li><img src="' . ($avv) . '" width="40" height="40"/></li></a>&nbsp&nbsp&nbsp';
                }
                echo '</ul></td>';
            }else{
                echo '<td>'.'--'.'</td>';
            }
        }
        echo '<td>';
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenheok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_ok']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenheno&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_no']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo ''.$Lang['bm_shenhe_status'].'&nbsp;:&nbsp;<font color="#0a9409">' . $Lang['bm_shenhe_status_1'] . '</font>'.$sheheBtnStr.'';
        }else if($value['shenhe_status'] == 2){
            echo ''.$Lang['bm_shenhe_status'].'&nbsp;:&nbsp;<font color="#f70404">' . $Lang['bm_shenhe_status_2'] . '</font>'.$sheheBtnStr.'';
        }else if($value['shenhe_status'] == 3){
            echo ''.$Lang['bm_shenhe_status'].'&nbsp;:&nbsp;<font color="#f70404">' . $Lang['bm_shenhe_status_3'] . '</font>'.$sheheBtnStr.'';
        }
        echo '</td>';
        echo '<td style="line-height: 20px;max-width: 150px;">';
        echo '<b><font color="'.$bmStatusColorArray[$value['bm_status']].'">' . $bmStatusArray[$value['bm_status']] . '</font></b><br/>';
        if($value['bm_status'] == 3){
            echo '<font color="#0894fb">(' .$Lang['bm_hexiao_user_id'].'&nbsp;:&nbsp;'.$value['hexiaoUserInfo']['nickname'].'&nbsp;:&nbsp;UID'.$value['hexiao_user_id'].')'.'</font><br/>';
            echo '<font color="#fd0d0d">(' .$Lang['bm_hexiao_time'].'&nbsp;:&nbsp;'. dgmdate($value['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset) .')'.'</font><br/>';
        }
        echo '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=bminfo&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['bm_info'] . '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delete&id='.$value['id'].'&formhash='.FORMHASH.'\');">'.$Lang['delete'].'</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi,false );
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")  
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}