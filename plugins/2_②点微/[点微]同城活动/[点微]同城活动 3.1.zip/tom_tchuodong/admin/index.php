<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index'; 
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $site_id     = isset($_GET['site_id'])? intval($_GET['site_id']):0;
        $type        = isset($_GET['type'])? intval($_GET['type']):0;
        $title       = isset($_GET['title'])? addslashes($_GET['title']):'';
        
        $insertData = array();
        $insertData['site_id']       = $site_id;
        $insertData['type']          = $type;
        $insertData['title']         = $title;
        $insertData['status']        = 2;
        $insertData['shenhe_status'] = 1;
        $insertData['add_time']      = TIMESTAMP;
        if(C::t('#tom_tchuodong#tom_tchuodong')->insert($insertData)){
            $tchuodong_id = C::t('#tom_tchuodong#tom_tchuodong')->insert_id();
        }
        cpmsg($Lang['act_success'], $modListUrl.'&act=edit&id='.$tchuodong_id, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['index_add'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['index_site_id'],'name'=>'site_id','value'=>1,'msg'=>$Lang['index_site_id_msg']),"input");
        $type_item = array(1=>$Lang['index_type_1'],2=>$Lang['index_type_2']);
        tomshowsetting(true,array('title'=>$Lang['index_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['index_type_msg'],'item'=>$type_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['index_title_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
}else if($_GET['act'] == 'edit'){
    
    $huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($huodongInfo);
        C::t('#tom_tchuodong#tom_tchuodong')->update($huodongInfo['id'],$updateData);
        
        $huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($huodongInfo['id']);
        update_huodong_status($huodongInfoTmp);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($huodongInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    DB::query("UPDATE ".DB::table('tom_tchuodong')." SET status=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    DB::query("UPDATE ".DB::table('tom_tchuodong')." SET status=2 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenheok'){
    
    DB::query("UPDATE ".DB::table('tom_tchuodong')." SET shenhe_status=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    $huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($_GET['id']);
    if($huodongInfo['site_id'] == 1){
        $sitename = $tongchengConfig['plugin_name'];
    }else{
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($huodongInfo['site_id']);
        $sitename = $siteInfo['name'];
    }
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($huodongInfo['user_id']);

    $shenhe = str_replace('{TITLE}', $huodongInfo['title'], $Lang['template_tchuodong_shenhe_ok']);
    $cpmsg = $Lang['tchuodong_shenhe_tz_succ'];
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $weixinClass = new weixinClass($appid,$appsecret);
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchuodong&site={$huodongInfo['site_id']}&mod=details&tchuodong_id=".$huodongInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $sitename,
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
        }else{
            $cpmsg = $Lang['tchuodong_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tchuodongConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenheno'){
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        DB::query("UPDATE ".DB::table('tom_tchuodong')." SET shenhe_status=3 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
        
        $huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($_GET['id']);
        if($huodongInfo['site_id'] == 1){
            $sitename = $tongchengConfig['plugin_name'];
        }else{
            $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($huodongInfo['site_id']);
            $sitename = $siteInfo['name'];
        }
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($huodongInfo['user_id']);
        
        $shenhe = str_replace('{TITLE}', $huodongInfo['title'], $Lang['template_tchuodong_shenhe_no']);
        $cpmsg = $Lang['tchuodong_shenhe_tz_succ'];
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchuodong&site={$huodongInfo['site_id']}&mod=edit&tchuodong_id=".$huodongInfo['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $sitename,
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
            }else{
                $cpmsg = $Lang['tchuodong_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tchuodongConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tchuodong_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenheno&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tchuodong_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcchuodong_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'tuijian'){
    
    DB::query("UPDATE ".DB::table('tom_tchuodong')." SET is_recommend=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'notuijian'){
    
    DB::query("UPDATE ".DB::table('tom_tchuodong')." SET is_recommend=0 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['act'] == 'photo'){
    
    $tchuodong_id  = isset($_GET['tchuodong_id'])? intval($_GET['tchuodong_id']):1;
    
    if(submitcheck('submit')){
        
        if($_FILES["picurl"]['tmp_name']) {
            $upload = new tom_upload();
            if(!$upload->init($_FILES["picurl"], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }
            $picurl = $upload->attach['attachment'];
        }else{
            $picurl = addslashes($_GET["picurl"]);
        }
        
        $insertData = array();
        $insertData['tchuodong_id']       = $tchuodong_id;
        $insertData['picurl']             = $picurl;
        $insertData['add_time']           = TIMESTAMP;
        C::t('#tom_tchuodong#tom_tchuodong_photo')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl."&act=photo&tchuodong_id=".$_GET['tchuodong_id'], 'succeed');
    }
    
    $huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($_GET['tchuodong_id']);
    
    $photoList = C::t('#tom_tchuodong#tom_tchuodong_photo')->fetch_all_list(" AND tchuodong_id={$tchuodong_id} ","ORDER BY id ASC",0,100);
    __create_nav_html();
    showformheader($modFromUrl.'&act=photo&tchuodong_id='.$tchuodong_id,'enctype');
    showtableheader();
    tomshowsetting(true,array('title'=>$Lang['index_photo_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['index_photo_picurl_msg']),"file");
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism-taobao_com*/
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['index_photo_picurl'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($photoList as $key => $value) {
        echo '<tr>';
        echo '<td><img src="' . tomgetfileurl($value['picurl']) . '" width="60" /></td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&tchuodong_id='.$tchuodong_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tchuodong#tom_tchuodong_photo')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl."&act=photo&tchuodong_id=".$_GET['tchuodong_id'], 'succeed');
    
}else if($_GET['act'] == 'xubuy'){
    
    $tchuodong_id  = isset($_GET['tchuodong_id'])? intval($_GET['tchuodong_id']):0;
    
    $tchuodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
    
    if(submitcheck('submit')){
        
        $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
        $option_id          = isset($_GET['option_id'])? intval($_GET['option_id']):0;
        $order_time         = isset($_GET['order_time'])? addslashes($_GET['order_time']):'';
        $order_time         = strtotime($order_time);
        
        if($order_time > TIMESTAMP){
            cpmsg($Lang['xubuy_order_time_error'], $modListUrl."&act=xubuy&tchuodong_id=".$_GET['tchuodong_id'], 'error');
        }
        
        $insertData = array();
        $insertData['tchuodong_id'] = $tchuodong_id;
        $insertData['option_id']    = $option_id;
        $insertData['type_id']      = 2;
        $insertData['user_id']      = $user_id;
        $insertData['bm_num']       = 1;
        $insertData['order_time']   = $order_time;
        C::t('#tom_tchuodong#tom_tchuodong_xubuy')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl."&act=xubuy&tchuodong_id=".$_GET['tchuodong_id'], 'succeed');
    }
    
    $csstr = <<<EOF
<style type="text/css">
.pns input{width: 20px;}
</style>
EOF;
    echo $csstr;
    tomloadcalendarjs();
    __create_nav_html();
    showformheader($modFromUrl.'&act=xubuy&tchuodong_id='.$tchuodong_id,'enctype');
    showtableheader();
    $userList = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_like_list(' AND is_majia = 1 ',"ORDER BY id DESC",0,1000,'');
    $userStr = '<tr class="header"><th>'.$Lang['xubuy_user_id'].'</th><th></th></tr>';
    $userStr.= '<tr><td width="300"><select style="width: 260px;" name="user_id" id="user_id">';
    foreach ($userList as $key => $value){
        $userStr.=  '<option value="'.$value['id'].'">'.$value['nickname'].'(ID:'.$value['id'].')</option>';
    }
    $userStr.= '</select></td><td></td></tr>';
    echo $userStr;
    
    $optionList = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_all_list(" AND tchuodong_id = {$tchuodong_id} ", 'ORDER BY osort ASC,id ASC', 0, 100);
    $optionStr = '<tr class="header"><th>'.$Lang['xubuy_option'].'</th><th></th></tr>';
    $optionStr.= '<tr><td width="300"><select style="width: 260px;" name="option_id" id="option_id">';
    foreach ($optionList as $key => $value){
        $optionStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $optionStr.= '</select></td><td></td></tr>';
    echo $optionStr;
    
    tomshowsetting(true,array('title'=>$Lang['xubuy_order_time'],'name'=>'order_time','value'=>$options['order_time'],'msg'=>$Lang['xubuy_order_time_msg']),"calendar");
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism-taobao_com*/
    
    $xubuyList = C::t('#tom_tchuodong#tom_tchuodong_xubuy')->fetch_all_list(" AND tchuodong_id={$tchuodong_id} AND type_id=2 ","ORDER BY order_time DESC,id ASC",0,1000);
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th>UID</th>';
    echo '<th>' . $Lang['xubuy_user_id'] . '</th>';
    echo '<th>' . $Lang['xubuy_option'] . '</th>';
    echo '<th>' . $Lang['xubuy_bm_num'] . '</th>';
    echo '<th>' . $Lang['xubuy_order_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($xubuyList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        $optionInfo = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($value['option_id']);
        
        echo '<tr>';
        echo '<td>' . $userInfo['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] . '</td>';
        echo '<th>' . $optionInfo['name'] . '</th>';
        echo '<td>' . $value['bm_num'] . '</td>';
        echo '<td>' . dgmdate($value['order_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delxubuy&id='.$value['id'].'&tchuodong_id='.$tchuodong_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delxubuy'){
    
    C::t('#tom_tchuodong#tom_tchuodong_xubuy')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl."&act=xubuy&tchuodong_id=".$_GET['tchuodong_id'], 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tchuodong#tom_tchuodong')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
   
    set_list_url("tom_tchuodong_admin_index_list");
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ list-style-type: none; height: 25px; line-height: 25px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;padding: 3px 10px;color: #6a6d6a; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
</style>
EOF;
    echo $csstr;
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $is_recommend   = isset($_GET['is_recommend'])? intval($_GET['is_recommend']):0;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $type           = isset($_GET['type'])? intval($_GET['type']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;

    $where = "";
    if($site_id > 0){
        $where.= " AND site_id={$site_id} ";
    }
    if($is_recommend == 1){
        $where.= " AND is_recommend=0 ";
    }else if($is_recommend == 2){
        $where.= " AND is_recommend=1 ";
    }
    if($status == 1){
        $where.= " AND status=1 ";
    }else if($status == 2){
        $where.= " AND status=2 ";
    }
    if($shenhe_status > 0){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    if($type == 1){
        $where.= " AND type=1 ";
    }else if($type == 2){
        $where.= " AND type=2 ";
    }
    
    $sort = " ORDER BY id DESC ";
    $pagesize = 15;
    $start = ($page - 1)*$pagesize;	
    $count       = C::t('#tom_tchuodong#tom_tchuodong')->fetch_all_count("{$where}",$title);
    $huodongList = C::t('#tom_tchuodong#tom_tchuodong')->fetch_all_like_list("{$where}",$sort,$start,$pagesize,$title);
    
    showtableheader();
    $Lang['index_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_3']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_3'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();/*Dism��taobao��com*/
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&status={$status}&shenhe_status={$shenhe_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    $selected_1 = '';
    if($site_id == 1){
        $selected_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$selected_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    echo '<tr><td width="100" align="right"><b>' . $Lang['index_title'] . '</b></td><td><input name="title" type="text" value="'.$title.'" style="width: 260px;" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['index_is_recommend'] . '</b></td><td><select style="width: 260px;" name="is_recommend" >';
    echo '<option value="0">'.$Lang['quanbu'].'</option>';
    $is_recommend1_selected = $is_recommend2_selected = "";
    if(1 == $is_recommend){
        $is_recommend1_selected = "selected";
    }
    if(2 == $is_recommend){
        $is_recommend2_selected = "selected";
    }
    echo '<option value="1" '.$is_recommend1_selected.'>'.$Lang['index_is_recommend_0'].'</option>';
    echo '<option value="2" '.$is_recommend2_selected.'>'.$Lang['index_is_recommend_1'].'</option>';
    echo '</select></td></tr>';
 
    $shenhe_status_1 = $shenhe_status_2 = $shenhe_status_3 = '';
    if($shenhe_status == 1){
        $shenhe_status_1 = 'selected';
    }else if($shenhe_status == 2){
        $shenhe_status_2 = 'selected';
    }else if($shenhe_status == 3){
        $shenhe_status_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['index_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$shenhe_status_1.'>'.$Lang['index_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$shenhe_status_2.'>'.$Lang['index_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$shenhe_status_3.'>'.$Lang['index_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    echo '<tr><td width="100" align="right"><b>' . $Lang['index_status'] . '</b></td><td><select style="width: 260px;" name="status" >';
    echo '<option value="0">'.$Lang['index_status'].'</option>';
    $status1_selected = $status2_selected = "";
    if(1 == $status){
        $status1_selected = "selected";
    }
    if(2 == $status){
        $status2_selected = "selected";
    }
    echo '<option value="1" '.$status1_selected.'>'.$Lang['index_status_1'].'</option>';
    echo '<option value="2" '.$status2_selected.'>'.$Lang['index_status_2'].'</option>';
    echo '</select></td></tr>';
    
    echo '<tr><td width="100" align="right"><b>' . $Lang['index_type'] . '</b></td><td><select style="width: 260px;" name="type" >';
    echo '<option value="0">'.$Lang['quanbu'].'</option>';
    $type1_selected = $type2_selected = "";
    if(1 == $type){
        $type1_selected = "selected";
    }
    if(2 == $type){
        $type2_selected = "selected";
    }
    echo '<option value="1" '.$type1_selected.'>'.$Lang['index_type_1'].'</option>';
    echo '<option value="2" '.$type2_selected.'>'.$Lang['index_type_2'].'</option>';
    echo '</select></td></tr>';
   
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism-taobao_com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['index_title'] . '</th>';
    echo '<th>' . $Lang['index_tcshop_info'] . '</th>';
    echo '<th>' . $Lang['index_huodong_status'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($huodongList as $key => $value) {
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $tcshopUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfoTmp['user_id']); 
        $huodongList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_tchuodong/') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $shenhe_status = '';
        if($value['shenhe_status'] == 1){
            $shenhe_status = $Lang['indexshenhe_ok'];
        }else if($value['shenhe_status'] == 2){
            $shenhe_status = $Lang['indexshenhe_ing'];
        }else if($value['shenhe_status'] == 3){
            $shenhe_status = $Lang['indexshenhe_no'];
        }else{
            $shenhe_status = '-';
        }
        $status = '';
        if($value['status'] == 1){
            $status = $Lang['status_yes'];
        }else{
            $status = $Lang['status_no'];
        }
        $bm_start_time     = dgmdate($value['bm_start_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $bm_end_time       = dgmdate($value['bm_end_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $hd_start_time     = dgmdate($value['hd_start_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $hd_end_time       = dgmdate($value['hd_end_time'], 'Y-m-d H:i:s',$tomSysOffset);
        
        $siteInfo       = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $tcshopInfo     = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $tcshopUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfo['user_id']);
        
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td style="max-width:300px;">' . $value['title'].'(<font color="#fd0d0d">ID:'.$value['id'].'</font>)</td>';
        if($value['type'] == 1 ){
            echo '<td><div class="tc_content_box"><ul>';
            echo '<li><b><font color="#238206">'.$Lang['index_type_1'].'</font>' . '</b></li>';
            echo '<li><b>'.$Lang['index_user_id'].'&nbsp;:&nbsp;</b>' . $value['user_id'] . '</li>';
            echo '<li><b>'.$Lang['index_nickname'].'&nbsp;:&nbsp;</b>' . $userInfo['nickname'] . '</li>';
            echo '</ul></div></td>'; 
            
        }elseif($value['type'] == 2 ){
            echo '<td><div class="tc_content_box"><ul>';
            echo '<li><b><font color="#0894fb">'.$Lang['index_type_2'].'</font>' . '</b></li>';
            echo '<li><b>'.$Lang['index_tcshop_id'].'&nbsp;:&nbsp;</b>' . $tcshopInfoTmp['id'] . '</li>';
            echo '<li><b>'.$Lang['index_tcshop_name'].'&nbsp;:&nbsp;</b>' . $tcshopInfoTmp['name'] . '</li>';
            echo '<li><b>'.$Lang['huodong_tcshop_balance_user_id'].'&nbsp;:&nbsp;</b>' . $tcshopUserInfo['id'] . '</li>';
            echo '<li><b>'.$Lang['huodong_tcshop_balance_nickname'].'&nbsp;:&nbsp;</b>' . $tcshopUserInfo['nickname'] . '</li>';
            echo '</ul></div></td>'; 
        }
        echo '<td><div class="tc_content_box"><ul>';
        if($value['hehuoren_tg_open'] == 1 ){
            echo '<li><b>'.$Lang['index_hehuoren_tg'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['open'] . '</font></li>';
        }else{
            echo '<li><b>'.$Lang['index_hehuoren_tg'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['close'] . '</font></li>';
        }
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenheok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_ok']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenheno&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_no']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<li><b>'.$Lang['index_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['index_shenhe_status_1'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 2){
            echo '<li><b>'.$Lang['index_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['index_shenhe_status_2'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 3){
            echo '<li><b>'.$Lang['index_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['index_shenhe_status_3'] . '</font>'.$sheheBtnStr.'</li>';
        }
        $recommendBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=tuijian&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_is_recommend_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=notuijian&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_is_recommend_0']. '</a>)';
        if($value['is_recommend'] == 1 ){
            echo '<li><b>'.$Lang['index_is_recommend'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['index_is_recommend_1'] . '</font>'.$recommendBtnStr.'</li>';
        }else if($value['is_recommend'] == 0){
            echo '<li><b>'.$Lang['index_is_recommend'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['index_is_recommend_0'] . '</font>'.$recommendBtnStr.'</li>';
        }
        if($value['status'] == 1 ){
            $statusBtnStr = '(&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['status_no']. '</a>)';
        }else{
            $statusBtnStr = '(&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['status_yes']. '</a>)';
        }
        if($value['status'] == 1 ){
            echo '<li><b>'.$Lang['status_show'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['status_yes'] . '</font>'.$statusBtnStr.'</li>';
        }else{
            echo '<li><b>'.$Lang['status_show'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['status_no'] . '</font>'.$statusBtnStr.'</li>';
        }
        echo '<li><b>'.$Lang['index_bm_start_time'].'&nbsp;:&nbsp;</b>' . $bm_start_time . '</li>';
        echo '<li><b>'.$Lang['index_bm_end_time'].'&nbsp;:&nbsp;</b>' . $bm_end_time . '</li>';
        echo '<li><b>'.$Lang['index_hd_start_time'].'&nbsp;:&nbsp;</b>' . $hd_start_time . '</li>';
        echo '<li><b>'.$Lang['index_hd_end_time'].'&nbsp;:&nbsp;</b>' . $hd_end_time . '</li>';
        echo '</ul></div></td>';
        echo '<td style="line-height: 30px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&tmod=attr&tchuodong_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_bm_attr']. '</a></br>';
        echo '<a href="'.$modBaseUrl.'&tmod=bm&tchuodong_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_bmlist']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&act=photo&tchuodong_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_photo']. '</a></br>';
        echo '<a href="'.$adminBaseUrl.'&tmod=option&tchuodong_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_option_title']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        if($value['open_xubuy'] == 1 ){
            echo '<a href="'.$modBaseUrl.'&act=xubuy&tchuodong_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['xubuy_title']. '</a></br>';
        }
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id                 = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id                 = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $tcshop_id               = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $title                   = isset($_GET['title'])? addslashes($_GET['title']):'';
    $cate_id                 = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $yongjin_bili            = isset($_GET['yongjin_bili'])? floatval($_GET['yongjin_bili']):0;
    $xiangou_num             = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $bm_start_time           = isset($_GET['bm_start_time'])? addslashes($_GET['bm_start_time']):'';
    $bm_start_time           = strtotime($bm_start_time);
    $bm_end_time             = isset($_GET['bm_end_time'])? addslashes($_GET['bm_end_time']):'';
    $bm_end_time             = strtotime($bm_end_time);
    $hd_start_time           = isset($_GET['hd_start_time'])? addslashes($_GET['hd_start_time']):'';
    $hd_start_time           = strtotime($hd_start_time);
    $hd_end_time             = isset($_GET['hd_end_time'])? addslashes($_GET['hd_end_time']):'';
    $hd_end_time             = strtotime($hd_end_time);
    $address                 = isset($_GET['address'])? addslashes($_GET['address']):'';
    $longitude               = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $latitude                = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $open_vip                = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $open_xubuy              = isset($_GET['open_xubuy'])? intval($_GET['open_xubuy']):0;
    $hexiao_pwd              = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):0;
    $mp3_link                = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $admin_edit              = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $content                 = isset($_GET['content'])? addslashes($_GET['content']):'';
    $fenkai_bm               = isset($_GET['fenkai_bm'])? intval($_GET['fenkai_bm']):0;
    $must_shenhe             = isset($_GET['must_shenhe'])? intval($_GET['must_shenhe']):0;
    $show_stock_num          = isset($_GET['show_stock_num'])? intval($_GET['show_stock_num']):0;
    $hehuoren_tg_open        = isset($_GET['hehuoren_tg_open'])? intval($_GET['hehuoren_tg_open']):0;
    $chuji_fc_scale          = isset($_GET['chuji_fc_scale'])? floatval($_GET['chuji_fc_scale']):0;
    $zhongji_fc_scale        = isset($_GET['zhongji_fc_scale'])? floatval($_GET['zhongji_fc_scale']):0;
    $gaoji_fc_scale          = isset($_GET['gaoji_fc_scale'])? floatval($_GET['gaoji_fc_scale']):0;
    $share_title             = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc              = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $virtual_clicks          = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $haibao_type             = isset($_GET['haibao_type'])? intval($_GET['haibao_type']):1;
    $qrcode_location         = isset($_GET['qrcode_location'])? intval($_GET['qrcode_location']):1;
    $paixu                   = isset($_GET['paixu'])? addslashes($_GET['paixu']):'';
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $picurl = $toppic = $haibao_picurl = "";
    if($_GET['act'] == 'add'){
        $picurl              = tomuploadFile("picurl");
        $toppic              = tomuploadFile("toppic");
        $haibao_picurl       = tomuploadFile("haibao_picurl");
       
    }else if($_GET['act'] == 'edit'){
        $picurl            = tomuploadFile("picurl",$infoArr['picurl']);
        $toppic            = tomuploadFile("toppic",$infoArr['toppic']);
        $haibao_picurl     = tomuploadFile("haibao_picurl",$infoArr['haibao_picurl']);
        
    }
    
    $data['site_id']            = $site_id;
    if($infoArr['type'] == 1){
        $data['user_id']        = $user_id;
    }elseif($infoArr['type'] == 2){
        $data['user_id']        = $tcshopInfo['user_id'];
    }
    $data['tcshop_id']          = $tcshopInfo['id'];
    $data['title']              = $title;
    $data['cate_id']            = $cate_id;
    $data['yongjin_bili']       = $yongjin_bili;
    $data['picurl']             = $picurl;
    $data['toppic']             = $toppic;
    $data['xiangou_num']        = $xiangou_num;
    $data['bm_start_time']      = $bm_start_time;
    $data['bm_end_time']        = $bm_end_time;
    $data['hd_start_time']      = $hd_start_time;
    $data['hd_end_time']        = $hd_end_time;
    $data['address']            = $address;
    $data['longitude']          = $longitude;
    $data['latitude']           = $latitude;
    $data['open_vip']           = $open_vip;
    $data['open_xubuy']         = $open_xubuy;
    $data['hexiao_pwd']         = $hexiao_pwd;
    $data['mp3_link']           = $mp3_link;
    $data['admin_edit']         = $admin_edit;
    $data['content']            = $content;
    $data['fenkai_bm']          = $fenkai_bm;
    $data['must_shenhe']        = $must_shenhe;
    $data['show_stock_num']     = $show_stock_num;
    $data['hehuoren_tg_open']   = $hehuoren_tg_open;
    $data['chuji_fc_scale']     = $chuji_fc_scale;
    $data['zhongji_fc_scale']   = $zhongji_fc_scale;
    $data['gaoji_fc_scale']     = $gaoji_fc_scale;
    $data['share_title']        = $share_title;
    $data['share_desc']         = $share_desc;
    $data['virtual_clicks']     = $virtual_clicks;
    $data['haibao_type']        = $haibao_type;
    $data['haibao_picurl']      = $haibao_picurl;
    $data['qrcode_location']    = $qrcode_location;
    $data['paixu']              = $paixu;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$tcyikatongConfig;
    $options = array(
        'site_id'        => 1,
        'type'           => '',
        'user_id'        => '',
        'title'          => '',
        'cate_id'        => 0,
        'yongjin_bili'   => 0,
        'picurl'         => '',
        'toppic'         => '',
        'xiangou_num'    => 0,
        'bm_start_time'  => time(),
        'bm_end_time'    => time(),
        'hd_start_time'  => time(),
        'hd_end_time'    => time(),
        'address'        => '',
        'longitude'      => '',
        'latitude'       => '',
        'open_vip'       => 0,
        'open_xubuy'     => 0,
        'hexiao_pwd'     => '',
        'mp3_link'       => '',
        'admin_edit'     => '',
        'content'        => '',
        'fenkai_bm'      => 0,
        'must_shenhe'    => 0,
        'show_stock_num' => 0,
        'hehuoren_tg_open'  => 2,
        'chuji_fc_scale'    => 0,
        'zhongji_fc_scale'  => 0,
        'gaoji_fc_scale'    => 0,
        'share_title'       => '',
        'share_desc'        => '',
        'virtual_clicks'    => '',
        'haibao_type'       => 1,
        'haibao_picurl'     => '',
        'qrcode_location'   => 1,
        'paixu'             => '',
        
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['index_site_id'],'name'=>'site_id','value'=>$options['site_id'],'msg'=>$Lang['index_site_id_msg']),"input");
    if($options['type'] == 2){
        tomshowsetting(true,array('title'=>$Lang['index_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['index_tcshop_id_msg']),"input");
    }
    if($options['type'] == 1){
        tomshowsetting(true,array('title'=>$Lang['index_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['index_user_id_msg']),"input");
    }
    tomshowsetting(true,array('title'=>$Lang['index_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['index_title_msg']),"input");
    $cateList = C::t('#tom_tchuodong#tom_tchuodong_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,100);
    $cateStr = '<tr class="header"><th>'.$Lang['index_cate_id'].'</th><th></th></tr>';
    $cateStr.= '<tr><td width="300"><select style="width: 260px;" name="cate_id" id="cate_id">';
    foreach ($cateList as $key => $value){
        if($value['id'] == $options['cate_id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select></td><td></td></tr>';
    echo $cateStr;
    tomshowsetting(true,array('title'=>$Lang['index_yongjin_bili'],'name'=>'yongjin_bili','value'=>$options['yongjin_bili'],'msg'=>$Lang['index_yongjin_bili_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['index_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_toppic'],'name'=>'toppic','value'=>$options['toppic'],'msg'=>$Lang['index_toppic_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_xiangou_num'],'name'=>'xiangou_num','value'=>$options['xiangou_num'],'msg'=>$Lang['index_xiangou_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_bm_start_time'],'name'=>'bm_start_time','value'=>$options['bm_start_time'],'msg'=>$Lang['index_bm_start_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['index_bm_end_time'],'name'=>'bm_end_time','value'=>$options['bm_end_time'],'msg'=>$Lang['index_bm_end_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['index_hd_start_time'],'name'=>'hd_start_time','value'=>$options['hd_start_time'],'msg'=>$Lang['index_hd_start_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['index_hd_end_time'],'name'=>'hd_end_time','value'=>$options['hd_end_time'],'msg'=>$Lang['index_hd_end_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['index_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['index_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_latitude'],'name'=>'latitude','value'=>$options['latitude'],'msg'=>$Lang['index_latitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_longitude'],'name'=>'longitude','value'=>$options['longitude'],'msg'=>$Lang['index_longitude_msg']),"input");
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $open_vip_item = array(0=>$Lang['index_open_vip_0'],1=>$Lang['index_open_vip_1']);
        tomshowsetting(true,array('title'=>$Lang['index_open_vip'],'name'=>'open_vip','value'=>$options['open_vip'],'msg'=>$tcyikatongConfig['plugin_name'].$Lang['index_open_vip_msg'],'item'=>$open_vip_item),"radio");
    }
    $open_xubuy_item = array(0=>$Lang['index_open_xubuy_0'],1=>$Lang['index_open_xubuy_1']);
    tomshowsetting(true,array('title'=>$Lang['index_open_xubuy'],'name'=>'open_xubuy','value'=>$options['open_xubuy'],'msg'=>$Lang['index_open_xubuy_msg'],'item'=>$open_xubuy_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_hexiao_pwd'],'name'=>'hexiao_pwd','value'=>$options['hexiao_pwd'],'msg'=>$Lang['index_hexiao_pwd_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_mp3_link'],'name'=>'mp3_link','value'=>$options['mp3_link'],'msg'=>$Lang['index_mp3_link_msg']),"input");
    $index_fenkai_bm_item = array(0=>$Lang['index_fenkai_bm_0'],1=>$Lang['index_fenkai_bm_1']);
    tomshowsetting(true,array('title'=>$Lang['index_fenkai_bm'],'name'=>'fenkai_bm','value'=>$options['fenkai_bm'],'msg'=>$Lang['index_fenkai_bm_msg'],'item'=>$index_fenkai_bm_item),"radio");
    $index_must_shenhe_item = array(0=>$Lang['index_must_shenhe_0'],1=>$Lang['index_must_shenhe_1']);
    tomshowsetting(true,array('title'=>$Lang['index_must_shenhe'],'name'=>'must_shenhe','value'=>$options['must_shenhe'],'msg'=>$Lang['index_must_shenhe_msg'],'item'=>$index_must_shenhe_item),"radio");
    $index_show_stock_num_item = array(0=>$Lang['index_show_stock_num_0'],1=>$Lang['index_show_stock_num_1']);
    tomshowsetting(true,array('title'=>$Lang['index_show_stock_num'],'name'=>'show_stock_num','value'=>$options['show_stock_num'],'msg'=>$Lang['index_show_stock_num_msg'],'item'=>$index_show_stock_num_item),"radio");
    $open_hehuoren_tg_item = array(1=>$Lang['open'],2=>$Lang['close']);
    tomshowsetting(true,array('title'=>$Lang['index_hehuoren_tg_open'],'name'=>'hehuoren_tg_open','value'=>$options['hehuoren_tg_open'],'msg'=>$Lang['index_hehuoren_tg_open_msg'],'item'=>$open_hehuoren_tg_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_chuji_fc_scale'],'name'=>'chuji_fc_scale','value'=>$options['chuji_fc_scale'],'msg'=>'<font color="#fd0d0d">%</font>&nbsp;&nbsp;'.$Lang['index_chuji_fc_scale_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_zhongji_fc_scale'],'name'=>'zhongji_fc_scale','value'=>$options['zhongji_fc_scale'],'msg'=>'<font color="#fd0d0d">%</font>&nbsp;&nbsp;'.$Lang['index_zhongji_fc_scale_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_gaoji_fc_scale'],'name'=>'gaoji_fc_scale','value'=>$options['gaoji_fc_scale'],'msg'=>'<font color="#fd0d0d">%</font>&nbsp;&nbsp;'.$Lang['index_gaoji_fc_scale_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_share_title'],'name'=>'share_title','value'=>$options['share_title'],'msg'=>$Lang['index_share_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_share_desc'],'name'=>'share_desc','value'=>$options['share_desc'],'msg'=>$Lang['index_share_desc_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_virtual_clicks'],'name'=>'virtual_clicks','value'=>$options['virtual_clicks'],'msg'=>$Lang['index_virtual_clicks_msg']),"input");
    $haibao_type_item = array(1=>$Lang['index_haibao_type_1'],2=>$Lang['index_haibao_type_2']);
    tomshowsetting(true,array('title'=>$Lang['index_haibao_type'],'name'=>'haibao_type','value'=>$options['haibao_type'],'msg'=>$Lang['index_haibao_type_msg'],'item'=>$haibao_type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_haibao_picurl'],'name'=>'haibao_picurl','value'=>$options['haibao_picurl'],'msg'=>$Lang['index_haibao_picurl_msg']),"file");
    $qrcode_location_item = array(1=>$Lang['index_qrcode_location_1'],2=>$Lang['index_qrcode_location_2']);
    tomshowsetting(true,array('title'=>$Lang['index_qrcode_location'],'name'=>'qrcode_location','value'=>$options['qrcode_location'],'msg'=>$Lang['index_qrcode_location_msg'],'item'=>$qrcode_location_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['index_paixu_msg']),"input");
    $admin_edit_item = array(0=>$Lang['index_admin_edit_0'],1=>$Lang['index_admin_edit_1']);
    tomshowsetting(true,array('title'=>$Lang['index_admin_edit'],'name'=>'admin_edit','value'=>$options['admin_edit'],'msg'=>$Lang['index_admin_edit_msg'],'item'=>$admin_edit_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['index_content_msg']),"text");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['index_edit'],"",true);
    }else if($_GET['act'] == 'photo'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_photo'],"",true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}