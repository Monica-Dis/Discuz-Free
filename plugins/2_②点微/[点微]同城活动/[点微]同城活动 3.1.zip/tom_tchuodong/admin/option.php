<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=option&tchuodong_id='.$_GET['tchuodong_id'];
$modListUrl = $adminListUrl.'&tmod=option&tchuodong_id='.$_GET['tchuodong_id'];
$modFromUrl = $adminFromUrl.'&tmod=option&tchuodong_id='.$_GET['tchuodong_id'];

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tchuodong#tom_tchuodong_option')->insert($insertData);
        $option_id = C::t('#tom_tchuodong#tom_tchuodong_option')->insert_id();
        updateStocklog($option_id);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
        
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $optionInfo = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($optionInfo);
        C::t('#tom_tchuodong#tom_tchuodong_option')->update($optionInfo['id'],$updateData);
        updateStocklog($optionInfo['id']);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($optionInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'showoption'){
    
    DB::query("UPDATE ".DB::table('tom_tchuodong_option')." SET is_hidden=0 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    updateStocklog($_GET['id']);
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hideoption'){
    
    DB::query("UPDATE ".DB::table('tom_tchuodong_option')." SET is_hidden=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    updateStocklog($_GET['id']);
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $optionInfo = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($_GET['id']);
    
    C::t('#tom_tchuodong#tom_tchuodong_option')->delete_by_id($_GET['id']);
    
    $optionListTmp = C::t("#tom_tchuodong#tom_tchuodong_option")->fetch_all_list(" AND tchuodong_id = {$optionInfo['tchuodong_id']} AND is_hidden = 0 ", 'ORDER BY osort ASC, id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_min_price = $show_max_price  = $show_min_vip_price = $show_max_vip_price = 0;
        foreach($optionListTmp as $key => $value){
            if($show_min_price == 0){
                $show_min_price         = $value['price'];
                $show_min_vip_price     = $value['vip_price'];
            }else if($value['price'] > 0 && $value['price'] < $show_min_price){
                $show_min_price         = $value['price'];
                $show_min_vip_price     = $value['vip_price'];
            }
            if($show_max_price == 0){
                $show_max_price         = $value['price'];
                $show_max_vip_price     = $value['vip_price'];
            }else if($value['price'] > 0 && $value['price'] > $show_max_price){
                $show_max_price         = $value['price'];
                $show_max_vip_price     = $value['vip_price'];
            }
        }
        $updateData = array();
        $updateData['show_min_price']       = $show_min_price;
        $updateData['show_min_vip_price']   = $show_min_vip_price;
        $updateData['show_max_price']       = $show_max_price;
        $updateData['show_max_vip_price']   = $show_max_vip_price;
        $updateData['part1']                = TIMESTAMP;
        C::t("#tom_tchuodong#tom_tchuodong")->update($optionInfo['tchuodong_id'],$updateData);
        $huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($optionInfo['tchuodong_id']);
        update_huodong_status($huodongInfoTmp);
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['act'] == 'stock_log'){
    
    $huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($_GET['tchuodong_id']);

    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $huodongInfo['title'] .'&nbsp;&nbsp;&gt;&nbsp;&nbsp;'.$Lang['option_stock_log']. '</th></tr>';
    showtablefooter();/*Dism��taobao��com*/
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $stockLogList = C::t('#tom_tchuodong#tom_tchuodong_stock_log')->fetch_all_list(" AND tchuodong_id = {$huodongInfo['id']} AND is_option = 1 "," ORDER BY change_time DESC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['stocklog_is_admin'] . '</th>';
    echo '<th>' . $Lang['stocklog_is_option'] . '</th>';
    echo '<th>' . $Lang['stocklog_change_num'] . '</th>';
    echo '<th>' . $Lang['stocklog_beizu'] . '</th>';
    echo '<th>' . $Lang['stocklog_change_time'] . '</th>';
    echo '</tr>';

    $i = 1;
    foreach ($stockLogList as $key => $value){
        echo '<tr>';
        if($value['is_admin'] == 1){
            echo '<td>' . $Lang['stocklog_is_admin_1'] . '</td>';
        }else{
            echo '<td>' . $Lang['stocklog_is_admin_0'] . '</td>';
        }
        if($value['is_option'] == 1){
            echo '<td>' . $Lang['stocklog_is_option_1'] . '</td>';
        }else{
            echo '<td>' . $Lang['stocklog_is_option_0'] . '</td>';
        }
        echo '<td>' . $value['change_num'] . '</td>';
        echo '<th>' . $value['beizu'] . '</th>';
        echo '<td>' . dgmdate($value['change_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    $huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($_GET['tchuodong_id']);

    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $huodongInfo['title'] .'&nbsp;&nbsp;&gt;&nbsp;&nbsp;'.$Lang['option_list_title']. '</th></tr>';
    showtablefooter();/*Dism��taobao��com*/
    
    $page     = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start    = ($page-1)*$pagesize;	
    $optionList = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_all_list(" AND tchuodong_id = {$huodongInfo['id']} "," ORDER BY osort ASC,id ASC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['option_name'] . '</th>';
    echo '<th>' . $Lang['option_price'] . '</th>';
    echo '<th>' . $Lang['option_vip_price'] . '</th>';
    echo '<th>' . $Lang['option_stock_num'] . '</th>';
    echo '<th>' . $Lang['option_sale_num'] . '</th>';
    echo '<th>' . $Lang['option_is_hidden'] . '</th>';
    echo '<th>' . $Lang['paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($optionList as $key => $value) {
        $optionCount = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_count(" AND option_id={$value['id']}");
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['price'] . '</td>';
        echo '<td>' . $value['vip_price'] . '</td>';
        echo '<td><font color="#fd0d0d">' . $value['stock_num'] . '</font></td>';
        echo '<td><font color="#238206">' . $value['sale_num'] . '</font></td>';
        echo '<td><div class="tc_content_box"><ul>';
        $is_hiddenBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=hideoption&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['option_is_hidden_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=showoption&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['option_is_hidden_0']. '</a>)';
        if($value['is_hidden'] == 1 ){
            echo '<li><font color="#0a9409">' . $Lang['option_is_hidden_1'] . '</font>'.$is_hiddenBtnStr.'</li>';
        }else if($value['is_hidden'] == 0){
            echo '<li><font color="#f70404">' . $Lang['option_is_hidden_0'] . '</font>'.$is_hiddenBtnStr.'</li>';
        }
        echo '</ul></div></td>';
        echo '<td>' . $value['osort'] . '</td>';
        echo '<td>';
        if($optionCount > 0){
            echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['option_edit']. '</a>';
        }else{
            echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['option_edit']. '</a>&nbsp;|&nbsp;';
            echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        }
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $tchuodong_id       = isset($_GET['tchuodong_id'])? intval($_GET['tchuodong_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $price              = isset($_GET['price'])? floatval($_GET['price']):0.00;
    $vip_price          = isset($_GET['vip_price'])? floatval($_GET['vip_price']):0.00;
    $stock_num          = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
    $is_hidden          = isset($_GET['is_hidden'])? intval($_GET['is_hidden']):0;
    $osort              = isset($_GET['osort'])? intval($_GET['osort']):10;

    $data['tchuodong_id']   = $tchuodong_id;
    $data['name']           = $name;
    $data['price']          = $price;
    $data['vip_price']      = $vip_price;
    $data['stock_num']      = $stock_num;
    $data['is_hidden']      = $is_hidden;
    $data['osort']          = $osort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'              => '',
        'price'             => '',
        'vip_price'         => '',
        'stock_num'         => '',
        'is_hidden'         => '',
        'osort'             => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['option_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['option_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_price'],'name'=>'price','value'=>$options['price'],'msg'=>$Lang['option_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_vip_price'],'name'=>'vip_price','value'=>$options['vip_price'],'msg'=>$Lang['option_vip_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_stock_num'],'name'=>'stock_num','value'=>$options['stock_num'],'msg'=>$Lang['option_stock_num_msg']),"input");
    $is_hidden_item = array(0=>$Lang['option_is_hidden_0'],1=>$Lang['option_is_hidden_1']);
    tomshowsetting(true,array('title'=>$Lang['option_is_hidden'],'name'=>'is_hidden','value'=>$options['is_hidden'],'msg'=>$Lang['option_is_hidden_msg'],'item'=>$is_hidden_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['paixu'],'name'=>'osort','value'=>$options['osort'],'msg'=>$Lang['option_osort_msg']),"input");
    
    return;
}

function updateStocklog($option_id){
    global $Lang;
    $optionInfo = C::t("#tom_tchuodong#tom_tchuodong_option")->fetch_by_id($option_id);
    
    $beizu = 'ID:&nbsp;<font color="#0a9409">'.$option_id.'</font>&nbsp;'.$Lang['option_name'].'&nbsp;<font color="#0a9409">'.$optionInfo['name'].'</font>&nbsp;'.$Lang['option_stock_num'].'&nbsp;<font color="#fd0d0d">'.$optionInfo['stock_num'].'</font>&nbsp;'.$Lang['option_price'].'&nbsp;<font color="#fd0d0d">'.$optionInfo['price'].'</font>&nbsp;'.$Lang['option_vip_price'].'&nbsp;<font color="#fd0d0d">'.$optionInfo['vip_price'].'</font><br/>';
    
    $insertData = array();
    $insertData['is_admin']       = 1;
    $insertData['is_option']      = 1;
    $insertData['tchuodong_id']   = $optionInfo['tchuodong_id'];
    $insertData['beizu']          = $beizu;
    $insertData['change_num']     = $optionInfo['stock_num'];
    $insertData['change_time']    = TIMESTAMP;
    C::t("#tom_tchuodong#tom_tchuodong_stock_log")->insert($insertData);
    
    $optionListTmp = C::t("#tom_tchuodong#tom_tchuodong_option")->fetch_all_list(" AND tchuodong_id = {$optionInfo['tchuodong_id']} AND is_hidden = 0", 'ORDER BY osort ASC,id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_min_price = $show_max_price  = $show_min_vip_price = $show_max_vip_price = 0;
        foreach($optionListTmp as $key => $value){
            if($show_min_price == 0){
                $show_min_price         = $value['price'];
                $show_min_vip_price     = $value['vip_price'];
            }else if($value['price'] > 0 && $value['price'] < $show_min_price){
                $show_min_price         = $value['price'];
                $show_min_vip_price     = $value['vip_price'];
            }
            if($show_max_price == 0){
                $show_max_price         = $value['price'];
                $show_max_vip_price     = $value['vip_price'];
            }else if($value['price'] > 0 && $value['price'] > $show_max_price){
                $show_max_price         = $value['price'];
                $show_max_vip_price     = $value['vip_price'];
            }
        }
        $updateData = array();
        $updateData['show_min_price']       = $show_min_price;
        $updateData['show_min_vip_price']   = $show_min_vip_price;
        $updateData['show_max_price']       = $show_max_price;
        $updateData['show_max_vip_price']   = $show_max_vip_price;
        $updateData['part1']                = TIMESTAMP;
        C::t("#tom_tchuodong#tom_tchuodong")->update($optionInfo['tchuodong_id'],$updateData);
        $huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($optionInfo['tchuodong_id']);
        update_huodong_status($huodongInfoTmp);
    }
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['option_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['option_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['option_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['option_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['option_edit'],"",true);
    }else if($_GET['act'] == 'stock_log'){
        tomshownavli($Lang['option_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['option_stock_log'],$modBaseUrl."&act=stock_log",true);
    }else{
        tomshownavli($Lang['option_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['option_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['option_stock_log'],$modBaseUrl."&act=stock_log",false);
    }
    tomshownavfooter();
}