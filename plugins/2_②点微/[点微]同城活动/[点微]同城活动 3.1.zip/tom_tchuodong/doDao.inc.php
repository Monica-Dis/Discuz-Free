<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tomSysOffset = getglobal('setting/timeoffset');

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/config/config.utf8.php';
}

$tchuodong_id       = isset($_GET['tchuodong_id'])? intval($_GET['tchuodong_id']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$bm_status          = isset($_GET['bm_status'])? intval($_GET['bm_status']):0;
$pagesize           = 1000;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$start              = ($page - 1)*$pagesize;	
$where = "";

if(!empty($tchuodong_id)){
    $where.= " AND tchuodong_id= {$tchuodong_id}";
}
if(!empty($shenhe_status)){
    $where.= " AND shenhe_status= {$shenhe_status}";
}
if(!empty($bm_status)){
    $where.= " AND bm_status= {$bm_status}";
}

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $bmListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_all_list($where,"ORDER BY add_time DESC,id DESC",$start,$pagesize);
    $bmList = $attrNamelist = $attrpicNamelist = array();
    foreach ($bmListTmp as $k => $v) {
        
        $huodongInfo    = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($v['tchuodong_id']);
        $optionInfo     = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($v['option_id']);
        
        $bmList[$k]['id']              = $v['id'];
        $bmList[$k]['tchuodong_id']    = $v['tchuodong_id'];
        $bmList[$k]['tchuodong_title'] = $huodongInfo['title'];
        $bmList[$k]['option_name']     = $optionInfo['name'];
        $bmList[$k]['user_id']         = $v['user_id'];
        $bmList[$k]['xm']              = $v['xm'];
        $bmList[$k]['tel']             = $v['tel'];
        $bmList[$k]['shenhe_status']   = $bmshenheStatusArray[$v['shenhe_status']];
        $bmList[$k]['bm_status']       = $bmStatusArray[$v['bm_status']];
        $bmList[$k]['add_time']        = dgmdate($v['add_time'],"Y-m-d H:i",$tomSysOffset);
        
        $attrListTmp = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list("AND tchuodong_id = {$v['tchuodong_id']} AND type != 6","ORDER BY paixu ASC,id DESC");
        $attrList = array();
        if(is_array($attrListTmp) && !empty($attrListTmp)){
            foreach ($attrListTmp as $key => $value){
                $attrList[$key] = $value;
                $attrNamelist[$key] = $value['name'];
                $attrbmListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_list("AND bm_id = {$v['id']} AND type_id != 6 AND attr_id = {$value['id']}","ORDER BY paixu ASC,id DESC");
                $attrbmList = array();
                if(is_array($attrbmListTmp) && !empty($attrbmListTmp)){
                    foreach($attrbmListTmp as $kk => $vv){
                        $attrbmList[] = $vv['value'];
                    }
                }
                $attrList[$key]['attrbmStr']      = implode('|',$attrbmList);
            }
        } 
        
        $attrpicListTmp = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list("AND tchuodong_id = {$v['tchuodong_id']} AND type = 6","ORDER BY paixu ASC,id DESC");
        $attrpicList = array();
        if(is_array($attrpicListTmp) && !empty($attrpicListTmp)){
            foreach ($attrpicListTmp as $key => $value){
                $attrpicList[$key] = $value;
                $attrpicNamelist[$key] = $value['name'];
                $attrbmpicListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_list("AND bm_id = {$v['id']} AND type_id = 6 AND attr_id = {$value['id']}","ORDER BY paixu ASC,id DESC");
                $attrbmpicList = array();
                if(is_array($attrbmpicListTmp) && !empty($attrbmpicListTmp)){
                    foreach($attrbmpicListTmp as $kk => $vv){
                        if(!preg_match('/^http/', $vv['picurl_value'])){
                            if(strpos($vv['picurl_value'], 'source/plugin/') === false){
                                $attrbmpicList[] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl_value'];
                            }else{
                                $attrbmpicList[] = $_G['siteurl'].$vv['picurl_value'];
                            }
                        }else{
                            $attrbmpicList[] = $vv['picurl_value'];
                        }
                    }
                }
                $attrpicList[$key]['attrbmpicStr']   = implode('|',$attrbmpicList);
            }
        } 
       
        $bmList[$k]['attrList']        = $attrList;
        $bmList[$k]['attrpicList']     = $attrpicList;
    }
    
    $bm_id           = lang('plugin/tom_tchuodong','bm_id');
    $tchuodong_id    = lang('plugin/tom_tchuodong','tchuodong_id');
    $index_title     = lang('plugin/tom_tchuodong','index_title');
    $bm_option_name  = lang('plugin/tom_tchuodong','bm_option_name');
    $user_id         = lang('plugin/tom_tchuodong','user_id');
    $xm              = lang('plugin/tom_tchuodong','bm_xm');
    $tel             = lang('plugin/tom_tchuodong','bm_tel');
    $shenhe_status   = lang('plugin/tom_tchuodong','bm_shenhe_status');
    $bm_status       = lang('plugin/tom_tchuodong','bm_status');
    $add_time        = lang('plugin/tom_tchuodong','bm_add_time');
    $fenhao          = lang('plugin/tom_tchuodong','fenghao');

    $listData[] = array($bm_id,$tchuodong_id,$index_title,$bm_option_name,$user_id,$xm,$tel); 
    foreach ($attrNamelist as $v){
        array_push($listData[0],$v);
    }
    foreach ($attrpicNamelist as $v){
        array_push($listData[0],$v);
    }
    array_push($listData[0],$shenhe_status,$bm_status,$add_time);

    foreach ($bmList as $v){
        $lineData = array();
        $lineData[] = $v['id'];
        $lineData[] = $v['tchuodong_id'];
        $lineData[] = $v['tchuodong_title'];
        $lineData[] = $v['option_name'];
        $lineData[] = $v['user_id'];
        $lineData[] = $v['xm'];
        $lineData[] = "'".$v['tel'];
        
        foreach($v['attrList'] as $av){
            if($av['attrbmStr']){
                $lineData[] = "'".$av['attrbmStr'];
            }else{
                $lineData[] = '--';
            }
        }
        
        foreach($v['attrpicList'] as $av){
            if($av['attrbmpicStr']){
                $lineData[] = $av['attrbmpicStr'];
            }else{
                $lineData[] = '--';
            }
        }
        $lineData[] = $v['shenhe_status'];
        $lineData[] = $v['bm_status'];
        $lineData[] = $v['add_time'];
        $listData[] = $lineData;
        
    }
    
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=exportHuodongbmlist.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}