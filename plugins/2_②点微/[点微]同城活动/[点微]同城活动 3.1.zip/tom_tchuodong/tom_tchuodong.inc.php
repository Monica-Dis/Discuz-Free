<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tchuodongConfig = $_G['cache']['plugin']['tom_tchuodong'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = '20190821';
if (!file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/tom_tongcheng.inc.php')) {
	echo ' no install https://dism.taobao.com/?@tom_tongcheng.plugin';
	exit(0);
}
if (CHARSET == 'gbk') {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/config/config.gbk.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/config/config.utf8.php';
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tchuodong/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/function.html.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tchuodongConfig['wx_share_title'];
$shareDesc = $tchuodongConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=index';
$shareLogo = $tchuodongConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$tcadminConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcadmin/tom_tcadmin.inc.php')) {
	$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')) {
	$tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
	if ($tcyikatongConfig['open_tcyikatong'] == 1) {
		$__ShowTcyikatong = 1;
	}
}
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')) {
	$tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
	if ($tcrenzhengConfig['open_tcrenzheng'] == 1) {
		$__ShowTcrenzheng = 1;
	}
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$tcyikatongStatus = 0;
if ($__ShowTcyikatong == 1 && $__UserInfo['id'] > 0) {
	$cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($__UserInfo['id']);
	if (is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1) {
		$tcyikatongStatus = 1;
	}
}
if ($_GET['mod'] == 'index') {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/site_ibs.php';
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$huodong_status = intval($_GET['huodong_status']) > 0 ? intval($_GET['huodong_status']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$cateInfo = array();
	if ($cate_id > 0) {
		$cateInfo = C::t('#tom_tchuodong#tom_tchuodong_cate')->fetch_by_id($cate_id);
	}
	$focuspicListTmp = C::t('#tom_tchuodong#tom_tchuodong_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tchuodong#tom_tchuodong_focuspic')->fetch_all_list(' AND site_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	foreach ($focuspicListTmp as $key => $value) {
		$focuspicList[$key] = $value;
		if (!preg_match('/^http/', $value['picurl'])) {
			if (strpos($value['picurl'], 'source/plugin/tom_tchuodong/') === false) {
				$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
			} else {
				$picurl = $value['picurl'];
			}
		} else {
			$picurl = $value['picurl'];
		}
		$focuspicList[$key]['picurl'] = $picurl;
		$focuspicList[$key]['link'] = str_replace('{site}', $site_id, $focuspicList[$key]['link']);
	}
	$cateListTmp = C::t('#tom_tchuodong#tom_tchuodong_cate')->fetch_all_list(' ', ' ORDER BY csort ASC,id DESC ', 0, 50);
	$cateList = array();
	$i = 1;
	$cateCount = 0;
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tchuodong/') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$cateList[$key]['picurl'] = $picurl;
			$cateList[$key]['i'] = $i;
			$cateList[$key]['link'] = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=index&cate_id=' . $value['id'];
			$i = $i + 1;
			$cateCount = $cateCount + 1;
		}
	}
	$shareUrl = $_G['siteurl'] . 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=index&cate_id=' . $cate_id;
	$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tchuodong:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
	$searchUrl = 'plugin.php?id=tom_tchuodong:ajax&site=' . $site_id . '&act=get_huodong_search_url';
	$ajaxLoadListUrl = 'plugin.php?id=tom_tchuodong:ajax&site=' . $site_id . '&act=list&cate_id=' . $cate_id . '&huodong_status=' . $huodong_status . '&keyword=' . $keyword . '&formhash=' . $formhash;
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tchuodong/images/index.js';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tchuodong:index');
	echo '<script src="source/plugin/tom_tchuodong/images/index.js"></script>';
} elseif ($_GET['mod'] == 'details') {
	$tchuodong_id = isset($_GET['tchuodong_id']) ? intval($_GET['tchuodong_id']) : 0;
	$tj_hehuoren_id = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
	if ($tj_hehuoren_id > 0) {
		$lifeTime = 86400;
		dsetcookie('tom_tchuodong_tj_hehuoren_id', $tj_hehuoren_id, $lifeTime);
	} else {
		$cookie_tj_hehuoren_id = getcookie('tom_tchuodong_tj_hehuoren_id');
		if ($cookie_tj_hehuoren_id > 0) {
			$tj_hehuoren_id = $cookie_tj_hehuoren_id;
		}
	}
	$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
	if ($huodongInfo['id'] <= 0) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	if (!preg_match('/^http/', $huodongInfo['picurl'])) {
		if (strpos($huodongInfo['picurl'], 'source/plugin/tom_tchuodong/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $huodongInfo['picurl'];
		} else {
			$picurl = $_G['siteurl'] . $huodongInfo['picurl'];
		}
	} else {
		$picurl = $huodongInfo['picurl'];
	}
	if (!preg_match('/^http/', $huodongInfo['toppic'])) {
		if (strpos($huodongInfo['toppic'], 'source/plugin/tom_tchuodong/') === false) {
			$toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $huodongInfo['toppic'];
		} else {
			$toppic = $_G['siteurl'] . $huodongInfo['toppic'];
		}
	} else {
		$toppic = $huodongInfo['toppic'];
	}
	if (!preg_match('/^http/', $huodongInfo['haibao_picurl'])) {
		if (strpos($huodongInfo['haibao_picurl'], 'source/plugin/tom_tchuodong/') === false) {
			$haibao_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $huodongInfo['haibao_picurl'];
		} else {
			$haibao_picurl = $huodongInfo['haibao_picurl'];
		}
	} else {
		$haibao_picurl = $huodongInfo['haibao_picurl'];
	}
	if ($huodongInfo['show_min_price'] >= 100) {
		$show_min_price = intval($huodongInfo['show_min_price']);
	} else {
		$show_min_price = $huodongInfo['show_min_price'];
	}
	if ($huodongInfo['show_min_vip_price'] >= 100) {
		$show_min_vip_price = intval($huodongInfo['show_min_vip_price']);
	} else {
		$show_min_vip_price = $huodongInfo['show_min_vip_price'];
	}
	if ($huodongInfo['show_max_price'] >= 100) {
		$show_max_price = intval($huodongInfo['show_max_price']);
	} else {
		$show_max_price = $huodongInfo['show_max_price'];
	}
	if ($huodongInfo['show_max_vip_price'] >= 100) {
		$show_max_vip_price = intval($huodongInfo['show_max_vip_price']);
	} else {
		$show_max_vip_price = $huodongInfo['show_max_vip_price'];
	}
	$content = stripslashes($huodongInfo['content']);
	$bm_start_time = dgmdate($huodongInfo['bm_start_time'], 'Y.m.d H:i', $tomSysOffset);
	$bm_end_time = dgmdate($huodongInfo['bm_end_time'], 'Y.m.d H:i', $tomSysOffset);
	$hd_start_time = dgmdate($huodongInfo['hd_start_time'], 'Y.m.d H:i', $tomSysOffset);
	$hd_end_time = dgmdate($huodongInfo['hd_end_time'], 'Y.m.d H:i', $tomSysOffset);
	$huodongInfo['clicks'] = $huodongInfo['clicks'] + $huodongInfo['virtual_clicks'];
	$huodongInfo['huodong_status'] = update_huodong_status($huodongInfo);
	$tcshopInfo = array();
	if ($huodongInfo['type'] == 2) {
		$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($huodongInfo['tcshop_id']);
		if (!preg_match('/^http/', $tcshopInfo['kefu_qrcode'])) {
			if (strpos($tcshopInfo['kefu_qrcode'], 'source/plugin/tom_tcshop/') === false) {
				$kefu_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['kefu_qrcode'];
			} else {
				$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
			}
		} else {
			$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
		}
	}
	$optionListTmp = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_all_list(' AND tchuodong_id=' . $tchuodong_id . ' AND is_hidden = 0', ' ORDER BY osort ASC,id DESC ', 0, 50);
	$optionCount = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_all_count(' AND tchuodong_id=' . $tchuodong_id . ' AND is_hidden = 0');
	$optionStockNumCount = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_all_sun_stock_num(' AND tchuodong_id=' . $tchuodong_id . ' AND is_hidden = 0');
	$optionList = array();
	if (is_array($optionListTmp) && !empty($optionListTmp)) {
		foreach ($optionListTmp as $key => $value) {
			$optionList[$key] = $value;
			$syStockTmp = $value['stock_num'] - $value['sale_num'];
			if ($syStockTmp < 0) {
				$syStockTmp = 0;
			}
			$optionList[$key]['sy_stock'] = $syStockTmp;
		}
	}
	$orderListTmp = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_list(' AND tchuodong_id = ' . $tchuodong_id . ' AND order_status IN(2,3) ', 'ORDER BY id DESC', 0, 10);
	$orderList = array();
	if ($huodongInfo['open_xubuy'] == 1) {
		if (is_array($orderListTmp) && !empty($orderListTmp)) {
			foreach ($orderListTmp as $key => $value) {
				$xubuyInfoTmp = C::t('#tom_tchuodong#tom_tchuodong_xubuy')->fetch_by_order_id($value['id']);
				if (!$xubuyInfoTmp || $xubuyInfoTmp['id'] <= 0) {
					$insertData = array();
					$insertData['tchuodong_id'] = $value['tchuodong_id'];
					$insertData['type_id'] = 1;
					$insertData['order_id'] = $value['id'];
					$insertData['user_id'] = $value['user_id'];
					$insertData['bm_num'] = $value['number'];
					$insertData['order_time'] = $value['order_time'];
					C::t('#tom_tchuodong#tom_tchuodong_xubuy')->insert($insertData);
				}
			}
		}
		$orderListTmp = array();
		$orderListTmp = C::t('#tom_tchuodong#tom_tchuodong_xubuy')->fetch_all_list(' AND tchuodong_id=' . $tchuodong_id . ' ', ' ORDER BY order_time DESC,id DESC ', 0, 10);
	}
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			$orderList[$key] = $value;
			$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$orderList[$key]['userInfo'] = $userInfoTmp;
		}
	}
	$bmCount = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_sun_bm_num(' AND tchuodong_id = ' . $tchuodong_id . ' AND order_status IN(2,3)');
	if ($huodongInfo['open_xubuy'] == 1) {
		$xubuyListCount = C::t('#tom_tchuodong#tom_tchuodong_xubuy')->fetch_all_count(' AND tchuodong_id=' . $tchuodong_id . ' AND type_id=2 ');
		$bmCount = $bmCount + $xubuyListCount;
	}
	$noPayOrderListTmp = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_list(' AND tchuodong_id=' . $tchuodong_id . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 6);
	if (is_array($noPayOrderListTmp) && !empty($noPayOrderListTmp)) {
		foreach ($noPayOrderListTmp as $key => $value) {
			$noPayOrderListTmp[$key] = $value;
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > $tchuodongConfig['bm_nopay_overtime'] * 3600) {
					DB::query('UPDATE ' . DB::table('tom_tchuodong_order') . (' SET order_status=4 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
					$bmIds = str_replace('|', ',', $value['bm_ids']);
					DB::query('UPDATE ' . DB::table('tom_tchuodong_bm') . (' SET bm_status=4 WHERE id IN (' . $bmIds . ') '), 'UNBUFFERED');
					if ($value['option_id'] > 0) {
						DB::query('UPDATE ' . DB::table('tom_tchuodong_option') . (' SET sale_num=sale_num - ' . $value['number'] . ' WHERE id=\'' . $value['option_id'] . '\' '), 'UNBUFFERED');
					}
				}
			}
		}
	}
	$photoListTmp = C::t('#tom_tchuodong#tom_tchuodong_photo')->fetch_all_list(' AND tchuodong_id=' . $tchuodong_id . ' ', 'ORDER BY id ASC', 0, 50);
	$photoList = array();
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tchuodong/') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$photoList[$key] = $value;
			$photoList[$key]['picurl'] = $picurlTmp;
		}
	}
	$xiangouStatus = 0;
	$bm_xiangou_num = $huodongInfo['xiangou_num'];
	if ($__UserInfo['id'] > 0 && $huodongInfo['xiangou_num'] > 0) {
		$myHaveOrderCount = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_sun_bm_num(' AND tchuodong_id=' . $tchuodong_id . ' AND user_id=' . $__UserInfo['id'] . ' AND order_status IN(1,2,3) ');
		$bm_xiangou_num = $huodongInfo['xiangou_num'] - $myHaveOrderCount;
		if ($myHaveOrderCount >= $huodongInfo['xiangou_num']) {
			$xiangouStatus = 1;
		}
	}
	$tcyikatongPayStatus = 0;
	if ($tcyikatongStatus == 1 && $huodongInfo['open_vip'] == 1) {
		$tcyikatongPayStatus = 1;
	}
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tchuodongConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$baiduMapToName = $huodongInfo['title'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapToAddress = $huodongInfo['address'];
	$baiduMapToAddress = diconv($baiduMapToAddress, CHARSET, 'utf-8');
	$baiduMapToAddress = urlencode($baiduMapToAddress);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $huodongInfo['latitude'] . ',' . $huodongInfo['longitude'] . '&title=' . $baiduMapToName . '&content=' . $baiduMapToAddress . '&output=html';
	$showTgButton = 0;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		$dengjiInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
		$dengjiInfo = array();
		if (is_array($dengjiInfoTmp) && !empty($dengjiInfoTmp)) {
			$dengjiInfo = $dengjiInfoTmp;
		}
		if ($huodongInfo['site_id'] > 1) {
			$siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($huodongInfo['site_id']);
			if ($siteInfoTmp['hehuoren_fc_open'] == 1) {
				$showTgButton = 1;
			}
		} else {
			if ($huodongInfo['site_id'] == 1) {
				$showTgButton = 1;
			}
		}
		$needPrice = 0;
		$yongjin_bili = $tchuodongConfig['yongjin_bili'];
		if ($huodongInfo['yongjin_bili'] > 0) {
			$yongjin_bili = $huodongInfo['yongjin_bili'];
		}
		$pay_price = $huodongInfo['show_min_price'];
		$pt_money = $pay_price;
		$pt_money = $pay_price * ($yongjin_bili / 100);
		$pt_money = number_format($pt_money, 2, '.', '');
		if ($dengjiInfo['level'] == 1) {
			$needPrice = $pt_money * ($huodongInfo['chuji_fc_scale'] / 100);
		} elseif ($dengjiInfo['level'] == 2) {
			$needPrice = $pt_money * ($huodongInfo['zhongji_fc_scale'] / 100);
		} elseif ($dengjiInfo['level'] == 3) {
			$needPrice = $pt_money * ($huodongInfo['gaoji_fc_scale'] / 100);
		}
		$needPrice = number_format($needPrice, 2, '.', '');
		$tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
		if ($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1) {
			$tctchehuorenParentInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
			$tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
		}
		if (!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1) {
			$tctchehuorenParent_fc_money = $needPrice * ($tctchehuorenParentDengji['tuijian_fc_scale'] / 100);
			$tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money, 2, '.', '');
			if ($tchehuorenConfig['subordinate_moneytype'] != 1) {
				$needPrice = $needPrice - $tctchehuorenParent_fc_money;
			}
		}
		$tchehuorenUrl = $_G['siteurl'] . ('plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=details&tchuodong_id=' . $tchuodong_id . '&tj_hehuoren_id=' . $tchehuorenInfo['id']);
	}
	if ($huodongInfo['hehuoren_tg_open'] == 1 && $showTgButton == 1) {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=details&tchuodong_id=' . $tchuodong_id . '&tj_hehuoren_id=' . $tchehuorenInfo['id']);
		$huodongUrl = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=buy&tchuodong_id=' . $tchuodong_id . '&tj_hehuoren_id=' . $tj_hehuoren_id;
	} else {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=details&tchuodong_id=') . $tchuodong_id;
		$huodongUrl = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=buy&tchuodong_id=' . $tchuodong_id;
	}
	$shareTitle = $huodongInfo['title'] . '-' . $tchuodongConfig['plugin_name'];
	if (!empty($huodongInfo['share_title'])) {
		$shareTitle = $huodongInfo['share_title'];
	}
	if (!empty($huodongInfo['share_desc'])) {
		$shareDesc = $huodongInfo['share_desc'];
	}
	$shareLogo = $picurl;
	$haibaoShareUrl = $shareUrl;
	$haibaoQrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($shareUrl);
	$haibaoNickname = cutstr($__UserInfo['nickname'], 12, '...');
	if ($huodongInfo['type'] == 1) {
		$kefuSmsUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&&to_user_id=' . $huodongInfo['user_id'] . '&formhash=' . FORMHASH;
	} elseif ($huodongInfo['type'] == 2) {
		$kefuSmsUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&&to_user_id=' . $tcshopInfo['user_id'] . '&formhash=' . FORMHASH;
	}
	$ajaxClicksUrl = $_G['siteurl'] . ('plugin.php?id=tom_tchuodong:ajax&site=' . $site_id . '&act=clicks&tchuodong_id=' . $tchuodong_id . '&formhash=') . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tchuodong:details');
} elseif ($_GET['mod'] == 'bmlist') {
	$tchuodong_id = isset($_GET['tchuodong_id']) ? intval($_GET['tchuodong_id']) : 0;
	$ajaxLoadBmListUrl = 'plugin.php?id=tom_tchuodong:ajax&site=' . $site_id . '&act=bmlist&tchuodong_id=' . $tchuodong_id . '&formhash=' . $formhash;
	dsetcookie('tom_tchuodong_virtual_bm_load_status', 2, 1800);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tchuodong:bmlist');
} elseif ($_GET['mod'] == 'buy') {
	$tchuodong_id = isset($_GET['tchuodong_id']) ? intval($_GET['tchuodong_id']) : 0;
	$option_id = isset($_GET['option_id']) ? intval($_GET['option_id']) : 0;
	$tj_hehuoren_id = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
	$number = isset($_GET['number']) ? intval($_GET['number']) : 0;
	$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
	if (!preg_match('/^http/', $huodongInfo['picurl'])) {
		if (strpos($huodongInfo['picurl'], 'source/plugin/tom_tchuodong/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $huodongInfo['picurl'];
		} else {
			$picurl = $_G['siteurl'] . $huodongInfo['picurl'];
		}
	} else {
		$picurl = $huodongInfo['picurl'];
	}
	$huodongInfo['huodong_status'] = update_huodong_status($huodongInfo);
	$optionInfo = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($option_id);
	if ($huodongInfo['fenkai_bm'] == 1) {
		$bmnumber = $number;
	} else {
		$bmnumber = 1;
	}
	$bmnumArr = array();
	for ($i = 1; $i <= $bmnumber; $i++) {
		$bmnumArr[] = $i;
	}
	$tcyikatongPayStatus = 0;
	if ($tcyikatongStatus == 1 && $huodongInfo['open_vip'] == 1) {
		$tcyikatongPayStatus = 1;
	}
	$price = $optionInfo['price'];
	$vip_price = $optionInfo['vip_price'];
	$pay_price = 0;
	if ($tcyikatongPayStatus == 1) {
		$pay_price = $vip_price * $number;
	} else {
		$pay_price = $price * $number;
	}
	$attrListTmp = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list(' AND tchuodong_id=' . $tchuodong_id . ' AND type != 6 AND is_hidden = 0 ', ' ORDER BY paixu ASC,id DESC ', 0, 50);
	$attrList = array();
	if (is_array($attrListTmp) && !empty($attrListTmp)) {
		foreach ($attrListTmp as $key => $value) {
			$attrList[$key] = $value;
			if ($value['type'] == 2 || $value['type'] == 4) {
				$value_listStr = str_replace("\r\n", '{n}', $value['value']);
				$value_listStr = str_replace("\n", '{n}', $value_listStr);
				$attrList[$key]['list'] = explode('{n}', $value_listStr);
			}
		}
	}
	$attrpicListTmp = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list(' AND tchuodong_id=' . $tchuodong_id . ' AND type = 6 AND is_hidden = 0', ' ORDER BY paixu ASC,id DESC ', 0, 50);
	$attrpicList = array();
	if (is_array($attrpicListTmp) && !empty($attrpicListTmp)) {
		foreach ($attrpicListTmp as $key => $value) {
			$attrpicList[$key] = $value;
		}
	}
	$orderListTmp = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_list(' AND tchuodong_id=' . $tchuodong_id . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 10);
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			$orderListTmp[$key] = $value;
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > $tchuodongConfig['bm_nopay_overtime'] * 3600) {
					DB::query('UPDATE ' . DB::table('tom_tchuodong_order') . (' SET order_status=4 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
					$bmIds = str_replace('|', ',', $value['bm_ids']);
					DB::query('UPDATE ' . DB::table('tom_tchuodong_bm') . (' SET bm_status=4 WHERE id IN (' . $bmIds . ') '), 'UNBUFFERED');
					if ($value['option_id'] > 0) {
						DB::query('UPDATE ' . DB::table('tom_tchuodong_option') . (' SET sale_num=sale_num - ' . $value['number'] . ' WHERE id=\'' . $value['option_id'] . '\' '), 'UNBUFFERED');
					}
				}
			}
		}
	}
	$noPayOrderListTmp = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_list(' AND tchuodong_id=' . $tchuodong_id . ' AND user_id=' . $__UserInfo['id'] . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 10);
	$isHaveNoPay = 0;
	if (is_array($noPayOrderListTmp) && !empty($noPayOrderListTmp)) {
		foreach ($noPayOrderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > $tchuodongConfig['bm_nopay_overtime'] * 3600) {
					DB::query('UPDATE ' . DB::table('tom_tchuodong_order') . (' SET order_status=4 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
					$bmIds = str_replace('|', ',', $value['bm_ids']);
					DB::query('UPDATE ' . DB::table('tom_tchuodong_bm') . (' SET bm_status=4 WHERE id IN (' . $bmIds . ') '), 'UNBUFFERED');
					if ($value['option_id'] > 0) {
						DB::query('UPDATE ' . DB::table('tom_tchuodong_option') . (' SET sale_num=sale_num - ' . $value['number'] . ' WHERE id=\'' . $value['option_id'] . '\' '), 'UNBUFFERED');
					}
				} else {
					$isHaveNoPay = 1;
				}
			}
		}
	}
	$xiangouStatus = 0;
	$bm_xiangou_num = 0;
	if ($huodongInfo['xiangou_num'] > 0) {
		$myHaveOrderCount = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_sun_bm_num(' AND tchuodong_id=' . $tchuodong_id . ' AND user_id=' . $__UserInfo['id'] . ' AND order_status IN(1,2,3) ');
		$bm_xiangou_num = $huodongInfo['xiangou_num'] - $myHaveOrderCount;
		if ($myHaveOrderCount >= $huodongInfo['xiangou_num']) {
			$xiangouStatus = 1;
		}
	}
	$payUrl = 'plugin.php?id=tom_tchuodong:pay&site=' . $site_id . '&act=pay_price';
	$wxUploadUrl = 'plugin.php?id=tom_tchuodong:wxMediaDowmload&site=' . $site_id . '&act=photo&formhash=' . FORMHASH;
	$uploadUrl = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=upload&act=photo&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tchuodong:buy');
} elseif ($_GET['mod'] == 'myorder') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$whereStr = ' AND user_id=' . $__UserInfo['id'] . ' ';
	if ($type == 1) {
		$whereStr .= ' AND order_status=1 ';
	} elseif ($type == 2) {
		$whereStr .= ' AND order_status=2 ';
	} elseif ($type == 3) {
		$whereStr .= ' AND shenhe_status=2 ';
	} elseif ($type == 4) {
		$whereStr .= ' AND order_status=3 ';
	}
	$pagesize = 10;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_count($whereStr);
	$orderListTmp = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_list($whereStr, ' ORDER BY id DESC ', $start, $pagesize);
	$orderList = array();
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			$orderList[$key] = $value;
			$huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($value['tchuodong_id']);
			if ($huodongInfoTmp['id'] > 0) {
				if (!preg_match('/^http/', $huodongInfoTmp['picurl'])) {
					if (strpos($huodongInfoTmp['picurl'], 'source/plugin/') === false) {
						$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $huodongInfoTmp['picurl'];
					} else {
						$picurl = $huodongInfoTmp['picurl'];
					}
				} else {
					$picurl = $huodongInfoTmp['picurl'];
				}
				$optionInfoTmp = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($value['option_id']);
				$optionInfoTmp['name'] = cutstr($optionInfoTmp['name'], 8, '...');
				$orderList[$key]['option'] = $optionInfoTmp;
				$orderList[$key]['picurl'] = $picurl;
				$orderList[$key]['huodongInfo'] = $huodongInfoTmp;
				$orderList[$key]['huodongInfo']['hd_start_time'] = dgmdate($huodongInfoTmp['hd_start_time'], 'Y.m.d', $tomSysOffset);
				$orderList[$key]['huodongInfo']['hd_end_time'] = dgmdate($huodongInfoTmp['hd_end_time'], 'm.d', $tomSysOffset);
				$orderList[$key]['orderUrl'] = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=myorderinfo&order_no=' . $value['order_no'];
				if ($value['order_status'] == 1) {
					if (TIMESTAMP - $value['order_time'] > $tchuodongConfig['bm_nopay_overtime'] * 3600) {
						DB::query('UPDATE ' . DB::table('tom_tchuodong_order') . (' SET order_status=4 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
						$bmIds = str_replace('|', ',', $value['bm_ids']);
						DB::query('UPDATE ' . DB::table('tom_tchuodong_bm') . (' SET bm_status=4 WHERE id IN (' . $bmIds . ') '), 'UNBUFFERED');
						if ($value['option_id'] > 0) {
							DB::query('UPDATE ' . DB::table('tom_tchuodong_option') . (' SET sale_num=sale_num - ' . $value['number'] . ' WHERE id=\'' . $value['option_id'] . '\' '), 'UNBUFFERED');
						}
						$orderList[$key]['order_status'] = 4;
					}
				}
			}
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=myorder&type=' . $type . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=myorder&type=' . $type . '&page=' . $nextPage;
	$ajaxPayUrl = 'plugin.php?id=tom_tchuodong:pay&site=' . $site_id . '&act=pay&formhash=' . FORMHASH;
	$ajaxCancelPayUrl = 'plugin.php?id=tom_tchuodong:pay&site=' . $site_id . '&act=cancelpay&formhash=' . FORMHASH;
	$shareUrl = $_G['siteurl'] . 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=myorder';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tchuodong:myorder');
} elseif ($_GET['mod'] == 'myorderinfo') {
	$order_no = !empty($_GET['order_no']) ? addslashes($_GET['order_no']) : '';
	$myorderInfo = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_order_no($order_no);
	$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($myorderInfo['user_id']);
	$optionInfo = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($myorderInfo['option_id']);
	$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($myorderInfo['tchuodong_id']);
	if (!preg_match('/^http/', $huodongInfo['picurl'])) {
		if (strpos($huodongInfo['picurl'], 'source/plugin/tom_tchuodong/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $huodongInfo['picurl'];
		} else {
			$picurl = $huodongInfo['picurl'];
		}
	} else {
		$picurl = $huodongInfo['picurl'];
	}
	if ($_GET['act'] == 'wancheng' && submitcheck('bm_id')) {
		$bm_id = isset($_GET['bm_id']) ? intval($_GET['bm_id']) : 0;
		$order_no = !empty($_GET['order_no']) ? addslashes($_GET['order_no']) : '';
		$bmInfo = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_by_id($bm_id);
		$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($bmInfo['tchuodong_id']);
		$orderInfo = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_order_no($order_no);
		if ($__UserInfo['id'] != $orderInfo['user_id']) {
			$outArr = array('status' => 404);
			echo json_encode($outArr);
			exit(0);
		}
		if ($huodongInfo['hd_end_time'] < TIMESTAMP) {
			$outArr = array('status' => 301);
			echo json_encode($outArr);
			exit(0);
		}
		if ($huodongInfo['hd_start_time'] > TIMESTAMP) {
			$outArr = array('status' => 302);
			echo json_encode($outArr);
			exit(0);
		}
		$updateData = array();
		$updateData['bm_status'] = 3;
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['hexiao_time'] = TIMESTAMP;
		C::t('#tom_tchuodong#tom_tchuodong_bm')->update($bm_id, $updateData);
		$hexiaoStatus = 1;
		$syUseNum = $myorderInfo['number'] - $myorderInfo['use_num'];
		if ($syUseNum <= 1 || $myorderInfo['is_fenkai_bm'] == 0) {
			$hexiaoStatus = 2;
		}
		$updateData = array();
		if ($hexiaoStatus == 2) {
			$updateData['use_num'] = $myorderInfo['number'];
			$updateData['order_status'] = 3;
		} else {
			$updateData['use_num'] = $myorderInfo['use_num'] + 1;
		}
		C::t('#tom_tchuodong#tom_tchuodong_order')->update($myorderInfo['id'], $updateData);
		if ($orderInfo['balance_status'] == 0) {
			include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/balance.php';
		}
		$outArr = array('status' => 200);
		echo json_encode($outArr);
		exit(0);
	}
	$pay_time = dgmdate($myorderInfo['pay_time'], 'Y-m-d H:i:s', $tomSysOffset);
	$order_time = dgmdate($myorderInfo['order_time'], 'Y-m-d H:i:s', $tomSysOffset);
	$hd_start_time = dgmdate($huodongInfo['hd_start_time'], 'Y.m.d', $tomSysOffset);
	$hd_end_time = dgmdate($huodongInfo['hd_end_time'], 'm.d', $tomSysOffset);
	$hexiao_end_time = dgmdate($huodongInfo['hd_end_time'], 'Y-m-d H:i', $tomSysOffset);
	$bmIds = str_replace('|', ',', $myorderInfo['bm_ids']);
	$bmListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_all_list('AND id IN(' . $bmIds . ')');
	$bmList = array();
	if (is_array($bmListTmp) && !empty($bmListTmp)) {
		foreach ($bmListTmp as $k => $v) {
			$bmList[$k] = $v;
			$attrbmListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_list('AND bm_id = ' . $v['id'] . ' AND type_id != 6', 'ORDER BY paixu ASC,id DESC');
			$attrbmList = array();
			if (is_array($attrbmListTmp) && !empty($attrbmListTmp)) {
				foreach ($attrbmListTmp as $key => $value) {
					$attrbmList[$key] = $value;
				}
			}
			$attrpicListTmp = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list('AND tchuodong_id = ' . $v['tchuodong_id'] . ' AND type = 6', 'ORDER BY paixu ASC,id DESC');
			$attrpicList = array();
			if (is_array($attrpicListTmp) && !empty($attrpicListTmp)) {
				foreach ($attrpicListTmp as $key => $value) {
					$attrpicList[$key] = $value;
					$attrbmpicListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_list('AND bm_id = ' . $v['id'] . ' AND type_id = 6 AND attr_id = ' . $value['id'], 'ORDER BY paixu ASC,id DESC');
					$attrbmpicList = array();
					$attrbmpicListAll = array();
					$attrbmpicListStr = '';
					if (is_array($attrbmpicListTmp) && !empty($attrbmpicListTmp)) {
						foreach ($attrbmpicListTmp as $kk => $vv) {
							$attrbmpicList[$kk] = $vv;
							if (!preg_match('/^http/', $vv['picurl_value'])) {
								if (strpos($vv['picurl_value'], 'source/plugin/') === false) {
									$attrbmpicList[$kk]['picurl_value'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $vv['picurl_value'];
								} else {
									$attrbmpicList[$kk]['picurl_value'] = $_G['siteurl'] . $vv['picurl_value'];
								}
							} else {
								$attrbmpicList[$kk]['picurl_value'] = $vv['picurl_value'];
							}
							$attrbmpicListAll[] = $attrbmpicList[$kk]['picurl_value'];
						}
						$attrbmpicListStr = implode('|', $attrbmpicListAll);
					}
					$attrpicList[$key]['attrbmpicList'] = $attrbmpicList;
					$attrpicList[$key]['attrbmpicListStr'] = $attrbmpicListStr;
				}
			}
			$attrallbmListCount = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_count('AND bm_id = ' . $v['id']);
			$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($v['hexiao_user_id']);
			$bmList[$k]['hexiaoUserInfo'] = $hexiaoUserInfo;
			$bmList[$k]['attrpicList'] = $attrpicList;
			$bmList[$k]['attrbmList'] = $attrbmList;
			$bmList[$k]['attrallbmListCount'] = $attrallbmListCount;
			$bmList[$k]['qrcodeImg'] = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($_G['siteurl'] . 'plugin.php?id=tom_tchuodong&site=' . $site_id . ('&mod=orderhexiao&bm_id=' . $v['id'] . '&order_no=' . $order_no));
			$bmList[$k]['hexiao_time'] = dgmdate($v['hexiao_time'], 'Y-m-d H:i:s', $tomSysOffset);
		}
	}
	$hexiaoTimeStatus = 1;
	if (TIMESTAMP > $huodongInfo['hd_end_time']) {
		$hexiaoTimeStatus = 2;
	} else {
		if (TIMESTAMP < $huodongInfo['hd_start_time']) {
			$hexiaoTimeStatus = 3;
		}
	}
	$wanchengUrl = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=myorderinfo&act=wancheng&order_no=' . $order_no . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tchuodong:myorderinfo');
} elseif ($_GET['mod'] == 'order') {
	$tchuodong_id = isset($_GET['tchuodong_id']) ? intval($_GET['tchuodong_id']) : 0;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	if ($tchuodong_id > 0) {
		$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
		if ($huodongInfo['user_id'] != $__UserInfo['id']) {
			dheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=index'));
			exit(0);
		}
	}
	$huodongListTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_all_list('AND type= 1 AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 100);
	$huodongListIds = array();
	if (is_array($huodongListTmp) && !empty($huodongListTmp)) {
		foreach ($huodongListTmp as $key => $value) {
			$huodongListIds[] = $value['id'];
		}
	}
	$huodongListIdsStr = '99999999999';
	if (is_array($huodongListIds) && !empty($huodongListIds)) {
		$huodongListIdsStr = implode(',', $huodongListIds);
	}
	if ($tchuodong_id > 0) {
		$whereStr = ' AND tchuodong_id=' . $tchuodong_id . ' ';
		$whereTjStr = ' AND tchuodong_id=' . $tchuodong_id . ' ';
	} else {
		$whereStr = ' AND tchuodong_id IN(' . $huodongListIdsStr . ')';
		$whereTjStr = ' AND tchuodong_id IN(' . $huodongListIdsStr . ')';
	}
	if ($type == 1) {
		$whereStr .= ' AND order_status=1 ';
	} elseif ($type == 2) {
		$whereStr .= ' AND order_status=2 ';
	} elseif ($type == 3) {
		$whereStr .= ' AND shenhe_status=2 ';
	} elseif ($type == 4) {
		$whereStr .= ' AND order_status=3 ';
	}
	$orderStr = ' ORDER BY add_time DESC,id DESC ';
	$pagesize = 10;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_like_count($whereStr, $keyword);
	$count1 = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_like_count('AND shenhe_status = 1 ' . $whereTjStr . ' ', $keyword);
	$count3 = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_like_count('AND shenhe_status = 3 ' . $whereTjStr . ' ', $keyword);
	$orderListTmp = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_like_list($whereStr, ' ORDER BY id DESC ', $start, $pagesize, $keyword);
	$orderList = array();
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			$orderList[$key] = $value;
			$huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($value['tchuodong_id']);
			if (!preg_match('/^http/', $huodongInfoTmp['picurl'])) {
				if (strpos($huodongInfoTmp['picurl'], 'source/plugin/') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $huodongInfoTmp['picurl'];
				} else {
					$picurl = $huodongInfoTmp['picurl'];
				}
			} else {
				$picurl = $huodongInfoTmp['picurl'];
			}
			$orderList[$key]['picurl'] = $picurl;
			$orderList[$key]['huodongInfo'] = $huodongInfoTmp;
			$optionInfoTmp = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($value['option_id']);
			$orderList[$key]['option'] = $optionInfoTmp;
			$orderList[$key]['huodongInfo']['hd_start_time'] = dgmdate($huodongInfoTmp['hd_start_time'], 'Y.m.d', $tomSysOffset);
			$orderList[$key]['huodongInfo']['hd_end_time'] = dgmdate($huodongInfoTmp['hd_end_time'], 'm.d', $tomSysOffset);
			$orderList[$key]['orderUrl'] = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=orderinfo&order_no=' . $value['order_no'];
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > $tchuodongConfig['bm_nopay_overtime'] * 3600) {
					DB::query('UPDATE ' . DB::table('tom_tchuodong_order') . (' SET order_status=4 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
					$bmIds = str_replace('|', ',', $value['bm_ids']);
					DB::query('UPDATE ' . DB::table('tom_tchuodong_bm') . (' SET bm_status=4 WHERE id IN (' . $bmIds . ') '), 'UNBUFFERED');
					if ($value['option_id'] > 0) {
						DB::query('UPDATE ' . DB::table('tom_tchuodong_option') . (' SET sale_num=sale_num - ' . $value['number'] . ' WHERE id=\'' . $value['option_id'] . '\' '), 'UNBUFFERED');
					}
					$orderList[$key]['order_status'] = 4;
				}
			}
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=order&tchuodong_id=' . $tchuodong_id . '&type=' . $type . '&keyword=' . $keyword . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=order&tchuodong_id=' . $tchuodong_id . '&type=' . $type . '&keyword=' . $keyword . '&page=' . $nextPage;
	$searchUrl = 'plugin.php?id=tom_tchuodong:ajax&site=' . $site_id . '&act=get_order_search_url';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tchuodong:order');
} elseif ($_GET['mod'] == 'orderinfo') {
	$order_no = !empty($_GET['order_no']) ? addslashes($_GET['order_no']) : '';
	$orderInfo = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_order_no($order_no);
	$optionInfo = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($orderInfo['option_id']);
	$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
	$bmIds = str_replace('|', ',', $orderInfo['bm_ids']);
	$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($orderInfo['tchuodong_id']);
	if (!preg_match('/^http/', $huodongInfo['picurl'])) {
		if (strpos($huodongInfo['picurl'], 'source/plugin/tom_tchuodong/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $huodongInfo['picurl'];
		} else {
			$picurl = $huodongInfo['picurl'];
		}
	} else {
		$picurl = $huodongInfo['picurl'];
	}
	if ($_GET['act'] == 'shenhe' && submitcheck('bm_id')) {
		if ('utf-8' != CHARSET) {
			if (!defined('IN_MOBILE')) {
				foreach ($_POST as $pk => $pv) {
					if (!is_numeric($pv)) {
						$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
					}
				}
			}
		}
		$bm_id = intval($_GET['bm_id']) > 0 ? intval($_GET['bm_id']) : 0;
		$shenhe_status = intval($_GET['shenhe_status']) > 0 ? intval($_GET['shenhe_status']) : 0;
		$content = isset($_GET['content']) ? daddslashes($_GET['content']) : '';
		$bmInfo = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_by_id($bm_id);
		$updateData = array();
		$updateData['shenhe_status'] = $shenhe_status;
		C::t('#tom_tchuodong#tom_tchuodong_bm')->update($bm_id, $updateData);
		$shenheCount = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_all_count('AND shenhe_status = ' . $shenhe_status . ' AND id IN (' . $bmIds . ')');
		if ($orderInfo['is_fenkai_bm'] == 1) {
			if ($orderInfo['number'] - $shenheCount <= 1) {
				DB::query('UPDATE ' . DB::table('tom_tchuodong_order') . (' SET shenhe_status=' . $shenhe_status . ' WHERE id=\'' . $orderInfo['id'] . '\' '), 'UNBUFFERED');
			}
		} else {
			DB::query('UPDATE ' . DB::table('tom_tchuodong_order') . (' SET shenhe_status=' . $shenhe_status . ' WHERE id=\'' . $orderInfo['id'] . '\' '), 'UNBUFFERED');
		}
		$toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($bmInfo['user_id']);
		if ($bmInfo) {
			$insertData = array();
			$insertData['user_id'] = $toUser['id'];
			$insertData['type'] = 1;
			if ($shenhe_status == 1) {
				$insertData['content'] = '<b><font color="#238206">' . lang('plugin/tom_tchuodong', 'shenhe_status_1_title') . '</font></b><br/>';
			} elseif ($shenhe_status == 3) {
				$insertData['content'] = '<b><font color="#fd0d0d">' . lang('plugin/tom_tchuodong', 'shenhe_status_3_title') . '</font></b><br/><font color="#8e8e8e">' . $content . '</font><br/>';
			}
			$insertData['is_read'] = 0;
			$insertData['tz_time'] = TIMESTAMP;
			C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
		}
		include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/templatesms.class.php';
		$access_token = $weixinClass->get_access_token();
		$nextSmsTime = $toUser['last_smstp_time'] + 0;
		if ($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime) {
			$templateSmsClass = new templateSms($access_token, $_G['siteurl'] . ('plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=myorderinfo&order_no=' . $orderInfo['order_no']));
			if ($shenhe_status == 1) {
				$template_first = lang('plugin/tom_tchuodong', 'shenhe_status_1_title');
			} elseif ($shenhe_status == 3) {
				$template_first = lang('plugin/tom_tchuodong', 'shenhe_status_3_title');
			}
			$smsData = array('first' => $template_first, 'keyword1' => $__SitesInfo['name'], 'keyword2' => $content, 'remark' => '');
			$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
			if ($r) {
				$updateData = array();
				$updateData['last_smstp_time'] = TIMESTAMP;
				C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'], $updateData);
			}
		}
		echo 200;
		exit(0);
	} else {
		if ($_GET['act'] == 'shenhe_show') {
			$bm_id = intval($_GET['bm_id']) > 0 ? intval($_GET['bm_id']) : 0;
			$bmInfo = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_by_id($bm_id);
			$ajaxShenheUrl = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=orderinfo&act=shenhe';
			$isGbk = false;
			if (CHARSET == 'gbk') {
				$isGbk = true;
			}
			include template('tom_tchuodong:ordershenhe');
			exit(0);
		}
	}
	$pay_time = dgmdate($orderInfo['pay_time'], 'Y-m-d H:i:s', $tomSysOffset);
	$order_time = dgmdate($orderInfo['order_time'], 'Y-m-d H:i:s', $tomSysOffset);
	$hd_start_time = dgmdate($huodongInfo['hd_start_time'], 'Y.m.d', $tomSysOffset);
	$hd_end_time = dgmdate($huodongInfo['hd_end_time'], 'm.d', $tomSysOffset);
	$bmListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_all_list('AND id IN(' . $bmIds . ')');
	$bmList = array();
	if (is_array($bmListTmp) && !empty($bmListTmp)) {
		foreach ($bmListTmp as $k => $v) {
			$bmList[$k] = $v;
			$attrbmListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_list('AND bm_id = ' . $v['id'] . ' AND type_id != 6', 'ORDER BY paixu ASC,id DESC');
			$attrbmList = array();
			if (is_array($attrbmListTmp) && !empty($attrbmListTmp)) {
				foreach ($attrbmListTmp as $key => $value) {
					$attrbmList[$key] = $value;
				}
			}
			$attrpicListTmp = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list('AND tchuodong_id = ' . $v['tchuodong_id'] . ' AND type = 6', 'ORDER BY paixu ASC,id DESC');
			$attrpicList = array();
			if (is_array($attrpicListTmp) && !empty($attrpicListTmp)) {
				foreach ($attrpicListTmp as $key => $value) {
					$attrpicList[$key] = $value;
					$attrbmpicListTmp = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_list('AND bm_id = ' . $v['id'] . ' AND type_id = 6 AND attr_id = ' . $value['id'], 'ORDER BY paixu ASC,id DESC');
					$attrbmpicList = array();
					$attrbmpicListAll = array();
					$attrbmpicListStr = '';
					if (is_array($attrbmpicListTmp) && !empty($attrbmpicListTmp)) {
						foreach ($attrbmpicListTmp as $kk => $vv) {
							$attrbmpicList[$kk] = $vv;
							if (!preg_match('/^http/', $vv['picurl_value'])) {
								if (strpos($vv['picurl_value'], 'source/plugin/') === false) {
									$attrbmpicList[$kk]['picurl_value'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $vv['picurl_value'];
								} else {
									$attrbmpicList[$kk]['picurl_value'] = $_G['siteurl'] . $vv['picurl_value'];
								}
							} else {
								$attrbmpicList[$kk]['picurl_value'] = $vv['picurl_value'];
							}
							$attrbmpicListAll[] = $attrbmpicList[$kk]['picurl_value'];
						}
						$attrbmpicListStr = implode('|', $attrbmpicListAll);
					}
					$attrpicList[$key]['attrbmpicList'] = $attrbmpicList;
					$attrpicList[$key]['attrbmpicListStr'] = $attrbmpicListStr;
				}
			}
			$attrallbmListCount = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_count('AND bm_id = ' . $v['id']);
			$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($v['hexiao_user_id']);
			$bmList[$k]['hexiaoUserInfo'] = $hexiaoUserInfo;
			$bmList[$k]['attrpicList'] = $attrpicList;
			$bmList[$k]['attrbmList'] = $attrbmList;
			$bmList[$k]['attrallbmListCount'] = $attrallbmListCount;
			$bmList[$k]['hexiao_time'] = dgmdate($v['hexiao_time'], 'Y-m-d H:i:s', $tomSysOffset);
		}
	}
	$ajaxShenheUrl = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=orderinfo&act=shenhe&&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tchuodong:orderinfo');
} elseif ($_GET['mod'] == 'orderhexiao') {
	$bm_id = isset($_GET['bm_id']) ? intval($_GET['bm_id']) : 0;
	$order_no = !empty($_GET['order_no']) ? addslashes($_GET['order_no']) : '';
	$bmInfo = C::t('#tom_tchuodong#tom_tchuodong_bm')->fetch_by_id($bm_id);
	$orderInfo = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_order_no($order_no);
	$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($bmInfo['tchuodong_id']);
	$optionInfo = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($orderInfo['option_id']);
	if ($huodongInfo['type'] == 2) {
		$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);
		if ($tcshopInfo['hexiao_type'] > 0) {
			$tchuodongConfig['hexiao_type'] = $tcshopInfo['hexiao_type'];
		}
	}
	if ($_GET['act'] == 'hexiao' && submitcheck('bm_id')) {
		$hexiao_pwd = isset($_GET['hexiao_pwd']) ? addslashes($_GET['hexiao_pwd']) : '';
		if ($tchuodongConfig['hexiao_type'] == 2) {
			if (empty($huodongInfo['hexiao_pwd'])) {
				echo 301;
				exit(0);
			}
			if ($huodongInfo['hexiao_pwd'] != $hexiao_pwd) {
				echo 302;
				exit(0);
			}
		}
		$updateData = array();
		$updateData['bm_status'] = 3;
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['hexiao_time'] = TIMESTAMP;
		C::t('#tom_tchuodong#tom_tchuodong_bm')->update($bm_id, $updateData);
		$hexiaoStatus = 1;
		$syUseNum = $orderInfo['number'] - $orderInfo['use_num'];
		if ($syUseNum <= 1 || $orderInfo['is_fenkai_bm'] == 0) {
			$hexiaoStatus = 2;
		}
		$updateData = array();
		if ($hexiaoStatus == 2) {
			$updateData['use_num'] = $orderInfo['number'];
			$updateData['order_status'] = 3;
		} else {
			$updateData['use_num'] = $orderInfo['use_num'] + 1;
		}
		C::t('#tom_tchuodong#tom_tchuodong_order')->update($orderInfo['id'], $updateData);
		if ($orderInfo['balance_status'] == 0) {
			include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/balance.php';
		}
		echo 200;
		exit(0);
	}
	$huodongPicurl = '';
	if (!preg_match('/^http/', $huodongInfo['picurl'])) {
		if (strpos($huodongInfo['picurl'], 'source/plugin/') === false) {
			$huodongPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $huodongInfo['picurl'];
		} else {
			$huodongPicurl = $huodongInfo['picurl'];
		}
	} else {
		$huodongPicurl = $huodongInfo['picurl'];
	}
	$isTcshopClerk = 0;
	if ($huodongInfo['type'] == 1) {
		if ($huodongInfo['user_id'] == $__UserInfo['id']) {
			$isTcshopClerk = 1;
		}
	} elseif ($huodongInfo['type'] == 2) {
		$clerkListTmp = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(' AND tcshop_id=' . $orderInfo['tcshop_id'] . ' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 1);
		if (!empty($clerkListTmp[0]['id']) || $tcshopInfo['user_id'] == $__UserInfo['id']) {
			$isTcshopClerk = 1;
		}
	}
	$showHexiaoBox = 1;
	if ($tchuodongConfig['hexiao_type'] == 1 && $isTcshopClerk == 0) {
		$showHexiaoBox = 2;
	}
	$hexiaoUserInfo = array();
	if ($bmInfo['bm_status'] == 3) {
		$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($bmInfo['hexiao_user_id']);
	}
	$hexiaoUrl = 'plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=orderhexiao&act=hexiao&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tchuodong:orderhexiao');
} elseif ($_GET['mod'] == 'fabu_step1') {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/fabu_step1.php';
} elseif ($_GET['mod'] == 'fabu_step2') {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/fabu_step2.php';
} elseif ($_GET['mod'] == 'myfabu') {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/myfabu.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/edit.php';
} elseif ($_GET['mod'] == 'editoption') {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/editoption.php';
} elseif ($_GET['mod'] == 'attrlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/attrlist.php';
} elseif ($_GET['mod'] == 'addattr') {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/addattr.php';
} elseif ($_GET['mod'] == 'editattr') {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/editattr.php';
} elseif ($_GET['mod'] == 'baidumap') {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/baidumap.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/upload.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/index.php';
}
tomoutput();