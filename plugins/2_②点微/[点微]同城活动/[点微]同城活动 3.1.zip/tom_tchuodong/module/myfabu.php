<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = 8;
$start      = ($page - 1)*$pagesize;

$whereStr   = " AND user_id = {$__UserInfo['id']} ";
$orderStr   = " ORDER BY id DESC ";

if($type == 1){
    $whereStr.= " AND status = 1 AND shenhe_status = 1 ";
}else if($type == 2){
    $whereStr.= " AND (shenhe_status = 2 OR shenhe_status = 3)";
    $orderStr = " ORDER BY shenhe_status ASC, id DESC ";
}

$count  = C::t('#tom_tchuodong#tom_tchuodong')->fetch_all_count(" {$whereStr} ");
$huodongListTmp   = C::t('#tom_tchuodong#tom_tchuodong')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);
$huodongList = array();
foreach ($huodongListTmp as $key => $value){
    $huodongList[$key] = $value;
    $huodongList[$key]['bm_start_time'] = dgmdate($value['bm_start_time'], 'Y.m.d',$tomSysOffset);
    $huodongList[$key]['bm_end_time']   = dgmdate($value['bm_end_time'], 'm.d',$tomSysOffset);
    $huodongList[$key]['hd_start_time'] = dgmdate($value['hd_start_time'], 'Y.m.d',$tomSysOffset);
    $huodongList[$key]['hd_end_time']   = dgmdate($value['hd_end_time'], 'm.d',$tomSysOffset);
    if(!preg_match('/^http/', $value['picurl']) ){
        if(strpos($value['picurl'], 'source/plugin/tom_tchuodong/') === FALSE){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $picurl = $value['picurl'];
        }
    }else{
        $picurl = $value['picurl'];
    }
    $huodongList[$key]['picurl'] = $picurl;
    $huodongList[$key]['link']   = 'plugin.php?id=tom_tchuodong&site='.$value['site_id'].'&mod=details&tchuodong_id='.$value['id'];
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum  = ceil($count/$pagesize);
$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=myfabu&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=myfabu&type={$type}&page={$nextPage}";

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tchuodong:ajax&site={$site_id}&act=updateStatus&&formhash=".$formhash;

$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tchuodong&site=".$site_id."&mod=myfabu";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchuodong:myfabu");