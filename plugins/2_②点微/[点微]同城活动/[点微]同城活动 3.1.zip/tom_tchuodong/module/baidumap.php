<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lat  = !empty($_GET['lat'])? addslashes($_GET['lat']):'';
$lng  = !empty($_GET['lng'])? addslashes($_GET['lng']):'';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchuodong:baidumap");