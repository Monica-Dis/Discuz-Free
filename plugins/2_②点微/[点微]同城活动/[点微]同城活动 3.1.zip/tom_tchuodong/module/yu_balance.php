<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcadmin start
$__ShowTcadmin = 0;
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
    if($tcadminConfig['open_fc'] == 1){
        $__ShowTcadmin = 1;
    }
}
## tcadmin end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

if($orderInfo['pay_price'] >= 0.1){
    
    $yongjin_bili = $tchuodongConfig['yongjin_bili'];
    $huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($orderInfo['tchuodong_id']);
    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
    if($huodongInfoTmp['yongjin_bili'] > 0){
        $yongjin_bili = $huodongInfoTmp['yongjin_bili'];
    }
    
    if($yongjin_bili <= 100){
        
        $pt_money = $orderInfo['pay_price']*($yongjin_bili/100);
        $pt_money = number_format($pt_money,2, '.', '');
        
        if($pt_money >= 0.1){
            # fc start
            $adminFc = false;
            if($__ShowTchehuoren == 1 && $orderInfo['tj_hehuoren_id'] > 0){
                
                $shenyu_money = $pt_money;
                $child_site_fc_money = $tchehuoren_fc_money = $tctchehuorenParent_fc_money = 0;

                $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($orderInfo['tj_hehuoren_id']);
                if($tchehuorenInfo){
                    $tchehuorenDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
                    $tchehuorenUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tchehuorenInfo['openid']);
                }

                $tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
                if($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1){
                    $tctchehuorenParentInfo = C::t("#tom_tchehuoren#tom_tchehuoren")->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
                    $tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
                    $tctchehuorenParentUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tctchehuorenParentInfo['openid']);
                }

                if($tchehuorenInfo && $tchehuorenInfo['status'] == 1 && $tchehuorenDengji['hd_fc_open'] == 1){
                    if($orderInfo['site_id'] > 1 && $tchuodongConfig['zizhandi_fc'] == 1){
                        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                        $sitename = $sitesInfo['name'];
                        if($__ShowTcadmin && $sitesInfo['hehuoren_fc_open'] == 1){
                            
                            if($tchehuorenDengji['level'] == 1){
                                $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['chuji_fc_scale']/100);
                            }else if($tchehuorenDengji['level'] == 2){
                                $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['zhongji_fc_scale']/100);
                            }else if($tchehuorenDengji['level'] == 3){
                                $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['gaoji_fc_scale']/100);
                            }
                            $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2, '.', '');
                            
                            $fc_scale = $sitesInfo['hd_fc_scale'];
                            if($fc_scale > 0){
                                $child_site_fc_money = $pt_money * ($fc_scale/100);
                                $child_site_fc_money = number_format($child_site_fc_money,2, '.', '');
                                $child_site_fc_money = $child_site_fc_money - $tchehuoren_fc_money;
                            }
                            if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                                $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                                $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                                if($tchehuorenConfig['subordinate_moneytype'] == 1){
                                    $child_site_fc_money   = $child_site_fc_money - $tctchehuorenParent_fc_money;
                                }else{
                                    $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                                }
                            }

                            $shenyu_money = $shenyu_money - $child_site_fc_money - $tchehuoren_fc_money;

                        }else{
                            if($__ShowTcadmin == 1 && $tchuodongConfig['zizhandi_fc'] == 1){
                                $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                                $fc_scale = $sitesInfo['hd_fc_scale'];
                                if($fc_scale > 0){
                                    $child_site_fc_money = $pt_money * ($fc_scale/100);
                                    $child_site_fc_money = number_format($child_site_fc_money,2, '.', '');
                                }
                            }

                            $shenyu_money = $shenyu_money - $child_site_fc_money;

                        }

                    }else{
                        $sitename = $tongchengConfig['plugin_name'];
                        if($tchehuorenDengji['level'] == 1){
                            $tchehuoren_fc_money = $pt_money * ($huodongInfoTmp['chuji_fc_scale']/100);
                        }else if($tchehuorenDengji['level'] == 2){
                            $tchehuoren_fc_money = $pt_money * ($huodongInfoTmp['zhongji_fc_scale']/100);
                        }else if($tchehuorenDengji['level'] == 3){
                            $tchehuoren_fc_money = $pt_money * ($huodongInfoTmp['gaoji_fc_scale']/100);
                        }
                        $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2, '.', '');

                        if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                            $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                            $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                            if($tchehuorenConfig['subordinate_moneytype'] == 1){
                            }else{
                                $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                            }
                        }

                        $shenyu_money = $shenyu_money - $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                    }

                    if($pt_money >= ($child_site_fc_money +  $tchehuoren_fc_money + $tctchehuorenParent_fc_money)){  

                        $sendTemplateTchehuoren = false;
                        if($tchehuoren_fc_money > 0){
                            $sendTemplateTchehuoren = true;

                            $insertData = array();
                            $insertData['order_no']         = $orderInfo['order_no'];
                            $insertData['hehuoren_id']      = $tchehuorenInfo['id'];
                            $insertData['ly_user_id']       = $userInfoTmp['id'];
                            $insertData['child_hehuoren_id'] = 0;
                            $insertData['today_time']       = $nowDayTime;
                            $insertData['week_time']        = $nowWeekTime;
                            $insertData['month_time']       = $nowMonthTime;
                            $insertData['type']             = lang('plugin/tom_tchuodong', 'hehuoren_tag_hd');
                            $insertData['shouyi_price']     = $tchehuoren_fc_money;
                            $insertData['content']          = lang('plugin/tom_tchuodong', 'hehuoren_beizu_1') . $orderInfo['order_no'] . lang('plugin/tom_tchuodong', 'hehuoren_beizu_2') . $userInfoTmp['nickname'];
                            $insertData['shouyi_status']    = 1;
                            $insertData['add_time']         = TIMESTAMP;
                            C::t('#tom_tchehuoren#tom_tchehuoren_yushouyi')->insert($insertData);
                        }

                        $sendTemplateTchehuorenParent = false;
                        if($tctchehuorenParent_fc_money > 0){
                            $sendTemplateTchehuorenParent = true;

                            $insertData = array();
                            $insertData['order_no']         = $orderInfo['order_no'];
                            $insertData['hehuoren_id']      = $tctchehuorenParentInfo['id'];
                            $insertData['ly_user_id']       = $userInfoTmp['id'];
                            $insertData['child_hehuoren_id'] = $tchehuorenInfo['id'];
                            $insertData['today_time']       = $nowDayTime;
                            $insertData['week_time']        = $nowWeekTime;
                            $insertData['month_time']       = $nowMonthTime;
                            $insertData['type']             = lang('plugin/tom_tchuodong', 'hehuoren_tag_hd');
                            $insertData['shouyi_price']     = $tctchehuorenParent_fc_money;
                            $insertData['content']          = lang('plugin/tom_tchuodong', 'hehuoren_beizu_1') . $orderInfo['order_no'] . lang('plugin/tom_tchuodong', 'hehuoren_beizu_2') . $userInfoTmp['nickname'];
                            $insertData['shouyi_status']    = 1;
                            $insertData['add_time']         = TIMESTAMP;
                            C::t('#tom_tchehuoren#tom_tchehuoren_yushouyi')->insert($insertData);
                        }
                    }

                }else{
                    $adminFc = true;
                }
            }else{
                $adminFc = true;
            }
            # fc end
        }
        
        if($sendTemplateTchehuoren == true){
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($tchehuorenInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                $shouyiText = str_replace("{NICKNAME}",$userInfoTmp['nickname'], lang('plugin/tom_tongcheng', 'paynotify_hehuoren_template'));
                $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                $shouyiText = str_replace("{TYPE}",lang('plugin/tom_tchuodong', 'hehuoren_tag_hd'), $shouyiText);
                $shouyiText = str_replace("{MONEY}",$tchehuoren_fc_money, $shouyiText);
                $smsData = array(
                    'first'         => lang('plugin/tom_tchehuoren', 'yujishouyi').$shouyiText,
                    'keyword1'      => $tchehuorenConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                if(!empty($tchehuorenConfig['template_id'])){
                    $template_id = $tchehuorenConfig['template_id'];
                }else{
                    $template_id = $tongchengConfig['template_id'];
                }
                @$r = $templateSmsClass->sendSms01($tchehuorenInfo['openid'], $template_id, $smsData);
            }
        }

        if($sendTemplateTchehuorenParent == true){
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($tctchehuorenParentInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                $shouyiText = str_replace("{TCHEHUOREN}",$tchehuorenInfo['xm'], lang('plugin/tom_tongcheng', 'paynotify_hehuorenparent_template'));
                $shouyiText = str_replace("{NICKNAME}",$userInfoTmp['nickname'], $shouyiText);
                $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                $shouyiText = str_replace("{TYPE}",lang('plugin/tom_tchuodong', 'hehuoren_tag_hd'), $shouyiText);
                $shouyiText = str_replace("{MONEY}",$tctchehuorenParent_fc_money, $shouyiText);
                $smsData = array(
                    'first'         => lang('plugin/tom_tchehuoren', 'yujishouyi').$shouyiText,
                    'keyword1'      => $tchehuorenConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                if(!empty($tchehuorenConfig['template_id'])){
                    $template_id = $tchehuorenConfig['template_id'];
                }else{
                    $template_id = $tongchengConfig['template_id'];
                }
                @$r = $templateSmsClass->sendSms01($tctchehuorenParentInfo['openid'], $template_id, $smsData);
            }
        }
        
    }
}