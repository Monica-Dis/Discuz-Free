<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tchuodong_id   = isset($_GET['tchuodong_id'])? intval($_GET['tchuodong_id']):0;

$huodongInfo    = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
$tcshopInfo     = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($huodongInfo['tcshop_id']);

if($__UserInfo['id'] != $huodongInfo['user_id']){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tchuodong&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && submitcheck('tchuodong_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $cate_id              = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $title                = isset($_GET['title'])? addslashes($_GET['title']):0;
    $open_vip             = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $fenkai_bm            = isset($_GET['fenkai_bm'])? intval($_GET['fenkai_bm']):0;
    $must_shenhe          = isset($_GET['must_shenhe'])? intval($_GET['must_shenhe']):0;
    $xiangou_num          = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $address              = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude             = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude            = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $bm_start_time        = isset($_GET['bm_start_time'])? addslashes($_GET['bm_start_time']):'';
    $bm_start_time        = str_replace("T", " ", $bm_start_time);
    $bm_start_time        = strtotime($bm_start_time);
    $bm_end_time          = isset($_GET['bm_end_time'])? addslashes($_GET['bm_end_time']):'';
    $bm_end_time          = str_replace("T", " ", $bm_end_time);
    $bm_end_time          = strtotime($bm_end_time);
    $hd_start_time        = isset($_GET['hd_start_time'])? addslashes($_GET['hd_start_time']):'';
    $hd_start_time        = str_replace("T", " ", $hd_start_time);
    $hd_start_time        = strtotime($hd_start_time);
    $hd_end_time          = isset($_GET['hd_end_time'])? addslashes($_GET['hd_end_time']):'';
    $hd_end_time          = str_replace("T", " ", $hd_end_time);
    $hd_end_time          = strtotime($hd_end_time);
    $mp3_link             = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $show_stock_num       = isset($_GET['show_stock_num'])? intval($_GET['show_stock_num']):0;
    $content              = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl               = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic               = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    $share_title          = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc           = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    
    $hexiao_pwd           = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $updateData = array();
    $updateData['cate_id']            = $cate_id;
    $updateData['title']              = $title;
    $updateData['open_vip']           = $open_vip;
    $updateData['fenkai_bm']          = $fenkai_bm;
    $updateData['must_shenhe']        = $must_shenhe;
    $updateData['xiangou_num']        = $xiangou_num;
    $updateData['address']            = $address;
    $updateData['latitude']           = $latitude;
    $updateData['longitude']          = $longitude;
    $updateData['bm_start_time']      = $bm_start_time;
    $updateData['bm_end_time']        = $bm_end_time;
    $updateData['hd_start_time']      = $hd_start_time;
    $updateData['hd_end_time']        = $hd_end_time;
    $updateData['mp3_link']           = $mp3_link;
    $updateData['show_stock_num']     = $show_stock_num;
    if($huodongInfo['admin_edit'] == 0){
        $updateData['content']        = dhtmlspecialchars($content);
    }
    $updateData['picurl']             = $picurl;
    $updateData['toppic']             = $toppic;
    $updateData['share_title']        = $share_title;
    $updateData['share_desc']         = $share_desc;
    $updateData['hexiao_pwd']         = $hexiao_pwd;
    $updateData['add_time']           = TIMESTAMP;
    
    if(C::t('#tom_tchuodong#tom_tchuodong')->update($tchuodong_id,$updateData)){
        
        $huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
        update_huodong_status($huodongInfoTmp);
        
        C::t('#tom_tchuodong#tom_tchuodong_photo')->delete_by_tchuodong_id($tchuodong_id);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['tchuodong_id']   = $tchuodong_id;
                $insertData['picurl']         = $value;
                $insertData['add_time']       = TIMESTAMP;
                C::t('#tom_tchuodong#tom_tchuodong_photo')->insert($insertData);
            }
        }
        
        echo 200;exit;
        
    }else{
        echo 404;exit;
    }
}

if(!preg_match('/^http/', $huodongInfo['picurl']) ){
    if(strpos($huodongInfo['picurl'], 'source/plugin/tom_tchuodong/') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$huodongInfo['picurl'];
    }else{
        $picurl = $huodongInfo['picurl'];
    }
}else{
    $picurl = $huodongInfo['picurl'];
}
if(!preg_match('/^http/', $huodongInfo['toppic']) ){
    if(strpos($huodongInfo['toppic'], 'source/plugin/tom_tchuodong/') === FALSE){
        $toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$huodongInfo['toppic'];
    }else{
        $toppic = $huodongInfo['toppic'];
    }
}else{
    $toppic = $huodongInfo['toppic'];
}

$huodongPhotoListTmp = C::t('#tom_tchuodong#tom_tchuodong_photo')->fetch_all_list(" AND tchuodong_id={$tchuodong_id} "," ORDER BY id ASC ",0,50);
$huodongPhotoList = array();
$photoCount = 0;
if(is_array($huodongPhotoListTmp) && !empty($huodongPhotoListTmp)){
    foreach ($huodongPhotoListTmp as $kk => $vv){
        $photoCount++;
        if(!preg_match('/^http/', $vv['picurl']) ){
            if(strpos($huodongInfo['toppic'], 'source/plugin/tom_tchuodong/') === FALSE){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
            }else{
                $picurlTmp = $vv['picurl'];
            }
        }else{
            $picurlTmp = $vv['picurl'];
        }
        $huodongPhotoList[$kk]['picurl'] = $vv['picurl'];
        $huodongPhotoList[$kk]['src'] = $picurlTmp;
        $huodongPhotoList[$kk]['li_i'] = $photoCount;
    }
}

$bm_start_time      = dgmdate($huodongInfo['bm_start_time'],'Y-m-d H:i:s',$tomSysOffset);
$bm_start_time      = str_replace(" ", "T", $bm_start_time);
$bm_end_time        = dgmdate($huodongInfo['bm_end_time'],'Y-m-d H:i:s',$tomSysOffset);
$bm_end_time        = str_replace(" ", "T", $bm_end_time);
$hd_start_time      = dgmdate($huodongInfo['hd_start_time'],'Y-m-d H:i:s',$tomSysOffset);
$hd_start_time      = str_replace(" ", "T", $hd_start_time);
$hd_end_time        = dgmdate($huodongInfo['hd_end_time'],'Y-m-d H:i:s',$tomSysOffset);
$hd_end_time        = str_replace(" ", "T", $hd_end_time);

$cateListTmp = C::t('#tom_tchuodong#tom_tchuodong_cate')->fetch_all_list(""," ORDER BY csort ASC,id DESC ",0,100);
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach ($cateListTmp as $key => $value){
        $cateList[$key] = $value;
    }
}

$saveUrl      = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=edit&act=save";
$uploadUrl1   = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2   = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=upload&act=toppic&formhash=".FORMHASH;
$uploadUrl3   = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=upload&act=photos&formhash=".FORMHASH;
$wxUploadUrl2 = "plugin.php?id=tom_tchuodong:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchuodong:edit");