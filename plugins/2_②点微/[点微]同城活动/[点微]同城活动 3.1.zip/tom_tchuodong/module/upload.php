<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$server_yasu_size = 720;
if($tongchengConfig['server_yasu_size'] > 0){
    $server_yasu_size = $tongchengConfig['server_yasu_size'];
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';

if($_GET['act'] == 'photo' && $_GET['formhash'] == FORMHASH){
    
    $upload = new tom_upload();
    $attr_id = isset($_GET['attr_id'])>0 ? addslashes($_GET['attr_id']):'';
    $name = "filename".$attr_id;

    $_FILES[$name]['name'] = addslashes(diconv(urldecode($_FILES[$name]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES[$name], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    $picurl = str_replace($_G['siteurl'], "", $picurl);
    $picurl = ltrim($picurl, '/');
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'picurl' && $_GET['formhash'] == FORMHASH){
    
    $upload = new tom_upload();
    $_FILES["filedata2"]['name'] = addslashes(diconv(urldecode($_FILES["filedata2"]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata2'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    //require_once libfile('class/image');
    //$image = new image();
    //$image->Thumb($upload->attach['target'], '', 200, 200, 2, 1);
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'toppic' && $_GET['formhash'] == FORMHASH){
    
    $upload = new tom_upload();
    $_FILES["filedata4"]['name'] = addslashes(diconv(urldecode($_FILES["filedata4"]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata4'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    require_once libfile('class/image');
    $image = new image();
    $image->Thumb($upload->attach['target'], '', 640, 300, 2, 1);
        
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'photos' && $_GET['formhash'] == FORMHASH){

    $upload = new tom_upload();
    $_FILES["filedata3"]['name'] = addslashes(diconv(urldecode($_FILES["filedata3"]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata3'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}