<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tchuodong_id   = isset($_GET['tchuodong_id'])? intval($_GET['tchuodong_id']):0;
$type           = isset($_GET['type'])? intval($_GET['type']):0;

$huodongInfo    = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);

if($__UserInfo['id'] != $huodongInfo['user_id']){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tchuodong&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && submitcheck('tchuodong_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    $name               = isset($_GET['name'])? addslashes($_GET['name']):0;
    $value              = isset($_GET['value'])? addslashes($_GET['value']):'';
    $is_must            = isset($_GET['is_must'])? intval($_GET['is_must']):0;
    $min_photo_num      = isset($_GET['min_photo_num'])? intval($_GET['min_photo_num']):0;
    $max_photo_num      = isset($_GET['max_photo_num'])? intval($_GET['max_photo_num']):0;
    $unit               = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $paixu              = isset($_GET['paixu'])? intval($_GET['paixu']):100;
  
    $insertData = array();
    $insertData['tchuodong_id']       = $tchuodong_id;
    $insertData['name']               = $name;
    $insertData['type']               = $type;
    $insertData['value']              = $value;
    $insertData['is_must']            = $is_must;
    $insertData['min_photo_num']      = $min_photo_num;
    $insertData['max_photo_num']      = $max_photo_num;
    $insertData['unit']               = $unit;
    $insertData['paixu']              = $paixu;
    $insertData['add_time']           = TIMESTAMP;
    if(C::t('#tom_tchuodong#tom_tchuodong_attr')->insert($insertData)){
        echo 200; exit;
    }else{
        echo 404; exit;
    }
}

$saveUrl    = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=addattr&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchuodong:addattr");