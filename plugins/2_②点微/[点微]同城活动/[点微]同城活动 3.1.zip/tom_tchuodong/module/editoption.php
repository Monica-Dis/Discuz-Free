<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tchuodong_id = intval($_GET['tchuodong_id'])>0? intval($_GET['tchuodong_id']):0;

$huodongInfo  = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);

if($__UserInfo['id'] != $huodongInfo['user_id']){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tchuodong&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'remove_option' && submitcheck('option_id')){
    
    $option_id = intval($_GET['option_id'])>0? intval($_GET['option_id']): 0;
    
    C::t("#tom_tchuodong#tom_tchuodong_option")->delete_by_id($option_id);
    
    $optionListTmp = C::t("#tom_tchuodong#tom_tchuodong_option")->fetch_all_list(" AND tchuodong_id = {$tchuodong_id} AND is_hidden = 0", 'ORDER BY osort ASC,id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_min_price = $show_max_price  = $show_min_vip_price = $show_max_vip_price = 0;
        foreach($optionListTmp as $key => $value){
            if($show_min_price == 0){
                $show_min_price         = $value['price'];
                $show_min_vip_price     = $value['vip_price'];
            }else if($value['price'] > 0 && $value['price'] < $show_min_price){
                $show_min_price         = $value['price'];
                $show_min_vip_price     = $value['vip_price'];
            }
            if($show_max_price == 0){
                $show_max_price         = $value['price'];
                $show_max_vip_price     = $value['vip_price'];
            }else if($value['price'] > 0 && $value['price'] > $show_max_price){
                $show_max_price         = $value['price'];
                $show_max_vip_price     = $value['vip_price'];
            }
        }
        
        $updateData = array();
        $updateData['show_min_price']       = $show_min_price;
        $updateData['show_min_vip_price']   = $show_min_vip_price;
        $updateData['show_max_price']       = $show_max_price;
        $updateData['show_max_vip_price']   = $show_max_vip_price;
        $updateData['part1']                = TIMESTAMP;
        C::t("#tom_tchuodong#tom_tchuodong")->update($tchuodong_id,$updateData);
        $huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
        update_huodong_status($huodongInfoTmp);
    }
    
    echo 1;exit;

}else if($_GET['act'] == 'save' && submitcheck('tchuodong_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $option_id      = intval($_GET['option_id'])> 0? intval($_GET['option_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):"";
    $price          = floatval($_GET['price'])> 0? floatval($_GET['price']):0.00;
    $vip_price      = floatval($_GET['vip_price'])> 0? floatval($_GET['vip_price']):0.00;
    $stock_num      = floatval($_GET['stock_num'])> 0? floatval($_GET['stock_num']):0.00;
    $osort          = intval($_GET['osort'])> 0? intval($_GET['osort']):10;
    
    if($option_id > 0){
        if($stock_num < $optionInfo['sale_num']){
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
     
        $updateData = array();
        $updateData['name']         = $name;
        $updateData['price']        = $price;
        $updateData['vip_price']    = $vip_price;
        $updateData['stock_num']    = $stock_num;
        $updateData['osort']        = $osort;
        C::t('#tom_tchuodong#tom_tchuodong_option')->update($option_id,$updateData);
    }else{
        $insertData = array();
        $insertData['tchuodong_id'] = $tchuodong_id;
        $insertData['name']         = $name;
        $insertData['price']        = $price;
        $insertData['vip_price']    = $vip_price;
        $insertData['stock_num']    = $stock_num;
        $insertData['osort']        = $osort;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tchuodong#tom_tchuodong_option')->insert($insertData);
        $option_id = C::t('#tom_tchuodong#tom_tchuodong_option')->insert_id();
    }
    
    $beizu = 'ID:&nbsp;<font color="#0a9409">'.$option_id.'</font>&nbsp;'.lang('plugin/tom_tchuodong', 'option_name').'&nbsp;<font color="#0a9409">'.$name.'</font>&nbsp;'.lang('plugin/tom_tchuodong', 'option_stock_num').'&nbsp;<font color="#fd0d0d">'.$stock_num.'</font>&nbsp;'.lang('plugin/tom_tchuodong', 'option_price').'&nbsp;<font color="#fd0d0d">'.$price.'</font>&nbsp;'.lang('plugin/tom_tchuodong', 'option_vip_price').'&nbsp;<font color="#fd0d0d">'.$vip_price.'</font><br/>';
    
    $insertData = array();
    $insertData['is_admin']         = 0;
    $insertData['is_option']        = 1;
    $insertData['tchuodong_id']     = $tchuodong_id;
    $insertData['beizu']            = $beizu;
    $insertData['change_num']       = $stock_num;
    $insertData['change_time']      = TIMESTAMP;
    C::t("#tom_tchuodong#tom_tchuodong_stock_log")->insert($insertData);
    
    $optionListTmp = C::t("#tom_tchuodong#tom_tchuodong_option")->fetch_all_list(" AND tchuodong_id = {$tchuodong_id} AND is_hidden = 0 ", 'ORDER BY osort ASC,id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_min_price = $show_max_price  = $show_min_vip_price = $show_max_vip_price = 0;
        foreach($optionListTmp as $key => $value){
            if($show_min_price == 0){
                $show_min_price         = $value['price'];
                $show_min_vip_price     = $value['vip_price'];
            }else if($value['price'] > 0 && $value['price'] < $show_min_price){
                $show_min_price         = $value['price'];
                $show_min_vip_price     = $value['vip_price'];
            }
            if($show_max_price == 0){
                $show_max_price         = $value['price'];
                $show_max_vip_price     = $value['vip_price'];
            }else if($value['price'] > 0 && $value['price'] > $show_max_price){
                $show_max_price         = $value['price'];
                $show_max_vip_price     = $value['vip_price'];
            }
        }
        
        $updateData = array();
        $updateData['show_min_price']       = $show_min_price;
        $updateData['show_min_vip_price']   = $show_min_vip_price;
        $updateData['show_max_price']       = $show_max_price;
        $updateData['show_max_vip_price']   = $show_max_vip_price;
        $updateData['part1']                = TIMESTAMP;
        C::t("#tom_tchuodong#tom_tchuodong")->update($tchuodong_id,$updateData);
    }
    
    $huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
    update_huodong_status($huodongInfoTmp);
    
    $outArr = array(
        'status'=> 200,
        'option_id'=> $option_id,
    );
    echo json_encode($outArr); exit;

}

$optionListTmp = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_all_list(" AND tchuodong_id = {$tchuodong_id}", 'ORDER BY osort ASC,id ASC', 0, 100);
$optionList = array();
if(is_array($optionListTmp) && !empty($optionListTmp)){
    foreach($optionListTmp as $key => $value){
        $optionList[$key] = $value;
        $orderCount = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_count(" AND option_id={$value['id']}");
        $optionList[$key]['orderCount']   = $orderCount;
    }
}

$saveUrl = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=editoption&tchuodong_id={$tchuodong_id}&act=save&formhash={$formhash}";
$ajaxUpdateOptionStatusUrl = "plugin.php?id=tom_tchuodong:ajax&site={$site_id}&act=updateOptionStatus&&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchuodong:editoption");