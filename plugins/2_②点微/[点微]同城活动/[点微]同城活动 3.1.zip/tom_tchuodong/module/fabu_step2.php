<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type   = isset($_GET['type'])? intval($_GET['type']):0;

if($type != 1 && $type != 2){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tchuodong&site={$site_id}&mod=fabu_step1");exit;
}

if($type == 1 && $tchuodongConfig['person_fabu'] == 0){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tchuodong&site={$site_id}&mod=fabu_step1");exit;
}

if($_GET['act'] == 'save' && submitcheck('user_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):0;
    $open_vip           = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $xiangou_num        = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $fenkai_bm          = isset($_GET['fenkai_bm'])? intval($_GET['fenkai_bm']):0;
    $must_shenhe        = isset($_GET['must_shenhe'])? intval($_GET['must_shenhe']):0;
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $bm_start_time      = isset($_GET['bm_start_time'])? addslashes($_GET['bm_start_time']):'';
    $bm_start_time      = str_replace("T", " ", $bm_start_time);
    $bm_start_time      = strtotime($bm_start_time);
    $bm_end_time        = isset($_GET['bm_end_time'])? addslashes($_GET['bm_end_time']):'';
    $bm_end_time        = str_replace("T", " ", $bm_end_time);
    $bm_end_time        = strtotime($bm_end_time);
    $hd_start_time      = isset($_GET['hd_start_time'])? addslashes($_GET['hd_start_time']):'';
    $hd_start_time      = str_replace("T", " ", $hd_start_time);
    $hd_start_time      = strtotime($hd_start_time);
    $hd_end_time        = isset($_GET['hd_end_time'])? addslashes($_GET['hd_end_time']):'';
    $hd_end_time        = str_replace("T", " ", $hd_end_time);
    $hd_end_time        = strtotime($hd_end_time);
    $mp3_link           = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $show_stock_num     = isset($_GET['show_stock_num'])? intval($_GET['show_stock_num']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    $share_title        = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc         = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    
    $hexiao_pwd           = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $insertData = array();
    if($type == 1){
        $insertData['site_id']        = $site_id;
    }elseif($type == 2){
        $insertData['site_id']        = $tcshopInfo['site_id'];
    }
    $insertData['user_id']            = $user_id;
    $insertData['type']               = $type;
    if($type == 2){
        $insertData['tcshop_id']      = $tcshop_id;
    }
    $insertData['cate_id']            = $cate_id;
    $insertData['title']              = $title;
    $insertData['open_vip']           = $open_vip;
    $insertData['xiangou_num']        = $xiangou_num;
    $insertData['fenkai_bm']          = $fenkai_bm;
    $insertData['must_shenhe']        = $must_shenhe;
    $insertData['address']            = $address;
    $insertData['latitude']           = $latitude;
    $insertData['longitude']          = $longitude;
    $insertData['bm_start_time']      = $bm_start_time;
    $insertData['bm_end_time']        = $bm_end_time;
    $insertData['hd_start_time']      = $hd_start_time;
    $insertData['hd_end_time']        = $hd_end_time;
    $insertData['mp3_link']           = $mp3_link;
    $insertData['show_stock_num']     = $show_stock_num;
    $insertData['content']            = $content;
    $insertData['picurl']             = $picurl;
    $insertData['toppic']             = $toppic;
    $insertData['share_title']        = $share_title;
    $insertData['share_desc']         = $share_desc;
    $insertData['status']             = 1;
    if($tchuodongConfig['must_shenhe'] == 1){
        $insertData['shenhe_status']  = 2;
    }else{
        $insertData['shenhe_status']  = 1;
    }
    $insertData['hexiao_pwd']         = $hexiao_pwd;
    $insertData['add_time']           = TIMESTAMP;
    if(C::t('#tom_tchuodong#tom_tchuodong')->insert($insertData)){
        
        $tchuodong_id = C::t('#tom_tchuodong#tom_tchuodong')->insert_id();
        
        $huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
        update_huodong_status($huodongInfoTmp);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['tchuodong_id']  = $tchuodong_id;
                $insertData['picurl']        = $value;
                $insertData['add_time']      = TIMESTAMP;
                C::t('#tom_tchuodong#tom_tchuodong_photo')->insert($insertData);
            }
        }
        
        if($tchuodongConfig['must_shenhe'] == 1){
            
            $huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
            if($huodongInfo['site_id'] == 1){
                $sitename = $tongchengConfig['plugin_name'];
            }else{
                $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($huodongInfo['site_id']);
                $sitename = $siteInfo['name'];
            }
            
            $toUser   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);

            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();

            if($access_token && !empty($toUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchuodong&site={$site_id}&mod=index");
                if($type == 1){
                    $smsData = array(
                        'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tchuodong','shenhe_template_first'),
                        'keyword1'      => $sitename,
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
                        'remark'        => ''
                    );
                }elseif($type == 2){
                    $smsData = array(
                        'first'         => '['.$tcshopInfo['name'].']'.lang('plugin/tom_tchuodong','shenhe_template_first'),
                        'keyword1'      => $sitename,
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
                        'remark'        => ''
                    );
                }
                
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }
        }
        
        $outArr = array(
            'status'        => 200,
            'tchuodong_id'  => $tchuodong_id,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'        => 404,
        );
        echo json_encode($outArr); exit;
    }
}

$cateListTmp = C::t('#tom_tchuodong#tom_tchuodong_cate')->fetch_all_list(""," ORDER BY csort ASC,id DESC ",0,100);
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach ($cateListTmp as $key => $value){
        $cateList[$key] = $value;
    }
}

if($type == 1){
    $personalRenzhengStatus = 0;
    $renzhengPersonalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND shenhe_status = 1 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($renzhengPersonalInfoTmp) && !empty($renzhengPersonalInfoTmp[0])){
        $personalRenzhengStatus = 1;
    }
}

if($type == 2){
    
    $allTcshopCount = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count(" AND user_id={$__UserInfo['id']} ");

    $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$__UserInfo['id']} AND v.open_tchuodong=1 "," ORDER BY s.id DESC ",0,100);
    $tcshopList = array();
    if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
        foreach ($tcshopListTmp as $key => $value){
            $tcshopList[$key] = $value;
        }
    }
    $tcshopCount = count($tcshopList);
}

$renzheng_back_url = $weixinClass->get_url();
$renzheng_back_url = urlencode($renzheng_back_url);
$personalRenzhengUrl = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=personal&renzheng_back={$renzheng_back_url}";

$saveUrl      = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=fabu_step2&act=save";
$myListUrl    = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=myfabu";
$uploadUrl1   = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2   = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=upload&act=toppic&formhash=".FORMHASH;
$uploadUrl3   = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=upload&act=photos&formhash=".FORMHASH;
$wxUploadUrl2 = "plugin.php?id=tom_tchuodong:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchuodong:fabu_step2");