<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$attr_id      = isset($_GET['attr_id'])? intval($_GET['attr_id']):0;
$type         = isset($_GET['type'])? intval($_GET['type']):0;

$attrInfo       = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_by_id($attr_id);
$huodongInfo    = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($attrInfo['tchuodong_id']);

if($__UserInfo['id'] != $huodongInfo['user_id']){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tchuodong&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && submitcheck('attr_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $is_must        = isset($_GET['is_must'])? intval($_GET['is_must']):0;
    $value          = isset($_GET['value'])? addslashes($_GET['value']):'';
    $min_photo_num  = isset($_GET['min_photo_num'])? intval($_GET['min_photo_num']):0;
    $max_photo_num  = isset($_GET['max_photo_num'])? intval($_GET['max_photo_num']):0;
    $unit           = isset($_GET['unit'])? addslashes($_GET['unit']):'';
    $paixu          = isset($_GET['paixu'])? intval($_GET['paixu']):100;
    
    $updateData = array();
    $updateData['name']              = $name;
    $updateData['type']              = $type;
    $updateData['is_must']           = $is_must;
    $updateData['value']             = $value;
    $updateData['min_photo_num']     = $min_photo_num;
    $updateData['max_photo_num']     = $max_photo_num;
    $updateData['unit']              = $unit;
    $updateData['paixu']             = $paixu;
    $updateData['add_time']          = TIMESTAMP;
    
    if(C::t('#tom_tchuodong#tom_tchuodong_attr')->update($attr_id,$updateData)){
        
        echo 200;exit;
        
    }else{
        echo 404;exit;
    }
}

$saveUrl    = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=editattr&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchuodong:editattr");