<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword          = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$huodong_status   = intval($_GET['huodong_status'])>0? intval($_GET['huodong_status']):0;
$cate_id          = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$page             = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize         = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):6;

if($_GET['from'] == 'tongcheng'){
    $tchuodongConfig['index_list_type'] = 1;
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND status = 1 AND shenhe_status = 1  ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($cate_id)){
    $whereStr.= " AND cate_id={$cate_id} ";
}
if(!empty($huodong_status)){
    $whereStr.= " AND huodong_status={$huodong_status} ";
}

$orderStr      = " ORDER BY huodong_status ASC,is_recommend DESC,paixu ASC,id DESC";

$pagesize      = $pagesize;
$start         = ($page - 1)*$pagesize;

$huodongData = C::t('#tom_tchuodong#tom_tchuodong')->fetch_all_like_list($whereStr,$orderStr,$start,$pagesize,$keyword);
$huodongList = array();
if(is_array($huodongData) && !empty($huodongData)){
    foreach($huodongData as $key => $value){
        $huodongList[$key] = $value;

        if(!preg_match('/^http/', $value['picurl'])){
            if(strpos($value['picurl'], 'source/plugin/') === false){
                $huodongList[$key]['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $huodongList[$key]['picurl'] = $value['picurl'];
            }
        }else{
            $huodongList[$key]['picurl'] = $value['picurl'];
        }
        $huodongList[$key]['count']  = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_sun_bm_num(" AND tchuodong_id = {$value['id']} AND order_status IN(2,3)");
        if($value['open_xubuy'] == 1){
            $xubuyListCountTmp  = C::t('#tom_tchuodong#tom_tchuodong_xubuy')->fetch_all_count(" AND tchuodong_id={$value['id']} AND type_id=2 ");
            $huodongList[$key]['count'] = $huodongList[$key]['count'] + $xubuyListCountTmp;
        }
        $huodongList[$key]['clicks']          = $value['clicks'] + $value['virtual_clicks'];
        $huodongList[$key]['hd_start_time']   = dgmdate($value['hd_start_time'], 'Y.m.d',$tomSysOffset);
        $huodongList[$key]['hd_end_time']     = dgmdate($value['hd_end_time'], 'm.d',$tomSysOffset);
        update_huodong_status($value);
    }
}
if(is_array($huodongList) && !empty($huodongList)){
    foreach ($huodongList as $key => $value){
        if($tchuodongConfig['index_list_type'] == 1){
            $outStr.= '<div class="item clearfix">';
                $outStr.= '<a href="plugin.php?id=tom_tchuodong&site='.$site_id.'&mod=details&tchuodong_id='.$value['id'].'">';
                $outStr.= '<div class="pic">';
                        $outStr .= '<img src="'.$value['picurl'].'">';
                $outStr.= '</div>';
                $outStr.= '<div class="content">';
                    $outStr.= '<div class="title">'.$value['title'].'</div>';
                    $outStr.= '<div class="huodongprice">';
                    if($value['show_min_price'] <= 0 ){
                        $outStr .= '<span class="price" style="font-size: 0.95em;color: #0d8000;">'.lang('plugin/tom_tchuodong','index_free').'</span>';
                    }else{
                         $outStr .= '<span class="price">'.lang('plugin/tom_tchuodong','yuan_ico').$value['show_min_price'].'</span>';
                         if($value['open_vip'] == 1){
                            $outStr .= '<i class="tciconfont tcicon-yikatong" style="font-size: 14px;color:#eabe06">'.'</i>'.'<span class="vip_name">'.lang('plugin/tom_tchuodong','yuan_ico').$value['show_min_vip_price'].'</span>';
                         }
                    }
                    $outStr.= '</div>';
                    $outStr.= '<div class="hd_time">';
                        $outStr .= '<span>'.$value['hd_start_time'].' ~ '.$value['hd_end_time'].'</span>';
                    $outStr.= '</div>';
                    $outStr .= '<div class="bminfo clearfix">';
                        $outStr .= '<div class="bminfo_left clearfix">';
                            $outStr .= '<span>'.$value['count'].lang('plugin/tom_tchuodong','index_yibm').'</span>';
                        $outStr .= '</div>';
                        if ($value['huodong_status'] == 1){
                            $outStr .= '<div class="bminfo_right start">';
                        }else{
                            $outStr .= '<div class="bminfo_right">';
                        }
                        if ($value['huodong_status'] == 2){
                            $outStr .= '<span>'.lang('plugin/tom_tchuodong','index_nostart_button').'</span>';
                        }else if($value['huodong_status'] == 3){
                            $outStr .= '<span>'.lang('plugin/tom_tchuodong','index_end_button').'</span>';
                        }else{
                            if($value['show_min_price'] <= 0){
                                $outStr .= '<span>'.lang('plugin/tom_tchuodong','index_free_bm').'</span>';
                            }else{
                                $outStr .= '<span>'.lang('plugin/tom_tchuodong','index_bm').'</span>';
                            }
                        }
                        $outStr .= '</div>';
                    $outStr .= '</div>';
                $outStr.= '</div>';
                $outStr.= '</a>';
                if($value['huodong_status'] == 3){
                    $outStr .= '<div class="bm_over">';
                        $outStr .= '<img src="source/plugin/tom_tchuodong/images/jieshu.png">';
                    $outStr .= '</div>'; 
                }
                if($value['huodong_status'] == 1){
                    if($value['is_recommend'] == 1){
                        $outStr .= '<div class="bm_tuijian">';
                            $outStr .= '<img src="source/plugin/tom_tchuodong/images/tuijian.png">';
                        $outStr .= '</div>'; 
                    }
                }
            $outStr.= '</div>';
        }else if($tchuodongConfig['index_list_type'] == 2){
            $outStr .= '<div class="huodonglist_item">';
                $outStr .= '<a href="plugin.php?id=tom_tchuodong&site='.$site_id.'&mod=details&tchuodong_id='.$value['id'].'">';
                    $outStr .= '<div class="huodonglist_info">';
                        $outStr .= '<div class="huodonglist_item_top">';
                            $outStr .= '<img class="huodong_picurl" src="'.$value['picurl'].'">';
                            if($value['huodong_status'] == 3){
                                $outStr .= '<div class="bm_over">';
                                    $outStr .= '<img src="source/plugin/tom_tchuodong/images/jieshu.png">';
                                $outStr .= '</div>'; 
                            }
                            if($value['huodong_status'] == 1){
                                if($value['is_recommend'] == 1){
                                    $outStr .= '<div class="item-bd__recommend">';
                                        $outStr .= '<img src="source/plugin/tom_tchuodong/images/tuijian.png">';
                                    $outStr .= '</div>'; 
                                }
                            }
                        $outStr .= '</div>';
                        $outStr .= '<div class="huodonglist_item_bottom">';
                            $outStr .= '<div class="title">'.$value['title'].'</div>';
                            $outStr .= '<div class="huodong_bm_top dislay-flex">';
                                $outStr .= '<div class="hd_time">';
                                    $outStr .= '<i class="tciconfont tcicon-shijian" style="font-size:.9em;color:#BFC0C5;padding-right:5px;">' .'</i>';
                                    $outStr .= '<span>'.$value['hd_start_time'].' ~ '.$value['hd_end_time'].'</span>';
                                $outStr .= '</div>';
                                $outStr .= '<div class="hd_bm" style="font-size: 0.8em;">'.$value['count'].lang('plugin/tom_tchuodong','index_yibm').'</div>';
                            $outStr .= '</div>';    
                            $outStr .= '<div class="huodong_bm_bottom dislay-flex">';
                                $outStr .= '<div class="hd_address">';
                                    $outStr .= '<i class="tciconfont tcicon-dingwei" style="font-size:.9em;color:#BFC0C5;padding-right:5px;">' .'</i>';
                                    $outStr .= '<span>'.lang('plugin/tom_tchuodong','index_hd_address').'</span>';
                                    $outStr .= '<span>'.$value['address'].'</span>';
                                $outStr .= '</div>';
                                $outStr .= '<div class="hd_price">';
                                    if($value['show_min_price'] <= 0){
                                        $outStr .= '<span class="price" style="font-size: 0.95em;color: #0d8000;">'.lang('plugin/tom_tchuodong','index_free').'</span>';
                                    }else{
                                        $outStr .= '<span>'.lang('plugin/tom_tchuodong','yuan_ico').'</span>';
                                        $outStr .= '<span class="price">'.$value['show_min_price'].'</span>';
                                    }
                                $outStr .= '</div>';
                            $outStr .= '</div>';
                        $outStr .= '</div>';
                    $outStr .= '</div>';
                $outStr .= '</a>';
            $outStr .= '</div>';
        }else if($tchuodongConfig['index_list_type'] == 3){
            $outStr .= '<a class="list-item__box" href="plugin.php?id=tom_tchuodong&site='.$site_id.'&mod=details&tchuodong_id='.$value['id'].'">';
                $outStr.= '<div class="item-hd">';
                    $outStr.= '<img class="hd_picurl" src="'.$value['picurl'].'">';
                    if($value['huodong_status'] == 3){
                        $outStr .= '<div class="item-bd__bm_over">';
                            $outStr .= '<img src="source/plugin/tom_tchuodong/images/jieshu.png">';
                        $outStr .= '</div>'; 
                    }
                    if($value['huodong_status'] == 1){
                        if($value['is_recommend'] == 1){
                            $outStr .= '<div class="item-bd__recommend">';
                                $outStr .= '<img src="source/plugin/tom_tchuodong/images/tuijian.png">';
                            $outStr .= '</div>'; 
                        }
                    }
                $outStr.= '</div>';
                $outStr.= '<div class="item-bd">';
                    $outStr.= '<div class="item-bd__title">'.$value['title'].'</div>';
                    $outStr.= '<div class="item-bd__bottom dislay-flex">';
                        $outStr.= '<div class="item-bd__price">';
                            if($value['show_min_price'] <= 0){
                                $outStr .= '<span class="price" style="font-size: 0.95em;color: #0d8000;">'.lang('plugin/tom_tchuodong','index_free').'</span>';
                            }else{
                                $outStr .= '<span>'.lang('plugin/tom_tchuodong','yuan_ico').'</span>';
                                $outStr .= '<span class="price">'.$value['show_min_price'].'</span>';
                            }
                        $outStr.= '</div>';
                        $outStr .= '<div class="item-bd__hd_bm">'.$value['count'].lang('plugin/tom_tchuodong','index_yibm').'</div>';
                    $outStr.= '</div>';
                $outStr.= '</div>';
            $outStr.= '</a>';
        }
    }
}else{
    $outStr = '205';
}
$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;