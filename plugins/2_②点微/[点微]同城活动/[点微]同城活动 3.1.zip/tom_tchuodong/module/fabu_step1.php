<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($tchuodongConfig['person_fabu'] == 0){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tchuodong&site={$site_id}&mod=fabu_step2&type=2");exit;
}
    
$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchuodong:fabu_step1");