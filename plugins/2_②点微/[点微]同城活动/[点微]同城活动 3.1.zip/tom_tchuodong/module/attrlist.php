<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tchuodong_id  = isset($_GET['tchuodong_id'])? intval($_GET['tchuodong_id']):0;

$attrListTmp = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list(" AND tchuodong_id={$tchuodong_id}"," ORDER BY paixu ASC,id DESC ",0,50);
$attrList = array();
foreach ($attrListTmp as $key => $value){
    $attrList[$key] = $value;
    $bmattrCount = C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->fetch_all_count(" AND attr_id={$value['id']}");
    $attrList[$key]['bmattrCount']   = $bmattrCount;
}

$ajaxDelattrUrl          = "plugin.php?id=tom_tchuodong:ajax&site={$site_id}&act=delattr&formhash=".$formhash;
$ajaxUpdateAttrStatusUrl = "plugin.php?id=tom_tchuodong:ajax&site={$site_id}&act=updateAttrStatus&&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchuodong:attrlist");