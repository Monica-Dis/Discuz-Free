<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tchuodong`;
CREATE TABLE `pre_tom_tchuodong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `cate_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `yongjin_bili` decimal(10,2) DEFAULT '0.00',
  `picurl` varchar(255) DEFAULT NULL,
  `toppic` varchar(255) DEFAULT NULL,
  `xiangou_num` int(11) DEFAULT '0',
  `bm_start_time` int(11) DEFAULT '0',
  `bm_end_time` int(11) DEFAULT '0',
  `hd_start_time` int(11) DEFAULT '0',
  `hd_end_time` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `show_min_price` decimal(10,2) DEFAULT '0.00',
  `show_max_price` decimal(10,2) DEFAULT '0.00',
  `open_vip` tinyint(4) DEFAULT NULL,
  `show_min_vip_price` decimal(10,2) DEFAULT '0.00',
  `show_max_vip_price` decimal(10,2) DEFAULT '0.00',
  `open_xubuy` int(11) DEFAULT '0',
  `mp3_link` varchar(255) DEFAULT NULL,
  `admin_edit` int(11) DEFAULT '0',
  `content` mediumtext,
  `is_recommend` tinyint(4) DEFAULT '0',
  `fenkai_bm` tinyint(4) DEFAULT '0',
  `must_shenhe` tinyint(4) DEFAULT '0',
  `show_stock_num` tinyint(4) DEFAULT '0',
  `hehuoren_tg_open` int(11) DEFAULT '0',
  `chuji_fc_scale` decimal(10,2) DEFAULT '0.00',
  `zhongji_fc_scale` decimal(10,2) DEFAULT '0.00',
  `gaoji_fc_scale` decimal(10,2) DEFAULT '0.00',
  `share_title` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `clicks` int(11) DEFAULT '0',
  `virtual_bmnum` int(11) DEFAULT '0',
  `virtual_bmstr` text,
  `virtual_clicks` int(11) DEFAULT '0',
  `huodong_status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `hexiao_pwd` varchar(255) DEFAULT NULL,
  `haibao_type` int(11) DEFAULT '1',
  `haibao_picurl` varchar(255) DEFAULT NULL,
  `qrcode_location` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '10000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_cate_id` (`cate_id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_huodong_status` (`huodong_status`),
  KEY `idx_paixu` (`paixu`),
  KEY `idx_is_recommend` (`is_recommend`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchuodong_attr`;
CREATE TABLE `pre_tom_tchuodong_attr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tchuodong_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '1',
  `value` text,
  `is_must` int(11) DEFAULT '0',
  `min_photo_num` int(11) DEFAULT '0',
  `max_photo_num` int(11) DEFAULT '0',
  `unit` varchar(255) DEFAULT NULL,
  `is_hidden` tinyint(4) DEFAULT '0',
  `msg` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchuodong_bm`;
CREATE TABLE `pre_tom_tchuodong_bm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tchuodong_id` int(11) DEFAULT '0',
  `order_id` int(11) DEFAULT '0',
  `option_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `shenhe_status` int(11) DEFAULT '0',
  `bm_status` int(11) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '10000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchuodong_bm_attr`;
CREATE TABLE `pre_tom_tchuodong_bm_attr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bm_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `tchuodong_id` int(11) DEFAULT '0',
  `attr_id` int(11) DEFAULT '0',
  `attr_name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `time_value` int(11) DEFAULT '0',
  `picurl_value` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchuodong_cate`;
CREATE TABLE `pre_tom_tchuodong_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `csort` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchuodong_focuspic`;
CREATE TABLE `pre_tom_tchuodong_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchuodong_option`;
CREATE TABLE `pre_tom_tchuodong_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tchuodong_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `vip_price` decimal(10,2) DEFAULT '0.00',
  `stock_num` int(11) DEFAULT '0',
  `sale_num` int(11) DEFAULT '0',
  `is_hidden` tinyint(4) DEFAULT '0',
  `osort` int(11) DEFAULT '10',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchuodong_order`;
CREATE TABLE `pre_tom_tchuodong_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tcshop_id` int(11) DEFAULT '0',
  `order_no` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `bm_ids` varchar(255) DEFAULT NULL,
  `tchuodong_id` int(11) DEFAULT '0',
  `tchuodong_title` varchar(255) DEFAULT NULL,
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `option_id` int(11) DEFAULT '0',
  `number` int(11) DEFAULT '0',
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `one_price` decimal(10,2) DEFAULT '0.00',
  `use_num` int(11) DEFAULT '0',
  `is_fenkai_bm` tinyint(4) DEFAULT '0',
  `vip_pay_status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `order_status` int(11) DEFAULT '0',
  `balance_status` int(11) DEFAULT '0',
  `refund_type` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `pay_time` int(11) DEFAULT '0',
  `search_txt` text,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_order_status` (`order_status`),
  KEY `idx_tchuodong_id` (`tchuodong_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchuodong_photo`;
CREATE TABLE `pre_tom_tchuodong_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tchuodong_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchuodong_stock_log`;
CREATE TABLE `pre_tom_tchuodong_stock_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_admin` int(11) DEFAULT '0',
  `tchuodong_id` int(11) DEFAULT '1',
  `change_num` int(11) DEFAULT '0',
  `change_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  `is_option` tinyint(4) DEFAULT '0',
  `beizu` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchuodong_xubuy`;
CREATE TABLE `pre_tom_tchuodong_xubuy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) DEFAULT '0',
  `order_id` int(11) DEFAULT '0',
  `tchuodong_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `option_id` int(11) DEFAULT '0',
  `bm_num` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$finish = TRUE;