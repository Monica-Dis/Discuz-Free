<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
loaducenter();
$formhash = FORMHASH;
$tchuodongConfig = $_G['cache']['plugin']['tom_tchuodong'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
$sql_in_site_ids = $site_id;
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login_ajax.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/function.html.php';
include DISCUZ_ROOT . './source/plugin/tom_tchuodong/class/function.core.php';
if ($_GET['act'] == 'list' && $_GET['formhash'] == FORMHASH) {
	include DISCUZ_ROOT . './source/plugin/tom_tchuodong/module/list.php';
} elseif ($_GET['act'] == 'bmlist' && $_GET['formhash'] == FORMHASH) {
	$outStr = '';
	$tchuodong_id = isset($_GET['tchuodong_id']) ? intval($_GET['tchuodong_id']) : 0;
	$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$pagesize = intval($_GET['pagesize']) > 0 ? intval($_GET['pagesize']) : 20;
	$pagesize = $pagesize;
	$start = ($page - 1) * $pagesize;
	$orderListTmp = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_list(' AND tchuodong_id = ' . $tchuodong_id . ' AND order_status IN(2,3)', 'ORDER BY id DESC', $start, $pagesize);
	$orderList = array();
	if ($huodongInfo['open_xubuy'] == 1) {
		if (is_array($orderListTmp) && !empty($orderListTmp)) {
			foreach ($orderListTmp as $key => $value) {
				$xubuyInfoTmp = C::t('#tom_tchuodong#tom_tchuodong_xubuy')->fetch_by_order_id($value['id']);
				if (!$xubuyInfoTmp || $xubuyInfoTmp['id'] <= 0) {
					$insertData = array();
					$insertData['tchuodong_id'] = $value['tchuodong_id'];
					$insertData['type_id'] = 1;
					$insertData['order_id'] = $value['id'];
					$insertData['user_id'] = $value['user_id'];
					$insertData['bm_num'] = $value['number'];
					$insertData['order_time'] = $value['order_time'];
					C::t('#tom_tchuodong#tom_tchuodong_xubuy')->insert($insertData);
				}
			}
		}
		$orderListTmp = array();
		$orderListTmp = C::t('#tom_tchuodong#tom_tchuodong_xubuy')->fetch_all_list(' AND tchuodong_id=' . $tchuodong_id . ' ', ' ORDER BY order_time DESC,id DESC ', $start, $pagesize);
	}
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			$orderList[$key] = $value;
			$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$orderList[$key]['userInfo'] = $userInfoTmp;
			if ($tchuodongConfig['open_hidden_nickname'] == 1) {
				$orderList[$key]['userInfo']['nickname'] = cutstr($userInfoTmp['nickname'], 2, '***');
			}
		}
	}
	if (is_array($orderList) && !empty($orderList)) {
		foreach ($orderList as $key => $val) {
			$outStr .= '<div class="bmlist_item">';
			$outStr .= '<div class="bm_avatar">';
			$outStr .= '<img src="' . $val['userInfo']['picurl'] . '">';
			$outStr .= '</div>';
			$outStr .= '<div class="bminfo">';
			$outStr .= '<span class="name">' . $val['userInfo']['nickname'] . lang('plugin/tom_tchuodong', 'kong') . '</span>';
			$outStr .= '</div>';
			$outStr .= '<div class="order_time">' . dgmdate($val['order_time'], 'm-d', $tomSysOffset) . '</div>';
			$outStr .= '</div>';
		}
	} else {
		$outStr = '205';
	}
	$outStr = tom_link_replace($outStr);
	$outStr = diconv($outStr, CHARSET, 'utf-8');
	echo json_encode($outStr);
	exit(0);
} elseif ($_GET['act'] == 'updateStatus' && submitcheck('tchuodong_id') && $userStatus) {
	$tchuodong_id = isset($_GET['tchuodong_id']) ? intval($_GET['tchuodong_id']) : 0;
	$status = isset($_GET['status']) ? intval($_GET['status']) : 0;
	$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
	if ($huodongInfo['user_id'] != $__UserInfo['id']) {
		echo '404';
		exit(0);
	}
	if ($status == 1) {
		DB::query('UPDATE ' . DB::table('tom_tchuodong') . (' SET status=1 WHERE id=\'' . $tchuodong_id . '\' '), 'UNBUFFERED');
	} elseif ($status == 2) {
		DB::query('UPDATE ' . DB::table('tom_tchuodong') . (' SET status=2 WHERE id=\'' . $tchuodong_id . '\' '), 'UNBUFFERED');
	}
	echo 200;
	exit(0);
} elseif ($_GET['act'] == 'clicks' && $formhash == FORMHASH) {
	$tchuodong_id = intval($_GET['tchuodong_id']) > 0 ? intval($_GET['tchuodong_id']) : 0;
	DB::query('UPDATE ' . DB::table('tom_tchuodong') . (' SET clicks=clicks + 1 WHERE id=\'' . $tchuodong_id . '\' '), 'UNBUFFERED');
	echo 1;
	exit(0);
} elseif ($_GET['act'] == 'get_huodong_search_url' && $_GET['formhash'] == FORMHASH) {
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$url = $_G['siteurl'] . ('plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=index&keyword=') . urlencode(trim($keyword));
	$url = tom_link_replace($url);
	echo $url;
	exit(0);
} elseif ($_GET['act'] == 'get_order_search_url' && $_GET['formhash'] == FORMHASH) {
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$url = $_G['siteurl'] . ('plugin.php?id=tom_tchuodong&site=' . $site_id . '&mod=order&tchuodong_id=' . $tchuodong_id . '&type=' . $type . '&keyword=') . urlencode(trim($keyword));
	$url = tom_link_replace($url);
	echo $url;
	exit(0);
} elseif ($_GET['act'] == 'update_lbs' && $_GET['formhash'] == FORMHASH) {
	$latitude = isset($_GET['latitude']) ? addslashes($_GET['latitude']) : '';
	$longitude = isset($_GET['longitude']) ? addslashes($_GET['longitude']) : '';
	$cookieTime = 86400 * 3;
	dsetcookie('tom_tongcheng_user_latitude', $latitude, $cookieTime);
	dsetcookie('tom_tongcheng_user_longitude', $longitude, $cookieTime);
	echo 200;
	exit(0);
} elseif ($_GET['act'] == 'delattr' && submitcheck('attr_id') && $userStatus) {
	$attr_id = isset($_GET['attr_id']) ? intval($_GET['attr_id']) : 0;
	$attrInfo = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_by_id($attr_id);
	$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($attrInfo['tchuodong_id']);
	if ($huodongInfo['user_id'] != $__UserInfo['id']) {
		$outArr = array('status' => 404);
		echo json_encode($outArr);
		exit(0);
	}
	$attrInfo = C::t('#tom_tchuodong#tom_tchuodong_attr')->delete_by_id($attr_id);
	$outArr = array('status' => 200);
	echo json_encode($outArr);
	exit(0);
} elseif ($_GET['act'] == 'updateAttrStatus' && submitcheck('attr_id') && $userStatus) {
	$attr_id = isset($_GET['attr_id']) ? intval($_GET['attr_id']) : 0;
	$is_hidden = isset($_GET['is_hidden']) ? intval($_GET['is_hidden']) : 0;
	$attrInfo = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_by_id($attr_id);
	$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($attrInfo['tchuodong_id']);
	if ($huodongInfo['user_id'] != $__UserInfo['id']) {
		$outArr = array('status' => 404);
		echo json_encode($outArr);
		exit(0);
	}
	if ($is_hidden == 0) {
		DB::query('UPDATE ' . DB::table('tom_tchuodong_attr') . (' SET is_hidden=0 WHERE id=\'' . $attr_id . '\' '), 'UNBUFFERED');
	} elseif ($is_hidden == 1) {
		DB::query('UPDATE ' . DB::table('tom_tchuodong_attr') . (' SET is_hidden=1 WHERE id=\'' . $attr_id . '\' '), 'UNBUFFERED');
	}
	$outArr = array('status' => 200);
	echo json_encode($outArr);
	exit(0);
} elseif ($_GET['act'] == 'updateOptionStatus' && submitcheck('option_id') && $userStatus) {
	$option_id = isset($_GET['option_id']) ? intval($_GET['option_id']) : 0;
	$is_hidden = isset($_GET['is_hidden']) ? intval($_GET['is_hidden']) : 0;
	$optionInfo = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($option_id);
	$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($optionInfo['tchuodong_id']);
	if ($huodongInfo['user_id'] != $__UserInfo['id']) {
		$outArr = array('status' => 404);
		echo json_encode($outArr);
		exit(0);
	}
	if ($is_hidden == 0) {
		DB::query('UPDATE ' . DB::table('tom_tchuodong_option') . (' SET is_hidden=0 WHERE id=\'' . $option_id . '\' '), 'UNBUFFERED');
	} elseif ($is_hidden == 1) {
		DB::query('UPDATE ' . DB::table('tom_tchuodong_option') . (' SET is_hidden=1 WHERE id=\'' . $option_id . '\' '), 'UNBUFFERED');
	}
	$optionListTmp = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_all_list(' AND tchuodong_id = ' . $optionInfo['tchuodong_id'] . ' AND is_hidden = 0', 'ORDER BY osort ASC,id DESC', 0, 100);
	if (is_array($optionListTmp) && !empty($optionListTmp)) {
		$show_min_price = $show_max_price = $show_min_vip_price = $show_max_vip_price = 0;
		foreach ($optionListTmp as $key => $value) {
			if ($show_min_price == 0) {
				$show_min_price = $value['price'];
				$show_min_vip_price = $value['vip_price'];
			} else {
				if ($value['price'] > 0 && $value['price'] < $show_min_price) {
					$show_min_price = $value['price'];
					$show_min_vip_price = $value['vip_price'];
				}
			}
			if ($show_max_price == 0) {
				$show_max_price = $value['price'];
				$show_max_vip_price = $value['vip_price'];
			} else {
				if ($value['price'] > 0 && $value['price'] > $show_max_price) {
					$show_max_price = $value['price'];
					$show_max_vip_price = $value['vip_price'];
				}
			}
		}
		$updateData = array();
		$updateData['show_min_price'] = $show_min_price;
		$updateData['show_min_vip_price'] = $show_min_vip_price;
		$updateData['show_max_price'] = $show_max_price;
		$updateData['show_max_vip_price'] = $show_max_vip_price;
		$updateData['part1'] = TIMESTAMP;
		C::t('#tom_tchuodong#tom_tchuodong')->update($optionInfo['tchuodong_id'], $updateData);
		$huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($optionInfo['tchuodong_id']);
		update_huodong_status($huodongInfoTmp);
	}
	$outArr = array('status' => 200);
	echo json_encode($outArr);
	exit(0);
} elseif ($_GET['act'] == 'new_order') {
	$callback = $_GET['callback'];
	$tchuodong_id = intval($_GET['tchuodong_id']) > 0 ? intval($_GET['tchuodong_id']) : 0;
	$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
	$orderListTmp = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_list(' AND tchuodong_id=' . $tchuodong_id . ' AND order_status IN(2,3) ', 'ORDER BY id DESC', 0, 6);
	$outOrderInfo = array();
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			$cookieOrderid = getcookie('tom_tchuodong_new_order_id' . $value['id']);
			if (!$cookieOrderid) {
				$outOrderInfo = $value;
				dsetcookie('tom_tchuodong_new_order_id' . $value['id'], 1, 21600);
				break;
			}
		}
	}
	$outArr = array('status' => 0);
	if (!empty($outOrderInfo) && $outOrderInfo['user_id'] > 0) {
		$outArr['status'] = 1;
		$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($outOrderInfo['user_id']);
		$userInfo['nickname'] = cutstr($userInfo['nickname'], 4, '***');
		$outArr['picurl'] = $userInfo['picurl'];
		$outArr['nickname'] = diconv($userInfo['nickname'], CHARSET, 'utf-8');
	}
	$outStr = '';
	$outStr = json_encode($outArr);/*Dism-taobao_com*/
	if ($callback) {
		$outStr = $callback . '(' . $outStr . ')';
	}
	echo $outStr;
	exit(0);
} else {
	echo 'error';
	exit(0);
}