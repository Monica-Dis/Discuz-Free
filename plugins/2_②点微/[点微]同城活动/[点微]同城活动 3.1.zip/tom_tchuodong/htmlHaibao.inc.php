<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);
$tchuodongConfig    = $_G['cache']['plugin']['tom_tchuodong'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';

if('utf-8' != CHARSET) {
    if(defined('IN_MOBILE')) {}else{
        foreach($_POST AS $pk => $pv) {
            if(!is_numeric($pv)) {
                $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
            }
        }
    }
}

$share_url      = isset($_GET['haibao_url'])? daddslashes($_GET['haibao_url']):'';
$tchuodong_id   = isset($_GET['tchuodong_id'])? intval($_GET['tchuodong_id']):0;
$user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;

$huodongInfo = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
$userInfo  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
    include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
}else{
    echo 'QR|phpqrcode';exit;
}

$toppic = '';
if(!preg_match('/^http/', $huodongInfo['toppic']) ){
    if(strpos($huodongInfo['toppic'], 'source/plugin/') === FALSE){
        $toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$huodongInfo['toppic'];
        if(strpos($toppic, $_G['siteurl']) !== false){
            $toppic = str_replace($_G['siteurl'], "", $toppic);
            $toppic = DISCUZ_ROOT.$toppic;
        }
    }else{
        $toppic = DISCUZ_ROOT.$huodongInfo['toppic'];
    }
}else{
    $toppic = $huodongInfo['toppic'];
}

$picurl = '';
if(!preg_match('/^http/', $huodongInfo['picurl'])){
    if(strpos($huodongInfo['picurl'], 'source/plugin/') === false){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$huodongInfo['picurl'];
    }else{
        $picurl = $_G['siteurl'].$huodongInfo['picurl'];
    }
}else{
    $picurl = $huodongInfo['picurl'];
}

$haibao_picurl = '';
if(!preg_match('/^http/', $huodongInfo['haibao_picurl']) ){
    if(strpos($huodongInfo['haibao_picurl'], 'source/plugin/') === FALSE){
        $haibao_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$huodongInfo['haibao_picurl'];
        if(strpos($haibao_picurl, $_G['siteurl']) !== false){
            $haibao_picurl = str_replace($_G['siteurl'], "", $haibao_picurl);
            $haibao_picurl = DISCUZ_ROOT.$haibao_picurl;
        }
    }else{
        $haibao_picurl = DISCUZ_ROOT.$huodongInfo['haibao_picurl'];
    }
}else{
    $haibao_picurl = $huodongInfo['haibao_picurl'];
}

if(strpos($userInfo['picurl'], 'data/attachment/tomwx') !== false){
    $userpic  = $_G['siteurl'].$userInfo['picurl'];
}else if(strpos($userInfo['picurl'], 'uc_server/') !== false){
    $userpic  = $_G['siteurl'].$userInfo['picurl'];
}else{
    $userpic  = $userInfo['picurl'];
}

$toppicImg = DISCUZ_ROOT.'./source/plugin/tom_tchuodong/data/haibao/'.md5($toppic).'_toppic.png';
$toppicUrl = 'source/plugin/tom_tchuodong/data/haibao/'.md5($toppic).'_toppic.png';

$haibaoPicurlImg = DISCUZ_ROOT.'./source/plugin/tom_tchuodong/data/haibao/'.md5($haibao_picurl).'_haibao_picurl.png';
$haibaoPicurlUrl = 'source/plugin/tom_tchuodong/data/haibao/'.md5($haibao_picurl).'_haibao_picurl.png';

$qrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tchuodong/data/haibao/'.md5($share_url).'_qrcode.png';
$qrcodeUrl = 'source/plugin/tom_tchuodong/data/haibao/'.md5($share_url).'_qrcode.png';

$userpicImg = DISCUZ_ROOT.'./source/plugin/tom_tchuodong/data/haibao/'.md5($userpic).'_userpic.png';
$userpicUrl = 'source/plugin/tom_tchuodong/data/haibao/'.md5($userpic).'_userpic.png';

$wxqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tchuodong/data/haibao/'.md5($share_url).'_wxqrcode'.date("Ymd").'.png';
$wxqrcodeUrl = 'source/plugin/tom_tchuodong/data/haibao/'.md5($share_url).'_wxqrcode'.date("Ymd").'.png';

$tempDir = "/source/plugin/tom_tchuodong/data/haibao/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0777); 
}

if(file_exists($toppicImg)){
}else{
    $top_pic_content = file_get_contents($toppic);
    if(false === file_put_contents($toppicImg,$top_pic_content)){
        $toppicImg = $toppic;
    }
}

if(file_exists($haibaoPicurlImg)){
}else if($huodongInfo['haibao_type'] == 2){
    $haibao_picurl_pic_content = file_get_contents($haibao_picurl);
    if(false === file_put_contents($haibaoPicurlImg,$haibao_picurl_pic_content)){
        $haibaoPicurlImg = $haibao_picurl;
    }
}

if(file_exists($userpicImg)){
}else{
    $user_pic_content = file_get_contents($userpic);
    if(false === file_put_contents($userpicImg,$user_pic_content)){
        $userpicImg = $userpic;
    }
}

$outQrcodeUrl = '';
if($tchuodongConfig['open_hb_wxqrcode'] == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_weixin/tom_weixin.inc.php')){
    
    $qrcodeKey  = md5($share_url);
    $qrcodeInfo = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_by_qkey($qrcodeKey);
    $qrcodeId = 0;
    if($qrcodeInfo){
        $qrcodeId = $qrcodeInfo['id'];
        $updateData = array();
        $updateData['title']  = $huodongInfo['title'];
        $updateData['picurl'] = $picurl;
        $updateData['desc']   = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        C::t('#tom_weixin#tom_weixin_qrcode')->update($qrcodeId,$updateData);
    }else{
        
        $qrcodeList = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_all_list(" ","ORDER BY id DESC",0,1);
        $qrcodeId = 100001;
        if(is_array($qrcodeList) && !empty($qrcodeList) && isset($qrcodeList['0']) && $qrcodeList['0']['id']>100000){
            $qrcodeId = $qrcodeList['0']['id']+1;
        }
        
        $insertData = array();
        $insertData['id']       = $qrcodeId;
        $insertData['qkey']     = $qrcodeKey;
        $insertData['title']    = $huodongInfo['title'];
        $insertData['picurl']   = $picurl;
        $insertData['desc']     = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        $insertData['link']     = $share_url;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_weixin#tom_weixin_qrcode')->insert($insertData);
        $qrcodeId = C::t('#tom_weixin#tom_weixin_qrcode')->insert_id();
    }
    
    if(file_exists($wxqrcodeImg)){
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        $access_token = $weixinClass->get_access_token();

        $dateStr = '{"expire_seconds": 2592000, "action_name": "QR_SCENE", "action_info": {"scene": {"scene_id": '.$qrcodeId.'}}}';
        $response   = tom_html_post($dateStr, 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token);
        $returnData = json_decode($response,true);
        if(isset($returnData['ticket']) &&  !empty($returnData['ticket'])){
            $wx_pic_content = tom_html_get('https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$returnData['ticket']);
            if(false === file_put_contents($wxqrcodeImg,$wx_pic_content)){
            }
        }
    }
    
    $outQrcodeUrl = $wxqrcodeUrl;
}else{
    if(file_exists($qrcodeImg)){
    }else{
        QRcode::png($share_url,$qrcodeImg,'H',5,2);
    }
    $outQrcodeUrl = $qrcodeUrl;
}

echo 'OK|'.$toppicUrl.'|'.$outQrcodeUrl.'|'.$userpicUrl.'|'.$haibaoPicurlUrl;exit;

function wx_iconv_recurrence($value) {
	if(is_array($value)) {
		foreach($value AS $key => $val) {
			$value[$key] = wx_iconv_recurrence($val);
		}
	} else {
		$value = diconv($value, 'utf-8', CHARSET);
	}
	return $value;
}