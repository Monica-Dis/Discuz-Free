<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tomSysOffset = getglobal('setting/timeoffset');

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/config/config.utf8.php';
}

$order_status       = isset($_GET['order_status'])? intval($_GET['order_status']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$pagesize           = 1000;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$start              = ($page - 1)*$pagesize;	
$where = "";

if(!empty($order_status)){
    $where.= " AND order_status= {$order_status}";
}
if(!empty($shenhe_status)){
    $where.= " AND shenhe_status= {$shenhe_status}";
}

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    $orderListTmp = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
    $orderList = array();
    foreach ($orderListTmp as $key => $value) {
        
        $orderList[$key]['bm_ids']          = $value['bm_ids'];
        $orderList[$key]['tchuodong_id']    = $value['tchuodong_id'];
        $orderList[$key]['tchuodong_title'] = $value['tchuodong_title'];
        $orderList[$key]['order_no']        = $value['order_no'];
        $orderList[$key]['user_id']         = $value['user_id'];
        $orderList[$key]['tj_hehuoren_id']  = $value['tj_hehuoren_id'];
        $orderList[$key]['option_id']       = $value['option_id'];
        $orderList[$key]['number']          = $value['number'];
        $orderList[$key]['pay_price']       = $value['pay_price'];
        $orderList[$key]['one_price']       = $value['one_price'];
        $orderList[$key]['use_num']         = $value['use_num'];
        $orderList[$key]['is_fenkai_bm']    = $value['is_fenkai_bm'];
        if($value['is_fenkai_bm'] == 1){
            $orderList[$key]['is_fenkai_bm'] = lang('plugin/tom_tchuodong','order_is_fenkai_bm_1');
        }else{
            $orderList[$key]['is_fenkai_bm'] = lang('plugin/tom_tchuodong','order_is_fenkai_bm_2');
        }
        $orderList[$key]['vip_pay_status']  = $value['vip_pay_status'];
        if($value['vip_pay_status'] == 1){
            $orderList[$key]['vip_pay_status'] = lang('plugin/tom_tchuodong','order_vip_pay_status_1');
        }else{
            $orderList[$key]['vip_pay_status'] = lang('plugin/tom_tchuodong','order_vip_pay_status_2');
        }
        $orderList[$key]['order_status']    = $orderStatusArray[$value['order_status']];
        $orderList[$key]['shenhe_status']   = $ordershenheStatusArray[$value['shenhe_status']];
        $orderList[$key]['order_time']      = dgmdate($value['order_time'],"Y-m-d H:i",$tomSysOffset);
        if($value['pay_time'] == 0){
            $orderList[$key]['pay_time']        = "--";
        }else{
            $orderList[$key]['pay_time']        = dgmdate($value['pay_time'],"Y-m-d H:i",$tomSysOffset);
        }
    }

    $bm_id           = lang('plugin/tom_tchuodong','bm_id');
    $tchuodong_id    = lang('plugin/tom_tchuodong','tchuodong_id');
    $index_title     = lang('plugin/tom_tchuodong','index_title');
    $order_no        = lang('plugin/tom_tchuodong','order_no');
    $user_id         = lang('plugin/tom_tchuodong','user_id');
    $tj_huohuoren_id = lang('plugin/tom_tchuodong','order_tj_huohuoren_id');
    $option_id       = lang('plugin/tom_tchuodong','order_option_id');
    $bm_num          = lang('plugin/tom_tchuodong','order_bm_num');
    $pay_price       = lang('plugin/tom_tchuodong','order_pay_price');
    $one_price       = lang('plugin/tom_tchuodong','order_one_price');
    $use_num         = lang('plugin/tom_tchuodong','order_use_num');
    $is_fenkai_bm    = lang('plugin/tom_tchuodong','order_is_fenkai_bm');
    $vip_pay_status  = lang('plugin/tom_tchuodong','orderdodao_vip_pay_status');
    $order_status    = lang('plugin/tom_tchuodong','order_status');
    $shenhe_status   = lang('plugin/tom_tchuodong','order_shenhe_status');
    $order_time      = lang('plugin/tom_tchuodong','order_time');
    $pay_time        = lang('plugin/tom_tchuodong','order_pay_time');

    $listData[] = array($bm_id,$tchuodong_id,$index_title,$order_no,$user_id,$tj_huohuoren_id,$option_id,$bm_num,$pay_price,$one_price,$use_num,$is_fenkai_bm,$vip_pay_status,$order_status,$shenhe_status,$pay_time,$order_time); 
    foreach ($orderList as $v){
        $lineData = array();
        $lineData[] = $v['bm_ids'];
        $lineData[] = $v['tchuodong_id'];
        $lineData[] = $v['tchuodong_title'];
        $lineData[] = $v['order_no'];
        $lineData[] = $v['user_id'];
        $lineData[] = $v['tj_hehuoren_id'];
        $lineData[] = $v['option_id'];
        $lineData[] = $v['number'];
        $lineData[] = $v['pay_price'];
        $lineData[] = $v['one_price'];
        $lineData[] = $v['use_num'];
        $lineData[] = $v['is_fenkai_bm'];
        $lineData[] = $v['vip_pay_status'];
        $lineData[] = $v['order_status'];
        $lineData[] = $v['shenhe_status'];
        $lineData[] = $v['pay_time'];
        $lineData[] = $v['order_time'];
        $listData[] = $lineData;
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=exportHuodongorderlist.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}