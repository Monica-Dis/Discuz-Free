<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tchuodong'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tchuodong&pmod=admin'; 
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tchuodong&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tchuodong&pmod=admin';
$tomSysOffset = getglobal('setting/timeoffset');

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){}else{
    echo " no install https://dism.taobao.com/?@tom_tongcheng.plugin";exit;
}

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/config/config.utf8.php';
}

include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/class/function.a.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/class/function.core.php';

$tchuodongConfig = get_tchuodong_config($pluginid);
$tongchengPlugin = C::t('#tom_tcshop#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$tcyikatongPlugin = C::t('#tom_tcshop#common_plugin')->fetch_by_identifier('tom_tcyikatong');
$tcyikatongConfig = get_plugin_config($tcyikatongPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$Lang = formatLang($Lang);

if($_GET['tmod'] == 'index'){
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/admin/index.php';
}else if($_GET['tmod'] == 'attr'){
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/admin/attr.php';
}else if($_GET['tmod'] == 'bm'){
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/admin/bm.php';
}else if($_GET['tmod'] == 'doDao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/admin/doDao.php';
}else if($_GET['tmod'] == 'orderdoDao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/admin/orderdoDao.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/admin/order.php';
}else if($_GET['tmod'] == 'option'){
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/admin/option.php';
}else if($_GET['tmod'] == 'cate'){
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/admin/cate.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/admin/focuspic.php';
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/admin/addon.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/admin/index.php';
}