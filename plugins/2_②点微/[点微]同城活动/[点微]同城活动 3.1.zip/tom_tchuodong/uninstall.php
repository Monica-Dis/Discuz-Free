<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS pre_tom_tchuodong;
DROP TABLE IF EXISTS pre_tom_tchuodong_attr;
DROP TABLE IF EXISTS pre_tom_tchuodong_bm;
DROP TABLE IF EXISTS pre_tom_tchuodong_bm_attr;
DROP TABLE IF EXISTS pre_tom_tchuodong_cate;
DROP TABLE IF EXISTS pre_tom_tchuodong_focuspic;
DROP TABLE IF EXISTS pre_tom_tchuodong_option;
DROP TABLE IF EXISTS pre_tom_tchuodong_order;
DROP TABLE IF EXISTS pre_tom_tchuodong_photo;
DROP TABLE IF EXISTS pre_tom_tchuodong_stock_log;
DROP TABLE IF EXISTS pre_tom_tchuodong_xubuy;

EOF;

runquery($sql);

$finish = TRUE;