<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$tchuodongConfig    = $_G['cache']['plugin']['tom_tchuodong'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];

## tcyikatong start
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
    $tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $__ShowTcyikatong = 1;
    }
}
## tcyikatong end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$act = isset($_GET['act'])? addslashes($_GET['act']):"pay_price";

if($act == "pay_price" && submitcheck('user_id')){
   
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $number             = isset($_GET['number'])? intval($_GET['number']):1;
    $tchuodong_id       = isset($_GET['tchuodong_id'])? intval($_GET['tchuodong_id']):'';
    $option_id          = isset($_GET['option_id'])? intval($_GET['option_id']):'';
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):'';
    $tj_hehuoren_id     = isset($_GET['tj_hehuoren_id'])? intval($_GET['tj_hehuoren_id']):0;
    
    $huodongInfo    = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($tchuodong_id);
    $userInfo       = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $tcshopInfo     = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($huodongInfo['tcshop_id']);
    
    if($huodongInfo['type'] == 1){
        if(!$huodongInfo || !$userInfo){
            $outArr = array(
                'status'=> 500,
            );
            echo json_encode($outArr); exit;
        }
    }elseif($huodongInfo['type'] == 2){
        if(!$huodongInfo || !$userInfo || empty($tcshopInfo)){
            $outArr = array(
                'status'=> 500,
            );
            echo json_encode($outArr); exit;
        }
    }
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    if($huodongInfo['status'] != 1 || $huodongInfo['shenhe_status'] != 1){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    if($huodongInfo['huodong_status'] == 2 || $huodongInfo['huodong_status'] == 3){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    $optionInfo  = C::t('#tom_tchuodong#tom_tchuodong_option')->fetch_by_id($option_id);
    if(is_array($optionInfo) && !empty($optionInfo)){
        $price          = $optionInfo['price'];
        $vip_price      = $optionInfo['vip_price'];
        $stock_num      = $optionInfo['stock_num'];
        $sale_num       = $optionInfo['sale_num'];
    }else{
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
    $tcyikatongPayStatus = 0;
    if($__ShowTcyikatong == 1 && $huodongInfo['open_vip'] == 1 ){
        $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($userInfo['id']);
        if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
            $tcyikatongPayStatus = 1;
        }
    }
    
    $pay_price = 0;
    if($tcyikatongPayStatus == 1){
        $pay_price = $vip_price;
    }else{
        $pay_price = $price;
    }
    if($pay_price < 0){
         $outArr = array(
            'status'=> 306,
        );
        echo json_encode($outArr); exit;
    }
    
    if($huodongInfo['xiangou_num'] > 0){
        $myHaveOrderCountTmp  = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_sun_bm_num(" AND tchuodong_id={$tchuodong_id} AND user_id={$userInfo['id']} AND order_status IN(1,2,3) ");
        $bm_xiangou_num_tmp = $huodongInfo['xiangou_num'] - $myHaveOrderCountTmp;
        if($number > $bm_xiangou_num_tmp){
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit;
        }
    }
    if($stock_num <= $sale_num){
        $outArr = array(
            'status'=> 309,
        );
        echo json_encode($outArr); exit;
    }
    if($number > ($stock_num - $sale_num)){
        $outArr = array(
            'status'=> 309,
        );
        echo json_encode($outArr); exit;
    }
    
    if($huodongInfo['fenkai_bm'] == 1){
        $bmnumber = $number;
    }else{
        $bmnumber = 1;
    }
    
    $search_txt = '';
    $bmidsArr = array();
    for ($i = 1; $i <= $bmnumber; $i++) {
        
        $xm        = isset($_GET['xm_'.$i])? daddslashes($_GET['xm_'.$i]):'';
        $xm        = dhtmlspecialchars($xm);
        $tel       = isset($_GET['tel_'.$i])? daddslashes($_GET['tel_'.$i]):'';
        $tel       = dhtmlspecialchars($tel);
        
        $search_txt .= $xm.'-'.$tel;
        
        $insertData = array();
        $insertData['tchuodong_id']            = $tchuodong_id;
        $insertData['option_id']               = $option_id;
        $insertData['tcshop_id']               = $huodongInfo['tcshop_id'];
        $insertData['user_id']                 = $user_id;
        $insertData['xm']                      = $xm;
        $insertData['tel']                     = $tel;
        if($huodongInfo['must_shenhe'] == 1){
            $insertData['shenhe_status']       = 2;
        }else{
            $insertData['shenhe_status']       = 1;
        }
        if($pay_price > 0){
            $insertData['bm_status']           = 1;
        }else{
            $insertData['bm_status']           = 2;
        }
        $insertData['add_time']                = TIMESTAMP;
        if(C::t('#tom_tchuodong#tom_tchuodong_bm')->insert($insertData)){

            $bm_id   = C::t('#tom_tchuodong#tom_tchuodong_bm')->insert_id();
            $bmidsArr[] = $bm_id; 

            $attrnameArr = $attrArr = $attrtypeArr = $attrunitArr = $attrpaixuArr = $attrdateArr = array();

            foreach($_GET as $key => $value){
                $value = dhtmlspecialchars($value);
                if(strpos($key, "attrname_".$i.'_') !== false){
                    $attr_id = intval(str_replace('attrname_'.$i.'_','',$key));
                    $attrnameArr[$attr_id] = daddslashes($value);
                }
                if(strpos($key, "attrtype_".$i.'_') !== false){
                    $attr_id = intval(str_replace('attrtype_'.$i.'_','',$key));
                    $attrtypeArr[$attr_id] = daddslashes($value);
                }
                if(strpos($key, "attrpaixu_".$i.'_') !== false){
                    $attr_id = intval(str_replace('attrpaixu_'.$i.'_','',$key));
                    $attrpaixuArr[$attr_id] = daddslashes($value);
                }
                if(strpos($key, "attrunit_".$i.'_') !== false){
                    $attr_id = intval(str_replace('attrunit_'.$i.'_','',$key));
                    $attrunitArr[$attr_id] = daddslashes($value);
                }
                if(strpos($key, "attr_".$i.'_') !== false){
                    $attr_id = intval(str_replace('attr_'.$i.'_','',$key));
                    if(is_array($value)){
                        $valueTmp = implode(" ", $value);
                        $attrArr[$attr_id] = daddslashes($valueTmp);
                    }else{
                        $attrArr[$attr_id] = daddslashes($value);
                    }
                }
                if(strpos($key, "attrdate_".$i.'_') !== false){
                    $attr_id = intval(str_replace('attrdate_'.$i.'_','',$key));
                    $value = str_replace("T", " ", $value);
                    $attrdateArr[$attr_id] = daddslashes($value);
                }
            }
            if(is_array($attrArr) && !empty($attrArr)){
                foreach ($attrArr as $key => $value){
                    $insertData = array();

                    $search_txt .= '-'.$value;
                    
                    $insertData['tchuodong_id'] = $tchuodong_id;
                    $insertData['bm_id']        = $bm_id;
                    $insertData['type_id']      = $attrtypeArr[$key];
                    $insertData['attr_id']      = $key;
                    $insertData['attr_name']    = $attrnameArr[$key];
                    $insertData['value']        = $value;
                    $insertData['unit']         = $attrunitArr[$key];
                    $insertData['paixu']        = $attrpaixuArr[$key];
                    $insertData['add_time']     = TIMESTAMP;
                    C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->insert($insertData);
                }
            }

            if(is_array($attrdateArr) && !empty($attrdateArr)){
                foreach ($attrdateArr as $key => $value){
                    $insertData = array();
                    $insertData['tchuodong_id'] = $tchuodong_id;
                    $insertData['bm_id']        = $bm_id;
                    $insertData['type_id']      = $attrtypeArr[$key];
                    $insertData['attr_id']      = $key;
                    $insertData['attr_name']    = $attrnameArr[$key];
                    $insertData['value']        = $value;
                    $insertData['time_value']   = strtotime($value);
                    $insertData['unit']         = $attrunitArr[$key];
                    $insertData['paixu']        = $attrpaixuArr[$key];
                    $insertData['add_time']     = TIMESTAMP;
                    C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->insert($insertData);
                }
            }

            $attrList = C::t('#tom_tchuodong#tom_tchuodong_attr')->fetch_all_list("AND tchuodong_id = {$tchuodong_id} AND type = 6 AND is_hidden = 0","ORDER BY paixu ASC,id DESC");
            if(is_array($attrList) && !empty($attrList)){
                foreach ($attrList as $key => $value){
                    $value['photo'] = $_GET['photo_'.$value['id'].'_'.$i];
                    if(is_array($value['photo']) && !empty($value['photo'])){
                        foreach ($value['photo'] as $k => $v){
                            $insertData = array();
                            $insertData['tchuodong_id'] = $tchuodong_id;
                            $insertData['bm_id']        = $bm_id;
                            $insertData['type_id']      = $value['type'];
                            $insertData['attr_id']      = $value['id'];
                            $insertData['attr_name']    = $value['name'];
                            $insertData['value']        = dhtmlspecialchars(daddslashes($v));
                            $insertData['picurl_value'] = dhtmlspecialchars(daddslashes($v));
                            $insertData['unit']         = $value['unit'];
                            $insertData['paixu']        = $value['paixu'];
                            $insertData['add_time']     = TIMESTAMP;
                            C::t('#tom_tchuodong#tom_tchuodong_bm_attr')->insert($insertData);

                        }
                    }
                }
            }
        }
    }
    
    $bmIdsList = array();
    if(is_array($bmidsArr) && !empty($bmidsArr)){
        foreach($bmidsArr as $key => $value){
            $id = intval($value);
            if($id > 0){
                $bmIdsList[] = $id;
            }
        }
    }
    $bmIds = implode('|', $bmIdsList);
    
    $one_price  = $pay_price;
    $pay_price  = $pay_price*$number;
    $openid     = $userInfo['openid'];
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
    if($tcshopInfo && $tcshopInfo['id'] > 0){
        $insertData['tcshop_id']        = $tcshopInfo['id'];
    }
    $insertData['tchuodong_id']     = $tchuodong_id;
    $insertData['tchuodong_title']  = $huodongInfo['title'];
    $insertData['user_id']          = $user_id;
    $insertData['bm_ids']           = $bmIds;
    $insertData['option_id']        = $option_id;
    $insertData['number']           = $number;
    $insertData['order_no']         = $order_no;
    $insertData['pay_price']        = $pay_price;
    $insertData['one_price']        = $one_price;
    if($tcyikatongPayStatus == 1){
        $insertData['vip_pay_status'] = 1;
    }
    if($huodongInfo['must_shenhe'] == 1){
        $insertData['shenhe_status']    = 2;
    }else{
        $insertData['shenhe_status']    = 1;
    }
    if($pay_price > 0){
        $insertData['order_status']     = 1;
    }else{
        $insertData['order_status']     = 2;
        $insertData['pay_time']         = TIMESTAMP;
    }
    if($huodongInfo['fenkai_bm'] == 1){
        $insertData['is_fenkai_bm']     = 1;
    }else{
        $insertData['is_fenkai_bm']     = 0;
    }
    $insertData['search_txt']      = $search_txt.'-'.$order_no;
    $insertData['order_time']      = TIMESTAMP;
    if(C::t('#tom_tchuodong#tom_tchuodong_order')->insert($insertData)){
        
        $order_id    = C::t('#tom_tchuodong#tom_tchuodong_order')->insert_id();
        
        DB::query("UPDATE ".DB::table('tom_tchuodong_option')." SET sale_num=sale_num+{$number} WHERE id='{$option_id}' ", 'UNBUFFERED');
        
        $bmIds = str_replace('|',',',$bmIds);
    
        DB::query("UPDATE ".DB::table('tom_tchuodong_bm')." SET order_id = {$order_id} WHERE id IN ({$bmIds}) ", 'UNBUFFERED');
        
        if($pay_price > 0 ){
            
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tchuodong';          
            $insertData['order_no']        = $order_no;                 
            $insertData['goods_id']        = $tchuodong_id;         
            $insertData['goods_name']      = $huodongInfo['title'];
            $insertData['goods_url']       = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=details&tchuodong_id={$tchuodong_id}";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=myorder";
            $insertData['fail_back_url']   = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=myorder"; 
            $insertData['allow_alipay']    = 1;    
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'    => 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 401,
                );
                echo json_encode($outArr); exit;
            }
            
        }else{
            
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
            $appid = trim($tongchengConfig['wxpay_appid']);
            $appsecret = trim($tongchengConfig['wxpay_appsecret']);
            $weixinClass = new weixinClass($appid,$appsecret);
            $access_token = $weixinClass->get_access_token();

            if($huodongInfo['type']== 1){
                $toUser        = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($huodongInfo['user_id']);
            }elseif($huodongInfo['type']== 2){
                $tcshopInfoTmp     = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($huodongInfo['tcshop_id']);
                $toUser        = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfoTmp['user_id']);
            }
            
            $smsFirst       = '['.$userInfo['nickname'].']'.lang('plugin/tom_tchuodong','huodong_template_first');
            $smsUrl         = $_G['siteurl']."plugin.php?id=tom_tchuodong&site={$site_id}&mod=order&tchuodong_id=".$huodongInfo['id'];
            
            if($access_token && !empty($toUser['openid'])){
                $templateSmsClass = new templateSms($access_token, $smsUrl);
                $smsData = array(
                    'first'         => $smsFirst,
                    'keyword1'      => $tongchengConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }
            $outArr = array(
                'status'=> 200,
            );
            echo json_encode($outArr); exit;
            
        }
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
  
}else if($act == "pay" && submitcheck('order_no')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $order_no   = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
    
    $orderInfo    = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_order_no($order_no);
    $huodongInfo  = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($orderInfo['tchuodong_id']);
    
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    if($orderInfo && $orderInfo['order_status'] == 1){
        
        DB::query("UPDATE ".DB::table('tom_tchuodong_order')." SET order_no='{$order_no}' WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tchuodong';          
        $insertData['order_no']        = $order_no;                 
        $insertData['goods_id']        = $orderInfo['tchuodong_id'];         
        $insertData['goods_name']      = $huodongInfo['title'];
        $insertData['goods_url']       = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=details&tchuodong_id={$orderInfo['tchuodong_id']}";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=myorder";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tchuodong&site={$site_id}&mod=myorder"; 
        $insertData['allow_alipay']    = 1;    
        $insertData['pay_price']       = $orderInfo['pay_price'];
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        C::t('#tom_pay#tom_pay_order')->insert($insertData);
        
        $outArr = array(
            'status'    => 200,
            'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }

}else if($act == "cancelpay" && submitcheck('order_no')){
    
    $order_no  = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
    
    $orderInfo = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_order_no($order_no);
    
    if($orderInfo && $orderInfo['order_status'] == 1){
        
        DB::query("UPDATE ".DB::table('tom_tchuodong_order')." SET order_status=4 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
        
        $bmIds = str_replace('|',',',$orderInfo['bm_ids']);
        DB::query("UPDATE ".DB::table('tom_tchuodong_bm')." SET bm_status=4 WHERE id IN ({$bmIds}) ", 'UNBUFFERED');
        if($orderInfo['option_id'] > 0){
            DB::query("UPDATE ".DB::table('tom_tchuodong_option')." SET sale_num=sale_num-{$orderInfo['number']} WHERE id='{$orderInfo['option_id']}' ", 'UNBUFFERED');
        }
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}