<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.cn
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tchuodongConfig    = $_G['cache']['plugin']['tom_tchuodong'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset       = getglobal('setting/timeoffset');

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end

$orderInfo = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_by_order_no($order_no);
if($orderInfo && $orderInfo['order_status'] == 1){
    
    $updateData = array();
    $updateData['order_status']  = 2;
    $updateData['pay_time'] = TIMESTAMP;
    C::t('#tom_tchuodong#tom_tchuodong_order')->update($orderInfo['id'],$updateData);
    
    $bmIds = str_replace('|',',',$orderInfo['bm_ids']);
    
    DB::query("UPDATE ".DB::table('tom_tchuodong_bm')." SET bm_status=2 WHERE id IN ({$bmIds}) ", 'UNBUFFERED');

    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($orderInfo['order_no'])));
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
    
    if($tchuodongConfig['open_back_score'] == 1){
        
        $score_yuan = $tongchengConfig['score_yuan'];
        if(!empty($tchuodongConfig['score_yuan'])){
            $score_yuan = $tchuodongConfig['score_yuan'];
        }
        
        $score = ceil($orderInfo['pay_price']*$score_yuan);
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] + $score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $orderInfo['user_id'];
        $insertData['score_value']      = $score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 33;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);

    }
    
    if($orderInfo['balance_status'] == 0 && $orderInfo['tj_hehuoren_id'] > 0){
        include DISCUZ_ROOT.'./source/plugin/tom_tchuodong/module/yu_balance.php';
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $appid = trim($tongchengConfig['wxpay_appid']);
    $appsecret = trim($tongchengConfig['wxpay_appsecret']);
    $weixinClass = new weixinClass($appid,$appsecret);
    $access_token = $weixinClass->get_access_token();

    $tchuodongInfoTmp  = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($orderInfo['tchuodong_id']);
    if($tchuodongInfoTmp['type']== 1){
        $toUser        = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tchuodongInfoTmp['user_id']);
    }elseif($tchuodongInfoTmp['type']== 2){
        $tcshopInfoTmp     = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);
        $toUser        = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfoTmp['user_id']);
    }
    
    $smsFirst       = '['.$userInfo['nickname'].']'.lang('plugin/tom_tchuodong','huodong_template_first');
    $smsUrl         = $_G['siteurl']."plugin.php?id=tom_tchuodong&site={$site_id}&mod=order&tchuodong_id=".$tchuodongInfoTmp['id'];
   
    if($access_token && !empty($toUser['openid'])){
        $templateSmsClass = new templateSms($access_token, $smsUrl);
        $smsData = array(
            'first'         => $smsFirst,
            'keyword1'      => $tongchengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
    }
}