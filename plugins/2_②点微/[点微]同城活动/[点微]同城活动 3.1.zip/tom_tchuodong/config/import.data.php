<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$cateArr = array();

$cateArr[1] = array(
    'name'      => '����/����',
    'picurl'    => 'source/plugin/tom_tchuodong/images/cate/cate_1.png',
);
$cateArr[2] = array(
    'name'      => '����',
    'picurl'    => 'source/plugin/tom_tchuodong/images/cate/cate_2.png',
);
$cateArr[3] = array(
    'name'      => '����',
    'picurl'    => 'source/plugin/tom_tchuodong/images/cate/cate_3.png',
);
$cateArr[4] = array(
    'name'      => '����',
    'picurl'    => 'source/plugin/tom_tchuodong/images/cate/cate_4.png',
);
$cateArr[5] = array(
    'name'      => '����',
    'picurl'    => 'source/plugin/tom_tchuodong/images/cate/cate_5.png',
);
$cateArr[6] = array(
    'name'      => '�������',
    'picurl'    => 'source/plugin/tom_tchuodong/images/cate/cate_6.png',
);
$cateArr[7] = array(
    'name'      => '��������',
    'picurl'    => 'source/plugin/tom_tchuodong/images/cate/cate_7.png',
);
$cateArr[8] = array(
    'name'      => '����',
    'picurl'    => 'source/plugin/tom_tchuodong/images/cate/cate_8.png',
);
$cateArr[9] = array(
    'name'      => '����',
    'picurl'    => 'source/plugin/tom_tchuodong/images/cate/cate_9.png',
);
$cateArr[10] = array(
    'name'      => '����',
    'picurl'    => 'source/plugin/tom_tchuodong/images/cate/cate_10.png',
);

if (CHARSET == 'utf-8') {
    $cateArr = tom_iconv($cateArr,'gbk','utf-8');
}