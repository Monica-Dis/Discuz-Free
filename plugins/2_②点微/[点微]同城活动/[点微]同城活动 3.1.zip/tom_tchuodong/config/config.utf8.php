<?php

 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$orderStatusArray = array(
    1 => '待支付',
    2 => '已支付',
    3 => '已完成',
    4 => '已取消',
    5 => '已退款',
);

$orderStatusColorArray = array(
    1 => '#fd0d0d',
    2 => '#238206',
    3 => '#0894fb',
    4 => '#8e8e8e',
    5 => '#fd0d0d',
);

$bmStatusArray = array(
    1 => '待支付',
    2 => '已支付',
    3 => '已完成',
    4 => '已取消',
    5 => '已退款',
);

$bmStatusColorArray = array(
    1 => '#fd0d0d',
    2 => '#238206',
    3 => '#0894fb',
    4 => '#8e8e8e',
    5 => '#8e8e8e',
);

$ordershenheStatusArray = array(
    1 => '审核通过',
    2 => '待审核',
    3 => '未通过',
);

$bmshenheStatusArray = array(
    1 => '审核通过',
    2 => '待审核',
    3 => '未通过',
);

$attrTypeArray = array(
    1 => '普通文本',
    2 => '下拉选择',
    3 => '时间输入',
    4 => '多选输入',
    5 => '数字输入',
    6 => '图片',
);