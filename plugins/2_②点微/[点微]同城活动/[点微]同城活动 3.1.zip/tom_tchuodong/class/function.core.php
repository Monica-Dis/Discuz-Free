<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


function wx_iconv_recurrence($value) {
    if(is_array($value)) {
        foreach($value AS $key => $val) {
            $value[$key] = wx_iconv_recurrence($val);
        }
    } else {
        $value = diconv($value, 'utf-8', CHARSET);
    }
    return $value;
}

function number_float($number=0.00 , $num=2){
    if($number > 0){
        $number = floatval(number_format($number, $num, '.' ,''));
    }
    return $number;
}

function update_huodong_status($huodongInfo = array()){
    
    $huodong_status = 1;
    
    if(TIMESTAMP < $huodongInfo['bm_start_time']){
        $huodong_status = 2;
    }

    if(TIMESTAMP > $huodongInfo['bm_end_time']){
        $huodong_status = 3;
    }

    if($huodongInfo['hd_end_time'] < TIMESTAMP){
        $huodong_status = 3;
    }
    
    if($huodong_status != $huodongInfo['huodong_status']){
        $updateData  = array();
        $updateData['huodong_status']  = $huodong_status;
        C::t('#tom_tchuodong#tom_tchuodong')->update($huodongInfo['id'],$updateData);
    }
    
    return $huodong_status;
}