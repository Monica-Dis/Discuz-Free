<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = '';

$tom_tchuodong_field = C::t('#tom_tchuodong#tom_tchuodong')->fetch_all_field();
if (!isset($tom_tchuodong_field['show_stock_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tchuodong')." ADD `show_stock_num` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tchuodong_field['virtual_bmstr'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tchuodong')." ADD `virtual_bmstr` text;\n";
}
if (!isset($tom_tchuodong_field['open_xubuy'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tchuodong')." ADD `open_xubuy` int(11) DEFAULT '0';\n";
}

$tom_tchuodong_order_field = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_field();
if (!isset($tom_tchuodong_order_field['refund_type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tchuodong_order')." ADD `refund_type` int(11) DEFAULT '0';\n";
}

runquery($sql);

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_tom_tchuodong_xubuy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) DEFAULT '0',
  `order_id` int(11) DEFAULT '0',
  `tchuodong_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `option_id` int(11) DEFAULT '0',
  `bm_num` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$finish = TRUE;