<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcsign'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcsign&pmod=admin';
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcsign&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcsign&pmod=admin';

$tomSysOffset = getglobal('setting/timeoffset');

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/config/config.utf8.php';
}

include DISCUZ_ROOT.'./source/plugin/tom_tcsign/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcsign/class/function.admin.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcsign/class/function.core.php';
$tcsignConfig = get_tcsign_config($pluginid);
$Lang = formatLang($Lang);

$tongchengPlugin = C::t('#tom_tcsign#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

if($_GET['tmod'] == 'goods'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/admin/goods.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/admin/order.php';
}else if($_GET['tmod'] == 'sign'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/admin/sign.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/admin/focuspic.php';
}else if($_GET['tmod'] == 'cate'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/admin/cate.php';
}else if($_GET['tmod'] == 'code'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/admin/code.php';
}else if($_GET['tmod'] == 'doDao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/admin/doDao.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/admin/goods.php';
}