<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

/**
   1 ������ 2 ������  3 ���ջ�  4 ��ǩ�� 5 ������ȡ��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$tcsignConfig       = $_G['cache']['plugin']['tom_tcsign'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset       = getglobal('setting/timeoffset');

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$act = isset($_GET['act'])? addslashes($_GET['act']):"order";

if($act == "order" && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $address_id     = isset($_GET['address_id'])? intval($_GET['address_id']):0;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $xm             = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $order_beizu    = isset($_GET['order_beizu'])? daddslashes($_GET['order_beizu']):'';
    $goods_num      = intval($_GET['goods_num'])>0? intval($_GET['goods_num']):1;
    
    $goodsInfo  = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_by_id($goods_id);
    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    $addressInfo = array('xm'=>'','tel'=>'','area_str'=>'','info'=>'');
    if($address_id > 0){
        $addressInfo = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
    }
    
    if(empty($userInfo) || empty($goodsInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['buy_score'] <= 0){
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['stock_num'] <= $goodsInfo['sale_num']){
        $outArr = array(
            'status'=> 309,
        );
        echo json_encode($outArr); exit;
    }
    if($goods_num > ($goodsInfo['stock_num'] - $goodsInfo['sale_num'])){
        $outArr = array(
            'status'=> 309,
        );
        echo json_encode($outArr); exit;
    }
    
    $pay_price     = $goodsInfo['buy_price']*$goods_num;
    $pay_score     = $goodsInfo['buy_score']*$goods_num;
    
    if($pay_score > $userInfo['score']){
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['xiangou_num'] > 0){
        $sun_goods_num = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_sun_goods_num(" AND user_id={$user_id} AND goods_id = {$goods_id} AND order_status IN(2,3,4)");
        $new_sun_goods_num = $sun_goods_num + $goods_num;
        if($new_sun_goods_num > $goodsInfo['xiangou_num']){
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $openid     = $userInfo['openid'];
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    if($goodsInfo['tcshop_id'] > 0){
        $insertData['tcshop_id']        = $goodsInfo['tcshop_id'];
    }
    $insertData['order_no']         = $order_no;
    $insertData['goods_id']         = $goods_id;
    $insertData['goods_title']      = $goodsInfo['title'];
    $insertData['user_id']          = $user_id;
    $insertData['pay_price']        = $pay_price;
    $insertData['pay_score']        = $pay_score;
    $insertData['goods_num']        = $goods_num;
    if($goodsInfo['peisong_type'] == 3){
        $insertData['xm']               = $addressInfo['xm'];
        $insertData['tel']              = $addressInfo['tel'];
        $insertData['address']          = $addressInfo['area_str']." ".$addressInfo['info'];  
    }else{
        $insertData['xm']               = $xm;
        $insertData['tel']              = $tel;
        $insertData['address']          = '';
    }
    if($pay_price > 0 ){
        $insertData['order_status']     = 1;
    }else{
        $insertData['order_status']     = 2;
        $insertData['pay_time']         = TIMESTAMP;
    }
    $insertData['peisong_type']     = $goodsInfo['peisong_type'];
    $insertData['order_beizu']      = $order_beizu;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcsign#tom_tcsign_goods_order')->insert($insertData)){
        
        $order_id = C::t('#tom_tcsign#tom_tcsign_goods_order')->insert_id();
        
        DB::query("UPDATE ".DB::table('tom_tcsign_goods')." SET sale_num=sale_num+{$goods_num} WHERE id='{$goodsInfo['id']}' ", 'UNBUFFERED');
        
        if($pay_price > 0 ){
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcsign';          
            $insertData['order_no']        = $order_no;                 
            $insertData['goods_id']        = $goodsInfo['id'];         
            $insertData['goods_name']      = $goodsInfo['title'];      
            $insertData['goods_beizu']     = $goodsInfo['title'];
            $insertData['goods_url']       = "plugin.php?id=tom_tcsign&site={$site_id}&mod=goodsbuy&goods_id={$goodsInfo['id']}";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tcsign&site={$site_id}&mod=myorder";
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcsign&site={$site_id}&mod=myorder";
            $insertData['allow_alipay']    = 1;    
            $insertData['pay_price']       = $pay_price;  
            $insertData['order_status']    = 1;             
            $insertData['add_time']        = TIMESTAMP;     
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'    => 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 308,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            
            $updateData = array();
            $updateData['score'] = $userInfo['score'] - $pay_score;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
            
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['score_value']      = $pay_score;
            $insertData['old_value']        = $userInfo['score'];
            $insertData['log_type']         = 23;
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
            
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
            $appid = trim($tongchengConfig['wxpay_appid']);
            $appsecret = trim($tongchengConfig['wxpay_appsecret']);
            $weixinClass = new weixinClass($appid,$appsecret);
            $access_token = $weixinClass->get_access_token();
            
            if($goodsInfo['peisong_type'] == 1 && $goodsInfo['tcshop_id'] > 0){
                $tcshopInfoTmp  = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
                $toUser         = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfoTmp['user_id']);
                $smsUrl         = $_G['siteurl']."plugin.php?id=tom_tcsign&site={$site_id}&mod=goodsinfo&goods_id=".$goodsInfo['id'];
                $smsFirst       = '['.$tcshopInfoTmp['name'].']'.lang('plugin/tom_tcsign','duihuan_template_first');
            }else{
                $toUser         = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
                $smsUrl         = $_G['siteurl']."plugin.php?id=tom_tcsign&site={$site_id}&mod=index";
                $smsFirst       = lang('plugin/tom_tcsign','duihuan_template_first');
            }
            
            if($access_token && !empty($toUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $smsUrl);
                $smsData = array(
                    'first'         => $smsFirst,
                    'keyword1'      => $tongchengConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }

            $outArr = array(
                'status'=> 201,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 307,
        );
        echo json_encode($outArr); exit;
    }
}else if($_GET['act'] == "cancelpay" && $_GET['formhash'] == FORMHASH){
    
    $order_no  = isset($_GET['order_no'])? addslashes($_GET['order_no']):'';

    $orderInfo = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_by_order_no($order_no);
    
    if($orderInfo && $orderInfo['order_status'] == 1){
        
        DB::query("UPDATE ".DB::table('tom_tcsign_goods')." SET sale_num=sale_num-{$orderInfo['goods_num']} WHERE id='{$orderInfo['goods_id']}' ", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tcsign_goods_order')." SET order_status=5 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}