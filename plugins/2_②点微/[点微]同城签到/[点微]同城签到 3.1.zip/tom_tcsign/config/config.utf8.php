<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$orderStatusArray = array(
    1 => '待付款',
    2 => '待发货',
    3 => '待收货',
    4 => '已签收',
    5 => '交易已取消',
);

$orderStatusColorArray = array(
    1 => '#fd0303',
    2 => '#1e9203',
    3 => '#0894fb',
    4 => '#ff6203',
    5 => '#fd0303',
);