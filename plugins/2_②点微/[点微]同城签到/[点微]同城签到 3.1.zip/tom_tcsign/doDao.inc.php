<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcsign/config/config.utf8.php';
}

$order_status    = isset($_GET['order_status'])? intval($_GET['order_status']):0;

$pagesize   = 1000;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$start      = ($page-1)*$pagesize;	
$where = "";

if(!empty($order_status)){
    $where.= " AND order_status= {$order_status}";
}

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    $orderListTmp = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
    $orderList = array();
    foreach ($orderListTmp as $key => $value) {
        $orderList[$key] = $value;
        
        $orderList[$key]['order_no']             = $value['order_no'];
        $orderList[$key]['goods_id']             = $value['goods_id'];
        $orderList[$key]['goods_title']          = $value['goods_title'];
        $orderList[$key]['goods_num']            = $value['goods_num'];
        $orderList[$key]['user_id']              = $value['user_id'];
        $orderList[$key]['xm']                   = $value['xm'];
        $orderList[$key]['tel']                  = $value['tel'];
        $orderList[$key]['address']              = $value['address'];
        $orderList[$key]['pay_price']            = $value['pay_price'];
        $orderList[$key]['pay_score']            = $value['pay_score'];
        $orderList[$key]['order_beizu']          = $value['order_beizu'];
        $orderList[$key]['order_status']         = $orderStatusArray[$value['order_status']];
        $orderList[$key]['express_name']         = $value['express_name'];
        $orderList[$key]['express_no']           = $value['express_no'];
        if($value['peisong_time'] > 0){
            $orderList[$key]['peisong_time']     = dgmdate($value['peisong_time'],"Y-m-d H:i:s");
        }else{
            $orderList[$key]['peisong_time']     = '-';
        }
        $orderList[$key]['order_time']           = dgmdate($value['order_time'],"Y-m-d H:i:s");
        $orderList[$key]['pay_time']             = dgmdate($value['pay_time'],"Y-m-d H:i:s");
        if($value['hexiao_user_id'] > 0){
            $orderList[$key]['hexiao_user_id']   = $value['hexiao_user_id'];
        }else{
            $orderList[$key]['hexiao_user_id']   = '-';
        }
        if($value['hexiao_time'] > 0){
            $orderList[$key]['hexiao_time']      = dgmdate($value['hexiao_time'],"Y-m-d H:i:s");
        }else{
            $orderList[$key]['hexiao_time']      = '-';
        }
        if($value['peisong_type'] == 1){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tcsign','goods_peisong_type_1');
        }else if($value['peisong_type'] == 2){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tcsign','goods_peisong_type_2');
        }else if($value['peisong_type'] == 3){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tcsign','goods_peisong_type_3');
        }else{
            $orderList[$key]['peisong_type'] = '-';
        }
    }
    
    $item_order_no                 = lang('plugin/tom_tcsign','order_no');
    $item_goods_id                 = lang('plugin/tom_tcsign','order_goods_id');
    $item_goods_title              = lang('plugin/tom_tcsign','order_goods_title');
    $item_goods_num                = lang('plugin/tom_tcsign','order_goods_num');
    $item_user_id                  = lang('plugin/tom_tcsign','order_user_id');
    $item_xm                       = lang('plugin/tom_tcsign','order_xm');
    $item_tel                      = lang('plugin/tom_tcsign','order_tel');
    $item_address                  = lang('plugin/tom_tcsign','order_address');
    $item_pay_price                = lang('plugin/tom_tcsign','order_pay_price');
    $item_pay_score                = lang('plugin/tom_tcsign','order_pay_score');
    $order_beizu                   = lang('plugin/tom_tcsign','order_beizu');
    $item_order_status             = lang('plugin/tom_tcsign','order_status');
    $item_peisong_type             = lang('plugin/tom_tcsign','goods_peisong_type');
    $item_express_name             = lang('plugin/tom_tcsign','order_express_name');
    $item_express_no               = lang('plugin/tom_tcsign','order_express_no');
    $item_peisong_time             = lang('plugin/tom_tcsign','order_peisong_time');
    $item_order_time               = lang('plugin/tom_tcsign','order_order_time');
    $item_pay_time                 = lang('plugin/tom_tcsign','order_pay_time');
    $item_order_hexiao_user_id     = lang('plugin/tom_tcsign','order_hexiao_user_id');
    $item_hexiao_time              = lang('plugin/tom_tcsign','order_hexiao_time');
  
    $listData[] = array($item_order_no,$item_goods_id,$item_goods_title,$item_goods_num,$item_user_id,$item_xm,$item_tel,$item_address,$item_pay_price,$item_pay_score,$order_beizu,$item_order_status,$item_peisong_type,$item_express_name,$item_express_no,$item_peisong_time,$item_order_time,$item_pay_time,$item_order_hexiao_user_id,$item_hexiao_time); 
    foreach ($orderList as $v){
        $lineData = array();
        $lineData[] = $v['order_no'];
        $lineData[] = $v['goods_id'];
        $lineData[] = $v['goods_title'];
        $lineData[] = $v['goods_num'];
        $lineData[] = $v['user_id'];
        $lineData[] = $v['xm'];
        $lineData[] = '\''.$v['tel'];
        $lineData[] = $v['address'];
        $lineData[] = $v['pay_price'];
        $lineData[] = $v['pay_score'];
        $lineData[] = $v['order_beizu'];
        $lineData[] = $v['order_status'];
        $lineData[] = $v['peisong_type'];
        $lineData[] = $v['express_name'];
        $lineData[] = $v['express_no'];
        $lineData[] = $v['peisong_time'];
        $lineData[] = $v['order_time'];
        $lineData[] = $v['pay_time'];
        $lineData[] = $v['hexiao_user_id'];
        $lineData[] = $v['hexiao_time'];
        $listData[] = $lineData;
    }
  
  header("Content-Type: application/vnd.ms-excel");
  header("Content-Disposition:filename=exportTcsign.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}