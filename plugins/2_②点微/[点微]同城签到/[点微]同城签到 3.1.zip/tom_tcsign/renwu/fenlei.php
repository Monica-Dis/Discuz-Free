<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

$renwuYear      = dgmdate($_G['timestamp'], 'Y',$tomSysOffset);
$renwuMonth     = dgmdate($_G['timestamp'], 'n',$tomSysOffset);
$renwuDay       = dgmdate($_G['timestamp'], 'j',$tomSysOffset);
$renwuDayTime   = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

if($__UserInfo['id'] > 0 && $tcsignConfig['renwu_open_fenlei'] == 1 && $tcsignConfig['renwu_fenlei_score'] > 0){
    
    $todayRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count("AND user_id = {$__UserInfo['id']} AND renwu_type = 'fenlei' AND time_key = {$renwuDayTime}");
    $fenleiIsRead = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count("AND user_id = {$__UserInfo['id']} AND renwu_type = 'fenlei' AND object_id = {$tongcheng_id} AND time_key = {$renwuDayTime}");
    if($todayRenwuCount < $tcsignConfig['renwu_fenlei_num'] && $fenleiIsRead <= 0){

        $insertData = array();
        $insertData['user_id']            = $__UserInfo['id'];
        $insertData['renwu_type']         = 'fenlei';
        $insertData['object_id']          = $tongcheng_id;
        $insertData['year']               = $renwuYear;
        $insertData['month']              = $renwuMonth;
        $insertData['day']                = $renwuDay;
        $insertData['time_key']           = $renwuDayTime;
        $insertData['do_time']            = TIMESTAMP;
        C::t('#tom_tcsign#tom_tcsign_renwu_data')->insert($insertData);

        $insertData = array();
        $insertData['user_id']          = $__UserInfo['id'];
        $insertData['score_value']      = $tcsignConfig['renwu_fenlei_score'];
        $insertData['old_value']        = $__UserInfo['score'];
        $insertData['log_type']         = 22;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);

        DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET score = score+{$tcsignConfig['renwu_fenlei_score']} WHERE id='{$__UserInfo['id']}' ", 'UNBUFFERED');

    }
}

if($__UserInfo['id'] > 0 && $tcsignConfig['renwu_open_share'] == 1 && $tcsignConfig['renwu_share_score'] > 0){
    
    $shareUrl   = $shareUrl."&suid={$__UserInfo['id']}";
    
    $suid = intval($_GET['suid'])>0? intval($_GET['suid']):0;
    
    if($suid > 0 && $suid != $__UserInfo['id']){
        $todayShareRenwuCount   = C::t('#tom_tcsign#tom_tcsign_renwu_share')->fetch_all_count("AND user_id = {$suid} AND type = 1 AND time_key = {$renwuDayTime}");
        $todayIsShare           = C::t('#tom_tcsign#tom_tcsign_renwu_share')->fetch_all_count("AND user_id = {$suid} AND type = 1 AND to_user_id = {$__UserInfo['id']} AND tongcheng_id = {$tongcheng_id}  AND time_key = {$renwuDayTime}");
        if($todayShareRenwuCount < $tcsignConfig['renwu_share_num'] && $todayIsShare <= 0){
            
            $insertData = array();
            $insertData['user_id']            = $suid;
            $insertData['to_user_id']         = $__UserInfo['id'];
            $insertData['type']               = 1;
            $insertData['tongcheng_id']       = $tongcheng_id;
            $insertData['year']               = $renwuYear;
            $insertData['month']              = $renwuMonth;
            $insertData['day']                = $renwuDay;
            $insertData['time_key']           = $renwuDayTime;
            $insertData['share_time']         = TIMESTAMP;
            C::t('#tom_tcsign#tom_tcsign_renwu_share')->insert($insertData);
            
            $ssUserInfo  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($suid); 

            $insertData = array();
            $insertData['user_id']          = $suid;
            $insertData['score_value']      = $tcsignConfig['renwu_share_score'];
            $insertData['old_value']        = $ssUserInfo['score'];
            $insertData['log_type']         = 22;
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);

            DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET score = score+{$tcsignConfig['renwu_share_score']} WHERE id='{$suid}' ", 'UNBUFFERED');

        }
    }
    
}