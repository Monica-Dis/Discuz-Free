<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcsign`;
CREATE TABLE `pre_tom_tcsign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `lianxu_days` int(11) DEFAULT '0',
  `all_days` int(11) DEFAULT '0',
  `last_sign_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcsign_code`;
CREATE TABLE `pre_tom_tcsign_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `code` varchar(255) DEFAULT NULL,
  `score` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `use_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_code` (`code`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcsign_data`;
CREATE TABLE `pre_tom_tcsign_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `year` int(11) DEFAULT '0',
  `month` int(11) DEFAULT '0',
  `day` int(11) DEFAULT '0',
  `score` int(11) DEFAULT '0',
  `no_days` int(11) DEFAULT '0',
  `time_key` int(11) DEFAULT '0',
  `sign_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_time_key` (`time_key`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcsign_focuspic`;
CREATE TABLE `pre_tom_tcsign_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcsign_goods`;
CREATE TABLE `pre_tom_tcsign_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tcshop_id` int(11) DEFAULT '0',
  `cate_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `toppic` varchar(255) DEFAULT NULL,
  `buy_price` decimal(10,2) DEFAULT '0.00',
  `buy_score` int(11) DEFAULT '0',
  `market_price` decimal(10,2) DEFAULT '0.00',
  `stock_num` int(11) DEFAULT '0',
  `sale_num` int(11) DEFAULT '0',
  `xiangou_num` int(11) DEFAULT '0',
  `peisong_type` int(11) DEFAULT '3',
  `content` text,
  `status` int(11) DEFAULT '1',
  `paixu` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcsign_goods_cate`;
CREATE TABLE `pre_tom_tcsign_goods_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `csort` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcsign_goods_order`;
CREATE TABLE `pre_tom_tcsign_goods_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tcshop_id` int(11) DEFAULT '0',
  `order_no` varchar(255) DEFAULT NULL,
  `goods_id` int(11) DEFAULT '0',
  `goods_title` varchar(255) DEFAULT NULL,
  `goods_num` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `pay_score` int(11) DEFAULT '0',
  `order_beizu` varchar(255) DEFAULT NULL,
  `order_status` int(11) DEFAULT '0',
  `express_name` varchar(255) DEFAULT NULL,
  `express_no` varchar(255) DEFAULT NULL,
  `peisong_type` int(11) DEFAULT '3',
  `peisong_time` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `pay_time` int(11) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcsign_month`;
CREATE TABLE `pre_tom_tcsign_month` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `year` int(11) DEFAULT '0',
  `month` int(11) DEFAULT '0',
  `days` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcsign_renwu_data`;
CREATE TABLE `pre_tom_tcsign_renwu_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `renwu_type` varchar(255) DEFAULT NULL,
  `object_id` int(11) DEFAULT '0',
  `year` int(11) DEFAULT '0',
  `month` int(11) DEFAULT '0',
  `day` int(11) DEFAULT '0',
  `time_key` int(11) DEFAULT '0',
  `do_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_renwu_type` (`renwu_type`),
  KEY `idx_time_key` (`time_key`),
  KEY `idx_object_id` (`object_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcsign_renwu_share`;
CREATE TABLE `pre_tom_tcsign_renwu_share` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `to_user_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '1',
  `tongcheng_id` int(11) DEFAULT '0',
  `tctoutiao_id` int(11) DEFAULT '0',
  `year` int(11) DEFAULT '0',
  `month` int(11) DEFAULT '0',
  `day` int(11) DEFAULT '0',
  `time_key` int(11) DEFAULT '0',
  `share_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$finish = TRUE;