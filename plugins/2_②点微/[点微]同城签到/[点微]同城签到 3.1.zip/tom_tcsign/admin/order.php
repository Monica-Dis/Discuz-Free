<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=order';
$modListUrl = $adminListUrl.'&tmod=order';
$modFromUrl = $adminFromUrl.'&tmod=order';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

if($formhash == FORMHASH && $act == 'express'){
    $info = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $express_name = !empty($_GET['express_name'])? addslashes($_GET['express_name']):'';
        $express_no = !empty($_GET['express_no'])? addslashes($_GET['express_no']):'';
        
        $updateData = array();
        $updateData['express_name'] = $express_name;
        $updateData['express_no']   = $express_no;
        $updateData['peisong_time'] = TIMESTAMP;
        $updateData['order_status'] = 3;
        C::t('#tom_tcsign#tom_tcsign_goods_order')->update($_GET['id'],$updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
    
        showformheader($modFromUrl.'&act=express&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_express_title'] . '</th></tr>';
        showtablefooter();/*Dism��taobao��com*/
        showtableheader();
        
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_order_title'] . '</th></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_goods_name'].'</b></td><td>'.$info['goods_title'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_no'].'</b></td><td>'.$info['order_no'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_pay_score'].'</b></td><td>'.$info['pay_score'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_pay_price'].'</b></td><td>'.$info['pay_price'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_status'].'</b></td><td><b><font color="'.$orderStatusColorArray[$info['order_status']].'">' . $orderStatusArray[$info['order_status']] . '</font></b></td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_xm'].'</b></td><td>'.$info['xm'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_tel'].'</b></td><td>'.$info['tel'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_address'].'</b></td><td>'.$info['address'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_beizu'].'</b></td><td>'.$info['order_beizu'].'</td></tr>';
        
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_user_title'] . '</th></tr>';
        if($info['peisong_time'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['order_peisong_time'].'</b></td><td>'.dgmdate($info['peisong_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
        }else{
            echo '<tr><td width="100" align="right"><b>' . $Lang['order_peisong_time'] . '</b></td><td>-</td></tr>';
        }
        echo '<tr><td width="100" align="right"><b>' . $Lang['order_express_name'] . '</b></td><td><input name="express_name" type="text" value="'.$info['express_name'].'" size="40" /></td></tr>';
        echo '<tr><td width="100" align="right"><b>' . $Lang['order_express_no'] . '</b></td><td><input name="express_no" type="text" value="'.$info['express_no'].'" size="40" /></td></tr>';
        
        tomshowsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }
}elseif($formhash == FORMHASH && $act == 'edit_order_status'){
    
    $info = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $order_status = intval($_GET['order_status']);
        $updateData = array();
        $updateData['order_status'] = $order_status;
        C::t('#tom_tcsign#tom_tcsign_goods_order')->update($_GET['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        showformheader($modFromUrl.'&act=edit_order_status&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_order_order_status'] . '</th></tr>';
        showtablefooter();/*Dism��taobao��com*/
        showtableheader();
        echo '<tr><td align="right"><b>'.$Lang['order_order_status'].'</b></td><td>';
        foreach ($orderStatusArray as $key => $value){
            if($key == $info['order_status']){
                echo '<input type="radio" name="order_status" value="'.$key.'" checked><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }else{
                echo '<input type="radio" name="order_status" value="'.$key.'" ><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }
        }
        echo '</td></tr>';
        echo '<tr><td>&nbsp;</td><td colspan="14" ><b><font color="#fd0303">(' . $Lang['order_order_status_msg'] . ')</font></b></td></tr>';
        tomshowsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }
}else{
    
    $goods_id      = isset($_GET['goods_id'])? intval($_GET['goods_id']):'';
    $order_no      = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
    $order_tel     = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $order_status  = isset($_GET['order_status'])? intval($_GET['order_status']):0;

    $pagesize = 100;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    
    $where = "";
    if(!empty($goods_id)){
        $where.= " AND goods_id={$goods_id} ";
    }
    if(!empty($order_no)){
        $where.=" AND order_no='{$order_no}' ";
    }
    if(!empty($order_tel)){
        $where.= " AND tel= '{$order_tel}'";
    }
    if(!empty($order_status)){
        $where.= " AND order_status={$order_status} ";
    }
    
    $count = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_count($where);
    $orderList = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&goods_id={$goods_id}&order_no={$order_no}&order_tel={$order_tel}&order_status={$order_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_search_list'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['order_goods_id'].'</b></td><td><input name="goods_id" type="text" value="'.$goods_id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['order_no'].'</b></td><td><input name="order_no" type="text" value="'.$order_no.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['order_tel'].'</b></td><td><input name="tel" type="text" value="'.$order_tel.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_order_status'] . '</b></td><td><select name="order_status" >';
    echo '<option value="0">'.$Lang['order_order_status'].'</option>';
    foreach ($orderStatusArray as $key => $value){
        if($key == $order_status){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select></td></tr>';
   
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();
   
    tomshownavheader();
    tomshownavli($Lang['daochu_order'],$adminBaseUrl.'&tmod=doDao',false);
    tomshownavfooter();
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_goods_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['order_no'] . '</th>';
    echo '<th>' . $Lang['order_user_id'] . '</th>';
    echo '<th>' . $Lang['order_goods_title'] . '</th>';
    echo '<th>' . $Lang['order_goods_num'] . '</th>';
    echo '<th>' . $Lang['order_pay_score'] . '</th>';
    echo '<th>' . $Lang['order_pay_price'] . '</th>';
    echo '<th>' . $Lang['order_xm'] . '</th>';
    echo '<th>' . $Lang['order_tel'] . '</th>';
    echo '<th>' . $Lang['order_status'] . '</th>';
    echo '<th>' . $Lang['order_order_time'] . '</th>';
    echo '<th>' . $Lang['order_pay_time'] . '</th>';
    echo '<th>' . $Lang['order_hexiao_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($orderList as $key => $value){
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        if($value['pay_time'] <= 0){
            $pay_time = "--";
        }else{
            $pay_time = dgmdate($value['pay_time'], 'Y-m-d H:i:s',$tomSysOffset);
        }
        $order_time = dgmdate($value['order_time'], 'Y-m-d H:i:s',$tomSysOffset);
        if($value['hexiao_time'] <= 0){
            $hexiao_time = "--";
        }else{
            $hexiao_time = dgmdate($value['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset);
        }
        echo '<tr>';
        echo '<td>' . $value['order_no'] . '</td>';
        echo '<td>' . $userInfo['nickname'].'(UID:'.$value['user_id'].')' . '</td>';
        echo '<td>' . $value['goods_title'] . '(ID:'.$value['goods_id'].')</td>';
        echo '<td>' . $value['goods_num'] . '</td>';
        echo '<td><font color="#fd0d0d">' . $value['pay_score'] . '</font></td>';
        echo '<td><font color="#fd0d0d">' . $value['pay_price'] . '</font></td>';
        echo '<td>' . $value['xm'] . '</td>';
        echo '<td>' . $value['tel'] . '</td>';
        echo '<td>';
        echo '<b><font color="'.$orderStatusColorArray[$value['order_status']].'">' . $orderStatusArray[$value['order_status']] . '</font></b><br/>';
        if($value['peisong_type'] == 1){
            echo '<font color="#0894fb">('.$Lang['goods_peisong_type_1'].')</font>';
        }else if($value['peisong_type'] == 2){
            echo '<font color="#0894fb">('.$Lang['goods_peisong_type_2'].')</font>';
        }else if($value['peisong_type'] == 3){
            echo '<font color="#0894fb">('.$Lang['goods_peisong_type_3'].')</font>';
        }
        if($value['hexiao_time'] > 0){
            echo '<br/><font color="#fd0d0d">'.$hexiaoUserInfo['nickname'].'(ID:'.$hexiaoUserInfo['id'].')</font><br/>';
        }
        echo '</td>';
        echo '<td>' . $order_time . '</td>';
        echo '<td>' . $pay_time . '</td>';
        echo '<td>' . $hexiao_time . '</td>';
        echo '<td style="line-height: 22px;">';
        if($value['peisong_type'] == 3){
            echo '<a href="'.$modBaseUrl.'&act=express&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['order_express_title'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        }
        echo '<a href="'.$modBaseUrl.'&act=edit_order_status&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_order_order_status'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
}