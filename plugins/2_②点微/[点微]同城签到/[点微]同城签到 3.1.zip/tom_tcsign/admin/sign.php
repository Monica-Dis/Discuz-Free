<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=sign';
$modListUrl = $adminListUrl.'&tmod=sign';
$modFromUrl = $adminFromUrl.'&tmod=sign';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

if($formhash == FORMHASH && $act == 'sign_log'){
    
    $user_id    = isset($_GET['user_id'])? intval($_GET['user_id']):1;
    
    $pagesize = 10;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcsign#tom_tcsign_data')->fetch_all_count(" AND user_id = {$user_id} ");
    $dataList   = C::t('#tom_tcsign#tom_tcsign_data')->fetch_all_list("AND user_id = {$user_id}","ORDER BY id DESC",$start,$pagesize);
    
    $fenhao = $Lang['fenhao'];
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['sign_log'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['sign_user_id'] . '</th>';
    echo '<th>' . $Lang['sign_user_picurl'] . '</th>';
    echo '<th>' . $Lang['sign_user_nickname'] . '</th>';
    echo '<th>' . $Lang['data_score'] . '</th>';
    echo '<th>' . $Lang['data_date'] . '</th>';
    echo '</tr>';
    foreach ($dataList as $key => $value){
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        if(strpos($userInfo['picurl'], 'data/attachment/tomwx') !== false){
            $userInfo['picurl']  = $_G['siteurl'].$userInfo['picurl'];
        }else if(strpos($userInfo['picurl'], 'uc_server/') !== false){
            $userInfo['picurl']  = $_G['siteurl'].$userInfo['picurl'];
        }else{
            $userInfo['picurl']  = $userInfo['picurl'];
        }
        echo '<tr>';
        echo '<td>' . $value['user_id'] . '</td>';
        echo '<td><img src="'.$userInfo['picurl'].'" width="40" /></td>';
        echo '<td>' . $userInfo['nickname'] . '</td>';
        echo '<td>' . $value['score'] . '</td>';
        echo '<td>' . dgmdate($value['sign_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
}else{
    
    showtableheader();
    $Lang['index_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_3']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_3'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();/*Dism��taobao��com*/
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $user_id = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    
    $where = "";
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['sign_user_id'].'</b></td><td><input name="user_id" type="text" value="'.$user_id.'" size="40" /></td></tr>';
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcsign#tom_tcsign')->fetch_all_count($where);
    $signList = C::t('#tom_tcsign#tom_tcsign')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['sign_user_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['sign_user_id'] . '</th>';
    echo '<th>' . $Lang['sign_user_picurl'] . '</th>';
    echo '<th>' . $Lang['sign_user_nickname'] . '</th>';
    echo '<th>' . $Lang['sign_user_all_days'] . '</th>';
    echo '<th>' . $Lang['sign_user_last_sign_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($signList as $key => $value){
        $signList[$key] = $value;
        $last_sign_time = dgmdate($value['last_sign_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        if(strpos($userInfo['picurl'], 'data/attachment/tomwx') !== false){
            $userInfo['picurl']  = $_G['siteurl'].$userInfo['picurl'];
        }else if(strpos($userInfo['picurl'], 'uc_server/') !== false){
            $userInfo['picurl']  = $_G['siteurl'].$userInfo['picurl'];
        }else{
            $userInfo['picurl']  = $userInfo['picurl'];
        }
        
        echo '<tr>';
        echo '<td>' . $value['user_id'] . '</td>';
        echo '<td><img src="'.$userInfo['picurl'].'" width="40" /></td>';
        echo '<td>' . $userInfo['nickname'] . '</td>';
        echo '<td>' . $value['all_days'] . '</td>';
        echo '<td>' . $last_sign_time . '</td>';
        echo '<td style="line-height: 22px;">';
        echo '<a href="'.$modBaseUrl.'&act=sign_log&user_id='.$value['user_id'].'&formhash='.FORMHASH.'">' . $Lang['sign_log'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
}