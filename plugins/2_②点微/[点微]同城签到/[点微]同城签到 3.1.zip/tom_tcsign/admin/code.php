<?php

/*
   [DisM!] (C)2001-2099 DisM Inc.
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=code';
$modListUrl = $adminListUrl.'&tmod=code';
$modFromUrl = $adminFromUrl.'&tmod=code';

if($_GET['act'] == 'addzd'){
    if(submitcheck('submit')){
        
        $score        = isset($_GET['score'])? intval($_GET['score']):0;
        $num          = isset($_GET['num'])? intval($_GET['num']):0;
        
        if($num > 50){
            $num = 50;
        }
        
        $codeInfoTmp = C::t('#tom_tcsign#tom_tcsign_code')->fetch_all_list(" ", " ORDER BY id DESC", 0, 1);
        $min_id = 1111;
        if(is_array($codeInfoTmp) && !empty($codeInfoTmp['0'])){
            $min_id = $codeInfoTmp['0']['id'] + 1;
        }
        
        $id = intval($min_id);
        for($i=0; $i<$num; $i++){
            $code = '';
            $len = strlen($id);
            $inviteCode = tom_random($len, 'qwertyupasdfghjkzxcvbnm');
            $no = strval($id);
            for($j=0;$j<$len;$j++){
                $code.=$inviteCode[$j].$no[$j];
            }
            
            $insertData = array();
            $insertData['id']           = $id++;
            $insertData['code']         = $code;
            $insertData['score']        = $score;
            $insertData['status']       = 0;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tcsign#tom_tcsign_code')->insert($insertData);
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=addzd','enctype');
        showtableheader();
        
        tomshowsetting(true,array('title'=>$Lang['code_score'],'name'=>'score','value'=>'','msg'=>$Lang['code_score_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['code_num'],'name'=>'num','value'=>'','msg'=>$Lang['code_num_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'addsd'){
    
    if(submitcheck('submit')){
        
        $score        = isset($_GET['score'])? intval($_GET['score']):0;
        $text         = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $codeListStr = str_replace("\r\n","{n}",trim($text));
        $codeListStr = str_replace("\n","{n}",$codeListStr);
        $codeListStr = explode("{n}", $codeListStr);
        
        $codeInfoTmp = C::t('#tom_tcsign#tom_tcsign_code')->fetch_all_list(" ", " ORDER BY id DESC", 0, 1);
        $min_id = 1111;
        if(is_array($codeInfoTmp) && !empty($codeInfoTmp['0'])){
            $min_id = $codeInfoTmp['0']['id'] + 1;
        }
        
        foreach($codeListStr as $key => $value){
            $insertData = array();
            $insertData['id']           = $min_id++;
            $insertData['score']        = $score;
            $insertData['code']         = trim($value);
            $insertData['status']       = 0;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tcsign#tom_tcsign_code')->insert($insertData);
        }

        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=addsd','enctype');
        showtableheader();
        
        tomshowsetting(true,array('title'=>$Lang['code_score'],'name'=>'score','value'=>'0','msg'=>$Lang['code_score_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['code_sd_code'],'name'=>'text','value'=>'','msg'=>$Lang['code_sd_code_msg']),"textarea");
        
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcsign#tom_tcsign_code')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{

    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $code_code      = !empty($_GET['code_code'])? addslashes($_GET['code_code']):'';
    $code_status    = isset($_GET['code_status'])? intval($_GET['code_status']):0;
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['code_code'].'</b></td><td><input name="code_code" type="text" value="'.$code_code.'" size="40" /></td></tr>';
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['code_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="code_status" id="code_status">';
    $statusStr.=  '<option value="0">'.$Lang['code_status'].'</option>';
    $statusStr.=  '<option value="1">'.$Lang['code_status_1'].'</option>';
    $statusStr.=  '<option value="2">'.$Lang['code_status_0'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();
    
    $where = "";
    if(!empty($code_code)){
        $where.= " AND code='{$code_code}' ";
    }
    if($code_status == 1){
        $where.= " AND status=1 ";
    }else if($code_status == 2){
        $where.= " AND status=0 ";
    }
    
    $modBasePageUrl = $modBaseUrl."&code_code={$code_code}&code_status={$code_status}";
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcsign#tom_tcsign_code')->fetch_all_count($where);
    $codeList = C::t('#tom_tcsign#tom_tcsign_code')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['code_code'] . '</th>';
    echo '<th>' . $Lang['code_score'] . '</th>';
    echo '<th>' . $Lang['code_status'] . '</th>';
    echo '<th>' . $Lang['code_user'] . '</th>';
    echo '<th>' . $Lang['code_use_time'] . '</th>';
    echo '<th>' . $Lang['code_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($codeList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);

        echo '<tr>';
        echo '<td>' . $value['code'] . '</td>';
        echo '<td>' . $value['score'] . '</td>';
        if($value['status'] == 1){
            echo '<td><font color="#f00">' . $Lang['code_status_1'] . '</font></td>';
        }else{
            echo '<td><font color="#0a9409">' . $Lang['code_status_0'] . '</font></td>';
        }
        if($value['user_id'] > 0){
            echo '<td>' . $userInfo['nickname'] .'<font color="#0a9409">(UID:'.$userInfo['id']. ')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['use_time'] > 0){
            echo '<td>' . dgmdate($value['use_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'addzd'){
        tomshownavli($Lang['code_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['code_addzd'],"",true);
    }else if($_GET['act'] == 'addsd'){
        tomshownavli($Lang['code_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['code_addsd'],$modBaseUrl."&act=addsd",true);
    }else{
        tomshownavli($Lang['code_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['code_addzd'],$modBaseUrl."&act=addzd",false);
        tomshownavli($Lang['code_addsd'],$modBaseUrl."&act=addsd",false);
    }
    tomshownavfooter();
}