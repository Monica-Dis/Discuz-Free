<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=goods';
$modListUrl = $adminListUrl.'&tmod=goods';
$modFromUrl = $adminFromUrl.'&tmod=goods';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tcsign#tom_tcsign_goods')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    
    $goodsInfo = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($goodsInfo);
        C::t('#tom_tcsign#tom_tcsign_goods')->update($goodsInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($goodsInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $goods_id  = isset($_GET['id'])? intval($_GET['id']):0;
    
    $count = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_count(" AND goods_id={$goods_id} ");
    if($count > 0){
        cpmsg($Lang['act_del_goods_error'], $modListUrl, 'error');
    }
    C::t('#tom_tcsign#tom_tcsign_goods')->delete_by_id($goods_id);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shangjia'){
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcsign#tom_tcsign_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'xiajia'){
    
    $updateData = array();
    $updateData['status'] = 2;
    C::t('#tom_tcsign#tom_tcsign_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
}else{
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):'';
    $goods_title    = !empty($_GET['goods_title'])? addslashes($_GET['goods_title']):'';
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['goods_id'].'</b></td><td><input name="goods_id" type="text" value="'.$goods_id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['goods_title'].'</b></td><td><input name="goods_title" type="text" value="'.$goods_title.'" size="40" /></td></tr>';
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();
    
    
    $where = "";
    if(!empty($goods_id)){
        $where.= " AND id={$goods_id} ";
    }
    
    $pagesize = 10;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_all_like_count($where,$goods_title);
    $goodsList = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_all_like_list($where," ORDER BY paixu ASC,id DESC ",$start,$pagesize,$goods_title);
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 60px;">' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['goods_id'] . '</th>';
    echo '<th>' . $Lang['goods_title'] . '</th>';
    echo '<th>' . $Lang['goods_cate'] . '</th>';
    echo '<th>' . $Lang['goods_picurl'] . '</th>';
    echo '<th>' . $Lang['goods_buy_score'] . '</th>';
    echo '<th>' . $Lang['goods_buy_price'] . '</th>';
    echo '<th>' . $Lang['goods_market_price'] . '</th>';
    echo '<th>' . $Lang['goods_xiangou_num'] . '</th>';
    echo '<th>' . $Lang['goods_stock_num'] . '</th>';
    echo '<th>' . $Lang['goods_sale_num'] . '</th>';
    echo '<th>' . $Lang['goods_status'] . '</th>';
    echo '<th>' . $Lang['goods_paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    foreach ($goodsList as $key => $value) {
        
        if(!preg_match('/^http/', $value['picurl']) ){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $picurl = $value['picurl'];
        }
        $cateInfo = C::t('#tom_tcsign#tom_tcsign_goods_cate')->fetch_by_id($value['cate_id']);
        
        echo '<tr>';
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        if($value['site_id'] == 99){
            echo '<td>' . $Lang['sites_all'] . '</td>';
        }else if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $value['title'] . '</td>';
        echo '<td>' . $cateInfo['name'] . '</td>';
        echo '<td>' . '<img style="height:40px;width:40px;" src="' .$picurl. '">' . '</td>'; 
        echo '<td>' . $value['buy_score'] . '</td>';
        echo '<td>' . $value['buy_price'] . '</td>';
        echo '<td>' . $value['market_price'] . '</td>';
        echo '<td>' . $value['xiangou_num'] . '</td>';
        echo '<td>' . $value['stock_num'] . '</td>';
        echo '<td>' . $value['sale_num'] . '</td>';
        if($value['status'] == 1){
            echo '<td><font color="#009900">' . $Lang['goods_status_1']. '</font></td>';
        }else if($value['status'] == 2){
            echo '<td><font color="#FF0000">' . $Lang['goods_status_2']. '</font></td>';
        }
        echo '<td>' . $value['paixu'] . '</td>';
        echo '<td>';
        if($value['status'] == 1){
            echo '<a href="'.$modBaseUrl.'&act=xiajia&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#FF0000">' . $Lang['goods_status_2']. '</font></a>&nbsp;|&nbsp;';
        }else{
            echo '<a href="'.$modBaseUrl.'&act=shangjia&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#009900">' . $Lang['goods_status_1']. '</font></a>&nbsp;|&nbsp;';
        }
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id                = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $tcshop_id              = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $title                  = isset($_GET['title'])? addslashes($_GET['title']):'';
    $cate_id                = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $buy_score              = isset($_GET['buy_score'])? intval($_GET['buy_score']):'';
    $buy_price              = isset($_GET['buy_price'])? addslashes($_GET['buy_price']):'';
    $market_price           = isset($_GET['market_price'])? addslashes($_GET['market_price']):'';
    $xiangou_num            = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $stock_num              = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
    $sale_num               = isset($_GET['sale_num'])? intval($_GET['sale_num']):0;
    $peisong_type           = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $content                = isset($_GET['content'])? addslashes($_GET['content']):'';
    $paixu                  = isset($_GET['paixu'])? addslashes($_GET['paixu']):'';
    
    $picurl   = "";
    $toppic   = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
        $toppic        = tomuploadFile("toppic");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
        $toppic        = tomuploadFile("toppic",$infoArr['toppic']);
    }
    
    $tcshopInfo = array();
    if($tcshop_id > 0){
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
        $site_id    = $tcshopInfo['site_id'];
    }
    
    $data['site_id']        = $site_id;
    $data['tcshop_id']      = $tcshop_id;
    $data['title']          = $title;
    $data['picurl']         = $picurl;
    $data['toppic']         = $toppic;
    $data['cate_id']        = $cate_id;
    $data['buy_score']      = $buy_score;
    $data['buy_price']      = $buy_price;
    $data['market_price']   = $market_price;
    $data['xiangou_num']    = $xiangou_num;
    $data['stock_num']      = $stock_num;
    $data['sale_num']       = $sale_num;
    $data['peisong_type']   = $peisong_type;
    $data['content']        = $content;
    $data['paixu']          = $paixu;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'site_id'       => 1,
        'tcshop_id'     => 0,
        'title'         => '',
        'picurl'        => '',
        'toppic'        => '',
        'cate_id'       => '',
        'buy_score'     => '',
        'buy_price'     => '',
        'market_price'  => '',
        'xiangou_num'   => '',
        'stock_num'     => '',
        'sale_num'      => '',
        'content'       => '',
        'paixu'         => '',
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['goods_site_id'],'name'=>'site_id','value'=>$options['site_id'],'msg'=>$Lang['goods_site_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['goods_tcshop_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['goods_title_msg']),"input");
    $cateList = C::t('#tom_tcsign#tom_tcsign_goods_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,100);
    $cateStr = '<tr class="header"><th>'.$Lang['goods_cate'].'</th><th></th></tr>';
    $cateStr.= '<tr><td width="300"><select style="width: 260px;" name="cate_id" id="cate_id">';
    foreach ($cateList as $key => $value){
        if($value['id'] == $options['cate_id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select></td><td></td></tr>';
    echo $cateStr;
    tomshowsetting(true,array('title'=>$Lang['goods_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['goods_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['goods_toppic'],'name'=>'toppic','value'=>$options['toppic'],'msg'=>$Lang['goods_toppic_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['goods_buy_score'],'name'=>'buy_score','value'=>$options['buy_score'],'msg'=>$Lang['goods_buy_score_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_buy_price'],'name'=>'buy_price','value'=>$options['buy_price'],'msg'=>$Lang['goods_buy_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_market_price'],'name'=>'market_price','value'=>$options['market_price'],'msg'=>$Lang['goods_market_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_xiangou_num'],'name'=>'xiangou_num','value'=>$options['xiangou_num'],'msg'=>$Lang['goods_xiangou_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_stock_num'],'name'=>'stock_num','value'=>$options['stock_num'],'msg'=>$Lang['goods_stock_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_sale_num'],'name'=>'sale_num','value'=>$options['sale_num'],'msg'=>$Lang['goods_sale_num_msg']),"input");
    $peisong_type_item = array(3=>$Lang['goods_peisong_type_3'],1=>$Lang['goods_peisong_type_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_peisong_type'],'name'=>'peisong_type','value'=>$options['peisong_type'],'msg'=>$Lang['goods_peisong_type_msg'],'item'=>$peisong_type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['goods_content_msg']),"text");
    tomshowsetting(true,array('title'=>$Lang['goods_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['fgoods_paixu_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['goods_edit'],"",true); 
    }else{
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}