<?php

/*
   [DisM!] (C)2001-2099 DisM Inc.
   Ӧ�ø���֧�֣�https://dism.taobao.com
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tcsignConfig       = $_G['cache']['plugin']['tom_tcsign'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset       = getglobal('setting/timeoffset');

$orderInfo = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_by_order_no($order_no);
$goodsInfo = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_by_id($orderInfo['goods_id']);
$userInfo  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 

if($orderInfo && $orderInfo['order_status'] == 1){
    
    $updateData = array();
    $updateData['order_status'] = 2;
    $updateData['pay_time'] = TIMESTAMP;
    C::t('#tom_tcsign#tom_tcsign_goods_order')->update($orderInfo['id'],$updateData);
    
    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($orderInfo['order_no'])));
    
    $updateData = array();
    $updateData['score'] = $userInfo['score'] - $orderInfo['pay_score'];
    C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
    
    $insertData = array();
    $insertData['user_id']          = $userInfo['id'];
    $insertData['score_value']      = $orderInfo['pay_score'];
    $insertData['old_value']        = $userInfo['score'];
    $insertData['log_type']         = 23;
    $insertData['log_time']         = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $appid = trim($tongchengConfig['wxpay_appid']);
    $appsecret = trim($tongchengConfig['wxpay_appsecret']);
    $weixinClass = new weixinClass($appid,$appsecret);
    $access_token = $weixinClass->get_access_token();

    if($orderInfo['peisong_type'] == 1 && $orderInfo['tcshop_id'] > 0){
        $tcshopInfoTmp  = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);
        $toUser         = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfoTmp['user_id']);
        $smsUrl         = $_G['siteurl']."plugin.php?id=tom_tcsign&site={$site_id}&mod=goodsinfo&goods_id=".$orderInfo['goods_id'];
        $smsFirst       = '['.$tcshopInfoTmp['name'].']'.lang('plugin/tom_tcsign','duihuan_template_first');
    }else{
        $toUser         = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
        $smsUrl         = $_G['siteurl']."plugin.php?id=tom_tcsign&site={$site_id}&mod=index";
        $smsFirst       = lang('plugin/tom_tcsign','duihuan_template_first');
    }

    if($access_token && !empty($toUser['openid'])){
        $templateSmsClass = new templateSms($access_token, $smsUrl);
        $smsData = array(
            'first'         => $smsFirst,
            'keyword1'      => $tongchengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
    }

}