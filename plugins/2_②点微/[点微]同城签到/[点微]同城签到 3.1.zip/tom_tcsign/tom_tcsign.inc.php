<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcsignConfig = $_G['cache']['plugin']['tom_tcsign'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
$nowtime = dgmdate($_G['timestamp'], 'Y-m-d', $tomSysOffset);
$nowYear = dgmdate($_G['timestamp'], 'Y', $tomSysOffset);
$nowMonth = dgmdate($_G['timestamp'], 'n', $tomSysOffset);
$nowDay = dgmdate($_G['timestamp'], 'j', $tomSysOffset);
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = '20200109';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
if (CHARSET == 'gbk') {
	include DISCUZ_ROOT . './source/plugin/tom_tcsign/config/config.gbk.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tcsign/config/config.utf8.php';
}
include DISCUZ_ROOT . './source/plugin/tom_tcsign/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcsignConfig['wx_share_title'];
$shareDesc = $tcsignConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=index');
$shareLogo = $tcsignConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$__ShowTcshop = 0;
$tcshopConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcshop/tom_tcshop.inc.php')) {
	$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
	if ($tcshopConfig['open_tcshop'] == 1) {
		$__ShowTcshop = 1;
	}
}
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')) {
	$tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
	if ($tcqianggouConfig['open_tcqianggou'] == 1) {
		$__ShowTcqianggou = 1;
	}
}
$__ShowTcptuan = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcptuan/tom_tcptuan.inc.php')) {
	$tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
	if ($tcptuanConfig['open_tcptuan'] == 1) {
		$__ShowTcptuan = 1;
	}
}
$__ShowTcmall = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcmall/tom_tcmall.inc.php')) {
	$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
	if ($tcmallConfig['open_tcmall'] == 1) {
		$__ShowTcmall = 1;
	}
}
$__ShowTctoutiao = 0;
$tctoutiaoConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tctoutiao/tom_tctoutiao.inc.php')) {
	$tctoutiaoConfig = $_G['cache']['plugin']['tom_tctoutiao'];
	if ($tctoutiaoConfig['open_tctoutiao'] == 1) {
		$__ShowTctoutiao = 1;
	}
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$ajaxLoadListUrl = 'plugin.php?id=tom_tcsign:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
if ($_GET['mod'] == 'index') {
	$signStatus = 0;
	$isDataList = C::t('#tom_tcsign#tom_tcsign_data')->fetch_all_list('AND user_id = ' . $__UserInfo['id'] . ' AND time_key = ' . $nowDayTime, ' ORDER BY id DESC ', 0, 1);
	if (is_array($isDataList) && !empty($isDataList)) {
		$signStatus = 1;
	}
	$renwu_index_projectArr = unserialize($tcsignConfig['renwu_index']);
	$showRenwuFenlei = $showRenwuShop = $showRenwuQianggou = $showRenwuToutiao = $showRenwuMall = $showRenwuPtuan = $showRenwuShare = 0;
	if (array_search('1', $renwu_index_projectArr) !== false) {
		$showRenwuFenlei = 1;
	}
	if (array_search('2', $renwu_index_projectArr) !== false) {
		$showRenwuShop = 1;
	}
	if (array_search('3', $renwu_index_projectArr) !== false) {
		$showRenwuQianggou = 1;
	}
	if (array_search('4', $renwu_index_projectArr) !== false) {
		$showRenwuToutiao = 1;
	}
	if (array_search('5', $renwu_index_projectArr) !== false) {
		$showRenwuMall = 1;
	}
	if (array_search('6', $renwu_index_projectArr) !== false) {
		$showRenwuPtuan = 1;
	}
	if (array_search('7', $renwu_index_projectArr) !== false) {
		$showRenwuShare = 1;
	}
	if (array_search('8', $renwu_index_projectArr) !== false) {
		$showRenwuTshare = 1;
	}
	$renwu_fenlei_score = $tcsignConfig['renwu_fenlei_score'] * $tcsignConfig['renwu_fenlei_num'];
	$renwu_share_score = $tcsignConfig['renwu_share_score'] * $tcsignConfig['renwu_share_num'];
	$renwu_tshare_score = $tcsignConfig['renwu_tshare_score'] * $tcsignConfig['renwu_tshare_num'];
	$todayFenleiRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count('AND user_id = ' . $__UserInfo['id'] . ' AND renwu_type = \'fenlei\' AND time_key = ' . $nowDayTime);
	$todayShopRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count('AND user_id = ' . $__UserInfo['id'] . ' AND renwu_type = \'shop\' AND time_key = ' . $nowDayTime);
	$todayQianggouRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count('AND user_id = ' . $__UserInfo['id'] . ' AND renwu_type = \'qianggou\' AND time_key = ' . $nowDayTime);
	$todayToutiaoRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count('AND user_id = ' . $__UserInfo['id'] . ' AND renwu_type = \'toutiao\' AND time_key = ' . $nowDayTime);
	$todayMallRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count('AND user_id = ' . $__UserInfo['id'] . ' AND renwu_type = \'mall\' AND time_key = ' . $nowDayTime);
	$todayPtuanRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count('AND user_id = ' . $__UserInfo['id'] . ' AND renwu_type = \'ptuan\' AND time_key = ' . $nowDayTime);
	$todayShareRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_share')->fetch_all_count('AND user_id = ' . $__UserInfo['id'] . ' AND time_key = ' . $nowDayTime . ' AND type = 1 ');
	$todayTshareRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_share')->fetch_all_count('AND user_id = ' . $__UserInfo['id'] . ' AND time_key = ' . $nowDayTime . ' AND type = 2 ');
	$focuspicData = C::t('#tom_tcsign#tom_tcsign_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' AND type_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicData) || empty($focuspicData)) {
		$focuspicData = C::t('#tom_tcsign#tom_tcsign_focuspic')->fetch_all_list(' AND site_id=1 AND type_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	if (is_array($focuspicData) && !empty($focuspicData)) {
		foreach ($focuspicData as $key => $value) {
			$focuspicList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				$focuspicList[$key]['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
			} else {
				$focuspicList[$key]['picurl'] = $value['picurl'];
			}
		}
	}
	$cateData = C::t('#tom_tcsign#tom_tcsign_goods_cate')->fetch_all_list('', 'ORDER BY csort ASC,id DESC');
	$cateList = array();
	if (is_array($cateData) && !empty($cateData)) {
		foreach ($cateData as $key => $value) {
			$cateList[$key] = $value;
			$goodsData = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_all_list(' AND site_id IN(' . $sql_in_site_ids . ',99) AND status = 1 AND cate_id = ' . $value['id'] . ' ', 'ORDER BY paixu ASC,id DESC', 0, 6);
			$goodsList = array();
			if (is_array($goodsData) && !empty($goodsData)) {
				foreach ($goodsData as $k => $v) {
					$goodsList[$k] = $v;
					if (!preg_match('/^http/', $v['picurl'])) {
						if (strpos($v['picurl'], 'source/plugin/') === false) {
							$goodsList[$k]['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $v['picurl'];
						} else {
							$goodsList[$k]['picurl'] = $_G['siteurl'] . $v['picurl'];
						}
					}
				}
			}
			$cateList[$key]['goodsList'] = $goodsList;
		}
	}
	if ($__ShowTchehuoren == 1) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tcsign/images/index.js';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcsign:index');
	echo '<script src="source/plugin/tom_tcsign/images/index.js"></script>';
} elseif ($_GET['mod'] == 'scorelog') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/config/gold_type.config.php';
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$pagesize = 20;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tongcheng#tom_tongcheng_score_log')->fetch_all_count(' AND user_id=' . $__UserInfo['id'] . ' ');
	$scorelogListTmp = C::t('#tom_tongcheng#tom_tongcheng_score_log')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', $start, $pagesize);
	$scorelogList = array();
	if (is_array($scorelogListTmp) && !empty($scorelogListTmp)) {
		foreach ($scorelogListTmp as $key => $value) {
			$scorelogList[$key] = $value;
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=scorelog&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=scorelog&page=' . $nextPage;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcsign:scorelog');
} elseif ($_GET['mod'] == 'recharge') {
	$recharge_score = array();
	if (!empty($tcsignConfig['recharge_score'])) {
		$recharge_score_str = str_replace("\r\n", '{n}', $tcsignConfig['recharge_score']);
		$recharge_score_str = str_replace("\n", '{n}', $recharge_score_str);
		$recharge_score_list = explode('{n}', $recharge_score_str);
		if (is_array($recharge_score_list) && !empty($recharge_score_list)) {
			foreach ($recharge_score_list as $key => $value) {
				$recharge_score_list_item = explode('|', $value);
				$recharge_score_list_item_score = intval($recharge_score_list_item[0]);
				$recharge_score_list_item_money = floatval($recharge_score_list_item[1]);
				$recharge_score_list_item_song = intval($recharge_score_list_item[2]);
				if ($recharge_score_list_item_score > 0 && $recharge_score_list_item_money > 0) {
					$recharge_score[$recharge_score_list_item_score]['score'] = $recharge_score_list_item_score;
					$recharge_score[$recharge_score_list_item_score]['money'] = $recharge_score_list_item_money;
					$recharge_score[$recharge_score_list_item_score]['song'] = $recharge_score_list_item_song;
				}
			}
		}
	}
	$payUrl = 'plugin.php?id=tom_tongcheng:pay&site=' . $site_id . '&act=recharge_score&formhash=' . $formhash;
	$moneyUrl = 'plugin.php?id=tom_tcsign:ajax&site=' . $site_id . '&act=money&formhash=' . $formhash;
	$codeUrl = 'plugin.php?id=tom_tcsign:ajax&site=' . $site_id . '&act=code&formhash=' . $formhash;
	$succUrl = 'plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=scorelog';
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=recharge');
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcsign:recharge');
} elseif ($_GET['mod'] == 'goodslist') {
	$cate_id = isset($_GET['cate_id']) ? intval($_GET['cate_id']) : 1;
	$cateData = C::t('#tom_tcsign#tom_tcsign_goods_cate')->fetch_all_list('', 'ORDER BY csort ASC,id DESC');
	$cateList = array();
	if (is_array($cateData) && !empty($cateData)) {
		foreach ($cateData as $key => $value) {
			$cateList[$key] = $value;
		}
	}
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcsign:ajax&site=' . $site_id . '&act=goodslist&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcsign:goodslist');
} elseif ($_GET['mod'] == 'goodsinfo') {
	$goods_id = isset($_GET['goods_id']) ? intval($_GET['goods_id']) : 0;
	$goodsInfo = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_by_id($goods_id);
	if ($goodsInfo['id'] <= 0) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$picurl = '';
	if (is_array($goodsInfo) && !empty($goodsInfo['picurl'])) {
		if (!preg_match('/^http/', $goodsInfo['picurl'])) {
			if (strpos($goodsInfo['toppic'], 'source/plugin/') === false) {
				$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
			} else {
				$picurl = $_G['siteurl'] . $goodsInfo['picurl'];
			}
		} else {
			$picurl = $goodsInfo['picurl'];
		}
	}
	$toppic = '';
	if (is_array($goodsInfo) && !empty($goodsInfo['toppic'])) {
		if (!preg_match('/^http/', $goodsInfo['toppic'])) {
			if (strpos($goodsInfo['toppic'], 'source/plugin/') === false) {
				$toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['toppic'];
			} else {
				$toppic = $_G['siteurl'] . $goodsInfo['toppic'];
			}
		} else {
			$toppic = $goodsInfo['toppic'];
		}
	}
	$content = stripslashes($goodsInfo['content']);
	$showBuyBtn = 1;
	if ($goodsInfo['stock_num'] <= $goodsInfo['sale_num']) {
		$showBuyBtn = 2;
	}
	if ($goodsInfo['status'] != 1) {
		$showBuyBtn = 3;
	}
	if ($__UserInfo['score'] < $goodsInfo['buy_score']) {
		$showBuyBtn = 4;
	}
	if (!$ucenterfilenameExists) {
		$showBuyBtn = 10;
	}
	$tcshopInfo = array();
	if ($goodsInfo['tcshop_id'] > 0) {
		$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
		if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
			if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_tcshop/') === false) {
				$tcshopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
			} else {
				$tcshopPicurl = $tcshopInfo['picurl'];
			}
		} else {
			$tcshopPicurl = $tcshopInfo['picurl'];
		}
	}
	$orderListTmp = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_list(' AND goods_id=' . $goodsInfo['id'] . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 6);
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tcsign_goods') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcsign_goods_order') . (' SET order_status=5 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
				}
			}
		}
	}
	$orderData = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_list('AND goods_id=' . $goods_id . ' AND order_status IN(2,3,4)', ' ORDER BY id DESC ', 0, 10);
	$orderList = array();
	if (is_array($orderData) && !empty($orderData)) {
		foreach ($orderData as $key => $value) {
			$orderList[$key] = $value;
			$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$orderList[$key]['userInfo'] = $userInfoTmp;
		}
	}
	$duihuan_guize_txt = dhtmlspecialchars($tcsignConfig['duihuan_guize_txt']);
	$duihuan_guize_txt = discuzcode($duihuan_guize_txt, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);
	$shareTitle = $goodsInfo['title'];
	$shareLogo = $picurl;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=goodsinfo&goods_id=' . $goods_id);
	if ($__ShowTchehuoren == 1) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcsign:goodsinfo');
} elseif ($_GET['mod'] == 'duihuanlist') {
	$goods_id = intval($_GET['goods_id']) > 0 ? intval($_GET['goods_id']) : 0;
	$goodsInfo = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_by_id($goods_id);
	$ajaxLoadDuihuanListUrl = 'plugin.php?id=tom_tcsign:ajax&site=' . $site_id . '&act=duihuanlist&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcsign:duihuanlist');
} elseif ($_GET['mod'] == 'goodsbuy') {
	$address_id = isset($_GET['address_id']) ? intval($_GET['address_id']) : 0;
	$goods_id = isset($_GET['goods_id']) ? intval($_GET['goods_id']) : 0;
	$number = isset($_GET['number']) ? intval($_GET['number']) : 1;
	$goodsInfo = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_by_id($goods_id);
	$goodsPicurl = '';
	if (is_array($goodsInfo) && !empty($goodsInfo['picurl'])) {
		if (!preg_match('/^http/', $goodsInfo['picurl'])) {
			if (strpos($goodsInfo['picurl'], 'source/plugin/') === false) {
				$goodsPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
			} else {
				$goodsPicurl = $_G['siteurl'] . $goodsInfo['picurl'];
			}
		} else {
			$goodsPicurl = $goodsInfo['picurl'];
		}
	}
	$address_back_url = $weixinClass->get_url();
	$address_back_url = preg_replace('/&address_id=[0-9]*/', '', $address_back_url);
	$address_back_url = urlencode($address_back_url);
	$setAddressStatus = 0;
	$setAddressUrl = '';
	$addressListCount = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_count(' AND uid=' . $__MemberInfo['uid'] . ' ');
	if ($addressListCount == 0) {
		$setAddressStatus = 1;
		$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $address_back_url);
	}
	$addressInfo = array();
	$addressInfoTmp = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
	if ($addressInfoTmp && !empty($addressInfoTmp['id'])) {
		$address_id = $addressInfoTmp['id'];
		$addressInfo = $addressInfoTmp;
	} else {
		$defaultAddressList = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_list(' AND uid=' . $__MemberInfo['uid'] . ' AND default_id=1 ', 'ORDER BY id DESC', 0, 1);
		if ($defaultAddressList && !empty($defaultAddressList['0']['id'])) {
			$address_id = $defaultAddressList['0']['id'];
			$addressInfo = $defaultAddressList['0'];
		} else {
			$setAddressStatus = 1;
			$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $address_back_url);
		}
	}
	$changeAddressUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&buying=1&address_id=' . $address_id . '&address_back_url=' . $address_back_url;
	$buy_price = $goodsInfo['buy_price'];
	$buy_price_arr = array();
	for ($i = 1; $i <= 100; $i++) {
		$buy_price_arr[$i] = $buy_price * $i;
	}
	$buy_score = $goodsInfo['buy_score'];
	$buy_score_arr = array();
	for ($i = 1; $i <= 100; $i++) {
		$buy_score_arr[$i] = $buy_score * $i;
	}
	$noPayOrderListTmp = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_list('AND order_status =1 AND goods_id=' . $goodsInfo['id'] . ' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 10);
	$isHaveNoPay = 0;
	if (is_array($noPayOrderListTmp) && !empty($noPayOrderListTmp)) {
		foreach ($noPayOrderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tcsign_goods') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcsign_goods_order') . (' SET order_status=5 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
				} else {
					$isHaveNoPay = 1;
				}
			}
		}
	}
	$xiangouStatus = 0;
	$goods_xiangou_num = 0;
	if ($goodsInfo['xiangou_num'] > 0) {
		$myHaveOrderCount = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_sun_goods_num(' AND goods_id=' . $goodsInfo['id'] . ' AND user_id=' . $__UserInfo['id'] . ' AND order_status IN(2,3,4) ');
		$goods_xiangou_num = $goodsInfo['xiangou_num'] - $myHaveOrderCount;
		if ($myHaveOrderCount >= $goodsInfo['xiangou_num']) {
			$xiangouStatus = 1;
		}
	}
	$orderListTmp = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_list(' AND goods_id=' . $goodsInfo['id'] . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 6);
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tcsign_goods') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcsign_goods_order') . (' SET order_status=5 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
				}
			}
		}
	}
	$ajaxPayUrl = 'plugin.php?id=tom_tcsign:pay&site=' . $site_id . '&act=pay&formhash=' . FORMHASH;
	$backUrl = 'plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=myorder';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcsign:goodsbuy');
} elseif ($_GET['mod'] == 'myorder') {
	$t_id = intval($_GET['t_id']) > 0 ? intval($_GET['t_id']) : 0;
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$whereStr = ' AND user_id = ' . $__UserInfo['id'] . ' ';
	if ($t_id == 1) {
		$whereStr .= ' AND order_status=1 ';
	} elseif ($t_id == 2) {
		$whereStr .= ' AND order_status=2 ';
	} elseif ($t_id == 3) {
		$whereStr .= ' AND order_status=3 ';
	} elseif ($t_id == 4) {
		$whereStr .= ' AND order_status=4 ';
	} else {
		$whereStr .= ' AND order_status IN(1,2,3,4,5) ';
	}
	$orderStr = ' ORDER BY id DESC ';
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_count($whereStr);
	$orderData = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_list($whereStr, $orderStr, $start, $pagesize);
	$orderList = array();
	if (is_array($orderData) && !empty($orderData)) {
		foreach ($orderData as $key => $value) {
			$orderList[$key] = $value;
			$orderList[$key]['pay_time'] = dgmdate($value['pay_time'], 'Y-m-d H:i:s', $tomSysOffset);
			$goodsData = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_by_id($value['goods_id']);
			$goodsPicurl = '';
			if (is_array($goodsData) && !empty($goodsData['picurl'])) {
				if (!preg_match('/^http/', $goodsData['picurl'])) {
					if (strpos($goodsData['picurl'], 'source/plugin/') === false) {
						$goodsPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsData['picurl'];
					} else {
						$goodsPicurl = $_G['siteurl'] . $goodsData['picurl'];
					}
				} else {
					$goodsPicurl = $goodsData['picurl'];
				}
			}
			$orderList[$key]['picurl'] = $goodsPicurl;
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3590) {
					DB::query('UPDATE ' . DB::table('tom_tcsign_goods_order') . (' SET order_status=5 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcsign_goods') . (' SET sale_num=sale_num-' . $value['goods_num'] . ' WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					$orderList[$key]['order_status'] = 5;
				}
			}
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=myorder&t_id=' . $t_id . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=myorder&t_id=' . $t_id . '&page=' . $nextPage;
	$ajaxCancelPayUrl = 'plugin.php?id=tom_tcsign:pay&site=' . $site_id . '&act=cancelpay&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcsign:myorder');
} elseif ($_GET['mod'] == 'myorderinfo') {
	$order_no = !empty($_GET['order_no']) ? addslashes($_GET['order_no']) : '';
	$orderInfo = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_by_order_no($order_no);
	$goodsInfo = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_by_id($orderInfo['goods_id']);
	$goodsPicurl = '';
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/') === false) {
			$goodsPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$goodsPicurl = $_G['siteurl'] . $goodsInfo['picurl'];
		}
	} else {
		$goodsPicurl = $goodsInfo['picurl'];
	}
	$pay_time = dgmdate($orderInfo['pay_time'], 'Y-m-d H:i:s', $tomSysOffset);
	$order_time = dgmdate($orderInfo['order_time'], 'Y-m-d H:i:s', $tomSysOffset);
	$qrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($_G['siteurl'] . ('plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=orderhexiao&order_no=' . $orderInfo['order_no']));
	$ajaxShouhuoUrl = 'plugin.php?id=tom_tcsign:ajax&site=' . $site_id . '&act=shouhuo&formhash=' . FORMHASH;
	$ajaxCancelPayUrl = 'plugin.php?id=tom_tcsign:pay&site=' . $site_id . '&act=cancelpay&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcsign:myorderinfo');
} elseif ($_GET['mod'] == 'orderhexiao') {
	$order_no = !empty($_GET['order_no']) ? addslashes($_GET['order_no']) : '';
	$orderInfo = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_by_order_no($order_no);
	$goodsInfo = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_by_id($orderInfo['goods_id']);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);
	if ($_GET['act'] == 'hexiao' && $_GET['formhash'] == FORMHASH) {
		$updateData = array();
		$updateData['order_status'] = 4;
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['hexiao_time'] = TIMESTAMP;
		C::t('#tom_tcsign#tom_tcsign_goods_order')->update($orderInfo['id'], $updateData);
		echo 200;
		exit(0);
	}
	$goodsPicurl = '';
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/') === false) {
			$goodsPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$goodsPicurl = $_G['siteurl'] . $goodsInfo['picurl'];
		}
	} else {
		$goodsPicurl = $goodsInfo['picurl'];
	}
	$pay_time = dgmdate($orderInfo['pay_time'], 'Y-m-d H:i:s', $tomSysOffset);
	$order_time = dgmdate($orderInfo['order_time'], 'Y-m-d H:i:s', $tomSysOffset);
	$isTcshopClerk = 0;
	$clerkListTmp = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(' AND tcshop_id=' . $orderInfo['tcshop_id'] . ' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 1);
	if ($clerkListTmp[0]['id'] > 0 || $tcshopInfo['user_id'] == $__UserInfo['id']) {
		$isTcshopClerk = 1;
	}
	$hexiaoUserInfo = array();
	if ($orderInfo['order_status'] == 4) {
		$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);
	}
	$showHexiaoBox = 1;
	if ($isTcshopClerk == 0) {
		$showHexiaoBox = 2;
	}
	$hexiaoUrl = 'plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=orderhexiao&act=hexiao&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcsign:orderhexiao');
} elseif ($_GET['mod'] == 'sign') {
	include DISCUZ_ROOT . './source/plugin/tom_tcsign/module/sign.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcsign&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();