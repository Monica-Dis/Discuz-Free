<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = '';

$tom_tcsign_goods_field = C::t('#tom_tcsign#tom_tcsign_goods')->fetch_all_field();
if (!isset($tom_tcsign_goods_field['tcshop_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcsign_goods')." ADD `tcshop_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcsign_goods_field['peisong_type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcsign_goods')." ADD `peisong_type` int(11) DEFAULT '3';\n";
}

$tom_tcsign_goods_order_field = C::t('#tom_tcsign#tom_tcsign_goods_order')->fetch_all_field();
if (!isset($tom_tcsign_goods_order_field['site_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcsign_goods_order')." ADD `site_id` int(11) DEFAULT '1';\n";
}
if (!isset($tom_tcsign_goods_order_field['tcshop_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcsign_goods_order')." ADD `tcshop_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcsign_goods_order_field['peisong_type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcsign_goods_order')." ADD `peisong_type` int(11) DEFAULT '3';\n";
}

$tom_tcsign_renwu_share_field = C::t('#tom_tcsign#tom_tcsign_renwu_share')->fetch_all_field();
if (!isset($tom_tcsign_renwu_share_field['type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcsign_renwu_share')." ADD `type` tinyint(4) DEFAULT '1';\n";
}
if (!isset($tom_tcsign_renwu_share_field['tctoutiao_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcsign_renwu_share')." ADD `tctoutiao_id` int(11) DEFAULT '0';\n";
}

if (!empty($sql)) {
	runquery($sql);
}

$finish = TRUE;