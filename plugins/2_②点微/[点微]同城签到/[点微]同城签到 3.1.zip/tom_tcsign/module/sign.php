<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

$last_sign_time = TIMESTAMP;
$yesterDayTime  = $nowDayTime - 86400;
$signScore      = $nextScore = $signStatus = $yesterStatus = $lianxuDays = 0;

$isDataList = C::t('#tom_tcsign#tom_tcsign_data')->fetch_all_list("AND user_id = {$__UserInfo['id']} AND time_key = {$nowDayTime}"," ORDER BY id DESC ",0,1);
if(is_array($isDataList) && !empty($isDataList[0]) && $isDataList[0]['id'] > 0){
    
    $signStatus = 1;
    $signInfo   = C::t('#tom_tcsign#tom_tcsign')->fetch_by_user_id($__UserInfo['id']);
    $lianxuDays = $signInfo['lianxu_days'];
    
}else{
    
    $isYesterDataList = C::t('#tom_tcsign#tom_tcsign_data')->fetch_all_list("AND user_id = {$__UserInfo['id']} AND time_key = {$yesterDayTime}"," ORDER BY id DESC ",0,1);
    if(is_array($isYesterDataList) && !empty($isYesterDataList[0]) && $isYesterDataList[0]['id'] > 0){
        $yesterStatus = 1;
    }
    
    $signInfo = C::t('#tom_tcsign#tom_tcsign')->fetch_by_user_id($__UserInfo['id']);
    if($signInfo && $signInfo['id'] > 0){
        
        if($yesterStatus == 1 && $signInfo['lianxu_days'] < 7){
            $lianxuDays = $signInfo['lianxu_days'] + 1;
            DB::query("UPDATE ".DB::table('tom_tcsign')." SET all_days = all_days+1,lianxu_days = lianxu_days+1,last_sign_time = {$last_sign_time} WHERE user_id='{$__UserInfo['id']}' ", 'UNBUFFERED');
        }else{
            $lianxuDays = 1;
            DB::query("UPDATE ".DB::table('tom_tcsign')." SET all_days = all_days+1,lianxu_days = 1,last_sign_time = {$last_sign_time} WHERE user_id='{$__UserInfo['id']}' ", 'UNBUFFERED');
        }
        
    }else{
        $lianxuDays = 1;
        $insertData = array();
        $insertData['user_id']            = $__UserInfo['id'];
        $insertData['lianxu_days']        = 1;
        $insertData['all_days']           = 1;
        $insertData['last_sign_time']     = TIMESTAMP;
        C::t('#tom_tcsign#tom_tcsign')->insert($insertData);
    }
    
    if($lianxuDays == 1){
        $signScore = $tcsignConfig['no1_score'];
    }else if($lianxuDays == 2){
        $signScore = $tcsignConfig['no2_score'];
    }else if($lianxuDays == 3){
        $signScore = $tcsignConfig['no3_score'];
    }else if($lianxuDays == 4){
        $signScore = $tcsignConfig['no4_score'];
    }else if($lianxuDays == 5){
        $signScore = $tcsignConfig['no5_score'];
    }else if($lianxuDays == 6){
        $signScore = $tcsignConfig['no6_score'];
    }else if($lianxuDays == 7){
        $signScore = $tcsignConfig['no7_score'];
    }
    
    $insertData = array();
    $insertData['user_id']      = $__UserInfo['id'];
    $insertData['year']         = $nowYear;
    $insertData['month']        = $nowMonth;
    $insertData['day']          = $nowDay;
    $insertData['score']        = $signScore;
    $insertData['no_days']      = $lianxuDays;
    $insertData['time_key']     = $nowDayTime;
    $insertData['sign_time']    = TIMESTAMP;
    C::t('#tom_tcsign#tom_tcsign_data')->insert($insertData);
    
    $insertData = array();
    $insertData['user_id']          = $__UserInfo['id'];
    $insertData['score_value']      = $signScore;
    $insertData['old_value']        = $__UserInfo['score'];
    $insertData['log_type']         = 24;
    $insertData['log_time']         = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    
    DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET score = score+{$signScore} WHERE id='{$__UserInfo['id']}' ", 'UNBUFFERED');
    
    $isMonthList = C::t('#tom_tcsign#tom_tcsign_month')->fetch_all_list("AND user_id = {$__UserInfo['id']} AND year = {$nowYear} AND month = {$nowMonth}"," ORDER BY id DESC ",0,1);
    if(is_array($isMonthList) && !empty($isMonthList)){
        DB::query("UPDATE ".DB::table('tom_tcsign_month')." SET days = days+1 WHERE user_id='{$__UserInfo['id']}' AND year = {$nowYear} AND month = {$nowMonth} ", 'UNBUFFERED');
    }else{
        $insertData = array();
        $insertData['user_id']      = $__UserInfo['id'];
        $insertData['year']         = $nowYear;
        $insertData['month']        = $nowMonth;
        $insertData['days']          = 1;
        C::t('#tom_tcsign#tom_tcsign_month')->insert($insertData);
    }
}

if($lianxuDays == 1){
    $nextScore = $tcsignConfig['no2_score'];
}else if($lianxuDays == 2){
    $nextScore = $tcsignConfig['no3_score'];
}else if($lianxuDays == 3){
    $nextScore = $tcsignConfig['no4_score'];
}else if($lianxuDays == 4){
    $nextScore = $tcsignConfig['no5_score'];
}else if($lianxuDays == 5){
    $nextScore = $tcsignConfig['no6_score'];
}else if($lianxuDays == 6){
    $nextScore = $tcsignConfig['no7_score'];
}else if($lianxuDays == 7){
    $nextScore = $tcsignConfig['no1_score'];
}

$renwu_fenlei_score = $tcsignConfig['renwu_fenlei_score'] * $tcsignConfig['renwu_fenlei_num'];
$renwu_share_score = $tcsignConfig['renwu_share_score'] * $tcsignConfig['renwu_share_num'];
$renwu_tshare_score = $tcsignConfig['renwu_tshare_score'] * $tcsignConfig['renwu_tshare_num'];

$todayFenleiRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count("AND user_id = {$__UserInfo['id']} AND renwu_type = 'fenlei' AND time_key = {$nowDayTime}");
$todayShopRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count("AND user_id = {$__UserInfo['id']} AND renwu_type = 'shop' AND time_key = {$nowDayTime}");
$todayQianggouRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count("AND user_id = {$__UserInfo['id']} AND renwu_type = 'qianggou' AND time_key = {$nowDayTime}");
$todayToutiaoRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count("AND user_id = {$__UserInfo['id']} AND renwu_type = 'toutiao' AND time_key = {$nowDayTime}");
$todayMallRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count("AND user_id = {$__UserInfo['id']} AND renwu_type = 'mall' AND time_key = {$nowDayTime}");
$todayPtuanRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_data')->fetch_all_count("AND user_id = {$__UserInfo['id']} AND renwu_type = 'ptuan' AND time_key = {$nowDayTime}");
$todayShareRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_share')->fetch_all_count("AND user_id = {$__UserInfo['id']} AND time_key = {$nowDayTime} AND type = 1 ");
$todayTshareRenwuCount = C::t('#tom_tcsign#tom_tcsign_renwu_share')->fetch_all_count("AND user_id = {$__UserInfo['id']} AND time_key = {$nowDayTime} AND type = 2 ");

$monthCount = C::t('#tom_tcsign#tom_tcsign_month')->fetch_all_count("AND year = {$nowYear} AND month = {$nowMonth}");
$monthData = C::t('#tom_tcsign#tom_tcsign_month')->fetch_all_list("AND year = {$nowYear} AND month = {$nowMonth}"," ORDER BY days DESC,id ASC ",0,10);
$monthList = array();
if(is_array($monthData) && !empty($monthData)){
    foreach($monthData as $key => $value){
        $key++;
        $monthList[$key] = $value;
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $monthList[$key]['user'] = $userInfo;
    }
}

$focuspicData = C::t('#tom_tcsign#tom_tcsign_focuspic')->fetch_all_list(" AND site_id={$site_id} AND type_id=2 "," ORDER BY fsort ASC,id DESC ",0,10);
if(is_array($focuspicData) && !empty($focuspicData)){
}else{
    $focuspicData = C::t('#tom_tcsign#tom_tcsign_focuspic')->fetch_all_list(" AND site_id=1 AND type_id=2 "," ORDER BY fsort ASC,id DESC ",0,10);
}
$focuspicList = array();
if(is_array($focuspicData) && !empty($focuspicData)){
    foreach($focuspicData as $key => $value){
        $focuspicList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl'])){
            $focuspicList[$key]['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $focuspicList[$key]['picurl'] = $value['picurl'];
        }
    }
}

$sign_guize_txt = discuzcode($tcsignConfig['sign_guize_txt'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);

$ajaxLoadPhbListUrl    = 'plugin.php?id=tom_tcsign:ajax&act=phblist&formhash='.$formhash;

$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tcsign&site={$site_id}&mod=sign";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcsign:sign");