<?php

/**
   Copyright 2001-2099 DisM!Ӧ������.
   This is NOT a freeware, use is subject to license terms
   Ӧ�ø���֧�֣�https://dism.taobao.com
   ���²����http://t.cn/Aiux1Jx1
 * 
 * shouyi_status    1 ������  2 ���˳ɹ�  3 ���˿�
 * handle_status    0 δͳ�� 1 ��ͳ�� (���ڸ��ºϻ��˱�����)
 * 
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tchehuoren_shouyi extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
		$this->_table = 'tom_tchehuoren_shouyi';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
    
    public function fetch_by_order_no($order_no,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE order_no=%s", array($this->_table, $order_no));
	}
	
    public function fetch_all_list($condition,$orders = '',$start = 0,$limit = 10) {
		$data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
		return $data;
	}
	
    public function fetch_field_list($condition,$field='*',$orders = '',$start = 0,$limit = 0) {
        if($limit > 0){
            $data = DB::fetch_all("SELECT $field FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        }else{
            $data = DB::fetch_all("SELECT $field FROM %t WHERE 1 %i $orders",array($this->_table,$condition));
        }
		return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_total_shouyi_sum($condition) {
        $return = DB::fetch_first("SELECT SUM(shouyi_price) AS num FROM ".DB::table($this->_table)." WHERE shouyi_status = 2 $condition ");
		return $return['num'];
	}
    
    public function fetch_shouyi_sum($condition) {
        $return = DB::fetch_first("SELECT SUM(shouyi_price) AS num FROM ".DB::table($this->_table)." WHERE shouyi_status in(1,2) $condition ");
		return $return['num'];
	}
    
    public function fetch_dai_shouyi_sum($condition) {
        $return = DB::fetch_first("SELECT SUM(shouyi_price) AS num FROM ".DB::table($this->_table)." WHERE shouyi_status = 1 $condition ");
        if($return['num'] > 0){
            return $return['num'];
        }else{
            return 0;
        }
	}
    
    public function fetch_all_count($condition) {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

}