<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/plugin');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $sql = '';

    $tom_tchehuoren_field = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_field();
    if (!isset($tom_tchehuoren_field['all_money'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren` ADD `all_money` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tchehuoren_field['month_money'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren` ADD `month_money` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tchehuoren_field['week_money'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren` ADD `week_money` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tchehuoren_field['expire_time'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren` ADD `expire_time` int(11) unsigned DEFAULT '0';\n";
        $sql .= "UPDATE `pre_tom_tchehuoren` SET expire_time = kaohe_time;\n";
    }
    if (!isset($tom_tchehuoren_field['open_xu_money'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren` ADD `open_xu_money` tinyint(4) DEFAULT '0';\n";
    }

    $tom_tchehuoren_dengji_field = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_all_field();
    if (!isset($tom_tchehuoren_dengji_field['pt_fc_open'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `pt_fc_open` int(11) DEFAULT '1';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['114_fc_open'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `114_fc_open` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['114_fc_scale'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `114_fc_scale` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['vip_fc_open'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `vip_fc_open` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['vip_fc_scale'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `vip_fc_scale` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['mall_fc_open'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `mall_fc_open` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['zp_fc_open'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `zp_fc_open` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['zp_fc_scale'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `zp_fc_scale` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['hehuoren_fc_scale'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `hehuoren_fc_scale` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['hd_fc_open'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `hd_fc_open` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['fc_fc_open'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `fc_fc_open` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['fc_fc_scale'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `fc_fc_scale` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['fans_num'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `fans_num` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['subordinate_num'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `subordinate_num` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['open_pay'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `open_pay` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['pay_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `pay_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['days'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `days` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['tui_fc_open'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `tui_fc_open` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['ershou_fc_open'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `ershou_fc_open` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['ershou_fc_scale'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `ershou_fc_scale` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['daojia_fc_open'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `daojia_fc_open` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['edu_fc_open'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `edu_fc_open` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_dengji_field['edu_fc_scale'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_dengji` ADD `edu_fc_scale` int(11) DEFAULT '0';\n";
    }
    
    $tom_tchehuoren_shouyi_field = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_all_field();
    if (!isset($tom_tchehuoren_shouyi_field['handle_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_shouyi` ADD `handle_status` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tchehuoren_shouyi_field['plugin_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_shouyi` ADD `plugin_id` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tchehuoren_shouyi_field['title'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_shouyi` ADD `title` varchar(255) DEFAULT NULL;\n";
    }
    if (isset($tom_tchehuoren_shouyi_field['title']) && $tom_tchehuoren_shouyi_field['title']['Type'] == 'varchar(11)') {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_shouyi` CHANGE `title` `title` varchar(255) DEFAULT NULL;\n";
    }

    $tom_tchehuoren_shenqing_field = C::t('#tom_tchehuoren#tom_tchehuoren_shenqing')->fetch_all_field();
    if (!isset($tom_tchehuoren_shenqing_field['site_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_shenqing` ADD `site_id` int(11) DEFAULT '1';\n";
    }
    if (!isset($tom_tchehuoren_shenqing_field['pay_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_shenqing` ADD `pay_status` tinyint(4) DEFAULT '0';\n";
    }
    
    if (!empty($sql)) {
        runquery($sql);
    }
    
    $sql = <<<EOF
    CREATE TABLE IF NOT EXISTS `pre_tom_tchehuoren_yushouyi` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `order_no` varchar(255) DEFAULT NULL,
      `hehuoren_id` int(11) DEFAULT '0',
      `ly_user_id` int(11) DEFAULT '0',
      `child_hehuoren_id` int(11) DEFAULT '0',
      `today_time` int(11) DEFAULT '0',
      `week_time` int(11) DEFAULT '0',
      `month_time` int(11) DEFAULT '0',
      `type` varchar(255) DEFAULT NULL,
      `shouyi_price` decimal(10,2) DEFAULT '0.00',
      `content` text,
      `shouyi_status` tinyint(11) DEFAULT '0',
      `shouyi_time` int(11) DEFAULT '0',
      `status` int(11) DEFAULT '0',
      `add_time` int(11) DEFAULT '0',
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`),
      KEY `sy_order_no` (`order_no`)
    ) ENGINE=MyISAM;
    CREATE TABLE IF NOT EXISTS `pre_tom_tchehuoren_order` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `site_id` int(11) DEFAULT '1',
        `order_no` varchar(255) DEFAULT NULL,
        `user_id` int(11) DEFAULT '0',
        `hehuoren_id` int(11) DEFAULT '0',
        `tj_hehuoren_id` int(11) DEFAULT '0',
        `openid` varchar(255) DEFAULT NULL,
        `dengji_id` int(11) DEFAULT '0',
        `days` int(11) DEFAULT '0',
        `pay_price` decimal(10,2) DEFAULT '0.00',
        `pay_time` int(11) DEFAULT '0',
        `order_status` int(11) DEFAULT '0',
        `order_time` int(11) DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_order_no` (`order_no`)
    ) ENGINE=MyISAM;
    CREATE TABLE IF NOT EXISTS `pre_tom_tchehuoren_dengji_code` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `dengji_id` int(11) DEFAULT '0',
        `dengji_days` int(11) DEFAULT '0',
        `code` varchar(255) DEFAULT NULL,
        `use_status` int(11) DEFAULT '0',
        `user_id` int(11) DEFAULT '0',
        `hehuoren_id` int(11) DEFAULT '0',
        `use_time` int(11) unsigned DEFAULT '0',
        `add_time` int(11) unsigned DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
    CREATE TABLE IF NOT EXISTS `pre_tom_tchehuoren_tui` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `order_no` varchar(255) DEFAULT NULL,
        `site_id` int(11) DEFAULT '1',
        `plugin_id` varchar(255) DEFAULT NULL,
        `tongcheng_id` int(11) DEFAULT '0',
        `toutiao_id` int(11) DEFAULT '0',
        `zhaopin_id` int(11) DEFAULT '0',
        `fangchan_id` int(11) DEFAULT '0',
        `ershou_id` int(11) DEFAULT '0',
        `all_money` decimal(10,2) DEFAULT '0.00',
        `sy_money` decimal(10,2) DEFAULT '0.00',
        `click_money` decimal(10,2) DEFAULT '0.00',
        `click_num` int(11) DEFAULT '0',
        `add_type` tinyint(4) DEFAULT '0',
        `pay_status` tinyint(4) DEFAULT '0',
        `status` tinyint(4) DEFAULT '0',
        `is_show` tinyint(4) DEFAULT '1',
        `add_time` int(11) DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
    CREATE TABLE IF NOT EXISTS `pre_tom_tchehuoren_tui_log` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `tui_id` int(11) DEFAULT '0',
        `hehuoren_id` int(11) DEFAULT '0',
        `click_user_id` int(11) DEFAULT '0',
        `click_money` decimal(10,2) DEFAULT '0.00',
        `click_ip` int(11) unsigned DEFAULT '0',
        `sms_status` tinyint(4) DEFAULT '0',
        `log_time` int(11) unsigned DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
EOF;

    runquery($sql);
    
    
    $sql = '';
    
    $tom_tchehuoren_yushouyi_field = C::t('#tom_tchehuoren#tom_tchehuoren_yushouyi')->fetch_all_field();
    if (!isset($tom_tchehuoren_yushouyi_field['plugin_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_yushouyi` ADD `plugin_id` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tchehuoren_yushouyi_field['title'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_yushouyi` ADD `title` varchar(255) DEFAULT NULL;\n";
    }
    
    $tom_tchehuoren_order_field = C::t('#tom_tchehuoren#tom_tchehuoren_order')->fetch_all_field();
    if (!isset($tom_tchehuoren_order_field['type'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_order` ADD `type` int(11) DEFAULT '0';\n";
    }
    
    $tom_tchehuoren_tui_field = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_field();
    if (!isset($tom_tchehuoren_tui_field['topic_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_tui` ADD `topic_id` int(11) DEFAULT '0';\n";
    }
    
    $tom_tchehuoren_tui_log_field = C::t('#tom_tchehuoren#tom_tchehuoren_tui_log')->fetch_all_field();
    if (!isset($tom_tchehuoren_tui_log_field['click_ip_region'])) {
        $sql .= "ALTER TABLE `pre_tom_tchehuoren_tui_log` ADD `click_ip_region` varchar(255) DEFAULT NULL;\n";
    }
    
    runquery($sql);
    
    echo 'OK';exit;
    
}else{
    exit('Access Denied');
}