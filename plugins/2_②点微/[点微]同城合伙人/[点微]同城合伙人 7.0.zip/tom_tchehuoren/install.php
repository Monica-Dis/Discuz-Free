<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tchehuoren`;
CREATE TABLE `pre_tom_tchehuoren` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) NOT NULL,
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `week_money` decimal(10,2) DEFAULT '0.00',
  `month_money` decimal(10,2) DEFAULT '0.00',
  `all_money` decimal(10,2) DEFAULT '0.00',
  `dengji_id` int(11) DEFAULT '0',
  `invite_id` int(11) DEFAULT '0',
  `invite_code` varchar(255) DEFAULT NULL,
  `open_xu_money` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT '1',
  `kaohe_time` int(11) DEFAULT '0',
  `expire_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchehuoren_kaohe_log`;
CREATE TABLE `pre_tom_tchehuoren_kaohe_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hehuoren_id` int(11) DEFAULT '0',
  `text` text,
  `old_dengji` int(11) DEFAULT '0',
  `new_dengji` int(11) DEFAULT '0',
  `log_status` tinyint(4) DEFAULT '0',
  `log_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tchehuoren_common_problem`;
CREATE TABLE `pre_tom_tchehuoren_common_problem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '0',
  `content` text,
  `zhuanshu_picurl` varchar(255) DEFAULT NULL,
  `paixu` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchehuoren_dengji`;
CREATE TABLE `pre_tom_tchehuoren_dengji` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `tuijian_fc_scale` varchar(255) DEFAULT NULL,
  `tui_fc_open` tinyint(4) DEFAULT '0',
  `fl_fc_open` varchar(255) DEFAULT NULL,
  `fl_fc_scale` int(11) DEFAULT '0',
  `shop_fc_open` varchar(255) DEFAULT NULL,
  `shop_fc_scale` int(11) DEFAULT '0',
  `qg_fc_open` varchar(255) DEFAULT NULL,
  `pt_fc_open` int(11) DEFAULT '1',
  `mall_fc_open` int(11) DEFAULT '0',
  `hd_fc_open` int(11) DEFAULT '0',
  `114_fc_open` int(11) DEFAULT '0',
  `114_fc_scale` int(11) DEFAULT '0',
  `vip_fc_open` int(11) DEFAULT '0',
  `vip_fc_scale` int(11) DEFAULT '0',
  `zp_fc_open` int(11) DEFAULT '0',
  `zp_fc_scale` int(11) DEFAULT '0',
  `fc_fc_open` int(11) DEFAULT '0',
  `fc_fc_scale` int(11) DEFAULT '0',
  `hehuoren_fc_scale` int(11) DEFAULT '0',
  `ershou_fc_open` int(11) DEFAULT '0',
  `ershou_fc_scale` int(11) DEFAULT '0',
  `daojia_fc_open` int(11) DEFAULT '0',
  `edu_fc_open` tinyint(4) DEFAULT '0',
  `edu_fc_scale` int(11) DEFAULT '0',
  `up_level` int(11) DEFAULT '0',
  `fans_num` int(11) DEFAULT '0',
  `subordinate_num` int(11) DEFAULT '0',
  `open_pay` tinyint(4) DEFAULT '0',
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `days` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchehuoren_dengji_shenqing`;
CREATE TABLE `pre_tom_tchehuoren_dengji_shenqing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hehuoren_id` int(11) DEFAULT '0',
  `dengji_id` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchehuoren_shenqing`;
CREATE TABLE `pre_tom_tchehuoren_shenqing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `order_no` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `pay_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sq_order_no` (`order_no`)      
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchehuoren_shouyi`;
CREATE TABLE `pre_tom_tchehuoren_shouyi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugin_id` varchar(255) DEFAULT NULL,
  `order_no` varchar(255) DEFAULT NULL,
  `hehuoren_id` int(11) DEFAULT '0',
  `ly_user_id` int(11) DEFAULT '0',
  `child_hehuoren_id` int(11) DEFAULT '0',
  `today_time` int(11) DEFAULT '0',
  `week_time` int(11) DEFAULT '0',
  `month_time` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `shouyi_price` decimal(10,2) DEFAULT '0.00',
  `content` text,
  `shouyi_status` tinyint(11) DEFAULT '0',
  `handle_status` tinyint(4) DEFAULT '0',
  `shouyi_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sy_order_no` (`order_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchehuoren_tz`;
CREATE TABLE `pre_tom_tchehuoren_tz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text,
  `link` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchehuoren_tz_log`;
CREATE TABLE `pre_tom_tchehuoren_tz_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tz_id` int(11) DEFAULT '0',
  `hehuoren_id` int(11) DEFAULT '0',
  `log_status` tinyint(4) DEFAULT '0',
  `log_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchehuoren_yushouyi`;
CREATE TABLE `pre_tom_tchehuoren_yushouyi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugin_id` varchar(255) DEFAULT NULL,
  `order_no` varchar(255) DEFAULT NULL,
  `hehuoren_id` int(11) DEFAULT '0',
  `ly_user_id` int(11) DEFAULT '0',
  `child_hehuoren_id` int(11) DEFAULT '0',
  `today_time` int(11) DEFAULT '0',
  `week_time` int(11) DEFAULT '0',
  `month_time` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `shouyi_price` decimal(10,2) DEFAULT '0.00',
  `content` text,
  `shouyi_status` tinyint(11) DEFAULT '0',
  `shouyi_time` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sy_order_no` (`order_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchehuoren_order`;
CREATE TABLE `pre_tom_tchehuoren_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `order_no` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `hehuoren_id` int(11) DEFAULT '0',
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `dengji_id` int(11) DEFAULT '0',
  `days` int(11) DEFAULT '0',
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `pay_time` int(11) DEFAULT '0',
  `order_status` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchehuoren_dengji_code`;
CREATE TABLE `pre_tom_tchehuoren_dengji_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dengji_id` int(11) DEFAULT '0',
  `dengji_days` int(11) DEFAULT '0',
  `code` varchar(255) DEFAULT NULL,
  `use_status` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `hehuoren_id` int(11) DEFAULT '0',
  `use_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchehuoren_tui`;
CREATE TABLE `pre_tom_tchehuoren_tui` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(255) DEFAULT NULL,
  `site_id` int(11) DEFAULT '1',
  `plugin_id` varchar(255) DEFAULT NULL,
  `tongcheng_id` int(11) DEFAULT '0',
  `toutiao_id` int(11) DEFAULT '0',
  `zhaopin_id` int(11) DEFAULT '0',
  `fangchan_id` int(11) DEFAULT '0',
  `ershou_id` int(11) DEFAULT '0',
  `topic_id` int(11) DEFAULT '0',
  `all_money` decimal(10,2) DEFAULT '0.00',
  `sy_money` decimal(10,2) DEFAULT '0.00',
  `click_money` decimal(10,2) DEFAULT '0.00',
  `click_num` int(11) DEFAULT '0',
  `add_type` tinyint(4) DEFAULT '0',
  `pay_status` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `is_show` tinyint(4) DEFAULT '1',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tchehuoren_tui_log`;
CREATE TABLE `pre_tom_tchehuoren_tui_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tui_id` int(11) DEFAULT '0',
  `hehuoren_id` int(11) DEFAULT '0',
  `click_user_id` int(11) DEFAULT '0',
  `click_money` decimal(10,2) DEFAULT '0.00',
  `click_ip` int(11) unsigned DEFAULT '0',
  `click_ip_region` varchar(255) DEFAULT NULL,
  `sms_status` tinyint(4) DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
