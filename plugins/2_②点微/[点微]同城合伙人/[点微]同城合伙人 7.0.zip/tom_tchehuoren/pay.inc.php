<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$tchehuorenConfig   = $_G['cache']['plugin']['tom_tchehuoren'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
$tomSysOffset       = getglobal('setting/timeoffset');
$nowDayTime         = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime       = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime        = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);
$appid = trim($tongchengConfig['wxpay_appid']);  
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

include DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/class/function.core.php';

$act = isset($_GET['act'])? addslashes($_GET['act']):"add";

if($act == "add" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $tj_hehuoren_id = isset($_GET['tj_hehuoren_id'])?intval($_GET['tj_hehuoren_id']):0;
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    $hehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($userInfo['id']);
    if(is_array($hehuorenInfo) && !empty($hehuorenInfo)){
        $outArr['status'] = 301;
        echo json_encode($outArr); exit;
    }
    
    $shenqingListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_shenqing')->fetch_all_list(" AND user_id = {$userInfo['id']} AND status = 1 AND pay_status IN(0,2) ","ORDER BY id DESC",0,10);
    if(is_array($shenqingListTmp) && !empty($shenqingListTmp)){
        $outArr['status'] = 302;
        echo json_encode($outArr); exit;
    }
    
    if(empty($userInfo['tel']) && $tchehuorenConfig['must_bind_tel']==1){
        $outArr['status'] = 303;
        echo json_encode($outArr); exit;
    }
    
    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['order_no']         = $order_no;
    $insertData['user_id']          = $userInfo['id'];
    if($tchehuorenConfig['open_subordinate'] == 1){
        $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
    }else{
        $insertData['tj_hehuoren_id']   = 0;
    }
    $insertData['openid']           = $userInfo['openid'];
    $insertData['xm']               = $userInfo['nickname'];
    $insertData['tel']              = $userInfo['tel'];
    if($tchehuorenConfig['open_shenhe'] == 1){
        $insertData['status']   = 1;
    }else{
        $insertData['status']   = 2;
    }
    if($tchehuorenConfig['open_pay_hehuoren'] == 1){
        $insertData['pay_status']   = 1;
    }else{
        $insertData['pay_status']   = 0;
    }
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tchehuoren#tom_tchehuoren_shenqing')->insert($insertData);
    $shenqingId = C::t('#tom_tchehuoren#tom_tchehuoren_shenqing')->insert_id();
    
    if($tchehuorenConfig['open_pay_hehuoren'] == 1){
        ## pay start
        if($tchehuorenConfig['hehuoren_pay_money'] > 0){
            
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'status'=> 304,
                );
                echo json_encode($outArr); exit;
            }
            
            $pay_price = $tchehuorenConfig['hehuoren_pay_money'];
            
            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['order_no']         = $order_no;
            $insertData['type']             = 1;
            $insertData['user_id']          = $userInfo['id'];
            $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
            $insertData['openid']           = $userInfo['openid'];
            $insertData['pay_price']        = $pay_price;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tchehuoren#tom_tchehuoren_order')->insert($insertData)){
                
                $order_id = C::t('#tom_tchehuoren#tom_tchehuoren_order')->insert_id();
                
                $insertData = array();
                $insertData['plugin_id']       = 'tom_tchehuoren';
                $insertData['order_no']        = $order_no;
                $insertData['goods_id']        = $order_id; 
                $insertData['goods_name']      = $tchehuorenConfig['hehuoren_name'].lang('plugin/tom_tchehuoren','pay_shenqing_order');
                $insertData['goods_beizu']     = $tchehuorenConfig['hehuoren_name'].lang('plugin/tom_tchehuoren','pay_shenqing_order');
                $insertData['goods_url']       = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=add";
                $insertData['succ_back_url']   = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=index";
                $insertData['fail_back_url']   = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=add";
                $insertData['allow_alipay']    = 1;         
                $insertData['pay_price']       = $pay_price;    
                $insertData['order_status']    = 1;             
                $insertData['add_time']        = TIMESTAMP;     
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    $outArr = array(
                        'status' => 200,
                        'paystatus' => 1,
                        'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                    );
                    echo json_encode($outArr); exit;

                }else{
                    $outArr = array(
                        'status'=> 307,
                    );
                    echo json_encode($outArr); exit;
                }
                
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
            
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
        ## pay end
    }else{
        
        if($tchehuorenConfig['open_shenhe'] == 1){
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($tongchengConfig['manage_user_id'])){
                $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
                if(!empty($userInfoTmp['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$site_id}&mod=index");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tchehuoren', 'ajax_template_shenhe_1').$tchehuorenConfig['hehuoren_name'].lang('plugin/tom_tchehuoren', 'ajax_template_shenhe_2'),
                        'keyword1'      => $tchehuorenConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );
                    if(!empty($tchehuorenConfig['template_id'])){
                        $template_id = $tchehuorenConfig['template_id'];
                    }else{
                        $template_id = $tongchengConfig['template_id'];
                    }
                    @$r = $templateSmsClass->sendSms01($userInfoTmp['openid'], $template_id, $smsData);
                }
            }
            
        }else{

            $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_list('', 'ORDER BY invite_id DESC,id DESC', 0, 1);
            $dengjiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_all_list(' AND level = 1 ', 'ORDER BY level DESC, id DESC', 0, 1);
            $invite_id = 11111;
            if(is_array($tchehuorenInfoTmp) && !empty($tchehuorenInfoTmp[0])){
                if($tchehuorenInfoTmp[0]['invite_id'] >= 11111){
                    $invite_id  = $tchehuorenInfoTmp[0]['invite_id'] + 1;
                }
            }

            $inviteStr = tom_random(1, 'qwertyupasdfghkzxcvbnm');
            $invite_code = $inviteStr.$invite_id;

            $insertData = array();
            $insertData['user_id']              = $userInfo['id'];
            if($tchehuorenConfig['open_subordinate'] == 1){
                $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
            }else{
                $insertData['tj_hehuoren_id']   = 0;
            }
            $insertData['picurl']               = $userInfo['picurl'];
            $insertData['xm']                   = $userInfo['nickname'];
            $insertData['tel']                  = $userInfo['tel'];
            $insertData['openid']               = $userInfo['openid'];
            $insertData['dengji_id']            = $dengjiInfo[0]['id'];
            $insertData['invite_id']            = $invite_id;
            $insertData['invite_code']          = $invite_code;
            $insertData['add_time']             = TIMESTAMP;
            C::t('#tom_tchehuoren#tom_tchehuoren')->insert($insertData);

            if($access_token && !empty($tongchengConfig['manage_user_id'])){
                $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
                if(!empty($userInfoTmp['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&mod=index");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tchehuoren', 'pay_template_new_hehuoren_1').$tchehuorenConfig['hehuoren_name'].lang('plugin/tom_tchehuoren', 'pay_template_new_hehuoren_2'),
                        'keyword1'      => $tchehuorenConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );
                    if(!empty($tchehuorenConfig['template_id'])){
                        $template_id = $tchehuorenConfig['template_id'];
                    }else{
                        $template_id = $tongchengConfig['template_id'];
                    }
                    @$r = $templateSmsClass->sendSms01($userInfoTmp['openid'], $template_id, $smsData);
                }
            }

        }
        
        $outArr['status'] = 200;
        echo json_encode($outArr); exit;
    
    }
    
}else if($act == "free_level" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $dengji_id  = intval($_GET['dengji_id'])>0? intval($_GET['dengji_id']):0;
    $user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($user_id);
    $dengjiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($dengji_id);
    if(!$userInfo || !$tchehuorenInfo || !$dengjiInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($dengjiInfo['level'] == 1){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tchehuorenInfo['expire_time'] > TIMESTAMP){
        $myDengjiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
        if($dengjiInfo['level'] == $myDengjiInfo['level'] && ($tchehuorenInfo['expire_time'] - TIMESTAMP) > 86400*3){
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
        if($dengjiInfo['level'] < $myDengjiInfo['level']){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $upLevelFansStatus = 0;
    if($dengjiInfo['fans_num'] > 0){
        $fansCount = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_count(" AND tj_hehuoren_id = {$tchehuorenInfo['id']} ");
        if($fansCount >= $dengjiInfo['fans_num']){
            $upLevelFansStatus = 1;
        }
    }else if($dengjiInfo['fans_num'] == 0){
        $upLevelFansStatus = 1;
    }
    
    $upLevelSubStatus = 0;
    if($dengjiInfo['subordinate_num'] > 0){
        $subordinateCount = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_count(" AND tj_hehuoren_id = {$tchehuorenInfo['id']} ");
        if($subordinateCount >= $dengjiInfo['subordinate_num']){
            $upLevelSubStatus = 1;
        }
    }else if($dengjiInfo['subordinate_num'] == 0){
        $upLevelSubStatus = 1;
    }
    
    $upLevelMoneyStatus = 0;
    if($dengjiInfo['up_level'] > 0){
        $monthMoney = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_shouyi_sum(" AND hehuoren_id = {$tchehuorenInfo['id']} AND month_time = {$nowMonthTime} ");
        $monthMoney = number_format(floatval($monthMoney), 2, '.', '');
        if($monthMoney >= $dengjiInfo['up_level']){
            $upLevelMoneyStatus = 1;
        }
    }else if($dengjiInfo['up_level'] == 0){
        $upLevelMoneyStatus = 1;
    }
    
    if($upLevelFansStatus == 1 && $upLevelSubStatus == 1 && $upLevelMoneyStatus == 1){
        
        $updateData = array();
        $updateData['dengji_id']        = $dengjiInfo['id'];
        $updateData['expire_time']      = TIMESTAMP + $dengjiInfo['days'] * 86400;
        C::t('#tom_tchehuoren#tom_tchehuoren')->update($tchehuorenInfo['id'], $updateData);
        
        $outArr = array(
            'status' => 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "pay_level" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $dengji_id  = intval($_GET['dengji_id'])>0? intval($_GET['dengji_id']):0;
    $user_id    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($user_id);
    $dengjiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($dengji_id);
    if(!$userInfo || !$tchehuorenInfo || !$dengjiInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($dengjiInfo['level'] == 1){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tchehuorenInfo['expire_time'] > TIMESTAMP){
        $myDengjiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
        if($dengjiInfo['level'] < $myDengjiInfo['level']){
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($dengjiInfo['open_pay'] == 1 && $dengjiInfo['pay_price'] > 0){
    
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }

        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        
        $pay_price = $dengjiInfo['pay_price'];
        
        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['order_no']         = $order_no;
        $insertData['type']             = 2;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['hehuoren_id']      = $tchehuorenInfo['id'];
        $insertData['tj_hehuoren_id']   = $tchehuorenInfo['tj_hehuoren_id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['dengji_id']        = $dengjiInfo['id'];
        $insertData['days']             = $dengjiInfo['days'];
        $insertData['pay_price']        = $pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tchehuoren#tom_tchehuoren_order')->insert($insertData)){
            $order_id = C::t('#tom_tchehuoren#tom_tchehuoren_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tchehuoren';          
            $insertData['order_no']        = $order_no;                 
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = $dengjiInfo['name'];
            $insertData['goods_beizu']     = '';
            $insertData['goods_url']       = 'plugin.php?id=tom_tchehuoren&site='.$site_id.'&mod=level';
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tchehuoren&site='.$site_id.'&mod=level';
            $insertData['fail_back_url']   = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=level"; 
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 307,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "code_level" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $code    = isset($_GET['code'])? daddslashes(diconv(urldecode($_GET['code']),'utf-8')):'';
    
    $codeInfo = C::t('#tom_tchehuoren#tom_tchehuoren_dengji_code')->fetch_by_code($code);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($user_id);
    
    if(!$userInfo || !$tchehuorenInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(empty($codeInfo)){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($codeInfo['use_status'] == 1){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $dengjiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($codeInfo['dengji_id']);
    if(empty($dengjiInfo)){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tchehuorenInfo['expire_time'] > TIMESTAMP){
        $myDengjiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
        if($dengjiInfo['level'] < $myDengjiInfo['level']){
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    
    $updateData = array();
    $updateData['dengji_id']        = $dengjiInfo['id'];
    $updateData['expire_time']      = TIMESTAMP + $codeInfo['dengji_days'] * 86400;
    C::t('#tom_tchehuoren#tom_tchehuoren')->update($tchehuorenInfo['id'], $updateData);
    
    $updateData = array();
    $updateData['use_status']   = 1;
    $updateData['user_id']      = $userInfo['id'];
    $updateData['hehuoren_id']  = $tchehuorenInfo['id'];
    $updateData['use_time']     = TIMESTAMP;
    C::t('#tom_tchehuoren#tom_tchehuoren_dengji_code')->update($codeInfo['id'], $updateData);
    
    $outArr = array(
        'status' => 200,
    );
    echo json_encode($outArr); exit;

}else if($act == "add_tui" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $tongcheng_id   = isset($_GET['tongcheng_id'])?intval($_GET['tongcheng_id']):0;
    $zhaopin_id     = isset($_GET['zhaopin_id'])?intval($_GET['zhaopin_id']):0;
    $fangchan_id    = isset($_GET['fangchan_id'])?intval($_GET['fangchan_id']):0;
    $ershou_id      = isset($_GET['ershou_id'])?intval($_GET['ershou_id']):0;
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $click_num      = intval($_GET['click_num'])>0? intval($_GET['click_num']):0;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    $plugin_id = '';
    $site_id = 1;
    if($tongcheng_id > 0){
        $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
        if($tongchengInfo && $tongchengInfo['id'] > 0){
            $plugin_id = 'tom_tongcheng';
            $site_id = $tongchengInfo['site_id'];
        }
    }
    if($zhaopin_id > 0){
        $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($zhaopin_id);
        if($tczhaopinInfo && $tczhaopinInfo['id'] > 0){
            $plugin_id = 'tom_tczhaopin';
            $site_id = $tczhaopinInfo['site_id'];
        }
    }
    if($fangchan_id > 0){
        $tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($fangchan_id);
        if($tcfangchanInfo && $tcfangchanInfo['id'] > 0){
            $plugin_id = 'tom_tcfangchan';
            $site_id = $tcfangchanInfo['site_id'];
        }
    }
    if($ershou_id > 0){
        $tcershouInfo  = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($ershou_id);
        if($tcershouInfo && $tcershouInfo['id'] > 0){
            $plugin_id = 'tom_tcershou';
            $site_id = $tcershouInfo['site_id'];
        }
    }
    
    if(empty($plugin_id)){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $tuiListTmp = array();
    if($tongcheng_id > 0){
        $tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND tongcheng_id={$tongcheng_id} ",'ORDER BY id DESC',0,1);
    }
    if($zhaopin_id > 0){
        $tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND zhaopin_id={$zhaopin_id} ",'ORDER BY id DESC',0,1);
    }
    if($fangchan_id > 0){
        $tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND fangchan_id={$fangchan_id} ",'ORDER BY id DESC',0,1);
    }
    if($ershou_id > 0){
        $tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND ershou_id={$ershou_id} ",'ORDER BY id DESC',0,1);
    }
    
    if(!empty($tuiListTmp) && $tuiListTmp[0]['status'] == 1){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $tuiListMoney = array();
    $tui_list_money_str = str_replace("\r\n","{n}",$tchehuorenConfig['tui_list_money']); 
    $tui_list_money_str = str_replace("\n","{n}",$tui_list_money_str);
    $tui_list_money_arr = explode("{n}", $tui_list_money_str);
    if(is_array($tui_list_money_arr) && !empty($tui_list_money_arr)){
        foreach ($tui_list_money_arr as $key => $value){
            $arr = explode("|", $value);
            $tuiListMoney[$arr[1]] = $arr[0];
        }
    }
    
    $pay_price = $all_money = $click_money = 0;
    if(isset($tuiListMoney[$click_num]) && $tuiListMoney[$click_num] > 0){
        
        $pay_price = $tuiListMoney[$click_num];
        $all_money = $tuiListMoney[$click_num];
        
        if($tchehuorenConfig['tui_yongjin'] > 0 && $tchehuorenConfig['tui_yongjin'] < 100){
            $all_money = $all_money * ((100 - $tchehuorenConfig['tui_yongjin'])/100);
        }
        
        $click_money = $all_money/$click_num;
    }
    
    if($pay_price > 0 && $all_money > 0 && $click_money >= 0.01){
    }else{
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    if($tuiListTmp[0]['pay_status'] == 1){
        $updateData = array();
        $updateData['order_no']         = $order_no;
        $updateData['all_money']        = $all_money;
        $updateData['sy_money']         = $all_money;
        $updateData['click_money']      = $click_money;
        $updateData['add_time']         = TIMESTAMP;
        C::t('#tom_tchehuoren#tom_tchehuoren_tui')->update($tuiListTmp[0]['id'],$updateData);
        $tuiId = $tuiListTmp[0]['id'];
    }else{
        $insertData = array();
        $insertData['order_no']         = $order_no;
        $insertData['site_id']          = $site_id;
        $insertData['plugin_id']        = $plugin_id;
        $insertData['tongcheng_id']     = $tongcheng_id;
        $insertData['zhaopin_id']       = $zhaopin_id;
        $insertData['fangchan_id']      = $fangchan_id;
        $insertData['ershou_id']        = $ershou_id;
        $insertData['all_money']        = $all_money;
        $insertData['sy_money']         = $all_money;
        $insertData['click_money']      = $click_money;
        $insertData['add_type']         = 1;
        $insertData['pay_status']       = 1;
        $insertData['status']           = 0;
        $insertData['is_show']          = 0;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tchehuoren#tom_tchehuoren_tui')->insert($insertData);
        $tuiId = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->insert_id();
    }
    
    ## pay start

    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['order_no']         = $order_no;
    $insertData['type']             = 3;
    $insertData['user_id']          = $userInfo['id'];
    $insertData['tj_hehuoren_id']   = 0;
    $insertData['openid']           = $userInfo['openid'];
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tchehuoren#tom_tchehuoren_order')->insert($insertData)){

        $order_id = C::t('#tom_tchehuoren#tom_tchehuoren_order')->insert_id();

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tchehuoren';
        $insertData['order_no']        = $order_no;
        $insertData['goods_id']        = $order_id; 
        $insertData['goods_name']      = $tchehuorenConfig['hehuoren_name'].lang('plugin/tom_tchehuoren','pay_tui_order');
        $insertData['goods_beizu']     = $tchehuorenConfig['hehuoren_name'].lang('plugin/tom_tchehuoren','pay_tui_order');
        $insertData['goods_url']       = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=addtui";
        if($tongcheng_id > 0){
            $insertData['succ_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist";
        }else if($zhaopin_id > 0){
            $insertData['succ_back_url']   = "plugin.php?id=tom_tczhaopin&site={$site_id}&mod=myzhaopinlist";
        }else if($fangchan_id > 0){
            $insertData['succ_back_url']   = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfangchanlist&model_id={$tcfangchanInfo['model_id']}";
        }else if($ershou_id > 0){
            $insertData['succ_back_url']   = "plugin.php?id=tom_tcershou&site={$site_id}&mod=myfabu";
        }else{
            $insertData['succ_back_url']   = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=personal";
        }
        $insertData['fail_back_url']   = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=addtui";
        $insertData['allow_alipay']    = 1;         
        $insertData['pay_price']       = $pay_price;    
        $insertData['order_status']    = 1;             
        $insertData['add_time']        = TIMESTAMP;     
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status' => 200,
                'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 306,
        );
        echo json_encode($outArr); exit;
    }

    ## pay end
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}