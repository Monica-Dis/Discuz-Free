<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function add_hehuoren($user_id, $tj_hehuoren_id){
    global $_G;
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($user_id);

    if(!$tchehuorenInfo){
        $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_list('', 'ORDER BY invite_id DESC,id DESC', 0, 1);
        $dengjiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_all_list(' AND level = 1 ', 'ORDER BY level DESC, id DESC', 0, 1);
        $invite_id = 11111;
        if(is_array($tchehuorenInfoTmp) && !empty($tchehuorenInfoTmp[0])){
            if($tchehuorenInfoTmp[0]['invite_id'] >= 11111){
                $invite_id  = $tchehuorenInfoTmp[0]['invite_id'] + 1;
            }
        }

        $inviteStr = hehuoren_random(1, 'qwertyupasdfghkzxcvbnm');
        $invite_code = $inviteStr.$invite_id;

        $insertData = array();
        $insertData['user_id']              = $user_id;
        if($tchehuorenConfig['open_subordinate'] == 1){
            $insertData['tj_hehuoren_id']       = $tj_hehuoren_id;
        }
        $insertData['picurl']               = $userInfo['picurl'];
        $insertData['xm']                   = $userInfo['nickname'];
        $insertData['tel']                  = $userInfo['tel'];
        $insertData['openid']               = $userInfo['openid'];
        $insertData['dengji_id']            = $dengjiInfo[0]['id'];
        $insertData['invite_id']            = $invite_id;
        $insertData['invite_code']          = $invite_code;
        $insertData['add_time']             = TIMESTAMP;
        C::t('#tom_tchehuoren#tom_tchehuoren')->insert($insertData);
        return true;
    }
    return false;
}

function hehuoren_random($length, $chars = '0123456789') {
	$hash = '';
	$max = strlen($chars) - 1;
	for($i = 0; $i < $length; $i++) {
		$hash .= $chars[mt_rand(0, $max)];
	}
	return $hash;
}