<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function hhr_tui_iconv_recurrence($value) {
    if(is_array($value)) {
        foreach($value AS $key => $val) {
            $value[$key] = hhr_tui_iconv_recurrence($val);
        }
    } else {
        $value = diconv($value, 'utf-8', CHARSET);
    }
    return $value;
}

function hhr_tui_ip_check_region(){
    global $_G;
    
    $outArr = array(
        'status' => 0,
        'region' => '',
    );
    
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    
    $host       = "https://ips.market.alicloudapi.com";
    $path       = "/iplocaltion";
    $appcode    = trim($tchehuorenConfig['tui_region_appcode']);
    $headers    = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys     = "ip=".$_G['clientip'];
    $bodys      = "";
    $url        = $host . $path . "?" . $querys;
    
    $start_time = time();
    
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    $return = curl_exec($curl);
    $content = json_decode($return,true);
    $content = hhr_tui_iconv_recurrence($content);
    
    $end_time = time();
    
    if($tchehuorenConfig['tui_region_debug'] == 1){
        echo $start_time.'--'.$end_time.'<hr>';
        print_r($content);exit;
    }
    
    $ip_region = '';
    if(is_array($content) && !empty($content) && $content['message'] == 'success' && is_array($content['result']) && !empty($content['result'])){
        
        $ip_region = $content['result']['province'].' '.$content['result']['city'].' '.$content['result']['district'];
        
        $outArr = array(
            'status' => 100,
            'region' => $ip_region,
        );
        
        $region_list = preg_quote(trim($tchehuorenConfig['tui_region_list']), '/');
        $region_list = str_replace(array("\\*"), array('.*'), $region_list);
        $region_list = '.*('.$region_list.').*';
        $region_list = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $region_list).')$/i';
        if(@preg_match($region_list, $ip_region,$matches)) {
            $outArr = array(
                'status' => 200,
                'region' => $ip_region,
            );
        }
    }
    
    return $outArr;
}