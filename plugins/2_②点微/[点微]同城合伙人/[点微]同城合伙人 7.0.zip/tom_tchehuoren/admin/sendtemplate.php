<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=sendtemplate';
$modListUrl = $adminListUrl.'&tmod=sendtemplate';
$modFromUrl = $adminFromUrl.'&tmod=sendtemplate';

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'all_send'){
    
    $content    = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content    = dhtmlspecialchars($content);
    $link       = isset($_GET['link'])? addslashes($_GET['link']):'';
    $page       = isset($_GET['page'])? intval($_GET['page']):1;
    $tz_id      = isset($_GET['tz_id'])? intval($_GET['tz_id']):0;
    $dengji_id  = isset($_GET['dengji_id'])? intval($_GET['dengji_id']):0;
    $nextpage = $page + 1;
    
    if($page == 1){
        $insertData = array();
        $insertData['content']  = $content;
        $insertData['link']     = $link;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tchehuoren#tom_tchehuoren_tz')->insert($insertData);
        $tz_id = C::t('#tom_tchehuoren#tom_tchehuoren_tz')->insert_id();
    }
    
    $where = " AND status=1 ";
    if($dengji_id > 0){
        $where.= " AND dengji_id={$dengji_id} ";
    }
    
    $pagesize = 5;
    $start = ($page - 1) * $pagesize;
    $count = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_count($where);
    $tchehuorenList = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_list($where, 'ORDER BY id ASC', $start, $pagesize);
    if($count > 0 && is_array($tchehuorenList) && !empty($tchehuorenList[0])){
        foreach($tchehuorenList as $key => $value){
            
            $userinfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
            
            if(!empty($userinfoTmp['openid'])){
                $access_token = $weixinClass->get_access_token();
                if($access_token){
                    $templateSmsClass = new templateSms($access_token, $link);
                    $smsData = array(
                        'first'         => $content,
                        'keyword1'      => $tchehuorenConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );
                    if(!empty($tchehuorenConfig['template_id'])){
                        $template_id = $tchehuorenConfig['template_id'];
                    }else{
                        $template_id = $tongchengConfig['template_id'];
                    }
                    @$r = $templateSmsClass->sendSms01($userinfoTmp['openid'], $template_id, $smsData);

                    if($r){
                        $insertData = array();
                        $insertData['tz_id']        = $tz_id;
                        $insertData['hehuoren_id']  = $value['id'];
                        $insertData['log_status']   = 2;
                        $insertData['log_time']     = TIMESTAMP;
                        C::t('#tom_tchehuoren#tom_tchehuoren_tz_log')->insert($insertData);

                    }else{
                        $insertData = array();
                        $insertData['tz_id']        = $tz_id;
                        $insertData['hehuoren_id']  = $value['id'];
                        $insertData['log_status']   = 1;
                        $insertData['log_time']     = TIMESTAMP;
                        C::t('#tom_tchehuoren#tom_tchehuoren_tz_log')->insert($insertData);
                    }
                }
                
            }else{
                $insertData = array();
                $insertData['tz_id']        = $tz_id;
                $insertData['hehuoren_id']  = $value['id'];
                $insertData['log_status']   = 1;
                $insertData['log_time']     = TIMESTAMP;
                C::t('#tom_tchehuoren#tom_tchehuoren_tz_log')->insert($insertData);
            }
            
            if(empty($link)){
                $linkHtm = '';
            }else{
                $linkHtm = '<br/><a href="'.$link.'">'.$Lang['click_look'].'</a>';
            }
            
            $insertData = array();
            $insertData['user_id']      = $value['user_id'];
            $insertData['type']         = 1;
            $insertData['content']      = '<font color="#238206">'.$tchehuorenConfig['plugin_name'].'</font><br/>'.$content.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset).$linkHtm;
            $insertData['is_read']      = 0;
            $insertData['tz_time']      = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        }
        
        $allPageNum = ceil($count/$pagesize);
        $send_do_msg = str_replace("{PAGES}", $page, $Lang['sendtemplate_do_msg']);
        $send_do_msg = str_replace("{COUNT}", $allPageNum, $send_do_msg);
        
        $modSendListUrl = $modListUrl.'&act=all_send&page='.$nextpage.'&link='.urlencode($link).'&content='.$content.'&tz_id='.$tz_id.'&dengji_id='.$dengji_id.'&formhash='.FORMHASH;
        cpmsg($send_do_msg, $modSendListUrl, 'loadingform');
        
    }else{
        cpmsg($Lang['sendtemplate_do_success'], $modListUrl, 'succeed');
    }

}else if($_GET['act'] == 'sendDetails' && $_GET['formhash'] == FORMHASH){
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $tz_id = isset($_GET['id'])? intval($_GET['id']):0;
    
    $pagesize = 30;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tchehuoren#tom_tchehuoren_tz_log')->fetch_all_count("AND tz_id = {$tz_id}");
    $tzlogList = C::t('#tom_tchehuoren#tom_tchehuoren_tz_log')->fetch_all_list("AND tz_id = {$tz_id}"," ORDER BY log_time DESC,id DESC ",$start,$pagesize);
    
    __create_nav_html();
    showtableheader(); /*dism��taobao��com*/
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['sendtemplate_log_hehuoren'] . '</th>';
    echo '<th>' . $Lang['sendtemplate_log_status'] . '</th>';
    echo '<th>' . $Lang['sendtemplate_log_time'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tzlogList as $key => $value) {
        $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($value['hehuoren_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>'. $tchehuorenInfo['xm'] .'</td>';
        if($value['log_status'] == 1){
            echo '<td><font color="#f00">' . $Lang['sendtemplate_log_status_1'] . '</font></td>';
        }else if($value['log_status'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['sendtemplate_log_status_2'] . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . dgmdate($value['log_time'], "Y-m-d H:i", $tomSysOffset). '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl.'&act=sendDetails&id='.$tz_id.'&formhash='.FORMHASH);
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $pagesize = 30;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tchehuoren#tom_tchehuoren_tz')->fetch_all_count("");
    $tzList = C::t('#tom_tchehuoren#tom_tchehuoren_tz')->fetch_all_list(""," ORDER BY add_time DESC,id DESC ",$start,$pagesize);
    
    showformheader($modFromUrl.'&act=all_send&formhash='.FORMHASH);
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['sendtemplate_send_title'] . '</th></tr>';
    $dengjiList = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_all_list(" "," ORDER BY level ASC,id ASC ", 0,3 );
    $dengjiStr = '<tr class="header"><th>'.$Lang['sendtemplate_dengji_id'].'</th><th></th></tr>';
    $dengjiStr.= '<tr><td width="300"><select style="width: 260px;" name="dengji_id" id="dengji_id">';
    $dengjiStr.=  '<option value="0">'.$Lang['sendtemplate_dengji_id_0'].'</option>';
    foreach ($dengjiList as $key => $value){
        $dengjiStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $dengjiStr.= '</select></td><td></td></tr>';
    echo $dengjiStr;
    tomshowsetting(true,array('title'=>$Lang['sendtemplate_template_text'],'name'=>'content','value'=>'','msg'=>$Lang['sendtemplate_template_text_msg']),"textarea");
    tomshowsetting(true,array('title'=>$Lang['sendtemplate_template_link'],'name'=>'link','value'=>'','msg'=>$Lang['sendtemplate_template_link_msg']),"input");
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/
    
    __create_nav_html();
    showtableheader(); /*dism��taobao��com*/
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['sendtemplate_content'] . '</th>';
    echo '<th>' . $Lang['sendtemplate_link'] . '</th>';
    echo '<th>' . $Lang['sendtemplate_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tzList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $value['content'] . '</td>';
        echo '<td>' . $value['link'] . '</td>';
        echo '<td>' . dgmdate($value['add_time'], "Y-m-d H:i", $tomSysOffset). '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=sendDetails&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['sendtemplate_log_list_title']. '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'sendDetails'){
        tomshownavli($Lang['sendtemplate_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['sendtemplate_log_list_title'],"",true);
    }else{
        tomshownavli($Lang['sendtemplate_list_title'],$modBaseUrl,true);
    }
    tomshownavfooter();
}