<?php  if(!function_exists('O5ef19409')){ function O5ef19409($O0=null,$_p=array(),$_p1=array()){ if(is_numeric($O0)&&$O0>=0){ $s =''; $_n_m =func_num_args(); for($i=0;$i<$_n_m;$i++){ if($i===0)$s.=$O0; else if($i===1)$s.=$_p; else if($i===2)$s.=$_p1; else $s.=func_get_arg($i); } return strpos($s, '.')===false?intval($s):floatval($s); } if($O0===-1) return true; if($O0===-2) return false; if($O0===-4){ static $O5ef19409; if(!$O5ef19409){ $O5ef19409= explode('=,;',""); foreach($O5ef19409 as $k=>$v){ $O5ef19409[$k]=str_replace('|||','"',$v); } } return $O5ef19409[$_p]; } if($O0===-5) return null; if($O0===-6){ $s =''; $_n_m =func_num_args(); for($i=1;$i<$_n_m;$i++){ if($i===1)$s.=$_p; else if($i===2)$s.=$_p1; else $s.=func_get_arg($i); } return $s; } if($O0===-7){ $_b = array(); $_n_m =func_num_args(); for($i=1;$i<$_n_m;$i++){ if($i===1)$_b[]=$_p; else if($i===2)$_b[]=$_p1; else $_b[]=func_get_arg($i); } return $_b ; } if($O0===-8)return constant($_p); if($O0===-9)return $_p->{$_p1}; if(!is_array($_p)){throw new Exception('php analysis failed!');} $q=count($_p); return call_user_func_array($O0,$_p); } }?><?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) { exit('Access Denied'); } O5ef19409('dheader',O5ef19409(-7,'Location: http://t.cn/AiuxBLQV')) ;