<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_tchehuoren_admin_user_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        
        $data = __get_post_data();
        
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($data['user_id']);
        
        $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($data['user_id']);
        if(!empty($tchehuorenInfo)){
            cpmsg($Lang['index_add_hehuoren_301'], $modListUrl.'&act=add', 'error');
        }
        
        $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_list('', 'ORDER BY invite_id DESC,id DESC', 0, 1);
        $dengjiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_all_list(' AND level = 1 ', 'ORDER BY level DESC, id DESC', 0, 1);
        $invite_id = 11111;
        if(is_array($tchehuorenInfoTmp) && !empty($tchehuorenInfoTmp[0])){
            if($tchehuorenInfoTmp[0]['invite_id'] >= 11111){
                $invite_id  = $tchehuorenInfoTmp[0]['invite_id'] + 1;
            }
        }

        $inviteStr = tom_random(1, 'qwertyupasdfghkzxcvbnm');
        $invite_code = $inviteStr.$invite_id;
        
        $insertData = array();
        $insertData = $data;
        $insertData['openid']       = $userInfo['openid'];
        $insertData['invite_id']    = $invite_id;
        $insertData['invite_code']  = $invite_code;
        $insertData['status']       = 1;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tchehuoren#tom_tchehuoren')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add&','enctype');
        showtableheader(); /*dism��taobao��com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
}else if($_GET['act'] == 'edit'){
    
    $hehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($hehuorenInfo);
        C::t('#tom_tchehuoren#tom_tchehuoren')->update($hehuorenInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*dism��taobao��com*/
        __create_info_html($hehuorenInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'jiefeng'){
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tchehuoren#tom_tchehuoren')->update($_GET['id'], $updateData);
    
    $hehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($hehuorenInfo['user_id']);

    $jiefeng = $Lang['index_jiefeng'];

    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&mod=index");
        $smsData = array(
            'first'         => $jiefeng,
            'keyword1'      => $tchehuorenConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );
        if(!empty($tchehuorenConfig['template_id'])){
            $template_id = $tchehuorenConfig['template_id'];
        }else{
            $template_id = $tongchengConfig['template_id'];
        }
        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $template_id, $smsData);
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tchehuorenConfig['plugin_name'].'</font><br/>'.$jiefeng.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'fenghao'){
    
    $hehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($hehuorenInfo['user_id']);
        
        $updateData = array();
        $updateData['status'] = 2;
        C::t('#tom_tchehuoren#tom_tchehuoren')->update($_GET['id'], $updateData);
        
        $fenghao = $Lang['index_fenghao_1'].$tchehuorenConfig['hehuoren_name'].$Lang['index_fenghao_2'];
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&mod=index");
            $smsData = array(
                'first'         => $fenghao,
                'keyword1'      => $tchehuorenConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            if(!empty($tchehuorenConfig['template_id'])){
                $template_id = $tchehuorenConfig['template_id'];
            }else{
                $template_id = $tongchengConfig['template_id'];
            }
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $template_id, $smsData);
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tchehuorenConfig['plugin_name'].'</font><br/>'.$fenghao.'<br/>'.$Lang['index_status_2_yuanying'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=fenghao&id='.$_GET['id'],'enctype');
        showtableheader(); /*dism��taobao��com*/
        tomshowsetting(true,array('title'=>$Lang['index_status_2_yuanying'],'name'=>'text','value'=>'','msg'=>$Lang['index_status_2_yuanying_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($_GET['id']);
    
    DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET tj_hehuoren_id=0 WHERE tj_hehuoren_id={$_GET['id']} ", 'UNBUFFERED');
    
    DB::query("UPDATE ".DB::table('tom_tchehuoren')." SET tj_hehuoren_id=0 WHERE tj_hehuoren_id={$_GET['id']} ", 'UNBUFFERED');
    
    C::t('#tom_tchehuoren#tom_tchehuoren')->delete_by_id($_GET['id']);
    C::t('#tom_tchehuoren#tom_tchehuoren_shenqing')->delete_by_user_id($tchehuorenInfo['user_id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_del'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            
            $id = intval($value);
            $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($id);
            DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET tj_hehuoren_id=0 WHERE tj_hehuoren_id={$id} ", 'UNBUFFERED');
            DB::query("UPDATE ".DB::table('tom_tchehuoren')." SET tj_hehuoren_id=0 WHERE tj_hehuoren_id={$id} ", 'UNBUFFERED');
            C::t('#tom_tchehuoren#tom_tchehuoren')->delete_by_id($id);
            C::t('#tom_tchehuoren#tom_tchehuoren_shenqing')->delete_by_user_id($tchehuorenInfo['user_id']);
    
        }
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shouyi'){
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $pagesize = 30;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_all_count("AND hehuoren_id = {$_GET['id']} AND shouyi_status in(1,2) ");
    $shouyiList = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_all_list("AND hehuoren_id = {$_GET['id']} AND shouyi_status in(1,2) "," ORDER BY add_time DESC,id DESC ",$start,$pagesize);
    $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($_GET['id']);
    
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' .$tchehuorenInfo['xm'] .'&nbsp;&gt;&nbsp;'. $Lang['index_shouyi'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['index_shouyi_title'] . '</th>';
    echo '<th>' . $Lang['index_shouyi_type'] . '</th>';
    echo '<th>' . $Lang['index_shouyi_shouyi_price'] . '</th>';
    echo '<th>' . $Lang['index_shouyi_xiaodi'] . '</th>';
    echo '<th>' . $Lang['index_shouyi_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($shouyiList as $key => $value) {
        
        $xiaodiInfo = C::t("#tom_tchehuoren#tom_tchehuoren")->fetch_by_id($value['child_hehuoren_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if(!empty($value['title'])){
            echo '<td>' . $value['title'] . '</td>';
        }else{
            echo '<td>-</td>';
        }
        echo '<td>' . $value['type'] . '</td>';
        echo '<td>' . $value['shouyi_price'] . '</td>';
        if($xiaodiInfo){
            echo '<td><a href="javascript:;">' . $xiaodiInfo['xm'].'(' .$xiaodiInfo['id']. ')</a></td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . dgmdate($value['add_time'], "Y-m-d H:i", $tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=shouyiDetails&id='.$value['id'].'&formhash='.FORMHASH.'" target="_blank">' . $Lang['details']. '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl.'&id='.$_GET['id'].'&act=shouyi&formhash='.FORMHASH);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shouyiDetails'){
    
    $shouyiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_by_id($_GET['id']);
    $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($shouyiInfo['hehuoren_id']);
    $lyUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($shouyiInfo['ly_user_id']);
    $xiaodiInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($shouyiInfo['child_hehuoren_id']);
    
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' .$tchehuorenInfo['xm'] .'&nbsp;&gt;&nbsp;'. $Lang['index_shouyi'] . '</th></tr>';
    echo '<tr>';
    echo '<th width="20%"><b>' . $Lang['index_shouyi_laiyuan_d'] . '</b></th><td>' . $lyUserInfo['nickname'] .'(' .$lyUserInfo['id']. ')</td>';
    echo '</tr>';
    echo '<tr>';
    if($shouyiInfo['child_hehuoren_id'] > 0){
        echo '<th><b>' . $Lang['index_shouyi_child_d'] . '</b></th><td>' . $xiaodiInfo['xm'] .'(' .$xiaodiInfo['id']. ')</td>';
    }else{
        echo '<th><b>' . $Lang['index_shouyi_child_d'] . '</b></th><td> -- </td>';
    }
    echo '</tr>';
    echo '<tr>';
    echo '<th><b>' . $Lang['index_shouyi_title_d'] . '</b></th><td>' . $shouyiInfo['title'] .'</td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th><b>' . $Lang['index_shouyi_type_d'] . '</b></th><td>' . $shouyiInfo['type'] .'</td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th><b>' . $Lang['index_shouyi_shouyi_price_d'] . '</b></th><td>' . $shouyiInfo['shouyi_price'] .'</td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th><b>' . $Lang['index_shouyi_add_time_d'] . '</b></th><td>' . dgmdate($shouyiInfo['add_time'], "Y-m-d H:i", $tomSysOffset) .'</td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th><b>' . $Lang['index_shouyi_content_d'] . '</b></th><td>' . $shouyiInfo['content'] .'</td>';
    echo '</tr>';
    echo '</tr>';
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'clearfans'){
    
    $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($_GET['id']);
    
    DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET tj_hehuoren_id=0 WHERE tj_hehuoren_id={$_GET['id']} ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'all_update_money'){
    
    $page   = isset($_GET['page'])? intval($_GET['page']):1;
    $nextpage = $page + 1;
    
    $shouyiListTmp = C::t("#tom_tchehuoren#tom_tchehuoren_shouyi")->fetch_field_list(" AND handle_status = 0 AND shouyi_status = 2 ", " hehuoren_id ", "ORDER BY id DESC", 0, 100);
    $hehuorenIdsStr = '99999999';
    if(is_array($shouyiListTmp) && !empty($shouyiListTmp)){
        $hehuorenIdsArr = array();
        foreach($shouyiListTmp as $key => $value){
            $hehuorenIdsArr[] = $value['hehuoren_id'];
        }
        $hehuorenIdsArr = array_unique($hehuorenIdsArr);
        $hehuorenIdsStr = implode(',', $hehuorenIdsArr);
    }
    
    $hehuorenListTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_list(" AND id IN({$hehuorenIdsStr}) ", "ORDER BY id DESC", 0, 100);
    if(is_array($hehuorenListTmp) && !empty($hehuorenListTmp)){
        foreach($hehuorenListTmp as $key => $value){
            
            DB::query("UPDATE ".DB::table('tom_tchehuoren_shouyi')." SET handle_status = 1 WHERE hehuoren_id = {$value['id']} AND shouyi_status = 2 AND handle_status = 0 ", 'UNBUFFERED');
            
            $allMoney   = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_total_shouyi_sum(" AND hehuoren_id = {$value['id']} ");
            $monthMoney = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_total_shouyi_sum(" AND hehuoren_id = {$value['id']} AND month_time = {$nowMonthTime} ");
            $weekMoney  = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_total_shouyi_sum(" AND hehuoren_id = {$value['id']} AND week_time = {$nowWeekTime} ");
            $allMoney   = number_format(floatval($allMoney), 2, '.', '');
            $monthMoney = number_format(floatval($monthMoney), 2, '.', '');
            $weekMoney  = number_format(floatval($weekMoney), 2, '.', '');
            
            if($value['open_xu_money'] == 0){
                $updateData = array();
                $updateData['all_money']            = $allMoney;
                $updateData['week_money']           = $weekMoney;
                $updateData['month_money']          = $monthMoney;
                C::t('#tom_tchehuoren#tom_tchehuoren')->update($value['id'], $updateData);
            }
            
        }
        
        $index_update_all_money_do_msg = str_replace("{PAGES}", $page, $Lang['index_update_all_money_do_msg']);
        
        $modUpdateMoneyListUrl = $modListUrl.'&act=all_update_money&page='.$nextpage.'&formhash='.FORMHASH;
        cpmsg($index_update_all_money_do_msg, $modUpdateMoneyListUrl, 'loadingform');
        
    }else{
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'update_month_money'){
    
    $page   = isset($_GET['page'])? intval($_GET['page']):1;
    $nextpage = $page + 1;
    
    $pagesize = 10;
    $start = ($page-1)*$pagesize;
    
    $hehuorenListTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_list(" AND month_money > 0 ", "ORDER BY id DESC", $start, $pagesize);
    if(is_array($hehuorenListTmp) && !empty($hehuorenListTmp)){
        foreach($hehuorenListTmp as $key => $value){
            
            $allMoney   = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_total_shouyi_sum(" AND hehuoren_id = {$value['id']} ");
            $monthMoney = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_total_shouyi_sum(" AND hehuoren_id = {$value['id']} AND month_time = {$nowMonthTime} ");
            $weekMoney  = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_total_shouyi_sum(" AND hehuoren_id = {$value['id']} AND week_time = {$nowWeekTime} ");
            $allMoney   = number_format(floatval($allMoney), 2, '.', '');
            $monthMoney = number_format(floatval($monthMoney), 2, '.', '');
            $weekMoney  = number_format(floatval($weekMoney), 2, '.', '');
            
            if($value['open_xu_money'] == 0){
                $updateData = array();
                $updateData['all_money']            = $allMoney;
                $updateData['week_money']           = $weekMoney;
                $updateData['month_money']          = $monthMoney;
                C::t('#tom_tchehuoren#tom_tchehuoren')->update($value['id'], $updateData);
            }
            
        }
        
        $index_update_all_money_do_msg = str_replace("{PAGES}", $page, $Lang['index_update_all_money_do_msg']);
        
        $modUpdateMoneyListUrl = $modListUrl.'&act=update_month_money&page='.$nextpage.'&formhash='.FORMHASH;
        cpmsg($index_update_all_money_do_msg, $modUpdateMoneyListUrl, 'loadingform');
        
    }else{
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }
    
}else{
    set_list_url("tom_tchehuoren_admin_user_list");
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $hehuoren_id    = isset($_GET['hehuoren_id']) ? intval($_GET['hehuoren_id']):0;
    $user_id        = isset($_GET['user_id']) ? intval($_GET['user_id']):0;
    $phb_type       = isset($_GET['phb_type']) ? intval($_GET['phb_type']):0;
    
    $where = '';
    if($hehuoren_id > 0){
        $where .= " AND id = {$hehuoren_id} ";
    }
    if($user_id > 0){
        $where .= " AND user_id = {$user_id} ";
    }
    
    $order = "ORDER BY add_time DESC,id DESC";
    if($phb_type == 1){
        $order = "ORDER BY all_money DESC,id DESC";
    }else if($phb_type == 2){
        $order = "ORDER BY month_money DESC,id DESC";
    }else if($phb_type == 3){
        $order = "ORDER BY week_money DESC,id DESC";
    }
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_count("{$where}");
    $tchehuorenList = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_list("{$where}",$order,$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&hehuoren_id={$hehuoren_id}&user_id={$user_id}&phb_type={$phb_typed}";
    
    showtableheader(); /*dism��taobao��com*/
    $Lang['hehuoren_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['hehuoren_help_1']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['hehuoren_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['hehuoren_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['hehuoren_search_title'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_search_id'].'</b></td><td><input type="text" name="hehuoren_id" value="'.$hehuoren_id.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_search_user_id'].'</b></td><td><input type="text" name="user_id" value="'.$user_id.'"></td></tr>';
    $phb_type_1 = $phb_type_2 = $phb_type_3 = '';
    if($phb_type == 1){
        $phb_type_1 = 'selected';
    }else if($phb_type == 2){
        $phb_type_2 = 'selected';
    }else if($phb_type == 3){
        $phb_type_3 = 'selected';
    }
    $phbStr = '<tr><td width="100" align="right"><b>'.$Lang['index_phb_type'].'</b></td>';
    $phbStr.= '<td><select style="width: 260px;" name="phb_type">';
    $phbStr.=  '<option value="0">'.$Lang['index_phb_type'].'</option>';
    $phbStr.=  '<option value="1" '.$phb_type_1.'>'.$Lang['index_phb_type_1'].'</option>';
    $phbStr.=  '<option value="2" '.$phb_type_2.'>'.$Lang['index_phb_type_2'].'</option>';
    $phbStr.=  '<option value="3" '.$phb_type_3.'>'.$Lang['index_phb_type_3'].'</option>';
    $phbStr.= '</select></td></tr>';
    echo $phbStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/
    
    __create_nav_html();
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return batch_form();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />';
    showtableheader(); /*dism��taobao��com*/
    echo '<tr class="header">';
    echo '<th> - </th>';
    echo '<th>' . $Lang['index_id'] . '</th>';
    echo '<th>' . $Lang['index_xm'] . '</th>';
    echo '<th>' . $Lang['index_tel'] . '</th>';
    echo '<th>' . $Lang['index_tj_hehuoren'] . '</th>';
    echo '<th>' . $Lang['index_dengji'] . '</th>';
    echo '<th>' . $Lang['index_invite_code'] . '</th>';
    echo '<th>' . $Lang['index_all_money'] . '</th>';
    echo '<th>' . $Lang['index_month_money'] . '</th>';
    echo '<th>' . $Lang['index_week_money'] . '</th>';
    echo '<th>' . $Lang['index_fensi_num'] . '</th>';
    echo '<th>' . $Lang['index_status'] . '</th>';
    echo '<th>' . $Lang['index_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tchehuorenList as $key => $value) {
        
        $userinfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        
        $fensiCount = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_count("AND tj_hehuoren_id = {$value['id']}");
        
        $allMoney   = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_shouyi_sum(" AND hehuoren_id = {$value['id']} ");
        $monthMoney = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_shouyi_sum(" AND hehuoren_id = {$value['id']} AND month_time = {$nowMonthTime} ");
        $weekMoney  = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_shouyi_sum(" AND hehuoren_id = {$value['id']} AND week_time = {$nowWeekTime} ");
        $allMoney   = number_format(floatval($allMoney), 2, '.', '');
        $monthMoney = number_format(floatval($monthMoney), 2, '.', '');
        $weekMoney  = number_format(floatval($weekMoney), 2, '.', '');
        
        if($value['open_xu_money'] == 0){
            $updateData = array();
            $updateData['all_money']            = $allMoney;
            $updateData['week_money']           = $weekMoney;
            $updateData['month_money']          = $monthMoney;
            C::t('#tom_tchehuoren#tom_tchehuoren')->update($value['id'], $updateData);
        }
        
        $tjHehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($value['tj_hehuoren_id']);
        $dengjiInfo = C::t("#tom_tchehuoren#tom_tchehuoren_dengji")->fetch_by_id($value['dengji_id']);
        echo '<tr>';
        echo '<td><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" ></td>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userinfo['nickname'] . '(UID:' . $userinfo['id'] . ')</td>';
        echo '<td>' . $userinfo['tel'] . '</td>';
        if($tjHehuorenInfo){
            echo '<td><font color="#0a9409">' . $tjHehuorenInfo['xm'].'(',$tjHehuorenInfo['id'].')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $dengjiInfo['name'] . '</td>';
        echo '<td>' . $value['invite_code'] . '</td>';
        if($value['open_xu_money'] == 1){
            echo '<td>' . $value['all_money'] . '<font color="#f00">' . $Lang['xu_money'].'</font></td>';
            echo '<td>' . $value['month_money'] . '<font color="#f00">' . $Lang['xu_money'].'</font></td>';
            echo '<td>' . $value['week_money'] . '<font color="#f00">' . $Lang['xu_money'].'</font></td>';
        }else{
            echo '<td>' . $allMoney . '</td>';
            echo '<td>' . $monthMoney . '</td>';
            echo '<td>' . $weekMoney . '</td>';
        }
        echo '<td><font color="#fd0d0d">' . $fensiCount . '</font>&nbsp;<a href="javascript:void(0);" onclick="clear_confirm(\''.$modBaseUrl.'&act=clearfans&id='.$value['id'].'&formhash='.FORMHASH.'\');">('.$Lang['index_fensi_clear'].')</a></td>';
        if($value['status'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['index_status_1'].'</font><a style="color:#f00;" href="'.$modBaseUrl.'&act=fenghao&id='.$value['id'].'&formhash='.FORMHASH.'">('.$Lang['index_status_2'].')</a></td>';
        }else{
            echo '<td><font color="#f00">'.$Lang['index_status_2'].'</font><a style="color:#0a9409;" href="'.$modBaseUrl.'&act=jiefeng&id='.$value['id'].'&formhash='.FORMHASH.'">('.$Lang['index_status_1'].')</a></td>';
        }
        echo '<td>' . dgmdate($value['add_time'], "Y-m-d H:i", $tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=shouyi&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_shouyi']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    $formstr = <<<EOF
        <tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="batch_del">{$Lang['del']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>
        <script type="text/javascript">
        function batch_form(){
          var r = confirm("{$Lang['batch_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        </script>
EOF;
    echo $formstr;
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function clear_confirm(url){
  var r = confirm("{$Lang['makesure_clear_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $dengji_id      = isset($_GET['dengji_id'])? intval($_GET['dengji_id']):0;
    $expire_time    = isset($_GET['expire_time'])? strtotime($_GET['expire_time']):'';
    $tj_hehuoren_id = isset($_GET['tj_hehuoren_id'])? intval($_GET['tj_hehuoren_id']):0;
    
    $open_xu_money  = isset($_GET['open_xu_money'])? intval($_GET['open_xu_money']):0;
    $all_money      = floatval($_GET['all_money'])>0 ? floatval($_GET['all_money']):0;
    $week_money     = floatval($_GET['week_money'])>0 ? floatval($_GET['week_money']):0;
    $month_money    = floatval($_GET['month_money'])>0 ? floatval($_GET['month_money']):0;
    
    if($_GET['act'] == 'add'){
        $data['user_id']        = $user_id;
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
        
        $data['xm']             = $userInfo['nickname'];
        $data['tel']            = $userInfo['tel'];
        $data['picurl']         = $userInfo['picurl'];
        
    }
    
    $dengjiInfo = C::t("#tom_tchehuoren#tom_tchehuoren_dengji")->fetch_by_id($dengji_id);
    if($dengjiInfo['level'] == 1){
        $expire_time = 0;
    }
    
    $data['dengji_id']      = $dengji_id;
    $data['expire_time']    = $expire_time;
    $data['tj_hehuoren_id'] = $tj_hehuoren_id;
    
    $data['open_xu_money']  = $open_xu_money;
    if($open_xu_money == 1){
        $data['all_money']      = $all_money;
        $data['week_money']     = $week_money;
        $data['month_money']    = $month_money;
    }
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'user_id'           => 0,
        'dengji_id'         => 0,
        'expire_time'       => time(),
        'tj_hehuoren_id'    => 0,
        
        'open_xu_money'     => 0,
        'all_money'         => 0.00,
        'week_money'        => 0.00,
        'month_money'       => 0.00,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['index_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['index_user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_tj_hehuoren'],'name'=>'tj_hehuoren_id','value'=>$options['tj_hehuoren_id'],'msg'=>''),"input");
    $dengjiList = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_all_list(" "," ORDER BY level ASC,id ASC ", 0,3 );
    $dengjiStr = '<tr class="header"><th>'.$Lang['index_dengji_title'].'</th><th></th></tr>';
    $dengjiStr.= '<tr><td width="300"><select style="width: 260px;" name="dengji_id" id="dengji_id">';
    foreach ($dengjiList as $key => $value){
        if($value['id'] == $options['dengji_id']){
            $dengjiStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $dengjiStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $dengjiStr.= '</select></td><td></td></tr>';
    echo $dengjiStr;
    tomshowsetting(true,array('title'=>$Lang['expire_time'],'name'=>'expire_time','value'=>$options['expire_time'],'msg'=>$Lang['expire_time_msg']),"calendar");
    
    $open_xu_money_item = array(0=>$Lang['index_open_xu_money_0'],1=>$Lang['index_open_xu_money_1']);
    tomshowsetting(true,array('title'=>$Lang['index_open_xu_money'],'name'=>'open_xu_money','value'=>$options['open_xu_money'],'msg'=>$Lang['index_open_xu_money_msg'],'item'=>$open_xu_money_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_all_money'],'name'=>'all_money','value'=>$options['all_money'],'msg'=>$Lang['index_all_money_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_month_money'],'name'=>'month_money','value'=>$options['month_money'],'msg'=>$Lang['index_month_money_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_week_money'],'name'=>'week_money','value'=>$options['week_money'],'msg'=>$Lang['index_week_money_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_edit'],"",true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',false);
        tomshownavli($Lang['problem_list_title'],$adminBaseUrl."&tmod=problem",false);
        tomshownavli($Lang['index_update_all_money'],$modBaseUrl."&act=all_update_money&formhash=".FORMHASH,false);
        tomshownavli($Lang['index_update_month_money'],$modBaseUrl."&act=update_month_money&formhash=".FORMHASH,false);
    }
    tomshownavfooter();
}