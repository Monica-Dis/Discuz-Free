<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=tui';
$modListUrl = $adminListUrl.'&tmod=tui';
$modFromUrl = $adminFromUrl.'&tmod=tui';

$__ShowTctoutiao = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/tom_tctoutiao.inc.php')){
    $__ShowTctoutiao = 1;
}
$__ShowTczhaopin = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')){
    $__ShowTczhaopin = 1;
}
$__ShowFangchan = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/tom_tcfangchan.inc.php')){
    $__ShowFangchan = 1;
}
$__ShowTcershou = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcershou/tom_tcershou.inc.php')){
    $__ShowTcershou = 1;
}
$__ShowTctopic = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tctopic/tom_tctopic.inc.php')){
    $__ShowTctopic = 1;
}

$get_list_url_value = get_list_url("tom_admin_tchehuoren_tui");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $data = __get_post_data();
        
        $site_id = 1;
        if($data['plugin_id'] == 'tom_tongcheng'){
            
            $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($data['tongcheng_id']);
            if($tongchengInfo){
                $site_id = $tongchengInfo['site_id'];
            }else{
                cpmsg($Lang['tui_add_err301'], $modListUrl, 'error');
            }
            
            $tuiListCount = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_count(" AND tongcheng_id={$data['tongcheng_id']} AND status=1 ");
            if($tuiListCount > 0){
                cpmsg($Lang['tui_add_err302'], $modListUrl."&tongcheng_id=".$data['tongcheng_id'], 'error');
            }
        }else if($data['plugin_id'] == 'tom_tctoutiao'){
            
            $tctoutiaoInfo = C::t("#tom_tctoutiao#tom_tctoutiao")->fetch_by_id($data['toutiao_id']);
            if($tctoutiaoInfo){
                if($tctoutiaoInfo['site_id'] > 100){
                    $site_id = $tctoutiaoInfo['site_id'];
                }
            }else{
                cpmsg($Lang['tui_add_err303'], $modListUrl, 'error');
            }
            
            $tuiListCount = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_count(" AND toutiao_id={$data['toutiao_id']} AND status=1 ");
            if($tuiListCount > 0){
                cpmsg($Lang['tui_add_err304'], $modListUrl."&toutiao_id=".$data['toutiao_id'], 'error');
            }
        }else if($data['plugin_id'] == 'tom_tczhaopin'){
            
            $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($data['zhaopin_id']);
            if($tczhaopinInfo){
                $site_id = $tczhaopinInfo['site_id'];
            }else{
                cpmsg($Lang['tui_add_err305'], $modListUrl, 'error');
            }
            
            $tuiListCount = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_count(" AND zhaopin_id={$data['zhaopin_id']} AND status=1 ");
            if($tuiListCount > 0){
                cpmsg($Lang['tui_add_err306'], $modListUrl."&zhaopin_id=".$data['zhaopin_id'], 'error');
            }
        }else if($data['plugin_id'] == 'tom_tcfangchan'){
            
            $tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($data['fangchan_id']);
            if($tcfangchanInfo){
                $site_id = $tcfangchanInfo['site_id'];
            }else{
                cpmsg($Lang['tui_add_err307'], $modListUrl, 'error');
            }
            
            $tuiListCount = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_count(" AND fangchan_id={$data['fangchan_id']} AND status=1 ");
            if($tuiListCount > 0){
                cpmsg($Lang['tui_add_err308'], $modListUrl."&zhaopin_id=".$data['zhaopin_id'], 'error');
            }
        }else if($data['plugin_id'] == 'tom_tcershou'){
            
            $tcershouInfo  = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($data['ershou_id']);
            if($tcershouInfo){
                $site_id = $tcershouInfo['site_id'];
            }else{
                cpmsg($Lang['tui_add_err309'], $modListUrl, 'error');
            }
            
            $tuiListCount = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_count(" AND ershou_id={$data['ershou_id']} AND status=1 ");
            if($tuiListCount > 0){
                cpmsg($Lang['tui_add_err310'], $modListUrl."&ershou_id=".$data['ershou_id'], 'error');
            }
        }else if($data['plugin_id'] == 'tom_tctopic'){
            
            $tctopicInfo = C::t("#tom_tctopic#tom_tctopic")->fetch_by_id($data['topic_id']);
            if($tctopicInfo){
                $site_id = $tctopicInfo['site_id'];
            }else{
                cpmsg($Lang['tui_add_err309'], $modListUrl, 'error');
            }
            
            $tuiListCount = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_count(" AND topic_id={$data['topic_id']} AND status=1 ");
            if($tuiListCount > 0){
                cpmsg($Lang['tui_add_err310'], $modListUrl."&topic_id=".$data['topic_id'], 'error');
            }
        }
        
        $insertData = array();
        $insertData = $data;
        $insertData['site_id']      = $site_id;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tchehuoren#tom_tchehuoren_tui')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); /*dism��taobao��com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $tuiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($tuiInfo);
        C::t('#tom_tchehuoren#tom_tchehuoren_tui')->update($tuiInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*dism��taobao��com*/
        __create_info_html($tuiInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    }
}else if($_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['is_show']     = 1;
    C::t('#tom_tchehuoren#tom_tchehuoren_tui')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['is_show']     = 0;
    C::t('#tom_tchehuoren#tom_tchehuoren_tui')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'tui_log'){
    
    $tui_id = intval($_GET['tui_id'])>0?intval($_GET['tui_id']):0;
    
    __create_nav_html();
    
    $where = "";
    if($tui_id > 0){
        $where = " AND tui_id={$tui_id} ";
    }
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tchehuoren#tom_tchehuoren_tui_log')->fetch_all_count($where);
    $tuiLogList = C::t('#tom_tchehuoren#tom_tchehuoren_tui_log')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    
    showtableheader(); /*dism��taobao��com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['tui_log_tui_id'] . '</th>';
    echo '<th>' . $Lang['tui_log_hehuoren'] . '</th>';
    echo '<th>' . $Lang['tui_log_click_user_id'] . '</th>';
    echo '<th>' . $Lang['tui_log_click_money'] . '</th>';
    echo '<th>' . $Lang['tui_log_click_ip'] . '</th>';
    if($tchehuorenConfig['tui_open_region'] == 1){
        echo '<th>' . $Lang['tui_log_click_ip_region'] . '</th>';
    }
    echo '<th>' . $Lang['tui_log_time'] . '</th>';
    echo '</tr>';
    foreach ($tuiLogList as $key => $value) {
        
        $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($value['hehuoren_id']);
        $userinfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tchehuorenInfo['user_id']); 
        $clickUserinfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['click_user_id']); 
        
        echo '<tr>';
        echo '<td>' . $value['tui_id'] . '</td>';
        echo '<td>' . $userinfo['nickname'] .'(' .$tchehuorenInfo['id'] . ')</td>';
        echo '<td>' . $clickUserinfo['nickname'] . '(UID:' . $clickUserinfo['id'] . ')</td>';
        echo '<td><font color="#fd0d0d">' . $value['click_money'] . '</font></td>';
        echo '<td>' . long2ip($value['click_ip']) . '</td>';
        if($tchehuorenConfig['tui_open_region'] == 1){
            if(!empty($value['click_ip_region'])){
                echo '<td>' . $value['click_ip_region']. '</td>';
            }else{
                echo '<td>-</td>';
            }
        }
        echo '<td>' . dgmdate($value['log_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '</tr>';
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl."&act=tui_log&tui_id=".$tui_id);	
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tchehuoren#tom_tchehuoren_tui')->delete_by_id($_GET['id']);
    C::t('#tom_tchehuoren#tom_tchehuoren_tui_log')->delete_by_tui_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_admin_tchehuoren_tui");
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $tui_id         = isset($_GET['tui_id'])? intval($_GET['tui_id']):0;
    $tongcheng_id   = isset($_GET['tongcheng_id'])? intval($_GET['tongcheng_id']):0;
    $toutiao_id     = isset($_GET['toutiao_id'])? intval($_GET['toutiao_id']):0;
    $zhaopin_id     = isset($_GET['zhaopin_id'])? intval($_GET['zhaopin_id']):0;
    $fangchan_id    = isset($_GET['fangchan_id'])? intval($_GET['fangchan_id']):0;
    $ershou_id      = isset($_GET['ershou_id'])? intval($_GET['ershou_id']):0;
    $topic_id       = isset($_GET['topic_id'])? intval($_GET['topic_id']):0;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    
    $where = "";
    if($tui_id > 0){
        $where.= "AND id={$tui_id} ";
    }
    if($tongcheng_id > 0){
        $where.= "AND tongcheng_id={$tongcheng_id} ";
    }
    if($toutiao_id > 0){
        $where.= "AND toutiao_id={$toutiao_id} ";
    }
    if($zhaopin_id > 0){
        $where.= "AND zhaopin_id={$zhaopin_id} ";
    }
    if($fangchan_id > 0){
        $where.= "AND fangchan_id={$fangchan_id} ";
    }
    if($ershou_id > 0){
        $where.= "AND ershou_id={$ershou_id} ";
    }
    if($topic_id > 0){
        $where.= "AND topic_id={$topic_id} ";
    }
    if($status > 0){
        $where.= "AND status={$status} ";
    }

    $modBasePageUrl = $modBaseUrl."&status={$status}";
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_count($where);
    $tuiList = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list($where,'ORDER BY id DESC',$start,$pagesize);
    
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['tui_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['tui_help_1'] . '</li>';
    echo '<li>' . $Lang['tui_help_2'] . '</li>';
    echo '<li>' . $Lang['tui_help_3'] . '</li>';
    echo '<li>' . $Lang['tui_help_4'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['hehuoren_search_title'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>ID</b></td><td><input name="tui_id" type="text" value="'.$tui_id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['tui_tongcheng_id'] . '</b></td><td><input name="tongcheng_id" type="text" value="'.$tongcheng_id.'" size="40" /></td></tr>';
    if($__ShowTctoutiao == 1){
        echo '<tr><td width="100" align="right"><b>' . $Lang['tui_toutiao_id'] . '</b></td><td><input name="toutiao_id" type="text" value="'.$toutiao_id.'" size="40" /></td></tr>';
    }
    if($__ShowTczhaopin == 1){
        echo '<tr><td width="100" align="right"><b>' . $Lang['tui_zhaopin_id'] . '</b></td><td><input name="zhaopin_id" type="text" value="'.$zhaopin_id.'" size="40" /></td></tr>';
    }
    if($__ShowFangchan == 1){
        echo '<tr><td width="100" align="right"><b>' . $Lang['tui_fangchan_id'] . '</b></td><td><input name="fangchan_id" type="text" value="'.$fangchan_id.'" size="40" /></td></tr>';
    }
    if($__ShowTcershou == 1){
        echo '<tr><td width="100" align="right"><b>' . $Lang['tui_ershou_id'] . '</b></td><td><input name="ershou_id" type="text" value="'.$ershou_id.'" size="40" /></td></tr>';
    }
    if($__ShowTctopic == 1){
        echo '<tr><td width="100" align="right"><b>' . $Lang['tui_topic_id'] . '</b></td><td><input name="topic_id" type="text" value="'.$topic_id.'" size="40" /></td></tr>';
    }
    
    $status_selected_1 = $status_selected_2 = '';
    if($tui_status == 1){
        $status_selected_1 = 'selected';
    }else if($tui_status == 2){
        $status_selected_2 = 'selected';
    }
    echo '<tr><td width="100" align="right"><b>'.$Lang['tui_status'].'</b></td>';
    echo '<td><select style="width: 260px;" name="status" id="status">';
    echo '<option value="0">'.$Lang['tui_status'].'</option>';
    echo '<option value="1" '.$status_selected_1.'>'.$Lang['tui_status_1'].'</option>';
    echo '<option value="2" '.$status_selected_2.'>'.$Lang['tui_status_2'].'</option>';
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/
    
    $allMoneyCount = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_sun_all_money("");
    $syMoneyCount = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_sun_sy_money("");
    $allClickMoney = C::t('#tom_tchehuoren#tom_tchehuoren_tui_log')->fetch_sun_click_money("");
    echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
    echo $Lang['tui_tongji_all_money'].'<font color="#fd0d0d">('.$allMoneyCount.')</font>&nbsp;&nbsp;';
    echo $Lang['tui_tongji_sy_money'].'<font color="#fd0d0d">('.$syMoneyCount.')</font>&nbsp;&nbsp;';
    echo $Lang['tui_tongji_click_money'].'<font color="#fd0d0d">('.$allClickMoney.')</font>&nbsp;&nbsp;';
    echo '</div>';
    
    __create_nav_html();
    showtableheader(); /*dism��taobao��com*/
    echo '<tr class="header">';
    echo '<th>ID</th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['tui_title'] . '</th>';
    echo '<th>' . $Lang['tui_all_money'] . '</th>';
    echo '<th>' . $Lang['tui_sy_money'] . '</th>';
    echo '<th>' . $Lang['tui_click_money'] . '</th>';
    echo '<th>' . $Lang['tui_click_num'] . '</th>';
    echo '<th>' . $Lang['tui_status'] . '</th>';
    echo '<th>' . $Lang['tui_add_type'] . '</th>';
    echo '<th>' . $Lang['tui_pay_status'] . '</th>';
    echo '<th>' . $Lang['tui_is_show'] . '</th>';
    echo '<th>' . $Lang['tui_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tuiList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 0){
            if($value['site_id'] > 1){
                echo '<td>' . $siteInfo['name'] . '</td>';
            }else{
                echo '<td>' . $Lang['sites_one'] . '</td>';
            }
        }else{
            echo '<td> -- </td>';
        }
        if($value['tongcheng_id'] > 0){
            $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($value['tongcheng_id']);
            echo '<td><font color="#0894fb">'.$Lang['tui_tongcheng_title'] .'</font>'.cutstr(tongchengContentFormat($tongchengInfo['content']),20,"...").'<font color="#fd0d0d">(ID:'.$value['tongcheng_id'].')</font></td>';
        }else if($value['toutiao_id'] > 0){
            $tctoutiaoInfo = C::t("#tom_tctoutiao#tom_tctoutiao")->fetch_by_id($value['toutiao_id']);
            echo '<td><font color="#0894fb">'.$Lang['tui_toutiao_title'] .'</font>'.$tctoutiaoInfo['title'].'<font color="#fd0d0d">(ID:'.$value['toutiao_id'].')</font></td>';
        }else if($value['zhaopin_id'] > 0){
            $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($value['zhaopin_id']);
            echo '<td><font color="#0894fb">'.$Lang['tui_zhaopin_title'] .'</font>'.$tczhaopinInfo['title'].'<font color="#fd0d0d">(ID:'.$value['zhaopin_id'].')</font></td>';
        }else if($value['fangchan_id'] > 0){
            $tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($value['fangchan_id']);
            echo '<td><font color="#0894fb">'.$Lang['tui_fangchan_title'] .'</font>'.$tcfangchanInfo['title'].'<font color="#fd0d0d">(ID:'.$value['fangchan_id'].')</font></td>';
        }else if($value['ershou_id'] > 0){
            $tcershouInfo  = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($value['ershou_id']);
            echo '<td><font color="#0894fb">'.$Lang['tui_ershou_title'] .'</font>'.$tcershouInfo['title'].'<font color="#fd0d0d">(ID:'.$value['ershou_id'].')</font></td>';
        }else if($value['topic_id'] > 0){
            $tctopicInfo = C::t("#tom_tctopic#tom_tctopic")->fetch_by_id($value['topic_id']);
            echo '<td><font color="#0894fb">'.$Lang['tui_topic_title'] .'</font>'.$tctopicInfo['title'].'<font color="#fd0d0d">(ID:'.$value['topic_id'].')</font></td>';
        }else{
            echo '<td>-</td>';
        }
        echo '<td><font color="#fd0d0d">' . $value['all_money'] . '</font></td>';
        echo '<td><font color="#fd0d0d">' . $value['sy_money'] . '</font></td>';
        echo '<td><font color="#fd0d0d">' . $value['click_money'] . '</font></td>';
        echo '<td><font color="#fd0d0d">' . $value['click_num'] . '</font></td>';
        if($value['status'] == 1){
            echo '<td><font color="#238206">' . $Lang['tui_status_1'] . '</font></td>';
        }else if($value['status'] == 2){
            echo '<td><font color="#8e8e8e">' . $Lang['tui_status_2'] . '</font></td>';
        }else{
            echo '<td>-</td>';
        }
        if($value['add_type'] == 1){
            echo '<td><font color="#fd0d0d">' . $Lang['tui_add_type_1'] . '</font></td>';
        }else if($value['add_type'] == 2){
            echo '<td><font color="#fd0d0d">' . $Lang['tui_add_type_2'] . '</font></td>';
        }else{
            echo '<td>-</td>';
        }
        if($value['pay_status'] == 1){
            echo '<td><font color="#fd0d0d">' . $Lang['tui_pay_status_1'] . '</font></td>';
        }else if($value['pay_status'] == 2){
            echo '<td><font color="#238206">' . $Lang['tui_pay_status_2'] . '</font></td>';
        }else{
            echo '<td>-</td>';
        }
        if($value['is_show'] == 1){
            echo '<td><font color="#238206">' . $Lang['tui_is_show_1'] . '</font></td>';
        }else{
            echo '<td><font color="#8e8e8e">' . $Lang['tui_is_show_0'] . '</font></td>';
        }
        echo '<td>' . dgmdate($value['add_time'], "Y-m-d H:i", $tomSysOffset) . '</td>';
        echo '</td>';
        echo '<td style="line-height: 22px;">';
        if($value['is_show'] == 1){
            echo '<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['tui_is_show_0']. '</a>&nbsp;|&nbsp;';
        }else{
            echo '<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['tui_is_show_1']. '</a>&nbsp;|&nbsp;';
        }
        if($value['click_num'] == 0){
            echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        }
        echo '<a href="'.$modBaseUrl.'&act=tui_log&tui_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['tui_log_list_title']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $plugin_id       = isset($_GET['plugin_id'])? addslashes($_GET['plugin_id']):'';
    $tongcheng_id    = isset($_GET['tongcheng_id'])? intval($_GET['tongcheng_id']):0;
    $toutiao_id      = isset($_GET['toutiao_id'])? intval($_GET['toutiao_id']):0;
    $zhaopin_id      = isset($_GET['zhaopin_id'])? intval($_GET['zhaopin_id']):0;
    $fangchan_id     = isset($_GET['fangchan_id'])? intval($_GET['fangchan_id']):0;
    $ershou_id       = isset($_GET['ershou_id'])? intval($_GET['ershou_id']):0;
    $topic_id        = isset($_GET['topic_id'])? intval($_GET['topic_id']):0;
    $all_click_num   = isset($_GET['all_click_num'])? intval($_GET['all_click_num']):0;
    $click_money     = floatval($_GET['click_money'])>0 ? floatval($_GET['click_money']):0;
    $is_show         = isset($_GET['is_show'])? intval($_GET['is_show']):1;
    
    $all_money = $all_click_num*$click_money;
    
    if($_GET['act'] == 'add'){
        $data['plugin_id']       = $plugin_id;
        $data['tongcheng_id']    = $tongcheng_id;
        $data['toutiao_id']      = $toutiao_id;
        $data['zhaopin_id']      = $zhaopin_id;
        $data['fangchan_id']     = $fangchan_id;
        $data['ershou_id']       = $ershou_id;
        $data['topic_id']        = $topic_id;
    }
    $data['all_money']       = $all_money;
    $data['sy_money']        = $all_money;
    $data['click_money']     = $click_money;
    $data['add_type']        = 2;
    if($all_money > 0){
        $data['status']     = 1;
    }else{
        $data['status']     = 2;
    }
    $data['is_show']         = $is_show;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$__ShowTctoutiao,$__ShowTczhaopin,$__ShowFangchan,$__ShowTcershou,$__ShowTctopic;
    $options = array(
        'plugin_id'         => '',
        'tongcheng_id'      => 0,
        'toutiao_id'        => 0,
        'zhaopin_id'        => 0,
        'fangchan_id'       => 0,
        'ershou_id'         => 0,
        'topic_id'          => 0,
        'all_money'         => 0.00,
        'click_money'       => 0.00,
        'is_show'           => 1,
    );
    $options = array_merge($options, $infoArr);
    
    $pluginStr = '<tr class="header"><th>'.$Lang['tui_plugin_id'].'</th><th></th></tr>';
    $pluginStr.= '<tr><td width="300"><select style="width: 260px;" name="plugin_id" id="plugin_id">';
    if($value['plugin_id'] == 'tom_tongcheng'){
        $pluginStr.=  '<option value="tom_tongcheng" selected>'.$Lang['tui_plugin_tongcheng'].'</option>';
    }else{
        $pluginStr.=  '<option value="tom_tongcheng">'.$Lang['tui_plugin_tongcheng'].'</option>';
    }
    if($__ShowTctoutiao == 1){
        if($value['plugin_id'] == 'tom_tctoutiao'){
            $pluginStr.=  '<option value="tom_tctoutiao" selected>'.$Lang['tui_plugin_toutiao'].'</option>';
        }else{
            $pluginStr.=  '<option value="tom_tctoutiao">'.$Lang['tui_plugin_toutiao'].'</option>';
        }
    }
    if($__ShowTczhaopin == 1){
        if($value['plugin_id'] == 'tom_tczhaopin'){
            $pluginStr.=  '<option value="tom_tczhaopin" selected>'.$Lang['tui_plugin_zhaopin'].'</option>';
        }else{
            $pluginStr.=  '<option value="tom_tczhaopin">'.$Lang['tui_plugin_zhaopin'].'</option>';
        }
    }
    if($__ShowFangchan == 1){
        if($value['plugin_id'] == 'tom_tcfangchan'){
            $pluginStr.=  '<option value="tom_tcfangchan" selected>'.$Lang['tui_plugin_fangchan'].'</option>';
        }else{
            $pluginStr.=  '<option value="tom_tcfangchan">'.$Lang['tui_plugin_fangchan'].'</option>';
        }
    }
    if($__ShowTcershou == 1){
        if($value['plugin_id'] == 'tom_tcershou'){
            $pluginStr.=  '<option value="tom_tcershou" selected>'.$Lang['tui_plugin_ershou'].'</option>';
        }else{
            $pluginStr.=  '<option value="tom_tcershou">'.$Lang['tui_plugin_ershou'].'</option>';
        }
    }
    if($__ShowTctopic == 1){
        if($value['plugin_id'] == 'tom_tctopic'){
            $pluginStr.=  '<option value="tom_tctopic" selected>'.$Lang['tui_plugin_topic'].'</option>';
        }else{
            $pluginStr.=  '<option value="tom_tctopic">'.$Lang['tui_plugin_topic'].'</option>';
        }
    }
    
    $pluginStr.= '</select></td><td>'.$Lang['tui_plugin_id_msg'].'</td></tr>';
    echo $pluginStr;
    tomshowsetting(true,array('title'=>$Lang['tui_tongcheng_id'],'name'=>'tongcheng_id','value'=>$options['tongcheng_id'],'msg'=>$Lang['tui_tongcheng_id_msg']),"input");
    if($__ShowTctoutiao == 1){
        tomshowsetting(true,array('title'=>$Lang['tui_toutiao_id'],'name'=>'toutiao_id','value'=>$options['toutiao_id'],'msg'=>$Lang['tui_toutiao_id_msg']),"input");
    }
    if($__ShowTczhaopin == 1){
        tomshowsetting(true,array('title'=>$Lang['tui_zhaopin_id'],'name'=>'zhaopin_id','value'=>$options['zhaopin_id'],'msg'=>$Lang['tui_zhaopin_id_msg']),"input");
    }
    if($__ShowFangchan == 1){
        tomshowsetting(true,array('title'=>$Lang['tui_fangchan_id'],'name'=>'fangchan_id','value'=>$options['fangchan_id'],'msg'=>$Lang['tui_fangchan_id_msg']),"input");
    }
    if($__ShowTcershou == 1){
        tomshowsetting(true,array('title'=>$Lang['tui_ershou_id'],'name'=>'ershou_id','value'=>$options['ershou_id'],'msg'=>$Lang['tui_ershou_id_msg']),"input");
    }
    if($__ShowTctopic == 1){
        tomshowsetting(true,array('title'=>$Lang['tui_topic_id'],'name'=>'topic_id','value'=>$options['topic_id'],'msg'=>$Lang['tui_topic_id_msg']),"input");
    }
    
    tomshowsetting(true,array('title'=>$Lang['tui_all_click_num'],'name'=>'all_click_num','value'=>$options['all_click_num'],'msg'=>$Lang['tui_all_click_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['tui_click_money'],'name'=>'click_money','value'=>$options['click_money'],'msg'=>$Lang['tui_click_money_msg']),"input");
    
    $is_show_item = array(0=>$Lang['tui_is_show_0'],1=>$Lang['tui_is_show_1']);
    tomshowsetting(true,array('title'=>$Lang['tui_is_show'],'name'=>'is_show','value'=>$options['is_show'],'msg'=>$Lang['tui_is_show_msg'],'item'=>$is_show_item),"radio");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl,$_G;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['tui_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['tui_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['tui_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['tui_edit'],"",true);
    }else if($_GET['act'] == 'tui_log'){
        tomshownavli($Lang['tui_list_title'],$modBaseUrl,false);
        if($_G['uid'] == 1){
            tomshownavli($Lang['tui_add'],$modBaseUrl.'&act=add',false);
        }
        tomshownavli($Lang['tui_log_list_title'],$modBaseUrl.'&act=tui_log',true);
    }else{
        tomshownavli($Lang['tui_list_title'],$modBaseUrl,true);
        if($_G['uid'] == 1){
            tomshownavli($Lang['tui_add'],$modBaseUrl.'&act=add',false);
        }
        tomshownavli($Lang['tui_log_list_title'],$modBaseUrl.'&act=tui_log',false);
    }
    tomshownavfooter();
}