<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=order';
$modListUrl = $adminListUrl.'&tmod=order';
$modFromUrl = $adminFromUrl.'&tmod=order';

$get_list_url_value = get_list_url("tom_tchehuoren_admin_order_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'info'){
}else{
    
    set_list_url("tom_tchehuoren_admin_order_list");
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $hehuoren_id        = isset($_GET['hehuoren_id'])? intval($_GET['hehuoren_id']):0;
    $order_no           = isset($_GET['order_no'])? addslashes($_GET['order_no']):'';
    $order_status       = isset($_GET['order_status'])? intval($_GET['order_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($hehuoren_id)){
        $where.= " AND hehuoren_id={$hehuoren_id} ";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    if(!empty($order_no)){
        $where.= " AND order_no='{$order_no}' ";
    }
    if($order_status > 0){
        $where.= " AND order_status={$order_status} ";
    }
    
    $order = "ORDER BY order_time DESC,id DESC";
    
    $pagesize = 30;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_tchehuoren#tom_tchehuoren_order')->fetch_all_count($where);
    $orderList  = C::t('#tom_tchehuoren#tom_tchehuoren_order')->fetch_all_list($where,$order,$start,$pagesize);

    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&user_id={$user_id}&order_status={$order_status}&hehuoren_id={$hehuoren_id}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['hehuoren_search_title'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_search_user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_search_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="hehuoren_id" value="'.$hehuoren_id.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['order_no'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="order_no" value="'.$order_no.'"></td></tr>';
    
    $site_1 = '';
    if($site_id == 1){
        $site_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $order_status_1 = $order_status_2 = '';
    if($order_status == 1){
        $order_status_1 = 'selected';
    }else if($order_status == 2){
        $order_status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['order_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="order_status">';
    $statusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $statusStr.=  '<option value="1" '.$order_status_1.'>'.$Lang['order_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$order_status_2.'>'.$Lang['order_status_2'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/
    
    $nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
    
    $todayPayPrice = C::t('#tom_tchehuoren#tom_tchehuoren_order')->fetch_all_sun_pay_price(" AND pay_time > $nowDayTime AND order_status=2 ");
    $monthPayPrice = C::t('#tom_tchehuoren#tom_tchehuoren_order')->fetch_all_sun_pay_price(" AND pay_time > $nowMonthTime AND order_status=2 ");
    $allPayPrice = C::t('#tom_tchehuoren#tom_tchehuoren_order')->fetch_all_sun_pay_price(" AND order_status=2 ");
    echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
    echo $Lang['today_pay_price_title'].'<font color="#fd0d0d">('.$todayPayPrice.')</font>&nbsp;&nbsp;';
    echo $Lang['month_pay_price_title'].'<font color="#fd0d0d">('.$monthPayPrice.')</font>&nbsp;&nbsp;';
    echo $Lang['all_pay_price_title'].'<font color="#fd0d0d">('.$allPayPrice.')</font>&nbsp;&nbsp;';
    echo '</div>';
    
    __create_nav_html();
    showtableheader(); /*dism��taobao��com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['order_no'] . '</th>';
    echo '<th>' . $Lang['order_user'] . '</th>';
    echo '<th>' . $Lang['order_type'] . '</th>';
    echo '<th>' . $Lang['order_hehuoren'] . '</th>';
    echo '<th>' . $Lang['order_tj_hehuoren'] . '</th>';
    echo '<th>' . $Lang['order_pay_price'] . '</th>';
    echo '<th>' . $Lang['order_status'] . '</th>';
    echo '<th>' . $Lang['order_pay_time'] . '</th>';
    echo '<th>' . $Lang['order_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($orderList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $hehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($value['user_id']);
        $tjHehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($value['tj_hehuoren_id']);
        $tjUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tjHehuorenInfo['user_id']);
        $dengjiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($value['dengji_id']);
        
        echo '<tr>';
        if($value['site_id'] > 0){
            if($value['site_id'] > 1){
                echo '<td>' . $siteInfo['name'] . '</td>';
            }else{
                echo '<td>' . $Lang['sites_one'] . '</td>';
            }
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $value['order_no'] . '</td>';
        echo '<td>' . $userInfo['nickname'] . '<font color="#fd0d0d">(ID:' . $value['user_id'] . ')</font></td>';
        if($value['type'] == 1){
            echo '<td><font color="#238206">' . $Lang['order_type_1'] . '</font></td>';
        }else if($value['type'] == 2){
            echo '<td><font color="#0894fb">' . $Lang['order_type_2'].'</font><br/>'. $dengjiInfo['name'] . '<font color="#fd0d0d">(' . $value['days'] . $Lang['tian']. ')</font></td>';
        }else if($value['type'] == 3){
            $tuiInfo = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_by_order_no($value['order_no']);
            echo '<td><font color="#0894fb">' . $Lang['order_type_3'].'</font><font color="#fd0d0d">(ID:' . $tuiInfo['id']. ')</font></td>';
        }
        if($value['type'] == 2){
            echo '<td>' . $userInfo['nickname'] . '<font color="#fd0d0d">(ID:' . $hehuorenInfo['id'] . ')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        if($tjHehuorenInfo['id'] > 0){
            echo '<td>' . $tjUserInfo['nickname'] . '<font color="#fd0d0d">(ID:' . $tjHehuorenInfo['id'] . ')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td><font color="#fd0d0d">' . $value['pay_price']. '</font></td>';
        if($value['order_status'] == 1 ){
            echo '<td><font color="#f00">'.$Lang['order_status_1'].'</font></td>';
        }else if($value['order_status'] == 2 ){
            echo '<td><font color="#0a9409">'.$Lang['order_status_2'].'</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['pay_time'] > 0){
            echo '<td>' . dgmdate($value['pay_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . dgmdate($value['order_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td> -- </td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    tomshownavli($Lang['order_list_title'],$modBaseUrl,true);
    tomshownavfooter();
}