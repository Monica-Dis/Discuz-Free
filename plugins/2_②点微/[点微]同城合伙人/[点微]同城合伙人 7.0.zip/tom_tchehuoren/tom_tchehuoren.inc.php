<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
$nowMonthTime = dgmdate($_G['timestamp'], 'Ym', $tomSysOffset);
$nowWeekTime = dgmdate($_G['timestamp'], 'YW', $tomSysOffset);
require_once libfile('function/discuzcode');
$prand = rand(1, 1000);
$cssJsVersion = '20210714';
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tchehuorenConfig['wx_share_title'];
$shareDesc = $tchehuorenConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tchehuoren&site=' . $site_id . '&mod=add');
$shareLogo = $tchehuorenConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$__ShowTcshop = 0;
$tcshopConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcshop/tom_tcshop.inc.php')) {
	$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
	if ($tcshopConfig['open_tcshop'] == 1) {
		$__ShowTcshop = 1;
	}
}
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')) {
	$tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
	if ($tcqianggouConfig['open_tcqianggou'] == 1) {
		$__ShowTcqianggou = 1;
	}
}
$__ShowTcptuan = 0;
$tcptuanConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcptuan/tom_tcptuan.inc.php')) {
	$tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
	if ($tcptuanConfig['open_tcptuan'] == 1) {
		$__ShowTcptuan = 1;
	}
}
$__ShowTc114 = 0;
$tc114Config = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tc114/tom_tc114.inc.php')) {
	$tc114Config = $_G['cache']['plugin']['tom_tc114'];
	if ($tc114Config['open_tc114'] == 1) {
		$__ShowTc114 = 1;
	}
}
$__ShowTcyikatong = 0;
$__Card_name = '';
$tcyikatongConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')) {
	$tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
	if ($tcyikatongConfig['open_tcyikatong'] == 1) {
		$__ShowTcyikatong = 1;
		$__Card_name = $tcyikatongConfig['card_name'];
	}
}
$__ShowTcmall = 0;
$tcmallConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcmall/tom_tcmall.inc.php')) {
	$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
	if ($tcmallConfig['open_tcmall'] == 1) {
		$__ShowTcmall = 1;
	}
}
$__ShowTczhaopin = 0;
$tczhaopinConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')) {
	$tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
	if ($tczhaopinConfig['open_tczhaopin'] == 1) {
		$__ShowTczhaopin = 1;
	}
}
$__ShowTchuodong = 0;
$tchuodongConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchuodong/tom_tchuodong.inc.php')) {
	$tchuodongConfig = $_G['cache']['plugin']['tom_tchuodong'];
	if ($tchuodongConfig['open_tchuodong'] == 1) {
		$__ShowTchuodong = 1;
	}
}
$__ShowFangchan = 0;
$tcfangchanConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcfangchan/tom_tcfangchan.inc.php')) {
	$tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
	if ($tcfangchanConfig['open_tcfangchan'] == 1) {
		$__ShowFangchan = 1;
	}
}
$__ShowTcershou = 0;
$tcershouConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcershou/tom_tcershou.inc.php')) {
	$tcershouConfig = $_G['cache']['plugin']['tom_tcershou'];
	if ($tcershouConfig['open_tcershou'] == 1) {
		$__ShowTcershou = 1;
	}
}
$tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
if ($tchehuorenInfo && $tchehuorenInfo['id'] > 0) {
	$shareUrl = $shareUrl . ('&tj_hehuoren_id=' . $tchehuorenInfo['id']);
} else {
	if ($_GET['mod'] != 'add' && $_GET['mod'] != 'addtui') {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tchehuoren&site=' . $site_id . '&mod=add'));
		exit(0);
	}
}
$ajaxUrl = 'plugin.php?id=tom_tchehuoren:ajax&site=' . $site_id . '&formhash=' . $formhash;
$ajaxUpdateHehuorenStatusUrl = 'plugin.php?id=tom_tchehuoren:ajax&site=' . $site_id . '&act=update_hehuoren_status&formhash=' . $formhash;
$payUrl = 'plugin.php?id=tom_tchehuoren:pay&site=' . $site_id;
if ($_GET['mod'] == 'index') {
	if ($tchehuorenInfo['openid'] != $__UserInfo['openid']) {
		$updateData = array();
		$updateData['openid'] = $__UserInfo['openid'];
		C::t('#tom_tchehuoren#tom_tchehuoren')->update($tchehuorenInfo['id'], $updateData);
	}
	$totalMoney = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_shouyi_sum(' AND hehuoren_id = ' . $tchehuorenInfo['id'] . ' ');
	$totalMoney = number_format(floatval($totalMoney), 2, '.', '');
	if ($totalMoney > 10000) {
		$totalMoney = intval($totalMoney);
	}
	$daiRuzhangMoney = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_dai_shouyi_sum(' AND hehuoren_id = ' . $tchehuorenInfo['id'] . ' ');
	$daiRuzhangMoney = number_format(floatval($daiRuzhangMoney), 2, '.', '');
	$dengjiInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
	$dengjiInfo = array();
	if (is_array($dengjiInfoTmp) && !empty($dengjiInfoTmp)) {
		$dengjiInfo = $dengjiInfoTmp;
		if (!preg_match('/^http/', $dengjiInfo['picurl'])) {
			if (strpos($dengjiInfo['picurl'], 'source/plugin/tom_') === false) {
				$dengjiInfo['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $dengjiInfo['picurl'];
			} else {
				$dengjiInfo['picurl'] = $dengjiInfo['picurl'];
			}
		} else {
			$dengjiInfo['picurl'] = $dengjiInfo['picurl'];
		}
	}
	if ($tchehuorenInfo['tj_hehuoren_id'] > 0) {
		$TJtchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
		$TJuserinfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($TJtchehuorenInfo['user_id']);
	}
	$shouyiNumDay = 3;
	if ($tchehuorenConfig['shouyi_num_day'] > 0) {
		$shouyiNumDay = $tchehuorenConfig['shouyi_num_day'];
	}
	$ruzhangTime = TIMESTAMP - $shouyiNumDay * 86400;
	$ruzhuangShouyiTmp = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_all_list(' AND hehuoren_id = ' . $tchehuorenInfo['id'] . ' AND add_time <= ' . $ruzhangTime . ' AND shouyi_status = 1 ', 'ORDER BY id DESC', 0, 1000);
	if (is_array($ruzhuangShouyiTmp) && !empty($ruzhuangShouyiTmp)) {
		foreach ($ruzhuangShouyiTmp as $key => $value) {
			$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($__UserInfo['id']);
			$updateData = array();
			$updateData['shouyi_status'] = 2;
			$updateData['handle_status'] = 1;
			$updateData['shouyi_time'] = TIMESTAMP;
			C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->update($value['id'], $updateData);
			DB::query('UPDATE ' . DB::table('tom_tongcheng_user') . (' SET money = money + ' . $value['shouyi_price'] . ' WHERE id=\'' . $userInfoTmp['id'] . '\''), 'UNBUFFERED');
			$insertData = array();
			$insertData['user_id'] = $userInfoTmp['id'];
			$insertData['type_id'] = 2;
			$insertData['change_money'] = $value['shouyi_price'];
			$insertData['old_money'] = $userInfoTmp['money'];
			$insertData['tag'] = $tchehuorenConfig['hehuoren_name'] . lang('plugin/tom_tchehuoren', 'shouyi_tag');
			$insertData['beizu'] = $value['content'];
			$insertData['log_time'] = TIMESTAMP;
			C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
		}
		$userAllMoneyTmp = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_total_shouyi_sum(' AND hehuoren_id = ' . $tchehuorenInfo['id'] . ' ');
		$userMonthMoneyTmp = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_total_shouyi_sum(' AND hehuoren_id = ' . $tchehuorenInfo['id'] . ' AND month_time = ' . $nowMonthTime . ' ');
		$userWeekMoneyTmp = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_total_shouyi_sum(' AND hehuoren_id = ' . $tchehuorenInfo['id'] . ' AND week_time = ' . $nowWeekTime . ' ');
		$userAllMoneyTmp = number_format(floatval($userAllMoneyTmp), 2, '.', '');
		$userMonthMoneyTmp = number_format(floatval($userMonthMoneyTmp), 2, '.', '');
		$userWeekMoneyTmp = number_format(floatval($userWeekMoneyTmp), 2, '.', '');
		if ($tchehuorenInfo['open_xu_money'] == 0) {
			$updateData = array();
			$updateData['all_money'] = $userAllMoneyTmp;
			$updateData['week_money'] = $userWeekMoneyTmp;
			$updateData['month_money'] = $userMonthMoneyTmp;
			C::t('#tom_tchehuoren#tom_tchehuoren')->update($tchehuorenInfo['id'], $updateData);
		}
	}
	$shouyiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_all_list('AND hehuoren_id = ' . $tchehuorenInfo['id'] . ' AND shouyi_status in(1,2)', 'ORDER BY id DESC', 0, 10);
	$shouyiList = array();
	if (is_array($shouyiListTmp) && !empty($shouyiListTmp)) {
		foreach ($shouyiListTmp as $key => $value) {
			if (empty($value['title'])) {
				$value['title'] = $value['type'];
			}
			$shouyiList[$key] = $value;
			$ruzhangTime = $value['add_time'] + $tchehuorenConfig['shouyi_num_day'] * 86400;
			$shouyiList[$key]['ruzhuang_time'] = dgmdate($ruzhangTime, 'm-d', $tomSysOffset);
			$lyUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['ly_user_id']);
			$shouyiList[$key]['lyUserInfo'] = $lyUserInfoTmp;
		}
	}
	$yushouyiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_yushouyi')->fetch_all_list(' AND hehuoren_id = ' . $tchehuorenInfo['id'] . ' AND status=0 ', 'ORDER BY id DESC', 0, 10);
	$yushouyiList = array();
	if (is_array($yushouyiListTmp) && !empty($yushouyiListTmp)) {
		foreach ($yushouyiListTmp as $key => $value) {
			$yushouyi_show_num_day = 7;
			if ($tchehuorenConfig['yushouyi_show_num_day'] > 0) {
				$yushouyi_show_num_day = $tchehuorenConfig['yushouyi_show_num_day'];
			}
			$sevenDaysTimes = TIMESTAMP - $yushouyi_show_num_day * 86400;
			$shouyiInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_by_order_no($value['order_no']);
			if ($shouyiInfoTmp && $shouyiInfoTmp['id'] > 0) {
				$updateData = array();
				$updateData['status'] = 1;
				C::t('#tom_tchehuoren#tom_tchehuoren_yushouyi')->update($value['id'], $updateData);
			} else {
				if ($value['add_time'] < $sevenDaysTimes) {
					$updateData = array();
					$updateData['status'] = 1;
					C::t('#tom_tchehuoren#tom_tchehuoren_yushouyi')->update($value['id'], $updateData);
				} else {
					if (empty($value['title'])) {
						$value['title'] = $value['type'];
					}
					$yushouyiList[$key] = $value;
					$lyUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['ly_user_id']);
					$yushouyiList[$key]['lyUserInfo'] = $lyUserInfoTmp;
				}
			}
		}
	}
	$subscribeFlag = 0;
	$open_subscribe = 0;
	$access_token = $weixinClass->get_access_token();
	if ($tongchengConfig['open_subscribe'] == 1 && $tongchengConfig['open_child_subscribe_sites'] == 1) {
		$open_subscribe = 1;
	} else {
		if ($tongchengConfig['open_subscribe'] == 1 && $site_id == 1) {
			$open_subscribe = 1;
		}
	}
	if ($open_subscribe == 1 && !empty($__UserInfo['openid']) && !empty($access_token)) {
		$get_user_info_url = 'https://api.weixin.qq.com/cgi-bin/user/info?access_token=' . $access_token . '&openid=' . $__UserInfo['openid'] . '&lang=zh_CN';
		$return = get_html($get_user_info_url);
		if (!empty($return)) {
			$tcContent = json_decode($return, true);
			if (is_array($tcContent) && !empty($tcContent) && isset($tcContent['subscribe'])) {
				if ($tcContent['subscribe'] == 1) {
					$subscribeFlag = 1;
				} else {
					$subscribeFlag = 2;
				}
			}
		}
	}
	if ($tchehuorenConfig['haibao_link_type'] == 1) {
		$haibaoUrl = $_G['siteurl'] . 'plugin.php?id=tom_tchehuoren&site=' . $site_id . '&mod=add&tj_hehuoren_id=' . $tchehuorenInfo['id'];
	} elseif ($tchehuorenConfig['haibao_link_type'] == 2) {
		$haibaoUrl = $_G['siteurl'] . 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=index&tj_hehuoren_id=' . $tchehuorenInfo['id'];
	} elseif ($tchehuorenConfig['haibao_link_type'] == 3) {
		$haibaoUrl = $_G['siteurl'] . 'plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=index&tj_hehuoren_id=' . $tchehuorenInfo['id'];
	} elseif ($tchehuorenConfig['haibao_link_type'] == 4) {
		$haibaoUrl = $_G['siteurl'] . 'plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=index&tj_hehuoren_id=' . $tchehuorenInfo['id'];
	}
	$haibaoQrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($haibaoUrl);
	$shareUrl = $_G['siteurl'] . 'plugin.php?id=tom_tchehuoren&site=' . $site_id . '&mod=add&tj_hehuoren_id=' . $tchehuorenInfo['id'];
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tchehuoren/images/index.js';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tchehuoren:index');
	echo '<script src="source/plugin/tom_tchehuoren/images/index.js"></script>';
} elseif ($_GET['mod'] == 'add' || $_GET['mod'] == 'inlet') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/add.php';
} elseif ($_GET['mod'] == 'shouyi') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/shouyi.php';
} elseif ($_GET['mod'] == 'yushouyi') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/yushouyi.php';
} elseif ($_GET['mod'] == 'phb') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/phb.php';
} elseif ($_GET['mod'] == 'level') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/level.php';
} elseif ($_GET['mod'] == 'fans') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/fans.php';
} elseif ($_GET['mod'] == 'subordinate') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/subordinate.php';
} elseif ($_GET['mod'] == 'task') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/task.php';
} elseif ($_GET['mod'] == 'tui') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/tui.php';
} elseif ($_GET['mod'] == 'addtui') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/addtui.php';
} elseif ($_GET['mod'] == 'mall') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/mall.php';
} elseif ($_GET['mod'] == 'ptuan') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/ptuan.php';
} elseif ($_GET['mod'] == 'qianggou') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/qianggou.php';
} elseif ($_GET['mod'] == 'huodong') {
	include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/module/huodong.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tchehuoren&site=' . $site_id . '&mod=add'));
	exit(0);
}
tomoutput();