<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/class/function.tui.php';

if($tj_hehuoren_id > 0 && $__UserInfo['id'] > 0 && $tchehuorenConfig['open_tui'] == 1){
    
    $allowTuiDoStatus = 0;
    $tuiDoInfo = array();
    $tuiDoTitle = '';
    $tuiDoContent = '';
    if($tongcheng_id > 0){
        $tuiDoTitle = $title;
        $tuiDoContent = $title.'|||'.$tongcheng_id;
        $tuiDoListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND tongcheng_id={$tongcheng_id} AND status=1 AND is_show=1 ",'ORDER BY id DESC',0,1);
        if($tuiDoListTmp && $tuiDoListTmp[0]['id'] > 0 && $tuiDoListTmp[0]['sy_money'] > 0){
            $tuiDoInfo = $tuiDoListTmp[0];
            $allowTuiDoStatus = 1;
        }else if($tuiDoListTmp && $tuiDoListTmp[0]['id'] > 0 && $tuiDoListTmp[0]['sy_money'] == 0){
            $updateData = array();
            $updateData['status']           = 2;
            C::t('#tom_tchehuoren#tom_tchehuoren_tui')->update($tuiDoListTmp[0]['id'],$updateData);
        }
    }
    if($tctoutiao_id > 0){
        $tuiDoTitle = $tctoutiaoInfo['title'];
        $tuiDoContent = $tctoutiaoInfo['title'].'|||'.$tctoutiao_id;
        $tuiDoListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND toutiao_id={$tctoutiao_id} AND status=1 AND is_show=1 ",'ORDER BY id DESC',0,1);
        if($tuiDoListTmp && $tuiDoListTmp[0]['id'] > 0 && $tuiDoListTmp[0]['sy_money'] > 0){
            $tuiDoInfo = $tuiDoListTmp[0];
            $allowTuiDoStatus = 1;
        }else if($tuiDoListTmp && $tuiDoListTmp[0]['id'] > 0 && $tuiDoListTmp[0]['sy_money'] == 0){
            $updateData = array();
            $updateData['status']           = 2;
            C::t('#tom_tchehuoren#tom_tchehuoren_tui')->update($tuiDoListTmp[0]['id'],$updateData);
        }
    }
    if($tczhaopin_id > 0){
        $tuiDoTitle = $tczhaopinInfo['title'];
        $tuiDoContent = $tczhaopinInfo['title'].'|||'.$tczhaopin_id;
        $tuiDoListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND zhaopin_id={$tczhaopin_id} AND status=1 AND is_show=1 ",'ORDER BY id DESC',0,1);
        if($tuiDoListTmp && $tuiDoListTmp[0]['id'] > 0 && $tuiDoListTmp[0]['sy_money'] > 0){
            $tuiDoInfo = $tuiDoListTmp[0];
            $allowTuiDoStatus = 1;
        }else if($tuiDoListTmp && $tuiDoListTmp[0]['id'] > 0 && $tuiDoListTmp[0]['sy_money'] == 0){
            $updateData = array();
            $updateData['status']           = 2;
            C::t('#tom_tchehuoren#tom_tchehuoren_tui')->update($tuiDoListTmp[0]['id'],$updateData);
        }
    }
    if($tcfangchan_id > 0){
        $tuiDoTitle = $tcfangchanInfo['title'];
        $tuiDoContent = $tcfangchanInfo['title'].'|||'.$tcfangchan_id;
        $tuiDoListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND fangchan_id={$tcfangchan_id} AND status=1 AND is_show=1 ",'ORDER BY id DESC',0,1);
        if($tuiDoListTmp && $tuiDoListTmp[0]['id'] > 0 && $tuiDoListTmp[0]['sy_money'] > 0){
            $tuiDoInfo = $tuiDoListTmp[0];
            $allowTuiDoStatus = 1;
        }else if($tuiDoListTmp && $tuiDoListTmp[0]['id'] > 0 && $tuiDoListTmp[0]['sy_money'] == 0){
            $updateData = array();
            $updateData['status']           = 2;
            C::t('#tom_tchehuoren#tom_tchehuoren_tui')->update($tuiDoListTmp[0]['id'],$updateData);
        }
    }
    if($tcershou_goods_id > 0){
        $tuiDoTitle = $goodsInfo['title'];
        $tuiDoContent = $goodsInfo['title'].'|||'.$tcershou_goods_id;
        $tuiDoListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND ershou_id={$tcershou_goods_id} AND status=1 AND is_show=1 ",'ORDER BY id DESC',0,1);
        if($tuiDoListTmp && $tuiDoListTmp[0]['id'] > 0 && $tuiDoListTmp[0]['sy_money'] > 0){
            $tuiDoInfo = $tuiDoListTmp[0];
            $allowTuiDoStatus = 1;
        }else if($tuiDoListTmp && $tuiDoListTmp[0]['id'] > 0 && $tuiDoListTmp[0]['sy_money'] == 0){
            $updateData = array();
            $updateData['status']           = 2;
            C::t('#tom_tchehuoren#tom_tchehuoren_tui')->update($tuiDoListTmp[0]['id'],$updateData);
        }
    }
    
    if($tctopic_id > 0){
        $tuiDoTitle = $tctopicInfo['title'];
        $tuiDoContent = $tctopicInfo['title'].'|||'.$tctopic_id;
        $tuiDoListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND topic_id={$tctopic_id} AND status=1 AND is_show=1 ",'ORDER BY id DESC',0,1);
        if($tuiDoListTmp && $tuiDoListTmp[0]['id'] > 0 && $tuiDoListTmp[0]['sy_money'] > 0){
            $tuiDoInfo = $tuiDoListTmp[0];
            $allowTuiDoStatus = 1;
        }else if($tuiDoListTmp && $tuiDoListTmp[0]['id'] > 0 && $tuiDoListTmp[0]['sy_money'] == 0){
            $updateData = array();
            $updateData['status']           = 2;
            C::t('#tom_tchehuoren#tom_tchehuoren_tui')->update($tuiDoListTmp[0]['id'],$updateData);
        }
    }
    
    if($allowTuiDoStatus == 1){
        $tuiDoTodayCount = C::t('#tom_tchehuoren#tom_tchehuoren_tui_log')->fetch_all_count(" AND click_user_id={$__UserInfo['id']} AND log_time > {$nowDayTime} ");
        if($tuiDoTodayCount > 0){
            $allowTuiDoStatus = 0;
        }
    }
    
    if($allowTuiDoStatus == 1){
        $tuiDoCount = C::t('#tom_tchehuoren#tom_tchehuoren_tui_log')->fetch_all_count(" AND click_user_id={$__UserInfo['id']} AND tui_id={$tuiDoInfo['id']} ");
        if($tuiDoCount > 0){
            $allowTuiDoStatus = 0;
        }
    }
    
    if($allowTuiDoStatus == 1){
        $tuiDoHehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($tj_hehuoren_id);
        if($tuiDoHehuorenInfo['id'] > 0 && $tuiDoHehuorenInfo['status'] == 1){
            $tuiDoHehuorenDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tuiDoHehuorenInfo['dengji_id']);
            if($tuiDoHehuorenDengji && $tuiDoHehuorenDengji['id'] > 0 && $tuiDoHehuorenDengji['tui_fc_open'] == 1){}else{
                $allowTuiDoStatus = 0;
            }
        }else{
            $allowTuiDoStatus = 0;
        }
    }
    
    if($allowTuiDoStatus == 1){
        $tuiDoTodayMoney = C::t('#tom_tchehuoren#tom_tchehuoren_tui_log')->fetch_sun_click_money(" AND log_time > $nowDayTime AND hehuoren_id={$tuiDoHehuorenInfo['id']} ");
        if($tuiDoTodayMoney > $tchehuorenConfig['tui_max_money']){
            $allowTuiDoStatus = 0;
        }
    }
    
    $tui_ip_region = '';
    if($allowTuiDoStatus == 1 && $tchehuorenConfig['tui_open_region'] == 1){
        @$tui_ip_check_r = hhr_tui_ip_check_region();
        if($tui_ip_check_r && $tui_ip_check_r['status'] == 200){
            $tui_ip_region = $tui_ip_check_r['region'];
        }else{
            $allowTuiDoStatus = 0;
        }
    }
    
    if($allowTuiDoStatus == 1){
        
        $tui_do_hehuoren_fc_money = 0;
        if($tuiDoInfo['sy_money'] > $tuiDoInfo['click_money']){
            $tui_do_hehuoren_fc_money = $tuiDoInfo['click_money'];
            DB::query("UPDATE ".DB::table('tom_tchehuoren_tui')." SET sy_money=sy_money-{$tuiDoInfo['click_money']},click_num=click_num+1 WHERE id='{$tuiDoInfo['id']}' ", 'UNBUFFERED');
        }else if($tuiDoInfo['sy_money'] <= $tuiDoInfo['click_money']){
            $tui_do_hehuoren_fc_money = $tuiDoInfo['sy_money'];
            DB::query("UPDATE ".DB::table('tom_tchehuoren_tui')." SET sy_money=0,status=2,click_num=click_num+1 WHERE id='{$tuiDoInfo['id']}' ", 'UNBUFFERED');
        }
        
        $insertData = array();
        $insertData['plugin_id']        = 'tom_tchehuoren';
        $insertData['order_no']         = '-';
        $insertData['hehuoren_id']      = $tuiDoHehuorenInfo['id'];
        $insertData['ly_user_id']       = $__UserInfo['id'];
        $insertData['child_hehuoren_id'] = 0;
        $insertData['today_time']       = $nowDayTime;
        $insertData['week_time']        = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);
        $insertData['month_time']       = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
        $insertData['title']            = $tuiDoTitle;
        $insertData['type']             = lang('plugin/tom_tchehuoren', 'tui_do_type');
        $insertData['shouyi_price']     = $tui_do_hehuoren_fc_money;
        $insertData['content']          = $tuiDoContent;
        $insertData['shouyi_status']    = 1;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
        
        $insertData = array();
        $insertData['tui_id']        = $tuiDoInfo['id'];
        $insertData['hehuoren_id']   = $tuiDoHehuorenInfo['id'];
        $insertData['click_user_id'] = $__UserInfo['id'];
        $insertData['click_money']   = $tui_do_hehuoren_fc_money;
        $insertData['click_ip']      = @bindec(decbin(ip2long($_G['clientip'])));
        $insertData['click_ip_region']   = $tui_ip_region;
        $insertData['log_time']      = TIMESTAMP;
        C::t('#tom_tchehuoren#tom_tchehuoren_tui_log')->insert($insertData);
        $tuiDoLogId = C::t('#tom_tchehuoren#tom_tchehuoren_tui_log')->insert_id();
        
        $ajaxTuiDoTzUrl = "plugin.php?id=tom_tchehuoren:ajax&site={$site_id}&act=tui_do_tz&tui_log_id={$tuiDoLogId}&formhash=".$formhash;
        
    }
    
}