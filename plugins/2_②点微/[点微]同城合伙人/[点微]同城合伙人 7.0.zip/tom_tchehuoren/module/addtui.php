<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tongcheng_id   = isset($_GET['tongcheng_id'])?intval($_GET['tongcheng_id']):0;
$zhaopin_id     = isset($_GET['zhaopin_id'])?intval($_GET['zhaopin_id']):0;
$fangchan_id    = isset($_GET['fangchan_id'])?intval($_GET['fangchan_id']):0;
$ershou_id      = isset($_GET['ershou_id'])?intval($_GET['ershou_id']):0;

$title          = '';
$tui_doing      = 0;
$tui_sy_num     = 0;
if($tongcheng_id > 0){
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    $title = cutstr(tongchengContentFormat($tongchengInfo['content']),20,"...");
    $tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND tongcheng_id={$tongcheng_id} AND status=1 ",'ORDER BY id DESC',0,1);
    if($tuiListTmp && $tuiListTmp[0]['id'] > 0){
        $tui_doing = 1;
        $tui_sy_num = ceil($tuiListTmp[0]['sy_money']/$tuiListTmp[0]['click_money']);
    }
}
if($zhaopin_id > 0){
    $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($zhaopin_id);
    $title = $tczhaopinInfo['title'];
    $tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND zhaopin_id={$zhaopin_id} AND status=1 ",'ORDER BY id DESC',0,1);
    if($tuiListTmp && $tuiListTmp[0]['id'] > 0){
        $tui_doing = 1;
        $tui_sy_num = ceil($tuiListTmp[0]['sy_money']/$tuiListTmp[0]['click_money']);
    }
}
if($fangchan_id > 0){
    $tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($fangchan_id);
    $title = $tcfangchanInfo['title'];
    $tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND fangchan_id={$fangchan_id} AND status=1 ",'ORDER BY id DESC',0,1);
    if($tuiListTmp && $tuiListTmp[0]['id'] > 0){
        $tui_doing = 1;
        $tui_sy_num = ceil($tuiListTmp[0]['sy_money']/$tuiListTmp[0]['click_money']);
    }
}
if($ershou_id > 0){
    $tcershouInfo  = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($ershou_id);
    $title = $tcershouInfo['title'];
    $tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND ershou_id={$ershou_id} AND status=1 ",'ORDER BY id DESC',0,1);
    if($tuiListTmp && $tuiListTmp[0]['id'] > 0){
        $tui_doing = 1;
        $tui_sy_num = ceil($tuiListTmp[0]['sy_money']/$tuiListTmp[0]['click_money']);
    }
}

$tuiListTmp = array();
if($tongcheng_id > 0){
    $tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND tongcheng_id={$tongcheng_id} ",'ORDER BY id DESC',0,100);
}
if($zhaopin_id > 0){
    $tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND zhaopin_id={$zhaopin_id} ",'ORDER BY id DESC',0,100);
}
if($fangchan_id > 0){
    $tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND fangchan_id={$fangchan_id} ",'ORDER BY id DESC',0,100);
}
if($ershou_id > 0){
    $tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list(" AND ershou_id={$ershou_id} ",'ORDER BY id DESC',0,100);
}
$tuiIds = '99999999';
$tuiIdsArr = array();
if(is_array($tuiListTmp) && !empty($tuiListTmp)){
    foreach ($tuiListTmp as $key => $value){
        $tuiIdsArr[] = $value['id'];
    }
    $tuiIds = implode(",", $tuiIdsArr);
}
$tuiLogCount = C::t('#tom_tchehuoren#tom_tchehuoren_tui_log')->fetch_all_count(" AND tui_id IN({$tuiIds}) ");

$tuiListMoney = array();
$tui_list_money_str = str_replace("\r\n","{n}",$tchehuorenConfig['tui_list_money']); 
$tui_list_money_str = str_replace("\n","{n}",$tui_list_money_str);
$tui_list_money_arr = explode("{n}", $tui_list_money_str);
if(is_array($tui_list_money_arr) && !empty($tui_list_money_arr)){
    foreach ($tui_list_money_arr as $key => $value){
        $arr = explode("|", $value);
        $tuiListMoney[$key]['price']            = $arr[0];
        $tuiListMoney[$key]['click_num']        = $arr[1];
    }
}

$ajaxUrl = $ajaxUrl."&act=tuiloglist&tongcheng_id={$tongcheng_id}&zhaopin_id={$zhaopin_id}&fangchan_id={$fangchan_id}&ershou_id={$ershou_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchehuoren:addtui");