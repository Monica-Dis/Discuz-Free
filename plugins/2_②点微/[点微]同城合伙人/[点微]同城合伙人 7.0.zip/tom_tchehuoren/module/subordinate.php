<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

if($tchehuorenConfig['open_subordinate'] != 1){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$site_id}&mod=index");exit;
}

$whereStr = " AND tj_hehuoren_id = {$tchehuorenInfo['id']} ";

$pagesize   = 10;
$start      = ($page - 1)*$pagesize;

$count = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_count($whereStr);
$subordinateListTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_list($whereStr, 'ORDER BY id DESC', $start, $pagesize);
$subordinateList = array();
if(is_array($subordinateListTmp) && !empty($subordinateListTmp)){
    foreach ($subordinateListTmp as $key => $value){
        $subordinateList[$key] = $value;

        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $tjUserCountTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_count("AND tj_hehuoren_id = {$value['id']}");

        $subordinateList[$key]['userInfo']      = $userInfoTmp;
        $subordinateList[$key]['tjUserCount']   = $tjUserCountTmp;
    }
}


$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=subordinate&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=subordinate&page={$nextPage}";

$subordinateUrl = $_G['siteurl'].'plugin.php?id=tom_tchehuoren&site='.$site_id.'&mod=add&tj_hehuoren_id='.$tchehuorenInfo['id'];
$haibaoQrcodeImg = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($subordinateUrl);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchehuoren:subordinate");