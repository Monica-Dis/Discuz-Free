<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$fansCount          = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_count(" AND tj_hehuoren_id = {$tchehuorenInfo['id']} ");
$subordinateCount   = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_count(" AND tj_hehuoren_id = {$tchehuorenInfo['id']} ");
$monthMoney         = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_shouyi_sum(" AND hehuoren_id = {$tchehuorenInfo['id']} AND month_time = {$nowMonthTime} ");
$monthMoney         = number_format(floatval($monthMoney), 2, '.', '');

$myDengjiInfo = $upLevelListTmp = array();

$dengjiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_all_list('', 'ORDER BY level ASC', 0, 3);

$nameArr        = array(0 => '');
$tjArr          = array(0 => lang('plugin/tom_tchehuoren', 'level_htm_tj'));
$tongchengArr   = array(0 => lang('plugin/tom_tchehuoren', 'level_htm_fl'));
$tcshopArr      = array(0 => lang('plugin/tom_tchehuoren', 'level_htm_shop'));
$tcmallArr      = array(0 => lang('plugin/tom_tchehuoren', 'level_htm_mall'));
$tcqianggouArr  = array(0 => lang('plugin/tom_tchehuoren', 'level_htm_qg'));
$tcptuanArr     = array(0 => lang('plugin/tom_tchehuoren', 'level_htm_pt'));
$tc114Arr       = array(0 => lang('plugin/tom_tchehuoren', 'level_htm_114'));
$tcyikatongArr  = array(0 => $__Card_name.lang('plugin/tom_tchehuoren', 'level_htm_vip'));
$tczhaopinArr   = array(0 => lang('plugin/tom_tchehuoren', 'level_htm_zhaopin'));
$tcfangchanArr  = array(0 => lang('plugin/tom_tchehuoren', 'level_htm_fangchan'));
$tcershouArr    = array(0 => lang('plugin/tom_tchehuoren', 'level_htm_ershou'));
$tchuodongArr   = array(0 => lang('plugin/tom_tchehuoren', 'level_htm_huodong'));

if(is_array($dengjiListTmp) && !empty($dengjiListTmp)){
    foreach($dengjiListTmp as $key => $value){

        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $value['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $value['picurl'] = $value['picurl'];
            }
        }else{
            $value['picurl'] = $value['picurl'];
        }

        if($value['id'] == $tchehuorenInfo['dengji_id']){
            $myDengjiInfo = $value;
        }

        if($value['level'] > 1){
            $upLevelListTmp[$key] = $value;
        }

        $nameArr[] = '<img src="'.$value['picurl'].'">'.$value['name'];
        if($value['tuijian_fc_scale'] >0 ){
            $tjArr[] = $value['tuijian_fc_scale'].'%';
        }else{
            $tjArr[] = '<span class="red">X</span>';
        }
        if($value['fl_fc_open'] == 1){
            $tongchengArr[] = $value['fl_fc_scale'].'%';
        }else{
            $tongchengArr[] = '<span class="red">X</span>';
        }
        if($value['shop_fc_open'] == 1){
            $tcshopArr[] = $value['shop_fc_scale'].'%';
        }else{
            $tcshopArr[] = '<span class="red">X</span>';
        }
        if($value['mall_fc_open'] == 1){
            $tcmallArr[] = '<span class="yuan"></span>';
        }else{
            $tcmallArr[] = '<span class="red">X</span>';
        }
        if($value['qg_fc_open'] == 1){
            $tcqianggouArr[] = '<span class="yuan"></span>';
        }else{
            $tcqianggouArr[] = '<span class="red">X</span>';
        }
        if($value['pt_fc_open'] == 1){
            $tcptuanArr[] = '<span class="yuan"></span>';
        }else{
            $tcptuanArr[] = '<span class="red">X</span>';
        }
        if($value['114_fc_open'] == 1){
            $tc114Arr[] = $value['114_fc_scale'].'%';
        }else{
            $tc114Arr[] = '<span class="red">X</span>';
        }
        if($value['vip_fc_open'] == 1){
            $tcyikatongArr[] = $value['vip_fc_scale'].'%';
        }else{
            $tcyikatongArr[] = '<span class="red">X</span>';
        }
        if($value['zp_fc_open'] == 1){
            $tczhaopinArr[] = $value['zp_fc_scale'].'%';
        }else{
            $tczhaopinArr[] = '<span class="red">X</span>';
        }
        if($value['fc_fc_open'] == 1){
            $tcfangchanArr[] = $value['fc_fc_scale'].'%';
        }else{
            $tcfangchanArr[] = '<span class="red">X</span>';
        }
        if($value['ershou_fc_open'] == 1){
            $tcershouArr[] = $value['ershou_fc_scale'].'%';
        }else{
            $tcershouArr[] = '<span class="red">X</span>';
        }
        if($value['hd_fc_open'] == 1){
            $tchuodongArr[] = '<span class="yuan"></span>';
        }else{
            $tchuodongArr[] = '<span class="red">X</span>';
        }
    }
}

$levelArr = array();
$levelArr[] = $nameArr;
if($tchehuorenConfig['open_subordinate'] == 1){
    $levelArr[] = $tjArr;
}
$levelArr[] = $tongchengArr;
if($__ShowTcshop == 1){
    $levelArr[] = $tcshopArr;
}
if($__ShowTcmall == 1){
    $levelArr[] = $tcmallArr;
}
if($__ShowTcqianggou == 1){
    $levelArr[] = $tcqianggouArr;
}
if($__ShowTcptuan == 1){
    $levelArr[] = $tcptuanArr;
}
if($__ShowTc114 == 1){
    $levelArr[] = $tc114Arr;
}
if($__ShowTcyikatong == 1){
    $levelArr[] = $tcyikatongArr;
}
if($__ShowTczhaopin == 1){
    $levelArr[] = $tczhaopinArr;
}
if($__ShowFangchan == 1){
    $levelArr[] = $tcfangchanArr;
}
if($__ShowTcershou == 1){
    $levelArr[] = $tcershouArr;
}
if($__ShowTchuodong == 1){
    $levelArr[] = $tchuodongArr;
}

$upLevelFreeList = $upLevelPayList = array();
if(is_array($upLevelListTmp) && !empty($upLevelListTmp)){
    foreach($upLevelListTmp as $key => $value){
        $upLevelFreeList[$key] = $value;

        $upLevelStatusTmp = 0;
        if(($tchehuorenInfo['expire_time'] - TIMESTAMP) < 86400*3  && $value['level'] == $myDengjiInfo['level']){
            $upLevelStatusTmp = 1;
        }else if($tchehuorenInfo['expire_time'] > TIMESTAMP && $value['level'] > $myDengjiInfo['level']){
            $upLevelStatusTmp = 1;
        }else if($tchehuorenInfo['expire_time'] == 0){
            $upLevelStatusTmp = 1;
        }
        
        $upLevelFreeStatusFansTmp = $upLevelFreeStatusSubTmp = $upLevelFreeStatusUpTmp = 0;
        if($upLevelStatusTmp == 1 && $value['fans_num'] > 0 && $fansCount >= $value['fans_num']){ 
            $upLevelFreeStatusFansTmp = 1;
        }else if($upLevelStatusTmp == 1 && $value['fans_num'] == 0){
            $upLevelFreeStatusFansTmp = 1;
        }
        if($upLevelStatusTmp == 1 && $value['subordinate_num'] > 0 && $subordinateCount >= $value['subordinate_num']){
            $upLevelFreeStatusSubTmp = 1;
        }else if($upLevelStatusTmp == 1 && $value['subordinate_num'] == 0){
            $upLevelFreeStatusSubTmp = 1;
        }
        if($upLevelStatusTmp == 1 && $value['up_level'] > 0 && $monthMoney >= $value['up_level']){
            $upLevelFreeStatusUpTmp = 1;
        }else if($upLevelStatusTmp == 1 && $value['up_level'] == 0){
            $upLevelFreeStatusUpTmp = 1;
        }
        if($upLevelFreeStatusFansTmp == 1 && $upLevelFreeStatusSubTmp == 1 && $upLevelFreeStatusUpTmp == 1){
            $upLevelFreeList[$key]['upLevelFreeStatus'] = 1;
        }

        if($upLevelStatusTmp == 1 && $value['open_pay'] == 1 && $value['pay_price'] > 0){
            $upLevelPayList[$key] = $value;
        }
    }
}

$showFreeLevelUpBox = $showPayLevelUpBox = 0;
if($tchehuorenConfig['hehuoren_level_type'] == 1){
    $showFreeLevelUpBox = 1;
}else if($tchehuorenConfig['hehuoren_level_type'] == 2){
    $showPayLevelUpBox = 1;
}else if($tchehuorenConfig['hehuoren_level_type'] == 3){
    $showFreeLevelUpBox = 1;
    $showPayLevelUpBox = 1;
}

$defaultType = '';
if($showFreeLevelUpBox == 1){
    $defaultType = 'free_level';
}else if($showPayLevelUpBox == 1){
    $defaultType = 'pay_level';
}

$dengji_desc = discuzcode($tchehuorenConfig['dengji_desc'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchehuoren:level");