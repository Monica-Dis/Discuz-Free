<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$dengjiInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
$dengjiInfo = array();
if(is_array($dengjiInfoTmp) && !empty($dengjiInfoTmp)){
    $dengjiInfo = $dengjiInfoTmp;
    if(!preg_match('/^http/', $dengjiInfo['picurl']) ){
        if(strpos($dengjiInfo['picurl'], 'source/plugin/tom_tchehuoren') === false){
            $dengjiInfo['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$dengjiInfo['picurl'];
        }else{
            $dengjiInfo['picurl'] = $dengjiInfo['picurl'];
        }
    }else{
        $dengjiInfo['picurl'] = $dengjiInfo['picurl'];
    }
}

$todayMoney = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_shouyi_sum(" AND hehuoren_id = {$tchehuorenInfo['id']} AND today_time = {$nowDayTime} ");
$weekMoney  = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_shouyi_sum(" AND hehuoren_id = {$tchehuorenInfo['id']} AND week_time = {$nowWeekTime} ");
$monthMoney = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_shouyi_sum(" AND hehuoren_id = {$tchehuorenInfo['id']} AND month_time = {$nowMonthTime} ");
$todayMoney = number_format(floatval($todayMoney), 2, '.', '');
$weekMoney  = number_format(floatval($weekMoney), 2, '.', '');
$monthMoney = number_format(floatval($monthMoney), 2, '.', '');

if($dengjiInfo['tui_fc_open'] == 1 && $tchehuorenConfig['open_tui'] == 1){
    $tuiCount = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_count(" AND status=1 AND is_show=1 AND site_id IN({$sql_in_site_ids})");
}
if($dengjiInfo['mall_fc_open'] == 1 && $__ShowTcmall == 1){
    $tcmallGoodsCount = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND status=1 AND shenhe_status=1 AND hehuoren_tg_open=1 AND site_id IN({$sql_in_site_ids}) ");
}
if($dengjiInfo['qg_fc_open'] == 1 && $__ShowTcqianggou == 1){
    $tcqianggouGoodsCount  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_count(" AND status=1 AND shenhe_status=1 AND type_id=1 AND hehuoren_tg_open = 1 AND qiang_status IN(1,2) AND site_id IN({$sql_in_site_ids}) ");
}
if($dengjiInfo['pt_fc_open'] == 1 && $__ShowTcptuan == 1){
    $tcptuanGoodsCount = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_count(" AND status=1 AND shenhe_status=1 AND hehuoren_tg_open=1 AND ptuan_status=1 AND site_id IN({$sql_in_site_ids}) ");
}
if($dengjiInfo['hd_fc_open'] == 1 && $__ShowTchuodong == 1){
    $tchuodongCount = C::t('#tom_tchuodong#tom_tchuodong')->fetch_all_count(" AND status = 1 AND shenhe_status = 1 AND hehuoren_tg_open=1 AND huodong_status IN(1,2) AND site_id IN({$sql_in_site_ids}) ");
}

$subscribeFlag = 0;
$open_subscribe = 0;
$access_token = $weixinClass->get_access_token();
if($tongchengConfig['open_subscribe']==1 && $tongchengConfig['open_child_subscribe_sites']==1){
    $open_subscribe = 1;
}else if($tongchengConfig['open_subscribe']==1 && $site_id==1){
    $open_subscribe = 1;
}
if($open_subscribe==1 && !empty($__UserInfo['openid']) && !empty($access_token)){
    $get_user_info_url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token={$access_token}&openid={$__UserInfo['openid']}&lang=zh_CN";
    $return = get_html($get_user_info_url);
    if(!empty($return)){
        $tcContent = json_decode($return,true);
        if(is_array($tcContent) && !empty($tcContent) && isset($tcContent['subscribe'])){
            if($tcContent['subscribe'] == 1){
                $subscribeFlag = 1;
            }else{
                $subscribeFlag = 2;
            }
        }
    }
}

$shareUrl = $_G['siteurl'].'plugin.php?id=tom_tchehuoren&site='.$site_id.'&mod=task&tj_hehuoren_id='.$tchehuorenInfo['id'];

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchehuoren:task");