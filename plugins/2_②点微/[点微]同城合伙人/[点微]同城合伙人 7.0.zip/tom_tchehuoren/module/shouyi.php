<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

$whereStr = " AND hehuoren_id = {$tchehuorenInfo['id']} ";

if($type > 0){
    $whereStr .= " AND shouyi_status = {$type} ";
}

$pagesize   = 10;
$start      = ($page - 1)*$pagesize;

$count = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_all_count($whereStr);
$shouyiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_all_List($whereStr, 'ORDER BY id DESC', $start, $pagesize);
$shouyiList = array();
if(is_array($shouyiListTmp) && !empty($shouyiListTmp)){
    foreach ($shouyiListTmp as $key => $value){
        if(empty($value['title'])){
            $value['title'] = $value['type'];
        }
        $shouyiList[$key] = $value;
        $ruzhangTime = $value['add_time'] + $tchehuorenConfig['shouyi_num_day']*86400;
        $shouyiList[$key]['ruzhuang_time'] = dgmdate($ruzhangTime, "m-d", $tomSysOffset);
        $lyUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['ly_user_id']);
        $shouyiList[$key]['lyUserInfo'] = $lyUserInfoTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=shouyi&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=shouyi&type={$type}&page={$nextPage}";

$navUrl = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=shouyi";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchehuoren:shouyi");