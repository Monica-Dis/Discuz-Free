<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       = intval($_GET['type'])>0? intval($_GET['type']):1;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$keyword    = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';

$whereStr = " AND tj_hehuoren_id = {$tchehuorenInfo['id']} ";

$myUserCount = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_count($whereStr);

$mySubordinateUserCount = 0;
if($tchehuorenConfig['open_subordinate'] == 1){
    $mySubordinateList = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_list($whereStr, " ORDER BY id DESC ", 0, 1000);
    if(is_array($mySubordinateList) && !empty($mySubordinateList)){
        $mySubordinateIdsArr = array();
        foreach($mySubordinateList as $key => $value){
            $mySubordinateIdsArr[] = $value['id'];
        }
        $mySubordinateIdsStr = implode(',', $mySubordinateIdsArr);
        if($type == 2){
            $whereStr = "AND tj_hehuoren_id IN({$mySubordinateIdsStr}) ";
        }
        $mySubordinateUserCount = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_count("AND tj_hehuoren_id IN({$mySubordinateIdsStr}) ");
    }
    
}

$pagesize   = 10;
$start      = ($page - 1)*$pagesize;

if(!empty($keyword)){
    if(is_numeric($keyword)){
        $keyword = intval($keyword);
        $whereStr .= "AND (id={$keyword} OR nickname LIKE '%{$keyword}%' OR tel LIKE '%{$keyword}%')";
    }else{
        $keyword = str_replace(array('%', '_'),'',$keyword);
        $whereStr .= " AND (nickname LIKE '%{$keyword}%' OR tel LIKE '%{$keyword}%')";
    }
}

$fansListTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_list($whereStr, 'ORDER BY id DESC', $start, $pagesize);
$fansList = array();
if(is_array($fansListTmp) && !empty($fansListTmp)){
    foreach ($fansListTmp as $key => $value){
        $fansList[$key] = $value;
    }
}

if($type == 1){
    $count = $myUserCount;
}else if($type == 2){
    $count = $mySubordinateUserCount;
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=fans&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=fans&type={$type}&page={$nextPage}";

$navUrl = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=fans";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchehuoren:fans");