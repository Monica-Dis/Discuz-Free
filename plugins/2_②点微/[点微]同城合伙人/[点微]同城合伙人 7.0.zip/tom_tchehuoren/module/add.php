<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tj_hehuoren_id = isset($_GET['tj_hehuoren_id'])?intval($_GET['tj_hehuoren_id']):0;
if($tj_hehuoren_id > 0){
    $lifeTime = 86400;
    dsetcookie('tom_hehuoren_tj_hehuoren_id',$tj_hehuoren_id, $lifeTime);
}else{
    $cookie_tj_hehuoren_id = getcookie('tom_hehuoren_tj_hehuoren_id');
    if($cookie_tj_hehuoren_id > 0){
        $tj_hehuoren_id = $cookie_tj_hehuoren_id;
    }
}

if($tchehuorenConfig['subordinate_type'] == 2 && $tchehuorenConfig['open_subordinate'] == 1){
    if($__UserInfo['tj_hehuoren_id'] > 0){
        $tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
    }else{
        $tj_hehuoren_id = 0;
    }
}
if($tchehuorenConfig['subordinate_type'] == 3 && $tchehuorenConfig['open_subordinate'] == 1 && $tj_hehuoren_id == 0){
    if($__UserInfo['tj_hehuoren_id'] > 0){
        $tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
    }
}
if($tj_hehuoren_id > 0){
    $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($tj_hehuoren_id);
    if($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1){
    }else{
        $tj_hehuoren_id = 0;
    }
}

$problemListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_common_problem')->fetch_all_list('', 'ORDER BY paixu ASC, add_time DESC', 0, 100);
$exclusive = $problem = array();
$e = $p = 1;
if(is_array($problemListTmp) && !empty($problemListTmp)){
    foreach($problemListTmp as $key => $value){
        if($value['type'] == 1){
            $exclusive[$key] = $value;
            $exclusive[$key]['content'] = dhtmlspecialchars($value['content']);
            $exclusive[$key]['i'] = $e;

            if(!preg_match('/^http/', $value['zhuanshu_picurl']) ){
                $exclusive[$key]['zhuanshu_picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['zhuanshu_picurl'];
            }else{
                $exclusive[$key]['zhuanshu_picurl'] = $value['zhuanshu_picurl'];
            }

            $e++;
        }else if($value['type'] == 2){
            $problem[$key] = $value;
            $problem[$key]['content'] = dhtmlspecialchars($value['content']);
            $problem[$key]['i'] = $p;
            $p++;
        }
    }
}

$shenqingStatus = 0;
$shenqingListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_shenqing')->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND status = 1 AND pay_status IN(0,2) ","ORDER BY id DESC",0,1);
if(is_array($shenqingListTmp) && !empty($shenqingListTmp)){
    $shenqingStatus = 1;
    if($shenqingListTmp[0]['status'] == 3){
        $shenqingStatus = 2;
    }else if($shenqingListTmp[0]['status'] == 4){
        $shenqingStatus = 0;
    }
}
if($tchehuorenInfo['id'] > 0){
    $shenqingStatus = 3;
}

$phone_back_url = $weixinClass->get_url();
$phone_back_url = urlencode($phone_back_url);

$phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchehuoren:add");