<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

$whereStr = " AND hehuoren_id = {$tchehuorenInfo['id']} AND status=0 ";

$pagesize   = 10;
$start      = ($page - 1)*$pagesize;
$count = C::t('#tom_tchehuoren#tom_tchehuoren_yushouyi')->fetch_all_count($whereStr);
$yushouyiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_yushouyi')->fetch_all_list($whereStr, 'ORDER BY id DESC', $start, $pagesize);
$yushouyiList = array();
if(is_array($yushouyiListTmp) && !empty($yushouyiListTmp)){
    foreach($yushouyiListTmp as $key => $value){

        $yushouyi_show_num_day = 7;
        if($tchehuorenConfig['yushouyi_show_num_day'] > 0){
            $yushouyi_show_num_day = $tchehuorenConfig['yushouyi_show_num_day'];
        }

        $sevenDaysTimes = TIMESTAMP - $yushouyi_show_num_day * 86400;
        $shouyiInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->fetch_by_order_no($value['order_no']);
        if($shouyiInfoTmp && $shouyiInfoTmp['id'] > 0){
            $updateData = array();
            $updateData['status']    = 1;
            C::t('#tom_tchehuoren#tom_tchehuoren_yushouyi')->update($value['id'], $updateData);
            $value['status'] = 1;
        }else if($value['add_time'] < $sevenDaysTimes){
            $updateData = array();
            $updateData['status']    = 1;
            C::t('#tom_tchehuoren#tom_tchehuoren_yushouyi')->update($value['id'], $updateData);
            $value['status'] = 1;
        }else{
            if(empty($value['title'])){
                $value['title'] = $value['type'];
            }
            $yushouyiList[$key] = $value;
            $lyUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['ly_user_id']);
            $yushouyiList[$key]['lyUserInfo'] = $lyUserInfoTmp;
        }
        
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=yushouyi&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tchehuoren&site={$site_id}&mod=yushouyi&type={$type}&page={$nextPage}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tchehuoren:yushouyi");