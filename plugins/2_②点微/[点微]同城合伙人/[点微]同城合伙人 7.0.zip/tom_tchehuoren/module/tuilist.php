<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$outStr = '';

$page = intval($_GET['page'])>0 ? intval($_GET['page']) : 1;

$where = " AND is_show = 1 AND (pay_status = 0 OR pay_status = 2) AND site_id IN({$sql_in_site_ids})  ";

$pagesize = 10;
$start = ($page - 1) * $pagesize;
$tuiListTmp = C::t('#tom_tchehuoren#tom_tchehuoren_tui')->fetch_all_list($where, "ORDER BY status ASC, id DESC", $start, $pagesize);
$tuiList = array();
if(is_array($tuiListTmp) && !empty($tuiListTmp)){
    foreach($tuiListTmp as $key => $value){
        $tuiList[$key] = $value;
        $hideTuiStatus = 0;
        if($value['tongcheng_id'] > 0){
            $tongchengInfo              = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($value['tongcheng_id']);
            $tuiList[$key]['title']     = cutstr(tongchengContentFormat($tongchengInfo['content']),30,"...");
            $tuiList[$key]['link']      = 'plugin.php?id=tom_tongcheng&site='.$tongchengInfo['site_id'].'&mod=view&xxid='.$tongchengInfo['id'];
            if($tongchengInfo['status'] != 1){
                $hideTuiStatus = 1;
            }
        }else if($value['toutiao_id'] > 0){
            $tctoutiaoInfo = C::t("#tom_tctoutiao#tom_tctoutiao")->fetch_by_id($value['toutiao_id']);
            $tuiList[$key]['title']     = $tctoutiaoInfo['title'];
            if($tctoutiaoInfo['site_id'] > 100){
                $tuiList[$key]['link']      = 'plugin.php?id=tom_tctoutiao&site='.$tctoutiaoInfo['site_id'].'&mod=info&aid='.$tctoutiaoInfo['id'];
            }else{
                $tuiList[$key]['link']      = 'plugin.php?id=tom_tctoutiao&site=1&mod=info&aid='.$tctoutiaoInfo['id'];
            }
            if($tctoutiaoInfo['status'] != 1){
                $hideTuiStatus = 1;
            }
        }else if($value['zhaopin_id'] > 0){
            $tczhaopinInfo = C::t("#tom_tczhaopin#tom_tczhaopin")->fetch_by_id($value['zhaopin_id']);
            $tuiList[$key]['title']     = $tczhaopinInfo['title'];
            $tuiList[$key]['link']      = 'plugin.php?id=tom_tczhaopin&site='.$tczhaopinInfo['site_id'].'&mod=zhaopininfo&tczhaopin_id='.$tczhaopinInfo['id'];
            if($tczhaopinInfo['status'] != 1){
                $hideTuiStatus = 1;
            }
        }else if($value['fangchan_id'] > 0){
            $tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($value['fangchan_id']);
            $tuiList[$key]['title']     = $tcfangchanInfo['title'];
            $tuiList[$key]['link']      = 'plugin.php?id=tom_tcfangchan&site='.$tcfangchanInfo['site_id'].'&mod=info&tcfangchan_id='.$tcfangchanInfo['id'];
            if($tcfangchanInfo['status'] != 1){
                $hideTuiStatus = 1;
            }
        }else if($value['ershou_id'] > 0){
            $tcershouInfo  = C::t('#tom_tcershou#tom_tcershou_goods')->fetch_by_id($value['ershou_id']);
            $tuiList[$key]['title']     = $tcershouInfo['title'];
            $tuiList[$key]['link']      = 'plugin.php?id=tom_tcershou&site='.$tcershouInfo['site_id'].'&mod=goodsinfo&goods_id='.$tcershouInfo['id'];
            if($tcershouInfo['status'] != 1){
                $hideTuiStatus = 1;
            }
        }else if($value['topic_id'] > 0){
            $tctopicInfo = C::t("#tom_tctopic#tom_tctopic")->fetch_by_id($value['topic_id']);
            $tuiList[$key]['title']     = $tctopicInfo['title'];
            $tuiList[$key]['link']      = 'plugin.php?id=tom_tctopic&site='.$tctopicInfo['site_id'].'&mod=info&tctopic_id='.$tctopicInfo['id'];
            if($tctopicInfo['status'] != 1){
                $hideTuiStatus = 1;
            }
        }else{
            $tuiList[$key]['title']     = '-';
            $tuiList[$key]['link']      = 'javascript:void(0);';
        }

        if($hideTuiStatus == 1){
            $updateData = array();
            $updateData['is_show']     = 0;
            C::t('#tom_tchehuoren#tom_tchehuoren_tui')->update($value['id'],$updateData);
        }

    }
}

if(is_array($tuiList) && !empty($tuiList)){
    foreach ($tuiList as $key => $value){

        $outStr .= '<div class="tui-item dislay-flex">';
            $outStr .= '<div class="tg-m flex">';
                $outStr .= '<div class="m-title">'.$value['title'].'</div>';
                $outStr .= '<div class="m-msg">'.lang('plugin/tom_tchehuoren', 'ajax_tui_list_msg1').'<span>'.$value['click_num'].'</span>'.lang('plugin/tom_tchehuoren', 'ajax_tui_list_msg2').'<span>'.$value['sy_money'].'</span>'.lang('plugin/tom_tchehuoren', 'yuan').'</div>';
            $outStr .= '</div>';
            $outStr .= '<div class="tg-btn">';
                $outStr .= '<div class="btn">';
                    if($value['status'] == 1){
                        $outStr .= '<a class="do"  href="'.$value['link'].'">'.$value['click_money'].lang('plugin/tom_tchehuoren', 'ajax_tui_list_zhuan').'</a>';
                    }else{
                        $outStr .= '<a class="end"  href="'.$value['link'].'">'.lang('plugin/tom_tchehuoren', 'ajax_tui_list_end').'</a>';
                    }
                $outStr .= '</div>';
            $outStr .= '</div>';
        $outStr .= '</div>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;