<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
$upload = new tom_upload();

if($_GET['act'] == 'prize_pic' && $_GET['formhash'] == FORMHASH){

    $prize_id = intval($_GET['prize_id'])>0 ? intval($_GET['prize_id']):0;
    $name     = "prize_prize_pic_".$prize_id;
    
    $_FILES[$name]['name'] = addslashes(diconv(urldecode($_FILES[$name]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES[$name], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    $updateData = array();
    $updateData['picurl'] = $upload->attach['attachment'];
    C::t("#tom_tcchoujiang#tom_tcchoujiang_prize")->update($prize_id, $updateData);
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'picurl' && $_GET['formhash'] == FORMHASH){
    
    $upload = new tom_upload();
    $_FILES["filedata1"]['name'] = addslashes(diconv(urldecode($_FILES["filedata1"]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata1'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    //require_once libfile('class/image');
    //$image = new image();
    //$image->Thumb($upload->attach['target'], '', 200, 200, 2, 1);
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'toppic' && $_GET['formhash'] == FORMHASH){
    
    $upload = new tom_upload();
    $_FILES["filedata2"]['name'] = addslashes(diconv(urldecode($_FILES["filedata2"]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata2'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    require_once libfile('class/image');
    $image = new image();
    $image->Thumb($upload->attach['target'], '', 640, 300, 2, 1);
        
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'photo' && $_GET['formhash'] == FORMHASH){

    $upload = new tom_upload();
    $_FILES["filedata3"]['name'] = addslashes(diconv(urldecode($_FILES["filedata3"]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata3'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}