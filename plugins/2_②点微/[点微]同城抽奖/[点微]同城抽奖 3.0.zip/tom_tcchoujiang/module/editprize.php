<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcchoujiang_id   = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):0;

$choujiangInfo    = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);
$tcshopInfo       = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($choujiangInfo['tcshop_id']);

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcchoujing&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $prize_id     = intval($_GET['prize_id'])>0? intval($_GET['prize_id']): 0;
    $type         = intval($_GET['type'])>0? intval($_GET['type']): 0;
    $peisong_type = intval($_GET['peisong_type'])>0? intval($_GET['peisong_type']): 1;
    $name         = isset($_GET['name'])? addslashes($_GET['name']):"";
    $num          = intval($_GET['num'])>0? intval($_GET['num']): 0;
    $chance       = intval($_GET['chance'])>0? intval($_GET['chance']): 0;
    $hexiao_pwd   = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):"";
    $content      = isset($_GET['content'])? addslashes($_GET['content']):"";
    
    $prizeInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_by_id($prize_id);
    $prizeListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_list("AND id != {$prize_id} AND tcchoujiang_id = {$tcchoujiang_id} AND type = {$type}");
    
    $chanceCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_sum_chance("AND tcchoujiang_id = {$tcchoujiang_id} ");
    if($chanceCount - $prizeInfo['chance'] + $chance*100 > 10000){
        echo 301;exit;
    }else if(!empty($prizeListTmp)){
        echo 302;exit; 
    }else{
        $updateData = array();
        $updateData['tcchoujiang_id']   = $tcchoujiang_id;
        $updateData['tcshop_id']        = $choujiangInfo['tcshop_id'];
        $updateData['name']             = $name;
        $updateData['num']              = $num;
        $updateData['chance']           = $chance*100;
        $updateData['type']             = $type;
        $updateData['peisong_type']     = $peisong_type;
        $updateData['hexiao_pwd']       = $hexiao_pwd;
        $updateData['is_extend']        = 0;
        $updateData['content']          = $content;
        $updateData['add_time']         = TIMESTAMP;
        C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->update($prize_id,$updateData);

        $log_txt .= ''.lang('plugin/tom_tcchoujiang', 'prize_grade').':&nbsp;<span><font color="#fd0d0d">'.$type.'</font>, </span>'.lang('plugin/tom_tcchoujiang', 'prize_name').':&nbsp;<span><font color="#fd0d0d">'.$name.'</font>, </span>'.lang('plugin/tom_tcchoujiang', 'prize_num').':&nbsp;<span><font color="#fd0d0d">'.$num.'</font>, </span>'.lang('plugin/tom_tcchoujiang', 'prize_chance').':&nbsp;<span><font color="#fd0d0d">'.$chance.'</font></span>'.'<br/>';
        $insertData = array();
        $insertData['is_admin']      = 0;
        $insertData['prize_id']      = $prize_id;
        $insertData['log_txt']       = $log_txt;
        $insertData['log_time']      = TIMESTAMP;
        C::t("#tom_tcchoujiang#tom_tcchoujiang_prize_log")->insert($insertData);

        echo 200; exit;
    }
}else if($_GET['act'] == 'add_prize' && $_GET['formhash'] == FORMHASH){
    $outStr = '';
    
    $insertData = array();
    $insertData['tcchoujiang_id'] = $tcchoujiang_id;
    
    C::t("#tom_tcchoujiang#tom_tcchoujiang_prize")->insert($insertData);
    $prize_id = C::t("#tom_tcchoujiang#tom_tcchoujiang_prize")->insert_id();
    
    $outStr = $prize_id;
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($_GET['act'] == 'remove_prize' && $_GET['formhash'] == FORMHASH){
    
    $prize_id = intval($_GET['prize_id'])>0? intval($_GET['prize_id']): 0;
    
    C::t("#tom_tcchoujiang#tom_tcchoujiang_prize")->delete_by_id($prize_id);
    
    echo 1;exit;
}

$prizeListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_list(" AND tcchoujiang_id = {$tcchoujiang_id} ","ORDER BY type ASC,id DESC",0,50);
$prizeList = array();
if(is_array($prizeListTmp) && !empty($prizeListTmp)){
    foreach ($prizeListTmp as $key => $value) {
        $prizeList[$key] = $value;
        $prizeList[$key]['old_picurl'] = $value['picurl'];
        if(!preg_match('/^http:/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_tcchoujiang/') === FALSE){
                $prizeList[$key]['picurl'] = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $prizeList[$key]['picurl'] = $value['picurl'];
            }
        }else{
            $prizeList[$key]['picurl'] = $value['picurl'];
        }
        $prizeList[$key]['chance']   = $value['chance']/100;
    }
}

$saveUrl     = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=editprize&tcchoujiang_id={$tcchoujiang_id}&act=save&formhash={$formhash}";
$addPrizeUrl = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=editprize&act=add_prize&tcchoujiang_id={$tcchoujiang_id}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcchoujiang:editprize");