<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcchoujiang_id   = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):0;

$choujiangInfo    = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);
$tcshopInfo       = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($choujiangInfo['tcshop_id']);

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcchoujing&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $title              = isset($_GET['title'])? addslashes($_GET['title']):0;
    $is_answer          = isset($_GET['is_answer'])? intval($_GET['is_answer']):0;
    $answer_num         = isset($_GET['answer_num'])? intval($_GET['answer_num']):0;
    $open_score_pay     = isset($_GET['open_score_pay'])? intval($_GET['open_score_pay']):0;
    $pay_score          = isset($_GET['pay_score'])? intval($_GET['pay_score']):0;
    $before_bm          = isset($_GET['before_bm'])? intval($_GET['before_bm']):0;
    $is_everyday        = isset($_GET['is_everyday'])? intval($_GET['is_everyday']):0;
    $cj_times           = isset($_GET['cj_times'])? intval($_GET['cj_times']):0;
    $zj_times           = isset($_GET['zj_times'])? intval($_GET['zj_times']):0;
    $guize              = isset($_GET['guize'])? addslashes($_GET['guize']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    $share_title        = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc         = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $mp3_link           = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = str_replace("T", " ", $start_time);
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = str_replace("T", " ", $end_time);
    $end_time           = strtotime($end_time);
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = str_replace("T", " ", $hexiao_time);
    $hexiao_time        = strtotime($hexiao_time);
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $updateData = array();
    $updateData['title']              = $title;
    $updateData['is_answer']          = $is_answer;
    $updateData['answer_num']         = $answer_num;
    $updateData['open_score_pay']     = $open_score_pay;
    $updateData['pay_score']          = $pay_score;
    $updateData['before_bm']          = $before_bm;
    $updateData['is_everyday']        = $is_everyday;
    $updateData['cj_times']           = $cj_times;
    $updateData['zj_times']           = $zj_times;
    if($choujiangInfo['admin_edit'] == 0){
        $updateData['guize']          = dhtmlspecialchars($guize);
        $updateData['content']        = dhtmlspecialchars($content);
    }
    $updateData['picurl']             = $picurl;
    $updateData['toppic']             = $toppic;
    $updateData['share_title']        = $share_title;
    $updateData['share_desc']         = $share_desc;
    $updateData['start_time']         = $start_time;
    $updateData['end_time']           = $end_time;
    $updateData['hexiao_time']        = $hexiao_time;
    $updateData['mp3_link']           = $mp3_link;
    $updateData['add_time']           = TIMESTAMP;
    
    if(C::t('#tom_tcchoujiang#tom_tcchoujiang')->update($tcchoujiang_id,$updateData)){
        
        $choujiangInfoTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);
        update_chou_status($choujiangInfoTmp);
        
        C::t('#tom_tcchoujiang#tom_tcchoujiang_photo')->delete_by_tcchoujiang_id($tcchoujiang_id);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['tcchoujiang_id'] = $tcchoujiang_id;
                $insertData['picurl']         = $value;
                $insertData['add_time']       = TIMESTAMP;
                C::t('#tom_tcchoujiang#tom_tcchoujiang_photo')->insert($insertData);
            }
        }
        
        echo 200;exit;
        
    }else{
        echo 404;exit;
    }
}

if(!preg_match('/^http/', $choujiangInfo['picurl']) ){
    if(strpos($choujiangInfo['picurl'], 'source/plugin/tom_tcchoujiang/') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$choujiangInfo['picurl'];
    }else{
        $picurl = $choujiangInfo['picurl'];
    }
}else{
    $picurl = $choujiangInfo['picurl'];
}
if(!preg_match('/^http/', $choujiangInfo['toppic']) ){
    if(strpos($choujiangInfo['toppic'], 'source/plugin/tom_tcchoujiang/') === FALSE){
        $toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$choujiangInfo['toppic'];
    }else{
        $toppic = $choujiangInfo['toppic'];
    }
}else{
    $toppic = $choujiangInfo['toppic'];
}

$choujiangPhotoListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_photo')->fetch_all_list(" AND tcchoujiang_id={$tcchoujiang_id} "," ORDER BY id ASC ",0,50);
$choujiangPhotoList = array();
$photoCount = 0;
if(is_array($choujiangPhotoListTmp) && !empty($choujiangPhotoListTmp)){
    foreach ($choujiangPhotoListTmp as $kk => $vv){
        $photoCount++;
        if(!preg_match('/^http/', $vv['picurl']) ){
            if(strpos($choujiangInfo['toppic'], 'source/plugin/tom_tcchoujiang/') === FALSE){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
            }else{
                $picurlTmp = $vv['picurl'];
            }
        }else{
            $picurlTmp = $vv['picurl'];
        }
        $choujiangPhotoList[$kk]['picurl'] = $vv['picurl'];
        $choujiangPhotoList[$kk]['src'] = $picurlTmp;
        $choujiangPhotoList[$kk]['li_i'] = $photoCount;
    }
}

$start_time   = dgmdate($choujiangInfo['start_time'],'Y-m-d H:i:s',$tomSysOffset);
$start_time   = str_replace(" ", "T", $start_time);
$end_time     = dgmdate($choujiangInfo['end_time'],'Y-m-d H:i:s',$tomSysOffset);
$end_time     = str_replace(" ", "T", $end_time);
$hexiao_time  = dgmdate($choujiangInfo['hexiao_time'],'Y-m-d H:i:s',$tomSysOffset);
$hexiao_time  = str_replace(" ", "T", $hexiao_time);

$saveUrl      = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=edit&act=save";
$uploadUrl1   = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2   = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=upload&act=toppic&formhash=".FORMHASH;
$uploadUrl3   = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcchoujiang:edit");