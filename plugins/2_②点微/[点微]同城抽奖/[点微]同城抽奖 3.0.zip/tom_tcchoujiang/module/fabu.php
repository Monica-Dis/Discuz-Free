<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):0;
    $is_answer          = isset($_GET['is_answer'])? intval($_GET['is_answer']):0;
    $answer_num         = isset($_GET['answer_num'])? intval($_GET['answer_num']):0;
    $open_score_pay     = isset($_GET['open_score_pay'])? intval($_GET['open_score_pay']):0;
    $pay_score          = isset($_GET['pay_score'])? intval($_GET['pay_score']):0;
    $before_bm          = isset($_GET['before_bm'])? intval($_GET['before_bm']):0;
    $is_everyday        = isset($_GET['is_everyday'])? intval($_GET['is_everyday']):0;
    $cj_times           = isset($_GET['cj_times'])? intval($_GET['cj_times']):0;
    $zj_times           = isset($_GET['zj_times'])? intval($_GET['zj_times']):0;
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = str_replace("T", " ", $start_time);
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = str_replace("T", " ", $end_time);
    $end_time           = strtotime($end_time);
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = str_replace("T", " ", $hexiao_time);
    $hexiao_time        = strtotime($hexiao_time);
    $mp3_link           = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $guize              = isset($_GET['guize'])? addslashes($_GET['guize']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    $share_title        = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc         = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $insertData = array();
    $insertData['site_id']            = $tcshopInfo['site_id'];
    $insertData['type']               = 2;
    $insertData['user_id']            = $user_id;
    $insertData['tcshop_id']          = $tcshop_id;
    $insertData['title']              = $title;
    $insertData['is_answer']          = $is_answer;
    $insertData['answer_num']         = $answer_num;
    $insertData['open_score_pay']     = $open_score_pay;
    $insertData['pay_score']          = $pay_score;
    $insertData['before_bm']          = $before_bm;
    $insertData['is_everyday']        = $is_everyday;
    $insertData['cj_times']           = $cj_times;
    $insertData['zj_times']           = $zj_times;
    $insertData['start_time']         = $start_time;
    $insertData['end_time']           = $end_time;
    $insertData['hexiao_time']        = $hexiao_time;
    $insertData['mp3_link']           = $mp3_link;
    $insertData['guize']              = $guize;
    $insertData['content']            = $content;
    $insertData['picurl']             = $picurl;
    $insertData['toppic']             = $toppic;
    $insertData['share_title']        = $share_title;
    $insertData['share_desc']         = $share_desc;
    $insertData['status']             = 1;
    if($tcchoujiangConfig['must_shenhe'] == 1){
        $insertData['shenhe_status']  = 2;
    }else{
        $insertData['shenhe_status']  = 1;
    }
    $insertData['add_time']           = TIMESTAMP;
    if(C::t('#tom_tcchoujiang#tom_tcchoujiang')->insert($insertData)){
        
        $tcchoujiang_id = C::t('#tom_tcchoujiang#tom_tcchoujiang')->insert_id();
        
        $choujiangInfoTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);
        update_chou_status($choujiangInfoTmp);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['tcchoujiang_id']  = $tcchoujiang_id;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcchoujiang#tom_tcchoujiang_photo')->insert($insertData);
            }
        }
        
        
        if($tcchoujiangConfig['must_shenhe'] == 1){
            
            $choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);
            if($choujiangInfo['site_id'] == 1){
                $sitename = $tongchengConfig['plugin_name'];
            }else{
                $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($choujiangInfo['site_id']);
                $sitename = $siteInfo['name'];
            }
            
            $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);

            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();

            if($access_token && !empty($toUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => '['.$tcshopInfo['name'].']'.lang('plugin/tom_tcchoujiang','shenhe_template_first'),
                    'keyword1'      => $sitename,
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }
        }
        
        echo 200; exit;
        
    }else{
        echo 404; exit;
    }
}

$allTcshopCount = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count(" AND user_id={$__UserInfo['id']} ");

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$__UserInfo['id']} AND v.open_tcchoujiang=1 "," ORDER BY s.id DESC ",0,100);
$tcshopList = array();
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach ($tcshopListTmp as $key => $value){
        $tcshopList[$key] = $value;
    }
}
$tcshopCount = count($tcshopList);

$saveUrl    = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=fabu&act=save";
$myListUrl  = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=myfabu";
$uploadUrl1 = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2 = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=upload&act=toppic&formhash=".FORMHASH;
$uploadUrl3 = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcchoujiang:fabu");