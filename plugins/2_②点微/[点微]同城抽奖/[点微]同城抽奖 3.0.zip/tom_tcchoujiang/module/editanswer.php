<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcchoujiang_id   = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):0;

$choujiangInfo    = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);
$tcshopInfo       = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($choujiangInfo['tcshop_id']);

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcchoujing&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $answer_id    = intval($_GET['answer_id'])>0? intval($_GET['answer_id']): 0;
    $title        = isset($_GET['title'])? addslashes($_GET['title']):"";
    $ok_answer    = isset($_GET['ok_answer'])? addslashes($_GET['ok_answer']):"";
    $no_answer1   = isset($_GET['no_answer1'])? addslashes($_GET['no_answer1']):"";
    $no_answer2   = isset($_GET['no_answer2'])? addslashes($_GET['no_answer2']):"";
    $asort        = isset($_GET['asort'])? intval($_GET['asort']):10;
    
    $updateData = array();
    $updateData['tcchoujiang_id']   = $tcchoujiang_id;
    $updateData['title']            = $title;
    $updateData['ok_answer']        = $ok_answer;
    $updateData['no_answer1']       = $no_answer1;
    $updateData['no_answer2']       = $no_answer2;
    $updateData['asort']            = $asort;
    $updateData['add_time']         = TIMESTAMP;
    C::t('#tom_tcchoujiang#tom_tcchoujiang_answer')->update($answer_id,$updateData);
    
    echo 200;exit;

}else if($_GET['act'] == 'add_answer' && $_GET['formhash'] == FORMHASH){
    $outStr = '';
    
    $insertData = array();
    $insertData['tcchoujiang_id'] = $tcchoujiang_id;
    
    C::t("#tom_tcchoujiang#tom_tcchoujiang_answer")->insert($insertData);
    $answer_id = C::t("#tom_tcchoujiang#tom_tcchoujiang_answer")->insert_id();
    
    $outStr = $answer_id;
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;
    
}else if($_GET['act'] == 'remove_answer' && $_GET['formhash'] == FORMHASH){
    
    $answer_id = intval($_GET['answer_id'])>0? intval($_GET['answer_id']): 0;
    
    C::t("#tom_tcchoujiang#tom_tcchoujiang_answer")->delete_by_id($answer_id);
    
    echo 1;exit;
}

$answerList = C::t('#tom_tcchoujiang#tom_tcchoujiang_answer')->fetch_all_list(" AND tcchoujiang_id = {$tcchoujiang_id} ","ORDER BY asort ASC,id DESC",0,50);

$saveUrl      = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=editanswer&tcchoujiang_id={$tcchoujiang_id}&act=save&formhash={$formhash}";
$addAnswerUrl = "plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=editanswer&act=add_answer&tcchoujiang_id={$tcchoujiang_id}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcchoujiang:editanswer");