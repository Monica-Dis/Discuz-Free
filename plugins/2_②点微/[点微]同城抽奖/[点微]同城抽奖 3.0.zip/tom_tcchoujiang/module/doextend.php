<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

$extendInfo  = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_extend')->fetch_by_id($prizeInfo['extend_id']);

if($extendInfo['type_id'] == 1){
    
    DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET score = score + {$extendInfo['score_value']} WHERE id='{$user_id}' ", 'UNBUFFERED');
    
    $insertData = array();
    $insertData['user_id']          = $user_id;
    $insertData['score_value']      = $extendInfo['score_value'];
    $insertData['old_value']        = $userInfo['score'];
    $insertData['log_type']         = 26;        
    $insertData['log_time']         = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
}else if($extendInfo['type_id'] == 2){
    
    $cardInfo     = C::t("#tom_tcyikatong#tom_tcyikatong_card")->fetch_by_user_id($user_id);
    $cardTypeInfo = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($extendInfo['card_type_id']);
    
    $oldCardTypeInfo = array();
    if(is_array($cardInfo) && !empty($cardInfo) && $cardInfo['id'] > 0){
        $cardId = $cardInfo['id'];
        $oldCardTypeInfo = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($cardInfo['card_type_id']);
    }else{
        $auto_id = 0;
        $autoidTmp  = C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->fetch_all_list(""," ORDER BY id DESC ",0,1);
        if(is_array($autoidTmp) && !empty($autoidTmp) && !empty($autoidTmp[0]['id'])){
            if($autoidTmp[0]['id'] > 999990 && $autoidTmp[0]['id'] < 10101000 ){
                $insertData = array();
                $insertData['id']               = 10101011;
                $insertData['add_time']         = TIMESTAMP;
                if(C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert($insertData)){
                    $auto_id = C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert_id();
                }
            }else{
                $insertData = array();
                $insertData['add_time']         = TIMESTAMP;
                if(C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert($insertData)){
                    $auto_id = C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert_id();
                }
            }
        }else{
            $insertData = array();
            $insertData['id']               = 101011;
            $insertData['add_time']         = TIMESTAMP;
            if(C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert($insertData)){
                $auto_id = C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert_id();
            }
        }

        $card_no = '';
        $auto_id_str = strval($auto_id);
        if($auto_id > 10101000){
            $rand_num1 = mt_rand(1, 9);
            $card_no .= $auto_id_str[0].$auto_id_str[1].$rand_num1;
            $rand_num2 = mt_rand(1, 9);
            $card_no .= $auto_id_str[2].$auto_id_str[3].$rand_num2;
            $rand_num3 = mt_rand(1, 9);
            $card_no .= $auto_id_str[4].$auto_id_str[5].$rand_num3;
            $rand_num4 = mt_rand(1, 9);
            $card_no .= $auto_id_str[6].$auto_id_str[7].$rand_num4;
        }else{
            $rand_num1 = mt_rand(1, 9);
            $card_no .= $auto_id_str[0].$auto_id_str[1].$rand_num1;
            $rand_num2 = mt_rand(1, 9);
            $card_no .= $auto_id_str[2].$auto_id_str[3].$rand_num2;
            $rand_num3 = mt_rand(1, 9);
            $card_no .= $auto_id_str[4].$auto_id_str[5].$rand_num3;
        }
        $insertData = array();
        $insertData['user_id']          = $user_id;
        $insertData['card_no']          = $card_no;
        $insertData['expire_time']      = 0;
        $insertData['status']           = 0;
        $insertData['add_time']         = TIMESTAMP;
        if(C::t('#tom_tcyikatong#tom_tcyikatong_card')->insert($insertData)){
            $cardId = C::t('#tom_tcyikatong#tom_tcyikatong_card')->insert_id();
        }
    }

    $updateData = array();
    if($cardInfo['expire_time'] > TIMESTAMP){
        if($cardTypeInfo['days'] > $oldCardTypeInfo['days']){
            $updateData['card_type_id']       = $cardTypeInfo['id'];
        }
        $updateData['expire_time']    = $cardInfo['expire_time'] + intval($cardTypeInfo['days'])*86400;
    }else{
        $updateData['card_type_id']   = $cardTypeInfo['id'];
        $updateData['expire_time']    = TIMESTAMP + intval($cardTypeInfo['days'])*86400;
    }
    $updateData['status']             = 1;
    C::t('#tom_tcyikatong#tom_tcyikatong_card')->update($cardId,$updateData);
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['card_id']          = $cardId;
    $insertData['user_id']          = $user_id;
    $insertData['card_type_id']     = $cardTypeInfo['id'];
    $insertData['card_type_name']   = $cardTypeInfo['name'];
    $insertData['card_type_days']   = $cardTypeInfo['days'];
    $insertData['log_type']         = 3;
    $insertData['add_time']         = TIMESTAMP;
    C::t('#tom_tcyikatong#tom_tcyikatong_card_log')->insert($insertData);
    
}else if($extendInfo['type_id'] == 3){
    
    $goodsInfo  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($extendInfo['coupon_id']);
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
    
    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
 
    $auto_id = 0;
    $autoidTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->fetch_all_list(""," ORDER BY id DESC ",0,1);
    if(is_array($autoidTmp) && !empty($autoidTmp) && !empty($autoidTmp[0]['id'])){
        if($autoidTmp[0]['id'] > 999990 && $autoidTmp[0]['id'] < 10101000 ){
            $insertData = array();
            $insertData['id']               = 10101011;
            $insertData['add_time']         = TIMESTAMP;
            if(C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert($insertData)){
                $auto_id = C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert_id();
            }
        }else{
            $insertData = array();
            $insertData['add_time']         = TIMESTAMP;
            if(C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert($insertData)){
                $auto_id = C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert_id();
            }
        }
    }else{
        $insertData = array();
        $insertData['id']               = 101011;
        $insertData['add_time']         = TIMESTAMP;
        if(C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert($insertData)){
            $auto_id = C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert_id();
        }
    }
    
    $hexiao_code = '';
    $auto_id_str = strval($auto_id);
    if($auto_id > 10101000){
        $rand_num1 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[0].$auto_id_str[1].$rand_num1;
        $rand_num2 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[2].$auto_id_str[3].$rand_num2;
        $rand_num3 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[4].$auto_id_str[5].$rand_num3;
        $rand_num4 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[6].$auto_id_str[7].$rand_num4;
    }else{
        $rand_num1 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[0].$auto_id_str[1].$rand_num1;
        $rand_num2 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[2].$auto_id_str[3].$rand_num2;
        $rand_num3 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[4].$auto_id_str[5].$rand_num3;
    }
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['tcshop_id']        = $tcshopInfo['id'];
    $insertData['order_no']         = $order_no;
    $insertData['hexiao_code']      = $hexiao_code;
    $insertData['type_id']          = $goodsInfo['type_id'];
    $insertData['goods_id']         = $goodsInfo['id'];
    $insertData['goods_title']      = $goodsInfo['title'];
    $insertData['goods_num']        = 1;
    $insertData['user_id']          = $user_id;
    $insertData['xm']               = $bmInfo['xm'];
    $insertData['tel']              = $bmInfo['tel'];
    $insertData['address']          = '';
    $insertData['order_status']     = 2;
    $insertData['order_time']       = TIMESTAMP;
    C::t('#tom_tcqianggou#tom_tcqianggou_order')->insert($insertData);
    
    DB::query("UPDATE ".DB::table('tom_tcqianggou_goods')." SET sale_num=sale_num + 1 WHERE id='{$goodsInfo['id']}' ", 'UNBUFFERED');
    
}else if($extendInfo['type_id'] == 4){
    
    $tcmallCouponInfo = C::t("#tom_tcmall#tom_tcmall_coupon")->fetch_by_id($extendInfo['tcmall_coupon_id']);
    if(!empty($tcmallCouponInfo) && $tcmallCouponInfo['id'] > 0 && $tcmallCouponInfo['status'] == 1 && $tcmallCouponInfo['lingqu_num'] < $tcmallCouponInfo['total_num']){
        $insertData = array();
        $insertData['user_id']      = $user_id;
        $insertData['coupon_id']    = $tcmallCouponInfo['id'];
        $insertData['tcshop_id']    = $tcmallCouponInfo['tcshop_id'];
        $insertData['status']       = 0;
        $insertData['add_time']     = TIMESTAMP;
        if(C::t("#tom_tcmall#tom_tcmall_coupon_lingqu")->insert($insertData)){
            DB::query("UPDATE ".DB::table('tom_tcmall_coupon')." SET lingqu_num = lingqu_num + 1 WHERE id='{$tcmallCouponInfo['id']}'", 'UNBUFFERED');
        }
    }
    
}else if($extendInfo['type_id'] == 5){
    
    $zhaopinVip = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($extendInfo['tczhaopin_vip_id']);
    
    if(!empty($zhaopinVip) && $zhaopinVip['id'] > 0){
        $zhaopinUserVipInfo = C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->fetch_by_user_id($user_id);
        if(!empty($zhaopinUserVipInfo) && $zhaopinUserVipInfo['id'] > 0){
            if($zhaopinUserVipInfo['expire_status'] == 1 && $zhaopinUserVipInfo['expire_time'] > TIMESTAMP){
                $oldZhaopinVip = C::t("#tom_tczhaopin#tom_tczhaopin_vip")->fetch_by_id($zhaopinUserVipInfo['vip_id']);
                $updateData = array();
                if($zhaopinVip['days'] > $oldZhaopinVip['days']){
                    $updateData['vip_id']       = $zhaopinVip['id'];
                }
                $updateData['expire_time']      = $zhaopinUserVipInfo['expire_time'] + $zhaopinVip['days'] * 86400;
                $updateData['expire_status']    = 1;
                C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->update($zhaopinUserVipInfo['id'], $updateData);
            }else{
                $updateData = array();
                $updateData['vip_id']           = $zhaopinVip['id'];
                $updateData['expire_time']      = $zhaopinVip['days'] * 86400 + TIMESTAMP;
                $updateData['expire_status']    = 1;
                C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->update($zhaopinUserVipInfo['id'], $updateData);
            }
            C::t("#tom_tczhaopin#tom_tczhaopin_log")->delete_vip_look_resume_by_user_id($user_id);
        }else{
            $insertData = array();
            $insertData['user_id']          = $user_id;
            $insertData['vip_id']           = $zhaopinVip['id'];
            $insertData['expire_time']      = $zhaopinVip['days'] * 86400 + TIMESTAMP;
            $insertData['expire_status']    = 1;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tczhaopin#tom_tczhaopin_user_vip")->insert($insertData);
        }
    }
    
}

$updateData = array();
$updateData['order_status']    = 3;
$updateData['hexiao_user_id']  = $user_id;
$updateData['hexiao_time']     = TIMESTAMP;
C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->update($order_id,$updateData);