<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outArr = array(
    'status'=> 1,
    'prize' => 6,
);

$tcchoujiang_id = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):'';
$user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):'';

$choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);
$userInfo      = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
$bmInfo        = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($tcchoujiang_id,$user_id);

if(!empty($choujiangInfo) && $choujiangInfo['id'] > 0){
}else{
    echo json_encode($outArr); exit;
}
if($userInfo['status'] != 1){
    $outArr['status'] = 301;
    echo json_encode($outArr); exit;
}
if($choujiangInfo['type'] == 1 || $choujiangInfo['type'] == 2){
    if($choujiangInfo['chou_status'] == 3){
        $outArr['status'] = 302;
        echo json_encode($outArr); exit;
    }
    if($choujiangInfo['chou_status'] == 2){
        $outArr['status'] = 303;
        echo json_encode($outArr); exit;
    }
}
$myorderCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_count(" AND tcchoujiang_id = {$tcchoujiang_id} AND user_id = {$__UserInfo['id']} ");
if($myorderCount >= $choujiangInfo['zj_times']){
    $outArr['status'] = 305;
    echo json_encode($outArr); exit;
}
if($bmInfo['cj_times'] <= 0){
    if($choujiangInfo['is_everyday'] == 1){
        $outArr['status'] = 308;
    }else{
        $outArr['status'] = 306;
    }
    echo json_encode($outArr); exit;
}
if($tcchoujiangConfig['allow_score_pay'] == 1 && $choujiangInfo['open_score_pay'] == 1 && $choujiangInfo['pay_score'] > 0){
    if($userInfo['score'] < $choujiangInfo['pay_score'] ){
        $outArr['status'] = 307;
        echo json_encode($outArr); exit;
    }
}

$prizeList = array();
for($i=1;$i<=5;$i++){
    $prizeList[$i] = array(
        'type'      => '',
        'name'      => '',
        'num'       => 0,
        'picurl'    => '',
        'chance'    => 0,
    );
}
$prizeListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_list(" AND tcchoujiang_id = {$tcchoujiang_id} ","ORDER BY type ASC,id DESC",0,50);
if(is_array($prizeListTmp) && !empty($prizeListTmp)){
    foreach ($prizeListTmp as $key => $value) {
        if(isset($prizeList[$value['type']])){
            $prizeList[$value['type']] = $value;
            if(!preg_match('/^http:/',$prizeList[$value['type']]['picurl']) && !empty($prizeList[$value['type']]['picurl']) ){
                if(strpos($prizeList[$value['type']]['picurl'], 'source/plugin/tom_tcchoujiang/') === FALSE){
                    $prizeList[$value['type']]['picurl'] = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$prizeList[$value['type']]['picurl'];
                }else{
                    $prizeList[$value['type']]['picurl'] = $prizeList[$value['type']]['picurl'];
                }
            }else{
                $prizeList[$value['type']]['picurl'] = $prizeList[$value['type']]['picurl'];
            }
        }
    }
}

$prizeArr = array();
foreach ($prizeList as $key => $value){
    if($value['chance'] > 0 && $value['num']>0 ){
        $prizeArr[$key] = $value['chance'];
    }
}

$prizeArr[6] = 10000 - array_sum($prizeArr);
if($prizeArr[6] < 0){
    $prizeArr[6] = 0;
}
$randPrize = get_rand($prizeArr);
$templateStatus = 0;
if($randPrize <=6 && $randPrize>=1){ 
    if($prizeList[$randPrize]['id']  && $prizeList[$randPrize]['num'] > 0  && $prizeList[$randPrize]['chance'] > 0){

        $templateStatus = 1;
        $prizeInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_by_id($prizeList[$randPrize]['id']);

        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        $hexiao_no  = date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']         = $choujiangInfo['site_id'];
        if($choujiangInfo['type'] == 2){
            $insertData['tcshop_id']   = $choujiangInfo['tcshop_id'];
        }else{
            $insertData['tcshop_id']   = $prizeInfo['tcshop_id'];
        }
        $insertData['tcchoujiang_id']  = $tcchoujiang_id;
        $insertData['user_id']         = $user_id;
        $insertData['hexiao_no']       = $hexiao_no;
        $insertData['order_no']        = $order_no;
        $insertData['prize_id']        = $prizeInfo['id'];
        $insertData['prize_name']      = $prizeInfo['name'];
        $insertData['xm']              = $bmInfo['xm'];
        $insertData['tel']             = $bmInfo['tel'];
        $insertData['order_status']    = 1;
        $insertData['peisong_type']    = $prizeInfo['peisong_type'];
        $insertData['order_time']      = TIMESTAMP;
        C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->insert($insertData);
        $order_id = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->insert_id();

        DB::query("UPDATE ".DB::table('tom_tcchoujiang_prize')." SET num=num - 1 WHERE id='{$prizeInfo['id']}' ", 'UNBUFFERED');

        if($prizeInfo['is_extend'] == 1){
            include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/module/doextend.php';
        }

    }else{
        $randPrize = 6;
    }
    
    $insertData = array();
    $insertData['tcchoujiang_id']  = $tcchoujiang_id;
    $insertData['type_id']         = 1;
    $insertData['user_id']         = $user_id;
    $insertData['change_num']      = 1;
    $insertData['log_time']        = TIMESTAMP;
    $insertData['beizu']           = '';
    $insertData['time_key']        = $nowDayTime;
    C::t('#tom_tcchoujiang#tom_tcchoujiang_log')->insert($insertData);

    DB::query("UPDATE ".DB::table('tom_tcchoujiang_bm')." SET cj_times=cj_times - 1 WHERE id='{$bmInfo['id']}' ", 'UNBUFFERED');
    
    if($tcchoujiangConfig['allow_score_pay'] == 1 && $choujiangInfo['open_score_pay'] == 1  && $choujiangInfo['pay_score'] > 0){

        DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET score = score - {$choujiangInfo['pay_score']} WHERE id='{$user_id}' ", 'UNBUFFERED');

        $insertData = array();
        $insertData['user_id']          = $user_id;
        $insertData['score_value']      = $choujiangInfo['pay_score'];
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 27;        
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    }

    $outArr = array(
        'status'    => 200,
        'prize'     => $randPrize,
    );
}

if($templateStatus == 1){
    $orderInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_by_id($order_id);
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);

    if($choujiangInfo['site_id'] == 1){
        $sitename = $tongchengConfig['plugin_name'];
    }else{
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($choujiangInfo['site_id']);
        $sitename = $siteInfo['name'];
    }

    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfo['user_id']);

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();

    if($access_token && !empty($toUser['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcchoujiang&site={$site_id}&mod=myorder");
        $smsData = array(
            'first'         => '['.$tcshopInfo['name'].']'.lang('plugin/tom_tcchoujiang','template_neworder_first'),
            'keyword1'      => $sitename,
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
    }
}

echo json_encode($outArr); exit;