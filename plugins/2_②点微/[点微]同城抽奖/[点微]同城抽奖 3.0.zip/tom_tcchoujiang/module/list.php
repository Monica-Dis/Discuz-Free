<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$chou_status   = intval($_GET['chou_status'])>0? intval($_GET['chou_status']):0;
$page          = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize      = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):6;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND type IN(1,2) AND status = 1 AND shenhe_status = 1 ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($chou_status)){
    $whereStr.= " AND chou_status={$chou_status} ";
}

$orderStr          = " ORDER BY chou_status ASC,paixu ASC,id DESC";

$pagesize      = $pagesize;
$start         = ($page - 1)*$pagesize;

$choujiangData = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);
$choujiangList = array();
if(is_array($choujiangData) && !empty($choujiangData)){
    foreach($choujiangData as $key => $value){
        $choujiangList[$key] = $value;
        $choujiangList[$key]['start_time'] = dgmdate($value['start_time'], 'Y.m.d',$tomSysOffset);
        $choujiangList[$key]['end_time']   = dgmdate($value['end_time'], 'Y.m.d',$tomSysOffset);
        if(!preg_match('/^http/', $value['picurl'])){
            if(strpos($value['picurl'], 'source/plugin/') === false){
                $choujiangList[$key]['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $choujiangList[$key]['picurl'] = $value['picurl'];
            }
        }else{
            $choujiangList[$key]['picurl'] = $value['picurl'];
        }
        $choujiangList[$key]['count'] = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_all_count(" AND tcchoujiang_id = {$value['id']} ");
        $bmData = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_all_list(" AND tcchoujiang_id = {$value['id']} ","ORDER BY add_time DESC,id DESC",0,5);
        $cjBmList = array();
        if(is_array($bmData) && !empty($bmData)){
            foreach($bmData as $k => $v){
                $cjBmList[$k] = $v;
                $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id("{$v['user_id']}");
                $cjBmList[$k]['userInfo'] = $userInfoTmp;
            }
        }
        $choujiangList[$key]['cjBmList']    = $cjBmList;
        $choujiangList[$key]['clicks']      = $value['clicks'] + $value['virtual_clicks'];
        $choujiangList[$key]['count']       = $choujiangList[$key]['count'] + $value['virtual_bmnum'];
        update_chou_status($value);
    }
}
if(is_array($choujiangList) && !empty($choujiangList)){
    foreach ($choujiangList as $key => $value){
        if($tcchoujiangConfig['index_list_type'] == 1){
            $outStr.= '<div class="item clearfix">';
                $outStr.= '<a href="plugin.php?id=tom_tcchoujiang&site='.$site_id.'&mod=details&cjid='.$value['id'].'">';
                $outStr.= '<div class="pic">';
                        $outStr .= '<img src="'.$value['picurl'].'">';
                $outStr.= '</div>';
                $outStr.= '<div class="content">';
                    $outStr.= '<div class="title">'.$value['title'].'</div>';
                    $outStr.= '<div class="cjcounts">';
                        $outStr .= ''.lang('plugin/tom_tcchoujiang','index_clicks').'<span>'.$value['clicks'].'</span>&nbsp;/&nbsp;'.lang('plugin/tom_tcchoujiang','index_yicanyu').'<span>'.$value['count'].'</span>'.lang('plugin/tom_tcchoujiang','index_ren').'';
                    $outStr.= '</div>';
                    $outStr .= '<div class="cjreceive clearfix">';
                        $outStr .= '<div class="cjreceive_left clearfix">';
                        foreach ($value['cjBmList'] as $k => $v){
                            $outStr .= '<img src="'.$v['userInfo']['picurl'].'"/>';
                        }
                            if($value['count'] >= 5){
                                $outStr .= '<img src="source/plugin/tom_tcchoujiang/images/shenglve.png"/>';
                            }
                            $outStr .= '</div>';
                            if ($value['chou_status'] == 1){
                                $outStr .= '<div class="cjreceive_right start">';
                            }else{
                                $outStr .= '<div class="cjreceive_right">';
                            }
                            if ($value['chou_status'] == 2){
                                $outStr .= '<span>'.lang('plugin/tom_tcchoujiang','index_nostart_button').'</span>';
                            }else if($value['chou_status'] == 3){
                                $outStr .= '<span>'.lang('plugin/tom_tcchoujiang','index_end_button').'</span>';
                            }else{
                                $outStr .= '<span>'.lang('plugin/tom_tcchoujiang','index_cj_button').'</span>';
                            }
                        $outStr .= '</div>';
                    $outStr .= '</div>';
                $outStr.= '</div>';
                $outStr.= '</a>';
            $outStr.= '</div>';
        }else if($tcchoujiangConfig['index_list_type'] == 2){
            $outStr .= '<div class="cjmain">';
                $outStr .= '<a href="plugin.php?id=tom_tcchoujiang&site='.$site_id.'&mod=details&cjid='.$value['id'].'">';
                $outStr .= '<div class="cjimg">';
                        $outStr .= '<img src="'.$value['picurl'].'">';
                $outStr .= '</div>';
                $outStr .= '<div class="cjtitle">'.$value['title'].'</div>';
                $outStr .= '<div class="cjreceive">';
                    $outStr .= '<div class="cjreceive_middle">';
                    foreach ($value['cjBmList'] as $k => $v){
                        $outStr .= '<img src="'.$v['userInfo']['picurl'].'"/>';
                    }
                        if($value['count'] >= 5){
                            $outStr .= '<img src="source/plugin/tom_tcchoujiang/images/shenglve.png"/>';
                        }
                        $outStr .= '</div>';
                        if ($value['chou_status'] == 1){
                            $outStr .= '<div class="cjreceive_right start">';
                        }else{
                            $outStr .= '<div class="cjreceive_right">';
                        }
                        if ($value['chou_status'] == 2){
                            $outStr .= '<span>'.lang('plugin/tom_tcchoujiang','index_nostart_button').'</span>';
                        }else if($value['chou_status'] == 3){
                            $outStr .= '<span>'.lang('plugin/tom_tcchoujiang','index_end_button').'</span>';
                        }else{
                            $outStr .= '<span>'.lang('plugin/tom_tcchoujiang','index_cj_button').'</span>';
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
                $outStr .= '</a>';
            $outStr .= '</div>';
        }
    }
}else{
    $outStr = '205';
}
$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;