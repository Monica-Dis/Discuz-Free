<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcchoujiang'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcchoujiang&pmod=admin'; 
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcchoujiang&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcchoujiang&pmod=admin';
$tomSysOffset = getglobal('setting/timeoffset');

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/config/config.utf8.php';
}

include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/class/function.a.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/class/function.core.php';

$tcchoujiangConfig = get_tcchoujiang_config($pluginid);
$tongchengPlugin = C::t('#tom_tcshop#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$Lang = formatLang($Lang);

if($_GET['tmod'] == 'index'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/admin/index.php';
}else if($_GET['tmod'] == 'prize'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/admin/prize.php';
}else if($_GET['tmod'] == 'answer'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/admin/answer.php';
}else if($_GET['tmod'] == 'bm'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/admin/bm.php';
}else if($_GET['tmod'] == 'prizelog'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/admin/prizelog.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/admin/focuspic.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/admin/order.php';
}else if($_GET['tmod'] == 'doDao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/admin/doDao.php';
}else if($_GET['tmod'] == 'extend'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/admin/extend.php';
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/admin/addon.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/admin/index.php';
}