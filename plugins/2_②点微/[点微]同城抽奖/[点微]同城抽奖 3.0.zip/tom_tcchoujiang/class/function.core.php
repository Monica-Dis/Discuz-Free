<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


function wx_iconv_recurrence($value) {
    if(is_array($value)) {
        foreach($value AS $key => $val) {
            $value[$key] = wx_iconv_recurrence($val);
        }
    } else {
        $value = diconv($value, 'utf-8', CHARSET);
    }
    return $value;
}

function number_float($number=0.00 , $num=2){
    if($number > 0){
        $number = floatval(number_format($number, $num, '.' ,''));
    }
    return $number;
}
 
function update_chou_status($choujiangInfo = array()){
    
    $chou_status = 1;
    
    if(TIMESTAMP < $choujiangInfo['start_time']){
        $chou_status = 2;
    }

    if(TIMESTAMP > $choujiangInfo['end_time']){
        $chou_status = 3;
    }

    if($chou_status != $choujiangInfo['chou_status']){
        $updateData  = array();
        $updateData['chou_status']  = $chou_status;
        C::t('#tom_tcchoujiang#tom_tcchoujiang')->update($choujiangInfo['id'],$updateData);
    }
    
    return $chou_status;
}

function get_rand($dataArr){ 
    $result = ''; 
    $dataSum = array_sum($dataArr); 
    $randNum = mt_rand(1, 10000); 
    foreach ($dataArr as $key => $dataCur) { 
        $nextSum = $dataSum - $dataCur;
        if($nextSum < $randNum && $randNum <= $dataSum) { 
            $result = $key; 
            break; 
        }
        $dataSum -= $dataCur;                     
    }
    unset ($dataArr); 
    return $result; 
}

function check_region(){
    global $_G;
    
    $tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
    
    # PC start
    if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false){
        if(!empty($tcchoujiangConfig['region_jump_link'])){
            dheader('location:'.$tcchoujiangConfig['region_jump_link']);exit;
        }else{
            dheader('location:'.$_G['siteurl'].'404.php');exit;
        }
    }
    # PC end
    
    $host       = "https://api01.aliyun.venuscn.com";
    $path       = "/ip";
    $appcode    = trim($tcchoujiangConfig['region_appcode']);
    $headers    = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys     = "ip=".$_G['clientip'];
    $bodys      = "";
    $url        = $host . $path . "?" . $querys;
    
    $start_time = time();
    
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    $return = curl_exec($curl);
    $content = json_decode($return,true);
    $content = wx_iconv_recurrence($content);
    
    $end_time = time();
    
    if($tcchoujiangConfig['region_debug'] == 1){
        echo $start_time.'--'.$end_time.'<hr>';
        print_r($content);exit;
    }
    
    $ip_region = '';
    if(is_array($content) && !empty($content) && $content['msg'] == 'success' && is_array($content['data']) && !empty($content['data'])){
        
        $ip_region = $content['data']['region'].' '.$content['data']['city'];
        
        $region_list = preg_quote(trim($tcchoujiangConfig['region_list']), '/');
        $region_list = str_replace(array("\\*"), array('.*'), $region_list);
        $region_list = '.*('.$region_list.').*';
        $region_list = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $region_list).')$/i';
        if(@preg_match($region_list, $ip_region,$matches)) {
            return true;
        }
    }
    
    if(!empty($tcchoujiangConfig['region_jump_link'])){
        dheader('location:'.$tcchoujiangConfig['region_jump_link']);exit;
    }else{
        dheader('location:'.$_G['siteurl'].'404.php');exit;
    }
    
    return false;
}