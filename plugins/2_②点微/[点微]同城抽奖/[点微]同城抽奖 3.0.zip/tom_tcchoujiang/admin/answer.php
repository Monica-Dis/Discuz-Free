<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=answer&tcchoujiang_id='.$_GET['tcchoujiang_id'];
$modListUrl = $adminListUrl.'&tmod=answer&tcchoujiang_id='.$_GET['tcchoujiang_id'];
$modFromUrl = $adminFromUrl.'&tmod=answer&tcchoujiang_id='.$_GET['tcchoujiang_id'];

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time']  = TIMESTAMP;
        C::t('#tom_tcchoujiang#tom_tcchoujiang_answer')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $answerInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_answer')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($answerInfo);
        $updateData['add_time'] = TIMESTAMP;
        C::t('#tom_tcchoujiang#tom_tcchoujiang_answer')->update($answerInfo['id'],$updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($answerInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcchoujiang#tom_tcchoujiang_answer')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $tcchoujiang_id = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):1;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize       = 1000;
    $start          = ($page - 1)*$pagesize;	
    $count          = C::t('#tom_tcchoujiang#tom_tcchoujiang_answer')->fetch_all_count("AND tcchoujiang_id={$tcchoujiang_id}");
    $answerList     = C::t('#tom_tcchoujiang#tom_tcchoujiang_answer')->fetch_all_list("AND tcchoujiang_id={$tcchoujiang_id}","ORDER BY asort ASC,id DESC",$start,$pagesize);
    
    __create_nav_html();
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['answer_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' .' ID '. '</th>';
    echo '<th>' . $Lang['answer_title'] . '</th>';
    echo '<th>' . $Lang['ok_answer'] . '</th>';
    echo '<th>' . $Lang['no_answer1'] . '</th>';
    echo '<th>' . $Lang['no_answer2'] . '</th>';
    echo '<th>' . $Lang['answer_asort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($answerList as $key => $value){
        $prizeList[$key] = $value;
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $value['title'] .'</td>';
        echo '<td>' . $value['ok_answer'] .'</td>';
        echo '<td>' . $value['no_answer1'] .'</td>';
        echo '<td>' . $value['no_answer2'] .'</td>';
        echo '<td>' . $value['asort'] .'</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['answer_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $title           = isset($_GET['title'])? addslashes($_GET['title']):'';
    $ok_answer       = isset($_GET['ok_answer'])? addslashes($_GET['ok_answer']):'';
    $no_answer1      = isset($_GET['no_answer1'])? addslashes($_GET['no_answer1']):'';
    $no_answer2      = isset($_GET['no_answer2'])? addslashes($_GET['no_answer2']):'';
    $asort           = isset($_GET['asort'])? intval($_GET['asort']):10;
    
    $data['tcchoujiang_id']     = $_GET['tcchoujiang_id'];
    $data['title']              = $title;
    $data['ok_answer']          = $ok_answer;
    $data['no_answer1']         = $no_answer1;
    $data['no_answer2']         = $no_answer2;
    $data['asort']              = $asort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'title'        => '',
        'ok_answer'    => '',
        'no_answer1'   => '',
        'no_answer2'   => '',
        'asort'        => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['answer_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['answer_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['ok_answer'],'name'=>'ok_answer','value'=>$options['ok_answer'],'msg'=>$Lang['ok_answer_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['no_answer1'],'name'=>'no_answer1','value'=>$options['no_answer1'],'msg'=>$Lang['no_answer1_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['no_answer2'],'name'=>'no_answer2','value'=>$options['no_answer2'],'msg'=>$Lang['no_answer2_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['answer_asort'],'name'=>'asort','value'=>$options['asort'],'msg'=>$Lang['answer_asort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['answer_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['answer_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['answer_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['answer_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['answer_edit'],"",true); 
    }else{
        tomshownavli($Lang['answer_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['answer_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}