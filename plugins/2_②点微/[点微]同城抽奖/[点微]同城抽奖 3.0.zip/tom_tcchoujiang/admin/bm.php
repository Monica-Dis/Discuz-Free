<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=bm&tcchoujiang_id='.$_GET['tcchoujiang_id'];
$modListUrl = $adminListUrl.'&tmod=bm&tcchoujiang_id='.$_GET['tcchoujiang_id'];
$modFromUrl = $adminFromUrl.'&tmod=bm&tcchoujiang_id='.$_GET['tcchoujiang_id'];

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editcj_times'){
    
    $info = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $cj_times = intval($_GET['cj_times'])>0?intval($_GET['cj_times']):0;
        $updateData = array();
        $updateData['cj_times'] = $cj_times;
        C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->update($info['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editcj_times&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['bm_cj_times'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['bm_cj_times'],'name'=>'cj_times','value'=>$info['cj_times'],'msg'=>''),"input");
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
}else if($_GET['act'] == 'cj_log'){
    
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):1;
    $tcchoujiang_id = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):1;
    
    $cjlogList      = C::t('#tom_tcchoujiang#tom_tcchoujiang_log')->fetch_all_list("AND user_id = {$user_id} AND tcchoujiang_id = {$tcchoujiang_id}","ORDER BY log_time DESC,id DESC",0,50);
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['cj_log'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['cj_choujiang_id'] . '</th>';
    echo '<th>' . $Lang['cj_user_id'] . '</th>';
    echo '<th>' . $Lang['cj_type_id'] . '</th>';
    echo '<th>' . $Lang['cj_change_num'] . '</th>';
    echo '<th>' . $Lang['cj_log_time'] . '</th>';
    echo '</tr>';
    foreach ($cjlogList as $key => $value){
        $log_time = dgmdate($value['log_time'], 'Y-m-d H:i:s',$tomSysOffset);
        echo '<tr>';
        echo '<td>' . $value['tcchoujiang_id'] . '</td>';
        echo '<td>' . $value['user_id'] . '</td>';
        if($value['type_id'] == 1){
            echo '<td>' . $Lang['cj_type_id_1'] . '</td>';
        }else if($value['type_id'] == 2){
            echo '<td>' . $Lang['cj_type_id_2'] . '</td>';
        }else if($value['type_id'] == 3){
            echo '<td>' . $Lang['cj_type_id_3'] . '</td>';
        }else if($value['type_id'] == 4){
            echo '<td>' . $Lang['cj_type_id_4'] . '</td>';
        }
        echo '<td>' . $value['change_num'] . '</td>';
        echo '<td>' . $log_time . '</td>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    
}else if($_GET['act'] == 'addzj'){
    
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):1;
    $prize_id       = isset($_GET['prize_id'])? intval($_GET['prize_id']):1;
    $tcchoujiang_id = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):1;
    $order_time    = isset($_GET['order_time'])? addslashes($_GET['order_time']):'';
    $order_time    = strtotime($order_time);
    
    $prizeInfo      = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_by_id($prize_id);
    $choujiangInfo  = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);
    $bmInfo         = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($tcchoujiang_id,$user_id);

    if(submitcheck('submit')){
        if($prizeInfo['is_extend'] == 1){
            cpmsg($Lang['bm_addzj_error'], $modListUrl, 'error');
        }
        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        $hexiao_no  = date("YmdHis")."-".mt_rand(111111, 666666);
        
        $insertData                     = array();
        $insertData['site_id']          = $choujiangInfo['site_id'];
        if($choujiangInfo['type'] == 2){
            $insertData['tcshop_id']    = $choujiangInfo['tcshop_id'];
        }else{
            $insertData['tcshop_id']    = $prizeInfo['tcshop_id'];
        }
        $insertData['tcchoujiang_id']   = $tcchoujiang_id;
        $insertData['user_id']          = $user_id;
        $insertData['order_no']         = $order_no;
        $insertData['hexiao_no']        = $hexiao_no;
        $insertData['prize_id']         = $prize_id;
        $insertData['prize_name']       = $prizeInfo['name'];
        $insertData['xm']               = $bmInfo['xm'];
        $insertData['tel']              = $bmInfo['tel'];
        $insertData['order_status']     = 1;
        $insertData['peisong_type']     = $prizeInfo['peisong_type'];
        $insertData['order_time']       = $order_time;
        C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->insert($insertData);

        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
       
    }else{
        echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=addzj&user_id='.$_GET['user_id'], 'enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delete'){
    
    C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $tcchoujiang_id = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):1;
    $user_id = !empty($_GET['user_id'])? addslashes($_GET['user_id']):0;
    
    $choujiangInfo  = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($_GET['tcchoujiang_id']);
    
    $where = " AND tcchoujiang_id={$tcchoujiang_id} ";
    if(!empty($user_id)){
        $where.= " AND user_id=$user_id ";
    }
   
    $pagesize = 15;
    $page     = intval($_GET['page'])>0 ? intval($_GET['page']):1;
    $start    = ($page - 1)*$pagesize;
    $count    = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_all_count("{$where}");
    $bmList   = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_all_list("{$where} ","ORDER BY add_time DESC,id DESC", $start, $pagesize);
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['bm_search_title'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['bm_user_id'] . '</b></td><td><input name="user_id" type="text" value="'.$user_id.'" size="40" /></td></tr>';
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism-taobao_com*/
  
    tomshownavheader();
    tomshownavli($Lang['daochu_user_list_title'],$_G['siteurl']."plugin.php?id=tom_tcchoujiang:bmlistexport&tcchoujiang_id={$tcchoujiang_id}",false);
    if($count > 5000){
        tomshownavli($Lang['daochu_user_list_title'].'(page:2)',$_G['siteurl']."plugin.php?id=tom_tcchoujiang:bmlistexport&tcchoujiang_id={$tcchoujiang_id}&page=2",false);
    }
    if($count > 10000){
        tomshownavli($Lang['daochu_user_list_title'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcchoujiang:bmlistexport&tcchoujiang_id={$tcchoujiang_id}&page=3",false);
    }
    if($count > 15000){
        tomshownavli($Lang['daochu_user_list_title'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcchoujiang:bmlistexport&tcchoujiang_id={$tcchoujiang_id}&page=4",false);
    }
    if($count > 20000){
        tomshownavli($Lang['daochu_user_list_title'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcchoujiang:bmlistexport&tcchoujiang_id={$tcchoujiang_id}&page=5",false);
    }
    if($count > 25000){
        tomshownavli($Lang['daochu_user_list_title'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcchoujiang:bmlistexport&tcchoujiang_id={$tcchoujiang_id}&page=6",false);
    }
    tomshownavfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th width="10%">'. $Lang['bm_user_id'].'</th>';
    echo '<th>'. $Lang['bm_xm'].'</th>';
    echo '<th>'. $Lang['bm_tel'].'</th>';
    echo '<th>'. $Lang['bm_cj_times'].'</th>';
    echo '<th>'. $Lang['handle'].'</th>';
    echo '</tr>';
    $i = 1;
    foreach ($bmList as $key => $value) {
        echo '<tr>';
        echo '<td>'. $value['user_id'].'</td>';
        echo '<td>'. $value['xm'].'</td>';
        echo '<td>'. $value['tel'].'</td>';
        echo '<td>'. $value['cj_times'].'</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=editcj_times&id='.$value['id'].'&tcchoujiang_id='.$tcchoujiang_id.'&formhash='.FORMHASH.'">'.$Lang['edit_cj_times'].'</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=cj_log&user_id='.$value['user_id'].'&tcchoujiang_id='.$tcchoujiang_id.'&formhash='.FORMHASH.'">'.$Lang['cj_log'].'</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=addzj&user_id='.$value['user_id'].'&tcchoujiang_id='.$tcchoujiang_id.'&formhash='.FORMHASH.'">'.$Lang['zj_add'].'</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delete&tcchoujiang_id='.$tcchoujiang_id.'&id='.$value['id'].'&formhash='.FORMHASH.'\');">'.$Lang['delete'].'</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi,false );
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")  
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}

function __create_info_html($infoArr = array()){
    global $Lang,$prize_list;
    $options = array(
        'prize_id'    => "",
        'order_time'  => "",
    );
    $options = array_merge($options, $infoArr);
    
    $prizeList = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_list(" AND tcchoujiang_id={$_GET['tcchoujiang_id']} ","ORDER BY id DESC",0,100);

    echo '<tr class="header"><th>'.$Lang['zj_prize'].'</th><th></th></tr>';
    echo '<tr><td width="300"><select name="prize_id">';
    foreach ($prizeList as $pk => $pv){
        echo '<option value="'.$pv['id'].'">'.$prize_list[$pv['type']].'</option>';
    }
    tomshowsetting(true,array('title'=>$Lang['bm_order_time'],'name'=>'order_time','value'=>$options['order_time'],'msg'=>$Lang['bm_order_time_msg']),"calendar");
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl,$doDaoUrl;
    tomshownavheader();
    if($_GET['act'] == 'addzj'){
        tomshownavli($Lang['user_list_title'],$modBaseUrl,false);
    }else{
        tomshownavli($Lang['user_list_title'],$modBaseUrl,true);
    }
    tomshownavfooter();
}