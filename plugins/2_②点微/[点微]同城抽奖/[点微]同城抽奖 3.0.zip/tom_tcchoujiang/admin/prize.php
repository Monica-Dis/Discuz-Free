<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=prize&tcchoujiang_id='.$_GET['tcchoujiang_id'];
$modListUrl = $adminListUrl.'&tmod=prize&tcchoujiang_id='.$_GET['tcchoujiang_id'];
$modFromUrl = $adminFromUrl.'&tmod=prize&tcchoujiang_id='.$_GET['tcchoujiang_id'];

if($_GET['act'] == 'add'){
    $choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($_GET['tcchoujiang_id']);
    if(submitcheck('submit')){
        
        if($choujiangInfo['type'] == 1 || $choujiangInfo['type'] == 3 || $choujiangInfo['type'] == 4){
            
            $tcshop_id  = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
            $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
            if($tcshopInfo && $tcshopInfo['status'] == 1){
            }else if($tcshop_id == 0){
            }else{
                cpmsg($Lang['prize_add_error_500'], $modListUrl.'&act=add', 'error');
            }
            
        }
        
        $insertData = array();
        $insertData = __get_post_data();
        
        $prizeListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_list("AND tcchoujiang_id = {$_GET['tcchoujiang_id']} AND type = {$insertData['type']}");
        if(!empty($prizeListTmp)){
            cpmsg($Lang['prize_add_error_400'], $modListUrl, 'error');
        }
        
        $chanceCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_sum_chance("AND tcchoujiang_id = {$_GET['tcchoujiang_id']} ");
        if($chanceCount + $insertData['chance'] > 10000){
            cpmsg($Lang['prize_add_error_300'], $modListUrl, 'error');
        }
        
        if($choujiangInfo['type'] == 2){
           $insertData['tcshop_id']  = $choujiangInfo['tcshop_id']; 
        }
        $insertData['add_time']  = TIMESTAMP;
        C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->insert($insertData);
        $prize_id = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->insert_id();
        updatePrizelog($prize_id);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($_GET['tcchoujiang_id']);
    $prizeInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        if($choujiangInfo['type'] == 1 || $choujiangInfo['type'] == 3 || $choujiangInfo['type'] == 4){
            
            $tcshop_id   = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
            $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
            if($tcshopInfo && $tcshopInfo['status'] == 1){
            }else if($tcshop_id == 0){
            }else{
                cpmsg($Lang['prize_add_error_500'], $modListUrl.'&act=add', 'error');
            }
        }
        
        $updateData = array();
        $updateData = __get_post_data($prizeInfo);
        
        $prizeListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_list("AND id != {$_GET['id']} AND tcchoujiang_id = {$_GET['tcchoujiang_id']} AND type = {$updateData['type']}");
        if(!empty($prizeListTmp)){
            cpmsg($Lang['prize_add_error_400'], $modListUrl, 'error');
        }
        
        $chanceCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_sum_chance("AND tcchoujiang_id = {$_GET['tcchoujiang_id']} ");
        if($chanceCount - $prizeInfo['chance'] + $updateData['chance'] > 10000){
            cpmsg($Lang['prize_add_error_300'], $modListUrl, 'error');
        }
        
        $updateData['add_time'] = TIMESTAMP;
        C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->update($prizeInfo['id'],$updateData);
        
        updatePrizelog($prizeInfo['id']);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($prizeInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $tcchoujiang_id  = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):1;
    $choujiangInfo  = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($_GET['tcchoujiang_id']);
    $page     = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page - 1)*$pagesize;	
    $count = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_count("AND tcchoujiang_id={$tcchoujiang_id}");
    $prizeList = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_list("AND tcchoujiang_id={$tcchoujiang_id}","ORDER BY type ASC , id DESC",$start,$pagesize);
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['prize_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['prize_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();/*Dism��taobao��com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['prize_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>ID</th>';
    echo '<th>' . $Lang['prize_grade'] . '</th>';
    echo '<th>' . $Lang['prize_name'] . '</th>';
    echo '<th>' . $Lang['prize_picurl'] . '</th>';
    echo '<th>' . $Lang['prize_num'] . '</th>';
    echo '<th>' . $Lang['prize_chance'] . '</th>';
    echo '<th>' . $Lang['prize_type'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($prizeList as $key => $value){
        $prizeList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl'])) {
            if(strpos($choujiangInfo['toppic'], 'source/plugin/tom_tcchoujiang/') === FALSE){
                $prize_picurl = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $prize_picurl = $value['picurl'];
            }
        }else{
            $prize_picurl = $value['picurl'];
        }
        
        $chance = 0;
        if($value['chance'] > 0){
            $chance = $value['chance']/100;
        }
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>'. $prize_list[$value['type']].'</td>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td><img src="'. $prize_picurl.'" width="40"></td>';
        echo '<td>' . $value['num'] . '</td>';
        echo '<td>' . $chance . '</td>';
        if($value['is_extend'] == 0){
            echo '<td>' . $Lang['is_extend_0'] . '</td>';
        }else{
            echo '<td>' . $Lang['is_extend_1'] . '</td>';
        }
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['prize_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $type            = isset($_GET['type'])? intval($_GET['type']):'';
    $tcshop_id       = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):'';
    $name            = isset($_GET['name'])? addslashes($_GET['name']):'';
    $num             = isset($_GET['num'])? intval($_GET['num']):0;        
    $chance          = isset($_GET['chance'])? intval($_GET['chance']*100):0; 
    $hexiao_pwd      = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $peisong_type    = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $is_extend       = isset($_GET['is_extend'])? intval($_GET['is_extend']):0;
    $extend_id       = isset($_GET['extend_id'])? intval($_GET['extend_id']):0;
    $content         = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $prize_picurl   = "";
    if($_GET['act'] == 'add'){
        $prize_picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $prize_picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    $data['tcchoujiang_id']     = $_GET['tcchoujiang_id'];
    $data['type']               = $type;
    $data['tcshop_id']          = $tcshop_id;
    $data['name']               = $name;
    $data['picurl']             = $prize_picurl;
    $data['num']                = $num;
    $data['chance']             = $chance;
    $data['hexiao_pwd']         = $hexiao_pwd;
    $data['peisong_type']       = $peisong_type;
    $data['is_extend']          = $is_extend;
    $data['extend_id']          = $extend_id;
    $data['content']            = $content;
    
    return $data;
}

function updatePrizelog($prize_id){
    
    $prizeInfo = C::t("#tom_tcchoujiang#tom_tcchoujiang_prize")->fetch_by_id($prize_id);
    $chance = $prizeInfo['chance']/100;
    $log_txt .= ''.lang('plugin/tom_tcchoujiang', 'prize_grade').':&nbsp;<span><font color="#fd0d0d">'.$prizeInfo['type'].'</font>, </span>'.lang('plugin/tom_tcchoujiang', 'prize_name').':&nbsp;<span><font color="#fd0d0d">'.$prizeInfo['name'].'</font>, </span>'.lang('plugin/tom_tcchoujiang', 'prize_num').':&nbsp;<span><font color="#fd0d0d">'.$prizeInfo['num'].'</font>, </span>'.lang('plugin/tom_tcchoujiang', 'prize_chance').':&nbsp;<span><font color="#fd0d0d">'.$chance.'</font></span>'.'<br/>';
    
    $insertData = array();
    $insertData['is_admin']     = 1;
    $insertData['prize_id']     = $prize_id;
    $insertData['log_txt']      = $log_txt;
    $insertData['log_time']     = TIMESTAMP;
    C::t("#tom_tcchoujiang#tom_tcchoujiang_prize_log")->insert($insertData);
   
}

function __create_info_html($infoArr = array()){
    global $Lang,$prize_list;
    $choujiangInfo  = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($_GET['tcchoujiang_id']);
    $options = array(
        'type'        => '',
        'tcshop_id'   => '',
        'name'        => '',
        'picurl'      => '',
        'num'         => '',
        'chance'      => '0',
        'hexiao_pwd'  => '0',
        'peisong_type'=> '1',
        'is_extend'   => '',
        'extend_id'   => '',
        'content'     => '',
    );
    $options = array_merge($options, $infoArr);
    
    if($options['chance'] > 0){
        $options['chance'] = $options['chance']/100;
    }
    
    if($choujiangInfo['type'] == 1 || $choujiangInfo['type'] == 3 || $choujiangInfo['type'] == 4){
        tomshowsetting(true,array('title'=>$Lang['prize_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['prize_tcshop_id_msg']),"input");
    }
    
    echo '<tr class="header"><th>'.$Lang['prize_grade'].'</th><th></th></tr>';
    echo '<tr><td width="300"><select name="type">';
        $si = $options['type'];
        for($i=1;$i<=5;$i++){
            if($i == $si){
                echo '<option value="'.$i.'" selected="selected">'.$prize_list[$i].'</option>';
            }else{
                echo '<option value="'.$i.'">'.$prize_list[$i].'</option>';
            }
        }
    echo '</select></td><td>'.$Lang['prize_grade_msg'].'</td></tr>';
    
    $is_extend_item = array(0=>$Lang['is_extend_0'],1=>$Lang['is_extend_1']);
    tomshowsetting(true,array('title'=>$Lang['prize_type'],'name'=>'is_extend','value'=>$options['is_extend'],'msg'=>$Lang['prize_type_msg'],'item'=>$is_extend_item),"radio");
    
    $extendList = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_extend')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $extendStr = '<tr class="header"><th>'.$Lang['prize_extend_name'].'</th><th></th></tr>';
    $extendStr.= '<tr><td width="300"><select style="width: 260px;" name="extend_id" id="extend_id">';
    $extendStr.=  '<option value="0">'.$Lang['prize_extend_name'].'</option>';
    foreach ($extendList as $key => $value){
        if($value['id'] == $options['extend_id']){
            $extendStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $extendStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $extendStr.= '</select></td><td></td></tr>';
    echo $extendStr;
    tomshowsetting(true,array('title'=>$Lang['prize_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['prize_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['prize_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['prize_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['prize_num'],'name'=>'num','value'=>$options['num'],'msg'=>$Lang['prize_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['prize_chance'],'name'=>'chance','value'=>$options['chance'],'msg'=>$Lang['prize_chance_msg']),"input");
    if($options['is_extend'] == 0){
        tomshowsetting(true,array('title'=>$Lang['prize_hexiao_pwd'],'name'=>'hexiao_pwd','value'=>$options['hexiao_pwd'],'msg'=>$Lang['prize_hexiao_pwd_msg']),"input");
        $peisong_type_item = array(1=>$Lang['prize_peisong_type_1'],2=>$Lang['prize_peisong_type_2'],3=>$Lang['prize_peisong_type_3']);
        tomshowsetting(true,array('title'=>$Lang['prize_peisong_type'],'name'=>'peisong_type','value'=>$options['peisong_type'],'msg'=>$Lang['prize_peisong_type_msg'],'item'=>$peisong_type_item),"radio");
    }
    tomshowsetting(true,array('title'=>$Lang['prize_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['prize_content_msg']),"textarea");
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['prize_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['prize_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['prize_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['prize_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['prize_edit'],"",true); 
    }else{
        tomshownavli($Lang['prize_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['prize_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['prize_log'],$adminBaseUrl.'&tmod=prizelog',false);
    }
    tomshownavfooter();
}