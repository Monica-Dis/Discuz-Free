<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=prizelog'; 
$modListUrl = $adminListUrl.'&tmod=prizelog';
$modFromUrl = $adminFromUrl.'&tmod=prizelog';

$act      = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

$where = "";

$pagesize = 100;
$page   = intval($_GET['page'])>0? intval($_GET['page']):1;
$start  = ($page - 1)*$pagesize;	
$count  = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_log')->fetch_all_count($where);
$prizelogList = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_log')->fetch_all_list($where,"ORDER BY log_time DESC,id DESC",$start,$pagesize);

showtableheader();
echo '<tr><th colspan="15" class="partition">' . $Lang['prize_log'] . '</th></tr>';
echo '<tr class="header">';
echo '<th>' . $Lang['prizelog_id'] . '</th>';
echo '<th>' . $Lang['prizelog_log_txt'] . '</th>';
echo '<th>' . $Lang['prizelog_is_admin'] . '</th>';
echo '<th>' . $Lang['prizelog_log_time'] . '</th>';
echo '</tr>';
foreach ($prizelogList as $key => $value){
    $modelUrl = $adminBaseUrl.'&tmod=index';
    echo '<tr>';
    echo '<td>'.$value['prize_id'].'</td>';
    echo '<td>'.$value['log_txt'].'</td>';
    if($value['is_admin'] == 1){
        echo '<td>'.$Lang['prizelog_is_admin_1'].'</td>';
    }else{
        echo '<td>'.$Lang['prizelog_is_admin_0'].'</td>';
    }
    echo '<td>'.dgmdate($value['log_time'],"Y-m-d H:i",$tomSysOffset).'</td>';
    echo '</tr>';
}
showtablefooter();/*Dism��taobao��com*/
$multi = multi($count, $pagesize, $page, $modBaseUrl);	
showsubmit('', '', '', '', $multi, false);