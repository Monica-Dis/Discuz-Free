<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $site_id     = isset($_GET['site_id'])? intval($_GET['site_id']):0;
        $type        = isset($_GET['type'])? intval($_GET['type']):0;
        $title       = isset($_GET['title'])? addslashes($_GET['title']):'';
        
        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['type']             = $type;
        $insertData['title']            = $title;
        if($type == 4){
           $insertData['is_everyday']            = 1; 
           $insertData['open_score_pay']         = 1; 
        }
        $insertData['shenhe_status']    = 1;
        $insertData['status']           = 2;
        $insertData['add_time']         = TIMESTAMP;
        if(C::t('#tom_tcchoujiang#tom_tcchoujiang')->insert($insertData)){
            $tcchoujiang_id = C::t('#tom_tcchoujiang#tom_tcchoujiang')->insert_id();
            cpmsg($Lang['act_success'], $modListUrl.'&act=edit&id='.$tcchoujiang_id, 'succeed');
        }else{
            cpmsg($Lang['index_add_error'], $modListUrl.'&act=add', 'error');
        }
        
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=add&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['index_add_type'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['index_site_id'],'name'=>'site_id','value'=>1,'msg'=>$Lang['index_site_id_msg']),"input");
        $type_item = array(1=>$Lang['index_type_1'],2=>$Lang['index_type_2'],3=>$Lang['index_type_3']);
        tomshowsetting(true,array('title'=>$Lang['index_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['index_type_msg'],'item'=>$type_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['index_title_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['act'] == 'edit'){
    
    $choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $updateData = array();
        $updateData = __get_post_data($choujiangInfo);
        C::t('#tom_tcchoujiang#tom_tcchoujiang')->update($choujiangInfo['id'],$updateData);
        
        $choujiangInfoTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($choujiangInfo['id']);
        update_chou_status($choujiangInfoTmp);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($choujiangInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    DB::query("UPDATE ".DB::table('tom_tcchoujiang')." SET status=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    DB::query("UPDATE ".DB::table('tom_tcchoujiang')." SET status=2 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenheok'){
    
    DB::query("UPDATE ".DB::table('tom_tcchoujiang')." SET shenhe_status=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    $choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($_GET['id']);
    if($choujiangInfo['site_id'] == 1){
        $sitename = $tongchengConfig['plugin_name'];
    }else{
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($choujiangInfo['site_id']);
        $sitename = $siteInfo['name'];
    }
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($choujiangInfo['user_id']);

    $shenhe = str_replace('{TITLE}', $choujiangInfo['title'], $Lang['template_tcchoujiang_shenhe_ok']);
    $cpmsg = $Lang['tcchoujiang_shenhe_tz_succ'];
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $weixinClass = new weixinClass($appid,$appsecret);
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcchoujiang&site={$choujiangInfo['site_id']}&mod=details&tcchoujiang_id=".$choujiangInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $sitename,
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
        }else{
            $cpmsg = $Lang['tcchoujiang_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcchoujiangConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenheno'){
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        DB::query("UPDATE ".DB::table('tom_tcchoujiang')." SET shenhe_status=3 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
        
        $choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($_GET['id']);
        if($choujiangInfo['site_id'] == 1){
            $sitename = $tongchengConfig['plugin_name'];
        }else{
            $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($choujiangInfo['site_id']);
            $sitename = $siteInfo['name'];
        }
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($choujiangInfo['user_id']);
        
        $shenhe = str_replace('{TITLE}', $choujiangInfo['title'], $Lang['template_tcchoujiang_shenhe_no']);
        $cpmsg = $Lang['tcchoujiang_shenhe_tz_succ'];
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcchoujiang&site={$choujiangInfo['site_id']}&mod=edit&tcchoujiang_id=".$choujiangInfo['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $sitename,
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
            }else{
                $cpmsg = $Lang['tcchoujiang_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcchoujiangConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tcchoujiang_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenheno&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tcchoujiang_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcchoujiang_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['act'] == 'photo'){
    
    $tcchoujiang_id  = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):1;
    
    if(submitcheck('submit')){
        
        if($_FILES["picurl"]['tmp_name']) {
            $upload = new tom_upload();
            if(!$upload->init($_FILES["picurl"], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }
            $picurl = $upload->attach['attachment'];
        }else{
            $picurl = addslashes($_GET["picurl"]);
        }
        
        $insertData = array();
        $insertData['tcchoujiang_id']     = $tcchoujiang_id;
        $insertData['picurl']             = $picurl;
        $insertData['add_time']           = TIMESTAMP;
        C::t('#tom_tcchoujiang#tom_tcchoujiang_photo')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl."&act=photo&tcchoujiang_id=".$_GET['tcchoujiang_id'], 'succeed');
    }
    
    $choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($_GET['tcchoujiang_id']);
    
    $photoList = C::t('#tom_tcchoujiang#tom_tcchoujiang_photo')->fetch_all_list(" AND tcchoujiang_id={$tcchoujiang_id} ","ORDER BY id ASC",0,100);
    __create_nav_html();
    showformheader($modFromUrl.'&act=photo&tcchoujiang_id='.$tcchoujiang_id,'enctype');
    showtableheader();
    tomshowsetting(true,array('title'=>$Lang['index_photo_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['index_photo_picurl_msg']),"file");
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism-taobao_com*/
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['index_photo_picurl'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($photoList as $key => $value) {
        echo '<tr>';
        echo '<td><img src="' . tomgetfileurl($value['picurl']) . '" width="60" /></td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&tcchoujiang_id='.$tcchoujiang_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tcchoujiang#tom_tcchoujiang_photo')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl."&act=photo&tcchoujiang_id=".$_GET['tcchoujiang_id'], 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcchoujiang#tom_tcchoujiang')->delete_by_id($_GET['id']);
    C::t('#tom_tcchoujiang#tom_tcchoujiang_photo')->delete_by_tcchoujiang_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_tcchoujiang_admin_index_list");
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ list-style-type: none; height: 25px; line-height: 25px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;padding: 3px 10px;color: #6a6d6a; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
</style>
EOF;
    echo $csstr;
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $is_answer      = isset($_GET['is_answer'])? intval($_GET['is_answer']):0;
    
    $where = "";
    
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if($status == 1){
        $where.= " AND status=1 ";
    }else if($status == 2){
        $where.= " AND status=2 ";
    }
    if($shenhe_status > 0){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    if($is_answer == 1){
        $where.= " AND is_answer=0 ";
    }else if($is_answer == 2){
        $where.= " AND is_answer=1 ";
    }
    
    $sort = " ORDER BY id DESC ";
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&status={$status}&shenhe_status={$shenhe_status}&is_answer={$is_answer}";
    
    $pagesize   = 15;
    $start      = ($page - 1)*$pagesize;
    $count      = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_all_count("{$where}",$title);
    $choujiangList = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_all_like_list("{$where}", $sort ,$start,$pagesize,$title);
    
    showtableheader();
    $Lang['index_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_3']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_3'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();/*Dism��taobao��com*/
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    $selected_1 = '';
    if($site_id == 1){
        $selected_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$selected_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    echo '<tr><td width="100" align="right"><b>' . $Lang['index_title'] . '</b></td><td><input name="title" type="text" value="'.$title.'" style="width: 260px;" /></td></tr>';
    $shenhe_status_1 = $shenhe_status_2 = $shenhe_status_3 = '';
    if($shenhe_status == 1){
        $shenhe_status_1 = 'selected';
    }else if($shenhe_status == 2){
        $shenhe_status_2 = 'selected';
    }else if($shenhe_status == 3){
        $shenhe_status_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['index_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$shenhe_status_1.'>'.$Lang['index_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$shenhe_status_2.'>'.$Lang['index_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$shenhe_status_3.'>'.$Lang['index_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    echo '<tr><td width="100" align="right"><b>' . $Lang['index_status'] . '</b></td><td><select style="width: 260px;" name="status" >';
    echo '<option value="0">'.$Lang['index_status'].'</option>';
    $status1_selected = $status2_selected = "";
    if(1 == $status){
        $status1_selected = "selected";
    }
    if(2 == $status){
        $status2_selected = "selected";
    }
    echo '<option value="1" '.$status1_selected.'>'.$Lang['index_status_1'].'</option>';
    echo '<option value="2" '.$status2_selected.'>'.$Lang['index_status_2'].'</option>';
    echo '</select></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['index_is_answer'] . '</b></td><td><select style="width: 260px;" name="is_answer" >';
    echo '<option value="0">'.$Lang['quanbu'].'</option>';
    $is_answer1_selected = $is_answer2_selected = "";
    if(1 == $is_answer){
        $is_answer1_selected = "selected";
    }
    if(2 == $is_answer){
        $is_answer2_selected = "selected";
    }
    echo '<option value="1" '.$is_answer1_selected.'>'.$Lang['index_is_answer_0'].'</option>';
    echo '<option value="2" '.$is_answer2_selected.'>'.$Lang['index_is_answer_1'].'</option>';
    echo '</select></td></tr>';
    
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism-taobao_com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['index_title'] . '</th>';
    echo '<th>' . $Lang['index_type'] . '</th>';
    echo '<th>' . $Lang['index_tcshop_info'] . '</th>';
    echo '<th>' . $Lang['index_cj_times'] . '</th>';
    echo '<th>' . $Lang['index_zj_times'] . '</th>';
    echo '<th>' . $Lang['index_choujiang_status'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($choujiangList as $key => $value) {
        
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $tcshopUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfoTmp['user_id']); 
        
        $choujiangList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_tcchoujiang/') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        $shenhe_status = '';
        if($value['shenhe_status'] == 1){
            $shenhe_status = $Lang['indexshenhe_ok'];
        }else if($value['shenhe_status'] == 2){
            $shenhe_status = $Lang['indexshenhe_ing'];
        }else if($value['shenhe_status'] == 3){
            $shenhe_status = $Lang['indexshenhe_no'];
        }else{
            $shenhe_status = '-';
        }
        $status = '';
        if($value['status'] == 1){
            $status = $Lang['status_yes'];
        }else{
            $status = $Lang['status_no'];
        }
        $start_time     = dgmdate($value['start_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $end_time       = dgmdate($value['end_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $hexiao_time    = dgmdate($value['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $siteInfo       = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $tcshopInfo     = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $tcshopUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfo['user_id']);
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $value['title'].'(<font color="#fd0d0d">ID:'.$value['id'].'</font>)</td>';
        if($value['type'] == 1){
            echo '<td>' . $Lang['index_type_1'] . '</td>';
        }else if($value['type'] == 2){
            echo '<td>' . $Lang['index_type_2'] . '</td>';
        }else if($value['type'] == 3){
            echo '<td>' . $Lang['index_type_3'] . '</td>';
        }else if($value['type'] == 4){
            echo '<td>' . $Lang['index_type_4'] . '</td>';
        }
        echo '<td><div class="tc_content_box"><ul>';
        if(empty($tcshopInfoTmp)){
            echo '<li>'.$Lang['index_pingtai'].'</li>';
        }else{
            echo '<li>'.$Lang['index_tcshop_id'].'&nbsp;:&nbsp;' . $tcshopInfoTmp['id'] . '</li>';
            echo '<li>'.$Lang['index_tcshop_name'].'&nbsp;:&nbsp;' . $tcshopInfoTmp['name'] . '</li>';
        }
        echo '</ul></div></td>';
        echo '<td>' . $value['cj_times'] . '</td>';
        echo '<td>' . $value['zj_times'] . '</td>';
        echo '<td><div class="tc_content_box"><ul>';
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenheok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_ok']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenheno&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_no']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<li><b>'.$Lang['index_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['index_shenhe_status_1'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 2){
            echo '<li><b>'.$Lang['index_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['index_shenhe_status_2'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 3){
            echo '<li><b>'.$Lang['index_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['index_shenhe_status_3'] . '</font>'.$sheheBtnStr.'</li>';
        }
        if($value['status'] == 1 ){
            $statusBtnStr = '(&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['status_no']. '</a>)';
        }else{
            $statusBtnStr = '(&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['status_yes']. '</a>)';
        }
        if($value['status'] == 1 ){
            echo '<li><b>'.$Lang['status_show'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['status_yes'] . '</font>'.$statusBtnStr.'</li>';
        }else{
            echo '<li><b>'.$Lang['status_show'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['status_no'] . '</font>'.$statusBtnStr.'</li>';
        }
        if($value['type'] == 1 || $value['type'] == 2){
            echo '<li><b>'.$Lang['index_start_time'].'&nbsp;:&nbsp;</b>' . $start_time . '</li>';
            echo '<li><b>'.$Lang['index_end_time'].'&nbsp;:&nbsp;</b>' . $end_time . '</li>';
        }
        echo '<li><b>'.$Lang['index_hexiao_time'].'&nbsp;:&nbsp;</b>' . $hexiao_time . '</li>';
        echo '</ul></div></td>';
        echo '<td style="line-height: 30px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&tmod=prize&tcchoujiang_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['prize_list_title']. '</a></br>';
        echo '<a href="'.$adminBaseUrl.'&tmod=bm&tcchoujiang_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['user_list_title']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&tmod=order&tcchoujiang_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['order_title']. '</a></br>';
        echo '<a href="'.$adminBaseUrl.'&act=photo&tcchoujiang_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_photo']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        if($value['type'] == 1 || $value['type'] == 2){
            echo '<a href="'.$adminBaseUrl.'&tmod=answer&tcchoujiang_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['answer_list_title']. '</a></br>';
        }
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id                 = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $tcshop_id               = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $title                   = isset($_GET['title'])? addslashes($_GET['title']):'';
    $bg_color                = isset($_GET['bg_color'])? addslashes($_GET['bg_color']):'';
    $font_color              = isset($_GET['font_color'])? intval($_GET['font_color']):1;
    $cj_times                = isset($_GET['cj_times'])? addslashes($_GET['cj_times']):'';
    $zj_times                = isset($_GET['zj_times'])? addslashes($_GET['zj_times']):'';
    $start_time              = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time              = strtotime($start_time);
    $end_time                = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time                = strtotime($end_time);
    $hexiao_time             = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time             = strtotime($hexiao_time);
    $is_answer               = isset($_GET['is_answer'])? intval($_GET['is_answer']):0;
    $answer_num              = isset($_GET['answer_num'])? intval($_GET['answer_num']):0;
    $open_score_pay          = isset($_GET['open_score_pay'])? intval($_GET['open_score_pay']):0;
    $pay_score               = isset($_GET['pay_score'])? intval($_GET['pay_score']):0;
    $before_bm               = isset($_GET['before_bm'])? intval($_GET['before_bm']):0;
    $is_everyday             = isset($_GET['is_everyday'])? intval($_GET['is_everyday']):0;
    $share_num               = isset($_GET['share_num'])? intval($_GET['share_num']):0;
    $guize                   = isset($_GET['guize'])? addslashes($_GET['guize']):'';
    $content                 = isset($_GET['content'])? addslashes($_GET['content']):'';
    $share_title             = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc              = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $mp3_link                = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $admin_edit              = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $virtual_clicks          = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $virtual_bmnum           = isset($_GET['virtual_bmnum'])? intval($_GET['virtual_bmnum']):0;
    $paixu                   = isset($_GET['paixu'])? addslashes($_GET['paixu']):'';
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $picurl = $toppic = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
        $toppic        = tomuploadFile("toppic");
        $bgpic         = tomuploadFile("bgpic");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
        $toppic        = tomuploadFile("toppic",$infoArr['toppic']);
        $bgpic         = tomuploadFile("bgpic",$infoArr['bgpic']);
    }
    
    $data['site_id']         = $site_id;
    $data['user_id']         = $tcshopInfo['user_id'];
    $data['tcshop_id']       = $tcshopInfo['id'];
    $data['title']           = $title;
    $data['bg_color']        = $bg_color;
    $data['font_color']      = $font_color;
    $data['picurl']          = $picurl;
    $data['toppic']          = $toppic;
    $data['bgpic']           = $bgpic;
    $data['before_bm']       = $before_bm;
    $data['cj_times']        = $cj_times;
    $data['zj_times']        = $zj_times;
    $data['start_time']      = $start_time;
    $data['end_time']        = $end_time;
    $data['hexiao_time']     = $hexiao_time;
    $data['is_answer']       = $is_answer;
    $data['answer_num']      = $answer_num;
    $data['open_score_pay']  = $open_score_pay;
    $data['pay_score']       = $pay_score;
    $data['is_everyday']     = $is_everyday;
    $data['share_num']       = $share_num;
    $data['guize']           = $guize;
    $data['content']         = $content;
    $data['share_title']     = $share_title;
    $data['share_desc']      = $share_desc;
    $data['mp3_link']        = $mp3_link;
    $data['admin_edit']      = $admin_edit;
    $data['virtual_clicks']  = $virtual_clicks;
    $data['virtual_bmnum']   = $virtual_bmnum;
    $data['paixu']           = $paixu;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        
        'site_id'           => 1,
        'type'              => '',
        'bg_color'          => '',
        'font_color'        => 1,
        'title'             => '',
        'picurl'            => '',
        'toppic'            => '',
        'bgpic'             => '',
        'before_bm'         => '',
        'cj_times'          => '',
        'zj_times'          => '',
        'start_time'        => time(),
        'end_time'          => time(),
        'hexiao_time'       => time(),
        'is_answer'         => 0,
        'answer_num'        => '',
        'open_score_pay'    => 0,
        'pay_score'         =>'',
        'is_everyday'       => 0,
        'share_num'         => 0,
        'guize'             => '',
        'content'           => '',
        'share_title'       => '',
        'share_desc'        => '',
        'mp3_link'       => '',
        'admin_edit'        => '',
        'virtual_clicks'    => '',
        'virtual_bmnum'     => '',
        'paixu'             => '',
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['index_site_id'],'name'=>'site_id','value'=>$options['site_id'],'msg'=>$Lang['index_site_id_msg']),"input");
    if($options['type'] == 2){
        tomshowsetting(true,array('title'=>$Lang['index_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['index_tcshop_id_msg']),"input");
    }
    tomshowsetting(true,array('title'=>$Lang['index_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['index_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_bg_color'],'name'=>'bg_color','value'=>$options['bg_color'],'msg'=>$Lang['index_bg_color_msg']),"input");
    $font_color_item = array(1=>$Lang['index_font_color_1'],2=>$Lang['index_font_color_2']);
    tomshowsetting(true,array('title'=>$Lang['index_font_color'],'name'=>'font_color','value'=>$options['font_color'],'msg'=>$Lang['index_font_color_msg'],'item'=>$font_color_item),"radio");
    if($options['type'] == 1 || $options['type'] == 2 || $options['type'] == 4 ){
        tomshowsetting(true,array('title'=>$Lang['index_cj_times'],'name'=>'cj_times','value'=>$options['cj_times'],'msg'=>$Lang['index_cj_times_msg']),"input");
    }
    tomshowsetting(true,array('title'=>$Lang['index_zj_times'],'name'=>'zj_times','value'=>$options['zj_times'],'msg'=>$Lang['index_zj_times_msg']),"input");
    if($options['type'] == 1 || $options['type'] == 2 ){
        $is_answer_item = array(0=>$Lang['index_is_answer_0'],1=>$Lang['index_is_answer_1']);
        tomshowsetting(true,array('title'=>$Lang['index_is_answer'],'name'=>'is_answer','value'=>$options['is_answer'],'msg'=>$Lang['index_is_answer_msg'],'item'=>$is_answer_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_answer_num'],'name'=>'answer_num','value'=>$options['answer_num'],'msg'=>$Lang['index_answer_num_msg']),"input");
        $before_bm_item = array(0=>$Lang['index_before_bm_0'],1=>$Lang['index_before_bm_1']);
        tomshowsetting(true,array('title'=>$Lang['index_before_bm'],'name'=>'before_bm','value'=>$options['before_bm'],'msg'=>$Lang['index_before_bm_msg'],'item'=>$before_bm_item),"radio");
    }
    if($options['type'] == 1 || $options['type'] == 2 || $options['type'] == 4 ){
        $open_score_pay_item = array(0=>$Lang['index_open_score_pay_0'],1=>$Lang['index_open_score_pay_1']);
        tomshowsetting(true,array('title'=>$Lang['index_open_score_pay'],'name'=>'open_score_pay','value'=>$options['open_score_pay'],'msg'=>$Lang['index_open_score_pay_msg'],'item'=>$open_score_pay_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_pay_score'],'name'=>'pay_score','value'=>$options['pay_score'],'msg'=>$Lang['index_pay_score_msg']),"input");
        $is_everyday_item = array(0=>$Lang['index_is_everyday_0'],1=>$Lang['index_is_everyday_1']);
        tomshowsetting(true,array('title'=>$Lang['index_is_everyday'],'name'=>'is_everyday','value'=>$options['is_everyday'],'msg'=>$Lang['index_is_everyday_msg'],'item'=>$is_everyday_item),"radio");
    }
    if($options['type'] == 1 || $options['type'] == 2 ){
        tomshowsetting(true,array('title'=>$Lang['index_start_time'],'name'=>'start_time','value'=>$options['start_time'],'msg'=>$Lang['index_start_time_msg']),"calendar");
        tomshowsetting(true,array('title'=>$Lang['index_end_time'],'name'=>'end_time','value'=>$options['end_time'],'msg'=>$Lang['index_end_time_msg']),"calendar");
    }
    tomshowsetting(true,array('title'=>$Lang['index_hexiao_time'],'name'=>'hexiao_time','value'=>$options['hexiao_time'],'msg'=>$Lang['index_hexiao_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['index_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['index_picurl_msg']),"file");
    if($options['type'] == 3 || $options['type'] == 4 ){
        tomshowsetting(true,array('title'=>$Lang['index_bgpic'],'name'=>'bgpic','value'=>$options['bgpic'],'msg'=>$Lang['index_bgpic_msg']),"file");
    }
    if($options['type'] == 1 || $options['type'] == 2 ){
        tomshowsetting(true,array('title'=>$Lang['index_toppic'],'name'=>'toppic','value'=>$options['toppic'],'msg'=>$Lang['index_toppic_msg']),"file");
    }
    if($options['type'] == 1 || $options['type'] == 2 ){
        tomshowsetting(true,array('title'=>$Lang['index_mp3_link'],'name'=>'mp3_link','value'=>$options['mp3_link'],'msg'=>$Lang['index_mp3_link_msg']),"input");
    }
    if($options['type'] == 1 || $options['type'] == 2 ){
        tomshowsetting(true,array('title'=>$Lang['index_virtual_clicks'],'name'=>'virtual_clicks','value'=>$options['virtual_clicks'],'msg'=>$Lang['index_virtual_clicks_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_virtual_bmnum'],'name'=>'virtual_bmnum','value'=>$options['virtual_bmnum'],'msg'=>$Lang['index_virtual_bmnum_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_share_num'],'name'=>'share_num','value'=>$options['share_num'],'msg'=>$Lang['index_share_num_msg']),"input");
    }
    tomshowsetting(true,array('title'=>$Lang['index_share_title'],'name'=>'share_title','value'=>$options['share_title'],'msg'=>$Lang['index_share_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_share_desc'],'name'=>'share_desc','value'=>$options['share_desc'],'msg'=>$Lang['index_share_desc_msg']),"input");
    $admin_edit_item = array(0=>$Lang['index_admin_edit_0'],1=>$Lang['index_admin_edit_1']);
    tomshowsetting(true,array('title'=>$Lang['index_admin_edit'],'name'=>'admin_edit','value'=>$options['admin_edit'],'msg'=>$Lang['index_admin_edit_msg'],'item'=>$admin_edit_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_guize'],'name'=>'guize','value'=>$options['guize'],'msg'=>$Lang['index_guize_msg']),"text");
    if($options['type'] == 1 || $options['type'] == 2 ){
        tomshowsetting(true,array('title'=>$Lang['index_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['index_content_msg']),"text");
    }
    tomshowsetting(true,array('title'=>$Lang['index_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['index_paixu_msg']),"input");
   
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add_type'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add_type'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['index_edit'],"",true); 
    }else if($_GET['act'] == 'photo'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_photo'],"",true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add_type'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}