<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=extend';
$modListUrl = $adminListUrl.'&tmod=extend';
$modFromUrl = $adminFromUrl.'&tmod=extend';

if($_GET['act'] == 'add'){
    $choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($_GET['tcchoujiang_id']);
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_extend')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $extendInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_extend')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($prizeInfo);
        $updateData['add_time'] = TIMESTAMP;
        C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_extend')->update($extendInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($extendInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_extend')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $page     = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page - 1)*$pagesize;	
    $count = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_extend')->fetch_all_count("");
    $extendList = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_extend')->fetch_all_list("","ORDER BY id DESC",$start,$pagesize);
    
    __create_nav_html();
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['extend_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['extend_id'] . '</th>';
    echo '<th>' . $Lang['extend_type_id'] . '</th>';
    echo '<th>' . $Lang['extend_name'] . '</th>';
    echo '<th>' . $Lang['extend_value'] . '</th>';
    echo '<th>' . $Lang['extend_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($extendList as $key => $value){
        $extendList[$key] = $value;
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['type_id'] == 1){
            echo '<td>' . $Lang['extend_type_id_1'] . '</td>';
        }else if($value['type_id'] == 2){
            echo '<td>' . $Lang['extend_type_id_2'] . '</td>';
        }else if($value['type_id'] == 3){
            echo '<td>' . $Lang['extend_type_id_3'] . '</td>';
        }else if($value['type_id'] == 4){
            echo '<td>' . $Lang['extend_type_id_4'] . '</td>';
        }else if($value['type_id'] == 5){
            echo '<td>' . $Lang['extend_type_id_5'] . '</td>';
        }
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>';
        if($value['type_id'] == 1){
            echo '<font color="#fd0d0d">' . $value['score_value'].'</font>'.$Lang['extend_score_name'];
        }else if($value['type_id'] == 2){
            $cardInfo = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($value['card_type_id']);
            echo '<font color="#fd0d0d">' . $cardInfo['name'].'</font>';
        }else if($value['type_id'] == 3){
            $couponInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($value['coupon_id']);
            echo $couponInfo['title'].'<font color="#fd0d0d">(ID:' . $couponInfo['id'].')</font>';
        }else if($value['type_id'] == 4){
            $tcmallCouponInfo = C::t('#tom_tcmall#tom_tcmall_coupon')->fetch_by_id($value['tcmall_coupon_id']);
            echo $tcmallCouponInfo['title'].'<font color="#fd0d0d">(ID:' . $tcmallCouponInfo['id'].')</font>';
        }else if($value['type_id'] == 5){
            $zhaopinVipInfo = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_by_id($value['tczhaopin_vip_id']);
            echo '<font color="#fd0d0d">' . $zhaopinVipInfo['title'].'</font>';
        }
        echo '</td>';
        echo '<td>' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['extend_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $type_id            = isset($_GET['type_id'])? intval($_GET['type_id']):'';
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $score_value        = isset($_GET['score_value'])? intval($_GET['score_value']):'';
    $card_type_id       = isset($_GET['card_type_id'])? intval($_GET['card_type_id']):'';
    $coupon_id          = isset($_GET['coupon_id'])? intval($_GET['coupon_id']):'';
    $tcmall_coupon_id   = isset($_GET['tcmall_coupon_id'])? intval($_GET['tcmall_coupon_id']):'';
    $tczhaopin_vip_id   = isset($_GET['tczhaopin_vip_id'])? intval($_GET['tczhaopin_vip_id']):'';
   
    $data['type_id']            = $type_id;
    $data['name']               = $name;
    $data['score_value']        = $score_value;
    $data['card_type_id']       = $card_type_id;
    $data['coupon_id']          = $coupon_id;
    $data['tcmall_coupon_id']   = $tcmall_coupon_id;
    $data['tczhaopin_vip_id']   = $tczhaopin_vip_id;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    
    $options = array(
        'type_id'           => '',
        'name'              => '',
        'score_value'       => '',
        'card_type_id'      => '',
        'coupon_id'         => '',
        'tcmall_coupon_id'  => '',
        'tczhaopin_vip_id'  => '',
    );
    $options = array_merge($options, $infoArr);
    
    $extendInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_extend')->fetch_by_id($_GET['id']);
    
    $HasTcyikatong = 0;
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
        $HasTcyikatong = 1;
    }
    $HasTcqianggou = 0;
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
        $HasTcqianggou = 1;
    }
    $HasTcmall = 0;
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcmall/tom_tcmall.inc.php')){
        $HasTcmall = 1;
    }
    $HasTczhaopin = 0;
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')){
        $HasTczhaopin = 1;
    }
    
    tomshowsetting(true,array('title'=>$Lang['extend_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['extend_name_msg']),"input");
    
    $extendtypeStr = '<tr class="header"><th>'.$Lang['extend_type_id'].'</th><th></th></tr>';
    $extendtypeStr.= '<tr><td colspan="2">';
    $type_id1_selected = $type_id2_selected = $type_id3_selected = $type_id4_selected = $type_id5_selected = "";
    if($extendInfo['type_id'] == 1){
        $type_id1_selected = "checked";
    }
    if($extendInfo['type_id'] == 2){
        $type_id2_selected = "checked";
    }
    if($extendInfo['type_id'] == 3){
        $type_id3_selected = "checked";
    }
    if($extendInfo['type_id'] == 4){
        $type_id4_selected = "checked";
    }
    if($extendInfo['type_id'] == 5){
        $type_id5_selected = "checked";
    }
    $extendtypeStr.= '<label><input type="radio" name="type_id" value="1" '.$type_id1_selected.'>'.$Lang['extend_type_id_1'].'</label>&nbsp;';
    if($HasTcyikatong == 1){
        $extendtypeStr.= '<label><input type="radio" name="type_id" value="2" '.$type_id2_selected.'>'.$Lang['extend_type_id_2'].'</label>&nbsp;';
    }
    if($HasTcqianggou == 1){
        $extendtypeStr.= '<label><input type="radio" name="type_id" value="3" '.$type_id3_selected.'>'.$Lang['extend_type_id_3'].'</label>&nbsp;';
    }
    if($HasTcmall == 1){
        $extendtypeStr.= '<label><input type="radio" name="type_id" value="4" '.$type_id4_selected.'>'.$Lang['extend_type_id_4'].'</label>&nbsp;';
    }
    if($HasTczhaopin == 1){
        $extendtypeStr.= '<label><input type="radio" name="type_id" value="5" '.$type_id5_selected.'>'.$Lang['extend_type_id_5'].'</label>&nbsp;';
    }
    $extendtypeStr.= '</td></tr>';
    echo $extendtypeStr;
    
    tomshowsetting(true,array('title'=>$Lang['extend_score_value'],'name'=>'score_value','value'=>$options['score_value'],'msg'=>$Lang['extend_score_value_msg']),"input");
    if($HasTcyikatong == 1){
        $cardList = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_all_list(" "," ORDER BY tsort ASC,id DESC ",0,100);
        $cardtypeStr = '<tr class="header"><th>'.$Lang['extend_card_type_id'].'</th><th></th></tr>';
        $cardtypeStr.= '<tr><td width="300"><select style="width: 260px;" name="card_type_id" id="card_type_id">';
        $cardtypeStr.=  '<option value="0">'.$Lang['extend_card_type_id_0'].'</option>';
        foreach ($cardList as $key => $value){
            if($value['id'] == $options['card_type_id']){
                $cardtypeStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $cardtypeStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $cardtypeStr.= '</select></td><td>'.$Lang['extend_card_type_id_msg'].'</td></tr>';
        echo $cardtypeStr;
    }
    if($HasTcqianggou == 1){
        tomshowsetting(true,array('title'=>$Lang['extend_coupon_id'],'name'=>'coupon_id','value'=>$options['coupon_id'],'msg'=>$Lang['extend_coupon_id_msg']),"input");
    }
    if($HasTcmall == 1){
        tomshowsetting(true,array('title'=>$Lang['extend_tcmall_coupon_id'],'name'=>'tcmall_coupon_id','value'=>$options['tcmall_coupon_id'],'msg'=>$Lang['extend_tcmall_coupon_id_msg']),"input");
    }
    if($HasTczhaopin == 1){
        $zhaopinVipList = C::t('#tom_tczhaopin#tom_tczhaopin_vip')->fetch_all_list(" "," ORDER BY tsort ASC,id DESC ",0,100);
        $zhaopinVipStr = '<tr class="header"><th>'.$Lang['extend_tczhaopin_vip_id'].'</th><th></th></tr>';
        $zhaopinVipStr.= '<tr><td width="300"><select style="width: 150px;" name="tczhaopin_vip_id" id="tczhaopin_vip_id" >';
        $zhaopinVipStr.=  '<option value="0">'.$Lang['extend_tczhaopin_vip_id_0'].'</option>';
        foreach ($zhaopinVipList as $key => $value){
            if($value['id'] == $options['tczhaopin_vip_id']){
                $zhaopinVipStr.=  '<option value="'.$value['id'].'" selected>'.$value['title'].'</option>';
            }else{
                $zhaopinVipStr.=  '<option value="'.$value['id'].'">'.$value['title'].'</option>';
            }
        }
        $zhaopinVipStr.= '</select></td><td>'.$Lang['extend_tczhaopin_vip_id_msg'].'</td></tr>';
        echo $zhaopinVipStr;
    }
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['extend_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['extend_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['extend_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['extend_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['extend_edit'],"",true); 
    }else{
        tomshownavli($Lang['extend_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['extend_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}