<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=order';
$modListUrl = $adminListUrl.'&tmod=order';
$modFromUrl = $adminFromUrl.'&tmod=order';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

if($formhash == FORMHASH && $act == 'info'){
    
    $info = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $order_status = intval($_GET['order_status']);
        $updateData = array();
        $updateData['order_status'] = $order_status;
        C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->update($_GET['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        $address = unserialize($info['address']);
        $fenghao = $Lang['fenghao'];
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_order_title'] . '</th></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_no'].$fenghao.'</b></td><td>'.$info['order_no'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_status'].$fenghao.'</b></td><td><b><font color="'.$orderStatusColorArray[$info['order_status']].'">' . $orderStatusArray[$info['order_status']] . '</font></b></td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_time'].$fenghao.'</b></td><td>'.dgmdate($info['order_time'], 'm-d H:i:s',$tomSysOffset).'</td></tr>';
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_user_title'] . '</th></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_xm'].$fenghao.'</b></td><td>'.$info['xm'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_tel'].$fenghao.'</b></td><td>'.$info['tel'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_address'].$fenghao.'</b></td><td>'.$info['address'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_beizu'].$fenghao.'</b></td><td>'.$info['order_beizu'].'</td></tr>';
        if($info['peisong_type'] == 1){
            echo '<tr><td align="right"><b>'.$Lang['order_peisong_type'].$fenghao.'</b></td><td>'.$Lang['order_peisong_type_1'].'</td></tr>';
        }else if($info['peisong_type'] == 2){
            echo '<tr><td align="right"><b>'.$Lang['order_peisong_type'].$fenghao.'</b></td><td>'.$Lang['order_peisong_type_2'].'</td></tr>';
            echo '<tr><td align="right"><b>'.$Lang['order_peisong_name2'].$fenghao.'</b></td><td>'.$info['peisong_name'].'</td></tr>';
            echo '<tr><td align="right"><b>'.$Lang['order_peisong_info2'].$fenghao.'</b></td><td>'.$info['peisong_info'].'</td></tr>';
        }else if($info['peisong_type'] == 3){
            echo '<tr><td align="right"><b>'.$Lang['order_peisong_type'].$fenghao.'</b></td><td>'.$Lang['order_peisong_type_3'].'</td></tr>';
            echo '<tr><td align="right"><b>'.$Lang['order_peisong_name3'].$fenghao.'</b></td><td>'.$info['peisong_name'].'</td></tr>';
            echo '<tr><td align="right"><b>'.$Lang['order_peisong_info3'].$fenghao.'</b></td><td>'.$info['peisong_info'].'</td></tr>';
        }
        if($info['hexiao_time'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['order_hexiao_time'].$fenghao.'</b></td><td>'.dgmdate($info['hexiao_time'], 'Y-m-d H:i',$tomSysOffset).'</td></tr>';
        }else{
            echo '<tr><td align="right"><b>'.$Lang['order_hexiao_time'].$fenghao.'</b></td><td>-</td></tr>';
        }
        
        showtablefooter();/*Dism��taobao��com*/
        
        showformheader($modFromUrl.'&act=info&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_order_order_status'] . '</th></tr>';
        showtablefooter();/*Dism��taobao��com*/
        showtableheader();
        echo '<tr><td align="right"><b>'.$Lang['order_order_status'].'</b></td><td>';
        foreach ($orderStatusArray as $key => $value){
            if($key == $info['order_status']){
                echo '<input type="radio" name="order_status" value="'.$key.'" checked><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }else{
                echo '<input type="radio" name="order_status" value="'.$key.'" ><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }
        }
        echo '</td></tr>';
       // echo '<tr><td>&nbsp;</td><td colspan="14" ><b><font color="#fd0303">(' . $Lang['order_order_status_msg'] . ')</font></b></td></tr>';
        tomshowsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();/*Dism-taobao_com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delete'){
    
    C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    set_list_url("tom_tcchoujiang_admin_user_list");
    
    $tcchoujiang_id  = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):0;
    $tel             = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $order_status    = isset($_GET['order_status'])? intval($_GET['order_status']):0;
    
    $pagesize = 100;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page - 1)*$pagesize;	
    
    $where = "";
    
    if(!empty($tcchoujiang_id)){
        $where.= " AND tcchoujiang_id={$tcchoujiang_id} ";
    }
    if(!empty($tel)){
        $where.= " AND tel= '{$tel}'";
    }
    if(!empty($order_status)){
        $where.= " AND order_status={$order_status} ";
    }
    
    $count  = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_count($where);
    $orderList = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_list($where,"ORDER BY order_time DESC,id DESC",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&tel={$tel}&order_status={$order_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_search_list'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['order_tcchoujiang_id'].'</b></td><td><input name="tcchoujiang_id" type="text" value="'.$tcchoujiang_id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['order_tel'].'</b></td><td><input name="tel" type="text" value="'.$tel.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_order_status'] . '</b></td><td><select name="order_status" >';
    echo '<option value="0">'.$Lang['order_order_status'].'</option>';
    foreach ($orderStatusArray as $key => $value){
        if($key == $order_status){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select></td></tr>';
   
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();/*Dism-taobao_com*/
    
    tomshownavheader();
    tomshownavli($Lang['order_list_dao'],$adminBaseUrl.'&tmod=doDao',false);
    tomshownavfooter();
   
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['order_user_id'] . '</th>';
    echo '<th>' . $Lang['order_tcchoujiang_id'] . '</th>';
    echo '<th>' . $Lang['order_xm'] . '</th>';
    echo '<th>' . $Lang['order_tel'] . '</th>';
    echo '<th>' . $Lang['order_name'] . '</th>';
    echo '<th>' . $Lang['order_order_status'] . '</th>';
    echo '<th>' . $Lang['order_time'] . '</th>';
    echo '<th>' . $Lang['order_hexiao_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($orderList as $key => $value){
        $prizeInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_by_id($value['prize_id']);
        $order_time = dgmdate($value['order_time'], 'Y-m-d H:i:s',$tomSysOffset);
        if($value['hexiao_time'] <= 0){
            $hexiao_time = "--";
        }else{
            $hexiao_time = dgmdate($value['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset);
        }
        echo '<tr>';
        echo '<td>' . $value['user_id'] . '</td>';
        echo '<td>' . $value['tcchoujiang_id'] . '</td>';
        echo '<td>' . $value['xm'] . '</td>';
        if(!empty($value['tel'])){
            echo '<td>' . $value['tel'] . '</td>';
        }else{
            echo '<td>' ."--". '</td>';
        }
        echo '<td>' . $value['prize_name'] . '</td>';
        echo '<td>' . $orderStatusArray[$value['order_status']] . '</td>';
        echo '<td>' . $order_time . '</td>';
        echo '<td>' . $hexiao_time . '</td>';
        echo '<td style="line-height: 22px;">';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['order_info'] . '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delete&id='.$value['id'].'&formhash='.FORMHASH.'\')">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
}

$jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;