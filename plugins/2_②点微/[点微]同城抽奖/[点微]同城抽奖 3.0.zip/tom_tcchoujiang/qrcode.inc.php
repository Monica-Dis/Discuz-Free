<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tcchoujiangConfig  = $_G['cache']['plugin']['tom_tcchoujiang'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

if('utf-8' != CHARSET) {
    if(defined('IN_MOBILE')) {}else{
        foreach($_POST AS $pk => $pv) {
            if(!is_numeric($pv)) {
                $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
            }
        }
    }
}

$share_url		= isset($_GET['share_url'])? daddslashes($_GET['share_url']):'';
$tcchoujiang_id = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):0;
$user_id		= isset($_GET['user_id'])? intval($_GET['user_id']):0;

if($user_id <= 0){
    echo 'LG|notomweixin';exit;
}

$tcchoujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);

$picurl = '';
if(!preg_match('/^http/', $tcchoujiangInfo['picurl'])){
    if(strpos($tcchoujiangInfo['picurl'], 'source/plugin/') === false){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcchoujiangInfo['picurl'];
    }else{
        $picurl = $_G['siteurl'].$tcchoujiangInfo['picurl'];
    }
}else{
    $picurl = $tcchoujiangInfo['picurl'];
}

$share_url = $share_url."&wxqrcode=tcchoujiangguanzu_".$tcchoujiang_id."_".$user_id;

$wxqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/data/qrcode/'.md5($share_url).'_wxqrcode.png';
$wxqrcodeUrl = 'source/plugin/tom_tcchoujiang/data/qrcode/'.md5($share_url).'_wxqrcode.png';

$tempDir = "/source/plugin/tom_tcchoujiang/data/qrcode/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0777); 
}

if($tcchoujiangConfig['open_wxqrcode'] == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_weixin/tom_weixin.inc.php')){
    
    $qrcodeKey  = md5($share_url);
    $qrcodeInfo = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_by_qkey($qrcodeKey);
    $qrcodeId = 0;
    if($qrcodeInfo){
        $qrcodeId = $qrcodeInfo['id'];
        $updateData = array();
        $updateData['title']  = $tcchoujiangInfo['title'];
        $updateData['picurl'] = $picurl;
        $updateData['desc']   = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        C::t('#tom_weixin#tom_weixin_qrcode')->update($qrcodeId,$updateData);
    }else{
        $insertData = array();
        $insertData['qkey']         = $qrcodeKey;
        $insertData['title']        = $tcchoujiangInfo['title'];
        $insertData['picurl']       = $picurl;
        $insertData['desc']         = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        $insertData['link']         = $share_url;
        $insertData['extend']       = 'tcchoujiangguanzu';
        $insertData['user_id']      = $user_id;
        $insertData['tcchoujiang_id']    = $tcchoujiang_id;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_weixin#tom_weixin_qrcode')->insert($insertData);
        $qrcodeId = C::t('#tom_weixin#tom_weixin_qrcode')->insert_id();
    }
    
    if(file_exists($wxqrcodeImg)){
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        $access_token = $weixinClass->get_access_token();

        $dateStr = '{"expire_seconds": 2592000, "action_name": "QR_SCENE", "action_info": {"scene": {"scene_id": '.$qrcodeId.'}}}';
        $response   = postDataCurl($dateStr, 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token);
        $returnData = json_decode($response,true);
        if(isset($returnData['ticket']) &&  !empty($returnData['ticket'])){
            $wx_pic_content = getHtml('https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$returnData['ticket']);
            if(false === file_put_contents($wxqrcodeImg,$wx_pic_content)){
            }
        }
    }
    
}else{
    echo 'QR|notomweixin';exit;
}

echo 'OK|'.$wxqrcodeUrl;exit;

function getHtml($url){
    if(function_exists('curl_init')){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $return = curl_exec($ch);
        curl_close($ch); 
        return $return;
    }
    return false;
}

function postDataCurl($data, $url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,FALSE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $return = curl_exec($ch);
    if($return){
        curl_close($ch);
        return $return;
    } else { 
        $error = curl_errno($ch);
        curl_close($ch);
        return false;
    }
}