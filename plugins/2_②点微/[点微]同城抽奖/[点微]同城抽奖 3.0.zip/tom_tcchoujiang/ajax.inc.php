<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
loaducenter();
$formhash = FORMHASH;
$tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
$sql_in_site_ids = $site_id;
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login_ajax.php';
include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/class/function.core.php';
if ($_GET['act'] == 'list' && $_GET['formhash'] == FORMHASH) {
	include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/module/list.php';
} elseif ($_GET['act'] == 'add_bm' && $_GET['formhash'] == FORMHASH) {
	$xm = isset($_GET['xm']) ? daddslashes(diconv(urldecode($_GET['xm']), 'utf-8')) : '';
	$tel = isset($_GET['tel']) ? daddslashes($_GET['tel']) : '';
	$tcchoujiang_id = isset($_GET['tcchoujiang_id']) ? intval($_GET['tcchoujiang_id']) : '';
	$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : '';
	if (empty($xm) || empty($tel)) {
		echo 404;
		exit(0);
	}
	$choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);
	$insertData = array();
	$insertData['tcchoujiang_id'] = $tcchoujiang_id;
	$insertData['user_id'] = $user_id;
	$insertData['xm'] = $xm;
	$insertData['tel'] = $tel;
	$insertData['cj_times'] = $choujiangInfo['cj_times'];
	$insertData['time_key'] = $nowDayTime;
	$insertData['add_time'] = TIMESTAMP;
	C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->insert($insertData);
	echo 200;
	exit(0);
} elseif ($_GET['act'] == 'cj' && $formhash == FORMHASH) {
	include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/module/cj.php';
} elseif ($_GET['act'] == 'clicks' && $formhash == FORMHASH) {
	$tcchoujiang_id = intval($_GET['tcchoujiang_id']) > 0 ? intval($_GET['tcchoujiang_id']) : 0;
	DB::query('UPDATE ' . DB::table('tom_tcchoujiang') . (' SET clicks=clicks + 1 WHERE id=\'' . $tcchoujiang_id . '\' '), 'UNBUFFERED');
	echo 1;
	exit(0);
} elseif ($_GET['act'] == 'answer_status' && $_GET['formhash'] == FORMHASH) {
	$bm_id = intval($_GET['bm_id']) > 0 ? intval($_GET['bm_id']) : 0;
	DB::query('UPDATE ' . DB::table('tom_tcchoujiang_bm') . (' SET answer_status=1 WHERE id=\'' . $bm_id . '\' '), 'UNBUFFERED');
	echo 1;
	exit(0);
} elseif ($_GET['act'] == 'get_order_search_url' && $_GET['formhash'] == FORMHASH) {
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$url = $_G['siteurl'] . ('plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=myorder&type=' . $type . '&keyword=') . urlencode(trim($keyword));
	$url = tom_link_replace($url);
	echo $url;
	exit(0);
} elseif ($_GET['act'] == 'updateStatus' && $_GET['formhash'] == FORMHASH && $userStatus) {
	$tcchoujiang_id = isset($_GET['tcchoujiang_id']) ? intval($_GET['tcchoujiang_id']) : 0;
	$status = isset($_GET['status']) ? intval($_GET['status']) : 0;
	$choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);
	if ($choujiangInfo['user_id'] != $__UserInfo['id']) {
		echo '404';
		exit(0);
	}
	if ($status == 1) {
		DB::query('UPDATE ' . DB::table('tom_tcchoujiang') . (' SET status=1 WHERE id=\'' . $tcchoujiang_id . '\' '), 'UNBUFFERED');
	} elseif ($status == 2) {
		DB::query('UPDATE ' . DB::table('tom_tcchoujiang') . (' SET status=2 WHERE id=\'' . $tcchoujiang_id . '\' '), 'UNBUFFERED');
	}
	echo 200;
	exit(0);
} elseif ($_GET['act'] == 'new_order') {
	$callback = $_GET['callback'];
	$tcchoujiang_id = intval($_GET['tcchoujiang_id']) > 0 ? intval($_GET['tcchoujiang_id']) : 0;
	$orderListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_list(' AND tcchoujiang_id = ' . $tcchoujiang_id . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY order_time DESC,id DESC', 0, 6);
	$outOrderInfo = array();
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			$cookieOrderid = getcookie('tom_tcchoujiang_new_order_id' . $value['id']);
			if (!$cookieOrderid) {
				$outOrderInfo = $value;
				dsetcookie('tom_tcchoujiang_new_order_id' . $value['id'], 1, 21600);
				break;
			}
		}
	}
	$outArr = array('status' => 0);
	if (!empty($outOrderInfo) && $outOrderInfo['user_id'] > 0) {
		$outArr['status'] = 1;
		$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($outOrderInfo['user_id']);
		$prizeInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_by_id($outOrderInfo['prize_id']);
		$outArr['picurl'] = $userInfo['picurl'];
		$outArr['prizename'] = diconv($prizeInfo['name'], CHARSET, 'utf-8');
	}
	$outStr = '';
	$outStr = json_encode($outArr);/*Dism-taobao_com*/
	if ($callback) {
		$outStr = $callback . '(' . $outStr . ')';
	}
	echo $outStr;
	exit(0);
} else {
	echo 'error';
	exit(0);
}