<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS pre_tom_tcchoujiang;
DROP TABLE IF EXISTS pre_tom_tcchoujiang_answer;
DROP TABLE IF EXISTS pre_tom_tcchoujiang_bm;
DROP TABLE IF EXISTS pre_tom_tcchoujiang_focuspic;
DROP TABLE IF EXISTS pre_tom_tcchoujiang_log;
DROP TABLE IF EXISTS pre_tom_tcchoujiang_order;
DROP TABLE IF EXISTS pre_tom_tcchoujiang_photo;
DROP TABLE IF EXISTS pre_tom_tcchoujiang_prize;
DROP TABLE IF EXISTS pre_tom_tcchoujiang_prize_extend;
DROP TABLE IF EXISTS pre_tom_tcchoujiang_prize_log;
DROP TABLE IF EXISTS pre_tom_tcchoujiang_share;

EOF;

runquery($sql);

$finish = TRUE;