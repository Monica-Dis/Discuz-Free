<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = '20200110';
if (CHARSET == 'gbk') {
	include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/config/config.gbk.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/config/config.utf8.php';
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$tcchoujiangConfig['tongcheng_hosts'] = trim($tcchoujiangConfig['tongcheng_hosts']);
$tcchoujiangConfig['chou_hosts'] = trim($tcchoujiangConfig['chou_hosts']);
$__OnlyHosts = 0;
$__TongchengHost = '';
if ($tcchoujiangConfig['open_only_hosts'] == 1 && !empty($tcchoujiangConfig['tongcheng_hosts']) && !empty($tcchoujiangConfig['chou_hosts'])) {
	$__OnlyHosts = 1;
	$urlTmp = $weixinClass->get_url();
	if (strpos($urlTmp, $tcchoujiangConfig['chou_hosts']) === false && strpos($urlTmp, $tcchoujiangConfig['tongcheng_hosts']) !== false) {
		$newUrlTmp = str_replace($tcchoujiangConfig['tongcheng_hosts'], $tcchoujiangConfig['chou_hosts'], $urlTmp);
		if ($tcchoujiangConfig['must_http'] == 1) {
			$newUrlTmp = str_replace('https', 'http', $newUrlTmp);
		}
		tomheader('location:' . $newUrlTmp);
		exit(0);
	}
	preg_match('#((http|https)://([^?]*)/)([a-z_0-9]*.php)#', $urlTmp, $urlmatches2);
	if (strpos($urlmatches2['0'], $tcchoujiangConfig['tongcheng_hosts']) === false && strpos($urlTmp, $tcchoujiangConfig['chou_hosts']) !== false) {
		$__TongchengHost = str_replace($tcchoujiangConfig['chou_hosts'], $tcchoujiangConfig['tongcheng_hosts'], $urlmatches2['0']);
		$__TongchengHost = rtrim($__TongchengHost, $urlmatches2['4']);
		if ($tcchoujiangConfig['must_http'] == 1) {
			if (strpos($__TongchengHost, 'https') === false) {
				$__TongchengHost = str_replace('http', 'https', $__TongchengHost);
			}
		}
	}
}
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcchoujiangConfig['wx_share_title'];
$shareDesc = $tcchoujiangConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=index';
$shareLogo = $tcchoujiangConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$ajaxLoadListUrl = 'plugin.php?id=tom_tcchoujiang:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
if ($_GET['mod'] == 'index') {
	if ($tcchoujiangConfig['open_region'] == 1) {
		check_region();
	}
	$chou_status = intval($_GET['chou_status']) > 0 ? intval($_GET['chou_status']) : 0;
	$focuspicListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_focuspic')->fetch_all_list(' AND site_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	foreach ($focuspicListTmp as $key => $value) {
		$focuspicList[$key] = $value;
		if (!preg_match('/^http/', $value['picurl'])) {
			if (strpos($value['picurl'], 'source/plugin/tom_tcchoujiang/') === false) {
				$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
			} else {
				$picurl = $value['picurl'];
			}
		} else {
			$picurl = $value['picurl'];
		}
		$focuspicList[$key]['picurl'] = $picurl;
	}
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcchoujiang:ajax&site=' . $site_id . '&act=list&chou_status=' . $chou_status . '&formhash=' . $formhash;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/images/index.js';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcchoujiang:index');
	echo '<script src="source/plugin/tom_tcchoujiang/images/index.js"></script>';
} elseif ($_GET['mod'] == 'details') {
	if ($tcchoujiangConfig['open_region'] == 1) {
		check_region();
	}
	$tcchoujiang_id = isset($_GET['tcchoujiang_id']) ? intval($_GET['tcchoujiang_id']) : 0;
	$cjid = isset($_GET['cjid']) ? intval($_GET['cjid']) : 0;
	if ($tcchoujiang_id == 0) {
		$tcchoujiang_id = $cjid;
	}
	$choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);
	if ($choujiangInfo['status'] != 1 && $choujiangInfo['shenhe_status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$hexiao_time = dgmdate($choujiangInfo['hexiao_time'], 'Y-m-d H:i', $tomSysOffset);
	$content = stripslashes($choujiangInfo['content']);
	$guize = stripslashes($choujiangInfo['guize']);
	if (!preg_match('/^http/', $choujiangInfo['picurl'])) {
		if (strpos($choujiangInfo['picurl'], 'source/plugin/tom_tcchoujiang/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $choujiangInfo['picurl'];
		} else {
			$picurl = $_G['siteurl'] . $choujiangInfo['picurl'];
		}
	} else {
		$picurl = $choujiangInfo['picurl'];
	}
	if (!preg_match('/^http/', $choujiangInfo['toppic'])) {
		if (strpos($choujiangInfo['toppic'], 'source/plugin/tom_tcchoujiang/') === false) {
			$toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $choujiangInfo['toppic'];
		} else {
			$toppic = $choujiangInfo['toppic'];
		}
	} else {
		$toppic = $choujiangInfo['toppic'];
	}
	$clicksNum = $choujiangInfo['clicks'] + $choujiangInfo['virtual_clicks'];
	$clicksNumTxt = $clicksNum;
	if ($clicksNum > 1000000) {
		$clicksNumTmp = $clicksNum / 10000;
		$clicksNumTxt = number_format($clicksNumTmp, 0);
	} elseif ($clicksNum > 10000) {
		$clicksNumTmp = $clicksNum / 10000;
		$clicksNumTxt = number_format($clicksNumTmp, 2);
	}
	$bmCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_all_count(' AND tcchoujiang_id = ' . $tcchoujiang_id);
	$bmNum = $choujiangInfo['virtual_bmnum'] + $bmCount;
	$start_time = dgmdate($choujiangInfo['start_time'], 'Y/m/d H:i');
	$end_time = dgmdate($choujiangInfo['end_time'], 'Y/m/d H:i');
	$daojishiBox = 0;
	$syTime = 0;
	if (TIMESTAMP < $choujiangInfo['start_time']) {
		$daojishiBox = 1;
		$syTime = ($choujiangInfo['start_time'] - TIMESTAMP) * 1000;
	} else {
		if (TIMESTAMP > $choujiangInfo['end_time']) {
			$daojishiBox = 2;
		} else {
			if ($choujiangInfo['end_time'] > TIMESTAMP) {
				$daojishiBox = 3;
				$syTime = ($choujiangInfo['end_time'] - TIMESTAMP) * 1000;
			}
		}
	}
	$choujiangInfo['chou_status'] = update_chou_status($choujiangInfo);
	$prizeList = array();
	for ($i = 1; $i <= 5; $i++) {
		$prizeList[$i] = array('id' => 0, 'type' => lang('plugin/tom_tcchoujiang', 'prize_kong'), 'name' => lang('plugin/tom_tcchoujiang', 'prize_kong_desc'), 'picurl' => 'source/plugin/tom_tcchoujiang/images/thanks.png', 'num' => 0, 'chance' => 0);
	}
	$prizeList[6] = array('id' => 0, 'type' => lang('plugin/tom_tcchoujiang', 'prize_xinyun'), 'name' => lang('plugin/tom_tcchoujiang', 'prize_xinyun_desc'), 'picurl' => '', 'num' => 0, 'chance' => 0);
	$prizeListTmpTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_list(' AND tcchoujiang_id = ' . $tcchoujiang_id . ' ', 'ORDER BY type ASC,id DESC', 0, 50);
	$prizeListTmp = $tcshopListIds = array();
	if (is_array($prizeListTmpTmp) && !empty($prizeListTmpTmp)) {
		foreach ($prizeListTmpTmp as $key => $value) {
			$prizeListTmp[$key] = $value;
			$tcshopListIds[] = $value['tcshop_id'];
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tcchoujiang/') === false) {
					$prize_pic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$prize_pic = $value['picurl'];
				}
			} else {
				$prize_pic = $value['picurl'];
			}
			if (isset($prizeList[$value['type']])) {
				$prizeList[$value['type']] = $value;
				$prizeList[$value['type']]['picurl'] = $prize_pic;
			}
		}
	}
	$orderCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_count(' AND tcchoujiang_id = ' . $tcchoujiang_id . ' ');
	$orderData = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_list(' AND tcchoujiang_id = ' . $tcchoujiang_id . ' ', 'ORDER BY order_time DESC,id DESC', 0, 10);
	$orderList = array();
	if (is_array($orderData) && !empty($orderData)) {
		foreach ($orderData as $key => $value) {
			$orderList[$key] = $value;
			$orderList[$key]['order_time'] = dgmdate($value['order_time'], 'Y.m.d H:i', $tomSysOffset);
			$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			if ($tcchoujiangConfig['open_hidden_nickname'] == 1) {
				$userInfoTmp['nickname'] = cutstr($userInfoTmp['nickname'], 2, '***');
			}
			$orderList[$key]['userInfo'] = $userInfoTmp;
		}
	}
	$myorderCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_count(' AND tcchoujiang_id = ' . $tcchoujiang_id . ' AND user_id = ' . $__UserInfo['id'] . ' ');
	$bmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($tcchoujiang_id, $__UserInfo['id']);
	if ($bmInfo['id'] > 0) {
		$syTimes = $bmInfo['cj_times'];
	} else {
		if ($choujiangInfo['before_bm'] == 0) {
			$insertData = array();
			$insertData['tcchoujiang_id'] = $tcchoujiang_id;
			$insertData['user_id'] = $__UserInfo['id'];
			$insertData['xm'] = $__UserInfo['nickname'];
			$insertData['tel'] = $__UserInfo['tel'];
			$insertData['cj_times'] = $choujiangInfo['cj_times'];
			$insertData['time_key'] = $nowDayTime;
			$insertData['add_time'] = TIMESTAMP;
			C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->insert($insertData);
			$bm_id = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->insert_id();
			$bmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_id($bm_id);
			$syTimes = $choujiangInfo['cj_times'];
		} else {
			$syTimes = $choujiangInfo['cj_times'];
		}
	}
	if ($choujiangInfo['is_everyday'] == 1 && !empty($bmInfo) && $bmInfo['id'] > 0 && $bmInfo['time_key'] != $nowDayTime) {
		DB::query('UPDATE ' . DB::table('tom_tcchoujiang_bm') . (' SET time_key=' . $nowDayTime . ', cj_times=' . $choujiangInfo['cj_times'] . ', answer_status=0 WHERE user_id=\'' . $__UserInfo['id'] . '\' AND tcchoujiang_id = ' . $tcchoujiang_id . ' '), 'UNBUFFERED');
		$bmInfo['answer_status'] = 0;
		$syTimes = $choujiangInfo['cj_times'];
	}
	$bmStatus = 0;
	$zjStatus = 0;
	$noscoreStatus = 0;
	if ($bmInfo && $bmInfo['id'] > 0) {
		$bmStatus = 1;
	}
	if ($myorderCount >= $choujiangInfo['zj_times']) {
		$zjStatus = 1;
	}
	if ($zjStatus == 1) {
		$syTimes = 0;
	}
	if ($tcchoujiangConfig['allow_score_pay'] == 1 && $choujiangInfo['open_score_pay'] == 1 && $choujiangInfo['pay_score'] > 0) {
		if ($__UserInfo['score'] < $choujiangInfo['pay_score']) {
			$noscoreStatus = 1;
		}
	}
	$needAnswer_num = $choujiangInfo['answer_num'];
	$answerCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_answer')->fetch_all_count(' AND tcchoujiang_id = ' . $tcchoujiang_id . ' ');
	$answerData = C::t('#tom_tcchoujiang#tom_tcchoujiang_answer')->fetch_all_list(' AND tcchoujiang_id = ' . $tcchoujiang_id . ' ', 'ORDER BY asort ASC,id DESC', 0, 50);
	$answerList = array();
	$i = 0;
	if (is_array($answerData) && !empty($answerData)) {
		foreach ($answerData as $key => $value) {
			$i = $i + 1;
			$answerList[$key] = $value;
			$answerList[$key]['i'] = $i;
			$answerarray = array($value['ok_answer'], $value['no_answer1'], $value['no_answer2']);
			shuffle($answerarray);
			$answerList[$key]['answer'] = $answerarray;
		}
	}
	$photoListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_photo')->fetch_all_list(' AND tcchoujiang_id=' . $tcchoujiang_id . ' ', 'ORDER BY id ASC', 0, 10);
	$photoList = array();
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tcchoujiang/') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$photoList[$key] = $value;
			$photoList[$key]['picurl'] = $picurlTmp;
		}
	}
	$tcshopInfo = array();
	$tcshopList = array();
	if ($choujiangInfo['type'] == 1) {
		$tcshopListIdsStr = '99999999999';
		if (is_array($tcshopListIds) && !empty($tcshopListIds)) {
			$tcshopListIdsStr = implode(',', $tcshopListIds);
		}
		$tcshopList = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list('AND id IN(' . $tcshopListIdsStr . ') ', ' ORDER BY clicks DESC,id DESC ');
		if (is_array($tcshopList) && !empty($tcshopList)) {
			foreach ($tcshopList as $key => $value) {
				$tcshopList[$key] = $value;
				if (!preg_match('/^http/', $value['picurl'])) {
					if (strpos($value['picurl'], 'source/plugin/') === false) {
						$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
					} else {
						$picurlTmp = $_G['siteurl'] . $value['picurl'];
					}
				} else {
					$picurlTmp = $value['picurl'];
				}
				$tcshopList[$key]['picurl'] = $picurlTmp;
			}
		}
	} elseif ($choujiangInfo['type'] == 2) {
		$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($choujiangInfo['tcshop_id']);
		$open_wx_map = 0;
		if ($__IsWeixin == 1 && $tcshopConfig['open_wx_map'] == 1) {
			$open_wx_map = 1;
		}
		$baiduMapToName = $tcshopInfo['name'];
		$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
		$baiduMapToName = urlencode($baiduMapToName);
		$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tcshopInfo['latitude'] . ',' . $tcshopInfo['longitude'] . '&title=' . $baiduMapToName . '&content=&output=html';
	}
	$bmUrl = 'plugin.php?id=tom_tcchoujiang:ajax&site=' . $site_id . '&act=add_bm&tcchoujiang_id=' . $tcchoujiang_id . '&formhash=' . $formhash;
	$ajaxCjUrl = 'plugin.php?id=tom_tcchoujiang:ajax&site=' . $site_id . '&act=cj&tcchoujiang_id=' . $tcchoujiang_id . '&user_id=' . $__UserInfo['id'] . '&formhash=' . FORMHASH;
	$ajaxAnswerUrl = 'plugin.php?id=tom_tcchoujiang:ajax&site=' . $site_id . '&act=answer_status&bm_id=' . $bmInfo['id'] . '&formhash=' . $formhash;
	$ajaxClicksUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcchoujiang:ajax&site=' . $site_id . '&act=clicks&tcchoujiang_id=' . $tcchoujiang_id . '&formhash=') . FORMHASH;
	$shareTitle = $choujiangInfo['title'];
	$shareDesc = $choujiangInfo['title'];
	if (!empty($choujiangInfo['share_title'])) {
		$shareTitle = $choujiangInfo['share_title'];
	}
	if (!empty($choujiangInfo['share_desc'])) {
		$shareDesc = $choujiangInfo['share_desc'];
	}
	$shareUrl = $_G['siteurl'] . 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . ('&mod=details&cjid=' . $tcchoujiang_id);
	$shareLogo = $picurl;
	$haibaoShareUrl = $shareUrl;
	if ($__UserInfo['id'] > 0 && $tcchoujiangConfig['open_share'] == 1 && $choujiangInfo['share_num'] > 0) {
		$haibaoShareUrl = $shareUrl . ('&suid=' . $__UserInfo['id']);
		$suid = intval($_GET['suid']) > 0 ? intval($_GET['suid']) : 0;
		if ($suid > 0 && $__UserInfo['id'] != $suid) {
			$shareCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_share')->fetch_all_count(' AND tcchoujiang_id = ' . $tcchoujiang_id . ' AND user_id = ' . $suid . ' ');
			$isShare = C::t('#tom_tcchoujiang#tom_tcchoujiang_share')->fetch_all_count(' AND tcchoujiang_id = ' . $tcchoujiang_id . ' AND user_id = ' . $suid . ' AND to_user_id = ' . $__UserInfo['id'] . ' ');
			$shareBmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($tcchoujiang_id, $suid);
			if ($shareCount < $choujiangInfo['share_num'] && $isShare == 0 && $shareBmInfo['id'] > 0) {
				$insertData = array();
				$insertData['tcchoujiang_id'] = $tcchoujiang_id;
				$insertData['user_id'] = $suid;
				$insertData['to_user_id'] = $__UserInfo['id'];
				$insertData['time_key'] = $nowDayTime;
				$insertData['share_time'] = TIMESTAMP;
				C::t('#tom_tcchoujiang#tom_tcchoujiang_share')->insert($insertData);
				DB::query('UPDATE ' . DB::table('tom_tcchoujiang_bm') . (' SET cj_times=cj_times+1 WHERE id=\'' . $shareBmInfo['id'] . '\' '), 'UNBUFFERED');
				$insertData = array();
				$insertData['tcchoujiang_id'] = $tcchoujiang_id;
				$insertData['type_id'] = 4;
				$insertData['user_id'] = $suid;
				$insertData['change_num'] = 1;
				$insertData['log_time'] = TIMESTAMP;
				$insertData['beizu'] = '';
				$insertData['time_key'] = $nowDayTime;
				C::t('#tom_tcchoujiang#tom_tcchoujiang_log')->insert($insertData);
			}
		}
	}
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcchoujiang:details');
} elseif ($_GET['mod'] == 'chou') {
	$tcchoujiang_id = isset($_GET['tcchoujiang_id']) ? intval($_GET['tcchoujiang_id']) : 0;
	$choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($tcchoujiang_id);
	if ($choujiangInfo['status'] != 1 && $choujiangInfo['shenhe_status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$hexiao_time = dgmdate($choujiangInfo['hexiao_time'], 'Y-m-d H:i', $tomSysOffset);
	$guize = stripslashes($choujiangInfo['guize']);
	if (!preg_match('/^http/', $choujiangInfo['picurl'])) {
		if (strpos($choujiangInfo['picurl'], 'source/plugin/tom_tcchoujiang/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $choujiangInfo['picurl'];
		} else {
			$picurl = $_G['siteurl'] . $choujiangInfo['picurl'];
		}
	} else {
		$picurl = $choujiangInfo['picurl'];
	}
	if (!preg_match('/^http/', $choujiangInfo['bgpic'])) {
		if (strpos($choujiangInfo['bgpic'], 'source/plugin/tom_tcchoujiang/') === false) {
			$bgpic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $choujiangInfo['bgpic'];
		} else {
			$bgpic = $choujiangInfo['bgpic'];
		}
	} else {
		$bgpic = $choujiangInfo['bgpic'];
	}
	$prizeList = array();
	for ($i = 1; $i <= 5; $i++) {
		$prizeList[$i] = array('id' => 0, 'type' => lang('plugin/tom_tcchoujiang', 'prize_kong'), 'name' => lang('plugin/tom_tcchoujiang', 'prize_kong_desc'), 'picurl' => 'source/plugin/tom_tcchoujiang/images/thanks.png', 'num' => 0, 'chance' => 0);
	}
	$prizeList[6] = array('id' => 0, 'type' => lang('plugin/tom_tcchoujiang', 'prize_xinyun'), 'name' => lang('plugin/tom_tcchoujiang', 'prize_xinyun_desc'), 'picurl' => '', 'num' => 0, 'chance' => 0);
	$prizeListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_all_list(' AND tcchoujiang_id = ' . $tcchoujiang_id . ' ', 'ORDER BY type ASC,id DESC', 0, 50);
	if (is_array($prizeListTmp) && !empty($prizeListTmp)) {
		foreach ($prizeListTmp as $key => $value) {
			if (!preg_match('/^http:/', $value['picurl'])) {
				if (strpos($choujiangInfo['bgpic'], 'source/plugin/tom_tcchoujiang/') === false) {
					$prize_pic = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$prize_pic = $value['picurl'];
				}
			} else {
				$prize_pic = $value['picurl'];
			}
			if (isset($prizeList[$value['type']])) {
				$prizeList[$value['type']] = $value;
				$prizeList[$value['type']]['picurl'] = $prize_pic;
			}
		}
	}
	$orderData = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_list(' AND tcchoujiang_id = ' . $tcchoujiang_id . ' ', 'ORDER BY order_time DESC,id DESC', 0, 10);
	$orderList = array();
	if (is_array($orderData) && !empty($orderData)) {
		foreach ($orderData as $key => $value) {
			$orderList[$key] = $value;
			$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$userInfoTmp['nickname'] = cutstr($userInfoTmp['nickname'], 8, '***');
			$orderList[$key]['userInfo'] = $userInfoTmp;
		}
	}
	$myorderCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_count(' AND tcchoujiang_id = ' . $tcchoujiang_id . ' AND user_id = ' . $__UserInfo['id'] . ' ');
	$bmCount = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_all_count(' AND tcchoujiang_id = ' . $tcchoujiang_id);
	$bmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($tcchoujiang_id, $__UserInfo['id']);
	if ($bmInfo['id'] > 0) {
		$syTimes = $bmInfo['cj_times'];
	} else {
		$insertData = array();
		$insertData['tcchoujiang_id'] = $tcchoujiang_id;
		$insertData['user_id'] = $__UserInfo['id'];
		$insertData['xm'] = $__UserInfo['nickname'];
		$insertData['tel'] = $__UserInfo['tel'];
		if ($choujiangInfo['type'] == 3) {
			$insertData['cj_times'] = 0;
		} elseif ($choujiangInfo['type'] == 4) {
			$insertData['cj_times'] = $choujiangInfo['cj_times'];
		}
		$insertData['time_key'] = $nowDayTime;
		$insertData['add_time'] = TIMESTAMP;
		C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->insert($insertData);
		$bm_id = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->insert_id();
		$bmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_id($bm_id);
		$syTimes = $choujiangInfo['cj_times'];
	}
	if ($choujiangInfo['is_everyday'] == 1 && !empty($bmInfo) && $bmInfo['id'] > 0 && $bmInfo['time_key'] != $nowDayTime) {
		DB::query('UPDATE ' . DB::table('tom_tcchoujiang_bm') . (' SET time_key=' . $nowDayTime . ', cj_times=' . $choujiangInfo['cj_times'] . ' WHERE user_id=\'' . $__UserInfo['id'] . '\' AND tcchoujiang_id = ' . $tcchoujiang_id . ' '), 'UNBUFFERED');
		$syTimes = $choujiangInfo['cj_times'];
	}
	$bmStatus = 0;
	$zjStatus = 0;
	$noscoreStatus = 0;
	if (!empty($bmInfo) && $bmInfo['id'] > 0) {
		$bmStatus = 1;
	}
	if ($myorderCount >= $choujiangInfo['zj_times']) {
		$zjStatus = 1;
	}
	if ($zjStatus == 1) {
		$syTimes = 0;
	}
	if ($tcchoujiangConfig['allow_score_pay'] == 1 && $choujiangInfo['open_score_pay'] == 1 && $choujiangInfo['pay_score'] > 0) {
		if ($__UserInfo['score'] < $choujiangInfo['pay_score']) {
			$noscoreStatus = 1;
		}
	}
	$ajaxCjUrl = 'plugin.php?id=tom_tcchoujiang:ajax&site=' . $site_id . '&act=cj&tcchoujiang_id=' . $tcchoujiang_id . '&user_id=' . $__UserInfo['id'] . '&formhash=' . FORMHASH;
	$ajaxClicksUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcchoujiang:ajax&site=' . $site_id . '&act=clicks&tcchoujiang_id=' . $tcchoujiang_id . '&formhash=') . FORMHASH;
	$shareTitle = $choujiangInfo['title'];
	$shareDesc = $choujiangInfo['title'];
	if (!empty($choujiangInfo['share_title'])) {
		$shareTitle = $choujiangInfo['share_title'];
	}
	if (!empty($choujiangInfo['share_desc'])) {
		$shareDesc = $choujiangInfo['share_desc'];
	}
	$shareUrl = $_G['siteurl'] . 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . ('&mod=chou&cjid=' . $tcchoujiang_id);
	$shareLogo = $picurl;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcchoujiang:chou');
} elseif ($_GET['mod'] == 'prizelist') {
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$whereStr = ' AND user_id = ' . $__UserInfo['id'] . ' ';
	if ($type == 1) {
		$whereStr .= ' AND order_status = 1 ';
	} elseif ($type == 2) {
		$whereStr .= ' AND order_status = 2 ';
	} elseif ($type == 3) {
		$whereStr .= ' AND order_status = 3 ';
	}
	$orderStr = ' ORDER BY order_time DESC,id DESC ';
	$pagesize = 10;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_count($whereStr);
	$myorderData = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_list($whereStr, $orderStr, $start, $pagesize);
	$myorderList = array();
	if (is_array($myorderData) && !empty($myorderData)) {
		foreach ($myorderData as $key => $value) {
			$myorderList[$key] = $value;
			$myorderList[$key]['order_time'] = dgmdate($value['order_time'], 'Y-m-d H:i', $tomSysOffset);
			$prizeInfoTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_by_id($value['prize_id']);
			if (is_array($prizeInfoTmp) && !empty($prizeInfoTmp['picurl'])) {
				if (!preg_match('/^http/', $prizeInfoTmp['picurl'])) {
					if (strpos($prizeInfoTmp['picurl'], 'source/plugin/') === false) {
						$prizeInfoTmp['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $prizeInfoTmp['picurl'];
					} else {
						$prizeInfoTmp['picurl'] = $prizeInfoTmp['picurl'];
					}
				}
			}
			$myorderList[$key]['prize'] = $prizeInfoTmp;
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=prizelist&type=' . $type . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=prizelist&type=' . $type . '&page=' . $nextPage;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcchoujiang:prizelist');
} elseif ($_GET['mod'] == 'prizeinfo') {
	$order_no = !empty($_GET['order_no']) ? addslashes($_GET['order_no']) : '';
	$orderInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_by_order_no($order_no);
	$choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($orderInfo['tcchoujiang_id']);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);
	if ($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH) {
		if ('utf-8' != CHARSET) {
			if (!defined('IN_MOBILE')) {
				foreach ($_POST as $pk => $pv) {
					if (!is_numeric($pv)) {
						$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
					}
				}
			}
		}
		$address_id = intval($_GET['address_id']) > 0 ? intval($_GET['address_id']) : 0;
		$order_beizu = isset($_GET['order_beizu']) ? addslashes($_GET['order_beizu']) : '';
		$addressInfo = array('area_str' => '', 'info' => '');
		if ($address_id > 0) {
			$addressInfo = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
		}
		$updateData = array();
		$updateData['xm'] = $addressInfo['xm'];
		$updateData['tel'] = $addressInfo['tel'];
		$updateData['address'] = $addressInfo['area_str'] . ' ' . $addressInfo['info'];
		$updateData['address_id'] = $address_id;
		$updateData['order_beizu'] = $order_beizu;
		C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->update($orderInfo['id'], $updateData);
		if ($choujiangInfo['site_id'] == 1) {
			$sitename = $tongchengConfig['plugin_name'];
		} else {
			$siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($choujiangInfo['site_id']);
			$sitename = $siteInfo['name'];
		}
		$toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfo['user_id']);
		include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/templatesms.class.php';
		$access_token = $weixinClass->get_access_token();
		if ($access_token && !empty($toUser['openid'])) {
			$templateSmsClass = new templateSms($access_token, $_G['siteurl'] . ('plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=myorder'));
			$smsData = array('first' => '[' . $tcshopInfo['name'] . ']' . lang('plugin/tom_tcchoujiang', 'template_jkfahuo_first'), 'keyword1' => $sitename, 'keyword2' => dgmdate(TIMESTAMP, 'Y-m-d H:i', $tomSysOffset), 'remark' => '');
			$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
		}
		echo 200;
		exit(0);
	} elseif ($_GET['act'] == 'qianshou' && $_GET['formhash'] == FORMHASH) {
		if ($orderInfo['peisong_type'] == 1) {
			echo 500;
			exit(0);
		}
		$updateData = array();
		$updateData['order_status'] = 3;
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['hexiao_time'] = TIMESTAMP;
		C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->update($orderInfo['id'], $updateData);
		echo 200;
		exit(0);
	}
	$address_id = isset($_GET['address_id']) ? intval($_GET['address_id']) : 0;
	$address_back_url = $weixinClass->get_url();
	$address_back_url = preg_replace('/&address_id=[0-9]*/', '', $address_back_url);
	$address_back_url = urlencode($address_back_url);
	$setAddressStatus = 0;
	$setAddressUrl = '';
	$addressListCount = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_count(' AND uid=' . $__MemberInfo['uid'] . ' ');
	if ($addressListCount == 0) {
		$setAddressStatus = 1;
		$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $address_back_url);
	}
	$addressInfo = array();
	$addressInfoTmp = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
	if ($addressInfoTmp && !empty($addressInfoTmp['id'])) {
		$address_id = $addressInfoTmp['id'];
		$addressInfo = $addressInfoTmp;
	} else {
		$defaultAddressList = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_list(' AND uid=' . $__MemberInfo['uid'] . ' AND default_id=1 ', 'ORDER BY id DESC', 0, 1);
		if ($defaultAddressList && !empty($defaultAddressList['0']['id'])) {
			$address_id = $defaultAddressList['0']['id'];
			$addressInfo = $defaultAddressList['0'];
		} else {
			$setAddressStatus = 1;
			$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $address_back_url);
		}
	}
	$changeAddressUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&buying=1&address_id=' . $address_id . '&address_back_url=' . $address_back_url;
	$prizeInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_by_id($orderInfo['prize_id']);
	$prizePicurl = '';
	if (!preg_match('/^http/', $prizeInfo['picurl'])) {
		if (strpos($prizeInfo['picurl'], 'source/plugin/') === false) {
			$prizePicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $prizeInfo['picurl'];
		} else {
			$prizePicurl = $prizeInfo['picurl'];
		}
	} else {
		$prizePicurl = $prizeInfo['picurl'];
	}
	$hexiaoTimeStatus = 1;
	if (TIMESTAMP > $choujiangInfo['hexiao_time']) {
		$hexiaoTimeStatus = 2;
	}
	$hexiao_time = dgmdate($choujiangInfo['hexiao_time'], 'Y-m-d H:i', $tomSysOffset);
	$hexiaoUserInfo = array();
	if ($orderInfo['order_status'] == 3) {
		$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);
	}
	$extendInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_extend')->fetch_by_id($prizeInfo['extend_id']);
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tcshopConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$baiduMapToName = $tcshopInfo['name'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tcshopInfo['latitude'] . ',' . $tcshopInfo['longitude'] . '&title=' . $baiduMapToName . '&content=&output=html';
	$qrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($_G['siteurl'] . 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . ('&mod=orderhexiao&hexiao_no=' . $orderInfo['hexiao_no']));
	$saveUrl = 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=prizeinfo&act=save&formhash=' . $formhash;
	$qianshouUrl = 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=prizeinfo&act=qianshou&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcchoujiang:prizeinfo');
} elseif ($_GET['mod'] == 'myorder') {
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 100);
	$tcshopListIds = array();
	if (is_array($tcshopListTmp) && !empty($tcshopListTmp)) {
		foreach ($tcshopListTmp as $key => $value) {
			$tcshopListIds[] = $value['id'];
		}
	}
	$tcshopListIdsStr = '99999999999';
	if (is_array($tcshopListIds) && !empty($tcshopListIds)) {
		$tcshopListIdsStr = implode(',', $tcshopListIds);
	}
	$whereStr = ' AND tcshop_id IN(' . $tcshopListIdsStr . ') ';
	if ($type == 1) {
		$whereStr .= ' AND order_status = 1 ';
	} elseif ($type == 2) {
		$whereStr .= ' AND order_status = 2 ';
	} elseif ($type == 3) {
		$whereStr .= ' AND order_status = 3 ';
	}
	if (!empty($keyword)) {
		$whereStr .= ' AND tel =\'' . $keyword . '\' ';
	}
	$orderStr = ' ORDER BY order_time DESC,id DESC ';
	$pagesize = 10;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_count($whereStr);
	$count1 = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_count('AND tcshop_id IN(' . $tcshopListIdsStr . ') AND order_status = 1');
	$count3 = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_count('AND tcshop_id IN(' . $tcshopListIdsStr . ') AND order_status = 3');
	$orderData = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_list($whereStr, $orderStr, $start, $pagesize);
	$orderList = array();
	if (is_array($orderData) && !empty($orderData)) {
		foreach ($orderData as $key => $value) {
			$orderList[$key] = $value;
			$prizeInfoTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_by_id($value['prize_id']);
			if (is_array($prizeInfoTmp) && !empty($prizeInfoTmp['picurl'])) {
				if (!preg_match('/^http/', $prizeInfoTmp['picurl'])) {
					if (strpos($prizeInfoTmp['picurl'], 'source/plugin/') === false) {
						$prizeInfoTmp['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $prizeInfoTmp['picurl'];
					} else {
						$prizeInfoTmp['picurl'] = $_G['siteurl'] . $prizeInfoTmp['picurl'];
					}
				} else {
					$prizeInfoTmp['picurl'] = $prizeInfoTmp['picurl'];
				}
			}
			$orderList[$key]['prize'] = $prizeInfoTmp;
			$orderList[$key]['url'] = 'plugin.php?id=tom_tcchoujiang&site=' . $value['site_id'] . '&mod=myorderinfo&order_no=' . $value['order_no'];
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=myorder&type=' . $type . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=myorder&type=' . $type . '&page=' . $nextPage;
	$searchUrl = 'plugin.php?id=tom_tcchoujiang:ajax&site=' . $site_id . '&act=get_order_search_url';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcchoujiang:myorder');
} elseif ($_GET['mod'] == 'myorderinfo') {
	$order_no = !empty($_GET['order_no']) ? addslashes($_GET['order_no']) : '';
	$orderInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_by_order_no($order_no);
	$choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($orderInfo['tcchoujiang_id']);
	$prizeInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_by_id($orderInfo['prize_id']);
	if ($_GET['act'] == 'fahuo' && $_GET['formhash'] == FORMHASH) {
		if ('utf-8' != CHARSET) {
			if (!defined('IN_MOBILE')) {
				foreach ($_POST as $pk => $pv) {
					if (!is_numeric($pv)) {
						$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
					}
				}
			}
		}
		$peisong_name = isset($_GET['peisong_name']) ? addslashes($_GET['peisong_name']) : '';
		$peisong_info = isset($_GET['peisong_info']) ? addslashes($_GET['peisong_info']) : '';
		$updateData = array();
		$updateData['peisong_name'] = $peisong_name;
		$updateData['peisong_info'] = $peisong_info;
		$updateData['order_status'] = 2;
		$updateData['peisong_time'] = TIMESTAMP;
		C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->update($orderInfo['id'], $updateData);
		if (!empty($tcchoujiangConfig['template_fahuo'])) {
			include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/class/templatesms.class.php';
			$access_token = $weixinClass->get_access_token();
			$orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
			if ($access_token && !empty($orderUserInfoTmp['openid'])) {
				$templateSmsClass = new cjTemplateSms($access_token, $_G['siteurl'] . ('plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=prizeinfo&order_no=' . $order_no));
				$smsData = array('first' => lang('plugin/tom_tcchoujiang', 'template_fahuo_first'), 'keyword1' => $orderInfo['order_no'], 'keyword2' => $orderInfo['prize_name'], 'keyword3' => 1, 'keyword4' => '0', 'remark' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s', $tomSysOffset));
				$r = $templateSmsClass->sendSmsFahuo($orderUserInfoTmp['openid'], $tcchoujiangConfig['template_fahuo'], $smsData);
			}
		}
		echo 200;
		exit(0);
	} elseif ($_GET['act'] == 'qianshou' && $_GET['formhash'] == FORMHASH) {
		if ($orderInfo['peisong_type'] == 1) {
			echo 500;
			exit(0);
		}
		$updateData = array();
		$updateData['order_status'] = 3;
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['hexiao_time'] = TIMESTAMP;
		C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->update($orderInfo['id'], $updateData);
		echo 200;
		exit(0);
	}
	$prizePicurl = '';
	if (!preg_match('/^http/', $prizeInfo['picurl'])) {
		if (strpos($prizeInfo['picurl'], 'source/plugin/') === false) {
			$prizePicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $prizeInfo['picurl'];
		} else {
			$prizePicurl = $prizeInfo['picurl'];
		}
	} else {
		$prizePicurl = $prizeInfo['picurl'];
	}
	$hexiaoUserInfo = array();
	if ($orderInfo['order_status'] == 3) {
		$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);
	}
	$showQianshouBtn = 0;
	if ($orderInfo['order_status'] == 2 && $orderInfo['peisong_time'] > 0) {
		if (TIMESTAMP > $orderInfo['peisong_time'] + 86400 * $tcchoujiangConfig['goods_autoreceive']) {
			$showQianshouBtn = 1;
		}
	}
	$choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($orderInfo['tcchoujiang_id']);
	$hexiao_time = dgmdate($choujiangInfo['hexiao_time'], 'Y-m-d H:i', $tomSysOffset);
	$fahuoUrl = 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=myorderinfo&act=fahuo&formhash=' . $formhash;
	$qianshouUrl = 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=myorderinfo&act=qianshou&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcchoujiang:myorderinfo');
} elseif ($_GET['mod'] == 'orderhexiao') {
	$hexiao_no = isset($_GET['hexiao_no']) ? addslashes($_GET['hexiao_no']) : '';
	$orderInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_by_hexiao_no($hexiao_no);
	$choujiangInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($orderInfo['tcchoujiang_id']);
	$prizeInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize')->fetch_by_id($orderInfo['prize_id']);
	if ($_GET['act'] == 'hexiao' && $_GET['formhash'] == FORMHASH) {
		$hexiao_pwd = isset($_GET['hexiao_pwd']) ? addslashes($_GET['hexiao_pwd']) : '';
		if ($tcchoujiangConfig['hexiao_type'] == 2) {
			if (empty($prizeInfo['hexiao_pwd'])) {
				echo 301;
				exit(0);
			}
			if ($prizeInfo['hexiao_pwd'] != $hexiao_pwd) {
				echo 302;
				exit(0);
			}
		}
		$updateData = array();
		$updateData['order_status'] = 3;
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['hexiao_time'] = TIMESTAMP;
		C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->update($orderInfo['id'], $updateData);
		echo 200;
		exit(0);
	}
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);
	$prizePicurl = '';
	if (!preg_match('/^http/', $prizeInfo['picurl'])) {
		if (strpos($prizeInfo['picurl'], 'source/plugin/') === false) {
			$prizePicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $prizeInfo['picurl'];
		} else {
			$prizePicurl = $prizeInfo['picurl'];
		}
	} else {
		$prizePicurl = $prizeInfo['picurl'];
	}
	$isTcshopClerk = 0;
	$clerkListTmp = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(' AND tcshop_id=' . $orderInfo['tcshop_id'] . ' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 1);
	if (!empty($clerkListTmp[0]['id']) || $tcshopInfo['user_id'] == $__UserInfo['id']) {
		$isTcshopClerk = 1;
	}
	$showHexiaoBox = 1;
	if ($tcchoujiangConfig['hexiao_type'] == 1 && $isTcshopClerk == 0) {
		$showHexiaoBox = 2;
	}
	$hexiaoUserInfo = array();
	if ($orderInfo['order_status'] == 3) {
		$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);
	}
	$hexiaoUrl = 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=orderhexiao&act=hexiao&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcchoujiang:orderhexiao');
} elseif ($_GET['mod'] == 'myfabu') {
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$whereStr = ' AND user_id = ' . $__UserInfo['id'] . ' ';
	$orderStr = ' ORDER BY id DESC ';
	if ($type == 1) {
		$whereStr .= ' AND status = 1 AND shenhe_status = 1 ';
	} elseif ($type == 2) {
		$whereStr .= ' AND (shenhe_status = 2 OR shenhe_status = 3)';
		$orderStr = ' ORDER BY shenhe_status ASC, id DESC ';
	}
	$count = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_all_count(' ' . $whereStr . ' ');
	$choujiangListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_all_list($whereStr, $orderStr, $start, $pagesize);
	$choujiangList = array();
	foreach ($choujiangListTmp as $key => $value) {
		$choujiangList[$key] = $value;
		$choujiangList[$key]['start_time'] = dgmdate($value['start_time'], 'Y-m-d', $tomSysOffset);
		$choujiangList[$key]['end_time'] = dgmdate($value['end_time'], 'Y-m-d', $tomSysOffset);
		$choujiangList[$key]['hexiao_time'] = dgmdate($value['hexiao_time'], 'Y-m-d', $tomSysOffset);
		if (!preg_match('/^http/', $value['picurl'])) {
			if (strpos($value['picurl'], 'source/plugin/tom_tcchoujiang/') === false) {
				$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
			} else {
				$picurl = $value['picurl'];
			}
		} else {
			$picurl = $value['picurl'];
		}
		$choujiangList[$key]['picurl'] = $picurl;
		$choujiangList[$key]['link'] = 'plugin.php?id=tom_tcchoujiang&site=' . $value['site_id'] . '&mod=details&tcchoujiang_id=' . $value['id'];
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=myfabu&type=' . $type . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=myfabu&type=' . $type . '&page=' . $nextPage;
	$ajaxUpdateStatusUrl = 'plugin.php?id=tom_tcchoujiang:ajax&site=' . $site_id . '&act=updateStatus&&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcchoujiang:myfabu');
} elseif ($_GET['mod'] == 'fabu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/module/fabu.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/module/edit.php';
} elseif ($_GET['mod'] == 'editprize') {
	include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/module/editprize.php';
} elseif ($_GET['mod'] == 'editanswer') {
	include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/module/editanswer.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/module/upload.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/module/index.php';
}
tomoutput();