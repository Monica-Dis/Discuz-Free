<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$orderStatusArray = array(
    1 => '未兑换',
    2 => '已发货',
    3 => '已兑换',
);

$orderStatusColorArray = array(
    1 => '#fd0303',
    2 => '#0585d6',
    3 => '#1e9203',
);

$prize_list = array(
    1 => '一等奖',
    2 => '二等奖',
    3 => '三等奖',
    4 => '四等奖',
    5 => '五等奖',
);