<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = '';

$tom_tcchoujiang_field = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_all_field();
if (!isset($tom_tcchoujiang_field['share_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcchoujiang')." ADD `share_num` int(11) DEFAULT '0';\n";
}

$tom_tcchoujiang_answer_field = C::t('#tom_tcchoujiang#tom_tcchoujiang_answer')->fetch_all_field();
if (!isset($tom_tcchoujiang_answer_field['asort'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcchoujiang_answer')." ADD `asort` int(11) DEFAULT '10';\n";
}

$tom_tcchoujiang_prize_extend_field = C::t('#tom_tcchoujiang#tom_tcchoujiang_prize_extend')->fetch_all_field();
if (!isset($tom_tcchoujiang_prize_extend_field['tcmall_coupon_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcchoujiang_prize_extend')." ADD `tcmall_coupon_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcchoujiang_prize_extend_field['tczhaopin_vip_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcchoujiang_prize_extend')." ADD `tczhaopin_vip_id` int(11) DEFAULT '0';\n";
}

if (!empty($sql)) {
	runquery($sql);
}

$sql = <<<EOF
    CREATE TABLE IF NOT EXISTS `pre_tom_tcchoujiang_share` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `tcchoujiang_id` int(11) DEFAULT '0',
      `user_id` int(11) DEFAULT '0',
      `to_user_id` int(11) DEFAULT '0',
      `time_key` int(11) DEFAULT '0',
      `share_time` int(11) DEFAULT '0',
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
EOF;

    runquery($sql);

$finish = TRUE;