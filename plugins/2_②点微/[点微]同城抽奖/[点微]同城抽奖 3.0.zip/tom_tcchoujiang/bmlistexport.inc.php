<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/config/config.utf8.php';
}

$tcqianggouConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
$tomSysOffset = getglobal('setting/timeoffset');

$page           = isset($_GET['page'])? intval($_GET['page']):1;
$tcchoujiang_id       = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):0;

$pagesize = 5000;
$start = ($page-1)*$pagesize;

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $where = "";
    if(!empty($tcchoujiang_id)){
        $where.=" AND tcchoujiang_id={$tcchoujiang_id} ";
    }
    
    $bmListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
    $bmList = array();
    foreach ($bmListTmp as $key => $value) {
        $bmList[$key] = $value;
        $bmList[$key]['tcchoujiang_id']  = $value['tcchoujiang_id'];
        $bmList[$key]['xm']              = $value['xm'];
        $bmList[$key]['tel']             = $value['tel'];
        
    }

    $tcchoujiang_id = lang('plugin/tom_tcchoujiang','bm_tcchoujiang_id');
    $xm = lang('plugin/tom_tcchoujiang','bm_xm');
    $tel = lang('plugin/tom_tcchoujiang','bm_tel');
    
    $listData[] = array(
        $tcchoujiang_id,
        $xm,
        $tel,
    ); 
    foreach ($bmList as $v){
        $lineData = array();
        
        $lineData[] = $v['tcchoujiang_id'];
        $lineData[] = $v['xm'];
        $lineData[] = "'".$v['tel'];
        $listData[] = $lineData;
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=exportChoujiangBmlist.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}