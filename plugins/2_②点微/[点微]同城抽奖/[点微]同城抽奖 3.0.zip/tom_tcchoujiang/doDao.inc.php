<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tomSysOffset = getglobal('setting/timeoffset');

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/config/config.utf8.php';
}

$order_status       = isset($_GET['order_status'])? intval($_GET['order_status']):0;
$pagesize           = 1000;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$start              = ($page - 1)*$pagesize;	
$where = "";

if(!empty($order_status)){
    $where.= " AND order_status= {$order_status}";
}

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    $orderListTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_order')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    $orderList = array();
    foreach ($orderListTmp as $key => $value) {
        $orderList[$key]['xm']              = $value['xm'];
        $orderList[$key]['tel']             = $value['tel'];
        $orderList[$key]['prize_name']      = $value['prize_name'];
        $orderList[$key]['order_beizu']     = $value['order_beizu'];
        $orderList[$key]['address']         = $value['address'];
        $orderList[$key]['order_status']    = $orderStatusArray[$value['order_status']];
        
        $peisong_type = '';
        if($value['peisong_type'] == 1){
            $peisong_type = lang('plugin/tom_tcchoujiang','peisong_type_1');
        }else if($value['peisong_type'] == 2){
            $peisong_type = lang('plugin/tom_tcchoujiang','peisong_type_2');
        }else if($value['peisong_type'] == 3){
            $peisong_type = lang('plugin/tom_tcchoujiang','peisong_type_3');
        }else{
            $peisong_type = '--';
        }
        $orderList[$key]['peisong_type']    = $peisong_type;
        $peisong_time = '';
        if($value['peisong_time'] <=  0){
            $peisong_time = '--';
        }else{
            $peisong_time = dgmdate($value['peisong_time'],"Y-m-d H:i",$tomSysOffset);;
        }
        $orderList[$key]['peisong_time']  = $peisong_time;
        $orderList[$key]['order_time']    = dgmdate($value['order_time'],"Y-m-d H:i",$tomSysOffset);
        if($value['hexiao_time'] <=  0){
            $hexiao_time = '--';
        }else{
            $hexiao_time = dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset);;
        }
        $orderList[$key]['hexiao_time']  = $hexiao_time;
        
        
    }

    $user_xm       = lang('plugin/tom_tcchoujiang','zj_xm');
    $user_tel      = lang('plugin/tom_tcchoujiang','zj_tel');
    $prize_name    = lang('plugin/tom_tcchoujiang','zj_name');
    $order_status  = lang('plugin/tom_tcchoujiang','zj_order_status');
    $peisong_type  = lang('plugin/tom_tcchoujiang','peisong_type');
    $peisong_time  = lang('plugin/tom_tcchoujiang','peisong_time');
    $order_time    = lang('plugin/tom_tcchoujiang','order_time');
    $order_beizu   = lang('plugin/tom_tcchoujiang','order_beizu');
    $order_address = lang('plugin/tom_tcchoujiang','order_address');
    $hexiao_time   = lang('plugin/tom_tcchoujiang','hexiao_time');

    $listData[] = array($user_xm,$user_tel,$prize_name,$order_status,$peisong_type,$peisong_time,$order_time,$order_beizu,$order_address,$hexiao_time); 
    foreach ($orderList as $v){
        $lineData = array();
        $lineData[] = $v['xm'];
        $lineData[] = "'".$v['tel'];
        $lineData[] = $v['prize_name'];
        $lineData[] = $v['order_status'];
        $lineData[] = $v['peisong_type'];
        $lineData[] = $v['peisong_time'];
        $lineData[] = $v['order_time'];
        $lineData[] = $v['order_beizu'];
        $lineData[] = $v['address'];
        $lineData[] = $v['hexiao_time'];
        $listData[] = $lineData;
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=exportChoujiang.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}