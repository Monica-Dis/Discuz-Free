<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcchoujiang`;
CREATE TABLE `pre_tom_tcchoujiang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `bg_color` varchar(255) DEFAULT NULL,
  `font_color` tinyint(4) DEFAULT '1',
  `picurl` varchar(255) DEFAULT NULL,
  `toppic` varchar(255) DEFAULT NULL,
  `bgpic` varchar(255) DEFAULT NULL,
  `before_bm` tinyint(4) DEFAULT '0',
  `is_everyday` tinyint(4) DEFAULT '0',
  `is_answer` tinyint(4) DEFAULT '0',
  `answer_num` int(11) DEFAULT '0',
  `cj_times` int(11) DEFAULT '0',
  `zj_times` int(11) DEFAULT '0',
  `open_score_pay` tinyint(4) DEFAULT '0',
  `pay_score` int(11) DEFAULT '0',
  `share_num` int(11) DEFAULT '0',
  `start_time` int(11) DEFAULT '0',
  `end_time` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `admin_edit` int(11) DEFAULT '0',
  `guize` text,
  `content` mediumtext,
  `share_title` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `chou_status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '1',
  `mp3_link` varchar(255) DEFAULT NULL,
  `clicks` int(11) NOT NULL DEFAULT '0',
  `virtual_clicks` int(11) DEFAULT '0',
  `virtual_bmnum` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '10000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_type` (`type`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcchoujiang_answer`;
CREATE TABLE `pre_tom_tcchoujiang_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcchoujiang_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `ok_answer` varchar(255) DEFAULT NULL,
  `no_answer1` varchar(255) DEFAULT NULL,
  `no_answer2` varchar(255) DEFAULT NULL,
  `asort` int(11) DEFAULT '10',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcchoujiang_bm`;
CREATE TABLE `pre_tom_tcchoujiang_bm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcchoujiang_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `cj_times` int(11) DEFAULT '0',
  `answer_status` tinyint(4) DEFAULT '0',
  `time_key` int(10) unsigned DEFAULT '0',
  `guanzu_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcchoujiang_focuspic`;
CREATE TABLE `pre_tom_tcchoujiang_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcchoujiang_log`;
CREATE TABLE `pre_tom_tcchoujiang_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcchoujiang_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `change_num` int(11) DEFAULT '0',
  `beizu` varchar(255) DEFAULT NULL,
  `time_key` int(11) DEFAULT '0',
  `log_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcchoujiang_order`;
CREATE TABLE `pre_tom_tcchoujiang_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tcshop_id` int(11) DEFAULT '0',
  `tcchoujiang_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `order_no` varchar(255) DEFAULT NULL,
  `hexiao_no` varchar(255) DEFAULT NULL,
  `prize_id` int(11) DEFAULT '0',
  `prize_name` varchar(255) DEFAULT NULL,
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `address_id` int(11) DEFAULT '0',
  `order_beizu` varchar(255) DEFAULT NULL,
  `peisong_type` int(11) DEFAULT '1',
  `peisong_name` varchar(255) DEFAULT NULL,
  `peisong_info` varchar(255) DEFAULT NULL,
  `peisong_time` int(11) DEFAULT '0',
  `order_status` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcchoujiang_photo`;
CREATE TABLE `pre_tom_tcchoujiang_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcchoujiang_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tcchoujiang_id` (`tcchoujiang_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcchoujiang_prize`;
CREATE TABLE `pre_tom_tcchoujiang_prize` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcchoujiang_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `is_extend` int(11) DEFAULT '0',
  `extend_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `num` int(11) DEFAULT '0',
  `chance` int(11) NOT NULL DEFAULT '0',
  `hexiao_pwd` varchar(255) NOT NULL,
  `peisong_type` int(11) DEFAULT '1',
  `content` text,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcchoujiang_prize_extend`;
CREATE TABLE `pre_tom_tcchoujiang_prize_extend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `score_value` int(11) DEFAULT '0',
  `card_type_id` int(11) DEFAULT '0',
  `coupon_id` int(11) DEFAULT '0',
  `tcmall_coupon_id` int(11) DEFAULT '0',
  `tczhaopin_vip_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcchoujiang_prize_log`;
CREATE TABLE `pre_tom_tcchoujiang_prize_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_admin` int(11) DEFAULT '0',
  `prize_id` int(11) DEFAULT '1',
  `log_txt` text,
  `log_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcchoujiang_share`;
CREATE TABLE `pre_tom_tcchoujiang_share` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcchoujiang_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `to_user_id` int(11) DEFAULT '0',
  `time_key` int(11) DEFAULT '0',
  `share_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;