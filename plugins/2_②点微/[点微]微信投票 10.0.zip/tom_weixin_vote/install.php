<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_weixin_vote`;
CREATE TABLE `pre_tom_weixin_vote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `style_id` int(11) DEFAULT '1',
  `must_tel` int(11) DEFAULT '1',
  `must_gz` int(11) DEFAULT '0',
  `open_bianhao` int(11) DEFAULT '0',
  `close_webtp` int(11) DEFAULT '1',
  `start_time` int(11) DEFAULT '0',
  `end_time` int(11) DEFAULT '0',
  `pic_url` varchar(255) DEFAULT NULL,
  `focus_status` int(11) DEFAULT '0',
  `focus_pic1` varchar(255) DEFAULT NULL,
  `focus_pic_url1` varchar(255) DEFAULT NULL,
  `focus_pic2` varchar(255) DEFAULT NULL,
  `focus_pic_url2` varchar(255) DEFAULT NULL,
  `focus_pic3` varchar(255) DEFAULT NULL,
  `focus_pic_url3` varchar(255) DEFAULT NULL,
  `prize_txt` text,
  `content` text,
  `item_obj_name` varchar(255) DEFAULT NULL,
  `share_logo` varchar(255) DEFAULT NULL,
  `share_title` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `guanzu_qrcode` varchar(255) DEFAULT NULL,
  `guanzu_desc` varchar(255) DEFAULT NULL,
  `guanzu_url` varchar(255) DEFAULT NULL,
  `cj_status` int(11) DEFAULT '1',
  `cj_id` int(11) DEFAULT '0',
  `bm_status` int(11) DEFAULT '1',
  `ads_text` text,
  `mp3_link` varchar(255) DEFAULT NULL,
  `pic_err_url` varchar(255) DEFAULT NULL,
  `pic_err_msg` varchar(255) DEFAULT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `xuni_clicks` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '100',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_vote_cj`;
CREATE TABLE `pre_tom_weixin_vote_cj` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `time_key` int(11) DEFAULT NULL,
  `log_time` int(11) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_vote_item`;
CREATE TABLE `pre_tom_weixin_vote_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_id` int(11) DEFAULT NULL,
  `no` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `desc` text,
  `pic_url` varchar(255) DEFAULT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `num` int(11) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `paixu` int(11) DEFAULT '100',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_no` (`no`),
  KEY `item_num` (`num`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_vote_log`;
CREATE TABLE `pre_tom_weixin_vote_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `time_key` int(11) DEFAULT NULL,
  `log_time` int(11) DEFAULT NULL,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_vote_photo`;
CREATE TABLE `pre_tom_weixin_vote_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `pic_url` varchar(255) DEFAULT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `paixu` int(11) DEFAULT '100',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_weixin_vote_user`;
CREATE TABLE `pre_tom_weixin_vote_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_id` int(11) DEFAULT NULL,
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `paixu` int(11) DEFAULT '100',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
