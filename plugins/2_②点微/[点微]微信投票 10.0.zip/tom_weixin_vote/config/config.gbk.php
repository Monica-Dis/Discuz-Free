<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.cn
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$bgColorArray = array(
    1 => array(
        'name' => '��ɫ',
        'value' => '#2dcc70'
    ),
    2 => array(
        'name' => '��ɫ',
        'value' => '#C70303'
    ),
    3 => array(
        'name' => '��ɫ',
        'value' => '#DF0893'
    ),
    4 => array(
        'name' => '��ɫ',
        'value' => '#09ACDB'
    ),
    5 => array(
        'name' => '��ɫ',
        'value' => '#A34B01'
    ),
   
);

