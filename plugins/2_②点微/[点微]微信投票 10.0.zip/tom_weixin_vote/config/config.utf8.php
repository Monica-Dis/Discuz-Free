<?php

/*
   This is NOT a freeware, use is subject to license terms
   版权所有：TOM微信 www.tomwx.cn
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$bgColorArray = array(
    1 => array(
        'name' => '绿色',
        'value' => '#2dcc70'
    ),
    2 => array(
        'name' => '红色',
        'value' => '#C70303'
    ),
    3 => array(
        'name' => '紫色',
        'value' => '#DF0893'
    ),
    4 => array(
        'name' => '蓝色',
        'value' => '#09ACDB'
    ),
    5 => array(
        'name' => '褐色',
        'value' => '#A34B01'
    ),
   
);

