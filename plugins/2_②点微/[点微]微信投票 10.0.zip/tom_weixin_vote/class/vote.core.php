<?php

function tomdoing($_arg_0, $_arg_1)
{
	cpmsg($_arg_0, $_arg_1, "loadingform");
}
function formatLang($_arg_0)
{
	$_var_1 = array();
	if (is_array($_arg_0) && !empty($_arg_0)) {
		foreach ($_arg_0 as $_var_2 => $_var_3) {
			$_var_1[$_var_2] = htmlspecialchars_decode($_var_3);
		}
	}
	return $_var_1;
}
function tomloadcalendarjs()
{
	echo "<script type=\"text/javascript\" src=\"static/js/calendar.js\"></script>";
}
function set_list_url($_arg_0 = '')
{
	$_var_1 = '';
	foreach ($_GET as $_var_2 => $_var_3) {
		$_var_1 = $_var_1 . ($_var_2 . "=" . $_var_3 . "&");
	}
	$_var_1 = $_var_1 . "s=1";
	$_var_4 = 86400;
	dsetcookie($_arg_0, $_var_1, $_var_4);
	return false;
}
function get_list_url($_arg_0 = '')
{
	$_var_1 = getcookie($_arg_0);
	if ($_var_1 && !empty($_var_1)) {
		return $_var_1;
	}
	return false;
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = DISCUZ_ROOT . "./source/plugin/tom_weixin_vote/images/admin.js";
	echo "<script src=\"source/plugin/tom_weixin_vote/images/admin.js?v=20160105\"></script>";
	$_var_3 = DISCUZ_ROOT . "./source/plugin/tom_weixin_vote/images/index.js";
	$_var_6 = DISCUZ_ROOT . "./source/plugin/tom_weixin_vote/template/index.htm";