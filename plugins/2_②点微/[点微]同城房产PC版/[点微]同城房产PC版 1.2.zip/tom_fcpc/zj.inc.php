<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$fcpcConfig = $_G['cache']['plugin']['tom_fcpc'];
$tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20210729";

$fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
if($fangchanSetting && $fangchanSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_setting')->insert($insertData);
    $fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
}

## video start
$__ShowVideo = 0;
if($fangchanSetting['open_video'] == 1){
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/video.inc.php')){
        $__ShowVideo = 1;
    }
}
## video end

$pczjUrl = 'plugin.php?id=tom_fcpc:zj';
$pcadminUrl = 'plugin.php?id=tom_tcfangchan:pcadmin';
$ajaxUrl = 'plugin.php?id=tom_admin:ajax';
$uploadUrl = 'plugin.php?id=tom_admin:upload';
$baidumapUrl = 'plugin.php?id=tom_admin:baidumap';
$fangchanAjaxUrl = 'plugin.php?id=tom_tcfangchan:pcadminAjax';

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/config/pczj.lang.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/class/function.url.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/config/config.data.php';

$Lang = $pczjLang;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_pc.php';

$_G['m_siteurl'] = $_G['siteurl'];

$fcpcConfig['fangchan_hosts']    = trim($fcpcConfig['fangchan_hosts']);
$fcpcConfig['tongcheng_hosts']   = trim($fcpcConfig['tongcheng_hosts']);

if($fcpcConfig['open_fangchan_hosts'] == 1 && !empty($fcpcConfig['fangchan_hosts']) && !empty($fcpcConfig['tongcheng_hosts'])){
    
    $fcpcConfig['tongcheng_hosts']  = rtrim($fcpcConfig['tongcheng_hosts'], '/');
    $fcpcConfig['tongcheng_hosts']  = $fcpcConfig['tongcheng_hosts'].'/';
    
    $_G['m_siteurl'] = $fcpcConfig['tongcheng_hosts'];
    
}

## xiaofenlei start
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')){
    $xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
    $__ShowXiaofenlei = 1;
}
## xiaofenlei end

$index1Url = tom_fcpc_url('index',1);

if(!empty($_GET['tmod'])){
    if($_GET['tmod'] == 'home'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/home.php';
    }else if($_GET['tmod'] == 'index'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/index.php';
    }else if($_GET['tmod'] == 'myfangchanlist'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/myfangchanlist.php';
    }else if($_GET['tmod'] == 'add'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/add.php';
    }else if($_GET['tmod'] == 'choose_houses'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/choose_houses.php';
    }else if($_GET['tmod'] == 'edit'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/edit.php';
    }else if($_GET['tmod'] == 'mynewhouseslist'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/mynewhouseslist.php';
    }else if($_GET['tmod'] == 'newhousesadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/newhousesadd.php';
    }else if($_GET['tmod'] == 'newhousesedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/newhousesedit.php';
    }else if($_GET['tmod'] == 'newhouses_guanzulist'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/newhouses_guanzulist.php';
    }else if($_GET['tmod'] == 'doDaoNewhousesGuanzu'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/doDaoNewhousesGuanzu.php';
    }else if($_GET['tmod'] == 'guanzulist'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/guanzulist.php';
    }else if($_GET['tmod'] == 'myhouseslist'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/myhouseslist.php';
    }else if($_GET['tmod'] == 'housesadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/housesadd.php';
    }else if($_GET['tmod'] == 'housesedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/housesedit.php';
    }else if($_GET['tmod'] == 'houses_guanzulist'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/houses_guanzulist.php';
    }else if($_GET['tmod'] == 'myvisitorlist'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/myvisitorlist.php';
    }else if($_GET['tmod'] == 'myagent'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/myagent.php';
    }else if($_GET['tmod'] == 'agentadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/agentadd.php';
    }else if($_GET['tmod'] == 'choose_mendian'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/choose_mendian.php';
    }else if($_GET['tmod'] == 'agentedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/agentedit.php';
    }else if($_GET['tmod'] == 'mendianedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/mendianedit.php';
    }else if($_GET['tmod'] == 'mendianadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/mendianadd.php';
    }else if($_GET['tmod'] == 'myadviserlist'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/myadviserlist.php';
    }else if($_GET['tmod'] == 'adviseradd'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/adviseradd.php';
    }else if($_GET['tmod'] == 'adviseredit'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/adviseredit.php';
    }else if($_GET['tmod'] == 'adviserruzhu'){
        include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/adviserruzhu.php';
    }
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/zj/index.php';
}