<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPczjUrl = $pczjUrl."&tmod=home";

$agentInfo   = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
$mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_user_id($__UserInfo['id']);

$agentMendianInfo = array();

if($mendianInfo['user_id'] == $agentInfo['user_id']){
    $agentMendianInfo = $mendianInfo;
}else{
    if($agentInfo['id'] > 0){
        $agentMendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
    }
}

$syAgentTotalFabuNum = $syMendianTotalFabuNum = $openVisitorStatus = 0;

if($tcfangchanConfig['open_agent_vip'] == 1  && $agentInfo['id'] > 0 && $agentInfo['vip_id'] > 0){

    $agentVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
    if($agentVipInfo['open_visitor'] == 1){
        $openVisitorStatus = 1;
    }

    if($agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP && $agentVipInfo['total_fabu_num'] > 0){
        $agentFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND expire_status = 3 AND pay_type = 4 AND add_time > {$agentInfo['vip_add_time']}  ");
        if($agentVipInfo['total_fabu_num'] > $agentFangchanCount){
            $syAgentTotalFabuNum = $agentVipInfo['total_fabu_num'] - $agentFangchanCount;
        }
    }
}

if($tcfangchanConfig['open_mendian_vip'] == 1 && $agentMendianInfo['id'] > 0 && $agentMendianInfo['vip_id'] > 0){
    
    $agentMendianVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($agentMendianInfo['vip_id']);
    
    if($agentMendianVipInfo['open_visitor'] == 1){
        $openVisitorStatus = 1;
    }
    
    if($agentMendianInfo['expire_status'] == 1 && $agentMendianInfo['expire_time'] > TIMESTAMP){
        if($agentMendianVipInfo['total_agent_fabu_num'] > 0){
            $mendianFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND expire_status = 3 AND pay_type = 3 AND add_time > {$agentMendianInfo['vip_add_time']}  ");
            if($agentMendianVipInfo['total_agent_fabu_num'] > $mendianFangchanCount){
                $syMendianTotalFabuNum = $agentMendianVipInfo['total_agent_fabu_num'] - $mendianFangchanCount;
            }
        }
    }
}

$syAllTotalFabuNum = $syAgentTotalFabuNum + $syMendianTotalFabuNum;

if($openVisitorStatus == 1){
        
    $tcfangchanIdsArrTmp =  C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_id_list("AND user_id = {$__UserInfo['id']}");
    $tcfangchanIdsArr = array();
    if(is_array($tcfangchanIdsArrTmp) && !empty($tcfangchanIdsArrTmp)){
        foreach($tcfangchanIdsArrTmp as $key => $value){
            $tcfangchanIdsArr[] = $value['id'];
        }
    }

    $visitorCount = 0;
    if(is_array($tcfangchanIdsArr) && !empty($tcfangchanIdsArr)){
        $tcfangchanIdsStr = implode(',', $tcfangchanIdsArr);
        $visitorCount = C::t("#tom_tcfangchan#tom_tcfangchan_visitor_log")->fetch_all_count(" AND tcfangchan_id IN({$tcfangchanIdsStr}) ");
    }
}

$ershoufangCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'ershoufang' AND deleted = 0 ");
$chuzuCount      = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'chuzu' AND deleted = 0 ");
$shangpuCount    = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'shangpu' AND deleted = 0 ");
$xiezilouCount   = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'xiezilou' AND deleted = 0 ");
$changfangCount  = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'changfang' AND deleted = 0 ");
$cangkuCount     = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'cangku' AND deleted = 0 ");
$tudiCount       = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'tudi' AND deleted = 0 ");

if($tcfangchanConfig['open_newhouses_sale_adviser'] == 1){
    $adviserCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count("AND user_id = {$__UserInfo['id']}");
}

$showNewhousesManage = 0;
$newhousesManageInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_manage")->fetch_by_user_id($__UserInfo['id']);
if(is_array($newhousesManageInfo) && !empty($newhousesManageInfo)){
    $showNewhousesManage = 1;
    $newhousesCount  = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_count("AND user_id = {$__UserInfo['id']}");
}

if($tcfangchanConfig['open_houses'] == 1 && $agentInfo['id'] > 0){
    $housesCount  = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_count("AND user_id = {$__UserInfo['id']}");
}

if($mendianInfo['id'] > 0){
  
    $agentListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_user_id(" AND mendian_id={$mendianInfo['id']} ","ORDER BY id DESC");
    
    $agentUserIdArr = array();
    if(is_array($agentListTmp) && !empty($agentListTmp)){
        foreach($agentListTmp as $key => $value){
            $agentUserIdArr[] = $value['user_id'];
        }
    }
    if(is_array($agentUserIdArr) && !empty($agentUserIdArr)){
        $agentUserIdStr = implode(',', $agentUserIdArr);
        $where = " AND user_id IN ({$agentUserIdStr}) ";
    }else{
        $where = " AND user_id={$__UserInfo['id']}";
    }
    
    $md_ershoufangCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" {$where} AND model_id = 'ershoufang' AND deleted = 0 ");
    $md_chuzuCount      = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" {$where} AND model_id = 'chuzu' AND deleted = 0 ");
    $md_shangpuCount    = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" {$where} AND model_id = 'shangpu' AND deleted = 0 ");
    $md_xiezilouCount   = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" {$where} AND model_id = 'xiezilou' AND deleted = 0 ");
    $md_changfangCount  = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" {$where} AND model_id = 'changfang' AND deleted = 0 ");
    $md_cangkuCount     = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" {$where} AND model_id = 'cangku' AND deleted = 0 ");
    $md_tudiCount       = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" {$where} AND model_id = 'tudi' AND deleted = 0 ");
    $agentCount         = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_agent_count(" AND mendian_id = {$mendianInfo['id']}");
}

$agent_expire_time   = dgmdate($agentInfo['expire_time'],"Y-m-d H:i",$tomSysOffset);
$mendian_expire_time = dgmdate($mendianInfo['expire_time'],"Y-m-d H:i",$tomSysOffset);
$agent_top_time      = dgmdate($agentInfo['top_time'],"Y-m-d H:i",$tomSysOffset);
$mendian_top_time    = dgmdate($mendianInfo['top_time'],"Y-m-d H:i",$tomSysOffset);

$buyAgentVipUrl     = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=agentvip";    
$buyMendianVipUrl   = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mendianvip";   
$buyAgentTopUrl     = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=agentbuytop";   
$buyMendianTopUrl   = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mendianbuytop"; 

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:zj/home");