<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$adviserInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->fetch_all_list("AND user_id={$__UserInfo['id']}","ORDER BY id ASC", 0, 1);

if(is_array($adviserInfoTmp) && !empty($adviserInfoTmp)){
}else if(!empty($__UserInfo['tel'])){
    dheader('location:'.$pczjUrl."&tmod=adviserruzhu");exit;
}

$modPczjUrl = $pczjUrl."&tmod=myadviserlist";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'hide' && submitcheck('adviser_id')){
    $outArr = array(
        'code'=> 1,
    );

    $adviser_id = intval($_GET['adviser_id'])>0 ? intval($_GET['adviser_id']):0;
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->update($adviser_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('adviser_id')){
    $outArr = array(
        'code'=> 1,
    );

    $adviser_id = intval($_GET['adviser_id'])>0 ? intval($_GET['adviser_id']):0;
        
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->update($adviser_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$name               = isset($_GET['name'])? addslashes($_GET['name']):'';
$tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$newhouses_id       = isset($_GET['newhouses_id'])? intval($_GET['newhouses_id']):0;
$adviser_id         = isset($_GET['adviser_id'])? intval($_GET['adviser_id']):0;
$expire_status      = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$__CityInfo  = array('id'=>0,'name'=>'');
if($site_id > 1){
    $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
    if($sitesInfoTmp){
        $__SitesInfo = $sitesInfoTmp;
        if(!empty($__SitesInfo['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
            if($cityInfoTmp){
                $__CityInfo = $cityInfoTmp;
            }
        }
    }
}else if($site_id == 1){
    $cityInfoTmp = array();
    if(!empty($tongchengConfig['city_id'])){
        $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
    }
    if(!empty($cityInfoTmp)){
        $__CityInfo = $cityInfoTmp;
    }
}

$whereStr = " AND user_id={$__UserInfo['id']}";

if(!empty($name)){
    $name = str_replace(array('%', '_'),'',$name);
    $whereStr .= " AND name LIKE '%{$name}%' ";
}
if(!empty($tel)){
    $tel = str_replace(array('%', '_'),'',$tel);
    $whereStr .= " AND tel LIKE '%{$tel}%' ";
}
if($newhouses_id > 0){
    $whereStr .= " AND newhouses_id={$newhouses_id} ";
}
if($site_id > 0){
    $whereStr .= " AND site_id={$site_id} ";
}
if($adviser_id > 0){
    $whereStr .= " AND id={$adviser_id} ";
}
if($expire_status > 0){
    if($expire_status == 1){
        $whereStr.= " AND ((expire_status = 1 AND expire_time > ".TIMESTAMP.") OR (expire_status = 3)) ";
    }else if($expire_status == 2){
        $whereStr.= " AND expire_status = 2 ";
    }
}
if(!empty($shenhe_status)){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}

$order = "ORDER BY asort ASC,id DESC";

$start           = ($page - 1)*$pagesize;
$count           = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count($whereStr);
$adviserListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_list($whereStr,$order,$start,$pagesize);
$adviserList = array();
if(!empty($adviserListTmp)){
    foreach ($adviserListTmp as $key => $value) {
        $adviserList[$key] = $value;
        
        $adviserList[$key]['avatar']      = get_file_url($value['avatar']);
        $adviserList[$key]['wx_qrcode']   = get_file_url($value['wx_qrcode']);
        $adviserList[$key]['work_picurl'] = get_file_url($value['work_picurl']);
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        
        $adviserList[$key]['siteInfo']           = $siteInfoTmp;
        $adviserList[$key]['expire_time']        = dgmdate($value['expire_time'],"Y-m-d H:i",$tomSysOffset);
        $adviserList[$key]['add_time']           = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$showSaleAdviserXianzhiBtn = 0;
if($tcfangchanConfig['newhouses_sale_adviser_max_num'] > 0){
    $nowTime = TIMESTAMP;
    $adviserCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) ");
    if($adviserCount >= $tcfangchanConfig['newhouses_sale_adviser_max_num']){
        $showSaleAdviserXianzhiBtn = 1;
    }
}

$showMustPhoneBtn = 0;
if(empty($__UserInfo['tel'])){
    $showMustPhoneBtn = 1;
    $phone_back_url = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myadviserlist";
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = $_G['m_siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$payUrl     = "plugin.php?id=tom_fcpc:pay";
$xufeiUrl   = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=adviserbuy&frompc=1&adviser_id="; 

$pageUrl = $modPczjUrl."&site_id={$site_id}&name={$name}&newhouses_id={$newhouses_id}&tel={$tel}&expire_status={$expire_status}&shenhe_status={$shenhe_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:zj/myadviserlist");