<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPczjUrl = $pczjUrl."&tmod=myfangchanlist";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'info' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );
        
    $tcfangchan_id = intval($_GET['tcfangchan_id'])>0? intval($_GET['tcfangchan_id']):0;
    
    $tcfangchanInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    
    $yanzhengStatus = 0;
    if($tcfangchanInfoTmp['user_id'] == $__UserInfo['id']){
        $yanzhengStatus = 1;
    }
    if($yanzhengStatus == 0 && $tcfangchanInfoTmp['source_type'] == 1){
        $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfoTmp['user_id']);
        if($agentInfo['id'] > 0){
            $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
            if($mendianInfo['id'] > 0 && $mendianInfo['user_id'] == $__UserInfo['id']){
                $yanzhengStatus = 1;
            }
        }
    }

    if($yanzhengStatus == 0){
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $tcfangchanInfo = array();
    if(!empty($tcfangchanInfoTmp)){
        
        $tcfangchanInfo = $tcfangchanInfoTmp;
        
        $userInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcfangchanInfo['user_id']);
        $areaInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tcfangchanInfo['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tcfangchanInfo['street_id']);
        $agentInfoTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if(is_array($agentInfoTmp) && !empty($agentInfoTmp)){
            $mendianInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfoTmp['mendian_id']);
        }
        $attrInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_attr')->fetch_by_tcfangchan_id($tcfangchan_id);
        
        $attr_rent_unit       = $rentUnitArr[$attrInfoTmp['attr_rent_unit']];
        $attr_rent_type       = $rentTypeArr[$attrInfoTmp['attr_rent_type']];
        $attr_shangpu_type    = $shangpuTypeArr[$attrInfoTmp['attr_shangpu_type']];
        $attr_zhuangxiu_type  = $zhuangxiuTypeArr[$attrInfoTmp['attr_zhuangxiu_type']];
        $attr_house_type      = $houseTypeArr[$attrInfoTmp['attr_house_type']];
        $attr_chaoxiang_type  = $chaoxiangTypeArr[$attrInfoTmp['attr_chaoxiang_type']];
        $attrTeseTagsArr      = explode('|', trim($attrInfoTmp['attr_tese_tags'], '|'));
        $attrPeitaoTagsArr    = explode('|', trim($attrInfoTmp['attr_peitao_tags'], '|'));
        
        $photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id={$tcfangchan_id} "," ORDER BY type DESC,psort ASC,id ASC ",0,20);
        $photoList = array();
        $vrPicurl = $videoPicurl = '';
        if(is_array($photoListTmp) && !empty($photoListTmp)){
            foreach($photoListTmp as $key => $value){
                $picurlTmp = $value['picurlTmp'];

                if($value['type'] == 1){
                    $photoList[] = $picurlTmp;
                }
                if($value['type'] == 2){
                    $vrPicurl = $picurlTmp;
                }
                if($value['type'] == 4){
                    $videoPicurl = $picurlTmp;
                }
            }
        }
        
        $tcfangchanInfo['userInfo']             = $userInfoTmp;
        $tcfangchanInfo['agentInfo']            = $agentInfoTmp;
        $tcfangchanInfo['mendianInfo']          = $mendianInfoTmp;
        $tcfangchanInfo['attrInfo']             = $attrInfoTmp;
        $tcfangchanInfo['areaInfo']             = $areaInfoTmp;
        $tcfangchanInfo['streetInfo']           = $streetInfoTmp;
        $tcfangchanInfo['attr_rent_unit']       = $attr_rent_unit;
        $tcfangchanInfo['attr_rent_type']       = $attr_rent_type;
        $tcfangchanInfo['attr_shangpu_type']    = $attr_shangpu_type;
        $tcfangchanInfo['attr_zhuangxiu_type']  = $attr_zhuangxiu_type;
        $tcfangchanInfo['attr_house_type']      = $attr_house_type;
        $tcfangchanInfo['attr_chaoxiang_type']  = $attr_chaoxiang_type;
        $tcfangchanInfo['attrTeseTagsArr']      = $attrTeseTagsArr;
        $tcfangchanInfo['attrPeitaoTagsArr']    = $attrPeitaoTagsArr;
        $tcfangchanInfo['video_pic']            = $videoPicurl;
        $tcfangchanInfo['vr_pic']               = $vrPicurl;
        $tcfangchanInfo['photoList']            = $photoList;
        
    }
    
    $tcfangchanInfo = iconv_to_utf8($tcfangchanInfo);
    
    $outArr = array(
        'code'  => 200,
        "msg"   => "",
        "data"  => $tcfangchanInfo,
    );
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;

    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    
    $yanzhengStatus = 0;
    if($tcfangchanInfo['user_id'] == $__UserInfo['id']){
        $yanzhengStatus = 1;
    }
    if($yanzhengStatus == 0 && $tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
            if($mendianInfo['id'] > 0 && $mendianInfo['user_id'] == $__UserInfo['id']){
                $yanzhengStatus = 1;
            }
        }
    }
    
    if($yanzhengStatus == 0){
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
        
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;
    
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    
    $yanzhengStatus = 0;
    if($tcfangchanInfo['user_id'] == $__UserInfo['id']){
        $yanzhengStatus = 1;
    }
    if($yanzhengStatus == 0 && $tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
            if($mendianInfo['id'] > 0 && $mendianInfo['user_id'] == $__UserInfo['id']){
                $yanzhengStatus = 1;
            }
        }
    }
    
    if($yanzhengStatus == 0){
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($fangchanSetting['open_over_expire_status3'] == 1 &&  $fangchanSetting['over_expire_status3_days'] > 0){
        $over_expire_status3_days_time = TIMESTAMP - $fangchanSetting['over_expire_status3_days']*86400;
        if($tcfangchanInfo['refresh_time'] < $over_expire_status3_days_time){
            $outArr = array(
                'code'=> 200,
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
    
   if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
        
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;
    
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    if($tcfangchanInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['deleted']          = 1;
    $updateData['expire_status']    = 2;
    $updateData['status']           = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
    
    delete_fangchan_tongcheng($tcfangchan_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'finish_ok' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;

    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    
    $yanzhengStatus = 0;
    if($tcfangchanInfo['user_id'] == $__UserInfo['id']){
        $yanzhengStatus = 1;
    }
    if($yanzhengStatus == 0 && $tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
            if($mendianInfo['id'] > 0 && $mendianInfo['user_id'] == $__UserInfo['id']){
                $yanzhengStatus = 1;
            }
        }
    }
    
    if($yanzhengStatus == 0){
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['finish'] = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
        
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'finish_no' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;
    
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    
    $yanzhengStatus = 0;
    if($tcfangchanInfo['user_id'] == $__UserInfo['id']){
        $yanzhengStatus = 1;
    }
    if($yanzhengStatus == 0 && $tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
            if($mendianInfo['id'] > 0 && $mendianInfo['user_id'] == $__UserInfo['id']){
                $yanzhengStatus = 1;
            }
        }
    }
    
    if($yanzhengStatus == 0){
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['finish'] = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
    
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_show' && submitcheck('tcfangchan_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchanIdsArr = array();
    if(is_array($_GET['tcfangchan_ids'])){
        foreach($_GET['tcfangchan_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcfangchanIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcfangchanIdsArr)){
        foreach($tcfangchanIdsArr as $key => $value){
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);
            
            $yanzhengStatus = 0;
            if($tcfangchanInfo['user_id'] == $__UserInfo['id']){
                $yanzhengStatus = 1;
            }
            if($yanzhengStatus == 0 && $tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
                    if($mendianInfo['id'] > 0 && $mendianInfo['user_id'] == $__UserInfo['id']){
                        $yanzhengStatus = 1;
                    }
                }
            }         
            
            if($yanzhengStatus == 1){
                $updateData = array();
                $updateData['status'] = 1;
                C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);

                if($tcfangchanInfo['source_type'] == 1){
                    $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                    if($agentInfo['id'] > 0){
                        update_mendian_xinxi($agentInfo['mendian_id']);
                    }
                }

                update_fangchan_tongcheng($value);
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_hide' && submitcheck('tcfangchan_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchanIdsArr = array();
    if(is_array($_GET['tcfangchan_ids'])){
        foreach($_GET['tcfangchan_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcfangchanIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcfangchanIdsArr)){
        foreach($tcfangchanIdsArr as $key => $value){
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);
            
            $yanzhengStatus = 0;
            if($tcfangchanInfo['user_id'] == $__UserInfo['id']){
                $yanzhengStatus = 1;
            }
            if($yanzhengStatus == 0 && $tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
                    if($mendianInfo['id'] > 0 && $mendianInfo['user_id'] == $__UserInfo['id']){
                        $yanzhengStatus = 1;
                    }
                }
            }

            if($yanzhengStatus == 1){
                $updateData = array();
                $updateData['status'] = 0;
                C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);

                if($tcfangchanInfo['source_type'] == 1){
                    $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                    if($agentInfo['id'] > 0){
                        update_mendian_xinxi($agentInfo['mendian_id']);
                    }
                }

                update_fangchan_tongcheng($value);
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_finish1' && submitcheck('tcfangchan_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchanIdsArr = array();
    if(is_array($_GET['tcfangchan_ids'])){
        foreach($_GET['tcfangchan_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcfangchanIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcfangchanIdsArr)){
        foreach($tcfangchanIdsArr as $key => $value){
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);
            
            $yanzhengStatus = 0;
            if($tcfangchanInfo['user_id'] == $__UserInfo['id']){
                $yanzhengStatus = 1;
            }
            if($yanzhengStatus == 0 && $tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
                    if($mendianInfo['id'] > 0 && $mendianInfo['user_id'] == $__UserInfo['id']){
                        $yanzhengStatus = 1;
                    }
                }
            }
            
            if($yanzhengStatus == 1){
                $updateData = array();
                $updateData['finish'] = 1;
                $updateData['status'] = 0;
                C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);

                if($tcfangchanInfo['source_type'] == 1){
                    $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                    if($agentInfo['id'] > 0){
                        update_mendian_xinxi($agentInfo['mendian_id']);
                    }
                }

                update_fangchan_tongcheng($value);
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_finish0' && submitcheck('tcfangchan_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchanIdsArr = array();
    if(is_array($_GET['tcfangchan_ids'])){
        foreach($_GET['tcfangchan_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcfangchanIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcfangchanIdsArr)){
        foreach($tcfangchanIdsArr as $key => $value){
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);
            
            $yanzhengStatus = 0;
            if($tcfangchanInfo['user_id'] == $__UserInfo['id']){
                $yanzhengStatus = 1;
            }
            if($yanzhengStatus == 0 && $tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
                    if($mendianInfo['id'] > 0 && $mendianInfo['user_id'] == $__UserInfo['id']){
                        $yanzhengStatus = 1;
                    }
                }
            }
            
            if($yanzhengStatus == 1){
                $updateData = array();
                $updateData['finish'] = 0;
                C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);

                if($tcfangchanInfo['source_type'] == 1){
                    $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                    if($agentInfo['id'] > 0){
                        update_mendian_xinxi($agentInfo['mendian_id']);
                    }
                }

                update_fangchan_tongcheng($value);
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$agentInfo   = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
$mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_user_id($__UserInfo['id']);

$keyword            = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$tcfangchan_id      = isset($_GET['tcfangchan_id'])? intval($_GET['tcfangchan_id']):0;
$house_no           = isset($_GET['house_no'])? addslashes($_GET['house_no']):'';
$tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
$model_id           = isset($_GET['model_id'])? addslashes($_GET['model_id']):'';
$area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
$street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
$source_type        = isset($_GET['source_type'])? intval($_GET['source_type']):0;
$status             = isset($_GET['status'])? intval($_GET['status']):0;
$expire_status      = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
$pay_type           = isset($_GET['pay_type'])? intval($_GET['pay_type']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}
$modelIdsArr = array(
    'ershoufang' => $Lang['ershoufang'],
    'chuzu' => $Lang['chuzu'],
    'shangpu' => $Lang['shangpu'],
    'xiezilou' => $Lang['xiezilou'],
    'changfang' => $Lang['changfang'],
    'cangku' => $Lang['cangku'],
    'tudi' => $Lang['tudi'],
);

$__CityInfo  = array('id'=>0,'name'=>'');
if($site_id > 1){
    $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
    if($sitesInfoTmp){
        $__SitesInfo = $sitesInfoTmp;
        if(!empty($__SitesInfo['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
            if($cityInfoTmp){
                $__CityInfo = $cityInfoTmp;
            }
        }
    }
}else if($site_id == 1){
    $cityInfoTmp = array();
    if(!empty($tongchengConfig['city_id'])){
        $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
    }
    if(!empty($cityInfoTmp)){
        $__CityInfo = $cityInfoTmp;
    }
}
$areaList   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);

$whereStr = ' AND deleted = 0 ';

if($mendianInfo['id'] > 0){
    
    $agentListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_user_id(" AND mendian_id={$mendianInfo['id']} ","ORDER BY id DESC");
    
    $agentUserIdArr = array();
    if(is_array($agentListTmp) && !empty($agentListTmp)){
        foreach($agentListTmp as $key => $value){
            $agentUserIdArr[] = $value['user_id'];
        }
    }
    if(is_array($agentUserIdArr) && !empty($agentUserIdArr)){
        $agentUserIdStr = implode(',', $agentUserIdArr);
        $whereStr.= " AND user_id IN ({$agentUserIdStr}) ";
    }else{
        $whereStr .= " AND user_id={$__UserInfo['id']}";
    }
    
}else{
    $whereStr .= " AND user_id={$__UserInfo['id']}";
}

if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}
if(!empty($tel)){
    $whereStr.= " AND tel='{$tel}' ";
}
if(!empty($model_id)){
    $whereStr.= " AND model_id='{$model_id}' ";
}
if($area_id > 0){
    $whereStr.= " AND area_id='{$area_id}' ";
}
if($street_id > 0){
    $whereStr.= " AND street_id='{$street_id}' ";
}
if(!empty($tcfangchan_id)){
    $whereStr.= " AND id={$tcfangchan_id} ";
}
if(!empty($house_no)){
    $whereStr.= " AND house_no='{$house_no}' ";
}
if(!empty($source_type)){
    $whereStr.= " AND source_type={$source_type} ";
}
if(!empty($status)){
    if($status == 1){
        $whereStr.= " AND status=1 ";
    }else if($status == 2){
        $whereStr.= " AND status != 1 ";
    }
}
if(!empty($shenhe_status)){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}
if($top_status > 0){
    if($top_status == 1){
        $whereStr.= " AND top_status = 1 ";
    }else if($top_status == 2){
        $whereStr.= " AND top_status = 0 ";
    }
}
if($pay_type > 0){
    $whereStr.= " AND pay_type = {$pay_type} ";
}
if($expire_status > 0){
    if($expire_status == 1){
        $whereStr.= " AND ((expire_status = 1 AND expire_time > ".TIMESTAMP.") OR (expire_status = 3)) ";
    }else if($expire_status == 2){
        $whereStr.= " AND expire_status = 2 ";
    }
}
$order = "ORDER BY refresh_time DESC,id DESC";

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count($whereStr,$keyword);
$tcfangchanListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($whereStr,$order,$start,$pagesize,$keyword);
$tcfangchanList = array();
if(!empty($tcfangchanListTmp)){
    foreach ($tcfangchanListTmp as $key => $value) {
        $tcfangchanList[$key] = $value;
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        
        $tcfangchanList[$key]['siteInfo']              = $siteInfoTmp;
        $tcfangchanList[$key]['top_time']              = dgmdate($value['top_time'],"Y-m-d H:i",$tomSysOffset);
        $tcfangchanList[$key]['refresh_time']          = dgmdate($value['refresh_time'],"Y-m-d H:i",$tomSysOffset);
        $tcfangchanList[$key]['add_time']              = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $tcfangchanList[$key]['expire_time']           = dgmdate($value['expire_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

if($agentInfo['mendian_id'] > 0){
    $agentMendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
}

$mendianVipInfo = $agentVipInfo = array();
if($agentInfo['id'] > 0 && $agentInfo['shenhe_status'] == 1){    
    
    if($agentMendianInfo['id'] > 0){
        if($tcfangchanConfig['open_mendian_vip'] == 1 && $agentMendianInfo['vip_id'] > 0 && $agentMendianInfo['expire_status'] == 1 && $agentMendianInfo['expire_time'] > TIMESTAMP){
            $mendianVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($agentMendianInfo['vip_id']);
        }
    }

    if($tcfangchanConfig['open_agent_vip'] == 1 && $agentInfo['vip_id'] > 0 && $agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP){
        $agentVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
    }
}

$refreshStatus = 0;
if($tcfangchanConfig['fangchan_refresh_price'] > 0){
    $refreshStatus = 1;
    
    if($tcfangchanConfig['free_refresh_num'] > 0){
        $freeRefreshCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND type = 4 AND today_time = {$nowDayTime} ");
        if($tcfangchanConfig['free_refresh_num'] > $freeRefreshCount){
            $refreshStatus = 2;
            $syFreeRefreshNum = $tcfangchanConfig['free_refresh_num'] - $freeRefreshCount;
        }
    }
    
    if($agentInfo['id'] > 0 && $agentInfo['shenhe_status'] == 1){

        if($refreshStatus == 1 && $agentMendianInfo['id'] > 0){
            $mendian_refresh_num_tmp = $tcfangchanConfig['default_mendian_vip_agent_refresh_num'];
            if(is_array($mendianVipInfo) && !empty($mendianVipInfo)){
                $mendian_refresh_num_tmp = intval($mendianVipInfo['agent_refresh_num']);
            }

            $mendianRefreshCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND mendian_id = {$agentMendianInfo['id']} AND type = 2 AND today_time = {$nowDayTime} ");
            if($mendian_refresh_num_tmp > $mendianRefreshCount){
                $refreshStatus = 3;
                $syMendianRefreshNum = $mendian_refresh_num_tmp - $mendianRefreshCount;
            }
        }
    
        if($refreshStatus == 1 && is_array($agentVipInfo) && !empty($agentVipInfo)){
            $agent_refresh_num_tmp = intval($agentVipInfo['refresh_num']);
            $agentRefreshCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND agent_id = {$agentInfo['id']} AND type = 6 AND today_time = {$nowDayTime} ");
            if($agent_refresh_num_tmp > $agentRefreshCount){
                $syAgentRefreshNum = $agent_refresh_num_tmp - $agentRefreshCount;
                $refreshStatus = 4;
            }
        }
    }
    
    if($refreshStatus == 1 && $tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
        $refreshPayScore = ceil($tcfangchanConfig['fangchan_refresh_price'] * $tongchengConfig['pay_score_yuan']);
        if($refreshPayScore > 0 && $__UserInfo['score'] > $refreshPayScore){
            $refreshStatus = 5;
        }
    }
}

$showMustPhoneBtn = 0;
if($tcfangchanConfig['fangchan_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my";
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = $_G['m_siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$vipEndStatus = 0;
if($agentInfo['id'] > 0){
   
    if($tcfangchanConfig['open_mendian_vip'] == 1 && $agentMendianInfo['id'] > 0 && $agentMendianInfo['vip_id'] > 0){
        
        if($tcfangchanConfig['open_mendian_vip_agent'] == 1 && $agentMendianInfo['user_id'] == $__UserInfo['id']){
            if($agentMendianInfo['expire_status'] == 1 && $agentMendianInfo['expire_time'] > TIMESTAMP){
            }else{
                $agentCount = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_count( " AND mendian_id = {$agentMendianInfo['id']} ");
                if($agentCount > $tcfangchanConfig['default_mendian_vip_agent_num']){
                    $vipEndStatus = 1;
                }
            }
        }
    }
}

$payUrl     = "plugin.php?id=tom_fcpc:pay";
$topUrl     = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=buytop&frompc=1&tcfangchan_id="; 
$xufeiUrl   = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=buyxufei&frompc=1&tcfangchan_id="; 
$buyMendianVipUrl   = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mendianvip";  

$pageUrl = $modPczjUrl."&site_id={$site_id}&tel={$tel}&model_id={$model_id}&area_id={$area_id}&street_id={$street_id}&house_no={$house_no}&source_type={$source_type}&status={$status}&shenhe_status={$shenhe_status}&top_status={$top_status}&pay_type={$pay_type}&expire_status={$expire_status}&keyword={$keyword}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:zj/myfangchanlist");