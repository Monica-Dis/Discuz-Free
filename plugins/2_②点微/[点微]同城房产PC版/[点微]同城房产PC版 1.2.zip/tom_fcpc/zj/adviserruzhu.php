<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPczjUrl = $pczjUrl."&tmod=adviserruzhu";

$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$name               = isset($_GET['name'])? addslashes($_GET['name']):'';
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$whereStr = " AND status = 1 AND open_sale_adviser = 1 ";
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}

$order  = "  ORDER BY id DESC  ";

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_count($whereStr,$name);
$newhousesListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_list($whereStr,$order,$start,$pagesize,$name);
$newhousesList = array();
if(!empty($newhousesListTmp)){
    foreach ($newhousesListTmp as $key => $value) {
        $newhousesList[$key] = $value;
        
        $typeStr = trim($value['type'], '|');
        $typeArr = explode('|', $typeStr);
        
        $nowTime = TIMESTAMP;
        $ruzhuStatus = 0;
        $adviserInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_list(" AND newhouses_id = {$value['id']} AND user_id = {$__UserInfo['id']} AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) ", "ORDER BY id ASC", 0, 1);
        if(is_array($adviserInfoTmp) && !empty($adviserInfoTmp)){
            $ruzhuStatus = 1;
        }
        $syAdviserNum = 0;
        if($value['sale_adviser_num'] > 0){
            $adviserCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count(" AND newhouses_id = {$value['id']} AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) ");
            $syAdviserNum = $value['sale_adviser_num'] - $adviserCount;
            if($ruzhuStatus == 0 && $syAdviserNum <= 0){
                $ruzhuStatus = 2;
            }
        }else{
            $ruzhuStatus = 2;
        }
        $siteInfoTmp = $sitesList[$value['site_id']];
        
        $newhousesList[$key]['siteInfo']        = $siteInfoTmp;
        $newhousesList[$key]['typeArr']         = $typeArr;
        $newhousesList[$key]['ruzhuStatus']     = $ruzhuStatus;
        $newhousesList[$key]['syAdviserNum']    = $syAdviserNum;
        
        if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->update($value['id'], $updateData);
        }
    }
}

$pageUrl = $modPczjUrl."&site_id={$site_id}&name={$name}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:zj/adviserruzhu");