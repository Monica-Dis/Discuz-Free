<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
if($agentInfo['id'] > 0 && $agentInfo['shenhe_status'] == 1){ }else{
    dheader('location:'.$pczjUrl."&tmod=home");exit;
}

$modPczjUrl = $pczjUrl."&tmod=myhouseslist";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'hide' && submitcheck('houses_id')){
    $outArr = array(
        'code'=> 1,
    );

    $houses_id  = intval($_GET['houses_id'])>0 ? intval($_GET['houses_id']):0;
    
    $housesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($houses_id);
    
    if($housesInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['status'] = 0;
    $updateData['update_time']  = TIMESTAMP;
    C::t('#tom_tcfangchan#tom_tcfangchan_houses')->update($houses_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('houses_id')){
    $outArr = array(
        'code'=> 1,
    );

    $houses_id = intval($_GET['houses_id'])>0 ? intval($_GET['houses_id']):0;
    
    $housesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($houses_id);
    
    if($housesInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
        
    $updateData = array();
    $updateData['status'] = 1;
    $updateData['update_time']  = TIMESTAMP;
    C::t('#tom_tcfangchan#tom_tcfangchan_houses')->update($houses_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'info' && submitcheck('houses_id')){
    $outArr = array(
        'code'=> 1,
    );
        
    $houses_id    = intval($_GET['houses_id'])>0 ? intval($_GET['houses_id']):0;
    
    $housesInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($houses_id);
    $housesInfo = array();
    if(!empty($housesInfoTmp)){
        
        $housesInfo = $housesInfoTmp;
        
        $typeArr = explode('|', trim($housesInfo['type'], '|'));
        $typeStr = '';
        if(is_array($houseTypeArr) && !empty($houseTypeArr)){
            foreach($houseTypeArr as $key => $value){
                if(in_array($key,$typeArr)){
                    $typeStr .= $houseTypeArr[$key].' ';
                }
            }
        }
        
        $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($housesInfo['site_id']);        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($housesInfo['user_id']);        
        
        $photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND houses_id = {$housesInfo['id']} ", 'ORDER BY psort ASC,id ASC', 0, 100);
        $photoList = array();
        if(is_array($photoListTmp) && !empty($photoListTmp)){
            foreach($photoListTmp as $key => $value){
                $photoList[$key] = $value;
                $photoList[$key]['pic_url'] = $value['picurlTmp'];
            }
        }
        
        $housesInfo['siteInfo']          = $siteInfoTmp;
        $housesInfo['userInfo']          = $userInfoTmp;
        $housesInfo['typeStr']           = $typeStr;
        $housesInfo['photoList']         = $photoList;
        $housesInfo['add_time']          = dgmdate($housesInfo['add_time'],"Y-m-d H:i",$tomSysOffset);
        $housesInfo['update_time']       = dgmdate($housesInfo['update_time'],"Y-m-d H:i",$tomSysOffset);
        
    }
    
    $housesInfo = iconv_to_utf8($housesInfo);
    $outArr = array(
        'code'  => 200,
        "msg"   => "",
        "data"  => $housesInfo
    );
    echo json_encode($outArr); exit;
}

$name           = isset($_GET['name'])? addslashes($_GET['name']):'';
$site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$houses_id      = isset($_GET['houses_id'])? intval($_GET['houses_id']):0;
$min_price      = isset($_GET['min_price'])? intval($_GET['min_price']):'';
$max_price      = isset($_GET['max_price'])? intval($_GET['max_price']):'';
$area_id        = isset($_GET['area_id'])? intval($_GET['area_id']):0;
$street_id      = isset($_GET['street_id'])? intval($_GET['street_id']):0;
$house_type     = isset($_GET['house_type'])? intval($_GET['house_type']):0;
$status         = isset($_GET['status'])? intval($_GET['status']):0;
$shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$__CityInfo  = array('id'=>0,'name'=>'');
if($site_id > 1){
    $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
    if($sitesInfoTmp){
        $__SitesInfo = $sitesInfoTmp;
        if(!empty($__SitesInfo['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
            if($cityInfoTmp){
                $__CityInfo = $cityInfoTmp;
            }
        }
    }
}else if($site_id == 1){
    $cityInfoTmp = array();
    if(!empty($tongchengConfig['city_id'])){
        $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
    }
    if(!empty($cityInfoTmp)){
        $__CityInfo = $cityInfoTmp;
    }
}
$areaList   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);

$whereStr = " AND user_id={$__UserInfo['id']}";
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}
if($houses_id > 0){
    $whereStr.= " AND id='{$houses_id}' ";
}
if(intval($min_price) > 0){
    $min_price = intval($min_price);
    $whereStr.= " AND average_price>={$min_price} ";
}
if(intval($max_price) > 0){
    $max_price = intval($max_price);
    $whereStr.= " AND average_price<={$max_price} ";
}
if($area_id > 0){
    $whereStr.= " AND area_id='{$area_id}' ";
}
if($street_id > 0){
    $whereStr.= " AND street_id='{$street_id}' ";
}
if($house_type > 0){
    $house_type = str_replace(array('%', '_'),'',$house_type);
    $whereStr .= " AND type LIKE '%|{$house_type}|%'";
}
if(!empty($shenhe_status)){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}
if(!empty($status)){
    if($status == 1){
        $whereStr.= " AND status=1 ";
    }else if($status == 2){
        $whereStr.= " AND status != 1 ";
    }
}

$order = "ORDER BY site_id ASC,id DESC";

$start          = ($page - 1)*$pagesize;
$count          = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_count($whereStr,$name);
$housesListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_list($whereStr,$order,$start,$pagesize,$name);
$housesList = array();
if(!empty($housesListTmp)){
    foreach ($housesListTmp as $key => $value) {
        $housesList[$key] = $value;
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        $typeStr = trim($value['type'], '|');
        $typeArr = explode('|', $typeStr);
 
        $housesList[$key]['siteInfo']              = $siteInfoTmp;
        $housesList[$key]['typeArr']               = $typeArr;
    }
}

$showMustPhoneBtn = 0;
if($tcfangchanConfig['fangchan_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my";
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = $_G['m_siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$pageUrl = $modPczjUrl."&site_id={$site_id}&name={$name}&min_price={$min_price}&max_price={$max_price}&area_id={$area_id}&street_id={$street_id}&house_type={$house_type}&shenhe_status={$shenhe_status}&status={$status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:zj/myhouseslist");