<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPczjUrl = $pczjUrl."&tmod=choose_mendian";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

$mendian_id         = intval($_GET['mendian_id'])? intval($_GET['mendian_id']):0;
$keyword            = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = ' AND shenhe_status=1 ';

$order = "ORDER BY top_status DESC, clicks DESC,id DESC";

$start           = ($page - 1)*$pagesize;
$count           = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_count($whereStr,$keyword);
$mendianListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_list($whereStr,$order,$start,$pagesize,$keyword);
$mendianList = array();
if(!empty($mendianListTmp)){
    foreach ($mendianListTmp as $key => $value) {
        $mendianList[$key] = $value;
            
        $selectStatus = 1;
        if($tcfangchanConfig['open_mendian_vip'] == 1 && $tcfangchanConfig['open_mendian_vip_agent'] == 1){
            $agentCount = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_count( " AND mendian_id = {$value['id']} ");
            $mendian_agent_num_tmp = $tcfangchanConfig['default_mendian_vip_agent_num'];
            if($value['vip_id'] > 0 && $value['expire_status'] == 1 && $value['expire_time'] > TIMESTAMP){
                $vipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($value['vip_id']);
                $mendian_agent_num_tmp = intval($vipInfo['agent_num']);
            }
            if($agentCount >= $mendian_agent_num_tmp){
                $selectStatus = 2;
            }
        }

        $photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND mendian_id={$value['id']} AND type = 5 "," ORDER BY type DESC,psort ASC,id ASC ",0,1);
        $logo_picurl = '';
        if(is_array($photoListTmp) && !empty($photoListTmp)){
            $logo_picurl = $photoListTmp[0]['picurlTmp'];
        }

        $mendianList[$key]['logo_picurl']       = $logo_picurl;
        $mendianList[$key]['selectStatus']      = $selectStatus;
    }
}

$pageUrl = $modPczjUrl."&keyword={$keyword}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:zj/choose_mendian");