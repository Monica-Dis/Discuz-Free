<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$newhousesManageInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_manage")->fetch_by_user_id($__UserInfo['id']);
if($newhousesManageInfo['id'] > 0){ }else{
    dheader('location:'.$pczjUrl."&tmod=mynewhouseslist");exit;
}

$modPczjUrl = $pczjUrl."&tmod=newhousesadd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id                = intval($_GET['site_id'])>0? intval($_GET['site_id']):1;
    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $sub_title              = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $open_sale_adviser      = isset($_GET['open_sale_adviser'])? intval($_GET['open_sale_adviser']):0;
    $sale_adviser_num       = isset($_GET['sale_adviser_num'])? intval($_GET['sale_adviser_num']):0;
    $sale_adviser_price_list = isset($_GET['sale_adviser_price_list'])? addslashes($_GET['sale_adviser_price_list']):'';
    $sell_status            = intval($_GET['sell_status'])>0? intval($_GET['sell_status']):0;
    $start_time             = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time             = strtotime($start_time);
    $jiaofang_time          = isset($_GET['jiaofang_time'])? addslashes($_GET['jiaofang_time']):'';
    $jiaofang_time          = strtotime($jiaofang_time);
    $city_id                = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id                = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $area_name              = isset($_GET['area_name'])? addslashes($_GET['area_name']):'';
    $street_id              = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $street_name            = isset($_GET['street_name'])? addslashes($_GET['street_name']):'';
    $address                = isset($_GET['address'])? addslashes($_GET['address']):'';
    $average_price          = intval($_GET['average_price'])>0? intval($_GET['average_price']):0;
    $zhuangxiu_type         = intval($_GET['zhuangxiu_type'])>0? intval($_GET['zhuangxiu_type']):0;
    $chanquan               = intval($_GET['chanquan'])>0? intval($_GET['chanquan']):0;
    $sales_tel              = isset($_GET['sales_tel'])? addslashes($_GET['sales_tel']):'';
    $sales_address          = isset($_GET['sales_address'])? addslashes($_GET['sales_address']):'';
    $lng                    = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                    = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $developer_company      = isset($_GET['developer_company'])? addslashes($_GET['developer_company']):'';
    $parking_space          = intval($_GET['parking_space'])>0? intval($_GET['parking_space']):0;
    $plot_ratio             = floatval($_GET['plot_ratio'])>0? floatval($_GET['plot_ratio']):0.0;
    $greening_rate          = intval($_GET['greening_rate'])>0? intval($_GET['greening_rate']):0;
    $households_num         = intval($_GET['households_num'])>0? intval($_GET['households_num']):0;
    $land_mianji            = intval($_GET['land_mianji'])>0? intval($_GET['land_mianji']):0;
    $house_total_mianji     = intval($_GET['house_total_mianji'])>0? intval($_GET['house_total_mianji']):0;
    $huode_ratio            = intval($_GET['huode_ratio'])>0? intval($_GET['huode_ratio']):0;
    $property_company       = isset($_GET['property_company'])? addslashes($_GET['property_company']):'';
    $property_price         = floatval($_GET['property_price'])>0? floatval($_GET['property_price']):0.00;
    $property_tel           = isset($_GET['property_tel'])? addslashes($_GET['property_tel']):'';
    $content                = isset($_GET['content'])? addslashes($_GET['content']):'';
    $vr_link                = isset($_GET['vr_link'])? addslashes($_GET['vr_link']):'';
    $vr_picurl              = isset($_GET['vr_pic'])? addslashes($_GET['vr_pic']):'';
    
    $teseTagsIdsArr = array();
    if(is_array($_GET['attr_tese_tags']) && !empty($_GET['attr_tese_tags'])){
        foreach($_GET['attr_tese_tags'] as $key => $value){
            if(intval($value) > 0){
                $teseTagsIdsArr[] = intval($value);
            }
        }
    }
    $configTagList = array();
    $attrTeseTagsStr = $attrTeseTagsIdsStr = '';
    if(is_array($teseTagsIdsArr) && !empty($teseTagsIdsArr)){
        $teseTagsIdsCount = count($teseTagsIdsArr);
        $attrTeseTagsIdsStr = implode(',', $teseTagsIdsArr);
        $configTagListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_all_list(" AND id IN({$attrTeseTagsIdsStr}) ", 'ORDER BY tsort ASC,id DESC', 0, $teseTagsIdsCount);
        $configTagNameArr = array();
        if(is_array($configTagListTmp) && !empty($configTagListTmp)){
            foreach($configTagListTmp as $key => $value){
                $configTagList[$key] = $value;
                $configTagNameArr[] = $value['name'];
            }
        }
        
        if(is_array($configTagNameArr) && !empty($configTagNameArr)){
            $attrTeseTagsStr = '|'.implode('|', $configTagNameArr).'|';
        }
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photopsort_") !== false){
            $kk = intval(ltrim($key, "photopsort_"));
            $photoArr[$kk]['psort'] = addslashes($value);
        }
    }
    
    $huxingpicArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "huxingpic_") !== false){
            $kk = intval(ltrim($key, "huxingpic_"));
            $huxingpicArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "huxinpsort_") !== false){
            $kk = intval(ltrim($key, "huxinpsort_"));
            $huxingpicArr[$kk]['psort'] = addslashes($value);
        }
        if(strpos($key, "house_huxing_") !== false){
            $kk = intval(ltrim($key, "house_huxing_"));
            $huxingpicArr[$kk]['huxing'] = addslashes($value);
        }
        if(strpos($key, "house_mianji_") !== false){
            $kk = intval(ltrim($key, "house_mianji_"));
            $huxingpicArr[$kk]['mianji'] = addslashes($value);
        }
    }
    
    $typeStr = '';
    if(!empty($_GET['type_ids'])){
        $typeStr = '|'.implode('|', $_GET['type_ids']).'|';
    }
        
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    
    $insertData = array();
    $insertData['site_id']              = $site_id;
    $insertData['user_id']              = $__UserInfo['id'];
    $insertData['name']                 = $name;
    $insertData['sub_title']            = $sub_title;
    $insertData['open_sale_adviser']    = $open_sale_adviser;
    $insertData['sale_adviser_num']     = $sale_adviser_num;
    $insertData['sale_adviser_price_list']  = $sale_adviser_price_list;
    $insertData['type']                 = $typeStr;
    $insertData['tese_tags']            = $attrTeseTagsStr;
    $insertData['city_id']              = $city_id;
    $insertData['area_id']              = $area_id;
    $insertData['area_name']            = $areaInfo['name'];
    $insertData['street_id']            = $street_id;
    $insertData['street_name']          = $streetInfo['name'];
    $insertData['average_price']        = $average_price;
    $insertData['chanquan']             = $chanquan;
    $insertData['zhuangxiu_type']       = $zhuangxiu_type;
    $insertData['address']              = $address;
    $insertData['latitude']             = $lat;
    $insertData['longitude']            = $lng;
    $insertData['sales_tel']            = $sales_tel;
    $insertData['sales_address']        = $sales_address;
    $insertData['developer_company']    = $developer_company;
    $insertData['parking_space']        = $parking_space;
    $insertData['plot_ratio']           = $plot_ratio;
    $insertData['greening_rate']        = $greening_rate;
    $insertData['households_num']       = $households_num;
    $insertData['land_mianji']          = $land_mianji;
    $insertData['house_total_mianji']   = $house_total_mianji;
    $insertData['huode_ratio']          = $huode_ratio;
    $insertData['property_company']     = $property_company;
    $insertData['property_price']       = $property_price;
    $insertData['property_tel']         = $property_tel;
    $insertData['content']              = $content;
    $insertData['vr_link']              = $vr_link;
    $insertData['sell_status']          = $sell_status;
    $insertData['start_time']           = $start_time;
    $insertData['jiaofang_time']        = $jiaofang_time;
    $insertData['status']               = 1;
    $insertData['admin_edit']           = 0;
    $insertData['update_time']          = TIMESTAMP;
    $insertData['add_time']             = TIMESTAMP;
    if(C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->insert($insertData)){
        
        $newhouses_id = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->insert_id();
        
        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['newhouses_id'] = $newhouses_id;
                $insertData['type']         = 1;
                $insertData['picurl']       = $value['picurl'];
                $insertData['psort']        = $value['psort'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tcfangchan#tom_tcfangchan_photo')->insert($insertData);
            }
        }
        
        if(!empty($vr_picurl)){
            $insertData = array();
            $insertData['newhouses_id']     = $newhouses_id;
            $insertData['type']             = 2;
            $insertData['picurl']           = $vr_picurl;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        
        if(!empty($huxingpicArr)){
            foreach($huxingpicArr as $key => $value){
                $insertData = array();
                $insertData['newhouses_id'] = $newhouses_id;
                $insertData['type']         = 3;
                $insertData['picurl']       = $value['picurl'];
                $insertData['house_huxing'] = $value['huxing'];
                $insertData['house_mianji'] = $value['mianji'];
                $insertData['psort']        = $value['psort'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tcfangchan#tom_tcfangchan_photo')->insert($insertData);
            }
        }
        
        if(is_array($configTagList) && !empty($configTagList)){
            foreach($configTagList as $key => $value){
                $insertData = array();
                $insertData['newhouses_id']     = $newhouses_id;
                $insertData['config_tag_id']    = $value['id'];
                $insertData['config_tag_ids']   = $attrTeseTagsIdsStr;
                $insertData['name']             = $value['name'];
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_tag")->insert($insertData);
            }
        }
        if(!empty($tongchengConfig['template_id'])){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

            $fabuNewhousesSms = str_replace('{NAME}', $__UserInfo['nickname'], lang('plugin/tom_tcfangchan', 'template_fabu_newhouses_msg'));
            $fabuNewhousesSms = str_replace('{NEWHOUSES}', $name, $fabuNewhousesSms);

            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesinfo&newhouses_id={$newhouses_id}");
                $smsData = array(
                    'first'         => $fabuNewhousesSms,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($fcmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesinfo&newhouses_id={$newhouses_id}");
                $smsData = array(
                    'first'         => $fabuNewhousesSms,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        
        if($newhouses_id > 0){
            $outArr = array(
                'code'=> 200,
                'id'=> $newhouses_id,
            );
            echo json_encode($outArr); exit;
        }
    }
    echo json_encode($outArr); exit;
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$__CityInfo = array();
if(!empty($tongchengConfig['city_id'])){
    $__CityInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);

$teseTagListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config_tag")->fetch_all_list(" AND model_id = 'newhouses' ", 'ORDER BY tsort ASC,id DESC', 0, 30);
$teseTagList = array();
if(is_array($teseTagListTmp) && !empty($teseTagListTmp)){
    foreach($teseTagListTmp as $key => $value){
        $teseTagList[$value['id']] = $value['name'];
    }
}

$addUrl = $modPczjUrl."&act=add";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:zj/newhousesadd");