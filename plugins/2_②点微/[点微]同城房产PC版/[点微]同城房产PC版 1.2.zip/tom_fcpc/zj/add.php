<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPczjUrl = $pczjUrl."&tmod=add";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('model_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    } 
    
    $site_id        = intval($_GET['site_id'])>0? intval($_GET['site_id']):1;
    $model_id       = isset($_GET['model_id'])? addslashes($_GET['model_id']):'';
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['user_id']          = $__UserInfo['id'];
    $insertData['model_id']         = $model_id;
    $insertData['title']            = $title;
    $insertData['status']           = 0;
    $insertData['shenhe_status']    = 2;
    $insertData['refresh_time']     = TIMESTAMP;
    $insertData['add_time']         = TIMESTAMP;
    $tcfangchan_id = C::t("#tom_tcfangchan#tom_tcfangchan")->insert($insertData, true);
    if($tcfangchan_id > 0){
        $outArr = array(
            'code'=> 200,
            'id'=> $tcfangchan_id,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}

$tcfangchan_id = intval($_GET['tcfangchan_id'])>0? intval($_GET['tcfangchan_id']):0;

$modelIdsArr = array(
    'ershoufang' => $Lang['ershoufang'],
    'chuzu' => $Lang['chuzu'],
    'shangpu' => $Lang['shangpu'],
    'xiezilou' => $Lang['xiezilou'],
    'changfang' => $Lang['changfang'],
    'cangku' => $Lang['cangku'],
    'tudi' => $Lang['tudi'],
);

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

if($tcfangchan_id > 0){
    $tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($tcfangchan_id);
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($tcfangchanInfo['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcfangchanInfo['site_id']);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
        }
    }else if($tcfangchanInfo['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    
    $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
    
    if($tcfangchanInfo['model_id'] == 'ershoufang' || $tcfangchanInfo['model_id'] == 'chuzu' || $tcfangchanInfo['model_id'] == 'shangpu' || $tcfangchanInfo['model_id'] == 'xiezilou'){
        if($tcfangchanConfig['open_trade'] == 1){
            $tradeListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_trade")->fetch_all_list(" ", 'ORDER BY tsort ASC,id DESC');
            $tradeList = array();
            if(is_array($tradeListTmp) && !empty($tradeListTmp)){
                foreach($tradeListTmp as $key => $value){
                    $tradeList[$key] = $value;
                }
            }
        }
    }
    
    $teseTagListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config_tag")->fetch_all_list(" AND model_id = '{$tcfangchanInfo['model_id']}' ", 'ORDER BY tsort ASC,id DESC', 0, 30);
    $teseTagList = array();
    if(is_array($teseTagListTmp) && !empty($teseTagListTmp)){
        foreach($teseTagListTmp as $key => $value){
            $teseTagList[$value['id']] = $value['name'];
        }
    }
    
    $housesListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_houses")->fetch_all_name(" AND status = 1 ", 'ORDER BY id DESC');
    $housesList = array();
    if(is_array($housesListTmp) && !empty($housesListTmp)){
        foreach($housesListTmp as $key => $value){
            $housesList[$key] = $value;
        }
    }
    
    if($tcfangchanInfo['model_id'] == 'ershoufang' || $tcfangchanInfo['model_id'] == 'chuzu'){
        $defaultHousesName = '';
        $defaultHousesId   = 0;
        $defaultAreaId     = 0;
        $defaultAreaName   = '';
        $defaultStreetId   = 0;
        $defaultStreetName = '';
        $defaultAddress    = '';
        $defaultLatitude   = '';
        $defaultLongitude  = '';

        $tcfangchanInfoTmpTmp = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_list(" AND user_id = {$tcfangchanInfo['user_id']} AND model_id = '{$tcfangchanInfo['model_id']}' AND id != {$tcfangchanInfo['id']}", 'ORDER BY id DESC', 0, 1);
        if(is_array($tcfangchanInfoTmpTmp) && !empty($tcfangchanInfoTmpTmp[0])){
            $tcfangchanInfoTmp = $tcfangchanInfoTmpTmp[0];
            $defaultHousesName = $tcfangchanInfoTmp['houses_name'];
            if($tcfangchanConfig['open_houses'] == 1){
                $defaultHousesId = $tcfangchanInfoTmp['houses_id'];
            }
            $defaultAreaId      = $tcfangchanInfoTmp['area_id'];
            $defaultAreaName    = $tcfangchanInfoTmp['area_name'];
            $defaultStreetId    = $tcfangchanInfoTmp['street_id'];
            $defaultStreetName  = $tcfangchanInfoTmp['street_name'];
            $defaultAddress     = $tcfangchanInfoTmp['address'];
            $defaultLatitude    = $tcfangchanInfoTmp['latitude'];
            $defaultLongitude   = $tcfangchanInfoTmp['longitude'];
        }
    }
    
    $chooseHousesUrl = $pczjUrl."&tmod=choose_houses";
    
    $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
    $syMendianFabuNum = $syAgentFabuNum  = 0;
    if($__UserInfo['editor'] == 0 && $agentInfo['id'] > 0 && $agentInfo['shenhe_status'] == 1){
        $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
        if($mendianInfo['id'] > 0){
            $mendian_fabu_num_tmp = $tcfangchanConfig['default_mendian_vip_agent_fabu_num'];
            $mendian_total_fabu_num = 0;
            if($tcfangchanConfig['open_mendian_vip'] == 1 && $mendianInfo['vip_id'] > 0){
                $mendianVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
                if($mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
                    $mendian_fabu_num_tmp = intval($mendianVipInfo['agent_fabu_num']);
                    $mendian_total_fabu_num = intval($mendianVipInfo['total_agent_fabu_num']);
                }
            }

            if($mendian_total_fabu_num > 0){
                $mendianFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND expire_status = 3 AND pay_type = 3 AND add_time > {$mendianInfo['vip_add_time']} ");
                if($mendianVipInfo['total_agent_fabu_num'] > $mendianFangchanCount){
                    $syMendianTotalFabuNum = $mendianVipInfo['total_agent_fabu_num'] - $mendianFangchanCount;

                    $mendianDayFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND mendian_id = {$mendianInfo['id']} AND type = 1 AND today_time = {$nowDayTime} ");
                    if($mendian_fabu_num_tmp > $mendianDayFabuCount){
                        $syMendianFabuNum = $mendian_fabu_num_tmp - $mendianDayFabuCount;
                        if($syMendianFabuNum > $syMendianTotalFabuNum){
                            $syMendianFabuNum = $syMendianTotalFabuNum;
                        }
                    }
                }
            }else{
                $mendianDayFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND mendian_id = {$mendianInfo['id']} AND type = 1 AND today_time = {$nowDayTime} ");
                if($mendian_fabu_num_tmp > $mendianDayFabuCount){
                    $syMendianFabuNum = $mendian_fabu_num_tmp - $mendianDayFabuCount;
                }
            }
        }

        if($tcfangchanConfig['open_agent_vip'] == 1 && $agentInfo['vip_id'] > 0 && $agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP){
            $agentVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
            $agent_fabu_num_tmp = intval($agentVipInfo['fabu_num']);

            if($agentVipInfo['total_fabu_num'] > 0){
                $agentFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND expire_status = 3  AND pay_type = 4 AND add_time > {$agentInfo['vip_add_time']}  ");
                if($agentVipInfo['total_fabu_num'] > $agentFangchanCount){
                    $syAgentTotalFabuNum = $agentVipInfo['total_fabu_num'] - $agentFangchanCount;

                    $agentFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND agent_id = {$agentInfo['id']} AND type = 5 AND today_time = {$nowDayTime} ");
                    if($agent_fabu_num_tmp > $agentFabuCount){
                        $syAgentFabuNum  = $agent_fabu_num_tmp - $agentFabuCount;
                        if($syAgentFabuNum > $syAgentTotalFabuNum){
                            $syAgentFabuNum = $syAgentTotalFabuNum;
                        }
                    }
                }
            }else{
                $agentFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND agent_id = {$agentInfo['id']} AND type = 5 AND today_time = {$nowDayTime} ");
                if($agent_fabu_num_tmp > $agentFabuCount){
                    $syAgentFabuNum  = $agent_fabu_num_tmp - $agentFabuCount;
                }
            }
        }
    }

    $syTotalFabuNum = $syMendianFabuNum + $syAgentFabuNum;
    
    $freeFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND type = 3  ");
    $syFreeFabuNum = $tcfangchanConfig['free_fabu_num'] - $freeFabuCount;
    $syFreeFabuNum = intval($syFreeFabuNum);
    if($syFreeFabuNum < 0){
        $syFreeFabuNum = 0;
    }
    
    $fangchanFabuList = array();
    $fangchan_fabu_list_str = str_replace("\r\n","{n}",$tcfangchanConfig['fangchan_fabu_list']);
    $fangchan_fabu_list_str = str_replace("\n","{n}",$fangchan_fabu_list_str);
    $fangchan_fabu_list_arr = explode("{n}", $fangchan_fabu_list_str);
    $i = 0;
    if(is_array($fangchan_fabu_list_arr) && !empty($fangchan_fabu_list_arr)){
        foreach ($fangchan_fabu_list_arr as $key => $value){
            $arr = explode("|", $value);

            $fangchanFabuList[$key]['days']             = $arr[0];
            $fangchanFabuList[$key]['price']            = $arr[1];
            $fangchanFabuList[$key]['desc']             = $arr[2];
            $fangchanFabuList[$key]['pay_score_status'] = 0;
            $fangchanFabuList[$key]['pay_score']        = 0;
            $fangchanFabuList[$key]['free_status']      = 0;

            if($i == 0 && $syFreeFabuNum > 0){
                $fangchanFabuList[$key]['free_status'] = 1;
            }

            if($tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                $fabu_pay_score = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
                if($fabu_pay_score > 0 && $__UserInfo['score'] >= $fabu_pay_score){
                    $fangchanFabuList[$key]['pay_score_status'] = 1;
                    $fangchanFabuList[$key]['pay_score'] = $fabu_pay_score;
                }
            }
            $i++;
        }
    }
    $addUrl = "plugin.php?id=tom_fcpc:pay&act=fangchan&tcfangchan_id={$tcfangchan_id}";
    
    if($tcfangchanInfo['model_id'] == 'ershoufang'){
    
        $isGbk = false;
        if (CHARSET == 'gbk') $isGbk = true;
        include template("tom_fcpc:zj/add2/ershoufang");

    }else if($tcfangchanInfo['model_id'] == 'chuzu'){

        $isGbk = false;
        if (CHARSET == 'gbk') $isGbk = true;
        include template("tom_fcpc:zj/add2/chuzu");

    }else if($tcfangchanInfo['model_id'] == 'shangpu'){

        $isGbk = false;
        if (CHARSET == 'gbk') $isGbk = true;
        include template("tom_fcpc:zj/add2/shangpu");

    }else if($tcfangchanInfo['model_id'] == 'xiezilou'){

        $isGbk = false;
        if (CHARSET == 'gbk') $isGbk = true;
        include template("tom_fcpc:zj/add2/xiezilou");

    }else if($tcfangchanInfo['model_id'] == 'changfang'){

        $isGbk = false;
        if (CHARSET == 'gbk') $isGbk = true;
        include template("tom_fcpc:zj/add2/changfang");

    }else if($tcfangchanInfo['model_id'] == 'cangku'){

        $isGbk = false;
        if (CHARSET == 'gbk') $isGbk = true;
        include template("tom_fcpc:zj/add2/cangku");

    }else if($tcfangchanInfo['model_id'] == 'tudi'){

        $isGbk = false;
        if (CHARSET == 'gbk') $isGbk = true;
        include template("tom_fcpc:zj/add2/tudi");

    }else{

        $isGbk = false;
        if (CHARSET == 'gbk') $isGbk = true;
        include template("tom_fcpc:zj/myfangchanlist");

    }
}else{
    
    $addUrl = $modPczjUrl."&act=add";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_fcpc:zj/add1");
}