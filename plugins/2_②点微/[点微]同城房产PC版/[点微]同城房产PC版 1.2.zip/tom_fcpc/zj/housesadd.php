<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPczjUrl = $pczjUrl."&tmod=housesadd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
if(empty($agentInfo)){
    dheader('location:'.$pczjUrl."&tmod=home");exit;
}

if($act == 'add' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id                = intval($_GET['site_id'])>0? intval($_GET['site_id']):1;
    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $city_id                = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id                = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id              = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $address                = isset($_GET['address'])? addslashes($_GET['address']):'';
    $lng                    = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                    = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $year                   = intval($_GET['year'])>0? intval($_GET['year']):0;
    $average_price          = intval($_GET['average_price'])>0? intval($_GET['average_price']):0;
    $open_auto_average      = intval($_GET['open_auto_average'])>0? intval($_GET['open_auto_average']):0;
    $chanquan               = intval($_GET['chanquan'])>0? intval($_GET['chanquan']):0;
    $developer_company      = isset($_GET['developer_company'])? addslashes($_GET['developer_company']):'';
    $parking_space          = intval($_GET['parking_space'])>0? intval($_GET['parking_space']):0;
    $plot_ratio             = floatval($_GET['plot_ratio'])>0? floatval($_GET['plot_ratio']):0.00;
    $greening_rate          = intval($_GET['greening_rate'])>0? intval($_GET['greening_rate']):0;
    $property_company       = isset($_GET['property_company'])? addslashes($_GET['property_company']):'';
    $property_price         = floatval($_GET['property_price'])>0? floatval($_GET['property_price']):0.00;
    $property_tel           = isset($_GET['property_tel'])? addslashes($_GET['property_tel']):'';
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photopsort_") !== false){
            $kk = intval(ltrim($key, "photopsort_"));
            $photoArr[$kk]['psort'] = addslashes($value);
        }
    }
    
    $typeStr = '';
    if(!empty($_GET['type_ids'])){
        $typeStr = '|'.implode('|', $_GET['type_ids']).'|';
    }
 
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    
    $insertData = array();
    $insertData['site_id']              = $site_id;
    $insertData['user_id']              = $__UserInfo['id'];
    $insertData['name']                 = $name;
    $insertData['type']                 = $typeStr;
    $insertData['city_id']              = $city_id;
    $insertData['area_id']              = $area_id;
    $insertData['area_name']            = $areaInfo['name'];
    $insertData['street_id']            = $street_id;
    $insertData['street_name']          = $streetInfo['name'];
    $insertData['year']                 = $year;
    $insertData['average_price']        = $average_price;
    $insertData['open_auto_average']    = $open_auto_average;
    $insertData['chanquan']             = $chanquan;
    $insertData['address']              = $address;
    $insertData['latitude']             = $lat;
    $insertData['longitude']            = $lng;
    $insertData['developer_company']    = $developer_company;
    $insertData['parking_space']        = $parking_space;
    $insertData['plot_ratio']           = $plot_ratio;
    $insertData['greening_rate']        = $greening_rate;
    $insertData['property_company']     = $property_company;
    $insertData['property_price']       = $property_price;
    $insertData['property_tel']         = $property_tel;
    $insertData['shenhe_status']        = 2;
    $insertData['status']               = 1;
    $insertData['update_time']          = TIMESTAMP;
    $insertData['add_time']             = TIMESTAMP;
    if(C::t("#tom_tcfangchan#tom_tcfangchan_houses")->insert($insertData)){
        
        $houses_id = C::t("#tom_tcfangchan#tom_tcfangchan_houses")->insert_id();

        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['houses_id']    = $houses_id;
                $insertData['type']         = 1;
                $insertData['picurl']       = $value['picurl'];
                $insertData['psort']        = $value['psort'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tcfangchan#tom_tcfangchan_photo')->insert($insertData);
            }
        }
        if(!empty($tongchengConfig['template_id'])){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_houses_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($fcmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_houses_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        
        if($houses_id > 0){
            $outArr = array(
                'code'=> 200,
                'id'=> $houses_id,
            );
            echo json_encode($outArr); exit;
        }
    }
    echo json_encode($outArr); exit;
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$__CityInfo = array();
if(!empty($tongchengConfig['city_id'])){
    $__CityInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);

$addUrl = $modPczjUrl."&act=add";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:zj/housesadd");