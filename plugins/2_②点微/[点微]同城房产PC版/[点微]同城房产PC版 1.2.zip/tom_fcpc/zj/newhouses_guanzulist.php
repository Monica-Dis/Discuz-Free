<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type          = intval($_GET['type'])>0? intval($_GET['type']):0;
$newhouses_id  = intval($_GET['newhouses_id'])>0? intval($_GET['newhouses_id']):0;

$newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($newhouses_id);

$newhousesManageInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_manage")->fetch_by_user_id($__UserInfo['id']);
if($newhousesManageInfo['id'] > 0 && $__UserInfo['id'] == $newhousesInfo['user_id']){ }else{
    dheader('location:'.$_G['siteurl']."{$pczjUrl}&tmod=home");exit;
}

$modPczjUrl = $pczjUrl."&tmod=newhouses_guanzulist&newhouses_id={$newhouses_id}&type={$type}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'list' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $page       = intval($_GET['page'])>0 ? intval($_GET['page']) :1;
    $pagesize   = intval($_GET['pagesize'])>0 ? intval($_GET['pagesize']) :10;
    
    $where = " AND newhouses_id = {$newhouses_id} ";
    
    if($type > 0){
        $where .= " AND type = {$type} ";
    }
    
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_guanzu')->fetch_all_count($where);
    $guanzuListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_guanzu')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    $guanzuList = array();
    if(!empty($guanzuListTmp)){
        foreach($guanzuListTmp as $key => $value){
            $guanzuList[$key] = $value;
            
            $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
            
            $guanzuList[$key]['userInfo'] = $userInfoTmp;
            $guanzuList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        }
    }

    $list = iconv_to_utf8($guanzuList);
    
    $outArr = array(
        'code'  => 0,
        'msg'   => '',
        'count' => $count,
        'data'  => $list,
    );
    echo json_encode($outArr); exit;
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:zj/newhouses_guanzulist");