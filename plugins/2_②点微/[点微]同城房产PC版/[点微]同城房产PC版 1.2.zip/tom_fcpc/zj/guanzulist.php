<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcfangchan_id  = intval($_GET['tcfangchan_id'])>0? intval($_GET['tcfangchan_id']):0;

$tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($tcfangchan_id);

$modPczjUrl  = $pczjUrl."&tmod=guanzulist&tcfangchan_id={$tcfangchan_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'list' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $page       = intval($_GET['page'])>0 ? intval($_GET['page']) :1;
    $pagesize   = intval($_GET['pagesize'])>0 ? intval($_GET['pagesize']) :10;
    
    $where = " AND tcfangchan_id = {$tcfangchan_id} ";
    
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_guanzu')->fetch_all_count($where);
    $guanzuListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_guanzu')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    $guanzuList = array();
    if(!empty($guanzuListTmp)){
        foreach($guanzuListTmp as $key => $value){
            $guanzuList[$key] = $value;
            
            $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
            
            $guanzuList[$key]['userInfo'] = $userInfoTmp;
            $guanzuList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        }
    }
    
    $list = iconv_to_utf8($guanzuList);
    
    $outArr = array(
        'code'  => 0,
        'msg'   => '',
        'count' => $count,
        'data'  => $list,
    );
    echo json_encode($outArr); exit;
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:zj/guanzulist");