<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPczjUrl = $pczjUrl."&tmod=myagent";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('agent_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $agent_id       = intval($_GET['agent_id'])>0? intval($_GET['agent_id']):0;
    
    $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($agent_id);
    if($agentInfo['mendian_shenhe_id'] > 0){
        $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($agentInfo['mendian_shenhe_id']);
    }else{
        $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($agentInfo['mendian_id']);
    }
    
    if($mendianInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'code'=> 404,
        );    
        echo json_encode($outArr); exit;
    }
    if($agentInfo['user_id'] == $mendianInfo['user_id']){
        $outArr = array(
            'code'=> 404,
        );    
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['mendian_id']               = 0;
    $updateData['mendian_shenhe_status']    = 0;
    $updateData['mendian_shenhe_id']        = 0;
    
    if(C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($agent_id,$updateData)){
        
        update_mendian_xinxi($mendianInfo['id']);
        
        if(!empty($tongchengConfig['template_id']) && $agentInfo['user_id'] > 0){

            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $template_sms = lang('plugin/tom_tcfangchan', 'template_myagent_del_msg');
            $template_sms = str_replace("{NAME}", $mendianInfo['name'], $template_sms);

            $agentInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($agentInfo['user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($agentInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");
                $smsData = array(
                    'first'         => $template_sms,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                @$r = $templateSmsClass->sendSms01($agentInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        $outArr = array(
            'code'=> 200,
        );    
        echo json_encode($outArr); exit;
    }
    
    $outArr = array(
        'code'=> 1,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'shenhe_ok' && submitcheck('agent_id')){
    
    $agent_id    = intval($_GET['agent_id'])>0? intval($_GET['agent_id']):0;
    
    $agentInfo   = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($agent_id);
    $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($agentInfo['mendian_shenhe_id']);
    
    if($mendianInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'code'=> 404,
        );    
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['mendian_id']               = $mendianInfo['id'];
    $updateData['shenhe_status']            = 1;
    $updateData['mendian_shenhe_status']    = 1;
    $updateData['mendian_shenhe_id']        = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($agent_id,$updateData);
    
    if(!empty($tongchengConfig['template_id']) && $agentInfo['user_id'] > 0){
        
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        
        $template_sms = lang('plugin/tom_tcfangchan', 'template_agent_shenhe_status_1_msg');
        $template_sms = str_replace("{NAME}", $mendianInfo['name'], $template_sms);

        $agentInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($agentInfo['user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($agentInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");
            $smsData = array(
                'first'         => $template_sms,
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($agentInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
    
}

$mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_user_id($__UserInfo['id']);

if(empty($mendianInfo)){
    dheader('location:'.$pczjUrl."&tmod=home");exit;
}

$mendian_shenhe_status   = isset($_GET['mendian_shenhe_status'])? intval($_GET['mendian_shenhe_status']):0;
$keyword                 = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page                    = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize                = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = " AND (mendian_id = {$mendianInfo['id']} OR mendian_shenhe_id = {$mendianInfo['id']}) ";

if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    $whereStr .= " AND (name LIKE '%{$keyword}%' OR tel LIKE '%{$keyword}%')";
}
if(!empty($mendian_shenhe_status)){
    $whereStr.= " AND mendian_shenhe_status={$mendian_shenhe_status} ";
}

$order = "ORDER BY id DESC";

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_agent_count($whereStr);
$agentListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_agent_list($whereStr,$order,$start,$pagesize);
$agentList = array();
if(!empty($agentListTmp)){
    foreach ($agentListTmp as $key => $value) {
        $agentList[$key] = $value;
        
        $agentList[$key]['avatar']      = get_file_url($value['avatar']);
        
        $ershoufangCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_user_houses_count(" AND user_id = {$value['user_id']} AND model_id = 'ershoufang' AND status=1 AND shenhe_status=1 AND finish = 0 ");
        $chuzuCount      = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_user_houses_count(" AND user_id = {$value['user_id']} AND model_id = 'chuzu' AND status=1 AND shenhe_status=1 AND finish = 0 ");
        $otherCount      = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_user_houses_count(" AND user_id = {$value['user_id']} AND model_id IN('shangpu','xiezilou','changfang','cangku','tudi') AND status=1 AND shenhe_status=1 AND finish = 0 ");
        $userInfoTmp     = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $agentList[$key]['ershoufangCount'] = $ershoufangCount;
        $agentList[$key]['chuzuCount']      = $chuzuCount;
        $agentList[$key]['otherCount']      = $otherCount;
        $agentList[$key]['userInfo']        = $userInfoTmp;
        $agentList[$key]['add_time']        = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPczjUrl."&mendian_shenhe_status={$mendian_shenhe_status}&keyword={$keyword}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:zj/myagent");