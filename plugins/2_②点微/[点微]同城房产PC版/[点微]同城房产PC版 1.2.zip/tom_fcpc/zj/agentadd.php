<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
if($agentInfo['id'] > 0){
    dheader('location:'.$pczjUrl."&tmod=home");exit;
}

$modPczjUrl = $pczjUrl."&tmod=agentadd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $mendian_id             = intval($_GET['mendian_id'])? intval($_GET['mendian_id']):0;
    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name                   = dhtmlspecialchars($name);
    $tel                    = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                    = dhtmlspecialchars($tel);
    $mendian_name           = isset($_GET['mendian_name'])? addslashes($_GET['mendian_name']):'';
    $mendian_name           = dhtmlspecialchars($mendian_name);
    $avatar                 = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $avatar                 = dhtmlspecialchars($avatar);
    $wx_qrcode              = isset($_GET['wx_qrcode'])? addslashes($_GET['wx_qrcode']):'';
    $wx_qrcode              = dhtmlspecialchars($wx_qrcode);
    
    $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
    if(is_array($agentInfo) && !empty($agentInfo)){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['agentadd_do_error_301'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($mendian_id);
   
    if($mendianInfo && $mendianInfo['id'] > 0 && $tcfangchanConfig['open_mendian_vip'] == 1 && $tcfangchanConfig['open_mendian_vip_agent'] == 1){
        $mendian_agent_num_tmp = $tcfangchanConfig['default_mendian_vip_agent_num'];
        if($mendianInfo['vip_id'] > 0 && $mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
            $vipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
            $mendian_agent_num_tmp = intval($vipInfo['agent_num']);
        }
        $agentCount = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_count( " AND mendian_id = {$mendianInfo['id']} ");
        if($agentCount >= $mendian_agent_num_tmp){
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['agentadd_do_error_302'],CHARSET,'utf-8'),
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $insertData = array();
    if($mendianInfo && $mendianInfo['id'] > 0){
        $insertData['site_id']              = $mendianInfo['site_id'];
        $insertData['mendian_name']         = $mendianInfo['name'];
    }else{
        $insertData['site_id']              = $site_id;
        $insertData['mendian_name']         = $mendian_name;
    }
    $insertData['user_id']              = $__UserInfo['id'];
    $insertData['avatar']               = $avatar;
    $insertData['name']                 = $name;
    $insertData['tel']                  = $tel;
    $insertData['wx_qrcode']            = $wx_qrcode;
    if($tcfangchanConfig['agent_must_shenhe'] == 1){
        $insertData['shenhe_status']    = 2;
    }else{
        $insertData['shenhe_status']    = 1;
    }
    if($mendianInfo && $mendianInfo['id'] > 0){
        $insertData['mendian_shenhe_status']    = 2;
        $insertData['mendian_shenhe_id']        = $mendianInfo['id'];
    }else{
        $insertData['mendian_shenhe_status']    = 0;
        $insertData['mendian_shenhe_id']        = 0;
    }
    $insertData['is_ok']                = 1;
    $insertData['add_time']             = TIMESTAMP;
    if(C::t("#tom_tcfangchan#tom_tcfangchan_agent")->insert($insertData)){

        DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET source_type=1 WHERE user_id = {$__UserInfo['id']} ", 'UNBUFFERED');

        if(!empty($tongchengConfig['template_id'])){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            if($mendianInfo && $mendianInfo['id'] > 0){
                $mendianUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($mendianInfo['user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($mendianUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myagent");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcfangchan', 'template_ruzhu_agent_shenhe_msg'),
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );
                    @$r = $templateSmsClass->sendSms01($mendianUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }else if($tcfangchanConfig['agent_must_shenhe'] == 1){
                $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($manageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerAgentList");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcfangchan', 'template_ruzhu_agent_shenhe_msg'),
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );
                    @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
                $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($fcmanageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerAgentList");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcfangchan', 'template_ruzhu_agent_shenhe_msg'),
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );
                    @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }
            
        }

        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    $outArr = array(
        'code'=> 404,
    );
    echo json_encode($outArr); exit;
}

$chooseMendianUrl = $pczjUrl."&tmod=choose_mendian";

$showMustPhoneBtn = 0;
if($tcfangchanConfig['agent_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my";
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = $_G['m_siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$saveUrl = $modPczjUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:zj/agentadd");