<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function list_houses($housesListTmp){
    global $_G,$tcfangchanConfig,$site_id,$tomSysOffset,$houseTypeArr;
    
    $housesList = array();
    if(is_array($housesListTmp) && !empty($housesListTmp)){

        $housesIdsArrTmp = array();
        foreach ($housesListTmp as $key => $value) {
            $housesIdsArrTmp[]   = $value['id'];
        }
        
        foreach ($housesListTmp as $key => $value) {
            $housesList[$key] = $value;
            
            $typeList = array();
            if(!empty($value['type'])){
                $typeListTmp = explode('|', trim($value['type'], '|'));
                if(is_array($typeListTmp) && !empty($typeListTmp)){
                    foreach ($typeListTmp as $k => $v){
                        if(!empty($v)){
                            $typeList[] = $houseTypeArr[$v];
                        }
                    }
                }
            }
            
            $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND houses_id = {$value['id']} AND type = 1 ", 'ORDER BY id ASC', 0, 1);
            $picurlTmp = '';
            if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
                $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
            }else{
                $picurlTmp = $tcfangchanConfig['default_houses_photo'];
            }
            
            $sellFangchanCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count("  AND houses_id = {$value['id']} AND model_id = 'ershoufang' AND status=1 AND shenhe_status=1 AND finish = 0 AND ((pay_status = 0) OR (pay_status = 2)) ");
            $chuzuFangchanCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count("  AND houses_id = {$value['id']} AND model_id = 'chuzu' AND status=1 AND shenhe_status=1 AND finish = 0 AND ((pay_status = 0) OR (pay_status = 2)) ");
          
            $housesList[$key]['picurl']                = $picurlTmp;
            $housesList[$key]['typeList']              = $typeList;
            $housesList[$key]['sellFangchanCount']     = $sellFangchanCount;
            $housesList[$key]['chuzuFangchanCount']    = $chuzuFangchanCount;
            $housesList[$key]['link']                  = tom_fcpc_url('housesinfo',$site_id,array('houses_id'=>$value['id']));
        }
    }
    return $housesList;
}