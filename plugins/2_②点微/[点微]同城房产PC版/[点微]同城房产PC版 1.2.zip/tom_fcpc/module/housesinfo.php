<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$houses_id  = intval($_GET['houses_id'])>0? intval($_GET['houses_id']):0;

if($__Mobile == 1 && $fcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=housesinfo&houses_id={$houses_id}");exit;
}

$housesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($houses_id);

if($housesInfo['status'] == 1 && $housesInfo['shenhe_status'] == 1){
}else{
    dheader('location:'."{$houseslistUrl}");exit;
}

$sellFangchanCount  = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count("  AND houses_id = {$houses_id} AND model_id = 'ershoufang' AND status=1 AND shenhe_status=1 AND finish = 0 AND ((pay_status = 0) OR (pay_status = 2)) ");
$chuzuFangchanCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count("  AND houses_id = {$houses_id} AND model_id = 'chuzu' AND status=1 AND shenhe_status=1 AND finish = 0 AND ((pay_status = 0) OR (pay_status = 2)) ");

if($housesInfo['area_id'] > 0){
    $areaUrl    = tom_fcpc_url('houseslist',$site_id,array('area_id'=>$housesInfo['area_id']));
}

if($housesInfo['street_id'] > 0){
    $streetUrl  = tom_fcpc_url('houseslist',$site_id,array('area_id'=>$housesInfo['area_id'],'street_id'=>$housesInfo['street_id']));
}

$housesTypeStr = '';
if(!empty($housesInfo['type'])){
    $typeArr = explode('|', trim($housesInfo['type'], '|'));
    $housesTypeList = array();
    if(is_array($houseTypeArr) && !empty($houseTypeArr)){
        foreach($houseTypeArr as $key => $value){
            if(in_array($key, $typeArr)){
                $housesTypeList[] = $value;
            }
        }
    }
    $housesTypeStr = implode(' ', $housesTypeList);
}

if($housesInfo['open_auto_average'] == 1){
    if(TIMESTAMP > ($housesInfo['last_auto_time'] + 7 * 86400)){
        $sanMonthTime = TIMESTAMP - 90 * 86400;
        $totalInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_houses_average_price_sum_list(" AND price > 0 AND houses_id = {$housesInfo['id']} AND model_id = 'ershoufang' AND refresh_time > {$sanMonthTime} AND shenhe_status = 1 AND status = 1 AND finish = 0 AND (pay_status = 0 OR pay_status = 2) ");
        $average_price_tmp = 0;
        if(is_array($totalInfo) && !empty($totalInfo)){
            $average_price_tmp = ($totalInfo['totalprice'] * 10000)/$totalInfo['totalmanji'];
            $average_price_tmp = intval($average_price_tmp);
            $updateData = array();
            $updateData['average_price'] = $average_price_tmp;
            $updateData['last_auto_time'] = TIMESTAMP;
            C::t('#tom_tcfangchan#tom_tcfangchan_houses')->update($housesInfo['id'], $updateData);
        }
        $housesInfo['average_price'] = $average_price_tmp;
    }
}

$photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND houses_id={$houses_id} AND type  = 1 "," ORDER BY type DESC,psort ASC,id ASC ",0,20);
$photoList = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];
        $photoList[] = $picurlTmp;
    }
}else{
    $default_houses_photo = $tcfangchanConfig['default_houses_photo'];
    $photoList[] = $default_houses_photo;
}
$photoCount   = count($photoList);

$guanzuStatus = 0;
if($__UserInfo['id'] > 0){
    $guanzuInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_houses_guanzu")->fetch_all_list(" AND houses_id = {$houses_id} AND user_id = {$__UserInfo['id']} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])){
        $guanzuStatus = 1;
    }
}

DB::query("UPDATE ".DB::table('tom_tcfangchan_houses')." SET clicks=clicks+1 WHERE id='{$houses_id}'", 'UNBUFFERED');

$ershoufangWhere   = " AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) AND houses_id = {$houses_id} AND model_id = 'ershoufang' ";
$chuzuWhere        = " AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) AND houses_id = {$houses_id} AND model_id = 'chuzu' ";

if($tcfangchanConfig['open_finish_ok_fangchan'] == 1){
}else{
    $ershoufangWhere .= ' AND finish = 0 ';
    $chuzuWhere .= ' AND finish = 0 ';
}
if(!empty($sql_in_site_ids)){
    $ershoufangWhere .= " AND site_id IN({$sql_in_site_ids}) ";
    $chuzuWhere .= " AND site_id IN({$sql_in_site_ids}) ";
}

$ershoufangListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($ershoufangWhere," ORDER BY top_status DESC,id DESC ",0,4);
$ershoufangList    = list_fangchan($ershoufangListTmp,1);

$chuzuListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($chuzuWhere," ORDER BY top_status DESC,id DESC ",0,4);
$chuzuList    = list_fangchan($chuzuListTmp,1);

$housesInfoUrl = tom_fcpc_url('housesinfo',$site_id,array('houses_id'=>$housesInfo['id']));

$ajaxUpdateGuanzuUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=update_houses_guanzu&user_id={$__UserInfo['id']}&houses_id={$houses_id}&formhash={$formhash}";

$seo_title          = $fcpcConfig['seo_housesinfo_title'];
$seo_title          = str_replace("{NAME}",$housesInfo['name'], $seo_title);
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);

$seo_keywords       = $fcpcConfig['seo_housesinfo_keywords'];
$seo_keywords       = str_replace("{NAME}",$housesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);

$seo_description    = $fcpcConfig['seo_housesinfo_description'];
$seo_description    = str_replace("{NAME}",$housesInfo['name'], $seo_description);
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:housesinfo");