<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$newhouses_id = intval($_GET['newhouses_id'])>0? intval($_GET['newhouses_id']):0;

if($__Mobile == 1 && $fcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesinfo&newhouses_id={$newhouses_id}");exit;
}

$newhousesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_by_id($newhouses_id);

if($newhousesInfo['status'] == 1){
}else{
    dheader('location:'."{$newhouseslistUrl}");exit;
}

if($newhousesInfo['area_id'] > 0){
    $areaUrl    = tom_fcpc_url('newhouseslist',$site_id,array('area_id'=>$newhousesInfo['area_id']));
}

if($newhousesInfo['street_id'] > 0){
    $streetUrl    = tom_fcpc_url('newhouseslist',$site_id,array('area_id'=>$newhousesInfo['area_id'],'street_id'=>$newhousesInfo['street_id']));
}

$teseTagsList = array();
if(!empty($newhousesInfo['tese_tags'])){
    $teseTagsList = explode('|', trim($newhousesInfo['tese_tags'], '|'));
}

$housesTypeStr = '';
if(!empty($newhousesInfo['type'])){
    $housesTypeList = array();
    $typeArr = explode('|', trim($newhousesInfo['type'], '|'));
    if(is_array($houseTypeArr) && !empty($houseTypeArr)){
        foreach($houseTypeArr as $key => $value){
            if(in_array($key, $typeArr)){
                $housesTypeList[] = $value;
            }
        }
        $housesTypeStr = implode(' ', $housesTypeList);
    }
}
    
$photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND newhouses_id={$newhouses_id} "," ORDER BY type DESC,psort ASC,id ASC ",0,100);
$photoList = $huxingList = array();
$vr_picurl = '';
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];

        if($value['type'] == 1){
            $photoList[] = $picurlTmp;
        }else if($value['type'] == 2){
            $vr_picurl = $picurlTmp;
        }else if($value['type'] == 3){
            $huxingList[$key] = $value;
            $huxingList[$key]['picurl'] = $picurlTmp;
        }
    }
}
$huxingCount = count($huxingList);

$adviserCount = 0;
if($tcfangchanConfig['open_newhouses_sale_adviser'] == 1 && $newhousesInfo['open_sale_adviser'] == 1){

    $nowTime = TIMESTAMP;
    $adviserListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_list(" AND newhouses_id={$newhouses_id} AND status = 1 AND shenhe_status = 1 AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) "," ORDER BY asort ASC,id ASC ");
    $adviserList = array();
    if(is_array($adviserListTmp) && !empty($adviserListTmp)){
        foreach($adviserListTmp as $key => $value){
            $adviserList[$key] = $value;
           
            if(!empty($value['avatar'])){
                if(!preg_match('/^http/', $value['avatar']) ){
                    if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                        $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
                    }else{
                        $avatarTmp = $_G['siteurl'].$value['avatar'];
                    }
                }else{
                    $avatarTmp = $value['avatar'];
                }
            }

            $is_wx_qrcode = 0;
            $wxQrcodeTmp = '';
            if(!empty($value['wx_qrcode'])){
                $is_wx_qrcode = 1;
                if(!preg_match('/^http/', $value['wx_qrcode']) ){
                    if(strpos($value['wx_qrcode'], 'source/plugin/tom_') === FALSE){
                        $wxQrcodeTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['wx_qrcode'];
                    }else{
                        $wxQrcodeTmp = $_G['siteurl'].$value['wx_qrcode'];
                    }
                }else{
                    $wxQrcodeTmp = $value['wx_qrcode'];
                }
            }

            $adviserList[$key]['avatar'] = $avatarTmp;
            $adviserList[$key]['wx_qrcode'] = $wxQrcodeTmp;
            $adviserList[$key]['is_wx_qrcode'] = $is_wx_qrcode;
        }
    }
    $adviserCount = count($adviserList);
}

$guanzuStatus = 0;
if($__UserInfo['id'] > 0){
    $guanzuInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_guanzu")->fetch_all_list(" AND newhouses_id = {$newhouses_id} AND user_id = {$__UserInfo['id']} AND type = 1 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])){
        $guanzuStatus = 1;
    }
}

$newhousesInfo['content'] = stripslashes($newhousesInfo['content']);
$newhousesInfo['content'] = str_replace("\r\n","<br/>",$newhousesInfo['content']);
$newhousesInfo['content'] = str_replace("\n","<br/>",$newhousesInfo['content']);
$newhousesInfo['content'] = str_replace("\r","<br/>",$newhousesInfo['content']);
$newhousesInfo['content'] = str_replace('src="source/plugin/', 'src="'.$_G['siteurl'].'source/plugin/', $newhousesInfo['content']);
$newhousesInfo['content'] = str_replace('src="data/attachment/', 'src="'.$_G['siteurl'].'data/attachment/', $newhousesInfo['content']);

$where = " AND status=1 AND id != {$newhousesInfo['id']} ";
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}

$newhousesCount   = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_count($where);
$newhousesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_list($where," ORDER BY top_status DESC,id DESC ",0,4);
$newhousesList = list_newhouses($newhousesListTmp);

DB::query("UPDATE ".DB::table('tom_tcfangchan_newhouses')." SET clicks=clicks+1 WHERE id='{$newhouses_id}'", 'UNBUFFERED');

$newhousesInfoUrl    = tom_fcpc_url('newhousesinfo',$site_id,array('newhouses_id'=>$newhousesInfo['id']));
$ajaxUpdateGuanzuUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=update_newhouses_guanzu&user_id={$__UserInfo['id']}&newhouses_id={$newhouses_id}&formhash={$formhash}";

$guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 7 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 7 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$seo_title          = $fcpcConfig['seo_newhousesinfo_title'];
$seo_title          = str_replace("{NAME}",$newhousesInfo['name'], $seo_title);
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);

$seo_keywords       = $fcpcConfig['seo_newhousesinfo_keywords'];
$seo_keywords       = str_replace("{NAME}",$newhousesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);

$seo_description    = $fcpcConfig['seo_newhousesinfo_description'];
$seo_description    = str_replace("{NAME}",$newhousesInfo['name'], $seo_description);
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:newhousesinfo");