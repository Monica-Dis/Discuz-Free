<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page               = intval($_GET['page'])>0 ? intval($_GET['page']):1;
$keyword            = isset($_GET['keyword'])? daddslashes(urldecode($_GET['keyword'])):'';
$keyword            = dhtmlspecialchars($keyword);
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$min_average_price  = intval($_GET['min_average_price'])>0? intval($_GET['min_average_price']):0;
$max_average_price  = intval($_GET['max_average_price'])>0? intval($_GET['max_average_price']):0;
$house_type         = intval($_GET['house_type'])>0? intval($_GET['house_type']):0;
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):0;

if($__Mobile == 1 && $fcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=houseslist&area_id={$area_id}&street_id={$street_id}");exit;
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$areaList = array();
if(is_array($areaListTmp) && !empty($areaListTmp)){
    $areaList = $areaListTmp;
}

$streetList = array();
if($area_id > 0){
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $areaUrl    = tom_fcpc_url('houseslist',$site_id,array('area_id'=>$area_id));
}

if($street_id > 0){
    $streetInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    $streetUrl    = tom_fcpc_url('houseslist',$site_id,array('area_id'=>$area_id,'street_id'=>$street_id));
}

$priceListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config")->fetch_all_list(" AND type = 2 ", 'ORDER BY csort ASC,id DESC', 0, 20);
$priceList = array();
if(is_array($priceListTmp) && !empty($priceListTmp)){
    foreach($priceListTmp as $key => $value){
        $priceList[$key] = $value;
    }
}

$where = ' AND status = 1 AND shenhe_status = 1 ';
$url = '';
$rewriteStatus = 1;
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}

if($area_id > 0){
    $where.= " AND area_id = {$area_id} ";
    $url .= "&area_id={$area_id}";
}

if($street_id > 0){
    $where.= " AND street_id = {$street_id} ";
    $url .= "&street_id={$street_id}";
}

if($min_average_price > 0){
    $rewriteStatus = 0;
    $where.= " AND average_price >= {$min_average_price} ";
    $url .= "&min_average_price={$min_average_price}";
}

if($max_average_price > 0){
    $rewriteStatus = 0;
    $where.= " AND average_price <= {$max_average_price} ";
    $url .= "&max_average_price={$max_average_price}";
}

if(!empty($keyword)){
    $rewriteStatus = 0;
    $url .= "&keyword={$keyword}";
}

$orderByWhere = "ORDER BY update_time DESC,clicks DESC,id DESC";

if($paixu_type > 0){
    $rewriteStatus = 0;
    if($paixu_type == 1){
        $orderByWhere = "ORDER BY average_price ASC,update_time DESC,id DESC";
    }else if($paixu_type == 2){
        $orderByWhere = "ORDER BY average_price DESC,update_time DESC,id DESC";
    }
    $url .= "&paixu_type={$paixu_type}";
}

$pagesize = 20;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_count($where);

$housesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_list($where,$orderByWhere,$start,$pagesize,$keyword,$house_type);
$housesList = list_houses($housesListTmp);

if($rewriteStatus == 1){
    $pageArr['link'] = tom_fcpc_url('houseslist',$site_id,array('area_id'=>$area_id,'street_id'=>$street_id,'page'=>'{page}'));
}else{
    $pageArr['link']  = $_G['siteurl']."plugin.php?id=tom_fcpc&site={$site_id}&mod=houseslist&{$url}&page={page}";
}
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 10 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 10 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$seo_title          = $fcpcConfig['seo_houseslist_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{PAGE}",$page, $seo_title);

$seo_keywords       = $fcpcConfig['seo_houseslist_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{PAGE}",$page, $seo_keywords);

$seo_description    = $fcpcConfig['seo_houseslist_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{PAGE}",$page, $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:houseslist");