<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$needs_id  = intval($_GET['needs_id'])>0? intval($_GET['needs_id']):0;

if($__Mobile == 1 && $fcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=needsinfo&needs_id={$needs_id}");exit;
}

$needsInfo = C::t("#tom_tcfangchan#tom_tcfangchan_needs")->fetch_by_id($needs_id);

if($needsInfo['status'] == 1 && $needsInfo['shenhe_status'] == 1){
}else{
    dheader('location:'."{$needslistUrl}");exit;
}

$userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);

if(!preg_match('/^http/', $userInfo['picurl']) ){
    $userInfo['picurl'] = $_G['siteurl'].$userInfo['picurl'];
}

if($needsInfo['area_id'] > 0){
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($needsInfo['area_id']);
    $areaUrl    = tom_fcpc_url('needslist',$site_id,array('area_id'=>$needsInfo['area_id']));
}
if($needsInfo['street_id'] > 0){
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($needsInfo['street_id']);
    $streetUrl  = tom_fcpc_url('needslist',$site_id,array('area_id'=>$needsInfo['area_id'],'street_id'=>$needsInfo['street_id']));
}

$content = stripslashes($needsInfo['content']);
$content = str_replace("\r\n","<br/>",$content);
$content = str_replace("\n","<br/>",$content);
$content = str_replace("\r","<br/>",$content);
if($tcfangchanConfig['open_contact_needs_price'] == 1){
    $content = preg_replace("/\d{7}/", '*****', $content);
}

$add_time   = dgmdate($needsInfo['add_time'], 'u','9999','m-d H:i');

$orderContactInfo = array();
if($__UserInfo['id'] > 0){
    $orderContactInfo   = C::t('#tom_tcfangchan#tom_tcfangchan_order')->fetch_all_list("AND type = 11 AND order_status = 2 AND needs_id = {$needs_id} AND user_id = {$__UserInfo['id']}");
}

$ndsInfoUrl   = tom_fcpc_url('needsinfo',$site_id,array('needs_id'=>$needsInfo['id']));
$needsInfoUrl = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=needsinfo&needs_id={$needsInfo['id']}";

$where = " AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND type= {$needsInfo['type']} AND id != {$needsInfo['id']} ";

if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}

$order = " ORDER BY top_status DESC,top_time DESC,refresh_time DESC,id DESC ";

$count = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_count($where);
$needsListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_list($where,$order,0,8);
$needsList = list_needs($needsListTmp);

$guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 16 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 16 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$seo_title          = $fcpcConfig['seo_needsinfo_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{NICKNAME}",$userInfo['nickname'], $seo_title);

$seo_keywords       = $fcpcConfig['seo_needsinfo_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{NICKNAME}",$userInfo['nickname'], $seo_keywords);

$seo_description    = $fcpcConfig['seo_needsinfo_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{NICKNAME}",$userInfo['nickname'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:needsinfo");