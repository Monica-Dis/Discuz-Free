<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page               = intval($_GET['page'])>0 ? intval($_GET['page']):1;
$keyword            = isset($_GET['keyword'])? daddslashes(urldecode($_GET['keyword'])):'';
$keyword            = dhtmlspecialchars($keyword);
$model_id           = isset($_GET['model_id'])? addslashes($_GET['model_id']):'ershoufang';
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$houses_min_price   = intval($_GET['houses_min_price'])>0? intval($_GET['houses_min_price']):0;
$houses_max_price   = intval($_GET['houses_max_price'])>0? intval($_GET['houses_max_price']):0;
$house_type         = intval($_GET['house_type'])>0? intval($_GET['house_type']):0;
$shi                = intval($_GET['shi'])>0? intval($_GET['shi']):0;
$source_type        = intval($_GET['source_type'])>0? intval($_GET['source_type']):0;
$min_mianji         = intval($_GET['min_mianji'])>0? intval($_GET['min_mianji']):0;
$max_mianji         = intval($_GET['max_mianji'])>0? intval($_GET['max_mianji']):0;
$chaoxiang_type     = intval($_GET['chaoxiang_type'])>0? intval($_GET['chaoxiang_type']):0;
$zhuangxiu_type     = intval($_GET['zhuangxiu_type'])>0? intval($_GET['zhuangxiu_type']):0;
$elevator           = intval($_GET['elevator'])>0? intval($_GET['elevator']):0;
$min_rent           = intval($_GET['min_rent'])>0? intval($_GET['min_rent']):0;
$max_rent           = intval($_GET['max_rent'])>0? intval($_GET['max_rent']):0;
$lease              = intval($_GET['lease'])>0? intval($_GET['lease']):0;
$rent_type          = intval($_GET['rent_type'])>0? intval($_GET['rent_type']):0;
$fangchan_nature    = intval($_GET['fangchan_nature'])>0? intval($_GET['fangchan_nature']):0;
$houses_id          = intval($_GET['houses_id'])>0? intval($_GET['houses_id']):0;
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):0;
$open_type          = intval($_GET['open_type'])>0? intval($_GET['open_type']):0;

if($__Mobile == 1 && $fcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=list&model_id={$model_id}&area_id={$area_id}&street_id={$street_id}");exit;
}

if($model_id == 'ershoufang' ){
    $search_type = 'ershoufang';
}else if($model_id == 'chuzu' ){
    $search_type = 'chuzu';
}else if($model_id == 'shangpu' ){
    $search_type = 'shangpu';
}else if($model_id == 'xiezilou' ){
    $search_type = 'xiezilou';
}else if($model_id == 'changfang' ){
    $search_type = 'changfang';
}else if($model_id == 'cangku' ){
    $search_type = 'cangku';
}else if($model_id == 'tudi' ){
    $search_type = 'tudi';
}else{
    dheader('location:'."{$indexUrl}");exit;
}
$nav_type = $search_type;

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$areaList = array();
if(is_array($areaListTmp) && !empty($areaListTmp)){
    $areaList = $areaListTmp;
}

$streetList = array();
if($area_id > 0){
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $areaUrl    = tom_fcpc_url('list',$site_id,array('model_id'=>$model_id,'area_id'=>$area_id));
}

if($street_id > 0){
    $streetInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    $streetUrl    = tom_fcpc_url('list',$site_id,array('model_id'=>$model_id,'area_id'=>$area_id,'street_id'=>$street_id));
}

if($model_id == 'ershoufang'){
    $configListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config")->fetch_all_list(" AND type IN(1,4) ", 'ORDER BY csort ASC,id DESC', 0, 20);
    $priceList = $mianjiList = array();
    if(is_array($configListTmp) && !empty($configListTmp)){
        foreach($configListTmp as $key => $value){
            if($value['type'] == 1){
                $priceList[$key] = $value;
            }else if($value['type'] == 4){
                $mianjiList[$key] = $value;
            }
        }
    }
}else if($model_id == 'chuzu'){
    $priceListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config")->fetch_all_list(" AND type = 3", 'ORDER BY csort ASC,id DESC', 0, 20);
    $priceList = array();
    if(is_array($priceListTmp) && !empty($priceListTmp)){
        foreach($priceListTmp as $key => $value){
            $priceList[$key] = $value;
        }
    }
}else if($model_id == 'shangpu' || $model_id == 'xiezilou'){
    $mianjiListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config")->fetch_all_list(" AND type = 5 ", 'ORDER BY csort ASC,id DESC', 0, 20);
    $mianjiList = array();
    if(is_array($mianjiListTmp) && !empty($mianjiListTmp)){
        foreach($mianjiListTmp as $key => $value){
            $mianjiList[$key] = $value;
        }
    }
}else if($model_id == 'changfang' || $model_id == 'cangku' || $model_id == 'tudi'){
    $mianjiListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config")->fetch_all_list(" AND type = 6 ", 'ORDER BY csort ASC,id DESC', 0, 20);
    $mianjiList = array();
    if(is_array($mianjiListTmp) && !empty($mianjiListTmp)){
        foreach($mianjiListTmp as $key => $value){
            $mianjiList[$key] = $value;
        }
    }
}

$where = " AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) AND model_id = '{$model_id}' ";
$url = '';
$rewriteStatus = 1;
if($tcfangchanConfig['open_finish_ok_fangchan'] == 1){
}else{
    $where .= ' AND finish = 0 ';
}
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($model_id)){
    $where .= " AND model_id = '{$model_id}' ";
    $url .= "&model_id={$model_id}";
}
if($area_id > 0){
    $where.= " AND area_id = {$area_id} ";
    $url .= "&area_id={$area_id}";
}
if($street_id > 0){
    $where.= " AND street_id = {$street_id} ";
    $url .= "&street_id={$street_id}";
}
if($houses_min_price > 0){
    $rewriteStatus = 0;
    $where .= " AND price>={$houses_min_price} ";
    $url .= "&houses_min_price={$houses_min_price}";
}
if($houses_max_price > 0){
    $rewriteStatus = 0;
    $where .= " AND price<={$houses_max_price} ";
    $url .= "&houses_max_price={$houses_max_price}";
}
if($source_type > 0){
    $rewriteStatus = 0;
    $where .= " AND source_type ={$source_type} ";
    $url .= "&source_type={$source_type}";
}
if($fangchan_nature > 0){
    $rewriteStatus = 0;
    $where .= " AND fangchan_nature ={$fangchan_nature} ";
    $url .= "&fangchan_nature={$fangchan_nature}";
}
if($min_mianji > 0){
    $rewriteStatus = 0;
    $where .= " AND mianji >={$min_mianji} ";
    $url .= "&min_mianji={$min_mianji}";
}
if($max_mianji > 0){
    $where .= " AND mianji <={$max_mianji} ";
    $url .= "&max_mianji={$max_mianji}";
}
if($min_rent > 0){
    $rewriteStatus = 0;
    $where .= " AND rent>={$min_rent} ";
    $url .= "&min_rent={$min_rent}";
}
if($max_rent > 0){
    $rewriteStatus = 0;
    $where .= " AND rent<={$max_rent} ";
    $url .= "&max_rent={$max_rent}";
}
if($houses_id > 0){
    $rewriteStatus = 0;
    $where .= " AND houses_id ={$houses_id} ";
    $url .= "&houses_id={$houses_id}";
}
$attrWhere = '';
if($house_type > 0){
    $rewriteStatus = 0;
    $attrWhere .= " AND attr_house_type ={$house_type} ";
    $url .= "&house_type={$house_type}";
}
if($shi > 0){
    $rewriteStatus = 0;
    if($shi == 99){
        $attrWhere .= " AND attr_shi > 5 ";
    }else{
        $attrWhere .= " AND attr_shi ={$shi} ";
    }
    $url .= "&shi={$shi}";
}
if($chaoxiang_type > 0){
    $rewriteStatus = 0;
    $attrWhere .= " AND attr_chaoxiang_type ={$chaoxiang_type} ";
    $url .= "&chaoxiang_type={$chaoxiang_type}";
}
if($zhuangxiu_type > 0){
    $rewriteStatus = 0;
    $attrWhere .= " AND attr_zhuangxiu_type ={$zhuangxiu_type} ";
    $url .= "&zhuangxiu_type={$zhuangxiu_type}";
}
if($elevator > 0){
    $rewriteStatus = 0;
    $attrWhere .= " AND attr_elevator ={$elevator} ";
    $url .= "&elevator={$elevator}";
}
if($lease > 0){
    $rewriteStatus = 0;
    $attrWhere .= " AND attr_lease_type ={$lease} ";
    $url .= "&lease={$lease}";
}
if($rent_type > 0){
    $rewriteStatus = 0;
    $attrWhere .= " AND attr_rent_type ={$rent_type} ";
    $url .= "&rent_type={$rent_type}";
}

$tcfangchanIdsList = array();
if(!empty($attrWhere)){
    $tcfangchanIdsListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_attr")->fetch_all_tcfangchan_id($attrWhere,"ORDER BY attr_id DESC");
    
    $tcfangchanIdsArr = array();
    if(is_array($tcfangchanIdsListTmp) && !empty($tcfangchanIdsListTmp)){
        foreach($tcfangchanIdsListTmp as $key => $value){
            $tcfangchanIdsArr[$value['tcfangchan_id']] = $value['tcfangchan_id'];
        }
    }
    
    if(is_array($tcfangchanIdsArr) && !empty($tcfangchanIdsArr)){
        $tcfangchanIdsList = $tcfangchanIdsArr;
    }else{
        $where.= " AND id = 9999999 ";
    }
}

if(is_array($tcfangchanIdsList) && !empty($tcfangchanIdsList)){
    $tcfangchanIdsStr = implode(',', $tcfangchanIdsList);
    $where.= " AND id IN ({$tcfangchanIdsStr}) ";
}

if(!empty($keyword)){
    $rewriteStatus = 0;
    $url .= "&keyword={$keyword}";
}

$orderByWhere = "ORDER BY finish ASC,top_status DESC,refresh_time DESC,id DESC";
if($paixu_type > 0){
    $rewriteStatus = 0;
    if($paixu_type == 1){
        $orderByWhere = "ORDER BY finish ASC,top_status DESC,price ASC,refresh_time DESC,id DESC";
    }else if($paixu_type == 2){
        $orderByWhere = "ORDER BY finish ASC,top_status DESC,price DESC,refresh_time DESC,id DESC";
    }else if($paixu_type == 3){
        $orderByWhere = "ORDER BY finish ASC,top_status DESC,mianji ASC,refresh_time DESC,id DESC";
    }else if($paixu_type == 4){
        $orderByWhere = "ORDER BY finish ASC,top_status DESC,mianji DESC,refresh_time DESC,id DESC";
    }
    $url .= "&paixu_type={$paixu_type}";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count($where);

$fangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($where,$orderByWhere,$start,$pagesize,$keyword);
$fangchanList = list_fangchan($fangchanListTmp,0);

if($rewriteStatus == 1){
    $pageArr['link'] = tom_fcpc_url('list',$site_id,array('model_id'=>$model_id,'area_id'=>$area_id,'street_id'=>$street_id,'page'=>'{page}'));
}else{
    $pageArr['link']  = $_G['siteurl']."plugin.php?id=tom_fcpc&site={$site_id}&mod=list&{$url}&page={page}";
}
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 8 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 8 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$seo_model_name = lang('plugin/tom_fcpc', "{$model_id}");

$seo_title          = $fcpcConfig['seo_list_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{MODELNAME}",$seo_model_name, $seo_title);
$seo_title          = str_replace("{PAGE}",$page, $seo_title);

$seo_keywords       = $fcpcConfig['seo_list_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{MODELNAME}",$seo_model_name, $seo_keywords);
$seo_keywords       = str_replace("{PAGE}",$page, $seo_keywords);

$seo_description    = $fcpcConfig['seo_list_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{MODELNAME}",$seo_model_name, $seo_description);
$seo_description    = str_replace("{PAGE}",$page, $seo_description);

if($model_id == 'ershoufang'){
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_fcpc:list/ershoufanglist");
}else if($model_id == 'chuzu'){
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_fcpc:list/chuzulist");
}else if($model_id == 'shangpu'){
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_fcpc:list/shangpulist");
}else if($model_id == 'xiezilou'){
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_fcpc:list/xieziloulist");
}else if($model_id == 'changfang'){
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_fcpc:list/changfanglist");
}else if($model_id == 'cangku'){
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_fcpc:list/cangkulist");
}else if($model_id == 'tudi'){
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_fcpc:list/tudilist");
}