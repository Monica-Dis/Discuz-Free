<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function list_fangchan($tcfangchanListTmp,$simple){
    global $_G,$tcfangchanConfig,$site_id,$tomSysOffset;
    
    $tcfangchanList = array();
    if(is_array($tcfangchanListTmp) && !empty($tcfangchanListTmp)){

        $fangchanIdsArrTmp = $housesIdsArrTmp = array();
        foreach ($tcfangchanListTmp as $key => $value) {
            $fangchanIdsArrTmp[] = $value['id'];
            if($value['houses_id'] > 0){
                $housesIdsArrTmp[]   = $value['houses_id'];
            }
        }
        
        $attrListTmp = array();
        if(is_array($fangchanIdsArrTmp) && !empty($fangchanIdsArrTmp)){
            $fangchanIdsStrTmp = implode(',', $fangchanIdsArrTmp);
            $attrArrTmp = C::t('#tom_tcfangchan#tom_tcfangchan_attr')->fetch_all_list(" AND tcfangchan_id IN({$fangchanIdsStrTmp}) "," ORDER BY attr_id DESC ",0,1000);
            if(is_array($attrArrTmp) && !empty($attrArrTmp)){
                foreach($attrArrTmp as $key => $value){
                    $attrListTmp[$value['tcfangchan_id']] = $value;
                }
            }
        }
        if($simple == 0){
            $housesIdsArrTmp = array_unique($housesIdsArrTmp);

            $housesListTmp = array();
            if(is_array($housesIdsArrTmp) && !empty($housesIdsArrTmp)){
                $housesIdsStrTmp = implode(',', $housesIdsArrTmp);
                $housesArrTmp = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_list(" AND id IN({$housesIdsStrTmp}) "," ORDER BY id ASC ",0,200);
                if(is_array($housesArrTmp) && !empty($housesArrTmp)){
                    foreach($housesArrTmp as $key => $value){
                        $housesListTmp[$value['id']] = $value;
                    }
                }
            }
        }
        
        foreach ($tcfangchanListTmp as $key => $value) {
            $tcfangchanList[$key] = $value;
            
            if(!empty($value['vr_link'])){
                $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND tcfangchan_id = {$value['id']} AND type = 2 ", 'ORDER BY id ASC', 0, 1);
            }else if(!empty($value['video_url'])){
                $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND tcfangchan_id = {$value['id']} AND type = 4 ", 'ORDER BY id ASC', 0, 1);
            }else{
                $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND tcfangchan_id = {$value['id']} AND type = 1 ", 'ORDER BY id ASC', 0, 1);
            }
            $picurlTmp = '';
            if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
                $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
            }else{
                $picurlTmp = $tcfangchanConfig['default_fangchan_photo'];
            }
            
            $attrInfoTmp = $housesInfoTmp = array();
           
            if(isset($attrListTmp[$value['id']])){
               $attrInfoTmp             = $attrListTmp[$value['id']];
            }
            if(isset($housesListTmp[$value['houses_id']])){
               $housesInfoTmp           = $housesListTmp[$value['houses_id']];
            }
            $teseTagsArr                = explode('|', trim($attrInfoTmp['attr_tese_tags'], '|'));
            
            $tcfangchanList[$key]['picurl']             = $picurlTmp;
            $tcfangchanList[$key]['attrInfo']           = $attrInfoTmp;
            $tcfangchanList[$key]['housesInfo']         = $housesInfoTmp;
            $tcfangchanList[$key]['teseTagsList']       = $teseTagsArr;
            $tcfangchanList[$key]['average_price']      = intval($value['price']/$value['mianji']*10000);
            $tcfangchanList[$key]['link']               = tom_fcpc_url('info',$site_id,array('tcfangchan_id'=>$value['id']));
        }
    }
    return $tcfangchanList;
}