<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page               = intval($_GET['page'])>0 ? intval($_GET['page']):1;
$keyword            = isset($_GET['keyword'])? daddslashes(urldecode($_GET['keyword'])):'';
$keyword            = dhtmlspecialchars($keyword);
$type               = intval($_GET['type'])>0? intval($_GET['type']):0;
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):0;

if($__Mobile == 1 && $fcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=needslist&area_id={$area_id}&street_id={$street_id}");exit;
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$areaList = array();
if(is_array($areaListTmp) && !empty($areaListTmp)){
    $areaList = $areaListTmp;
}

$streetList = array();
if($area_id > 0){
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $areaUrl    = tom_fcpc_url('needslist',$site_id,array('area_id'=>$area_id));
}

if($street_id > 0){
    $streetInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    $streetUrl    = tom_fcpc_url('needslist',$site_id,array('area_id'=>$area_id,'street_id'=>$street_id));
}

$where = ' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ';
$url = '';
$rewriteStatus = 1;
if(!empty($sql_in_site_ids)){
    $where.= " AND site_id IN({$sql_in_site_ids}) ";
}

if($tcfangchanConfig['open_qiugou'] == 1 && $tcfangchanConfig['open_qiuzu'] == 0){
    $type = 1;
}else if($tcfangchanConfig['open_qiuzu'] == 1 && $tcfangchanConfig['open_qiugou'] == 0){
   $type = 2;
}

if($type > 0){
    $where.= " AND type={$type} ";
    $url .= "&type={$type}";
}

if($area_id > 0){
    $where.= " AND area_id = {$area_id} ";
    $url .= "&area_id={$area_id}";
}

if($street_id > 0){
    $where.= " AND m.street_id = {$street_id} ";
    $url .= "&street_id={$street_id}";
}

if(!empty($keyword)){
    $rewriteStatus = 0;
    $url .= "&keyword={$keyword}";
}

$orderByWhere = " ORDER BY top_status DESC,top_time DESC,refresh_time DESC,id DESC ";
if($paixu_type > 0){
    $rewriteStatus = 0;
    if($paixu_type == 1){
        $orderByWhere = " ORDER BY refresh_time DESC,top_status DESC,top_time DESC,id DESC";
    }else if($paixu_type == 2){
        $orderByWhere = " ORDER BY clicks DESC,top_status DESC,top_time DESC,id DESC";
    }
    $url .= "&paixu_type={$paixu_type}";
}

$pagesize = 10;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_count($where);

$needsListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_list($where, $orderByWhere, $start, $pagesize, $keyword);
$needsList = list_needs($needsListTmp);

if($rewriteStatus == 1){
    $pageArr['link'] = tom_fcpc_url('needslist',$site_id,array('type'=>$type,'area_id'=>$area_id,'street_id'=>$street_id,'page'=>'{page}'));
}else{
    $pageArr['link'] = $_G['siteurl']."plugin.php?id=tom_fcpc&site={$site_id}&mod=needslist&{$url}&page={page}";
}
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 15 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 15 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$type0url = tom_fcpc_url('needslist',$site_id,array('type'=>0));
$type1url = tom_fcpc_url('needslist',$site_id,array('type'=>1));
$type2url = tom_fcpc_url('needslist',$site_id,array('type'=>2));

$seo_title          = $fcpcConfig['seo_needslist_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);
$seo_title          = str_replace("{PAGE}",$page, $seo_title);

$seo_keywords       = $fcpcConfig['seo_needslist_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{PAGE}",$page, $seo_keywords);

$seo_description    = $fcpcConfig['seo_needslist_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);
$seo_description    = str_replace("{PAGE}",$page, $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:needslist");