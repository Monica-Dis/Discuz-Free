<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function list_needs($needsListTmp){
    global $_G,$tongchengConfig,$tcfangchanConfig,$site_id,$tomSysOffset;
    
    $needsList = array();
    if(is_array($needsListTmp) && !empty($needsListTmp)){

        $needsIdsArrTmp = $userIdsArrTmp = $districtIdsArrTmp = array();
        foreach ($needsListTmp as $key => $value) {
            $needsIdsArrTmp[] = $value['id'];
            $userIdsArrTmp[] = $value['user_id'];
            if($value['area_id'] > 0){
                $districtIdsArrTmp[] = $value['area_id'];
            }
            if($value['street_id'] > 0){
                $districtIdsArrTmp[] = $value['street_id'];
            }
        }
        
        $userListTmp = array();
        if(is_array($userIdsArrTmp) && !empty($userIdsArrTmp)){
            $userIdsStrTmp = implode(',', $userIdsArrTmp);
            $userArrTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_list(" AND id IN({$userIdsStrTmp}) "," ORDER BY id DESC ",0,1000);
            if(is_array($userArrTmp) && !empty($userArrTmp)){
                foreach($userArrTmp as $key => $value){
                    $userListTmp[$value['id']] = $value;
                }
            }
        }
        
        $districtIdsArrTmp = array_unique($districtIdsArrTmp);

        $districtListTmp = array();
        if(is_array($districtIdsArrTmp) && !empty($districtIdsArrTmp)){
            $districtIdsStrTmp = implode(',', $districtIdsArrTmp);
            $districtArrTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_list(" AND id IN({$districtIdsStrTmp}) "," ORDER BY id ASC ",0,2000);
            if(is_array($districtArrTmp) && !empty($districtArrTmp)){
                foreach($districtArrTmp as $key => $value){
                    $districtListTmp[$value['id']] = $value;
                }
            }
        }
        
        foreach ($needsListTmp as $key => $value) {
            $needsList[$key] = $value;
            
            $userInfoTmp = $userListTmp[$value['user_id']];
            if(!preg_match('/^http/', $userInfoTmp['picurl']) ){
                $userInfoTmp['picurl'] = $_G['siteurl'].$userInfoTmp['picurl'];
            }
            $needsList[$key]['userInfo']        = $userInfoTmp;

            $needsList[$key]['area_street'] = '';
            $areaNameTmp = '';
            if(!empty($value['area_id'])){
                $areaInfoTmp = $districtListTmp[$value['area_id']];
                $areaNameTmp = $areaInfoTmp['name'];
            }
            $streetNameTmp = '';
            if(!empty($value['street_id'])){
                $streetInfoTmp = $districtListTmp[$value['street_id']];
                $streetNameTmp = $streetInfoTmp['name'];
            }
            if(!empty($areaNameTmp) && !empty($streetNameTmp)){
                $needsList[$key]['area_street'] = $areaNameTmp."-".$streetNameTmp;
            }else{
                $needsList[$key]['area_street'] = $areaNameTmp;
            }
            
            if($tcfangchanConfig['open_contact_needs_price'] == 1){
                $needsList[$key]['content']  =  preg_replace("/\d{7}/", '*****', $value['content']);
            }
            
            $needsList[$key]['refresh_time']        = dgmdate($value['refresh_time'],"Y-m-d",$tomSysOffset);
            $needsList[$key]['link']                = tom_fcpc_url('needsinfo',$site_id,array('needs_id'=>$value['id']));
        }
    }
    return $needsList;
}