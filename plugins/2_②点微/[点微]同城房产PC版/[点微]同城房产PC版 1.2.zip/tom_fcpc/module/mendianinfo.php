<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$mendian_id  = intval($_GET['mendian_id'])>0? intval($_GET['mendian_id']):0;

if($__Mobile == 1 && $fcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mendianinfo&mendian_id={$mendian_id}");exit;
}

$mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($mendian_id);

if($mendianInfo['shenhe_status'] == 1){
}else{
    dheader('location:'."{$mendianlistUrl}");exit;
}

if($mendianInfo['area_id'] > 0){
    $areaUrl    = tom_fcpc_url('mendianlist',$site_id,array('area_id'=>$mendianInfo['area_id']));
}

if($mendianInfo['street_id'] > 0){
    $streetUrl  = tom_fcpc_url('mendianlist',$site_id,array('area_id'=>$mendianInfo['area_id'],'street_id'=>$mendianInfo['street_id']));
}

$model_id        = isset($_GET['model_id'])? addslashes($_GET['model_id']):'ershoufang';
$page            = intval($_GET['page'])>0 ? intval($_GET['page']):1;

$ershoufangCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_agent_houses_count( " AND m.id = {$mendian_id} AND t.model_id = 'ershoufang' AND t.status=1 AND t.shenhe_status=1 AND t.finish = 0");
$chuzuCount      = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_agent_houses_count( " AND m.id = {$mendian_id} AND t.model_id = 'chuzu' AND t.status=1 AND t.shenhe_status=1 AND t.finish = 0 ");
$otherCount      = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_agent_houses_count( " AND m.id = {$mendian_id} AND t.model_id IN('shangpu','xiezilou','changfang','cangku','tudi') AND t.status=1 AND t.shenhe_status=1 AND t.finish = 0 ");
$agentCountTmp   = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_count( " AND mendian_id = {$mendian_id} AND shenhe_status = 1 ");

$add_time = dgmdate($mendianInfo['add_time'],'Y-m-d',$tomSysOffset);

if($mendianInfo['house_num'] != ($ershoufangCount + $chuzuCount + $otherCount) || $mendianInfo['agent_num'] != $agentCountTmp){
    $updateData = array();
    $updateData['house_num']    = $ershoufangCount + $chuzuCount + $otherCount;
    $updateData['agent_num']    = $agentCountTmp;
    C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->update($mendian_id, $updateData);
    $mendianInfo['house_num']   = $ershoufangCount + $chuzuCount + $otherCount;
    $mendianInfo['agent_num']   = $agentCountTmp;
}

$photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND mendian_id={$mendianInfo['id']} AND type IN (5,6) "," ORDER BY type DESC,psort ASC,id ASC ",0,20);
$photoList = array();
$logo_picurl = '';
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        if($value['type'] == 5){
            $logo_picurl = $value['picurlTmp'];
        }else if($value['type'] == 6){
            $photoList[] = $value['picurlTmp'];
        }
    }
}

$content = stripslashes($mendianInfo['content']);

if($mendianInfo['admin_edit'] == 0){
    $content = str_replace("\r\n","<br/>",$content);
    $content = str_replace("\n","<br/>",$content);
    $content = str_replace("\r","<br/>",$content);
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

    
$where = " AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) ";

if($tcfangchanConfig['open_finish_ok_fangchan'] == 1){
}else{
    $where .= ' AND finish = 0 ';
}
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}
$where .= " AND model_id = '{$model_id}' ";

$order = " ORDER BY top_status DESC,id DESC ";

$agentListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_user_id(" AND mendian_id={$mendian_id} ","ORDER BY id DESC");
$agentUserIdArr = array();
if(is_array($agentListTmp) && !empty($agentListTmp)){
    foreach($agentListTmp as $key => $value){
        $agentUserIdArr[] = $value['user_id'];
    }
}
if(is_array($agentUserIdArr) && !empty($agentUserIdArr)){
    $agentUserIdStr = implode(',', $agentUserIdArr);
    $where.= " AND user_id IN ({$agentUserIdStr}) ";
}

$fangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($where,$order,$start,$pagesize);
$fangchanList = list_fangchan($fangchanListTmp,0);
$count = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count($where);

$pageArr['link']  = $_G['siteurl']."plugin.php?id=tom_fcpc&site={$site_id}&mod=mendianinfo&mendian_id={$mendian_id}&model_id={$model_id}&page={page}";
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$agentWhere = " AND t.mendian_id = {$mendianInfo['id']} AND t.shenhe_status = 1 AND t.is_ok = 1  ";
$agentOrder = " ORDER BY t.clicks DESC,t.id DESC ";

$agentListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_list($agentWhere, $agentOrder, 0, 6);
$agentList = list_agent($agentListTmp,1);

$guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 12 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 12 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$mendianInfoUrl = tom_fcpc_url('mendianinfo',$site_id,array('mendian_id'=>$mendianInfo['id']));

$seo_title          = $fcpcConfig['seo_mendianinfo_title'];
$seo_title          = str_replace("{NAME}",$mendianInfo['name'], $seo_title);
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);

$seo_keywords       = $fcpcConfig['seo_mendianinfo_keywords'];
$seo_keywords       = str_replace("{NAME}",$mendianInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);

$seo_description    = $fcpcConfig['seo_mendianinfo_description'];
$seo_description    = str_replace("{NAME}",$mendianInfo['name'], $seo_description);
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:mendianinfo");