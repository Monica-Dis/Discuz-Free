<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function list_newhouses($newhousesListTmp){
    global $_G,$tcfangchanConfig,$site_id,$tomSysOffset,$houseTypeArr;
    
    $newhousesList = array();
    if(is_array($newhousesListTmp) && !empty($newhousesListTmp)){
        
        $newhousesIdsArrTmp = array();
        foreach ($newhousesListTmp as $key => $value) {
            $newhousesIdsArrTmp[] = $value['id'];
        }

        foreach ($newhousesListTmp as $key => $value) {
            $newhousesList[$key] = $value;
            
            $teseTagsArr = explode('|', trim($value['tese_tags'], '|'));
            $typeList = array();
            if(!empty($value['type'])){
                $typeListTmp = explode('|', trim($value['type'], '|'));
                if(is_array($typeListTmp) && !empty($typeListTmp)){
                    foreach ($typeListTmp as $k => $v){
                        if(!empty($v)){
                            $typeList[] = $houseTypeArr[$v];
                        }
                    }
                }
            }
            
            if(!empty($value['vr_link'])){
                $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND newhouses_id = {$value['id']} AND type = 2 ", 'ORDER BY id ASC', 0, 1);
            }else{
                $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND newhouses_id = {$value['id']} AND type = 1 ", 'ORDER BY id ASC', 0, 1);
            }
            $picurlTmp = '';
            if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
                $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
            }
           
            $newhousesList[$key]['typeList']            = $typeList;
            $newhousesList[$key]['teseTagsList']        = $teseTagsArr;
            $newhousesList[$key]['picurl']              = $picurlTmp;
            $newhousesList[$key]['start_time']          = dgmdate($value['start_time'],"Y-m-d",$tomSysOffset);
            $newhousesList[$key]['link']                = tom_fcpc_url('newhousesinfo',$site_id,array('newhouses_id'=>$value['id']));
        }
    }
    
    return $newhousesList;
}