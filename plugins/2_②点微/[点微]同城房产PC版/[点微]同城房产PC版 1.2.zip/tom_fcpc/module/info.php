<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcfangchan_id  = intval($_GET['tcfangchan_id'])>0? intval($_GET['tcfangchan_id']):0;

if($__Mobile == 1 && $fcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=info&tcfangchan_id={$tcfangchan_id}");exit;
}

$tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);

if($tcfangchanInfo['status'] == 1 && $tcfangchanInfo['shenhe_status'] == 1){
}else{
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_fcpc&site={$site_id}&mod=list&model_id={$tcfangchanInfo['model_id']}");exit;
}

$search_type = $model_type = '';
if($tcfangchanInfo['model_id'] == 'ershoufang' ){
    $search_type = 'ershoufang';
    $model_type = lang('plugin/tom_fcpc', 'ershoufang');
}else if($tcfangchanInfo['model_id'] == 'chuzu' ){
    $search_type = 'chuzu';
    $model_type = lang('plugin/tom_fcpc', 'chuzu');
}else if($tcfangchanInfo['model_id'] == 'shangpu' ){
    $search_type = 'shangpu';
    $model_type = lang('plugin/tom_fcpc', 'shangpu');
}else if($tcfangchanInfo['model_id'] == 'xiezilou' ){
    $search_type = 'xiezilou';
    $model_type = lang('plugin/tom_fcpc', 'xiezilou');
}else if($tcfangchanInfo['model_id'] == 'changfang' ){
    $search_type = 'changfang';
    $model_type = lang('plugin/tom_fcpc', 'changfang');
}else if($tcfangchanInfo['model_id'] == 'cangku' ){
    $search_type = 'cangku';
    $model_type = lang('plugin/tom_fcpc', 'cangku');
}else if($tcfangchanInfo['model_id'] == 'tudi' ){
    $search_type = 'tudi';
    $model_type = lang('plugin/tom_fcpc', 'tudi');
}  
$nav_type = $search_type;

$modellistUrl       = tom_fcpc_url('list',$site_id,array('model_id'=>$tcfangchanInfo['model_id']));

if($tcfangchanInfo['area_id'] > 0){
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tcfangchanInfo['area_id']);
    $areaUrl    = tom_fcpc_url('list',$site_id,array('model_id'=>$tcfangchanInfo['model_id'],'area_id'=>$tcfangchanInfo['area_id']));
}

if($tcfangchanInfo['street_id'] > 0){
    $streetInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tcfangchanInfo['street_id']);
    $streetUrl    = tom_fcpc_url('list',$site_id,array('model_id'=>$tcfangchanInfo['model_id'],'area_id'=>$tcfangchanInfo['area_id'],'street_id'=>$tcfangchanInfo['street_id']));
}

$userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanInfo['user_id']);

if(!preg_match('/^http/', $userInfo['picurl']) ){
    $userInfo['picurl'] = $_G['siteurl'].$userInfo['picurl'];
}

$agentStatus = 0;
if($tcfangchanInfo['source_type'] == 1){
    $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
    if($agentInfo['id'] > 0 ){
        $agentStatus = 1;

        $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);

        if(!preg_match('/^http/', $agentInfo['avatar']) ){
            if(strpos($agentInfo['avatar'], 'source/plugin/tom_') === FALSE){
                $avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$agentInfo['avatar'];
            }else{
                $avatar = $_G['siteurl'].$agentInfo['avatar'];
            }
        }else{
            $avatar = $agentInfo['avatar'];
        }

        if(!preg_match('/^http/', $agentInfo['wx_qrcode']) ){
            if(strpos($agentInfo['wx_qrcode'], 'source/plugin/tom_') === FALSE){
                $wxQrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$agentInfo['wx_qrcode'];
            }else{
                $wxQrcode = $_G['siteurl'].$agentInfo['wx_qrcode'];
            }
        }else{
            $wxQrcode = $agentInfo['wx_qrcode'];
        }
    }
}

if($tcfangchanInfo['houses_id'] > 0){
    $housesInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_houses")->fetch_by_id($tcfangchanInfo['houses_id']);
    $housesInfo = array();
    if($housesInfoTmp['status'] == 1 && $housesInfoTmp['shenhe_status'] == 1){
        $housesInfo = $housesInfoTmp;
    }
}

$attrInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_attr")->fetch_all_list(" AND tcfangchan_id = {$tcfangchan_id} ", 'ORDER BY attr_id DESC', 0, 1);
$attrInfo = array();
if(is_array($attrInfoTmp) && !empty($attrInfoTmp[0])){
    $attrInfo = $attrInfoTmp[0];
}

$chuzuPeitaoList = array();
if(!empty($attrInfo['attr_peitao_tags'])){
    $attrPeitaoTagsList = explode('|', trim($attrInfo['attr_peitao_tags'], '|'));

    if(is_array($chuzuPeitaoArr) && !empty($chuzuPeitaoArr)){
        foreach($chuzuPeitaoArr as $key => $value){
            $chuzuPeitaoList[$key] = $value;
            $chuzuPeitaoList[$key]['status'] = 0;

            if(in_array($value['name'], $attrPeitaoTagsList)){
                $chuzuPeitaoList[$key]['status'] = 1;
            }
        }
    }
}

$attrTeseTagsList = array();
if(!empty($attrInfo['attr_tese_tags'])){
    $attrTeseTagsList = explode('|', trim($attrInfo['attr_tese_tags'], '|'));
}

$tcfangchanInfo['content'] = stripslashes($tcfangchanInfo['content']);

$guanzuStatus = 0;
if($__UserInfo['id'] > 0){
    $guanzuInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_guanzu")->fetch_all_list(" AND tcfangchan_id = {$tcfangchan_id} AND user_id = {$__UserInfo['id']} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])){
        $guanzuStatus = 1;
    }
}

$average_price = intval($tcfangchanInfo['price']/$tcfangchanInfo['mianji']*10000);

$photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id={$tcfangchan_id} AND type IN(1,2,4) "," ORDER BY type DESC,psort ASC,id ASC ",0,20);
$photoList = array();
$vrPicurl = $videoPicurl = '';
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];

        if($value['type'] == 1){
            $photoList[] = $picurlTmp;
        }
        if($value['type'] == 2){
            $vrPicurl = $picurlTmp;
        }
        if($value['type'] == 4){
            $videoPicurl = $picurlTmp;
        }
    }
}

$where  = " AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) AND id != {$tcfangchanInfo['id']} AND model_id = '{$tcfangchanInfo['model_id']}' ";
if($tcfangchanConfig['open_finish_ok_fangchan'] == 1){
}else{
    $where .= ' AND finish = 0 ';
}
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}
$count           = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count($where);
$fangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($where," ORDER BY top_status DESC,id DESC ",0,4);
$fangchanList    = list_fangchan($fangchanListTmp,1);

DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET clicks=clicks+1 WHERE id='{$tcfangchan_id}'", 'UNBUFFERED');

$agentUrl        = tom_fcpc_url('agentinfo',$site_id,array('agent_id'=>$agentInfo['id']));
$fcinfoUrl       = tom_fcpc_url('info',$site_id,array('tcfangchan_id'=>$tcfangchanInfo['id']));
$housesinfoUrl   = tom_fcpc_url('housesinfo',$site_id,array('houses_id'=>$tcfangchanInfo['houses_id']));
$fangchanInfoUrl = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=info&tcfangchan_id={$tcfangchanInfo['id']}";

$ajaxUpdateGuanzuUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=update_fangchan_guanzu&user_id={$__UserInfo['id']}&tcfangchan_id={$tcfangchan_id}&formhash={$formhash}";

$guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 9 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 9 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$seo_title          = $fcpcConfig['seo_info_title'];
$seo_title          = str_replace("{TITLE}",$tcfangchanInfo['title'], $seo_title);
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);

$seo_keywords       = $fcpcConfig['seo_info_keywords'];
$seo_keywords       = str_replace("{TITLE}",$tcfangchanInfo['title'], $seo_keywords);
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);

$seo_description    = $fcpcConfig['seo_info_description'];
$seo_description    = str_replace("{TITLE}",$tcfangchanInfo['title'], $seo_description);
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:info");