<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($__Mobile == 1 && $fcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
}

$focuspicListTmp = C::t('#tom_fcpc#tom_fcpc_focuspic')->fetch_all_list(" AND site_id={$site_id} AND type=1 "," ORDER BY fsort ASC,id DESC ", 0, 10);
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
}else if($site_id > 1){
    $focuspicListTmp = C::t('#tom_fcpc#tom_fcpc_focuspic')->fetch_all_list(" AND site_id=1 AND type=1 "," ORDER BY fsort ASC,id DESC ", 0, 10);
}
$focuspicList = array();
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
    foreach($focuspicListTmp as $key => $value){
        $focuspicList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $focuspicList[$key]['picurl'] = $picurl;
        $focuspicList[$key]['link'] = str_replace("{site}",$site_id, $value['link']);
    }
}
$focuspicCount = count($focuspicList);

$newhousesWhere = ' AND status = 1 ';
if(!empty($sql_in_site_ids)){
    $newhousesWhere .= " AND site_id IN({$sql_in_site_ids}) ";
}

$newhousesCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_count($newhousesWhere);
$newhousesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_list($newhousesWhere," ORDER BY top_status DESC,id DESC ",0,$fcpcConfig['index_newhouseslist_num']);
$newhousesList = list_newhouses($newhousesListTmp);

$ershoufangWhere = " AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) AND model_id = 'ershoufang' ";
if(!empty($sql_in_site_ids)){
    $ershoufangWhere .= " AND site_id IN({$sql_in_site_ids}) ";
}
if($tcfangchanConfig['open_finish_ok_fangchan'] == 1){
}else{
    $ershoufangWhere .= ' AND finish = 0 ';
}
$ershoufangCount   = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count($ershoufangWhere);
$ershoufangListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($ershoufangWhere," ORDER BY top_status DESC,id DESC ",0,$fcpcConfig['index_ershoufanglist_num']);
$ershoufangList    = list_fangchan($ershoufangListTmp,1);

$chuzuWhere = " AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) AND model_id = 'chuzu' ";
if(!empty($sql_in_site_ids)){
    $chuzuWhere .= " AND site_id IN({$sql_in_site_ids}) ";
}
if($tcfangchanConfig['open_finish_ok_fangchan'] == 1){
}else{
    $chuzuWhere .= ' AND finish = 0 ';
}
$chuzuCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count($chuzuWhere);
$chuzuListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($chuzuWhere," ORDER BY top_status DESC,id DESC ",0,$fcpcConfig['index_chuzulist_num']);
$chuzuList = list_fangchan($chuzuListTmp,1);

$shangpuWhere = " AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) AND model_id = 'shangpu' ";
if(!empty($sql_in_site_ids)){
    $shangpuWhere .= " AND site_id IN({$sql_in_site_ids}) ";
}
if($tcfangchanConfig['open_finish_ok_fangchan'] == 1){
}else{
    $shangpuWhere .= ' AND finish = 0 ';
}
$shangpuCount   = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count($shangpuWhere);
$shangpuListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($shangpuWhere," ORDER BY top_status DESC,id DESC ",0,$fcpcConfig['index_shangpulist_num']);
$shangpuList    = list_fangchan($shangpuListTmp,1);

if($fcpcConfig['open_index_agent'] == 1){
    $agentWhere = " AND t.shenhe_status=1 AND t.is_ok=1 ";
    if(!empty($sql_in_site_ids)){
        $agentWhere.= " AND t.site_id IN({$sql_in_site_ids}) ";
    }
    $agentListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_list($agentWhere," ORDER BY t.top_status DESC,t.clicks DESC,t.id DESC ",0,$fcpcConfig['index_agentlist_num']);
    $agentList    = list_agent($agentListTmp,1);
    $agentCount   = count($agentList);
}

if($fcpcConfig['open_index_mendian'] == 1){
    $mendianWhere = " AND shenhe_status = 1 ";
    if(!empty($sql_in_site_ids)){
        $mendianWhere.= " AND site_id IN({$sql_in_site_ids}) ";
    }
    $mendianListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_list($mendianWhere, 'ORDER BY top_status DESC,house_num DESC,id DESC', 0, $fcpcConfig['index_mendianlist_num']);
    $mendianList    = list_mendian($mendianListTmp);
    $mendianCount   = count($mendianList);
}

$guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi IN(2,3,4,5) AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi IN(2,3,4,5) AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoTonglan1List = $guanggaoTonglan2List = $guanggaoTonglan3List  = $guanggaoTonglan4List = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        if($value['weizhi'] == 2){
            $guanggaoTonglan1List[] = $guanggaoItemTmp;
        }
        if($value['weizhi'] == 3){
            $guanggaoTonglan2List[] = $guanggaoItemTmp;
        }
        if($value['weizhi'] == 4){
            $guanggaoTonglan3List[] = $guanggaoItemTmp;
        }
        if($value['weizhi'] == 5){
            $guanggaoTonglan4List[] = $guanggaoItemTmp;
        }
    }
}

$linksListTmp = C::t('#tom_fcpc#tom_fcpc_links')->fetch_all_list(" AND site_id={$site_id} "," ORDER BY lsort ASC,id DESC ");
if(is_array($linksListTmp) && !empty($linksListTmp)){
}else{
    $linksListTmp = C::t('#tom_fcpc#tom_fcpc_links')->fetch_all_list(" AND site_id=1 "," ORDER BY lsort ASC,id DESC ");
}
$linksList = array();
if(is_array($linksListTmp) && !empty($linksListTmp)){
    foreach($linksListTmp as $key => $value){
        $linksList[$key] = $value;
        $linksList[$key]['link'] = str_replace("{site}",$site_id, $value['link']);
    }
}
$linksCount = count($linksList);

$seo_title          = $fcpcConfig['seo_index_title'];
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);

$seo_keywords       = $fcpcConfig['seo_index_keywords'];
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);

$seo_description    = $fcpcConfig['seo_index_description'];
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:index");