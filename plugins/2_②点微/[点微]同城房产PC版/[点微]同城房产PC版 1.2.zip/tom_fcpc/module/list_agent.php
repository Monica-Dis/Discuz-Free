<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function list_agent($agentListTmp,$simple){
    global $_G,$tcfangchanConfig,$site_id,$tomSysOffset;
    
    $agentList = array();
    if(is_array($agentListTmp) && !empty($agentListTmp)){

        $agentIdsArrTmp = array();
        foreach ($agentListTmp as $key => $value) {
            $agentIdsArrTmp[] = $value['id'];
        }
        
        foreach ($agentListTmp as $key => $value) {
            $agentList[$key] = $value;
            
            $avatarTmp = $wx_qrcodeTmp = '';
            if(!empty($value['avatar'])){
                if(!preg_match('/^http/', $value['avatar']) ){
                    if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                        $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
                    }else{
                        $avatarTmp = $_G['siteurl'].$value['avatar'];
                    }
                }else{
                    $avatarTmp = $value['avatar'];
                }
            }
            
            if($simple == 0){
                $tcfangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$value['user_id']} AND status=1 AND shenhe_status=1 AND model_id= 'ershoufang' AND ((pay_status = 0) OR (pay_status = 2)) ");
                $tcfangchanChuzuCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$value['user_id']} AND status=1 AND shenhe_status=1 AND model_id= 'chuzu' AND ((pay_status = 0) OR (pay_status = 2)) ");
                $agentList[$key]['tcfangchanCount']        = $tcfangchanCount;
                $agentList[$key]['tcfangchanChuzuCount']   = $tcfangchanChuzuCount;
            }
            
            if(!empty($value['m_name'])){
                $agentList[$key]['mendian_name']                 = $value['m_name'];
            }
            
            $agentList[$key]['avatar']                 = $avatarTmp;
            $agentList[$key]['link']                   = tom_fcpc_url('agentinfo',$site_id,array('agent_id'=>$value['id']));
        }
    }
    return $agentList;
}