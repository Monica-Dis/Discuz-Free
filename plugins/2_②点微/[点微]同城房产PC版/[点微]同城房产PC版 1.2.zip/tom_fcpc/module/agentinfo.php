<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$agent_id  = intval($_GET['agent_id'])>0? intval($_GET['agent_id']):0;

if($__Mobile == 1 && $fcpcConfig['open_mobile'] == 1){
    dheader('location:'.$_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=agentinfo&agent_id={$agent_id}");exit;
}

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_id($agent_id);

if($agentInfo['shenhe_status'] == 1 && $agentInfo['is_ok'] == 1){
}else{
    dheader('location:'."{$agentlistUrl}");exit;
}

$model_id   = isset($_GET['model_id'])? addslashes($_GET['model_id']):'ershoufang';
$page       = intval($_GET['page'])>0 ? intval($_GET['page']):1;

$mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);

if($mendianInfo['area_id'] > 0){
    $areaUrl    = tom_fcpc_url('agentlist',$site_id,array('area_id'=>$mendianInfo['area_id']));
}

if($mendianInfo['street_id'] > 0){
    $streetUrl  = tom_fcpc_url('agentlist',$site_id,array('area_id'=>$mendianInfo['area_id'],'street_id'=>$mendianInfo['street_id']));
}

$housesCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$agentInfo['user_id']} AND status=1 AND shenhe_status=1 AND finish = 0 ");

if(!preg_match('/^http/', $agentInfo['avatar']) ){
    if(strpos($agentInfo['avatar'], 'source/plugin/tom_') === FALSE){
        $avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$agentInfo['avatar'];
    }else{
        $avatar = $_G['siteurl'].$agentInfo['avatar'];
    }
}else{
    $avatar = $agentInfo['avatar'];
}

if(!preg_match('/^http/', $agentInfo['wx_qrcode']) ){
    if(strpos($agentInfo['wx_qrcode'], 'source/plugin/tom_') === FALSE){
        $wxQrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$agentInfo['wx_qrcode'];
    }else{
        $wxQrcode = $_G['siteurl'].$agentInfo['wx_qrcode'];
    }
}else{
    $wxQrcode = $agentInfo['wx_qrcode'];
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) AND user_id = {$agentInfo['user_id']}";

if($tcfangchanConfig['open_finish_ok_fangchan'] == 1){
}else{
    $where .= ' AND finish = 0 ';
}

if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}

$where .= " AND model_id = '{$model_id}' ";

$order = "  ORDER BY top_status DESC,id DESC ";

$count = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count($where);
$fangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($where,$order,$start,$pagesize);
$fangchanList    = list_fangchan($fangchanListTmp,0);

$pageArr['link']  = $_G['siteurl']."plugin.php?id=tom_fcpc&site={$site_id}&mod=agentinfo&agent_id={$agent_id}&model_id={$model_id}&page={page}";
$pageArr['count'] = $count;
$pageArr['pagesize'] = $pagesize;
$pageArr['page'] = $page;
$pageArr = tom_page($pageArr, 7);

$guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 14 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 14 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoYouList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoYouList[] = $guanggaoItemTmp;
    }
}
$guanggaoYouCount = count($guanggaoYouList);

$agentInfoUrl       = tom_fcpc_url('agentinfo',$site_id,array('agent_id'=>$agentInfo['id']));
$mendianInfoUrl     = tom_fcpc_url('mendianinfo',$site_id,array('mendian_id'=>$mendianInfo['id']));

$seo_title          = $fcpcConfig['seo_agentinfo_title'];
$seo_title          = str_replace("{NAME}",$agentInfo['name'], $seo_title);
$seo_title          = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_title);
$seo_title          = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_title);

$seo_keywords       = $fcpcConfig['seo_agentinfo_keywords'];
$seo_keywords       = str_replace("{NAME}",$agentInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_keywords);
$seo_keywords       = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_keywords);

$seo_description    = $fcpcConfig['seo_agentinfo_description'];
$seo_description    = str_replace("{NAME}",$agentInfo['name'], $seo_description);
$seo_description    = str_replace("{SITENAME}",$__SitesInfo['name'], $seo_description);
$seo_description    = str_replace("{CITYNAME}",$__CityInfo['name'], $seo_description);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:agentinfo");