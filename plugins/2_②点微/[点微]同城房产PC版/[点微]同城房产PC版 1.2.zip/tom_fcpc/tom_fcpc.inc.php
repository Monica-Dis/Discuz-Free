<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$timestamp = TIMESTAMP;
$fcpcConfig = $_G['cache']['plugin']['tom_fcpc'];
$tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = "20210825";

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/tom_tcfangchan.inc.php')){}else{
    echo " no install https://dism.taobao.com/?@tom_tcfangchan.plugin";exit;
}

$fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
if($fangchanSetting && $fangchanSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_setting')->insert($insertData);
    $fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/qqface.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/sitesinfo.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcpc/class/function.page.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/class/function.url.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/list_newhouses.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/list_fangchan.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/list_agent.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/list_houses.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/list_mendian.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/list_needs.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/config/config.data.php';

$__IsWeixin = $__Ios = $__Android = $__Mobile = 0;
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){ $__IsWeixin = 1;$__Mobile = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') !== false){$__Ios = 1;$__Mobile = 1;}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false){$__Android = 1;$__Mobile = 1;}

## tcadmin start
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
## tcadmin end
## video start
$__ShowVideo = 0;
if($fangchanSetting['open_video'] == 1){
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/video.inc.php')){
        $__ShowVideo = 1;
    }
}
## video end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/site_lbs.php';
include DISCUZ_ROOT.'./source/plugin/tom_fcpc/userinfo.php';

$__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
if(!$__CommonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tongcheng#tom_tongcheng_common')->insert($insertData);
}
if($site_id > 1){
    $__siteCommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id($site_id);
    if(!$__siteCommonInfo){
        $insertData = array();
        $insertData['id']      = $site_id;
        C::t('#tom_tongcheng#tom_tongcheng_common')->insert($insertData);
    }
}

$aboutListTmp = C::t('#tom_fcpc#tom_fcpc_about')->fetch_all_list(""," ORDER BY asort ASC,id DESC ",0,50);
$aboutList = array();
$about_i = 1;
if(is_array($aboutListTmp) && !empty($aboutListTmp)){
    foreach ($aboutListTmp as $key => $value){
        $aboutList[$key] = $value;
        $aboutList[$key]['i'] = $about_i;
        $aboutList[$key]['link'] = tom_fcpc_url('about',$site_id,array('about_id'=>$value['id']));
        $about_i++;
    }
}
$aboutCount = count($aboutList);

$guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id={$site_id} AND weizhi = 1 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
}else if($site_id > 1){
    $guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list(" AND site_id=1 AND weizhi = 1 AND over_time > {$timestamp} "," ORDER BY gsort ASC,id DESC ");
}
$guanggaoTonglanTopList = array();
if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
    foreach($guanggaoListTmp as $key => $value){
        $guanggaoItemTmp = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $guanggaoItemTmp['picurl'] = $picurl;
        $guanggaoItemTmp['code'] = stripslashes($value['code']);
        $guanggaoItemTmp['link'] = str_replace("{site}",$site_id, $value['link']);
        $guanggaoTonglanTopList[] = $guanggaoItemTmp;
    }
}

$footer_qrcode_List = array();
if(!empty($fcpcConfig['footer_qrcode_list'])){
    $footer_qrcode_str = str_replace("\r\n","{n}",trim($fcpcConfig['footer_qrcode_list'])); 
    $footer_qrcode_str = str_replace("\n","{n}",$footer_qrcode_str);
    $footer_qrcode_str = str_replace("{site}",$site_id,$footer_qrcode_str);
    $footer_qrcode_arr = explode("{n}", $footer_qrcode_str);
    if(is_array($footer_qrcode_arr) && !empty($footer_qrcode_arr)){
        foreach ($footer_qrcode_arr as $key => $value){
            $footer_qrcode_List[] = explode("|", $value);
        }
    }
}
$footerQrcodeCount = count($footer_qrcode_List);
if($footerQrcodeCount > 3){
    $footer_qrcode_List = array_slice($footer_qrcode_List,0,3);
}
$footer_qrcode_List = array_reverse($footer_qrcode_List); 

$fcpcConfig['pc_logo'] = trim($fcpcConfig['pc_logo']);
if(!empty($fcpcConfig['pc_logo']) && !preg_match('/^http/', $fcpcConfig['pc_logo']) ){
    $fcpcConfig['pc_logo'] = $_G['siteurl'].$fcpcConfig['pc_logo'];
}

$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
if($__SitesInfo['id'] > 1 && !empty($__SitesInfo['kefu_qrcode'])){
    if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])){
        if(strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_') === FALSE){
            $kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
        }else{
            $kefuQrcodeSrc = $_G['siteurl'].$__SitesInfo['kefu_qrcode'];
        }
    }else{
        $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
    }
}

$tcfangchanConfig['kefu_qrcode'] = trim($tcfangchanConfig['kefu_qrcode']);
if(!empty($tcfangchanConfig['kefu_qrcode'])){
    $kefuQrcodeSrc = $tcfangchanConfig['kefu_qrcode'];
}

$_G['m_siteurl'] = $_G['siteurl'];

$fcpcConfig['fangchan_hosts']   = trim($fcpcConfig['fangchan_hosts']);
$fcpcConfig['tongcheng_hosts']  = trim($fcpcConfig['tongcheng_hosts']);

if($fcpcConfig['open_fangchan_hosts'] == 1 && !empty($fcpcConfig['fangchan_hosts']) && !empty($fcpcConfig['tongcheng_hosts'])){
    
    $fcpcConfig['tongcheng_hosts']  = rtrim($fcpcConfig['tongcheng_hosts'], '/');
    $fcpcConfig['tongcheng_hosts']  = $fcpcConfig['tongcheng_hosts'].'/';
    
    $_G['m_siteurl'] = $fcpcConfig['tongcheng_hosts'];
    
}

$fabuUrl  = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index";

$index1Url          = tom_fcpc_url('index',1);
$indexUrl           = tom_fcpc_url('index',$site_id);
$newhouseslistUrl   = tom_fcpc_url('newhouseslist',$site_id);
$ershoufanglistUrl  = tom_fcpc_url('list',$site_id,array('model_id'=>'ershoufang'));
$chuzulistUrl       = tom_fcpc_url('list',$site_id,array('model_id'=>'chuzu'));
$shangpulistUrl     = tom_fcpc_url('list',$site_id,array('model_id'=>'shangpu'));
$xieziloulistUrl    = tom_fcpc_url('list',$site_id,array('model_id'=>'xiezilou'));
$changfanglistUrl   = tom_fcpc_url('list',$site_id,array('model_id'=>'changfang'));
$cangkulistUrl      = tom_fcpc_url('list',$site_id,array('model_id'=>'cangku'));
$tudilistUrl        = tom_fcpc_url('list',$site_id,array('model_id'=>'tudi'));
$houseslistUrl      = tom_fcpc_url('houseslist',$site_id);
$mendianlistUrl     = tom_fcpc_url('mendianlist',$site_id);
$agentlistUrl       = tom_fcpc_url('agentlist',$site_id);
$needslistUrl       = tom_fcpc_url('needslist',$site_id);
$mUrl               = $_G['m_siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index";

$template_color_rgb = '';
if(!empty($fcpcConfig['template_color'])){
    $template_color_rgb = fcpc_hex2rgbstr($fcpcConfig['template_color']);
}

if(!preg_match('/^http/', $tcfangchanConfig['default_fangchan_photo']) ){
    $tcfangchanConfig['default_fangchan_photo'] = $_G['siteurl'].$tcfangchanConfig['default_fangchan_photo'];
}

if(!preg_match('/^http/', $tcfangchanConfig['default_houses_photo']) ){
    $tcfangchanConfig['default_houses_photo'] = $_G['siteurl'].$tcfangchanConfig['default_houses_photo'];
}

if($_GET['mod'] == 'index'){
    
    $search_type = 'ershoufang';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/index.php';
    
}else if($_GET['mod'] == 'newhouseslist'){
    
    $search_type = 'newhouses';
    $nav_type = 'newhouses';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/newhouseslist.php';
    
}else if($_GET['mod'] == 'list'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/list.php';
    
}else if($_GET['mod'] == 'houseslist'){
    
    $search_type = 'houses';
    $nav_type = 'houses';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/houseslist.php';
    
}else if($_GET['mod'] == 'agentlist'){
    
    $search_type = 'agent';
    $nav_type = 'agent';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/agentlist.php';
    
}else if($_GET['mod'] == 'mendianlist'){
    
    $search_type = 'mendian';
    $nav_type = 'mendian';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/mendianlist.php';
    
}else if($_GET['mod'] == 'needslist'){
    
    $search_type = 'needs';
    $nav_type = 'needs';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/needslist.php';
    
}else if($_GET['mod'] == 'newhousesinfo'){
    
    $search_type = 'newhouses';
    $nav_type = 'newhouses';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/newhousesinfo.php';
    
}else if($_GET['mod'] == 'info'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/info.php';
    
}else if($_GET['mod'] == 'housesinfo'){
    
    $search_type = 'houses';
    $nav_type = 'houses';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/housesinfo.php';
    
}else if($_GET['mod'] == 'mendianinfo'){
    
    $search_type = 'mendian';
    $nav_type = 'mendian';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/mendianinfo.php';
    
}else if($_GET['mod'] == 'agentinfo'){
    
    $search_type = 'agent';
    $nav_type = 'agent';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/agentinfo.php';
    
}else if($_GET['mod'] == 'needsinfo'){
    
    $search_type = 'needs';
    $nav_type = 'needs';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/needsinfo.php';
    
}else if($_GET['mod'] == 'about'){
    
    $search_type = 'ershoufang';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/about.php';
    
}else{
    
    $search_type = 'ershoufang';
    
    include DISCUZ_ROOT.'./source/plugin/tom_fcpc/module/index.php';
}