<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$rewritedata = array(
	'rulesearch' => array(
        'fangchan_site'             => $fcpcConfig['rewrite_fangchan_name'].'/index-{site}.html',
        'fangchan_newhouseslist'    => $fcpcConfig['rewrite_fangchan_name'].'/newhouseslist-{site}-{area_id}-{street_id}-{page}.html',
        'fangchan_newhousesinfo'    => $fcpcConfig['rewrite_fangchan_name'].'/newhousesinfo-{site}-{newhouses_id}.html',
		'fangchan_list'             => $fcpcConfig['rewrite_fangchan_name'].'/list-{model_id}-{site}-{area_id}-{street_id}-{page}.html',
        'fangchan_info'             => $fcpcConfig['rewrite_fangchan_name'].'/info-{site}-{tcfangchan_id}.html',
        'fangchan_houseslist'       => $fcpcConfig['rewrite_fangchan_name'].'/houseslist-{site}-{area_id}-{street_id}-{page}.html',
        'fangchan_housesinfo'       => $fcpcConfig['rewrite_fangchan_name'].'/housesinfo-{site}-{houses_id}.html',
        'fangchan_mendianlist'      => $fcpcConfig['rewrite_fangchan_name'].'/mendianlist-{site}-{area_id}-{street_id}-{page}.html',
        'fangchan_mendianinfo'      => $fcpcConfig['rewrite_fangchan_name'].'/mendianinfo-{site}-{mendian_id}.html',
        'fangchan_agentlist'        => $fcpcConfig['rewrite_fangchan_name'].'/agentlist-{site}-{area_id}-{street_id}-{page}.html',
        'fangchan_agentinfo'        => $fcpcConfig['rewrite_fangchan_name'].'/agentinfo-{site}-{agent_id}.html',
        'fangchan_needslist'        => $fcpcConfig['rewrite_fangchan_name'].'/needslist-{site}-{type}-{area_id}-{street_id}-{page}.html',
        'fangchan_needsinfo'        => $fcpcConfig['rewrite_fangchan_name'].'/needsinfo-{site}-{needs_id}.html',
        'fangchan_about'            => $fcpcConfig['rewrite_fangchan_name'].'/about-{site}-{about_id}.html',
        'fangchan_index'            => $fcpcConfig['rewrite_fangchan_name'].'/',
	),
	'rulereplace' => array(
        'fangchan_site'             => 'plugin.php?id=tom_fcpc&site={site}&mod=index',
        'fangchan_newhouseslist'    => 'plugin.php?id=tom_fcpc&site={site}&mod=newhouseslist&area_id={area_id}&street_id={street_id}&page={page}',
        'fangchan_newhousesinfo'    => 'plugin.php?id=tom_fcpc&site={site}&mod=newhousesinfo&newhouses_id={newhouses_id}',
		'fangchan_list'             => 'plugin.php?id=tom_fcpc&model_id={model_id}&site={site}&mod=list&area_id={area_id}&street_id={street_id}&page={page}',
        'fangchan_info'             => 'plugin.php?id=tom_fcpc&site={site}&mod=info&tcfangchan_id={tcfangchan_id}',
        'fangchan_houseslist'       => 'plugin.php?id=tom_fcpc&site={site}&mod=houseslist&area_id={area_id}&street_id={street_id}&page={page}',
        'fangchan_housesinfo'       => 'plugin.php?id=tom_fcpc&site={site}&mod=housesinfo&houses_id={houses_id}',
        'fangchan_mendianlist'      => 'plugin.php?id=tom_fcpc&site={site}&mod=mendianlist&area_id={area_id}&street_id={street_id}&page={page}',
        'fangchan_mendianinfo'      => 'plugin.php?id=tom_fcpc&site={site}&mod=mendianinfo&mendian_id={mendian_id}',
        'fangchan_agentlist'        => 'plugin.php?id=tom_fcpc&site={site}&mod=agentlist&area_id={area_id}&street_id={street_id}&page={page}',
        'fangchan_agentinfo'        => 'plugin.php?id=tom_fcpc&site={site}&mod=agentinfo&agent_id={agent_id}',
        'fangchan_needslist'        => 'plugin.php?id=tom_fcpc&site={site}&mod=needslist&type={type}&area_id={area_id}&street_id={street_id}&page={page}',
        'fangchan_needsinfo'        => 'plugin.php?id=tom_fcpc&site={site}&mod=needsinfo&needs_id={needs_id}',
        'fangchan_about'            => 'plugin.php?id=tom_fcpc&site={site}&mod=about&about_id={about_id}',
        'fangchan_index'            => 'plugin.php?id=tom_fcpc&site=1&mod=index',
	),
	'rulevars' => array(
        'fangchan_site'            => array('{site}' => '([0-9]+)'),
        'fangchan_newhouseslist'   => array('{site}' => '([0-9]+)', '{area_id}' => '([0-9]+)', '{street_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'fangchan_newhousesinfo'   => array('{site}' => '([0-9]+)', '{newhouses_id}' => '([0-9]+)'),
		'fangchan_list'            => array('{model_id}' => '([a-z]+)','{site}' => '([0-9]+)', '{area_id}' => '([0-9]+)', '{street_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'fangchan_info'            => array('{site}' => '([0-9]+)', '{tcfangchan_id}' => '([0-9]+)'),
        'fangchan_houseslist'      => array('{site}' => '([0-9]+)', '{area_id}' => '([0-9]+)', '{street_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'fangchan_housesinfo'      => array('{site}' => '([0-9]+)', '{houses_id}' => '([0-9]+)'),
        'fangchan_mendianlist'     => array('{site}' => '([0-9]+)', '{area_id}' => '([0-9]+)', '{street_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'fangchan_mendianinfo'     => array('{site}' => '([0-9]+)', '{mendian_id}' => '([0-9]+)'),
        'fangchan_agentlist'       => array('{site}' => '([0-9]+)', '{area_id}' => '([0-9]+)', '{street_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'fangchan_agentinfo'       => array('{site}' => '([0-9]+)', '{agent_id}' => '([0-9]+)'),
        'fangchan_needslist'       => array('{site}' => '([0-9]+)', '{type}' => '([0-9]+)','{area_id}' => '([0-9]+)', '{street_id}' => '([0-9]+)', '{page}' => '([0-9]+)'),
        'fangchan_needsinfo'       => array('{site}' => '([0-9]+)', '{needs_id}' => '([0-9]+)'),
        'fangchan_about'           => array('{site}' => '([0-9]+)', '{about_id}' => '([0-9]+)'),
        'fangchan_index'           => array(),
	)
);

if($fcpcConfig['open_fangchan_hosts'] == 1 && $fcpcConfig['closed_rewrite_name'] == 1){
    foreach($rewritedata['rulesearch'] as $key => $value) {
        $rewritedata['rulesearch'][$key] = str_replace($fcpcConfig['rewrite_fangchan_name'].'/', '', $value);
    }
}

$rule['{apache1}'] = $rule['{apache2}'] = $rule['{iis}'] = $rule['{iis7}'] = $rule['{zeus}'] = $rule['{nginx}'] = '';
foreach($rewritedata['rulesearch'] as $k => $v) {
    $pvmaxv = count($rewritedata['rulevars'][$k]) + 2;
    $vkeys = array_keys($rewritedata['rulevars'][$k]);
    $rewritedata['rulereplace'][$k] = pvsort($vkeys, $v, $rewritedata['rulereplace'][$k]);
    $v = str_replace($vkeys, $rewritedata['rulevars'][$k], addcslashes($v, '?*+^$.[]()|'));
    $rule['{apache1}'] .= "\t".'RewriteCond %{QUERY_STRING} ^(.*)$'."\n\t".'RewriteRule ^(.*)/'.$v.'$ $1/'.pvadd($rewritedata['rulereplace'][$k])."&%1\n";
    if($k != 'forum_archiver') {
        $rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^'.$v.'$ '.$rewritedata['rulereplace'][$k]."&%1\n";
    } else {
        $rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^archiver/'.$v.'$ archiver/'.$rewritedata['rulereplace'][$k]."&%1\n";
    }
    $rule['{iis}'] .= 'RewriteRule ^(.*)/'.$v.'(\?(.*))*$ $1/'.addcslashes(pvadd($rewritedata['rulereplace'][$k]).'&$'.($pvmaxv + 1), '.?')."\n";
    $rule['{iis7}'] .= "\t\t".'&lt;rule name="'.$k.'"&gt;'."\n\t\t\t".'&lt;match url="^(.*/)*'.str_replace('\.', '.', $v).'\?*(.*)$" /&gt;'."\n\t\t\t".'&lt;action type="Rewrite" url="{R:1}/'.str_replace(array('&', 'page\%3D'), array('&amp;amp;', 'page%3D'), addcslashes(pvadd($rewritedata['rulereplace'][$k], 1).'&{R:'.$pvmaxv.'}', '?')).'" /&gt;'."\n\t\t".'&lt;/rule&gt;'."\n";
    $rule['{zeus}'] .= 'match URL into $ with ^(.*)/'.$v.'\?*(.*)$'."\n".'if matched then'."\n\t".'set URL = $1/'.pvadd($rewritedata['rulereplace'][$k]).'&$'.$pvmaxv."\nendif\n";
    $rule['{nginx}'] .= 'rewrite ^([^\.]*)/'.$v.'$ $1/'.stripslashes(pvadd($rewritedata['rulereplace'][$k]))." last;\n";
}
$rule['{nginx}'] .= "if (!-e \$request_filename) {\n\treturn 404;\n}";
echo str_replace(array_keys($rule), $rule, $scriptlang['tom_fcpc']['rewrite_message']);
    
function pvsort($key, $v, $s) {
	$r = '/';
	$p = '';
	foreach($key as $k) {
		$r .= $p.preg_quote($k);
		$p = '|';
	}
	$r .= '/';
	preg_match_all($r, $v, $a);
	$a = $a[0];
	$a = array_flip($a);
	foreach($a as $key => $value) {
		$s = str_replace($key, '$'.($value + 1), $s);
	}
	return $s;
}

function pvadd($s, $t = 0) {
	$s = str_replace(array('$6','$5','$4', '$3', '$2', '$1'), array('~7', '~6', '~5', '~4', '~3', '~2'), $s);
	if(!$t) {
		return str_replace(array('~7','~6','~5', '~4', '~3', '~2'), array('$7','$6','$5', '$4', '$3', '$2'), $s);
	} else {
		return str_replace(array('~7','~6','~5', '~4', '~3', '~2'), array('{R:7}','{R:6}','{R:5}','{R:4}', '{R:3}', '{R:2}'), $s);
	}

}