<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$fcpcConfig         = $_G['cache']['plugin']['tom_fcpc'];
$tcfangchanConfig   = $_G['cache']['plugin']['tom_tcfangchan'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/config/config.data.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/class/function.core.php';

$_G['m_siteurl'] = $_G['siteurl'];

$fcpcConfig['fangchan_hosts']    = trim($fcpcConfig['fangchan_hosts']);
$fcpcConfig['tongcheng_hosts']   = trim($fcpcConfig['tongcheng_hosts']);

if($fcpcConfig['open_fangchan_hosts'] == 1 && !empty($fcpcConfig['fangchan_hosts']) && !empty($fcpcConfig['tongcheng_hosts'])){
    
    $fcpcConfig['tongcheng_hosts']  = rtrim($fcpcConfig['tongcheng_hosts'], '/');
    $fcpcConfig['tongcheng_hosts']  = $fcpcConfig['tongcheng_hosts'].'/';
    
    $_G['m_siteurl'] = $fcpcConfig['tongcheng_hosts'];
    
}

## xiaofenlei start
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')){
    $xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
    $__ShowXiaofenlei = 1;
}
## xiaofenlei end

$tempDir = "/source/plugin/tom_fcpc/data/payqrcode/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0755); 
}

$act = isset($_GET['act'])? addslashes($_GET['act']):"fangchan";

if($act == "fangchan" && submitcheck('title') && $userStatus){
    
    $outArr = array(
        'code'=> 1,
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcfangchan_id          = intval($_GET['tcfangchan_id'])>0? intval($_GET['tcfangchan_id']):0;
    $title                  = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title                  = dhtmlspecialchars($title);
    $houses_id              = intval($_GET['houses_id'])>0? intval($_GET['houses_id']):0;
    $houses_name            = isset($_GET['houses_name'])? addslashes($_GET['houses_name']):'';
    $houses_name            = dhtmlspecialchars($houses_name);
    $city_id                = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id                = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id              = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $address                = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address                = dhtmlspecialchars($address);
    $lng                    = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                    = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $trade_id               = intval($_GET['trade_id'])>0? intval($_GET['trade_id']):0;
    $mianji                 = floatval($_GET['mianji'])>0? floatval($_GET['mianji']):0.00;
    $price                  = floatval($_GET['price'])>0? floatval($_GET['price']):0.0;
    $fabu_days              = intval($_GET['fabu_days'])>0? intval($_GET['fabu_days']):0;
    $xm                     = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $xm                     = dhtmlspecialchars($xm);
    $tel                    = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                    = dhtmlspecialchars($tel);
    $wx                     = isset($_GET['wx'])? addslashes($_GET['wx']):'';
    $wx                     = dhtmlspecialchars($wx);
    $house_tel              = isset($_GET['house_tel'])? addslashes($_GET['house_tel']):'';
    $house_tel              = dhtmlspecialchars($house_tel);
    $house_no               = isset($_GET['house_no'])? addslashes($_GET['house_no']):'';
    $house_no               = dhtmlspecialchars($house_no);
    $attr_zhuangxiu_type    = intval($_GET['attr_zhuangxiu_type'])>0? intval($_GET['attr_zhuangxiu_type']):0;
    $attr_house_type        = intval($_GET['attr_house_type'])>0? intval($_GET['attr_house_type']):0;
    $attr_chaoxiang_type    = intval($_GET['attr_chaoxiang_type'])>0? intval($_GET['attr_chaoxiang_type']):0;
    $attr_shi               = intval($_GET['attr_shi'])>0? intval($_GET['attr_shi']):0;
    $attr_ting              = intval($_GET['attr_ting'])>0? intval($_GET['attr_ting']):0;
    $attr_wei               = intval($_GET['attr_wei'])>0? intval($_GET['attr_wei']):0;
    $attr_louceng           = intval($_GET['attr_louceng'])>0? intval($_GET['attr_louceng']):0;
    $attr_cengshu           = intval($_GET['attr_cengshu'])>0? intval($_GET['attr_cengshu']):0;
    $attr_chanquan          = intval($_GET['attr_chanquan'])>0? intval($_GET['attr_chanquan']):0;
    $attr_elevator          = intval($_GET['attr_elevator'])>0? intval($_GET['attr_elevator']):0;
    $content                = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content                = dhtmlspecialchars($content);
    $video_url              = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_url              = dhtmlspecialchars($video_url);
    $video_pic              = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic              = dhtmlspecialchars($video_pic);
    $vr_link                = isset($_GET['vr_link'])? addslashes($_GET['vr_link']):'';
    $vr_link                = dhtmlspecialchars($vr_link);
    $vr_picurl              = isset($_GET['vr_picurl'])? addslashes($_GET['vr_picurl']):'';
    $vr_picurl              = dhtmlspecialchars($vr_picurl);
    
    $rent                   = intval($_GET['rent'])>0? intval($_GET['rent']):0;
    $attr_lease_type        = intval($_GET['attr_lease_type'])>0? intval($_GET['attr_lease_type']):0;
    $attr_rent_unit         = intval($_GET['attr_rent_unit'])>0? intval($_GET['attr_rent_unit']):1;
    $attr_rent_type         = intval($_GET['attr_rent_type'])>0? intval($_GET['attr_rent_type']):0;
    
    $fangchan_nature        = intval($_GET['fangchan_nature'])>0? intval($_GET['fangchan_nature']):0;
    $zhuanrang_price        = floatval($_GET['zhuanrang_price'])>0? floatval($_GET['zhuanrang_price']):0.00;
    $attr_shangpu_type      = intval($_GET['attr_shangpu_type'])>0? intval($_GET['attr_shangpu_type']):0;
    
    $tcfangchanInfo   = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($tcfangchan_id);
    $userInfo         = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcfangchanInfo['user_id']);
    
    if($trade_id > 0){
        $tradeInfo = C::t('#tom_tcfangchan#tom_tcfangchan_trade')->fetch_by_id($trade_id);
    }
    $teseTagsIdsArr = array();
    if(is_array($_GET['attr_tese_tags']) && !empty($_GET['attr_tese_tags'])){
        foreach($_GET['attr_tese_tags'] as $key => $value){
            if(intval($value) > 0){
                $teseTagsIdsArr[] = intval($value);
            }
        }
    }
    
    $configTagList = array();
    $attrTeseTagsStr = $attrTeseTagsIdsStr = '';
    if(is_array($teseTagsIdsArr) && !empty($teseTagsIdsArr)){
        $teseTagsIdsCount = count($teseTagsIdsArr);
        $attrTeseTagsIdsStr = implode(',', $teseTagsIdsArr);
        $configTagListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_all_list(" AND id IN({$attrTeseTagsIdsStr}) ", 'ORDER BY tsort ASC,id DESC', 0, $teseTagsIdsCount);
        $configTagNameArr = array();
        if(is_array($configTagListTmp) && !empty($configTagListTmp)){
            foreach($configTagListTmp as $key => $value){
                $configTagList[$key] = $value;
                $configTagNameArr[] = $value['name'];
            }
        }
        
        if(is_array($configTagNameArr) && !empty($configTagNameArr)){
            $attrTeseTagsStr = '|'.implode('|', $configTagNameArr).'|';
        }
    }
    
    $attrPeitaoTagsArr = array();
    if(is_array($_GET['attr_peitao_tags']) && !empty($_GET['attr_peitao_tags'])){
        foreach($_GET['attr_peitao_tags'] as $key => $value){
            if(!empty($value)){
                $attrPeitaoTagsArr[] = addslashes($chuzuPeitaoArr[$value]['name']);
            }
        }
    }
    
    $attrPeitaoTagsStr = '';
    if(is_array($attrPeitaoTagsArr) && !empty($attrPeitaoTagsArr)){
        $attrPeitaoTagsStr = '|'.implode('|', $attrPeitaoTagsArr).'|';
    }
    
    $city_id = 0;
    if($tcfangchanInfo['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tcfangchanInfo['site_id']);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($tcfangchanInfo['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photopsort_") !== false){
            $kk = intval(ltrim($key, "photopsort_"));
            $photoArr[$kk]['psort'] = addslashes($value);
        }
    }
    
    if(!$userInfo){
        $outArr = array(
            'code'  => 200,
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($houses_id > 0){
        $housesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($houses_id);
        if(!$housesInfo){
            $outArr = array(
                'code'  => 200,
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $checkSafeText = $title.$houses_name.$address.$xm.$content;
    $__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
    if(!empty($__CommonInfo['forbid_word'])){
        $forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
        $forbid_word = str_replace(array("\\*"), array('.*'), $forbid_word);
        $forbid_word = '.*('.$forbid_word.').*';
        $forbid_word = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word).')$/i';
        $contentTmpTmp = $checkSafeText;
        $contentTmpTmp = str_replace("\r\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\r","",$contentTmpTmp);
        if(@preg_match($forbid_word, $contentTmpTmp,$matches)) {
            $i = count($matches)-1;
            $word = '';
            if(isset($matches[$i]) && !empty($matches[$i])){
                $word = diconv($matches[$i],CHARSET,'utf-8');
            }
            if($tongchengConfig['safe_words_do'] == 1){
                $tcfangchanConfig['fangchan_must_shenhe'] = 1;
            }else{
                $outArr = array(
                    'code'  => 200,
                    'status'=> 505,
                    'word'=> $word,
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    if($__ShowXiaofenlei == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php';
        if($xiaofenleiConfig['open_msgseccheck'] == 1){
            @$s_m_r = wx_msgSecCheck($checkSafeText);
            if($s_m_r['code'] == 100){
                $tcfangchanConfig['fangchan_must_shenhe'] = 1;
            }
            if($s_m_r['code'] == 500){
                $outArr = array(
                    'code'  => 200,
                    'status'=> 505,
                    'word'=> $s_m_r['word'],
                );
                echo json_encode($outArr); exit;
            }
        }
        $imgseccheck_listArr = unserialize($xiaofenleiConfig['imgseccheck_list']);
        if(array_search('2',$imgseccheck_listArr) !== false && $xiaofenleiConfig['open_imgseccheck'] == 1){
            if(is_array($photoArr) && !empty($photoArr)){
                foreach ($photoArr as $kk => $vv){
                    if(!preg_match('/^http/', $vv['picurl']) ){
                        if(strpos($vv['picurl'], 'source/plugin/tom_') === false){    
                            $check_picurl_tmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                        }else{
                            $check_picurl_tmp = $_G['siteurl'].$vv['picurl'];
                        }
                    }else{
                        $check_picurl_tmp = $vv['picurl'];
                    }
                    @$s_i_r = wx_imgSecCheck($check_picurl_tmp);
                    if($s_i_r['code'] == 500){
                        $tcfangchanConfig['fangchan_must_shenhe'] = 1;
                    }
                }
            }
        }
    }
    
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    
    $agentStatus = $freeShenheStatus = 0;
    $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
    if($userInfo['editor'] == 0 && $agentInfo['id'] > 0){
        if($agentInfo['shenhe_status'] == 1){
            $agentStatus = 1;
            $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
            
            $mendianVipInfo = array();
            if($tcfangchanConfig['open_mendian_vip'] == 1 && $mendianInfo['vip_id'] > 0 && $mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
                $mendianVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
                if(is_array($mendianVipInfo) && !empty($mendianVipInfo)){
                    if($mendianVipInfo['free_shenhe'] == 1){
                        $freeShenheStatus = 1;
                    }
                    
                    if($mendianVipInfo['total_agent_fabu_num'] > 0){
                        $mendianFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$tcfangchanInfo['user_id']} AND expire_status = 3 AND pay_type = 3 AND add_time > {$mendianInfo['vip_add_time']} ");
                        if($mendianFangchanCount >= $mendianVipInfo['total_agent_fabu_num']){
                            $mendianVipInfo['agent_fabu_num'] = 0;
                        }
                    }
                }
            }
            
            $agentVipInfo = array();
            if($tcfangchanConfig['open_agent_vip'] == 1 && $agentInfo['vip_id'] > 0 && $agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP){
                $agentVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
                if(is_array($agentVipInfo) && !empty($agentVipInfo)){
                    if($agentVipInfo['free_shenhe'] == 1){
                        $freeShenheStatus = 1;
                    }
                    
                    if($agentVipInfo['total_fabu_num'] > 0){
                        $agentFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$tcfangchanInfo['user_id']} AND expire_status = 3 AND pay_type = 4 AND add_time > {$agentInfo['vip_add_time']} ");
                        if($agentFangchanCount >= $agentVipInfo['total_fabu_num']){
                            $agentVipInfo['fabu_num'] = 0;
                        }
                    }
                }
            }
            
        }else{
            $outArr = array(
                'code'  => 200,
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $firstFabuDaysStatus = $fabu_pay_price = $fabu_pay_score = 0;
    if($fabu_days > 0){
        $fangchan_fabu_list_str = str_replace("\r\n","{n}",$tcfangchanConfig['fangchan_fabu_list']); 
        $fangchan_fabu_list_str = str_replace("\n","{n}",$fangchan_fabu_list_str);
        $fangchan_fabu_list_arr = explode("{n}", $fangchan_fabu_list_str);
        $i = 1;
        if(is_array($fangchan_fabu_list_arr) && !empty($fangchan_fabu_list_arr)){
            foreach ($fangchan_fabu_list_arr as $key => $value){
                $fangchanFabuInfoTmp = array();
                $fangchanFabuInfoTmp = explode("|", $value);

                if($fangchanFabuInfoTmp[0] == $fabu_days){
                    $fabu_pay_price = $fangchanFabuInfoTmp[1];
                    
                    if($i == 1){
                        $firstFabuDaysStatus = 1;
                    }
                }
                $i++;
            }
        }
        
        if($tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $fabu_pay_score = ceil($fabu_pay_price * $tongchengConfig['pay_score_yuan']);
        }

        if($fabu_pay_price > 0){}else{
            $outArr = array(
                'code'  => 200,
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }
    if($agentStatus == 1){
        $fabu_pay_price = floatval($tcfangchanConfig['fangchan_agent_fabu_price']);
        if($tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $fabu_pay_score = ceil($fabu_pay_price * $tongchengConfig['pay_score_yuan']);
        }
        
        if($fabu_pay_price > 0){}else{
            $outArr = array(
                'code'  => 200,
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }

    $fabuPayStatus = 1;
    if($userInfo['editor'] == 1){
        $fabuPayStatus = 2;
    }
    
    if(($firstFabuDaysStatus == 1 || $agentStatus == 1) && $fabuPayStatus == 1){
        if($tcfangchanConfig['free_fabu_num'] > 0){
            $freeFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$tcfangchanInfo['user_id']} AND type = 3 ");
            if($tcfangchanConfig['free_fabu_num'] > $freeFabuCount){
                $fabuPayStatus = 3;
            }
        }
    }

    if($agentStatus == 1 && $fabuPayStatus == 1){
        if($mendianInfo['id'] > 0){
            $mendian_fabu_num_tmp = $tcfangchanConfig['default_mendian_vip_agent_fabu_num'];
            if(is_array($mendianVipInfo) && !empty($mendianVipInfo)){
                $mendian_fabu_num_tmp = intval($mendianVipInfo['agent_fabu_num']);
            }

            if($mendian_fabu_num_tmp > 0){
                $mendianFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$tcfangchanInfo['user_id']} AND mendian_id = {$mendianInfo['id']} AND type = 1 AND today_time = {$nowDayTime} ");
                if($mendian_fabu_num_tmp > $mendianFabuCount){
                    $fabuPayStatus = 4;
                }
            }
        }
    }

    if($agentStatus == 1 && $fabuPayStatus == 1){
        if(is_array($agentVipInfo) && !empty($agentVipInfo)){
            $agent_fabu_num_tmp = intval($agentVipInfo['fabu_num']);
            if($agent_fabu_num_tmp > 0){
                $agentFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$tcfangchanInfo['user_id']} AND agent_id = {$agentInfo['id']} AND type = 5 AND today_time = {$nowDayTime} ");
                if($agent_fabu_num_tmp > $agentFabuCount){
                    $fabuPayStatus = 5;
                }
            }
        }
    }
    
    if($fabuPayStatus == 1 && $fabu_pay_score > 0){
        if($userInfo['score'] >= $fabu_pay_score){
            $fabuPayStatus = 6;
        }
    }

    $pay_price = 0;
    
    if($fabuPayStatus == 1){
        $pay_price = $fabu_pay_price;
    }
    
    $pay_score = 0;
  
    if($fabuPayStatus == 6){
        $pay_score = $fabu_pay_score;
    }

    $searchText = $title.'|++++|'.$house_no.'|++++|'.$houses_name;
    
    $updateData = array();
    $updateData['site_id']              = $site_id;
    $updateData['title']                = $title;
    if($trade_id > 0 && $tradeInfo['id'] > 0){
        $searchText .= '|++++|'.$tradeInfo['name'];
        
        $updateData['trade_id']             = $tradeInfo['id'];
        $updateData['trade_name']           = $tradeInfo['name'];
    }
    if($houses_id > 0){
        $updateData['city_id']              = $housesInfo['city_id'];
        $updateData['area_id']              = $housesInfo['area_id'];
        $updateData['area_name']            = $housesInfo['area_name'];
        $updateData['street_id']            = $housesInfo['street_id'];
        $updateData['street_name']          = $housesInfo['street_name'];
        $updateData['address']              = $housesInfo['address'];
        $updateData['latitude']             = $housesInfo['latitude'];
        $updateData['longitude']            = $housesInfo['longitude'];
        $updateData['houses_id']            = $housesInfo['id'];
    }else{
        $updateData['city_id']              = $city_id;
        $updateData['area_id']              = $area_id;
        $updateData['area_name']            = $areaInfo['name'];
        $updateData['street_id']            = $street_id;
        $updateData['street_name']          = $streetInfo['name'];
        $updateData['address']              = $address;
        $updateData['latitude']             = $lat;
        $updateData['longitude']            = $lng;
    }
    $updateData['video_url']            = $video_url;
    $updateData['vr_link']              = $vr_link;
    $updateData['house_tel']            = $house_tel;
    $updateData['house_no']             = $house_no;
    $updateData['search_text']          = $searchText;
    $updateData['content']              = $content;
    $updateData['mianji']               = $mianji;
    if($agentInfo['id'] > 0){
        $updateData['source_type']          = 1;
        $updateData['xm']                   = $agentInfo['name'];
        $updateData['tel']                  = $agentInfo['tel'];
    }else{
        $updateData['source_type']          = 2;
        $updateData['xm']                   = $xm;
        $updateData['tel']                  = $tel;
        $updateData['wx']                   = $wx;
    }
    if($fangchan_nature > 0){
        $updateData['fangchan_nature']      = $fangchan_nature;
        if($fangchan_nature == 1){
            $updateData['rent']                 = $rent;
        }else if($fangchan_nature == 2){
            $updateData['price']                = $price;
        }else if($fangchan_nature == 3){
            $updateData['zhuanrang_price']      = $zhuanrang_price;
        }
    }
    
    if($tcfangchanInfo['model_id'] == 'ershoufang'){
        $updateData['houses_name']          = $houses_name;
        $updateData['price']                = $price;
    }else if($tcfangchanInfo['model_id'] == 'chuzu'){
        $updateData['houses_name']          = $houses_name;
        $updateData['rent']                 = $rent;
    }
    
    if($freeShenheStatus == 0 && $tcfangchanConfig['fangchan_must_shenhe'] == 1 && $fabuPayStatus != 2){
        $updateData['shenhe_status']        = 2;
        $updateData['status']               = 0;
    }else{
        $updateData['shenhe_status']        = 1;
        $updateData['status']               = 1;
    }
    if($fabuPayStatus == 1){
        $updateData['pay_status']           = 1;
        $updateData['status']               = 0;
    }else{
        $updateData['pay_status']           = 0;
    }
    if($fabuPayStatus == 2){
        $updateData['expire_status']        = 3;
    }else{
        $updateData['expire_status']        = 2;
    }
    
    if($fabuPayStatus == 1){
        $updateData['pay_type']             = 2;
    }else if($fabuPayStatus == 4){
        $updateData['pay_type']             = 3;
    }else if($fabuPayStatus == 5){
        $updateData['pay_type']             = 4;
    }else if($fabuPayStatus == 6){
        $updateData['pay_type']             = 5;
    }else{
        $updateData['pay_type']             = 1;
    }
    
    $updateData['client_ip_port']       = $_G['clientip'].'|'.$_SERVER['REMOTE_PORT'];
    $updateData['refresh_time']         = TIMESTAMP;
    $updateData['add_time']             = TIMESTAMP;
    if(C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData)){
        
        $insertData = array();
        $insertData['tcfangchan_id']        = $tcfangchan_id;
        $insertData['attr_tese_tags']       = $attrTeseTagsStr;
        if($fangchan_nature == 1){
            $insertData['attr_rent_type']       = $attr_rent_type;
            $insertData['attr_rent_unit']       = $attr_rent_unit;
        }
        
        if($tcfangchanInfo['model_id'] == 'ershoufang'){
            
            $insertData['attr_zhuangxiu_type']  = $attr_zhuangxiu_type;
            $insertData['attr_house_type']      = $attr_house_type;
            $insertData['attr_chaoxiang_type']  = $attr_chaoxiang_type;
            $insertData['attr_shi']             = $attr_shi;
            $insertData['attr_ting']            = $attr_ting;
            $insertData['attr_wei']             = $attr_wei;
            $insertData['attr_louceng']         = $attr_louceng;
            $insertData['attr_cengshu']         = $attr_cengshu;
            $insertData['attr_chanquan']        = $attr_chanquan;
            $insertData['attr_elevator']        = $attr_elevator;
            
        }else if($tcfangchanInfo['model_id'] == 'chuzu'){
            
            $insertData['attr_zhuangxiu_type']  = $attr_zhuangxiu_type;
            $insertData['attr_house_type']      = $attr_house_type;
            $insertData['attr_chaoxiang_type']  = $attr_chaoxiang_type;
            $insertData['attr_shi']             = $attr_shi;
            $insertData['attr_ting']            = $attr_ting;
            $insertData['attr_wei']             = $attr_wei;
            $insertData['attr_louceng']         = $attr_louceng;
            $insertData['attr_cengshu']         = $attr_cengshu;
            $insertData['attr_lease_type']      = $attr_lease_type;
            $insertData['attr_rent_type']       = $attr_rent_type;
            $insertData['attr_rent_unit']       = $attr_rent_unit;
            $insertData['attr_elevator']        = $attr_elevator;
            $insertData['attr_peitao_tags']     = $attrPeitaoTagsStr;
        
        }else if($tcfangchanInfo['model_id'] == 'shangpu'){
        
            $insertData['attr_shangpu_type']    = $attr_shangpu_type;
            $insertData['attr_louceng']         = $attr_louceng;
            $insertData['attr_cengshu']         = $attr_cengshu;
        
        }else if($tcfangchanInfo['model_id'] == 'xiezilou'){
            
            $insertData['attr_louceng']         = $attr_louceng;
            $insertData['attr_cengshu']         = $attr_cengshu;
        
        }
        
        $insertData['attr_time']            = TIMESTAMP;
        C::t("#tom_tcfangchan#tom_tcfangchan_attr")->insert($insertData);
        
        if(is_array($configTagList) && !empty($configTagList)){
            foreach($configTagList as $key => $value){
                $insertData = array();
                $insertData['tcfangchan_id']    = $tcfangchan_id;
                $insertData['config_tag_id']    = $value['id'];
                $insertData['config_tag_ids']   = $attrTeseTagsIdsStr;
                $insertData['name']             = $value['name'];
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_tag")->insert($insertData);
            }
        }
        
        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['tcfangchan_id'] = $tcfangchan_id;
                $insertData['type']          = 1;
                $insertData['picurl']        = $value['picurl'];
                $insertData['psort']         = $value['psort'];
                $insertData['add_time']      = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
        }
        if(!empty($vr_picurl)){
            $insertData = array();
            $insertData['tcfangchan_id']    = $tcfangchan_id;
            $insertData['type']             = 2;
            $insertData['picurl']           = $vr_picurl;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        if(!empty($video_pic)){
            $insertData = array();
            $insertData['tcfangchan_id']    = $tcfangchan_id;
            $insertData['type']             = 4;
            $insertData['picurl']           = $video_pic;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        
        if($fabuPayStatus == 3){
            $updateData = array();
            if($agentStatus == 1){
                $updateData['expire_status']   = 3;
            }else{
                $fabu_time = $fabu_days * 86400 + TIMESTAMP;
                
                $updateData['expire_status']   = 1;
                $updateData['expire_time']     = $fabu_time;
            }
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id, $updateData);
            
            $insertData = array();
            $insertData['user_id']      = $tcfangchanInfo['user_id'];
            $insertData['type']         = 3;
            $insertData['log_time']     = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_log")->insert($insertData);
        }
        
        if($fabuPayStatus == 4){
            $updateData = array();
            $updateData['expire_status']   = 3;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id, $updateData);
            
            $insertData = array();
            $insertData['user_id']      = $tcfangchanInfo['user_id'];
            $insertData['mendian_id']   = $agentInfo['mendian_id'];
            $insertData['agent_id']     = $agentInfo['id'];
            $insertData['type']         = 1;
            $insertData['today_time']   = $nowDayTime;
            $insertData['log_time']     = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_log")->insert($insertData);
        }
        
        if($fabuPayStatus == 5){
            $updateData = array();
            $updateData['expire_status']   = 3;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id, $updateData);
            
            $insertData = array();
            $insertData['user_id']      = $tcfangchanInfo['user_id'];
            $insertData['agent_id']     = $agentInfo['id'];
            $insertData['type']         = 5;
            $insertData['today_time']   = $nowDayTime;
            $insertData['log_time']     = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_log")->insert($insertData);
        }
        
        if($pay_score > 0){
            
            $updateData = array();
            $updateData['score'] = $userInfo['score'] - $pay_score;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

            if($fabuPayStatus == 6){
                $updateData = array();
                if($agentStatus == 1){
                    $updateData['expire_status']   = 3;
                }else{
                    $fabu_time = $fabu_days * 86400 + TIMESTAMP;

                    $updateData['expire_status']   = 1;
                    $updateData['expire_time']     = $fabu_time;
                }
                C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id, $updateData);
            }
            
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['score_value']      = $pay_score;
            $insertData['old_value']        = $userInfo['score'];
            $insertData['log_type']         = 51;
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        }
        
        if($pay_price > 0){
            
            if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
                include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
            }else{
                $outArr = array(
                    'code'  => 200,
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }
            
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'code'  => 200,
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

            $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['tcfangchan_id']    = $tcfangchan_id;
            $insertData['type']             = 1;
            $insertData['user_id']          = $userInfo['id'];
            $insertData['openid']           = $userInfo['openid'];
            $insertData['order_no']         = $order_no;
            if($fabuPayStatus == 1 && $agentStatus == 0){
                $insertData['fabu_days']      = $fabu_days;
                $insertData['fabu_price']     = $fabu_pay_price;
            }
            $insertData['pay_price']        = $pay_price;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tcfangchan#tom_tcfangchan_order')->insert($insertData)){
                $order_id = C::t('#tom_tcfangchan#tom_tcfangchan_order')->insert_id();

                $insertData = array();
                $insertData['plugin_id']       = 'tom_tcfangchan';          
                $insertData['order_no']        = $order_no;                 
                $insertData['goods_id']        = $order_id;         
                $insertData['goods_name']      = $title;
                $insertData['goods_beizu']     = '';
                $insertData['goods_url']       = 'plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=info&tcfangchan_id='.$tcfangchan_id;
                $insertData['succ_back_url']   = 'plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=myfangchanlist';
                $insertData['fail_back_url']   = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfangchanlist"; 
                $insertData['allow_alipay']    = 1;
                $insertData['pay_price']       = $pay_price;
                $insertData['order_status']    = 1;
                $insertData['add_time']        = TIMESTAMP;
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    
                    $payurl = $_G['m_siteurl']."plugin.php?id=tom_pay&order_no=".$order_no;
                    
                    $payqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_fcpc/data/payqrcode/'.md5($payurl).'.png';
                    $payqrcodeUrl = $_G['siteurl'].'source/plugin/tom_fcpc/data/payqrcode/'.md5($payurl).'.png';
                    
                    if(file_exists($payqrcodeImg)){
                    }else{
                        QRcode::png($payurl,$payqrcodeImg,'H',5,2);
                    }
                    
                    $outArr = array(
                        'code'          => 200,
                        'status'        => 200,
                        'pay_status'    => 1,
                        'pay_price'     => $pay_price,
                        'payqrcode'     => $payqrcodeUrl,
                    );
                    echo json_encode($outArr); exit;
               
                }else{
                    $outArr = array(
                        'code'    => 200,
                        'status'=> 304,
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
        }else{
            
            update_fangchan_tongcheng($tcfangchan_id);
            if(!empty($tongchengConfig['template_id']) && $tcfangchanConfig['fangchan_must_shenhe'] == 1 && $freeShenheStatus == 0){
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
                $weixinClass = new weixinClass($appid,$appsecret);

                $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($manageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_fangchan_shenhe_msg'),
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }

                $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($fcmanageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_fangchan_shenhe_msg'),
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }else{
                if($agentStatus == 1){
                    update_mendian_xinxi($agentInfo['mendian_id'], $mendianInfo);
                }
            }
            $outArr = array(
                'code'    => 200,
                'status'=> 200,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'code'    => 200,
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "fangchan_pay" && submitcheck('tcfangchan_id') && $userStatus){

    $outArr = array(
        'code'  => 1,
        'status'=> 1,
    );
    
    $user_id        = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;
    
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    $tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($tcfangchan_id);
    
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
    }else{
        $outArr = array(
            'code'  => 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'code'  => 200,
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tcfangchanInfo['user_id'] > 0 && $userInfo['id'] > 0 && $userInfo['id'] == $tcfangchanInfo['user_id']){ }else{
        $outArr = array(
            'code'  => 200,
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }

    $orderInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_order")->fetch_all_list(" AND type = 1 AND tcfangchan_id = {$tcfangchan_id} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($orderInfoTmp) && !empty($orderInfoTmp[0]) && $orderInfoTmp[0]['pay_price'] > 0 && $orderInfoTmp[0]['order_status'] == 1){ 
        $orderInfo = $orderInfoTmp[0];
    }else{
        $outArr = array(
            'code'  => 200,
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['pay_type']        = 2;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
    
    $pay_price = $orderInfo['pay_price'];
    if($pay_price <= 0){
        $outArr = array(
            'code'  => 200,
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['tcfangchan_id']    = $tcfangchan_id;
    $insertData['type']             = 1;
    $insertData['user_id']          = $userInfo['id'];
    $insertData['openid']           = $userInfo['openid'];
    $insertData['order_no']         = $order_no;
    $insertData['top_days']         = $orderInfo['top_days'];
    $insertData['top_price']        = $orderInfo['top_price'];
    $insertData['fabu_days']        = $orderInfo['fabu_days'];
    $insertData['fabu_price']       = $orderInfo['fabu_price'];
    $insertData['pay_price']        = $orderInfo['pay_price'];
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcfangchan#tom_tcfangchan_order')->insert($insertData)){
        $order_id = C::t('#tom_tcfangchan#tom_tcfangchan_order')->insert_id();

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tcfangchan';
        $insertData['order_no']        = $order_no;
        $insertData['goods_id']        = $order_id;
        $insertData['goods_name']      = $tcfangchanInfo['title'];
        $insertData['goods_beizu']     = '';
        $insertData['goods_url']       = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfangchanlist";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfangchanlist";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfangchanlist";
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $orderInfo['pay_price'];
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $payurl = $_G['m_siteurl']."plugin.php?id=tom_pay&order_no=".$order_no;
                    
            $payqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_fcpc/data/payqrcode/'.md5($payurl).'.png';
            $payqrcodeUrl = $_G['siteurl'].'source/plugin/tom_fcpc/data/payqrcode/'.md5($payurl).'.png';

            if(file_exists($payqrcodeImg)){
            }else{
                QRcode::png($payurl,$payqrcodeImg,'H',5,2);
            }

            $outArr = array(
                'code'          => 200,
                'status'        => 200,
                'pay_price'     => $pay_price,
                'payqrcode'     => $payqrcodeUrl,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'code'   => 200,
                'status' => 304,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'code'   => 200,
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }

}else if($act == "pay_refresh" && submitcheck('tcfangchan_id') && $userStatus){
    
    $outArr = array(
        'code'=> 1,
        'status'=> 1,
    );
    
    $user_id        = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;
    $userInfo       = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($user_id);
    $agentInfo      = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($user_id);
    $tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($tcfangchan_id);
    if($tcfangchanInfo['user_id'] > 0 && $userInfo['id'] > 0 && $userInfo['id'] == $tcfangchanInfo['user_id']){ }else{
        $outArr = array(
            'code'=> 200,
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
    }else{
        $outArr = array(
            'code'  => 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'code'  => 200,
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tcfangchanConfig['fangchan_refresh_price'] <= 0){
        $outArr = array(
            'code'  => 200,
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    $refreshPayStatus = 1;
    
    if($tcfangchanConfig['free_refresh_num'] > 0){
        $freeRefreshCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$user_id} AND type = 4 AND today_time = {$nowDayTime} ");
        if($tcfangchanConfig['free_refresh_num'] > $freeRefreshCount){
            $refreshPayStatus = 2;
        }
    }
    
    if($agentInfo['id'] > 0 && $agentInfo['shenhe_status'] == 1){
        if($refreshPayStatus == 1){
            $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
            if($mendianInfo['id'] > 0){
                $mendian_refresh_num_tmp = $tcfangchanConfig['default_mendian_vip_agent_refresh_num'];
                if($tcfangchanConfig['open_mendian_vip'] == 1 && $mendianInfo['vip_id'] > 0 && $mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
                    $vipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
                    $mendian_refresh_num_tmp = intval($vipInfo['agent_refresh_num']);
                }

                $mendianRefreshCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$user_id} AND mendian_id = {$mendianInfo['id']} AND type = 2 AND today_time = {$nowDayTime} ");
                if($mendian_refresh_num_tmp > $mendianRefreshCount){
                    $refreshPayStatus = 3;
                }
            }
        }
        
        if($refreshPayStatus == 1 && $tcfangchanConfig['open_agent_vip'] == 1 && $agentInfo['vip_id'] > 0 && $agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP){
            $vipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
            $agent_refresh_num_tmp = intval($vipInfo['refresh_num']);
            $agentRefreshCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$user_id} AND agent_id = {$agentInfo['id']} AND type = 6 AND today_time = {$nowDayTime} ");
            if($agent_refresh_num_tmp > $agentRefreshCount){
                $refreshPayStatus = 4;
            }
        }
    }
    
    if($refreshPayStatus == 1 && $tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
        $refreshPayScore = ceil($tcfangchanConfig['fangchan_refresh_price'] * $tongchengConfig['pay_score_yuan']);
        if($refreshPayScore > 0 && $userInfo['score'] > $refreshPayScore){
            $refreshPayStatus = 5;
        }
    }
    
    if($refreshPayStatus == 1){
        
        $pay_price = floatval($tcfangchanConfig['fangchan_refresh_price']);
        
        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['tcfangchan_id']    = $tcfangchan_id;
        $insertData['type']             = 4;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcfangchan#tom_tcfangchan_order')->insert($insertData)){
            $order_id = C::t('#tom_tcfangchan#tom_tcfangchan_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcfangchan';
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $order_id;
            $insertData['goods_name']      = lang('plugin/tom_tcfangchan','mendian_refresh');
            $insertData['goods_beizu']     = lang('plugin/tom_tcfangchan','mendian_refresh');
            $insertData['goods_url']       = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfangchanlist";
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=myfangchanlist';
            $insertData['fail_back_url']   = 'plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=myfangchanlist';
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $payurl = $_G['m_siteurl']."plugin.php?id=tom_pay&order_no=".$order_no;
                    
                $payqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_fcpc/data/payqrcode/'.md5($payurl).'.png';
                $payqrcodeUrl = $_G['siteurl'].'source/plugin/tom_fcpc/data/payqrcode/'.md5($payurl).'.png';

                if(file_exists($payqrcodeImg)){
                }else{
                    QRcode::png($payurl,$payqrcodeImg,'H',5,2);
                }
                
                $outArr = array(
                    'code'          => 200,
                    'status'        => 200,
                    'pay_status'    => 1,
                    'pay_price'     => $pay_price,
                    'payqrcode'     => $payqrcodeUrl,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'code'  => 200,
                    'status'=> 304,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'code'  => 200,
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
        
    }else if($refreshPayStatus == 2){
        
        $updateData = array();
        $updateData['refresh_time']   = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
        
        $insertData = array();
        $insertData['user_id']      = $user_id;
        $insertData['type']         = 4;
        $insertData['today_time']   = $nowDayTime;
        $insertData['log_time']     = TIMESTAMP;
        C::t("#tom_tcfangchan#tom_tcfangchan_log")->insert($insertData);
        
    }else if($refreshPayStatus == 3){
        
        $updateData = array();
        $updateData['refresh_time']   = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
        
        $insertData = array();
        $insertData['user_id']      = $user_id;
        $insertData['mendian_id']   = $agentInfo['mendian_id'];
        $insertData['agent_id']     = $agentInfo['id'];
        $insertData['type']         = 2;
        $insertData['today_time']   = $nowDayTime;
        $insertData['log_time']     = TIMESTAMP;
        C::t("#tom_tcfangchan#tom_tcfangchan_log")->insert($insertData);
        
    }else if($refreshPayStatus == 4){
                
        $updateData = array();
        $updateData['refresh_time']   = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
        
        $insertData = array();
        $insertData['user_id']      = $user_id;
        $insertData['agent_id']     = $agentInfo['id'];
        $insertData['type']         = 6;
        $insertData['today_time']   = $nowDayTime;
        $insertData['log_time']     = TIMESTAMP;
        C::t("#tom_tcfangchan#tom_tcfangchan_log")->insert($insertData);
        
    }else if($refreshPayStatus == 5){
        
        $pay_score = $refreshPayScore;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $updateData = array();
        $updateData['refresh_time']   = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
        
        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 54;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
    }
    
    update_fangchan_tongcheng($tcfangchan_id);
    
    $outArr = array(
        'code'          => 200,
        'status'        => 200,
        'pay_status'    => 0,
    );
    echo json_encode($outArr); exit;
    
}else if($act == "adviser_pay" && submitcheck('adviser_id')){
    
    $outArr = array(
        'code'=> 1,
        'status'=> 1,
    );
    
    $adviser_id     = intval($_GET['adviser_id'])>0 ? intval($_GET['adviser_id']):0;
    
    $adviserInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->fetch_by_id($adviser_id);
    if(!$adviserInfo){
        $outArr = array(
            'code'     => 200,
            'status'   => 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $userInfo      = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($adviserInfo['user_id']);
    $newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($adviserInfo['newhouses_id']);
    
    if($newhousesInfo['open_sale_adviser'] == 0){
        $outArr = array(
            'code'     => 200,
            'status'   => 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $nowTime = TIMESTAMP;
    if($newhousesInfo['sale_adviser_num'] > 0){
        $adviserCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count(" AND newhouses_id = {$newhousesInfo['id']} AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) ");
        if($adviserCount >= $newhousesInfo['sale_adviser_num']){
            $outArr = array(
                'code'    => 200,
                'status'  => 302,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($tcfangchanConfig['newhouses_sale_adviser_max_num'] > 0){
        $adviserCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count(" AND user_id = {$userInfo['id']} AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) ");
        if($adviserCount >= $tcfangchanConfig['newhouses_sale_adviser_max_num']){
            $outArr = array(
                'code'   => 200,
                'status' => 304,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
    }else{
        $outArr = array(
            'code'  => 200,
            'status'=> 308,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'code'  => 200,
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
    $pay_price = $fabu_days = 0;
    $orderInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_order')->fetch_all_list(" AND adviser_id = {$adviserInfo['id']} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($orderInfoTmp) && !empty($orderInfoTmp[0])){
        $pay_price = $orderInfoTmp[0]['pay_price'];
        $fabu_days = $orderInfoTmp[0]['fabu_days'];
    }
    if($pay_price <= 0){
        $outArr = array(
            'code'  => 200,
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }

    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['adviser_id']       = $adviserInfo['id'];
    $insertData['type']             = 9;
    $insertData['user_id']          = $userInfo['id'];
    $insertData['openid']           = $userInfo['openid'];
    $insertData['order_no']         = $order_no;
    $insertData['pay_price']        = $pay_price;
    $insertData['fabu_days']        = $fabu_days;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcfangchan#tom_tcfangchan_order')->insert($insertData)){
        $order_id = C::t('#tom_tcfangchan#tom_tcfangchan_order')->insert_id();

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tcfangchan';
        $insertData['order_no']        = $order_no;
        $insertData['goods_id']        = $order_id;
        $insertData['goods_name']      = lang('plugin/tom_tcfangchan', 'order_type_9');
        $insertData['goods_beizu']     = $newhousesInfo['name'];
        $insertData['goods_url']       = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesinfo&newhouses_id={$newhousesInfo['id']}";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myadviserlist";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myadviserlist";
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $pay_price;
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            
            $payurl = $_G['m_siteurl']."plugin.php?id=tom_pay&order_no=".$order_no;
                    
            $payqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_fcpc/data/payqrcode/'.md5($payurl).'.png';
            $payqrcodeUrl = $_G['siteurl'].'source/plugin/tom_fcpc/data/payqrcode/'.md5($payurl).'.png';

            if(file_exists($payqrcodeImg)){
            }else{
                QRcode::png($payurl,$payqrcodeImg,'H',5,2);
            }

            $outArr = array(
                'code'          => 200,
                'status'        => 200,
                'pay_status'    => 1,
                'pay_price'     => $pay_price,
                'payqrcode'     => $payqrcodeUrl,
            );
            echo json_encode($outArr); exit;
          
        }else{
            $outArr = array(
                'code'   => 200,
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'code'   => 200,
            'status'=> 307,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "adviser_ruzhu_pay" && submitcheck('newhouses_id')){

    $outArr = array(
        'code'=> 1,
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name                   = dhtmlspecialchars($name);
    $tel                    = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                    = dhtmlspecialchars($tel);
    $sub_desc               = isset($_GET['sub_desc'])? addslashes($_GET['sub_desc']):'';
    $sub_desc               = dhtmlspecialchars($sub_desc);
    $avatar                 = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $avatar                 = dhtmlspecialchars($avatar);
    $wx_qrcode              = isset($_GET['wx_qrcode'])? addslashes($_GET['wx_qrcode']):'';
    $wx_qrcode              = dhtmlspecialchars($wx_qrcode);
    $work_picurl            = isset($_GET['work_picurl'])? addslashes($_GET['work_picurl']):'';
    $work_picurl            = dhtmlspecialchars($work_picurl);
    $newhouses_id           = intval($_GET['newhouses_id'])>0? intval($_GET['newhouses_id']):0;
    $fabu_days              = intval($_GET['fabu_days'])>0? intval($_GET['fabu_days']):0;
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($__UserInfo['id']);
    if(!$userInfo){
        $outArr = array(
            'code'   => 200,
            'status' => 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $newhousesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_by_id($newhouses_id);
    if(!$newhousesInfo){
        $outArr = array(
            'code'   => 200,
            'status' => 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
    }else{
        $outArr = array(
            'code'  => 200,
            'status'=> 309,
        );
        echo json_encode($outArr); exit;
    }
    
    if($newhousesInfo['open_sale_adviser'] != 1){
        $outArr = array(
            'code'   => 200,
            'status' => 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $nowTime = TIMESTAMP;
    $adviserCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count(" AND newhouses_id = {$newhousesInfo['id']} AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) ");
    if($adviserCount >= $newhousesInfo['sale_adviser_num']){
        $outArr = array(
            'code'   => 200,
            'status' => 303,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tcfangchanConfig['newhouses_sale_adviser_max_num'] > 0){
        $adviserCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count(" AND user_id = {$userInfo['id']} AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) ");
        if($adviserCount >= $tcfangchanConfig['newhouses_sale_adviser_max_num']){
            $outArr = array(
                'code'   => 200,
                'status' => 304,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $ruzhuPayStatus = 0;
    if(!empty($newhousesInfo['sale_adviser_price_list'])){
        $ruzhuPayStatus = 1;
        
        if($fabu_days > 0){
            
            $pay_price = 0;
            
            $sale_adviser_price_list_str = str_replace("\r\n","{n}",$newhousesInfo['sale_adviser_price_list']);
            $sale_adviser_price_list_str = str_replace("\n","{n}",$sale_adviser_price_list_str);
            $sale_adviser_price_list_arr = explode("{n}", $sale_adviser_price_list_str);
            if(is_array($sale_adviser_price_list_arr) && !empty($sale_adviser_price_list_arr)){
                foreach($sale_adviser_price_list_arr as $key => $value){
                    if(!empty($value)){
                        $arrTmp = explode('|', $value);
                        if($arrTmp[0] == $fabu_days){
                            $pay_price = $arrTmp[1];
                        }
                    }
                }
            }
            
        }else{
            $outArr = array(
                'code'   => 200,
                'status' => 308,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $adviserInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->fetch_all_list(" AND newhouses_id = {$newhousesInfo['id']} AND user_id = {$userInfo['id']} ", 'ORDER BY id DESC', 0, 1);
    if(is_array($adviserInfoTmp) && !empty($adviserInfoTmp[0])){
        $adviserInfo = $adviserInfoTmp[0];
        if(($adviserInfo['pay_status'] == 0 && $adviserInfo['expire_status'] == 3) || ($adviserInfo['pay_status'] == 2 && $adviserInfo['expire_status'] == 1 && $adviserInfo['expire_time'] > TIMESTAMP)){
            $outArr = array(
                'code'   => 200,
                'status' => 302,
            );
            echo json_encode($outArr); exit;
        }else{
            C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->delete_by_id($adviserInfo['id']);
        }
    }
    
    $insertData = array();
    $insertData['site_id']              = $newhousesInfo['site_id'];
    $insertData['user_id']              = $userInfo['id'];
    $insertData['newhouses_id']         = $newhousesInfo['id'];
    $insertData['newhouses_name']       = $newhousesInfo['name'];
    $insertData['name']                 = $name;
    $insertData['sub_desc']             = $sub_desc;
    $insertData['tel']                  = $tel;
    $insertData['avatar']               = $avatar;
    $insertData['wx_qrcode']            = $wx_qrcode;
    $insertData['work_picurl']          = $work_picurl;
    if($ruzhuPayStatus == 1){
        $insertData['pay_status']           = 1;
    }else{
        $insertData['pay_status']           = 0;
        $insertData['expire_status']        = 3;
    }
    $insertData['status']               = 1;
    $insertData['shenhe_status']        = 2;
    $insertData['add_time']             = TIMESTAMP;
    if(C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->insert($insertData)){
        $adviser_id = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->insert_id();
        
        if($ruzhuPayStatus == 1){
            
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'code'   => 200,
                    'status' => 305,
                );
                echo json_encode($outArr); exit;
            }

            $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['adviser_id']       = $adviser_id;
            $insertData['type']             = 9;
            $insertData['user_id']          = $userInfo['id'];
            $insertData['openid']           = $userInfo['openid'];
            $insertData['order_no']         = $order_no;
            $insertData['pay_price']        = $pay_price;
            $insertData['fabu_days']        = $fabu_days;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tcfangchan#tom_tcfangchan_order')->insert($insertData)){
                $order_id = C::t('#tom_tcfangchan#tom_tcfangchan_order')->insert_id();

                $insertData = array();
                $insertData['plugin_id']       = 'tom_tcfangchan';          
                $insertData['order_no']        = $order_no;                 
                $insertData['goods_id']        = $order_id;         
                $insertData['goods_name']      = lang('plugin/tom_tcfangchan', 'order_type_9');
                $insertData['goods_beizu']     = $newhousesInfo['name'];
                $insertData['goods_url']       = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesinfo&newhouses_id={$newhousesInfo['id']}";
                $insertData['succ_back_url']   = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myadviserlist";
                $insertData['fail_back_url']   = $back_url; 
                $insertData['allow_alipay']    = 1;
                $insertData['pay_price']       = $pay_price;
                $insertData['order_status']    = 1;
                $insertData['add_time']        = TIMESTAMP;
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    
                    $payurl = $_G['m_siteurl']."plugin.php?id=tom_pay&order_no=".$order_no;
                    
                    $payqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_fcpc/data/payqrcode/'.md5($payurl).'.png';
                    $payqrcodeUrl = $_G['siteurl'].'source/plugin/tom_fcpc/data/payqrcode/'.md5($payurl).'.png';

                    if(file_exists($payqrcodeImg)){
                    }else{
                        QRcode::png($payurl,$payqrcodeImg,'H',5,2);
                    }

                    $outArr = array(
                        'code'          => 200,
                        'status'        => 200,
                        'pay_status'    => 1,
                        'pay_price'     => $pay_price,
                        'payqrcode'     => $payqrcodeUrl,
                    );
                    echo json_encode($outArr); exit;
                   
                }else{
                    $outArr = array(
                        'code'   => 200,
                        'status' => 307,
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
        }else{
            
            if(!empty($tongchengConfig['template_id'])){
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
                $weixinClass = new weixinClass($appid,$appsecret);

                $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($manageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_adviser_shenhe_msg'),
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }

                $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($fcmanageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_adviser_shenhe_msg'),
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }
            $outArr = array(
                'code'   => 200,
                'status' => 200,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'code'   => 200,
            'status' => 306,
        );
        echo json_encode($outArr); exit;
    }
    
}else{
    $outArr = array(
        'code'  => 111111,
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}