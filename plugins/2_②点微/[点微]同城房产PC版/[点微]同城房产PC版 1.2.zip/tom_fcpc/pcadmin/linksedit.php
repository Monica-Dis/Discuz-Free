<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$links_id = intval($_GET['links_id'])>0 ? intval($_GET['links_id']):0;
$linksInfo = C::t('#tom_fcpc#tom_fcpc_links')->fetch_by_id($links_id);
if(empty($linksInfo)){
    dheader('location:'.$pcadminUrl."&tmod=links");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=linksedit&links_id={$links_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $link           = isset($_GET['link'])? addslashes($_GET['link']):'';
    $lsort          = isset($_GET['lsort'])? intval($_GET['lsort']):10;
    
    $updateData = array();
    $updateData['site_id']      = $site_id;
    $updateData['name']         = $name;
    $updateData['link']         = $link;
    $updateData['lsort']        = $lsort;
    $updateData['add_time']     = TIMESTAMP;
    if(C::t('#tom_fcpc#tom_fcpc_links')->update($links_id, $updateData)){
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:pcadmin/linksedit");