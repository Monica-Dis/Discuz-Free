<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=guanggao";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('guanggao_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $guanggao_id = intval($_GET['guanggao_id'])>0 ? intval($_GET['guanggao_id']):0;
    
    C::t('#tom_fcpc#tom_fcpc_guanggao')->delete_by_id($guanggao_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;
$site_id    = intval($_GET['site_id'])>0? intval($_GET['site_id']):0;
$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$weizhi     = intval($_GET['weizhi'])>0? intval($_GET['weizhi']):0;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = "";
if($site_id > 0){
    $where .= " AND site_id={$site_id} ";
}
if($type > 0){
    $where .= " AND type={$type} ";
}
if($weizhi > 0){
    $where .= " AND weizhi={$weizhi} ";
}

$orderStr = ' ORDER BY id DESC ';
if($weizhi > 0){
    $orderStr = ' ORDER BY gsort ASC,id DESC ';
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_count($where);
$guanggaoListTmp = C::t('#tom_fcpc#tom_fcpc_guanggao')->fetch_all_list($where,$orderStr,$start,$pagesize);
$guanggaoList = array();
if(!empty($guanggaoListTmp)){
    foreach ($guanggaoListTmp as $key => $value) {
        $guanggaoList[$key] = $value;
        
        $guanggaoList[$key]['picurlTmp']    = get_file_url($value['picurl']);
        $guanggaoList[$key]['siteInfo']     = $sitesList[$value['site_id']];
        $guanggaoList[$key]['over_time']    = dgmdate($value['over_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&type={$type}&weizhi={$weizhi}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_fcpc:pcadmin/guanggao");