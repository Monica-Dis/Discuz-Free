<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function tom_fcpc_url($mod,$site,$param = array()){
    global $_G;
    
    $fcpcConfig = $_G['cache']['plugin']['tom_fcpc'];
    
    $siteurl = $_G['siteurl'];
    
    $fcpcConfig['fangchan_hosts'] = trim($fcpcConfig['fangchan_hosts']);
    if($fcpcConfig['open_fangchan_hosts'] == 1 && !empty($fcpcConfig['fangchan_hosts'])){
        $fcpcConfig['fangchan_hosts']  = rtrim($fcpcConfig['fangchan_hosts'], '/');
        $fcpcConfig['fangchan_hosts']  = $fcpcConfig['fangchan_hosts'].'/';
        $siteurl = $fcpcConfig['fangchan_hosts'];
    }
    
    $url = '';
    
    $rewrite = 0;
    if($fcpcConfig['open_rewrite'] == 1){
        $rewrite = 1;
    }
    
    if($site > 0){}else{
        $site = 1;
    }
    
    if($mod == 'index'){
        if($rewrite == 1){
            if($site > 1){
                $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/index-{$site}.html";
            }else{
                if($fcpcConfig['open_fangchan_hosts'] == 1 && !empty($fcpcConfig['fangchan_hosts'])){
                    $url = $siteurl;
                }else{
                    $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/";
                }
            }
        }else{
            if($site == 1 && $fcpcConfig['open_fangchan_hosts'] == 1 && !empty($fcpcConfig['fangchan_hosts'])){
                $url = $siteurl;
            }else{
                $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=index";
            }
        }
        
    }else if($mod == 'newhouseslist'){
        if($rewrite == 1){
            $area_id = $street_id = 0;
            $page = 1;
            if(isset($param['area_id']) && $param['area_id'] > 0){
                $area_id = $param['area_id'];
            }
            if(isset($param['street_id']) && $param['street_id'] > 0){
                $street_id = $param['street_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/newhouseslist-{$site}-{$area_id}-{$street_id}-{$page}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=newhouseslist";
            if(isset($param['area_id']) && $param['area_id'] > 0){
                $url = $url."&area_id={$param['area_id']}";
            }
            if(isset($param['street_id']) && $param['street_id'] > 0){
                $url = $url."&street_id={$param['street_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
        
    }else if($mod == 'newhousesinfo'){
        if($rewrite == 1){
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/newhousesinfo-{$site}-{$param['newhouses_id']}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=newhousesinfo&newhouses_id={$param['newhouses_id']}";
        }
           
    }else if($mod == 'list'){
        if($rewrite == 1){
            $model_id = '';
            $area_id = $street_id = 0;
            $page = 1;
            if(isset($param['model_id']) && !empty($param['model_id'])){
                $model_id = $param['model_id'];
            }
            if(isset($param['area_id']) && $param['area_id'] > 0){
                $area_id = $param['area_id'];
            }
            if(isset($param['street_id']) && $param['street_id'] > 0){
                $street_id = $param['street_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/list-{$model_id}-{$site}-{$area_id}-{$street_id}-{$page}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=list";
            if(!empty($param['model_id'])){
                $url = $url."&model_id={$param['model_id']}";
            }
            if(isset($param['area_id']) && $param['area_id'] > 0){
                $url = $url."&area_id={$param['area_id']}";
            }
            if(isset($param['street_id']) && $param['street_id'] > 0){
                $url = $url."&street_id={$param['street_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
        
    }else if($mod == 'info'){
        if($rewrite == 1){
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/info-{$site}-{$param['tcfangchan_id']}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=info&tcfangchan_id={$param['tcfangchan_id']}";
        }
        
    }else if($mod == 'houseslist'){
        if($rewrite == 1){
            $area_id = $street_id = 0;
            $page = 1;
            if(isset($param['area_id']) && $param['area_id'] > 0){
                $area_id = $param['area_id'];
            }
            if(isset($param['street_id']) && $param['street_id'] > 0){
                $street_id = $param['street_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/houseslist-{$site}-{$area_id}-{$street_id}-{$page}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=houseslist";
            if(isset($param['area_id']) && $param['area_id'] > 0){
                $url = $url."&area_id={$param['area_id']}";
            }
            if(isset($param['street_id']) && $param['street_id'] > 0){
                $url = $url."&street_id={$param['street_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
    
    }else if($mod == 'housesinfo'){
        if($rewrite == 1){
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/housesinfo-{$site}-{$param['houses_id']}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=housesinfo&houses_id={$param['houses_id']}";
        }
    
    }else if($mod == 'mendianlist'){
        if($rewrite == 1){
            $area_id = $street_id = 0;
            $page = 1;
            if(isset($param['area_id']) && $param['area_id'] > 0){
                $area_id = $param['area_id'];
            }
            if(isset($param['street_id']) && $param['street_id'] > 0){
                $street_id = $param['street_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/mendianlist-{$site}-{$area_id}-{$street_id}-{$page}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=mendianlist";
            if(isset($param['area_id']) && $param['area_id'] > 0){
                $url = $url."&area_id={$param['area_id']}";
            }
            if(isset($param['street_id']) && $param['street_id'] > 0){
                $url = $url."&street_id={$param['street_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
    
    }else if($mod == 'mendianinfo'){
        if($rewrite == 1){
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/mendianinfo-{$site}-{$param['mendian_id']}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=mendianinfo&mendian_id={$param['mendian_id']}";
        }
        
    }else if($mod == 'agentlist'){
        if($rewrite == 1){
            $area_id = $street_id = 0;
            $page = 1;
            if(isset($param['area_id']) && $param['area_id'] > 0){
                $area_id = $param['area_id'];
            }
            if(isset($param['street_id']) && $param['street_id'] > 0){
                $street_id = $param['street_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/agentlist-{$site}-{$area_id}-{$street_id}-{$page}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=agentlist";
            if(isset($param['area_id']) && $param['area_id'] > 0){
                $url = $url."&area_id={$param['area_id']}";
            }
            if(isset($param['street_id']) && $param['street_id'] > 0){
                $url = $url."&street_id={$param['street_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
        
    }else if($mod == 'agentinfo'){
        if($rewrite == 1){
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/agentinfo-{$site}-{$param['agent_id']}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=agentinfo&agent_id={$param['agent_id']}";
        }
    
    }else if($mod == 'needslist'){
        if($rewrite == 1){
            $type = $area_id = $street_id = 0;
            $page = 1;
            if(isset($param['type']) && $param['type'] > 0){
                $type = $param['type'];
            }
            if(isset($param['area_id']) && $param['area_id'] > 0){
                $area_id = $param['area_id'];
            }
            if(isset($param['street_id']) && $param['street_id'] > 0){
                $street_id = $param['street_id'];
            }
            if(isset($param['page'])){
                $page = $param['page'];
            }
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/needslist-{$site}-{$type}-{$area_id}-{$street_id}-{$page}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=needslist";
            if(isset($param['type']) && $param['type'] > 0){
                $url = $url."&type={$param['type']}";
            }
            if(isset($param['area_id']) && $param['area_id'] > 0){
                $url = $url."&area_id={$param['area_id']}";
            }
            if(isset($param['street_id']) && $param['street_id'] > 0){
                $url = $url."&street_id={$param['street_id']}";
            }
            if(isset($param['page'])){
                $url = $url."&page={$param['page']}";
            }
        }
        
    }else if($mod == 'needsinfo'){
        if($rewrite == 1){
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/needsinfo-{$site}-{$param['needs_id']}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=needsinfo&needs_id={$param['needs_id']}";
        }
        
    }else if($mod == 'about'){
        if($rewrite == 1){
            $url = $siteurl.$fcpcConfig['rewrite_fangchan_name']."/about-{$site}-{$param['about_id']}.html";
        }else{
            $url = $siteurl."plugin.php?id=tom_fcpc&site={$site}&mod=about&about_id={$param['about_id']}";
        }
    }
    
    if($rewrite == 1 && $fcpcConfig['open_fangchan_hosts'] == 1 && $fcpcConfig['closed_rewrite_name'] == 1){
        $url = str_replace('/'.$fcpcConfig['rewrite_fangchan_name'].'/', '/', $url);
    }
    
    return $url;
    
}