<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $title                  = isset($_GET['title'])? addslashes($_GET['title']):'';
    $tcshop_id              = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
    $xianzhi_num            = intval($_GET['xianzhi_num'])>0 ? intval($_GET['xianzhi_num']):0;
    $today_num              = intval($_GET['today_num'])>0 ? intval($_GET['today_num']):0;
    $type                   = intval($_GET['type'])>0 ? intval($_GET['type']):1;
    $tequan_type            = intval($_GET['tequan_type'])>0 ? intval($_GET['tequan_type']):1;
    $tequan_zhekou          = isset($_GET['tequan_zhekou'])? addslashes($_GET['tequan_zhekou']):'';
    //$tequan_shengprice      = intval($_GET['tequan_shengprice'])>0 ? intval($_GET['tequan_shengprice']):0;
    $tequan_shengprice      = isset($_GET['tequan_shengprice'])? addslashes($_GET['tequan_shengprice']):'0';
    $tequan_shenglimit      = intval($_GET['tequan_shenglimit'])>0 ? intval($_GET['tequan_shenglimit']):0;
    $open_putong_zhekou     = intval($_GET['open_putong_zhekou'])>0 ? intval($_GET['open_putong_zhekou']):0;
    $putong_zhekou          = isset($_GET['putong_zhekou'])? addslashes($_GET['putong_zhekou']):'';
    $putong_shengprice      = intval($_GET['putong_shengprice'])>0 ? intval($_GET['putong_shengprice']):0;
    $putong_shenglimit      = intval($_GET['putong_shenglimit'])>0 ? intval($_GET['putong_shenglimit']):0;
    $guize                  = isset($_GET['guize'])? addslashes($_GET['guize']):'';
    $content                = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl                 = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    
    $weeksArr = $daysArr = array();
    if($type == 1){
        if(is_array($_GET['weeks']) && !empty($_GET['weeks'])){
            foreach($_GET['weeks'] as $key => $value){
                $weeksArr[] = intval($value);
            }
        }
        $weeks = '-'.implode('-', $weeksArr).'-';
    }else{
        if(is_array($_GET['days']) && !empty($_GET['days'])){
            foreach($_GET['days'] as $key => $value){
                $daysArr[] = intval($value);
            }
        }
        $days = '-'.implode('-', $daysArr).'-';
    }
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    if(empty($tcshopInfo)){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tcyikatongConfig['open_shop_more_tequan'] == 0){
        $tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_tcshop_id($tcshop_id);
        if(is_array($tequanInfo) && !empty($tequanInfo)){
            $name = diconv($tcshopInfo['name'],CHARSET,'utf-8');
            $outArr = array(
                'status'=> 302,
                'name'=> $name,
            );
            echo json_encode($outArr); exit;
        }
    }

    $insertData = array();
    $insertData['site_id']              = $tcshopInfo['site_id'];
    $insertData['tcshop_cate_id']       = $tcshopInfo['cate_id'];
    $insertData['tcshop_cate_child_id'] = $tcshopInfo['cate_child_id'];
    $insertData['tcshop_latitude']      = $tcshopInfo['latitude'];
    $insertData['tcshop_longitude']     = $tcshopInfo['longitude'];
    $insertData['tcshop_id']            = $tcshop_id;
    $insertData['user_id']              = $__UserInfo['id'];
    $insertData['title']                = $title;
    $insertData['picurl']               = $picurl;
    $insertData['type']                 = $type;
    if($type == 1){
        $insertData['weeks']            = $weeks;
    }else if($type == 2){
        $insertData['days']             = $days;
    }
    $insertData['xianzhi_num']          = $xianzhi_num;
    $insertData['today_num']            = $today_num;
    $insertData['tequan_type']          = $tequan_type;
    $insertData['tequan_zhekou']        = $tequan_zhekou;
    $insertData['tequan_shengprice']    = $tequan_shengprice;
    $insertData['tequan_shenglimit']    = $tequan_shenglimit;
    if($tcyikatongConfig['open_putong_zhekou'] == 1){
        $insertData['open_putong_zhekou'] = $open_putong_zhekou;
        $insertData['putong_zhekou']      = $putong_zhekou;
        $insertData['putong_shengprice']  = $putong_shengprice;
        $insertData['putong_shenglimit']  = $putong_shenglimit;
    }
    $insertData['guize']                = $guize;
    $insertData['content']              = $content;
    $insertData['status']               = 1;
    if($tcyikatongConfig['must_shenhe'] == 1){
        $insertData['shenhe_status']    = 2;
    }else{
        $insertData['shenhe_status']    = 1;
    }
    $insertData['add_time']             = TIMESTAMP;
    if(C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->insert($insertData)){
        
        $tequan_id = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->insert_id();
        
        if(is_array($weeksArr) && !empty($weeksArr)){
            foreach ($weeksArr as $key => $value){
                $insertData = array();
                $insertData['tequan_id'] = $tequan_id;
                $insertData['site_id']   = $tcshopInfo['site_id'];
                $insertData['week']      = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->insert($insertData);
            }
        }
        
        if(is_array($daysArr) && !empty($daysArr)){
            foreach ($daysArr as $key => $value){
                $insertData = array();
                $insertData['tequan_id'] = $tequan_id;
                $insertData['site_id']   = $tcshopInfo['site_id'];
                $insertData['day']       = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->insert($insertData);
            }
        }
        
        $shenhe_type = 0;
        if($tcyikatongConfig['must_shenhe'] == 1){
            $shenhe_type = 1;
            $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);

            $tcyikatong_ruzhu_shenhe_msg = str_replace('{NAME}', $tcyikatongConfig['plugin_name'],lang('plugin/tom_tcyikatong','tcyikatong_ruzhu_shenhe_msg') );
            
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($toUser['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcshop&site={$tcshopInfo['site_id']}&mod=index");

                $smsData = array(
                    'first'         => $tcyikatong_ruzhu_shenhe_msg,
                    'keyword1'      => $tongchengConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                @$r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
            'type'=> $shenhe_type,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}

$allTcshopCount = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count(" AND user_id={$__UserInfo['id']} ");

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$__UserInfo['id']} AND v.open_tcyikatong=1 "," ORDER BY s.id DESC ",0,100);
$tcshopList = array();
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach ($tcshopListTmp as $key => $value){
        $tcshopList[$key] = $value;
    }
}
$tcshopCount = count($tcshopList);

$ruzhu_xieyi_txt = stripslashes($commonInfo['ruzhu_xieyi_txt']);

$daysDateArray = array();
for($i = 1; $i <= 31; $i++){
    $daysDateArray[$i] = $i;
}

$tequanZhekouListArr = unserialize($tcyikatongConfig['tequan_zhekou_list']);
$noTequanZhekouListArr = unserialize($tcyikatongConfig['putong_zhekou_list']);

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcyikatong&site={$site_id}&mod=ruzhu";

$ruzhuUrl = "plugin.php?id=tom_tcyikatong&mod=ruzhu&act=save&site={$site_id}";
$backLinkUrl = "plugin.php?id=tom_tcyikatong&site={$site_id}&mod=mylist&fromlist=mylist";
$uploadUrl = "plugin.php?id=tom_tcyikatong&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcyikatong:ruzhu");