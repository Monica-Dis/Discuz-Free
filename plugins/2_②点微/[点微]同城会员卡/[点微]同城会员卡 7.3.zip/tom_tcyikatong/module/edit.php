<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tequan_id = intval($_GET['tq_id'])>0? intval($_GET['tq_id']):0;

$tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_id($tequan_id);
$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tequanInfo['tcshop_id']);

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcyikatong&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $title                  = isset($_GET['title'])? addslashes($_GET['title']):'';
    $xianzhi_num            = intval($_GET['xianzhi_num'])>0 ? intval($_GET['xianzhi_num']):0;
    $today_num              = intval($_GET['today_num'])>0 ? intval($_GET['today_num']):0;
    $type                   = intval($_GET['type'])>0 ? intval($_GET['type']):1;
    $tequan_type            = intval($_GET['tequan_type'])>0 ? intval($_GET['tequan_type']):1;
    $tequan_zhekou          = isset($_GET['tequan_zhekou'])? addslashes($_GET['tequan_zhekou']):'';
    $tequan_shengprice      = intval($_GET['tequan_shengprice'])>0 ? intval($_GET['tequan_shengprice']):0;
    $tequan_shenglimit      = intval($_GET['tequan_shenglimit'])>0 ? intval($_GET['tequan_shenglimit']):0;
    $open_putong_zhekou     = intval($_GET['open_putong_zhekou'])>0 ? intval($_GET['open_putong_zhekou']):0;
    $putong_zhekou          = isset($_GET['putong_zhekou'])? addslashes($_GET['putong_zhekou']):'';
    $putong_shengprice      = intval($_GET['putong_shengprice'])>0 ? intval($_GET['putong_shengprice']):0;
    $putong_shenglimit      = intval($_GET['putong_shenglimit'])>0 ? intval($_GET['putong_shenglimit']):0;
    $guize                  = isset($_GET['guize'])? addslashes($_GET['guize']):'';
    $content                = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl                 = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    
    $weeksArr = $daysArr = array();
    if($type == 1){
        if(is_array($_GET['weeks']) && !empty($_GET['weeks'])){
            foreach($_GET['weeks'] as $key => $value){
                $weeksArr[] = intval($value);
            }
        }
        $weeks = '-'.implode('-', $weeksArr).'-';
    }else{
        if(is_array($_GET['days']) && !empty($_GET['days'])){
            foreach($_GET['days'] as $key => $value){
                $daysArr[] = intval($value);
            }
        }
        $days = '-'.implode('-', $daysArr).'-';
    }

    $updateData = array();
    $updateData['title']            = $title;
    $updateData['picurl']           = $picurl;
    $updateData['type']             = $type;
    if($type == 1){
        $updateData['weeks']        = $weeks;
    }else if($type == 2){
        $updateData['days']         = $days;
    }
    $updateData['tequan_type']      = $tequan_type;
    $updateData['tequan_zhekou']    = $tequan_zhekou;
    $updateData['tequan_shengprice']= $tequan_shengprice;
    $updateData['tequan_shenglimit']= $tequan_shenglimit;
    if($tcyikatongConfig['open_putong_zhekou'] == 1){
        $updateData['open_putong_zhekou'] = $open_putong_zhekou;
        $updateData['putong_zhekou']      = $putong_zhekou;
        $updateData['putong_shengprice']  = $putong_shengprice;
        $updateData['putong_shenglimit']  = $putong_shenglimit;
    }
    $updateData['xianzhi_num']      = $xianzhi_num;
    $updateData['today_num']        = $today_num;
    $updateData['guize']            = $guize;
    $updateData['content']          = $content;
    $updateData['part1']            = TIMESTAMP;
    
    if(C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->update($tequan_id,$updateData)){
        
        C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->delete_by_tequan_id($tequan_id);
        C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->delete_by_tequan_id($tequan_id);
        
        if(is_array($weeksArr) && !empty($weeksArr)){
            foreach ($weeksArr as $key => $value){
                $insertData = array();
                $insertData['tequan_id'] = $tequan_id;
                $insertData['site_id']   = $tcshopInfo['site_id'];
                $insertData['week']      = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->insert($insertData);
            }
        }
        
        if(is_array($daysArr) && !empty($daysArr)){
            foreach ($daysArr as $key => $value){
                $insertData = array();
                $insertData['tequan_id'] = $tequan_id;
                $insertData['site_id']   = $tcshopInfo['site_id'];
                $insertData['day']       = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->insert($insertData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}

if(!preg_match('/^http/', $tequanInfo['picurl']) ){
    if(strpos($tequanInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tequanInfo['picurl'];
    }else{
        $picurl = $tequanInfo['picurl'];
    }
}else{
    $picurl = $tequanInfo['picurl'];
}

$weeksListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->fetch_all_list(" AND tequan_id = {$tequanInfo['id']} ", " ORDER BY week ASC,id DESC ", 0, 10);
$weeksList = array();
if(is_array($weeksListTmp) && !empty($weeksListTmp)){
    foreach($weeksListTmp as $key => $value){
        $weeksList[] = $value['week'];
    }
}
$checkedWeeksList = array();
if(is_array($weeksDateArray) && !empty($weeksDateArray)){
    foreach($weeksDateArray as $key => $value){
        $checkedWeeksList[$key]['name'] = $value;
        if(in_array($key,$weeksList)){
            $checkedWeeksList[$key]['status'] = 1;
        }else{
            $checkedWeeksList[$key]['status'] = 0;
        }
    }
}

$daysListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->fetch_all_list(" AND tequan_id = {$tequanInfo['id']} ", " ORDER BY day ASC,id DESC ", 0, 50);
$daysList = array();
if(is_array($daysListTmp) && !empty($daysListTmp)){
    foreach($daysListTmp as $key => $value){
        $daysList[] = $value['day'];
    }
}

$checkedDaysList = array();
for($i = 1; $i <= 31; $i++){
    $checkedDaysList[$i]['name'] = $i;
    if(in_array($i,$daysList)){
        $checkedDaysList[$i]['status'] = 1;
    }else{
        $checkedDaysList[$i]['status'] = 0;
    }
}

$tequanZhekouListArr = unserialize($tcyikatongConfig['tequan_zhekou_list']);
$noTequanZhekouListArr = unserialize($tcyikatongConfig['putong_zhekou_list']);

$saveUrl = "plugin.php?id=tom_tcyikatong&site={$site_id}&mod=edit&act=save";
$uploadUrl = "plugin.php?id=tom_tcyikatong&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcyikatong:edit");