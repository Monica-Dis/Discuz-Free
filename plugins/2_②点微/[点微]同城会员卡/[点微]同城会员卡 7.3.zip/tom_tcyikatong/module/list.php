<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';
    
$area_id        = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id      = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$cate_id        = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$cate_child_id  = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
$week           = intval($_GET['week'])>0? intval($_GET['week']):0;
$day            = intval($_GET['day'])>0? intval($_GET['day']):0;
$keyword        = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$ordertype      = !empty($_GET['ordertype'])? addslashes($_GET['ordertype']):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$nowDay = date("d",strtotime(dgmdate($_G['timestamp'], 'Y-m-d H:i:s',$tomSysOffset)));
$nowWeek = dgmdate($_G['timestamp'], 'N',$tomSysOffset);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';
$sql_in_site_ids_arr = explode(',', $sql_in_site_ids);

$searchAddress = '';
if($tcshopConfig['open_ruzhu_area'] == 0){
    if(!empty($street_id)){
        $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
        $searchAddress = $streetInfo['name'];
    }else if(!empty($area_id)){
        $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
        $searchAddress = $areaInfo['name'];
    }
}
    
$whereStr = " AND t.status=1 AND t.shenhe_status=1 ";
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND t.site_id IN({$sql_in_site_ids}) ";
}
if(!empty($cate_id)){
    $whereStr.= " AND t.tcshop_cate_id={$cate_id} ";
}
if(!empty($cate_child_id)){
    $whereStr.= " AND t.tcshop_cate_child_id={$cate_child_id} ";
}
if(!empty($area_id)){
    $whereStr.= " AND s.area_id={$area_id} ";
}
if(!empty($street_id)){
    $whereStr.= " AND s.street_id={$street_id} ";
}
if(!empty($week) && !empty($day)){
    $whereStr.= " AND ((t.type=1 AND t.weeks LIKE '%-{$week}-%') OR (t.type=2 AND t.days LIKE '%-{$day}-%')) ";
}else if(!empty($week)){
    $whereStr.= " AND t.type=1 AND t.weeks LIKE '%-{$week}-%' ";
}else if(!empty($day)){
    $whereStr.= " AND t.type=2 AND t.days LIKE '%-{$day}-%' ";
}

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
$tequanList = array();
if($ordertype == 'lbs' && !empty($latitude) && !empty($longitude)){
    $tequanListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_left_shop_list($whereStr," ORDER BY t.paixu ASC,t.id DESC ",$start,$pagesize,$keyword,$latitude,$longitude,$searchAddress);
}else{
    $tequanListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_left_shop_list($whereStr," ORDER BY t.paixu ASC,t.id DESC ",$start,$pagesize,$keyword,'','',$searchAddress);
}
if(is_array($tequanListTmp) && !empty($tequanListTmp)){
    foreach ($tequanListTmp as $key => $value) {
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        
        if(!preg_match('/^http/', $value['s_picurl']) ){
            if(strpos($value['s_picurl'], 'source/plugin/tom_') === FALSE){
                $s_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['s_picurl'];
            }else{
                $s_picurl = $value['s_picurl'];
            }
        }else{
            $s_picurl = $value['s_picurl'];
        }

        $weeksArr = $daysArr = array();
        if($value['type'] == 1){
            $weeksArr = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->fetch_all_list(" AND tequan_id = {$value['id']} ", " ORDER BY week ASC,id DESC ", 0, 10);
        }else if($value['type'] == 2){
            $daysArr = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->fetch_all_list(" AND tequan_id = {$value['id']} ", " ORDER BY day ASC,id DESC ", 0, 10);
        }

        $lingCount = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_ling')->fetch_all_count(" AND tequan_id = {$value['id']} ");

        $tequanList[$key] = $value;
        $tequanList[$key]['daysArr'] = $daysArr;
        $tequanList[$key]['weeksArr'] = $weeksArr;
        $tequanList[$key]['picurl'] = $s_picurl;
        $tequanList[$key]['lingCount'] = $lingCount;
        
    }
}

if(is_array($tequanList) && !empty($tequanList)){
    foreach ($tequanList as $key => $val){
        
        $outStr .= '<div class="tequan-item">';
            $outStr .= '<div class="tequan-item__hd  dislay-flex">';
                $outStr .= '<div class="item-hd__lt">';
                    $outStr .= '<a href="plugin.php?id=tom_tcyikatong&site='.$site_id.'&mod=info&tq_id='.$val['id'].'">';
                        $outStr .= '<img src="'.$val['picurl'].'">';
                    $outStr .= '</a>';
                $outStr .= '</div>';
                $outStr .= '<a class="item-hd__rt" href="plugin.php?id=tom_tcyikatong&site='.$site_id.'&mod=info&tq_id='.$val['id'].'">';
                    $outStr .= '<div class="item-rt__title">'.$val['s_name'].'</div>';
                    if($val['tequan_type'] == 2){
                        $outStr .= '<div class="item-rt__zhekou"><span>'.$val['tequan_shengprice'].'</span>'.lang('plugin/tom_tcyikatong','ajax_list_quan').'</div>';
                    }else{
                        $outStr .= '<div class="item-rt__zhekou"><span>'.$val['tequan_zhekou'].'</span>'.lang('plugin/tom_tcyikatong','ajax_list_zhekou').'</div>';
                    }
                    $outStr .= '<div class="item-rt__ka">'.$val['title'].'</div>';
                    if($val['type'] == 1 && !empty($val['weeksArr'])){
                        $outStr .= '<div class="item-rt__week"><span class="week">'.lang('plugin/tom_tcyikatong','ajax_list_weeks').'</span>';
                        foreach($val['weeksArr'] as $kw => $vw){
                            $outStr .= '<span class="weeks">'.$weeksDateArray[$vw['week']].'</span>';
                        }
                        $outStr .= '</div>';
                    }else if($val['type'] == 2 && !empty($val['daysArr'])){
                        $outStr .= '<div class="item-rt__month"><span class="month">'.lang('plugin/tom_tcyikatong','ajax_list_months').'</span>';
                        foreach($val['daysArr'] as $kd => $vd){
                            $outStr .= '<span class="months">'.$vd['day'].lang('plugin/tom_tcyikatong','ajax_list_day').'</span>';
                        }
                        $outStr .= '</div>';
                    }
                $outStr .= '</a>';
                $outStr .= '<a class="item-hd__tel" href="plugin.php?id=tom_tcyikatong&site='.$site_id.'&mod=info&tq_id='.$val['id'].'">';
                    $outStr .= '<span class="item-renqi"><em class="tciconfont tcicon-hot"></em>'.$val['s_clicks'].'</span>';
                    if($ordertype == 'lbs' && !empty($longitude) && !empty($latitude)){
                        $juli = tomGetDistance($longitude, $latitude, $val['s_longitude'], $val['s_latitude']);
                        $outStr .= '<span class="item-lbs">'.$juli.'km</span>';
                    }else{
                        $outStr .= '<span class="item-ling">'.$val['lingCount'].lang('plugin/tom_tcyikatong','ajax_list_ling').'</span>';
                    }
                    $outStr .= '<span class="item-btn">'.lang('plugin/tom_tcyikatong','ajax_list_btn').'</span>';
                $outStr .= '</a>';
            $outStr .= '</div>';
        $outStr .= '</div>';
    }

}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;