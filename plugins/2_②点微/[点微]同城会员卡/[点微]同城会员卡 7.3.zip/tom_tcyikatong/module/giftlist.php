<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):50;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND status=1 ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}

$orderStr = " ORDER BY paixu ASC,id DESC ";
$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
$giftListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_gift')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);
$giftList = array();
foreach ($giftListTmp as $key => $value) {
    $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
    if($tcshopInfoTmp && $tcshopInfoTmp['status']==1 && $tcshopInfoTmp['shenhe_status']==1 ){
        $typeNameArr = array();
        if(!empty($value['card_type_ids'])){
            $cardTypeIdsStr = str_replace('|', ',', $value['card_type_ids']);
            $typeListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_all_list(" AND id IN({$cardTypeIdsStr}) ", 'ORDER BY tsort ASC,id DESC', 0, 100);
            if(is_array($typeListTmp) && !empty($typeListTmp)){
                foreach($typeListTmp as $k => $v){
                    $typeNameArr[] = $v['name'];
                }
            }

        }else{
            $typeInfo = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($value['card_type_id']);
            $typeNameArr[] = $typeInfo['name'];
        }

        if(!preg_match('/^http/', $tcshopInfoTmp['picurl']) ){
            if(strpos($tcshopInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfoTmp['picurl'];
            }else{
                $picurl = $tcshopInfoTmp['picurl'];
            }
        }else{
            $picurl = $tcshopInfoTmp['picurl'];
        }

        $giftUsesInfo = array();
        if($__UserInfo['id'] > 0){
            $giftUsesInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND gift_id = {$value['id']} AND status = 0 ", 'ORDER BY id DESC', 0, 1);
            if(is_array($giftUsesInfoTmp) && !empty($giftUsesInfoTmp[0])){
                $giftUsesInfo = $giftUsesInfoTmp[0];
            }
        }
        
        $giftList[$key] = $value;
        $giftList[$key]['typeNameArr']          = $typeNameArr;
        $giftList[$key]['tcshopInfo']           = $tcshopInfoTmp;
        $giftList[$key]['tcshopInfo']['picurl'] = $picurl;
        $giftList[$key]['giftUsesInfo']         = $giftUsesInfo;
        $cardTypeInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($value['card_type_id']);
    }
}

if(is_array($giftList) && !empty($giftList)){
    foreach ($giftList as $key => $val){
        $djs = ($val['end_time'] - TIMESTAMP) * 1000;

        $giftUsesCount = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_count(" AND gift_id = {$val['id']} ");
        $syNum = $val['num'] - $giftUsesCount;
        if($syNum <= 0){
            $syNum = 0;
        }

        $outStr .= '<div class="card-item">';
            $outStr .= '<div class="card-item__hd  dislay-flex">';
                $outStr .= '<div class="item-hd__lt">';
                    $outStr .= '<a href="plugin.php?id=tom_tcyikatong&site='.$site_id.'&mod=gift&gift_id='.$val['id'].'">';
                        $outStr .= '<img src="'.$val['tcshopInfo']['picurl'].'">';
                    $outStr .= '</a>';
                $outStr .= '</div>';
                $outStr .= '<div class="item-hd__rt" >';
                    $outStr .= '<div class="item-rt__title"><a href="plugin.php?id=tom_tcyikatong&site='.$site_id.'&mod=gift&gift_id='.$val['id'].'" style="margin-left:0;">'.$val['title'].'</a></div>';
                    $outStr .= '<div class="item-rt__price">';
                        if(is_array($val['typeNameArr']) && !empty($val['typeNameArr'])){
                            $outStr .= '<a href="plugin.php?id=tom_tcyikatong&site='.$site_id.'&mod=gift&gift_id='.$val['id'].'">';
                            foreach($val['typeNameArr'] as $tv){
                                $outStr .= '<span class="type-item">'.$tv.'</span>';
                            }
                            $outStr .= '</a>';
                        }
                    $outStr .= '</div>';
                    $outStr .= '<div class="item-rt__desc"><a href="plugin.php?id=tom_tcyikatong&site='.$site_id.'&mod=gift&gift_id='.$val['id'].'">'.lang('plugin/tom_tcyikatong', 'ajax_list_card_price').'<span class="price">'.lang('plugin/tom_tcyikatong', 'yuan_ico').$val['price'].'</span></a></div>';
                $outStr .= '</div>';
                $outStr .= '<a class="item-hd__btn" href="plugin.php?id=tom_tcyikatong&site='.$site_id.'&mod=gift&gift_id='.$val['id'].'">';
                    $outStr .= '<span class="item-shengyu">'.lang('plugin/tom_tcyikatong', 'ajax_list_card_sy_1').$syNum.lang('plugin/tom_tcyikatong', 'ajax_list_card_sy_2').'</span>';
                    if(is_array($val['giftUsesInfo']) && !empty($val['giftUsesInfo'])){
                        $outStr .= '<span class="item-btn">'.lang('plugin/tom_tcyikatong', 'ajax_list_card_button_3').'</span>';
                    }else{
                        $outStr .= '<span class="item-btn">'.lang('plugin/tom_tcyikatong', 'ajax_list_card_button_1').'</span>';
                    }
                $outStr .= '</a>';
            $outStr .= '</div>';
        $outStr .= '</div>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;