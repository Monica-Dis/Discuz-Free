<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tcyikatong_tequan extends discuz_table{
	public function __construct() {
        parent::__construct(); /*DISM - TAOBAO - COM*/
		$this->_table = 'tom_tcyikatong_tequan';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}

    public function fetch_by_tcshop_id($tcshop_id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE tcshop_id=%d", array($this->_table, $tcshop_id));
	}
    
    public function fetch_left_shop_list($condition,$orders = '',$start = 0,$limit = 10,$keyword = '',$lat='',$lng='',$address='') {
        
        $searchWhere = '';
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $searchWhere .= " AND (t.title LIKE '%{$keyword}%')";
        }
        if(!empty($address)){
            $address = str_replace(array('%', '_'),'',$address);
            $searchWhere .= " AND (s.address LIKE '%{$address}%')";
        }
        
        $shopWhere = ",s.name as s_name,s.picurl as s_picurl,s.clicks as s_clicks,s.latitude as s_latitude,s.longitude as s_longitude";
        if(!empty($lat) && !empty($lng)){
            $data = DB::fetch_all("SELECT t.*{$shopWhere},acos(cos($lat*pi()/180 )*cos(s.latitude*pi()/180)*cos($lng*pi()/180 - s.longitude*pi()/180)+sin($lat*pi()/180 )*sin(s.latitude*pi()/180))*6370996.81/1000 as distance FROM ".DB::table($this->_table)." t LEFT JOIN ".DB::table("tom_tcshop")." s on s.id=t.tcshop_id WHERE 1 {$condition} {$searchWhere} ORDER BY distance ASC,t.id DESC LIMIT $start,$limit");
        }else{
            $data = DB::fetch_all("SELECT t.*{$shopWhere}  FROM ".DB::table($this->_table)." t LEFT JOIN ".DB::table("tom_tcshop")." s on s.id=t.tcshop_id WHERE 1 {$condition} {$searchWhere} $orders LIMIT $start,$limit");
        }
        
		return $data;
	}
    
    public function fetch_all_list($condition,$orders = '',$start = 0,$limit = 10,$keyword = '',$weeks = '',$days = '') {
        if(!empty($weeks) && !empty($days) && !empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i AND ((type=1 AND weeks LIKE %s) OR (type=2 AND days LIKE %s)) AND title LIKE %s $orders LIMIT $start,$limit",array($this->_table,$condition,'%-'.$weeks.'-%','%-'.$days.'-%','%'.$keyword.'%'));
        }else if(!empty($weeks) && !empty($days)){
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i AND ((type=1 AND weeks LIKE %s) OR (type=2 AND days LIKE %s)) $orders LIMIT $start,$limit",array($this->_table,$condition,'%-'.$weeks.'-%','%-'.$days.'-%'));
        }else if(!empty($weeks)){
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i AND weeks LIKE %s $orders LIMIT $start,$limit",array($this->_table,$condition,'%-'.$weeks.'-%'));
        }else if(!empty($days)){
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i AND days LIKE %s $orders LIMIT $start,$limit",array($this->_table,$condition,'%-'.$days.'-%'));
        }else if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i AND title LIKE %s $orders LIMIT $start,$limit",array($this->_table,$condition,'%'.$keyword.'%'));
        }else{
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        }
		return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition) {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
    
    public function fetch_all_weeks_days_count($condition,$weeks = '',$days = '') {
        $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i AND ((type=1 AND weeks LIKE %s) OR (type=2 AND days LIKE %s)) ", array($this->_table,$condition,'%-'.$weeks.'-%','%-'.$days.'-%'));
		return $return['num'];
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

}