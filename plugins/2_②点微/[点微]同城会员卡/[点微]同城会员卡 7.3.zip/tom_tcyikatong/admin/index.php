<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_tcyikatong_admin_index_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tcyikatong#tom_tcyikatong_card')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
        
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $cardInfo = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($cardInfo);
        C::t('#tom_tcyikatong#tom_tcyikatong_card')->update($cardInfo['id'],$updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($cardInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcyikatong#tom_tcyikatong_card')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'card_log'){
    
    $card_id = $_GET['card_id'];
    $cardInfo = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_id($card_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($cardInfo['user_id']);
    
    $pagesize = 50;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcyikatong#tom_tcyikatong_card_log')->fetch_all_count(" AND card_id={$card_id} ");
    $logList = C::t('#tom_tcyikatong#tom_tcyikatong_card_log')->fetch_all_list(" AND card_id={$card_id} ","ORDER BY id DESC",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl.'&act=card_log&card_id='.$card_id.'&formhash='.FORMHASH;
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition"><font color="#238206">'.$userInfo['nickname'].'</font>&nbsp;>&nbsp;' . $Lang['index_card_log'] .'</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['index_cardlog_card_type_name'] . '</th>';
    echo '<th>' . $Lang['index_cardlog_days'] . '</th>';
    echo '<th>' . $Lang['index_cardlog_code'] . '</th>';
    echo '<th>' . $Lang['index_cardlog_log_type'] . '</th>';
    echo '<th>' . $Lang['index_cardlog_add_time'] . '</th>';
    echo '</tr>';
    foreach ($logList as $key => $value) {
        
        echo '<tr>';
        echo '<th>' . $value['card_type_name'] . '</th>';
        echo '<th>' . $value['card_type_days'] . '</th>';
        if(!empty($value['code'])){
            echo '<th>' . $value['code'] . '</th>';
        }else{
            echo '<th> -- </th>';
        }
        if($value['log_type'] == 1){
            echo '<th>' . $Lang['index_cardlog_log_type_1'] . '</th>';
        }else if($value['log_type'] == 2){
            echo '<th>' . $Lang['index_cardlog_log_type_2'] . '</th>';
        }else{
            echo '<th> -- </th>';
        }
        echo '<th>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</th>';
        echo '</tr>';
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['act'] == 'tequan_uses'){
    
    $card_id = $_GET['card_id'];
    $cardInfo = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_id($card_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($cardInfo['user_id']);
    
    $pagesize = 50;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses')->fetch_all_count(" AND card_id={$card_id} ");
    $usesList = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses')->fetch_all_list(" AND card_id={$card_id} ","ORDER BY id ASC",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl.'&act=tequan_uses&card_id='.$card_id.'&formhash='.FORMHASH;
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition"><font color="#238206">'.$userInfo['nickname'].'</font>&nbsp;>&nbsp;' . $Lang['index_tequan_uses'] .'</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['tequan_uses_tequan_id'] . '</th>';
    echo '<th>' . $Lang['tequan_uses_hexiao_user_id'] . '</th>';
    echo '<th>' . $Lang['tequan_uses_num'] . '</th>';
    echo '<th>' . $Lang['tequan_uses_price'] . '</th>';
    echo '<th width="150px">' . $Lang['tequan_uses_beizu'] . '</th>';
    echo '<th>' . $Lang['tequan_uses_photo'] . '</th>';
    echo '<th>' . $Lang['tequan_uses_add_time'] . '</th>';
    echo '</tr>';
    foreach ($usesList as $key => $value) {
        
        $tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_id($value['tequan_id']);
        $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        $usesPhotoList = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses_photo')->fetch_all_list(" AND tequan_uses_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);

        echo '<tr>';
        echo '<th><font color="#0a9409">' . $tequanInfo['title'] .'(' .$tequanInfo['id']. ')</font></th>';
        echo '<th><font color="#0a9409">' . $hexiaoUserInfo['nickname'] .'(' .$hexiaoUserInfo['id']. ')</font></th>';
        echo '<th>' . $value['num'] . '</th>';
        echo '<th>' . $value['price'] . '</th>';
        echo '<th>' . $value['beizu'] . '</th>';
        if(is_array($usesPhotoList) && !empty($usesPhotoList)){
            echo '<th>';
            foreach($usesPhotoList as $key => $value){
                echo '<a href="'.tomgetfileurl($value['picurl']).'" target="_blank"><img style="width:40px;" src="'.tomgetfileurl($value['picurl']).'"></a> ';
            }
            echo '</th> ';
        }else{
            echo '<th> -- </th>';
        }
        echo '<th>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</th>';
        echo '</tr>';
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    set_list_url("tom_tcyikatong_admin_index_list");
    
    $card_no            = isset($_GET['card_no'])? addslashes($_GET['card_no']):'';
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($card_no)){
        $where.= " AND card_no={$card_no} ";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    if(!empty($status)){
        if($status == 1){
            $where.= " AND status=1 ";
        }else if($status == 2){
            $where.= " AND status=2 ";
        }else if($status == 3){
            $where.= " AND status=3 ";
        }
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_all_count($where);
    $cardList = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_all_list("{$where}"," ORDER BY id DESC ",$start,$pagesize);
    
    showtableheader();
    $Lang['index_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_1']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    $modBasePageUrl = $modBaseUrl."&status={$status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    $status_1 = $status_2 = '';
    if($status == 1){
        $status_1 = 'selected';
    }else if($status == 2){
        $status_2 = 'selected';
    }else if($status == 3){
        $status_3 = 'selected';
    }
    
    $userIdStr = '<td width="100" align="right"><b>'.$Lang['index_user_id'].'</b></td>';
    $userIdStr .= '<td><input type="text" name="user_id" value="'.$user_id.'"></td></tr>';
    echo $userIdStr;
    
    $cardNoStr = '<td width="100" align="right"><b>'.$Lang['index_card_no'].'</b></td>';
    $cardNoStr .= '<td><input type="text" name="card_no" value="'.$card_no.'"></td></tr>';
    echo $cardNoStr;
    
    $statusStr = '<td width="100" align="right"><b>'.$Lang['index_status'].'</b></td>';
    $statusStr .= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr .=  '<option value="0">'.$Lang['index_status_all'].'</option>';
    $statusStr .=  '<option value="1" '.$status_1.'>'.$Lang['index_status_1'].'</option>';
    $statusStr .=  '<option value="2" '.$status_2.'>'.$Lang['index_status_2'].'</option>';
    $statusStr .=  '<option value="3" '.$status_3.'>'.$Lang['index_status_3'].'</option>';
    $statusStr .= '</select></td></tr>';
    echo $statusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 100px;">' . $Lang['index_card_no'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['index_card_type'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['index_user_id'] . '</th>';
    echo '<th>' . $Lang['index_user_tel'] . '</th>';
    echo '<th style="width: ;">' . $Lang['index_expire_time'] . '</th>';
    echo '<th>' . $Lang['index_gift_status'] . '</th>';
    echo '<th>' . $Lang['index_status2'] . '</th>';
    echo '<th style="width: 300px;">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($cardList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $cardTypeInfo = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($value['card_type_id']);
        
        echo '<tr >';
        echo '<td>' . $value['card_no'] . '</td>';
        echo '<td>' . $cardTypeInfo['name'] . '</td>';
        echo '<td><font color="#0a9409">' . $userInfo['nickname'] .'(UID:' .$value['user_id'] . ')</font></td>';
        if(!empty($userInfo['tel'])){
            echo '<td>' . $userInfo['tel'] . '</td>';
        }else{
            echo '<td>-</td>';
        }
        echo '<td>' . dgmdate($value['expire_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        if($value['gift_status'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['index_gift_status_1'] . '</font></td>';
        }else{
            echo '<td><font color="#f00">' . $Lang['index_gift_status_0'] . '</font></td>';
        }
        if($value['status'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['index_status_1'] . '</font></td>';
        }else if($value['status'] == 2){
            echo '<td><font color="#f00">' . $Lang['index_status_2'] . '</font></td>';
        }else{
            echo '<td><font color="#f00">' . $Lang['index_status_3'] . '</font></td>';
        }

        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=card_log&card_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_card_log']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=tequan_uses&card_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_tequan_uses']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    global $Lang,$modListUrl;
    
    $data = array();
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $card_type_id       = isset($_GET['card_type_id'])? intval($_GET['card_type_id']):0;
    $expire_time        = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time        = strtotime($expire_time);
    $gift_status        = isset($_GET['gift_status'])? intval($_GET['gift_status']):0;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;

    if($_GET['act'] == 'add'){
        
        $cardUserInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($user_id);
        if($cardUserInfoTmp){
            cpmsg($Lang['act_success'], $modListUrl."&user_id=".$user_id, 'succeed');exit;
        }
        
        $auto_id = 0;
        $autoidTmp  = C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->fetch_all_list(""," ORDER BY id DESC ",0,1);
        if(is_array($autoidTmp) && !empty($autoidTmp) && !empty($autoidTmp[0]['id'])){
            if($autoidTmp[0]['id'] > 999990 && $autoidTmp[0]['id'] < 10101000 ){
                $insertData = array();
                $insertData['id']               = 10101011;
                $insertData['add_time']         = TIMESTAMP;
                if(C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert($insertData)){
                    $auto_id = C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert_id();
                }
            }else{
                $insertData = array();
                $insertData['add_time']         = TIMESTAMP;
                if(C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert($insertData)){
                    $auto_id = C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert_id();
                }
            }
        }else{
            $insertData = array();
            $insertData['id']               = 101011;
            $insertData['add_time']         = TIMESTAMP;
            if(C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert($insertData)){
                $auto_id = C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert_id();
            }
        }

        $card_no = '';
        $auto_id_str = strval($auto_id);
        if($auto_id > 10101000){
            $rand_num1 = mt_rand(1, 9);
            $card_no .= $auto_id_str[0].$auto_id_str[1].$rand_num1;
            $rand_num2 = mt_rand(1, 9);
            $card_no .= $auto_id_str[2].$auto_id_str[3].$rand_num2;
            $rand_num3 = mt_rand(1, 9);
            $card_no .= $auto_id_str[4].$auto_id_str[5].$rand_num3;
            $rand_num4 = mt_rand(1, 9);
            $card_no .= $auto_id_str[6].$auto_id_str[7].$rand_num4;
        }else{
            $rand_num1 = mt_rand(1, 9);
            $card_no .= $auto_id_str[0].$auto_id_str[1].$rand_num1;
            $rand_num2 = mt_rand(1, 9);
            $card_no .= $auto_id_str[2].$auto_id_str[3].$rand_num2;
            $rand_num3 = mt_rand(1, 9);
            $card_no .= $auto_id_str[4].$auto_id_str[5].$rand_num3;
        }
    }
    
    if($_GET['act'] == 'add'){
        $data['card_no']            = $card_no;
        $data['user_id']            = $user_id;
    }
    $data['card_type_id']       = $card_type_id;
    $data['expire_time']        = $expire_time;
    $data['gift_status']        = $gift_status;
    $data['status']             = $status;
    $data['add_time']           = TIMESTAMP;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'user_id'           => 0,
        'card_type_id'      => 0,
        'expire_time'       => time(),
        'gift_status'       => 0,
        'status'            => 0,
    );
    $options = array_merge($options, $infoArr);
    if($_GET['act'] == 'add'){
        tomshowsetting(true,array('title'=>$Lang['index_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['index_user_id_msg']),"input");
    }
    
    $cardTypeList = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_all_list(" ", 'ORDER BY tsort ASC,id DESC', 0, 100);
    $cardTypeStr = '<tr><td width="100" ><b>'.$Lang['index_card_type'].'</b></td></tr>';
    $cardTypeStr.= '<tr><td><select style="width: 260px;" name="card_type_id" id="card_type_id">';
    foreach($cardTypeList as $key => $value){
        if($options['card_type_id'] == $value['id']){
            $cardTypeStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cardTypeStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cardTypeStr.= '</select></td></tr>';
    echo $cardTypeStr;
    
    tomshowsetting(true,array('title'=>$Lang['index_expire_time'],'name'=>'expire_time','value'=>$options['expire_time'],'msg'=>$Lang['index_expire_time_msg']),"calendar");
    $gift_status_item = array(0=>$Lang['index_gift_status_0'],1=>$Lang['index_gift_status_1']);
    tomshowsetting(true,array('title'=>$Lang['index_gift_status'],'name'=>'gift_status','value'=>$options['gift_status'],'msg'=>$Lang['index_gift_status_msg'],'item'=>$gift_status_item),"radio");
    $open_status_item = array(0=>$Lang['index_status_3'],1=>$Lang['index_status_1'],2=>$Lang['index_status_2']);
    tomshowsetting(true,array('title'=>$Lang['index_status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['index_status_msg'],'item'=>$open_status_item),"radio");

    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['index_edit'],"",true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['index_open_card_title'],$adminBaseUrl.'&tmod=common',false);
        tomshownavli($Lang['index_info_use_title'],$adminBaseUrl.'&tmod=common',false);
    }
    tomshownavfooter();
}