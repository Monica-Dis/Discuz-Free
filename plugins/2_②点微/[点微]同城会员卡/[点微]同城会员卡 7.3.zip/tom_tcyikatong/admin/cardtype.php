<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=cardtype';
$modListUrl = $adminListUrl.'&tmod=cardtype';
$modFromUrl = $adminFromUrl.'&tmod=cardtype';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $typeInfo = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($typeInfo);
        C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->update($typeInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($typeInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'import' && $_GET['formhash'] == FORMHASH){
    
    $importArr = array(
        0 => array(
            'name'                  => $Lang['cardtype_import_name_1'],
            'price'                 => 2.00,
            'days'                  => 7,
            'content'               => $Lang['cardtype_import_msg_1'],
            'tsort'                 => 1,
        ),
        1 => array(
            'name'                  => $Lang['cardtype_import_name_2'],
            'price'                 => 5.00,
            'days'                  => 30,
            'content'               => $Lang['cardtype_import_msg_2'],
            'tsort'                 => 2,
        ),
        2 => array(
            'name'                  => $Lang['cardtype_import_name_3'],
            'price'                 => 28.00,
            'days'                  => 180,
            'content'               => $Lang['cardtype_import_msg_3'],
            'tsort'                 => 3,
        ),
        3 => array(
            'name'                  => $Lang['cardtype_import_name_4'],
            'price'                 => 50.00,
            'days'                  => 365,
            'content'               => $Lang['cardtype_import_msg_4'],
            'tsort'                 => 4,
        ),
    );
    
    foreach($importArr as $key => $value){
        $insertData = array();
        $insertData['name']       = $value['name'];
        $insertData['price']      = $value['price'];
        $insertData['days']       = $value['days'];
        $insertData['content']    = $value['content'];
        $insertData['tsort']      = $value['tsort'];
        $insertData['add_time']   = TIMESTAMP;
        C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->insert($insertData);
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{

    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=import&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['cardtype_import'].'</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/

    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $typeList = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_all_list(""," ORDER BY tsort ASC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['cardtype_tsort'] . '</th>';
    echo '<th>' . $Lang['cardtype_name'] . '</th>';
    echo '<th>' . $Lang['cardtype_picurl'] . '</th>';
    echo '<th>' . $Lang['cardtype_price'] . '</th>';
    echo '<th>' . $Lang['cardtype_days'] . '</th>';
    echo '<th>' . $Lang['cardtype_content'] . '</th>';
    echo '<th>' . $Lang['cardtype_max_num'] . '</th>';
    echo '<th>' . $Lang['cardtype_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($typeList as $key => $value) {
        
        if(!preg_match('/^http/', $value['picurl']) ){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $picurl = $value['picurl'];
        }
        
        echo '<tr>';
        echo '<td>' . $value['tsort'] . '</td>';
        echo '<td>' . $value['name'] . '</td>';
        
        if(!empty($value['picurl'])){
            echo '<td><img src="'.$picurl.'" width="40" /></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        echo '<td>' . $value['price'] . '</td>';
        echo '<td>' . $value['days'] . '</td>';
        echo '<td width="160px">' . $value['content'] . '</td>';
        if($value['max_num'] > 0){
            echo '<td>' . $value['max_num'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">    
function import_confirm(url){
  var r = confirm("{$Lang['cardtype_import_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}

function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $max_num        = isset($_GET['max_num'])? intval($_GET['max_num']):0;
    $price          = isset($_GET['price'])? floatval($_GET['price']):0.00;
    $days           = isset($_GET['days'])? intval($_GET['days']):0;
    $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
    $tsort          = isset($_GET['tsort'])? intval($_GET['tsort']):10;
    
    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    $data['name']               = $name;
    $data['picurl']             = $picurl;
    $data['max_num']            = $max_num;
    $data['price']              = $price;
    $data['days']               = $days;
    $data['content']            = $content;
    $data['tsort']              = $tsort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'           => '',
        'picurl'         => '',
        'price'          => 0.00,
        'days'           => 0,
        'max_num'        => 0,
        'content'        => '',
        'tsort'          => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['cardtype_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['cardtype_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['cardtype_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['cardtype_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['cardtype_max_num'],'name'=>'max_num','value'=>$options['max_num'],'msg'=>$Lang['cardtype_max_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['cardtype_price'],'name'=>'price','value'=>$options['price'],'msg'=>$Lang['cardtype_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['cardtype_days'],'name'=>'days','value'=>$options['days'],'msg'=>$Lang['cardtype_days_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['cardtype_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['cardtype_content_msg']),"textarea");
    tomshowsetting(true,array('title'=>$Lang['cardtype_tsort'],'name'=>'tsort','value'=>$options['tsort'],'msg'=>$Lang['cardtype_tsort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['cardtype_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['cardtype_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['cardtype_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['cardtype_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['cardtype_edit'],"",true);
    }else{
        tomshownavli($Lang['cardtype_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['cardtype_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['cardcode_list_title'],$adminBaseUrl."&tmod=cardcode",false);
    }
    tomshownavfooter();
}