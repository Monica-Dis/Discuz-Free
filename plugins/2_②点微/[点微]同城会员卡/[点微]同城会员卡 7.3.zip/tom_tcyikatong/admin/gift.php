<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=gift';
$modListUrl = $adminListUrl.'&tmod=gift';
$modFromUrl = $adminFromUrl.'&tmod=gift';

$get_list_url_value = get_list_url("tom_tcyikatong_admin_gift_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcyikatong#tom_tcyikatong_gift')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
        
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $giftInfo = C::t('#tom_tcyikatong#tom_tcyikatong_gift')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($giftInfo);
        C::t('#tom_tcyikatong#tom_tcyikatong_gift')->update($giftInfo['id'],$updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($giftInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tcyikatong#tom_tcyikatong_gift')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status']     = 0;
    C::t('#tom_tcyikatong#tom_tcyikatong_gift')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcyikatong#tom_tcyikatong_gift')->delete_by_id($_GET['id']);
    C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->delete_by_gift_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'uses_list'){
    
    $gift_id = $_GET['gift_id'];
    $giftInfo = C::t('#tom_tcyikatong#tom_tcyikatong_gift')->fetch_by_id($gift_id);
    
    $pagesize = 15;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_count(" AND gift_id={$gift_id} ");
    $usesList = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_list(" AND gift_id={$gift_id} ","ORDER BY id ASC",$start,$pagesize);

    showformheader($modFromUrl.'&act=edit_date&tequan_id='.$tequan_id,'enctype');
    showtableheader();
    echo '<tr><th colspan="15" class="partition"><font color="#238206">'.$giftInfo['title'].'</font>&nbsp;>&nbsp;' . $Lang['gift_uses_list'] .'</th></tr>';
    
    $modBasePageUrl = $adminBaseUrl.'&tmod=gift&act=uses_list&gift_id='.$gift_id.'&formhash='.FORMHASH;
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['gift_uses_user'] . '</th>';
    echo '<th>' . $Lang['gift_uses_card_id'] . '</th>';
    echo '<th>' . $Lang['gift_uses_hexiao_user'] . '</th>';
    echo '<th width="160px">' . $Lang['gift_uses_beizu'] . '</th>';
    echo '<th>' . $Lang['gift_uses_status'] . '</th>';
    echo '<th>' . $Lang['gift_uses_time'] . '</th>';
    echo '<th>' . $Lang['gift_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($usesList as $key => $value) {
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_id($value['card_id']);
        $hexiaoUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        
        echo '<tr>';
        echo '<th><font color="#0a9409">' . $userInfoTmp['nickname'] .'('.$value['user_id']. ')</font></th>';
        echo '<td> '.$cardInfoTmp['card_no'].' </td>';
        if($value['hexiao_user_id'] > 0){
            echo '<th><font color="#0a9409">' . $hexiaoUserInfoTmp['nickname'] .'('.$value['hexiao_user_id']. ')</font></th>';
        }else{
            echo '<td> -- </td>';
        }
        if(!empty($value['beizu'])){
            echo '<td> '.$value['beizu'].' </td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['status'] == 1){
            echo '<td><font color="#0a9409"> '.$Lang['gift_uses_status_1'].' </font></td>';
        }else{
            echo '<td><font color="#f00"> '.$Lang['gift_uses_status_0'].' </font></td>';
        }
        echo '<th>' . dgmdate($value['use_time'],"Y-m-d H:i:s",$tomSysOffset) . '</th>';
        echo '<th>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</th>';
        echo '<td> -- </td>';
        echo '</tr>';
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    set_list_url("tom_tcyikatong_admin_gift_list");
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ list-style-type: none; height: 25px; line-height: 25px;margin-bottom: 2px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;padding: 3px 10px;color: #6a6d6a; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
</style>
EOF;
    echo $csstr;
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($status)){
        if($status == 1){
            $where.= " AND status=1 ";
        }else if($status == 2){
            $where.= " AND status=0 ";
        }
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $giftList = C::t('#tom_tcyikatong#tom_tcyikatong_gift')->fetch_all_list("{$where}"," ORDER BY id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&status={$status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $status_1 = $status_2 = '';
    if($status == 1){
        $status_1 = 'selected';
    }else if($status == 2){
        $status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['shop_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['shop_status_all'].'</option>';
    $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['shop_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['shop_status_0'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 60px;">' . $Lang['sites_title'] . '</th>';
    //echo '<th>' . $Lang['gift_picurl'] . '</th>';
    echo '<th>' . $Lang['gift_card_type_id'] . '</th>';
    echo '<th>' . $Lang['gift_info'] . '</th>';
    echo '<th>' . $Lang['gift_status'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($giftList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        
        $typeNameStr = '';
        if(!empty($value['card_type_ids'])){
            $cardTypeIdsStr = str_replace('|', ',', $value['card_type_ids']);
            $typeListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_all_list(" AND id IN({$cardTypeIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            $typeNameArr = array();
            if(is_array($typeListTmp) && !empty($typeListTmp)){
                foreach($typeListTmp as $k => $v){
                    $typeNameArr[] = $v['name'];
                }
                $typeNameStr = implode('<br/>', $typeNameArr);
            }
            
        }else{
            $typeInfo = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($value['card_type_id']);
            $typeNameStr = $typeInfo['name'];
        }
        
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        //echo '<td><img src="'.tomgetfileurl($value['picurl']).'" width="40" /></td>';
        
        if(!empty($typeNameStr)){
            echo '<td><font color="#0a9409">' . $typeNameStr . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['gift_tcshop'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $tcshopInfo['name'] .'</font></li>';
        echo '<li><b>'.$Lang['gift_tcshop_id'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $tcshopInfo['id'] .'</font></li>';
        echo '<li><b>'.$Lang['gift_title'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $value['title'] . '</font></li>';
        echo '</ul></div></td>';
        
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['shop_paixu'].'&nbsp;:&nbsp;</b><font color="#f70404">' .$value['paixu']. '</font></li>';
        echo '<li><b>'.$Lang['gift_num'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $value['num'] .'</font></li>';
        echo '<li><b>'.$Lang['gift_price'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $value['price'] .'</font></li>';
        if($value['status'] == 1){
            echo '<li><b>'.$Lang['gift_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['gift_status_1'] . '</font></li>';
        }else{
            echo '<li><b>'.$Lang['gift_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['gift_status_0'] . '</font></li>';
        }
        echo '<li><b>'.$Lang['shop_add_time'].'&nbsp;:&nbsp;</b><font color="#f70404">' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</font></li>';
        echo '<li><b>'.$Lang['gift_end_time'].'&nbsp;:&nbsp;</b><font color="#f70404">' . dgmdate($value['end_time'],"Y-m-d H:i:s",$tomSysOffset) . '</font></li>';
        echo '</ul></div></td>';

        echo '<td><div class="tc_content_box_handle"><ul>';
        if($value['status'] == 1 ){
            echo '<li><a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['gift_status_0']. '</a></li>';
        }else{
            echo '<li><a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['gift_status_1']. '</a></li>';
        }
        echo '<li><a href="'.$modBaseUrl.'&act=uses_list&gift_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['gift_uses_list']. '</a></li>';
        echo '<li><a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a></li>';
        echo '<li><a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a></li>';
        echo '</ul></div></td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $num                = isset($_GET['num'])? intval($_GET['num']):0;
    $price              = isset($_GET['price'])? floatval($_GET['price']):0.00;
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = strtotime($end_time);
    //$guize              = isset($_GET['guize'])? addslashes($_GET['guize']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $paixu                  = intval($_GET['paixu'])>0 ? intval($_GET['paixu']):100;
    
    $cardTypeIdsArr = array();
    if(is_array($_GET['card_type_ids_arr']) && !empty($_GET['card_type_ids_arr'])){
        foreach($_GET['card_type_ids_arr'] as $key => $value){
            $cardTypeIdsArr[] = intval($value);
        }
    }

    $card_type_ids = implode('|', $cardTypeIdsArr);
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl         = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    $data['site_id']            = $tcshopInfo['site_id'];
    $data['card_type_ids']      = $card_type_ids;
    $data['tcshop_id']          = $tcshop_id;
    $data['user_id']            = $tcshopInfo['user_id'];
    $data['title']              = $title;
    $data['picurl']             = $picurl;
    $data['num']                = $num;
    $data['price']              = $price;
    $data['end_time']           = $end_time;
    //$data['guize']              = $guize;
    $data['content']            = $content;
    $data['paixu']              = $paixu;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'card_type_id'      => 0,
        'card_type_ids'     => '',
        'tcshop_id'         => 0,
        'title'             => '',
        'picurl'            => '',
        'num'               => 0,
        'price'             => 0.00,
        'end_time'          => time(),
        'guize'             => '',
        'content'           => '',
        'paixu'             => 100,
    );
    $options = array_merge($options, $infoArr);
    
    $cardTypeIdsArr = array();
    if(!empty($options['card_type_ids'])){
        $cardTypeIdsArr = explode('|', $options['card_type_ids']);
    }else{
        $cardTypeIdsArr[] = $options['card_type_id'];
    }

    $cardTypeList = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_all_list(""," ORDER BY tsort ASC,id DESC ",0,100);
    $cardTypeStr = '<tr class="header"><th>'.$Lang['gift_card_type_id'].'</th><th></th></tr>';
    $cardTypeStr.= '<tr><td >';
    foreach ($cardTypeList as $key => $value){
        if(in_array($value['id'], $cardTypeIdsArr)){
            $cardTypeStr.=  '<label><input type="checkbox" name="card_type_ids_arr[]" value="'.$value['id'].'" checked>'.$value['name'].'</label>&nbsp;&nbsp;';
        }else{
            $cardTypeStr.=  '<label><input type="checkbox" name="card_type_ids_arr[]" value="'.$value['id'].'">'.$value['name'].'</label>&nbsp;&nbsp;';
        }
    }
    $cardTypeStr.= '</td><td>'.$Lang['gift_card_type_id_msg'].'</td></tr>';
    echo $cardTypeStr;
    
    tomshowsetting(true,array('title'=>$Lang['gift_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['gift_tcshop_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['gift_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['gift_title_msg']),"input");
    //tomshowsetting(true,array('title'=>$Lang['gift_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['gift_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['gift_num'],'name'=>'num','value'=>$options['num'],'msg'=>$Lang['gift_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['gift_price'],'name'=>'price','value'=>$options['price'],'msg'=>$Lang['gift_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['gift_end_time'],'name'=>'end_time','value'=>$options['end_time'],'msg'=>$Lang['gift_end_time_msg']),"calendar");
    //tomshowsetting(true,array('title'=>$Lang['gift_guize'],'name'=>'guize','value'=>$options['guize'],'msg'=>$Lang['gift_guize_msg']),"text");
    tomshowsetting(true,array('title'=>$Lang['shop_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['shop_paixu_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['gift_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['gift_content_msg']),"text");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['gift_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['gift_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['gift_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['gift_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['gift_edit'],"",true);
    }else{
        tomshownavli($Lang['gift_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['gift_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}