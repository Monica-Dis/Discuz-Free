<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=carduses';
$modListUrl = $adminListUrl.'&tmod=carduses';
$modFromUrl = $adminFromUrl.'&tmod=carduses';

$get_list_url_value = get_list_url("tom_tcyikatong_admin_carduses_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    
}else if($_GET['act'] == 'edit'){
    
}else{
    
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $site_id    = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $tcshop_id  = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $user_id    = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($tcshop_id)){
        $tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_tcshop_id($tcshop_id);
        $tequan_id = intval($tequanInfo['id']);
        $where.= " AND tequan_id={$tequan_id} ";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses')->fetch_all_count($where);
    $usesList = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&act=tequan_uses&site_id={$site_id}&tequan_id={$tequan_id}&user_id={$user_id}&formhash=".FORMHASH;
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $userIdStr = '<td width="100" align="right"><b>'.$Lang['index_user_id'].'</b></td>';
    $userIdStr .= '<td><input type="text" name="user_id" value="'.$user_id.'"></td></tr>';
    echo $userIdStr;
    
    $tcshopStr = '<td width="100" align="right"><b>'.$Lang['index_tcshop_id'].'</b></td>';
    $tcshopStr .= '<td><input type="text" name="tcshop_id" value="'.$tcshop_id.'"></td></tr>';
    echo $tcshopStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_tequan_uses'] .'</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['tequan_uses_tequan_id'] . '</th>';
    echo '<th>' . $Lang['index_user_id'] . '</th>';
    echo '<th>' . $Lang['tequan_uses_hexiao_user_id'] . '</th>';
    echo '<th>' . $Lang['tequan_uses_num'] . '</th>';
    echo '<th>' . $Lang['tequan_uses_price'] . '</th>';
    echo '<th width="150px">' . $Lang['tequan_uses_beizu'] . '</th>';
    echo '<th>' . $Lang['tequan_uses_photo'] . '</th>';
    echo '<th>' . $Lang['tequan_uses_add_time'] . '</th>';
    echo '</tr>';
    foreach ($usesList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_id($value['tequan_id']);
        $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        $usesPhotoList = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses_photo')->fetch_all_list(" AND tequan_uses_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);

        echo '<tr>';
        echo '<th><font color="#0a9409">' . $tequanInfo['title'] .'</font></th>';
        echo '<th><font color="#0a9409">' . $userInfo['nickname'] .'(UID:' .$userInfo['id']. ')</font></th>';
        echo '<th><font color="#0a9409">' . $hexiaoUserInfo['nickname'] .'(UID:' .$hexiaoUserInfo['id']. ')</font></th>';
        echo '<th>' . $value['num'] . '</th>';
        echo '<th>' . $value['price'] . '</th>';
        echo '<th>' . $value['beizu'] . '</th>';
        if(is_array($usesPhotoList) && !empty($usesPhotoList)){
            echo '<th>';
            foreach($usesPhotoList as $key => $value){
                echo '<a href="'.tomgetfileurl($value['picurl']).'" target="_blank"><img style="width:40px;" src="'.tomgetfileurl($value['picurl']).'"></a> ';
            }
            echo '</th> ';
        }else{
            echo '<th> -- </th>';
        }
        echo '<th>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</th>';
        echo '</tr>';
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
}