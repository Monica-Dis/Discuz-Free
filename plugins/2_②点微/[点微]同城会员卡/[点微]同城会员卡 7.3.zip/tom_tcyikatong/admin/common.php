<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=common'; 
$modListUrl = $adminListUrl.'&tmod=common';
$modFromUrl = $adminFromUrl.'&tmod=common';

$commonInfo = C::t('#tom_tcyikatong#tom_tcyikatong_common')->fetch_by_id(1);
if(!$commonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcyikatong#tom_tcyikatong_common')->insert($insertData);
}
if(submitcheck('submit')){
    $updateData = array();
    $updateData = __get_post_data($commonInfo);
    C::t('#tom_tcyikatong#tom_tcyikatong_common')->update(1,$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    tomloadcalendarjs();
    loadeditorjs();
    __create_nav_html();
    showformheader($modFromUrl,'enctype');
    showtableheader();
    __create_info_html($commonInfo);
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $ruzhu_xieyi_txt    = isset($_GET['ruzhu_xieyi_txt'])? addslashes($_GET['ruzhu_xieyi_txt']):'';
    $open_card_txt      = isset($_GET['open_card_txt'])? addslashes($_GET['open_card_txt']):'';
    $info_use_txt       = isset($_GET['info_use_txt'])? addslashes($_GET['info_use_txt']):'';

    //$data['ruzhu_xieyi_txt']    = $ruzhu_xieyi_txt;
    $data['open_card_txt']      = $open_card_txt;
    $data['info_use_txt']       = $info_use_txt;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'ruzhu_xieyi_txt'       => '',
        'open_card_txt'         => '',
        'info_use_txt'          => '',
    );
    $options = array_merge($options, $infoArr);
    
    //tomshowsetting(true,array('title'=>$Lang['common_ruzhu_xieyi_title'],'name'=>'ruzhu_xieyi_txt','value'=>$options['ruzhu_xieyi_txt'],'msg'=>$Lang['common_ruzhu_xieyi_title_msg']),"text");
    tomshowsetting(true,array('title'=>$Lang['common_open_card_title'],'name'=>'open_card_txt','value'=>$options['open_card_txt'],'msg'=>$Lang['common_open_card_title_msg']),"text");
    tomshowsetting(true,array('title'=>$Lang['common_info_use_title'],'name'=>'info_use_txt','value'=>$options['info_use_txt'],'msg'=>$Lang['common_info_use_title_msg']),"text");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    tomshownavli($Lang['common_title'],"",true);
    tomshownavfooter();
}