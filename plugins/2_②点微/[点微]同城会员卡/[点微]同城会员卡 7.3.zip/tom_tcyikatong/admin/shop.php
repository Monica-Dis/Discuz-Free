<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=shop';
$modListUrl = $adminListUrl.'&tmod=shop';
$modFromUrl = $adminFromUrl.'&tmod=shop';

$get_list_url_value = get_list_url("tom_tcyikatong_admin_shop_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
        
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($tequanInfo);
        C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->update($tequanInfo['id'],$updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($tequanInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status']     = 1;
    C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->update($_GET['id'],$updateData);
    
    $tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tequanInfo['user_id']);

    $shenhe = str_replace('{TITLE}', $tequanInfo['title'], $Lang['template_tcyikatong_shenhe_ok']);

    $cpmsg = $Lang['act_success'];
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyikatong&site={$tequanInfo['site_id']}&mod=info&tequan_id=".$tequanInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcyikatongConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['tcyikatong_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['tcyikatong_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcyikatongConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tequanInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->update($_GET['id'],$updateData);
        
        $shenhe = str_replace('{TITLE}', $tequanInfo['title'], $Lang['template_tcyikatong_shenhe_no']);
        
        $cpmsg = $Lang['act_success'];
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyikatong&site={$tequanInfo['site_id']}&mod=edit&tequan_id=".$tequanInfo['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcyikatongConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tcyikatong_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tcyikatong_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcyikatongConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tcyikatong_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tcyikatong_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcyikatong_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status']     = 0;
    C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->delete_by_id($_GET['id']);
    C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->delete_by_tequan_id($_GET['id']);
    C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->delete_by_tequan_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'edit_date'){
    
    $tequan_id = $_GET['tequan_id'];
    $tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_id($tequan_id);
    
    if(submitcheck('submit')){
        
        $type = isset($_GET['type'])? intval($_GET['type']):1;
        
        $weeksArr = $daysArr = array();
        if($type == 1){
            if(is_array($_GET['weeks']) && !empty($_GET['weeks'])){
                foreach($_GET['weeks'] as $key => $value){
                    $weeksArr[] = intval($value);
                }
            }
            $weeks = '-'.implode('-', $weeksArr).'-';
        }else{
            if(is_array($_GET['days']) && !empty($_GET['days'])){
                foreach($_GET['days'] as $key => $value){
                    $daysArr[] = intval($value);
                }
            }
            $days = '-'.implode('-', $daysArr).'-';
        }
        
        $updateData = array();
        $updateData['type']     = $type;
        $updateData['weeks']    = $weeks;
        $updateData['days']     = $days;
        if(C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->update($tequan_id, $updateData)){
            C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->delete_by_tequan_id($tequan_id);
            C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->delete_by_tequan_id($tequan_id);

            if(is_array($weeksArr) && !empty($weeksArr)){
                foreach ($weeksArr as $key => $value){
                    $insertData = array();
                    $insertData['tequan_id'] = $tequan_id;
                    $insertData['site_id']   = $tcshopInfo['site_id'];
                    $insertData['week']      = $value;
                    $insertData['add_time']  = TIMESTAMP;
                    C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->insert($insertData);
                }
            }

            if(is_array($daysArr) && !empty($daysArr)){
                foreach ($daysArr as $key => $value){
                    $insertData = array();
                    $insertData['tequan_id'] = $tequan_id;
                    $insertData['site_id']   = $tcshopInfo['site_id'];
                    $insertData['day']       = $value;
                    $insertData['add_time']  = TIMESTAMP;
                    C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->insert($insertData);
                }
            }
        }
        
        cpmsg($Lang['act_success'], $adminListUrl."&tmod=shop&act=edit_date&tequan_id=".$tequan_id, 'succeed');
        
    }
    
    $tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_id($tequan_id);
    $pagesize = 15;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;
    
    $type_1 = $type_2 = '';
    if($tequanInfo['type'] == 1){
        $type_1 = 'selected';
        $count = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->fetch_all_count(" AND tequan_id={$tequan_id} ");
        $weeksList = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->fetch_all_list(" AND tequan_id={$tequan_id} ","ORDER BY week ASC,id ASC",$start,$pagesize);
    }else{
        $type_2 = 'selected';
        $count = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->fetch_all_count(" AND tequan_id={$tequan_id} ");
        $daysList = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->fetch_all_list(" AND tequan_id={$tequan_id} ","ORDER BY day ASC,id ASC",$start,$pagesize);
    }
    showformheader($modFromUrl.'&act=edit_date&tequan_id='.$tequan_id,'enctype');
    showtableheader();
    echo '<tr><th colspan="15" class="partition"><font color="#238206">'.$tequanInfo['title'].'</font>&nbsp;>&nbsp;' . $Lang['shop_edit_date'] .'</th></tr>';
    
    
    $typeStr = '<tr class="header"><th>'.$Lang['shop_tequan_type'].'</th><th></th></tr>';
    $typeStr.= '<tr><td width="300"><select id="type" name="type" onChange="typeShow()">';
    $typeStr.= '<option value="1" '.$type_1.'>'.$Lang['shop_tequan_type_1'].'</option>';
    $typeStr.= '<option value="2" '.$type_2.'>'.$Lang['shop_tequan_type_2'].'</option>';
    $typeStr.= '<selected></td><td></td></tr>';
    echo $typeStr;
    
    $weeksStr = '<tr class="header weeks"><th>'.$Lang['shop_tequan_date'].'</th><th></th></tr>';
    $weeksStr.= '<tr class="weeks"><td width="300">';
    foreach($weeksDateArray as $key => $value){
        $weeksInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->fetch_all_list(" AND tequan_id={$tequan_id} AND week = {$key} ","ORDER BY week ASC,id ASC",$start,$pagesize);
        if(is_array($weeksInfoTmp) && !empty($weeksInfoTmp[0])){
            $weeksStr.=  '<label><input type="checkbox" value="'.$key.'" name="weeks[]" checked>'.$value.'</label>';
        }else{
            $weeksStr.=  '<label><input type="checkbox" value="'.$key.'" name="weeks[]">'.$value.'</label>';
        }
    }
    $weeksStr.= '</td><td></td></tr>';
    echo $weeksStr;
    
    $daysStr = '<tr class="header days"><th>'.$Lang['shop_tequan_date'].'</th><th></th></tr>';
    $daysStr.= '<tr class="days"><td width="300">';
    for($i=1; $i<=31; $i++){
        $daysInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->fetch_all_list(" AND tequan_id={$tequan_id} AND day = {$i} ","ORDER BY day ASC,id ASC",$start,$pagesize);
        if(is_array($daysInfoTmp) && !empty($daysInfoTmp[0])){
            $daysStr.=  '<label><input type="checkbox" value="'.$i.'" name="days[]" checked>'.$i.'</label>';
        }else{
            $daysStr.=  '<label><input type="checkbox" value="'.$i.'" name="days[]">'.$i.'</label>';
        }
    }
    $daysStr.= '</td><td></td></tr>';
    echo $daysStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    $jsstr = <<<EOF
<script type="text/javascript">
var type = "{$tequanInfo['type']}";
type = type * 1;

jq(document).ready(function(){
    if(type == 1){
        jq('.days').hide();
    }else{
        jq('.weeks').hide();
    }
})
            
function typeShow(){
    var type_id = jq('#type').val();
    if(type_id == 1){
        jq('.days').hide();
        jq('.weeks').show();
    }else{
        jq('.weeks').hide();
        jq('.days').show();
    }
}
</script>
EOF;
    echo $jsstr;
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'deldate'){
    
    C::t('#tom_tcyikatong#tom_tcyikatong_tequan_date')->delete_by_id($_GET['id']);
    
    $tequan_id = $_GET['tequan_id'];
    $tequanDateList = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_date')->fetch_all_list("AND tequan_id = {$tequan_id} ", 'ORDER BY id DESC', 0, 50);
    $datesArr = array();
    if(is_array($tequanDateList) && !empty($tequanDateList)){
        foreach($tequanDateList as $key => $value){
            $datesArr[] = $value['week'];
        }
    }
    
    $dates = '';
    if(is_array($datesArr) && !empty($datesArr)){
        $dates = implode('|', $datesArr);
    }
    $updateData = array();
    $updateData['dates'] = $dates;
    C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->update($tequan_id, $updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_tcyikatong_admin_shop_list");
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ list-style-type: none; height: 25px; line-height: 25px; margin-bottom: 2px;}
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;padding: 3px 10px;color: #6a6d6a; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
.span_model{color: #F75000 !important;border: 1px solid #F75000; height: 25px; width: 100px; line-height: 25px; text-align: center; color: #FFF; display: block; margin-bottom: 5px;}
.span_type{color: #0080FF !important;border: 1px solid #0080FF; height: 25px; width: 100px; line-height: 25px; text-align: center; color: #FFF;  display: block;margin-bottom: 5px;}
.span_cate{color: #009500 !important;border: 1px solid #009500; height: 25px; width: 100px; line-height: 25px; text-align: center; color: #FFF;  display: block;margin-bottom: 5px;}
</style>
EOF;
    echo $csstr;
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $tequan_id          = isset($_GET['tequan_id'])? intval($_GET['tequan_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($tequan_id)){
        $where.= " AND id={$tequan_id} ";
    }
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($status)){
        if($status == 1){
            $where.= " AND status=1 ";
        }else if($status == 2){
            $where.= " AND status=0 ";
        }
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    
    $pagesize = 20;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_all_count($where);
    $tequanList = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_all_list("{$where}"," ORDER BY id DESC ",$start,$pagesize,$title);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&status={$status}&shenhe_status={$shenhe_status}&title={$title}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_search_title'] . '</th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $titleStr = '<td width="100" align="right"><b>'.$Lang['shop_title'].'</b></td>';
    $titleStr .= '<td><input type="text" name="title" value="'.$title.'"></td></tr>';
    echo $titleStr;
    
    $status_1 = $status_2 = '';
    if($status == 1){
        $status_1 = 'selected';
    }else if($status == 2){
        $status_2 = 'selected';
    }
    $statusStr = '<td width="100" align="right"><b>'.$Lang['shop_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['shop_status_all'].'</option>';
    $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['shop_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['shop_status_0'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    $status_shenhe_1 = $status_shenhe_2 = $status_shenhe_3 = '';
    if($shenhe_status == 1){
        $status_shenhe_1 = 'selected';
    }else if($shenhe_status == 2){
        $status_shenhe_2 = 'selected';
    }else if($shenhe_status == 3){
        $status_shenhe_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['shop_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['shop_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$status_shenhe_1.'>'.$Lang['shop_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$status_shenhe_2.'>'.$Lang['shop_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$status_shenhe_3.'>'.$Lang['shop_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 60px;">' . $Lang['sites_title'] . '</th>';
    //echo '<th>' . $Lang['shop_picurl'] . '</th>';
    echo '<th>' . $Lang['shop_tcshop_cate_id'] . '</th>';
    echo '<th>' . $Lang['shop_tcshop_info'] . '</th>';
    echo '<th>' . $Lang['shop_tequan_info'] . '</th>';
    echo '<th>' . $Lang['shop_status'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tequanList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $cateInfoTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($value['tcshop_cate_id']);
        $cateChildInfoTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($value['tcshop_cate_child_id']);
        
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        //echo '<td><img src="'.tomgetfileurl($value['picurl']).'" width="40" /></td>';
        
        echo '<td>';
        if($cateInfoTmp){
            echo '<span class="span_model">' . $cateInfoTmp['name'] . '</span>';
        }
        if($cateChildInfoTmp){
            echo '<span class="span_type">' . $cateChildInfoTmp['name'] . '</span>';
        }
        echo '</td>';
        
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['shop_tcshop'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $tcshopInfo['name'] .'</font></li>';
        echo '<li><b>'.$Lang['shop_tcshop_id'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $tcshopInfo['id'] .'</font></li>';
        echo '</ul></div></td>';
        
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li>'.$Lang['shop_title'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $value['title'] . '</font></li>';
        if($value['tequan_type'] == 1){
            echo '<li>'.$Lang['shop_tequan_tequan_type'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $Lang['shop_tequan_tequan_tequan_type_1'] . '</font></li>';
            echo '<li>'.$Lang['shop_tequan_zhekou'].'&nbsp;:&nbsp;<font color="#0a9409">' . $value['tequan_zhekou'] . '</font></li>';
            if($value['open_putong_zhekou'] == 1){
                echo '<li>'.$Lang['shop_putong_zhekou'].'&nbsp;:&nbsp;<font color="#0a9409">' . $value['putong_zhekou'] . '</font></li>';
            }
        }else{
            echo '<li>'.$Lang['shop_tequan_tequan_type'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $Lang['shop_tequan_tequan_tequan_type_2'] . '</font></li>';
            echo '<li>'.$Lang['shop_tequan_tequan_shengprice'].'&nbsp;:&nbsp;<font color="#0a9409">' . $value['tequan_shengprice'] . '</font></li>';
            echo '<li>'.$Lang['shop_tequan_tequan_shenglimit'].'&nbsp;:&nbsp;<font color="#0a9409">' . $value['tequan_shenglimit'] . '</font></li>';
            if($value['open_putong_zhekou'] == 1){
                echo '<li>'.$Lang['shop_tequan_putong_shengprice'].'&nbsp;:&nbsp;<font color="#0a9409">' . $value['putong_shengprice'] . '</font></li>';
                echo '<li>'.$Lang['shop_tequan_putong_shenglimit'].'&nbsp;:&nbsp;<font color="#0a9409">' . $value['putong_shenglimit'] . '</font></li>';
            }
        }
        
        echo '</ul></div></td>';
        
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['shop_paixu'].'&nbsp;:&nbsp;</b><font color="#f70404">' .$value['paixu']. '</font></li>';
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shop_shenhe_btn_2']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shop_shenhe_btn_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<li><b>'.$Lang['shop_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['shop_shenhe_status_1'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 2){
            echo '<li><b>'.$Lang['shop_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['shop_shenhe_status_2'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 3){
            echo '<li><b>'.$Lang['shop_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['shop_shenhe_status_3'] . '</font>'.$sheheBtnStr.'</li>';
        }
        if($value['status'] == 1){
            echo '<li><b>'.$Lang['shop_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['shop_status_1'] . '</font></li>';
        }else{
            echo '<li><b>'.$Lang['shop_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['shop_status_0'] . '</font></li>';
        }
        echo '<li><b>'.$Lang['shop_add_time'].'&nbsp;:&nbsp;</b><font color="#f70404">' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</font></li>';
        echo '</ul></div></td>';

        echo '<td><div class="tc_content_box_handle"><ul>';
        if($value['status'] == 1 ){
            echo '<li><a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shop_status_0']. '</a></li>';
        }else{
            echo '<li><a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shop_status_1']. '</a></li>';
        }
        echo '<li><a href="'.$modBaseUrl.'&act=edit_date&tequan_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shop_edit_date']. '</a></li>';
        echo '<li><a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a></li>';
        echo '<li><a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a></li>';
        echo '</ul></div></td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $tcshop_id              = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $title                  = isset($_GET['title'])? addslashes($_GET['title']):'';
    $xianzhi_num            = isset($_GET['xianzhi_num'])? intval($_GET['xianzhi_num']):0;
    $today_num              = isset($_GET['today_num'])? intval($_GET['today_num']):0;
    $tequan_type            = intval($_GET['tequan_type'])>0 ? intval($_GET['tequan_type']):1;
    $tequan_zhekou          = isset($_GET['tequan_zhekou'])? addslashes($_GET['tequan_zhekou']):'';
    //$tequan_shengprice      = intval($_GET['tequan_shengprice'])>0 ? intval($_GET['tequan_shengprice']):0;
    $tequan_shengprice      = isset($_GET['tequan_shengprice'])? addslashes($_GET['tequan_shengprice']):'0';
    $tequan_shenglimit      = intval($_GET['tequan_shenglimit'])>0 ? intval($_GET['tequan_shenglimit']):0;
    $open_putong_zhekou     = isset($_GET['open_putong_zhekou'])? intval($_GET['open_putong_zhekou']):0;
    $putong_zhekou          = isset($_GET['putong_zhekou'])? addslashes($_GET['putong_zhekou']):'';
    //$putong_shengprice      = intval($_GET['putong_shengprice'])>0 ? intval($_GET['putong_shengprice']):0;
    $putong_shengprice      = isset($_GET['putong_shengprice'])? addslashes($_GET['putong_shengprice']):'0';
    $putong_shenglimit      = intval($_GET['putong_shenglimit'])>0 ? intval($_GET['putong_shenglimit']):0;
    //$guize                  = isset($_GET['guize'])? addslashes($_GET['guize']):'';
    $content                = isset($_GET['content'])? addslashes($_GET['content']):'';
    $paixu                  = intval($_GET['paixu'])>0 ? intval($_GET['paixu']):10000;
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl         = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    $data['site_id']                = $tcshopInfo['site_id'];
    $data['tcshop_cate_id']         = $tcshopInfo['cate_id'];
    $data['tcshop_cate_child_id']   = $tcshopInfo['cate_child_id'];
    $data['tcshop_latitude']        = $tcshopInfo['latitude'];
    $data['tcshop_longitude']       = $tcshopInfo['longitude'];
    $data['tcshop_id']              = $tcshop_id;
    $data['user_id']                = $tcshopInfo['user_id'];
    $data['title']                  = $title;
    $data['picurl']                 = $picurl;
    $data['xianzhi_num']            = $xianzhi_num;
    $data['today_num']              = $today_num;
    $data['tequan_type']            = $tequan_type;
    $data['tequan_zhekou']          = $tequan_zhekou;
    $data['tequan_shengprice']      = $tequan_shengprice;
    $data['tequan_shenglimit']      = $tequan_shenglimit;
    $data['open_putong_zhekou']     = $open_putong_zhekou;
    $data['putong_zhekou']          = $putong_zhekou;
    $data['putong_shengprice']      = $putong_shengprice;
    $data['putong_shenglimit']      = $putong_shenglimit;
    //$data['guize']                  = $guize;
    $data['content']                = $content;
    $data['shenhe_status']          = 1;
    $data['paixu']                  = $paixu;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$tcyikatongConfig;
    $options = array(
        'tcshop_id'             => 0,
        'title'                 => '',
        'picurl'                => '',
        'xianzhi_num'           => 0,
        'today_num'             => 0,
        'tequan_type'           => 1,
        'tequan_zhekou'         => '',
        'tequan_shengprice'     => '',
        'tequan_shenglimit'     => '',
        'open_putong_zhekou'    => 0,
        'putong_zhekou'         => '',
        'putong_shengprice'     => '',
        'putong_shenglimit'     => '',
        'guize'                 => '',
        'content'               => '',
        'paixu'                 => 10000,
    );
    $options = array_merge($options, $infoArr);
    
    $tequanZhekouListArr = unserialize($tcyikatongConfig['tequan_zhekou_list']);
    $noTequanZhekouListArr = unserialize($tcyikatongConfig['putong_zhekou_list']);
    
    tomshowsetting(true,array('title'=>$Lang['shop_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['shop_tcsho_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['shop_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['shop_title_msg']),"input");
    //tomshowsetting(true,array('title'=>$Lang['shop_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['shop_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['shop_xianzhi_num'],'name'=>'xianzhi_num','value'=>$options['xianzhi_num'],'msg'=>$Lang['shop_xianzhi_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['shop_today_num'],'name'=>'today_num','value'=>$options['today_num'],'msg'=>$Lang['shop_today_num_msg']),"input");
    
    $tequan_type_item = array(1=>$Lang['shop_tequan_tequan_tequan_type_1'],2=>$Lang['shop_tequan_tequan_tequan_type_2']);
    tomshowsetting(true,array('title'=>$Lang['shop_tequan_tequan_type'],'name'=>'tequan_type','value'=>$options['tequan_type'],'msg'=>$Lang['shop_tequan_tequan_type_msg'],'item'=>$tequan_type_item),"radio");
    
    $tequanZhekouStr = '<tr><td width="100" ><b>'.$Lang['shop_tequan_zhekou'].'</b></td></tr>';
    $tequanZhekouStr.= '<tr><td><select style="width: 260px;" name="tequan_zhekou" id="tequan_zhekou">';
    $tequanZhekouStr.=  '<option value="0">'.$Lang['shop_tequan_zhekou_all'].'</option>';
    foreach($tequanZhekouListArr as $key => $value){
        if($options['tequan_zhekou'] == $value){
            $tequanZhekouStr.=  '<option value="'.$value.'" selected>'.$value.'</option>';
        }else{
            $tequanZhekouStr.=  '<option value="'.$value.'">'.$value.'</option>';
        }
    }
    $tequanZhekouStr.= '</select></td></tr>';
    echo $tequanZhekouStr;
    
    tomshowsetting(true,array('title'=>$Lang['shop_tequan_tequan_shengprice'],'name'=>'tequan_shengprice','value'=>$options['tequan_shengprice'],'msg'=>$Lang['shop_tequan_tequan_shengprice_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['shop_tequan_tequan_shenglimit'],'name'=>'tequan_shenglimit','value'=>$options['tequan_shenglimit'],'msg'=>$Lang['shop_tequan_tequan_shenglimit_msg']),"input");
    
    if($tcyikatongConfig['open_putong_zhekou'] == 1){
        $open_status_item = array(0=>$Lang['shop_open_putong_zhekou_0'],1=>$Lang['shop_open_putong_zhekou_1']);
        tomshowsetting(true,array('title'=>$Lang['shop_open_putong_zhekou'],'name'=>'open_putong_zhekou','value'=>$options['open_putong_zhekou'],'msg'=>$Lang['shop_open_putong_zhekou_msg'],'item'=>$open_status_item),"radio");

        $noTequanZhekouStr = '<tr><td width="100" ><b>'.$Lang['shop_putong_zhekou'].'</b></td></tr>';
        $noTequanZhekouStr.= '<tr><td><select style="width: 260px;" name="putong_zhekou" id="putong_zhekou">';
        $noTequanZhekouStr.=  '<option value="0">'.$Lang['shop_putong_zhekou_all'].'</option>';
        foreach($noTequanZhekouListArr as $key => $value){
            if($options['putong_zhekou'] == $value){
                $noTequanZhekouStr.=  '<option value="'.$value.'" selected>'.$value.'</option>';
            }else{
                $noTequanZhekouStr.=  '<option value="'.$value.'">'.$value.'</option>';
            }
        }
        $noTequanZhekouStr.= '</select></td></tr>';
        echo $noTequanZhekouStr;
        
        tomshowsetting(true,array('title'=>$Lang['shop_tequan_putong_shengprice'],'name'=>'putong_shengprice','value'=>$options['putong_shengprice'],'msg'=>$Lang['shop_tequan_putong_shengprice_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['shop_tequan_putong_shenglimit'],'name'=>'putong_shenglimit','value'=>$options['putong_shenglimit'],'msg'=>$Lang['shop_tequan_putong_shenglimit_msg']),"input");
        
    }
    
    tomshowsetting(true,array('title'=>$Lang['shop_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['shop_paixu_msg']),"input");
    //tomshowsetting(true,array('title'=>$Lang['shop_guize'],'name'=>'guize','value'=>$options['guize'],'msg'=>$Lang['shop_guize_msg']),"text");
    tomshowsetting(true,array('title'=>$Lang['shop_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['shop_content_msg']),"text");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['shop_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['shop_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['shop_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['shop_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['shop_edit'],"",true);
    }else{
        tomshownavli($Lang['shop_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['shop_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['index_tequan_uses'],$adminBaseUrl.'&tmod=carduses',false);
    }
    tomshownavfooter();
}