<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/class/function.core.php';

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end

$act = isset($_GET['act'])? addslashes($_GET['act']):"";

if($act == "card" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id        = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    $card_type_id   = intval($_GET['card_type_id'])>0 ? intval($_GET['card_type_id']):0;
    $invite_code    = isset($_GET['invite_code']) ? addslashes($_GET['invite_code']):'';
    $vfrom          = isset($_GET['vfrom']) ? addslashes($_GET['vfrom']):'';

    $cardTypeInfo = C::t("#tom_tcyikatong#tom_tcyikatong_card_type")->fetch_by_id($card_type_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    if(empty($cardTypeInfo) || $cardTypeInfo['price'] <= 0){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if(empty($userInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($cardTypeInfo['max_num'] > 0){
        $useCardCount=  C::t('#tom_tcyikatong#tom_tcyikatong_card_log')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND card_type_id = {$cardTypeInfo['id']} ");
        if($useCardCount >= $cardTypeInfo['max_num']){
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $pay_price = $cardTypeInfo['price'];
    
    $tj_hehuoren_id = 0;
    if($__ShowTchehuoren == 1){
        if($tchehuorenConfig['tcyikatong_type'] == 1){
            if(!empty($invite_code)){
                $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_all_list(" AND invite_code = '{$invite_code}' AND status=1 ", 'ORDER BY id DESC', 0, 1);
                if(is_array($tchehuorenInfoTmp) && !empty($tchehuorenInfoTmp[0])){
                    $tj_hehuoren_id = $tchehuorenInfoTmp[0]['id'];
        
                    $tcyikatong_ruzhu_discount_arr = array(2=>'9.5',3=>'9',4=>'8.5',5=>'8',6=>'7.5',7=>'7',8=>'6.5',9=>'6',10=>'5.5',11=>'5');
                    $tcyikatong_ruzhu_discount = 0;
                    if(isset($tcyikatong_ruzhu_discount_arr[$tchehuorenConfig['tcyikatong_ruzhu_discount']])){
                        $tcyikatong_ruzhu_discount      = $tcyikatong_ruzhu_discount_arr[$tchehuorenConfig['tcyikatong_ruzhu_discount']];
                        $tcyikatong_ruzhu_discount  = $tcyikatong_ruzhu_discount/10;
                        $pay_price = number_format($pay_price * $tcyikatong_ruzhu_discount, 2, '.', '');
                    }
                }
            }
        }else if($tchehuorenConfig['tcyikatong_type'] == 2){
            $tj_hehuoren_id = $userInfo['tj_hehuoren_id'];
        }
        
    }
    
    $cardInfo = C::t("#tom_tcyikatong#tom_tcyikatong_card")->fetch_by_user_id($user_id);
    
    if(is_array($cardInfo) && !empty($cardInfo)){
        $cardId = $cardInfo['id'];
    }else{
        $auto_id = 0;
        $autoidTmp  = C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->fetch_all_list(""," ORDER BY id DESC ",0,1);
        if(is_array($autoidTmp) && !empty($autoidTmp) && !empty($autoidTmp[0]['id'])){
            if($autoidTmp[0]['id'] > 999990 && $autoidTmp[0]['id'] < 10101000 ){
                $insertData = array();
                $insertData['id']               = 10101011;
                $insertData['add_time']         = TIMESTAMP;
                if(C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert($insertData)){
                    $auto_id = C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert_id();
                }
            }else{
                $insertData = array();
                $insertData['add_time']         = TIMESTAMP;
                if(C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert($insertData)){
                    $auto_id = C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert_id();
                }
            }
        }else{
            $insertData = array();
            $insertData['id']               = 101011;
            $insertData['add_time']         = TIMESTAMP;
            if(C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert($insertData)){
                $auto_id = C::t('#tom_tcyikatong#tom_tcyikatong_autoid')->insert_id();
            }
        }

        $card_no = '';
        $auto_id_str = strval($auto_id);
        if($auto_id > 10101000){
            $rand_num1 = mt_rand(1, 9);
            $card_no .= $auto_id_str[0].$auto_id_str[1].$rand_num1;
            $rand_num2 = mt_rand(1, 9);
            $card_no .= $auto_id_str[2].$auto_id_str[3].$rand_num2;
            $rand_num3 = mt_rand(1, 9);
            $card_no .= $auto_id_str[4].$auto_id_str[5].$rand_num3;
            $rand_num4 = mt_rand(1, 9);
            $card_no .= $auto_id_str[6].$auto_id_str[7].$rand_num4;
        }else{
            $rand_num1 = mt_rand(1, 9);
            $card_no .= $auto_id_str[0].$auto_id_str[1].$rand_num1;
            $rand_num2 = mt_rand(1, 9);
            $card_no .= $auto_id_str[2].$auto_id_str[3].$rand_num2;
            $rand_num3 = mt_rand(1, 9);
            $card_no .= $auto_id_str[4].$auto_id_str[5].$rand_num3;
        }
        
        $insertData = array();
        $insertData['user_id']          = $user_id;
        $insertData['card_no']          = $card_no;
        $insertData['expire_time']      = 0;
        $insertData['status']           = 0;
        $insertData['add_time']         = TIMESTAMP;
        if(C::t('#tom_tcyikatong#tom_tcyikatong_card')->insert($insertData)){
            $cardId = C::t('#tom_tcyikatong#tom_tcyikatong_card')->insert_id();
        }else{
            $outArr = array(
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    ## pay start
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }

    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
    $insertData['order_no']         = $order_no;
    $insertData['user_id']          = $user_id;
    $insertData['openid']           = $userInfo['openid'];
    $insertData['card_id']          = $cardId;
    $insertData['card_type_id']     = $cardTypeInfo['id'];
    $insertData['card_type_name']   = $cardTypeInfo['name'];
    $insertData['card_type_days']   = $cardTypeInfo['days'];
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcyikatong#tom_tcyikatong_order')->insert($insertData)){

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tcyikatong';
        $insertData['order_no']        = $order_no;
        $insertData['goods_id']        = $cardId;
        $insertData['goods_name']      = lang('plugin/tom_tcyikatong','pay_order_type_1').$tcyikatongConfig['card_name'];
        $insertData['goods_beizu']     = lang('plugin/tom_tcyikatong','pay_order_type_1').$tcyikatongConfig['card_name'];
        $insertData['goods_url']       = "plugin.php?id=tom_tcyikatong&site={$site_id}&mod=card&vfrom={$vfrom}";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tcyikatong&site={$site_id}&mod=card&vfrom={$vfrom}";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tcyikatong&site={$site_id}&mod=card&vfrom={$vfrom}";
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $pay_price;
        $insertData['order_status']    = 1;     
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'    => 200,
                'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;

        }else{
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }

    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    ## pay end
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}