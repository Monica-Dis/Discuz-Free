<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcyikatong'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcyikatong&pmod=admin';
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcyikatong&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcyikatong&pmod=admin';

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/class/function.admin.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/class/function.core.php';
$tcyikatongConfig = get_plugin_config($pluginid);
$Lang = formatLang($Lang);
tomloadJqueryjs();
$tcshopPlugin = C::t('#tom_tcshop#common_plugin')->fetch_by_identifier('tom_tcshop');
$tcshopConfig = get_plugin_config($tcshopPlugin['pluginid']);

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/config/config.utf8.php';
}

$tongchengPlugin = C::t('#tom_tcyikatong#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

if($_GET['tmod'] == 'index'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/admin/index.php';
}else if($_GET['tmod'] == 'carduses'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/admin/carduses.php';
}else if($_GET['tmod'] == 'shop'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/admin/shop.php';
}else if($_GET['tmod'] == 'cardtype'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/admin/cardtype.php';
}else if($_GET['tmod'] == 'cardcode'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/admin/cardcode.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/admin/order.php';
}else if($_GET['tmod'] == 'gift'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/admin/gift.php';
}else if($_GET['tmod'] == 'common'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/admin/common.php';
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/admin/addon.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/admin/index.php';
}