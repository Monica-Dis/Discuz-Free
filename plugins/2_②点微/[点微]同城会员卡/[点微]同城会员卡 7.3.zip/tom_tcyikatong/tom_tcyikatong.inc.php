<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
$prand = rand(1, 1000);
$cssJsVersion = '20201227';
$sql_in_site_ids = $site_id;
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tcyikatong/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/qqface.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcyikatongConfig['wx_share_title'];
$shareDesc = $tcyikatongConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=index');
$shareLogo = $tcyikatongConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$__ShowTcshop = 0;
$tcshopConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcshop/tom_tcshop.inc.php')) {
	$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
	if ($tcshopConfig['open_tcshop'] == 1) {
		$__ShowTcshop = 1;
	}
}
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')) {
	$tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
	if ($tcqianggouConfig['open_tcqianggou'] == 1) {
		$__ShowTcqianggou = 1;
	}
}
$__ShowTcmall = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcmall/tom_tcmall.inc.php')) {
	$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
	if ($tcmallConfig['open_tcmall'] == 1) {
		$__ShowTcmall = 1;
	}
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$__CardInfo = array();
$__CardExpire = '00/00/00';
if ($__UserInfo['id'] > 0) {
	$cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($__UserInfo['id']);
	if (is_array($cardInfoTmp) && !empty($cardInfoTmp)) {
		$__CardInfo = $cardInfoTmp;
		$__CardExpire = dgmdate($__CardInfo['expire_time'], 'Y/m/d', $tomSysOffset);
		$__CardInfo['cardTypeInfo'] = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($__CardInfo['card_type_id']);
	}
}
if (CHARSET == 'gbk') {
	include DISCUZ_ROOT . './source/plugin/tom_tcyikatong/config/config.gbk.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tcyikatong/config/config.utf8.php';
}
$ajaxAddLbsUrl = 'plugin.php?id=tom_tcyikatong:ajax&site=' . $site_id . '&act=add_lbs&formhash=' . $formhash;
$searchUrl = 'plugin.php?id=tom_tcyikatong:ajax&site=' . $site_id . '&act=get_search_url';
$updateUserCardStatusUrl = 'plugin.php?id=tom_tcyikatong:ajax&site=' . $site_id . '&act=update_user_card&formhash=' . FORMHASH;
$updateGiftStatusUrl = 'plugin.php?id=tom_tcyikatong:ajax&site=' . $site_id . '&act=update_gift&formhash=' . FORMHASH;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
$commonInfo = C::t('#tom_tcyikatong#tom_tcyikatong_common')->fetch_by_id(1);
if (!$commonInfo) {
	$insertData = array();
	$insertData['id'] = 1;
	C::t('#tom_tcyikatong#tom_tcyikatong_common')->insert($insertData);
}
if ($_GET['mod'] == 'index') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$month = dgmdate($_G['timestamp'], 'n', $tomSysOffset);
	$year = dgmdate($_G['timestamp'], 'Y', $tomSysOffset);
	$day = date('d', strtotime(dgmdate($_G['timestamp'], 'Y-m-d H:i:s', $tomSysOffset)));
	$week = dgmdate($_G['timestamp'], 'N', $tomSysOffset);
	$dayCount = date('t', strtotime($year . '-' . $month));
	if ($month + 1 > 12) {
		$nextMonth = 1;
		$nextYear = $year;
	} else {
		$nextMonth = $month + 1;
		$nextYear = $year + 1;
	}
	$nextMonthDayCount = date('t', strtotime($nextYear . '-' . $nextMonth));
	$dayArr = array();
	for ($i = $day; $i <= $dayCount; $i++) {
		$dayArr[] = $i;
	}
	if ($nextMonthDayCount >= $day) {
		$nextMonthDayCount = $day;
	}
	for ($i = 1; $i <= $nextMonthDayCount; $i++) {
		$dayArr[] = $i;
	}
	$i = 1;
	$dayList = array();
	if (!empty($dayArr)) {
		foreach ($dayArr as $key => $value) {
			$weekTime = ($i - 1) * 86400;
			$dayList[$key]['i'] = $i;
			$dayList[$key]['day'] = $value;
			$dayList[$key]['week'] = dgmdate($_G['timestamp'] + $weekTime, 'N', $tomSysOffset);
			$dayList[$key]['num'] = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_all_weeks_days_count(' AND status=1 AND shenhe_status=1 AND site_id IN(' . $sql_in_site_ids . ') ', $dayList[$key]['week'], $dayList[$key]['day']);
			$i++;
		}
	}
	$str_replace_search_array = array('{QIANGGOU}', '{MALL}', '{FENLEI}', '{TEQUAN}');
	$str_replace_search_replace = array('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=qianggoulist&is_vip=1', 'plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=list&is_vip=1', 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=fabu', 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=list');
	$menuList = array();
	$i = 1;
	if (!empty($tcyikatongConfig['index_nav'])) {
		$index_menu_str = str_replace($str_replace_search_array, $str_replace_search_replace, $tcyikatongConfig['index_nav']);
		$index_menu_str = str_replace('{site}', $site_id, $index_menu_str);
		$index_menu_str = str_replace("\r\n", '{n}', $index_menu_str);
		$index_menu_str = str_replace("\n", '{n}', $index_menu_str);
		$index_menu_arr = explode('{n}', $index_menu_str);
		if (is_array($index_menu_arr) && !empty($index_menu_arr)) {
			foreach ($index_menu_arr as $key => $value) {
				$menuList[$i] = explode('|', $value);
				$i++;
			}
		}
	}
	$menuCount = count($menuList);
	$cardLogListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card_log')->fetch_all_list('', 'ORDER BY id DESC', 0, 10);
	$cardLogList = array();
	if (is_array($cardLogListTmp) && !empty($cardLogListTmp)) {
		foreach ($cardLogListTmp as $key => $value) {
			$cardLogList[$key] = $value;
			$cartUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$cartUserInfoTmp['nickname'] = cutstr($cartUserInfoTmp['nickname'], 10, '...');
			$cardLogList[$key]['userInfo'] = $cartUserInfoTmp;
		}
	}
	$cardLogCount = count($cardLogList);
	$tcqianggouList = array();
	if ($tcyikatongConfig['qianggou_num'] > 0 && $__ShowTcqianggou == 1) {
		$tcqianggouListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND type_id=1 AND qiang_status=1 AND open_vip=1 AND site_id IN(' . $sql_in_site_ids . ') ', ' ORDER BY qiang_status ASC,type_id ASC,paixu ASC,id DESC ', 0, $tcyikatongConfig['qianggou_num']);
		foreach ($tcqianggouListTmp as $key => $value) {
			$tcqianggouList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$tcqianggouList[$key]['picurl'] = $picurl;
			$tcqianggouList[$key]['link'] = 'plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=details&goods_id=' . $value['id'];
			$tcqianggouList[$key]['clicks'] = $value['clicks'] + $value['virtual_clicks'];
			if ($value['end_time'] > TIMESTAMP) {
				$tcqianggouList[$key]['syTime'] = ($value['end_time'] - TIMESTAMP) * 1000;
			} else {
				$tcqianggouList[$key]['syTime'] = 0;
			}
		}
	}
	$tcmallGoodsList = array();
	if ($tcyikatongConfig['mall_num'] > 0 && $__ShowTcmall == 1) {
		$tcmallGoodsListTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_list(' AND status=1 AND shenhe_status=1 AND open_vip=1 AND site_id IN(' . $sql_in_site_ids . ') ', ' ORDER BY gsort DESC ,add_time DESC,id DESC ', 0, $tcyikatongConfig['mall_num']);
		foreach ($tcmallGoodsListTmp as $key => $value) {
			$tcmallGoodsList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$tcmallGoodsList[$key]['picurl'] = $picurl;
			$tcmallGoodsList[$key]['link'] = 'plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=goodsinfo&goods_id=' . $value['id'];
		}
	}
	$tcmallGoodsCount = count($tcmallGoodsList);
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcyikatong:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
	$ajaxGiftLoadListUrl = 'plugin.php?id=tom_tcyikatong:ajax&site=' . $site_id . '&act=gift_list&formhash=' . $formhash;
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tcyikatong/images/index.js';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:index');
	echo '<script src="source/plugin/tom_tcyikatong/images/index.js"></script>';
} elseif ($_GET['mod'] == 'list') {
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$ordertype = !empty($_GET['ordertype']) ? addslashes($_GET['ordertype']) : '';
	$areaInfo = array();
	if (!empty($area_id)) {
		$areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
	}
	$streetInfo = array();
	if (!empty($street_id)) {
		$streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
	}
	$cateInfo = array();
	if (!empty($cate_id)) {
		$cateInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($cate_id);
	}
	$cateChildInfo = array();
	if (!empty($cate_child_id)) {
		$cateChildInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($cate_child_id);
	}
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		$areaList = $areaListTmp;
	}
	$cateList = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list(' AND parent_id=0 ', ' ORDER BY csort ASC,id DESC ', 0, 500);
	$ajaxGetStreetUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=list_get_street&&formhash=' . $formhash;
	$ajaxGetCateChildUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=list_get_cate_child&&formhash=' . $formhash;
	$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcyikatong:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=list&cate_id=' . $cate_id);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:list');
} elseif ($_GET['mod'] == 'card') {
	$vfrom = !empty($_GET['vfrom']) ? addslashes($_GET['vfrom']) : '';
	$showInviteCodeInput = 0;
	if ($__ShowTchehuoren == 1) {
		$tcyikatong_ruzhu_discount_arr = array(2 => '9.5', 3 => '9', 4 => '8.5', 5 => '8', 6 => '7.5', 7 => '7', 8 => '6.5', 9 => '6', 10 => '5.5', 11 => '5');
		$tcyikatong_ruzhu_discount = 0;
		if (isset($tcyikatong_ruzhu_discount_arr[$tchehuorenConfig['tcyikatong_ruzhu_discount']])) {
			$tcyikatong_ruzhu_discount = $tcyikatong_ruzhu_discount_arr[$tchehuorenConfig['tcyikatong_ruzhu_discount']];
			$tcyikatong_ruzhu_discount = $tcyikatong_ruzhu_discount / 10;
		}
		if ($site_id > 1) {
			if ($__SitesInfo['hehuoren_fc_open'] == 1) {
				$showInviteCodeInput = 1;
			}
		} else {
			if ($site_id == 1) {
				$showInviteCodeInput = 1;
			}
		}
		if ($tchehuorenConfig['tcyikatong_type'] == 2) {
			$showInviteCodeInput = 0;
		}
	}
	$cardTypeListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_all_list('', 'ORDER BY tsort ASC,id DESC', 0, 100);
	$cardTypeList = array();
	if (is_array($cardTypeListTmp) && !empty($cardTypeListTmp)) {
		foreach ($cardTypeListTmp as $key => $value) {
			$cardTypeList[$key] = $value;
			if ($value['max_num'] > 0) {
				$useCardCount = C::t('#tom_tcyikatong#tom_tcyikatong_card_log')->fetch_all_count(' AND user_id = ' . $__UserInfo['id'] . ' AND card_type_id = ' . $value['id'] . ' ');
				$shengYuNum = $value['max_num'] - $useCardCount;
				if ($shengYuNum <= 0) {
					$shengYuNum = 0;
				}
				$cardTypeList[$key]['shengYuNum'] = $shengYuNum;
			}
			if ($__ShowTchehuoren == 1 && $showInviteCodeInput == 1 && $tcyikatong_ruzhu_discount > 0) {
				$cardTypeList[$key]['zhekou_price'] = number_format($value['price'] * $tcyikatong_ruzhu_discount, 2, '.', '');
			}
		}
	}
	$open_card_txt = stripslashes($commonInfo['open_card_txt']);
	$showMustPhoneBtn = 0;
	if ($tcyikatongConfig['must_bind_tel'] == 1 && empty($__UserInfo['tel'])) {
		$showMustPhoneBtn = 1;
		$phone_back_url = $weixinClass->get_url();
		$phone_back_url = urlencode($phone_back_url);
		$phoneUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=phone&phone_back=' . $phone_back_url;
	}
	$tchehuorenAjaxUrl = 'plugin.php?id=tom_tchehuoren:ajax&site=' . $site_id . '&formhash=' . FORMHASH;
	$payUrl = 'plugin.php?id=tom_tcyikatong:pay&site=' . $site_id . '&act=card&formhash=' . $formhash;
	$codeUrl = 'plugin.php?id=tom_tcyikatong:ajax&site=' . $site_id . '&act=code&formhash=' . $formhash;
	$hideFooterNav = 0;
	$showBackIndex = 0;
	$backIndexUrl = '';
	$showMoreTequan = 1;
	if ($vfrom == 'qianggou') {
		$hideFooterNav = 1;
		$showBackIndex = 1;
		$showMoreTequan = 2;
		$backIndexUrl = 'plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=index';
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:card');
} elseif ($_GET['mod'] == 'info') {
	$tequan_id = intval($_GET['tq_id']) > 0 ? intval($_GET['tq_id']) : 0;
	$tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_id($tequan_id);
	if (empty($tequanInfo)) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tequanInfo['tcshop_id']);
	if (!$tcshopInfo || $tcshopInfo['status'] != 1 || $tcshopInfo['shenhe_status'] != 1 || $tcshopInfo['vip_status'] != 1) {
		$tequanInfo['status'] = 0;
		$updateData = array();
		$updateData['status'] = 0;
		C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->update($tequan_id, $updateData);
	}
	if ($tequanInfo['status'] != 1 || $tequanInfo['shenhe_status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
		if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
		} else {
			$picurl = $_G['siteurl'] . $tcshopInfo['picurl'];
		}
	} else {
		$picurl = $tcshopInfo['picurl'];
	}
	if (!preg_match('/^http/', $tcshopInfo['kefu_qrcode'])) {
		if (strpos($tcshopInfo['kefu_qrcode'], 'source/plugin/tom_') === false) {
			$kefu_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['kefu_qrcode'];
		} else {
			$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
		}
	} else {
		$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
	}
	$day = date('d', strtotime(dgmdate($_G['timestamp'], 'Y-m-d H:i:s', $tomSysOffset)));
	$week = dgmdate($_G['timestamp'], 'N', $tomSysOffset);
	$zhekouStatus = 0;
	if ($tcyikatongConfig['open_putong_zhekou'] == 1 && $tequanInfo['open_putong_zhekou'] == 1) {
		$zhekouStatus = 1;
	}
	$dateStr = '';
	if ($tequanInfo['type'] == 1) {
		$weeksListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->fetch_all_list(' AND tequan_id = ' . $tequanInfo['id'] . ' ', ' ORDER BY week ASC,id DESC ', 0, 10);
		$weeksList = array();
		if (is_array($weeksListTmp) && !empty($weeksListTmp)) {
			foreach ($weeksListTmp as $key => $value) {
				if ($week == $value['week']) {
					$zhekouStatus = 2;
				}
				$weeksList[] = $weeksDateArray[$value['week']];
			}
		}
		$dateStr = implode(lang('plugin/tom_tcyikatong', 'info_ge'), $weeksList);
	} else {
		$daysListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->fetch_all_list(' AND tequan_id = ' . $tequanInfo['id'] . ' ', ' ORDER BY day ASC,id DESC ', 0, 50);
		$daysList = array();
		if (is_array($daysListTmp) && !empty($daysListTmp)) {
			foreach ($daysListTmp as $key => $value) {
				if ($day == $value['day']) {
					$zhekouStatus = 2;
				}
				$daysList[] = $value['day'] . lang('plugin/tom_tcyikatong', 'info_day');
			}
		}
		$dateStr = implode(lang('plugin/tom_tcyikatong', 'info_ge'), $daysList);
	}
	$todayNum = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses')->fetch_all_sum_num(' AND tequan_id = ' . $tequan_id . ' AND uses_time = ' . $nowDayTime . ' ');
	$todayNum = intval($todayNum);
	if ($tequanInfo['today_num'] > 0) {
		if ($todayNum >= $tequanInfo['today_num']) {
			$zhekouStatus = 3;
		}
	}
	$lingCount = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_ling')->fetch_all_count(' AND tequan_id = ' . $tequan_id . ' ');
	$lingListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_ling')->fetch_all_list(' AND tequan_id = ' . $tequan_id . ' ', 'ORDER BY add_time DESC,id DESC', 0, 8);
	$lingList = array();
	if (is_array($lingListTmp) && !empty($lingListTmp)) {
		foreach ($lingListTmp as $key => $value) {
			$lingList[$key] = $value;
			$useUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$lingList[$key]['userInfo'] = $useUserInfoTmp;
		}
	}
	$info_use_txt = stripslashes($commonInfo['info_use_txt']);
	$guize = stripslashes($tequanInfo['guize']);
	$content = stripslashes($tequanInfo['content']);
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tcshopConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$baiduMapToName = $tcshopInfo['name'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapToAddress = $tcshopInfo['address'];
	$baiduMapToAddress = diconv($baiduMapToAddress, CHARSET, 'utf-8');
	$baiduMapToAddress = urlencode($baiduMapToAddress);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tcshopInfo['latitude'] . ',' . $tcshopInfo['longitude'] . '&title=' . $baiduMapToName . '&content=' . $baiduMapToAddress . '&output=html';
	$open_edit_pinglun = 0;
	if ($tcshopInfo['user_id'] == $__UserInfo['id'] && $tongchengConfig['open_fbr_remove_pinglun'] == 1) {
		$open_edit_pinglun = 1;
	} else {
		if ($__UserInfo['groupid'] == 1 && $site_id == 1) {
			$open_edit_pinglun = 1;
		} else {
			if ($__UserInfo['groupid'] == 2 && $site_id == $__UserInfo['groupsiteid']) {
				$open_edit_pinglun = 1;
			}
		}
	}
	$pinglunCount = C::t('#tom_tcshop#tom_tcshop_pinglun')->fetch_all_count(' AND tcshop_id = ' . $tcshopInfo['id'] . ' ');
	$wxUploadUrl = 'plugin.php?id=tom_tcshop:wxMediaDowmload&site=' . $site_id . '&act=photo&formhash=' . FORMHASH;
	$pinglunPloadUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=upload&act=pinglun_picurl&formhash=' . FORMHASH;
	$addTcshopPinglunUrl = 'plugin.php?id=tom_tcshop:ajax&act=pinglun&formhash=' . FORMHASH;
	$checkTcshopPinglunUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=check_pinglun&formhash=' . FORMHASH;
	$showPinglunUrl = 'plugin.php?id=tom_tcshop:ajax&act=loadPinglun&tcshop_id=' . $tcshopInfo['id'] . '&formhash=' . FORMHASH;
	$removePinglunUrl = 'plugin.php?id=tom_tcshop:ajax&act=removePinglun&tcshop_id=' . $tcshopInfo['id'] . '&formhash=' . FORMHASH;
	$removeReplyUrl = 'plugin.php?id=tom_tcshop:ajax&act=removeReplyPinglun&tcshop_id=' . $tcshopInfo['id'] . '&formhash=' . FORMHASH;
	$tequanLingStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$tequanLingInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_ling')->fetch_all_list(' AND tequan_id = ' . $tequanInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' AND status=0 ', 'ORDER BY id DESC', 0, 1);
		if (is_array($tequanLingInfoTmp) && !empty($tequanLingInfoTmp[0]) && $tequanLingInfoTmp[0]['id'] > 0) {
			$tequanLingStatus = 1;
		}
	}
	$url = $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=shophexiao&tq_id=' . $tequanInfo['id'] . '&user_id=' . $__UserInfo['id']);
	$imageDir = '/source/plugin/tom_tcyikatong/data/tequan_' . $tequanInfo['id'] . '/';
	$qrcodeUrl = DISCUZ_ROOT . ('./source/plugin/tom_tcyikatong/data/tequan_' . $tequanInfo['id'] . '/') . md5($url) . '.jpg';
	$qrcodeImg = 'source/plugin/tom_tcyikatong/data/tequan_' . $tequanInfo['id'] . '/' . md5($url) . '.jpg';
	if (!file_exists($qrcodeUrl)) {
		include DISCUZ_ROOT . './source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
		$tomDir = DISCUZ_ROOT . '.' . $imageDir;
		if (!is_dir($tomDir)) {
			mkdir($tomDir, 511, true);
		} else {
			chmod($tomDir, 511);
		}
		QRcode::png($url, $qrcodeUrl, 'H', 5, 2);
	}
	if ($tequanInfo['tequan_type'] == 2) {
		$shareTitle = str_replace('{MONEY}', $tequanInfo['tequan_shengprice'], $tcyikatongConfig['quan_share_title']);
	} else {
		$shareTitle = str_replace('{ZHEKOU}', $tequanInfo['tequan_zhekou'], $tcyikatongConfig['zhekou_share_title']);
	}
	$shareTitle = str_replace('{TITLE}', $tequanInfo['title'], $shareTitle);
	$shareTitle = str_replace('{SHOPNAME}', $tcshopInfo['name'], $shareTitle);
	$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	$shareTitle = str_replace("\r\n", '', $shareTitle);
	$shareTitle = str_replace("\n", '', $shareTitle);
	$shareTitle = str_replace("\r", '', $shareTitle);
	$shareLogo = $picurl;
	$shareDesc = $tequanInfo['title'];
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=info&tq_id=' . $tequanInfo['id']);
	$lingAjaxUrl = 'plugin.php?id=tom_tcyikatong:ajax&site=' . $site_id . '&act=ling_tequan&tq_id=' . $tequanInfo['id'] . '&user_id=' . $__UserInfo['id'] . '&formhash=' . FORMHASH;
	$ajaxClicksUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=clicks&tcshop_id=' . $tcshopInfo['id'] . '&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:info');
} elseif ($_GET['mod'] == 'infouseslist') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$tequan_id = intval($_GET['tq_id']) > 0 ? intval($_GET['tq_id']) : 0;
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_ling')->fetch_all_count(' AND tequan_id = ' . $tequan_id . ' ');
	$usesListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_ling')->fetch_all_list(' AND tequan_id = ' . $tequan_id . ' ', 'ORDER BY add_time DESC,id DESC', $start, $pagesize);
	$usesList = array();
	if (is_array($usesListTmp) && !empty($usesListTmp)) {
		foreach ($usesListTmp as $key => $value) {
			$usesList[$key] = $value;
			$useUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$usesList[$key]['userInfo'] = $useUserInfoTmp;
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=infouseslist&tq_id=' . $tequan_id . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=infouseslist&tq_id=' . $tequan_id . '&page=' . $nextPage;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:infouseslist');
} elseif ($_GET['mod'] == 'gift') {
	$gift_id = intval($_GET['gift_id']) > 0 ? intval($_GET['gift_id']) : 0;
	$giftInfo = C::t('#tom_tcyikatong#tom_tcyikatong_gift')->fetch_by_id($gift_id);
	if ($giftInfo['id'] <= 0) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($giftInfo['tcshop_id']);
	$cardTypeNameStr = '';
	$cardTypeIdsArr = array();
	if (!empty($giftInfo['card_type_ids'])) {
		$cardTypeIdsArr = explode('|', $giftInfo['card_type_ids']);
		$cardTypeIdsStr = str_replace('|', ',', $giftInfo['card_type_ids']);
		$giftCardTypeListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_all_list(' AND id IN(' . $cardTypeIdsStr . ') ', 'ORDER BY tsort ASC,id DESC', 0, 100);
		$typeNameArr = array();
		if (is_array($giftCardTypeListTmp) && !empty($giftCardTypeListTmp)) {
			foreach ($giftCardTypeListTmp as $k => $v) {
				$typeNameArr[] = $v['name'];
			}
			$cardTypeNameStr = implode(lang('plugin/tom_tcyikatong', 'dian'), $typeNameArr);
		}
	} else {
		$cardTypeIdsArr[] = $giftInfo['card_type_id'];
		$giftCardTypeInfo = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($giftInfo['card_type_id']);
		$cardTypeNameStr = $giftCardTypeInfo['name'];
	}
	$giftUsesInfo = array();
	if ($__UserInfo['id'] > 0) {
		$giftUsesInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_list(' AND user_id = ' . $__UserInfo['id'] . ' AND gift_id = ' . $gift_id . ' AND status = 0 ', 'ORDER BY id DESC', 0, 1);
		if (is_array($giftUsesInfoTmp) && !empty($giftUsesInfoTmp[0])) {
			$giftUsesInfo = $giftUsesInfoTmp[0];
		}
	}
	$showBtnStatus = 0;
	if ($__CardInfo['status'] == 1 && in_array($__CardInfo['card_type_id'], $cardTypeIdsArr)) {
		$showBtnStatus = 1;
	}
	if ($giftUsesInfo['id'] > 0) {
		$showBtnStatus = 2;
	}
	if ($showBtnStatus == 1 && $__CardInfo['gift_status'] == 1) {
		$showBtnStatus = 3;
	}
	$giftUsesCount = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_count(' AND gift_id = ' . $gift_id . ' ');
	if ($showBtnStatus == 1) {
		if ($giftUsesCount >= $giftInfo['num']) {
			$showBtnStatus = 4;
		}
	}
	if ($giftInfo['status'] != 1) {
		$showBtnStatus = 5;
	}
	if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
		if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
		} else {
			$picurl = $_G['siteurl'] . $tcshopInfo['picurl'];
		}
	} else {
		$picurl = $tcshopInfo['picurl'];
	}
	if (!preg_match('/^http/', $tcshopInfo['kefu_qrcode'])) {
		if (strpos($tcshopInfo['kefu_qrcode'], 'source/plugin/tom_') === false) {
			$kefu_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['kefu_qrcode'];
		} else {
			$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
		}
	} else {
		$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
	}
	$syNum = $giftInfo['num'] - $giftUsesCount;
	$end_time = dgmdate($giftInfo['end_time'], 'Y' . lang('plugin/tom_tcyikatong', 'year') . 'm' . lang('plugin/tom_tcyikatong', 'month') . 'd' . lang('plugin/tom_tcyikatong', 'day') . '', $tomSysOffset);
	$info_use_txt = stripslashes($commonInfo['info_use_txt']);
	$guize = stripslashes($giftInfo['guize']);
	$content = stripslashes($giftInfo['content']);
	$usesCount = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_count(' AND gift_id = ' . $gift_id . ' ');
	$usesListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_list(' AND gift_id = ' . $gift_id . ' ', 'ORDER BY add_time DESC,id DESC', 0, 8);
	$usesList = array();
	if (is_array($usesListTmp) && !empty($usesListTmp)) {
		foreach ($usesListTmp as $key => $value) {
			$usesList[$key] = $value;
			$useUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$usesList[$key]['userInfo'] = $useUserInfoTmp;
		}
	}
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tcshopConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$baiduMapToName = $tcshopInfo['name'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapToAddress = $tcshopInfo['address'];
	$baiduMapToAddress = diconv($baiduMapToAddress, CHARSET, 'utf-8');
	$baiduMapToAddress = urlencode($baiduMapToAddress);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tcshopInfo['latitude'] . ',' . $tcshopInfo['longitude'] . '&title=' . $baiduMapToName . '&content=' . $baiduMapToAddress . '&output=html';
	$open_edit_pinglun = 0;
	if ($tcshopInfo['user_id'] == $__UserInfo['id'] && $tongchengConfig['open_fbr_remove_pinglun'] == 1) {
		$open_edit_pinglun = 1;
	} else {
		if ($__UserInfo['groupid'] == 1 && $site_id == 1) {
			$open_edit_pinglun = 1;
		} else {
			if ($__UserInfo['groupid'] == 2 && $site_id == $__UserInfo['groupsiteid']) {
				$open_edit_pinglun = 1;
			}
		}
	}
	$pinglunCount = C::t('#tom_tcshop#tom_tcshop_pinglun')->fetch_all_count(' AND tcshop_id = ' . $tcshopInfo['id'] . ' ');
	$pinglunPloadUrl = 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=upload&act=pinglun_picurl&formhash=' . FORMHASH;
	$checkTcshopPinglunUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=check_pinglun&formhash=' . FORMHASH;
	$addTcshopPinglunUrl = 'plugin.php?id=tom_tcshop:ajax&act=pinglun&formhash=' . FORMHASH;
	$addPinglunUrl = 'plugin.php?id=tom_tongcheng:ajax&act=pinglun&formhash=' . FORMHASH;
	$showPinglunUrl = 'plugin.php?id=tom_tcshop:ajax&act=loadPinglun&tcshop_id=' . $tcshopInfo['id'] . '&formhash=' . FORMHASH;
	$removePinglunUrl = 'plugin.php?id=tom_tcshop:ajax&act=removePinglun&tcshop_id=' . $tcshopInfo['id'] . '&formhash=' . FORMHASH;
	$removeReplyUrl = 'plugin.php?id=tom_tcshop:ajax&act=removeReplyPinglun&tcshop_id=' . $tcshopInfo['id'] . '&formhash=' . FORMHASH;
	$url = $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=gifthexiao&gift_id=' . $giftInfo['id'] . '&user_id=' . $__UserInfo['id']);
	$imageDir = '/source/plugin/tom_tcyikatong/data/gift_' . $giftInfo['id'] . '/';
	$qrcodeUrl = DISCUZ_ROOT . ('./source/plugin/tom_tcyikatong/data/gift_' . $giftInfo['id'] . '/') . md5($url) . '.jpg';
	$qrcodeImg = 'source/plugin/tom_tcyikatong/data/gift_' . $giftInfo['id'] . '/' . md5($url) . '.jpg';
	if (!file_exists($qrcodeUrl)) {
		include DISCUZ_ROOT . './source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
		$tomDir = DISCUZ_ROOT . '.' . $imageDir;
		if (!is_dir($tomDir)) {
			mkdir($tomDir, 511, true);
		} else {
			chmod($tomDir, 511);
		}
		QRcode::png($url, $qrcodeUrl, 'H', 5, 2);
	}
	$contentTmp = strip_tags($content);
	$contentTmp = str_replace("\r\n", '', $contentTmp);
	$contentTmp = str_replace("\n", '', $contentTmp);
	$contentTmp = str_replace("\r", '', $contentTmp);
	$shareTitle = $giftInfo['title'] . '-' . $tcyikatongConfig['plugin_name'];
	$shareLogo = $picurl;
	$shareDesc = cutstr($contentTmp, 80, '...');
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=gift&gift_id=' . $giftInfo['id']);
	$lingquAjaxUrl = 'plugin.php?id=tom_tcyikatong:ajax&site=' . $site_id . '&act=lingqu_gift&gift_id=' . $giftInfo['id'] . '&user_id=' . $__UserInfo['id'] . '&formhash=' . FORMHASH;
	$ajaxClicksUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=clicks&tcshop_id=' . $tcshopInfo['id'] . '&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:gift');
} elseif ($_GET['mod'] == 'giftuseslist') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$gift_id = intval($_GET['gift_id']) > 0 ? intval($_GET['gift_id']) : 0;
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_count(' AND gift_id = ' . $gift_id . ' ');
	$usesListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_list(' AND gift_id = ' . $gift_id . ' ', 'ORDER BY add_time DESC,id DESC', $start, $pagesize);
	$usesList = array();
	if (is_array($usesListTmp) && !empty($usesListTmp)) {
		foreach ($usesListTmp as $key => $value) {
			$usesList[$key] = $value;
			$useUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$usesList[$key]['userInfo'] = $useUserInfoTmp;
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=giftuseslist&gift_id=' . $gift_id . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=giftuseslist&gift_id=' . $gift_id . '&page=' . $nextPage;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:giftuseslist');
} elseif ($_GET['mod'] == 'mylist') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$where = ' AND user_id=' . $__UserInfo['id'] . ' ';
	$order = ' ORDER BY id DESC ';
	if ($type == 1) {
		$where .= ' AND status=1 ';
	}
	if ($type == 2) {
		$where .= ' AND (shenhe_status=2 OR shenhe_status=3)';
		$order = ' ORDER BY shenhe_status ASC,id DESC ';
	}
	$count = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_all_count(' ' . $where . ' ');
	$tequanListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_all_list(' ' . $where . ' ', ' ' . $order . ' ', $start, $pagesize);
	$tequanList = array();
	if (is_array($tequanListTmp) && !empty($tequanListTmp)) {
		foreach ($tequanListTmp as $key => $value) {
			$tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
			if (!empty($tcshopInfoTmp)) {
				$shopPowerStatus = 0;
				if ($tcshopInfoTmp['status'] != 1 || $tcshopInfoTmp['shenhe_status'] != 1 || $tcshopInfoTmp['vip_status'] != 1) {
					$updateData = array();
					$updateData['status'] = 0;
					C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->update($value['id'], $updateData);
					$value['status'] = 0;
					$shopPowerStatus = 1;
				}
				if (!preg_match('/^http/', $tcshopInfoTmp['picurl'])) {
					if (strpos($tcshopInfoTmp['picurl'], 'source/plugin/tom_') === false) {
						$tcshopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfoTmp['picurl'];
					} else {
						$tcshopPicurl = $tcshopInfoTmp['picurl'];
					}
				} else {
					$tcshopPicurl = $tcshopInfoTmp['picurl'];
				}
				$overTime = dgmdate($tcshopInfoTmp['vip_time'], 'Y-m-d', $tomSysOffset);
				if (!preg_match('/^http/', $value['picurl'])) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
				$tequanList[$key] = $value;
				$tequanList[$key]['tcshopInfo'] = $tcshopInfoTmp;
				$tequanList[$key]['tcshopInfo']['picurl'] = $tcshopPicurl;
				$tequanList[$key]['tcshopInfo']['overTime'] = $overTime;
				$tequanList[$key]['picurl'] = $picurl;
				$tequanList[$key]['shopPowerStatus'] = $shopPowerStatus;
			}
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=mylist&type=' . $type . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=mylist&type=' . $type . '&page=' . $nextPage;
	$ajaxUpdateStatusUrl = 'plugin.php?id=tom_tcyikatong:ajax&site=' . $site_id . '&act=updateStatus&&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:mylist');
} elseif ($_GET['mod'] == 'tequanuseslist') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$tequan_id = intval($_GET['tq_id']) > 0 ? intval($_GET['tq_id']) : 0;
	$tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_id($tequan_id);
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses')->fetch_all_count(' AND tequan_id = ' . $tequan_id . ' ');
	$usesListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses')->fetch_all_list(' AND tequan_id = ' . $tequan_id . ' ', ' ORDER BY add_time DESC,id DESC ', $start, $pagesize);
	$usesList = array();
	if (is_array($usesListTmp) && !empty($usesListTmp)) {
		foreach ($usesListTmp as $key => $value) {
			$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
			$photoListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses_photo')->fetch_all_list(' AND tequan_uses_id = ' . $value['id'] . ' ', 'ORDER BY id DESC', 0, 100);
			$photoList = array();
			if (is_array($photoListTmp) && !empty($photoListTmp)) {
				foreach ($photoListTmp as $kp => $vp) {
					$photoList[$kp] = $vp;
					if (!preg_match('/^http/', $vp['picurl'])) {
						$photoPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $vp['picurl'];
					} else {
						$photoPicurl = $vp['picurl'];
					}
					$photoList[$kp] = $photoPicurl;
				}
			}
			$usesList[$key] = $value;
			$usesList[$key]['userInfo'] = $userInfo;
			$usesList[$key]['hexiaoUserInfo'] = $hexiaoUserInfo;
			$usesList[$key]['photoList'] = $photoList;
			$usesList[$key]['photoListStr'] = implode('|', $photoList);
			$usesList[$key]['add_time'] = dgmdate($value['add_time'], 'u', '9999', 'm-d H:i');
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=tequanuseslist&tq_id=' . $tequan_id . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=tequanuseslist&tq_id=' . $tequan_id . '&page=' . $nextPage;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:tequanuseslist');
} elseif ($_GET['mod'] == 'mylinglist') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 1;
	$where = ' AND user_id = ' . $__UserInfo['id'] . ' ';
	if ($type == 1) {
		$where .= ' AND status = 0 ';
	}
	if ($type == 2) {
		$where .= ' AND status = 1 ';
	}
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_ling')->fetch_all_count(' ' . $where . ' ');
	$lingListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_ling')->fetch_all_list(' ' . $where . ' ', ' ORDER BY add_time DESC,id DESC ', $start, $pagesize);
	$lingList = array();
	if (is_array($lingListTmp) && !empty($lingListTmp)) {
		foreach ($lingListTmp as $key => $value) {
			$tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_id($value['tequan_id']);
			if ($tequanInfo['status'] == 1) {
				$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
				$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tequanInfo['tcshop_id']);
				if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
					if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === false) {
						$tcshopInfo['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
					}
				}
				$lingList[$key] = $value;
				$lingList[$key]['userInfo'] = $userInfo;
				$lingList[$key]['tequanInfo'] = $tequanInfo;
				$lingList[$key]['tcshopInfo'] = $tcshopInfo;
				$lingList[$key]['add_time'] = dgmdate($value['add_time'], 'u', '9999', 'm-d H:i');
			}
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=mylinglist&page=' . $prePage . '&type=' . $type;
	$nextPageUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=mylinglist&page=' . $nextPage . '&type=' . $type;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:mylinglist');
} elseif ($_GET['mod'] == 'mygiftlist') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$where = 'AND user_id = ' . $__UserInfo['id'];
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_count($where);
	$giftUsesListTmp = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_list($where, ' ORDER BY add_time DESC,id DESC ', $start, $pagesize);
	$giftUsesList = array();
	if (is_array($giftUsesListTmp) && !empty($giftUsesListTmp)) {
		foreach ($giftUsesListTmp as $key => $value) {
			$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
			$giftInfo = C::t('#tom_tcyikatong#tom_tcyikatong_gift')->fetch_by_id($value['gift_id']);
			$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($giftInfo['tcshop_id']);
			if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
				if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === false) {
					$tcshopInfo['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
				}
			}
			$giftInfo['picurl'] = $tcshopInfo['picurl'];
			$giftUsesList[$key] = $value;
			$giftUsesList[$key]['userInfo'] = $userInfo;
			$giftUsesList[$key]['hexiaoUserInfo'] = $hexiaoUserInfo;
			$giftUsesList[$key]['giftInfo'] = $giftInfo;
			$giftUsesList[$key]['tcshopInfo'] = $tcshopInfo;
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=mygiftlist&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=mygiftlist&page=' . $nextPage;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:mygiftlist');
} elseif ($_GET['mod'] == 'shophexiao') {
	$tequan_id = intval($_GET['tq_id']) > 0 ? intval($_GET['tq_id']) : 0;
	$user_id = intval($_GET['user_id']) > 0 ? intval($_GET['user_id']) : 0;
	$act = isset($_GET['act']) ? addslashes($_GET['act']) : '';
	$week = dgmdate($_G['timestamp'], 'N', $tomSysOffset);
	$day = intval(date('d', strtotime(dgmdate($_G['timestamp'], 'Y-m-d H:i:s', $tomSysOffset))));
	if (empty($tequan_id) || empty($user_id)) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$tequanInfo = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_by_id($tequan_id);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tequanInfo['tcshop_id']);
	$xfUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
	$useNum = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses')->fetch_all_sum_num(' AND tequan_id = ' . $tequan_id . ' AND user_id = ' . $user_id . ' AND uses_time = ' . $nowDayTime . ' ');
	$useNum = intval($useNum);
	$todayNum = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses')->fetch_all_sum_num(' AND tequan_id = ' . $tequan_id . ' AND uses_time = ' . $nowDayTime . ' ');
	$todayNum = intval($todayNum);
	if ($tequanInfo['type'] == 1) {
		$weeksInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_weeks')->fetch_all_list(' AND tequan_id = ' . $tequan_id . ' AND week = ' . $week . ' ', 'ORDER BY id DESC', 0, 1);
	} elseif ($tequanInfo['type'] == 2) {
		$daysInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_days')->fetch_all_list(' AND tequan_id = ' . $tequan_id . ' AND day = ' . $day . ' ', 'ORDER BY id DESC', 0, 1);
	}
	$zhekouStatus = 0;
	if ($tcyikatongConfig['open_putong_zhekou'] == 1 && $tequanInfo['open_putong_zhekou'] == 1) {
		$zhekouStatus = 1;
	}
	if ($tequanInfo['type'] == 1) {
		if (is_array($weeksInfoTmp) && !empty($weeksInfoTmp[0])) {
			$zhekouStatus = 2;
		}
	} elseif ($tequanInfo['type'] == 2) {
		if (is_array($daysInfoTmp) && !empty($daysInfoTmp[0])) {
			$zhekouStatus = 2;
		}
	}
	if ($act == 'heixiao' && $_GET['formhash'] == FORMHASH) {
		if ('utf-8' != CHARSET) {
			if (!defined('IN_MOBILE')) {
				foreach ($_POST as $pk => $pv) {
					if (!is_numeric($pv)) {
						$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
					}
				}
			}
		}
		$num = intval($_GET['num']) > 0 ? intval($_GET['num']) : 0;
		$price = intval($_GET['price']) > 0 ? floatval($_GET['price']) : 0;
		$beizu = isset($_GET['beizu']) ? addslashes($_GET['beizu']) : '';
		$photoArr = array();
		if (is_array($_GET['photo']) && !empty($_GET['photo'])) {
			foreach ($_GET['photo'] as $key => $value) {
				$photoArr[] = addslashes($value);
			}
		}
		if (empty($tequan_id) || empty($user_id)) {
			echo 301;
			exit(0);
		}
		if ($__UserInfo['id'] != $tcshopInfo['user_id']) {
			$tcshopClerkInfo = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(' AND tcshop_id = ' . $tcshopInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
			if (!is_array($tcshopClerkInfo) || empty($tcshopClerkInfo[0])) {
				echo 302;
				exit(0);
			}
		}
		if ($zhekouStatus == 0) {
			echo 303;
			exit(0);
		}
		if ($num + $useNum > $tequanInfo['xianzhi_num'] && $zhekouStatus == 2) {
			echo 304;
			exit(0);
		}
		if ($tequanInfo['today_num'] > 0) {
			if ($num + $todayNum > $tequanInfo['today_num']) {
				echo 305;
				exit(0);
			}
		}
		$insertData = array();
		$insertData['site_id'] = $site_id;
		$insertData['tequan_id'] = $tequan_id;
		$insertData['user_id'] = $user_id;
		$insertData['card_id'] = $__CardInfo['id'];
		$insertData['hexiao_user_id'] = $__UserInfo['id'];
		$insertData['num'] = $num;
		$insertData['price'] = $price;
		$insertData['beizu'] = $beizu;
		$insertData['uses_time'] = $nowDayTime;
		$insertData['add_time'] = TIMESTAMP;
		if (C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses')->insert($insertData)) {
			$tequanUsesId = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses')->insert_id();
			if (is_array($photoArr) && !empty($photoArr)) {
				foreach ($photoArr as $key => $value) {
					$insertData = array();
					$insertData['tequan_uses_id'] = $tequanUsesId;
					$insertData['picurl'] = $value;
					$insertData['add_time'] = TIMESTAMP;
					C::t('#tom_tcyikatong#tom_tcyikatong_tequan_uses_photo')->insert($insertData);
				}
			}
			$tequanLingInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_tequan_ling')->fetch_all_list(' AND tequan_id = ' . $tequan_id . ' AND user_id = ' . $user_id . ' AND status=0 ', 'ORDER BY id DESC', 0, 1);
			if (is_array($tequanLingInfoTmp) && !empty($tequanLingInfoTmp[0]) && $tequanLingInfoTmp[0]['id'] > 0) {
				$updateData = array();
				$updateData['tequan_uses_id'] = $tequanUsesId;
				$updateData['status'] = 1;
				$updateData['uses_time'] = TIMESTAMP;
				C::t('#tom_tcyikatong#tom_tcyikatong_tequan_ling')->update($tequanLingInfoTmp[0]['id'], $updateData);
			}
			$toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfo['user_id']);
			$tcyikatong_shop_hexiao_msg = str_replace('{NAME}', $xfUserInfo['nickname'], lang('plugin/tom_tcyikatong', 'tcyikatong_shop_hexiao_msg'));
			include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/templatesms.class.php';
			$access_token = $weixinClass->get_access_token();
			if ($access_token && !empty($toUser['openid'])) {
				$templateSmsClass = new templateSms($access_token, $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $tcshopInfo['site_id'] . '&mod=tequanuseslist&tq_id=' . $tequan_id));
				$smsData = array('first' => $tcyikatong_shop_hexiao_msg, 'keyword1' => $tongchengConfig['plugin_name'], 'keyword2' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s', $tomSysOffset), 'remark' => '');
				@($r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData));
			}
		}
		echo 200;
		exit(0);
	}
	$hexiaoPowerStatus = 0;
	if ($__UserInfo['id'] == $tcshopInfo['user_id']) {
		$hexiaoPowerStatus = 1;
	}
	$tcshopClerkInfo = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(' AND tcshop_id = ' . $tcshopInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
	if (is_array($tcshopClerkInfo) && !empty($tcshopClerkInfo[0])) {
		$hexiaoPowerStatus = 1;
	}
	if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
		if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === false) {
			$shopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
		} else {
			$shopPicurl = $tcshopInfo['picurl'];
		}
	} else {
		$shopPicurl = $tcshopInfo['picurl'];
	}
	$hexiaoUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=shophexiao&formhash=' . $formhash;
	$uploadUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=upload&act=photo&formhash=' . FORMHASH;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:shophexiao');
} elseif ($_GET['mod'] == 'gifthexiao') {
	$gift_id = intval($_GET['gift_id']) > 0 ? intval($_GET['gift_id']) : 0;
	$user_id = intval($_GET['user_id']) > 0 ? intval($_GET['user_id']) : 0;
	$act = isset($_GET['act']) ? addslashes($_GET['act']) : '';
	if (empty($gift_id) || empty($user_id)) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$giftInfo = C::t('#tom_tcyikatong#tom_tcyikatong_gift')->fetch_by_id($gift_id);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($giftInfo['tcshop_id']);
	$xfUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
	$hexiaoPowerStatus = 0;
	if ($__UserInfo['id'] == $tcshopInfo['user_id']) {
		$hexiaoPowerStatus = 1;
	}
	$tcshopClerkInfo = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(' AND tcshop_id = ' . $tcshopInfo['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
	if (is_array($tcshopClerkInfo) && !empty($tcshopClerkInfo[0])) {
		$hexiaoPowerStatus = 1;
	}
	if ($act == 'heixiao' && $_GET['formhash'] == FORMHASH) {
		if ('utf-8' != CHARSET) {
			if (!defined('IN_MOBILE')) {
				foreach ($_POST as $pk => $pv) {
					if (!is_numeric($pv)) {
						$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
					}
				}
			}
		}
		$beizu = isset($_GET['beizu']) ? addslashes($_GET['beizu']) : '';
		if (empty($gift_id) || empty($user_id)) {
			echo 301;
			exit(0);
		}
		if ($hexiaoPowerStatus == 0) {
			echo 302;
			exit(0);
		}
		$giftUsesInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_list(' AND user_id = ' . $user_id . ' AND gift_id = ' . $gift_id . ' AND status = 0 ', 'ORDER BY id DESC', 0, 1);
		if (!is_array($giftUsesInfoTmp) || empty($giftUsesInfoTmp[0])) {
			echo 303;
			exit(0);
		}
		$updateData = array();
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['beizu'] = $beizu;
		$updateData['status'] = 1;
		$updateData['use_time'] = TIMESTAMP;
		C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->update($giftUsesInfoTmp[0]['id'], $updateData);
		echo 200;
		exit(0);
	}
	if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
		if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_') === false) {
			$shopPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
		} else {
			$shopPicurl = $tcshopInfo['picurl'];
		}
	} else {
		$shopPicurl = $tcshopInfo['picurl'];
	}
	$djs = ($giftInfo['end_time'] - TIMESTAMP) * 1000;
	$usesStatusBtn = 0;
	$giftUsesInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_gift_uses')->fetch_all_list(' AND user_id = ' . $user_id . ' AND gift_id = ' . $gift_id . ' AND status = 0 ', 'ORDER BY id DESC', 0, 1);
	if (is_array($giftUsesInfoTmp) && !empty($giftUsesInfoTmp[0]) && $giftUsesInfoTmp[0]['id'] > 0) {
		$usesStatusBtn = 1;
	}
	$hexiaoUrl = 'plugin.php?id=tom_tcyikatong&mod=gifthexiao&site=' . $site_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcyikatong:gifthexiao');
} elseif ($_GET['mod'] == 'ruzhu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcyikatong/module/ruzhu.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcyikatong/module/edit.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tcyikatong/module/upload.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();