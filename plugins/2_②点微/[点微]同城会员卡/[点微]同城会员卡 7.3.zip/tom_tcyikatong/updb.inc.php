<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/plugin');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $sql = '';
    
    $tom_tcyikatong_tequan_field = C::t('#tom_tcyikatong#tom_tcyikatong_tequan')->fetch_all_field();
    if (!isset($tom_tcyikatong_tequan_field['tequan_type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_tequan` ADD `tequan_type` int(11) DEFAULT '1';\n";
    }
    if (!isset($tom_tcyikatong_tequan_field['tequan_shengprice'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_tequan` ADD `tequan_shengprice` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcyikatong_tequan_field['tequan_shenglimit'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_tequan` ADD `tequan_shenglimit` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcyikatong_tequan_field['putong_shengprice'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_tequan` ADD `putong_shengprice` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcyikatong_tequan_field['putong_shenglimit'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_tequan` ADD `putong_shenglimit` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcyikatong_tequan_field['today_num'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_tequan` ADD `today_num` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcyikatong_tequan_field['paixu'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_tequan` ADD `paixu` int(11) DEFAULT '10000';\n";
    }
    
    $tom_tcyikatong_card_type_field = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_all_field();
    if (!isset($tom_tcyikatong_card_type_field['max_num'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_card_type` ADD `max_num` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcyikatong_card_type_field['picurl'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_card_type` ADD `picurl` varchar(255) DEFAULT NULL;\n";
    }
    
    $tom_tcyikatong_gift_field = C::t('#tom_tcyikatong#tom_tcyikatong_gift')->fetch_all_field();
    if (!isset($tom_tcyikatong_gift_field['card_type_ids'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_gift` ADD `card_type_ids` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcyikatong_gift_field['paixu'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_gift` ADD `paixu` int(11) DEFAULT '100';\n";
    }
    
    $tom_tcyikatong_order_field = C::t('#tom_tcyikatong#tom_tcyikatong_order')->fetch_all_field();
    if (!isset($tom_tcyikatong_order_field['tj_hehuoren_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_order` ADD `tj_hehuoren_id` int(11) DEFAULT '0';\n";
    }
    
    $tom_tcyikatong_card_field = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_all_field();
    if (!isset($tom_tcyikatong_card_field['gift_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tcyikatong_card` ADD `gift_status` int(11) DEFAULT '1';\n";
    }
    
    if (!empty($sql)) {
        runquery($sql);
    }
    
    $sql = <<<EOF
    CREATE TABLE IF NOT EXISTS `pre_tom_tcyikatong_fabu_log` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` int(11) DEFAULT '0',
      `time_key` int(11) DEFAULT '0',
      `add_time` int(11) DEFAULT '0',
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_tcyikatong_tequan_ling` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `site_id` int(11) DEFAULT '1',
      `tequan_id` int(11) DEFAULT '0',
      `user_id` int(11) DEFAULT '0',
      `tequan_uses_id` int(11) DEFAULT '0',
      `status` int(11) DEFAULT '0',
      `uses_time` int(11) DEFAULT '0',
      `add_time` int(11) DEFAULT '0',
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
EOF;

    runquery($sql);

    echo 'OK';exit;
    
}else{
    exit('Access Denied');
}



