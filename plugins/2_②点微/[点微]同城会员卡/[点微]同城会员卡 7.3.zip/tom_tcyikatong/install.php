<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcyikatong_autoid`;
CREATE TABLE `pre_tom_tcyikatong_autoid` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_card`;
CREATE TABLE `pre_tom_tcyikatong_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_type_id` int(11) DEFAULT '0',
  `card_no` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `expire_time` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `gift_status` int(11) DEFAULT '1',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_card_number` (`card_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_card_code`;
CREATE TABLE `pre_tom_tcyikatong_card_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_type_id` int(11) DEFAULT '0',
  `code` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `card_no` varchar(255) DEFAULT NULL,
  `use_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_card_log`;
CREATE TABLE `pre_tom_tcyikatong_card_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `card_id` int(11) DEFAULT '0',
  `order_no` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `card_type_id` int(11) DEFAULT '0',
  `card_type_name` varchar(255) DEFAULT NULL,
  `card_type_days` int(11) DEFAULT '0',
  `code` varchar(255) DEFAULT NULL,
  `log_type` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_card_type`;
CREATE TABLE `pre_tom_tcyikatong_card_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `days` int(11) DEFAULT '0',
  `max_num` int(11) DEFAULT '0',
  `content` text,
  `add_time` int(11) DEFAULT '0',
  `tsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_common`;
CREATE TABLE `pre_tom_tcyikatong_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ruzhu_xieyi_txt` text,
  `open_card_txt` text,
  `info_use_txt` text,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcyikatong_fabu_log`;
CREATE TABLE `pre_tom_tcyikatong_fabu_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `time_key` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_gift`;
CREATE TABLE `pre_tom_tcyikatong_gift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `card_type_id` int(11) DEFAULT '0',
  `card_type_ids` varchar(255) DEFAULT NULL,
  `tcshop_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `num` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `guize` text,
  `content` text,
  `status` int(11) DEFAULT '0',
  `end_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '100',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_gift_uses`;
CREATE TABLE `pre_tom_tcyikatong_gift_uses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_type_id` int(11) DEFAULT '0',
  `gift_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `card_id` int(11) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `beizu` text,
  `status` int(11) DEFAULT '0',
  `use_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_order`;
CREATE TABLE `pre_tom_tcyikatong_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `order_no` varchar(255) DEFAULT NULL,
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `card_id` int(11) DEFAULT '0',
  `card_type_id` int(11) DEFAULT '0',
  `card_type_name` varchar(255) DEFAULT NULL,
  `card_type_days` int(11) DEFAULT '0',
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `pay_time` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `order_status` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_tequan`;
CREATE TABLE `pre_tom_tcyikatong_tequan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tcshop_id` int(11) DEFAULT '0',
  `tcshop_cate_id` int(11) DEFAULT '0',
  `tcshop_cate_child_id` int(11) DEFAULT '0',
  `tcshop_latitude` varchar(255) DEFAULT NULL,
  `tcshop_longitude` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '1',
  `weeks` varchar(255) DEFAULT NULL,
  `days` varchar(255) DEFAULT NULL,
  `xianzhi_num` int(11) DEFAULT '0',
  `today_num` int(11) DEFAULT '0',
  `tequan_type` int(11) DEFAULT '1',
  `tequan_zhekou` varchar(255) DEFAULT NULL,
  `tequan_shengprice` int(11) DEFAULT '0',
  `tequan_shenglimit` int(11) DEFAULT '0',
  `open_putong_zhekou` int(11) DEFAULT '0',
  `putong_zhekou` varchar(255) DEFAULT NULL,
  `putong_shengprice` int(11) DEFAULT '0',
  `putong_shenglimit` int(11) DEFAULT '0',
  `guize` text,
  `content` text,
  `shenhe_status` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `lbs_id` int(11) unsigned DEFAULT '0',
  `lbs_status` int(11) DEFAULT '0',
  `lbs_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '10000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_tequan_days`;
CREATE TABLE `pre_tom_tcyikatong_tequan_days` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tequan_id` int(11) DEFAULT '0',
  `day` int(11) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_tequan_uses`;
CREATE TABLE `pre_tom_tcyikatong_tequan_uses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tequan_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `card_id` int(11) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `num` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `beizu` text,
  `uses_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_tequan_uses_photo`;
CREATE TABLE `pre_tom_tcyikatong_tequan_uses_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tequan_uses_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_tequan_weeks`;
CREATE TABLE `pre_tom_tcyikatong_tequan_weeks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tequan_id` int(11) DEFAULT '0',
  `week` int(11) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcyikatong_tequan_ling`;
CREATE TABLE `pre_tom_tcyikatong_tequan_ling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tequan_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `tequan_uses_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `uses_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;