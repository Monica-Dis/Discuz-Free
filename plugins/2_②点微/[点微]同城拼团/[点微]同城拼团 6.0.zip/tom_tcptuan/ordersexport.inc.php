<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tomSysOffset = getglobal('setting/timeoffset');
$tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/config/config.utf8.php';
}

$page           = isset($_GET['page'])? intval($_GET['page']):1;
$goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
$order_no       = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
$order_tel      = !empty($_GET['order_tel'])? trim(addslashes($_GET['order_tel'])):'';
$order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;
$order_type     = isset($_GET['order_type'])? intval($_GET['order_type']):0;
$tuan_id        = isset($_GET['tuan_id'])? intval($_GET['tuan_id']):0;
$tuan_status    = isset($_GET['tuan_status'])? intval($_GET['tuan_status']):0;

$pagesize = 10000;
$start = ($page-1)*$pagesize;


if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $where = "";
    if(!empty($goods_id)){
        $where.=" AND goods_id={$goods_id} ";
    }
    if(!empty($order_no)){
        $where.=" AND order_no='{$order_no}' ";
    }
    if(!empty($order_tel)){
        $where.=" AND tel='{$order_tel}' ";
    }
    if(!empty($order_status)){
        $where.=" AND order_status={$order_status} ";
    }
    if(!empty($order_type)){
        $where.=" AND order_type={$order_type} ";
    }
    if(!empty($tuan_id)){
        $where.=" AND tuan_id={$tuan_id} ";
    }
    if($tuan_status){
        $where.= " AND tuan_status={$tuan_status} ";
    }
    $ordersListTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_like_list($where,"ORDER BY order_time DESC",$start,$pagesize,'');
    $orderList = array();
    foreach ($ordersListTmp as $key => $value) {
        $orderList[$key] = $value;
        
        if($value['option_id'] > 0){
            $orderList[$key]['goods_name'] = $value['goods_name'] .'('.$value['option_name'].')';
        }
        
        if($value['order_type'] == 1 || $value['order_type'] == 2){
            $orderList[$key]['order_type'] = $order_typeArray[$value['order_type']]."(".$tuanStatusArray[$value['tuan_status']].")";
        }else{
            $orderList[$key]['order_type'] = $order_typeArray[$value['order_type']];
        }
        $orderList[$key]['order_status'] = $orderStatusArray[$value['order_status']];
        if($value['peisong_type'] == 1){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tcptuan','goods_peisong_type_1');
        }else if($value['peisong_type'] == 2){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tcptuan','goods_peisong_type_2');
        }else if($value['peisong_type'] == 3){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tcptuan','goods_peisong_type_3');
        }
        $orderList[$key]['order_time'] = dgmdate($value['order_time'],"Y-m-d H:i:s",$tomSysOffset);
        if($value['hexiao_time'] > 0){
            $orderList[$key]['hexiao_time'] = dgmdate($value['hexiao_time'],"Y-m-d H:i:s",$tomSysOffset);
        }else{
            $orderList[$key]['hexiao_time'] = '-';
        }
        
    }

    $order_order_type = lang('plugin/tom_tcptuan','order_order_type');
    $order_tuan_id = lang('plugin/tom_tcptuan','tuan_id');
    $order_order_no = lang('plugin/tom_tcptuan','order_order_no');
    $goods_id = lang('plugin/tom_tcptuan','goods_id');
    $order_goods_name = lang('plugin/tom_tcptuan','order_goods_name');
    $order_goods_num = lang('plugin/tom_tcptuan','order_goods_num');
    $order_goods_price = lang('plugin/tom_tcptuan','order_goods_price');
    $order_pay_price = lang('plugin/tom_tcptuan','order_pay_price');
    $user_id = lang('plugin/tom_tcptuan','user_id');
    $order_user_openid = lang('plugin/tom_tcptuan','order_user_openid');
    $order_xm = lang('plugin/tom_tcptuan','order_xm');
    $order_tel = lang('plugin/tom_tcptuan','order_tel');
    $order_address = lang('plugin/tom_tcptuan','order_address');
    $order_order_beizu = lang('plugin/tom_tcptuan','order_order_beizu');
    $order_order_status = lang('plugin/tom_tcptuan','order_order_status');
    $goods_peisong_type = lang('plugin/tom_tcptuan','goods_peisong_type');
    $order_peisong_info = lang('plugin/tom_tcptuan','order_peisong_info');
    $order_order_time = lang('plugin/tom_tcptuan','order_order_time');
    $order_hexiao_time = lang('plugin/tom_tcptuan','order_hexiao_time');

    $listData[] = array(
        $order_order_type,
        $order_tuan_id,
        $order_order_no,
        $goods_id,
        $order_goods_name,
        $order_goods_num,
        $order_goods_price,
        $order_pay_price,
        $user_id,
        $order_user_openid,
        $order_xm,
        $order_tel,
        $order_address,
        $order_order_beizu,
        $order_order_status,
        $goods_peisong_type,
        $order_peisong_info,
        $order_order_time,
        $order_hexiao_time,
    ); 
    foreach ($orderList as $v){
        $lineData = array();
        $lineData[] = $v['order_type'];
        $lineData[] = $v['tuan_id'];
        $lineData[] = $v['order_no'];
        $lineData[] = $v['goods_id'];
        $lineData[] = $v['goods_name'];
        $lineData[] = $v['goods_num'];
        $lineData[] = $v['goods_price'];
        $lineData[] = $v['pay_price'];
        $lineData[] = $v['user_id'];
        $lineData[] = $v['user_openid'];
        $lineData[] = $v['xm'];
        $lineData[] = $v['tel'];
        $v['address'] = str_replace("\r\n", "", $v['address']);
        $v['address'] = str_replace("\n", "", $v['address']);
        $lineData[] = $v['address'];
        $lineData[] = $v['order_beizu'];
        $v['order_beizu'] = str_replace("\r\n", "", $v['order_beizu']);
        $v['order_beizu'] = str_replace("\n", "", $v['order_beizu']);
        $lineData[] = $v['order_status'];
        $lineData[] = $v['peisong_type'];
        $v['peisong_info'] = str_replace("\r\n", "", $v['peisong_info']);
        $v['peisong_info'] = str_replace("\n", "", $v['peisong_info']);
        $lineData[] = $v['peisong_info'];
        $lineData[] = $v['order_time'];
        $lineData[] = $v['hexiao_time'];
        
        $listData[] = $lineData;
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=exportOrders.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}