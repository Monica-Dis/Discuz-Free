<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

/**
   1 ��֧�� 2 ��֧����δȷ�� 3 ��ȷ�ϣ�������  4 ������ 5 ��ǩ�� 6 ������ȡ�� 7 �˿����  8 �˿�ɹ�
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

$tcptuanConfig      = $_G['cache']['plugin']['tom_tcptuan'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$act = isset($_GET['act'])? addslashes($_GET['act']):"order";

if($act == "order" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $option_id      = isset($_GET['option_id'])? intval($_GET['option_id']):0;
    $address_id     = isset($_GET['address_id'])? intval($_GET['address_id']):0;
    $order_type     = isset($_GET['order_type'])? intval($_GET['order_type']):0;
    $tuan_id        = isset($_GET['tuan_id'])? intval($_GET['tuan_id']):0;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $goods_num      = intval($_GET['goods_num'])>0? intval($_GET['goods_num']):1;
    $order_xm       = isset($_GET['order_xm'])? daddslashes($_GET['order_xm']):'';
    $order_tel      = isset($_GET['order_tel'])? daddslashes($_GET['order_tel']):'';
    $order_beizu    = isset($_GET['order_beizu'])? daddslashes($_GET['order_beizu']):'';
    $tj_hehuoren_id = isset($_GET['tj_hehuoren_id'])? intval($_GET['tj_hehuoren_id']):0;

    $addressInfo = array('xm'=>'','tel'=>'','area_str'=>'','info'=>'');
    
    $goodsInfo  = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);
    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
    if($address_id){
        $addressInfo = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
    }
    
    if(!$goodsInfo || !$userInfo || empty($tcshopInfo)){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!empty($goodsInfo['end_time']) && $goodsInfo['end_time'] < TIMESTAMP){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
   
    if($goodsInfo['hasoption'] == 1){
        $optionInfo = C::t('#tom_tcptuan#tom_tcptuan_goods_option')->fetch_by_id($option_id);
        if($optionInfo['id'] > 0){
            $saleNumCount = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND option_id = {$option_id} AND goods_id={$goods_id} AND order_status IN(2,3,4,5) ");
            $stock_num    = $optionInfo['stock_num'];
            $tuan_price   = $optionInfo['tuan_price'];
            $tuanz_price  = $optionInfo['tuanz_price'];
            $one_price    = $optionInfo['one_price'];
        }else{
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $stock_num    = $goodsInfo['stock_num'];
        $saleNumCount = $goodsInfo['sale_num'];
        $tuan_price   = $goodsInfo['tuan_price'];
        $tuanz_price  = $goodsInfo['tuanz_price'];
        $one_price    = $goodsInfo['one_price'];
    }
    
    if($stock_num <= $saleNumCount){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    if($goods_num > ($stock_num - $saleNumCount)){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['status'] != 1 || $goodsInfo['shenhe_status'] != 1){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    $tuan_num       = $goodsInfo['tuan_num'];
    if($order_type == 1 || $order_type == 2){
        $goods_price    = $tuan_price;
    }else{
        $goods_price    = $one_price;
    }
    
    if($order_type == 1){
        if($goodsInfo['tuanz_status'] == 1 && $tuanz_price > 0){
            $goods_price = $tuanz_price;
        }
    }
    
    if($goodsInfo['open_ding_pay'] == 1 && $goodsInfo['ding_price'] > 0){
        $goods_price = $goodsInfo['ding_price'];
    }
    
    $express_price = $goodsInfo['express_price'];
    if($goodsInfo['peisong_type'] == 1 || $goodsInfo['express_type'] == 1){
        $express_price = 0;
    }
    
    if($goodsInfo['express_type'] == 3){
        $pay_price = $express_price*$goods_num+$goods_price*$goods_num;
    }else if($goodsInfo['express_type'] == 2){
        $pay_price = $express_price+$goods_price*$goods_num;
    }else{
        $pay_price = $goods_price*$goods_num;
    }
    
    if($order_type == 2 && $tuan_id){
        $tuanTeamListTmp = C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->fetch_all_list(" AND tuan_id={$tuan_id} AND type_id=2 ","ORDER BY id ASC",0,500);
        $tuanTeamListCount = 1;
        if(is_array($tuanTeamListTmp) && !empty($tuanTeamListTmp)){
            foreach ($tuanTeamListTmp as $key => $value){
                $orderinfoTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($value['order_id']);
                if($orderinfoTmp['order_status'] == 2 || $orderinfoTmp['order_status'] == 3 || $orderinfoTmp['order_status'] == 4 || $orderinfoTmp['order_status'] == 5){
                    $tuanTeamListCount++;
                }
            }
        }
        if($tuan_num <= $tuanTeamListCount){
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($goodsInfo['xiangou_num'] > 0){
        $sun_goods_num = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND user_id={$user_id} AND goods_id={$goods_id} AND order_status IN(2,3,4,5) ");
        $new_sun_goods_num = $sun_goods_num + $goods_num;
        if( $new_sun_goods_num > $goodsInfo['xiangou_num']){
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $tuanInfo = array();
    if($order_type == 1){
        $insertData = array();
        $insertData['site_id']           = $site_id;
        $insertData['goods_id']          = $goods_id;
        $insertData['user_id']           = $user_id;
        $insertData['tuan_time']         = TIMESTAMP;
        $insertData['tuan_status']       = 1;
        if(C::t('#tom_tcptuan#tom_tcptuan_tuan')->insert($insertData)){
            $tuan_id  = C::t('#tom_tcptuan#tom_tcptuan_tuan')->insert_id();
            $tuanInfo = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_by_id($tuan_id);
        }
    }else if($order_type == 2){
        $tuanInfo = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_by_id($tuan_id);
    }

    if($order_type == 1 || $order_type == 2){
        if(!$tuanInfo){
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $openid     = $userInfo['openid'];
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    $hexiao_no  = date("YmdHis")."-".mt_rand(111111, 666666);
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
    $insertData['tcshop_id']        = $tcshopInfo['id'];
    $insertData['order_type']       = $order_type;
    $insertData['order_no']         = $order_no;
    $insertData['hexiao_no']        = $hexiao_no;
    $insertData['goods_id']         = $goods_id;
    $insertData['peisong_type']     = $goodsInfo['peisong_type'];
    $insertData['goods_name']       = $goodsInfo['name'];
    $insertData['goods_num']        = $goods_num;
    $insertData['goods_price']      = $goods_price;
    if($goodsInfo['hasoption'] == 1){
        $insertData['option_id']      = $optionInfo['id'];
        $insertData['option_name']    = $optionInfo['name'];
    }
    $insertData['pay_price']        = $pay_price;
    $insertData['user_id']          = $user_id;
    $insertData['user_nickname']    = $userInfo['nickname'];
    $insertData['user_openid']      = $openid;
    if($address_id > 0 && $goodsInfo['peisong_type'] == 2){
        $insertData['address_id']   = $address_id;
    }
    if($goodsInfo['peisong_type'] == 2 || $goodsInfo['peisong_type'] == 3){
        $insertData['xm']             = $addressInfo['xm'];
        $insertData['tel']            = $addressInfo['tel'];
        $insertData['address']        = $addressInfo['area_str']." ".$addressInfo['info'];  
    }else{
        $insertData['xm']           = $order_xm;
        $insertData['tel']          = $order_tel;
        $insertData['address']      = '';
    }
    $insertData['tuan_id']          = $tuan_id;
    $insertData['tuan_status']      = 1;
    $insertData['order_beizu']      = $order_beizu;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcptuan#tom_tcptuan_order')->insert($insertData)){
        $order_id = C::t('#tom_tcptuan#tom_tcptuan_order')->insert_id();

        DB::query("UPDATE ".DB::table('tom_tcptuan_goods')." SET sale_num=sale_num+{$goods_num} WHERE id='$goods_id'", 'UNBUFFERED');

        if($order_type == 1 || $order_type == 2){
            $tuanUserTeamTmp = C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->fetch_by_tuan_user_id($tuan_id,$__UserInfo['id']);
            if($tuanUserTeamTmp){
                $updateData['order_id'] = $order_id;
                $updateData['add_time'] = TIMESTAMP;
                C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->update($tuanUserTeamTmp['id'],$updateData);
            }else{
                $insertData = array();
                $insertData['tuan_id']          = $tuan_id;
                $insertData['goods_id']         = $goods_id;
                $insertData['order_id']         = $order_id;
                $insertData['user_id']          = $user_id;
                if($order_type == 1){
                    $insertData['type_id']      = 1;
                }else{
                    $insertData['type_id']      = 2;
                }
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->insert($insertData);
            }
        }
        
        $pay_hosts = '';
        if($tcptuanConfig['open_only_hosts'] == 1 && !empty($tcptuanConfig['tongcheng_hosts']) && !empty($tcptuanConfig['ptuan_hosts'])){
            if(strpos($_G['siteurl'],$tcptuanConfig['tongcheng_hosts']) === FALSE && strpos($_G['siteurl'],$tcptuanConfig['ptuan_hosts']) !== FALSE){
                $pay_hosts = str_replace($tcptuanConfig['ptuan_hosts'], $tcptuanConfig['tongcheng_hosts'], $_G['siteurl']);
                if($tcptuanConfig['must_http'] == 1){
                    if(strpos($pay_hosts,'https') === FALSE){
                        $pay_hosts = str_replace("http", "https", $pay_hosts);
                    }
                }
            }
        }
        
        $insertData = array();
        $insertData['plugin_id']       = 'tom_tcptuan';          
        $insertData['order_no']        = $order_no;                 
        $insertData['goods_id']        = $goodsInfo['id'];         
        $insertData['goods_name']      = $goodsInfo['name'];      
        $insertData['goods_beizu']     = $goodsInfo['name'];
        $insertData['goods_url']       = 'plugin.php?id=tom_tcptuan&site='.$site_id.'&mod=goodsinfo&goods_id='.$goodsInfo['id'];
        if($order_type == 1 || $order_type == 2){
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcptuan&site='.$site_id.'&mod=tuan&tuan_id='.$tuan_id;
        }else{
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcptuan&site='.$site_id.'&mod=order';
        }
        $insertData['fail_back_url']   = "plugin.php?id=tom_tcptuan&site={$site_id}&mod=order"; 
        if($tcptuanConfig['open_alipay'] == 1){
            $insertData['allow_alipay']    = 1;    
        }else{
            $insertData['allow_alipay']    = 0;    
        }
        $insertData['pay_price']       = $pay_price;  
        $insertData['order_status']    = 1;             
        $insertData['add_time']        = TIMESTAMP;     
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'    => 200,
                'payurl' => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 308,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 307,
        );
        echo json_encode($outArr); exit;
    }

}else if($act == "pay" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $order_id   = isset($_GET['order_id'])? intval($_GET['order_id']):0;
    
    $orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($order_id);
    
    if($orderInfo && $orderInfo['order_status'] == 1){
        
        $goodsInfo  = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($orderInfo['goods_id']);
        
        $tuanInfo = array();
        if($orderInfo['tuan_id']){
            $tuanInfo = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_by_id($orderInfo['tuan_id']);
        }
        
        if($orderInfo['order_type'] == 2 && $tuanInfo){
            $tuanTeamListTmp = C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->fetch_all_list(" AND tuan_id={$orderInfo['tuan_id']} AND type_id=2 ","ORDER BY id ASC",0,500);
            $tuanTeamListCount = 1;
            if(is_array($tuanTeamListTmp) && !empty($tuanTeamListTmp)){
                foreach ($tuanTeamListTmp as $key => $value){
                    $orderinfoTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($value['order_id']);
                    if($orderinfoTmp['order_status'] == 2 || $orderinfoTmp['order_status'] == 3 || $orderinfoTmp['order_status'] == 4 || $orderinfoTmp['order_status'] == 5){
                        $tuanTeamListCount++;
                    }
                }
            }
            if($goodsInfo['tuan_num'] <= $tuanTeamListCount){
                DB::query("UPDATE ".DB::table('tom_tcptuan_goods')." SET sale_num=sale_num-{$orderInfo['goods_num']} WHERE id='{$orderInfo['goods_id']}'", 'UNBUFFERED');
                DB::query("UPDATE ".DB::table('tom_tcptuan_order')." SET order_status=6 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
                $outArr = array(
                    'status'=> 301,
                );
                echo json_encode($outArr); exit;
            }
        }
        
        if($goodsInfo['xiangou_num'] > 0){
            $sun_goods_num = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND user_id={$orderInfo['user_id']} AND goods_id={$orderInfo['goods_id']} AND order_status IN(2,3,4,5) ");
            $new_sun_goods_num = $sun_goods_num + $orderInfo['goods_num'];
            if( $new_sun_goods_num > $goodsInfo['xiangou_num']){
                $outArr = array(
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }
        }
        
        if((TIMESTAMP - $orderInfo['order_time']) > 3590){
            
            DB::query("UPDATE ".DB::table('tom_tcptuan_goods')." SET sale_num=sale_num-{$orderInfo['goods_num']} WHERE id='{$orderInfo['goods_id']}'", 'UNBUFFERED');
            DB::query("UPDATE ".DB::table('tom_tcptuan_order')." SET order_status=6 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
            
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }
        
        $pay_hosts = '';
        if($tcptuanConfig['open_only_hosts'] == 1 && !empty($tcptuanConfig['tongcheng_hosts']) && !empty($tcptuanConfig['ptuan_hosts'])){
            if(strpos($_G['siteurl'],$tcptuanConfig['tongcheng_hosts']) === FALSE && strpos($_G['siteurl'],$tcptuanConfig['ptuan_hosts']) !== FALSE){
                $pay_hosts = str_replace($tcptuanConfig['ptuan_hosts'], $tcptuanConfig['tongcheng_hosts'], $_G['siteurl']);
            }
        }
        
        $outArr = array(
            'status'    => 200,
            'payurl' => $pay_hosts."plugin.php?id=tom_pay&order_no=".$orderInfo['order_no'],
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }

}else if($act == "cancelpay" && $_GET['formhash'] == FORMHASH){
    
    $order_no  = isset($_GET['order_no'])? addslashes($_GET['order_no']):'';

    $orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_order_no($order_no);
    
    if($orderInfo && $orderInfo['order_status'] == 1){
        
        DB::query("UPDATE ".DB::table('tom_tcptuan_goods')." SET sale_num=sale_num-{$orderInfo['goods_num']} WHERE id='{$orderInfo['goods_id']}'", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tcptuan_order')." SET order_status=6 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}