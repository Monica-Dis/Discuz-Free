<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.cn
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tcptuanConfig      = $_G['cache']['plugin']['tom_tcptuan'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset       = getglobal('setting/timeoffset');
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass        = new weixinClass($appid,$appsecret);

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/config/config.utf8.php';
}

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcchoujiang start
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')){
    $tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
    if($tcchoujiangConfig['open_tcchoujiang'] == 1){
        $__ShowTcchoujiang = 1;
    }
}
## tcchoujiang end
## print start
$__ShowPrint = 0;
$printConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_print/tom_print.inc.php')){
    $printConfig = $_G['cache']['plugin']['tom_print'];
    if($printConfig['open_print'] == 1){
        $__ShowPrint = 1;
    }
}
## print end

$orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_order_no($order_no);
if($orderInfo && $orderInfo['order_status'] == 1){
    
    $updateData = array();
    $updateData['order_status'] = 2;
    $updateData['pay_time'] = TIMESTAMP;
    C::t('#tom_tcptuan#tom_tcptuan_order')->update($orderInfo['id'],$updateData);

    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($orderInfo['order_no'])));

    if($orderInfo['order_type'] == 1){
        $tuanInfo = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_by_id($orderInfo['tuan_id']);
        if($tuanInfo && $tuanInfo['tuan_status'] == 1){
            $updateData = array();
            $updateData['tuan_status'] = 2;
            $updateData['tuan_time'] = TIMESTAMP;
            C::t('#tom_tcptuan#tom_tcptuan_tuan')->update($tuanInfo['id'],$updateData);
            $updateData = array();
            $updateData['tuan_status'] = 2;
            C::t('#tom_tcptuan#tom_tcptuan_order')->update($orderInfo['id'],$updateData);
        }
        Log::DEBUG("update tuan:" . json_encode(iconv_to_utf8($tuanInfo['id'])));
    }else if($orderInfo['order_type'] == 2){
        $tuanInfo = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_by_id($orderInfo['tuan_id']);
        if($tuanInfo){
            $updateData = array();
            $updateData['tuan_status'] = $tuanInfo['tuan_status'];
            C::t('#tom_tcptuan#tom_tcptuan_order')->update($orderInfo['id'],$updateData);
        }
    }
    
    $goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($orderInfo['goods_id']);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
    
    if($tcptuanConfig['open_back_score'] == 1){
        
        $score_yuan = $tongchengConfig['score_yuan'];
        if(!empty($tcptuanConfig['score_yuan'])){
            $score_yuan = $tcptuanConfig['score_yuan'];
        }
        
        $score = ceil($orderInfo['pay_price']*$score_yuan);
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] + $score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 11;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    }
    
    if($__ShowTcchoujiang == 1 && $goodsInfo['tcchoujiang_id'] > 0){
        $choujiangInfo    = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($goodsInfo['tcchoujiang_id']);
        if($choujiangInfo['status'] == 1 && $choujiangInfo['shenhe_status'] == 1 && $choujiangInfo['type'] == 3){
            $choujiangBmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($goodsInfo['tcchoujiang_id'],$userInfo['id']);
            if($choujiangBmInfo){
                DB::query("UPDATE ".DB::table('tom_tcchoujiang_bm')." SET cj_times=cj_times+1 WHERE id='".$choujiangBmInfo['id']."' ", 'UNBUFFERED');
            }else{
                $insertData = array();
                $insertData['tcchoujiang_id']          = $goodsInfo['tcchoujiang_id'];
                $insertData['user_id']                 = $userInfo['id'];
                $insertData['xm']                      = $userInfo['nickname'];
                $insertData['tel']                     = $userInfo['tel'];
                $insertData['cj_times']                = 1;
                $insertData['time_key']                = $nowDayTime;
                $insertData['add_time']                = TIMESTAMP;
                C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->insert($insertData);
            }
        }
    }
    
    if($__ShowTchehuoren == 1 && $tcptuanConfig['open_ptuan_hehuoren'] == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/class/function.hehuoren.php';
        add_hehuoren($orderInfo['user_id'], $orderInfo['tj_hehuoren_id']);
    }
    
    if($orderInfo['order_type'] == 3 && $__ShowPrint == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_print/print.func.php';
        @add_ptuan_print($order_no);
        @ptuan_print($order_no);
    }
    
    if($orderInfo['balance_status'] == 0 && $orderInfo['tj_hehuoren_id'] > 0){
        include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/module/yu_balance.php';
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    }
    
    if(!empty($tcptuanConfig['template_neworder'])){
        include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();

        $orderTcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);
        $orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderTcshopInfoTmp['user_id']); 

        if($access_token && !empty($orderUserInfoTmp['openid']) ){
            $templateSmsClass = new ptTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site=".$orderInfo['site_id']."&mod=personal&act=shop");
            $smsData = array(
                'first'         => lang('plugin/tom_tcptuan','template_neworder_first'),
                'keyword1'      => '['.$order_typeArray[$orderInfo['order_type']].']'.$orderInfo['goods_name'],
                'keyword2'      => $orderInfo['pay_price'],
                'keyword3'      => $orderInfo['xm'],
                'keyword4'      => $orderInfo['tel'],
                'keyword5'      => $orderInfo['order_no'],
                'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset)
            );
            $r = $templateSmsClass->sendSmsNewOrder($orderUserInfoTmp['openid'],$tcptuanConfig['template_neworder'],$smsData);
            if($r){
                Log::DEBUG("template sms manage_1_openid:" . json_encode($smsData));
            }
        }
    }
    
    if($orderInfo['order_type'] == 2){
        $access_token = $weixinClass->get_access_token();
        $templateSmsClass2 = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcptuan&site=".$orderInfo['site_id']."&mod=tuan&tuan_id={$tuanInfo['id']}");
        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tuanInfo['user_id']);
        if($access_token && !empty($toUser['openid']) ){
            $smsData = array(
                'first'         => lang('plugin/tom_tcptuan','cantuan_template_first'),
                'keyword1'      => $tcptuanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass2->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
        }
    }

}