<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcptuan'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcptuan&pmod=admin'; 
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcptuan&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcptuan&pmod=admin';
$tomSysOffset = getglobal('setting/timeoffset');

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/config/config.utf8.php';
}

include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/class/function.admin.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/class/tom.upload.php';
$tcptuanConfig = get_tcptuan_config($pluginid);
$tongchengPlugin = C::t('#tom_tcptuan#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$Lang = formatLang($Lang);

if($_GET['tmod'] == 'goods'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/admin/goods.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/admin/order.php';
}else if($_GET['tmod'] == 'tuan'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/admin/tuan.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/admin/focuspic.php';
}else if($_GET['tmod'] == 'cate'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/admin/cate.php';
}else if($_GET['tmod'] == 'option'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/admin/option.php';
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/admin/addon.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcptuan/admin/goods.php';
}