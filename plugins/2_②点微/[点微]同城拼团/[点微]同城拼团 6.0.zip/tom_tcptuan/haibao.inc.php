<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);
$tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
$plugin_id = 'tom_tcptuan';

if('utf-8' != CHARSET) {
    if(defined('IN_MOBILE')) {}else{
        foreach($_POST AS $pk => $pv) {
            if(!is_numeric($pv)) {
                $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
            }
        }
    }
}

$share_url = isset($_GET['share_url'])? daddslashes($_GET['share_url']):'';
$goods_id  = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);

include DISCUZ_ROOT.'./source/plugin/'.$plugin_id.'/class/function.haibao.php';

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
    include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
}else{
    echo 'QR|phpqrcode';exit;
}

if(empty($goodsInfo['hehuoren_tg_haibao'])){
    echo 'HB|nothaibao';exit;
}

$bgImg = '';
if(!preg_match('/^http/', $goodsInfo['hehuoren_tg_haibao']) ){
    if(strpos($goodsInfo['hehuoren_tg_haibao'], 'source/plugin/tom_tcptuan/') === FALSE){
        $bgImg = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['hehuoren_tg_haibao'];
        if(strpos($bgImg, $_G['siteurl']) !== false){
            $bgImg = str_replace($_G['siteurl'], "", $bgImg);
            $bgImg = DISCUZ_ROOT.$bgImg;
        }
    }else{
        $bgImg = DISCUZ_ROOT.$goodsInfo['hehuoren_tg_haibao'];
    }
}else{
    $bgImg = $goodsInfo['hehuoren_tg_haibao'];
}

$haibaoKey = md5($share_url.$bgImg);

$haibaoImg = DISCUZ_ROOT.'./source/plugin/tom_tcptuan/data/haibao/'.$haibaoKey.'_haibao.png';
$haibaoUrl = $_G['siteurl'].'/source/plugin/tom_tcptuan/data/haibao/'.$haibaoKey.'_haibao.png';

if(file_exists($haibaoImg)){
    echo 'OK|'.$haibaoUrl;exit;
}

$tempDir = "/source/plugin/tom_tcptuan/data/haibao/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0777); 
}

$tempImg = $tempDir.$haibaoKey;

QRcode::png($share_url,$tempImg.'_qrcode.png','H',5,2);

require_once libfile('class/image');
$image = new image();
$image->Thumb($tempImg.'_qrcode.png', '', 240, 240, 1, 1);

$linshiImg = DISCUZ_ROOT.'./source/plugin/tom_tcptuan/data/haibao/'.$haibaoKey.'_lingshihaibao.png';
$bg_pic_content = file_get_contents($bgImg);
if(false ===file_put_contents($linshiImg,$bg_pic_content)){
    $linshiImg = $bgImg;
}

share_haibao_img($linshiImg,$tempImg.'_haibao.png',$tempImg.'_qrcode.png',385);

@unlink($tempImg.'_qrcode.png');
@unlink($tempImg.'_new.png');
@unlink($tempImg.'_lingshihaibao.png');

echo 'OK|'.$haibaoUrl;exit;

function wx_iconv_recurrence($value) {
	if(is_array($value)) {
		foreach($value AS $key => $val) {
			$value[$key] = wx_iconv_recurrence($val);
		}
	} else {
		$value = diconv($value, 'utf-8', CHARSET);
	}
	return $value;
}



