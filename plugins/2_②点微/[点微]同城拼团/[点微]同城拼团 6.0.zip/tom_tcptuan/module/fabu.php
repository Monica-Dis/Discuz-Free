<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $stock_num          = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
    $xiangou_num        = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $market_price       = isset($_GET['market_price'])? addslashes($_GET['market_price']):'';
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? addslashes($_GET['ding_price']):'';
    $tuanz_status       = isset($_GET['tuanz_status'])? intval($_GET['tuanz_status']):0;
    $tuanz_price        = isset($_GET['tuanz_price'])? addslashes($_GET['tuanz_price']):'';
    $tuanz_price_num    = isset($_GET['tuanz_price_num'])? intval($_GET['tuanz_price_num']):0;
    $tuan_num           = isset($_GET['tuan_num'])? intval($_GET['tuan_num']):0;
    $tuan_price         = isset($_GET['tuan_price'])? addslashes($_GET['tuan_price']):'';
    $tuan_hours         = isset($_GET['tuan_hours'])? intval($_GET['tuan_hours']):24;
    $open_one_buy       = isset($_GET['open_one_buy'])? intval($_GET['open_one_buy']):0;
    $one_price          = isset($_GET['one_price'])? addslashes($_GET['one_price']):'';
    $peisong_type       = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $express_type       = isset($_GET['express_type'])? intval($_GET['express_type']):1;
    $express_price      = isset($_GET['express_price'])? addslashes($_GET['express_price']):'';
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = str_replace("T", " ", $hexiao_time);
    $hexiao_time        = strtotime($hexiao_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = str_replace("T", " ", $end_time);
    $end_time           = strtotime($end_time);
    $open_yuyue         = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $yuyue_type         = isset($_GET['yuyue_type'])? intval($_GET['yuyue_type']):1;
    $tcyuyue_id         = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
    $yuyue_xm           = isset($_GET['yuyue_xm'])? addslashes($_GET['yuyue_xm']):'';
    $yuyue_tel          = isset($_GET['yuyue_tel'])? addslashes($_GET['yuyue_tel']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    if($__UserInfo['id'] != $tcshopInfo['user_id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $insertData = array();
    $insertData['site_id']            = $tcshopInfo['site_id'];
    $insertData['user_id']            = $user_id;
    $insertData['tcshop_id']          = $tcshop_id;
    $insertData['name']               = $name;
    $insertData['hasoption']          = $hasoption;
    $insertData['cate_id']            = $cate_id;
    $insertData['cate_child_id']      = $cate_child_id;
    $insertData['picurl']             = $picurl;
    $insertData['toppic']             = $toppic;
    $insertData['stock_num']          = $stock_num;
    $insertData['xiangou_num']        = $xiangou_num;
    $insertData['market_price']       = $market_price;
    $insertData['open_ding_pay']      = $open_ding_pay;
    $insertData['ding_price']         = $ding_price;
    $insertData['tuanz_status']       = $tuanz_status;
    $insertData['tuanz_price']        = $tuanz_price;
    $insertData['tuanz_price_num']    = $tuanz_price_num;
    $insertData['tuan_num']           = $tuan_num;
    $insertData['tuan_price']         = $tuan_price;
    $insertData['tuan_hours']         = $tuan_hours;
    $insertData['open_one_buy']       = $open_one_buy;
    $insertData['one_price']          = $one_price;
    $insertData['express_type']       = $express_type;
    $insertData['express_price']      = $express_price;
    $insertData['peisong_type']       = $peisong_type;
    $insertData['hexiao_time']        = $hexiao_time;
    $insertData['end_time']           = $end_time;
    $insertData['open_yuyue']         = $open_yuyue;
    $insertData['yuyue_type']         = $yuyue_type;
    $insertData['tcyuyue_id']         = $tcyuyue_id;
    $insertData['yuyue_xm']           = $yuyue_xm;
    $insertData['yuyue_tel']          = $yuyue_tel;
    $insertData['content']            = $content;
    if($hasoption == 0){
        $insertData['show_market_price']  = $market_price;
        $insertData['show_tuan_price']    = $tuan_price;
        $insertData['show_tuanz_price']   = $tuanz_price;
        $insertData['show_one_price']     = $one_price;
    }
    $insertData['status']             = 2;
    if($tcptuanConfig['must_shenhe'] == 1){
        $insertData['shenhe_status']  = 2;
    }else{
        $insertData['shenhe_status']  = 1;
    }
    $insertData['add_time']           = TIMESTAMP;
    $insertData['edit_time']          = TIMESTAMP;
    if(C::t('#tom_tcptuan#tom_tcptuan_goods')->insert($insertData)){
        
        $goods_id = C::t('#tom_tcptuan#tom_tcptuan_goods')->insert_id();
        $goodsInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);
        update_ptuan_status($goodsInfoTmp);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']  = $goods_id;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->insert($insertData);
            }
        }
        
        $insertData = array();
        $insertData['is_admin']     = 0;
        $insertData['goods_id']     = $goods_id;
        $insertData['change_num']   = $stock_num;
        $insertData['change_time']  = TIMESTAMP;
        C::t('#tom_tcptuan#tom_tcptuan_stock_log')->insert($insertData);
        
        if($tcptuanConfig['must_shenhe'] == 1){
            $toUser = array();
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $toUser = $toUserTmp;
            }

            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();

            if($access_token && !empty($toUser['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcptuan&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => '['.$tcshopInfo['name'].']'.lang('plugin/tom_tcptuan','shenhe_template_first'),
                    'keyword1'      => $tongchengConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
            'goods_id'=> $goods_id,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}

$allTcshopCount = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count(" AND user_id={$__UserInfo['id']} ");

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$__UserInfo['id']} AND v.open_tcptuan=1 "," ORDER BY s.id DESC ",0,100);
$tcshopList = array();
$firstTcshopId = 0;
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach ($tcshopListTmp as $key => $value){
        $tcshopList[$key] = $value;
        if($firstTcshopId == 0){
            $firstTcshopId  = $value['id'];
        }
    }
}
$tcshopCount = count($tcshopList);

$cateArr = array();
$cateList = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(" AND parent_id=0 "," ORDER BY csort ASC,id DESC ",0,100);
$i = 0;
if(is_array($cateList) && !empty($cateList)){
    foreach ($cateList as $key => $value){
        $cateArr[$i]['id'] = $value['id'];
        $cateArr[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $childCateList = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(" AND parent_id={$value['id']} "," ORDER BY csort ASC,id DESC ",0,100);
        $j = 0;
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $kk => $vv){
                $cateArr[$i]['sub'][$j]['id'] = $vv['id'];
                $cateArr[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cateData = urlencode(json_encode($cateArr));

if($__ShowTcyuyue == 1){
    $tcyuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list("AND tcshop_id = {$firstTcshopId} AND type = 2 AND status = 1 AND shenhe_status = 1 ");
    $tcyuyueList = array();
    foreach($tcyuyueListTmp as $key => $value){
        $tcyuyueList[$key] = $value;
    }
}

$uploadUrl1 = "plugin.php?id=tom_tcptuan&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2 = "plugin.php?id=tom_tcptuan&site={$site_id}&mod=upload&act=toppic&formhash=".FORMHASH;
$uploadUrl3 = "plugin.php?id=tom_tcptuan&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;

$saveUrl = "plugin.php?id=tom_tcptuan&site={$site_id}&mod=fabu&act=save";

$ajaxLoadYuyueUrl = 'plugin.php?id=tom_tcptuan:ajax&site='.$site_id.'&act=load_yuyue&formhash='.$formhash;
$myListUrl = "plugin.php?id=tom_tcptuan&site={$site_id}&mod=myfabu";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //d'.'i'.'sm.ta'.'o'.'bao.com
include template("tom_tcptuan:fabu");