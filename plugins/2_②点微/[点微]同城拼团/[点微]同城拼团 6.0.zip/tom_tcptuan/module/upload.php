<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';

if($_GET['act'] == 'picurl' && $_GET['formhash'] == FORMHASH){
    
    $upload = new tom_upload();
    $_FILES["filedata1"]['name'] = addslashes(diconv(urldecode($_FILES["filedata1"]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata1'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    require_once libfile('class/image');
    $image = new image();
    $image->Thumb($upload->attach['target'], '', 200, 200, 2, 1);
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'toppic' && $_GET['formhash'] == FORMHASH){
    
    $upload = new tom_upload();
    $_FILES["filedata2"]['name'] = addslashes(diconv(urldecode($_FILES["filedata2"]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata2'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    require_once libfile('class/image');
    $image = new image();
    $image->Thumb($upload->attach['target'], '', 640, 300, 2, 1);
        
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}else if($_GET['act'] == 'photo' && $_GET['formhash'] == FORMHASH){

    $upload = new tom_upload();
    $_FILES["filedata3"]['name'] = addslashes(diconv(urldecode($_FILES["filedata3"]['name']), 'UTF-8'));
    
    if(!$upload->init($_FILES['filedata3'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    
    echo 'OK|'.$picurl.'|'.$upload->attach['attachment'];exit;
    
}