<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id   = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;

$goodsInfo  = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);
$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcptuan&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $xiangou_num        = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $market_price       = isset($_GET['market_price'])? addslashes($_GET['market_price']):'';
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? addslashes($_GET['ding_price']):'';
    $tuanz_status       = isset($_GET['tuanz_status'])? intval($_GET['tuanz_status']):0;
    $tuanz_price        = isset($_GET['tuanz_price'])? addslashes($_GET['tuanz_price']):'';
    $tuanz_price_num    = isset($_GET['tuanz_price_num'])? intval($_GET['tuanz_price_num']):0;
    $tuan_num           = isset($_GET['tuan_num'])? intval($_GET['tuan_num']):0;
    $tuan_price         = isset($_GET['tuan_price'])? addslashes($_GET['tuan_price']):'';
    $tuan_hours         = isset($_GET['tuan_hours'])? intval($_GET['tuan_hours']):24;
    $open_one_buy       = isset($_GET['open_one_buy'])? intval($_GET['open_one_buy']):0;
    $one_price          = isset($_GET['one_price'])? addslashes($_GET['one_price']):'';
    $peisong_type       = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $express_type       = isset($_GET['express_type'])? intval($_GET['express_type']):1;
    $express_price      = isset($_GET['express_price'])? addslashes($_GET['express_price']):'';
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = str_replace("T", " ", $hexiao_time);
    $hexiao_time        = strtotime($hexiao_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = str_replace("T", " ", $end_time);
    $end_time           = strtotime($end_time);
    $open_yuyue         = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $yuyue_type         = isset($_GET['yuyue_type'])? intval($_GET['yuyue_type']):1;
    $tcyuyue_id         = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
    $yuyue_xm           = isset($_GET['yuyue_xm'])? addslashes($_GET['yuyue_xm']):'';
    $yuyue_tel          = isset($_GET['yuyue_tel'])? addslashes($_GET['yuyue_tel']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $updateData = array();
    $updateData['name']               = $name;
    $updateData['hasoption']          = $hasoption;
    $updateData['cate_id']            = $cate_id;
    $updateData['cate_child_id']      = $cate_child_id;
    $updateData['picurl']             = $picurl;
    $updateData['toppic']             = $toppic;
    $updateData['xiangou_num']        = $xiangou_num;
    $updateData['open_ding_pay']      = $open_ding_pay;
    $updateData['ding_price']         = $ding_price;
    $updateData['tuanz_status']       = $tuanz_status;
    $updateData['tuanz_price_num']    = $tuanz_price_num;
    $updateData['tuan_num']           = $tuan_num;
    $updateData['tuan_hours']         = $tuan_hours;
    $updateData['open_one_buy']       = $open_one_buy;
    $updateData['peisong_type']       = $peisong_type;
    $updateData['express_type']       = $express_type;
    $updateData['express_price']      = $express_price;
    $updateData['hexiao_time']        = $hexiao_time;
    $updateData['end_time']           = $end_time;
    $updateData['open_yuyue']         = $open_yuyue;
    $updateData['yuyue_type']         = $yuyue_type;
    $updateData['tcyuyue_id']         = $tcyuyue_id;
    $updateData['yuyue_xm']           = $yuyue_xm;
    $updateData['yuyue_tel']          = $yuyue_tel;
    if($goodsInfo['admin_edit'] == 0){
        $updateData['content']        = dhtmlspecialchars($content);
    }
    if($hasoption == 0){
        $updateData['market_price']       = $market_price;
        $updateData['tuanz_price']        = $tuanz_price;
        $updateData['tuan_price']         = $tuan_price;
        $updateData['one_price']          = $one_price;
        $updateData['show_market_price']  = $market_price;
        $updateData['show_tuan_price']    = $tuan_price;
        $updateData['show_tuanz_price']   = $tuanz_price;
        $updateData['show_one_price']     = $one_price;
    }
    $updateData['edit_time']          = TIMESTAMP;
    if(C::t('#tom_tcptuan#tom_tcptuan_goods')->update($goods_id,$updateData)){
        
        $goodsInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);
        update_ptuan_status($goodsInfoTmp);
        
        C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->delete_by_goods_id($goods_id);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']  = $goods_id;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->insert($insertData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
            'goods_id'=> $goods_id,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

if(!preg_match('/^http/', $goodsInfo['picurl']) ){
    if(strpos($goodsInfo['picurl'], 'source/plugin/tom_tcptuan/') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['picurl'];
    }else{
        $picurl = $goodsInfo['picurl'];
    }
}else{
    $picurl = $goodsInfo['picurl'];
}

if(!preg_match('/^http/', $goodsInfo['toppic']) ){
    if(strpos($goodsInfo['toppic'], 'source/plugin/tom_tcptuan/') === FALSE){
        $toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['toppic'];
    }else{
        $toppic = $goodsInfo['toppic'];
    }
}else{
    $toppic = $goodsInfo['toppic'];
}

$goodsPhotoListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->fetch_all_list(" AND goods_id={$goodsInfo['id']} "," ORDER BY id ASC ",0,50);
$goodsPhotoList = array();
$photoCount = 0;
if(is_array($goodsPhotoListTmp) && !empty($goodsPhotoListTmp)){
    foreach ($goodsPhotoListTmp as $kk => $vv){
        $photoCount++;
        if(!preg_match('/^http/', $vv['picurl']) ){
            $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
        }else{
            $picurlTmp = $vv['picurl'];
        }
        $goodsPhotoList[$kk]['picurl'] = $vv['picurl'];
        $goodsPhotoList[$kk]['src'] = $picurlTmp;
        $goodsPhotoList[$kk]['li_i'] = $photoCount;

    }
}

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,100);
$tcshopList = array();
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach ($tcshopListTmp as $key => $value){
        $tcshopList[$key] = $value;
    }
}else{
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcshop&site={$site_id}&mod=ruzhu");exit;
}

$cateInfo = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_by_id($goodsInfo['cate_id']);
$cateChildInfo = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_by_id($goodsInfo['cate_child_id']);

$cateArr = array();
$cateList = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(" AND parent_id=0 "," ORDER BY csort ASC,id DESC ",0,100);
$i = 0;
if(is_array($cateList) && !empty($cateList)){
    foreach ($cateList as $key => $value){
        $cateArr[$i]['id'] = $value['id'];
        $cateArr[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $childCateList = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(" AND parent_id={$value['id']} "," ORDER BY csort ASC,id DESC ",0,100);
        $j = 0;
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $kk => $vv){
                $cateArr[$i]['sub'][$j]['id'] = $vv['id'];
                $cateArr[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cateData = urlencode(json_encode($cateArr));

if($__ShowTcyuyue == 1){
    $tcyuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list(" AND tcshop_id = {$tcshopInfo['id']} AND type = 2 AND status = 1 AND shenhe_status = 1 ");
    $tcyuyueList = array();
    foreach($tcyuyueListTmp as $key => $value){
        $tcyuyueList[$key] = $value;
    }
}

$hexiao_time = dgmdate($goodsInfo['hexiao_time'],'Y-m-d H:i:s',$tomSysOffset);
$hexiao_time = str_replace(" ", "T", $hexiao_time);

$end_time = '';
if($goodsInfo['end_time'] > 0){
    $end_time = dgmdate($goodsInfo['end_time'],'Y-m-d H:i:s',$tomSysOffset);
    $end_time = str_replace(" ", "T", $end_time);
}

$uploadUrl1 = "plugin.php?id=tom_tcptuan&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2 = "plugin.php?id=tom_tcptuan&site={$site_id}&mod=upload&act=toppic&formhash=".FORMHASH;
$uploadUrl3 = "plugin.php?id=tom_tcptuan&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;

$saveUrl = "plugin.php?id=tom_tcptuan&site={$site_id}&mod=edit&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //d'.'i'.'sm.ta'.'o'.'bao.com
include template("tom_tcptuan:edit");