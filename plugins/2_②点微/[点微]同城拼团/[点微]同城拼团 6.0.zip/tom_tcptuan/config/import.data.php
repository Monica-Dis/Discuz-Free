<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$cateArr = array();

$cateArr[1] = array(
    'name'      => '������ʳ',
    'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_1.png',
    'childs'    => array(
        1 => array(
            'name'      => '���',
            'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_1_child_1.png',
        ),
        2 => array(
            'name'      => '���',
            'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_1_child_2.png',
        ),
        3 => array(
            'name'      => '����',
            'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_1_child_3.png',
        ),
        4 => array(
            'name'      => 'ߣ��',
            'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_1_child_4.png',
        ),
        5 => array(
            'name'      => '��Ʒ',
            'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_1_child_5.png',
        ),
        6 => array(
            'name'      => '������',
            'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_1_child_6.png',
        ),
    )
);
$cateArr[2] = array(
    'name'      => '��������',
    'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_2.png',
    'childs'    => array(
        1 => array(
            'name'      => 'KTV',
            'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_2_child_1.png',
        ),
    )
);

$cateArr[3] = array(
    'name'      => '�����Ӱ',
    'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_3.png',
    'childs'    => array(
        1 => array(
            'name'      => '��ɴ��Ӱ',
            'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_3_child_1.png',
        ),
    )
);
$cateArr[4] = array(
    'name'      => '���ʹ���',
    'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_4.png',
    'childs'    => array(
        1 => array(
            'name'      => 'ˮ��',
            'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_4_child_1.png',
        ),
        2 => array(
            'name'      => 'ũ��Ʒ',
            'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_4_child_2.png',
        ),
    )
);
$cateArr[5] = array(
    'name'      => '����ҵ�',
    'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_5.png',
    'childs'    => array(
        1 => array(
            'name'      => '�ֻ�',
            'picurl'    => 'source/plugin/tom_tcptuan/images/cate/cate_5_child_1.png',
        ),
    )
);

if (CHARSET == 'utf-8') {
    $cateArr = tom_iconv($cateArr,'gbk','utf-8');
}