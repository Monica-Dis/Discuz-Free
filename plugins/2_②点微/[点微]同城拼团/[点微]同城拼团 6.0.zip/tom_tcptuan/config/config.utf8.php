<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$orderStatusArray = array(
    1 => '待支付',
    2 => '已支付',
    3 => '已确认，待发货',
    4 => '配送中',
    5 => '已签收',
    6 => '交易已取消',
    7 => '退款处理中',
    8 => '退款成功',
);

$orderStatusColorArray = array(
    1 => '#fd0303',
    2 => '#1e9203',
    3 => '#1e9203',
    4 => '#0585d6',
    5 => '#ff6203',
    6 => '#fd0303',
    7 => '#777a77',
    8 => '#05a6ce',
);


$order_typeArray = array(
    1 => '开团订单',
    2 => '参团订单',
    3 => '普通订单',
);

$order_typeColorArray = array(
    1 => '#1ea004',
    2 => '#0489d5',
    3 => '#2e2f2e',
);

$tuanStatusArray = array(
    1 => '未支付',
    2 => '已支付，拼单中',
    3 => '拼单成功',
    4 => '拼单失败',
);

$tuanStatusColorArray = array(
    1 => '#fc2009',
    2 => '#0389c1',
    3 => '#359606',
    4 => '#fc2009',
);