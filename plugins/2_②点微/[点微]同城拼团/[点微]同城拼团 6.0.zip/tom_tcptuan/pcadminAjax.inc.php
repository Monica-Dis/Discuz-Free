<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
if($_GET['act'] == 'load_yuyue' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'code'=> 1,
    );

    $tcshop_id = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $tcyuyueList = array();
    if($tcshopInfo){
        $tcyuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list("AND tcshop_id = {$tcshop_id} AND type = 2 AND status = 1 AND shenhe_status = 1 ");
        foreach($tcyuyueListTmp as $key => $value){
            $tcyuyueList[$key] = $value;
        }
    }
    
    $list = iconv_to_utf8($tcyuyueList);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}else{
    echo 'error';exit;
}