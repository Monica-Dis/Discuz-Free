<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=order";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('order_id')){
    $outArr = array(
        'code'=> 1,
    );
    exit;
    $order_id = intval($_GET['order_id'])>0 ? intval($_GET['order_id']):0;
    
    C::t('#tom_tcptuan#tom_tcptuan_order')->delete_by_id($order_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):'';
$goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):'';
$tuan_id        = isset($_GET['tuan_id'])? intval($_GET['tuan_id']):'';
$order_no       = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
$order_tel      = !empty($_GET['order_tel'])? trim(addslashes($_GET['order_tel'])):'';
$order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;
$order_type     = isset($_GET['order_type'])? intval($_GET['order_type']):0;
$tuan_status    = isset($_GET['tuan_status'])? intval($_GET['tuan_status']):0;
$start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
$end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = "";
if($user_id > 0){
    $where.=" AND user_id='{$user_id}' ";
}
if(!empty($order_no)){
    $where.=" AND order_no='{$order_no}' ";
}
if(!empty($order_tel)){
    $where.=" AND tel='{$order_tel}' ";
}
if(!empty($order_status)){
    $where.=" AND order_status={$order_status} ";
}
if(!empty($tuan_id)){
    $where.=" AND tuan_id={$tuan_id} ";
}
if(!empty($order_type)){
    $where.=" AND order_type={$order_type} ";
}
if(!empty($goods_id)){
    $where.=" AND goods_id={$goods_id} ";
}
if($tuan_status){
    $where.= " AND tuan_status={$tuan_status} ";
}
if(!empty($start_time)){
    $startTime = strtotime($start_time);
    $where.=" AND order_time >=  {$startTime} ";
}
if(!empty($end_time)){
    $endTime = strtotime($end_time);
    $where.=" AND order_time < {$endTime} ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_like_count($where,'');
$orderListTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_like_list($where,"ORDER BY order_time DESC,id DESC",$start,$pagesize,'');
$orderList = array();
if(!empty($orderListTmp)){
    foreach($orderListTmp as $key => $value){
        $orderList[$key] = $value;
        
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $hexiaoUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        $goodsInfoTmp = C::t("#tom_tcptuan#tom_tcptuan_goods")->fetch_by_id($value['goods_id']);
        $goodsInfoTmp['picurl'] = get_file_url($goodsInfoTmp['picurl']);
        
        $site_name_tmp = $Lang['sites_one'];
        if($value['site_id'] > 1){
            $siteInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_sites")->fetch_by_id($value['goods_id']);
            $site_name_tmp = $siteInfoTmp['name'];
        }
        
        $orderList[$key]['userInfo']        = $userInfoTmp;
        $orderList[$key]['hexiaoUserInfo']  = $hexiaoUserInfoTmp;
        $orderList[$key]['goodsInfo']       = $goodsInfoTmp;
        $orderList[$key]['site_name']       = $site_name_tmp;
        $orderList[$key]['orderTime']       = dgmdate($value['order_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $orderList[$key]['payTime']         = dgmdate($value['pay_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $orderList[$key]['hexiaoTime']      = dgmdate($value['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&goods_id={$goods_id}&order_no={$order_no}&tuan_id={$tuan_id}"
            . "&order_tel={$order_tel}&order_status={$order_status}&order_type={$order_type}"
            . "&tuan_status={$tuan_status}&start_time={$start_time}&end_time={$end_time}";

$goodsNumCount = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num($where);

if($goods_id > 0){
    $countOrderStatus1 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=1 ");
    $countOrderStatus1 = intval($countOrderStatus1);
    $countOrderStatus2 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=2 ");
    $countOrderStatus2 = intval($countOrderStatus2);
    $countOrderStatus4 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=4 ");
    $countOrderStatus4 = intval($countOrderStatus4);
    $countOrderStatus5 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=5 ");
    $countOrderStatus5 = intval($countOrderStatus5);
    $countOrderStatus6 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=6 ");
    $countOrderStatus6 = intval($countOrderStatus6);
    $countOrderStatus7 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=7 ");
    $countOrderStatus7 = intval($countOrderStatus7);
    $countOrderStatus8 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=8 ");
    $countOrderStatus8 = intval($countOrderStatus8);
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //d'.'i'.'sm.ta'.'o'.'bao.com
include template("tom_tcptuan:pcadmin/order");