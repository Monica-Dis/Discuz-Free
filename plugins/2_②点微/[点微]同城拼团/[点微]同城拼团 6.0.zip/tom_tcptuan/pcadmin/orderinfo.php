<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_id = intval($_GET['order_id'])>0? intval($_GET['order_id']):0;
$orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($order_id);

$modPcadminUrl = $pcadminUrl."&tmod=orderinfo&order_id={$order_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('order_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $order_status = intval($_GET['order_status'])>0 ? intval($_GET['order_status']) :0;
    
    $updateData = array();
    $updateData['order_status'] = $order_status;
    C::t('#tom_tcptuan#tom_tcptuan_order')->update($order_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($orderInfo['user_id']);
$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);
$goodsInfo =  C::t("#tom_tcptuan#tom_tcptuan_goods")->fetch_by_id($orderInfo['goods_id']);
$goodsInfo['picurl'] = get_file_url($goodsInfo['picurl']);

$site_name_tmp = $Lang['sites_one'];
if($orderInfo['site_id'] > 1){
    $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
    $site_name_tmp = $siteInfoTmp['name'];
}

$orderInfo['site_name']       = $site_name_tmp;
$orderInfo['orderTime']       = dgmdate($orderInfo['order_time'], 'Y-m-d H:i:s',$tomSysOffset);
$orderInfo['payTime']           = dgmdate($orderInfo['pay_time'], 'Y-m-d H:i:s',$tomSysOffset);
$orderInfo['hexiaoTime']      = dgmdate($orderInfo['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //d'.'i'.'sm.ta'.'o'.'bao.com
include template("tom_tcptuan:pcadmin/orderinfo");