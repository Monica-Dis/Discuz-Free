<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);
if(empty($goodsInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($__UserInfo['id'] != $goodsInfo['user_id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=edit&goods_id={$goods_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $tcchoujiang_id     = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):0;
    $xiangou_num        = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $market_price       = isset($_GET['market_price'])? addslashes($_GET['market_price']):'';
    $tuan_num           = isset($_GET['tuan_num'])? intval($_GET['tuan_num']):0;
    $tuan_price         = isset($_GET['tuan_price'])? addslashes($_GET['tuan_price']):'';
    $tuan_hours         = isset($_GET['tuan_hours'])? intval($_GET['tuan_hours']):24;
    $tuanz_status       = isset($_GET['tuanz_status'])? intval($_GET['tuanz_status']):0;
    $tuanz_price        = isset($_GET['tuanz_price'])? addslashes($_GET['tuanz_price']):'';
    $tuanz_price_num    = isset($_GET['tuanz_price_num'])? intval($_GET['tuanz_price_num']):0;
    $open_one_buy       = isset($_GET['open_one_buy'])? intval($_GET['open_one_buy']):0;
    $one_price          = isset($_GET['one_price'])? addslashes($_GET['one_price']):'';
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? addslashes($_GET['ding_price']):'';
    $virtual_sale_num  = isset($_GET['virtual_sale_num'])? intval($_GET['virtual_sale_num']):0;
    $peisong_type       = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $express_type       = isset($_GET['express_type'])? intval($_GET['express_type']):1;
    $express_price      = isset($_GET['express_price'])? addslashes($_GET['express_price']):'';
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = strtotime($end_time);
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = strtotime($hexiao_time);
    $open_yuyue         = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $yuyue_type         = isset($_GET['yuyue_type'])? intval($_GET['yuyue_type']):1;
    $tcyuyue_id         = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
    $yuyue_xm           = isset($_GET['yuyue_xm'])? addslashes($_GET['yuyue_xm']):'';
    $yuyue_tel          = isset($_GET['yuyue_tel'])? addslashes($_GET['yuyue_tel']):'';
    $paixu              = isset($_GET['paixu'])? intval($_GET['paixu']):10000;
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    
    $stock_num          = isset($_GET['stock_num'])? addslashes($_GET['stock_num']):0;
    
    $yongjin_bili       = isset($_GET['yongjin_bili'])? addslashes($_GET['yongjin_bili']):0;
    $hehuoren_tg_open   = isset($_GET['hehuoren_tg_open'])? intval($_GET['hehuoren_tg_open']):2;
    $chuji_fc_scale     = isset($_GET['chuji_fc_scale'])? intval($_GET['chuji_fc_scale']):0;
    $zhongji_fc_scale   = isset($_GET['zhongji_fc_scale'])? intval($_GET['zhongji_fc_scale']):0;
    $gaoji_fc_scale     = isset($_GET['gaoji_fc_scale'])? intval($_GET['gaoji_fc_scale']):0;
    
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    
    $photoArr = array();
    foreach($_GET['photo'] as $key => $value){
        $value = addslashes($value);
        if(!empty($value)){
            $photoArr[] = $value;
        }
    }
    
    if($stock_num < $goodsInfo['sale_num']){
        $stock_num = $goodsInfo['sale_num'];
    }
    
    if($hasoption == 1){
        $optionList = array();
        foreach($_GET as $key => $value){
            if(strpos($key, "option_id_") !== false){
                $key = intval(ltrim($key, "option_id_"));
                $optionList[$key]['id'] = intval($value);
            }
            if(strpos($key, "option_name_") !== false){
                $key = intval(ltrim($key, "option_name_"));
                $optionList[$key]['name'] = addslashes($value);
            }
            if(strpos($key, "option_market_price_") !== false){
                $key = intval(ltrim($key, "option_market_price_"));
                $optionList[$key]['market_price'] = floatval($value);
            }
            if(strpos($key, "option_tuan_price_") !== false){
                $key = intval(ltrim($key, "option_tuan_price_"));
                $optionList[$key]['tuan_price'] = floatval($value);
            }
            if(strpos($key, "option_tuanz_price_") !== false){
                $key = intval(ltrim($key, "option_tuanz_price_"));
                $optionList[$key]['tuanz_price'] = floatval($value);
            }
            if(strpos($key, "option_one_price_") !== false){
                $key = intval(ltrim($key, "option_one_price_"));
                $optionList[$key]['one_price'] = floatval($value);
            }
            if(strpos($key, "option_stock_num_") !== false){
                $key = intval(ltrim($key, "option_stock_num_"));
                $optionList[$key]['stock_num'] = addslashes($value);
            }
            if(strpos($key, "option_osort_") !== false){
                $key = intval(ltrim($key, "option_osort_"));
                $optionList[$key]['osort'] = addslashes($value);
            }
        }
        
        if(empty($optionList)){
            $outArr = array(
                'code'=> 200,
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
        
        foreach($optionList as $key => $value){
            if(empty($value['name'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }
            if(empty($value['market_price'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }
            if(empty($value['tuan_price'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 304,
                );
                echo json_encode($outArr); exit;
            }
            if($tuanz_status == 1 && empty($value['tuanz_price'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 305,
                );
                echo json_encode($outArr); exit;
            }
            if($open_one_buy == 1 && empty($value['one_price'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
            if(empty($value['stock_num'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 307,
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    
    if($__Admin['admin'] == 'admin'){
        $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($tcshop_id);
    }else if($__Admin['admin'] == 'shopadmin'){
        $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($goodsInfo['tcshop_id']);
    }
    
    if($__Admin['admin'] == 'shopadmin' && $tcshopInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    if($__Admin['admin'] == 'admin'){
        $updateData['site_id']              = $tcshopInfo['site_id'];
        $updateData['user_id']              = $tcshopInfo['user_id'];
        $updateData['tcshop_id']            = $tcshopInfo['id'];
    }
    $updateData['name']                 = $name;
    $updateData['cate_id']              = $cate_id;
    $updateData['cate_child_id']        = $cate_child_id;
    $updateData['xiangou_num']          = $xiangou_num;
    $updateData['market_price']         = $market_price;
    $updateData['tuan_num']             = $tuan_num;
    $updateData['tuan_price']           = $tuan_price;
    $updateData['tuan_hours']           = $tuan_hours;
    $updateData['tuanz_status']         = $tuanz_status;
    if($tuanz_status == 1){
        $updateData['tuanz_price']          = $tuanz_price;
        $updateData['tuanz_price_num']      = $tuanz_price_num;
    }
    $updateData['open_one_buy']         = $open_one_buy;
    if($open_one_buy == 1){
        $updateData['one_price']            = $one_price;
    }
    $updateData['open_ding_pay']        = $open_ding_pay;
    if($open_ding_pay == 1){
        $updateData['ding_price']           = $ding_price;
    }
    $updateData['peisong_type']         = $peisong_type;
    $updateData['express_type']         = $express_type;
    $updateData['express_price']        = $express_price;
    $updateData['end_time']             = $end_time;
    $updateData['hexiao_pwd']           = $hexiao_pwd;
    $updateData['hexiao_time']          = $hexiao_time;
    $updateData['open_yuyue']           = $open_yuyue;
    if($open_yuyue == 1){
        $updateData['yuyue_type']           = $yuyue_type;
        if($yuyue_type == 1){
            $updateData['yuyue_xm']             = $yuyue_xm;
            $updateData['yuyue_tel']            = $yuyue_tel;
        }else if($yuyue_type == 3){
            $updateData['tcyuyue_id']           = $tcyuyue_id;
        }
    }
    $updateData['admin_edit']           = $admin_edit;
    $updateData['content']              = $content;
    $updateData['picurl']               = $picurl;
    $updateData['toppic']               = $toppic;
    $updateData['stock_num']            = $stock_num;
    $updateData['hasoption']            = $hasoption;
    if($hasoption == 0){
        $updateData['show_market_price']    = $market_price;
        $updateData['show_tuan_price']      = $tuan_price;
        $updateData['show_tuanz_price']     = $tuanz_price;
        $updateData['show_one_price']       = $one_price;
    }
    if($__Admin['admin'] == 'admin'){
        $updateData['tcchoujiang_id']       = $tcchoujiang_id;
        $updateData['virtual_sale_num']     = $virtual_sale_num;
        $updateData['paixu']                = $paixu;
        $updateData['yongjin_bili']         = $yongjin_bili;
        $updateData['hehuoren_tg_open']     = $hehuoren_tg_open;
        $updateData['chuji_fc_scale']       = $chuji_fc_scale;
        $updateData['zhongji_fc_scale']     = $zhongji_fc_scale;
        $updateData['gaoji_fc_scale']       = $gaoji_fc_scale;
        
    }
    if($__Admin['admin'] == 'shopadmin' && $tcptuanConfig['must_shenhe'] == 1){
        $updateData['shenhe_status']        = 2;
    }else{
        $updateData['shenhe_status']        = 1;
    }
    $updateData['edit_time']            = TIMESTAMP;
    if(C::t('#tom_tcptuan#tom_tcptuan_goods')->update($goods_id, $updateData)){
        
        C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->delete_by_goods_id($goods_id);
    
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']     = $goods_id;
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->insert($insertData);
            }
        }
        
        if($hasoption == 1){
            if(is_array($optionList) && !empty($optionList)){
                $show_market_price = $show_tuan_price = $show_tuanz_price = $show_one_price = $stock_num = 0;
                foreach ($optionList as $key => $value){
                    
                    $optionInfo = array();
                    if($value['id'] > 0){
                        $optionInfo = C::t('#tom_tcptuan#tom_tcptuan_goods_option')->fetch_by_id($value['id']);
                    }
                    if(!empty($optionInfo)){
                        
                        $saleNumCount = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND option_id = {$optionInfo['id']} AND goods_id={$goods_id} AND order_status IN(2,3,4,5) ");
                        if($saleNumCount > $value['stock_num']){
                            $value['stock_num'] = $saleNumCount;
                        }
                        
                        $updateData = array();
                        $updateData['name']             = $value['name'];
                        $updateData['market_price']     = $value['market_price'];
                        $updateData['tuan_price']       = $value['tuan_price'];
                        $updateData['tuanz_price']      = $value['tuanz_price'];
                        $updateData['one_price']        = $value['one_price'];
                        $updateData['stock_num']        = $value['stock_num'];
                        $updateData['osort']            = $value['osort'];
                        C::t('#tom_tcptuan#tom_tcptuan_goods_option')->update($optionInfo['id'], $updateData);
                        $option_id = $optionInfo['id'];
                    }else{
                        $insertData = array();
                        $insertData['goods_id']         = $goods_id;
                        $insertData['name']             = $value['name'];
                        $insertData['market_price']     = $value['market_price'];
                        $insertData['tuan_price']       = $value['tuan_price'];
                        $insertData['tuanz_price']      = $value['tuanz_price'];
                        $insertData['one_price']        = $value['one_price'];
                        $insertData['stock_num']        = $value['stock_num'];
                        $insertData['osort']            = $value['osort'];
                        $insertData['add_time']         = TIMESTAMP;
                        $option_id = C::t('#tom_tcptuan#tom_tcptuan_goods_option')->insert($insertData, true);
                    }
                    
                    if($option_id > 0){

                        $beizu = 'ID:&nbsp;<font color="#0a9409">'.$option_id.'</font> '
                                .$Lang['add_option_name'].' <font color="#0a9409">'.$value['name'].'</font>: '
                                .$Lang['add_stock_num'].'<font color="#fd0d0d">'.$value['stock_num'].'</font> '
                                .$Lang['add_market_price'].'<font color="#fd0d0d">'.$value['market_price'].'</font> '
                                .$Lang['add_tuan_price'].'<font color="#fd0d0d">'.$value['tuan_price'].'</font> '
                                .$Lang['add_tuanz_price'].'<font color="#fd0d0d">'.$value['tuanz_price'].'</font> '
                                .$Lang['add_one_price'].'<font color="#fd0d0d">'.$value['one_price'].'</font><br/>';

                        $insertData = array();
                        if($__Admin['admin'] == 'admin'){
                            $insertData['is_admin']     = 1;
                        }
                        $insertData['is_option']    = 1;
                        $insertData['goods_id']     = $goods_id;
                        $insertData['beizu']        = $beizu;
                        $insertData['change_num']   = $value['stock_num'];
                        $insertData['change_time']  = TIMESTAMP;
                        C::t("#tom_tcptuan#tom_tcptuan_stock_log")->insert($insertData);
                    }
                    
                    $stock_num = $stock_num + $value['stock_num'];
                    if($show_market_price == 0){
                        $show_market_price  = $value['market_price'];
                        $show_tuan_price    = $value['tuan_price'];
                        $show_tuanz_price   = $value['tuanz_price'];
                        $show_one_price     = $value['one_price'];
                    }else if($value['market_price'] < $show_market_price){
                        $show_market_price  = $value['market_price'];
                        $show_tuan_price    = $value['tuan_price'];
                        $show_tuanz_price   = $value['tuanz_price'];
                        $show_one_price     = $value['one_price'];
                    }
                }
                
                if($show_market_price > 0){
                    $updateData = array();
                    $updateData['show_market_price']    = $show_market_price;
                    $updateData['show_tuan_price']      = $show_tuan_price;
                    $updateData['show_tuanz_price']     = $show_tuanz_price;
                    $updateData['show_one_price']       = $show_one_price;
                    $updateData['stock_num']            = $stock_num;
                    $updateData['part1']                = TIMESTAMP;
                    C::t("#tom_tcptuan#tom_tcptuan_goods")->update($goods_id,$updateData);
                }
            }
        }else{
            
            $insertData = array();
            if($__Admin['admin'] == 'admin'){
                $insertData['is_admin']     = 1;
            }
            $insertData['goods_id']     = $goods_id;
            $insertData['change_num']   = $stock_num;
            $insertData['change_time']  = TIMESTAMP;
            C::t('#tom_tcptuan#tom_tcptuan_stock_log')->insert($insertData);
        }
        
        update_ptuan_status($goodsInfo);
        if($__Admin['admin'] == 'shopadmin' && $tcptuanConfig['must_shenhe'] == 1){
            $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUser && !empty($toUser['openid'])){

                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                $access_token = $weixinClass->get_access_token();

                if($access_token && !empty($toUser['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcptuan&site={$site_id}&mod=index");
                    $smsData = array(
                        'first'         => '['.$tcshopInfo['name'].']'.$Lang['template_shenhe_template_edit'],
                        'keyword1'      => $tongchengConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                        'remark'        => ''
                    );
                    $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}else if($act == 'del_option' && submitcheck('option_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $option_id = intval($_GET['option_id'])>0? intval($_GET['option_id']): 0;
    
    $optionInfo = C::t('#tom_tcptuan#tom_tcptuan_goods_option')->fetch_by_id($option_id);
    
    C::t('#tom_tcptuan#tom_tcptuan_goods_option')->delete_by_id($option_id);
    
    $optionListTmp = C::t("#tom_tcptuan#tom_tcptuan_goods_option")->fetch_all_list(" AND goods_id = {$optionInfo['goods_id']} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_market_price = $show_buy_price = $show_vip_price = $show_before_price = $stock_num = 0;
        foreach($optionListTmp as $key => $value){
            $stock_num = $stock_num + $value['stock_num'];
            if($show_market_price == 0){
                $show_market_price  = $value['market_price'];
                $show_tuan_price    = $value['tuan_price'];
                $show_tuanz_price   = $value['tuanz_price'];
                $show_one_price     = $value['one_price'];
            }else if($value['market_price'] < $show_market_price){
                $show_market_price  = $value['market_price'];
                $show_tuan_price    = $value['tuan_price'];
                $show_tuanz_price   = $value['tuanz_price'];
                $show_one_price     = $value['one_price'];
            }
        }
        if($show_market_price > 0){
            $updateData = array();
            $updateData['show_market_price']    = $show_market_price;
            $updateData['show_tuan_price']      = $show_tuan_price;
            $updateData['show_tuanz_price']     = $show_tuanz_price;
            $updateData['show_one_price']       = $show_one_price;
            $updateData['stock_num']            = $stock_num;
            $updateData['part1']                = TIMESTAMP;
            C::t("#tom_tcptuan#tom_tcptuan_goods")->update($goods_id,$updateData);
        }
        update_ptuan_status($goodsInfo);
    }
    
    $outArr = array(
        'code' => 200,
    );
    echo json_encode($outArr); exit;
}

$cateListTmp = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['parent_id'] > 0){
            $cateChildList[$value['parent_id']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($goodsInfo['tcshop_id']);

$end_time       = dgmdate($goodsInfo['end_time'],"Y-m-d H:i:s",$tomSysOffset);
$hexiao_time    = dgmdate($goodsInfo['hexiao_time'],"Y-m-d H:i:s",$tomSysOffset);

$picurl         = get_file_url($goodsInfo['picurl']);
$toppic         = get_file_url($goodsInfo['toppic']);

$photoListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->fetch_all_list(" AND goods_id={$goods_id} ","ORDER BY id ASC",0,50);
$photoList = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach ($photoListTmp as $key => $value){
        $photoList[$key] = $value;
        $photoList[$key]['picurlTmp'] = get_file_url($value['picurl']);
    }
}

if($goodsInfo['hasoption'] == 1){
    $optionListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods_option')->fetch_all_list("AND goods_id = {$goods_id}", 'ORDER BY osort ASC, id ASC', 0, 100);
    $optionList = array();
    $option_num = 1;
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        foreach($optionListTmp as $key => $value){
            $optionList[$key] = $value;
            $optionList[$key]['option_num'] = $option_num;
            $option_num++;
        }
    }
}

if($__ShowTcyuyue == 1){
    $tcyuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list("AND tcshop_id = {$goodsInfo['tcshop_id']}  AND type = 2 AND status = 1 AND shenhe_status = 1 ");
    $tcyuyueList = array();
    if(is_array($tcyuyueListTmp) && !empty($tcyuyueListTmp)){
        foreach($tcyuyueListTmp as $key => $value){
            $tcyuyueList[$key] = $value;
        }
    }
}

$goodsInfo['content'] = stripcslashes($goodsInfo['content']);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //d'.'i'.'sm.ta'.'o'.'bao.com
include template("tom_tcptuan:pcadmin/edit");