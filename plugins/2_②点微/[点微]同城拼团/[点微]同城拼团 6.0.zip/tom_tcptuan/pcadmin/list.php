<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=list";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'show' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );

    $goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;

    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcptuan#tom_tcptuan_goods')->update($goods_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );

    $goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;

    $updateData = array();
    $updateData['status'] = 2;
    C::t('#tom_tcptuan#tom_tcptuan_goods')->update($goods_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'shenhe' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $goods_id       = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']);
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status'] = 1;
        C::t('#tom_tcptuan#tom_tcptuan_goods')->update($goods_id, $updateData);

        $shenhe = str_replace('{NAME}', $goodsInfo['name'], $Lang['template_tcptuan_shenhe_ok']);
        
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcptuanConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcptuan&site={$goodsInfo['site_id']}&mod=goodsinfo&goods_id=".$goodsInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcptuanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcptuan#tom_tcptuan_goods')->update($goods_id, $updateData);
        
        $shenhe = str_replace('{NAME}', $goodsInfo['name'], $Lang['template_tcptuan_shenhe_no']);
        
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcptuanConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tcptuan_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcptuan&site={$goodsInfo['site_id']}&mod=edit&goods_id=".$goodsInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcptuanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0; 
    
    $count = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_count(" AND goods_id={$goods_id} ");
    if($orderGoodsCount > 0){
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }else{
        
        C::t('#tom_tcptuan#tom_tcptuan_goods')->delete_by_id($goods_id);
        C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->delete_by_goods_id($goods_id);
        C::t('#tom_tcptuan#tom_tcptuan_goods_option')->delete_by_goods_id($goods_id);
        
        $outArr = array(
            'code'=> 200,
        );    
        echo json_encode($outArr); exit;
    }
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$goods_name         = !empty($_GET['goods_name'])? addslashes($_GET['goods_name']):'';
$status             = isset($_GET['status'])? intval($_GET['status']):0;
$cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
$cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ",0,1000);
$cateList = $cateChildList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        if($value['parent_id'] > 0){
            $cateChildList[$value['parent_id']][$value['id']] = $value;
        }else{
            $cateList[$value['id']] = $value;
        }
    }
    foreach($cateChildList as $key => $value){
        $cateList[$key]['cateChildList'] = $value;
    }
}
$cateArr = iconv_to_utf8($cateList);
$cateData[0] = $cateArr;
$cateData = urlencode(json_encode($cateData));

$where = "";
if(!empty($site_id)){
    $where.= " AND site_id={$site_id} ";
}
if(!empty($status)){
    if($status == 1){
        $where.= " AND status = 1 ";
    }else{
        $where.= " AND status != 1 ";
    }
}
if(!empty($cate_id)){
    $where.= " AND cate_id={$cate_id} ";
}
if(!empty($cate_child_id)){
    $where.= " AND cate_child_id={$cate_child_id} ";
}
if(!empty($shenhe_status)){
    $where.= " AND shenhe_status={$shenhe_status} ";
}

$sort = " ORDER BY id DESC ";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_like_count($where,$goods_name);
$goodsListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_like_list($where,$sort,$start,$pagesize,$goods_name);
$goodsList = array();
if(!empty($goodsListTmp)){
    foreach ($goodsListTmp as $key => $value) {
        $goodsList[$key] = $value;
        
        $siteInfoTmp        = $sitesList[$value['site_id']];
        $cateInfoTmp        = $cateList[$value['cate_id']];
        $cateChildInfoTmp   = $cateChildList[$value['cate_id']][$value['cate_child_id']];
        $tcshopInfoTmp      = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $tcshopUserInfoTmp  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfoTmp['user_id']); 
        
        $goodsList[$key]['picurl']          = get_file_url($value['picurl']);
        $goodsList[$key]['siteInfo']        = $siteInfoTmp;
        $goodsList[$key]['cateInfo']        = $cateInfoTmp;
        $goodsList[$key]['cateChildInfo']   = $cateChildInfoTmp;
        $goodsList[$key]['tcshopInfo']      = $tcshopInfoTmp;
        $goodsList[$key]['tcshopUserInfo']  = $tcshopUserInfoTmp;
        $goodsList[$key]['hexiao_time']     = dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
        $goodsList[$key]['add_time']        = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $goodsList[$key]['end_time']        = dgmdate($value['end_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&goods_name={$goods_name}&status={$status}&cate_id={$cate_id}&cate_child_id={$cate_child_id}&shenhe_status={$shenhe_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //d'.'i'.'sm.ta'.'o'.'bao.com
include template("tom_tcptuan:pcadmin/list");