<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=tuan";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('tuan_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tuan_id = isset($_GET['tuan_id'])? intval($_GET['tuan_id']):0;
    
    C::t('#tom_tcptuan#tom_tcptuan_tuan')->delete_by_id($tuan_id);
    C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->delete_by_tuan_id($tuan_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}elseif($act == 'edit_tuan_status' && submitcheck('tuan_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tuan_id        = isset($_GET['tuan_id'])? intval($_GET['tuan_id']):0;
    $tuan_status    = intval($_GET['tuan_status'])>0 ? intval($_GET['tuan_status']) : 0;
    $prolong_hours  = intval($_GET['prolong_hours'])>0 ? intval($_GET['prolong_hours']) : 0;
    
    $updateData     = array();
    $updateData['prolong_hours']    = $prolong_hours;
    $updateData['tuan_status']      = $tuan_status;
    if(C::t('#tom_tcptuan#tom_tcptuan_tuan')->update($tuan_id,$updateData)){
        C::t('#tom_tcptuan#tom_tcptuan_order')->update_tuan_status_by_tuan_id($tuan_id,$tuan_status);
    }
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$tuan_id        = isset($_GET['tuan_id'])? intval($_GET['tuan_id']):0;
$tuan_status    = isset($_GET['tuan_status'])? intval($_GET['tuan_status']):0;

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$where = "";
if($tuan_id > 0){
    $where.= " AND id={$tuan_id} ";
}
if($tuan_status > 0){
    $where.= " AND tuan_status={$tuan_status} ";
}

$order = " ORDER BY tuan_time DESC,id DESC ";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_all_count($where);
$tuanListTmp = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_all_list($where,$order,$start,$pagesize);
$tuanList = array();
if(!empty($tuanListTmp)){
    foreach ($tuanListTmp as $key => $value) {
        $tuanList[$key] = $value;
        
        $goodsInfoTmp  = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($value['goods_id']);
        $goodsInfoTmp['picurl'] = get_file_url($goodsInfoTmp['picurl']);
        
        $userInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $orderListTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_like_list(" AND tuan_id={$value['id']} ","ORDER BY order_time DESC",0,500,"");
        $orderStatusArrTmp = array();
        for($i=1;$i<=8;$i++){
            $orderStatusArrTmp[$i] = 0;
        }
        if(is_array($orderListTmp) && !empty($orderListTmp)){
            foreach ($orderListTmp as $k1 => $v1){
                $orderStatusArrTmp[$v1['order_status']]++;
            }
        }
        
        $qrcodeImgTmp = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($_G['siteurl']."plugin.php?id=tom_tcptuan&site=".$value['site_id']."&mod=tuan&tuan_id={$value['id']}");
        
        $tuanList[$key]['goodsInfo']        = $goodsInfoTmp;
        $tuanList[$key]['userInfo']         = $userInfoTmp;
        $tuanList[$key]['orderStatusArr']   = $orderStatusArrTmp;
        $tuanList[$key]['qrcodeImg']        = $qrcodeImgTmp;
        $tuanList[$key]['tuanTime']         = dgmdate($value['tuan_time'],"Y-m-d H:i",$tomSysOffset);
        $tuanList[$key]['successTime']      = dgmdate($value['success_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&tuan_id={$tuan_id}&tuan_status={$tuan_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //d'.'i'.'sm.ta'.'o'.'bao.com
include template("tom_tcptuan:pcadmin/tuan");