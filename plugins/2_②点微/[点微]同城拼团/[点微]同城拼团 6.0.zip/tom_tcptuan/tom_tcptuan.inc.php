<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = '20210506';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
include DISCUZ_ROOT . './source/plugin/tom_tcptuan/class/function.core.php';
$__OnlyHosts = 0;
$__TongchengHost = '';
if ($tcptuanConfig['open_only_hosts'] == 1 && !empty($tcptuanConfig['tongcheng_hosts']) && !empty($tcptuanConfig['ptuan_hosts'])) {
	$__OnlyHosts = 1;
	$urlTmp = $weixinClass->get_url();
	if (strpos($urlTmp, $tcptuanConfig['ptuan_hosts']) === false && strpos($urlTmp, $tcptuanConfig['tongcheng_hosts']) !== false) {
		$newUrlTmp = str_replace($tcptuanConfig['tongcheng_hosts'], $tcptuanConfig['ptuan_hosts'], $urlTmp);
		if ($tcptuanConfig['must_http'] == 1) {
			$newUrlTmp = str_replace('https', 'http', $newUrlTmp);
		}
		tomheader('location:' . $newUrlTmp);
		exit(0);
	}
	preg_match('#((http|https)://([^?]*)/)([a-z_0-9]*.php)#', $urlTmp, $urlmatches2);
	if (strpos($urlmatches2['0'], $tcptuanConfig['tongcheng_hosts']) === false && strpos($urlTmp, $tcptuanConfig['ptuan_hosts']) !== false) {
		$__TongchengHost = str_replace($tcptuanConfig['ptuan_hosts'], $tcptuanConfig['tongcheng_hosts'], $urlmatches2['0']);
		$__TongchengHost = rtrim($__TongchengHost, $urlmatches2['4']);
		if ($tcptuanConfig['must_http'] == 1) {
			if (strpos($__TongchengHost, 'https') === false) {
				$__TongchengHost = str_replace('http', 'https', $__TongchengHost);
			}
		}
	}
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/function.core.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcptuanConfig['wx_share_title'];
$shareDesc = $tcptuanConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=index';
$shareLogo = $tcptuanConfig['wx_share_pic'];
if (CHARSET == 'gbk') {
	include DISCUZ_ROOT . './source/plugin/tom_tcptuan/config/config.gbk.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tcptuan/config/config.utf8.php';
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$ajaxLoadListUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
$ajaxRefundUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=refund&formhash=' . $formhash;
$ajaxRefundqueryUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=refundquery&formhash=' . $formhash;
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$__ShowTcmall = 0;
$tcmallConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcmall/tom_tcmall.inc.php')) {
	$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
	if ($tcmallConfig['open_tcmall'] == 1) {
		$__ShowTcmall = 1;
	}
}
$__ShowTcsign = 0;
$tcsignConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcsign/tom_tcsign.inc.php')) {
	$tcsignConfig = $_G['cache']['plugin']['tom_tcsign'];
	$__ShowTcsign = 1;
}
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')) {
	$tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
	if ($tcchoujiangConfig['open_tcchoujiang'] == 1) {
		$__ShowTcchoujiang = 1;
	}
}
$__ShowKuaidi = 0;
$kuaidiConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_kuaidi/tom_kuaidi.inc.php')) {
	$__ShowKuaidi = 1;
	$kuaidiConfig = $_G['cache']['plugin']['tom_kuaidi'];
}
$__ShowPrint = 0;
$printConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_print/tom_print.inc.php')) {
	$printConfig = $_G['cache']['plugin']['tom_print'];
	if ($printConfig['open_print'] == 1) {
		$__ShowPrint = 1;
	}
}
$__ShowTcyuyue = 0;
$tcyuyueConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcyuyue/tom_tcyuyue.inc.php')) {
	$tcyuyueConfig = $_G['cache']['plugin']['tom_tcyuyue'];
	if ($tcyuyueConfig['open_tcyuyue'] == 1) {
		$__ShowTcyuyue = 1;
	}
}
if ($_GET['mod'] == 'index') {
	$tui = intval($_GET['tui']) > 0 ? intval($_GET['tui']) : 0;
	$focuspicListTmp = C::t('#tom_tcptuan#tom_tcptuan_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tcptuan#tom_tcptuan_focuspic')->fetch_all_list(' AND site_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	foreach ($focuspicListTmp as $key => $value) {
		$focuspicList[$key] = $value;
		if (!preg_match('/^http/', $value['picurl'])) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
		} else {
			$picurl = $value['picurl'];
		}
		$focuspicList[$key]['picurl'] = $picurl;
	}
	$cateListTmp = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(' AND parent_id=0 ', ' ORDER BY csort ASC,id DESC ', 0, 100);
	$i = 1;
	$cateCount = 0;
	$cateList = array();
	foreach ($cateListTmp as $key => $value) {
		$cateList[$key] = $value;
		$cateList[$key]['i'] = $i;
		if (!preg_match('/^http/', $value['picurl'])) {
			if (strpos($value['picurl'], 'source/plugin/tom_tcptuan/') === false) {
				$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
			} else {
				$picurl = $value['picurl'];
			}
		} else {
			$picurl = $value['picurl'];
		}
		$cateList[$key]['picurl'] = $picurl;
		$i++;
		$cateCount++;
	}
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tcptuan/images/index.js';
	if ($tcptuanConfig['index_list_type'] == 2) {
		$ajaxLoadListUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=list&tui=' . $tui . '&liststyle=big&formhash=' . $formhash;
	} else {
		$ajaxLoadListUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=list&tui=' . $tui . '&liststyle=small&formhash=' . $formhash;
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:index');
	echo '<script src="source/plugin/tom_tcptuan/images/index.js"></script>';
} elseif ($_GET['mod'] == 'cates') {
	$cateListTmp = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(' AND parent_id=0 ', ' ORDER BY csort ASC,id DESC ', 0, 100);
	$cateList = array();
	$i = 1;
	foreach ($cateListTmp as $key => $value) {
		$cateList[$key] = $value;
		$cateList[$key]['i'] = $i;
		if (!preg_match('/^http/', $value['picurl'])) {
			if (strpos($value['picurl'], 'source/plugin/tom_tcptuan/') === false) {
				$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
			} else {
				$picurl = $value['picurl'];
			}
		} else {
			$picurl = $value['picurl'];
		}
		$cateList[$key]['picurl'] = $picurl;
		$childCateListTmp = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(' AND parent_id=' . $value['id'] . ' ', ' ORDER BY csort ASC,id DESC ', 0, 100);
		$childCateList = array();
		if (is_array($childCateListTmp) && !empty($childCateListTmp)) {
			foreach ($childCateListTmp as $kk => $vv) {
				$childCateList[$kk] = $vv;
				if (!preg_match('/^http/', $vv['picurl'])) {
					if (strpos($vv['picurl'], 'source/plugin/tom_tcptuan/') === false) {
						$child_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $vv['picurl'];
					} else {
						$child_picurl = $vv['picurl'];
					}
				} else {
					$child_picurl = $vv['picurl'];
				}
				$childCateList[$kk]['picurl'] = $child_picurl;
			}
		}
		$cateList[$key]['childs'] = $childCateList;
		$i++;
	}
	$searchUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=get_search_url';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:cates');
} elseif ($_GET['mod'] == 'list') {
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$cateInfo = array();
	if (!empty($cate_id)) {
		$cateInfo = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_by_id($cate_id);
	}
	$cateChildInfo = array();
	if (!empty($cate_child_id)) {
		$cateChildInfo = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_by_id($cate_child_id);
	}
	$cateList = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(' AND parent_id=0 ', ' ORDER BY csort ASC,id DESC ', 0, 100);
	$cateChildList = array();
	if ($cate_id > 0) {
		$cateChildList = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(' AND parent_id=' . $cate_id . ' ', ' ORDER BY csort ASC,id DESC ', 0, 100);
	}
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=list&keyword=' . $_GET['keyword'] . '&formhash=' . $formhash;
	$title = '';
	if ($cateChildInfo && !empty($cateChildInfo['name'])) {
		$title = $cateChildInfo['name'];
	} else {
		if ($cateInfo && !empty($cateInfo['name'])) {
			$title = $cateInfo['name'];
		} else {
			$title = urldecode($keyword);
		}
	}
	$shareTitle = $title . '-' . $tcptuanConfig['plugin_name'];
	$shareUrl = $_G['siteurl'] . 'plugin.php?id=tom_tcptuan&site=' . $site_id . ('&mod=list&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&keyword=') . $_GET['keyword'];
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:list');
} elseif ($_GET['mod'] == 'goodsinfo') {
	$goods_id = isset($_GET['goods_id']) ? intval($_GET['goods_id']) : 0;
	$tj_hehuoren_id = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
	if ($tj_hehuoren_id > 0) {
		$lifeTime = 86400;
		dsetcookie('tom_tcptuan_tj_hehuoren_id_goods_' . $goods_id, $tj_hehuoren_id, $lifeTime);
	} else {
		$cookie_tj_hehuoren_id = getcookie('tom_tcptuan_tj_hehuoren_id_goods_' . $goods_id);
		if ($cookie_tj_hehuoren_id > 0) {
			$tj_hehuoren_id = $cookie_tj_hehuoren_id;
		}
	}
	if ($tcptuanConfig['open_hehuoren_self_sheng'] == 1) {
		if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
			$tchehuorenInfoTmpTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
			if ($tchehuorenInfoTmpTmp && $tchehuorenInfoTmpTmp['status'] == 1) {
				$tj_hehuoren_id = $tchehuorenInfoTmpTmp['id'];
			}
		}
	}
	$goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);
	if ($goodsInfo['id'] <= 0) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	if ($goodsInfo['show_tuan_price'] <= 0) {
		$goodsInfo['show_tuan_price'] = $goodsInfo['tuan_price'];
		$goodsInfo['show_tuanz_price'] = $goodsInfo['tuanz_price'];
		$goodsInfo['show_market_price'] = $goodsInfo['market_price'];
		$goodsInfo['show_one_price'] = $goodsInfo['one_price'];
	}
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	if (!preg_match('/^http/', $goodsInfo['toppic']) && !empty($goodsInfo['toppic'])) {
		$toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['toppic'];
	} else {
		$toppic = $goodsInfo['toppic'];
	}
	if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
		if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_tcshop/') === false) {
			$shop_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
		} else {
			$shop_picurl = $tcshopInfo['picurl'];
		}
	} else {
		$shop_picurl = $tcshopInfo['picurl'];
	}
	if (!preg_match('/^http/', $tcshopInfo['kefu_qrcode'])) {
		if (strpos($tcshopInfo['kefu_qrcode'], 'source/plugin/tom_tcshop/') === false) {
			$kefu_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['kefu_qrcode'];
		} else {
			$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
		}
	} else {
		$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
	}
	$kefuSmsUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&&to_user_id=' . $tcshopInfo['user_id'] . '&tcptuan_goods_id=' . $goods_id . '&formhash=' . FORMHASH;
	$sale_num = $goodsInfo['sale_num'] + $goodsInfo['virtual_sale_num'];
	$clicks = $goodsInfo['clicks'] + $goodsInfo['virtual_clicks'];
	$score_yuan = $tongchengConfig['score_yuan'];
	if (!empty($tcptuanConfig['score_yuan'])) {
		$score_yuan = $tcptuanConfig['score_yuan'];
	}
	$back_score = ceil($goodsInfo['show_tuan_price'] * $score_yuan);
	$hexiao_time = dgmdate($goodsInfo['hexiao_time'], 'Y' . lang('plugin/tom_tcptuan', 'year') . 'm' . lang('plugin/tom_tcptuan', 'month') . 'd' . lang('plugin/tom_tcptuan', 'day'), $tomSysOffset);
	if ($goodsInfo['end_time'] > 0) {
		$end_time = $goodsInfo['end_time'] - TIMESTAMP;
	} else {
		if ($goodsInfo['peisong_type'] == 1 || $goodsInfo['peisong_type'] == 3) {
			$end_time = $goodsInfo['hexiao_time'] - TIMESTAMP;
		} else {
			$end_time = $goodsInfo['add_time'] + 86400 * 365 - TIMESTAMP;
		}
	}
	if ($goodsInfo['admin_edit'] == 1) {
		$content = stripslashes($goodsInfo['content']);
	} else {
		$content = stripslashes($goodsInfo['content']);
		$content = strip_tags($content);
		$content = str_replace("\r\n", '<br/>', $content);
		$content = str_replace("\n", '<br/>', $content);
		$content = str_replace("\r", '<br/>', $content);
	}
	$goodsCount = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(' AND goods_id=' . $goods_id . ' AND order_status IN(2,3,4,5) ');
	$sy_stock = $goodsInfo['stock_num'] - $goodsCount;
	if ($sy_stock < 0) {
		$sy_stock = 0;
	}
	if ($goodsInfo['hasoption'] == 1) {
		$optionListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods_option')->fetch_all_list('AND goods_id = ' . $goodsInfo['id'], 'ORDER BY osort ASC, id DESC', 0, 100);
		$optionList = array();
		if (is_array($optionListTmp) && !empty($optionListTmp)) {
			foreach ($optionListTmp as $key => $value) {
				$optionList[$key] = $value;
				$optionGoodsCount = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(' AND option_id=' . $value['id'] . ' AND goods_id=' . $goods_id . ' AND order_status IN(2,3,4,5) ');
				$syStockTmp = $value['stock_num'] - $optionGoodsCount;
				if ($syStockTmp < 0) {
					$syStockTmp = 0;
				}
				$optionList[$key]['sy_stock'] = $syStockTmp;
			}
		}
		$optionCount = count($optionList);
	}
	if ($__UserInfo['id'] > 0) {
		if ($goodsInfo['tuanz_status'] == 1 && $goodsInfo['show_tuanz_price'] > 0) {
			if ($goodsInfo['tuanz_price_num'] > 0) {
				$goodsInfo['xiangou_num'] = $goodsInfo['tuanz_price_num'];
			}
		}
		$xiangouStatus = 0;
		$goods_xiangou_num = 0;
		if ($goodsInfo['xiangou_num'] > 0) {
			$myHaveOrderCount = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(' AND user_id=' . $__UserInfo['id'] . ' AND goods_id=' . $goods_id . ' AND order_status IN(2,3,4,5) ');
			$goods_xiangou_num = $goodsInfo['xiangou_num'] - $myHaveOrderCount;
			if ($myHaveOrderCount >= $goodsInfo['xiangou_num']) {
				$xiangouStatus = 1;
			}
		}
	}
	DB::query('UPDATE ' . DB::table('tom_tcptuan_goods') . (' SET clicks=clicks+1 WHERE id=\'' . $goods_id . '\''), 'UNBUFFERED');
	$tuanListOkTmp = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_all_list(' AND goods_id=' . $goods_id . ' AND tuan_status=3  ', 'ORDER BY success_time DESC', 0, 10);
	$tuanListOkCount = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_all_count(' AND goods_id=' . $goods_id . ' AND tuan_status=3  ');
	$tuanListOk = array();
	if (is_array($tuanListOkTmp) && !empty($tuanListOkTmp) && $tcptuanConfig['open_tuanok_list'] == 1) {
		foreach ($tuanListOkTmp as $key => $value) {
			$tuanListOk[$key] = $value;
			$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$tuanListOk[$key]['userInfo'] = $userInfoTmp;
		}
	}
	$tuanListTmp = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_all_list(' AND goods_id=' . $goods_id . ' AND tuan_status=2  ', 'ORDER BY tuan_time DESC', 0, 4);
	$tuanListCount = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_all_count(' AND goods_id=' . $goods_id . ' AND tuan_status=2  ');
	$tuanList = array();
	if (is_array($tuanListTmp) && !empty($tuanListTmp) && $tcptuanConfig['open_tuan_list'] == 1) {
		foreach ($tuanListTmp as $key => $value) {
			$tuanList[$key] = $value;
			$goodsInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($value['goods_id']);
			if ($goodsInfoTmp['show_tuan_price'] <= 0) {
				$goodsInfoTmp['show_tuan_price'] = $goodsInfoTmp['tuan_price'];
			}
			$tuanList[$key]['tuan_price'] = $goodsInfoTmp['show_tuan_price'];
			$tuanList[$key]['tuan_time'] = dgmdate($value['tuan_time'], 'm-d H:i', $tomSysOffset);
			$tuanList[$key]['tuanUrl'] = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=tuan&tuan_id=' . $value['id'];
			$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$userInfoTmp['nickname'] = cutstr($userInfoTmp['nickname'], 18, '..');
			$tuanList[$key]['userInfo'] = $userInfoTmp;
			$tuanHoursTmp = $goodsInfoTmp['tuan_hours'];
			if (!empty($value['prolong_hours'])) {
				$tuanHoursTmp = $goodsInfoTmp['tuan_hours'] + $value['prolong_hours'];
			}
			$tuanHoursTmp = intval($tuanHoursTmp);
			$tuanList[$key]['daojishi'] = ($value['tuan_time'] + $tuanHoursTmp * 3600 - TIMESTAMP) * 1000;
			$tuanTeamListTmp = C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->fetch_all_list(' AND tuan_id=' . $value['id'] . ' AND type_id=2 ', 'ORDER BY add_time ASC', 0, 500);
			$tuanTeamList = array();
			$tuanTeamListCount = 1;
			if (is_array($tuanTeamListTmp) && !empty($tuanTeamListTmp)) {
				foreach ($tuanTeamListTmp as $k => $v) {
					$orderinfoTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($v['order_id']);
					if ($orderinfoTmp['order_status'] == 2 || $orderinfoTmp['order_status'] == 3 || $orderinfoTmp['order_status'] == 4 || $orderinfoTmp['order_status'] == 5) {
						$tuanTeamListCount++;
					}
				}
			}
			$tuanList[$key]['shengyuTuanTeamNum'] = $goodsInfoTmp['tuan_num'] - $tuanTeamListCount;
		}
	}
	$photoListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->fetch_all_list(' AND goods_id=' . $goods_id . ' ', 'ORDER BY id ASC', 0, 50);
	$photoList = array();
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tcptuan/') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$photoList[$key] = $value;
			$photoList[$key]['picurl'] = $picurlTmp;
		}
	}
	$orderListTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_list(' AND goods_id=' . $goodsInfo['id'] . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 6);
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tcptuan_goods') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcptuan_order') . (' SET order_status=6 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
				}
			}
		}
	}
	$tuanhelp = str_replace("\r\n", '<br/>', $tcptuanConfig['tuanhelp']);
	$tuanhelp = str_replace("\n", '<br/>', $tuanhelp);
	$tuanhelp = str_replace("\r", '<br/>', $tuanhelp);
	$goodsInfo['ptuan_status'] = update_ptuan_status($goodsInfo);
	$showBuyBtn = 1;
	if ($goodsInfo['status'] != 1 || $goodsInfo['shenhe_status'] != 1) {
		$showBuyBtn = 3;
	}
	if ($goodsInfo['ptuan_status'] == 3) {
		$showBuyBtn = 3;
	}
	if (!$ucenterfilenameExists) {
		$showBuyBtn = 10;
	}
	$showTgButton = 0;
	if ($__ShowTchehuoren == 1 && $goodsInfo['hehuoren_tg_open'] == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfo['id'] > 0 && $tchehuorenInfo['status'] == 1) {
			$dengjiInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
			$dengjiInfo = array();
			if (is_array($dengjiInfoTmp) && !empty($dengjiInfoTmp)) {
				$dengjiInfo = $dengjiInfoTmp;
			}
			if ($dengjiInfo['pt_fc_open'] == 1) {
				if ($goodsInfo['site_id'] > 1) {
					$siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($goodsInfo['site_id']);
					if ($siteInfoTmp['hehuoren_fc_open'] == 1) {
						$showTgButton = 1;
					}
				} else {
					if ($goodsInfo['site_id'] == 1) {
						$showTgButton = 1;
					}
				}
			}
			if ($showTgButton == 1) {
				$needPrice = 0;
				$yongjin_bili = $tcptuanConfig['yongjin_bili'];
				if ($goodsInfo['yongjin_bili'] > 0) {
					$yongjin_bili = $goodsInfo['yongjin_bili'];
				}
				$pay_price = 0;
				$base_price = $goodsInfo['show_tuan_price'];
				if ($goodsInfo['tuanz_status'] == 1 && $goodsInfo['show_tuanz_price'] > 0) {
					$base_price = $goodsInfo['show_tuanz_price'];
				}
				if ($goodsInfo['open_ding_pay'] == 1 && $goodsInfo['ding_price'] > 0) {
					$base_price = $goodsInfo['ding_price'];
				}
				$pay_price = $base_price;
				$pt_money = $pay_price * ($yongjin_bili / 100);
				$pt_money = number_format($pt_money, 2, '.', '');
				if ($dengjiInfo['level'] == 1) {
					$needPrice = $pt_money * ($goodsInfo['chuji_fc_scale'] / 100);
				} elseif ($dengjiInfo['level'] == 2) {
					$needPrice = $pt_money * ($goodsInfo['zhongji_fc_scale'] / 100);
				} elseif ($dengjiInfo['level'] == 3) {
					$needPrice = $pt_money * ($goodsInfo['gaoji_fc_scale'] / 100);
				}
				$needPrice = number_format($needPrice, 2, '.', '');
				$tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
				if ($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1) {
					$tctchehuorenParentInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
					$tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
				}
				if (!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1) {
					$tctchehuorenParent_fc_money = $needPrice * ($tctchehuorenParentDengji['tuijian_fc_scale'] / 100);
					$tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money, 2, '.', '');
					if ($tchehuorenConfig['subordinate_moneytype'] != 1) {
						$needPrice = $needPrice - $tctchehuorenParent_fc_money;
					}
				}
				$tchehuorenUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=goodsinfo&goods_id=' . $goods_id . '&tj_hehuoren_id=' . $tchehuorenInfo['id']);
			}
		}
	}
	if ($showTgButton == 1) {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=goodsinfo&goods_id=') . $goods_id . ('&tj_hehuoren_id=' . $tchehuorenInfo['id']);
	} else {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=goodsinfo&goods_id=') . $goods_id;
	}
	if ($tj_hehuoren_id > 0 && $goodsInfo['hehuoren_tg_open'] == 1) {
		$tuanBuyUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=buy&order_type=1&goods_id=' . $goods_id . ('&tj_hehuoren_id=' . $tj_hehuoren_id);
		$oneBuyUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=buy&order_type=3&goods_id=' . $goods_id . ('&tj_hehuoren_id=' . $tj_hehuoren_id);
	} else {
		$tuanBuyUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=buy&order_type=1&goods_id=' . $goods_id;
		$oneBuyUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=buy&order_type=3&goods_id=' . $goods_id;
	}
	$haibaoQrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($shareUrl);
	$ajaxUpdateTuanstatusUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=updatetuanstatus&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$shareTitle = $goodsInfo['name'];
	$contentTmp = strip_tags($content);
	$contentTmp = str_replace("\r\n", '', $contentTmp);
	$contentTmp = str_replace("\n", '', $contentTmp);
	$contentTmp = str_replace("\r", '', $contentTmp);
	$contentTmp = str_replace(' ', '', $contentTmp);
	$contentTmp = str_replace('	', '', $contentTmp);
	$contentTmp = cutstr($contentTmp, 80, '...');
	if (!empty($contentTmp)) {
		$shareDesc = $contentTmp;
	} else {
		$shareDesc = $goodsInfo['name'];
	}
	$shareLogo = $picurl;
	if ($__ShowTcsign == 1) {
		include DISCUZ_ROOT . './source/plugin/tom_tcsign/renwu/ptuan.php';
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:goodsinfo');
} elseif ($_GET['mod'] == 'help') {
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:help');
} elseif ($_GET['mod'] == 'tuanlistdoing') {
	$goods_id = isset($_GET['goods_id']) ? intval($_GET['goods_id']) : 0;
	$type = isset($_GET['type']) ? intval($_GET['type']) : 1;
	$goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);
	$ajaxLoadTuanListUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=tuanlistdoing&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:tuanlistdoing');
} elseif ($_GET['mod'] == 'tuanlistok') {
	$goods_id = isset($_GET['goods_id']) ? intval($_GET['goods_id']) : 0;
	$type = isset($_GET['type']) ? intval($_GET['type']) : 1;
	$goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);
	$ajaxLoadTuanListUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=tuanlistok&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:tuanlistok');
} elseif ($_GET['mod'] == 'tuan') {
	$tuan_id = isset($_GET['tuan_id']) ? intval($_GET['tuan_id']) : 0;
	$tj_hehuoren_id = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfoTmpTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmpTmp && $tchehuorenInfoTmpTmp['status'] == 1) {
			$tj_hehuoren_id = $tchehuorenInfoTmpTmp['id'];
		}
	}
	$tuanInfo = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_by_id($tuan_id);
	$goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($tuanInfo['goods_id']);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	$goodsInfo['picurl'] = $picurl;
	if (!preg_match('/^http/', $tcshopInfo['picurl'])) {
		if (strpos($tcshopInfo['picurl'], 'source/plugin/tom_tcshop/') === false) {
			$shop_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['picurl'];
		} else {
			$shop_picurl = $tcshopInfo['picurl'];
		}
	} else {
		$shop_picurl = $tcshopInfo['picurl'];
	}
	if (!preg_match('/^http/', $tcshopInfo['kefu_qrcode'])) {
		if (strpos($tcshopInfo['kefu_qrcode'], 'source/plugin/tom_tcshop/') === false) {
			$kefu_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['kefu_qrcode'];
		} else {
			$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
		}
	} else {
		$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
	}
	$kefuSmsUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&&to_user_id=' . $tcshopInfo['user_id'] . '&formhash=' . FORMHASH;
	if ($goodsInfo['show_tuan_price'] <= 0) {
		$goodsInfo['show_tuan_price'] = $goodsInfo['tuan_price'];
	}
	if ($goodsInfo['admin_edit'] == 1) {
		$content = stripslashes($goodsInfo['content']);
	} else {
		$content = stripslashes($goodsInfo['content']);
		$content = strip_tags($content);
		$content = str_replace("\r\n", '<br/>', $content);
		$content = str_replace("\n", '<br/>', $content);
		$content = str_replace("\r", '<br/>', $content);
	}
	DB::query('UPDATE ' . DB::table('tom_tcptuan_goods') . (' SET clicks=clicks+1 WHERE id=\'' . $goodsInfo['id'] . '\''), 'UNBUFFERED');
	$tuanTop = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tuanInfo['user_id']);
	$tuanTeamListTmp = C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->fetch_all_list(' AND tuan_id=' . $tuan_id . ' AND type_id=2 ', 'ORDER BY id ASC', 0, 500);
	$tuanTeamList = array();
	$tuanTeamListCount = 1;
	if (is_array($tuanTeamListTmp) && !empty($tuanTeamListTmp)) {
		foreach ($tuanTeamListTmp as $key => $value) {
			$orderinfoTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($value['order_id']);
			if ($orderinfoTmp['order_status'] == 2 || $orderinfoTmp['order_status'] == 3 || $orderinfoTmp['order_status'] == 4 || $orderinfoTmp['order_status'] == 5) {
				$tuanTeamListCount++;
				$tuanTeamList[$key] = $value;
				$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
				$tuanTeamList[$key]['userInfo'] = $userInfoTmp;
			}
		}
	}
	$shengyuTuanTeamNum = 0;
	if ($goodsInfo['tuan_num'] > $tuanTeamListCount) {
		$shengyuTuanTeamNum = $goodsInfo['tuan_num'] - $tuanTeamListCount;
	}
	$shengyuTuanTeamArr = array();
	for ($i = 1; $i <= $shengyuTuanTeamNum; $i++) {
		$shengyuTuanTeamArr[$i] = 1;
	}
	$addPrint = 0;
	if ($shengyuTuanTeamNum == 0 && $tuanInfo['tuan_status'] == 2) {
		$addPrint = 1;
		$tuanInfo['tuan_status'] = 3;
		$updateData = array();
		$updateData['tuan_status'] = 3;
		$updateData['success_time'] = TIMESTAMP;
		C::t('#tom_tcptuan#tom_tcptuan_tuan')->update($tuanInfo['id'], $updateData);
		C::t('#tom_tcptuan#tom_tcptuan_order')->update_tuan_status_by_tuan_id($tuanInfo['id'], 3);
	}
	$sendPrintAjax = 0;
	if ($tuanInfo['tuan_status'] == 3 && $__ShowPrint == 1 && $addPrint == 1) {
		$sendPrintAjax = 1;
		include DISCUZ_ROOT . './source/plugin/tom_print/print.func.php';
		$orderListTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_like_list(' AND tuan_id=' . $tuan_id . '  ', 'ORDER BY id DESC', 0, 500, '');
		if (is_array($orderListTmp) && !empty($orderListTmp)) {
			foreach ($orderListTmp as $key => $value) {
				if ($value['order_status'] == 2 || $value['order_status'] == 3) {
					@add_ptuan_print($value['order_no']);
				}
			}
		}
	}
	$printAjaxUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=tuan_ok_print&tuan_id=' . $tuan_id . '&formhash=' . FORMHASH;
	$sendTemplateSmsAjax = 0;
	if ($tuanInfo['template_status'] == 0 && $tuanInfo['tuan_status'] == 3) {
		$sendTemplateSmsAjax = 1;
	}
	$templateSmsAjaxUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=tuan_ok_sms&tuan_id=' . $tuan_id . '&formhash=' . FORMHASH;
	$addTuanUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=buy&order_type=2&goods_id=' . $tuanInfo['goods_id'] . '&tuan_id=' . $tuan_id . ('&tj_hehuoren_id=' . $tj_hehuoren_id);
	$showBtnBox = 1;
	if ($__UserInfo['id'] > 0) {
		if ($__UserInfo['id'] == $tuanInfo['user_id']) {
			$showBtnBox = 2;
		} else {
			$tuanUserTeamTmp = C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->fetch_by_tuan_user_id($tuan_id, $__UserInfo['id']);
			if ($tuanUserTeamTmp) {
				$orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($tuanUserTeamTmp['order_id']);
				if ($orderInfo && $orderInfo['order_status'] == 6) {
					$showBtnBox = 4;
				} else {
					$showBtnBox = 3;
				}
			} else {
				$showBtnBox = 4;
			}
		}
	}
	if ($tuanInfo['tuan_status'] != 2) {
		$showBtnBox = 5;
	}
	$tuanHours = $goodsInfo['tuan_hours'];
	if (!empty($tuanInfo['prolong_hours'])) {
		$tuanHours = $goodsInfo['tuan_hours'] + $tuanInfo['prolong_hours'];
	}
	$tuanHours = intval($tuanHours);
	$daojishiTimes = $tuanInfo['tuan_time'] + $tuanHours * 3600 - TIMESTAMP;
	if ($daojishiTimes <= 0 && $tuanInfo['tuan_status'] != 3) {
		$tuanInfo['tuan_status'] = 4;
		$updateData = array();
		$updateData['tuan_status'] = 4;
		C::t('#tom_tcptuan#tom_tcptuan_tuan')->update($tuanInfo['id'], $updateData);
		C::t('#tom_tcptuan#tom_tcptuan_order')->update_tuan_status_by_tuan_id($tuanInfo['id'], 4);
		$daojishiTimes = 0;
		$showBtnBox = 6;
	}
	if ($goodsInfo['peisong_type'] == 1 && $goodsInfo['hexiao_time'] < TIMESTAMP) {
		$showBuyBtn = 6;
	}
	$photoListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->fetch_all_list(' AND goods_id=' . $goodsInfo['id'] . ' ', 'ORDER BY id ASC', 0, 50);
	$photoList = array();
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_tcptuan/') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$photoList[$key] = $value;
			$photoList[$key]['picurl'] = $picurlTmp;
		}
	}
	$tuanhelp = str_replace("\r\n", '<br/>', $tcptuanConfig['tuanhelp']);
	$tuanhelp = str_replace("\n", '<br/>', $tuanhelp);
	$tuanhelp = str_replace("\r", '<br/>', $tuanhelp);
	$shareTitle = str_replace('{NUM}', $shengyuTuanTeamNum, $tcptuanConfig['tuan_share_title']);
	$shareTitle = str_replace('{NAME}', $goodsInfo['name'], $shareTitle);
	$shareTitle = str_replace('{SHOPNAME}', $tcshopInfo['name'], $shareTitle);
	$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	$contentTmp = strip_tags($content);
	$contentTmp = str_replace("\r\n", '', $contentTmp);
	$contentTmp = str_replace("\n", '', $contentTmp);
	$contentTmp = str_replace("\r", '', $contentTmp);
	$contentTmp = str_replace(' ', '', $contentTmp);
	$contentTmp = str_replace('	', '', $contentTmp);
	$contentTmp = cutstr($contentTmp, 80, '...');
	if (!empty($contentTmp)) {
		$shareDesc = $contentTmp;
	} else {
		$shareDesc = $goodsInfo['name'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=tuan&tuan_id=') . $tuan_id;
	$shareLogo = $goodsInfo['picurl'];
	if ($__ShowTchehuoren == 1) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tj_hehuoren_id=' . $tchehuorenInfoTmp['id']);
		}
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:tuan');
} elseif ($_GET['mod'] == 'buy') {
	$goods_id = isset($_GET['goods_id']) ? intval($_GET['goods_id']) : 0;
	$option_id = isset($_GET['option_id']) ? intval($_GET['option_id']) : 0;
	$number = isset($_GET['number']) ? intval($_GET['number']) : 1;
	$address_id = isset($_GET['address_id']) ? intval($_GET['address_id']) : 0;
	$order_type = isset($_GET['order_type']) ? intval($_GET['order_type']) : 0;
	$tuan_id = isset($_GET['tuan_id']) ? intval($_GET['tuan_id']) : 0;
	$tj_hehuoren_id = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
	$back_url = $weixinClass->get_url();
	$back_url = preg_replace('/&address_id=[0-9]*/', '', $back_url);
	$back_url = urlencode($back_url);
	$goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);
	if ($goodsInfo['show_tuan_price'] <= 0) {
		$tuan_price = $goodsInfo['tuan_price'];
		$tuanz_price = $goodsInfo['tuanz_price'];
		$market_price = $goodsInfo['market_price'];
		$one_price = $goodsInfo['one_price'];
	} else {
		$tuan_price = $goodsInfo['show_tuan_price'];
		$tuanz_price = $goodsInfo['show_tuanz_price'];
		$market_price = $goodsInfo['show_market_price'];
		$one_price = $goodsInfo['show_one_price'];
	}
	if ($goodsInfo['hasoption'] == 1) {
		$optionInfo = C::t('#tom_tcptuan#tom_tcptuan_goods_option')->fetch_by_id($option_id);
		if ($optionInfo['id'] > 0) {
			$tuan_price = $optionInfo['tuan_price'];
			$tuanz_price = $optionInfo['tuanz_price'];
			$market_price = $optionInfo['market_price'];
			$one_price = $optionInfo['one_price'];
		}
		$optionListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods_option')->fetch_all_list(' AND goods_id = ' . $goodsInfo['id'] . ' ', 'ORDER BY osort ASC, id DESC', 0, 100);
		$optionList = array();
		if (is_array($optionListTmp) && !empty($optionListTmp)) {
			foreach ($optionListTmp as $key => $value) {
				$optionList[$key] = $value;
				if ($order_type == 1 || $order_type == 2) {
					$option_base_price = $value['tuan_price'];
				} else {
					$option_base_price = $value['one_price'];
				}
				if ($order_type == 1) {
					if ($goodsInfo['tuanz_status'] == 1 && $value['tuanz_price'] > 0) {
						$option_base_price = $value['tuanz_price'];
					}
				}
				$optionList[$key]['base_price'] = $option_base_price;
			}
		}
	}
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	$setAddressStatus = 0;
	$setAddressUrl = '';
	$addressListCount = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_count(' AND uid=' . $__MemberInfo['uid'] . ' ');
	if ($addressListCount == 0) {
		$setAddressStatus = 1;
		$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $back_url);
	}
	$addressInfo = array();
	$addressInfoTmp = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
	if ($addressInfoTmp && !empty($addressInfoTmp['id'])) {
		$address_id = $addressInfoTmp['id'];
		$addressInfo = $addressInfoTmp;
	} else {
		$defaultAddressList = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_list(' AND uid=' . $__MemberInfo['uid'] . ' AND default_id=1 ', 'ORDER BY id DESC', 0, 1);
		if ($defaultAddressList && !empty($defaultAddressList['0']['id'])) {
			$address_id = $defaultAddressList['0']['id'];
			$addressInfo = $defaultAddressList['0'];
		} else {
			$setAddressStatus = 1;
			$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $back_url);
		}
	}
	$changeAddressUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&buying=1&address_id=' . $address_id . '&address_back_url=' . $back_url;
	if ($order_type == 1 || $order_type == 2) {
		$base_price = $tuan_price;
	} else {
		$base_price = $one_price;
	}
	$show_tuanz_price = 0;
	if ($order_type == 1) {
		if ($goodsInfo['tuanz_status'] == 1 && $tuanz_price > 0) {
			$show_tuanz_price = 1;
			$tuan_price = $tuanz_price;
			$base_price = $tuanz_price;
			if ($goodsInfo['tuanz_price_num'] > 0) {
				$goodsInfo['xiangou_num'] = $goodsInfo['tuanz_price_num'];
			}
		}
	}
	$show_ding_price = 0;
	if ($goodsInfo['open_ding_pay'] == 1 && $goodsInfo['ding_price'] > 0) {
		$show_ding_price = 1;
		$base_price = $goodsInfo['ding_price'];
	}
	$express_price = $goodsInfo['express_price'];
	if ($goodsInfo['peisong_type'] == 1 || $goodsInfo['express_type'] == 1) {
		$express_price = 0;
	}
	$express_price_arr = array();
	for ($i = 1; $i <= 100; $i++) {
		if ($goodsInfo['express_type'] == 3) {
			$express_price_arr[$i] = $express_price * $i;
		} elseif ($goodsInfo['express_type'] == 2) {
			$express_price_arr[$i] = $express_price;
		} else {
			$express_price_arr[$i] = 0;
		}
	}
	$pay_price = 0;
	if ($goodsInfo['express_type'] == 3) {
		$pay_price = $express_price * $number + $base_price * $number;
	} elseif ($goodsInfo['express_type'] == 2) {
		$pay_price = $express_price + $base_price * $number;
	} else {
		$pay_price = $base_price * $number;
	}
	$orderListTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_list(' AND goods_id=' . $goodsInfo['id'] . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 6);
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tcptuan_goods') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcptuan_order') . (' SET order_status=6 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
				}
			}
		}
	}
	$noPayOrderListTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_list(' AND goods_id=' . $goodsInfo['id'] . ' AND user_id=' . $__UserInfo['id'] . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 6);
	$isHaveNoPay = 0;
	if (is_array($noPayOrderListTmp) && !empty($noPayOrderListTmp)) {
		foreach ($noPayOrderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tcptuan_goods') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcptuan_order') . (' SET order_status=6 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
				} else {
					$isHaveNoPay = 1;
				}
			}
		}
	}
	$xiangouStatus = 0;
	$goods_xiangou_num = 0;
	if ($goodsInfo['xiangou_num'] > 0) {
		$myHaveOrderCount = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(' AND user_id=' . $__UserInfo['id'] . ' AND goods_id=' . $goods_id . ' AND order_status IN(2,3,4,5) ');
		$goods_xiangou_num = $goodsInfo['xiangou_num'] - $myHaveOrderCount;
		if ($myHaveOrderCount >= $goodsInfo['xiangou_num']) {
			$xiangouStatus = 1;
		}
	}
	if ($order_type == 2 && $tuan_id > 0 && $__ShowTchehuoren == 1 && $tj_hehuoren_id == 0) {
		$hehuorenOrderTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_list(' AND tuan_id=' . $tuan_id . ' AND order_status IN(2,3) AND order_type=1 ', ' ORDER BY id DESC ', 0, 1);
		if (is_array($hehuorenOrderTmp) && !empty($hehuorenOrderTmp) && $hehuorenOrderTmp[0]['tj_hehuoren_id'] > 0) {
			$tj_hehuoren_id = $hehuorenOrderTmp[0]['tj_hehuoren_id'];
		} else {
			if (is_array($hehuorenOrderTmp) && !empty($hehuorenOrderTmp)) {
				$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($hehuorenOrderTmp['user_id']);
				if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
					$tj_hehuoren_id = $tchehuorenInfoTmp['id'];
				}
			}
		}
	}
	$xm = '';
	$tel = $__UserInfo['tel'];
	$userOrderTmp = array();
	if ($goodsInfo['peisong_type'] == 1) {
		$userOrderTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' AND peisong_type=1  AND order_status IN(2,3,4,5) ', ' ORDER BY id DESC ', 0, 1);
	}
	if (is_array($userOrderTmp) && !empty($userOrderTmp) && !empty($userOrderTmp[0]['tel'])) {
		$xm = $userOrderTmp[0]['xm'];
		$tel = $userOrderTmp[0]['tel'];
	}
	$ajaxPayUrl = 'plugin.php?id=tom_tcptuan:pay&site=' . $site_id;
	$orderUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=order';
	$tuanUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=tuan&tuan_id=';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:buy');
} elseif ($_GET['mod'] == 'groups') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$whereStr = ' AND a.user_id=' . $__UserInfo['id'] . ' ';
	if ($type == 1) {
		$whereStr .= ' AND b.tuan_status=2 ';
	} elseif ($type == 2) {
		$whereStr .= ' AND b.tuan_status=3 ';
	} elseif ($type == 3) {
		$whereStr .= ' AND b.tuan_status=4 ';
	}
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->fetch_all_count_left_tuan(' ' . $whereStr . ' ');
	$tuanListTmp = C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->fetch_all_list_left_tuan(' ' . $whereStr . ' ', 'ORDER BY a.id DESC', $start, $pagesize);
	$tuanList = array();
	if (is_array($tuanListTmp) && !empty($tuanListTmp)) {
		foreach ($tuanListTmp as $key => $value) {
			$tuanList[$key] = $value;
			$tuanInfo = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_by_id($value['tuan_id']);
			$tuanList[$key]['tuanInfo'] = $tuanInfo;
			$goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($value['goods_id']);
			if (!preg_match('/^http/', $goodsInfo['picurl'])) {
				$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
			} else {
				$picurl = $goodsInfo['picurl'];
			}
			$goodsInfo['picurl'] = $picurl;
			if ($goodsInfo['show_tuan_price'] < 0) {
				$goodsInfo['show_tuan_price'] = $goodsInfo['tuan_price'];
			}
			$tuanList[$key]['goodsInfo'] = $goodsInfo;
			$orderinfoTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($value['order_id']);
			$tuanList[$key]['orderinfo'] = $orderinfoTmp;
			$tuanList[$key]['tuanUrl'] = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=tuan&tuan_id=' . $value['tuan_id'];
			$tuanList[$key]['orderUrl'] = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=orderinfo&order_no=' . $orderinfoTmp['order_no'];
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=groups&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=groups&page=' . $nextPage;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:groups');
} elseif ($_GET['mod'] == 'myfabu') {
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$whereStr = ' AND user_id = ' . $__UserInfo['id'] . ' ';
	$orderStr = ' ORDER BY id DESC ';
	if ($type == 1) {
		$whereStr .= ' AND status = 1 AND shenhe_status = 1 ';
	} elseif ($type == 2) {
		$whereStr .= ' AND (shenhe_status = 2 OR shenhe_status = 3)';
		$orderStr = ' ORDER BY shenhe_status ASC, id DESC ';
	}
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_count(' ' . $whereStr . ' ');
	$goodsListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_list($whereStr, $orderStr, $start, $pagesize);
	$goodsList = array();
	foreach ($goodsListTmp as $key => $value) {
		$goodsList[$key] = $value;
		if (!preg_match('/^http/', $value['picurl'])) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
		} else {
			$picurl = $value['picurl'];
		}
		$goodsList[$key]['picurl'] = $picurl;
		if ($value['show_tuan_price'] < 0) {
			$show_tuan_price = $value['tuan_price'];
			$show_market_price = $value['market_price'];
		} else {
			$show_tuan_price = $value['show_tuan_price'];
			$show_market_price = $value['show_market_price'];
		}
		$goodsList[$key]['show_tuan_price'] = $show_tuan_price;
		$goodsList[$key]['show_market_price'] = $show_market_price;
		$goodsList[$key]['link'] = 'plugin.php?id=tom_tcptuan&site=' . $value['site_id'] . '&mod=goodsinfo&goods_id=' . $value['id'];
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=myfabu&type=' . $type . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=myfabu&type=' . $type . '&page=' . $nextPage;
	$ajaxUpdateStatusUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=updateStatus&&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:myfabu');
} elseif ($_GET['mod'] == 'order') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$whereStr = ' AND user_id=' . $__UserInfo['id'] . ' ';
	if ($type == 1) {
		$whereStr .= ' AND order_status=1 ';
	} elseif ($type == 2) {
		$whereStr .= ' AND order_status IN (2,3,4) ';
	} elseif ($type == 3) {
		$whereStr .= ' AND order_status=5 ';
	}
	$pagesize = 10;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_count($whereStr);
	$orderListTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_list($whereStr, ' ORDER BY id DESC ', $start, $pagesize);
	$orderList = array();
	$choujiangIdArr = array();
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			$orderList[$key] = $value;
			$goodsInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($value['goods_id']);
			if (!preg_match('/^http/', $goodsInfoTmp['picurl'])) {
				$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfoTmp['picurl'];
			} else {
				$picurl = $goodsInfoTmp['picurl'];
			}
			$orderList[$key]['picurl'] = $picurl;
			$orderList[$key]['order_time'] = dgmdate($value['order_time'], 'Y-m-d H:i:s', $tomSysOffset);
			$orderList[$key]['orderUrl'] = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=orderinfo&order_no=' . $value['order_no'];
			$orderList[$key]['choujiang'] = 0;
			if ($__ShowTcchoujiang == 1 && $goodsInfoTmp['tcchoujiang_id'] > 0) {
				$choujiangBmInfoTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($goodsInfoTmp['tcchoujiang_id'], $value['user_id']);
				if ($choujiangBmInfoTmp['id'] > 0 && $choujiangBmInfoTmp['cj_times'] > 0) {
					if (!in_array($goodsInfoTmp['tcchoujiang_id'], $choujiangIdArr)) {
						$orderList[$key]['choujiang'] = 1;
						$orderList[$key]['tcchoujiang_id'] = $goodsInfoTmp['tcchoujiang_id'];
						$choujiangIdArr[] = $goodsInfoTmp['tcchoujiang_id'];
					}
				}
			}
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3590) {
					DB::query('UPDATE ' . DB::table('tom_tcptuan_goods') . (' SET sale_num=sale_num-' . $value['goods_num'] . ' WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcptuan_order') . (' SET order_status=6 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
					$orderList[$key]['order_status'] = 6;
				}
			}
		}
	}
	$ajaxPayUrl = 'plugin.php?id=tom_tcptuan:pay&site=' . $site_id . '&act=pay&formhash=' . FORMHASH;
	$ajaxCancelPayUrl = 'plugin.php?id=tom_tcptuan:pay&site=' . $site_id . '&act=cancelpay&formhash=' . FORMHASH;
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=order&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=order&page=' . $nextPage;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:order');
} elseif ($_GET['mod'] == 'orderinfo') {
	$order_no = isset($_GET['order_no']) ? addslashes($_GET['order_no']) : '';
	$orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_order_no($order_no);
	$goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($orderInfo['goods_id']);
	if ($_GET['act'] == 'qianshou' && $_GET['formhash'] == FORMHASH) {
		if ($orderInfo['peisong_type'] == 1) {
			echo 501;
			exit(0);
		}
		if ($orderInfo['order_status'] == 1) {
			echo 502;
			exit(0);
		}
		$updateData = array();
		$updateData['order_status'] = 5;
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['hexiao_time'] = TIMESTAMP;
		C::t('#tom_tcptuan#tom_tcptuan_order')->update($orderInfo['id'], $updateData);
		if ($tcptuanConfig['balance_type'] == 1 && $orderInfo['balance_status'] == 0) {
			include DISCUZ_ROOT . './source/plugin/tom_tcptuan/module/balance.php';
		}
		echo 200;
		exit(0);
	}
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	$hexiaoUserInfo = array();
	if ($orderInfo['order_status'] == 5) {
		$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);
	}
	$stateStr = '';
	if ($orderInfo['order_status'] == 1 || $orderInfo['order_status'] == 2 || $orderInfo['order_status'] == 3) {
		$stateStr = 'state_1';
	}
	if ($orderInfo['order_status'] == 4) {
		$stateStr = 'state_2';
	}
	if ($orderInfo['order_status'] == 5) {
		$stateStr = 'state_3';
	}
	$showQrcodeBox = 0;
	if ($orderInfo['order_status'] == 2 || $orderInfo['order_status'] == 3 || $orderInfo['order_status'] == 4) {
		if ($orderInfo['order_type'] == 3) {
			$showQrcodeBox = 1;
		} elseif ($orderInfo['tuan_status'] == 3) {
			$showQrcodeBox = 1;
		}
	}
	$hexiaoTimeStatus = 1;
	if (TIMESTAMP > $goodsInfo['hexiao_time']) {
		$hexiaoTimeStatus = 2;
	}
	$qrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($_G['siteurl'] . 'plugin.php?id=tom_tcptuan&site=' . $site_id . ('&mod=orderhexiao&hexiao_no=' . $orderInfo['hexiao_no']));
	$showChoujiang = 0;
	if ($__ShowTcchoujiang == 1 && $goodsInfo['tcchoujiang_id'] > 0) {
		$choujiangBmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($goodsInfo['tcchoujiang_id'], $__UserInfo['id']);
		if ($choujiangBmInfo['id'] > 0 && $choujiangBmInfo['cj_times'] > 0) {
			$showChoujiang = 1;
		}
	}
	$kuaidiSmsList = array();
	if (!empty($orderInfo['kuaidi_no']) && !empty($orderInfo['kuaidi_type']) && $__ShowKuaidi == 1) {
		include DISCUZ_ROOT . './source/plugin/tom_kuaidi/kuaidi.func.php';
		$kuaidiNoArr = explode(' ', $orderInfo['kuaidi_no']);
		if (is_array($kuaidiNoArr) && !empty($kuaidiNoArr)) {
			foreach ($kuaidiNoArr as $key => $value) {
				$value = trim($value);
				if (!empty($value)) {
					$kuaidiArr = query_kuaidi($value, $orderInfo['kuaidi_type']);
					if ($kuaidiArr) {
						$kuaidiSmsList[$key] = $kuaidiArr;
						$kuaidiSmsList[$key]['kuaidi_no'] = $value;
					}
				}
			}
		}
	}
	$back_url = $weixinClass->get_url();
	$tcyuyueStatus = 0;
	if ($__ShowTcyuyue == 1 && $orderInfo['order_status'] == 2 && $orderInfo['peisong_type'] == 1 && $goodsInfo['open_yuyue'] == 1 && $goodsInfo['yuyue_type'] == 3 && $goodsInfo['tcyuyue_id'] > 0 && ($orderInfo['order_type'] == 3 || $orderInfo['tuan_status'] == 3)) {
		$tcyuyueStatus = 1;
		$tcyuyueUrl = 'plugin.php?id=tom_tcyuyue&site_id=' . $site_id . '&mod=info&order_no=' . $orderInfo['order_no'] . '&yuyue_type=ptuan&buy_status=2&back_url=' . urlencode($back_url);
		if ($orderInfo['tcyuyue_log_id'] > 0) {
			$tcyuyueLogInfo = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_by_id($orderInfo['tcyuyue_log_id']);
			if ($tcyuyueLogInfo && ($tcyuyueLogInfo['yuyue_status'] == 1 || $tcyuyueLogInfo['yuyue_status'] == 3)) {
				$tcyuyueStatus = 2;
				$tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyueLogInfo['tcyuyue_id']);
				$tcyuyueEditUrl = 'plugin.php?id=tom_tcyuyue&site_id=' . $site_id . '&mod=info&order_no=' . $orderInfo['order_no'] . '&tcyuyue_log_id=' . $tcyuyueLogInfo['id'] . '&yuyue_type=ptuan&buy_status=2&back_url=' . urlencode($back_url);
				$tcyuyueLogInfo['yuyue_start_time'] = $tcyuyueLogInfo['time_start_stamp'] + $tcyuyueLogInfo['yuyue_daytime'];
				$tcyuyueLogInfo['yuyue_end_time'] = $tcyuyueLogInfo['time_end_stamp'] + $tcyuyueLogInfo['yuyue_daytime'];
				if (TIMESTAMP >= $tcyuyueLogInfo['yuyue_start_time'] && TIMESTAMP < $tcyuyueLogInfo['yuyue_end_time']) {
					$tcyuyueStatus = 3;
				}
				if ($tcyuyueLogInfo['clerk_id'] > 0) {
					$clerkInfo = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_by_id($tcyuyueLogInfo['clerk_id']);
					if (!preg_match('/^http/', $clerkInfo['picurl'])) {
						if (strpos($clerkInfo['picurl'], 'source/plugin/tom_') === false) {
							$clerkInfo['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $clerkInfo['picurl'];
						} else {
							$clerkInfo['picurl'] = $_G['siteurl'] . $clerkInfo['picurl'];
						}
					} else {
						$clerkInfo['picurl'] = $clerkInfo['picurl'];
					}
				}
				$attrListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_log_attr')->fetch_all_list(' AND tcyuyue_log_id = ' . $tcyuyueLogInfo['id'] . ' ', ' ORDER BY paixu ASC,id DESC ');
				$yuyueAttrList = array();
				if (is_array($attrListTmp) && !empty($attrListTmp)) {
					foreach ($attrListTmp as $k => $v) {
						$yuyueAttrList[$k] = $v;
						if ($v['attr_type'] == 4) {
							$yuyueAttrList[$k]['valueList'] = explode('|', $v['value']);
						}
					}
				}
			}
		}
	}
	$qianshouUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=orderinfo&act=qianshou&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:orderinfo');
} elseif ($_GET['mod'] == 'orderhexiao') {
	$hexiao_no = isset($_GET['hexiao_no']) ? addslashes($_GET['hexiao_no']) : '';
	$orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_hexiao_no($hexiao_no);
	$goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($orderInfo['goods_id']);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	if ($_GET['act'] == 'hexiao' && $_GET['formhash'] == FORMHASH) {
		$hexiao_pwd = isset($_GET['hexiao_pwd']) ? addslashes($_GET['hexiao_pwd']) : '';
		if ($tcptuanConfig['hexiao_type'] == 2) {
			if (empty($goodsInfo['hexiao_pwd'])) {
				echo 301;
				exit(0);
			}
			if ($goodsInfo['hexiao_pwd'] != $hexiao_pwd) {
				echo 302;
				exit(0);
			}
		}
		$updateData = array();
		$updateData['order_status'] = 5;
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['hexiao_time'] = TIMESTAMP;
		C::t('#tom_tcptuan#tom_tcptuan_order')->update($orderInfo['id'], $updateData);
		if ($__ShowTcyuyue == 1 && $orderInfo['tcyuyue_log_id'] > 0) {
			$updateData = array();
			$updateData['yuyue_status'] = 2;
			$updateData['hexiao_user_id'] = $__UserInfo['id'];
			$updateData['hexiao_time'] = TIMESTAMP;
			C::t('#tom_tcyuyue#tom_tcyuyue_log')->update($orderInfo['tcyuyue_log_id'], $updateData);
		}
		if ($tcptuanConfig['balance_type'] == 1 && $orderInfo['balance_status'] == 0) {
			include DISCUZ_ROOT . './source/plugin/tom_tcptuan/module/balance.php';
		}
		echo 200;
		exit(0);
	}
	$isTcshopClerk = 0;
	$clerkListTmp = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(' AND tcshop_id=' . $orderInfo['tcshop_id'] . ' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 1);
	if (!empty($clerkListTmp[0]['id']) || $tcshopInfo['user_id'] == $__UserInfo['id']) {
		$isTcshopClerk = 1;
	}
	$hexiaoUserInfo = array();
	if ($orderInfo['order_status'] == 5) {
		$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);
	}
	$showHexiaoBox = 1;
	if ($tcptuanConfig['hexiao_type'] == 1 && $isTcshopClerk == 0) {
		$showHexiaoBox = 2;
	}
	$showBtnBox = 0;
	if ($orderInfo['order_status'] == 2 || $orderInfo['order_status'] == 3 || $orderInfo['order_status'] == 4) {
		if ($orderInfo['order_type'] == 3) {
			$showBtnBox = 1;
		} elseif ($orderInfo['tuan_status'] == 3) {
			$showBtnBox = 1;
		}
	}
	$hexiaoUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=orderhexiao&act=hexiao&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:orderhexiao');
} elseif ($_GET['mod'] == 'myorder') {
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$goods_id = isset($_GET['goods_id']) ? intval($_GET['goods_id']) : 0;
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 100);
	$tcshopListId = array();
	if (is_array($tcshopListTmp) && !empty($tcshopListTmp)) {
		foreach ($tcshopListTmp as $key => $value) {
			$tcshopListId[] = $value['id'];
		}
	}
	$tcshopListIdStr = '99999999999';
	if (is_array($tcshopListId) && !empty($tcshopListId)) {
		$tcshopListIdStr = implode(',', $tcshopListId);
	}
	$whereStr = ' AND tcshop_id IN(' . $tcshopListIdStr . ') ';
	$whereTjStr = ' AND tcshop_id IN(' . $tcshopListIdStr . ') ';
	$orderStr = ' ORDER BY id DESC ';
	if (!empty($goods_id)) {
		$whereStr .= ' AND goods_id=' . $goods_id . ' ';
		$whereTjStr .= ' AND goods_id=' . $goods_id . ' ';
	}
	if ($type == 1) {
		$whereStr .= ' AND order_status=2 AND (tuan_status=3 OR order_type=3)  ';
	} elseif ($type == 2) {
		$whereStr .= ' AND order_status=4 ';
	} elseif ($type == 3) {
		$whereStr .= ' AND order_status=5 ';
	}
	if (!empty($keyword)) {
		$whereStr .= ' AND tel=\'' . $keyword . '\' ';
		$whereTjStr .= ' AND tel=\'' . $keyword . '\' ';
	}
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$count = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_count(' ' . $whereStr . ' ');
	$count2 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(' ' . $whereTjStr . ' AND order_status=2 AND tuan_status=3 ');
	$count4 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(' ' . $whereTjStr . ' AND order_status=4 ');
	$count5 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(' ' . $whereTjStr . ' AND order_status=5 ');
	$orderListTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_list($whereStr, $orderStr, $start, $pagesize);
	$orderList = array();
	foreach ($orderListTmp as $key => $value) {
		$orderList[$key] = $value;
		$goodsInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($value['goods_id']);
		if (!preg_match('/^http/', $goodsInfoTmp['picurl'])) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfoTmp['picurl'];
		} else {
			$picurl = $goodsInfoTmp['picurl'];
		}
		if ($goodsInfoTmp['show_tuan_price'] < 0) {
			$goodsInfoTmp['show_tuan_price'] = $value['tuan_price'];
		}
		$orderList[$key]['goodsInfo'] = $goodsInfoTmp;
		$orderList[$key]['goodsInfo']['picurl'] = $picurl;
		$orderList[$key]['pay_time'] = dgmdate($goodsInfoTmp['pay_time'], 'm-d H:i', $tomSysOffset);
		$orderList[$key]['goodsInfo']['link'] = 'plugin.php?id=tom_tcptuan&site=' . $value['site_id'] . '&mod=goodsinfo&goods_id=' . $goodsInfoTmp['id'];
		$orderList[$key]['url'] = 'plugin.php?id=tom_tcptuan&site=' . $value['site_id'] . '&mod=myorderinfo&order_no=' . $value['order_no'];
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=myorder&goods_id=' . $goods_id . '&type=' . $type . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=myorder&goods_id=' . $goods_id . '&type=' . $type . '&page=' . $nextPage;
	$searchUrl = 'plugin.php?id=tom_tcptuan:ajax&site=' . $site_id . '&act=get_order_search_url';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:myorder');
} elseif ($_GET['mod'] == 'myorderinfo') {
	$order_no = !empty($_GET['order_no']) ? addslashes($_GET['order_no']) : '';
	$orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_order_no($order_no);
	$goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($orderInfo['goods_id']);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	$clerkAllowTmp = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(' AND tcshop_id=' . $goodsInfo['tcshop_id'] . ' AND user_id=' . $__UserInfo['id'] . ' ', ' ORDER BY id DESC ', 0, 1);
	if (empty($clerkAllowTmp[0]['id']) && $tcshopInfo['user_id'] != $__UserInfo['id']) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	if ($_GET['act'] == 'fahuo' && $_GET['formhash'] == FORMHASH) {
		$outArr = array('status' => 1, 'code' => 1);
		if ('utf-8' != CHARSET) {
			if (!defined('IN_MOBILE')) {
				foreach ($_POST as $pk => $pv) {
					if (!is_numeric($pv)) {
						$_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
					}
				}
			}
		}
		$peisong_info = isset($_GET['peisong_info']) ? addslashes($_GET['peisong_info']) : '';
		$kuaidi_type = isset($_GET['kuaidi_type']) ? addslashes($_GET['kuaidi_type']) : '';
		$kuaidi_no = isset($_GET['kuaidi_no']) ? addslashes($_GET['kuaidi_no']) : '';
		if ($orderInfo['peisong_type'] == 2 && $__ShowKuaidi == 1 && !empty($kuaidi_type)) {
			$kuaidiInfo = C::t('#tom_kuaidi#tom_kuaidi')->fetch_by_type($kuaidi_type);
			if (is_array($kuaidiInfo) && !empty($kuaidiInfo)) {
				$peisong_info = $kuaidiInfo['name'] . ' ' . $kuaidi_no;
			}
		}
		$updateData = array();
		$updateData['peisong_info'] = $peisong_info;
		if ($orderInfo['peisong_type'] == 2) {
			$updateData['kuaidi_type'] = $kuaidi_type;
			$updateData['kuaidi_no'] = $kuaidi_no;
		}
		$updateData['order_status'] = 4;
		$updateData['peisong_time'] = TIMESTAMP;
		C::t('#tom_tcptuan#tom_tcptuan_order')->update($orderInfo['id'], $updateData);
		if (!empty($tcptuanConfig['template_fahuo'])) {
			include DISCUZ_ROOT . './source/plugin/tom_tcptuan/class/templatesms.class.php';
			$access_token = $weixinClass->get_access_token();
			$orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
			if ($access_token && !empty($orderUserInfoTmp['openid'])) {
				$templateSmsClass = new ptTemplateSms($access_token, $_G['siteurl'] . ('plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=orderinfo&order_no=' . $order_no));
				$smsData = array('first' => lang('plugin/tom_tcptuan', 'template_sms_fahuo'), 'keyword1' => $orderInfo['order_no'], 'keyword2' => $orderInfo['goods_name'], 'keyword3' => $orderInfo['goods_num'], 'keyword4' => $orderInfo['pay_price'], 'remark' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s', $tomSysOffset));
				$r = $templateSmsClass->sendSmsFahuo($orderUserInfoTmp['openid'], $tcptuanConfig['template_fahuo'], $smsData);
			}
		}
		$outArr = array('status' => 200, 'code' => 200);
		echo json_encode($outArr);
		exit(0);
	} elseif ($_GET['act'] == 'qianshou' && $_GET['formhash'] == FORMHASH) {
		$outArr = array('status' => 1, 'code' => 1);
		if ($orderInfo['peisong_type'] == 1) {
			$outArr = array('status' => 500, 'code' => 500);
			echo json_encode($outArr);
			exit(0);
		}
		if ($orderInfo['order_status'] == 1) {
			$outArr = array('status' => 501, 'code' => 500);
			echo json_encode($outArr);
			exit(0);
		}
		$updateData = array();
		$updateData['order_status'] = 5;
		$updateData['hexiao_user_id'] = $__UserInfo['id'];
		$updateData['hexiao_time'] = TIMESTAMP;
		C::t('#tom_tcptuan#tom_tcptuan_order')->update($orderInfo['id'], $updateData);
		if ($tcptuanConfig['balance_type'] == 1 && $orderInfo['balance_status'] == 0) {
			include DISCUZ_ROOT . './source/plugin/tom_tcptuan/module/balance.php';
		}
		$outArr = array('status' => 200, 'code' => 200);
		echo json_encode($outArr);
		exit(0);
	}
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/tom_tcptuan/') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$picurl = $goodsInfo['picurl'];
		}
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	$stateStr = '';
	if ($orderInfo['order_status'] == 1 || $orderInfo['order_status'] == 2 || $orderInfo['order_status'] == 3) {
		$stateStr = 'state_1';
	}
	if ($orderInfo['order_status'] == 4) {
		$stateStr = 'state_2';
	}
	if ($orderInfo['order_status'] == 5) {
		$stateStr = 'state_3';
	}
	$hexiaoUserInfo = array();
	if ($orderInfo['order_status'] == 5) {
		$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);
	}
	$showQianshouBtn = 0;
	if ($orderInfo['order_status'] == 4 && $orderInfo['peisong_time'] > 0) {
		if (TIMESTAMP > $orderInfo['peisong_time'] + 86400 * $tcptuanConfig['shop_qianshou_days']) {
			$showQianshouBtn = 1;
		}
	}
	$showFahuoBox = 0;
	if ($orderInfo['order_status'] == 2 || $orderInfo['order_status'] == 3 || $orderInfo['order_status'] == 4) {
		if ($orderInfo['order_type'] == 3) {
			$showFahuoBox = 1;
		} elseif ($orderInfo['tuan_status'] == 3) {
			$showFahuoBox = 1;
		}
	}
	$kuaidiList = array();
	if ($orderInfo['peisong_type'] == 2 && $__ShowKuaidi == 1) {
		$kuaidiListTmp = C::t('#tom_kuaidi#tom_kuaidi')->fetch_all_list(' ', 'ORDER BY sort ASC, id DESC');
		if (is_array($kuaidiListTmp) && !empty($kuaidiListTmp)) {
			foreach ($kuaidiListTmp as $key => $value) {
				$kuaidiList[$key] = $value;
			}
		}
	}
	$showPeisongBox = 1;
	if ($orderInfo['peisong_type'] == 2) {
		if ($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList) && empty($orderInfo['peisong_info'])) {
			$showPeisongBox = 2;
		}
		if ($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList) && !empty($orderInfo['kuaidi_no']) && !empty($orderInfo['kuaidi_type'])) {
			$showPeisongBox = 2;
		}
		$kuaidiSmsList = array();
		if (!empty($orderInfo['kuaidi_no']) && !empty($orderInfo['kuaidi_type']) && $__ShowKuaidi == 1) {
			include DISCUZ_ROOT . './source/plugin/tom_kuaidi/kuaidi.func.php';
			$kuaidiNoArr = explode(' ', $orderInfo['kuaidi_no']);
			if (is_array($kuaidiNoArr) && !empty($kuaidiNoArr)) {
				foreach ($kuaidiNoArr as $key => $value) {
					$value = trim($value);
					if (!empty($value)) {
						$kuaidiArr = query_kuaidi($value, $orderInfo['kuaidi_type']);
						if ($kuaidiArr) {
							$kuaidiSmsList[$key] = $kuaidiArr;
							$kuaidiSmsList[$key]['kuaidi_no'] = $value;
						}
					}
				}
			}
		}
	}
	$fahuoUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=myorderinfo&act=fahuo&formhash=' . $formhash;
	$qianshouUrl = 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=myorderinfo&act=qianshou&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcptuan:myorderinfo');
} elseif ($_GET['mod'] == 'fabu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcptuan/module/fabu.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcptuan/module/edit.php';
} elseif ($_GET['mod'] == 'editstock') {
	include DISCUZ_ROOT . './source/plugin/tom_tcptuan/module/editstock.php';
} elseif ($_GET['mod'] == 'editoption') {
	include DISCUZ_ROOT . './source/plugin/tom_tcptuan/module/editoption.php';
} elseif ($_GET['mod'] == 'editpwd') {
	include DISCUZ_ROOT . './source/plugin/tom_tcptuan/module/editpwd.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tcptuan/module/upload.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();