<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_id = intval($_GET['order_id'])>0? intval($_GET['order_id']):0;
$orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($order_id);
if(empty($orderInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);
if($__UserInfo['id'] != $tcshopInfo['user_id']){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=orderinfo&order_id={$order_id}";

$userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($orderInfo['user_id']);
$hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']);
$goodsInfo =  C::t("#tom_tcptuan#tom_tcptuan_goods")->fetch_by_id($orderInfo['goods_id']);
$goodsInfo['picurl'] = get_file_url($goodsInfo['picurl']);

$site_name_tmp = $Lang['sites_one'];
if($orderInfo['site_id'] > 1){
    $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
    $site_name_tmp = $siteInfoTmp['name'];
}

$orderInfo['site_name']         = $site_name_tmp;
$orderInfo['orderTime']         = dgmdate($orderInfo['order_time'], 'Y-m-d H:i:s',$tomSysOffset);
$orderInfo['payTime']           = dgmdate($orderInfo['pay_time'], 'Y-m-d H:i:s',$tomSysOffset);
$orderInfo['hexiaoTime']        = dgmdate($orderInfo['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //d'.'i'.'sm.ta'.'o'.'bao.com
include template("tom_tcptuan:pcshopadmin/orderinfo");