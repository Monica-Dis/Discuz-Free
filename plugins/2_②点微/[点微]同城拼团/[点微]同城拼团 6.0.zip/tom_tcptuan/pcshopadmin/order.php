<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=order";

$user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):'';
$goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):'';
$tuan_id        = isset($_GET['tuan_id'])? intval($_GET['tuan_id']):'';
$order_no       = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
$order_tel      = !empty($_GET['order_tel'])? trim(addslashes($_GET['order_tel'])):'';
$order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;
$order_type     = isset($_GET['order_type'])? intval($_GET['order_type']):0;
$tuan_status    = isset($_GET['tuan_status'])? intval($_GET['tuan_status']):0;
$start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
$end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$kuaidiList = array();
if($__ShowKuaidi == 1){
    include DISCUZ_ROOT.'./source/plugin/tom_kuaidi/kuaidi.func.php';
    $kuaidiListTmp = C::t("#tom_kuaidi#tom_kuaidi")->fetch_all_list(" ", 'ORDER BY sort ASC, id DESC');
    if(is_array($kuaidiListTmp) && !empty($kuaidiListTmp)){
        foreach($kuaidiListTmp as $key => $value){
            $kuaidiList[$key] = $value;
        }
    }
}

$where = "";
if($goods_id > 0){
    $goodsInfo = C::t("#tom_tcptuan#tom_tcptuan_goods")->fetch_by_id($goods_id);
    if(!empty($goodsInfo) && $goodsInfo['user_id'] == $__UserInfo['id']){
        $where .= " AND goods_id = {$goods_id} ";
    }else{
        $where .= " AND goods_id = 999999999 ";
    }
}else{
    $tcshopIdsListTmp = C::t("#tom_tcshop#tom_tcshop")->fetch_all_field_list(" AND user_id = {$__UserInfo['id']} ", 'id');
    $tcshopIdsList = array();
    if(!empty($tcshopIdsListTmp)){
        foreach($tcshopIdsListTmp as $key => $value){
            $tcshopIdsList[] = $value['id'];
        }
    }
    
    if(!empty($tcshopIdsList)){
        $tcshopIdsStr = implode(',', $tcshopIdsList);
        $where .= " AND tcshop_id IN({$tcshopIdsStr}) ";
    }else{
        $where .= " AND tcshop_id = 999999999 ";
    }
}
if($user_id > 0){
    $where.=" AND user_id='{$user_id}' ";
}
if(!empty($order_no)){
    $where.=" AND order_no='{$order_no}' ";
}
if(!empty($order_tel)){
    $where.=" AND tel='{$order_tel}' ";
}
if(!empty($order_status)){
    $where.=" AND order_status={$order_status} ";
}
if(!empty($tuan_id)){
    $where.=" AND tuan_id={$tuan_id} ";
}
if(!empty($order_type)){
    $where.=" AND order_type={$order_type} ";
}
if($tuan_status){
    $where.= " AND tuan_status={$tuan_status} ";
}
if(!empty($start_time)){
    $startTime = strtotime($start_time);
    $where.=" AND order_time >=  {$startTime} ";
}
if(!empty($end_time)){
    $endTime = strtotime($end_time);
    $where.=" AND order_time < {$endTime} ";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_like_count($where,'');
$orderListTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_like_list($where,"ORDER BY order_time DESC,id DESC",$start,$pagesize,'');
$orderList = array();
if(!empty($orderListTmp)){
    foreach($orderListTmp as $key => $value){
        $goodsInfoTmp = C::t("#tom_tcptuan#tom_tcptuan_goods")->fetch_by_id($value['goods_id']);
        if(!empty($goodsInfoTmp) && $goodsInfoTmp['user_id'] == $__UserInfo['id']){
            $orderList[$key] = $value;

            $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
            $hexiaoUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
            $goodsInfoTmp['picurl'] = get_file_url($goodsInfoTmp['picurl']);

            $site_name_tmp = $Lang['sites_one'];
            if($value['site_id'] > 1){
                $siteInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_sites")->fetch_by_id($value['goods_id']);
                $site_name_tmp = $siteInfoTmp['name'];
            }

            $showFahuoBoxTmp = 0;
            if($value['order_status'] == 2 || $value['order_status'] == 3 || $value['order_status'] == 4){
                if($value['order_type'] == 3 ){
                    $showFahuoBoxTmp = 1;
                }else{
                    if($value['tuan_status'] == 3){
                        $showFahuoBoxTmp = 1;
                    }
                }
            }
            
            $showPeisongBoxTmp = 1;
            if($value['peisong_type'] == 2){
                if($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList) && empty($value['peisong_info'])){
                    $showPeisongBoxTmp = 2;
                }
                if($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList) && !empty($value['kuaidi_no']) && !empty($value['kuaidi_type'])){
                    $showPeisongBoxTmp = 2;
                }
            }
            
            $showQianshouBtnTmp = 0;
            if($value['order_status'] == 4 && $value['peisong_time'] > 0){
                if(TIMESTAMP > ($value['peisong_time'] + 86400*$tcptuanConfig['shop_qianshou_days'])){
                    $showQianshouBtnTmp = 1;
                }
            }
            
            $orderList[$key]['userInfo']        = $userInfoTmp;
            $orderList[$key]['hexiaoUserInfo']  = $hexiaoUserInfoTmp;
            $orderList[$key]['goodsInfo']       = $goodsInfoTmp;
            $orderList[$key]['site_name']       = $site_name_tmp;
            $orderList[$key]['showFahuoBox']    = $showFahuoBoxTmp;
            $orderList[$key]['showPeisongBox']  = $showPeisongBoxTmp;
            $orderList[$key]['showQianshouBtn'] = $showQianshouBtnTmp;
            $orderList[$key]['orderTime']       = dgmdate($value['order_time'], 'Y-m-d H:i:s',$tomSysOffset);
            $orderList[$key]['payTime']         = dgmdate($value['pay_time'], 'Y-m-d H:i:s',$tomSysOffset);
            $orderList[$key]['hexiaoTime']      = dgmdate($value['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset);
        }
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&goods_id={$goods_id}&order_no={$order_no}&tuan_id={$tuan_id}"
            . "&order_tel={$order_tel}&order_status={$order_status}&order_type={$order_type}"
            . "&tuan_status={$tuan_status}&start_time={$start_time}&end_time={$end_time}";

$goodsNumCount = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num($where);

if($goods_id > 0 && !empty($orderList)){
    $countOrderStatus1 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=1 ");
    $countOrderStatus1 = intval($countOrderStatus1);
    $countOrderStatus2 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=2 ");
    $countOrderStatus2 = intval($countOrderStatus2);
    $countOrderStatus4 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=4 ");
    $countOrderStatus4 = intval($countOrderStatus4);
    $countOrderStatus5 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=5 ");
    $countOrderStatus5 = intval($countOrderStatus5);
    $countOrderStatus6 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=6 ");
    $countOrderStatus6 = intval($countOrderStatus6);
    $countOrderStatus7 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=7 ");
    $countOrderStatus7 = intval($countOrderStatus7);
    $countOrderStatus8 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=8 ");
    $countOrderStatus8 = intval($countOrderStatus8);
}

$fahuoUrl       = 'plugin.php?id=tom_tcptuan&site='.$site_id.'&mod=myorderinfo&act=fahuo&formhash='.$formhash;
$qianshouUrl    = 'plugin.php?id=tom_tcptuan&site='.$site_id.'&mod=myorderinfo&act=qianshou&formhash='.$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //d'.'i'.'sm.ta'.'o'.'bao.com
include template("tom_tcptuan:pcshopadmin/order");