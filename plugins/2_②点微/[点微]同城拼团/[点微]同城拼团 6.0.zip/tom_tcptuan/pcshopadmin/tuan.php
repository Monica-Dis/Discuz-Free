<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=tuan";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

$tuan_id        = isset($_GET['tuan_id'])? intval($_GET['tuan_id']):0;
$tuan_status    = isset($_GET['tuan_status'])? intval($_GET['tuan_status']):0;

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$goodsListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_list_id(" AND user_id = {$__UserInfo['id']} ", 'ORDER BY id DESC', 0, 10000);
$goodsIdsList = array();
if(!empty($goodsListTmp)){
    foreach($goodsListTmp as $key => $value){
        $goodsIdsList[] = $value['id'];
    }
}
if(!empty($goodsIdsList)){
    $goodsIdsStr = implode(',', $goodsIdsList);
    $where = " AND goods_id IN({$goodsIdsStr}) ";
}else{
    $where = " AND goods_id = 999999999 ";
}

if($tuan_id > 0){
    $where.= " AND id={$tuan_id} ";
}
if($tuan_status > 0){
    $where.= " AND tuan_status={$tuan_status} ";
}

$order = " ORDER BY tuan_time DESC,id DESC ";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_all_count($where);
$tuanListTmp = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_all_list($where,$order,$start,$pagesize);
$tuanList = array();
if(!empty($tuanListTmp)){
    foreach ($tuanListTmp as $key => $value) {
        $tuanList[$key] = $value;
        
        $goodsInfoTmp  = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($value['goods_id']);
        $goodsInfoTmp['picurl'] = get_file_url($goodsInfoTmp['picurl']);
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $orderListTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_like_list(" AND tuan_id={$value['id']} ","ORDER BY order_time DESC",0,500,"");
        $orderStatusArrTmp = array();
        for($i=1;$i<=8;$i++){
            $orderStatusArrTmp[$i] = 0;
        }
        if(is_array($orderListTmp) && !empty($orderListTmp)){
            foreach ($orderListTmp as $k1 => $v1){
                $orderStatusArrTmp[$v1['order_status']]++;
            }
        }
        
        $qrcodeImgTmp = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($_G['siteurl']."plugin.php?id=tom_tcptuan&site=".$value['site_id']."&mod=tuan&tuan_id={$value['id']}");
        
        $tuanList[$key]['goodsInfo']        = $goodsInfoTmp;
        $tuanList[$key]['userInfo']         = $userInfoTmp;
        $tuanList[$key]['orderStatusArr']   = $orderStatusArrTmp;
        $tuanList[$key]['qrcodeImg']        = $qrcodeImgTmp;
        $tuanList[$key]['tuanTime']         = dgmdate($value['tuan_time'],"Y-m-d H:i",$tomSysOffset);
        $tuanList[$key]['successTime']      = dgmdate($value['success_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&tuan_id={$tuan_id}&tuan_status={$tuan_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //d'.'i'.'sm.ta'.'o'.'bao.com
include template("tom_tcptuan:pcshopadmin/tuan");