<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=order';
$modListUrl = $adminListUrl.'&tmod=order';
$modFromUrl = $adminFromUrl.'&tmod=order';

$get_list_url_value = get_list_url("tom_tcptuan_admin_order_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'info'){
    
    $info = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $order_status = intval($_GET['order_status']);
        $updateData = array();
        $updateData['order_status'] = $order_status;
        C::t('#tom_tcptuan#tom_tcptuan_order')->update($_GET['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        $fenghao = $Lang['fenghao'];
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_goods_title'] . '</th></tr>';
        if($info['option_id'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['goods_name'].$fenghao.'</b></td><td>'.$info['goods_name'].'<font color="#0894fb">('.$info['option_name'] . ')</font></td></tr>';
        }else{
            echo '<tr><td align="right"><b>'.$Lang['goods_name'].$fenghao.'</b></td><td>'.$info['goods_name'].'</td></tr>';
        }
        echo '<tr><td align="right"><b>'.$Lang['order_goods_num'].$fenghao.'</b></td><td>'.$info['goods_num'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_goods_price'].$fenghao.'</b></td><td>'.$info['goods_price'].'</td></tr>';
        
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_order_title'] . '</th></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_no'].$fenghao.'</b></td><td>'.$info['order_no'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_pay_price'].$fenghao.'</b></td><td>'.$info['pay_price'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_status'].$fenghao.'</b></td><td><b><font color="'.$orderStatusColorArray[$info['order_status']].'">' . $orderStatusArray[$info['order_status']] . '</font></b></td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_time'].$fenghao.'</b></td><td>'.dgmdate($info['order_time'], 'm-d H:i:s',$tomSysOffset).'</td></tr>';
        if($info['pay_time'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['order_pay_time'].$fenghao.'</b></td><td>'.dgmdate($info['pay_time'], 'm-d H:i:s',$tomSysOffset).'</td></tr>';
        }else{
            echo '<tr><td align="right"><b>'.$Lang['order_pay_time'].$fenghao.'</b></td><td>-</td></tr>';
        }
        
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_info_user_title'] . '</th></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_xm'].$fenghao.'</b></td><td>'.$info['xm'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_tel'].$fenghao.'</b></td><td>'.$info['tel'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_address'].$fenghao.'</b></td><td>'.$info['address'].'</td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['order_order_beizu'].$fenghao.'</b></td><td>'.$info['order_beizu'].'</td></tr>';
        if($info['peisong_type'] == 1){
            echo '<tr><td align="right"><b>'.$Lang['goods_peisong_type'].$fenghao.'</b></td><td>'.$info['goods_peisong_type_1'].'</td></tr>';
        }else if($info['peisong_type'] == 2){
            echo '<tr><td align="right"><b>'.$Lang['goods_peisong_type'].$fenghao.'</b></td><td>'.$info['goods_peisong_type_2'].'</td></tr>';
        }else if($info['peisong_type'] == 3){
            echo '<tr><td align="right"><b>'.$Lang['goods_peisong_type'].$fenghao.'</b></td><td>'.$info['goods_peisong_type_3'].'</td></tr>';
        }
        echo '<tr><td align="right"><b>'.$Lang['order_peisong_info'].$fenghao.'</b></td><td>'.$info['peisong_info'].'</td></tr>';
        if($info['hexiao_time'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['order_hexiao_time'].$fenghao.'</b></td><td>'.dgmdate($info['hexiao_time'], 'm-d H:i:s',$tomSysOffset).'</td></tr>';
        }else{
            echo '<tr><td align="right"><b>'.$Lang['order_hexiao_time'].$fenghao.'</b></td><td>-</td></tr>';
        }
        
        showtablefooter(); //d'.'is'.'m.ta'.'obao.com
        showformheader($modFromUrl.'&act=info&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_edit'] . '</th></tr>';
        showtablefooter(); //d'.'is'.'m.ta'.'obao.com
        showtableheader();
        echo '<tr><td align="right"><b>'.$Lang['order_order_status'].$fenghao.'</b></td><td>';
        foreach ($orderStatusArray as $key => $value){
            if($key == $info['order_status']){
                echo '<input type="radio" name="order_status" value="'.$key.'" checked><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }else{
                echo '<input type="radio" name="order_status" value="'.$key.'" ><b><font color="'.$orderStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }
        }
        echo '</td></tr>';
        echo '<tr><td>&nbsp;</td><td colspan="14" ><b><font color="#fd0303">(' . $Lang['order_order_status_msg'] . ')</font></b></td></tr>';
        tomshowsubmit('submit', 'submit');
        showtablefooter(); //d'.'is'.'m.ta'.'obao.com
        showformfooter(); //di'.'sm.t'.'aoba'.'o.com
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refund'){
    
    $wxpay_appid        = trim($tongchengConfig['wxpay_appid']);
    $wxpay_mchid        = trim($tongchengConfig['wxpay_mchid']);
    $wxpay_key          = trim($tongchengConfig['wxpay_key']);
    $wxpay_appsecret    = trim($tongchengConfig['wxpay_appsecret']);

    define("TOM_WXPAY_APPID", $wxpay_appid);
    define("TOM_WXPAY_MCHID", $wxpay_mchid);
    define("TOM_WXPAY_KEY", $wxpay_key);
    define("TOM_WXPAY_APPSECRET", $wxpay_appsecret);
    define("TOM_WXPAY_SSLCERT_PATH", DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_cert.pem');
    define("TOM_WXPAY_SSLKEY_PATH", DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_key.pem');
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/wxpay/lib/WxPay.Api.php';
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            
            $id = intval($value);
            $orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($id);
            
            $payOrderInfo = C::t('#tom_pay#tom_pay_order')->fetch_by_order_no($orderInfo['order_no']);
            if($payOrderInfo['payment'] == 'wxpay_jsapi' || $payOrderInfo['payment'] == 'wxpay_h5'){
                
                if($orderInfo && !empty($orderInfo['order_no']) && !empty($orderInfo['pay_price']) && $orderInfo['order_status']==2){
                    $pay_price = $orderInfo['pay_price']*100;
                    $input = new WxPayRefund();
                    $input->SetOut_trade_no($orderInfo['order_no']);
                    $input->SetTotal_fee($pay_price);
                    $input->SetRefund_fee($pay_price);
                    $input->SetOut_refund_no(WxPayConfig::MCHID.date("YmdHis"));
                    $input->SetOp_user_id(WxPayConfig::MCHID);
                    $return = WxPayApi::refund($input);
                    if(is_array($return) && $return['result_code'] == 'SUCCESS'){
                        DB::query("UPDATE ".DB::table('tom_tcptuan_goods')." SET sale_num=sale_num-{$orderInfo['goods_num']} WHERE id='{$orderInfo['goods_id']}'", 'UNBUFFERED');
                        DB::query("UPDATE ".DB::table('tom_tcptuan_order')." SET order_status=7 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
                    }
                }
                
            }else{
                
                if($orderInfo && !empty($orderInfo['order_no']) && !empty($orderInfo['pay_price']) && $orderInfo['order_status']==2){
                    $orderUserInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
                    $insertData = array();
                    $insertData['user_id']          = $orderInfo['user_id'];
                    $insertData['type_id']          = 2;
                    $insertData['change_money']     = $orderInfo['pay_price'];
                    $insertData['old_money']        = $orderUserInfo['money'];
                    $insertData['tag']              = lang('plugin/tom_tcptuan', 'refund_money_log_tag');
                    $insertData['beizu']            = lang('plugin/tom_tcptuan', 'beizu_order_no') . $orderInfo['order_no'];
                    $insertData['log_time']         = TIMESTAMP;
                    C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);

                    DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$orderInfo['pay_price']} WHERE id='{$orderUserInfo['id']}'", 'UNBUFFERED');

                    DB::query("UPDATE ".DB::table('tom_tcptuan_goods')." SET sale_num=sale_num-{$orderInfo['goods_num']} WHERE id='{$orderInfo['goods_id']}'", 'UNBUFFERED');
                    DB::query("UPDATE ".DB::table('tom_tcptuan_order')." SET order_status=8 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
                }
                
            }
        }
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refundquery'){
    
    $wxpay_appid        = trim($tongchengConfig['wxpay_appid']);
    $wxpay_mchid        = trim($tongchengConfig['wxpay_mchid']);
    $wxpay_key          = trim($tongchengConfig['wxpay_key']);
    $wxpay_appsecret    = trim($tongchengConfig['wxpay_appsecret']);

    define("TOM_WXPAY_APPID", $wxpay_appid);
    define("TOM_WXPAY_MCHID", $wxpay_mchid);
    define("TOM_WXPAY_KEY", $wxpay_key);
    define("TOM_WXPAY_APPSECRET", $wxpay_appsecret);

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/wxpay/lib/WxPay.Api.php';
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $id = intval($value);
            $orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($id);
            if($orderInfo && !empty($orderInfo['order_no']) && !empty($orderInfo['pay_price'])  && $orderInfo['order_status']==7){
                $input = new WxPayRefundQuery();
                $input->SetOut_trade_no($orderInfo['order_no']);
                $return = WxPayApi::refundQuery($input);
                if(is_array($return) && $return['refund_status_0'] == 'SUCCESS'){
                    $updateData = array();
                    $updateData['order_status'] = 8;
                    C::t('#tom_tcptuan#tom_tcptuan_order')->update($orderInfo['id'],$updateData);
                }
            }
        }
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcptuan#tom_tcptuan_order')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_tcptuan_admin_order_list");
    
    $file_apiclient_cert = DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_cert.pem';
    $file_apiclient_key = DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_key.pem';
    if(!file_exists($file_apiclient_cert) || !file_exists($file_apiclient_key)){
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['order_error_title'] . '</th></tr>';
        echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
        echo '<li><font color="#FF0000"><b>' . $Lang['order_error_1'] . '</b></font></a></li>';
        echo '</ul></td></tr>';
        showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    }
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $order_no       = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
    $order_tel      = !empty($_GET['order_tel'])? trim(addslashes($_GET['order_tel'])):'';
    $order_status   = isset($_GET['order_status'])? intval($_GET['order_status']):0;
    $tuan_id        = isset($_GET['tuan_id'])? intval($_GET['tuan_id']):0;
    $order_type     = isset($_GET['order_type'])? intval($_GET['order_type']):0;
    $goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $tuan_status    = isset($_GET['tuan_status'])? intval($_GET['tuan_status']):0;
    
    $where = "";
    if(!empty($order_no)){
        $where.=" AND order_no='{$order_no}' ";
    }
    if(!empty($order_tel)){
        $where.=" AND tel='{$order_tel}' ";
    }
    if(!empty($order_status)){
        $where.=" AND order_status={$order_status} ";
    }
    if(!empty($tuan_id)){
        $where.=" AND tuan_id={$tuan_id} ";
    }
    if(!empty($order_type)){
        $where.=" AND order_type={$order_type} ";
    }
    if(!empty($goods_id)){
        $where.=" AND goods_id={$goods_id} ";
    }
    if($tuan_status){
        $where.= " AND tuan_status={$tuan_status} ";
    }
    
    $modBasePageUrl = $modBaseUrl."&order_no={$order_no}&order_tel={$order_tel}&order_status={$order_status}&tuan_id={$tuan_id}&order_type={$order_type}&goods_id={$goods_id}&tuan_status={$tuan_status}";
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_like_count($where,'');
    $goodsNumCount = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num($where);
    $orderList = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_like_list($where,"ORDER BY order_time DESC",$start,$pagesize,'');
    $fenghao = $Lang['fenghao'];
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_search_list'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['goods_id'] . '</b></td><td><input name="goods_id" type="text" value="'.$goods_id.'" size="40" /><font color="#fd0d0d">' . $Lang['order_goods_id_msg'] . '</font></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_order_no'] . '</b></td><td><input name="order_no" type="text" value="'.$order_no.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_tel'] . '</b></td><td><input name="order_tel" type="text" value="'.$order_tel.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_order_status'] . '</b></td><td><select name="order_status" >';
    echo '<option value="0">'.$Lang['order_order_status'].'</option>';
    foreach ($orderStatusArray as $key => $value){
        if($key == $order_status){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['order_order_type'] . '</b></td><td><select name="order_type" >';
    echo '<option value="0">'.$Lang['order_order_type'].'</option>';
    foreach ($order_typeArray as $key => $value){
        if($key == $order_type){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['tuan_tuan_status'] . '</b></td><td><select name="tuan_status" >';
    echo '<option value="0">'.$Lang['tuan_tuan_status'].'</option>';
    foreach ($tuanStatusArray as $key => $value){
        if($key == $tuan_status){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select></td></tr>';
    showsubmit('submit', 'submit');
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    showformfooter(); //di'.'sm.t'.'aoba'.'o.com
    
    if($goods_id > 0){
        $countOrderStatus1 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=1 ");
        $countOrderStatus2 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=2 ");
        $countOrderStatus4 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=4 ");
        $countOrderStatus5 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=5 ");
        $countOrderStatus6 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=6 ");
        $countOrderStatus7 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=7 ");
        $countOrderStatus8 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=8 ");
        echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
        echo $orderStatusArray[1].'<font color="#fd0d0d">('.$countOrderStatus1.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[2].'<font color="#fd0d0d">('.$countOrderStatus2.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[4].'<font color="#fd0d0d">('.$countOrderStatus4.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[5].'<font color="#fd0d0d">('.$countOrderStatus5.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[6].'<font color="#fd0d0d">('.$countOrderStatus6.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[7].'<font color="#fd0d0d">('.$countOrderStatus7.')</font>&nbsp;&nbsp;';
        echo $orderStatusArray[8].'<font color="#fd0d0d">('.$countOrderStatus8.')</font>&nbsp;&nbsp;';
        echo '</div>';
        if(!empty($order_status)){
            echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
            echo '<b>'.$Lang['order_search_count_msg1'].'</b>'.$Lang['order_search_count_msg2'].'<font color="#fd0d0d">('.$count.')</font>&nbsp;&nbsp;'.$Lang['order_search_count_msg3'].'<font color="#fd0d0d">('.$goodsNumCount.')</font>';
            echo '</div>';
        }
        tomshownavheader();
        tomshownavli($Lang['order_export'],$_G['siteurl']."plugin.php?id=tom_tcptuan:ordersexport&goods_id={$goods_id}",false);
        if($count > 5000){
            tomshownavli($Lang['order_export'].'(page:2)',$_G['siteurl']."plugin.php?id=tom_tcptuan:ordersexport&goods_id={$goods_id}&page=2",false);
        }
        if($count > 10000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcptuan:ordersexport&goods_id={$goods_id}&page=3",false);
        }
        if($count > 15000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcptuan:ordersexport&goods_id={$goods_id}&page=4",false);
        }
        if($count > 20000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcptuan:ordersexport&goods_id={$goods_id}&page=5",false);
        }
        if($count > 25000){
            tomshownavli($Lang['order_export'].'(page:3)',$_G['siteurl']."plugin.php?id=tom_tcptuan:ordersexport&goods_id={$goods_id}&page=6",false);
        }
        tomshownavfooter();
    }
    //tomshownavheader();
    //tomshownavli($Lang['order_export'],$_G['siteurl']."plugin.php?id=tom_tcptuan:ordersexport&order_no={$order_no}&order_tel={$order_tel}&order_status={$order_status}&tuan_id={$tuan_id}&order_type={$order_type}&goods_id={$goods_id}&tuan_status={$tuan_status}",false);
    //tomshownavfooter();
    
    $anchor = isset($_GET['anchor']) ? dhtmlspecialchars($_GET['anchor']) : '';
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return order_form();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />'.
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th width="10">&nbsp;</th>';
    echo '<th width="200">' . $Lang['order_goods_name'] . '</th>';
    echo '<th>' . $Lang['order_goods_num'] . '</th>';
    echo '<th>' . $Lang['order_pay_price'] . '</th>';
    echo '<th>' . $Lang['order_user_nickname'] . '</th>';
    echo '<th>' . $Lang['order_order_type'] . '</th>';
    echo '<th>' . $Lang['tuan_id'] . '</th>';
    echo '<th>' . $Lang['order_order_status'] . '</th>';
    echo '<th>' . $Lang['goods_peisong_type'] . '</th>';
    echo '<th width="120">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($orderList as $key => $value){
        
        $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        
        echo '<tr style="background-color: #E4FAF7;">';
        echo '<td colspan="2">' . $Lang['order_order_no'] . '&nbsp;:&nbsp;' . $value['order_no'] . '</td>';
        echo '<td colspan="3">' . $Lang['order_order_time'] . '&nbsp;:&nbsp;' . dgmdate($value['order_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        if($value['hexiao_time'] > 0){
            echo '<td colspan="3">' . $Lang['order_hexiao_time'] . '&nbsp;:&nbsp;' . dgmdate($value['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset). '</td>';
        }else{
            echo '<td colspan="3">' . $Lang['order_hexiao_time'] . '&nbsp;:&nbsp; - </td>';
        }
        if($value['tj_hehuoren_id'] > 0){
            echo '<td colspan="10">' . $Lang['order_tj_hehuoren_id'] . '&nbsp;:&nbsp; ' . $value['tj_hehuoren_id'] . ' </td>';
        }else{
            echo '<td colspan="10">' . $Lang['order_tj_hehuoren_id'] . '&nbsp;:&nbsp; - </td>';
        }
        echo '</tr>';
        
        echo '<tr style="height: 60px;">';
        echo '<td><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" ></td>';
        if($value['option_id'] > 0){
            echo '<td>' . $value['goods_name'] .'<font color="#0894fb">('.$value['option_name'] . ')</font>(ID:' . $value['goods_id'] . ')</td>';
        }else{
            echo '<td>' . $value['goods_name'] .'(ID:' . $value['goods_id'] . ')</td>';
        }
        echo '<td align="center">' . $value['goods_num'] . '</td>';
        echo '<td><font color="#009900">' . $value['pay_price'] . '</font></td>';
        echo '<td>' . $value['user_nickname'] . '(UID:'.$value['user_id'].')</td>';
        if($value['order_type'] == 1 || $value['order_type'] == 2){
            echo '<td><b><font color="'.$order_typeColorArray[$value['order_type']].'">' . $order_typeArray[$value['order_type']] . '</font></b><br/>(<font color="'.$tuanStatusColorArray[$value['tuan_status']].'">'.$tuanStatusArray[$value['tuan_status']].'</font>)</td>';
        }else{
            echo '<td><b><font color="'.$order_typeColorArray[$value['order_type']].'">' . $order_typeArray[$value['order_type']] . '</font></b></td>';
        }
        
        echo '<td><font color="#0585d6">' . $value['tuan_id'] . '</font></td>';
        echo '<td>';
        echo '<b><font color="'.$orderStatusColorArray[$value['order_status']].'">' . $orderStatusArray[$value['order_status']] . '</font></b>';
        if($value['hexiao_time'] > 0){
            echo '<br/><font color="#fd0d0d">'.$hexiaoUserInfo['nickname'].'(ID:'.$hexiaoUserInfo['id'].')</font><br/>';
        }
        echo '</td>';
        if($value['peisong_type'] == 1){
            echo '<td>' . $Lang['goods_peisong_type_1'] . '</td>'; 
        }else if($value['peisong_type'] == 2){
            echo '<td><b>' . $Lang['goods_peisong_type_2'] . '</b></td>'; 
        }else if($value['peisong_type'] == 3){
            echo '<td><b>' . $Lang['goods_peisong_type_3'] . '</b></td>'; 
        }
        echo '<td style="line-height: 30px;">';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['order_info'] . '</a>';
        //echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    
    $formstr = <<<EOF
        <tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="refund">{$Lang['batch_refund']}</option>
                    <option value="refundquery">{$Lang['batch_refundquery']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>
        <script type="text/javascript">
        function order_form(){
          var r = confirm("{$Lang['batch_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
        </script>
EOF;
    
    echo $formstr;
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    showformfooter(); //di'.'sm.t'.'aoba'.'o.com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
}