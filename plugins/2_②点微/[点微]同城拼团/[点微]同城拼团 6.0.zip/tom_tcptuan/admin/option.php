<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=option&goods_id='.$_GET['goods_id'];
$modListUrl = $adminListUrl.'&tmod=option&goods_id='.$_GET['goods_id'];
$modFromUrl = $adminFromUrl.'&tmod=option&goods_id='.$_GET['goods_id'];

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcptuan#tom_tcptuan_goods_option')->insert($insertData);
        $option_id = C::t('#tom_tcptuan#tom_tcptuan_goods_option')->insert_id();
        
        updateStocklog($option_id,$_GET['goods_id']);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); //d'.'is'.'m.ta'.'obao.com
        showformfooter(); //di'.'sm.t'.'aoba'.'o.com
    }
    
}else if($_GET['act'] == 'edit'){
    $optionInfo = C::t('#tom_tcptuan#tom_tcptuan_goods_option')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($optionInfo);
        C::t('#tom_tcptuan#tom_tcptuan_goods_option')->update($optionInfo['id'],$updateData);
        updateStocklog($optionInfo['id'],$optionInfo['goods_id']);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($optionInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); //d'.'is'.'m.ta'.'obao.com
        showformfooter(); //di'.'sm.t'.'aoba'.'o.com
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $optionInfo = C::t('#tom_tcptuan#tom_tcptuan_goods_option')->fetch_by_id($_GET['id']);
    
    C::t('#tom_tcptuan#tom_tcptuan_goods_option')->delete_by_id($_GET['id']);
    updateStocklog(0,$optionInfo['goods_id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['act'] == 'stock_log'){
    
    $goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($_GET['goods_id']);

    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $goodsInfo['name'] .'&nbsp;&nbsp;&gt;&nbsp;&nbsp;'.$Lang['option_stock_log']. '</th></tr>';
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $stockLogList = C::t('#tom_tcptuan#tom_tcptuan_stock_log')->fetch_all_list(" AND goods_id = {$goodsInfo['id']} "," ORDER BY change_time DESC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['stocklog_is_admin'] . '</th>';
    echo '<th>' . $Lang['stocklog_is_option'] . '</th>';
    echo '<th>' . $Lang['stocklog_change_num'] . '</th>';
    echo '<th>' . $Lang['stocklog_beizu'] . '</th>';
    echo '<th>' . $Lang['stocklog_change_time'] . '</th>';
    echo '</tr>';

    $i = 1;
    foreach ($stockLogList as $key => $value) {
        echo '<tr>';
        if($value['is_admin'] == 1){
            echo '<td>' . $Lang['stocklog_is_admin_1'] . '</td>';
        }else{
            echo '<td>' . $Lang['stocklog_is_admin_0'] . '</td>';
        }
        if($value['is_option'] == 1){
            echo '<td>' . $Lang['stocklog_is_option_1'] . '</td>';
        }else{
            echo '<td>' . $Lang['stocklog_is_option_0'] . '</td>';
        }
        echo '<td>' . $value['change_num'] . '</td>';
        echo '<th>' . $value['beizu'] . '</th>';
        echo '<td>' . dgmdate($value['change_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    $goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($_GET['goods_id']);

    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $goodsInfo['name'] .'&nbsp;&nbsp;&gt;&nbsp;&nbsp;'.$Lang['option_list_title']. '</th></tr>';
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $optionList = C::t('#tom_tcptuan#tom_tcptuan_goods_option')->fetch_all_list(" AND goods_id = {$goodsInfo['id']} "," ORDER BY osort ASC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['option_name'] . '</th>';
    echo '<th>' . $Lang['option_market_price'] . '</th>';
    echo '<th>' . $Lang['option_tuan_price'] . '</th>';
    echo '<th>' . $Lang['option_tuanz_price'] . '</th>';
    echo '<th>' . $Lang['option_one_price'] . '</th>';
    echo '<th>' . $Lang['option_stock_num'] . '</th>';
    echo '<th>' . $Lang['goods_sale_num'] . '</th>';
    echo '<th>' . $Lang['paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($optionList as $key => $value) {
        
        $saleNumCount = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND option_id = {$value['id']} AND goods_id={$value['goods_id']} AND order_status IN(2,3,4,5) ");
        if($saleNumCount > 0){}else{
            $saleNumCount = 0;
        }
        
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['market_price'] . '</td>';
        echo '<td>' . $value['tuan_price'] . '</td>';
        echo '<td>' . $value['tuanz_price'] . '</td>';
        echo '<td>' . $value['one_price'] . '</td>';
        echo '<td><font color="#fd0d0d">' . $value['stock_num'] . '</font></td>';
        echo '<td><font color="#238206">' . $saleNumCount . '</font></td>';
        echo '<td>' . $value['osort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['option_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $goods_id           = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $market_price       = isset($_GET['market_price'])? floatval($_GET['market_price']):0.00;
    $tuan_price         = isset($_GET['tuan_price'])? floatval($_GET['tuan_price']):0.00;
    $tuanz_price        = isset($_GET['tuanz_price'])? floatval($_GET['tuanz_price']):0.00;
    $one_price          = isset($_GET['one_price'])? floatval($_GET['one_price']):0.00;
    $stock_num          = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
    $osort              = isset($_GET['osort'])? intval($_GET['osort']):10;

    if($_GET['act'] == 'edit'){
        $saleNumCount = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_goods_num(" AND option_id = {$infoArr['id']} AND goods_id={$goods_id} AND order_status IN(2,3,4,5) ");
        if($saleNumCount > $stock_num){
            $stock_num = $saleNumCount;
        }
    }
    
    $data['goods_id']       = $goods_id;
    $data['name']           = $name;
    $data['market_price']   = $market_price;
    $data['tuan_price']     = $tuan_price;
    $data['tuanz_price']    = $tuanz_price;
    $data['one_price']      = $one_price;
    $data['stock_num']      = $stock_num;
    $data['osort']          = $osort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'              => '',
        'market_price'      => '',
        'tuan_price'        => '',
        'tuanz_price'       => '',
        'one_price'         => '',
        'stock_num'         => '',
        'osort'             => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['option_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['option_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_market_price'],'name'=>'market_price','value'=>$options['market_price'],'msg'=>$Lang['option_market_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_tuan_price'],'name'=>'tuan_price','value'=>$options['tuan_price'],'msg'=>$Lang['option_tuan_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_tuanz_price'],'name'=>'tuanz_price','value'=>$options['tuanz_price'],'msg'=>$Lang['option_tuanz_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_one_price'],'name'=>'one_price','value'=>$options['one_price'],'msg'=>$Lang['option_one_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_stock_num'],'name'=>'stock_num','value'=>$options['stock_num'],'msg'=>$Lang['option_stock_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['paixu'],'name'=>'osort','value'=>$options['osort'],'msg'=>$Lang['option_osort_msg']),"input");
    
    return;
}

function updateStocklog($option_id, $goods_id){
    
    if($option_id > 0){
        $optionInfo = C::t("#tom_tcptuan#tom_tcptuan_goods_option")->fetch_by_id($option_id);

        $beizu = 'ID:&nbsp;<font color="#0a9409">'.$option_id.'</font> '.lang('plugin/tom_tcptuan', 'option_name').' <font color="#0a9409">'.$optionInfo['name'].'</font>: '.lang('plugin/tom_tcptuan', 'option_stock_num').'<font color="#fd0d0d">'.$optionInfo['stock_num'].'</font> '.lang('plugin/tom_tcptuan', 'option_market_price').'<font color="#fd0d0d">'.$optionInfo['market_price'].'</font> '.lang('plugin/tom_tcptuan', 'option_tuan_price').'<font color="#fd0d0d">'.$optionInfo['tuan_price'].'</font> '.lang('plugin/tom_tcptuan', 'option_tuanz_price').'<font color="#fd0d0d">'.$optionInfo['tuanz_price'].'</font> '.lang('plugin/tom_tcptuan', 'option_one_price').'<font color="#fd0d0d">'.$optionInfo['one_price'].'</font><br/>';

        $insertData = array();
        $insertData['is_admin']     = 1;
        $insertData['is_option']    = 1;
        $insertData['goods_id']     = $optionInfo['goods_id'];
        $insertData['beizu']        = $beizu;
        $insertData['change_num']   = $optionInfo['stock_num'];
        $insertData['change_time']  = TIMESTAMP;
        C::t("#tom_tcptuan#tom_tcptuan_stock_log")->insert($insertData);
    }

    $optionListTmp = C::t("#tom_tcptuan#tom_tcptuan_goods_option")->fetch_all_list(" AND goods_id = {$goods_id} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_market_price = $show_tuan_price = $show_tuanz_price = $show_one_price = $stock_num = 0;
        foreach($optionListTmp as $key => $value){
            $stock_num = $stock_num + $value['stock_num'];
            if($show_market_price == 0){
                $show_market_price  = $value['market_price'];
                $show_tuan_price    = $value['tuan_price'];
                $show_tuanz_price   = $value['tuanz_price'];
                $show_one_price     = $value['one_price'];
            }else if($value['market_price'] < $show_market_price){
                $show_market_price  = $value['market_price'];
                $show_tuan_price    = $value['tuan_price'];
                $show_tuanz_price   = $value['tuanz_price'];
                $show_one_price     = $value['one_price'];
            }
        }
        if($show_market_price > 0){
            $updateData = array();
            $updateData['show_market_price']    = $show_market_price;
            $updateData['show_tuan_price']      = $show_tuan_price;
            $updateData['show_tuanz_price']     = $show_tuanz_price;
            $updateData['show_one_price']       = $show_one_price;
            $updateData['stock_num']            = $stock_num;
            $updateData['part1']                = TIMESTAMP;
            C::t("#tom_tcptuan#tom_tcptuan_goods")->update($goods_id,$updateData);
        }
    }
    
    $goodsInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);
    update_ptuan_status($goodsInfoTmp);
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['option_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['option_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['option_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['option_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['option_edit'],"",true);
    }else if($_GET['act'] == 'stock_log'){
        tomshownavli($Lang['option_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['option_stock_log'],$modBaseUrl."&act=stock_log",true);
    }else{
        tomshownavli($Lang['option_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['option_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['option_stock_log'],$modBaseUrl."&act=stock_log",false);
    }
    tomshownavfooter();
}