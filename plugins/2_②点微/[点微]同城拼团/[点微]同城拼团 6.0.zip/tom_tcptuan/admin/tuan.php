<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=tuan';
$modListUrl = $adminListUrl.'&tmod=tuan';
$modFromUrl = $adminFromUrl.'&tmod=tuan';

$get_list_url_value = get_list_url("tom_tcptuan_admin_tuan_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'info'){
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'tuan_status'){
    $fenghao = $Lang['fenghao'];
    $info = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $tuan_status    = intval($_GET['tuan_status']);
        $prolong_hours  = intval($_GET['prolong_hours']);
        $updateData     = array();
        $updateData['prolong_hours'] = $prolong_hours;
        $updateData['tuan_status'] = $tuan_status;
        if(C::t('#tom_tcptuan#tom_tcptuan_tuan')->update($_GET['id'],$updateData)){
            C::t('#tom_tcptuan#tom_tcptuan_order')->update_tuan_status_by_tuan_id($_GET['id'],$tuan_status);
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        showformheader($modFromUrl.'&act=tuan_status&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['tuan_tuan_status_title'] . '</th></tr>';
        showtablefooter(); //d'.'is'.'m.ta'.'obao.com
        showtableheader();
        echo '<tr><td width="100" align="right"><b>' . $Lang['tuan_prolong_hours'].$fenghao. '</b></td><td><input name="prolong_hours" type="text" value="'.$info['prolong_hours'].'" size="10" /><font color="#fd0d0d">'.$Lang['tuan_prolong_hours_msg'].'</font></td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['tuan_tuan_status'].$fenghao.'</b></td><td>';
        foreach ($tuanStatusArray as $key => $value){
            if($key == $info['tuan_status']){
                echo '<input type="radio" name="tuan_status" value="'.$key.'" checked><b><font color="'.$tuanStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }else{
                echo '<input type="radio" name="tuan_status" value="'.$key.'" ><b><font color="'.$tuanStatusColorArray[$key].'">'.$value.'</font></b>&nbsp;';
            }
        }
        echo '</td></tr>';
        tomshowsubmit('submit', 'submit');
        showtablefooter(); //d'.'is'.'m.ta'.'obao.com
        showformfooter(); //di'.'sm.t'.'aoba'.'o.com
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refund'){
    
    $tuan_id = intval($_GET['id']);
    
    $wxpay_appid        = trim($tongchengConfig['wxpay_appid']);
    $wxpay_mchid        = trim($tongchengConfig['wxpay_mchid']);
    $wxpay_key          = trim($tongchengConfig['wxpay_key']);
    $wxpay_appsecret    = trim($tongchengConfig['wxpay_appsecret']);

    define("TOM_WXPAY_APPID", $wxpay_appid);
    define("TOM_WXPAY_MCHID", $wxpay_mchid);
    define("TOM_WXPAY_KEY", $wxpay_key);
    define("TOM_WXPAY_APPSECRET", $wxpay_appsecret);
    define("TOM_WXPAY_SSLCERT_PATH", DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_cert.pem');
    define("TOM_WXPAY_SSLKEY_PATH", DISCUZ_ROOT.'source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_key.pem');
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/wxpay/lib/WxPay.Api.php';
    
    $tuanTeamList = C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->fetch_all_list(" AND tuan_id={$tuan_id} ","ORDER BY add_time DESC",0,50);
    $flag = false;
    if(is_array($tuanTeamList) && !empty($tuanTeamList)){
        foreach ($tuanTeamList as $key => $value){
            $id = intval($value['order_id']);
            $orderInfo = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_by_id($id);
            
            $payOrderInfo = C::t('#tom_pay#tom_pay_order')->fetch_by_order_no($orderInfo['order_no']);
            if($payOrderInfo['payment'] == 'wxpay_jsapi' || $payOrderInfo['payment'] == 'wxpay_h5'){
                
                if($orderInfo && !empty($orderInfo['order_no']) && !empty($orderInfo['pay_price']) && $orderInfo['order_status']==2){
                    $pay_price = $orderInfo['pay_price']*100;
                    $input = new WxPayRefund();
                    $input->SetOut_trade_no($orderInfo['order_no']);
                    $input->SetTotal_fee($pay_price);
                    $input->SetRefund_fee($pay_price);
                    $input->SetOut_refund_no(WxPayConfig::MCHID.date("YmdHis"));
                    $input->SetOp_user_id(WxPayConfig::MCHID);
                    $return = WxPayApi::refund($input);
                    if(is_array($return) && $return['result_code'] == 'SUCCESS'){
                        $flag = true;
                        DB::query("UPDATE ".DB::table('tom_tcptuan_goods')." SET sale_num=sale_num-{$orderInfo['goods_num']} WHERE id='{$orderInfo['goods_id']}'", 'UNBUFFERED');
                        DB::query("UPDATE ".DB::table('tom_tcptuan_order')." SET order_status=7 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
                    }
                }
                
            }else{
                
                if($orderInfo && !empty($orderInfo['order_no']) && !empty($orderInfo['pay_price']) && $orderInfo['order_status']==2){
                    $orderUserInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
                    $insertData = array();
                    $insertData['user_id']          = $orderInfo['user_id'];
                    $insertData['type_id']          = 2;
                    $insertData['change_money']     = $orderInfo['pay_price'];
                    $insertData['old_money']        = $orderUserInfo['money'];
                    $insertData['tag']              = lang('plugin/tom_tcptuan', 'refund_money_log_tag');
                    $insertData['beizu']            = lang('plugin/tom_tcptuan', 'beizu_order_no') . $orderInfo['order_no'];
                    $insertData['log_time']         = TIMESTAMP;
                    C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);
                    
                    $flag = true;
                    DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$orderInfo['pay_price']} WHERE id='{$orderUserInfo['id']}'", 'UNBUFFERED');
                
                    DB::query("UPDATE ".DB::table('tom_tcptuan_goods')." SET sale_num=sale_num-{$orderInfo['goods_num']} WHERE id='{$orderInfo['goods_id']}'", 'UNBUFFERED');
                    DB::query("UPDATE ".DB::table('tom_tcptuan_order')." SET order_status=8 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
                        
                }
                
            }
            
            
        }
    }
    if($flag){
        $updateData = array();
        $updateData['tuan_status'] = 4;
        C::t('#tom_tcptuan#tom_tcptuan_tuan')->update($_GET['id'],$updateData);
        C::t('#tom_tcptuan#tom_tcptuan_order')->update_tuan_status_by_tuan_id($_GET['id'],4);
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcptuan#tom_tcptuan_tuan')->delete_by_id($_GET['id']);
    C::t('#tom_tcptuan#tom_tcptuan_tuan_team')->delete_by_tuan_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_tcptuan_admin_tuan_list");
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $tuan_id        = isset($_GET['tuan_id'])? intval($_GET['tuan_id']):0;
    $tuan_status    = isset($_GET['tuan_status'])? intval($_GET['tuan_status']):0;
    
    $where = "";
    $order = " ORDER BY tuan_time DESC,id DESC ";
    if($tuan_id){
        $where.= " AND id={$tuan_id} ";
    }
    if($tuan_status){
        $where.= " AND tuan_status={$tuan_status} ";
    }
    
    $modBasePageUrl = $modBaseUrl."&tuan_status={$tuan_status}&tuan_order={$tuan_order}";
    
    $pagesize = 10;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_all_count($where);
    $tuanList = C::t('#tom_tcptuan#tom_tcptuan_tuan')->fetch_all_list($where,$order,$start,$pagesize);
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['tuan_search_title'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['tuan_id'] . '</b></td><td><input name="tuan_id" type="text" value="'.$tuan_id.'" size="40" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['tuan_tuan_status'] . '</b></td><td><select name="tuan_status" >';
    echo '<option value="0">'.$Lang['tuan_tuan_status'].'</option>';
    foreach ($tuanStatusArray as $key => $value){
        if($key == $tuan_status){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select></td></tr>';
    
    showsubmit('submit', 'submit');
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    showformfooter(); //di'.'sm.t'.'aoba'.'o.com
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['tuan_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['tuan_id'] . '</th>';
    echo '<th>' . $Lang['tuan_user_nickname'] . '</th>';
    echo '<th width="200">' . $Lang['tuan_goods_name'] . '</th>';
    echo '<th>' . $Lang['goods_tuan_price'] . '</th>';
    echo '<th>' . $Lang['goods_tuan_num'] . '</th>';
    echo '<th>' . $Lang['tuan_tuan_status'] . '</th>';
    echo '<th width="120">' . $Lang['order_order_status'] . '</th>';
    echo '<th width="100">' . $Lang['tuan_tuan_time'] . '</th>';
    echo '<th width="100">' . $Lang['tuan_success_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($tuanList as $key => $value){
        
        $goodsInfo  = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($value['goods_id']);
        $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $orderListTmp = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_like_list(" AND tuan_id={$value['id']} ","ORDER BY order_time DESC",0,500,"");
        $order_status_tmp = array();
        for($i=1;$i<=8;$i++){
            $order_status_tmp[$i] = 0;
        }
        if(is_array($orderListTmp) && !empty($orderListTmp)){
            foreach ($orderListTmp as $k1 => $v1){
                $order_status_tmp[$v1['order_status']]++;
            }
        }
        
        echo '<tr>';
        echo '<td>'.$value['id'].'</td>';
        echo '<td>'.$userInfo['nickname'].'</td>';
        echo '<td>'.$goodsInfo['name'].'</td>';
        echo '<td>' . $goodsInfo['tuan_price'] . '</td>';
        echo '<td>' . $goodsInfo['tuan_num'] . '</td>';
        echo '<td><font color="'.$tuanStatusColorArray[$value['tuan_status']].'">'.$tuanStatusArray[$value['tuan_status']].'</font></td>';
        echo '<td>';
        foreach ($orderStatusArray as $k2 => $v2){
            if($order_status_tmp[$k2] > 0){
               echo $v2.'<font color="'.$orderStatusColorArray[$k2].'">('.$order_status_tmp[$k2].')</font>&nbsp;&nbsp;<br/>'; 
            }
        }
        echo '</td>';
        
        echo '<td>' . dgmdate($value['tuan_time'], 'm-d H:i:s',$tomSysOffset) . '</td>';
        if($value['success_time'] == 0){
            echo '<td>-</td>';
        }else{
            echo '<td>' . dgmdate($value['success_time'], 'm-d H:i:s',$tomSysOffset) . '</td>';
        }
        
        $qrcodeImg = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($_G['siteurl']."plugin.php?id=tom_tcptuan&site=".$value['site_id']."&mod=tuan&tuan_id={$value['id']}");
        
        echo '<td style="line-height: 30px;">';
        echo '<a href="'.$adminBaseUrl.'&tmod=order&tuan_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['tuan_order_title'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=tuan_status&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['tuan_tuan_status_title'] . '</a><br/>';
        echo '<a href="javascript:void(0);" onclick="refund_confirm(\''.$modBaseUrl.'&act=refund&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['tuan_refund_title'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a target="_blank" href="'.$_G['siteurl'].'plugin.php?id=tom_tcptuan:ordersexport&tuan_id='.$value['id'].'">' . $Lang['tuan_dodao_title'] . '</a><br/>';
        echo '<a target="_blank" href="'.$qrcodeImg.'">' . $Lang['tuan_qrcode_title'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
            
function refund_confirm(url){
  var r = confirm("{$Lang['tuan_refund_sure']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
            
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}