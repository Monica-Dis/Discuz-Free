<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=goods';
$modListUrl = $adminListUrl.'&tmod=goods';
$modFromUrl = $adminFromUrl.'&tmod=goods';

$get_list_url_value = get_list_url("tom_tcptuan_admin_goods_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['status']        = 2;
        $insertData['shenhe_status'] = 1;
        $insertData['add_time']      = TIMESTAMP;
        $insertData['edit_time']     = TIMESTAMP;
        if(C::t('#tom_tcptuan#tom_tcptuan_goods')->insert($insertData)){
            $goods_id = C::t('#tom_tcptuan#tom_tcptuan_goods')->insert_id();
            
            $goodsInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goods_id);
            update_ptuan_status($goodsInfoTmp);
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        tomshowsubmit('submit', 'submit');
        showtablefooter(); //d'.'is'.'m.ta'.'obao.com
        showformfooter(); //di'.'sm.t'.'aoba'.'o.com
    }
    
}else if($_GET['act'] == 'edit'){
    $goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData['edit_time']     = TIMESTAMP;
        $updateData = __get_post_data($goodsInfo);
        C::t('#tom_tcptuan#tom_tcptuan_goods')->update($goodsInfo['id'],$updateData);
        
        $goodsInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($goodsInfo['id']);
        update_ptuan_status($goodsInfoTmp);
        if($updateData['hasoption'] == 1){
            updateStocklog($goodsInfo['id']);
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($goodsInfo);
        tomshowsubmit('submit', 'submit');
        showtablefooter(); //d'.'is'.'m.ta'.'obao.com
        showformfooter(); //di'.'sm.t'.'aoba'.'o.com
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe'){
    
    $shenhe_status     = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):1;
    
    $updateData = array();
    $updateData['shenhe_status']     = $shenhe_status;
    C::t('#tom_tcptuan#tom_tcptuan_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tcptuan#tom_tcptuan_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status']     = 2;
    C::t('#tom_tcptuan#tom_tcptuan_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editstock'){
    
    $info = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $stock_num     = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
        if($stock_num < $info['sale_num']){
            $stock_num = $info['sale_num'];
        }
        
        $updateData = array();
        $updateData['stock_num'] = $stock_num;
        C::t('#tom_tcptuan#tom_tcptuan_goods')->update($_GET['id'],$updateData);
        
        $goodsInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($info['id']);
        update_ptuan_status($goodsInfoTmp);
        
        $insertData = array();
        $insertData['is_admin']     = 1;
        $insertData['goods_id']     = $_GET['id'];
        $insertData['change_num']   = $stock_num;
        $insertData['change_time']  = TIMESTAMP;
        C::t('#tom_tcptuan#tom_tcptuan_stock_log')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editstock&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_stock_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_stock_num'],'name'=>'stock_num','value'=>$info['stock_num'],'msg'=>$Lang['edit_stock_num_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter(); //d'.'is'.'m.ta'.'obao.com
        showformfooter(); //di'.'sm.t'.'aoba'.'o.com
        
        tomshownavheader();
        tomshownavli($Lang['stocklog_list_title'],"",true);
        tomshownavfooter();

        $stockyLogList = C::t('#tom_tcptuan#tom_tcptuan_stock_log')->fetch_all_list(" AND goods_id={$info['id']} "," ORDER BY id DESC ",0,500);
        showtableheader();
        echo '<tr class="header">';
        echo '<th>' . $Lang['stocklog_is_admin'] . '</th>';
        echo '<th>' . $Lang['stocklog_is_option'] . '</th>';
        echo '<th>' . $Lang['stocklog_change_num'] . '</th>';
        echo '<th>' . $Lang['stocklog_beizu'] . '</th>';
        echo '<th>' . $Lang['stocklog_change_time'] . '</th>';
        echo '</tr>';

        $i = 1;
        foreach ($stockyLogList as $key => $value) {
            echo '<tr>';
            if($value['is_admin'] == 1){
                echo '<td>' . $Lang['stocklog_is_admin_1'] . '</td>';
            }else{
                echo '<td>' . $Lang['stocklog_is_admin_0'] . '</td>';
            }
            if($value['is_option'] == 1){
                echo '<td>' . $Lang['stocklog_is_option_1'] . '</td>';
            }else{
                echo '<td>' . $Lang['stocklog_is_option_0'] . '</td>';
            }
            echo '<td>' . $value['change_num'] . '</td>';
            echo '<th>' . $value['beizu'] . '</th>';
            echo '<td>' . dgmdate($value['change_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
            echo '</tr>';
            $i++;
        }
        showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    }
}else if($_GET['act'] == 'photo'){
    
    $goods_id = $_GET['goods_id'];
    
    if(submitcheck('submit')){
        
        if($_FILES["picurl"]['tmp_name']) {
            $upload = new tom_upload();
            if(!$upload->init($_FILES["picurl"], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }
            $picurl = $upload->attach['attachment'];
        }else{
            $picurl = addslashes($_GET["picurl"]);
        }
        
        $insertData = array();
        $insertData['goods_id']     = $goods_id;
        $insertData['picurl']       = $picurl;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->insert($insertData);
        
        cpmsg($Lang['act_success'], $adminListUrl.'&tmod=goods'."&act=photo&goods_id=".$_GET['goods_id'], 'succeed');
    }
    
    $goodsInfo = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($_GET['goods_id']);
    
    $photoList = C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->fetch_all_list(" AND goods_id={$goods_id} ","ORDER BY id ASC",0,100);
    __create_nav_html();
    showformheader($modFromUrl.'&act=photo&goods_id='.$goods_id,'enctype');
    showtableheader();
    tomshowsetting(true,array('title'=>$Lang['goods_photo_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['goods_photo_picurl_msg']),"file");
    showsubmit('submit', 'submit');
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    showformfooter(); //di'.'sm.t'.'aoba'.'o.com
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['goods_photo_picurl'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($photoList as $key => $value) {
        echo '<tr>';
        echo '<td><img src="' . tomgetfileurl($value['picurl']) . '" width="60" /></td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&goods_id='.$goods_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $adminListUrl.'&tmod=goods'."&act=photo&goods_id=".$_GET['goods_id'], 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcptuan#tom_tcptuan_goods')->delete_by_id($_GET['id']);
    C::t('#tom_tcptuan#tom_tcptuan_goods_photo')->delete_by_goods_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_tcptuan_admin_goods_list");
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ list-style-type: none; height: 25px; line-height: 25px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;padding: 3px 10px;color: #6a6d6a; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
</style>
EOF;
    echo $csstr;
    
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $goods_name     = !empty($_GET['goods_name'])? addslashes($_GET['goods_name']):'';
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id  = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($status)){
        $where.= " AND status={$status} ";
    }
    if(!empty($cate_id)){
        $where.= " AND cate_id={$cate_id} ";
    }
    if(!empty($cate_child_id)){
        $where.= " AND cate_child_id={$cate_child_id} ";
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    
    $sort = " ORDER BY id DESC ";
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&goods_name={$goods_name}&status={$status}&cate_id={$cate_id}&cate_child_id={$cate_child_id}&shenhe_status={$shenhe_status}";
    
    $pagesize   = 10;
    $start      = ($page-1)*$pagesize;	
    $count      = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_like_count($where,$goods_name);
    $goodsList  = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_like_list($where,$sort,$start,$pagesize,$goods_name);
    showtableheader();
    $Lang['pin_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['pin_help_1']);
    $Lang['pin_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['pin_help_3']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['pin_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    //echo '<li>' . $Lang['pin_help_1'] . '</font></a></li>';
    echo '<li>' . $Lang['pin_help_2'] . '</font></a></li>';
    echo '<li>' . $Lang['pin_help_3'] . '</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    
    $fenghao = $Lang['fenghao'];
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['goods_search_title'] . '</th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td>';
    echo $sitesStr;
    
    echo '<tr><td width="100" align="right"><b>' . $Lang['goods_name'] . '</b></td><td><input name="goods_name" type="text" value="'.$goods_name.'" size="40" /></td></tr>';
    
    $cateList = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(" AND parent_id=0 "," ORDER BY csort ASC,id DESC ",0,100);
    $cate_list_item = array();
    if(is_array($cateList) && !empty($cateList)){
        foreach ($cateList as $key => $value){
            $cate_list_item[$value['id']] = $value['name'];
        }
    }
    echo '<tr><td width="100" align="right"><b>' . $Lang['goods_cate_id'] . '</b></td><td><select name="cate_id" id="cate_id" onchange="getChild();" >';
    echo '<option value="0">'.$Lang['goods_cate_id'].'</option>';
    foreach ($cate_list_item as $key => $value){
        if($key == $cate_id){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select>&nbsp;&nbsp;<select name="cate_child_id" id="cate_child_id">';
    echo '<option value="0">'.$Lang['goods_cate_child_id'].'</option>';
    if($cate_id > 0){
        $childCateList = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(" AND parent_id={$cate_id} "," ORDER BY csort ASC,id DESC ",0,50);
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $key => $value) {
                if($value['id'] == $cate_child_id){
                    echo  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
                }else{
                    echo  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                }
            }
        }
    }
    echo '</select></td></tr>';
    
    echo '<tr><td width="100" align="right"><b>' . $Lang['goods_status'] . '</b></td><td><select name="status" >';
    echo '<option value="0">'.$Lang['goods_status'].'</option>';
    $status1_selected = $status2_selected = "";
    if(1 == $status){
        $status1_selected = "selected";
    }
    if(2 == $status){
        $status2_selected = "selected";
    }
    echo '<option value="1" '.$status1_selected.'>'.$Lang['goods_status_1'].'</option>';
    echo '<option value="2" '.$status2_selected.'>'.$Lang['goods_status_2'].'</option>';
    echo '</select></td></tr>';
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['goods_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1">'.$Lang['goods_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2">'.$Lang['goods_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3">'.$Lang['goods_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    showsubmit('submit', 'submit');
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    showformfooter(); //di'.'sm.t'.'aoba'.'o.com
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header" style="color: #3d7eb7;background-color: #f2f9fd;">';
    echo '<th style="width: 60px;">' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['goods_picurl'] . '</th>';
    echo '<th width="200">' . $Lang['goods_info'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['shop_info'] . '</th>';
    echo '<th>' . $Lang['goods_stock_num'] . '</th>';
    echo '<th>' . $Lang['goods_sale_num'] . '</th>';
    echo '<th>' . $Lang['goods_price'] . '</th>';
    echo '<th>' . $Lang['goods_status2'] . '</th>';  
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($goodsList as $key => $value) {
        
        if(!preg_match('/^http/', $value['picurl']) ){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $picurl = $value['picurl'];
        }
        
        $siteInfo       = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $cateInfo       = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_by_id($value['cate_id']);
        $cateChildInfo  = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_by_id($value['cate_child_id']);
        $tcshopInfo     = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $tcshopUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfo['user_id']); 
        
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td><img src="'.$picurl.'" width="40" /></td>';
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['goods_cate_id'].'&nbsp;:&nbsp;</b>' . $cateInfo['name'] . '&nbsp;&nbsp;&nbsp;'.$cateChildInfo['name'] . '</li>';
        echo '<li><b>'.$Lang['goods_id'].'&nbsp;:&nbsp;</b>' . $value['id'] . '</li>';
        echo '<li><b>'.$Lang['goods_name'].'&nbsp;:&nbsp;</b>' . $value['name'] . '</li>';
        echo '</ul></div></td>';
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li>'.$Lang['goods_tcshop_id'].'&nbsp;:&nbsp;' . $tcshopInfo['id'] . '</li>';
        echo '<li>'.$Lang['goods_tcshop_name'].'&nbsp;:&nbsp;' . $tcshopInfo['name'] . '</li>';
        echo '<li>'.$Lang['goods_tcshop_balance_user_id'].'&nbsp;:&nbsp;<font color="#0894fb">' . $tcshopUserInfo['id'] . '</font></li>';
        echo '<li>'.$Lang['goods_tcshop_balance_nickname'].'&nbsp;:&nbsp;<font color="#0894fb">' . $tcshopUserInfo['nickname'] . '</font></li>';
        echo '</ul></div></td>';
        echo '<td><font color="#fd0d0d">' . $value['stock_num'] . '</font></td>';
        echo '<td><font color="#238206">' . $value['sale_num'] . '</font></td>';
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li>'.$Lang['goods_tuan_num'].'&nbsp;:&nbsp;' . $value['tuan_num'] . '</font></li>';
        echo '<li>'.$Lang['goods_tuan_price'].'&nbsp;:&nbsp;' . $value['tuan_price'] . '</font></li>';
        if($value['open_one_buy'] == 1){
            echo '<li>'.$Lang['goods_one_price'].'&nbsp;:&nbsp;' . $value['one_price'] . '</li>';
        }
        if($value['tuanz_status'] == 1){
            echo '<li>'.$Lang['goods_tuanz_price'].'&nbsp;:&nbsp;' . $value['tuanz_price'] . '</li>';
            echo '<li>'.$Lang['goods_tuanz_price_num'].'&nbsp;:&nbsp;' . $value['tuanz_price_num'] . '</li>';
        }
        if($value['open_ding_pay'] == 1){
            echo '<li>'.$Lang['goods_ding_price'].'&nbsp;:&nbsp;' . $value['ding_price'] . '</li>';
        }
        echo '</ul></div></td>';
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['goods_clicks'].'&nbsp;:&nbsp;</b>' . $value['clicks'] . '</li>';
        if($value['hehuoren_tg_open'] == 1 && $value['type_id'] == 1){
            echo '<li><b>'.$Lang['goods_hehuoren_tg'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['open'] . '</font></li>';
        }else if($value['type_id'] == 1){
            echo '<li><b>'.$Lang['goods_hehuoren_tg'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['close'] . '</font></li>';
        }
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe&id='.$value['id'].'&shenhe_status=1&formhash='.FORMHASH.'">' . $Lang['goods_shenhe_btn_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe&id='.$value['id'].'&shenhe_status=3&formhash='.FORMHASH.'">' . $Lang['goods_shenhe_btn_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<li><b>'.$Lang['goods_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['goods_shenhe_status_1'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 2){
            echo '<li><b>'.$Lang['goods_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['goods_shenhe_status_2'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 3){
            echo '<li><b>'.$Lang['goods_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['goods_shenhe_status_3'] . '</font>'.$sheheBtnStr.'</li>';
        }
        if($value['status'] == 1 ){
            echo '<li><b>'.$Lang['goods_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['goods_status_1'] . '</font></li>';
        }else{
            echo '<li><b>'.$Lang['goods_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['goods_status_2'] . '</font></li>';
        }
        if($value['peisong_type'] == 1 ){
            echo '<li><b>'.$Lang['goods_hexiao_time'].'&nbsp;:&nbsp;</b>' . dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset) . '</li>';
        }
        echo '</ul></div></td>';
        echo '<td style="line-height: 30px;">';
        echo '<a href="'.$adminBaseUrl.'&tmod=order&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_order_title'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_edit']. '</a><br/>';
        if($value['hasoption'] == 1){
            echo '<a href="'.$adminBaseUrl.'&tmod=option&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_option_title']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        }else{
            echo '<a href="'.$modBaseUrl.'&act=editstock&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_stock_title']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        }
        
        echo '<a href="'.$modBaseUrl.'&act=photo&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_photo']. '</a><br/>';
        if($value['status'] == 1){
            echo '<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#FF0000">' . $Lang['goods_status_2']. '</font></a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        }else{
            echo '<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#009900">' . $Lang['goods_status_1']. '</font></a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        }
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}

function getChild(){
  var cate_id = jq("#cate_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcptuan:ajax",
        data: "act=childcates&parent_id="+cate_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var cateChildHtml = '<option value="0">{$Lang['goods_cate_child_id']}</option>';
            jq.each(json,function(k,v){
                cateChildHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#cate_child_id").html(cateChildHtml);
            jq("#cate_child_id").show();
        }
    });
}
</script>
EOF;
    echo $jsstr;
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $yongjin_bili       = isset($_GET['yongjin_bili'])? addslashes($_GET['yongjin_bili']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $tcchoujiang_id     = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):0;
    $xiangou_num        = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    $market_price       = isset($_GET['market_price'])? addslashes($_GET['market_price']):'';
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? addslashes($_GET['ding_price']):'';
    $tuanz_status       = isset($_GET['tuanz_status'])? intval($_GET['tuanz_status']):0;
    $tuanz_price        = isset($_GET['tuanz_price'])? addslashes($_GET['tuanz_price']):'';
    $tuanz_price_num    = isset($_GET['tuanz_price_num'])? intval($_GET['tuanz_price_num']):0;
    $tuan_num           = isset($_GET['tuan_num'])? intval($_GET['tuan_num']):0;
    $tuan_price         = isset($_GET['tuan_price'])? addslashes($_GET['tuan_price']):'';
    $tuan_hours         = isset($_GET['tuan_hours'])? intval($_GET['tuan_hours']):24;
    $open_one_buy       = isset($_GET['open_one_buy'])? intval($_GET['open_one_buy']):0;
    $one_price          = isset($_GET['one_price'])? addslashes($_GET['one_price']):'';
    $virtual_sale_num  = isset($_GET['virtual_sale_num'])? intval($_GET['virtual_sale_num']):0;
    $peisong_type       = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $express_type       = isset($_GET['express_type'])? intval($_GET['express_type']):1;
    $express_price      = isset($_GET['express_price'])? addslashes($_GET['express_price']):'';
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = strtotime($end_time);
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = strtotime($hexiao_time);
    $open_yuyue         = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $yuyue_xm           = isset($_GET['yuyue_xm'])? addslashes($_GET['yuyue_xm']):'';
    $yuyue_tel          = isset($_GET['yuyue_tel'])? addslashes($_GET['yuyue_tel']):'';
    $hehuoren_tg_open   = isset($_GET['hehuoren_tg_open'])? intval($_GET['hehuoren_tg_open']):2;
    $chuji_fc_scale     = isset($_GET['chuji_fc_scale'])? intval($_GET['chuji_fc_scale']):0;
    $zhongji_fc_scale   = isset($_GET['zhongji_fc_scale'])? intval($_GET['zhongji_fc_scale']):0;
    $gaoji_fc_scale     = isset($_GET['gaoji_fc_scale'])? intval($_GET['gaoji_fc_scale']):0;
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $paixu              = isset($_GET['paixu'])? intval($_GET['paixu']):10000;
    $virtual_clicks     = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    $toppic = "";
    if($_GET['act'] == 'add'){
        $toppic        = tomuploadFile("toppic");
    }else if($_GET['act'] == 'edit'){
        $toppic        = tomuploadFile("toppic",$infoArr['toppic']);
    }
    
    $hehuoren_tg_haibao = '';
    if($_GET['act'] == 'add'){
        $hehuoren_tg_haibao        = tomuploadFile("hehuoren_tg_haibao");
    }else if($_GET['act'] == 'edit'){
        $hehuoren_tg_haibao        = tomuploadFile("hehuoren_tg_haibao",$infoArr['hehuoren_tg_haibao']);
    }
    
    $data['site_id']            = $site_id;
    $data['user_id']            = $tcshopInfo['user_id'];
    $data['tcshop_id']          = $tcshopInfo['id'];
    $data['name']               = $name;
    $data['yongjin_bili']       = $yongjin_bili;
    $data['cate_id']            = $cate_id;
    $data['cate_child_id']      = $cate_child_id;
    $data['tcchoujiang_id']     = $tcchoujiang_id;
    $data['picurl']             = $picurl;
    $data['toppic']             = $toppic;
    $data['xiangou_num']        = $xiangou_num;
    $data['hasoption']          = $hasoption;
    $data['market_price']       = $market_price;
    $data['open_ding_pay']      = $open_ding_pay;
    $data['ding_price']         = $ding_price;
    $data['tuanz_status']       = $tuanz_status;
    $data['tuanz_price']        = $tuanz_price;
    $data['tuanz_price_num']    = $tuanz_price_num;
    $data['tuan_num']           = $tuan_num;
    $data['tuan_price']         = $tuan_price;
    $data['tuan_hours']         = $tuan_hours;
    $data['open_one_buy']       = $open_one_buy;
    $data['one_price']          = $one_price;
    $data['virtual_sale_num']   = $virtual_sale_num;
    $data['peisong_type']       = $peisong_type;
    $data['express_type']       = $express_type;
    $data['express_price']      = $express_price;
    $data['hexiao_pwd']         = $hexiao_pwd;
    $data['end_time']           = $end_time;
    $data['hexiao_time']        = $hexiao_time;
    $data['open_yuyue']         = $open_yuyue;
    $data['yuyue_xm']           = $yuyue_xm;
    $data['yuyue_tel']          = $yuyue_tel;
    $data['hehuoren_tg_open']   = $hehuoren_tg_open;
    //$data['hehuoren_tg_haibao'] = $hehuoren_tg_haibao;
    $data['chuji_fc_scale']     = $chuji_fc_scale;
    $data['zhongji_fc_scale']   = $zhongji_fc_scale;
    $data['gaoji_fc_scale']     = $gaoji_fc_scale;
    $data['admin_edit']         = $admin_edit;
    $data['content']            = $content;
    if($hasoption == 0){
        $data['show_market_price']          = $market_price;
        $data['show_tuan_price']            = $tuan_price;
        $data['show_tuanz_price']           = $tuanz_price;
        $data['show_one_price']             = $one_price;
    }
    //$data['virtual_clicks']     = $virtual_clicks;
    $data['paixu']              = $paixu;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$tcptuanConfig;
    $options = array(
        'site_id'           => '1',
        'name'              => '',
        'yongjin_bili'      => 0,
        'cate_id'           => 0,
        'cate_child_id'     => 0,
        'tcchoujiang_id'    => 0,
        'picurl'            => '',
        'toppic'            => '',
        'xiangou_num'       => 0,
        'hasoption'         => 0,
        'market_price'      => '0.00',
        'open_ding_pay'     => 0,
        'ding_price'        => '0.00',
        'tuanz_status'      => 0,
        'tuanz_price'       => '0.00',
        'tuanz_price_num'   => 0,
        'tuan_price'        => '0.00',
        'tuan_num'          => 0,
        'tuan_hours'        => "24",
        'open_one_buy'      => 0,
        'one_price'         => '0.00',
        'virtual_sale_num' => "0",
        'peisong_type'      => "1",
        'express_type'      => 1,
        'express_price'     => 0,
        'end_time'          => '',
        'hexiao_pwd'        => '',
        'hexiao_time'       => '',
        'open_yuyue'        => 0,
        'yuyue_xm'          => '',
        'yuyue_tel'         => '',
        'hehuoren_tg_open'  => 2,
        'hehuoren_tg_haibao'=> '',
        'chuji_fc_scale'    => 0,
        'zhongji_fc_scale'  => 0,
        'gaoji_fc_scale'    => 0,
        'admin_edit'        => 0,
        'virtual_clicks'    => 0,
        'content'           => "",
        'paixu'             => "10000",
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['goods_site_id'],'name'=>'site_id','value'=>$options['site_id'],'msg'=>$Lang['goods_site_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['goods_tcshop_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['goods_name_msg']),"input");
    
    $cateList = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(" AND parent_id=0 "," ORDER BY csort ASC,id DESC ",0,100);
    $catesStr = '<tr class="header"><th>'.$Lang['goods_cate_id'].'</th><th></th></tr>';
    $catesStr.= '<tr><td width="300"><select name="cate_id" id="cate_id" onchange="getChild();">';
    $catesStr.=  '<option value="0">'.$Lang['goods_cate_id'].'</option>';
    foreach ($cateList as $key => $value){
        if($value['id'] == $options['cate_id']){
            $catesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $catesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $catesStr.= '</select>&nbsp;&nbsp;<select name="cate_child_id" id="cate_child_id">';
    $catesStr.=  '<option value="0">'.$Lang['goods_cate_child_id'].'</option>';
    if($options['cate_id'] > 0){
        $childCateList = C::t('#tom_tcptuan#tom_tcptuan_cate')->fetch_all_list(" AND parent_id={$options['cate_id']} "," ORDER BY csort ASC,id DESC ",0,50);
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $key => $value) {
                if($value['id'] == $options['cate_child_id']){
                    $catesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
                }else{
                    $catesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                }
            }
        }
    }
    $catesStr.= '</select></td><td>'.$Lang['goods_cate_id_msg'].'</td></tr>';
    echo $catesStr;
    
    tomshowsetting(true,array('title'=>$Lang['goods_yongjin_bili'],'name'=>'yongjin_bili','value'=>$options['yongjin_bili'],'msg'=>$Lang['goods_yongjin_bili_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_tcchoujiang_id'],'name'=>'tcchoujiang_id','value'=>$options['tcchoujiang_id'],'msg'=>$Lang['goods_tcchoujiang_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['goods_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['goods_toppic'],'name'=>'toppic','value'=>$options['toppic'],'msg'=>$Lang['goods_toppic_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['goods_xiangou_num'],'name'=>'xiangou_num','value'=>$options['xiangou_num'],'msg'=>$Lang['goods_xiangou_num_msg']),"input");
    $hasoption_item = array(0=>$Lang['goods_hasoption_0'],1=>$Lang['goods_hasoption_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_hasoption'],'name'=>'hasoption','value'=>$options['hasoption'],'msg'=>$Lang['goods_hasoption_msg'],'item'=>$hasoption_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_market_price'],'name'=>'market_price','value'=>$options['market_price'],'msg'=>$Lang['goods_market_price_msg']),"input");
    
    tomshowsetting(true,array('title'=>$Lang['goods_tuan_num'],'name'=>'tuan_num','value'=>$options['tuan_num'],'msg'=>$Lang['goods_tuan_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_tuan_price'],'name'=>'tuan_price','value'=>$options['tuan_price'],'msg'=>$Lang['goods_tuan_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_tuan_hours'],'name'=>'tuan_hours','value'=>$options['tuan_hours'],'msg'=>$Lang['goods_tuan_hours_msg']),"input");
    
    $tuanz_status_item = array(0=>$Lang['goods_tuanz_status_0'],1=>$Lang['goods_tuanz_status_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_tuanz_status'],'name'=>'tuanz_status','value'=>$options['tuanz_status'],'msg'=>$Lang['goods_tuanz_status_msg'],'item'=>$tuanz_status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_tuanz_price'],'name'=>'tuanz_price','value'=>$options['tuanz_price'],'msg'=>$Lang['goods_tuanz_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_tuanz_price_num'],'name'=>'tuanz_price_num','value'=>$options['tuanz_price_num'],'msg'=>$Lang['goods_tuanz_price_num_msg']),"input");
    
    $open_one_buy_item = array(0=>$Lang['goods_open_one_buy_0'],1=>$Lang['goods_open_one_buy_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_open_one_buy'],'name'=>'open_one_buy','value'=>$options['open_one_buy'],'msg'=>$Lang['goods_open_one_buy_msg'],'item'=>$open_one_buy_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_one_price'],'name'=>'one_price','value'=>$options['one_price'],'msg'=>$Lang['goods_one_price_msg']),"input");
    
    $open_ding_pay_item = array(0=>$Lang['goods_open_ding_pay_0'],1=>$Lang['goods_open_ding_pay_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_open_ding_pay'],'name'=>'open_ding_pay','value'=>$options['open_ding_pay'],'msg'=>$Lang['goods_open_ding_pay_msg'],'item'=>$open_ding_pay_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_ding_price'],'name'=>'ding_price','value'=>$options['ding_price'],'msg'=>$Lang['goods_ding_price_msg']),"input");
    
    tomshowsetting(true,array('title'=>$Lang['goods_virtual_sale_num'],'name'=>'virtual_sale_num','value'=>$options['virtual_sale_num'],'msg'=>$Lang['goods_virtual_sale_num_msg']),"input");
    
    $peisong_type_item = array(1=>$Lang['goods_peisong_type_1'],2=>$Lang['goods_peisong_type_2'],3=>$Lang['goods_peisong_type_3']);
    tomshowsetting(true,array('title'=>$Lang['goods_peisong_type'],'name'=>'peisong_type','value'=>$options['peisong_type'],'msg'=>$Lang['goods_peisong_type_msg'],'item'=>$peisong_type_item),"radio");
    $express_type_item = array(1=>$Lang['goods_express_type_1'],2=>$Lang['goods_express_type_2'],3=>$Lang['goods_express_type_3']);
    tomshowsetting(true,array('title'=>$Lang['goods_express_type'],'name'=>'express_type','value'=>$options['express_type'],'msg'=>$Lang['goods_express_type_msg'],'item'=>$express_type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_express_price'],'name'=>'express_price','value'=>$options['express_price'],'msg'=>$Lang['goods_express_price_msg']),"input");
    
    tomshowsetting(true,array('title'=>$Lang['goods_end_time'],'name'=>'end_time','value'=>$options['end_time'],'msg'=>$Lang['goods_end_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['goods_hexiao_pwd'],'name'=>'hexiao_pwd','value'=>$options['hexiao_pwd'],'msg'=>$Lang['goods_hexiao_pwd_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_hexiao_time'],'name'=>'hexiao_time','value'=>$options['hexiao_time'],'msg'=>$Lang['goods_hexiao_time_msg']),"calendar");
    
    $open_yuyue_item = array(0=>$Lang['goods_open_yuyue_0'],1=>$Lang['goods_open_yuyue_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_open_yuyue'],'name'=>'open_yuyue','value'=>$options['open_yuyue'],'msg'=>$Lang['goods_open_yuyue_msg'],'item'=>$open_yuyue_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_yuyue_xm'],'name'=>'yuyue_xm','value'=>$options['yuyue_xm'],'msg'=>$Lang['goods_yuyue_xm_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_yuyue_tel'],'name'=>'yuyue_tel','value'=>$options['yuyue_tel'],'msg'=>$Lang['goods_yuyue_tel_msg']),"input");
    
    $open_hehuoren_tg_item = array(0=>$Lang['close'],1=>$Lang['open']);
    tomshowsetting(true,array('title'=>$Lang['goods_hehuoren_tg_open'],'name'=>'hehuoren_tg_open','value'=>$options['hehuoren_tg_open'],'msg'=>$Lang['goods_hehuoren_tg_open_msg'],'item'=>$open_hehuoren_tg_item),"radio");
    //tomshowsetting(true,array('title'=>$Lang['goods_hehuoren_tg_haibao'],'name'=>'hehuoren_tg_haibao','value'=>$options['hehuoren_tg_haibao'],'msg'=>$Lang['goods_hehuoren_tg_haibao_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['goods_chuji_fc_scale'],'name'=>'chuji_fc_scale','value'=>$options['chuji_fc_scale'],'msg'=>'<font color="#fd0d0d">%</font>&nbsp;&nbsp;'.$Lang['goods_chuji_fc_scale_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_zhongji_fc_scale'],'name'=>'zhongji_fc_scale','value'=>$options['zhongji_fc_scale'],'msg'=>'<font color="#fd0d0d">%</font>&nbsp;&nbsp;'.$Lang['goods_zhongji_fc_scale_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_gaoji_fc_scale'],'name'=>'gaoji_fc_scale','value'=>$options['gaoji_fc_scale'],'msg'=>'<font color="#fd0d0d">%</font>&nbsp;&nbsp;'.$Lang['goods_gaoji_fc_scale_msg']),"input");

    tomshowsetting(true,array('title'=>$Lang['goods_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['goods_paixu_msg']),"input");
    
    //tomshowsetting(true,array('title'=>$Lang['goods_virtual_clicks'],'name'=>'virtual_clicks','value'=>$options['virtual_clicks'],'msg'=>$Lang['goods_virtual_clicks_msg']),"input");
    
    $admin_edit_item = array(0=>$Lang['goods_admin_edit_0'],1=>$Lang['goods_admin_edit_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_admin_edit'],'name'=>'admin_edit','value'=>$options['admin_edit'],'msg'=>$Lang['goods_admin_edit_msg'],'item'=>$admin_edit_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['goods_content_msg']),"text");
    
    $jsstr = <<<EOF
<script type="text/javascript">
function getChild(){
  var cate_id = jq("#cate_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcptuan:ajax",
        data: "act=childcates&parent_id="+cate_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var cateChildHtml = '<option value="0">{$Lang['goods_cate_child_id']}</option>';
            jq.each(json,function(k,v){
                cateChildHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#cate_child_id").html(cateChildHtml);
            jq("#cate_child_id").show();
        }
    });
}
</script>
EOF;
    echo $jsstr;
    
    return;
}

function updateStocklog($goods_id){
    
    $optionListTmp = C::t("#tom_tcptuan#tom_tcptuan_goods_option")->fetch_all_list(" AND goods_id = {$goods_id} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_market_price = $show_tuan_price = $show_tuanz_price = $show_one_price = $stock_num = 0;
        foreach($optionListTmp as $key => $value){
            $stock_num = $stock_num + $value['stock_num'];
            if($show_market_price == 0){
                $show_market_price  = $value['market_price'];
                $show_tuan_price    = $value['tuan_price'];
                $show_tuanz_price   = $value['tuanz_price'];
                $show_one_price     = $value['one_price'];
            }else if($value['market_price'] < $show_market_price){
                $show_market_price  = $value['market_price'];
                $show_tuan_price    = $value['tuan_price'];
                $show_tuanz_price   = $value['tuanz_price'];
                $show_one_price     = $value['one_price'];
            }
        }
        if($show_market_price > 0){
            $updateData = array();
            $updateData['show_market_price']    = $show_market_price;
            $updateData['show_tuan_price']      = $show_tuan_price;
            $updateData['show_tuanz_price']     = $show_tuanz_price;
            $updateData['show_one_price']       = $show_one_price;
            $updateData['stock_num']            = $stock_num;
            $updateData['part1']                = TIMESTAMP;
            C::t("#tom_tcptuan#tom_tcptuan_goods")->update($goods_id,$updateData);
        }
    }
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['goods_edit'],"",true);
    }else{
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}