<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcptuan_cate`;
CREATE TABLE `pre_tom_tcptuan_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT '0',
  `csort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcptuan_focuspic`;
CREATE TABLE `pre_tom_tcptuan_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcptuan_goods`;
CREATE TABLE `pre_tom_tcptuan_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `tcchoujiang_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `cate_id` int(11) DEFAULT '0',
  `cate_child_id` int(11) DEFAULT '0',
  `yongjin_bili` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `toppic` varchar(255) DEFAULT NULL,
  `sale_num` int(11) DEFAULT '0',
  `virtual_sale_num` int(11) DEFAULT '0',
  `stock_num` int(11) DEFAULT '0',
  `xiangou_num` int(11) DEFAULT '0',
  `hasoption` tinyint(4) DEFAULT '0',
  `market_price` decimal(10,2) DEFAULT '0.00',
  `open_ding_pay` int(11) DEFAULT '0',
  `ding_price` decimal(10,2) DEFAULT '0.00',
  `tuanz_status` int(11) DEFAULT '0',
  `tuanz_price` decimal(10,2) DEFAULT '0.00',
  `tuanz_price_num` int(11) DEFAULT '0',
  `tuan_num` int(11) DEFAULT '0',
  `tuan_price` decimal(10,2) DEFAULT '0.00',
  `tuan_hours` int(11) DEFAULT '24',
  `open_one_buy` int(11) DEFAULT '0',
  `one_price` decimal(10,2) DEFAULT '0.00',
  `express_type` int(11) DEFAULT '1',
  `express_price` decimal(10,2) DEFAULT '0.00',
  `peisong_type` int(11) DEFAULT '1',
  `hexiao_time` int(11) DEFAULT '0',
  `hexiao_pwd` varchar(255) DEFAULT NULL,
  `tcyuyue_id` int(11) DEFAULT '0',
  `yuyue_type` tinyint(4) DEFAULT '1',
  `open_yuyue` int(11) DEFAULT '0',
  `yuyue_xm` varchar(255) DEFAULT NULL,
  `yuyue_tel` varchar(255) DEFAULT NULL,
  `hehuoren_tg_open` int(11) DEFAULT '0',
  `hehuoren_tg_haibao` varchar(255) DEFAULT NULL,
  `chuji_fc_scale` int(11) DEFAULT '0',
  `zhongji_fc_scale` int(11) DEFAULT '0',
  `gaoji_fc_scale` int(11) DEFAULT '0',
  `admin_edit` int(11) DEFAULT '0',
  `show_market_price` decimal(10,2) DEFAULT '0.00',
  `show_tuan_price` decimal(10,2) DEFAULT '0.00',
  `show_tuanz_price` decimal(10,2) DEFAULT '0.00',
  `show_one_price` decimal(10,2) DEFAULT '0.00',
  `content` text,
  `shenhe_status` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '1',
  `ptuan_status` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '10000',
  `add_time` int(11) DEFAULT '0',
  `edit_time` int(11) DEFAULT '0',
  `end_time` int(11) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `virtual_clicks` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_is_show` (`status`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcptuan_goods_photo`;
CREATE TABLE `pre_tom_tcptuan_goods_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcptuan_order`;
CREATE TABLE `pre_tom_tcptuan_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `order_type` int(11) DEFAULT '0',
  `order_no` varchar(255) DEFAULT NULL,
  `hexiao_no` varchar(255) DEFAULT NULL,
  `goods_id` int(11) DEFAULT '0',
  `goods_name` varchar(255) DEFAULT NULL,
  `goods_num` int(11) DEFAULT '0',
  `goods_price` decimal(10,2) DEFAULT '0.00',
  `option_id` int(11) DEFAULT '0',
  `option_name` varchar(255) DEFAULT NULL,
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `user_id` int(11) DEFAULT '0',
  `user_nickname` varchar(255) DEFAULT NULL,
  `user_openid` varchar(255) DEFAULT NULL,
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `address_id` int(11) DEFAULT '0',
  `tcyuyue_log_id` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `order_beizu` varchar(255) DEFAULT NULL,
  `peisong_type` int(11) DEFAULT '1',
  `express_name` varchar(255) DEFAULT NULL,
  `express_no` varchar(255) DEFAULT NULL,
  `peisong_info` varchar(255) DEFAULT NULL,
  `peisong_time` int(11) DEFAULT '0',
  `kuaidi_type` varchar(255) DEFAULT NULL,
  `kuaidi_no` varchar(255) DEFAULT NULL,
  `hexiao_user_id` int(11) DEFAULT '0',
  `tuan_id` int(11) DEFAULT '0',
  `tuan_status` int(11) DEFAULT '0',
  `order_status` int(11) DEFAULT NULL,
  `balance_status` int(11) DEFAULT '0',
  `pay_time` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_heixiao_no` (`hexiao_no`),
  KEY `idx_order_status` (`order_status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcptuan_stock_log`;
CREATE TABLE `pre_tom_tcptuan_stock_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_admin` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `is_option` int(11) DEFAULT '0',
  `beizu` text,
  `change_num` int(11) DEFAULT '0',
  `change_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcptuan_tuan`;
CREATE TABLE `pre_tom_tcptuan_tuan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `goods_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `prolong_hours` int(11) DEFAULT '0',
  `tuan_time` int(11) DEFAULT '0',
  `success_time` int(11) DEFAULT '0',
  `tuan_status` int(11) DEFAULT '1',
  `template_status` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcptuan_tuan_team`;
CREATE TABLE `pre_tom_tcptuan_tuan_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tuan_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `order_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_tuan_id` (`tuan_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcptuan_goods_option`;
CREATE TABLE `pre_tom_tcptuan_goods_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `market_price` decimal(10,2) DEFAULT '0.00',
  `tuan_price` decimal(10,2) DEFAULT '0.00',
  `tuanz_price` decimal(10,2) DEFAULT '0.00',
  `one_price` decimal(10,2) DEFAULT '0.00',
  `stock_num` int(11) DEFAULT '0',
  `osort` int(11) DEFAULT '10',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;