<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/plugin');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $sql = '';
    
    $tom_tcptuan_goods_field = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_field();
    if (!isset($tom_tcptuan_goods_field['virtual_clicks'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_goods` ADD `virtual_clicks` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcptuan_goods_field['hasoption'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_goods` ADD `hasoption` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcptuan_goods_field['show_market_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_goods` ADD `show_market_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcptuan_goods_field['show_tuan_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_goods` ADD `show_tuan_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcptuan_goods_field['show_tuanz_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_goods` ADD `show_tuanz_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcptuan_goods_field['show_one_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_goods` ADD `show_one_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcptuan_goods_field['end_time'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_goods` ADD `end_time` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcptuan_goods_field['ptuan_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_goods` ADD `ptuan_status` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcptuan_goods_field['tcchoujiang_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_goods` ADD `tcchoujiang_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcptuan_goods_field['tcyuyue_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_goods` ADD `tcyuyue_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcptuan_goods_field['yuyue_type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_goods` ADD `yuyue_type` tinyint(4) DEFAULT '1';\n";
    }
    
    $tom_tcptuan_stock_log_field = C::t('#tom_tcptuan#tom_tcptuan_stock_log')->fetch_all_field();
    if (!isset($tom_tcptuan_stock_log_field['is_option'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_stock_log` ADD `is_option` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcptuan_stock_log_field['beizu'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_stock_log` ADD `beizu` text;\n";
    }
    
    $tom_tcptuan_order_field = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_field();
    if (!isset($tom_tcptuan_order_field['option_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_order` ADD `option_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcptuan_order_field['option_name'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_order` ADD `option_name` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcptuan_order_field['kuaidi_type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_order` ADD `kuaidi_type` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcptuan_order_field['kuaidi_no'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_order` ADD `kuaidi_no` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcptuan_order_field['address_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_order` ADD `address_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcptuan_order_field['tcyuyue_log_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcptuan_order` ADD `tcyuyue_log_id` int(11) DEFAULT '0';\n";
    }

    if (!empty($sql)) {
        runquery($sql);
    }
    
    $sql = <<<EOF
    CREATE TABLE IF NOT EXISTS `pre_tom_tcptuan_goods_option` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `goods_id` int(11) DEFAULT '0',
        `name` varchar(255) DEFAULT NULL,
        `market_price` decimal(10,2) DEFAULT '0.00',
        `tuan_price` decimal(10,2) DEFAULT '0.00',
        `tuanz_price` decimal(10,2) DEFAULT '0.00',
        `one_price` decimal(10,2) DEFAULT '0.00',
        `stock_num` int(11) DEFAULT '0',
        `osort` int(11) DEFAULT '10',
        `add_time` int(11) DEFAULT '0',
        `part1` varchar(255) DEFAULT NULL,
        `part2` varchar(255) DEFAULT NULL,
        `part3` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
EOF;

    runquery($sql);

    echo 'OK';exit;
    
}else{
    exit('Access Denied');
}