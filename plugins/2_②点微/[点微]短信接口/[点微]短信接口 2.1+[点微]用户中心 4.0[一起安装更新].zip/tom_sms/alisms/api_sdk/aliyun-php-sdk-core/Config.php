<?php

//config http proxy	
define('ENABLE_HTTP_PROXY', FALSE);
define('HTTP_PROXY_IP', '127.0.0.1');
define('HTTP_PROXY_PORT', '8888');


include_once 'Auth/Credential.php';
include_once 'Auth/ISigner.php';
include_once 'Auth/ShaHmac1Signer.php';
include_once 'Auth/ShaHmac256Signer.php';

include_once 'Regions/ProductDomain.php';
include_once 'Regions/Endpoint.php';
include_once 'Regions/EndpointProvider.php';
include_once 'Regions/EndpointConfig.php';

include_once 'AcsRequest.php';
include_once 'AcsResponse.php';
include_once 'IAcsClient.php';
include_once 'RoaAcsRequest.php';
include_once 'RpcAcsRequest.php';
include_once 'DefaultAcsClient.php';

include_once 'Exception/ClientException.php';
include_once 'Exception/ServerException.php';

include_once 'Http/HttpHelper.php';
include_once 'Http/HttpResponse.php';

include_once 'Profile/IClientProfile.php';
include_once 'Profile/DefaultProfile.php';
