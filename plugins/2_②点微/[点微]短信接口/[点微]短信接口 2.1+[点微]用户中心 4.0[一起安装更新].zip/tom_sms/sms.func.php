<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function plugin_send_sms($sms_id,$tel,$data){
    $templateInfo = C::t('#tom_sms#tom_sms_template')->fetch_by_sms_id($sms_id);
    if($templateInfo && !empty($templateInfo['sign_name']) && !empty($templateInfo['template_code'])){
        $r = send_sms($templateInfo['sign_name'],$data,$tel,$templateInfo['template_code']);
    }else{
        return false;
    }
    return $r;
}

function check_tel_number($sms_id,$tel,$number){
    if($sms_id == 0){
        return false;
    }
    $smsInfo = C::t('#tom_sms#tom_sms_log')->fetch_by_id($sms_id);
    if($smsInfo['tel'] != $tel){
        return false;
    }
    $smsData = json_decode($smsInfo['sms_param'],true);
    if($smsData['number'] != $number){
        return false;
    }
    return true;
}

function send_sms($signName,$smsData,$tel,$templateCode){
    global $_G;
    
    $smsConfig = $_G['cache']['plugin']['tom_sms'];
    
    if($smsConfig['open_region'] == 1){
        if(!check_region($tel)){
            $r = array('error' => 'not_region');
            return $r;
        }
    }
    
    if($smsConfig['open_lock'] == 1){
        
        $lockList = C::t('#tom_sms#tom_sms_lock')->fetch_all_list(" ","ORDER BY id DESC",0,1);
        if(is_array($lockList) && !empty($lockList) && $lockList[0]['lock_time'] > 0){
            if((TIMESTAMP - $lockList[0]['lock_time']) < $smsConfig['lock_minutes']*60){
                $r = array('error' => 'lock');
                return $r;
            }
        }
        
        $one_minute_time    = TIMESTAMP - 60;
        $five_minute_time   = TIMESTAMP - 300;
        $one_hour_time      = TIMESTAMP - 3600;
        
        $one_minute_count   = C::t('#tom_sms#tom_sms_log')->fetch_all_count(" AND add_time > $one_minute_time ");
        $five_minute_count  = C::t('#tom_sms#tom_sms_log')->fetch_all_count(" AND add_time > $five_minute_time ");
        $one_hour_count     = C::t('#tom_sms#tom_sms_log')->fetch_all_count(" AND add_time > $one_hour_time ");
        
        $doLock = 0;
        if($one_minute_count >= $smsConfig['one_minute_xz']){
            $doLock = 1;
            $insertData = array();
            $insertData['tel']              = $tel;
            $insertData['content']          = lang('plugin/tom_sms', 'one_minute_error_msg');
            $insertData['add_time']         = TIMESTAMP;
            C::t('#tom_sms#tom_sms_error')->insert($insertData);
        }else if($five_minute_count >= $smsConfig['five_minute_xz']){
            $doLock = 1;
            $insertData = array();
            $insertData['tel']              = $tel;
            $insertData['content']          = lang('plugin/tom_sms', 'five_minute_error_msg');
            $insertData['add_time']         = TIMESTAMP;
            C::t('#tom_sms#tom_sms_error')->insert($insertData);
        }else if($one_hour_count >= $smsConfig['one_hour_xz']){
            $doLock = 1;
            $insertData = array();
            $insertData['tel']              = $tel;
            $insertData['content']          = lang('plugin/tom_sms', 'one_hour_error_msg');
            $insertData['add_time']         = TIMESTAMP;
            C::t('#tom_sms#tom_sms_error')->insert($insertData);
        }
        
        if($doLock == 1){
            $insertData = array();
            $insertData['lock_time']         = TIMESTAMP;
            C::t('#tom_sms#tom_sms_lock')->insert($insertData);
            
            $r = array('error' => 'lock');
            return $r;
        }
        
    }
    
    if($smsConfig['api_type'] == 1){
        $r =  send_sms_aliyun($signName,$smsData,$tel,$templateCode);
    }else if($smsConfig['api_type'] == 2){
        $r =  send_sms_dayu($signName,$smsData,$tel,$templateCode);
    }
    
    return $r;
}

function send_sms_dayu($signName,$smsData,$tel,$templateCode){
    global $_G;
    
    $smsConfig = $_G['cache']['plugin']['tom_sms'];
    include DISCUZ_ROOT.'./source/plugin/tom_sms/sms.class.php';
    $sms = new AlidayuSms($smsConfig['appkey'],$smsConfig['appsecret']);
    $sms->sign($signName);
    $sms->data($smsData);
    $sms->phone($tel);
    $sms->code($templateCode);
    $r = $sms->send();
    
    if(is_array($r)){
        $insertData = array();
        $insertData['tel']              = $tel;
        $insertData['template_code']    = $templateCode;
        $insertData['sms_param']        = json_encode($smsData);
        if($r['status'] == 'success'){
            $insertData['status']       = 1;
        }else{
            $insertData['status']       = 2;
        }
        $insertData['return']           = $r['return'];
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_sms#tom_sms_log')->insert($insertData);
        $sms_id = C::t('#tom_sms#tom_sms_log')->insert_id();
        $r['sms_id'] = $sms_id;
    }
    return $r;
}

function send_sms_aliyun($signName,$smsData,$tel,$templateCode){
    global $_G;
    
    $smsConfig = $_G['cache']['plugin']['tom_sms'];
    
    include DISCUZ_ROOT.'./source/plugin/tom_sms/alisms/api_sdk/aliyun-php-sdk-core/Config.php';
    include DISCUZ_ROOT.'./source/plugin/tom_sms/alisms/api_sdk/Dysmsapi/Request/V20170525/SendSmsRequest.php';
    include DISCUZ_ROOT.'./source/plugin/tom_sms/alisms/api_sdk/Dysmsapi/Request/V20170525/QuerySendDetailsRequest.php';
    
    //�˴���Ҫ�滻���Լ���AK��Ϣ
    $accessKeyId = trim($smsConfig['appkey']);
    $accessKeySecret = trim($smsConfig['appsecret']);
    //����API��Ʒ��
    $product = "Dysmsapi";
    //����API��Ʒ����
    $domain = "dysmsapi.aliyuncs.com";
    //��ʱ��֧�ֶ�Region
    $region = "cn-hangzhou";
    
    //��ʼ�����ʵ�acsCleint
    $profile = DefaultProfile::getProfile($region, $accessKeyId, $accessKeySecret);
    DefaultProfile::addEndpoint("cn-hangzhou", "cn-hangzhou", $product, $domain);
    $acsClient= new DefaultAcsClient($profile);

    $request = new SendSmsRequest;
    //����-���Ž��պ���
    $request->setPhoneNumbers($tel);
    //����-����ǩ��
    $signName = diconv($signName,CHARSET,'utf-8');
    $request->setSignName($signName);
    //����-����ģ��Code
    $request->setTemplateCode($templateCode);
    //ѡ��-����ģ���д��ڱ�����Ҫ�滻��Ϊ����(JSON��ʽ)
    $smsDataTmp = toUtf8($smsData);
    $smsDataStr = json_encode($smsDataTmp);
    $request->setTemplateParam($smsDataStr);
    //�����������
    $acsResponse = $acsClient->getAcsResponse($request);
    
    if($acsResponse){
        $insertData = array();
        $insertData['tel']              = $tel;
        $insertData['template_code']    = $templateCode;
        $insertData['sms_param']        = json_encode($smsData);
        if($acsResponse->Code == 'OK'){
            $insertData['status']       = 1;
        }else{
            $insertData['status']       = 2;
        }
        $message = diconv($acsResponse->Message,'utf-8',CHARSET);
        $insertData['return']           = $acsResponse->Code.':'.$message;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_sms#tom_sms_log')->insert($insertData);
        $sms_id = C::t('#tom_sms#tom_sms_log')->insert_id();
    }
    if($acsResponse->Code == 'OK'){
        $r = array();
        $r['status'] = 'success';
        $r['sms_id'] = $sms_id;
        return $r;
    }else{
        return $acsResponse->Code;
    }
    
}

function check_region($mobile = ''){
    global $_G;
    
    $smsConfig = $_G['cache']['plugin']['tom_sms'];
    
    $host       = "https://api04.aliyun.venuscn.com";
    $path       = "/mobile";
    $appcode    = $smsConfig['region_app_code'];
    $headers    = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys     = "mobile=".$mobile;
    $bodys      = "";
    $url        = $host . $path . "?" . $querys;
    
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    $return = curl_exec($curl);
    $content = json_decode($return,true);
    $content = region_iconv_recurrence($content);
    
    $tel_region = '';
    if(is_array($content) && !empty($content) && $content['msg'] == 'success' && is_array($content['data']) && !empty($content['data'])){
        
        $tel_region = $content['data']['prov'].' '.$content['data']['city'];
        
        $region_list = preg_quote(trim($smsConfig['region_list']), '/');
        $region_list = str_replace(array("\\*"), array('.*'), $region_list);
        $region_list = '.*('.$region_list.').*';
        $region_list = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $region_list).')$/i';
        if(@preg_match($region_list, $tel_region,$matches)) {
            return true;
        }
    }
    
    if(!empty($tel_region)){
        $insertData = array();
        $insertData['tel']              = $mobile;
        $insertData['content']          = lang('plugin/tom_sms', 'not_region_list_error_msg').$tel_region;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_sms#tom_sms_error')->insert($insertData);
    }else{
        $insertData = array();
        $insertData['tel']              = $mobile;
        $insertData['content']          = diconv($return,'utf-8',CHARSET);
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_sms#tom_sms_error')->insert($insertData);
    }
    
    return false;
}

function toUtf8($data = array()){
    $dataTmp = array();
    if(is_array($data) && !empty($data)){
        foreach ($data as $key => $value){
            $dataTmp[$key] = diconv($value,CHARSET,'utf-8');
        }
    }
    return $dataTmp;
}

function region_iconv_recurrence($value) {
    if(is_array($value)) {
        foreach($value AS $key => $val) {
            $value[$key] = region_iconv_recurrence($val);
        }
    } else {
        $value = diconv($value, 'utf-8', CHARSET);
    }
    return $value;
}