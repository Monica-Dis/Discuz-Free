<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class AlidayuSms {

	private $gatewayUrl         = "https://eco.taobao.com/router/rest";
	private $method             = "alibaba.aliqin.fc.sms.num.send";
	private $format             = "json";
	private $v                  = "2.0";
	private $sign_method        = "md5";
	private $appKey;
	private $secretKey;
	private $sms_type           = "normal";
	private $sms_free_sign_name = '';
	private $sms_param          = array();
	private $rec_num            = '';
	private $sms_template_code  = '';
    
    public function __construct($appKey,$secretKey){
        $this->appKey = $appKey;
        $this->secretKey = $secretKey;
    }
	
	public function sign($sign_name = ''){
        $sign_name = diconv($sign_name,CHARSET,'utf-8');
		$this->sms_free_sign_name = $sign_name;
		return $this;
	}
	
	public function data($data = array()){
        $dataTmp = array();
        if(is_array($data) && !empty($data)){
            foreach ($data as $key => $value){
                $dataTmp[$key] = diconv($value,CHARSET,'utf-8');
            }
        }
		$this->sms_param = $dataTmp;
		return $this;
	}
	
	public function phone($phone=''){
		$this->rec_num = $phone;
		return $this;
	}
	
	public function code($code=''){
		$this->sms_template_code = $code;
		return $this;
	}
    
	public function send($phone=''){
        
        if($phone!==''){
			$this->phone($phone);
		}
        
		$param = array(
			'method'				=>	$this->method,
			'format'				=>	$this->format,
			'app_key'				=>	$this->appKey,
			'timestamp'				=>	date("Y-m-d H:i:s"),
			'v'						=>	$this->v,
			'sign_method'			=>	$this->sign_method,
			'sms_type'				=>	$this->sms_type,
			'sms_free_sign_name'	=>	$this->sms_free_sign_name,
			'sms_param'				=>	json_encode($this->sms_param),
			'rec_num'				=>	$this->rec_num,
			'sms_template_code'		=>	$this->sms_template_code,
		);
		if(empty($this->sms_param)){
			unset($param['sms_param']);
		}
		
		$param['sign'] = $this->_sign(array_merge($param));
		$result = $this->_getHml($param);
        $data = json_decode($result,true);
        
        if(is_array($data) && !empty($data) && isset($data['alibaba_aliqin_fc_sms_num_send_response'])){
            if(isset($data['alibaba_aliqin_fc_sms_num_send_response']['result']['success']) && $data['alibaba_aliqin_fc_sms_num_send_response']['result']['success'] == 1){
                return array('status'=>'success','return'=>$result);
            }
        }
        return array('status'=>'error','return'=>$result);
	}
	
	private function _sign($param){
        
		ksort($param);

		$sign = $this->secretKey;
		foreach ($param as $k => $v){
			$sign .= "$k$v";
		}
		$sign .= $this->secretKey;

		return strtoupper(md5($sign));
	}
	
	private function _getHml($param){
		$url = $this->gatewayUrl . "?" . http_build_query($param);
        
        $content = dfsockopen($url);
        
        return $content;
        
	}
	
}