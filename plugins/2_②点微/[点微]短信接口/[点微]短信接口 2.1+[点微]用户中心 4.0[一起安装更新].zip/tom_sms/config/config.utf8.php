<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pluginArray = array(
    'tom_ucenter_01' => array(
        'plugin_id'     => 'tom_ucenter',
        'name'          => '用户中心注册',
        'sms_template_txt'  => '验证码${number}，感谢你注册同城平台。',
    ),
    'tom_tongcheng_01' => array(
        'plugin_id'     => 'tom_tongcheng',
        'name'          => '同城手机认证',
        'sms_template_txt'  => '验证码${number}，感谢你申请同城平台的手机号认证。',
    ),
    'tom_love_01' => array(
        'plugin_id'     => 'tom_love',
        'name'          => '交友手机认证',
        'sms_template_txt'  => '验证码${number}，感谢你申请婚恋交友平台的手机号认证。',
    ),
    'tom_ucenter_02' => array(
        'plugin_id'     => 'tom_ucenter',
        'name'          => '【国际短信】用户中心注册',
        'sms_template_txt'  => '验证码${number}，感谢你注册同城平台。',
    ),
    'tom_tongcheng_02' => array(
        'plugin_id'     => 'tom_tongcheng',
        'name'          => '【国际短信】同城手机认证',
        'sms_template_txt'  => '验证码${number}，感谢你申请同城平台的手机号认证。',
    ),
    'tom_love_02' => array(
        'plugin_id'     => 'tom_love',
        'name'          => '【国际短信】交友手机认证',
        'sms_template_txt'  => '验证码${number}，感谢你申请婚恋交友平台的手机号认证。',
    ),
);