<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=log';
$modListUrl = $adminListUrl.'&tmod=log';
$modFromUrl = $adminFromUrl.'&tmod=log';

if($_GET['act'] == 'add'){
}else{
    
    $pagesize = 15;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_sms#tom_sms_log')->fetch_all_count(" ");
    $logList = C::t('#tom_sms#tom_sms_log')->fetch_all_list(" ","ORDER BY add_time DESC",$start,$pagesize);
    
    showtableheader();/*Dism_taobao-com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['log_list_title'] . '</th></tr>';
    showtablefooter();/*Dism_taobao_com*/
    
    showtableheader();/*Dism_taobao-com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['log_template_code'] . '</th>';
    echo '<th>' . $Lang['log_tel'] . '</th>';
    echo '<th>' . $Lang['log_sms_param'] . '</th>';
    echo '<th>' . $Lang['log_time'] . '</th>';
    echo '<th width="200">' . $Lang['log_status'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($logList as $key => $value) {
        echo '<tr>';
        echo '<td>' . $value['template_code'] . '</td>';
        echo '<td>' . $value['tel'] . '</td>';
        echo '<td>' . $value['sms_param'] . '</td>';
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        if($value['status'] == 1){
            echo '<td>' . $Lang['log_status_1'] . '</td>';
        }else if($value['status'] == 2){
            echo '<td>' . $Lang['log_status_2'] .'(<br/>'.$value['return'].')'.'</td>';
        }
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism_taobao_com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
}
