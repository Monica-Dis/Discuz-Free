<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

if($_GET['act'] == 'save'){
    if(submitcheck('submit')){
        
        if(isset($_GET['sign_name']) && is_array($_GET['sign_name']) && !empty($_GET['sign_name'])){
            foreach ($_GET['sign_name'] as $key => $value){
                $sign_nameValue = trim(addslashes($value));
                $template_codeValue = trim(addslashes($_GET['template_code'][$key]));
                
                if(empty($sign_nameValue) || empty($template_codeValue)){
                    continue;
                }
                
                if(!empty($sign_nameValue) && !empty($template_codeValue)){
                    $templateInfoTmp = C::t('#tom_sms#tom_sms_template')->fetch_by_sms_id($key);
                    if($templateInfoTmp){
                        if($sign_nameValue != $templateInfoTmp['sign_name'] || $template_codeValue != $templateInfoTmp['template_code']){
                            $updateData = array();
                            $updateData['sign_name']     = $sign_nameValue;
                            $updateData['template_code']   = $template_codeValue;
                            C::t('#tom_sms#tom_sms_template')->update($templateInfoTmp['id'],$updateData);
                        }
                    }else{
                        $insertData = array();
                        $insertData['sms_id']           = $key;
                        $insertData['sign_name']        = $sign_nameValue;
                        $insertData['template_code']    = $template_codeValue;
                        $insertData['add_time']         = TIMESTAMP;
                        C::t('#tom_sms#tom_sms_template')->insert($insertData);
                    }
                }
            }
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }
}else{
    
    showtableheader();/*Dism_taobao-com*/
    $Lang['sms_help_2']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['sms_help_2']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['sms_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['sms_help_1_a'] . '<a target="_blank" href="http://dism.taobao.com/?index.php?m=help&t=plugin&pluginid=tom_sms"><font color="#FF0000">' . $Lang['sms_help_1_b'] . '</font></a></li>';
    echo '<li>' . $Lang['sms_help_2']. '</font></a></li>';
    echo '<li>' . $Lang['sms_help_3']. '</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter();/*Dism_taobao_com*/
    
    echo '<form name="cpform1" id="cpform1" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&act=save&formhash='.FORMHASH.'">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />'.
		'<input type="hidden" id="formscrolltop" name="scrolltop" value="" />'.
		'<input type="hidden" name="anchor" value="" />';
    showtableheader();/*Dism_taobao-com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['sms_name'] . '</th>';
    echo '<th>' . $Lang['sms_sign_name'] . '</th>';
    echo '<th>' . $Lang['sms_template_code'] . '</th>';
    echo '<th>' . $Lang['sms_template_txt'] . '</th>';
    echo '</tr>';
    foreach ($pluginArray as $key => $value) {
        
        if(!is_dir(DISCUZ_ROOT.'./source/plugin/'.$value['plugin_id'].'/')){
            continue;
        }
        
        $templateInfoTmp = C::t('#tom_sms#tom_sms_template')->fetch_by_sms_id($key);
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td><input name="sign_name['.$key.']" type="text" value="'.$templateInfoTmp['sign_name'].'" size="15" /></td>';
        echo '<td><input name="template_code['.$key.']" type="text" value="'.$templateInfoTmp['template_code'].'" size="15" /></td>';
        echo '<td>' . $value['sms_template_txt'] . '</td>';
        echo '</tr>';
    }
    echo '<tr>';
    echo '<td>';
    echo '<input type="submit" class="btn" id="submit_submit" name="submit" value="' . $Lang['sms_submit'] . '">';
    echo '</td>';
    echo '</tr>';
    showtablefooter();/*Dism_taobao_com*/
    showformfooter();/*dis'.'m.tao'.'bao.com*/
    
}