<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=error';
$modListUrl = $adminListUrl.'&tmod=error';
$modFromUrl = $adminFromUrl.'&tmod=error';

if($_GET['act'] == 'add'){
}else{
    
    $pagesize = 100;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_sms#tom_sms_error')->fetch_all_count(" ");
    $errorList = C::t('#tom_sms#tom_sms_error')->fetch_all_list(" ","ORDER BY add_time DESC",$start,$pagesize);
    
    showtableheader();/*Dism_taobao-com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['error_list_title'] . '</th></tr>';
    showtablefooter();/*Dism_taobao_com*/
    
    showtableheader();/*Dism_taobao-com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['error_tel'] . '</th>';
    echo '<th>' . $Lang['error_content'] . '</th>';
    echo '<th>' . $Lang['error_time'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($errorList as $key => $value) {
        echo '<tr>';
        echo '<td>' . $value['tel'] . '</td>';
        echo '<td>' . $value['content'] . '</td>';
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism_taobao_com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
}