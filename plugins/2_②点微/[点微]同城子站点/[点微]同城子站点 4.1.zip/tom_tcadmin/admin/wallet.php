<?php

/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=wallet';
$modListUrl = $adminListUrl.'&tmod=wallet';
$modFromUrl = $adminFromUrl.'&tmod=wallet';

if($_GET['act'] == 'log'){
    
    $site_id = intval($_GET['site_id'])>0?intval($_GET['site_id']):0;
    
    $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
    
    tomshownavheader();
    tomshownavli($sitesInfo['name'].' > '.$Lang['log_list_title'],"",true);
    tomshownavfooter();
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->fetch_all_count(" AND site_id={$site_id} ");
    $walletLogList = C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->fetch_all_list(" AND site_id={$site_id} "," ORDER BY id DESC ",$start,$pagesize);
    
    showtableheader();/*DisM-taobao.Com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['log_log_type'] . '</th>';
    echo '<th>' . $Lang['log_change_money'] . '</th>';
    echo '<th>' . $Lang['log_old_money'] . '</th>';
    echo '<th>' . $Lang['log_beizu'] . '</th>';
    echo '<th>IP</th>';
    echo '<th>' . $Lang['log_log_time'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($walletLogList as $key => $value) {
        
        echo '<tr>';
        if($value['log_type'] == 1){
            echo '<td>' . $Lang['log_log_type_1'] . '</td>';
            echo '<td><font color="#238206">+' . $value['change_money'] . '</font></td>';
        }else if($value['log_type'] == 2){
            echo '<td>' . $Lang['log_log_type_2'] . '</td>';
            echo '<td><font color="#fd0d0d">-' . $value['change_money'] . '</font></td>';
        }
        
        echo '<td><font color="#8e8e8e">' . $value['old_money'] . '</font></td>';
        echo '<td>';
        if($value['order_type'] == 1){
            echo '[' . $Lang['log_order_type_1'] . ']';
        }else if($value['order_type'] == 2){
            echo '[' . $Lang['log_order_type_2'] . ']';
        }else if($value['order_type'] == 3){
            echo '[' . $Lang['log_order_type_3'] . ']';
        }else if($value['order_type'] == 4){
            echo '[' . $Lang['log_order_type_4'] . ']';
        }else if($value['order_type'] == 5){
            echo '[' . $Lang['log_order_type_5'] . ']';
        }else if($value['order_type'] == 6){
            echo '[' . $Lang['log_order_type_6'] . ']';
        }
        if($value['log_type'] == 1){
            echo '' . $value['beizu'] . '';
        }else if($value['log_type'] == 2){
            $tixianInfo = C::t('#tom_tcadmin#tom_tcadmin_tixian')->fetch_by_id($value['tixian_id']);
            if($tixianInfo['status'] == 1){
                echo '<font color="#fd0d0d">' . $Lang['tixian_status_1'] . '</font>';
            }else if($tixianInfo['status'] == 2){
                echo '<font color="#238206">' . $Lang['tixian_status_2'] . '</font>';
            }
        }
        
        if(!empty($value['order_no'])){
            echo '<font color="#238206">(' . $value['order_no'] . ')</font>';
        }
        echo '</td>';
        echo '<td>' . $value['log_ip'] . '</td>';
        echo '<td>' . dgmdate($value['log_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*http://t.cn/Aiux14ti*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl."&act=log&site_id=".$site_id);	
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    showtableheader();/*DisM-taobao.Com*/
    $Lang['tcadmin_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcadmin_help_1']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['tcadmin_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['tcadmin_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();/*http://t.cn/Aiux14ti*/
    
    tomshownavheader();
    tomshownavli($Lang['wallet_list_title'],$modBaseUrl,true);
    tomshownavfooter();
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_count("");
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(""," ORDER BY id DESC ",$start,$pagesize);
    
    showtableheader();/*DisM-taobao.Com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['sites_name'] . '</th>';
    echo '<th>' . $Lang['wallet_account_balance'] . '</th>';
    echo '<th>' . $Lang['wallet_total_income'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($sitesList as $key => $value) {
        
        $account_balance = $total_income = 0;        
        $walletInfoTmp = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($value['id']);
        if($walletInfoTmp){
            $account_balance = $walletInfoTmp['account_balance'];
            $total_income = $walletInfoTmp['total_income'];
        }
        
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $account_balance . '</td>';
        echo '<td>' . $total_income . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=log&site_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['log_list_title']. '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*http://t.cn/Aiux14ti*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}



