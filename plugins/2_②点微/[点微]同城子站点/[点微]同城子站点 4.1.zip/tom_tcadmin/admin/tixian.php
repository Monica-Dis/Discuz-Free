<?php

/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=tixian';
$modListUrl = $adminListUrl.'&tmod=tixian';
$modFromUrl = $adminFromUrl.'&tmod=tixian';

if($_GET['act'] == 'wxok'){
    
    $tixianInfo = C::t('#tom_tcadmin#tom_tcadmin_tixian')->fetch_by_id($_GET['id']);
    $sitesInfo  = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tixianInfo['site_id']);
    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($sitesInfo['manage_user_id']);
    
    $wxpay_mchid = trim($tongchengConfig['wxpay_mchid']);
    $wxpay_key = trim($tongchengConfig['wxpay_key']);
    $wxpay_appid = trim($tongchengConfig['wxpay_appid']);
    $wxpay_ip = trim($tongchengConfig['wxpay_ip']);
    
    define("TOM_WXPAY_MCHID", $wxpay_mchid); // ��д�̻���
    define("TOM_WXPAY_KEY", $wxpay_key); // ΢��֧����Կ
    define("TOM_WXPAY_APPID", $wxpay_appid); // ΢��appID
    define("TOM_WXPAY_IP", $wxpay_ip); // ������IP
    
    $tixian_wx_desc = '['.$sitesInfo['name'].']'.$Lang['tixian_wx_desc'];
	$desc = diconv($tixian_wx_desc,CHARSET,'utf-8');
    $price = $tixianInfo['money']*100;
    
    if(empty($tixianInfo['tx_order_no'])){
        $order_no = TOM_WXPAY_MCHID.date('YmdHis').rand(1000, 9999);
        $updateData = array();
        $updateData['tx_order_no']     = $order_no;
        C::t('#tom_tcadmin#tom_tcadmin_tixian')->update($tixianInfo['id'],$updateData);
        $tixianInfo['tx_order_no'] = $order_no;
    }
    
	# ��ҵ����
	define("TOM_WXPAY_SSLCERT_PATH", DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_cert.pem');
	define("TOM_WXPAY_SSLKEY_PATH", DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/apiclient_key.pem');
	define("TOM_WXPAY_SSLROOT_PATH", DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/WxFuKuanApi/cert/rootca.pem');

	include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/WxFuKuanApi/WxFuKuanApi.php';
	$fukuan = new WxFuKuanApi();
	$r = $fukuan->send($userInfo['openid'],$price,$tixianInfo['tx_order_no'],$desc);
    if($r['status'] == 1){
        $updateData['status'] = 2;
        $updateData['beizu'] = wx_iconv_recurrence($r['response_xml']);
        $updateData['tixian_time']     = TIMESTAMP;
        C::t('#tom_tcadmin#tom_tcadmin_tixian')->update($tixianInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        $response_xml = wx_iconv_recurrence($r['response_xml']);
        $response_xml = str_replace("<","&lt;",$response_xml);
        $response_xml = str_replace(">","&gt;",$response_xml);
        cpmsg($response_xml, $modListUrl, 'error');
    }
}else if($_GET['act'] == 'ok'){
    $tixianInfo = C::t('#tom_tcadmin#tom_tcadmin_tixian')->fetch_by_id($_GET['id']);
    $updateData['status'] = 2;
    $updateData['tixian_time']     = TIMESTAMP;
    C::t('#tom_tcadmin#tom_tcadmin_tixian')->update($tixianInfo['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'cancel'){
    $tixianInfo = C::t('#tom_tcadmin#tom_tcadmin_tixian')->fetch_by_id($_GET['id']);
    $updateData['status'] = 3;
    $updateData['tixian_time']     = TIMESTAMP;
    C::t('#tom_tcadmin#tom_tcadmin_tixian')->update($tixianInfo['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $status = intval($_GET['status'])>0? intval($_GET['status']):0;
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    
    $where = "";
    if($status == 1){
        $where = " AND status=1 ";
    }
    $count = C::t('#tom_tcadmin#tom_tcadmin_tixian')->fetch_all_count(" {$where} ");
    $tixianList = C::t('#tom_tcadmin#tom_tcadmin_tixian')->fetch_all_list(" {$where} "," ORDER BY id DESC ",$start,$pagesize);
    
    showtableheader();/*DisM-taobao.Com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['tixian_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><font color="#fd0d0d">' . $Lang['tixian_help_1'] . '</font></li>';
    echo '</ul></td></tr>';
    showtablefooter();/*http://t.cn/Aiux14ti*/
    
    tomshownavheader();
    if($status == 1){
        tomshownavli($Lang['tixian_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['tixian_status_1'],$modBaseUrl."&status=1",true);
    }else{
        tomshownavli($Lang['tixian_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['tixian_status_1'],$modBaseUrl."&status=1",false);
    }
    tomshownavfooter();
    
    showtableheader();/*DisM-taobao.Com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['sites_name'] . '</th>';
    echo '<th>' . $Lang['tixian_user'] . '</th>';
    echo '<th>' . $Lang['tixian_money'] . '</th>';
    echo '<th>' . $Lang['tixian_order_no'] . '</th>';
    echo '<th>' . $Lang['tixian_status'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tixianList as $key => $value) {
        
        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($sitesInfo['manage_user_id']);
        
        echo '<tr>';
        echo '<td>' . $sitesInfo['name'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'(ID:'.$userInfo['id'].')'. '</td>';
        echo '<td>' . $value['money'] . '</td>';
        if(!empty($value['tx_order_no'])){
            echo '<td>' . $value['tx_order_no'] . '</td>';
        }else{
            echo '<td>-</td>';
        }
        if($value['status'] == 1){
            echo '<td><font color="#fd0d0d">' . $Lang['tixian_status_1'] . '</font></td>';
        }else if($value['status'] == 2){
            echo '<td><font color="#238206">' . $Lang['tixian_status_2'] . '</font></td>';
        }else if($value['status'] == 3){
            echo '<td><font color="#8e8e8e">' . $Lang['tixian_status_3'] . '</font></td>';
        }else{
            echo '<td>-</td>';
        }
        echo '<td>' . $value['link'] . '</td>';
        echo '<td>';
        if($value['status'] == 1){
            echo '<a href="javascript:void(0);" onclick="wxok_confirm(\''.$modBaseUrl.'&act=wxok&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['tixian_status_btn2'] . '</a>&nbsp;|&nbsp;';
            echo '<a href="javascript:void(0);" onclick="ok_confirm(\''.$modBaseUrl.'&act=ok&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['tixian_status_btn1'] . '</a>';
            //echo '<a href="javascript:void(0);" onclick="cancel_confirm(\''.$modBaseUrl.'&act=cancel&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['tixian_status_3'] . '</a>';
        }else{
            echo '<td>-</td>';
        }
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*http://t.cn/Aiux14ti*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function ok_confirm(url){
  var r = confirm("{$Lang['makesure_status_2_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function wxok_confirm(url){
  var r = confirm("{$Lang['makesure_status_wx2_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function cancel_confirm(url){
  var r = confirm("{$Lang['makesure_status_3_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

