<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
function get_tcadmin_config($_arg_0)
{
	$_var_1 = C::t("common_pluginvar")->fetch_all_by_pluginid($_arg_0);
	$_var_2 = array();
	foreach ($_var_1 as $_var_3 => $_var_4) {
		$_var_2[$_var_4["variable"]] = $_var_4["value"];
	}
	return $_var_2;
}
function get_plugin_config($_arg_0)
{
	$_var_1 = C::t("common_pluginvar")->fetch_all_by_pluginid($_arg_0);
	$_var_2 = array();
	foreach ($_var_1 as $_var_3 => $_var_4) {
		$_var_2[$_var_4["variable"]] = $_var_4["value"];
	}
	return $_var_2;
}
function formatLang($_arg_0)
{
	$_var_1 = array();
	if (is_array($_arg_0) && !empty($_arg_0)) {
		foreach ($_arg_0 as $_var_2 => $_var_3) {
			$_var_1[$_var_2] = htmlspecialchars_decode($_var_3);
		}
	}
	return $_var_1;
}
function tom_doing($_arg_0, $_arg_1)
{
	cpmsg($_arg_0, $_arg_1, "loadingform");
}
function tomshowsetting($_arg_0, $_arg_1, $_arg_2)
{
	if ($_arg_0) {
		if ($_arg_2 == "input") {
			tomcreateInput($_arg_1);
		} else {
			if ($_arg_2 == "calendar") {
				tomcreateCalendar($_arg_1);
			} else {
				if ($_arg_2 == "textarea") {
					tomcreateTextarea($_arg_1);
				} else {
					if ($_arg_2 == "text") {
						tomcreateText($_arg_1);
					} else {
						if ($_arg_2 == "radio") {
							tomcreateRadio($_arg_1);
						} else {
							if ($_arg_2 == "select") {
								tomcreateSelect($_arg_1);
							} else {
								if ($_arg_2 == "file") {
									tomcreateFile($_arg_1);
								}
							}
						}
					}
				}
			}
		}
	}
	return false;
}
function tomshowsubmit($_arg_0, $_arg_1)
{
	showsubmit($_arg_0, $_arg_1);
}
function tomloadcalendarjs()
{
	echo "<script type=\"text/javascript\" src=\"static/js/calendar.js\"></script>";
}
function set_list_url($_arg_0 = '')
{
	$_var_1 = '';
	foreach ($_GET as $_var_2 => $_var_3) {
		$_var_1 = $_var_1 . ($_var_2 . "=" . $_var_3 . "&");
	}
	$_var_1 = $_var_1 . "s=1";
	$_var_4 = 86400;
	dsetcookie($_arg_0, $_var_1, $_var_4);
	return false;
}
function get_list_url($_arg_0 = '')
{
	$_var_1 = getcookie($_arg_0);
	if ($_var_1 && !empty($_var_1)) {
		return $_var_1;
	}
	return false;
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "Access Denied";
		return 0;
	}