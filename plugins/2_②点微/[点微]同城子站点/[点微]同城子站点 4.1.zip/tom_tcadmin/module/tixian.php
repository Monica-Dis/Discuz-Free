<?php

/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $money    = intval($_GET['money'])>0? intval($_GET['money']):0;
    
    if(is_numeric($money) && $money > 0){
    }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($tcadminConfig['min_money'] > 0 && $money < $tcadminConfig['min_money'] ){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($site_id);
    
    if($walletInfo['account_balance'] < $money){
        $outArr = array(
            'status'=> 303,
        );
        echo json_encode($outArr); exit;
    }
    
    $insertData = array();
    $insertData['site_id']     = $site_id;
    $insertData['money']       = $money;
    $insertData['status']       = 1;
    $insertData['add_time']    = TIMESTAMP;
    if(C::t('#tom_tcadmin#tom_tcadmin_tixian')->insert($insertData)){
        
        $tixianId = C::t('#tom_tcadmin#tom_tcadmin_tixian')->insert_id();
        
        $updateData = array();
        $updateData['account_balance']   = $walletInfo['account_balance'] - $money;
        C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
        
        $insertData = array();
        $insertData['site_id']      = $site_id;
        $insertData['log_type']     = 2;
        $insertData['tixian_id']    = $tixianId;
        $insertData['change_money'] = $money;
        $insertData['old_money']    = $walletInfo['account_balance'];
        $insertData['log_ip']       = $_G['clientip'];
        $insertData['log_time']     = TIMESTAMP;
        C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData);
        
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tongchengConfig['manage_user_id'])){
            $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if(!empty($toUser['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=index");
                $template_first = lang("plugin/tom_tcadmin", "template_tixian_title");
                $template_first = str_replace("{SITENAME}",$__SitesInfo['name'], $template_first);
                $template_first = str_replace("{MONEY}",$money, $template_first);
                $smsData = array(
                    'first'         => $template_first,
                    'keyword1'      => $__SitesInfo['name'],
                    'keyword2'      => lang("plugin/tom_tcadmin", "template_tixian_content"),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }
    
    $outArr = array(
        'status'=> 404,
    );
    echo json_encode($outArr); exit;
    
}

$tixianListTmp = C::t('#tom_tcadmin#tom_tcadmin_tixian')->fetch_all_list(" AND site_id={$site_id} ","ORDER BY id DESC",0,10);
$tixianList = array();
if(is_array($tixianListTmp) && !empty($tixianListTmp)){
    foreach ($tixianListTmp as $key => $value){
        $tixianList[$key] = $value;
    }
}

$saveUrl = "plugin.php?id=tom_tcadmin&site={$site_id}&mod=tixian&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcadmin:tixian");

