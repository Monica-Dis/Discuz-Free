<?php

/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $name              = isset($_GET['name'])? addslashes($_GET['name']):'';
    $share_title       = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc        = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $share_pic         = isset($_GET['share_pic'])? addslashes($_GET['share_pic']):'';
    $logo              = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    $kefu_qrcode       = isset($_GET['kefu_qrcode'])? addslashes($_GET['kefu_qrcode']):'';
    $dingyue_qrcode    = isset($_GET['dingyue_qrcode'])? addslashes($_GET['dingyue_qrcode']):'';
    
    $updateData = array();
    $updateData['name']            = $name;
    $updateData['share_title']     = $share_title;
    $updateData['share_desc']      = $share_desc;
    $updateData['share_pic']       = $share_pic;
    $updateData['logo']            = $logo;
    $updateData['kefu_qrcode']     = $kefu_qrcode;
    $updateData['dingyue_qrcode']  = $dingyue_qrcode;
    $updateData['part1']           = TIMESTAMP;
    if(C::t('#tom_tongcheng#tom_tongcheng_sites')->update($site_id,$updateData)){
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

if(!preg_match('/^http/', $__SitesInfo['share_pic']) ){
    $share_pic = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['share_pic'];
}else{
    $share_pic = $__SitesInfo['share_pic'];
}

if(!preg_match('/^http/', $__SitesInfo['logo']) ){
    $logo = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['logo'];
}else{
    $logo = $__SitesInfo['logo'];
}

if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode']) ){
    $kefu_qrcode = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
}else{
    $kefu_qrcode = $__SitesInfo['kefu_qrcode'];
}

if(!preg_match('/^http/', $__SitesInfo['dingyue_qrcode']) ){
    $dingyue_qrcode = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['dingyue_qrcode'];
}else{
    $dingyue_qrcode = $__SitesInfo['dingyue_qrcode'];
}

$uploadUrl1 = "plugin.php?id=tom_tcadmin&site={$site_id}&mod=upload&act=share_pic&formhash=".FORMHASH;
$uploadUrl2 = "plugin.php?id=tom_tcadmin&site={$site_id}&mod=upload&act=logo&formhash=".FORMHASH;
$uploadUrl3 = "plugin.php?id=tom_tcadmin&site={$site_id}&mod=upload&act=kefu_qrcode&formhash=".FORMHASH;
$uploadUrl4 = "plugin.php?id=tom_tcadmin&site={$site_id}&mod=upload&act=dingyue_qrcode&formhash=".FORMHASH;

$saveUrl = "plugin.php?id=tom_tcadmin&site={$site_id}&mod=edit&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcadmin:edit");