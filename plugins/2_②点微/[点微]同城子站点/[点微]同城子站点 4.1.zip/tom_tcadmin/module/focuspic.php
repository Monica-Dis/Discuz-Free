<?php

/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $photoArr = $photoLinkArr = $photoPaixuArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
        if(strpos($key, "link_") !== false){
            $kk = intval(ltrim($key, "link_"));
            $photoLinkArr[$kk] = addslashes($value);
        }
        if(strpos($key, "paixu_") !== false){
            $kk = intval(ltrim($key, "paixu_"));
            $photoPaixuArr[$kk] = addslashes($value);
        }
    }
    
    C::t('#tom_tongcheng#tom_tongcheng_focuspic')->delete_by_site_id($site_id,1);
        
    if(is_array($photoArr) && !empty($photoArr)){
        foreach ($photoArr as $key => $value){
            $insertData = array();
            $insertData['site_id']      = $site_id;
            $insertData['type_id']      = 1;
            $insertData['picurl']       = $value;
            $insertData['link']         = $photoLinkArr[$key];
            $insertData['fsort']        = $photoPaixuArr[$key];
            C::t('#tom_tongcheng#tom_tongcheng_focuspic')->insert($insertData);
        }
    }
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
        
    
}

$focuspicListTmp = C::t('#tom_tongcheng#tom_tongcheng_focuspic')->fetch_all_list(" AND site_id={$site_id} AND type_id = 1 "," ORDER BY fsort ASC,id ASC ",0,10);
$focuspicList = array();
$photoCount = 0;
if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
    foreach ($focuspicListTmp as $kk => $vv){
        $photoCount++;
        if(!preg_match('/^http/', $vv['picurl']) ){
            if(strpos($vv['picurl'], 'source/plugin/') === FALSE){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
            }else{
                $picurlTmp = $vv['picurl'];
            }
        }else{
            $picurlTmp = $vv['picurl'];
        }
        $focuspicList[$kk]['picurl']    = $vv['picurl'];
        $focuspicList[$kk]['link']      = $vv['link'];
        $focuspicList[$kk]['paixu']     = $vv['fsort'];
        $focuspicList[$kk]['src']       = $picurlTmp;
        $focuspicList[$kk]['li_i']      = $photoCount;

    }
}
    
$saveUrl = "plugin.php?id=tom_tcadmin&site={$site_id}&mod=focuspic&act=save";
$uploadUrl1 = "plugin.php?id=tom_tcadmin&site={$site_id}&mod=upload&act=focuspic&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcadmin:focuspic");