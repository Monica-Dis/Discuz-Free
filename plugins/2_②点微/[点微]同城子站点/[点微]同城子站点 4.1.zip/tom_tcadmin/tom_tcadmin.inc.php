<?php

/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$prand = rand(1, 1000);
$cssJsVersion = "20180903";

# tongcheng start
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];

$appid = trim($tongchengConfig['wxpay_appid']);  
$appsecret = trim($tongchengConfig['wxpay_appsecret']);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$wxJssdkConfig = array();
$wxJssdkConfig["appId"]     = "";
$wxJssdkConfig["timestamp"] = time();
$wxJssdkConfig["nonceStr"]  = "";
$wxJssdkConfig["signature"] = "";
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tongchengConfig['wx_share_title'];
$shareDesc  = $tongchengConfig['wx_share_desc'];
$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=index";
$shareLogo  = $tongchengConfig['wx_share_pic'];

$__SitesInfo = array('id'=>1,'name'=>$tongchengConfig['plugin_name']);
$__CityInfo = array('id'=>0,'name'=>'');
if($site_id > 1){
    $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
    if($sitesInfoTmp){
        $__SitesInfo = $sitesInfoTmp;
        if($__SitesInfo['status'] == 2){
            dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site=1&mod=index");exit;
        }
        if(!empty($__SitesInfo['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
            if($cityInfoTmp){
                $__CityInfo = $cityInfoTmp;
            }
        }
        $shareTitle = $__SitesInfo['share_title'];
        $shareDesc  = $__SitesInfo['share_desc'];
        if(!preg_match('/^http/', $__SitesInfo['share_pic']) ){
            $shareLogo = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['share_pic'];
        }else{
            $shareLogo = $__SitesInfo['share_pic'];
        }
    }else{
        $site_id = 1;
    }
}
if($site_id == 1){
    $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_level1_name($tongchengConfig['city_name']);
    if($cityInfoTmp){
        $__CityInfo = $cityInfoTmp;
    }
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login.php';

# tongcheng end

# check start
if($__UserInfo['groupid'] == 2 && $__UserInfo['groupsiteid'] == $site_id){
}else{
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=index");exit;
}
# check end

if($_GET['mod'] == 'index'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcadmin/module/index.php';
    
}else if($_GET['mod'] == 'wallet'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcadmin/module/wallet.php';
    
}else if($_GET['mod'] == 'wallet_log'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcadmin/module/wallet_log.php';
    
}else if($_GET['mod'] == 'tixian'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcadmin/module/tixian.php';
    
}else if($_GET['mod'] == 'edit'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcadmin/module/edit.php';
    
}else if($_GET['mod'] == 'focuspic'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcadmin/module/focuspic.php';
    
}else if($_GET['mod'] == 'focuspicShop'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcadmin/module/focuspicShop.php';
    
}else if($_GET['mod'] == 'upload'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcadmin/module/upload.php';
    
}else{
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcadmin/module/index.php';
    
}