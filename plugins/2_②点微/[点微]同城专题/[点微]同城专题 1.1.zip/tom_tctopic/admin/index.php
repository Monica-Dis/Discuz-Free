<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_tctopic_admin_index_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        
        $data = __get_post_data();
        
        $insertData = array();
        $insertData = $data['topicInfo'];
        $insertData['add_time'] = TIMESTAMP;
        if(C::t('#tom_tctopic#tom_tctopic')->insert($insertData)){
            $tctopic_id = C::t('#tom_tctopic#tom_tctopic')->insert_id();
            
            if(!empty($data['photoInfo']['bg_picurl'])){
                $insertData = array();
                $insertData['tctopic_id']   = $tctopic_id;
                $insertData['picurl']       = $data['photoInfo']['bg_picurl'];
                $insertData['type']         = 1;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tctopic#tom_tctopic_photo')->insert($insertData);
            }
            if(!empty($data['photoInfo']['list_picurl'])){
                $insertData = array();
                $insertData['tctopic_id']   = $tctopic_id;
                $insertData['picurl']       = $data['photoInfo']['list_picurl'];
                $insertData['type']         = 2;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tctopic#tom_tctopic_photo')->insert($insertData);
            }
            if(!empty($data['photoInfo']['header_picurl'])){
                $insertData = array();
                $insertData['tctopic_id']   = $tctopic_id;
                $insertData['picurl']       = $data['photoInfo']['header_picurl'];
                $insertData['type']         = 3;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tctopic#tom_tctopic_photo')->insert($insertData);
            }
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();/*dism - taobao - com*/
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*DisM �� Taobao �� Com*/
    }
    
}else if($_GET['act'] == 'edit'){

    $tctopicInfo = C::t('#tom_tctopic#tom_tctopic')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $data = __get_post_data($tctopicInfo);
        
        $updateData = array();
        $updateData = $data['topicInfo'];
        $updateData['update_time'] = TIMESTAMP;
        if(C::t('#tom_tctopic#tom_tctopic')->update($tctopicInfo['id'],$updateData)){
            C::t('#tom_tctopic#tom_tctopic_photo')->delete_all(" AND tctopic_id={$tctopicInfo['id']} AND type IN(1,2,3) ");
            
            if(!empty($data['photoInfo']['bg_picurl'])){
                $insertData = array();
                $insertData['tctopic_id'] = $tctopicInfo['id'];
                $insertData['picurl'] = $data['photoInfo']['bg_picurl'];
                $insertData['type'] = 1;
                $insertData['add_time'] = TIMESTAMP;
                C::t('#tom_tctopic#tom_tctopic_photo')->insert($insertData);
            }
            if(!empty($data['photoInfo']['list_picurl'])){
                $insertData = array();
                $insertData['tctopic_id'] = $tctopicInfo['id'];
                $insertData['picurl'] = $data['photoInfo']['list_picurl'];
                $insertData['type'] = 2;
                $insertData['add_time'] = TIMESTAMP;
                C::t('#tom_tctopic#tom_tctopic_photo')->insert($insertData);
            }
            if(!empty($data['photoInfo']['header_picurl'])){
                $insertData = array();
                $insertData['tctopic_id'] = $tctopicInfo['id'];
                $insertData['picurl'] = $data['photoInfo']['header_picurl'];
                $insertData['type'] = 3;
                $insertData['add_time'] = TIMESTAMP;
                C::t('#tom_tctopic#tom_tctopic_photo')->insert($insertData);
            }
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{

        tomloadcalendarjs();
        loadeditorjs();/*dism - taobao - com*/
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($tctopicInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*DisM �� Taobao �� Com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    $tctopicInfo = C::t('#tom_tctopic#tom_tctopic')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tctopic#tom_tctopic')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    $tctopicInfo = C::t('#tom_tctopic#tom_tctopic')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tctopic#tom_tctopic')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'listshow'){
    $tctopicInfo = C::t('#tom_tctopic#tom_tctopic')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['is_list_show'] = 1;
    C::t('#tom_tctopic#tom_tctopic')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'listhide'){
    $tctopicInfo = C::t('#tom_tctopic#tom_tctopic')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['is_list_show'] = 0;
    C::t('#tom_tctopic#tom_tctopic')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tctopic#tom_tctopic')->delete_by_id($_GET['id']);
    C::t('#tom_tctopic#tom_tctopic_photo')->delete_by_tctopic_id($_GET['id']);
    C::t('#tom_tctopic#tom_tctopic_model')->delete_by_tctopic_id($_GET['id']);
    C::t('#tom_tctopic#tom_tctopic_nav')->delete_by_tctopic_id($_GET['id']);
    C::t('#tom_tctopic#tom_tctopic_guanggao')->delete_by_tctopic_id($_GET['id']);
    C::t('#tom_tctopic#tom_tctopic_model_goods')->delete_by_tctopic_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'url'){
    
    $tctopicInfo = C::t('#tom_tctopic#tom_tctopic')->fetch_by_id($_GET['id']);
    $url = "{SITEURL}plugin.php?id=tom_tctopic&site={$tctopicInfo['site_id']}&mod=info&tctopic_id=".$_GET['id'];
    $url = str_replace("{SITEURL}", $_G['siteurl'], $url);
    __create_nav_html();
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' .$tctopicInfo['title'].'>>'. $Lang['index_url_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_url_title'] . ' <input name="" readonly="readonly" type="text" value="'.$url.'" size="100" /> </li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
}else{
    set_list_url("tom_tctopic_admin_index_list");
    
    $site_id    = intval($_GET['site_id'])>0? intval($_GET['site_id']):0;
    $status     = intval($_GET['status'])>0? intval($_GET['status']):0;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($status)){
        if($status == 1){
            $where.= " AND status=1 ";
        }else if($status == 2){
            $where.= " AND status != 1 ";
        }
    }
    
    $order = "ORDER BY add_time DESC,id DESC";
    
    $pagesize = 20;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tctopic#tom_tctopic')->fetch_all_count($where);
    $tctopicList  = C::t('#tom_tctopic#tom_tctopic')->fetch_all_list($where,$order,$start,$pagesize);
    
    showtableheader();
    $Lang['index_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_1']);
    $Lang['index_help_2']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_2']);
    $Lang['index_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_3']);
    $Lang['index_help_4']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_4']);
    $Lang['index_help_5']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_5']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_1'] . '</li>';
    echo '<li>' . $Lang['index_help_2_1'] . '<a target="_blank" href="http://www.tomwx.cn/index.php?m=help&t=plugin&pluginid=tom_tctopic"><font color="#FF0000">' . $Lang['index_help_2_2'] . '</font></a></li>';
    if($tongchengConfig['open_yun'] == 2){
        echo '<li>' . $Lang['index_help_4'] . '</li>';
    }
    if($tongchengConfig['open_yun'] == 3){
        echo '<li>' . $Lang['index_help_5'] . '</li>';
    }
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/

    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&status={$status}";
    
    showformheader($modFromUrl."&formhash=".FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
    
    $site_1 = '';
    if($site_id == 1){
        $site_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id" onChange="getCity();">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
        
    $status_1 = $status_2 = '';
    if($status == 1){
        $status_1 = 'selected';
    }else if($status == 2){
        $status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['status_0'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*DisM �� Taobao �� Com*/
    
    __create_nav_html();
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 60px;"> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['index_title'] . '</th>';
    echo '<th>' . $Lang['index_clicks'] . '</th>';
    echo '<th>' . $Lang['index_is_list_show'] . '</th>';
    echo '<th>' . $Lang['status'] . '</th>';
    echo '<th>' . $Lang['sort'] . '</th>';
    echo '<th>' . $Lang['index_end_time'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th >' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tctopicList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $photoList = C::t('#tom_tctopic#tom_tctopic_photo')->fetch_all_list(" AND tctopic_id = {$value['id']} AND type IN(1,2,3) ");
        $bg_picurl = $list_picurl = $header_picurl = '';
        if(is_array($photoList) && !empty($photoList)){
            foreach($photoList as $k => $v){
                if($v['type'] == 1){
                    $bg_picurl = $v['picurlTmp'];
                }else if($v['type'] == 2){
                    $list_picurl = $v['picurlTmp'];
                }else if($v['type'] == 3){
                    $header_picurl = $v['picurlTmp'];
                }
            }
        }
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 0){
            if($value['site_id'] > 1){
                echo '<td>' . $siteInfo['name'] . '</td>';
            }else{
                echo '<td>' . $Lang['sites_one'] . '</td>';
            }
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $value['title'] . '</td>';
        echo '<td>' . $value['clicks'] . '</td>';
        if($value['is_list_show'] == 1 ){
            echo '<td><font color="#0a9409">'.$Lang['index_is_list_show_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=listhide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['index_is_list_show_0']. ')</font></a></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['index_is_list_show_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=listshow&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['index_is_list_show_1']. ')</font></a></td>';
        }
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">'.$Lang['status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['status_0']. ')</font></a></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['status_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['status_1']. ')</font></a></td>';
        }
        echo '<td>' . $value['tsort'] . '</td>';
        if($value['end_time'] > 0){
            echo '<td>' . dgmdate($value['end_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        }else{
            echo '<td>-</td>';
        }
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&act=url&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_url_title'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&tmod=model&tctopic_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_model_title'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&tmod=nav&tctopic_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_nav_title'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$adminBaseUrl.'&tmod=guanggao&tctopic_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_guanggao_title'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    showformfooter(); /*DisM �� Taobao �� Com*/
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id                = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $title                  = isset($_GET['title'])? addslashes($_GET['title']):'';
    $bg_color               = isset($_GET['bg_color'])? addslashes($_GET['bg_color']):'';
    $theme_color            = isset($_GET['theme_color'])? addslashes($_GET['theme_color']):'';
    $virtual_clicks         = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $haibao_qrcode_location = isset($_GET['haibao_qrcode_location'])? intval($_GET['haibao_qrcode_location']):0;
    $music_url              = isset($_GET['music_url'])? addslashes($_GET['music_url']):'';
    $open_model_nav         = isset($_GET['open_model_nav'])? intval($_GET['open_model_nav']):0;
    $end_time               = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time               = strtotime($end_time);
    $huodong_guize          = isset($_GET['huodong_guize'])? addslashes($_GET['huodong_guize']):'';
    $share_title            = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc             = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $is_list_show           = isset($_GET['is_list_show'])? intval($_GET['is_list_show']):0;
    $tsort                  = isset($_GET['tsort'])? intval($_GET['tsort']):100;
    
    $bg_picurl = $list_picurl = $header_picurl = $haibao_picurl = $kefu_qrcode = $share_pic = "";
    if($_GET['act'] == 'add'){
        $bg_picurl          = tomuploadFile("bg_picurl");
        $list_picurl        = tomuploadFile("list_picurl");
        $header_picurl      = tomuploadFile("header_picurl");
        $haibao_picurl      = tomuploadFile("haibao_picurl");
        $kefu_qrcode        = tomuploadFile("kefu_qrcode");
        $share_pic          = tomuploadFile("share_pic");
    }else if($_GET['act'] == 'edit'){
        $bg_picurl          = tomuploadFile("bg_picurl",$infoArr['bg_picurl']);
        $list_picurl        = tomuploadFile("list_picurl",$infoArr['list_picurl']);
        $header_picurl      = tomuploadFile("header_picurl",$infoArr['header_picurl']);
        $haibao_picurl      = tomuploadFile("haibao_picurl",$infoArr['haibao_picurl']);
        $kefu_qrcode        = tomuploadFile("kefu_qrcode",$infoArr['kefu_qrcode']);
        $share_pic          = tomuploadFile("share_pic",$infoArr['share_pic']);
    }
    
    $topicInfo = array();
    $topicInfo['site_id']           = $site_id;
    $topicInfo['title']             = $title;
    $topicInfo['bg_color']          = $bg_color;
    $topicInfo['theme_color']       = $theme_color;
    $topicInfo['haibao_picurl']     = $haibao_picurl;
    $topicInfo['haibao_qrcode_location'] = $haibao_qrcode_location;
    $topicInfo['music_url']         = $music_url;
    $topicInfo['open_model_nav']    = $open_model_nav;
    $topicInfo['kefu_qrcode']       = $kefu_qrcode;
    $topicInfo['end_time']          = $end_time;
    $topicInfo['huodong_guize']     = $huodong_guize;
    $topicInfo['virtual_clicks']    = $virtual_clicks;
    $topicInfo['share_title']       = $share_title;
    $topicInfo['share_desc']        = $share_desc;
    $topicInfo['share_pic']         = $share_pic;
    $topicInfo['is_list_show']      = $is_list_show;
    $topicInfo['tsort']             = $tsort;
    
    $photoInfo = array();
    $photoInfo['bg_picurl']         = $bg_picurl;
    $photoInfo['list_picurl']       = $list_picurl;
    $photoInfo['header_picurl']     = $header_picurl;
    
    $data['topicInfo']          = $topicInfo;
    $data['photoInfo']          = $photoInfo;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'site_id'                   => 1,
        'title'                     => '',
        'bg_color'                  => '',
        'theme_color'               => '',
        'bg_picurl'                 => '',
        'list_picurl'               => '',
        'header_picurl'             => '',
        'music_url'                 => '',
        'open_model_nav'            => 0,
        'end_time'                  => '',
        'haibao_picurl'             => '',
        'haibao_qrcode_location'    => '',
        'kefu_qrcode'               => '',
        'huodong_guize'             => '',
        'virtual_clicks'            => '',
        'share_title'               => '',
        'share_desc'                => '',
        'share_pic'                 => '',
        'is_list_show'              => 1,
        'tsort'                     => 100,
    );
    
    $options = array_merge($options, $infoArr);
    if(!empty($infoArr)){
        $photoList = C::t('#tom_tctopic#tom_tctopic_photo')->fetch_all_list(" AND tctopic_id = {$infoArr['id']} AND type IN(1,2,3) ");
        if(is_array($photoList) && !empty($photoList)){
            foreach($photoList as $k => $v){
                if($v['type'] == 1){
                    $options['bg_picurl'] = $v['picurl'];
                }else if($v['type'] == 2){
                    $options['list_picurl'] = $v['picurl'];
                }else if($v['type'] == 3){
                    $options['header_picurl'] = $v['picurl'];
                }
            }
        }
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    tomshowsetting(true,array('title'=>$Lang['index_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['index_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_bg_color'],'name'=>'bg_color','value'=>$options['bg_color'],'msg'=>$Lang['index_bg_color_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_theme_color'],'name'=>'theme_color','value'=>$options['theme_color'],'msg'=>$Lang['index_theme_color_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_bg_picurl'],'name'=>'bg_picurl','value'=>$options['bg_picurl'],'msg'=>$Lang['index_bg_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_header_picurl'],'name'=>'header_picurl','value'=>$options['header_picurl'],'msg'=>$Lang['index_header_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_list_picurl'],'name'=>'list_picurl','value'=>$options['list_picurl'],'msg'=>$Lang['index_list_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_end_time'],'name'=>'end_time','value'=>$options['end_time'],'msg'=>$Lang['index_end_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['index_music_url'],'name'=>'music_url','value'=>$options['music_url'],'msg'=>$Lang['index_music_url_msg']),"input");
    $open_model_nav_item = array(1=>$Lang['index_open_model_nav_1'], 0=>$Lang['index_open_model_nav_0']);
    tomshowsetting(true,array('title'=>$Lang['index_open_model_nav'],'name'=>'open_model_nav','value'=>$options['open_model_nav'],'msg'=>$Lang['index_open_model_nav_msg'],'item'=>$open_model_nav_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_haibao_picurl'],'name'=>'haibao_picurl','value'=>$options['haibao_picurl'],'msg'=>$Lang['index_haibao_picurl_msg']),"file");
    $haibao_qrcode_location_item = array(1=>$Lang['index_haibao_qrcode_location_1'], 2=>$Lang['index_haibao_qrcode_location_2']);
    tomshowsetting(true,array('title'=>$Lang['index_haibao_qrcode_location'],'name'=>'haibao_qrcode_location','value'=>$options['haibao_qrcode_location'],'msg'=>$Lang['index_haibao_qrcode_location_msg'],'item'=>$haibao_qrcode_location_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_kefu_qrcode'],'name'=>'kefu_qrcode','value'=>$options['kefu_qrcode'],'msg'=>$Lang['index_kefu_qrcode_msg']),"file");
    //tomshowsetting(true,array('title'=>$Lang['index_virtual_clicks'],'name'=>'virtual_clicks','value'=>$options['virtual_clicks'],'msg'=>$Lang['index_virtual_clicks_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_share_title'],'name'=>'share_title','value'=>$options['share_title'],'msg'=>$Lang['index_share_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_share_desc'],'name'=>'share_desc','value'=>$options['share_desc'],'msg'=>$Lang['index_share_desc_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_share_pic'],'name'=>'share_pic','value'=>$options['share_pic'],'msg'=>$Lang['index_share_pic_msg']),"file");
    $is_list_show_item = array(1=>$Lang['index_is_list_show_1'], 0=>$Lang['index_is_list_show_0']);
    tomshowsetting(true,array('title'=>$Lang['index_is_list_show'],'name'=>'is_list_show','value'=>$options['is_list_show'],'msg'=>$Lang['index_is_list_show_msg'],'item'=>$is_list_show_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'tsort','value'=>$options['tsort'],'msg'=>$Lang['sort_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_huodong_guize'],'name'=>'huodong_guize','value'=>$options['huodong_guize'],'msg'=>$Lang['index_huodong_guize_msg']),"text");
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['edit'],"",true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',false);
    }
    
    tomshownavfooter(); /*Dism_taobao��com*/
}