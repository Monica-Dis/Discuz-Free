<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=goods&model_id='.$_GET['model_id'];
$modListUrl = $adminListUrl.'&tmod=goods&model_id='.$_GET['model_id'];
$modFromUrl = $adminFromUrl.'&tmod=goods&model_id='.$_GET['model_id'];

$model_id = intval($_GET['model_id'])>0? intval($_GET['model_id']):0;
$modelInfo = C::t('#tom_tctopic#tom_tctopic_model')->fetch_by_id($model_id);
$tctopicInfo = C::t('#tom_tctopic#tom_tctopic')->fetch_by_id($modelInfo['tctopic_id']);

showtableheader();
echo '<tr><th colspan="15" class="partition"><font color="#fd0d0d">' . $tctopicInfo['title'] .'</font>&nbsp;&gt;&gt;&nbsp;<font color="#238206">' . $modelInfo['title'] .'</font>&nbsp;&gt;&gt;&nbsp;'.$Lang['goods_list_title']. '</th></tr>';
showtablefooter(); /*dism��taobao��com*/

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $data = __get_post_data();
        
        $insertData = array();
        $insertData = $data['goodsInfo'];
        $insertData['tctopic_id']   = $modelInfo['tctopic_id'];
        $insertData['model_id']     = $modelInfo['id'];
        $insertData['add_time']     = TIMESTAMP;
        $model_goods_id = C::t('#tom_tctopic#tom_tctopic_model_goods')->insert($insertData, true);
        
        if($model_goods_id > 0){
            if(!empty($data['picurl'])){
                $insertData = array();
                $insertData['tctopic_id']       = $modelInfo['tctopic_id'];
                $insertData['model_goods_id']   = $model_goods_id;
                $insertData['picurl']           = $data['picurl'];
                $insertData['type']             = 4;
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_tctopic#tom_tctopic_photo')->insert($insertData);
            }
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();/*dism - taobao - com*/
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*DisM �� Taobao �� Com*/
    }
    
}else if($_GET['act'] == 'edit'){
    
    $goodsInfo = C::t('#tom_tctopic#tom_tctopic_model_goods')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        
        $data = __get_post_data();
        
        $updateData = array();
        $updateData = $data['goodsInfo'];
        $updateData['update_time'] = TIMESTAMP;
        if(C::t('#tom_tctopic#tom_tctopic_model_goods')->update($goodsInfo['id'],$updateData)){
            C::t('#tom_tctopic#tom_tctopic_photo')->delete_by_model_goods_id($goodsInfo['id']);
            
            if(!empty($data['picurl'])){
                $insertData = array();
                $insertData['tctopic_id']       = $modelInfo['tctopic_id'];
                $insertData['model_goods_id']   = $goodsInfo['id'];
                $insertData['picurl']           = $data['picurl'];
                $insertData['type']             = 4;
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_tctopic#tom_tctopic_photo')->insert($insertData);
            }
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();/*dism - taobao - com*/
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($goodsInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*DisM �� Taobao �� Com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tctopic#tom_tctopic_model_goods')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tctopic#tom_tctopic_model_goods')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tctopic#tom_tctopic_model_goods')->delete_by_id($_GET['id']);
    C::t('#tom_tctopic#tom_tctopic_photo')->delete_by_model_goods_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'editgoods'){
    
    if(submitcheck('submit')){
        
        $index_show_num     = intval($_GET['index_show_num'])>0? intval($_GET['index_show_num']):0;
        $list_template      = isset($_GET['list_template'])? addslashes($_GET['list_template']):'';
    
        $updateData = array();
        $updateData['index_show_num']   = $index_show_num;
        $updateData['list_template']    = $list_template;
        C::t('#tom_tctopic#tom_tctopic_model')->update($modelInfo['id'], $updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }
    
}else{
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><b><font color="#f00">' . $Lang['goods_help_1'] . '</b></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    tomloadcalendarjs();
    showformheader($modFromUrl.'&act=editgoods&formhash='.FORMHASH);
    showtableheader();
    
    tomshowsetting(true,array('title'=>$Lang['model_index_show_num'],'name'=>'index_show_num','value'=>$modelInfo['index_show_num'],'msg'=>$Lang['model_index_show_num_msg']),"input");
    if($modelInfo['type'] == 1){
        if($modelInfo['plugin_id'] == 'qianggou'){
            
            $list_template_item = array('template_qianggou_1'=>$Lang['model_qianggou_list_template_1'],'template_qianggou_2'=>$Lang['model_qianggou_list_template_2'],'template_qianggou_3'=>$Lang['model_qianggou_list_template_3']);
            tomshowsetting(true,array('title'=>$Lang['model_qianggou_list_template'],'name'=>'list_template','value'=>$modelInfo['list_template'],'msg'=>$Lang['model_list_template_msg'],'item'=>$list_template_item,'width'=>450),"radio");
    
        }else if($modelInfo['plugin_id'] == 'ptuan'){
            
            $list_template_item = array('template_ptuan_1'=>$Lang['model_ptuan_list_template_1']);
            tomshowsetting(true,array('title'=>$Lang['model_ptuan_list_template'],'name'=>'list_template','value'=>$modelInfo['list_template'],'msg'=>$Lang['model_list_template_msg'],'item'=>$list_template_item,'width'=>300),"radio");
            
        }else if($modelInfo['plugin_id'] == 'mall'){
            
            $list_template_item = array('template_mall_1'=>$Lang['model_mall_list_template_1'],'template_mall_2'=>$Lang['model_mall_list_template_2']);
            tomshowsetting(true,array('title'=>$Lang['model_mall_list_template'],'name'=>'list_template','value'=>$modelInfo['list_template'],'msg'=>$Lang['model_list_template_msg'],'item'=>$list_template_item,'width'=>300),"radio");
            
        }else if($modelInfo['plugin_id'] == 'shop'){
            
            $list_template_item = array('template_shop_1'=>$Lang['model_shop_list_template_1']);
            tomshowsetting(true,array('title'=>$Lang['model_shop_list_template'],'name'=>'list_template','value'=>$modelInfo['list_template'],'msg'=>$Lang['model_list_template_msg'],'item'=>$list_template_item,'width'=>300),"radio");
            
        }else if($modelInfo['plugin_id'] == 'huodong'){
            
            $list_template_item = array('template_huodong_1'=>$Lang['model_huodong_list_template_1']);
            tomshowsetting(true,array('title'=>$Lang['model_huodong_list_template'],'name'=>'list_template','value'=>$modelInfo['list_template'],'msg'=>$Lang['model_list_template_msg'],'item'=>$list_template_item,'width'=>300),"radio");
            
        }
    }else if($modelInfo['type'] == 2){
        
        $list_template_item = array('template_mall_1'=>$Lang['model_mall_list_template_1'],'template_mall_2'=>$Lang['model_mall_list_template_2'],'template_other_1'=>$Lang['model_other_list_template_1'],'template_other_2'=>$Lang['model_other_list_template_2'],'template_other_3'=>$Lang['model_other_list_template_3'],'template_other_4'=>$Lang['model_other_list_template_4']);
        tomshowsetting(true,array('title'=>$Lang['model_other_list_template'],'name'=>'list_template','value'=>$modelInfo['list_template'],'msg'=>$Lang['model_list_template_msg'],'item'=>$list_template_item,'width'=>800),"radio");

    }
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*DisM �� Taobao �� Com*/
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = " AND model_id = {$modelInfo['id']}";
    $pagesize = 1000;
    $start = ($page-1)*$pagesize;	
    $goodsList = C::t('#tom_tctopic#tom_tctopic_model_goods')->fetch_all_list($where," ORDER BY gsort ASC,id DESC ",$start,$pagesize);
    
    __create_nav_html();
    showtableheader();
    
    if($modelInfo['type'] == 1){
        
        $goodsTypeName = '';
        if($modelInfo['plugin_id'] == 'qianggou'){
            $goodsTypeName = $Lang['goods_id_qianggou'];
        }else if($modelInfo['plugin_id'] == 'ptuan'){
            $goodsTypeName = $Lang['goods_id_ptuan'];
        }else if($modelInfo['plugin_id'] == 'mall'){
            $goodsTypeName = $Lang['goods_id_mall'];
        }else if($modelInfo['plugin_id'] == 'shop'){
            $goodsTypeName = $Lang['goods_id_shop'];
        }else if($modelInfo['plugin_id'] == 'huodong'){
            $goodsTypeName = $Lang['goods_id_huodong'];
        }
        
        echo '<tr class="header">';
        echo '<th> ID </th>';
        echo '<th>' .$goodsTypeName. $Lang['goods_id'] . '</th>';
        echo '<th>' .$goodsTypeName. $Lang['goods_title'] . '</th>';
        if($modelInfo['plugin_id'] == 'shop'){
            echo '<th>' . $Lang['goods_sub_title'] . '</th>';
        }
        echo '<th>' . $Lang['goods_picurl'] . '</th>';
        echo '<th>' . $Lang['status'] . '</th>';
        echo '<th>' . $Lang['sort'] . '</th>';
        echo '<th>' . $Lang['add_time'] . '</th>';
        echo '<th>' . $Lang['handle'] . '</th>';
        echo '</tr>';

        $i = 1;
        foreach ($goodsList as $key => $value) {

            $photoInfo = C::t('#tom_tctopic#tom_tctopic_photo')->fetch_by(" AND model_goods_id = {$value['id']} AND type = 4 ");
            
            $titleTmp = '';
            if($modelInfo['plugin_id'] == 'qianggou'){
                $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($value['goods_id']);
                $titleTmp = $goodsInfoTmp['title'];
            }else if($modelInfo['plugin_id'] == 'ptuan'){
                $goodsInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($value['goods_id']);
                $titleTmp = $goodsInfoTmp['name'];
            }else if($modelInfo['plugin_id'] == 'mall'){
                $goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($value['goods_id']);
                $titleTmp = $goodsInfoTmp['title'];
            }else if($modelInfo['plugin_id'] == 'shop'){
                $tcshopInfoTmp  = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['goods_id']);
                $titleTmp = $tcshopInfoTmp['name'];
            }else if($modelInfo['plugin_id'] == 'huodong'){
                $tchuodongInfoTmp  = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($value['goods_id']);
                $titleTmp = $tchuodongInfoTmp['title'];
            }
            
            echo '<tr>';
            echo '<td>' . $value['id'] . '</td>';
            echo '<td>'. $value['goods_id'] . '</td>';
            if(!empty($value['title'])){
                echo '<td>' . $value['title'] . '</td>';
            }else{
                echo '<td>' . $titleTmp . '</td>';
            }
            if($modelInfo['plugin_id'] == 'shop'){
                echo '<td>' . $value['sub_title'] . '</td>';
            }
            echo '<td><a href="'.tomgetfileurl($photoInfo['picurl']).'" target="_blank"><img width="40px" src="'.tomgetfileurl($photoInfo['picurl']).'"></a></td>';
            if($value['status'] == 1 ){
                echo '<td><font color="#0a9409">'.$Lang['status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['status_0']. ')</font></a></td>';
            }else{
                echo '<td><font color="#f70404">'.$Lang['status_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['status_1']. ')</font></a></td>';
            }
            echo '<td>' . $value['gsort'] . '</td>';
            echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
            echo '<td>';
            echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
            echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
            echo '</td>';
            echo '</tr>';
            $i++;
        }
        
    }else if($modelInfo['type'] == 2){
        
        echo '<tr class="header">';
        echo '<th> ID </th>';
        echo '<th>' . $Lang['goods_title'] . '</th>';
        echo '<th>' . $Lang['goods_picurl'] . '</th>';
        if($modelInfo['list_template'] == 'template_mall_1' || $modelInfo['list_template'] == 'template_mall_2'){
            echo '<th>' . $Lang['goods_market_price'] . '</th>';
            echo '<th>' . $Lang['goods_buy_price'] . '</th>';
        }
        echo '<th width="150px">' . $Lang['goods_link'] . '</th>';
        echo '<th>' . $Lang['status'] . '</th>';
        echo '<th>' . $Lang['sort'] . '</th>';
        echo '<th>' . $Lang['add_time'] . '</th>';
        echo '<th>' . $Lang['handle'] . '</th>';
        echo '</tr>';

        $i = 1;
        foreach ($goodsList as $key => $value) {

            $photoInfo = C::t('#tom_tctopic#tom_tctopic_photo')->fetch_by(" AND model_goods_id = {$value['id']} AND type = 4 ");

            echo '<tr>';
            echo '<td>' . $value['id'] . '</td>';
            echo '<td>' . $value['title'] . '</td>';
            echo '<td><a href="'.tomgetfileurl($photoInfo['picurl']).'" target="_blank"><img width="40px" src="'.tomgetfileurl($photoInfo['picurl']).'"></a></td>';
            if($modelInfo['list_template'] == 'template_mall_1' || $modelInfo['list_template'] == 'template_mall_2'){
                echo '<td>' . $value['market_price'] . '</td>';
                echo '<td>' . $value['buy_price'] . '</td>';
            }
            echo '<td style="word-break: break-all;">' . $value['link'] . '</td>';
            if($value['status'] == 1 ){
                echo '<td><font color="#0a9409">'.$Lang['status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['status_0']. ')</font></a></td>';
            }else{
                echo '<td><font color="#f70404">'.$Lang['status_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['status_1']. ')</font></a></td>';
            }
            echo '<td>' . $value['gsort'] . '</td>';
            echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
            echo '<td>';
            echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
            echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
            echo '</td>';
            echo '</tr>';
            $i++;
        }
    }
    
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $goods_id       = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
    $sub_title      = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $market_price   = floatval($_GET['market_price'])>0? floatval($_GET['market_price']):0;
    $buy_price      = floatval($_GET['buy_price'])>0? floatval($_GET['buy_price']):0;
    $link           = isset($_GET['link'])? addslashes($_GET['link']):'';
    $status         = intval($_GET['status'])>0? intval($_GET['status']):0;
    $gsort          = intval($_GET['gsort'])>0? intval($_GET['gsort']):100;
    
    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    $goodsInfo = array();
    $goodsInfo['goods_id']       = $goods_id;
    $goodsInfo['title']          = $title;
    $goodsInfo['sub_title']      = $sub_title;
    $goodsInfo['market_price']   = $market_price;
    $goodsInfo['buy_price']      = $buy_price;
    $goodsInfo['link']           = $link;
    $goodsInfo['status']         = $status;
    $goodsInfo['gsort']          = $gsort;
    
    $data['goodsInfo']      = $goodsInfo;
    $data['picurl']         = $picurl;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'goods_id'      => 0,
        'title'         => '',
        'sub_title'     => '',
        'picurl'        => '',
        'market_price'  => 0.00,
        'buy_price'     => 0.00,
        'link'          => '',
        'status'        => 1,
        'gsort'         => 100,
    );
    $options = array_merge($options, $infoArr);
    
    $modelInfo = C::t('#tom_tctopic#tom_tctopic_model')->fetch_by_id($_GET['model_id']);
    
    if(!empty($infoArr)){
        $photoInfo = C::t('#tom_tctopic#tom_tctopic_photo')->fetch_by(" AND model_goods_id = {$infoArr['id']} AND type = 4 ");
        if(is_array($photoInfo) && !empty($photoInfo)){
            $options['picurl'] = $photoInfo['picurl'];
        }
    }
    
    if($modelInfo['type'] == 1){
        
        $goodsTypeName = '';
        if($modelInfo['plugin_id'] == 'qianggou'){
            $goodsTypeName = $Lang['goods_id_qianggou'];
        }else if($modelInfo['plugin_id'] == 'ptuan'){
            $goodsTypeName = $Lang['goods_id_ptuan'];
        }else if($modelInfo['plugin_id'] == 'mall'){
            $goodsTypeName = $Lang['goods_id_mall'];
        }else if($modelInfo['plugin_id'] == 'shop'){
            $goodsTypeName = $Lang['goods_id_shop'];
        }else if($modelInfo['plugin_id'] == 'huodong'){
            $goodsTypeName = $Lang['goods_id_huodong'];
        }
        
        tomshowsetting(true,array('title'=>$goodsTypeName.$Lang['goods_id'],'name'=>'goods_id','value'=>$options['goods_id'],'msg'=>$Lang['goods_id_msg']),"input");
    }
    
    tomshowsetting(true,array('title'=>$goodsTypeName.$Lang['goods_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['goods_title_msg']),"input");
    
    if($modelInfo['type'] == 1 && $modelInfo['plugin_id'] == 'shop'){
        tomshowsetting(true,array('title'=>$Lang['goods_sub_title'],'name'=>'sub_title','value'=>$options['sub_title'],'msg'=>$Lang['goods_sub_title_msg']),"input");
    }
    
    tomshowsetting(true,array('title'=>$Lang['goods_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['goods_picurl_msg']),"file");
    if($modelInfo['type'] == 2){
        if($modelInfo['list_template'] == 'template_mall_1' || $modelInfo['list_template'] == 'template_mall_2'){
            tomshowsetting(true,array('title'=>$Lang['goods_market_price'],'name'=>'market_price','value'=>$options['market_price'],'msg'=>$Lang['goods_market_price_msg']),"input");
            tomshowsetting(true,array('title'=>$Lang['goods_buy_price'],'name'=>'buy_price','value'=>$options['buy_price'],'msg'=>$Lang['goods_buy_price_msg']),"input");
        }
        tomshowsetting(true,array('title'=>$Lang['goods_link'],'name'=>'link','value'=>$options['link'],'msg'=>$Lang['goods_link_msg']),"input");
    }
    $status_item = array(1=>$Lang['status_1'], 0=>$Lang['status_0']);
    tomshowsetting(true,array('title'=>$Lang['status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['status_msg'],'item'=>$status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'gsort','value'=>$options['gsort'],'msg'=>$Lang['sort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['edit'],"",true);
    }else{
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter(); /*Dism_taobao��com*/
}