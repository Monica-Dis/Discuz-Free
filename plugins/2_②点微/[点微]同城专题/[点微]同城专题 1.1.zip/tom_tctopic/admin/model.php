<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=model&tctopic_id='.$_GET['tctopic_id'];
$modListUrl = $adminListUrl.'&tmod=model&tctopic_id='.$_GET['tctopic_id'];
$modFromUrl = $adminFromUrl.'&tmod=model&tctopic_id='.$_GET['tctopic_id'];

$tctopicInfo = C::t("#tom_tctopic#tom_tctopic")->fetch_by_id($_GET['tctopic_id']);

$get_list_url_value = get_list_url("tom_tctopic_admin_model_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['tctopic_id'] = $_GET['tctopic_id'];
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tctopic#tom_tctopic_model')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();/*dism - taobao - com*/
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*DisM �� Taobao �� Com*/
    }
    
}else if($_GET['act'] == 'edit'){

    $modelInfo = C::t('#tom_tctopic#tom_tctopic_model')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        
        $updateData = array();
        $updateData = __get_post_data($modelInfo);
        C::t('#tom_tctopic#tom_tctopic_model')->update($modelInfo['id'],$updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{

        tomloadcalendarjs();
        loadeditorjs();/*dism - taobao - com*/
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($modelInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*DisM �� Taobao �� Com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tctopic#tom_tctopic_model')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tctopic#tom_tctopic_model')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tctopic#tom_tctopic_model')->delete_by_id($_GET['id']);
    
    $modelGoodsIdsListTmp = C::t('#tom_tctopic#tom_tctopic_model_goods')->fetch_all_id(" AND model_id = {$_GET['id']} ");
    $modelGoodsIdsList = array();
    if(is_array($modelGoodsIdsListTmp) && !empty($modelGoodsIdsListTmp)){
        foreach($modelGoodsIdsListTmp as $key => $value){
            $modelGoodsIdsList[] = $value['id'];
        }
        $modelGoodsIdsStr = implode(',', $modelGoodsIdsList);
        C::t('#tom_tctopic#tom_tctopic_photo')->delete_all(" AND model_goods_id IN({$modelGoodsIdsStr}) ");
    }
    C::t('#tom_tctopic#tom_tctopic_model_goods')->delete_by_model_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    set_list_url("tom_tctopic_admin_model_list");
    
    $status     = intval($_GET['status'])>0? intval($_GET['status']):0;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = " AND tctopic_id={$_GET['tctopic_id']} ";
    if(!empty($status)){
        if($status == 1){
            $where.= " AND status=1 ";
        }else if($status == 2){
            $where.= " AND status != 1 ";
        }
    }
    
    $order = "ORDER BY msort ASC, add_time DESC,id DESC";
    
    $pagesize = 20;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tctopic#tom_tctopic_model')->fetch_all_count($where);
    $modelList  = C::t('#tom_tctopic#tom_tctopic_model')->fetch_all_list($where,$order,$start,$pagesize);

    $modBasePageUrl = $modBaseUrl."&status={$status}";
    
    showformheader($modFromUrl."&formhash=".FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $tctopicInfo['title'] .'&nbsp;&gt;&nbsp;'.$Lang['index_model_title'].'</th></tr>';
    //echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
        
    $status_1 = $status_2 = '';
    if($status == 1){
        $status_1 = 'selected';
    }else if($status == 2){
        $status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['status_0'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*DisM �� Taobao �� Com*/
    
    __create_nav_html();
    
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 60px;"> ID </th>';
    echo '<th>' . $Lang['model_title'] . '</th>';
    echo '<th>' . $Lang['model_title_picurl'] . '</th>';
    echo '<th>' . $Lang['model_type'] . '</th>';
    echo '<th>' . $Lang['status'] . '</th>';
    echo '<th>' . $Lang['sort'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($modelList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $tctopInfo = C::t('#tom_tctopic#tom_tctopic')->fetch_by_id($value['tctopic_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $value['title'] . '</td>';
        echo '<td><a href="'.tomgetfileurl($value['title_picurl']).'" target="_blank"><img width="40px" src="'.tomgetfileurl($value['title_picurl']).'"></a></td>';
        if($value['type'] == 1 ){
            if($value['plugin_id'] == 'qianggou'){
                echo '<td><font color="#0a9409">'.$Lang['model_plugin_qg'].'</font></td>';
            }else if($value['plugin_id'] == 'ptuan'){
                echo '<td><font color="#0a9409">'.$Lang['model_plugin_pt'].'</font></td>';
            }else if($value['plugin_id'] == 'mall'){
                echo '<td><font color="#0a9409">'.$Lang['model_plugin_mall'].'</font></td>';
            }else if($value['plugin_id'] == 'shop'){
                echo '<td><font color="#0a9409">'.$Lang['model_plugin_shop'].'</font></td>';
            }else if($value['plugin_id'] == 'huodong'){
                echo '<td><font color="#0a9409">'.$Lang['model_plugin_huodong'].'</font></td>';
            }else{
                echo '<td> -- </td>';
            }
        }else{
            echo '<td><font color="#f70404">'.$Lang['model_type_2'].'</font></td>';
        }
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">'.$Lang['status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['status_0']. ')</font></a></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['status_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['status_1']. ')</font></a></td>';
        }
        echo '<td>' . $value['msort'] . '</td>';
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$adminBaseUrl.'&tmod=goods&model_id='.$value['id'].'&formhash='.FORMHASH.'" target="_blank">' . $Lang['model_goods_title'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    showformfooter(); /*DisM �� Taobao �� Com*/
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $hide_title         = isset($_GET['hide_title'])? intval($_GET['hide_title']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):1;
    $plugin_id          = isset($_GET['plugin_id'])? addslashes($_GET['plugin_id']):'';
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $msort              = isset($_GET['msort'])? intval($_GET['msort']):100;
    
    $title_picurl = "";
    if($_GET['act'] == 'add'){
        $title_picurl          = tomuploadFile("title_picurl");
    }else if($_GET['act'] == 'edit'){
        $title_picurl          = tomuploadFile("title_picurl",$infoArr['title_picurl']);
    }
    
    $data['title']              = $title;
    $data['title_picurl']       = $title_picurl;
    $data['hide_title']         = $hide_title;
    $data['type']               = $type;
    $data['plugin_id']          = $plugin_id;
    $data['status']             = $status;
    $data['msort']              = $msort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'title'             => '',
        'title_picurl'      => '',
        'hide_title'        => 0,
        'type'              => 1,
        'plugin_id'         => '',
        'status'            => 1,
        'msort'             => 100,
    );
    
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['model_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['model_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['model_title_picurl'],'name'=>'title_picurl','value'=>$options['title_picurl'],'msg'=>$Lang['model_title_picurl_msg']),"file");
    $type_item = array(1=>$Lang['model_type_1'], 2=>$Lang['model_type_2']);
    tomshowsetting(true,array('title'=>$Lang['model_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['type_msg'],'item'=>$type_item),"radio");
    $plugin_item = array('qianggou'=>$Lang['model_plugin_qg'], 'ptuan'=>$Lang['model_plugin_pt'], 'mall'=>$Lang['model_plugin_mall'], 'shop'=>$Lang['model_plugin_shop'], 'huodong'=>$Lang['model_plugin_huodong']);
    tomshowsetting(true,array('title'=>$Lang['model_plugin'],'name'=>'plugin_id','value'=>$options['plugin_id'],'msg'=>$Lang['model_plugin_msg'],'item'=>$plugin_item,'width'=>450),"radio");
    $hide_title_item = array(0=>$Lang['model_hide_title_0'], 1=>$Lang['model_hide_title_1']);
    tomshowsetting(true,array('title'=>$Lang['model_hide_title'],'name'=>'hide_title','value'=>$options['hide_title'],'msg'=>$Lang['model_hide_title_msg'],'item'=>$hide_title_item),"radio");
    $status_item = array(1=>$Lang['status_1'], 0=>$Lang['status_0']);
    tomshowsetting(true,array('title'=>$Lang['status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['status_msg'],'item'=>$status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'msort','value'=>$options['msort'],'msg'=>$Lang['sort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['model_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['model_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['model_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['model_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['edit'],"",true);
    }else{
        tomshownavli($Lang['model_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['model_add'],$modBaseUrl.'&act=add',false);
    }
    
    tomshownavfooter(); /*Dism_taobao��com*/
}