<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$page               = intval($_GET['page'])>0? intval($_GET['page']):0;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND status=1 AND is_list_show = 1 ';
if(!empty($sql_in_site_ids)){
    $whereStr .= " AND site_id IN({$sql_in_site_ids}) ";
}

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
$tctopicList = array();
$tctopicListTmp = C::t('#tom_tctopic#tom_tctopic')->fetch_all_list($whereStr, "ORDER BY tsort ASC,id DESC", $start, $pagesize);
if(is_array($tctopicListTmp) && !empty($tctopicListTmp)){
    foreach ($tctopicListTmp as $key => $value) {
        $tctopicList[$key] = $value;
        
        $photoInfoTmp = C::t("#tom_tctopic#tom_tctopic_photo")->fetch_by("AND tctopic_id = {$value['id']} AND type = 2 ");
        $picurlTmp = '';
        if(!empty($photoInfoTmp['picurl'])){
            if(!preg_match('/^http/', $photoInfoTmp['picurl']) ){
                if(strpos($photoInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$photoInfoTmp['picurl'];
                }else{
                    $picurlTmp = $_G['siteurl'].$photoInfoTmp['picurl'];
                }
            }else{
                $picurlTmp = $photoInfoTmp['picurl'];
            }
        }

        $tctopicList[$key]['picurl'] = $picurlTmp;
    }
}

if(is_array($tctopicList) && !empty($tctopicList)){
    foreach($tctopicList as $key => $val){
        $outStr .= '<a class="topic-list__item" href="plugin.php?id=tom_tctopic&site='.$site_id.'&mod=info&tctopic_id='.$val['id'].'">';
            $outStr .= '<img src="'.$val['picurl'].'">';
        $outStr .= '</a>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;