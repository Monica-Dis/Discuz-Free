<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tctopic`;
CREATE TABLE `pre_tom_tctopic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `bg_color` varchar(255) DEFAULT NULL,
  `theme_color` varchar(255) DEFAULT NULL,
  `start_time` int(10) unsigned DEFAULT '0',
  `end_time` int(11) unsigned DEFAULT '0',
  `huodong_guize` text,
  `haibao_picurl` varchar(255) DEFAULT NULL,
  `haibao_qrcode_location` tinyint(4) DEFAULT '0',
  `kefu_qrcode` varchar(255) DEFAULT NULL,
  `music_url` varchar(255) DEFAULT NULL,
  `open_model_nav` tinyint(4) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `virtual_clicks` int(11) DEFAULT '0',
  `is_list_show` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `tsort` int(11) DEFAULT '100',
  `share_title` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `share_pic` varchar(255) DEFAULT NULL,
  `update_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_is_list_show` (`is_list_show`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctopic_guanggao`;
CREATE TABLE `pre_tom_tctopic_guanggao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tctopic_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `link` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `gsort` int(11) DEFAULT '10',
  `update_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tctopic_id` (`tctopic_id`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctopic_model`;
CREATE TABLE `pre_tom_tctopic_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tctopic_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `title_picurl` varchar(255) DEFAULT NULL,
  `hide_title` tinyint(4) DEFAULT '0',
  `type` tinyint(11) DEFAULT '0',
  `plugin_id` varchar(255) DEFAULT NULL,
  `index_show_num` int(11) DEFAULT '0',
  `list_template` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `msort` int(11) DEFAULT '100',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tctopic_id` (`tctopic_id`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctopic_model_goods`;
CREATE TABLE `pre_tom_tctopic_model_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tctopic_id` int(11) DEFAULT '0',
  `model_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `market_price` decimal(10,2) DEFAULT '0.00',
  `buy_price` decimal(10,2) DEFAULT '0.00',
  `link` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `gsort` int(11) DEFAULT '100',
  `update_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tctopic_id` (`tctopic_id`),
  KEY `idx_model_id` (`model_id`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctopic_nav`;
CREATE TABLE `pre_tom_tctopic_nav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tctopic_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `select` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `nsort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tctopic_id` (`tctopic_id`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tctopic_photo`;
CREATE TABLE `pre_tom_tctopic_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tctopic_id` int(11) DEFAULT '0',
  `model_goods_id` int(11) DEFAULT '0',
  `guanggao_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `oss_picurl` varchar(255) DEFAULT NULL,
  `oss_status` tinyint(4) DEFAULT '0',
  `qiniu_picurl` varchar(255) DEFAULT NULL,
  `qiniu_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tctopic_id` (`tctopic_id`),
  KEY `idx_type` (`type`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;