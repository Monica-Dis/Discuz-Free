<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);
$tctopicConfig      = $_G['cache']['plugin']['tom_tctopic'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';

if('utf-8' != CHARSET) {
    if(defined('IN_MOBILE')) {}else{
        foreach($_POST AS $pk => $pv) {
            if(!is_numeric($pv)) {
                $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
            }
        }
    }
}

$share_url  = isset($_GET['share_url'])? daddslashes($_GET['share_url']):'';
$tctopic_id = isset($_GET['tctopic_id'])? intval($_GET['tctopic_id']):0;
$user_id    = isset($_GET['user_id'])? intval($_GET['user_id']):0;

$tctopicInfo = C::t('#tom_tctopic#tom_tctopic')->fetch_by_id($tctopic_id);
$userInfo  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
    include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
}else{
    echo 'QR|phpqrcode';exit;
}

$share_pic = '';
if(!preg_match('/^http/', $tctopicInfo['share_pic']) ){
    if(strpos($tctopicInfo['share_pic'], 'source/plugin/tom_') === FALSE){
        $share_pic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tctopicInfo['share_pic'];
        if(strpos($share_pic, $_G['siteurl']) !== false){
            $share_pic = str_replace($_G['siteurl'], "", $share_pic);
            $share_pic = DISCUZ_ROOT.$share_pic;
        }
    }else{
        $share_pic = DISCUZ_ROOT.$tctopicInfo['share_pic'];
    }
}else{
    $share_pic = $tctopicInfo['share_pic'];
}

$haibao_picurl = '';
if(!preg_match('/^http/', $tctopicInfo['haibao_picurl']) ){
    if(strpos($tctopicInfo['haibao_picurl'], 'source/plugin/tom_') === FALSE){
        $haibao_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tctopicInfo['haibao_picurl'];
        if(strpos($haibao_picurl, $_G['siteurl']) !== false){
            $haibao_picurl = str_replace($_G['siteurl'], "", $haibao_picurl);
            $haibao_picurl = DISCUZ_ROOT.$haibao_picurl;
        }
    }else{
        $haibao_picurl = DISCUZ_ROOT.$tctopicInfo['haibao_picurl'];
    }
}else{
    $haibao_picurl = $tctopicInfo['haibao_picurl'];
}

if(strpos($userInfo['picurl'], 'data/attachment/tomwx') !== false){
    $userpic  = $_G['siteurl'].$userInfo['picurl'];
}else if(strpos($userInfo['picurl'], 'uc_server/') !== false){
    $userpic  = $_G['siteurl'].$userInfo['picurl'];
}else{
    $userpic  = $userInfo['picurl'];
}

$sharePicImg = DISCUZ_ROOT.'./source/plugin/tom_tctopic/data/haibao/'.md5($share_pic).'_sharepic.png';
$sharePicUrl = 'source/plugin/tom_tctopic/data/haibao/'.md5($share_pic).'_sharepic.png';

$haibaoPicurlImg = DISCUZ_ROOT.'./source/plugin/tom_tctopic/data/haibao/'.md5($haibao_picurl).'_haibao_picurl.png';
$haibaoPicurlUrl = 'source/plugin/tom_tctopic/data/haibao/'.md5($haibao_picurl).'_haibao_picurl.png';

$qrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tctopic/data/haibao/'.md5($share_url).'_qrcode.png';
$qrcodeUrl = 'source/plugin/tom_tctopic/data/haibao/'.md5($share_url).'_qrcode.png';

$wxqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tctopic/data/haibao/'.md5($share_url).'_wxqrcode'.date("Ymd").'.png';
$wxqrcodeUrl = 'source/plugin/tom_tctopic/data/haibao/'.md5($share_url).'_wxqrcode'.date("Ymd").'.png';

$userpicImg = DISCUZ_ROOT.'./source/plugin/tom_tctopic/data/haibao/'.md5($userpic).'_userpic.png';
$userpicUrl = 'source/plugin/tom_tctopic/data/haibao/'.md5($userpic).'_userpic.png';

$tempDir = "/source/plugin/tom_tctopic/data/haibao/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0755); 
}

if(file_exists($sharePicImg)){
}else{
    $top_pic_content = file_get_contents($share_pic);
    
    if(false === file_put_contents($sharePicImg,$top_pic_content)){
        $sharePicImg = $share_pic;
    }
}

if(file_exists($haibaoPicurlImg)){
}else{
    $haibao_picurl_pic_content = file_get_contents($haibao_picurl);
    if(false === file_put_contents($haibaoPicurlImg,$haibao_picurl_pic_content)){
        $haibaoPicurlImg = $haibao_picurl;
    }
}

if(file_exists($userpicImg)){
}else{
    $user_pic_content = file_get_contents($userpic);
    if(false === file_put_contents($userpicImg,$user_pic_content)){
        $userpicImg = $userpic;
    }
}

$outQrcodeUrl = '';
if($tctopicConfig['open_wxqrcode'] == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_weixin/tom_weixin.inc.php')){
    
    $qrcodeKey  = md5($share_url);
    $qrcodeInfo = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_by_qkey($qrcodeKey);
    $qrcodeId = 0;
    if($qrcodeInfo){
        $qrcodeId = $qrcodeInfo['id'];
        $updateData = array();
        $updateData['title']  = $tctopicInfo['share_title'];
        $updateData['picurl'] = $_G['siteurl'].$sharePicUrl;
        $updateData['desc']   = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        $updateData['link']   = $share_url;
        C::t('#tom_weixin#tom_weixin_qrcode')->update($qrcodeId,$updateData);
    }else{
        
        $qrcodeList = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_all_list(" ","ORDER BY id DESC",0,1);
        $qrcodeId = 100001;
        if(is_array($qrcodeList) && !empty($qrcodeList) && isset($qrcodeList['0']) && $qrcodeList['0']['id']>100000){
            $qrcodeId = $qrcodeList['0']['id']+1;
        }
        
        $insertData = array();
        $insertData['id']       = $qrcodeId;
        $insertData['qkey']     = $qrcodeKey;
        $insertData['title']    = $tctopicInfo['share_title'];
        $insertData['picurl']   = $_G['siteurl'].$sharePicUrl;
        $insertData['desc']     = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        $insertData['link']     = $share_url;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_weixin#tom_weixin_qrcode')->insert($insertData);
        $qrcodeId = C::t('#tom_weixin#tom_weixin_qrcode')->insert_id();
    }
    
    if(file_exists($wxqrcodeImg)){
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        $access_token = $weixinClass->get_access_token();

        $dateStr = '{"expire_seconds": 2592000, "action_name": "QR_SCENE", "action_info": {"scene": {"scene_id": '.$qrcodeId.'}}}';
        $response   = tom_html_post($dateStr, 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token);
        $returnData = json_decode($response,true);
        if(isset($returnData['ticket']) &&  !empty($returnData['ticket'])){
            $wx_pic_content = tom_html_get('https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$returnData['ticket']);
            if(false === file_put_contents($wxqrcodeImg,$wx_pic_content)){
            }
        }
    }
    
    $outQrcodeUrl = $wxqrcodeUrl;
}else{
    
    if(file_exists($qrcodeImg)){
    }else{
        QRcode::png($share_url,$qrcodeImg,'H',5,2);
    }
    $outQrcodeUrl = $qrcodeUrl;
}

echo 'OK|'.$haibaoPicurlUrl.'|'.$outQrcodeUrl.'|'.$userpicUrl;exit;

function wx_iconv_recurrence($value) {
	if(is_array($value)) {
		foreach($value AS $key => $val) {
			$value[$key] = wx_iconv_recurrence($val);
		}
	} else {
		$value = diconv($value, 'utf-8', CHARSET);
	}
	return $value;
}