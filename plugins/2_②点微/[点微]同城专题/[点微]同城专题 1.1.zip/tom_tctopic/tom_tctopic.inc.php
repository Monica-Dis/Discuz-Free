<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tctopicConfig = $_G['cache']['plugin']['tom_tctopic'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = "201911151";

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){}else{
    echo " no install https://dism.taobao.com/?@tom_tongcheng.plugin";exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/nofind.php';

$wxJssdkConfig = array();
$wxJssdkConfig["appId"]     = "";
$wxJssdkConfig["timestamp"] = time();
$wxJssdkConfig["nonceStr"]  = "";
$wxJssdkConfig["signature"] = "";
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tctopicConfig['wx_share_title'];
$shareDesc  = $tctopicConfig['wx_share_desc'];
$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tctopic&site={$site_id}&mod=index";
$shareLogo  = $tctopicConfig['wx_share_pic'];

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesinfo.php';

## tcadmin start
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
## tcadmin end
## tcqianggou start
$__ShowTcqianggou = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
    $tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
    if($tcqianggouConfig['open_tcqianggou'] == 1){
        $__ShowTcqianggou = 1;
    }
}
## tcqianggou end
## tcptuan start
$__ShowTcptuan = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcptuan/tom_tcptuan.inc.php')){
    $tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
    if($tcptuanConfig['open_tcptuan'] == 1){
        $__ShowTcptuan = 1;
    }
}
## tcptuan end
## tcmall start
$__ShowTcmall = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcmall/tom_tcmall.inc.php')){
    $tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
    if($tcmallConfig['open_tcmall'] == 1){
        $__ShowTcmall = 1;
    }
}
## tcmall end
## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tchuodong start
$__ShowTchuodong = 0;
$tchuodongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchuodong/tom_tchuodong.inc.php')){
    $tchuodongConfig = $_G['cache']['plugin']['tom_tchuodong'];
    if($tchuodongConfig['open_tchuodong'] == 1){
        $__ShowTchuodong = 1;
    }
}
## tchuodong end
## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login.php';

$__TjHehuorenId = intval($_GET['tj_hehuoren_id'])>0 ? intval($_GET['tj_hehuoren_id']):0;
$tj_hehuoren_id = $__TjHehuorenId;
if($__ShowTchehuoren == 1){
    
    if($__UserInfo['id'] > 0){
        $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
        if($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1){
            $__TjHehuorenId = $tchehuorenInfoTmp['id'];
            $shareUrl = $shareUrl."&tjid={$__TjHehuorenId}";
        }
    }
    
    if($__TjHehuorenId == 0){
        $cookiesTjHehuorenId = getcookie('tom_tctopic_tj_hehuoren_id');
        if($cookiesTjHehuorenId > 0){
            $__TjHehuorenId = $cookiesTjHehuorenId;
        }
    }
    
    if($__TjHehuorenId > 0){
        dsetcookie('tom_tctopic_tj_hehuoren_id', $__TjHehuorenId, 86400);
    }
}

/********************* index ***********************/
if($_GET['mod'] == 'index'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';
    
    $md5HostUrl = md5($_G['siteurl']."plugin.php?id=tom_tctopic&site={$site_id}&mod=index");
    
    $ajaxListUrl = "plugin.php?id=tom_tctopic:ajax&site={$site_id}&act=list&formhash=".$formhash;
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tctopic:index");
    
    
/********************* info ***********************/
}else if($_GET['mod'] == 'info'){
    
    $tctopic_id = intval($_GET['tctopic_id'])>0 ? intval($_GET['tctopic_id']):0;
    
    $tctopicInfo = C::t("#tom_tctopic#tom_tctopic")->fetch_by_id($tctopic_id);
    if($tctopicInfo['id'] > 0){
        if($tctopicInfo['status'] != 1){
            if((isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1) || $tongchengConfig['manage_user_id'] == $__UserInfo['id']){ }else{
                tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctopic&site={$site_id}&mod=index");exit;
            }
        }
    }else{
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctopic&site={$site_id}&mod=index");exit;
    }
    
    $photoListTmp = C::t("#tom_tctopic#tom_tctopic_photo")->fetch_all_list("AND tctopic_id = {$tctopicInfo['id']} AND type IN(1,3) ", 'ORDER BY id DESC', 0, 2);
    $topPicurl = $bgPicurl = '';
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach($photoListTmp as $key => $value){
            if($value['type'] == 1){
                $bgPicurl = $value['picurlTmp'];
            }else if($value['type'] == 3){
                $topPicurl = $value['picurlTmp'];
            }
        }
    }
    
    $syTime = ($tctopicInfo['end_time'] - TIMESTAMP)*1000;
    
    $guanggaoListTmp = C::t("#tom_tctopic#tom_tctopic_guanggao")->fetch_all_list("AND tctopic_id = {$tctopicInfo['id']} AND status = 1 ", 'ORDER BY gsort ASC, id DESC');
    $guanggao1List = $guanggao2List = array();
    if(is_array($guanggaoListTmp) && !empty($guanggaoListTmp)){
        foreach($guanggaoListTmp as $key => $value){
            $linkTmp = str_replace("{site}",$site_id, $value['link']);
            
            $photoInfoTmp = C::t("#tom_tctopic#tom_tctopic_photo")->fetch_all_list("AND guanggao_id = {$value['id']} AND type = 5 ", 'ORDER BY id DESC', 0, 1);
            $picurlTmp = '';
            if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
                $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
            }
            if($value['type'] == 1){
                $guanggao1List[$key] = $value;
                $guanggao1List[$key]['link'] = $linkTmp;
                $guanggao1List[$key]['picurl'] = $picurlTmp;
            }else if($value['type'] == 2){
                $guanggao2List[$key] = $value;
                $guanggao2List[$key]['link'] = $linkTmp;
                $guanggao2List[$key]['picurl'] = $picurlTmp;
            }
        }
    }
    $guanggaoCount = count($guanggao1List) + count($guanggao2List);
    
    $modelListTmp = C::t("#tom_tctopic#tom_tctopic_model")->fetch_all_list("AND tctopic_id = {$tctopicInfo['id']} AND status = 1 ", 'ORDER BY msort ASC, id DESC');
    $modelList = array();
    if(is_array($modelListTmp) && !empty($modelListTmp)){
        foreach($modelListTmp as $key => $value){
            $goodsCountTmp = C::t("#tom_tctopic#tom_tctopic_model_goods")->fetch_all_count("AND model_id = {$value['id']} AND status = 1 ");
            $goodsListTmpTmp = C::t("#tom_tctopic#tom_tctopic_model_goods")->fetch_all_list("AND model_id = {$value['id']} AND status = 1 ", 'ORDER BY gsort ASC, id DESC', 0, $value['index_show_num']);
            $goodsListTmp = array();
            if(is_array($goodsListTmpTmp) && !empty($goodsListTmpTmp)){
                foreach($goodsListTmpTmp as $k => $v){
                    $goodsListTmp[$k] = $v;
                    
                    $titleTmp = $picurlTmp = '';
                    if($value['type'] == 1){
                        $goodsInfo = array();
                        if($value['plugin_id'] == 'qianggou' && $__ShowTcqianggou == 1){
                            
                            $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($v['goods_id']);
                            if($goodsInfoTmp['status'] == 1 && $goodsInfoTmp['shenhe_status'] == 1 && $goodsInfoTmp['type_id'] == 1 ){
                                $goodsInfo = $goodsInfoTmp;
                                $picurlTmp = $goodsInfoTmp['picurl'];
                                $titleTmp = $goodsInfoTmp['title'];
                                if($goodsInfo['open_xubuy'] == 1){
                                    $qiangListCountTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(" AND goods_id={$goodsInfo['id']} AND type_id=2 ");
                                    $goodsInfo['sale_num'] = $goodsInfo['sale_num'] + $qiangListCountTmp;
                                }
                                
                                if(floatval($goodsInfo['show_buy_price']) <= 0){
                                    $goodsInfo['show_buy_price']    = $goodsInfo['buy_price'];
                                    $goodsInfo['show_market_price'] = $goodsInfo['market_price'];
                                }
                                $goodsInfo['show_buy_price'] = floatval($goodsInfo['show_buy_price']);
                                $goodsInfo['show_market_price'] = floatval($goodsInfo['show_market_price']);
                                
                            }
                            
                        }else if($value['plugin_id'] == 'ptuan' && $__ShowTcptuan == 1){
                            
                            $goodsInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($v['goods_id']);
                            if($goodsInfoTmp['status'] == 1 && $goodsInfoTmp['shenhe_status'] == 1){
                                $goodsInfo = $goodsInfoTmp;
                                $goodsInfo['show_market_price'] = floatval($goodsInfo['show_market_price']);
                                $goodsInfo['show_tuan_price'] = floatval($goodsInfo['show_tuan_price']);
                                
                                $picurlTmp = $goodsInfoTmp['toppic'];
                                $titleTmp = $goodsInfoTmp['name'];
                            }
                            
                        }else if($value['plugin_id'] == 'mall' && $__ShowTcmall == 1){
                            
                            $goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($v['goods_id']);
                            if($goodsInfoTmp['status'] == 1 && $goodsInfoTmp['shenhe_status'] == 1){
                                $goodsInfo = $goodsInfoTmp;
                                $goodsInfo['sales'] = $goodsInfo['virtual_sales'] + $goodsInfo['sales'];
                                $goodsInfo['show_buy_price'] = floatval($goodsInfo['show_buy_price']);
                                $goodsInfo['show_market_price'] = floatval($goodsInfo['show_market_price']);
                                
                                $picurlTmp = $goodsInfoTmp['picurl'];
                                $titleTmp = $goodsInfoTmp['title'];
                            }
                            
                        }else if($value['plugin_id'] == 'shop' && $__ShowTcshop == 1){
                            
                            $tcshopInfoTmp  = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($v['goods_id']);
                            if($tcshopInfoTmp['status'] == 1 && $tcshopInfoTmp['shenhe_status'] == 1){
                                $goodsInfo = $tcshopInfoTmp;
                                $picurlTmp = $tcshopInfoTmp['picurl'];
                                $titleTmp = $tcshopInfoTmp['name'];
                                
                                $avatarInfoTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(" AND tcshop_id={$v['goods_id']} AND type_id = 4 ","ORDER BY id ASC",0,1);
                                if(is_array($avatarInfoTmp) && !empty($avatarInfoTmp)){
                                    if($tongchengConfig['open_yun'] == 2 && !empty($avatarInfoTmp[0]['oss_picurl']) && $avatarInfoTmp[0]['oss_status'] == 1){
                                        $picurlTmp = $avatarInfoTmp[0]['oss_picurl'];
                                    }else if($tongchengConfig['open_yun'] == 3 && !empty($avatarInfoTmp[0]['qiniu_picurl'])  && $avatarInfoTmp[0]['qiniu_status'] == 1){
                                        $picurlTmp = $avatarInfoTmp[0]['qiniu_picurl'];
                                    }
                                }
                            }
                            
                        }else if($value['plugin_id'] == 'huodong' && $__ShowTchuodong == 1){
                            
                            $huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($v['goods_id']);
                            if($huodongInfoTmp['status'] == 1 && $huodongInfoTmp['shenhe_status'] == 1){
                                $goodsInfo = $huodongInfoTmp;
                                $picurlTmp = $huodongInfoTmp['picurl'];
                                $titleTmp = $huodongInfoTmp['title'];
                                $goodsInfo['bm_num']  = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_sun_bm_num(" AND tchuodong_id = {$goodsInfo['id']} AND order_status IN(2,3)");
                                if($goodsInfo['open_xubuy'] == 1){
                                    $xubmListCountTmp  = C::t('#tom_tchuodong#tom_tchuodong_xubuy')->fetch_all_count(" AND tchuodong_id={$goodsInfo['id']} AND type_id=2 ");
                                    $goodsInfo['bm_num'] = $goodsInfo['bm_num'] + $xubmListCountTmp;
                                }
                                $goodsInfo['hd_start_time']   = dgmdate($goodsInfo['hd_start_time'], 'Y.m.d',$tomSysOffset);
                                $goodsInfo['hd_end_time']     = dgmdate($goodsInfo['hd_end_time'], 'm.d',$tomSysOffset);
                                
                            }
                            
                        }
                    }
                    
                    $photoInfoTmp = C::t("#tom_tctopic#tom_tctopic_photo")->fetch_all_list("AND model_goods_id = {$v['id']} AND type = 4 ", 'ORDER BY id DESC', 0, 1);
                    if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
                        $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
                    }
                    
                    if(!empty($v['title'])){
                        $titleTmp = $v['title'];
                    }
                    
                    if(!preg_match('/^http/', $picurlTmp) ){
                        if(strpos($picurlTmp, 'source/plugin/tom_') === false){
                            $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$picurlTmp;
                        }else{
                            $picurlTmp = $_G['siteurl'].$picurlTmp;
                        }
                    }else{
                        $picurlTmp = $picurlTmp;
                    }
                    
                    $goodsListTmp[$k]['goodsInfo'] = $goodsInfo;
                    $goodsListTmp[$k]['picurl'] = $picurlTmp;
                    $goodsListTmp[$k]['title'] = $titleTmp;
                    $goodsListTmp[$k]['link'] = str_replace("{site}",$site_id, $v['link']);
                    
                }
            }
            
            $goodsCount = count($goodsListTmp);
            if($goodsCount > 0){
                
                if(!preg_match('/^http/', $value['title_picurl']) ){
                    if(strpos($value['title_picurl'], 'source/plugin/tom_') === false){
                        $titlePicurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['title_picurl'];
                    }else{
                        $titlePicurlTmp = $_G['siteurl'].$value['title_picurl'];
                    }
                }else{
                    $titlePicurlTmp = $value['title_picurl'];
                }
                
                $modelList[$key] = $value;
                $modelList[$key]['goodsList'] = $goodsListTmp;
                $modelList[$key]['goodsCount'] = $goodsCountTmp;
                $modelList[$key]['title_picurl'] = $titlePicurlTmp;
            }
        }
    }
    
    $navListTmp = C::t("#tom_tctopic#tom_tctopic_nav")->fetch_all_list("AND tctopic_id = {$tctopicInfo['id']} AND status = 1 ", 'ORDER BY nsort ASC, id DESC', 0, 5);
    $navList = array();
    if(is_array($navListTmp) && !empty($navListTmp)){
        foreach($navListTmp as $key => $value){
            $navList[$key] = $value;
            
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === false){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurlTmp = $_G['siteurl'].$value['picurl'];
                }
            }else{
                $picurlTmp = $value['picurl'];
            }
            $navList[$key]['picurl'] = $picurlTmp;
            $navList[$key]['link'] = str_replace("{site}",$site_id, $value['link']);
        }
    }
    $navCount = count($navList);
    
    if(!preg_match('/^http/', $tctopicInfo['share_pic']) ){
        if(strpos($tctopicInfo['share_pic'], 'source/plugin/tom_') === false){
            $shareLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tctopicInfo['share_pic'];
        }else{
            $shareLogo = $_G['siteurl'].$tctopicInfo['share_pic'];
        }
    }else{
        $shareLogo = $tctopicInfo['share_pic'];
    }
    $shareTitle = $tctopicInfo['share_title'];
    $shareDesc = $tctopicInfo['share_desc'];
    $shareUrl = $_G['siteurl']."plugin.php?id=tom_tctopic&site={$site_id}&mod=info&tctopic_id={$tctopicInfo['id']}&tj_hehuoren_id={$__TjHehuorenId}";
    
    if(!preg_match('/^http/', $tctopicInfo['haibao_picurl']) ){
        if(strpos($tctopicInfo['haibao_picurl'], 'source/plugin/tom_') === FALSE){
            $haibao_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tctopicInfo['haibao_picurl'];
        }else{
            $haibao_picurl = $tctopicInfo['haibao_picurl'];
        }
    }else{
        $haibao_picurl = $tctopicInfo['haibao_picurl'];
    }
    
    if(!preg_match('/^http/', $tctopicInfo['kefu_qrcode']) ){
        if(strpos($tctopicInfo['kefu_qrcode'], 'source/plugin/tom_') === FALSE){
            $kefu_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tctopicInfo['kefu_qrcode'];
        }else{
            $kefu_qrcode = $tctopicInfo['kefu_qrcode'];
        }
    }else{
        $kefu_qrcode = $tctopicInfo['kefu_qrcode'];
    }
    
    $haibaoQrcodeImg = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($shareUrl);
    
    $ajaxTuiDoTzUrl = '';
    if($__ShowTchehuoren == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tui_do.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tui_do.php';
    }
    
    $ajaxClicksUrl = "plugin.php?id=tom_tctopic:ajax&site={$site_id}&act=clicks&tctopic_id={$tctopicInfo['id']}&formhash=".$formhash;
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tctopic:info");
    
    
    
}else if($_GET['mod'] == 'goodslist'){
    
    $s          = intval($_GET['s']) > 0 ? intval($_GET['s']):0;
    $model_id   = intval($_GET['model_id']) > 0 ? intval($_GET['model_id']):0;
    
    $modelInfo = C::t("#tom_tctopic#tom_tctopic_model")->fetch_by_id($model_id);
    if(!empty($modelInfo) && $modelInfo['status'] == 1){ }else{
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctopic&site={$site_id}&mod=index");exit;
    }
    $tctopicInfo = C::t("#tom_tctopic#tom_tctopic")->fetch_by_id($modelInfo['tctopic_id']);
    if($tctopicInfo['id'] > 0){ }else{
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctopic&site={$site_id}&mod=index");exit;
    }
    
    $goodsListTmp = C::t("#tom_tctopic#tom_tctopic_model_goods")->fetch_all_list("AND model_id = {$model_id} AND status = 1 ", 'ORDER BY gsort ASC, id DESC', 0, 100);
    $goodsList = array();
    if(is_array($goodsListTmp) && !empty($goodsListTmp)){
        foreach($goodsListTmp as $k => $v){
            $goodsList[$k] = $v;

            $titleTmp = $picurlTmp = '';
            if($modelInfo['type'] == 1){
                $goodsInfo = array();
                if($modelInfo['plugin_id'] == 'qianggou' && $__ShowTcqianggou == 1){

                    $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($v['goods_id']);
                    if($goodsInfoTmp['status'] == 1 && $goodsInfoTmp['shenhe_status'] == 1 && $goodsInfoTmp['type_id'] == 1 ){
                        $goodsInfo = $goodsInfoTmp;
                        $picurlTmp = $goodsInfoTmp['picurl'];
                        $titleTmp = $goodsInfoTmp['title'];
                        if($goodsInfo['open_xubuy'] == 1){
                            $qiangListCountTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(" AND goods_id={$goodsInfo['id']} AND type_id=2 ");
                            $goodsInfo['sale_num'] = $goodsInfo['sale_num'] + $qiangListCountTmp;
                        }

                        if(floatval($goodsInfo['show_buy_price']) <= 0){
                            $goodsInfo['show_buy_price']    = $goodsInfo['buy_price'];
                            $goodsInfo['show_market_price'] = $goodsInfo['market_price'];
                        }
                        $goodsInfo['show_buy_price'] = floatval($goodsInfo['show_buy_price']);
                        $goodsInfo['show_market_price'] = floatval($goodsInfo['show_market_price']);

                    }

                }else if($modelInfo['plugin_id'] == 'ptuan' && $__ShowTcptuan == 1){

                    $goodsInfoTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_by_id($v['goods_id']);
                    if($goodsInfoTmp['status'] == 1 && $goodsInfoTmp['shenhe_status'] == 1){
                        $goodsInfo = $goodsInfoTmp;
                        $goodsInfo['show_market_price'] = floatval($goodsInfo['show_market_price']);
                        $goodsInfo['show_tuan_price'] = floatval($goodsInfo['show_tuan_price']);

                        $picurlTmp = $goodsInfoTmp['toppic'];
                        $titleTmp = $goodsInfoTmp['name'];
                    }

                }else if($modelInfo['plugin_id'] == 'mall' && $__ShowTcmall == 1){

                    $goodsInfoTmp = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_by_id($v['goods_id']);
                    if($goodsInfoTmp['status'] == 1 && $goodsInfoTmp['shenhe_status'] == 1){
                        $goodsInfo = $goodsInfoTmp;
                        $goodsInfo['sales'] = $goodsInfo['virtual_sales'] + $goodsInfo['sales'];
                        $goodsInfo['show_buy_price'] = floatval($goodsInfo['show_buy_price']);
                        $goodsInfo['show_market_price'] = floatval($goodsInfo['show_market_price']);

                        $picurlTmp = $goodsInfoTmp['picurl'];
                        $titleTmp = $goodsInfoTmp['title'];
                    }

                }else if($modelInfo['plugin_id'] == 'shop' && $__ShowTcshop == 1){

                    $tcshopInfoTmp  = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($v['goods_id']);
                    if($tcshopInfoTmp['status'] == 1 && $tcshopInfoTmp['shenhe_status'] == 1){
                        $goodsInfo = $tcshopInfoTmp;
                        $picurlTmp = $goodsInfoTmp['picurl'];
                        $titleTmp = $tcshopInfoTmp['name'];

                        $avatarInfoTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(" AND tcshop_id={$v['goods_id']} AND type_id = 4 ","ORDER BY id ASC",0,1);
                        if(is_array($avatarInfoTmp) && !empty($avatarInfoTmp)){
                            if($tongchengConfig['open_yun'] == 2 && !empty($avatarInfoTmp[0]['oss_picurl']) && $avatarInfoTmp[0]['oss_status'] == 1){
                                $picurlTmp = $avatarInfoTmp[0]['oss_picurl'];
                            }else if($tongchengConfig['open_yun'] == 3 && !empty($avatarInfoTmp[0]['qiniu_picurl'])  && $avatarInfoTmp[0]['qiniu_status'] == 1){
                                $picurlTmp = $avatarInfoTmp[0]['qiniu_picurl'];
                            }
                        }

                    }

                }else if($modelInfo['plugin_id'] == 'huodong' && $__ShowTchuodong == 1){
                            
                    $huodongInfoTmp = C::t('#tom_tchuodong#tom_tchuodong')->fetch_by_id($v['goods_id']);
                    if($huodongInfoTmp['status'] == 1 && $huodongInfoTmp['shenhe_status'] == 1){
                        $goodsInfo = $huodongInfoTmp;
                        $picurlTmp = $huodongInfoTmp['picurl'];
                        $titleTmp = $huodongInfoTmp['title'];
                        $goodsInfo['bm_num']  = C::t('#tom_tchuodong#tom_tchuodong_order')->fetch_all_sun_bm_num(" AND tchuodong_id = {$goodsInfo['id']} AND order_status IN(2,3)");
                        if($goodsInfo['open_xubuy'] == 1){
                            $xubmListCountTmp  = C::t('#tom_tchuodong#tom_tchuodong_xubuy')->fetch_all_count(" AND tchuodong_id={$goodsInfo['id']} AND type_id=2 ");
                            $goodsInfo['bm_num'] = $goodsInfo['bm_num'] + $xubmListCountTmp;
                        }
                        $goodsInfo['hd_start_time']   = dgmdate($goodsInfo['hd_start_time'], 'Y.m.d',$tomSysOffset);
                        $goodsInfo['hd_end_time']     = dgmdate($goodsInfo['hd_end_time'], 'm.d',$tomSysOffset);

                    }

                }
            }

            $photoInfoTmp = C::t("#tom_tctopic#tom_tctopic_photo")->fetch_all_list("AND model_goods_id = {$v['id']} AND type = 4 ", 'ORDER BY id DESC', 0, 1);
            if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
                $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
            }
            
            if(!empty($v['title'])){
                $titleTmp = $v['title'];
            }

            if(!preg_match('/^http/', $picurlTmp) ){
                if(strpos($picurlTmp, 'source/plugin/tom_') === false){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$picurlTmp;
                }else{
                    $picurlTmp = $_G['siteurl'].$picurlTmp;
                }
            }else{
                $picurlTmp = $picurlTmp;
            }

            $goodsList[$k]['goodsInfo'] = $goodsInfo;
            $goodsList[$k]['picurl'] = $picurlTmp;
            $goodsList[$k]['title'] = $titleTmp;
            $goodsList[$k]['link'] = str_replace("{site}",$site_id, $v['link']);

        }
    }
    
    $md5HostUrl = md5($_G['siteurl']."plugin.php?id=tom_tctopic&site={$site_id}&mod=goodslist&model_id={$model_id}");
    $ajaxClicksUrl = "plugin.php?id=tom_tctopic:ajax&site={$site_id}&act=clicks&tctopic_id={$tctopicInfo['id']}&formhash=".$formhash;
    
    if(!preg_match('/^http/', $tctopicInfo['share_pic']) ){
        if(strpos($tctopicInfo['share_pic'], 'source/plugin/tom_') === false){
            $shareLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tctopicInfo['share_pic'];
        }else{
            $shareLogo = $_G['siteurl'].$tctopicInfo['share_pic'];
        }
    }else{
        $shareLogo = $tctopicInfo['share_pic'];
    }
    $shareTitle = $tctopicInfo['share_title'];
    $shareDesc = $tctopicInfo['share_desc'];
    $shareUrl = $_G['siteurl']."plugin.php?id=tom_tctopic&site={$site_id}&mod=goodslist&model_id={$model_id}&tj_hehuoren_id={$__TjHehuorenId}&s=1";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tctopic:goodslist");
    
    
}else if($_GET['mod'] == 'guize'){
    
    $tctopic_id = intval($_GET['tctopic_id']) > 0 ? intval($_GET['tctopic_id']):0;
    $tctopicInfo = C::t("#tom_tctopic#tom_tctopic")->fetch_by_id($tctopic_id);
    
    $huodong_guize = stripslashes($tctopicInfo['huodong_guize']);
    
    if(!preg_match('/^http/', $tctopicInfo['share_pic']) ){
        if(strpos($tctopicInfo['share_pic'], 'source/plugin/tom_') === false){
            $shareLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tctopicInfo['share_pic'];
        }else{
            $shareLogo = $_G['siteurl'].$tctopicInfo['share_pic'];
        }
    }else{
        $shareLogo = $tctopicInfo['share_pic'];
    }
    $shareTitle = $tctopicInfo['share_title'];
    $shareDesc = $tctopicInfo['share_desc'];
    $shareUrl = $_G['siteurl']."plugin.php?id=tom_tctopic&site={$site_id}&mod=info&tctopic_id={$tctopicInfo['id']}";
    
    $ajaxClicksUrl = "plugin.php?id=tom_tctopic:ajax&site={$site_id}&act=clicks&tctopic_id={$tctopicInfo['id']}&formhash=".$formhash;
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tctopic:guize");
    
    
    
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tctopic&site={$site_id}&mod=index");exit;
}
tomoutput();