<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=loginlog';
$modListUrl = $adminListUrl.'&tmod=loginlog';
$modFromUrl = $adminFromUrl.'&tmod=loginlog';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

if($formhash == FORMHASH && $act == 'clear'){
    
    C::t('#tom_ucenter#tom_ucenter_loginlog')->delete_by_login_time();
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    $uid = isset($_GET['uid'])? intval($_GET['uid']):0;
    
    if($uid == 0){
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['loginlog_help_title'] . '</th></tr>';
        echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
        echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=clear&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['loginlog_clear_title'].'</font></a></li>';
        echo '</ul></td></tr>';
        showtablefooter(); /*dism��taobao��com*/
    }
    
    $where = "";
    if($uid > 0){
        $where = " AND uid={$uid} ";
    }

    $pagesize = 20;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_ucenter#tom_ucenter_loginlog')->fetch_all_count($where);
    $loginlogList = C::t('#tom_ucenter#tom_ucenter_loginlog')->fetch_all_list($where,"ORDER BY id DESC",$start,$count);

    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['loginlog_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['member_picurl'] . '</th>';
    echo '<th>' . $Lang['member_nickname'] . '</th>';
    echo '<th>' . $Lang['loginlog_login_type'] . '</th>';
    echo '<th>' . $Lang['loginlog_login_ip'] . '</th>';
    echo '<th>' . $Lang['loginlog_login_port'] . '</th>';
    echo '<th>' . $Lang['loginlog_login_time'] . '</th>';
    echo '</tr>';
    foreach ($loginlogList as $key => $value){

        $memberInfo = C::t('#tom_ucenter#tom_ucenter_member')->fetch_by_uid($value['uid']);

        echo '<tr>';
        echo '<td><img src="'.$memberInfo['picurl'].'" width="40" /></td>';
        echo '<td>'.$memberInfo['nickname'].'</td>';
        if($value['login_type'] == "weixin"){
            echo '<td>'.$Lang['loginlog_login_type_weixin'].'</td>';
        }else if($value['login_type'] == "bbs"){
            echo '<td>'.$Lang['loginlog_login_type_bbs'].'</td>';
        }else if($value['login_type'] == "tel"){
            echo '<td>'.$Lang['loginlog_login_type_tel'].'</td>';
        }else if($value['login_type'] == "app"){
            echo '<td>'.$Lang['loginlog_login_type_app'].'</td>';
        }else{
            echo '<td>-</td>';
        }
        echo '<td>'.$value['login_ip'].'</td>';
        echo '<td>'.$value['login_port'].'</td>';
        echo '<td>' . dgmdate($value['login_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '</tr>';
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl."&act=scorelog");	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function import_confirm(url){
  var r = confirm("{$Lang['makesure_clear_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}