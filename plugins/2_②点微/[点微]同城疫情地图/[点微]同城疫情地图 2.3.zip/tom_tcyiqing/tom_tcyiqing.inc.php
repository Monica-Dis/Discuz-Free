<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcyiqingConfig = $_G['cache']['plugin']['tom_tcyiqing'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = "20210121";

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){
}else{
    echo '<a href="https://addon.dismall.com/?@tom_tongcheng.plugin">https://addon.dismall.com/?@tom_tongcheng.plugin</a>';exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/nofind.php';

$wxJssdkConfig = array();
$wxJssdkConfig["appId"]     = "";
$wxJssdkConfig["timestamp"] = time();
$wxJssdkConfig["nonceStr"]  = "";
$wxJssdkConfig["signature"] = "";
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcyiqingConfig['wx_share_title'];
$shareDesc  = $tcyiqingConfig['wx_share_desc'];
$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tcyiqing&site={$site_id}&mod=index";
$shareLogo  = $tcyiqingConfig['wx_share_pic'];

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesinfo.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login.php';

## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end

$shareTitle = str_replace("{SITENAME}",$__SitesInfo['name'], $shareTitle);
$shareDesc = str_replace("{SITENAME}",$__SitesInfo['name'], $shareDesc);

/********************* index ***********************/
if($_GET['mod'] == 'index'){
    
    $__IsWeixin = $__Ios = $__Android = 0;
    if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){ $__IsWeixin = 1;}
    if(strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') !== false){$__Ios = 1;}
    if(strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false){$__Android = 1;}
    
    $__IsWeixinDingwei = 0;
    if($__IsWeixin == 1 && ($__Ios == 1 || $__Android == 1)){
        $__IsWeixinDingwei = 1;
    }
    
    $tcyiqingListTmp = C::t("#tom_tcyiqing#tom_tcyiqing")->fetch_all_list(" ", 'ORDER BY id DESC',0,1000);
    $tcyiqingList = array();
    if(is_array($tcyiqingListTmp) && !empty($tcyiqingListTmp)){
        foreach($tcyiqingListTmp as $key => $value){
            
            $value['content'] = stripslashes($value['content']);
            
            $tcyiqingList[$key]['num']          = $value['num'];
            $tcyiqingList[$key]['latitude']     = $value['latitude'];
            $tcyiqingList[$key]['longitude']    = $value['longitude'];
            $tcyiqingList[$key]['address']      = diconv($value['address'],CHARSET,'utf-8');
            $tcyiqingList[$key]['date']         = dgmdate($value['faxian_time'],"Y-m-d",$tomSysOffset);
            $tcyiqingList[$key]['content']      =  diconv($value['content'],CHARSET,'utf-8');
        }
    }
    $tcyiqingData = json_encode($tcyiqingList);
    
    $latitude = getcookie('tom_tongcheng_user_latitude');
    $longitude = getcookie('tom_tongcheng_user_longitude');
    
    $line4NavList = array();
    if(!empty($tcyiqingConfig['index_line4_nav'])){
        $index_line4_str = str_replace("\r\n","{n}",trim($tcyiqingConfig['index_line4_nav'])); 
        $index_line4_str = str_replace("\n","{n}",$index_line4_str);
        $index_line4_str = str_replace("{site}",$site_id,$index_line4_str);
        $index_line4_arr = explode("{n}", $index_line4_str);
        if(is_array($index_line4_arr) && !empty($index_line4_arr)){
            foreach ($index_line4_arr as $key => $value){
                $line4NavList[] = explode("|", $value);
            }
        }
    }
    $line4NavCount = count($line4NavList);
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcyiqing:index");
    
}else if($_GET['mod'] == 'glzc'){
    
    if($__IsMiniprogram == 1){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=index");exit;
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcyiqing/config/glzc.config.php';
    
    $footer_nav1_content_name = $footer_nav1_content_link = $footer_nav1_content_ico = '';
    if($tongchengConfig['footer_nav1_mod'] == 2){
        if(!empty($tongchengConfig['footer_nav1_content'])){
            $footer_nav1_content = explode("|", $tongchengConfig['footer_nav1_content']);
            $footer_nav1_content_name = $footer_nav1_content[0];
            $footer_nav1_content_link = $footer_nav1_content[1];
            $footer_nav1_content_link = str_replace("{site}",$site_id, $footer_nav1_content_link);
            if(isset($footer_nav1_content[2]) && !empty($footer_nav1_content[2])){
                $footer_nav1_content_ico = $footer_nav1_content[2];
            }
        }
    }

    $footer_nav_content_name = $footer_nav_content_link = $footer_nav_content_ico = '';
    if($tongchengConfig['footer_nav_mod'] == 1){
        if(!empty($tongchengConfig['footer_nav_content'])){
            $footer_nav_content = explode("|", $tongchengConfig['footer_nav_content']);
            $footer_nav_content_name = $footer_nav_content[0];
            $footer_nav_content_link = $footer_nav_content[1];
            $footer_nav_content_link = str_replace("{site}",$site_id, $footer_nav_content_link);
            if(isset($footer_nav_content[2]) && !empty($footer_nav_content[2])){
                $footer_nav_content_ico = $footer_nav_content[2];
            }
        }
    }
    
    $ajaxCheckSubscribeUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=check_subscribe&formhash='.$formhash;
    
    $shareTitle = $tcyiqingConfig['glzc_share_title'];
    $shareDesc  = $tcyiqingConfig['glzc_share_desc'];
    $shareUrl   = $_G['siteurl']."plugin.php?id=tom_tcyiqing&site={$site_id}&mod=glzc";
    $shareLogo  = $tcyiqingConfig['glzc_share_pic'];
    
    if($__ShowTchehuoren == 1){
        $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
        if($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1){
            $shareUrl   = $shareUrl."&tjid={$tchehuorenInfoTmp['id']}";
        }
    }
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcyiqing:glzc");
    
}else{
    
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcyiqing&site={$site_id}&mod=index");exit;
    
}
tomoutput();