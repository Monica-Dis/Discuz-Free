<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_tcyiqing_admin_index_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcyiqing#tom_tcyiqing')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); /*dism��taobao��com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter(); /*dism_taobao_com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $yiqingInfo = C::t('#tom_tcyiqing#tom_tcyiqing')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($yiqingInfo);
        C::t('#tom_tcyiqing#tom_tcyiqing')->update($yiqingInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*dism��taobao��com*/
        __create_info_html($yiqingInfo);
        showsubmit('submit', 'submit');
        showtablefooter();
        showformfooter(); /*dism_taobao_com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcyiqing#tom_tcyiqing')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_tcyiqing_admin_index_list");
    
    $page   = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    
    $order = "ORDER BY id DESC";
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_tcyiqing#tom_tcyiqing')->fetch_all_count($where);
    $yiqingList  = C::t('#tom_tcyiqing#tom_tcyiqing')->fetch_all_list($where,$order,$start,$pagesize);

    showtableheader(); /*dism��taobao��com*/
    $Lang['index_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_1']);
    $Lang['index_help_2']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_2']);
    $Lang['index_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_3']);
    $Lang['index_help_4']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_4']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_1'] . '</li>';
    echo '<li>' . $Lang['index_help_4'] . '</li>';
    echo '<li>' . $Lang['index_help_2'] . '</li>';
    //echo '<li>' . $Lang['index_help_3'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();

    $modBasePageUrl = $modBaseUrl;
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); /*dism��taobao��com*/
    
    __create_nav_html();
    showtableheader(); /*dism��taobao��com*/
    echo '<tr class="header">';
    echo '<th style="width: 60px;"> ID </th>';
    echo '<th>' . $Lang['index_faxian_time'] . '</th>';
    echo '<th>' . $Lang['index_num'] . '</th>';
    echo '<th>' . $Lang['index_longitude'] . '</th>';
    echo '<th>' . $Lang['index_latitude'] . '</th>';
    echo '<th >' . $Lang['index_address'] . '</th>';
    echo '<th >' . $Lang['handle'] . '</th>';
    echo '</tr>';
    $i = 1;
    foreach ($yiqingList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . dgmdate($value['faxian_time'],"Y-m-d",$tomSysOffset) . '</td>';
        echo '<td>' . $value['num'] . '</td>';
        echo '<td>' . $value['longitude'] . '</td>';
        echo '<td>' . $value['latitude'] . '</td>';
        echo '<td>' . $value['address'] . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'">' . $Lang['edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a><br/>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $num            = intval($_GET['num'])>0? intval($_GET['num']):1;
    $latitude       = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude      = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $address        = isset($_GET['address'])? addslashes($_GET['address']):'';
    $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
    $faxian_time    = isset($_GET['faxian_time'])? addslashes($_GET['faxian_time']):'';
    $faxian_time    = strtotime($faxian_time);
    
    $data['num']            = $num;
    $data['faxian_time']    = $faxian_time;
    $data['latitude']       = $latitude;
    $data['longitude']      = $longitude;
    $data['address']        = $address;
    $data['content']        = $content;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'num'               => 1,
        'faxian_time'       => '',
        'latitude'          => '',
        'longitude'         => '',
        'address'           => '',
        'content'           => '',
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['index_num'],'name'=>'num','value'=>$options['num'],'msg'=>$Lang['index_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_faxian_time'],'name'=>'faxian_time','value'=>$options['faxian_time'],'msg'=>$Lang['index_faxian_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['index_latitude'],'name'=>'latitude','value'=>$options['latitude'],'msg'=>$Lang['index_latitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_longitude'],'name'=>'longitude','value'=>$options['longitude'],'msg'=>$Lang['index_longitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['index_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['index_content_msg']),"text");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',false);
        tomshownavli($Lang['edit'],$modBaseUrl.'&act=edit',true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',false);
    }
    tomshownavfooter();
}