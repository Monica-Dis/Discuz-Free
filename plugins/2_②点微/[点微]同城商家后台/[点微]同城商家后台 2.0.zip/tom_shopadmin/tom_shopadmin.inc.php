<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH; //DISM - TAOBAO - COM
$timestamp = TIMESTAMP;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$shopadminConfig = $_G['cache']['plugin']['tom_shopadmin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20210425";

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_admin/tom_admin.inc.php')){}else{
    echo " no install https://dism.taobao.com/?@tom_admin.plugin";exit;
}

## tcadmin start
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
## tcadmin end
## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tcmall start
$__ShowTcmall = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcmall/tom_tcmall.inc.php')){
    $tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
    if($tcmallConfig['open_tcmall'] == 1){
        $__ShowTcmall = 1;
    }
}
## tcmall end
## tcqianggou start
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
    $tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
    if($tcqianggouConfig['open_tcqianggou'] == 1){
        $__ShowTcqianggou = 1;
    }
}
## tcqianggou end
## tcptuan start
$__ShowTcptuan = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcptuan/tom_tcptuan.inc.php')){
    $tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
    if($tcptuanConfig['open_tcptuan'] == 1){
        $__ShowTcptuan = 1;
    }
}
## tcptuan end
## tckjia start
$__ShowTckjia = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tckjia/tom_tckjia.inc.php')){
    $tckjiaConfig = $_G['cache']['plugin']['tom_tckjia'];
    if($tckjiaConfig['open_tckjia'] == 1){
        $__ShowTckjia = 1;
    }
}
## tckjia end
## tctoutiao start
$__ShowTctoutiao = 0;
$tctoutiaoConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tctoutiao/tom_tctoutiao.inc.php')){
    $tctoutiaoConfig = $_G['cache']['plugin']['tom_tctoutiao'];
    if($tctoutiaoConfig['open_tctoutiao'] == 1){
        $__ShowTctoutiao = 1;
    }
}
## tctoutiao end
## tcrenzheng start
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')){
    $tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
    if($tcrenzhengConfig['open_tcrenzheng'] == 1){
        $__ShowTcrenzheng = 1;
    }
}
## tcrenzheng end
## tczhaopin start
$__ShowTczhaopin = 0;
$tczhaopinConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')){
    $tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
    if($tczhaopinConfig['open_tczhaopin'] == 1){
        $__ShowTczhaopin = 1;
    }
}
## tczhaopin end
## tcpinche start
$__ShowTcpinche = 0;
$tcpincheConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcpinche/tom_tcpinche.inc.php')){
    $tcpincheConfig = $_G['cache']['plugin']['tom_tcpinche'];
    $__ShowTcpinche = 1;
}
## tcpinche end
## tcfangchan start
$__ShowFangchan = 0;
$tcfangchanConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/tom_tcfangchan.inc.php')){
    $tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
    if($tcfangchanConfig['open_tcfangchan'] == 1){
        $__ShowFangchan = 1;
    }
}
## tcfangchan end
## video start
$__ShowVideo = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/video.inc.php')){
    $__ShowVideo = 1;
}
## video end
## tchongbao start
$__ShowTchongbao = 0;
$tchongbaoConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchongbao/tom_tchongbao.inc.php')){
    $tchongbaoConfig = $_G['cache']['plugin']['tom_tchongbao'];
    if($tchongbaoConfig['open_tchongbao'] == 1){
        $__ShowTchongbao = 1;
        $tchongbaoConfig['hb_lq_type'] = 1;
    }
}
## tchongbao end
## tcchoujiang start
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')){
    $tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
    if($tcchoujiangConfig['open_tcchoujiang'] == 1){
        $__ShowTcchoujiang = 1;
    }
}
## tcchoujiang end
## tchuodong start
$__ShowTchuodong = 0;
$tchuodongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchuodong/tom_tchuodong.inc.php')){
    $tchuodongConfig = $_G['cache']['plugin']['tom_tchuodong'];
    if($tchuodongConfig['open_tchuodong'] == 1){
        $__ShowTchuodong = 1;
    }
}
## tchuodong end
## tcyuyue start
$__ShowTcyuyue = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/tom_tcyuyue.inc.php')){
    $tcyuyueConfig = $_G['cache']['plugin']['tom_tcyuyue'];
    if($tcyuyueConfig['open_tcyuyue'] == 1){
        $__ShowTcyuyue = 1;
    }
}
## tcyuyue end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

$lifeTime = 86400;
$shopAdminKey = md5($appid.'_shopadmin_'.$appsecret);

dsetcookie('tom_admin', 'shopadmin', $lifeTime);
dsetcookie('tom_admin_key', $shopAdminKey, $lifeTime);

include DISCUZ_ROOT.'./source/plugin/tom_admin/login_check.php';

$pcadminUrl = 'plugin.php?id=tom_shopadmin';
$ajaxUrl = 'plugin.php?id=tom_admin:ajax';
$uploadUrl = 'plugin.php?id=tom_admin:upload';
$baidumapUrl = 'plugin.php?id=tom_admin:baidumap';

if($_GET['tmod'] == 'home'){
    include DISCUZ_ROOT.'./source/plugin/tom_shopadmin/module/home.php';
}else{
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
    include template("tom_shopadmin:index");
}