<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=index";

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(" AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,100,"");
$tcshopIdsTmp = array();
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach ($tcshopListTmp as $key => $value){
        $tcshopIdsTmp[] = $value['id'];
    }
}
$tcshop_ids_str = "999999999";
if(is_array($tcshopIdsTmp) && !empty($tcshopIdsTmp) && count($tcshopIdsTmp) > 0){
    $tcshop_ids_str = implode(",", $tcshopIdsTmp);
}

$orderStartTime = TIMESTAMP - (15 * 86400);
$orderStartTime = gmmktime(0,0,0,dgmdate($orderStartTime, 'n',$tomSysOffset),dgmdate($orderStartTime, 'j',$tomSysOffset),dgmdate($orderStartTime, 'Y',$tomSysOffset)) - $tomSysOffset*3600;

$orderViewArr = array();
for($i = 15; $i >= 0; $i--){
    $timeStampTmp = TIMESTAMP - ($i * 86400);
    $monthDayTmp = dgmdate($timeStampTmp, 'm-d',$tomSysOffset);
    $orderViewArr[$monthDayTmp]['all_pay_price'] = 0;
    $orderViewArr[$monthDayTmp]['order_num'] = 0;
}

$todayDate = dgmdate($timeStampTmp, 'm-d',$tomSysOffset);
$totalGoodsNum = $totalOrderNum = $totalOrderPrice = $todayOrderPrcie = $todayOrderNum = 0;
if($__ShowTcmall == 1){
    $mallGoodsCount =  C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND tcshop_id IN ({$tcshop_ids_str}) ");
    $totalGoodsNum = $totalGoodsNum + intval($mallGoodsCount);
    
    $mallOrdersCount =  C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id IN ({$tcshop_ids_str}) AND order_status IN(2,3,4) ");
    $mallOrdersCount2 = C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_count(" AND tcshop_id IN ({$tcshop_ids_str}) AND order_status=2 ");
    
    $mallOrdersPrice =  C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_pay_price(" AND tcshop_id IN ({$tcshop_ids_str}) AND order_status IN(2,3,4) ");
    
    $mallOrdersCount = intval($mallOrdersCount);
    $mallOrdersCount2 = intval($mallOrdersCount2);
    
    $totalOrderNum = $totalOrderNum + $mallOrdersCount;
    $totalOrderPrice = $totalOrderPrice + $mallOrdersPrice;
    
    $mallOrdersListTmp =  C::t('#tom_tcmall#tom_tcmall_order')->fetch_all_list(" AND order_time >={$orderStartTime} AND tcshop_id IN ({$tcshop_ids_str}) AND order_status IN(2,3,4) ",'ORDER BY id ASC', 0, 100000);
    if(!empty($mallOrdersListTmp)){
        foreach($mallOrdersListTmp as $key => $value){
            $monthDayTmp = dgmdate($value['order_time'], 'm-d',$tomSysOffset);
            
            if(isset($orderViewArr[$monthDayTmp])){
                $orderViewArr[$monthDayTmp]['all_pay_price'] += $value['pay_price'];
                $orderViewArr[$monthDayTmp]['order_num'] += 1;
            }
            
            if($todayDate == $monthDayTmp){
                $todayOrderPrcie += $value['pay_price'];
                $todayOrderNum += 1;
            }
        }
    }
}

if($__ShowTcqianggou == 1){
    $qianggouGoodsCount =  C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_count(" AND tcshop_id IN ({$tcshop_ids_str}) ");
    $totalGoodsNum = $totalGoodsNum + intval($qianggouGoodsCount);
    
    $qgOrdersCount =  C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(" AND tcshop_id IN ({$tcshop_ids_str}) AND order_status IN(2,3) ");
    $qgOrdersCount2 = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(" AND tcshop_id IN ({$tcshop_ids_str}) AND order_status=2 ");
    $qgOrdersPrice =  C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_pay_price(" AND tcshop_id IN ({$tcshop_ids_str}) AND order_status IN(2,3) ");
    
    $qgOrdersCount = intval($qgOrdersCount);
    $qgOrdersCount2 = intval($qgOrdersCount2);
    
    $totalOrderNum = $totalOrderNum + $qgOrdersCount;
    $totalOrderPrice = $totalOrderPrice + $qgOrdersPrice;
    
    $qgOrdersListTmp =  C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list(" AND order_time >={$orderStartTime} AND tcshop_id IN ({$tcshop_ids_str}) AND order_status IN(2,3) ", 'ORDER BY id ASC', 0, 100000);
    if(!empty($qgOrdersListTmp)){
        foreach($qgOrdersListTmp as $key => $value){
            $monthDayTmp = dgmdate($value['order_time'], 'm-d',$tomSysOffset);
            
            if(isset($orderViewArr[$monthDayTmp])){
                $orderViewArr[$monthDayTmp]['all_pay_price'] += $value['pay_price'];
                $orderViewArr[$monthDayTmp]['order_num'] += 1;
            }
            
            if($todayDate == $monthDayTmp){
                $todayOrderPrcie += $value['pay_price'];
                $todayOrderNum += 1;
            }
        }
    }
    
}

if($__ShowTcptuan == 1){
    $ptuanGoodsCount =  C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_count(" AND tcshop_id IN ({$tcshop_ids_str}) ");
    $totalGoodsNum = $totalGoodsNum + intval($ptuanGoodsCount);
    
    $ptOrdersCount =  C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_count(" AND tcshop_id IN ({$tcshop_ids_str}) AND order_status IN(2,3,4,5) ");
    $ptOrdersCount2 = C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_count(" AND tcshop_id IN ({$tcshop_ids_str}) AND order_status=2 AND tuan_status=3 ");
    
    $ptOrdersPrice =  C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_sun_pay_price(" AND tcshop_id IN ({$tcshop_ids_str}) AND order_status IN(2,3,4,5) ");
    
    $ptOrdersCount = intval($ptOrdersCount);
    $ptOrdersCount2 = intval($ptOrdersCount2);
    
    $totalOrderNum = $totalOrderNum + $ptOrdersCount;
    $totalOrderPrice = $totalOrderPrice + $ptOrdersPrice;
    
    $ptOrdersListTmp =  C::t('#tom_tcptuan#tom_tcptuan_order')->fetch_all_list(" AND order_time >={$orderStartTime}  AND tcshop_id IN ({$tcshop_ids_str}) AND order_status IN(2,3,4,5) ", 'ORDER BY id ASC', 0, 100000);
    if(!empty($ptOrdersListTmp)){
        foreach($ptOrdersListTmp as $key => $value){
            $monthDayTmp = dgmdate($value['order_time'], 'm-d',$tomSysOffset);
            
            if(isset($orderViewArr[$monthDayTmp])){
                $orderViewArr[$monthDayTmp]['all_pay_price'] += $value['pay_price'];
                $orderViewArr[$monthDayTmp]['order_num'] += 1;
            }
            
            if($todayDate == $monthDayTmp){
                $todayOrderPrcie += $value['pay_price'];
                $todayOrderNum += 1;
            }
        }
    }
}

if($__ShowTckjia == 1){
    $kjiaGoodsCount =  C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_count(" AND tcshop_id IN ({$tcshop_ids_str}) ");
    $totalGoodsNum = $totalGoodsNum + intval($kjiaGoodsCount);
    
    $kjOrdersCount =  C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND tcshop_id IN ({$tcshop_ids_str}) AND order_status IN(2,3) ");
    $kjOrdersCount2 = C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_count(" AND tcshop_id IN ({$tcshop_ids_str}) AND order_status=2 ");
    $kjOrdersPrice =  C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_sun_pay_price(" AND tcshop_id IN ({$tcshop_ids_str}) AND order_status IN(2,3) ");
    
    $kjOrdersCount = intval($kjOrdersCount);
    $kjOrdersCount2 = intval($kjOrdersCount2);
    
    $totalOrderNum = $totalOrderNum + $kjOrdersCount;
    $totalOrderPrice = $totalOrderPrice + $kjOrdersPrice;
    
    $kjOrdersListTmp =  C::t('#tom_tckjia#tom_tckjia_order')->fetch_all_list(" AND order_time >={$orderStartTime} AND tcshop_id IN ({$tcshop_ids_str}) AND order_status IN(2,3) ", 'ORDER BY id ASC', 0, 100000);
    if(!empty($kjOrdersListTmp)){
        foreach($kjOrdersListTmp as $key => $value){
            $monthDayTmp = dgmdate($value['order_time'], 'm-d',$tomSysOffset);
            
            if(isset($orderViewArr[$monthDayTmp])){
                $orderViewArr[$monthDayTmp]['all_pay_price'] += $value['pay_price'];
                $orderViewArr[$monthDayTmp]['order_num'] += 1;
            }
            
            if($todayDate == $monthDayTmp){
                $todayOrderPrcie += $value['pay_price'];
                $todayOrderNum += 1;
            }
        }
    }
}

$orderArr = array();
$maxPrice = $minPrice = $maxNum = $minNum = 0;
if(is_array($orderViewArr) && !empty($orderViewArr)){
    foreach($orderViewArr as $key => $value){
        if($value['all_pay_price'] > $maxPrice){
            $maxPrice = $value['all_pay_price'];
        }
        if($minPrice > $value['all_pay_price']){
            $minPrice = $value['all_pay_price'];
        }
        if($value['order_num'] > $maxNum){
            $maxNum = $value['order_num'];
        }
        if($minNum > $value['order_num']){
            $minNum = $value['order_num'];
        }
        
        $orderArr['date'][]         = $key;
        $orderArr['orderPrice'][]   = floatval($value['all_pay_price']);
        $orderArr['orderNum'][]     = floatval($value['order_num']);
    }
}

$orderArr['maxPrice']   = $maxPrice;
$orderArr['minPrice']   = $minPrice;
$orderArr['maxNum']     = $maxNum;
$orderArr['minNum']     = $minNum;
$orderData[0] = $orderArr;
$orderData = urlencode(json_encode($orderData));

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_shopadmin:home");