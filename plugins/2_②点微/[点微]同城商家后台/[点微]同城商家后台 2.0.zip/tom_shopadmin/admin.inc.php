<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_shopadmin'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_shopadmin&pmod=admin';
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_shopadmin&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_shopadmin&pmod=admin';

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_admin/tom_admin.inc.php')){}else{
    echo " no install https://dism.taobao.com/?@tom_admin.plugin";exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.a.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$adminConfig = get_plugin_config($pluginid);
$Lang = formatLang($Lang);

if($_GET['tmod'] == 'url'){
    include DISCUZ_ROOT.'./source/plugin/tom_shopadmin/admin/url.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_shopadmin/admin/url.php';
}