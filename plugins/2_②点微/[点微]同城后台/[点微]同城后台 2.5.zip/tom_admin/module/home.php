<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=home";

$commonClicks = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_all_sun_clicks("");

$fabuNum = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count("");

$userNum = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_count("");

$showTcshopStatus = 0;
if(!empty($powerList['shop']) && in_array('list', $powerList['shop']) && $__ShowTcshop == 1){
    $showTcshopStatus = 1;
    $ruzhuNum = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count("");
    $tcshopShenheCount = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count(" AND shenhe_status=2 AND pay_status!=1 AND is_ok=1 ");
}

$tongchengShenheCount = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count(" AND shenhe_status=2 AND pay_status!=1 ");

$showTcmallStatus = 0;
if(!empty($powerList['mall']) && in_array('list', $powerList['mall']) && $__ShowTcmall == 1){
    $showTcmallStatus = 1;
    $tcmallShenheCount = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count(" AND shenhe_status=2");
    $tcmallGoodsCount = C::t('#tom_tcmall#tom_tcmall_goods')->fetch_all_count("");
}

$showTcqianggouStatus = $showTcqianggouCouponStatus = 0;
if($__ShowTcqianggou == 1){
    if(!empty($powerList['qianggou']) && in_array('list', $powerList['qianggou'])){
        $showTcqianggouStatus = 1;
        $tcqianggouShenheCount = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_count(" AND type_id=1 AND shenhe_status=2");
        $tcqianggouGoodsCount = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_count(" AND type_id=1 ");
    }
    
    if(!empty($powerList['qianggou']) && in_array('coupon', $powerList['qianggou'])){
        $showTcqianggouCouponStatus = 1;
        $tcqianggouCouponShenheCount = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_count("  AND type_id IN(2,3,4) AND shenhe_status=2");
        $tcqianggouCouponCount = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_count(" AND type_id IN(2,3,4) ");
    }
}

$showTcptuanStatus = 0;
if(!empty($powerList['ptuan']) && in_array('list', $powerList['ptuan']) && $__ShowTcptuan == 1){
    $showTcptuanStatus = 1;
    $tcptuanShenheCount = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_like_count(" AND shenhe_status=2");
    $tcptuanGoodsCount = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_like_count(" ");
}

$showTckjiaStatus = 0;
if(!empty($powerList['kjia']) && in_array('list', $powerList['kjia']) && $__ShowTckjia == 1){
    $showTckjiaStatus = 1;
    $tckjiaShenheCount = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_like_count(" AND shenhe_status=2");
    $tckjiaGoodsCount = C::t('#tom_tckjia#tom_tckjia_goods')->fetch_all_like_count(" ");
}

$showTcyuyueStatus = 0;
if(!empty($powerList['yuyue']) && in_array('list', $powerList['yuyue']) && $__ShowTcyuyue == 1){
    $showTcyuyueStatus = 1;
    $tcyuyueShenheCount = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_count(" AND shenhe_status=2 ");
}

$showTczhaopinStatus = $showTczhaopinResumeStatus = 0;
if($__ShowTczhaopin == 1){
    if(!empty($powerList['zhaopin']) && in_array('list', $powerList['zhaopin'])){
        $showTczhaopinStatus = 1;
        $tczhaopinShenheCount = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count(" AND shenhe_status=2 AND pay_status!=1 ");
        $tczhaopinCount = C::t('#tom_tczhaopin#tom_tczhaopin')->fetch_all_count(" ");
    }
    
    if(!empty($powerList['zhaopin']) && in_array('resume', $powerList['zhaopin'])){
        $showTczhaopinResumeStatus = 1;
        $tczhaopinResumeShenheCount = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count(" AND shenhe_status=2 ");
        $tczhaopinResumeCount = C::t('#tom_tczhaopin#tom_tczhaopin_resume')->fetch_all_count(" ");
    }
}

$showTcfangchanStatus = $showTcfangchanNeedsStatus = $showTcfangchanHousesStatus = $showTcfangchanMendianStatus = $showTcfangchanAgentStatus = $showTcfangchanNewhousesAdviserStatus = 0;
if($__ShowFangchan == 1){
    if(!empty($powerList['fangchan']) && in_array('list', $powerList['fangchan'])){
        $showTcfangchanStatus = 1;
        $tcfangchanShenheCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count(" AND shenhe_status=2 AND pay_status!=1 ");
        $tcfangchanCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count(" ");
    }
    
    if(!empty($powerList['fangchan']) && in_array('needs', $powerList['fangchan'])){
        $showTcfangchanNeedsStatus = 1;
        $tcfangchanNeedsShenheCount = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_count(" AND shenhe_status=2 AND pay_status!=1 ");
        $tcfangchanNeedsCount = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_count(" ");
    }
    
    if(!empty($powerList['fangchan']) && in_array('houses', $powerList['fangchan'])){
        $showTcfangchanHousesStatus = 1;
        $tcfangchanHousesShenheCount = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_count(" AND shenhe_status=2 ");
    }
    
    if(!empty($powerList['fangchan']) && in_array('mendian', $powerList['fangchan'])){
        $showTcfangchanMendianStatus = 1;
        $tcfangchanMendianShenheCount = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_count(" AND shenhe_status=2 ");
    }
    
    if(!empty($powerList['fangchan']) && in_array('agent', $powerList['fangchan'])){
        $showTcfangchanAgentStatus = 1;
        $tcfangchanAgentShenheCount = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_count(" AND shenhe_status=2 ");
    }
    
    if(!empty($powerList['fangchan']) && in_array('newhouses', $powerList['fangchan'])){
        $showTcfangchanNewhousesAdviserStatus = 1;
        $tcfangchanNewhousesAdviserShenheCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count(" AND shenhe_status=2 AND pay_status!=1 ");
    }
    
}

$showTcrenzhengCompanyStatus = $showTcrenzhengPersonalStatus = 0;
if($__ShowTcrenzheng == 1){
    if(!empty($powerList['renzheng']) && in_array('company', $powerList['renzheng'])){
        $showTcrenzhengCompanyStatus = 1;
        $tcrenzhengCompanyShenheCount = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_count(" AND shenhe_status=2");
        $tcrenzhengCompanyCount = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_all_count(" ");
    }
    
    if(!empty($powerList['renzheng']) && in_array('personal', $powerList['renzheng'])){
        $showTcrenzhengPersonalStatus = 1;
        $tcrenzhengPersonalShenheCount = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_all_count(" AND shenhe_status=2 ");
        $tcrenzhengPersonalCount = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_all_count(" ");
    }
}

$showTceduStatus = $showTceduCourseStatus = 0;
if($__ShowTcedu == 1){
    if(!empty($powerList['edu']) && in_array('list', $powerList['edu'])){
        $showTceduStatus = 1;
        $tceduShenheCount = C::t('#tom_tcedu#tom_tcedu')->fetch_all_count(" AND shenhe_status=2 AND expire_status = 1 ");
        $tceduCount = C::t('#tom_tcedu#tom_tcedu')->fetch_all_count(" ");
    }
    if(!empty($powerList['edu']) && in_array('course', $powerList['edu'])){
        $showTceduCourseStatus = 1;
        $tceduShenheCourseCount = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(" AND shenhe_status=2 ");
        $tceduCourseCount = C::t('#tom_tcedu#tom_tcedu_course')->fetch_all_count(" ");
    }
}

$showTcloveStatus = $showTcloveTalkStatus = $showTcloveHongniangStatus = 0;
if($__ShowTclove == 1){
    if(!empty($powerList['love']) && in_array('list', $powerList['love'])){
        $showTcloveStatus = 1;
        $tcloveShenheCount = C::t('#tom_tclove#tom_tclove')->fetch_all_count(" AND shenhe_status=2 AND is_ok=1 ");
        $tcloveCount = C::t('#tom_tclove#tom_tclove')->fetch_all_count(" ");
    }
    
    if(!empty($powerList['love']) && in_array('talk', $powerList['love'])){
        $showTcloveTalkStatus = 1;
        $tcloveTalkShenheCount = C::t('#tom_tclove#tom_tclove_talk')->fetch_all_count(" AND shenhe_status=2 ");
    }
    
    if(!empty($powerList['love']) && in_array('hongniang', $powerList['love'])){
        $showTcloveHongniangStatus = 1;
        $tcloveHongniangShenheCount = C::t('#tom_tclove#tom_tclove_hongniang_shenqing')->fetch_all_count(" AND shenhe_status=2 ");
    }
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_admin:home");