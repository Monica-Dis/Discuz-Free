<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;

## tcadmin start
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
## tcadmin end
## tcshop start
$__ShowTcshop = 0;
$tcshopConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end
## tcrenzheng start
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')){
    $tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
    if($tcrenzhengConfig['open_tcrenzheng'] == 1){
        $__ShowTcrenzheng = 1;
    }
}
## tcrenzheng end
## tczhaopin start
$__ShowTczhaopin = 0;
$tczhaopinConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tczhaopin/tom_tczhaopin.inc.php')){
    $tczhaopinConfig = $_G['cache']['plugin']['tom_tczhaopin'];
    if($tczhaopinConfig['open_tczhaopin'] == 1){
        $__ShowTczhaopin = 1;
    }
}
## tczhaopin end
## tcpinche start
$__ShowTcpinche = 0;
$tcpincheConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcpinche/tom_tcpinche.inc.php')){
    $tcpincheConfig = $_G['cache']['plugin']['tom_tcpinche'];
    $__ShowTcpinche = 1;
}
## tcpinche end
## tcfangchan start
$__ShowFangchan = 0;
$tcfangchanConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/tom_tcfangchan.inc.php')){
    $tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
    if($tcfangchanConfig['open_tcfangchan'] == 1){
        $__ShowFangchan = 1;
    }
}
## tcfangchan end
## video start
$__ShowVideo = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/video.inc.php')){
    $__ShowVideo = 1;
}
## video end
## tcqianggou start
$__ShowTcqianggou = 0;
$tcqianggouConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/tom_tcqianggou.inc.php')){
    $tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
    if($tcqianggouConfig['open_tcqianggou'] == 1){
        $__ShowTcqianggou = 1;
    }
}
## tcqianggou end
## tcptuan start
$__ShowTcptuan = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcptuan/tom_tcptuan.inc.php')){
    $tcptuanConfig = $_G['cache']['plugin']['tom_tcptuan'];
    if($tcptuanConfig['open_tcptuan'] == 1){
        $__ShowTcptuan = 1;
    }
}
## tcptuan end

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
if($_GET['act'] == 'tcshop' && $__ShowTcshop == 1 && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $user_id    = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    $type       = isset($_GET['type'])? addslashes($_GET['type']):'';
    
    $where = " AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$user_id} ";
    if($type == 'tongcheng'){
        $where .= ' AND v.open_fenlei=1 ';
    }
    
    $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip($where," ORDER BY s.id DESC ",0,100);
    $tcshopList = array();
    if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
        foreach ($tcshopListTmp as $key => $value){
            
            $arrTmp = array();
            $arrTmp['id'] = $value['id'];
            $arrTmp['name'] = diconv($value['name'],CHARSET,'utf-8');
            
            $tcshopList[] = $arrTmp;
        }
    }
    
    $outArr = array(
        'code'  => 200,
        'list'  => $tcshopList,
    );    
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'tcshop_clerk' && $__ShowTcshop == 1 && submitcheck('tcshop_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcshop_id = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
    
    $clerkListTmp = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_all_list(" AND tcshop_id = {$tcshop_id} ", 'ORDER BY id ASC', 0, 100);
    $clerkList = array();
    if(is_array($clerkListTmp) && !empty($clerkListTmp)){
        foreach($clerkListTmp as $key => $value){
            $clerkList[$key] = $value;
            
            $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
            $clerkList[$key]['nickname'] = $userInfoTmp['nickname'];
        }
    }
    $list = iconv_to_utf8($clerkList);
    
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );    
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'tcqianggou' && $__ShowTcqianggou == 1 && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $user_id = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    
    $tcqianggouListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_list(" AND status=1 AND shenhe_status=1 AND type_id=1 AND user_id={$user_id} AND qiang_status IN(1,2)"," ORDER BY qiang_status ASC,paixu ASC,id DESC ",0,100);
    $tcqianggouList = array();
    if(is_array($tcqianggouListTmp) && !empty($tcqianggouListTmp)){
        foreach ($tcqianggouListTmp as $key => $value){
            
            $arrTmp = array();
            $arrTmp['id']       = $value['id'];
            $arrTmp['title']    = diconv($value['title'],CHARSET,'utf-8');
            
            $tcqianggouList[] = $arrTmp;
        }
    }
    
    $outArr = array(
        'code'  => 200,
        'list'  => $tcqianggouList,
    );    
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'tcptuan' && $__ShowTcptuan == 1 && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $user_id = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    
    $tcptuanListTmp = C::t('#tom_tcptuan#tom_tcptuan_goods')->fetch_all_like_list(" AND ptuan_status = 1 AND status=1 AND shenhe_status=1 AND user_id={$user_id} "," ORDER BY ptuan_status ASC,paixu ASC,id DESC ",0,100);
    $tcptuanList = array();
    if(is_array($tcptuanListTmp) && !empty($tcptuanListTmp)){
        foreach ($tcptuanListTmp as $key => $value){
            
            $arrTmp = array();
            $arrTmp['id']   = $value['id'];
            $arrTmp['name'] = diconv($value['name'],CHARSET,'utf-8');
            
            $tcptuanList[] = $arrTmp;
        }
    }
    
    $outArr = array(
        'code'  => 200,
        'list'  => $tcptuanList,
    );    
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'district' && submitcheck('parent_id')){
    $outArr = array(
        'code'=> 1,
    );

    $site_id = intval($_GET['site_id'])>0 ? intval($_GET['site_id']):0;
    $parent_id = intval($_GET['parent_id'])>0 ? intval($_GET['parent_id']):0;
    
    if($site_id > 0){
        if($site_id > 1){
            $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
            if($sitesInfoTmp){
                $__SitesInfo = $sitesInfoTmp;
                if(!empty($__SitesInfo['city_id'])){
                    $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                    if($cityInfoTmp){
                        $parent_id = $cityInfoTmp['id'];
                    }
                }
            }
        }else if($site_id == 1){
            $cityInfoTmp = array();
            if(!empty($tongchengConfig['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
            }
            if(!empty($cityInfoTmp)){
                $parent_id = $cityInfoTmp['id'];
            }
        }
    }
    
    $areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($parent_id);
    $areaList = array();
    if(is_array($areaListTmp) && !empty($areaListTmp)){
        foreach ($areaListTmp as $key => $value){
            
            $arrTmp = array();
            $arrTmp['id'] = $value['id'];
            $arrTmp['name'] = diconv($value['name'],CHARSET,'utf-8');
            
            $areaList[] = $arrTmp;
        }
    }
    
    $outArr = array(
        'code'  => 200,
        'list'  => $areaList,
    );    
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'ucenter_district' && submitcheck('parent_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $parent_id = intval($_GET['parent_id'])>0 ? intval($_GET['parent_id']):0;
    
    $districtListTmp = C::t('#tom_ucenter#tom_ucenter_district')->fetch_all_by_upid($parent_id);
    $districtList = array();
    if(is_array($districtListTmp) && !empty($districtListTmp)){
        foreach ($districtListTmp as $key => $value){
            $districtList[$key] = $value;
        }
    }
    
    $list = iconv_to_utf8($districtList);
    
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );    
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'tcshop_viplist' && $__ShowTcshop == 1 && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );

    $vipListTmp = C::t('#tom_tcshop#tom_tcshop_vip')->fetch_all_list(""," ORDER BY vsort ASC,id DESC ",0,100);
    $vipList = array();
    if(!empty($vipListTmp)){
        foreach($vipListTmp as $key => $value){
            $vipList[$key] = $value;
        }
    }
    
    $vipList = iconv_to_utf8($vipList);
    
    $outArr = array(
        'code'  => 200,
        'list'  => $vipList,
    );    
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'tcshop_mall_cate' && $__ShowTcshop == 1 && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );

    $tcshop_id = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
    
    $shopCateListTmp = C::t('#tom_tcshop#tom_tcshop_mall_cate')->fetch_all_list(" AND tcshop_id={$tcshop_id} "," ORDER BY csort ASC,id DESC ",0,100);
    $shopCateList = array();
    if(!empty($shopCateListTmp)){
        foreach($shopCateListTmp as $key => $value){
            $shopCateList[$key] = $value;
        }
    }
    
    $shopCateList = iconv_to_utf8($shopCateList);
    
    $outArr = array(
        'code'  => 200,
        'list'  => $shopCateList,
    );
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'tongcheng_model' && submitcheck('site_id')){
    $outArr = array(
        'code'=> 1,
    );

    $site_id = intval($_GET['site_id'])>0 ? intval($_GET['site_id']):0;
    
    $modelWhereStr = " ";
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if(!empty($sitesInfoTmp['model_ids'])){
            $modelWhereStr.= " AND id IN({$sitesInfoTmp['model_ids']}) ";
        }
    }else{
        $modelWhereStr.= " AND sites_show=0 ";
    }
    
    $modelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list($modelWhereStr," ORDER BY paixu ASC,id DESC ",0,50);
    $modelList = array();
    if(is_array($modelListTmp) && !empty($modelListTmp)){
        foreach ($modelListTmp as $key => $value){
            $modelList[$value['id']] = $value;
        }
    }
    
    $list = iconv_to_utf8($modelList);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );    
    echo json_encode($outArr); exit;
}else{
    echo 'error';exit;
}