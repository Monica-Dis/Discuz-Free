<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';

if($_GET['act'] == 'photo' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $upload = new tom_upload();
    $_FILES["file"]['name'] = addslashes(diconv(urldecode($_FILES["file"]['name']), 'UTF-8'));
    
    if(!getimagesize($_FILES['file']['tmp_name']) || !$upload->init($_FILES['file'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    require_once libfile('class/image');
    $image = new image();
    $image->Thumb($upload->attach['target'], '', 1500, 1500, 1, 1); 
    if($tongchengConfig['open_watermask'] == 1){
        $image->Watermark($upload->attach['target']);
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    
    $outArr = array(
        'code'      => 200,
        'pic'       => $upload->attach['attachment'],
        'picurl'    => $picurl,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'photo_original' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $upload = new tom_upload();
    $_FILES["file"]['name'] = addslashes(diconv(urldecode($_FILES["file"]['name']), 'UTF-8'));
    
    if(!getimagesize($_FILES['file']['tmp_name']) || !$upload->init($_FILES['file'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    
    $outArr = array(
        'code'      => 200,
        'pic'       => $upload->attach['attachment'],
        'picurl'    => $picurl,
    );
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'logo' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $upload = new tom_upload();
    $_FILES["file"]['name'] = addslashes(diconv(urldecode($_FILES["file"]['name']), 'UTF-8'));
    
    if(!getimagesize($_FILES['file']['tmp_name']) || !$upload->init($_FILES['file'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    
    $outArr = array(
        'code'      => 200,
        'pic'       => $upload->attach['attachment'],
        'picurl'    => $picurl,
    );
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'tcshop_photolist' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $upload = new tom_upload();
    $_FILES["file"]['name'] = addslashes(diconv(urldecode($_FILES["file"]['name']), 'UTF-8'));
    
    if(!getimagesize($_FILES['file']['tmp_name']) || !$upload->init($_FILES['file'], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
        echo 'NO|url';exit;
    }
    
    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$upload->attach['attachment'];
    
    ## thumb start
    $imageData = file_get_contents($upload->attach['target']);
    $imageDir = "/source/plugin/tom_tcshop/data/photo/".date("Ym")."/";
    $imageName = "source/plugin/tom_tcshop/data/photo/".date("Ym")."/".md5($upload->attach['attachment']).".jpg";

    $tomDir = DISCUZ_ROOT.'.'.$imageDir;
    if(!is_dir($tomDir)){
        mkdir($tomDir, 0777,true);
    }else{
        chmod($tomDir, 0777);
    }
    file_put_contents(DISCUZ_ROOT.'./'.$imageName, $imageData);
    
    require_once libfile('class/image');
    $image = new image();
    $image->Thumb(DISCUZ_ROOT.'./'.$imageName,'', 720, 324, 2, 1);
    ## thumb end
    
    $outArr = array(
        'code'      => 200,
        'pic'       => $upload->attach['attachment'],
        'thumb_pic' => $imageName,
        'picurl'    => $picurl,
    );
    echo json_encode($outArr); exit;
    
}else{
    echo 1;exit;
}