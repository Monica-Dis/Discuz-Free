<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);

$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
$tomSysOffset = getglobal('setting/timeoffset');

$fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
if($fangchanSetting && $fangchanSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_setting')->insert($insertData);
    $fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
}

$showQrcode = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
    $showQrcode = 1;
    include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
}

$tempDir = "/source/plugin/tom_tcfangchan/data/infoqrcode/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0755); 
}

include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/config/config.data.php';

$colorArr = array();
$colorArr[1] = 'rgb(236, 75, 10)';
$colorArr[2] = 'rgb(234, 186, 0)';
$colorArr[3] = 'rgb(31, 199, 3)';
$colorArr[4] = 'rgb(3, 199, 137)';
$colorArr[5] = 'rgb(3, 143, 199)';

$page        = isset($_GET['page'])? intval($_GET['page']):1;
$day_type    = isset($_GET['day_type'])? intval($_GET['day_type']):1;
$days        = isset($_GET['days'])? intval($_GET['days']):0;
$source_type = isset($_GET['source_type'])? intval($_GET['source_type']):0;
$model_id    = isset($_GET['model_id'])? addslashes($_GET['model_id']):'ershoufang';
$dao_tel     = isset($_GET['dao_tel'])? intval($_GET['dao_tel']):0;
$dao_type    = isset($_GET['dao_type'])? intval($_GET['dao_type']):0;
$from        = isset($_GET['from'])? addslashes($_GET['from']):'';

$site_ids   = isset($_GET['site_ids'])? addslashes($_GET['site_ids']):'';
$site_ids_tmp = explode('_', $site_ids);
$site_ids_arr = array();
if(is_array($site_ids_tmp) && !empty($site_ids_tmp)){
    foreach ($site_ids_tmp as $key => $value){
        $value = intval($value);
        if($value > 0){
            $site_ids_arr[] = $value;
        }
    }
}

$where = " AND shenhe_status = 1 AND status = 1  AND finish = 0 AND ((pay_status = 0) OR (pay_status = 2)) AND ((expire_status = 1 AND expire_time > ".TIMESTAMP.") OR (expire_status = 3)) ";

if(!empty($site_ids_arr)){
    $where.= " AND site_id IN (".implode(',',$site_ids_arr).") ";
}
if(!empty($model_id)){
    $where.= " AND model_id = '{$model_id}' ";
}

if($days > 0){
    $minTime = TIMESTAMP - $days * 86400;
    if($day_type == 1){
        $where.= " AND (refresh_time > {$minTime} OR top_status = 1 ) ";
    }else{
        $where.= " AND (add_time > {$minTime} OR top_status = 1 ) ";
    }
}

if($source_type > 0){
    $where.= " AND source_type ={$source_type} ";
}

$order = " ORDER BY top_status DESC,refresh_time DESC,id DESC ";
if($day_type == 2){
    $order = " ORDER BY top_status DESC,add_time DESC,id DESC ";
}

$pagesize = 1000;
$start = ($page-1)*$pagesize;
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$quanXianStatus = false;
if($from == 'tom_admin'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_pc.php';
    $adminConfig = $_G['cache']['plugin']['tom_admin'];
    if(!empty($adminConfig['manage_user_id']) && $adminConfig['manage_user_id'] == $__UserInfo['id']){
        $quanXianStatus = true;
    }else{
        $addminManagerInfo = C::t("#tom_admin#tom_admin_manager")->fetch_by_user_id($__UserInfo['id']);
        if(empty($addminManagerInfo)){
            include template("tom_admin:error");exit;
        }
        
        $powerListTmp = C::t("#tom_admin#tom_admin_role_power")->fetch_all_list(" AND plugin_id = 'fangchan' AND role_id={$addminManagerInfo['role_id']} ", "ORDER BY id ASC");
        if(!empty($powerListTmp)){
            foreach($powerListTmp as $key => $value){
                $powerList[] = $value['type'];
            }
        }
        
        if(in_array('list', $powerList)){
            $quanXianStatus = true;
        }
        
    }
}else{
    if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
        $quanXianStatus = true;
    }
}

if($quanXianStatus === true){
    
    $fangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($where,$order,$start,$pagesize);
    $fangchanList = array();
    foreach ($fangchanListTmp as $key => $value) {
        $fangchanList[$key] = $value;
        
        $attrInfo = C::t('#tom_tcfangchan#tom_tcfangchan_attr')->fetch_by_tcfangchan_id($value['id']);
        
        if($value['site_id'] == 1){
            $fangchanList[$key]['site_id'] = $tongchengConfig['plugin_name'];
        }else if($value['site_id'] == 1){
            $siteList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
            $fangchanList[$key]['site_id'] = $value['name'];
        }
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $fangchanList[$key]['user_id'] = $userInfo['nickname'].'(ID:'.$value['user_id'].')';
        
        $fangchanList[$key]['quyu'] = $value['area_name'] .'-'.$value['street_name'];
        
        $fangchanList[$key]['model_id'] = lang('plugin/tom_tcfangchan',$value['model_id']);
        
        if($value['trade_id'] > 0){ 
            $tradeInfo = C::t('#tom_tcfangchan#tom_tcfangchan_trade')->fetch_by_id($value['trade_id']);
            $fangchanList[$key]['trade_name'] = $tradeInfo['name'];
        }else{
            $fangchanList[$key]['trade_name'] = lang('plugin/tom_tcfangchan','doDao_trade_name_no');
        }
        
        $fangchanList[$key]['fangchan_nature'] = '';
        if($value['fangchan_nature'] == 1){
            $fangchanList[$key]['fangchan_nature'] = lang('plugin/tom_tcfangchan','doDao_fangchan_nature_1');
        }else if($value['fangchan_nature'] == 2){
            $fangchanList[$key]['fangchan_nature'] = lang('plugin/tom_tcfangchan','doDao_fangchan_nature_2');
        }else if($value['fangchan_nature'] == 3){
            $fangchanList[$key]['fangchan_nature'] = lang('plugin/tom_tcfangchan','doDao_fangchan_nature_3');
        }
        
        if($value['source_type'] == 1){
            $fangchanList[$key]['source_type'] = lang('plugin/tom_tcfangchan','doDao_source_type_1');
        }else if($value['source_type'] == 2){
            $fangchanList[$key]['source_type'] = lang('plugin/tom_tcfangchan','doDao_source_type_2');
        }
        
        if($attrInfo['attr_zhuangxiu_type'] > 0){
            $fangchanList[$key]['attr_zhuangxiu_type']  = $zhuangxiuTypeArr[$attrInfo['attr_zhuangxiu_type']];
        }else{
            $fangchanList[$key]['attr_zhuangxiu_type']  = '-';
        }
        if($attrInfo['attr_house_type'] > 0){
            $fangchanList[$key]['attr_house_type']      = $houseTypeArr[$attrInfo['attr_house_type']];
        }else{
            $fangchanList[$key]['attr_house_type']      = '-';
        }
        if($attrInfo['attr_chaoxiang_type'] > 0){
            $fangchanList[$key]['attr_chaoxiang_type']  = $chaoxiangTypeArr[$attrInfo['attr_chaoxiang_type']];
        }else{
            $fangchanList[$key]['attr_chaoxiang_type']  = '-';
        }
        
        $fangchanList[$key]['attr_huxing']          = $attrInfo['attr_shi'].lang('plugin/tom_tcfangchan','shi').$attrInfo['attr_ting'].lang('plugin/tom_tcfangchan','ting').$attrInfo['attr_wei'].lang('plugin/tom_tcfangchan','wei');
        if($attrInfo['attr_louceng'] > 0){
            $fangchanList[$key]['attr_louceng']         = $attrInfo['attr_louceng'].lang('plugin/tom_tcfangchan','lou').lang('plugin/tom_tcfangchan','gong').$attrInfo['attr_cengshu'].lang('plugin/tom_tcfangchan','ceng');
        }else{
            $fangchanList[$key]['attr_louceng']         = '-';
        }
        if($attrInfo['attr_rent_type'] > 0){
            $fangchanList[$key]['attr_rent_type']       = $rentTypeArr[$attrInfo['attr_rent_type']];
        }else{
            $fangchanList[$key]['attr_rent_type']       = '-';
        }
        if($attrInfo['attr_shangpu_type'] > 0){
            $fangchanList[$key]['attr_shangpu_type']    = $shangpuTypeArr[$attrInfo['attr_shangpu_type']];
        }else{
            $fangchanList[$key]['attr_shangpu_type']    = '-';
        }
        
        if($attrInfo['attr_lease_type'] == 1){
            $fangchanList[$key]['attr_lease_type'] = lang('plugin/tom_tcfangchan','doDao_attr_lease_type_1');
        }else if($attrInfo['attr_lease_type'] == 2){
            $fangchanList[$key]['attr_lease_type'] = lang('plugin/tom_tcfangchan','doDao_attr_lease_type_2');
        }else{
            $fangchanList[$key]['attr_lease_type'] = '-';
        }
        
        if($attrInfo['attr_elevator'] == 1){
            $fangchanList[$key]['attr_elevator'] = lang('plugin/tom_tcfangchan','doDao_attr_elevator_1');
        }else if($attrInfo['attr_elevator'] == 2){
            $fangchanList[$key]['attr_elevator'] = lang('plugin/tom_tcfangchan','doDao_attr_elevator_2');
        }else{
            $fangchanList[$key]['attr_elevator'] = '-';
        }
        if($attrInfo['attr_chanquan'] > 0){
            $fangchanList[$key]['attr_chanquan'] = $attrInfo['attr_chanquan'].lang('plugin/tom_tcfangchan','year');
        }else{
            $fangchanList[$key]['attr_chanquan'] = '-';
        }
        $fangchanList[$key]['attr_tese_tags'] = str_replace('|', '-',trim($attrInfo['attr_tese_tags'], '|'));;
        
        $infoqrcodeUrl = '';
        if($showQrcode == 1){
            $infoUrlTmp = $_G['siteurl'].'plugin.php?id=tom_tcfangchan&site='.$value['site_id'].'&mod=info&tcfangchan_id='.$value['id'];
            $infoqrcodeUrl = 'source/plugin/tom_tcfangchan/data/infoqrcode/'.md5($infoUrlTmp).'.png';
            $infoqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/data/infoqrcode/'.md5($infoUrlTmp).'.png';
            if(file_exists($infoqrcodeImg)){
            }else{
                QRcode::png($infoUrlTmp,$infoqrcodeImg,'H',5,2);
            }
        }
        $fangchanList[$key]['qrcode'] = $infoqrcodeUrl;
    }
    
    $doDao_site_id = lang('plugin/tom_tcfangchan','sites_title');
    $doDao_title = lang('plugin/tom_tcfangchan','doDao_fangchan_title');
    $doDao_user_id = lang('plugin/tom_tcfangchan','user_id');
    $doDao_source_type = lang('plugin/tom_tcfangchan','doDao_source_type');
    $doDao_model_id = lang('plugin/tom_tcfangchan','doDao_model_id');
    $doDao_houses_name = lang('plugin/tom_tcfangchan','doDao_houses_name');
    $doDao_trade_name = lang('plugin/tom_tcfangchan','doDao_trade_name');
    $doDao_quyu = lang('plugin/tom_tcfangchan','doDao_quyu');
    $doDao_mianji = lang('plugin/tom_tcfangchan','doDao_mianji');
    $doDao_price = lang('plugin/tom_tcfangchan','doDao_price');
    $doDao_rent = lang('plugin/tom_tcfangchan','doDao_rent');
    $doDao_zhuanrang_price = lang('plugin/tom_tcfangchan','doDao_zhuanrang_price');
    $doDao_fangchan_nature = lang('plugin/tom_tcfangchan','doDao_fangchan_nature');
    $doDao_address = lang('plugin/tom_tcfangchan','doDao_address');
    $doDao_xm = lang('plugin/tom_tcfangchan','doDao_xm');
    $doDao_tel = lang('plugin/tom_tcfangchan','doDao_tel');
    $doDao_attr_zhuangxiu_type = lang('plugin/tom_tcfangchan','doDao_attr_zhuangxiu_type');
    $doDao_attr_house_type = lang('plugin/tom_tcfangchan','doDao_attr_house_type');
    $doDao_attr_chaoxiang_type = lang('plugin/tom_tcfangchan','doDao_attr_chaoxiang_type');
    $doDao_attr_huxing = lang('plugin/tom_tcfangchan','doDao_attr_huxing');
    $doDao_attr_louceng = lang('plugin/tom_tcfangchan','doDao_attr_louceng');
    $doDao_attr_chanquan = lang('plugin/tom_tcfangchan','doDao_attr_chanquan');
    $doDao_attr_elevator = lang('plugin/tom_tcfangchan','doDao_attr_elevator');
    $doDao_attr_tese_tags = lang('plugin/tom_tcfangchan','doDao_attr_tese_tags');
    $doDao_attr_lease_type = lang('plugin/tom_tcfangchan','doDao_attr_lease_type');
    $doDao_attr_rent_type = lang('plugin/tom_tcfangchan','doDao_attr_rent_type');
    $doDao_attr_peitao_tags = lang('plugin/tom_tcfangchan','doDao_attr_peitao_tags');
    
    if($dao_type == 1){

        $listData = array();
        if($model_id == 'ershoufang'){

            $listData[] = array(
                'ID',
                $doDao_site_id,
                $doDao_title,
                $doDao_user_id,
                $doDao_source_type,
                $doDao_model_id,
                $doDao_houses_name,
                $doDao_trade_name,
                $doDao_price,
                $doDao_mianji,
                $doDao_quyu,
                $doDao_address,
                $doDao_xm,
                $doDao_tel,
                $doDao_attr_zhuangxiu_type,
                $doDao_attr_house_type,
                $doDao_attr_chaoxiang_type,
                $doDao_attr_huxing,
                $doDao_attr_louceng,
                $doDao_attr_chanquan,
                $doDao_attr_elevator,
                $doDao_attr_tese_tags,
            ); 
            foreach ($fangchanList as $v){
                $lineData = array();
                $lineData[] = $v['id'];
                $lineData[] = $v['site_id'];
                $lineData[] = $v['title'];
                $lineData[] = $v['user_id'];
                $lineData[] = $v['source_type'];
                $lineData[] = $v['model_id'];
                $lineData[] = $v['houses_name'];
                $lineData[] = $v['trade_name'];
                $lineData[] = $v['price'];
                $lineData[] = $v['mianji'];
                $lineData[] = $v['quyu'];
                $v['address'] = str_replace("\r\n", "", $v['address']);
                $v['address'] = str_replace("\n", "", $v['address']);
                $lineData[] = $v['address'];
                $lineData[] = $v['xm'];
                $lineData[] = "'".$v['tel'];
                $lineData[] = $v['attr_zhuangxiu_type'];
                $lineData[] = $v['attr_house_type'];
                $lineData[] = $v['attr_chaoxiang_type'];
                $lineData[] = $v['attr_huxing'];
                $lineData[] = $v['attr_louceng'];
                $lineData[] = $v['attr_chanquan'];
                $lineData[] = $v['attr_elevator'];
                $lineData[] = $v['attr_tese_tags'];
                $listData[] = $lineData;
            }
        }else if($model_id == 'chuzu'){

            $listData[] = array(
                'ID',
                $doDao_site_id,
                $doDao_title,
                $doDao_user_id,
                $doDao_source_type,
                $doDao_model_id,
                $doDao_houses_name,
                $doDao_trade_name,
                $doDao_rent,
                $doDao_mianji,
                $doDao_quyu,
                $doDao_address,
                $doDao_xm,
                $doDao_tel,
                $doDao_attr_zhuangxiu_type,
                $doDao_attr_house_type,
                $doDao_attr_chaoxiang_type,
                $doDao_attr_huxing,
                $doDao_attr_louceng,
                $doDao_attr_lease_type,
                $doDao_attr_rent_type,
                $doDao_attr_tese_tags,
                $doDao_attr_peitao_tags,
            );
            foreach ($fangchanList as $v){
                $lineData = array();
                $lineData[] = $v['id'];
                $lineData[] = $v['site_id'];
                $lineData[] = $v['title'];
                $lineData[] = $v['user_id'];
                $lineData[] = $v['source_type'];
                $lineData[] = $v['model_id'];
                $lineData[] = $v['houses_name'];
                $lineData[] = $v['trade_name'];
                $lineData[] = $v['rent'];
                $lineData[] = $v['mianji'];
                $lineData[] = $v['quyu'];
                $v['address'] = str_replace("\r\n", "", $v['address']);
                $v['address'] = str_replace("\n", "", $v['address']);
                $lineData[] = $v['address'];
                $lineData[] = $v['xm'];
                $lineData[] = "'".$v['tel'];
                $lineData[] = $v['attr_zhuangxiu_type'];
                $lineData[] = $v['attr_house_type'];
                $lineData[] = $v['attr_chaoxiang_type'];
                $lineData[] = $v['attr_huxing'];
                $lineData[] = $v['attr_louceng'];
                $lineData[] = $v['attr_lease_type'];
                $lineData[] = $v['attr_rent_type'];
                $lineData[] = $v['attr_tese_tags'];
                $lineData[] = $v['attr_peitao_tags'];
                $listData[] = $lineData;
            }

        }else if($model_id == 'shangpu' || $model_id == 'xiezilou' || $model_id == 'changfang' || $model_id == 'cangku' || $model_id == 'tudi'){

            $listData[] = array(
                'ID',
                $doDao_site_id,
                $doDao_title,
                $doDao_user_id,
                $doDao_source_type,
                $doDao_model_id,
                $doDao_trade_name,
                $doDao_fangchan_nature,
                $doDao_price,
                $doDao_rent,
                $doDao_zhuanrang_price,
                $doDao_mianji,
                $doDao_quyu,
                $doDao_address,
                $doDao_xm,
                $doDao_tel,
                $doDao_attr_rent_type,
                $doDao_attr_tese_tags,
            );
            foreach ($fangchanList as $v){
                $lineData = array();
                $lineData[] = $v['id'];
                $lineData[] = $v['site_id'];
                $lineData[] = $v['title'];
                $lineData[] = $v['user_id'];
                $lineData[] = $v['source_type'];
                $lineData[] = $v['model_id'];
                $lineData[] = $v['trade_name'];
                $lineData[] = $v['fangchan_nature'];
                if(!empty($v['price'])){
                    $lineData[] = $v['price'];
                }else{
                    $lineData[] = '--';
                }
                if(!empty($v['rent'])){
                    $lineData[] = $v['rent'];
                }else{
                    $lineData[] = '--';
                }
                if(!empty($v['zhuanrang_price'])){
                    $lineData[] = $v['zhuanrang_price'];
                }else{
                    $lineData[] = '--';
                }
                if(!empty($v['mianji'])){
                    $lineData[] = $v['mianji'];
                }else{
                    $lineData[] = '--';
                }
                $lineData[] = $v['quyu'];
                $v['address'] = str_replace("\r\n", "", $v['address']);
                $v['address'] = str_replace("\n", "", $v['address']);
                $lineData[] = $v['address'];
                $lineData[] = $v['xm'];
                $lineData[] = "'".$v['tel'];
                if(!empty($v['attr_rent_type'])){
                    $lineData[] = $v['attr_rent_type'];
                }else{
                    $lineData[] = '--';
                }
                $lineData[] = $v['attr_tese_tags'];
                $listData[] = $lineData;
            }

        }

        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition:filename=exportFangchan.xls");

        foreach ($listData as $fields){
            foreach ($fields as $k=> $v){
                $str = @diconv("$v",CHARSET,"GB2312");
                echo $str ."\t";
            }
            echo "\n";
        }
        exit;
        
    }else if($dao_type == 2){
        
        $fenhao = lang('plugin/tom_tcfangchan', 'fenghao');
        
        if (CHARSET == 'gbk'){
            $outStr = '<meta charset="gbk" /> ';
        }else{
            $outStr = '<meta charset="utf-8" /> ';
        }
        $outStr.= '<section style="font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px;">';
             $outStr.= '<p style="white-space: normal;"><br /></p> ';
             $outStr.= '<p style="max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);">';
               $outStr.= '<span style="max-width: 100%; color: rgb(255, 255, 255); box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(236, 101, 5);">'.lang('plugin/tom_tongcheng', 'doDao_msg1').'</span>';
             $outStr.= '</p> ';
             $outStr.= '<p style="max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);"> ';
               $outStr.= '<span style="max-width: 100%; color: rgb(255, 255, 255); box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(236, 101, 5);">'.lang('plugin/tom_tongcheng', 'doDao_msg2').'</span> ';
             $outStr.= '</p> ';
             $outStr.= '<p style="max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);">'; 
               $outStr.= '<span style="max-width: 100%; color: rgb(236, 101, 5); font-size: 12px; line-height: 19.2px; box-sizing: border-box !important; word-wrap: break-word !important;">'.lang('plugin/tom_tongcheng', 'doDao_jian').'</span> ';
             $outStr.= '</p> ';
             $outStr.= '<p style="margin: 0px;max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);">';
               $outStr.= '<img style="max-width: 60%;" src="'.$tongchengConfig['fwh_qrcode'].'"/>';
             $outStr.= '</p> <br /> ';
        $outStr.= '</section> ';

        $outStr.= '<section style="margin: 2em 0em; padding: 0.5em 0.8em; white-space: normal; border: 1px solid '.$colorArr[1].';border-radius: 6px; font-size: 1em; font-family: inherit; font-weight: inherit; text-decoration: inherit; color: rgb(166, 166, 166); background-color: rgb(255, 255, 255);"> ';
            $outStr.= '<section style="margin-top: -1.4em; text-align: center; border: none; line-height: 1.4;"> ';
               $outStr.= '<section style="padding-right: 24px; padding-left: 24px; color: '.$colorArr[1].'; font-size: 30px; font-family: inherit; text-decoration: inherit; border-color: rgb(255, 255, 255); display: inline-block; background-color: rgb(254, 255, 255); "> ';
                  $outStr.= '<section>'.lang('plugin/tom_tcfangchan', $model_id).'</section> ';
               $outStr.= '</section> ';
            $outStr.= '</section> ';
            $outStr.= '<section style="padding: 16px 0px; color: rgb(32, 32, 32); line-height: 2; font-family: inherit;"> ';
            
            $color_i = 2;
            foreach ($fangchanList as $key => $value){
                $title = lang('plugin/tom_tongcheng', 'doDao_left').$value['title'].lang('plugin/tom_tongcheng', 'doDao_right');
                $top_status_text = '';
                if($value['top_status'] == 1 && $value['top_time'] > TIMESTAMP){
                    $top_status_text = '<span style="color:#f00;">'.lang('plugin/tom_tongcheng', 'doDao_left').lang('plugin/tom_tongcheng', 'doDao_top_title').lang('plugin/tom_tongcheng', 'doDao_right').'</span>';
                }
                
                $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                    $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;"><span style="color: '.$colorArr[$color_i].';">'.lang('plugin/tom_tongcheng', 'doDao_jian').$top_status_text.$title.'</span></span> ';
                $outStr.= '</p> ';
                
                if($value['houses_id'] > 0){
                    $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                        $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$doDao_houses_name.$fenhao.$value['houses_name'].'</span> ';
                    $outStr.= '</p> ';
                }
                
                if($model_id == 'ershoufang'){
                
                    $houses_price_text = lang('plugin/tom_tcfangchan', 'doDao_houses_price').$fenhao.$value['mianji'].lang('plugin/tom_tcfangchan', 'pingmi').'/'.$value['price'].lang('plugin/tom_tcfangchan', 'price_unit');
                    $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                        $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$houses_price_text.'</span> ';
                    $outStr.= '</p> ';
                    
                    $houses_attr_text = lang('plugin/tom_tcfangchan', 'doDao_houses_huxing').$fenhao.$value['attr_huxing'];
                    $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                        $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$houses_attr_text.'</span> ';
                    $outStr.= '</p> ';
                    
                }else if($model_id == 'chuzu'){
                    
                    $houses_price_text = lang('plugin/tom_tcfangchan', 'doDao_houses_rent').$fenhao.$value['rent'].lang('plugin/tom_tcfangchan', 'yuan');
                    $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                        $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$houses_price_text.'</span> ';
                    $outStr.= '</p> ';
                    
                    $houses_attr_text = lang('plugin/tom_tcfangchan', 'doDao_houses_huxing').$fenhao.$value['attr_huxing'];
                    $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                        $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$houses_attr_text.'</span> ';
                    $outStr.= '</p> ';
                    
                }else{
                    
                    $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                        $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$doDao_fangchan_nature.$fenhao.$value['fangchan_nature'].'</span> ';
                    $outStr.= '</p> ';
                    if(!empty($value['rent'])){
                        $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                            $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$doDao_rent.$fenhao.$value['rent'].'</span> ';
                        $outStr.= '</p> ';
                    }else if(!empty($value['price'])){
                        $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                            $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$doDao_price.$fenhao.$value['price'].'</span> ';
                        $outStr.= '</p> ';
                    }else if(!empty($value['zhuanrang_price'])){
                        $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                            $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$doDao_zhuanrang_price.$fenhao.$value['zhuanrang_price'].'</span> ';
                        $outStr.= '</p> ';
                    }
                }
                
                if($dao_tel == 1){
                    $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                        $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$doDao_tel.$fenhao.$value['tel'].'</span> ';
                    $outStr.= '</p> ';
                }
                $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                    $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$doDao_address.$fenhao.$value['address'].'</span> ';
                $outStr.= '</p> ';
                
                if(!empty($value['qrcode'])){
                    $outStr.= '<span style="display: block;text-align: center;"><img style="width:120px;" src="'.$value['qrcode'].'"/></span> ';
                    $outStr.= '<span style="display: block;text-align: center;color:#999;font-size: 12px;">'.lang('plugin/tom_tongcheng', 'doDao_qrcode_msg').'</span> ';
                }
                
                $color_i++;
                if($color_i == 6){
                    $color_i = 1;
                }
            }
            $outStr.= '</section>';
        $outStr.= '</section>';
        
        $doDao_msg3 = lang('plugin/tom_tongcheng', 'doDao_msg3');
        $doDao_msg3 = str_replace('{SITENAME}', $tongchengConfig['plugin_name'], $doDao_msg3);
        $outStr.= '<span style="color:#999;font-size: 14px;"><span style="color:red"> '.lang('plugin/tom_tongcheng', 'doDao_msg_mz').'</span><br /> '.$doDao_msg3.'</span><br /><br />';
        
        echo $outStr;
        exit;
    }
}else{
    exit('Access Denied');
}