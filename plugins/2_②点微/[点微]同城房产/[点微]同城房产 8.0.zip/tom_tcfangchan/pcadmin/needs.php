<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=needs";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'refresh' && submitcheck('needs_id')){
    $outArr = array(
        'code'=> 1,
    );

    $needs_id   = intval($_GET['needs_id'])>0 ? intval($_GET['needs_id']):0;

    $updateData = array();
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($needs_id,$updateData);
    
    update_needs_tongcheng($needs_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('needs_id')){
    $outArr = array(
        'code'=> 1,
    );

    $needs_id   = intval($_GET['needs_id'])>0 ? intval($_GET['needs_id']):0;

    $updateData = array();
    $updateData['status']     = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($needs_id,$updateData);
    
    update_needs_tongcheng($needs_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('needs_id')){
    $outArr = array(
        'code'=> 1,
    );

    $needs_id   = intval($_GET['needs_id'])>0 ? intval($_GET['needs_id']):0;
    
    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($needs_id,$updateData);
    
    update_needs_tongcheng($needs_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'edittop' && submitcheck('needs_id')){
    $outArr = array(
        'code'=> 1,
    );

    $needs_id        = intval($_GET['needs_id'])>0 ? intval($_GET['needs_id']):0;
    $top_time        = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
    $top_time        = strtotime($top_time);
        
    $updateData = array();
    
    if($top_time <= TIMESTAMP){
        $updateData['top_status'] = 0;
        $updateData['top_time']   = 0;
    }else{
        $updateData['top_status']   = 1;
        $updateData['refresh_time'] = TIMESTAMP;
        $updateData['top_time']     = $top_time;
    }
    
    C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($needs_id, $updateData);
    
    update_needs_tongcheng($needs_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'del' && submitcheck('needs_id')){
    $outArr = array(
        'code'=> 1,
    );

    $needs_id = intval($_GET['needs_id'])>0 ? intval($_GET['needs_id']):0;
    
    C::t('#tom_tcfangchan#tom_tcfangchan_needs')->delete_by_id($needs_id);
    
    delete_needs_tongcheng($needs_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'edit_pay_status' && submitcheck('needs_id')){
    $outArr = array(
        'code'=> 1,
    );

    $needs_id   = intval($_GET['needs_id'])>0 ? intval($_GET['needs_id']):0;
    
    $updateData = array();
    $updateData['pay_status'] = 2;
    C::t("#tom_tcfangchan#tom_tcfangchan_needs")->update($needs_id, $updateData);
    
    update_needs_tongcheng($needs_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'shenhe' && submitcheck('needs_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $needs_id       = intval($_GET['needs_id'])>0 ? intval($_GET['needs_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $needsInfo = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($needs_id);
    $userInfo  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status']    = 1;
        $updateData['status']           = 1;
        C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($needs_id,$updateData);
        
        update_needs_tongcheng($needs_id);
        
        $shenhe = str_replace('{CONTENT}', $needsInfo['content'], $Lang['template_needs_shenhe_ok']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$needsInfo['site_id'].'&mod=needsinfo&needs_id='.$needsInfo['id'].'">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$needsInfo['site_id']}&mod=needsinfo&needs_id=".$needsInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }

        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($needs_id,$updateData);
        
        update_needs_tongcheng($needs_id);
        
        $shenhe = str_replace('{CONTENT}', $needsInfo['content'], $Lang['template_needs_shenhe_no']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$needsInfo['site_id'].'&mod=edit_needs&needs_id='.$needsInfo['id'].'">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$needsInfo['site_id']}&mod=edit_needs&needs_id=".$needsInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}elseif($act == 'edit_expire_time' && submitcheck('needs_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $needs_id           = isset($_GET['needs_id'])? intval($_GET['needs_id']):0;
    $expire_time        = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time        = strtotime($expire_time);
    
    $updateData = array();
    if($expire_time < TIMESTAMP){
        $updateData['expire_status']    = 2;
        $updateData['expire_time']      = 0;
        $updateData['status']           = 0;
    }else{
        $updateData['expire_status']    = 1;
        $updateData['refresh_time']     = TIMESTAMP;
        $updateData['expire_time']      = $expire_time;
    }
    C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($needs_id,$updateData);

    update_needs_tongcheng($needs_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_refresh' && submitcheck('needs_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $needsIdsArr = array();
    if(is_array($_GET['needs_ids'])){
        foreach($_GET['needs_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $needsIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($needsIdsArr)){
        foreach($needsIdsArr as $key => $value){
            $updateData = array();
            $updateData['refresh_time'] = TIMESTAMP;
            C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($value, $updateData);
            update_needs_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'batch_shenhe1' && submitcheck('needs_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $needsIdsArr = array();
    if(is_array($_GET['needs_ids'])){
        foreach($_GET['needs_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $needsIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($needsIdsArr)){
        $needsIdsStr = implode(',', $needsIdsArr);
        $needsListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_needs")->fetch_all_list(" AND id IN({$needsIdsStr}) ", 'ORDER BY id DESC', 0, 100);
        $userIdsArr = array();
        foreach($needsListTmp as $key => $value){
            
            $userIdsArr[] = $value['user_id'];
            
            $updateData = array();
            $updateData['shenhe_status'] = 1;
            $updateData['status']        = 1;
            C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($value['id'], $updateData);
            
            update_needs_tongcheng($value['id']);
        }
        
        if(!empty($tongchengConfig['template_id'])){
            $userIdsStr = implode(',', $userIdsArr);
            $userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            foreach($userListTmp as $key => $value){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($value['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfabu_needs");
                    $smsData = array(
                        'first'         => $Lang['shenhe_needs_succ_msg'],
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($value['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_shenhe3' && submitcheck('needs_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $needsIdsArr = array();
    if(is_array($_GET['needs_ids'])){
        foreach($_GET['needs_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $needsIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($needsIdsArr)){
        $needsIdsStr = implode(',', $needsIdsArr);
        $needsListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_needs")->fetch_all_list(" AND id IN({$needsIdsStr}) ", 'ORDER BY id DESC', 0, 100);
        $userIdsArr = array();
        foreach($needsListTmp as $key => $value){
            
            $userIdsArr[] = $value['user_id'];
            
            $updateData = array();
            $updateData['shenhe_status'] = 3;
            C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($value['id'], $updateData);
                        
            update_needs_tongcheng($value['id']);
        }
        
        if(!empty($tongchengConfig['template_id'])){
            $userIdsStr = implode(',', $userIdsArr);
            $userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            foreach($userListTmp as $key => $value){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($value['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfabu_needs");
                    $smsData = array(
                        'first'         => $Lang['shenhe_needs_fail_msg'],
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($value['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('needs_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $needsIdsArr = array();
    if(is_array($_GET['needs_ids'])){
        foreach($_GET['needs_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $needsIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($needsIdsArr)){
        foreach($needsIdsArr as $key => $value){
            C::t('#tom_tcfangchan#tom_tcfangchan_needs')->delete_by_id($value);
            
            delete_needs_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_show' && submitcheck('needs_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $needsIdsArr = array();
    if(is_array($_GET['needs_ids'])){
        foreach($_GET['needs_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $needsIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($needsIdsArr)){
        foreach($needsIdsArr as $key => $value){
            
            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($value,$updateData);
            
            update_needs_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_hide' && submitcheck('needs_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $needsIdsArr = array();
    if(is_array($_GET['needs_ids'])){
        foreach($_GET['needs_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $needsIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($needsIdsArr)){
        foreach($needsIdsArr as $key => $value){
            
            $updateData = array();
            $updateData['status'] = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($value,$updateData);
            
            update_needs_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$needs_id           = isset($_GET['needs_id'])? intval($_GET['needs_id']):0;
$area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
$street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
$status             = isset($_GET['status'])? intval($_GET['status']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
$pay_status         = isset($_GET['pay_status'])? intval($_GET['pay_status']):0;
$expire_status      = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$__CityInfo  = array('id'=>0,'name'=>'');
if($site_id > 1){
    $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
    if($sitesInfoTmp){
        $__SitesInfo = $sitesInfoTmp;
        if(!empty($__SitesInfo['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
            if($cityInfoTmp){
                $__CityInfo = $cityInfoTmp;
            }
        }
    }
}else if($site_id == 1){
    $cityInfoTmp = array();
    if(!empty($tongchengConfig['city_id'])){
        $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
    }
    if(!empty($cityInfoTmp)){
        $__CityInfo = $cityInfoTmp;
    }
}
$areaList   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);

$whereStr = '';
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}
if(!empty($needs_id)){
    $whereStr.= " AND id={$needs_id} ";
}
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}
if($area_id > 0){
    $whereStr.= " AND area_id='{$area_id}' ";
}
if($street_id > 0){
    $whereStr.= " AND street_id='{$street_id}' ";
}
if(!empty($status)){
    if($status == 1){
        $whereStr.= " AND status=1 ";
    }else if($status == 2){
        $whereStr.= " AND status != 1 ";
    }
}
if($pay_status > 0){
    $whereStr.= " AND pay_status = {$pay_status} ";
}
if(!empty($shenhe_status)){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}
if($top_status > 0){
    if($top_status == 1){
        $whereStr.= " AND top_status = 1 ";
    }else if($top_status == 2){
        $whereStr.= " AND top_status = 0 ";
    }
}
if($expire_status > 0){
    if($expire_status == 1){
        $whereStr.= " AND ((expire_status = 1 AND expire_time > ".TIMESTAMP.") OR (expire_status = 3)) ";
    }else if($expire_status == 2){
        $whereStr.= " AND expire_status = 2 ";
    }
}

$order = "ORDER BY id DESC";

$start         = ($page - 1)*$pagesize;
$count         = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_count($whereStr);
$needsListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_list($whereStr,$order,$start,$pagesize);
$needsList = array();
if(!empty($needsListTmp)){
    foreach ($needsListTmp as $key => $value) {
        $needsList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        $siteInfoTmp = $sitesList[$value['site_id']];
        
        $needsList[$key]['userInfo']              = $userInfoTmp;
        $needsList[$key]['siteInfo']              = $siteInfoTmp;
        $needsList[$key]['top_time']              = dgmdate($value['top_time'],"Y-m-d H:i",$tomSysOffset);
        $needsList[$key]['refresh_time']          = dgmdate($value['refresh_time'],"Y-m-d H:i",$tomSysOffset);
        $needsList[$key]['add_time']              = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $needsList[$key]['expire_time']           = dgmdate($value['expire_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&site_id={$site_id}&area_id={$area_id}&street_id={$street_id}&status={$status}&shenhe_status={$shenhe_status}&top_status={$top_status}&pay_status={$pay_status}&expire_status={$expire_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/needs");