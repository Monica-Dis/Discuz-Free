<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$adviser_id  = intval($_GET['adviser_id'])>0? intval($_GET['adviser_id']):0;
$adviserInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_by_id($adviser_id);

if(empty($adviserInfo)){
    tomheader('location:'.$_G['siteurl']."{$pcadminUrl}&tmod=adviser");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=adviseredit&adviser_id={$adviser_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($_GET['act'] == 'save' && submitcheck('adviser_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
        
    $newhouses_id   = isset($_GET['newhouses_id'])? intval($_GET['newhouses_id']):0;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $sub_desc       = isset($_GET['sub_desc'])? addslashes($_GET['sub_desc']):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $asort          = isset($_GET['asort'])? intval($_GET['asort']):10;
    $avatar         = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $work_picurl    = isset($_GET['work_picurl'])? addslashes($_GET['work_picurl']):'';
    $wx_qrcode      = isset($_GET['wx_qrcode'])? addslashes($_GET['wx_qrcode']):'';
    
    $newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($newhouses_id);
    
    $updateData = array();
    $updateData['site_id']              = $newhousesInfo['site_id'];
    $updateData['user_id']              = $user_id;
    $updateData['newhouses_id']         = $newhouses_id;
    $updateData['newhouses_name']       = $newhousesInfo['name'];
    $updateData['name']                 = $name;
    $updateData['sub_desc']             = $sub_desc;
    $updateData['tel']                  = $tel;
    $updateData['asort']                = $asort;
    $updateData['avatar']               = $avatar;
    $updateData['wx_qrcode']            = $wx_qrcode;
    $updateData['work_picurl']          = $work_picurl;
    
    if(C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->update($adviser_id,$updateData)){
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    } 
}

$avatar      = get_file_url($adviserInfo['avatar']);
$wx_qrcode   = get_file_url($adviserInfo['wx_qrcode']);
$work_picurl = get_file_url($adviserInfo['work_picurl']);

$editUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/adviseredit");