<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$agent_id = intval($_GET['agent_id'])>0 ? intval($_GET['agent_id']):0;

$agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($agent_id);
if(empty($agentInfo)){
    dheader('location:'.$pcadminUrl."&tmod=agent");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=agentedit&agent_id={$agent_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id        = intval($_GET['site_id'])>0? intval($_GET['site_id']):1;
    $mendian_id     = isset($_GET['mendian_id'])? intval($_GET['mendian_id']):0;
    $mendian_name   = isset($_GET['mendian_name'])? addslashes($_GET['mendian_name']):'';
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $avatar         = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $wx_qrcode      = isset($_GET['wx_qrcode'])? addslashes($_GET['wx_qrcode']):'';
    
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($mendian_id);
    
    $updateData = array();
    if($mendianInfo['id'] > 0){
        $updateData['site_id']                  = $mendianInfo['site_id'];
        $updateData['mendian_id']               = $mendian_id;
        $updateData['mendian_name']             = $mendianInfo['name'];
        $updateData['mendian_shenhe_status']    = 1;
        $updateData['mendian_shenhe_id']        = 0;
    }else{
        $updateData['site_id']                  = $site_id;
        $updateData['mendian_id']               = 0;
        $updateData['mendian_name']             = $mendian_name;
        if($agentInfo['mendian_shenhe_status'] != 2){
            $updateData['mendian_shenhe_status']= 0;
            $updateData['mendian_shenhe_id']    = 0;
        }
    }
    $updateData['user_id']            = $user_id;
    $updateData['name']               = $name;
    $updateData['tel']                = $tel;
    $updateData['avatar']             = $avatar;
    $updateData['wx_qrcode']          = $wx_qrcode;
    $updateData['is_ok']              = 1;
    $updateData['part1']              = TIMESTAMP;
    if(C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($agent_id, $updateData)){
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(""," ORDER BY paixu ASC,id DESC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$avatar    = get_file_url($agentInfo['avatar']);
$wx_qrcode = get_file_url($agentInfo['wx_qrcode']);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/agentedit");