<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$mendian_id  = intval($_GET['mendian_id'])>0? intval($_GET['mendian_id']):0;

$mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($mendian_id);

if(empty($mendianInfo)){
    tomheader('location:'.$_G['siteurl']."{$pcadminUrl}&tmod=mendian");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=mendianedit&mendian_id={$mendian_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($_GET['act'] == 'save' && submitcheck('mendian_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
        
    $site_id            = intval($_GET['site_id'])>0? intval($_GET['site_id']):1;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $city_id            = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $lng                = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $business_hours     = isset($_GET['business_hours'])? addslashes($_GET['business_hours']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $shopkeeper_tel     = isset($_GET['shopkeeper_tel'])? addslashes($_GET['shopkeeper_tel']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $logo               = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    $business_licence   = isset($_GET['business_licence'])? addslashes($_GET['business_licence']):'';
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
   
        if(strpos($key, "photosort_") !== false){
            $kk = intval(ltrim($key, "photosort_"));
            $photoArr[$kk]['sort'] = addslashes($value);
        }
    }
    
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    
    $updateData = array();
    $updateData['site_id']          = $site_id;
    $updateData['name']             = $name;
    $updateData['city_id']          = $city_id;
    $updateData['area_id']          = $area_id;
    $updateData['area_name']        = $areaInfo['name'];
    $updateData['street_id']        = $street_id;
    $updateData['street_name']      = $streetInfo['name'];
    $updateData['address']          = $address;
    $updateData['latitude']         = $lat;
    $updateData['longitude']        = $lng;
    $updateData['business_hours']   = $business_hours;
    $updateData['tel']              = $tel;
    $updateData['shopkeeper_tel']   = $shopkeeper_tel;
    $updateData['content']          = $content;
    $updateData['admin_edit']       = 1;
    $updateData['search_text']      = $name.'|++++|'.$tel.'|++++|'.$address;
    $updateData['part1']            = TIMESTAMP;
    
    if(C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendian_id,$updateData)){
        
        update_mendian_tcshop($mendian_id);
        
        C::t("#tom_tcfangchan#tom_tcfangchan_photo")->delete_by_mendian_id($mendianInfo['id']);
        
        if(!empty($logo)){
            $insertData = array();
            $insertData['mendian_id']       = $mendian_id;
            $insertData['type']             = 5;
            $insertData['picurl']           = $logo;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        
        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['mendian_id']   = $mendian_id;
                $insertData['type']         = 6;
                $insertData['picurl']       = $value['picurl'];
                $insertData['psort']        = $value['sort'];
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tcfangchan#tom_tcfangchan_photo')->insert($insertData);
            }
        }
        
        if(!empty($business_licence)){
            $insertData = array();
            $insertData['mendian_id']       = $mendian_id;
            $insertData['type']             = 7;
            $insertData['picurl']           = $business_licence;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    } 
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(""," ORDER BY paixu ASC,id DESC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($mendianInfo['city_id']);
$areaList = array();
if(!empty($areaListTmp)){
    foreach ($areaListTmp as $key => $value){
        $areaList[$value['id']] = $value;
    }
}

$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($mendianInfo['area_id']);
$streetList = array();
if(!empty($streetListTmp)){
    foreach ($streetListTmp as $key => $value){
        $streetList[$value['id']] = $value;
    }
}

$mendianInfo['content']    = stripcslashes($mendianInfo['content']);

$photoListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list(" AND mendian_id={$mendianInfo['id']} AND type IN (5,6,7) "," ORDER BY type DESC,psort ASC,id ASC ",0,20);
$photoList =  array();
$logo = $logo_picurl = $business_licence = $business_licence_picurl = '';
$photoCount  = 0;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];
        if($value['type'] == 5){
            $logo = $value['picurl'];
            $logo_picurl = $value['picurlTmp'];
        }else if($value['type'] == 6){
            $photoList[$key] = $value;
            $photoList[$key]['picurlTmp'] = $picurlTmp;
            $photoCount++;
            $photoList[$key]['i'] = $photoCount;
        }else if($value['type'] == 7){
            $business_licence = $value['picurl'];
            $business_licence_picurl = $value['picurlTmp'];
        }
    }
}

$editUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/mendianedit");