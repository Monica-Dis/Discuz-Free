<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=list";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'refresh' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;

    $updateData = array();
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id, $updateData);
    
    update_fangchan_tongcheng($tcfangchan_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'edittop' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id   = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;
    $top_time        = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
    $top_time        = strtotime($top_time);
        
    $updateData = array();
    
    if($top_time <= TIMESTAMP){
        $updateData['top_status'] = 0;
        $updateData['top_time']   = 0;
    }else{
        $updateData['top_status']   = 1;
        $updateData['refresh_time'] = TIMESTAMP;
        $updateData['top_time']     = $top_time;
    }
    
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id, $updateData);
    
    update_fangchan_tongcheng($tcfangchan_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'info' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );
        
    $tcfangchan_id = intval($_GET['tcfangchan_id'])>0? intval($_GET['tcfangchan_id']):0;
    
    $tcfangchanInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    $tcfangchanInfo = array();
    if(!empty($tcfangchanInfoTmp)){
        
        $tcfangchanInfo = $tcfangchanInfoTmp;
        
        $userInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcfangchanInfo['user_id']);
        $areaInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tcfangchanInfo['area_id']);
        $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tcfangchanInfo['street_id']);
        $agentInfoTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if(is_array($agentInfoTmp) && !empty($agentInfoTmp)){
            $mendianInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfoTmp['mendian_id']);
        }
        $attrInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_attr')->fetch_by_tcfangchan_id($tcfangchan_id);
        
        $attr_rent_unit       = $rentUnitArr[$attrInfoTmp['attr_rent_unit']];
        $attr_rent_type       = $rentTypeArr[$attrInfoTmp['attr_rent_type']];
        $attr_shangpu_type    = $shangpuTypeArr[$attrInfoTmp['attr_shangpu_type']];
        $attr_zhuangxiu_type  = $zhuangxiuTypeArr[$attrInfoTmp['attr_zhuangxiu_type']];
        $attr_house_type      = $houseTypeArr[$attrInfoTmp['attr_house_type']];
        $attr_chaoxiang_type  = $chaoxiangTypeArr[$attrInfoTmp['attr_chaoxiang_type']];
        $attrTeseTagsArr      = explode('|', trim($attrInfoTmp['attr_tese_tags'], '|'));
        $attrPeitaoTagsArr    = explode('|', trim($attrInfoTmp['attr_peitao_tags'], '|'));
        
        $photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id={$tcfangchan_id} "," ORDER BY type DESC,psort ASC,id ASC ",0,20);
        $photoList = array();
        $vrPicurl = $videoPicurl = '';
        if(is_array($photoListTmp) && !empty($photoListTmp)){
            foreach($photoListTmp as $key => $value){
                $picurlTmp = $value['picurlTmp'];

                if($value['type'] == 1){
                    $photoList[] = $picurlTmp;
                }
                if($value['type'] == 2){
                    $vrPicurl = $picurlTmp;
                }
                if($value['type'] == 4){
                    $videoPicurl = $picurlTmp;
                }
            }
        }
        
        $tcfangchanInfo['userInfo']             = $userInfoTmp;
        $tcfangchanInfo['agentInfo']            = $agentInfoTmp;
        $tcfangchanInfo['mendianInfo']          = $mendianInfoTmp;
        $tcfangchanInfo['attrInfo']             = $attrInfoTmp;
        $tcfangchanInfo['areaInfo']             = $areaInfoTmp;
        $tcfangchanInfo['streetInfo']           = $streetInfoTmp;
        $tcfangchanInfo['attr_rent_unit']       = $attr_rent_unit;
        $tcfangchanInfo['attr_rent_type']       = $attr_rent_type;
        $tcfangchanInfo['attr_shangpu_type']    = $attr_shangpu_type;
        $tcfangchanInfo['attr_zhuangxiu_type']  = $attr_zhuangxiu_type;
        $tcfangchanInfo['attr_house_type']      = $attr_house_type;
        $tcfangchanInfo['attr_chaoxiang_type']  = $attr_chaoxiang_type;
        $tcfangchanInfo['attrTeseTagsArr']      = $attrTeseTagsArr;
        $tcfangchanInfo['attrPeitaoTagsArr']    = $attrPeitaoTagsArr;
        $tcfangchanInfo['video_pic']            = $videoPicurl;
        $tcfangchanInfo['vr_pic']               = $vrPicurl;
        $tcfangchanInfo['photoList']            = $photoList;
        
    }
    
    $tcfangchanInfo = iconv_to_utf8($tcfangchanInfo);
    
    $outArr = array(
        'code'  => 200,
        "msg"   => "",
        "data"  => $tcfangchanInfo,
    );
    echo json_encode($outArr); exit;
}else if($act == 'edit_expire_time' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchan_id      = isset($_GET['tcfangchan_id'])? intval($_GET['tcfangchan_id']):0;
    $expire_time        = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time        = strtotime($expire_time);
    
    $updateData = array();
    if($expire_time < TIMESTAMP){
        $updateData['expire_status']    = 2;
        $updateData['expire_time']      = 0;
        $updateData['status']           = 0;
    }else{
        $updateData['expire_status']    = 1;
        $updateData['refresh_time']     = TIMESTAMP;
        $updateData['expire_time']      = $expire_time;
    }
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);

    update_fangchan_tongcheng($tcfangchan_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;

    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
        
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;
    
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
    
   if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
        
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'finish_ok' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;

    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    
    $updateData = array();
    $updateData['finish'] = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
        
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'finish_no' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;
    
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    
    $updateData = array();
    $updateData['finish'] = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
    
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;
    
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    
    C::t('#tom_tcfangchan#tom_tcfangchan')->delete_by_id($tcfangchan_id);
    C::t('#tom_tcfangchan#tom_tcfangchan_attr')->delete_by_tcfangchan_id($tcfangchan_id);
    C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_tcfangchan_id($tcfangchan_id);
    C::t("#tom_tcfangchan#tom_tcfangchan_tag")->delete_by_tcfangchan_id($tcfangchan_id);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
    
    delete_fangchan_tongcheng($tcfangchanInfo['id']);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'edit_pay_status' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    $tcfangchan_id = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;
    
    $updateData = array();
    $updateData['pay_status'] = 2;
    C::t("#tom_tcfangchan#tom_tcfangchan")->update($tcfangchan_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'shenhe' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ? intval($_GET['tcfangchan_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcfangchanInfo['user_id']);
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status']    = 1;
        $updateData['status']           = 1;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
        
        update_fangchan_tongcheng($tcfangchanInfo['id']);
        
        $shenhe = str_replace('{TITLE}', $tcfangchanInfo['title'], $Lang['template_tcfangchan_shenhe_ok']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$tcfangchanInfo['site_id'].'&mod=info&tcfangchan_id='.$tcfangchanInfo['id'].'">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$tcfangchanInfo['site_id']}&mod=info&tcfangchan_id=".$tcfangchanInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }

        if($tcfangchanInfo['source_type'] == 1){
            $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
            if($agentInfo['id'] > 0){
                update_mendian_xinxi($agentInfo['mendian_id']);
            }
        }

        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData);
        
        update_fangchan_tongcheng($tcfangchanInfo['id']);
        
        $shenhe = str_replace('{TITLE}', $tcfangchanInfo['title'], $Lang['template_tcfangchan_shenhe_no']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$tcfangchanInfo['site_id'].'&mod=edit&tcfangchan_id='.$tcfangchanInfo['id'].'">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$tcfangchanInfo['site_id']}&mod=edit&tcfangchan_id=".$tcfangchanInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }

            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }
        }
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}else if($act == 'batch_refresh' && submitcheck('tcfangchan_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchanIdsArr = array();
    if(is_array($_GET['tcfangchan_ids'])){
        foreach($_GET['tcfangchan_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcfangchanIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcfangchanIdsArr)){
        foreach($tcfangchanIdsArr as $key => $value){
            $updateData = array();
            $updateData['refresh_time'] = TIMESTAMP;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value, $updateData);
            update_fangchan_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'batch_shenhe1' && submitcheck('tcfangchan_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchanIdsArr = array();
    if(is_array($_GET['tcfangchan_ids'])){
        foreach($_GET['tcfangchan_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcfangchanIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcfangchanIdsArr)){
        $tcfangchanIdsStr = implode(',', $tcfangchanIdsArr);
        $tcfangchanListTmp = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_list(" AND id IN({$tcfangchanIdsStr}) ", 'ORDER BY id DESC', 0, 100);
        $userIdsArr = array();
        foreach($tcfangchanListTmp as $key => $value){
            
            $userIdsArr[] = $value['user_id'];
            
            $updateData = array();
            $updateData['shenhe_status'] = 1;
            $updateData['status']        = 1;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value['id'], $updateData);
                        
            if($value['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($value['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }
            
            update_fangchan_tongcheng($value['id']);
        }
        
        if(!empty($tongchengConfig['template_id'])){
            $userIdsStr = implode(',', $userIdsArr);
            $userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            foreach($userListTmp as $key => $value){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($value['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfangchanlist");
                    $smsData = array(
                        'first'         => $Lang['shenhe_tcfangchan_succ_msg'],
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($value['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_shenhe3' && submitcheck('tcfangchan_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchanIdsArr = array();
    if(is_array($_GET['tcfangchan_ids'])){
        foreach($_GET['tcfangchan_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcfangchanIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcfangchanIdsArr)){
        $tcfangchanIdsStr = implode(',', $tcfangchanIdsArr);
        $tcfangchanListTmp = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_list(" AND id IN({$tcfangchanIdsStr}) ", 'ORDER BY id DESC', 0, 100);
        $userIdsArr = array();
        foreach($tcfangchanListTmp as $key => $value){
            
            $userIdsArr[] = $value['user_id'];
            
            $updateData = array();
            $updateData['shenhe_status'] = 3;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value['id'], $updateData);
                        
            if($value['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($value['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }
            
            update_fangchan_tongcheng($value['id']);
        }
        
        if(!empty($tongchengConfig['template_id'])){
            $userIdsStr = implode(',', $userIdsArr);
            $userListTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_all_list(" AND id IN({$userIdsStr}) ", 'ORDER BY id DESC', 0, 100);
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            foreach($userListTmp as $key => $value){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($value['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfangchanlist");
                    $smsData = array(
                        'first'         => $Lang['shenhe_tcfangchan_fail_msg'],
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => $text
                    );
                    @$r = $templateSmsClass->sendSms01($value['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_del' && submitcheck('tcfangchan_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchanIdsArr = array();
    if(is_array($_GET['tcfangchan_ids'])){
        foreach($_GET['tcfangchan_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcfangchanIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcfangchanIdsArr)){
        foreach($tcfangchanIdsArr as $key => $value){
            C::t('#tom_tcfangchan#tom_tcfangchan')->delete_by_id($value);
            C::t('#tom_tcfangchan#tom_tcfangchan_attr')->delete_by_tcfangchan_id($value);
            C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_tcfangchan_id($value);
            C::t("#tom_tcfangchan#tom_tcfangchan_tag")->delete_by_tcfangchan_id($value);
            
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);
            
            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }
            
            delete_fangchan_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_show' && submitcheck('tcfangchan_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchanIdsArr = array();
    if(is_array($_GET['tcfangchan_ids'])){
        foreach($_GET['tcfangchan_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcfangchanIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcfangchanIdsArr)){
        foreach($tcfangchanIdsArr as $key => $value){
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);
            
            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);
            
            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }
            
            update_fangchan_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_hide' && submitcheck('tcfangchan_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchanIdsArr = array();
    if(is_array($_GET['tcfangchan_ids'])){
        foreach($_GET['tcfangchan_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcfangchanIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcfangchanIdsArr)){
        foreach($tcfangchanIdsArr as $key => $value){
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);
            
            $updateData = array();
            $updateData['status'] = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);
            
            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }
            
            update_fangchan_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_finish1' && submitcheck('tcfangchan_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchanIdsArr = array();
    if(is_array($_GET['tcfangchan_ids'])){
        foreach($_GET['tcfangchan_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcfangchanIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcfangchanIdsArr)){
        foreach($tcfangchanIdsArr as $key => $value){
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);
            
            $updateData = array();
            $updateData['finish'] = 1;
            $updateData['status'] = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);
            
            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }
            
            update_fangchan_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'batch_finish0' && submitcheck('tcfangchan_ids')){
    $outArr = array(
        'code'=> 1,
    );
    
    $tcfangchanIdsArr = array();
    if(is_array($_GET['tcfangchan_ids'])){
        foreach($_GET['tcfangchan_ids'] as $key => $value){
            $idTmp = intval($value);
            if($idTmp > 0){
                $tcfangchanIdsArr[] = $idTmp;
            }
        }
    }
    
    if(!empty($tcfangchanIdsArr)){
        foreach($tcfangchanIdsArr as $key => $value){
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);
            
            $updateData = array();
            $updateData['finish'] = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);
            
            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }
            
            update_fangchan_tongcheng($value);
        }
    }
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$keyword            = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$tcfangchan_id      = isset($_GET['tcfangchan_id'])? intval($_GET['tcfangchan_id']):0;
$house_no           = isset($_GET['house_no'])? addslashes($_GET['house_no']):'';
$tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
$model_id           = isset($_GET['model_id'])? addslashes($_GET['model_id']):'';
$area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
$street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
$source_type        = isset($_GET['source_type'])? intval($_GET['source_type']):0;
$status             = isset($_GET['status'])? intval($_GET['status']):0;
$expire_status      = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
$deleted            = isset($_GET['deleted'])? intval($_GET['deleted']):0;
$pay_type           = isset($_GET['pay_type'])? intval($_GET['pay_type']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}
$modelIdsArr = array(
    'ershoufang' => $Lang['ershoufang'],
    'chuzu' => $Lang['chuzu'],
    'shangpu' => $Lang['shangpu'],
    'xiezilou' => $Lang['xiezilou'],
    'changfang' => $Lang['changfang'],
    'cangku' => $Lang['cangku'],
    'tudi' => $Lang['tudi'],
);

$__CityInfo  = array('id'=>0,'name'=>'');
if($site_id > 1){
    $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
    if($sitesInfoTmp){
        $__SitesInfo = $sitesInfoTmp;
        if(!empty($__SitesInfo['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
            if($cityInfoTmp){
                $__CityInfo = $cityInfoTmp;
            }
        }
    }
}else if($site_id == 1){
    $cityInfoTmp = array();
    if(!empty($tongchengConfig['city_id'])){
        $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
    }
    if(!empty($cityInfoTmp)){
        $__CityInfo = $cityInfoTmp;
    }
}
$areaList   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);

$whereStr = '';
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}
if(!empty($tel)){
    $whereStr.= " AND tel='{$tel}' ";
}
if(!empty($model_id)){
    $whereStr.= " AND model_id='{$model_id}' ";
}
if($area_id > 0){
    $whereStr.= " AND area_id='{$area_id}' ";
}
if($street_id > 0){
    $whereStr.= " AND street_id='{$street_id}' ";
}
if(!empty($tcfangchan_id)){
    $whereStr.= " AND id={$tcfangchan_id} ";
}
if(!empty($house_no)){
    $whereStr.= " AND house_no='{$house_no}' ";
}
if(!empty($source_type)){
    $whereStr.= " AND source_type={$source_type} ";
}
if(!empty($status)){
    if($status == 1){
        $whereStr.= " AND status=1 ";
    }else if($status == 2){
        $whereStr.= " AND status != 1 ";
    }
}
if(!empty($shenhe_status)){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}
if($top_status > 0){
    if($top_status == 1){
        $whereStr.= " AND top_status = 1 ";
    }else if($top_status == 2){
        $whereStr.= " AND top_status = 0 ";
    }
}
if($deleted > 0){
    if($deleted == 1){
        $whereStr.= " AND deleted = 1 ";
    }else if($deleted == 2){
        $whereStr.= " AND deleted = 0 ";
    }
}
if($pay_type > 0){
    $whereStr.= " AND pay_type = {$pay_type} ";
}
if($expire_status > 0){
    if($expire_status == 1){
        $whereStr.= " AND ((expire_status = 1 AND expire_time > ".TIMESTAMP.") OR (expire_status = 3)) ";
    }else if($expire_status == 2){
        $whereStr.= " AND expire_status = 2 ";
    }
}

$order = "ORDER BY add_time DESC,id DESC";

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count($whereStr,$keyword);
$tcfangchanListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($whereStr,$order,$start,$pagesize,$keyword);
$tcfangchanList = array();
if(!empty($tcfangchanListTmp)){
    foreach ($tcfangchanListTmp as $key => $value) {
        $tcfangchanList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        $siteInfoTmp = $sitesList[$value['site_id']];
        
        $tcfangchanList[$key]['userInfo']              = $userInfoTmp;
        $tcfangchanList[$key]['siteInfo']              = $siteInfoTmp;
        $tcfangchanList[$key]['top_time']              = dgmdate($value['top_time'],"Y-m-d H:i",$tomSysOffset);
        $tcfangchanList[$key]['refresh_time']          = dgmdate($value['refresh_time'],"Y-m-d H:i",$tomSysOffset);
        $tcfangchanList[$key]['add_time']              = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $tcfangchanList[$key]['expire_time']           = dgmdate($value['expire_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&user_id={$user_id}&site_id={$site_id}&tel={$tel}&model_id={$model_id}&area_id={$area_id}&street_id={$street_id}&house_no={$house_no}&source_type={$source_type}&status={$status}&shenhe_status={$shenhe_status}&top_status={$top_status}&deleted={$deleted}&pay_type={$pay_type}&expire_status={$expire_status}&keyword={$keyword}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/list");