<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=adviseradd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $newhouses_id   = isset($_GET['newhouses_id'])? intval($_GET['newhouses_id']):0;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $sub_desc       = isset($_GET['sub_desc'])? addslashes($_GET['sub_desc']):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $asort          = isset($_GET['asort'])? intval($_GET['asort']):10;
    $avatar         = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $work_picurl    = isset($_GET['work_picurl'])? addslashes($_GET['work_picurl']):'';
    $wx_qrcode      = isset($_GET['wx_qrcode'])? addslashes($_GET['wx_qrcode']):'';
    
    $newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($newhouses_id);
    
    $insertData = array();
    $insertData['site_id']              = $newhousesInfo['site_id'];
    $insertData['user_id']              = $user_id;
    $insertData['newhouses_id']         = $newhouses_id;
    $insertData['newhouses_name']       = $newhousesInfo['name'];
    $insertData['name']                 = $name;
    $insertData['sub_desc']             = $sub_desc;
    $insertData['tel']                  = $tel;
    $insertData['asort']                = $asort;
    $insertData['avatar']               = $avatar;
    $insertData['wx_qrcode']            = $wx_qrcode;
    $insertData['work_picurl']          = $work_picurl;
    $insertData['status']               = 0;
    $insertData['shenhe_status']        = 1;
    $insertData['add_time']             = TIMESTAMP;
    if(C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->insert($insertData)){
        $adviser_id = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->insert_id();
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    echo json_encode($outArr); exit;
}

$addUrl = $modPcadminUrl."&act=add";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/adviseradd");