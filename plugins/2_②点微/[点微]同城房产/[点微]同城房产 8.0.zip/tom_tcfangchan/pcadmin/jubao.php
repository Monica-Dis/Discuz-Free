<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=jubao";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('jubao_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $jubao_id = intval($_GET['jubao_id'])>0 ? intval($_GET['jubao_id']):0;
    
    C::t('#tom_tcfangchan#tom_tcfangchan_jubao')->delete_by_id($jubao_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcfangchan#tom_tcfangchan_jubao')->fetch_all_count('');
$jubaoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_jubao')->fetch_all_list(" "," ORDER BY id DESC ",$start,$pagesize);
$jubaoList = array();
if(!empty($jubaoListTmp)){
    foreach ($jubaoListTmp as $key => $value) {
        $jubaoList[$key] = $value;
        
        $userInfoTmp       = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        
        if($value['tcfangchan_id'] > 0){
            $tcfangchanInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value['tcfangchan_id']);
            $jubaoList[$key]['tcfangchanInfo']   = $tcfangchanInfoTmp;
        }
        if($value['needs_id'] > 0){
            $needsInfoTmp      = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($value['needs_id']);
            $jubaoList[$key]['needsInfo']        = $needsInfoTmp;
        }
        
        $jubaoList[$key]['userInfo']         = $userInfoTmp;
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/jubao");