<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=doDaoFangchan";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'dodao_url' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $day_type       = isset($_GET['day_type'])? intval($_GET['day_type']):1;
    $source_type    = isset($_GET['source_type'])? intval($_GET['source_type']):0;
    $model_id       = isset($_GET['model_id'])? addslashes($_GET['model_id']):'ershoufang';
    $days           = isset($_GET['days'])? intval($_GET['days']):0;
    $dao_tel        = isset($_GET['dao_tel'])? intval($_GET['dao_tel']):0;
    $dao_type       = isset($_GET['dao_type'])? intval($_GET['dao_type']):2;
    
    $site_ids_url = '';
    if(is_array($_GET['site_ids']) && !empty($_GET['site_ids'])){
        $site_ids = implode(',', $_GET['site_ids']);
        $site_ids_url = implode('_', $_GET['site_ids']);
    }
    
    $doDaoUrl = $_G['siteurl']."plugin.php?id=tom_tcfangchan:doDaoFangchan&site_id={$site_id}&site_ids={$site_ids_url}&source_type={$source_type}&day_type={$day_type}&days={$days}&model_id={$model_id}&dao_tel={$dao_tel}&dao_type={$dao_type}&from=tom_admin";
    
    $outArr = array(
        'code'=> 200,
        'url'=> $doDaoUrl,
    );
    echo json_encode($outArr); exit;
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$daysList = array();
for($i = 1; $i <= 30; $i++){
    $daysList[] = $i;
}

$dodaoUrl = $modPcadminUrl."&act=dodao_url&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/doDaoFangchan");