<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=needsadd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id                    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $site_id                    = intval($_GET['site_id'])>0? intval($_GET['site_id']):1;
    $type                       = isset($_GET['type'])? intval($_GET['type']):0;
    $area_id                    = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id                  = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $lng                        = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                        = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address                    = isset($_GET['address'])? addslashes($_GET['address']):'';
    $xm                         = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $wx                         = isset($_GET['wx'])? addslashes($_GET['wx']):'';
    $content                    = isset($_GET['content'])? addslashes($_GET['content']):'';
    $expire_time                = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time                = strtotime($expire_time);
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $insertData = array();
    $insertData['site_id']            = $site_id;
    $insertData['user_id']            = $user_id;
    $insertData['type']               = $type;
    $insertData['city_id']            = $city_id;
    $insertData['area_id']            = $area_id;
    $insertData['street_id']          = $street_id;
    $insertData['address']            = $address;
    $insertData['latitude']           = $lat;
    $insertData['longitude']          = $lng;
    $insertData['xm']                 = $xm;
    $insertData['tel']                = $tel;
    $insertData['wx']                 = $wx;
    $insertData['content']            = $content;
    if($expire_time < TIMESTAMP){
        $insertData['expire_status']    = 2;
        $insertData['expire_time']      = 0;
    }else{
        $insertData['expire_status']    = 1;
        $insertData['expire_time']      = $expire_time;
    }
    $insertData['shenhe_status']    = 1;
    $insertData['status']           = 0;
    $insertData['refresh_time']     = TIMESTAMP;
    $insertData['add_time']         = TIMESTAMP;
    
    $needs_id = C::t("#tom_tcfangchan#tom_tcfangchan_needs")->insert($insertData, true);
        
    if($needs_id > 0){
        
        update_needs_tongcheng($needs_id);
        
        $outArr = array(
            'code'=> 200,
            'id'=> $needs_id,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$__CityInfo = array();
if(!empty($tongchengConfig['city_id'])){
    $__CityInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);

$addUrl = $modPcadminUrl."&act=add";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/needsadd");