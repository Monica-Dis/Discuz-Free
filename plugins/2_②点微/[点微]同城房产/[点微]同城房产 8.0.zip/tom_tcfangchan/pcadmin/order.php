<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=order";

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$tcfangchan_id  = isset($_GET['tcfangchan_id'])? intval($_GET['tcfangchan_id']):0;
$order_no       = isset($_GET['order_no'])? addslashes($_GET['order_no']):'';
$type           = intval($_GET['type'])>0? intval($_GET['type']):0;
$order_status   = intval($_GET['order_status'])>0? intval($_GET['order_status']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$whereStr = '';
if($site_id > 0){
    $whereStr .= " AND site_id={$site_id} ";
}
if($user_id > 0){
    $whereStr .= " AND user_id={$user_id} ";
}
if($tcfangchan_id > 0){
    $whereStr .= " AND tcfangchan_id={$tcfangchan_id} ";
}
if(!empty($order_no)){
    $whereStr .= " AND order_no='{$order_no}' ";
}
if($type > 0){
    $whereStr .= " AND type={$type} ";
}
if($order_status > 0){
    $whereStr .= " AND order_status={$order_status} ";
}

$start         = ($page - 1)*$pagesize;
$count         = C::t('#tom_tcfangchan#tom_tcfangchan_order')->fetch_all_count($whereStr);
$orderListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_order')->fetch_all_list($whereStr," ORDER BY id DESC ",$start,$pagesize);
$orderList = array();
if(!empty($orderListTmp)){
    foreach ($orderListTmp as $key => $value) {
        $orderList[$key] = $value;

        $userInfoTmp       = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $tcfangchanInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value['tcfangchan_id']);
        $mendianInfoTmp    = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_user_id($value['user_id']);
        $agentInfoTmp      = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($value['agent_id']);
        $agentVipInfoTmp   = C::t('#tom_tcfangchan#tom_tcfangchan_agent_vip')->fetch_by_id($value['agent_vip_id']);
        $adviserInfoTmp    = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_by_id($value['adviser_id']);
        $needsInfoTmp      = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($value['needs_id']);
        $siteInfoTmp       = $sitesList[$value['site_id']];
        
        $content  = cutstr($needsInfoTmp['content'],30,"...");

        $orderList[$key]['userInfo']              = $userInfoTmp;
        $orderList[$key]['tcfangchanInfo']        = $tcfangchanInfoTmp;
        $orderList[$key]['mendianInfo']           = $mendianInfoTmp;
        $orderList[$key]['agentInfo']             = $agentInfoTmp;
        $orderList[$key]['agentVipInfo']          = $agentVipInfoTmp;
        $orderList[$key]['adviserInfo']           = $adviserInfoTmp;
        $orderList[$key]['needsInfo']             = $needsInfoTmp;
        $orderList[$key]['siteInfo']              = $siteInfoTmp;
        $orderList[$key]['content']               = $content;
        $orderList[$key]['order_time']            = dgmdate($value['order_time'],"Y-m-d H:i:s",$tomSysOffset) ;
        $orderList[$key]['pay_time']              = dgmdate($value['pay_time'],"Y-m-d H:i:s",$tomSysOffset) ;

    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&user_id={$user_id}&type={$type}&order_status={$order_status}&tcfangchan_id={$tcfangchan_id}";

$todayPayPrice = C::t('#tom_tcfangchan#tom_tcfangchan_order')->fetch_all_sun_pay_price(" AND pay_time > $nowDayTime AND order_status=2 ");
$monthPayPrice = C::t('#tom_tcfangchan#tom_tcfangchan_order')->fetch_all_sun_pay_price(" AND pay_time > $nowMonthTime AND order_status=2 ");
$allPayPrice   = C::t('#tom_tcfangchan#tom_tcfangchan_order')->fetch_all_sun_pay_price(" AND order_status=2 ");

if(!empty($whereStr)){
    $searchAllPayPrice = C::t('#tom_tcfangchan#tom_tcfangchan_order')->fetch_all_sun_pay_price($whereStr);
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/order");