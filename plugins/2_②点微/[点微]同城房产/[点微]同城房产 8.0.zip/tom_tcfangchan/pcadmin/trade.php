<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=trade";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'del' && submitcheck('trade_id')){
    $outArr = array(
        'code'=> 1,
    );

    $trade_id    = intval($_GET['trade_id'])>0 ? intval($_GET['trade_id']):0;
        
    C::t('#tom_tcfangchan#tom_tcfangchan_trade')->delete_by_id($trade_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'trade_add' && submitcheck('site_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tsort          = isset($_GET['tsort'])? intval($_GET['tsort']):100;
    
    $insertData = array();
    $insertData['site_id']  = $site_id;
    $insertData['name']     = $name;
    $insertData['tsort']    = $tsort;
    $insertData['add_time'] = TIMESTAMP;
    C::t('#tom_tcfangchan#tom_tcfangchan_trade')->insert($insertData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'trade_edit' && submitcheck('trade_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $trade_id       = intval($_GET['trade_id'])>0 ? intval($_GET['trade_id']):0;
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tsort          = isset($_GET['tsort'])? intval($_GET['tsort']):100;
    
    $updateData = array();
    $updateData['site_id']  = $site_id;
    $updateData['name']     = $name;
    $updateData['tsort']    = $tsort;
    C::t('#tom_tcfangchan#tom_tcfangchan_trade')->update($trade_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$whereStr = '';
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}

$order = " ORDER BY site_id ASC,tsort ASC,id DESC";

$start          = ($page - 1)*$pagesize;
$count          = C::t('#tom_tcfangchan#tom_tcfangchan_trade')->fetch_all_count($whereStr);
$tradeListTmp   = C::t('#tom_tcfangchan#tom_tcfangchan_trade')->fetch_all_list($whereStr,$order,$start,$pagesize);
$tradeList = array();
if(!empty($tradeListTmp)){
    foreach ($tradeListTmp as $key => $value) {
        $tradeList[$key] = $value;
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        $tradeList[$key]['siteInfo']     = $siteInfoTmp;
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/trade");