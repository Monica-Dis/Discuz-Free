<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=agent";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'agent_viplist' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );

    $vipListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_agent_vip')->fetch_all_list(" "," ORDER BY vsort ASC,id DESC ",0,100);
    $vipList = array();
    if(!empty($vipListTmp)){
        foreach($vipListTmp as $key => $value){
            $vipList[$key] = $value;
        }
    }
    
    $vipList = iconv_to_utf8($vipList);
    
    $outArr = array(
        'code'  => 200,
        'list'  => $vipList,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'editvip' && submitcheck('agent_id')){
    $outArr = array(
        'code'=> 1,
    );

    $agent_id       = intval($_GET['agent_id'])>0 ? intval($_GET['agent_id']):0; 
    $vip_id         = intval($_GET['vip_id'])>0? intval($_GET['vip_id']):0;
    $expire_time    = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time    = strtotime($expire_time);
    
    $updateData = array();
    if($expire_time > TIMESTAMP){
        $updateData['vip_id']          = $vip_id;
        $updateData['expire_status']   = 1;
        $updateData['expire_time']     = $expire_time;
        $updateData['vip_add_time']    = TIMESTAMP;
    }else{
        $updateData['expire_status']   = 0;
        $updateData['expire_time']     = $expire_time;
    }
    C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($agent_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'edittop' && submitcheck('agent_id')){
    $outArr = array(
        'code'=> 1,
    );

    $agent_id        = intval($_GET['agent_id'])>0 ? intval($_GET['agent_id']):0;
    $top_time        = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
    $top_time        = strtotime($top_time);
        
    $updateData = array();
    
    if($top_time <= TIMESTAMP){
        $updateData['top_status'] = 0;
        $updateData['top_time']   = 0;
    }else{
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
    }
    C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($agent_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'del' && submitcheck('agent_id')){
    $outArr = array(
        'code'=> 1,
    );

    $agent_id  = intval($_GET['agent_id'])>0 ? intval($_GET['agent_id']):0;
        
    $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($agent_id);
    C::t('#tom_tcfangchan#tom_tcfangchan_agent')->delete_by_id($agent_id);
    
    DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET source_type=2 WHERE user_id = {$agentInfo['user_id']} ", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET expire_status=2,status=0 WHERE user_id = {$agentInfo['user_id']} AND expire_status=3 ", 'UNBUFFERED');
    
    $tcfangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_id_list(" AND user_id = {$agentInfo['user_id']} AND expire_status=2 ");
    if(is_array($tcfangchanListTmp) && !empty($tcfangchanListTmp)){
        foreach($tcfangchanListTmp as $key => $value){
            update_fangchan_tongcheng($value['id']);
        }
    }
    
    update_mendian_xinxi($agentInfo['mendian_id']);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'mendian_shenhe' && submitcheck('agent_id')){
    
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $agent_id               = intval($_GET['agent_id'])>0 ? intval($_GET['agent_id']):0;
    $mendian_shenhe_status  = intval($_GET['mendian_shenhe_status'])>0 ? intval($_GET['mendian_shenhe_status']):0;
    
    $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($agent_id);
    
    $updateData = array();
    if($mendian_shenhe_status == 1){
        $updateData['mendian_id']               = $agentInfo['mendian_shenhe_id'];
        $updateData['shenhe_status']            = 1;
        $updateData['mendian_shenhe_status']    = 1;
        $updateData['mendian_shenhe_id']        = 0;
    }
    if($mendian_shenhe_status == 3){
        $updateData['mendian_id']               = 0;
        $updateData['mendian_shenhe_status']    = 0;
        $updateData['mendian_shenhe_id']        = 0;
    }
    C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($agent_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'shenhe' && submitcheck('agent_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $agent_id       = intval($_GET['agent_id'])>0 ? intval($_GET['agent_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($agent_id);
    $userInfo  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($agentInfo['user_id']);
    
    if($shenhe_status == 1){
        
        $updateData = array();
        $updateData['shenhe_status']    = 1;
        C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($agent_id,$updateData);

        $shenhe = str_replace('{NAME}', $agentInfo['name'], $Lang['template_agent_shenhe_ok']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$agentInfo['site_id'].'&mod=agentinfo&agent_id='.$agentInfo['id'].'">['.$Lang['template_dianjichakan'].']</a>';

        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$agentInfo['site_id']}&mod=agentinfo&agent_id=".$agentInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }

        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status']    = 3;
        C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($agent_id,$updateData);

        $shenhe = str_replace('{NAME}', $agentInfo['name'], $Lang['template_agent_shenhe_no']);
        $tzShenhe = $shenhe.'<br/>'.$text.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$agentInfo['site_id'].'&mod=agentedit&agent_id='.$agentInfo['id'].'">['.$Lang['template_dianjichakan'].']</a>';

        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$agentInfo['site_id']}&mod=agentedit&agent_id=".$agentInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );

                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }

        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
    }

    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$name               = isset($_GET['name'])? addslashes(urldecode($_GET['name'])):'';
$mendian_id         = isset($_GET['mendian_id'])? intval($_GET['mendian_id']):0;
$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$tel                = isset($_GET['tel'])? addslashes(urldecode($_GET['tel'])):'';
$agent_id           = isset($_GET['agent_id'])? intval($_GET['agent_id']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$whereStr = '';
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}
if($mendian_id > 0){
    $whereStr.= " AND mendian_id={$mendian_id} ";
}
if($agent_id > 0){
    $whereStr.= " AND id={$agent_id}";
}
if(!empty($name)){
    $name = str_replace(array('%', '_'),'',$name);
    $whereStr .= " AND name LIKE '%{$name}%' ";
}
if(!empty($tel)){
    $tel = str_replace(array('%', '_'),'',$tel);
    $whereStr .= " AND tel LIKE '%{$tel}%' ";
}
if(!empty($shenhe_status)){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}

$order = "ORDER BY id DESC";

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_count($whereStr);
$agentListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_agent_list($whereStr,$order,$start,$pagesize);
$agentList = array();
if(!empty($agentListTmp)){
    foreach ($agentListTmp as $key => $value) {
        $agentList[$key] = $value;
        
        $agentList[$key]['avatar']      = get_file_url($value['avatar']);
        $agentList[$key]['wx_qrcode']   = get_file_url($value['wx_qrcode']);
        
        $siteInfoTmp    = $sitesList[$value['site_id']];
        $userInfoTmp    = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $mendianInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($value['mendian_id']);
        $mendianShenheInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($value['mendian_shenhe_id']);
        $vipInfoTmp     = C::t('#tom_tcfangchan#tom_tcfangchan_agent_vip')->fetch_by_id($value['vip_id']);
        
        $agentList[$key]['siteInfo']      = $siteInfoTmp;
        $agentList[$key]['userInfo']      = $userInfoTmp;
        $agentList[$key]['vipInfo']       = $vipInfoTmp;
        $agentList[$key]['mendianInfo']   = $mendianInfoTmp;
        $agentList[$key]['mendianShenheInfo']   = $mendianShenheInfoTmp;
        $agentList[$key]['add_time']      = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $agentList[$key]['expire_time']   = dgmdate($value['expire_time'],"Y-m-d H:i",$tomSysOffset);
        $agentList[$key]['top_time']      = dgmdate($value['top_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&name={$name}&tel={$tel}&mendian_id={$mendian_id}&shenhe_status={$shenhe_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/agent");