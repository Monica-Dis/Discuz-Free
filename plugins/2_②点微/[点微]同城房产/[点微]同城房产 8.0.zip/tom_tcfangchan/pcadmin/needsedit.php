<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$needs_id  = intval($_GET['needs_id'])>0? intval($_GET['needs_id']):0;
$needsInfo = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($needs_id);

if(empty($needsInfo)){
    tomheader('location:'.$_G['siteurl']."{$pcadminUrl}&tmod=needs");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=needsedit&needs_id={$needs_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($_GET['act'] == 'save' && submitcheck('needs_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
        
    $user_id                    = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $site_id                    = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $type                       = isset($_GET['type'])? intval($_GET['type']):0;
    $area_id                    = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id                  = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $lng                        = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                        = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address                    = isset($_GET['address'])? addslashes($_GET['address']):'';
    $xm                         = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $wx                         = isset($_GET['wx'])? addslashes($_GET['wx']):'';
    $content                    = isset($_GET['content'])? addslashes($_GET['content']):'';
    $expire_time                = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time                = strtotime($expire_time);
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $updateData = array();
    $updateData['site_id']            = $site_id;
    $updateData['user_id']            = $user_id;
    $updateData['type']               = $type;
    $updateData['city_id']            = $city_id;
    $updateData['area_id']            = $area_id;
    $updateData['street_id']          = $street_id;
    $updateData['address']            = $address;
    $updateData['latitude']           = $lat;
    $updateData['longitude']          = $lng;
    $updateData['xm']                 = $xm;
    $updateData['tel']                = $tel;
    $updateData['wx']                 = $wx;
    $updateData['content']            = $content;
    if($expire_time < TIMESTAMP){
        $updateData['expire_status']    = 2;
        $updateData['expire_time']      = 0;
    }else{
        $updateData['expire_status']    = 1;
        $updateData['expire_time']      = $expire_time;
    }
    
    if(C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($needs_id,$updateData)){
        update_needs_tongcheng($needs_id);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    } 
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(""," ORDER BY paixu ASC,id DESC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($needsInfo['city_id']);
$areaList = array();
if(!empty($areaListTmp)){
    foreach ($areaListTmp as $key => $value){
        $areaList[$value['id']] = $value;
    }
}

$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($needsInfo['area_id']);
$streetList = array();
if(!empty($streetListTmp)){
    foreach ($streetListTmp as $key => $value){
        $streetList[$value['id']] = $value;
    }
}

$needsInfo['content']    = stripcslashes($needsInfo['content']);
$expire_time = dgmdate($needsInfo['expire_time'],"Y-m-d H:i",$tomSysOffset);

$editUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/needsedit");