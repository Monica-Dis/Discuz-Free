<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcfangchan_id  = intval($_GET['tcfangchan_id'])>0? intval($_GET['tcfangchan_id']):0;

$tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);

if(empty($tcfangchanInfo)){
    tomheader('location:'.$_G['siteurl']."{$pcadminUrl}&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=edit&tcfangchan_id={$tcfangchan_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($_GET['act'] == 'save' && submitcheck('tcfangchan_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
        
    $site_id                = intval($_GET['site_id'])>0? intval($_GET['site_id']):1;
    $model_id               = isset($_GET['model_id'])? addslashes($_GET['model_id']):'';
    $title                  = isset($_GET['title'])? addslashes($_GET['title']):'';
    $user_id                = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;    
    $houses_id              = intval($_GET['houses_id'])>0? intval($_GET['houses_id']):0;
    $houses_name            = isset($_GET['houses_name'])? addslashes($_GET['houses_name']):'';
    $city_id                = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id                = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id              = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $address                = isset($_GET['address'])? addslashes($_GET['address']):'';
    $lng                    = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                    = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $trade_id               = intval($_GET['trade_id'])>0? intval($_GET['trade_id']):0;
    $mianji                 = floatval($_GET['mianji'])>0? floatval($_GET['mianji']):0.00;
    $price                  = floatval($_GET['price'])>0? floatval($_GET['price']):0.0;
    $xm                     = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                    = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $wx                     = isset($_GET['wx'])? addslashes($_GET['wx']):'';
    $house_tel              = isset($_GET['house_tel'])? addslashes($_GET['house_tel']):'';
    $house_no               = isset($_GET['house_no'])? addslashes($_GET['house_no']):'';
    $attr_zhuangxiu_type    = intval($_GET['attr_zhuangxiu_type'])>0? intval($_GET['attr_zhuangxiu_type']):0;
    $attr_house_type        = intval($_GET['attr_house_type'])>0? intval($_GET['attr_house_type']):0;
    $attr_chaoxiang_type    = intval($_GET['attr_chaoxiang_type'])>0? intval($_GET['attr_chaoxiang_type']):0;
    $attr_shi               = intval($_GET['attr_shi'])>0? intval($_GET['attr_shi']):0;
    $attr_ting              = intval($_GET['attr_ting'])>0? intval($_GET['attr_ting']):0;
    $attr_wei               = intval($_GET['attr_wei'])>0? intval($_GET['attr_wei']):0;
    $attr_louceng           = intval($_GET['attr_louceng'])>0? intval($_GET['attr_louceng']):0;
    $attr_cengshu           = intval($_GET['attr_cengshu'])>0? intval($_GET['attr_cengshu']):0;
    $attr_chanquan          = intval($_GET['attr_chanquan'])>0? intval($_GET['attr_chanquan']):0;
    $attr_elevator          = intval($_GET['attr_elevator'])>0? intval($_GET['attr_elevator']):0;
    $content                = isset($_GET['content'])? addslashes($_GET['content']):'';
    $video_url              = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_pic              = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $vr_link                = isset($_GET['vr_link'])? addslashes($_GET['vr_link']):'';
    $vr_picurl              = isset($_GET['vr_pic'])? addslashes($_GET['vr_pic']):'';
    $rent                   = intval($_GET['rent'])>0? intval($_GET['rent']):0;
    $attr_lease_type        = intval($_GET['attr_lease_type'])>0? intval($_GET['attr_lease_type']):0;
    $attr_rent_unit         = intval($_GET['attr_rent_unit'])>0? intval($_GET['attr_rent_unit']):1;
    $attr_rent_type         = intval($_GET['attr_rent_type'])>0? intval($_GET['attr_rent_type']):0;
    $fangchan_nature        = intval($_GET['fangchan_nature'])>0? intval($_GET['fangchan_nature']):0;
    $zhuanrang_price        = floatval($_GET['zhuanrang_price'])>0? floatval($_GET['zhuanrang_price']):0.00;
    $attr_shangpu_type      = intval($_GET['attr_shangpu_type'])>0? intval($_GET['attr_shangpu_type']):0;
    $expire_status          = intval($_GET['expire_status'])>0? intval($_GET['expire_status']):1;
    $expire_time            = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time            = strtotime($expire_time);
    
    $old_user_id = $tcfangchanInfo['user_id'];
    
    $teseTagsIdsArr = array();
    if(is_array($_GET['attr_tese_tags']) && !empty($_GET['attr_tese_tags'])){
        foreach($_GET['attr_tese_tags'] as $key => $value){
            if(intval($value) > 0){
                $teseTagsIdsArr[] = intval($value);
            }
        }
    }
    
    $configTagList = array();
    $attrTeseTagsStr = $attrTeseTagsIdsStr = '';
    if(is_array($teseTagsIdsArr) && !empty($teseTagsIdsArr)){
        $teseTagsIdsCount = count($teseTagsIdsArr);
        $attrTeseTagsIdsStr = implode(',', $teseTagsIdsArr);
        $configTagListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_all_list(" AND id IN({$attrTeseTagsIdsStr}) ", 'ORDER BY tsort ASC,id DESC', 0, $teseTagsIdsCount);
        $configTagNameArr = array();
        if(is_array($configTagListTmp) && !empty($configTagListTmp)){
            foreach($configTagListTmp as $key => $value){
                $configTagList[$key] = $value;
                $configTagNameArr[] = $value['name'];
            }
        }
        
        if(is_array($configTagNameArr) && !empty($configTagNameArr)){
            $attrTeseTagsStr = '|'.implode('|', $configTagNameArr).'|';
        }
    }
    
    $attrPeitaoTagsArr = array();
    if(is_array($_GET['attr_peitao_tags']) && !empty($_GET['attr_peitao_tags'])){
        foreach($_GET['attr_peitao_tags'] as $key => $value){
            if(!empty($value)){
                $attrPeitaoTagsArr[] = addslashes($chuzuPeitaoArr[$value]['name']);
            }
        }
    }
    
    $attrPeitaoTagsStr = '';
    if(is_array($attrPeitaoTagsArr) && !empty($attrPeitaoTagsArr)){
        $attrPeitaoTagsStr = '|'.implode('|', $attrPeitaoTagsArr).'|';
    }
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photosort_") !== false){
            $kk = intval(ltrim($key, "photosort_"));
            $photoArr[$kk]['sort'] = addslashes($value);
        }
    }

    if($houses_id > 0){
        $housesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($houses_id);
    }
    if($trade_id > 0){
        $tradeInfo = C::t('#tom_tcfangchan#tom_tcfangchan_trade')->fetch_by_id($trade_id);
    }
    
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    $agentInfo  = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($user_id);
    
    $searchText = $title.'|++++|'.$house_no.'|++++|'.$houses_name;
    
    $updateData = array();
    $updateData['site_id']              = $site_id;
    $updateData['user_id']              = $user_id;
    $updateData['title']                = $title;
    if($trade_id > 0 && $tradeInfo['id'] > 0){
        $searchText .= '|++++|'.$tradeInfo['name'];

        $updateData['trade_id']             = $tradeInfo['id'];
        $updateData['trade_name']           = $tradeInfo['name'];
    }else{
        $updateData['trade_id']             = 0;
        $updateData['trade_name']           = '';
    }
    if($houses_id > 0){
        $updateData['city_id']              = $housesInfo['city_id'];
        $updateData['area_id']              = $housesInfo['area_id'];
        $updateData['area_name']            = $housesInfo['area_name'];
        $updateData['street_id']            = $housesInfo['street_id'];
        $updateData['street_name']          = $housesInfo['street_name'];
        $updateData['address']              = $housesInfo['address'];
        $updateData['latitude']             = $housesInfo['latitude'];
        $updateData['longitude']            = $housesInfo['longitude'];
        $updateData['houses_id']            = $housesInfo['id'];
    }else{
        $updateData['area_id']              = $area_id;
        $updateData['area_name']            = $areaInfo['name'];
        $updateData['street_id']            = $street_id;
        $updateData['street_name']          = $streetInfo['name'];
        $updateData['address']              = $address;
        $updateData['latitude']             = $lat;
        $updateData['longitude']            = $lng;
        $updateData['houses_id']            = 0;
    }
    $updateData['mianji']                   = $mianji;
    if($fangchan_nature > 0){
        $updateData['fangchan_nature']      = $fangchan_nature;
        if($fangchan_nature == 1){
            $updateData['rent']                 = $rent;
            $updateData['price']                = 0;
            $updateData['zhuanrang_price']      = 0;
        }else if($fangchan_nature == 2){
            $updateData['price']                = $price;
            $updateData['rent']                 = 0;
            $updateData['zhuanrang_price']      = 0;
        }else if($fangchan_nature == 3){
            $updateData['zhuanrang_price']      = $zhuanrang_price;
            $updateData['price']                = 0;
            $updateData['rent']                 = 0;
        }
    }
    
    if($tcfangchanInfo['model_id'] == 'ershoufang'){
        
        $updateData['houses_name']          = $houses_name;
        $updateData['price']                = $price;
        
    }else if($tcfangchanInfo['model_id'] == 'chuzu'){
        
        $updateData['houses_name']          = $houses_name;
        $updateData['rent']                 = $rent;
        
    }
    
    $updateData['video_url']            = $video_url;
    $updateData['vr_link']              = $vr_link;
    
    if($agentInfo['id'] > 0){  }else{
        $updateData['xm']                   = $xm;
        $updateData['tel']                  = $tel;
        $updateData['wx']                   = $wx;
    }
    
    $updateData['house_tel']            = $house_tel;
    $updateData['house_no']             = $house_no;
    $updateData['search_text']          = $searchText;
    $updateData['content']              = $content;
    $updateData['shenhe_status']        = 1;
    
    if($old_user_id != $user_id ){
        if($expire_status == 3){
            $updateData['expire_status']  = $expire_status;
        }else{
            if($expire_time < TIMESTAMP){
                $updateData['expire_status']    = 2;
                $updateData['expire_time']      = 0;
            }else{
                $updateData['expire_status']    = 1;
                $updateData['expire_time']      = $expire_time;
            }
        }
    }
    $updateData['refresh_time'] = TIMESTAMP;
    if(C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchan_id,$updateData)){
        C::t("#tom_tcfangchan#tom_tcfangchan_attr")->delete_by_tcfangchan_id($tcfangchan_id);
        C::t("#tom_tcfangchan#tom_tcfangchan_photo")->delete_by_tcfangchan_id($tcfangchan_id);
        C::t("#tom_tcfangchan#tom_tcfangchan_tag")->delete_by_tcfangchan_id($tcfangchan_id);

        $insertData = array();
        $insertData['tcfangchan_id']   = $tcfangchan_id;

        if($tcfangchanInfo['model_id'] == 'ershoufang'){

            $insertData['attr_zhuangxiu_type']  = $attr_zhuangxiu_type;
            $insertData['attr_house_type']      = $attr_house_type;
            $insertData['attr_chaoxiang_type']  = $attr_chaoxiang_type;
            $insertData['attr_shi']             = $attr_shi;
            $insertData['attr_ting']            = $attr_ting;
            $insertData['attr_wei']             = $attr_wei;
            $insertData['attr_louceng']         = $attr_louceng;
            $insertData['attr_cengshu']         = $attr_cengshu;
            $insertData['attr_chanquan']        = $attr_chanquan;
            $insertData['attr_elevator']        = $attr_elevator;
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;

        }else if($tcfangchanInfo['model_id'] == 'chuzu'){

            $insertData['attr_zhuangxiu_type']  = $attr_zhuangxiu_type;
            $insertData['attr_house_type']      = $attr_house_type;
            $insertData['attr_chaoxiang_type']  = $attr_chaoxiang_type;
            $insertData['attr_shi']             = $attr_shi;
            $insertData['attr_ting']            = $attr_ting;
            $insertData['attr_wei']             = $attr_wei;
            $insertData['attr_louceng']         = $attr_louceng;
            $insertData['attr_cengshu']         = $attr_cengshu;
            $insertData['attr_lease_type']      = $attr_lease_type;
            $insertData['attr_rent_type']       = $attr_rent_type;
            $insertData['attr_rent_unit']       = $attr_rent_unit;
            $insertData['attr_elevator']        = $attr_elevator;
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;
            $insertData['attr_peitao_tags']     = $attrPeitaoTagsStr;

        }else if($tcfangchanInfo['model_id'] == 'shangpu'){

            if($fangchan_nature == 1){
                $insertData['attr_rent_type']       = $attr_rent_type;
                $insertData['attr_rent_unit']       = $attr_rent_unit;
            }
            $insertData['attr_shangpu_type']    = $attr_shangpu_type;
            $insertData['attr_louceng']         = $attr_louceng;
            $insertData['attr_cengshu']         = $attr_cengshu;
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;

        }else if($tcfangchanInfo['model_id'] == 'xiezilou'){

            if($fangchan_nature == 1){
                $insertData['attr_rent_type']       = $attr_rent_type;
                $insertData['attr_rent_unit']       = $attr_rent_unit;
            }
            $insertData['attr_louceng']         = $attr_louceng;
            $insertData['attr_cengshu']         = $attr_cengshu;
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;

        }else if($tcfangchanInfo['model_id'] == 'changfang'){

            if($fangchan_nature == 1){
                $insertData['attr_rent_type']       = $attr_rent_type;
                $insertData['attr_rent_unit']       = $attr_rent_unit;
            }
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;

            if($fangchan_nature == 1){
                $insertData['attr_rent_type']       = $attr_rent_type;
                $insertData['attr_rent_unit']       = $attr_rent_unit;
            }
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;

        }else if($tcfangchanInfo['model_id'] == 'tudi'){

            if($fangchan_nature == 1){
                $insertData['attr_rent_type']       = $attr_rent_type;
                $insertData['attr_rent_unit']       = $attr_rent_unit;
            }
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;

        }else if($tcfangchanInfo['model_id'] == 'cangku'){

            if($fangchan_nature == 1){
                $insertData['attr_rent_type']       = $attr_rent_type;
                $insertData['attr_rent_unit']       = $attr_rent_unit;
            }
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;

        }

        $insertData['attr_time']            = TIMESTAMP;
        C::t("#tom_tcfangchan#tom_tcfangchan_attr")->insert($insertData);

        if(is_array($configTagList) && !empty($configTagList)){
            foreach($configTagList as $key => $value){
                $insertData = array();
                $insertData['tcfangchan_id']    = $tcfangchan_id;
                $insertData['config_tag_id']    = $value['id'];
                $insertData['config_tag_ids']   = $attrTeseTagsIdsStr;
                $insertData['name']             = $value['name'];
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_tag")->insert($insertData);
            }
        }

        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['tcfangchan_id'] = $tcfangchan_id;
                $insertData['type']          = 1;
                $insertData['picurl']       = $value['picurl'];
                $insertData['psort']        = $value['sort'];
                $insertData['add_time']     = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
        }
        if(!empty($vr_picurl)){
            $insertData = array();
            $insertData['tcfangchan_id']    = $tcfangchan_id;
            $insertData['type']             = 2;
            $insertData['picurl']           = $vr_picurl;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        if(!empty($video_pic)){
            $insertData = array();
            $insertData['tcfangchan_id']    = $tcfangchan_id;
            $insertData['type']             = 4;
            $insertData['picurl']           = $video_pic;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }    

        update_fangchan_tongcheng($tcfangchan_id);

        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == 'check_user_id' && $_GET['formhash'] == FORMHASH ){
    $outArr = array(
        'code'=> 1,
    );
    
    $user_id   = intval($_GET['user_id'])>0 ? intval($_GET['user_id']):0;
    
    $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($user_id);
    $agent_status = $vip_status = 0;
    if($agentInfo['id'] > 0){
        
        $agent_status = 1;
        
        if($agentInfo['shenhe_status'] == 1){
            $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
            
            $mendianVipInfo = array();
            if($tcfangchanConfig['open_mendian_vip'] == 1 && $mendianInfo['vip_id'] > 0 && $mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
                
                $mendianVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
                if(is_array($mendianVipInfo) && !empty($mendianVipInfo)){
                    
                    if($mendianVipInfo['total_agent_fabu_num'] > 0){
                        
                        $mendianFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$user_id} AND expire_status = 3 AND pay_type = 3 AND add_time > {$mendianInfo['vip_add_time']} ");
                        if($mendianVipInfo['total_agent_fabu_num'] > $mendianFangchanCount){
                            $vip_status = 1;
                        }
                    }
                }
            }
            
            $agentVipInfo = array();
            if($tcfangchanConfig['open_agent_vip'] == 1 && $agentInfo['vip_id'] > 0 && $agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP){
                $agentVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
                if(is_array($agentVipInfo) && !empty($agentVipInfo)){
                    
                    if($agentVipInfo['total_fabu_num'] > 0){
                        $agentFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$user_id} AND expire_status = 3 AND pay_type = 4 AND add_time > {$agentInfo['vip_add_time']} ");
                        if( $agentVipInfo['total_fabu_num'] > $agentFangchanCount){
                            $vip_status = 1;
                        }
                    }
                }
            }
        }
    }
    
    $outArr = array(
        'code'  => 200,
        'vip_status'    => $vip_status,
        'agent_status'  => $agent_status,
    );
    
    echo json_encode($outArr); exit;
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id DESC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$modelIdsArr = array(
    'ershoufang' => $Lang['ershoufang'],
    'chuzu' => $Lang['chuzu'],
    'shangpu' => $Lang['shangpu'],
    'xiezilou' => $Lang['xiezilou'],
    'changfang' => $Lang['changfang'],
    'cangku' => $Lang['cangku'],
    'tudi' => $Lang['tudi'],
);

if($tcfangchanInfo['model_id'] == 'ershoufang' || $tcfangchanInfo['model_id'] == 'chuzu' || $tcfangchanInfo['model_id'] == 'shangpu' || $tcfangchanInfo['model_id'] == 'xiezilou'){
    if($tcfangchanConfig['open_trade'] == 1){
        $tradeListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_trade")->fetch_all_list("", 'ORDER BY tsort ASC,id DESC');
        $tradeList = array();
        if(is_array($tradeListTmp) && !empty($tradeListTmp)){
            foreach($tradeListTmp as $key => $value){
                $tradeList[$key] = $value;
            }
        }
    }
}

$agent_status = 0;
$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
if($agentInfo['id'] > 0){
    $agent_status = 1;
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($tcfangchanInfo['city_id']);
$areaList = array();
if(!empty($areaListTmp)){
    foreach ($areaListTmp as $key => $value){
        $areaList[$value['id']] = $value;
    }
}

$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($tcfangchanInfo['area_id']);
$streetList = array();
if(!empty($streetListTmp)){
    foreach ($streetListTmp as $key => $value){
        $streetList[$value['id']] = $value;
    }
}

$attrInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_attr")->fetch_all_list(" AND tcfangchan_id={$tcfangchan_id} ", 'ORDER BY attr_id DESC', 0, 1);
$attrInfo = array();
if(is_array($attrInfoTmp) && !empty($attrInfoTmp[0])){
    $attrInfo = $attrInfoTmp[0];
}

$photoListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list(" AND tcfangchan_id={$tcfangchan_id} ", 'ORDER BY psort ASC,id ASC', 0, 50);
$photoList = array();
$video_pic = $vr_pic = $video_pic_src = $vr_pic_src = '';
$photoCount = 0;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];
        if($value['type'] == 1){
            $photoList[$key] = $value;
            $photoList[$key]['picurlTmp'] = $picurlTmp;
            $photoCount++;
            $photoList[$key]['i'] = $photoCount;
        }else if($value['type'] == 2){
            $vr_pic = $value['picurl'];
            $vr_pic_src = $value['picurlTmp'];
        }else if($value['type'] == 4){
            $video_pic = $value['picurl'];
            $video_pic_src = $value['picurlTmp'];
        }
    }
}

$tcfangchanInfo['content']    = stripcslashes($tcfangchanInfo['content']);

$teseTagListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config_tag")->fetch_all_list(" AND model_id = '{$tcfangchanInfo['model_id']}' ", 'ORDER BY tsort ASC,id DESC', 0, 30);
$teseTagList = array();
if(is_array($teseTagListTmp) && !empty($teseTagListTmp)){
    foreach($teseTagListTmp as $key => $value){
        $teseTagList[$value['id']] = $value['name'];
    }
}

$teseStr = trim($attrInfo['attr_tese_tags'], '|');
$teseArr = explode('|', $teseStr);
$teseTypeList = array();
if(is_array($teseTagList) && !empty($teseTagList)){
    foreach($teseTagList as $key => $value){
        $teseTypeList[$key]['name'] = $value;
        if(in_array($value ,$teseArr)){
            $teseTypeList[$key]['checked'] = 1;
        }
    }
}

$chooseHousesUrl = $pcadminUrl."&tmod=choose_houses";

$editUrl = $modPcadminUrl."&act=save";

if($tcfangchanInfo['model_id'] == 'ershoufang'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:pcadmin/edit/ershoufang");

}else if($tcfangchanInfo['model_id'] == 'chuzu'){

    $chuzuPeitaoStr = trim($attrInfo['attr_peitao_tags'], '|');
    $chuzuPeitaoArray = explode('|', $chuzuPeitaoStr);
    $chuzuPeitaoList = array();
    if(is_array($chuzuPeitaoArr) && !empty($chuzuPeitaoArr)){
        foreach($chuzuPeitaoArr as $key => $value){
            $chuzuPeitaoList[$key]['name'] = $value['name'];
            if(in_array($value['name'] ,$chuzuPeitaoArray)){
                $chuzuPeitaoList[$key]['checked'] = 1;
            }
        }
    }

    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:pcadmin/edit/chuzu");

}else if($tcfangchanInfo['model_id'] == 'shangpu'){

    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:pcadmin/edit/shangpu");

}else if($tcfangchanInfo['model_id'] == 'xiezilou'){

    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:pcadmin/edit/xiezilou");

}else if($tcfangchanInfo['model_id'] == 'changfang'){

    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:pcadmin/edit/changfang");

}else if($tcfangchanInfo['model_id'] == 'cangku'){

    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:pcadmin/edit/cangku");

}else if($tcfangchanInfo['model_id'] == 'tudi'){

    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:pcadmin/edit/tudi");

}else{

    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:pcadmin/list");

}