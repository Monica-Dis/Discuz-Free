<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$mendian_id = intval($_GET['mendian_id'])>0? intval($_GET['mendian_id']):0;

$modPcadminUrl = $pcadminUrl."&tmod=viplog&mendian_id={$mendian_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'list' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $page       = intval($_GET['page'])>0 ? intval($_GET['page']) :1;
    $pagesize   = intval($_GET['pagesize'])>0 ? intval($_GET['pagesize']) :10;
    
    $where = "  AND mendian_id = {$mendian_id} ";
    
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_log')->fetch_all_count($where);
    $logListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_log')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    $logList = array();
    if(!empty($logListTmp)){
        foreach($logListTmp as $key => $value){
            $logList[$key] = $value;
            
            $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
            $agentInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($value['agent_id']);
            
            $logList[$key]['userInfo']  = $userInfoTmp;
            $logList[$key]['agentInfo'] = $agentInfoTmp;
            $logList[$key]['log_time']  = dgmdate($value['log_time'],"Y-m-d H:i:s",$tomSysOffset);
        }
    }
    
    $list = iconv_to_utf8($logList);
    
    $outArr = array(
        'code'  => 0,
        'msg'   => '',
        'count' => $count,
        'data'  => $list,
    );
    echo json_encode($outArr); exit;
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/viplog");