<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=mendian";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'mendian_viplist' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );

    $vipListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_mendian_vip')->fetch_all_list(" "," ORDER BY vsort ASC,id DESC ",0,100);
    $vipList = array();
    if(!empty($vipListTmp)){
        foreach($vipListTmp as $key => $value){
            $vipList[$key] = $value;
        }
    }
    
    $vipList = iconv_to_utf8($vipList);
    
    $outArr = array(
        'code'  => 200,
        'list'  => $vipList,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'editvip' && submitcheck('mendian_id')){
    $outArr = array(
        'code'=> 1,
    );

    $mendian_id        = intval($_GET['mendian_id'])>0 ? intval($_GET['mendian_id']):0; 
    $vip_id            = intval($_GET['vip_id'])>0? intval($_GET['vip_id']):0;
    $expire_time       = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time       = strtotime($expire_time);
    
    $updateData = array();
    if($expire_time > TIMESTAMP){
        $updateData['vip_id']          = $vip_id;
        $updateData['expire_status']   = 1;
        $updateData['expire_time']     = $expire_time;
        $updateData['vip_add_time']    = TIMESTAMP;
    }else{
        $updateData['expire_status']   = 0;
        $updateData['expire_time']     = $expire_time;
    }
    C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendian_id,$updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'edittop' && submitcheck('mendian_id')){
    $outArr = array(
        'code'=> 1,
    );

    $mendian_id      = intval($_GET['mendian_id'])>0 ? intval($_GET['mendian_id']):0;
    $top_time        = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
    $top_time        = strtotime($top_time);
        
    $updateData = array();
    
    if($top_time <= TIMESTAMP){
        $updateData['top_status'] = 0;
        $updateData['top_time']   = 0;
    }else{
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
    }
    C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendian_id,$updateData);
    
    update_mendian_tcshop($mendian_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'edituser' && submitcheck('mendian_id')){
    $outArr = array(
        'code'=> 1,
    );

    $mendian_id     = intval($_GET['mendian_id'])>0 ? intval($_GET['mendian_id']):0;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    
    $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($mendian_id);
    
    if($mendianInfo['user_id'] == $user_id){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['mendian_edituser_error1'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    if($userInfo && $userInfo['id'] > 0){}else{
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['mendian_edituser_error2'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    $isHaveMendian = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_user_id($user_id);
    if($isHaveMendian && $isHaveMendian['id'] > 0){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['mendian_edituser_error3'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($user_id);
    if($agentInfo && $agentInfo['id'] > 0 && $agentInfo['mendian_id'] != $mendianInfo['id']){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['mendian_edituser_error4'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    
    DB::query("UPDATE ".DB::table('tom_tcfangchan_mendian')." SET user_id={$user_id} WHERE user_id='{$mendianInfo['user_id']}'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET user_id={$user_id} WHERE user_id='{$mendianInfo['user_id']}'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tcfangchan_log')." SET user_id={$user_id} WHERE user_id='{$mendianInfo['user_id']}'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tcfangchan_order')." SET user_id={$user_id} WHERE user_id='{$mendianInfo['user_id']}'", 'UNBUFFERED');
    
    if($agentInfo && $agentInfo['id'] > 0){ }else{
            
        $insertData = array();
        $insertData['site_id']              = $mendianInfo['site_id'];
        $insertData['mendian_id']           = $mendianInfo['id'];
        $insertData['user_id']              = $user_id;
        $insertData['avatar']               = $tcfangchanConfig['default_agent_avatar'];
        $insertData['name']                 = $userInfo['nickname'];
        $insertData['tel']                  = $userInfo['tel'];
        $insertData['is_ok']                = 0;
        $insertData['shenhe_status']        = 1;
        $insertData['add_time']             = TIMESTAMP;
        if(C::t("#tom_tcfangchan#tom_tcfangchan_agent")->insert($insertData)){

            DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET source_type=1 WHERE user_id = {$user_id} ", 'UNBUFFERED');
            
            if(!empty($tongchengConfig['template_id']) && $userInfo){
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($userInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mymendian");
                    $smsData = array(
                        'first'         => $Lang['template_edit_mymendian_xinxi_msg'],
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                    
                }
            }
        }
    }
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
    
}else if($act == 'del' && submitcheck('mendian_id')){
    $outArr = array(
        'code'=> 1,
    );

    $mendian_id   = intval($_GET['mendian_id'])>0 ? intval($_GET['mendian_id']):0;
        
    C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->delete_by_id($mendian_id);
    
    $agentList = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_agent_list(" AND mendian_id = {$mendian_id}");
    
    if(is_array($agentList) && !empty($agentList)){
        foreach($agentList as $key => $value){
            DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET source_type=2 WHERE user_id = {$value['user_id']} ", 'UNBUFFERED');
        }
    }
    C::t('#tom_tcfangchan#tom_tcfangchan_agent')->delete_by_mendian_id($mendian_id);
    C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_mendian_id($mendian_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'shenhe' && submitcheck('mendian_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $mendian_id     = intval($_GET['mendian_id'])>0 ? intval($_GET['mendian_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0 ? intval($_GET['shenhe_status']):0;
    $text           = isset($_GET['text'])? addslashes($_GET['text']):'';
    
    $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($mendian_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($mendianInfo['user_id']);
    
    if($shenhe_status == 1){
        $updateData = array();
        $updateData['shenhe_status']    = 1;
        C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendian_id,$updateData);
        
        update_mendian_tcshop($mendianInfo['id']);
        
        $shenhe = str_replace('{NAME}', $mendianInfo['name'], $Lang['template_mendian_shenhe_ok']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$mendianInfo['site_id'].'&mod=mendianinfo&mendian_id='.$mendianInfo['id'].'">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$mendianInfo['site_id']}&mod=mendianinfo&mendian_id=".$mendianInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
       
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($shenhe_status == 3){
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendian_id,$updateData);
        
        update_mendian_tcshop($mendianInfo['id']);
        
        $shenhe = str_replace('{NAME}', $mendianInfo['name'], $Lang['template_mendian_shenhe_no']);
        $tzShenhe = $shenhe.'<br/>'.$text.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$mendianInfo['site_id'].'&mod=mendianedit">['.$Lang['template_dianjichakan'].']</a>';
        
        if(!empty($tongchengConfig['template_id']) && $userInfo){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$mendianInfo['site_id']}&mod=mendianedit");
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => $text
                );
                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                }else{
                    $outArr = array(
                        'code'=> 200,
                        'send_status'=> 301,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
        $insertData = array();
        $insertData['user_id']      = $userInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    echo json_encode($outArr); exit;
}

$keyword            = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$mendian_id         = isset($_GET['mendian_id'])? intval($_GET['mendian_id']):0;
$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$whereStr = '';
if(!empty($site_id)){
    $whereStr.= " AND site_id={$site_id} ";
}
if($user_id > 0){
    $whereStr.= " AND user_id={$user_id} ";
}
if($mendian_id > 0){
    $whereStr.= " AND id={$mendian_id} ";
}
if($shenhe_status > 0){
    $whereStr.= " AND shenhe_status={$shenhe_status} ";
}
if($top_status > 0){
    if($top_status == 1){
        $whereStr.= " AND top_status = 1 ";
    }else if($top_status == 2){
        $whereStr.= " AND top_status = 0 ";
    }
}

$order = "ORDER BY id DESC";

$start  = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_count($whereStr,$keyword);
$mendianListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_list($whereStr,$order,$start,$pagesize,$keyword);
$mendianList = array();
if(!empty($mendianListTmp)){
    foreach ($mendianListTmp as $key => $value) {
        $mendianList[$key] = $value;
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $vipInfoTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_mendian_vip')->fetch_by_id($value['vip_id']);
        
        $mendianList[$key]['siteInfo']      = $siteInfoTmp;
        $mendianList[$key]['userInfo']      = $userInfoTmp;
        $mendianList[$key]['vipInfo']       = $vipInfoTmp;
        $mendianList[$key]['add_time']      = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        $mendianList[$key]['expire_time']   = dgmdate($value['expire_time'],"Y-m-d H:i",$tomSysOffset);
        $mendianList[$key]['top_time']      = dgmdate($value['top_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&user_id={$user_id}&shenhe_status={$shenhe_status}&top_status={$top_status}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/mendian");