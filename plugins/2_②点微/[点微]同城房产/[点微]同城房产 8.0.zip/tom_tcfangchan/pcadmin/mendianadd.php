<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=mendianadd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('user_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id            = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $site_id            = intval($_GET['site_id'])>0? intval($_GET['site_id']):1;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $city_id            = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $lng                = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $business_hours     = isset($_GET['business_hours'])? addslashes($_GET['business_hours']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $shopkeeper_tel     = isset($_GET['shopkeeper_tel'])? addslashes($_GET['shopkeeper_tel']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $logo               = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    $business_licence   = isset($_GET['business_licence'])? addslashes($_GET['business_licence']):'';
    
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_user_id($user_id);
    
    if(is_array($mendianInfo) && !empty($mendianInfo)){
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['mendianadd_error'],CHARSET,'utf-8'),
        );
        echo json_encode($outArr); exit;
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk]['picurl'] = addslashes($value);
        }
        if(strpos($key, "photopsort_") !== false){
            $kk = intval(ltrim($key, "photopsort_"));
            $photoArr[$kk]['psort'] = addslashes($value);
        }
    }
  
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            if(!empty($sitesInfoTmp['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($sitesInfoTmp['city_id']);
                if($cityInfoTmp){
                    $city_id = $cityInfoTmp['id'];
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $city_id = $cityInfoTmp['id'];
        }
    }
    
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['user_id']          = $user_id;
    $insertData['name']             = $name;
    $insertData['city_id']          = $city_id;
    $insertData['area_id']          = $area_id;
    $insertData['area_name']        = $areaInfo['name'];
    $insertData['street_id']        = $street_id;
    $insertData['street_name']      = $streetInfo['name'];
    $insertData['address']          = $address;
    $insertData['latitude']         = $lat;
    $insertData['longitude']        = $lng;
    $insertData['business_hours']   = $business_hours;
    $insertData['tel']              = $tel;
    $insertData['shopkeeper_tel']   = $shopkeeper_tel;
    $insertData['content']          = $content;
    $insertData['search_text']      = $name.'|++++|'.$tel.'|++++|'.$address;
    $insertData['shenhe_status']    = 1;
    $insertData['admin_edit']       = 1;
    $insertData['add_time']         = TIMESTAMP;
    $mendian_id = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->insert($insertData, true);    
        
    if($mendian_id > 0){
        
        $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($mendian_id);
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($mendianInfo['user_id']);
            
        update_mendian_tcshop($mendian_id);

        if(!empty($logo)){
            $insertData = array();
            $insertData['mendian_id']       = $mendian_id;
            $insertData['type']             = 5;
            $insertData['picurl']           = $logo;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }

        if(!empty($photoArr)){
            foreach($photoArr as $key => $value){
                $insertData = array();
                $insertData['mendian_id']    = $mendian_id;
                $insertData['type']          = 6;
                $insertData['picurl']        = $value['picurl'];
                $insertData['psort']         = $value['psort'];
                $insertData['add_time']      = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
        }
        
        if(!empty($business_licence)){
            $insertData = array();
            $insertData['mendian_id']       = $mendian_id;
            $insertData['type']             = 7;
            $insertData['picurl']           = $business_licence;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        
        $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($userInfo['id']);
        
        if(is_array($agentInfo) && !empty($agentInfo)){
            $updateData = array();
            $updateData['site_id']              = $mendianInfo['site_id'];
            $updateData['mendian_id']           = $mendian_id;
            $updateData['name']                 = $userInfo['nickname'];
            $updateData['tel']                  = $userInfo['tel'];
            $updateData['is_ok']                = 0;
            $updateData['shenhe_status']        = 1;
            C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($agentInfo['id'],$updateData);
            
        }else{
            $insertData = array();
            $insertData['site_id']              = $mendianInfo['site_id'];
            $insertData['mendian_id']           = $mendian_id;
            $insertData['user_id']              = $userInfo['id'];
            $insertData['avatar']               = $tcfangchanConfig['default_agent_avatar'];
            $insertData['name']                 = $userInfo['nickname'];
            $insertData['tel']                  = $userInfo['tel'];
            $insertData['is_ok']                = 0;
            $insertData['shenhe_status']        = 1;
            $insertData['add_time']             = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_agent")->insert($insertData);
            
        }
        
        DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET source_type=1 WHERE user_id = {$userInfo['id']} ", 'UNBUFFERED');
        if(!empty($tongchengConfig['template_id'])){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mymendian");
                $smsData = array(
                    'first'         => $Lang['template_edit_mymendian_xinxi_msg'],
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }

        $outArr = array(
            'code'=> 200,
            'id'=> $mendian_id,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(is_array($sitesListTmp) && !empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$__CityInfo = array();
if(!empty($tongchengConfig['city_id'])){
    $__CityInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);

$addUrl = $modPcadminUrl."&act=add";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:pcadmin/mendianadd");