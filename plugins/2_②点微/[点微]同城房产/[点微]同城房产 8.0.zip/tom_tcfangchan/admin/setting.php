<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=setting';
$modListUrl = $adminListUrl.'&tmod=setting';
$modFromUrl = $adminFromUrl.'&tmod=setting';

if(submitcheck('submit')){
    $updateData = array();
    $updateData = __get_post_data($fangchanSetting);
    C::t('#tom_tcfangchan#tom_tcfangchan_setting')->update(1,$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['setting_title'] . '</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    tomloadcalendarjs();
    loadeditorjs();
    showformheader($modFromUrl,'enctype');
    showtableheader();
    __create_info_html($fangchanSetting);
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $open_video                 = isset($_GET['open_video'])? intval($_GET['open_video']):0;
    $open_vr                    = isset($_GET['open_vr'])? intval($_GET['open_vr']):0;
    $open_house_no              = isset($_GET['open_house_no'])? intval($_GET['open_house_no']):0;
    $open_house_tel             = isset($_GET['open_house_tel'])? intval($_GET['open_house_tel']):0;
    $open_attr_chanquan         = isset($_GET['open_attr_chanquan'])? intval($_GET['open_attr_chanquan']):0;
    $open_attr_elevator         = isset($_GET['open_attr_elevator'])? intval($_GET['open_attr_elevator']):0;
    
    $mendianinfo_share_title    = isset($_GET['mendianinfo_share_title'])? addslashes($_GET['mendianinfo_share_title']):'';
    $mendianinfo_share_desc     = isset($_GET['mendianinfo_share_desc'])? addslashes($_GET['mendianinfo_share_desc']):'';
    $agentinfo_share_title      = isset($_GET['agentinfo_share_title'])? addslashes($_GET['agentinfo_share_title']):'';
    $agentinfo_share_desc       = isset($_GET['agentinfo_share_desc'])? addslashes($_GET['agentinfo_share_desc']):'';
    
    $fabu_top_style             = isset($_GET['fabu_top_style'])? intval($_GET['fabu_top_style']):0;
    $open_over_expire_status3   = isset($_GET['open_over_expire_status3'])? intval($_GET['open_over_expire_status3']):0;
    $over_expire_status3_days   = isset($_GET['over_expire_status3_days'])? intval($_GET['over_expire_status3_days']):0;
    
    $data['open_video']                 = $open_video;
    $data['open_vr']                    = $open_vr;
    $data['open_house_no']              = $open_house_no;
    $data['open_house_tel']             = $open_house_tel;
    $data['open_attr_chanquan']         = $open_attr_chanquan;
    $data['open_attr_elevator']         = $open_attr_elevator;
    
    $data['mendianinfo_share_title']    = $mendianinfo_share_title;
    $data['mendianinfo_share_desc']     = $mendianinfo_share_desc;
    $data['agentinfo_share_title']      = $agentinfo_share_title;
    $data['agentinfo_share_desc']       = $agentinfo_share_desc;
    
    $data['fabu_top_style']             = $fabu_top_style;
    $data['open_over_expire_status3']   = $open_over_expire_status3;
    $data['over_expire_status3_days']   = $over_expire_status3_days;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'open_video'                => 0,
        'open_vr'                   => 0,
        'open_house_no'             => 0,
        'open_house_tel'            => 0,
        'open_attr_chanquan'        => 0,
        'open_attr_elevator'        => 0,
        
        'mendianinfo_share_title'   => '',
        'mendianinfo_share_desc'    => '',
        'agentinfo_share_title'     => '',
        'agentinfo_share_desc'      => '',
        
        'fabu_top_style'            => 0,
        'open_over_expire_status3'  => 0,
        'over_expire_status3_days'  => 30,
        
    );
    $options = array_merge($options, $infoArr);
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/config/setting.lang.php';
    
    $open_item = array(1=>$Lang['open'],0=>$Lang['close']);
    
    tomshowsetting(true,array('title'=>$settingLang['open_video'],'name'=>'open_video','value'=>$options['open_video'],'msg'=>$settingLang['open_video_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['open_vr'],'name'=>'open_vr','value'=>$options['open_vr'],'msg'=>$settingLang['open_vr_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['open_house_no'],'name'=>'open_house_no','value'=>$options['open_house_no'],'msg'=>$settingLang['open_house_no_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['open_house_tel'],'name'=>'open_house_tel','value'=>$options['open_house_tel'],'msg'=>$settingLang['open_house_tel_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['open_attr_chanquan'],'name'=>'open_attr_chanquan','value'=>$options['open_attr_chanquan'],'msg'=>$settingLang['open_attr_chanquan_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['open_attr_elevator'],'name'=>'open_attr_elevator','value'=>$options['open_attr_elevator'],'msg'=>$settingLang['open_attr_elevator_msg'],'item'=>$open_item),"radio");
    
    tomshowsetting(true,array('title'=>$settingLang['mendianinfo_share_title'],'name'=>'mendianinfo_share_title','value'=>$options['mendianinfo_share_title'],'msg'=>$settingLang['mendianinfo_share_title_msg']),"input");
    tomshowsetting(true,array('title'=>$settingLang['mendianinfo_share_desc'],'name'=>'mendianinfo_share_desc','value'=>$options['mendianinfo_share_desc'],'msg'=>$settingLang['mendianinfo_share_desc_msg']),"input");
    tomshowsetting(true,array('title'=>$settingLang['agentinfo_share_title'],'name'=>'agentinfo_share_title','value'=>$options['agentinfo_share_title'],'msg'=>$settingLang['agentinfo_share_title_msg']),"input");
    tomshowsetting(true,array('title'=>$settingLang['agentinfo_share_desc'],'name'=>'agentinfo_share_desc','value'=>$options['agentinfo_share_desc'],'msg'=>$settingLang['agentinfo_share_desc_msg']),"input");
    
    $fabu_top_style_item = array(1=>$settingLang['fabu_top_style_1'],2=>$settingLang['fabu_top_style_2']);
    tomshowsetting(true,array('title'=>$settingLang['fabu_top_style'],'name'=>'fabu_top_style','value'=>$options['fabu_top_style'],'msg'=>$settingLang['fabu_top_style_msg'],'item'=>$fabu_top_style_item),"radio");
    
    tomshowsetting(true,array('title'=>$settingLang['open_over_expire_status3'],'name'=>'open_over_expire_status3','value'=>$options['open_over_expire_status3'],'msg'=>$settingLang['open_over_expire_status3_msg'],'item'=>$open_item),"radio");
    tomshowsetting(true,array('title'=>$settingLang['over_expire_status3_days'],'name'=>'over_expire_status3_days','value'=>$options['over_expire_status3_days'],'msg'=>$settingLang['over_expire_status3_days_msg']),"input");
    
    return;
}