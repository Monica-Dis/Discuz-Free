<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=newhouses_manage';
$modListUrl = $adminListUrl.'&tmod=newhouses_manage';
$modFromUrl = $adminFromUrl.'&tmod=newhouses_manage';

if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_manage')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'edit'){
    
    $manageInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_manage')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($manageInfo);
        C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_manage')->update($manageInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($manageInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $newhousesManageInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_manage')->fetch_by_id($_GET['id']);
    C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_manage')->delete_by_id($_GET['id']);
    DB::query("UPDATE ".DB::table('tom_tcfangchan_newhouses')." SET user_id=0 WHERE user_id = {$newhousesManageInfo['user_id']} ", 'UNBUFFERED');
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if($user_id > 0){
        $where .= " AND user_id={$user_id} ";
    }
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_manage')->fetch_all_count($where);
    $manageList = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_manage')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['user_id'] . '</th>';
    echo '<th width="300">' . $Lang['newhouses_manage_beizu'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($manageList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f70404">(ID:'.$value['user_id']. ')</font></td>';
        echo '<td>' . $value['beizu'] . '</td>';
        echo '<td>' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $beizu          = isset($_GET['beizu'])? addslashes($_GET['beizu']):'';
    
    $data['user_id']            = $user_id;
    $data['beizu']              = $beizu;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$mendian_id;
    $options = array(
        'user_id'       => 0,
        'beizu'         => '',
    );
    
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_manage_beizu'],'name'=>'beizu','value'=>$options['beizu'],'msg'=>$Lang['newhouses_manage_beizu_msg']),"textarea");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['newhouses_manage_title'],$modBaseUrl,false);
        tomshownavli($Lang['newhouses_manage_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['newhouses_manage_title'],$modBaseUrl,false);
        tomshownavli($Lang['newhouses_manage_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['edit'],"",true);
    }else{
        tomshownavli($Lang['newhouses_manage_title'],$modBaseUrl,true);
        tomshownavli($Lang['newhouses_manage_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}