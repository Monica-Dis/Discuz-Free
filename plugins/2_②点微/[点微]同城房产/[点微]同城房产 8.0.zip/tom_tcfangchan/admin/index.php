<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_tcfangchan_admin_index_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'info'){
    
    $info = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($_GET['id']);
    $attrInfo = C::t('#tom_tcfangchan#tom_tcfangchan_attr')->fetch_by_tcfangchan_id($_GET['id']);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($info['user_id']);
    $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($info['user_id']);
    if(is_array($agentInfo) && !empty($agentInfo)){
        $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
    }
    
    $photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id={$_GET['id']} "," ORDER BY type DESC,psort ASC,id ASC ",0,20);
    $photoList = array();
    $vrPicurl = $videoPicurl = '';
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach($photoListTmp as $key => $value){
            $picurlTmp = $value['picurlTmp'];
            
            if($value['type'] == 1){
                $photoList[] = $picurlTmp;
            }
            if($value['type'] == 2){
                $vrPicurl = $picurlTmp;
            }
            if($value['type'] == 4){
                $videoPicurl = $picurlTmp;
            }
        }
    }
    
    $attrTeseTagsArr = explode('|', trim($attrInfo['attr_tese_tags'], '|'));
    $attrPeitaoTagsArr = explode('|', trim($attrInfo['attr_peitao_tags'], '|'));
    
    $fenghao = $Lang['fenghao'];
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['info'] . '</th></tr>';
    echo '<tr><td align="right"><b>ID'.$fenghao.'</b></td><td>'.$info['id'].'</td></tr>';
    if($info['model_id'] == 'ershoufang'){
        echo '<tr><td align="right"><b>'.$Lang['index_model_id'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['ershoufang'].'</font></td></tr>';
    }else if($info['model_id'] == 'chuzu'){
        echo '<tr><td align="right"><b>'.$Lang['index_model_id'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['chuzu'].'</font></td></tr>';
    }else if($info['model_id'] == 'shangpu'){
        echo '<tr><td align="right"><b>'.$Lang['index_model_id'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['shangpu'].'</font></td></tr>';
    }else if($info['model_id'] == 'xiezilou'){
        echo '<tr><td align="right"><b>'.$Lang['index_model_id'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['xiezilou'].'</font></td></tr>';
    }else if($info['model_id'] == 'changfang'){
        echo '<tr><td align="right"><b>'.$Lang['index_model_id'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['changfang'].'</font></td></tr>';
    }else if($info['model_id'] == 'cangku'){
        echo '<tr><td align="right"><b>'.$Lang['index_model_id'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['cangku'].'</font></td></tr>';
    }else if($info['model_id'] == 'tudi'){
        echo '<tr><td align="right"><b>'.$Lang['index_model_id'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['tudi'].'</font></td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['index_model_id'].$fenghao.'</b></td><td> -- </td></tr>';
    }
    echo '<tr><td align="right"><b>'.$Lang['index_title'].$fenghao.'</b></td><td>'.$info['title'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_house_no'].$fenghao.'</b></td><td>'.$info['house_no'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_xm'].$fenghao.'</b></td><td>'.$info['xm'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_tel'].$fenghao.'</b></td><td>'.$info['tel'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_wx'].$fenghao.'</b></td><td>'.$info['wx'].'</td></tr>';
    if(!empty($info['house_tel'])){
        echo '<tr><td align="right"><b>'.$Lang['index_house_tel'].$fenghao.'</b></td><td>'.$info['house_tel'].'</td></tr>';
    }
    if($info['source_type'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_source_type'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['index_source_type_1'].'</font></td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['index_agent'].$fenghao.'</b></td><td><a href="'.$adminBaseUrl.'&tmod=agent&agent_id='.$agentInfo['id'].'" target="_blank">'.$agentInfo['name'].' <font color="#f00">(ID:'.$agentInfo['id'].')</a></font></td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['index_agent_mendian'].$fenghao.'</b></td><td><a href="'.$adminBaseUrl.'&tmod=mendian&mendian_id='.$agentInfo['mendian_id'].'" target="_blank">'.$mendianInfo['name'].' <font color="#f00">(ID:'.$agentInfo['mendian_id'].')</a></font></td></tr>';
    }else if($info['source_type'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['index_source_type'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['index_source_type_2'].'</font></td></tr>';
        echo '<tr><td align="right"><b>'.$Lang['index_user'].$fenghao.'</b></td><td>'.$userInfo['nickname'].' <font color="#f00">(ID:'.$info['user_id'].')</font></td></tr>';
    }
    
    if($tcfangchanConfig['open_trade'] == 1){
        if($info['trade_id'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['index_trade'].$fenghao.'</b></td><td>'.$info['trade_name'].'<font color="#f00">(ID:'.$info['trade_id'].')</font></td></tr>';
        }else{
            echo '<tr><td align="right"><b>'.$Lang['index_trade'].$fenghao.'</b></td><td>'.$Lang['index_trade_0'].'</td></tr>';
        }
    }
    
    echo '<tr><td align="right"><b>'.$Lang['index_quyu'].$fenghao.'</b></td><td>'.$info['area_name'].'-'.$info['street_name'].'</td></tr>';
    if(!empty($info['houses_name'])){
        echo '<tr><td align="right"><b>'.$Lang['index_houses_name'].$fenghao.'</b></td><td><a href="'.$adminBaseUrl.'&tmod=houses&houses_id='.$info['houses_id'].'" target="_blank">'.$info['houses_name'].' <font color="#f00">(ID:'.$info['houses_id'].')</font></a></td></tr>';
    }
    echo '<tr><td align="right"><b>'.$Lang['index_mianji'].$fenghao.'</b></td><td>'.$info['mianji'].$Lang['pingmi'].'</td></tr>';
    if($info['fangchan_nature'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_fangchan_nature'].$fenghao.'</b></td><td>'.$Lang['index_fangchan_nature_1'].'</td></tr>';
    }elseif($info['fangchan_nature'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['index_fangchan_nature'].$fenghao.'</b></td><td>'.$Lang['index_fangchan_nature_2'].'</td></tr>';
    }elseif($info['fangchan_nature'] == 3){
        echo '<tr><td align="right"><b>'.$Lang['index_fangchan_nature'].$fenghao.'</b></td><td>'.$Lang['index_fangchan_nature_3'].'</td></tr>';
    }
    if(!empty($info['price'])){
        echo '<tr><td align="right"><b>'.$Lang['index_price'].$fenghao.'</b></td><td>'.$info['price'].$Lang['index_price_unit'].'</td></tr>';
    }
    if($info['model_id'] == 'chuzu' || $info['fangchan_nature'] == 1){
        if($info['rent'] > 0){
            echo '<tr><td align="right"><b>'.$Lang['index_rent'].$fenghao.'</b></td><td>'.$info['rent'].' '.$rentUnitArr[$attrInfo['attr_rent_unit']].'</td></tr>';
        }else{
            echo '<tr><td align="right"><b>'.$Lang['index_rent'].$fenghao.'</b></td><td>'.$Lang['index_mianyi'].'</td></tr>';
        }
    }
    if(!empty($info['zhuanrang_price'])){
        echo '<tr><td align="right"><b>'.$Lang['index_zhuanrang_price'].$fenghao.'</b></td><td>'.$info['zhuanrang_price'].$Lang['index_zhuanrang_price_unit'].'</td></tr>';
    }
    if(!empty($attrInfo['attr_rent_type'])){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_rent_type'].$fenghao.'</b></td><td>'.$rentTypeArr[$attrInfo['attr_rent_type']].'</td></tr>';
    }
    echo '<tr><td align="right"><b>'.$Lang['latitude'].$fenghao.'</b></td><td>'.$info['latitude'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['longitude'].$fenghao.'</b></td><td>'.$info['longitude'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['index_address'].$fenghao.'</b></td><td>'.$info['address'].'</td></tr>';
    if(!empty($info['video_url'])){
        echo '<tr><td align="right"><b>'.$Lang['index_video_url'].$fenghao.'</b></td><td><a href="'.$info['video_url'].'" target="_blank">'.$info['video_url'].'</a></td></tr>';
    }
    if(!empty($info['vr_link'])){
        echo '<tr><td align="right"><b>'.$Lang['index_vr_link'].$fenghao.'</b></td><td><a href="'.$info['vr_link'].'" target="_blank">'.$info['vr_link'].'</a></td></tr>';
    }
    echo '<tr><td align="right"><b>'.$Lang['index_content'].$fenghao.'</b></td><td><p style="max-width:500px">'.$info['content'].'</p></td></tr>';
    
    if($info['top_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['top_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['top_status_1'].'('.dgmdate($info['top_time'], 'Y-m-d H:i:s',$tomSysOffset).')</font></td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['top_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['top_status_0'].'</font></td></tr>';
    }
    if($info['status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['index_status_1'].'</font></td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['index_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['index_status_0'].'</font></td></tr>';
    }
    if($info['shenhe_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['shenhe_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['shenhe_status_1'].'</font></td></tr>';
    }else if($info['shenhe_status'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['shenhe_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['shenhe_status_2'].'</font></td></tr>';
    }else if($info['shenhe_status'] == 3){
        echo '<tr><td align="right"><b>'.$Lang['shenhe_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['shenhe_status_3'].'</font></td></tr>';
    }
    if($info['finish'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_finish'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['index_finish_1'].'</font></td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['index_finish'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['index_finish_0'].'</font></td></tr>';
    }
    if($info['pay_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['pay_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['pay_status_1'].'</font></td></tr>';
    }else if($info['pay_status'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['pay_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['pay_status_2'].'</font></td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['pay_status'].$fenghao.'</b></td><td> -- </td></tr>';
    }
    if($info['expire_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['expire_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['expire_status_1'].'('.dgmdate($info['expire_time'], 'Y-m-d H:i:s',$tomSysOffset).')</font></td></tr>';
    }else if($info['expire_status'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['expire_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['expire_status_2'].'</font></td></tr>';
    }else if($info['expire_status'] == 3){
        echo '<tr><td align="right"><b>'.$Lang['expire_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['expire_status_3'].'</font></td></tr>';
    }
    echo '<tr><td align="right"><b>'.$Lang['index_clicks'].$fenghao.'</b></td><td>'.$info['clicks'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['refresh_time'].$fenghao.'</b></td><td>'.dgmdate($info['refresh_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['add_time'].$fenghao.'</b></td><td>'.dgmdate($info['add_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
    if(!empty($info['client_ip_port'])){
        echo '<tr><td align="right"><b>' . $Lang['index_client_ip_port'].$fenghao. '</b></td><td>'.$info['client_ip_port'].'</td></tr>';
    }
    if(!empty($attrInfo['attr_shangpu_type'])){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_shangpu_type'].$fenghao.'</b></td><td>'.$shangpuTypeArr[$attrInfo['attr_shangpu_type']].'</td></tr>';
    }
    if(!empty($attrInfo['attr_zhuangxiu_type'])){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_zhuangxiu_type'].$fenghao.'</b></td><td>'.$zhuangxiuTypeArr[$attrInfo['attr_zhuangxiu_type']].'</td></tr>';
    }
    if(!empty($attrInfo['attr_house_type'])){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_house_type'].$fenghao.'</b></td><td>'.$houseTypeArr[$attrInfo['attr_house_type']].'</td></tr>';
    }
    if(!empty($attrInfo['attr_shi'])){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_s_t_w'].$fenghao.'</b></td><td>'.$attrInfo['attr_shi'].$Lang['shi'].$attrInfo['attr_ting'].$Lang['ting'].$attrInfo['attr_wei'].$Lang['wei'].'</td></tr>';
    }
    if(!empty($attrInfo['attr_chaoxiang_type'])){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_chaoxiang_type'].$fenghao.'</b></td><td>'.$chaoxiangTypeArr[$attrInfo['attr_chaoxiang_type']].'</td></tr>';
    }
    if(!empty($attrInfo['attr_louceng'])){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_louceng'].$fenghao.'</b></td><td>'.$attrInfo['attr_louceng'].$Lang['lou'].'/'.$Lang['gong'].$attrInfo['attr_cengshu'].$Lang['ceng'].'</td></tr>';
    }
    if(!empty($attrInfo['attr_chanquan'])){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_chanquan'].$fenghao.'</b></td><td>'.$attrInfo['attr_chanquan'].$Lang['year'].'</td></tr>';
    }
    if($attrInfo['attr_elevator'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_elevator'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['index_attr_elevator_1'].'</font></td></tr>';
    }else if($attrInfo['attr_elevator'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_elevator'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['index_attr_elevator_2'].'</font></td></tr>';
    }
    if($attrInfo['attr_lease_type'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_lease_type'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['index_attr_lease_type_1'].'</font></td></tr>';
    }else if($attrInfo['attr_elevator'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_lease_type'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['index_attr_lease_type_2'].'</font></td></tr>';
    }
    
    if(!empty($attrInfo['attr_tese_tags'])){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_tese_tags'].$fenghao.'</b></td><td>';
        foreach($attrTeseTagsArr as $key => $value){
            echo '<span style="display:inline-block; margin-right:10px; line-height:20px; padding:0 10px; border:1px solid #f5833b; color:#f5833b">'.$value.'</span>';
        }
        echo '</td></tr>';
    }
    if(!empty($attrInfo['attr_peitao_tags'])){
        echo '<tr><td align="right"><b>'.$Lang['index_attr_peitao_tags'].$fenghao.'</b></td><td>';
        foreach($attrPeitaoTagsArr as $key => $value){
            echo '<span style="display:inline-block; margin-right:10px; line-height:20px; padding:0 10px; border:1px solid #f5833b; color:#f5833b">'.$value.'</span>';
        }
        echo '</td></tr>';
    }
    
    if(!empty($videoPicurl)){
        echo '<tr><td align="right"><b>'.$Lang['index_photo_video'].$fenghao.'</b></td><td><a href="'.$videoPicurl.'" target="_blank"><img width="100" height="100" src="'.$videoPicurl.'"></a></td></tr>';
    }
    
    if(!empty($vrPicurl)){
        echo '<tr><td align="right"><b>'.$Lang['index_photo_vr'].$fenghao.'</b></td><td><a href="'.$vrPicurl.'" target="_blank"><img width="100" height="100" src="'.$vrPicurl.'"></a></td></tr>';
    }
    
    if(is_array($photoList) && !empty($photoList)){
        echo '<tr><td align="right"><b>'.$Lang['index_photo_list'].$fenghao.'</b></td><td>';
        foreach($photoList as $key => $value){
            echo '<a href="'.$value.'" target="_blank"><img width="100" height="100" src="'.$value.'"></a>';
        }
        echo '</td></tr>';
    }
    
    showtablefooter(); /*dism��taobao��com*/
    
}else if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        
        $model_id   = isset($_GET['model_id'])? addslashes($_GET['model_id']):'';
        $site_id    = isset($_GET['site_id'])? intval($_GET['site_id']):0;
        $user_id    = isset($_GET['user_id'])? intval($_GET['user_id']):0;
        $title      = isset($_GET['title'])? addslashes($_GET['title']):'';
        
        $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($user_id);
        
        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['user_id']          = $user_id;
        $insertData['model_id']         = $model_id;
        $insertData['title']            = $title;
        if($agentInfo['id'] > 0){
            $insertData['source_type']      = 1;
        }else{
            $insertData['source_type']      = 2;
        }
        $insertData['status']           = 0;
        $insertData['shenhe_status']    = 1;
        $insertData['pay_type']         = 1;
        $insertData['add_time']         = TIMESTAMP;
        $insertData['refresh_time']     = TIMESTAMP;
        if(C::t('#tom_tcfangchan#tom_tcfangchan')->insert($insertData)){
            $tcfangchan_id = C::t('#tom_tcfangchan#tom_tcfangchan')->insert_id();
            
            cpmsg($Lang['act_success'], $modListUrl.'&act=edit&id='.$tcfangchan_id, 'succeed');
        }else{
            cpmsg($Lang['index_add_error'], $modListUrl.'&act=add', 'error');
        }
        
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=add&formhash='.FORMHASH);
        __create_nav_html();
        showtableheader();
        
        $modelIdsArr = array(
            'ershoufang' => $Lang['ershoufang'],
            'chuzu' => $Lang['chuzu'],
            'shangpu' => $Lang['shangpu'],
            'xiezilou' => $Lang['xiezilou'],
            'changfang' => $Lang['changfang'],
            'cangku' => $Lang['cangku'],
            'tudi' => $Lang['tudi'],
            ) ;
        tomshowsetting(true,array('title'=>$Lang['index_model_id'],'name'=>'model_id','value'=>'ershoufang','msg'=>$Lang['index_model_id_msg'],'item'=>$modelIdsArr),"select");
        tomshowsetting(true,array('title'=>$Lang['sites_title'],'name'=>'site_id','value'=>1,'msg'=>$Lang['sites_title_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['user_id'],'name'=>'user_id','value'=> '','msg'=>$Lang['user_id_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_title'],'name'=>'title','value'=>'','msg'=>$Lang['index_title_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'edit'){

    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($_GET['id']);
    $attrInfo = C::t('#tom_tcfangchan#tom_tcfangchan_attr')->fetch_by_tcfangchan_id($_GET['id']);
    
    if(submitcheck('submit')){
        $data = __get_post_data($tcfangchanInfo);

        $updateData = array();
        $updateData = $data['fangchanInfo'];
        $updateData['refresh_time'] = TIMESTAMP;
        if(C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchanInfo['id'],$updateData)){
            
            if($tcfangchanInfo['id'] > 0){
                C::t("#tom_tcfangchan#tom_tcfangchan_attr")->delete_by_tcfangchan_id($tcfangchanInfo['id']);
                C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_all_list(" AND tcfangchan_id={$tcfangchanInfo['id']} AND type IN(2) ");
                C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_all_list(" AND tcfangchan_id={$tcfangchanInfo['id']} AND type IN(4) ");
            }
            
            $insertData = array();
            $insertData = $data['attrInfo'];
            $insertData['tcfangchan_id']    = $tcfangchanInfo['id'];
            $insertData['attr_time']        = TIMESTAMP;
            C::t('#tom_tcfangchan#tom_tcfangchan_attr')->insert($insertData);
            
            if(!empty($data['vr_picurl'])){
                $insertData = array();
                $insertData['tcfangchan_id']    = $tcfangchanInfo['id'];
                $insertData['type']             = 2;
                $insertData['picurl']           = $data['vr_picurl'];
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
            if(!empty($data['video_picurl'])){
                $insertData = array();
                $insertData['tcfangchan_id']    = $tcfangchanInfo['id'];
                $insertData['type']             = 4;
                $insertData['picurl']           = $data['video_picurl'];
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
            
             C::t("#tom_tcfangchan#tom_tcfangchan_tag")->delete_by_tcfangchan_id($tcfangchanInfo['id']);
            
            if(is_array($data['configTagList']) && !empty($data['configTagList'])){
                foreach($data['configTagList'] as $key => $value){
                    $insertData = array();
                    $insertData['tcfangchan_id']    = $tcfangchanInfo['id'];
                    $insertData['config_tag_id']    = $value['id'];
                    $insertData['config_tag_ids']   = $data['attrTeseTagsIdsStr'];
                    $insertData['name']             = $value['name'];
                    $insertData['add_time']         = TIMESTAMP;
                    C::t("#tom_tcfangchan#tom_tcfangchan_tag")->insert($insertData);
                }
            }
            
        }
        
        if($tcfangchanInfo['source_type'] == 1){
            $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
            if($agentInfo['id'] > 0){
                update_mendian_xinxi($agentInfo['mendian_id']);
            }
        }
        
        update_fangchan_tongcheng($tcfangchanInfo['id']);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{

        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($tcfangchanInfo, $attrInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status']    = 1;
    $updateData['status']           = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($_GET['id'],$updateData);
    
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcfangchanInfo['user_id']);

    $shenhe = str_replace('{TITLE}', $tcfangchanInfo['title'], $Lang['index_template_tcfangchan_shenhe_ok']);
    $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$tcfangchanInfo['site_id'].'&mod=info&tcfangchan_id='.$tcfangchanInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
    
    $cpmsg = $Lang['act_success'];
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$tcfangchanInfo['site_id']}&mod=info&tcfangchan_id=".$tcfangchanInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcfangchanConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['tcfangchan_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['tcfangchan_shenhe_tz_fail'];
        }
    }
        
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
        
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcfangchanInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($_GET['id'],$updateData);
        
        $shenhe = str_replace('{TITLE}', $tcfangchanInfo['title'], $Lang['index_template_tcfangchan_shenhe_no']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$tcfangchanInfo['site_id'].'&mod=edit&tcfangchan_id='.$tcfangchanInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        
        $cpmsg = $Lang['act_success'];
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$tcfangchanInfo['site_id']}&mod=edit&tcfangchan_id=".$tcfangchanInfo['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tcfangchan_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tcfangchan_shenhe_tz_fail'];
            }
        }
        
        if($tcfangchanInfo['source_type'] == 1){
            $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
            if($agentInfo['id'] > 0){
                update_mendian_xinxi($agentInfo['mendian_id']);
            }
        }
        
        update_fangchan_tongcheng($tcfangchanInfo['id']);
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.$Lang['tcfangchan_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tcfangchan_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcfangchan_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($_GET['id'],$updateData);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
        
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($_GET['id'],$updateData);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
        
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'finish_ok'){
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['finish'] = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($_GET['id'],$updateData);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
        
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'finish_no'){
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($_GET['id']);
    
    $updateData = array();
    $updateData['finish'] = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($_GET['id'],$updateData);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
    
    update_fangchan_tongcheng($tcfangchanInfo['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'pay_ok'){
    
    $updateData = array();
    $updateData['pay_status'] = 2;
    C::t("#tom_tcfangchan#tom_tcfangchan")->update($_GET['id'], $updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){

    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($_GET['id']);
    
    C::t('#tom_tcfangchan#tom_tcfangchan')->delete_by_id($_GET['id']);
    C::t('#tom_tcfangchan#tom_tcfangchan_attr')->delete_by_tcfangchan_id($_GET['id']);
    C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_tcfangchan_id($_GET['id']);
    C::t("#tom_tcfangchan#tom_tcfangchan_tag")->delete_by_tcfangchan_id($_GET['id']);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
    
    delete_fangchan_tongcheng($tcfangchanInfo['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'edittop'){
    $info = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $top_time     = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
        $top_time     = strtotime($top_time);
        $updateData = array();
        if($top_time < TIMESTAMP){
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
        }else{
            $updateData['top_status']   = 1;
            $updateData['refresh_time'] = TIMESTAMP;
            $updateData['top_time']     = $top_time;
        }
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($_GET['id'],$updateData);
    
        update_fangchan_tongcheng($_GET['id']);
    
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edittop&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_top_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_top_time'],'name'=>'top_time','value'=>$info['top_time'],'msg'=>$Lang['edit_top_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editexpire'){
    $info = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $expire_time     = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
        $expire_time     = strtotime($expire_time);
        $updateData = array();
        if($expire_time < TIMESTAMP){
            $updateData['expire_status']    = 2;
            $updateData['expire_time']      = 0;
            $updateData['status']           = 0;
        }else{
            $updateData['expire_status']    = 1;
            $updateData['refresh_time']     = TIMESTAMP;
            $updateData['expire_time']      = $expire_time;
        }
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($_GET['id'],$updateData);
    
        update_fangchan_tongcheng($_GET['id']);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editexpire&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_expire_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_expire_time'],'name'=>'expire_time','value'=>$info['expire_time'],'msg'=>$Lang['edit_expire_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refresh'){
    
    $updateData = array();
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($_GET['id'],$updateData);
    
    update_fangchan_tongcheng($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_refresh'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['refresh_time']     = TIMESTAMP;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);
            
            update_fangchan_tongcheng($value);
            
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_shenhe1'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            
            $updateData = array();
            $updateData['shenhe_status']    = 1;
            $updateData['status']           = 1;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);
            
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);

            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }

            update_fangchan_tongcheng($value);
            
            $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcfangchanInfo['user_id']);

            $shenhe = str_replace('{TITLE}', $tcfangchanInfo['title'], $Lang['index_template_tcfangchan_shenhe_ok']);
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$tcfangchanInfo['site_id'].'&mod=info&tcfangchan_id='.$tcfangchanInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($tcUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$tcfangchanInfo['site_id']}&mod=info&tcfangchan_id=".$tcfangchanInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $insertData = array();
            $insertData['user_id']      = $tcUserInfo['id'];
            $insertData['type']         = 1;
            $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
            $insertData['is_read']      = 0;
            $insertData['tz_time']      = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
            
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_shenhe3'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);
            $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcfangchanInfo['user_id']);

            $updateData = array();
            $updateData['shenhe_status']    = 3;
            $updateData['status']           = 1;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);

            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }

            update_fangchan_tongcheng($value);

            $shenhe = str_replace('{TITLE}', $tcfangchanInfo['title'], $Lang['index_template_tcfangchan_shenhe_no']);
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$tcfangchanInfo['site_id'].'&mod=edit&tcfangchan_id='.$tcfangchanInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($tcUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$tcfangchanInfo['site_id']}&mod=edit&tcfangchan_id=".$tcfangchanInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                    $cpmsg = $Lang['tcfangchan_shenhe_tz_succ'];
                }else{
                    $cpmsg = $Lang['tcfangchan_shenhe_tz_fail'];
                }
            }

            $insertData = array();
            $insertData['user_id']      = $tcUserInfo['id'];
            $insertData['type']         = 1;
            $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.$Lang['tcfangchan_shenhe_fail_title'].'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
            $insertData['is_read']      = 0;
            $insertData['tz_time']      = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);

        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_del'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);

            C::t('#tom_tcfangchan#tom_tcfangchan')->delete_by_id($value);
            C::t('#tom_tcfangchan#tom_tcfangchan_attr')->delete_by_tcfangchan_id($value);
            C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_tcfangchan_id($value);
            C::t("#tom_tcfangchan#tom_tcfangchan_tag")->delete_by_tcfangchan_id($value);

            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }
            
            delete_fangchan_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_show'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);

            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);

            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }
            
            update_fangchan_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_hide'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);

            $updateData = array();
            $updateData['status'] = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);

            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }

            update_fangchan_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_finish1'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);

            $updateData = array();
            $updateData['finish'] = 1;
            $updateData['status'] = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);

            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }

            update_fangchan_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_finish0'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            
            $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value);

            $updateData = array();
            $updateData['finish'] = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value,$updateData);

            if($tcfangchanInfo['source_type'] == 1){
                $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
                if($agentInfo['id'] > 0){
                    update_mendian_xinxi($agentInfo['mendian_id']);
                }
            }

            update_fangchan_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'guanzulist'){
    
    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0? intval($_GET['tcfangchan_id']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($tcfangchan_id);
    
    $where = " AND tcfangchan_id = {$tcfangchan_id} ";
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_guanzu')->fetch_all_count($where);
    $guanzuList = C::t('#tom_tcfangchan#tom_tcfangchan_guanzu')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);

    $modBasePageUrl = $modBaseUrl."&act=guanzulist&tcfangchan_id={$tcfangchan_id}";
    
    __create_nav_html();
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $tcfangchanInfo['title'] .'&nbsp;&nbsp;&gt;&gt;&gt;&nbsp;&nbsp;'.$Lang['index_guanzulist_title']. '</th></tr>';
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['index_user'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($guanzuList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f70404">(ID:'.$value['user_id']. ')</font></td>';
        echo '<td>' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        
        echo '<td> -- </td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['act'] == 'addphoto'){
    
    if(submitcheck('submit')){
        
        $id             = isset($_GET['id'])? intval($_GET['id']):0;
        $type           = isset($_GET['type'])? intval($_GET['type']):1;
        $psort          = isset($_GET['psort'])? intval($_GET['psort']):10;
        $picurl         = tomuploadFile("picurl");
        
        $insertData = array();
        $insertData['tcfangchan_id']    = $id;
        $insertData['picurl']           = $picurl;
        $insertData['type']             = $type;
        $insertData['psort']            = $psort;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_photo')->insert($insertData);
        update_fangchan_tongcheng($id);
    
        cpmsg($Lang['act_success'], $modListUrl.'&act=photo&id='.$id, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        tomshownavheader();
        tomshownavli($Lang['houses_photo_add'],'',true);
        tomshownavfooter();
        showformheader($modFromUrl.'&act=addphoto&id='.$_GET['id'],'enctype');
        showtableheader();
        
        tomshowsetting(true,array('title'=>$Lang['houses_photo'],'name'=>'picurl','value'=>'','msg'=>$Lang['houses_photo_msg']),"file");
        $type_item = array(1=>$Lang['index_photo_type_1'],2=>$Lang['index_photo_type_2'],4=>$Lang['index_photo_type_4']);
        tomshowsetting(true,array('title'=>$Lang['index_photo_type'],'name'=>'type','value'=>1,'msg'=>$Lang['index_photo_type_msg'],'item'=>$type_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'psort','value'=>10,'msg'=>$Lang['sort_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_id($_GET['id']);
    update_fangchan_tongcheng($_GET['tcfangchan_id']);
    
    cpmsg($Lang['act_success'], $modListUrl.'&act=photo&id='.$_GET['tcfangchan_id'], 'succeed');
    
}else if($_GET['act'] == 'photo'){
    
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $id         = intval($_GET['id'])>0? intval($_GET['id']):0;
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $fangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($id);
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_count(" AND tcfangchan_id = {$id} ");
    $photoList = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id = {$id} "," ORDER BY psort ASC,id ASC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&act=photo&site_id={$site_id}";
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' .$fangchanInfo['title'].'&gt;'. $Lang['houses_photo'] . '</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    tomshownavheader();
    tomshownavli($Lang['houses_photo_add'],$modBaseUrl."&act=addphoto&id=".$id,false);
    tomshownavfooter();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['index_photo'] . '</th>';
    echo '<th>' . $Lang['index_photo_type'] . '</th>';
    echo '<th>' . $Lang['sort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($photoList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a href="' . $value['picurlTmp'] . '" target="_blank"><img height="40" src="' . $value['picurlTmp'] . '"></a></td>';
        if($value['type'] == 1){
            echo '<td>' . $Lang['index_photo_type_1'] . '</td>';
        }else if($value['type'] == 2){
            echo '<td>' . $Lang['index_photo_type_2'] . '</td>';
        }else if($value['type'] == 4){
            echo '<td>' . $Lang['index_photo_type_4'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $value['psort'] . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&tcfangchan_id='.$id.'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}else{
    set_list_url("tom_tcfangchan_admin_index_list");
    
    $keyword            = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $tcfangchan_id      = isset($_GET['tcfangchan_id'])? intval($_GET['tcfangchan_id']):0;
    $house_no           = isset($_GET['house_no'])? addslashes($_GET['house_no']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $model_id           = isset($_GET['model_id'])? addslashes($_GET['model_id']):'';
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $source_type        = isset($_GET['source_type'])? intval($_GET['source_type']):0;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $finish             = isset($_GET['finish'])? intval($_GET['finish']):0;
    $pay_status         = isset($_GET['pay_status'])? intval($_GET['pay_status']):0;
    $expire_status      = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $deleted            = isset($_GET['deleted'])? intval($_GET['deleted']):0;
    $pay_type           = isset($_GET['pay_type'])? intval($_GET['pay_type']):0;
    $search             = isset($_GET['search'])? intval($_GET['search']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    if(!empty($tel)){
        $where.= " AND tel='{$tel}' ";
    }
    if(!empty($model_id)){
        $where.= " AND model_id='{$model_id}' ";
    }
    if($area_id > 0){
        $where.= " AND area_id='{$area_id}' ";
    }
    if($street_id > 0){
        $where.= " AND street_id='{$street_id}' ";
    }
    if(!empty($tcfangchan_id)){
        $where.= " AND id={$tcfangchan_id} ";
    }
    if(!empty($house_no)){
        $where.= " AND house_no='{$house_no}' ";
    }
    if(!empty($source_type)){
        $where.= " AND source_type={$source_type} ";
    }
    if(!empty($status)){
        if($status == 1){
            $where.= " AND status=1 ";
        }else if($status == 2){
            $where.= " AND status != 1 ";
        }
    }
    if($pay_status > 0){
        $where.= " AND pay_status = {$pay_status} ";
    }
    if(!empty($finish)){
        if($finish == 1){
            $where.= " AND finish=1 ";
        }else if($finish == 2){
            $where.= " AND finish != 1 ";
        }
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    if($top_status > 0){
        if($top_status == 1){
            $where.= " AND top_status = 1 ";
        }else if($top_status == 2){
            $where.= " AND top_status = 0 ";
        }
    }
    if($deleted > 0){
        if($deleted == 1){
            $where.= " AND deleted = 1 ";
        }else if($deleted == 2){
            $where.= " AND deleted = 0 ";
        }
    }
    if($pay_type > 0){
        $where.= " AND pay_type = {$pay_type} ";
    }
    
    if($expire_status > 0){
        if($expire_status == 1){
            $where.= " AND ((expire_status = 1 AND expire_time > ".TIMESTAMP.") OR (expire_status = 3)) ";
        }else if($expire_status == 2){
            $where.= " AND expire_status = 2 ";
        }
    }
    
    $order = "ORDER BY add_time DESC,id DESC";
    
    $pagesize = 20;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count($where);
    $tcfangchanList  = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($where,$order,$start,$pagesize,$keyword);
    
    showtableheader();
    $Lang['index_help_0']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_0']);
    $Lang['index_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_1']);
    $Lang['index_help_2']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_2']);
    $Lang['index_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_3']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_0'] . '</li>';
    echo '<li>' . $Lang['index_help_1'] . '</li>';
    if($tongchengConfig['open_yun'] == 2){
        echo '<li>' . $Lang['index_help_2'] . '</li>';
    }
    if($tongchengConfig['open_yun'] == 3){
        echo '<li>' . $Lang['index_help_3'] . '</li>';
    }
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/

    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&user_id={$user_id}&tel={$tel}&status={$status}&shenhe_status={$shenhe_status}&top_status={$top_status}&model_id={$model_id}&source_type={$source_type}&finish={$finish}&search={$search}&area_id={$area_id}&street_id={$street_id}&expire_status={$expire_status}&pay_status={$pay_status}&deleted={$deleted}&pay_type={$pay_type}&keyword=".urlencode($keyword);
    
    showformheader($modFromUrl."&search={$search}&formhash=".FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '<a href="'.$modBaseUrl.'&search=1"><font color="#F90B0B">('.$Lang['search_gaoji'].')</font></a></th></tr>';
    
    $site_1 = '';
    if($site_id == 1){
        $site_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id" onChange="getCity();">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_search_text'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="keyword" value="'.$keyword.'" placeholder="'.$Lang['index_search_text_msg'].'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_tel'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="tel" value="'.$tel.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_house_no'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="house_no" value="'.$house_no.'"></td></tr>';
    
    $ershoufang = $chuzu = $shangpu = $xiezilou = $changfang = $cangku = $tudi = '';
    if($model_id == 'ershoufang'){
        $ershoufang = 'selected';
    }else if($model_id == 'chuzu'){
        $chuzu = 'selected';
    }else if($model_id == 'shangpu'){
        $shangpu = 'selected';
    }else if($model_id == 'xiezilou'){
        $xiezilou = 'selected';
    }else if($model_id == 'changfang'){
        $changfang = 'selected';
    }else if($model_id == 'cangku'){
        $cangku = 'selected';
    }else if($model_id == 'tudi'){
        $tudi = 'selected';
    }
    $modelIdStr = '<tr><td width="100" align="right"><b>'.$Lang['index_model_id'].'</b></td>';
    $modelIdStr.= '<td><select style="width: 260px;" name="model_id" id="model_id">';
    $modelIdStr.=  '<option value="">'.$Lang['all'].'</option>';
    $modelIdStr.=  '<option value="ershoufang" '.$ershoufang.'>'.$Lang['ershoufang'].'</option>';
    $modelIdStr.=  '<option value="chuzu" '.$chuzu.'>'.$Lang['chuzu'].'</option>';
    $modelIdStr.=  '<option value="shangpu" '.$shangpu.'>'.$Lang['shangpu'].'</option>';
    $modelIdStr.=  '<option value="xiezilou" '.$xiezilou.'>'.$Lang['xiezilou'].'</option>';
    $modelIdStr.=  '<option value="changfang" '.$changfang.'>'.$Lang['changfang'].'</option>';
    $modelIdStr.=  '<option value="cangku" '.$cangku.'>'.$Lang['cangku'].'</option>';
    $modelIdStr.=  '<option value="tudi" '.$tudi.'>'.$Lang['tudi'].'</option>';
    $modelIdStr.= '</select></td></tr>';
    echo $modelIdStr;
    
    if($search == 1){
        echo '<tr><td width="100" align="right"><b>'.$Lang['user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';
        echo '<tr><td width="100" align="right"><b>'.$Lang['index_tcfangchan_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="tcfangchan_id" value="'.$tcfangchan_id.'"></td></tr>';

        $__CityInfo  = array('id'=>0,'name'=>'');
        if($site_id > 1){
            $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
            if($sitesInfoTmp){
                $__SitesInfo = $sitesInfoTmp;
                if(!empty($__SitesInfo['city_id'])){
                    $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                    if($cityInfoTmp){
                        $__CityInfo = $cityInfoTmp;
                    }
                }
            }
        }else if($site_id == 1){
            $cityInfoTmp = array();
            if(!empty($tongchengConfig['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
            }
            if(!empty($cityInfoTmp)){
                $__CityInfo = $cityInfoTmp;
            }
        }
        $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
        $areaStr.= '<tr><td width="100" align="right"><b>'.$Lang['newhouses_search_diqu'].'</b></td>';
        $areaStr.= '<td ><select style="width: 130px;" name="area_id" id="area_id" onChange="getStreet();">';
        $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
        foreach ($areaList as $key => $value){
            if($area_id == $value['id']){
                $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $areaStr.= '</select>';

        $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
        $areaStr.= '<select style="width: 130px;" name="street_id" id="street_id">';
        $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
        foreach ($streetList as $key => $value){
            if($street_id == $value['id']){
                $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $areaStr.= '</select></td></tr>';
        echo $areaStr;
        
        $source_type_1 = $source_type_2 = '';
        if($source_type == 1){
            $source_type_1 = 'selected';
        }else if($source_type == 2){
            $source_type_2 = 'selected';
        }
        $sourceTypeStr = '<tr><td width="100" align="right"><b>'.$Lang['index_source_type'].'</b></td>';
        $sourceTypeStr.= '<td><select style="width: 260px;" name="source_type" id="source_type">';
        $sourceTypeStr.=  '<option value="0">'.$Lang['all'].'</option>';
        $sourceTypeStr.=  '<option value="1" '.$source_type_1.'>'.$Lang['index_source_type_1'].'</option>';
        $sourceTypeStr.=  '<option value="2" '.$source_type_2.'>'.$Lang['index_source_type_2'].'</option>';
        $sourceTypeStr.= '</select></td></tr>';
        echo $sourceTypeStr;

        $finish_1 = $finish_2 = '';
        if($finish == 1){
            $finish_1 = 'selected';
        }else if($finish == 2){
            $finish_2 = 'selected';
        }
        $finishStr = '<tr><td width="100" align="right"><b>'.$Lang['index_finish'].'</b></td>';
        $finishStr.= '<td><select style="width: 260px;" name="finish" id="finish">';
        $finishStr.=  '<option value="0">'.$Lang['all'].'</option>';
        $finishStr.=  '<option value="1" '.$finish_1.'>'.$Lang['index_finish_1'].'</option>';
        $finishStr.=  '<option value="2" '.$finish_2.'>'.$Lang['index_finish_0'].'</option>';
        $finishStr.= '</select></td></tr>';
        echo $finishStr;

        $expire_status_1 = $expire_status_2 = '';
        if($expire_status == 1){
            $expire_status_1 = 'selected';
        }else if($expire_status == 2){
            $expire_status_2 = 'selected';
        }
        $expireStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['expire_status'].'</b></td>';
        $expireStatusStr.= '<td><select style="width: 260px;" name="expire_status" id="expire_status">';
        $expireStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
        $expireStatusStr.=  '<option value="1" '.$expire_status_1.'>'.$Lang['expire_status_1'].'</option>';
        $expireStatusStr.=  '<option value="2" '.$expire_status_2.'>'.$Lang['expire_status_2'].'</option>';
        $expireStatusStr.= '</select></td></tr>';
        echo $expireStatusStr;

        $pay_status_1 = $pay_status_2 = '';
        if($pay_status == 1){
            $pay_status_1 = 'selected';
        }else if($pay_status == 2){
            $pay_status_2 = 'selected';
        }
        $payStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['pay_status'].'</b></td>';
        $payStatusStr.= '<td><select style="width: 260px;" name="pay_status" id="pay_status">';
        $payStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
        $payStatusStr.=  '<option value="1" '.$pay_status_1.'>'.$Lang['pay_status_1'].'</option>';
        $payStatusStr.=  '<option value="2" '.$pay_status_2.'>'.$Lang['pay_status_2'].'</option>';
        $payStatusStr.= '</select></td></tr>';
        echo $payStatusStr;
    
    }
        
    $status_1 = $status_2 = '';
    if($status == 1){
        $status_1 = 'selected';
    }else if($status == 2){
        $status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['index_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['index_status_0'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    $status_shenhe_1 = $status_shenhe_2 = $status_shenhe_3 = '';
    if($shenhe_status == 1){
        $status_shenhe_1 = 'selected';
    }else if($shenhe_status == 2){
        $status_shenhe_2 = 'selected';
    }else if($shenhe_status == 3){
        $status_shenhe_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$status_shenhe_1.'>'.$Lang['shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$status_shenhe_2.'>'.$Lang['shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$status_shenhe_3.'>'.$Lang['shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    $top_status_1 = $top_status_0 = '';
    if($top_status == 1){
        $top_status_1 = 'selected';
    }else if($top_status == 2){
        $top_status_0 = 'selected';
    }
    $topStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['top_status'].'</b></td>';
    $topStatusStr.= '<td><select style="width: 260px;" name="top_status" id="top_status">';
    $topStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $topStatusStr.=  '<option value="1" '.$top_status_1.'>'.$Lang['top_status_1'].'</option>';
    $topStatusStr.=  '<option value="2" '.$top_status_0.'>'.$Lang['top_status_0'].'</option>';
    $topStatusStr.= '</select></td></tr>';
    echo $topStatusStr;
    
    $deleted_1 = $deleted_0 = '';
    if($deleted == 1){
        $deleted_1 = 'selected';
    }else if($deleted == 2){
        $deleted_0 = 'selected';
    }
    $topStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_deleted'].'</b></td>';
    $topStatusStr.= '<td><select style="width: 260px;" name="deleted" id="deleted">';
    $topStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $topStatusStr.=  '<option value="1" '.$deleted_1.'>'.$Lang['index_deleted_1'].'</option>';
    $topStatusStr.=  '<option value="2" '.$deleted_0.'>'.$Lang['index_deleted_0'].'</option>';
    $topStatusStr.= '</select></td></tr>';
    echo $topStatusStr;
    
    $pay_type_1 = $pay_type_2 = $pay_type_3 = $pay_type_4 = $pay_type_5 = '';
    if($pay_type == 1){
        $pay_type_1 = 'selected';
    }else if($pay_type == 2){
        $pay_type_2 = 'selected';
    }else if($pay_type == 3){
        $pay_type_3 = 'selected';
    }else if($pay_type == 4){
        $pay_type_4 = 'selected';
    }else if($pay_type == 5){
        $pay_type_5 = 'selected';
    }
    $payTypeStr = '<tr><td width="100" align="right"><b>'.$Lang['index_pay_type'].'</b></td>';
    $payTypeStr.= '<td><select style="width: 260px;" name="pay_type" id="pay_type">';
    $payTypeStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $payTypeStr.=  '<option value="1" '.$pay_type_1.'>'.$Lang['index_pay_type_1'].'</option>';
    $payTypeStr.=  '<option value="2" '.$pay_type_2.'>'.$Lang['index_pay_type_2'].'</option>';
    $payTypeStr.=  '<option value="3" '.$pay_type_3.'>'.$Lang['index_pay_type_3'].'</option>';
    $payTypeStr.=  '<option value="4" '.$pay_type_4.'>'.$Lang['index_pay_type_4'].'</option>';
    $payTypeStr.=  '<option value="5" '.$pay_type_5.'>'.$Lang['index_pay_type_5'].'</option>';
    $payTypeStr.= '</select></td></tr>';
    echo $payTypeStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
    
    __create_nav_html();
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return batch_do();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />';
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 60px;"> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['index_house_no'] . '</th>';
    echo '<th>' . $Lang['index_user'] . '</th>';
    echo '<th>' . $Lang['index_title'] . '</th>';
    echo '<th>' . $Lang['index_model_id'] . '</th>';
    echo '<th >' . $Lang['index_source_type'] . '</th>';
    echo '<th style="width:300px;">' . $Lang['status'] . '</th>';
    echo '<th >' . $Lang['refresh_time'] . '</th>';
    echo '<th >' . $Lang['add_time'] . '</th>';
    echo '<th >' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tcfangchanList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        echo '<tr>';
        echo '<td><label><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" >' . $value['id'] . '</label></td>';
        if($value['site_id'] > 0){
            if($value['site_id'] > 1){
                echo '<td>' . $siteInfo['name'] . '</td>';
            }else{
                echo '<td>' . $Lang['sites_one'] . '</td>';
            }
        }else{
            echo '<td> -- </td>';
        }
        if($value['house_no']){
            echo '<td>' . $value['house_no'] . '</td>';
        }else{
            echo '<td>-</td>';
        }
        echo '<td><font color="#0a9409">' . $userInfo['nickname'] . '</font><font color="#f70404">(ID:'.$value['user_id'].')</font></td>';
        echo '<td>' . $value['title'] . '</td>';
        if($value['model_id'] == 'ershoufang'){
            echo '<td>' . $Lang['ershoufang'] . '</td>';
        }else if($value['model_id'] == 'chuzu'){
            echo '<td>' . $Lang['chuzu'] . '</td>';
        }else if($value['model_id'] == 'shangpu'){
            echo '<td>' . $Lang['shangpu'] . '</td>';
        }else if($value['model_id'] == 'xiezilou'){
            echo '<td>' . $Lang['xiezilou'] . '</td>';
        }else if($value['model_id'] == 'changfang'){
            echo '<td>' . $Lang['changfang'] . '</td>';
        }else if($value['model_id'] == 'cangku'){
            echo '<td>' . $Lang['cangku'] . '</td>';
        }else if($value['model_id'] == 'tudi'){
            echo '<td>' . $Lang['tudi'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['source_type'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['index_source_type_1'] . '</font></td>';
        }else if($value['source_type'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['index_source_type_2'] . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td style="line-height: 25px;">';
        if($value['pay_type'] == 1){
            echo '<p style="line-height:20px;">' . $Lang['index_pay_type'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['index_pay_type_1'].'</font></p>';
        }else if($value['pay_type'] == 2){
            echo '<p style="line-height:20px;">' . $Lang['index_pay_type'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['index_pay_type_2'].'</font></p>';
        }else if($value['pay_type'] == 3){
            echo '<p style="line-height:20px;">' . $Lang['index_pay_type'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['index_pay_type_3'].'</font></p>';
        }else if($value['pay_type'] == 4){
            echo '<p style="line-height:20px;">' . $Lang['index_pay_type'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['index_pay_type_4'].'</font></p>';
        }else if($value['pay_type'] == 5){
            echo '<p style="line-height:20px;">' . $Lang['index_pay_type'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['index_pay_type_5'].'</font></p>';
        }else{
            echo '<p style="line-height:20px;">' . $Lang['index_pay_type'].$Lang['fenghao']. '<font color="#0a9409"> -- </font></p>';
        }
        if($value['top_status'] == 1){
            echo '<p style="line-height:20px;">' . $Lang['top_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['top_status_1'].'</font> <font color="#f70404">('.dgmdate($value['top_time'], 'Y-m-d H:i',$tomSysOffset).')</font></p>';
        }else{
            echo '<p style="line-height:20px;">' . $Lang['top_status'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['top_status_0'].'</font></p>';
        }
        if($value['expire_status'] == 1){
            echo '<p style="line-height:20px;">' . $Lang['expire_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['expire_status_1'].'</font><font color="#f70404">('.dgmdate($value['expire_time'], 'Y-m-d H:i',$tomSysOffset).')</font></p>';
        }else if($value['expire_status'] == 2){
            echo '<p style="line-height:20px;">' . $Lang['expire_status'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['expire_status_2'].'</font></p>';
        }else if($value['expire_status'] == 3){
            echo '<p style="line-height:20px;">' . $Lang['expire_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['expire_status_3'].'</font></p>';
        }
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_status_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_status_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<p style="line-height:20px;">' . $Lang['shenhe_status'].$Lang['fenghao']. '<font color="#0a9409">' . $Lang['shenhe_status_1']. '</font>'.$sheheBtnStr.'</p>';
        }else if($value['shenhe_status'] == 2 ){
            echo '<p style="line-height:20px;">' . $Lang['shenhe_status'].$Lang['fenghao']. '<font color="#f70404">' . $Lang['shenhe_status_2']. '</font>'.$sheheBtnStr.'</p>';
        }else if($value['shenhe_status'] == 3 ){
            echo '<p style="line-height:20px;">' . $Lang['shenhe_status'].$Lang['fenghao']. '<font color="#f70404">' . $Lang['shenhe_status_3']. '</font>'.$sheheBtnStr.'</p>';
        }
        if($value['pay_status'] == 1){
            echo '<p style="line-height:20px;">' . $Lang['pay_status'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['pay_status_1'].'</font><a href="javascript:void(0);" onclick="pay_confirm(\''.$modBaseUrl.'&act=pay_ok&id='.$value['id'].'&formhash='.FORMHASH.'\');">('.$Lang['pay_status_2'].')</a></p>';
        }else if($value['pay_status'] == 2){
            echo '<p style="line-height:20px;">' . $Lang['pay_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['pay_status_2'].'</font></p>';
        }
        if($value['deleted'] == 1){
            echo '<p style="line-height:20px;">' . $Lang['index_deleted'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['index_deleted_1'].'</font></p>';
        }else{
            if($value['status'] == 1 ){
                echo '<p style="line-height:20px;">' . $Lang['index_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['index_status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['index_status_0']. ')</font></a></p>';
            }else{
                echo '<p style="line-height:20px;">' . $Lang['index_status'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['index_status_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['index_status_1']. ')</font></a></p>';
            }
        }
        if($value['finish'] == 1 ){
            echo '<p style="line-height:20px;">' . $Lang['index_finish'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['index_finish_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=finish_no&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['index_finish_0']. ')</font></a></p>';
        }else{
            echo '<p style="line-height:20px;">' . $Lang['index_finish'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['index_finish_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=finish_ok&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['index_finish_1']. ')</font></a></p>';
        }
        echo '</td>';
        
        echo '<td>' . dgmdate($value['refresh_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=refresh&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['refresh']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edittop&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_top_title']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'&formhash='.FORMHASH.'" target="_blank">' . $Lang['info']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=guanzulist&tcfangchan_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_guanzulist_title']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=photo&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['houses_photo_title']. '</a><br/>';
        if($value['expire_status'] == 2 || $value['expire_status'] == 1){
            echo '<a href="'.$modBaseUrl.'&act=editexpire&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_expire_title']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        }
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function pay_confirm(url){
  var r = confirm("{$Lang['makesure_pay_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
    $formstr = <<<EOF
        <tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="batch_refresh">{$Lang['batch_refresh']}</option>
                    <option value="batch_shenhe1">{$Lang['batch_shenhe1']}</option>
                    <option value="batch_shenhe3">{$Lang['batch_shenhe3']}</option>
                    <option value="batch_del">{$Lang['batch_del']}</option>
                    <option value="batch_show">{$Lang['batch_show']}</option>
                    <option value="batch_hide">{$Lang['batch_hide']}</option>
                    <option value="batch_finish1">{$Lang['batch_finish1']}</option>
                    <option value="batch_finish0">{$Lang['batch_finish0']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>
        <script type="text/javascript">
        function batch_do(){
          var r = confirm("{$Lang['batch_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        </script>
EOF;
    echo $formstr;
    showformfooter(); /*Dism_taobao-com*/
}

$jsstr = <<<EOF
<script type="text/javascript">
function getCity(){
  var site_id = jq("#site_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcfangchan:ajax",
        data: "act=admin_area&site="+site_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var areaHtml = '<option value="0">{$Lang['all']}</option>';
            jq.each(json,function(k,v){
                areaHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#area_id").html(areaHtml);
            jq("#area_id").show();
        }
    });
}
function getStreet(){
  var area_id = jq("#area_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcfangchan:ajax",
        data: "act=admin_street&area_id="+area_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var streetHtml = '<option value="0">{$Lang['all']}</option>';
            jq.each(json,function(k,v){
                streetHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            console.log(streetHtml);
            jq("#street_id").html(streetHtml);
            jq("#street_id").show();
        }
    });
}
</script>
EOF;
echo $jsstr;

function __get_post_data($infoArr = array()){
    $data = array();
    
    $title                  = isset($_GET['title'])? addslashes($_GET['title']):'';
    $user_id                = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $xm                     = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                    = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $wx                     = isset($_GET['wx'])? addslashes($_GET['wx']):'';
    $house_no               = isset($_GET['house_no'])? addslashes($_GET['house_no']):'';
    $house_tel              = isset($_GET['house_tel'])? addslashes($_GET['house_tel']):'';
    $trade_id               = isset($_GET['trade_id'])? intval($_GET['trade_id']):0;
    $top_time               = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
    $top_time               = strtotime($top_time);
    $expire_time            = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time            = strtotime($expire_time);
    $video_url              = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $vr_link                = isset($_GET['vr_link'])? addslashes($_GET['vr_link']):'';
    $content                = isset($_GET['content'])? addslashes($_GET['content']):'';
    $houses_id              = isset($_GET['houses_id'])? intval($_GET['houses_id']):0;
    $houses_name            = isset($_GET['houses_name'])? addslashes($_GET['houses_name']):'';
    $mianji                 = isset($_GET['mianji'])? floatval($_GET['mianji']):0.00;
    $price                  = isset($_GET['price'])? floatval($_GET['price']):0.00;
    $fangchan_nature        = isset($_GET['fangchan_nature'])? intval($_GET['fangchan_nature']):0;
    $zhuanrang_price        = isset($_GET['zhuanrang_price'])? floatval($_GET['zhuanrang_price']):0.00;
    $rent                   = isset($_GET['rent'])? intval($_GET['rent']):0;
    $city_id                = isset($_GET['city_id'])? intval($_GET['city_id']):0;
    $area_id                = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id              = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $address                = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude               = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude              = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    
    $attr_zhuangxiu_type    = isset($_GET['attr_zhuangxiu_type'])? intval($_GET['attr_zhuangxiu_type']):0;
    $attr_house_type        = isset($_GET['attr_house_type'])? intval($_GET['attr_house_type']):0;
    $attr_chaoxiang_type    = isset($_GET['attr_chaoxiang_type'])? intval($_GET['attr_chaoxiang_type']):0;
    $attr_shi               = isset($_GET['attr_shi'])? intval($_GET['attr_shi']):0;
    $attr_ting              = isset($_GET['attr_ting'])? intval($_GET['attr_ting']):0;
    $attr_wei               = isset($_GET['attr_wei'])? intval($_GET['attr_wei']):0;
    $attr_louceng           = isset($_GET['attr_louceng'])? intval($_GET['attr_louceng']):0;
    $attr_cengshu           = isset($_GET['attr_cengshu'])? intval($_GET['attr_cengshu']):0;
    $attr_chanquan          = isset($_GET['attr_chanquan'])? intval($_GET['attr_chanquan']):0;
    $attr_elevator          = isset($_GET['attr_elevator'])? intval($_GET['attr_elevator']):0;
    $attr_lease_type        = isset($_GET['attr_lease_type'])? intval($_GET['attr_lease_type']):0;
    $attr_rent_type         = isset($_GET['attr_rent_type'])? intval($_GET['attr_rent_type']):0;
    $attr_rent_unit         = isset($_GET['attr_rent_unit'])? intval($_GET['attr_rent_unit']):1;
    $attr_shangpu_type      = isset($_GET['attr_shangpu_type'])? intval($_GET['attr_shangpu_type']):0;

    
    $teseTagsIdsArr = array();
    if(is_array($_GET['attr_tese_tags']) && !empty($_GET['attr_tese_tags'])){
        foreach($_GET['attr_tese_tags'] as $key => $value){
            if(intval($value) > 0){
                $teseTagsIdsArr[] = intval($value);
            }
        }
    }

    $configTagList = array();
    $attr_tese_tags = $attrTeseTagsIdsStr = '';
    if(is_array($teseTagsIdsArr) && !empty($teseTagsIdsArr)){
        $teseTagsIdsCount = count($teseTagsIdsArr);
        $attrTeseTagsIdsStr = implode(',', $teseTagsIdsArr);
        $configTagListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_all_list(" AND id IN({$attrTeseTagsIdsStr}) ", 'ORDER BY tsort ASC,id DESC', 0, $teseTagsIdsCount);
        $configTagNameArr = array();
        if(is_array($configTagListTmp) && !empty($configTagListTmp)){
            foreach($configTagListTmp as $key => $value){
                $configTagList[$key] = $value;
                $configTagNameArr[] = $value['name'];
            }
        }

        if(is_array($configTagNameArr) && !empty($configTagNameArr)){
            $attr_tese_tags = '|'.implode('|', $configTagNameArr).'|';
        }
    }
    
    
    $attrPeitaoTagsArr = array();
    if(is_array($_GET['attr_peitao_tags']) && !empty($_GET['attr_peitao_tags'])){
        foreach($_GET['attr_peitao_tags'] as $key => $value){
            if(!empty($value)){
                $attrPeitaoTagsArr[] = addslashes($value);
            }
        }
    }
    $attr_peitao_tags = '|'.implode('|', $attrPeitaoTagsArr).'|';
    
    $video_picurl = $vr_picurl = "";
    if($_GET['act'] == 'add'){
        $video_picurl       = tomuploadFile("video_picurl");
        $vr_picurl          = tomuploadFile("vr_picurl");
    }else if($_GET['act'] == 'edit'){
        $video_picurl       = tomuploadFile("video_picurl",$infoArr['video_picurl']);
        $vr_picurl          = tomuploadFile("vr_picurl",$infoArr['vr_picurl']);
    }
    
    $housesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_houses")->fetch_by_id($houses_id);
    $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($user_id);
    $tradeInfo = C::t("#tom_tcfangchan#tom_tcfangchan_trade")->fetch_by_id($trade_id);
    $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    
    $fangchanInfo = $attrInfo = array();
    $fangchanInfo['user_id']        = $user_id;
    $fangchanInfo['title']          = $title;
    if($agentInfo['id'] > 0){
        $fangchanInfo['xm']             = $agentInfo['name'];
        $fangchanInfo['tel']            = $agentInfo['tel'];
        $fangchanInfo['source_type']    = 1;
    }else{
        $fangchanInfo['xm']             = $xm;
        $fangchanInfo['tel']            = $tel;
        $fangchanInfo['wx']             = $wx;
        $fangchanInfo['source_type']    = 2;
    }
    $fangchanInfo['house_no']       = $house_no;
    $fangchanInfo['house_tel']      = $house_tel;
    $fangchanInfo['trade_id']       = $trade_id;
    $fangchanInfo['trade_name']     = $tradeInfo['name'];
    if($top_time > TIMESTAMP){
        $fangchanInfo['top_status']     = 1;
        $fangchanInfo['top_time']       = $top_time;
    }
    if($expire_time > TIMESTAMP){
        $fangchanInfo['expire_status']  = 1;
        $fangchanInfo['expire_time']    = $expire_time;
    }
    $fangchanInfo['video_url']      = $video_url;
    $fangchanInfo['vr_link']        = $vr_link;
    $fangchanInfo['content']        = $content;
    
    if($infoArr['model_id'] == 'ershoufang'){
        
        if($houses_id > 0){
            $fangchanInfo['city_id']        = $housesInfo['city_id'];
            $fangchanInfo['area_id']        = $housesInfo['area_id'];
            $fangchanInfo['area_name']      = $housesInfo['area_name'];
            $fangchanInfo['street_id']      = $housesInfo['street_id'];
            $fangchanInfo['street_name']    = $housesInfo['street_name'];
            $fangchanInfo['address']        = $housesInfo['address'];
            $fangchanInfo['latitude']       = $housesInfo['latitude'];
            $fangchanInfo['longitude']      = $housesInfo['longitude'];
            $fangchanInfo['houses_id']      = $housesInfo['id'];
            $fangchanInfo['houses_name']    = $housesInfo['name'];
        }else{
            $fangchanInfo['city_id']        = $city_id;
            $fangchanInfo['area_id']        = $area_id;
            $fangchanInfo['area_name']      = $areaInfo['name'];
            $fangchanInfo['street_id']      = $street_id;
            $fangchanInfo['street_name']    = $streetInfo['name'];
            $fangchanInfo['address']        = $address;
            $fangchanInfo['latitude']       = $latitude;
            $fangchanInfo['longitude']      = $longitude;
            $fangchanInfo['houses_name']    = $houses_name;
        }
        
        $fangchanInfo['mianji']         = $mianji;
        $fangchanInfo['price']          = $price;
        $fangchanInfo['search_text']    = $title.'|++++|'.$house_no.'|++++|'.$housesInfo['name'].'|++++|'.$tradeInfo['name'];
        
        $attrInfo['attr_zhuangxiu_type']    = $attr_zhuangxiu_type;
        $attrInfo['attr_house_type']        = $attr_house_type;
        $attrInfo['attr_chaoxiang_type']    = $attr_chaoxiang_type;
        $attrInfo['attr_shi']               = $attr_shi;
        $attrInfo['attr_ting']              = $attr_ting;
        $attrInfo['attr_wei']               = $attr_wei;
        $attrInfo['attr_louceng']           = $attr_louceng;
        $attrInfo['attr_cengshu']           = $attr_cengshu;
        $attrInfo['attr_chanquan']          = $attr_chanquan;
        $attrInfo['attr_elevator']          = $attr_elevator;
        $attrInfo['attr_tese_tags']         = $attr_tese_tags;
        
    }else if($infoArr['model_id'] == 'chuzu'){
        if($houses_id > 0){
            $fangchanInfo['city_id']        = $housesInfo['city_id'];
            $fangchanInfo['area_id']        = $housesInfo['area_id'];
            $fangchanInfo['area_name']      = $housesInfo['area_name'];
            $fangchanInfo['street_id']      = $housesInfo['street_id'];
            $fangchanInfo['street_name']    = $housesInfo['street_name'];
            $fangchanInfo['address']        = $housesInfo['address'];
            $fangchanInfo['latitude']       = $housesInfo['latitude'];
            $fangchanInfo['longitude']      = $housesInfo['longitude'];
            $fangchanInfo['houses_id']      = $housesInfo['id'];
            $fangchanInfo['houses_name']    = $housesInfo['name'];
        }else{
            $fangchanInfo['city_id']        = $city_id;
            $fangchanInfo['area_id']        = $area_id;
            $fangchanInfo['area_name']      = $areaInfo['name'];
            $fangchanInfo['street_id']      = $street_id;
            $fangchanInfo['street_name']    = $streetInfo['name'];
            $fangchanInfo['address']        = $address;
            $fangchanInfo['latitude']       = $latitude;
            $fangchanInfo['longitude']      = $longitude;
            $fangchanInfo['houses_name']    = $houses_name;
        }
        $fangchanInfo['mianji']         = $mianji;
        $fangchanInfo['rent']           = $rent;
        $fangchanInfo['search_text']    = $title.'|++++|'.$house_no.'|++++|'.$housesInfo['name'].'|++++|'.$tradeInfo['name'];
        
        $attrInfo['attr_zhuangxiu_type']    = $attr_zhuangxiu_type;
        $attrInfo['attr_house_type']        = $attr_house_type;
        $attrInfo['attr_chaoxiang_type']    = $attr_chaoxiang_type;
        $attrInfo['attr_shi']               = $attr_shi;
        $attrInfo['attr_ting']              = $attr_ting;
        $attrInfo['attr_wei']               = $attr_wei;
        $attrInfo['attr_louceng']           = $attr_louceng;
        $attrInfo['attr_cengshu']           = $attr_cengshu;
        $attrInfo['attr_lease_type']        = $attr_lease_type;
        $attrInfo['attr_rent_type']         = $attr_rent_type;
        $attrInfo['attr_rent_unit']         = $attr_rent_unit;
        $attrInfo['attr_elevator']          = $attr_elevator;
        $attrInfo['attr_tese_tags']         = $attr_tese_tags;
        $attrInfo['attr_peitao_tags']       = $attr_peitao_tags;
        
    }else if($infoArr['model_id'] == 'shangpu' || $infoArr['model_id'] == 'xiezilou' || $infoArr['model_id'] == 'changfang' ||  $infoArr['model_id'] == 'cangku' ||  $infoArr['model_id'] == 'tudi'){
        
        $fangchanInfo['city_id']            = $city_id;
        $fangchanInfo['area_id']            = $area_id;
        $fangchanInfo['area_name']          = $areaInfo['name'];
        $fangchanInfo['street_id']          = $street_id;
        $fangchanInfo['street_name']        = $streetInfo['name'];
        $fangchanInfo['address']            = $address;
        $fangchanInfo['latitude']           = $latitude;
        $fangchanInfo['longitude']          = $longitude;
        $fangchanInfo['fangchan_nature']    = $fangchan_nature;
        if($fangchan_nature == 1){
            $fangchanInfo['rent']               = $rent;
        }else if($fangchan_nature == 2){
            $fangchanInfo['price']              = $price;
        }else if($fangchan_nature == 3){
            $fangchanInfo['zhuanrang_price']    = $zhuanrang_price;
        }
        $fangchanInfo['mianji']             = $mianji;
        $fangchanInfo['search_text']        = $title.'|++++|'.$house_no.'|++++|'.$tradeInfo['name'];
        
        if($fangchan_nature == 1){
            $attrInfo['attr_rent_type']         = $attr_rent_type;
            $attrInfo['attr_rent_unit']         = $attr_rent_unit;
        }
        if($infoArr['model_id'] == 'shangpu'){
            $attrInfo['attr_shangpu_type']      = $attr_shangpu_type;
            $attrInfo['attr_louceng']           = $attr_louceng;
            $attrInfo['attr_cengshu']           = $attr_cengshu;
        }
        if($infoArr['model_id'] == 'xiezilou'){
            $attrInfo['attr_louceng']           = $attr_louceng;
            $attrInfo['attr_cengshu']           = $attr_cengshu;
        }
        $attrInfo['attr_tese_tags']         = $attr_tese_tags;
        
    }
    
    $data['fangchanInfo']       = $fangchanInfo;
    $data['attrInfo']           = $attrInfo;
    $data['vr_picurl']          = $vr_picurl;
    $data['video_picurl']       = $video_picurl;
    $data['configTagList']      = $configTagList;
    $data['attrTeseTagsIdsStr'] = $attrTeseTagsIdsStr;
    
    return $data;
}

function __create_info_html($infoArr = array(), $attrInfoArr = array()){
    global $Lang,$tcfangchanConfig,$tongchengConfig,$zhuangxiuTypeArr,$houseTypeArr,$zhuangxiuTypeAr,$chaoxiangTypeArr,$rentTypeArr,$rentUnitArr,$chuzuPeitaoArr,$shangpuTypeArr;
    $options = array(
        'title'             => '',
        'user_id'           => 0,
        'house_no'          => '',
        'house_tel'         => '',
        'trade_id'          => 0,
        'city_id'           => 0,
        'area_id'           => 0,
        'street_id'         => 0,
        'houses_id'         => 0,
        'houses_name'       => '',
        'mianji'            => 0.00,
        'price'             => 0.00,
        'rent'              => 0.00,
        'zhuanrang_price'   => 0.00,
        'fangchan_nature'   => 0,
        'address'           => '',
        'latitude'          => '',
        'longitude'         => '',
        'video_url'         => '',
        'video_picurl'      => '',
        'vr_link'           => '',
        'vr_picurl'         => '',
        'xm'                => '',
        'tel'               => '',
        'wx'                => '',
        'content'           => '',
        'top_time'          => 0,
        'expire_time'       => 0,
    );
    $attrOptions = array(
        'attr_zhuangxiu_type'   => 0,
        'attr_house_type'       => 0,
        'attr_chaoxiang_type'   => 0,
        'attr_shi'              => 0,
        'attr_ting'             => 0,
        'attr_wei'              => 0,
        'attr_louceng'          => 0,
        'attr_cengshu'          => 0,
        'attr_chanquan'         => 0,
        'attr_elevator'         => 0,
        'attr_tese_tags'        => 0,
        'attr_lease_type'       => 0,
        'attr_shangpu_type'     => 0,
        'attr_rent_type'        => 0,
        'attr_rent_unit'        => 1,
        'attr_peitao_tags'      => 0,
    );
    $options = array_merge($options, $infoArr);
    $attrOptions = array_merge($attrOptions, $attrInfoArr);
    
    $teseTagListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config_tag")->fetch_all_list(" AND model_id = '{$options['model_id']}' ", 'ORDER BY tsort ASC,id DESC', 0, 30);
    $teseTagList = array();
    if(is_array($teseTagListTmp) && !empty($teseTagListTmp)){
        foreach($teseTagListTmp as $key => $value){
            $teseTagList[$value['id']] = $value['name'];
        }
    }
    
    $photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id={$options['id']} AND type IN(2,4) "," ORDER BY type DESC,psort ASC,id ASC ",0,1);
    $vrPicurl = $videoPicurl = '';
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach($photoListTmp as $key => $value){
            if($value['type'] == 2){
                $vrPicurl = $value['picurl'];
            }
            if($value['type'] == 4){
                $videoPicurl = $value['picurl'];
            }
        }
    }
    
    tomshowsetting(true,array('title'=>$Lang['index_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['index_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_xm'],'name'=>'xm','value'=>$options['xm'],'msg'=>$Lang['index_xm_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_tel'],'name'=>'tel','value'=>$options['tel'],'msg'=>$Lang['index_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_wx'],'name'=>'wx','value'=>$options['wx'],'msg'=>$Lang['index_wx_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_house_no'],'name'=>'house_no','value'=>$options['house_no'],'msg'=>$Lang['index_house_no_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_house_tel'],'name'=>'house_tel','value'=>$options['house_tel'],'msg'=>$Lang['index_house_tel_msg']),"input");
    if($tcfangchanConfig['open_trade'] == 1){
        tomshowsetting(true,array('title'=>$Lang['index_trade_id'],'name'=>'trade_id','value'=>$options['trade_id'],'msg'=>$Lang['index_trade_id_msg']),"input");
    }
    if($options['source_type'] == 2){
        tomshowsetting(true,array('title'=>$Lang['edit_expire_time'],'name'=>'expire_time','value'=>$options['expire_time'],'msg'=>$Lang['edit_expire_time_msg']),"calendar");
    }
    tomshowsetting(true,array('title'=>$Lang['edit_top_time'],'name'=>'top_time','value'=>$options['top_time'],'msg'=>$Lang['edit_top_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['index_video_url'],'name'=>'video_url','value'=>$options['video_url'],'msg'=>$Lang['index_video_url_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_video_pic_link'],'name'=>'video_picurl','value'=>$videoPicurl,'msg'=>$Lang['index_video_pic_link_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_vr_link'],'name'=>'vr_link','value'=>$options['vr_link'],'msg'=>$Lang['index_vr_link_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_vr_pic_link'],'name'=>'vr_picurl','value'=>$vrPicurl,'msg'=>$Lang['index_vr_pic_link_msg']),"file");
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($options['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($options['site_id']);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
        }
    }else if($options['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
    $areaStr.= '<tr><td width="100" ><b>'.$Lang['newhouses_diqu'].'</b></td></tr>';
    $areaStr.= '<tr><td ><select style="width: 130px;" name="area_id" id="area_id" onChange="getStreet();">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($areaList as $key => $value){
        if($options['area_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select>';

    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($options['area_id']);
    $areaStr.= '<select style="width: 130px;" name="street_id" id="street_id">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($streetList as $key => $value){
        if($options['street_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select><input type="hidden" name="city_id" value="'.$__CityInfo['id'].'"></td><td>'.$Lang['newhouses_diqu_msg'].'</td></tr>';
    echo $areaStr;

    tomshowsetting(true,array('title'=>$Lang['index_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['index_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_latitude'],'name'=>'latitude','value'=>$options['latitude'],'msg'=>$Lang['houses_latitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_longitude'],'name'=>'longitude','value'=>$options['longitude'],'msg'=>$Lang['houses_longitude_msg']),"input");

    if($options['model_id'] == 'ershoufang'){
        
        tomshowsetting(true,array('title'=>$Lang['index_houses_id'],'name'=>'houses_id','value'=>$options['houses_id'],'msg'=>$Lang['index_houses_id_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_houses_name'],'name'=>'houses_name','value'=>$options['houses_name'],'msg'=>$Lang['index_houses_name_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_mianji'],'name'=>'mianji','value'=>$options['mianji'],'msg'=>$Lang['index_mianji_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_price'],'name'=>'price','value'=>$options['price'],'msg'=>$Lang['index_price_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_attr_zhuangxiu_type'],'name'=>'attr_zhuangxiu_type','value'=>$attrOptions['attr_zhuangxiu_type'],'msg'=>$Lang['index_attr_zhuangxiu_type_msg'],'item'=>$zhuangxiuTypeArr),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_attr_house_type'],'name'=>'attr_house_type','value'=>$attrOptions['attr_house_type'],'msg'=>$Lang['index_attr_house_type_msg'],'item'=>$houseTypeArr),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_attr_chaoxiang_type'],'name'=>'attr_chaoxiang_type','value'=>$attrOptions['attr_chaoxiang_type'],'msg'=>$Lang['index_attr_chaoxiang_type_msg'],'item'=>$chaoxiangTypeArr),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_attr_s_t_w'],'name'=>'attr_shi','value'=>$attrOptions['attr_shi'],'msg'=>$Lang['shi']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_attr_s_t_w'],'name'=>'attr_ting','value'=>$attrOptions['attr_ting'],'msg'=>$Lang['ting']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_attr_s_t_w'],'name'=>'attr_wei','value'=>$attrOptions['attr_wei'],'msg'=>$Lang['wei']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_attr_louceng'],'name'=>'attr_louceng','value'=>$attrOptions['attr_louceng'],'msg'=>$Lang['index_attr_louceng_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_attr_cengshu'],'name'=>'attr_cengshu','value'=>$attrOptions['attr_cengshu'],'msg'=>$Lang['index_attr_cengshu_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_attr_chanquan'],'name'=>'attr_chanquan','value'=>$attrOptions['attr_chanquan'],'msg'=>$Lang['index_attr_chanquan_msg']),"input");
        $attr_elevator_item = array(1=>$Lang['index_attr_elevator_1'], 2=>$Lang['index_attr_elevator_2']);
        tomshowsetting(true,array('title'=>$Lang['index_attr_elevator'],'name'=>'attr_elevator','value'=>$attrOptions['attr_elevator'],'msg'=>$Lang['index_attr_elevator_msg'],'item'=>$attr_elevator_item),"radio");
        
        $attrTestTagsArr = explode('|', trim($attrOptions['attr_tese_tags'],'|'));
        $teseTagsStr = '<tr class="header"><th>'.$Lang['index_attr_tese_tags'].'</th><th></th></tr>';
        $teseTagsStr.= '<tr><td width="300">';
        foreach ($teseTagList as $key => $value){
            if(in_array($value, $attrTestTagsArr)){
                $teseTagsStr.=  '<label><input type="checkbox" name="attr_tese_tags[]" value="'.$key.'" checked>'.$value.'</label>&nbsp;&nbsp;';
            }else{
                $teseTagsStr.=  '<label><input type="checkbox" name="attr_tese_tags[]" value="'.$key.'">'.$value.'</label>&nbsp;&nbsp;';
            }
        }
        $teseTagsStr.= '</select></td><td>'.$Lang['index_attr_tese_tags_msg'].'</td></tr>';
        echo $teseTagsStr;
        
    }else if($options['model_id'] == 'chuzu'){
        
        tomshowsetting(true,array('title'=>$Lang['index_houses_id'],'name'=>'houses_id','value'=>$options['houses_id'],'msg'=>$Lang['index_houses_id_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_houses_name'],'name'=>'houses_name','value'=>$options['houses_name'],'msg'=>$Lang['index_houses_name_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_mianji'],'name'=>'mianji','value'=>$options['mianji'],'msg'=>$Lang['index_mianji_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_rent'],'name'=>'rent','value'=>$options['rent'],'msg'=>$Lang['index_rent_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_attr_rent_unit'],'name'=>'attr_rent_unit','value'=>$attrOptions['attr_rent_unit'],'msg'=>$Lang['index_attr_rent_unit_msg'],'item'=>$rentUnitArr),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_attr_zhuangxiu_type'],'name'=>'attr_zhuangxiu_type','value'=>$attrOptions['attr_zhuangxiu_type'],'msg'=>$Lang['index_attr_zhuangxiu_type_msg'],'item'=>$zhuangxiuTypeArr),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_attr_house_type'],'name'=>'attr_house_type','value'=>$attrOptions['attr_house_type'],'msg'=>$Lang['index_attr_house_type_msg'],'item'=>$houseTypeArr),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_attr_chaoxiang_type'],'name'=>'attr_chaoxiang_type','value'=>$attrOptions['attr_chaoxiang_type'],'msg'=>$Lang['index_attr_chaoxiang_type_msg'],'item'=>$chaoxiangTypeArr),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_attr_s_t_w'],'name'=>'attr_shi','value'=>$attrOptions['attr_shi'],'msg'=>$Lang['shi']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_attr_s_t_w'],'name'=>'attr_ting','value'=>$attrOptions['attr_ting'],'msg'=>$Lang['ting']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_attr_s_t_w'],'name'=>'attr_wei','value'=>$attrOptions['attr_wei'],'msg'=>$Lang['wei']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_attr_louceng'],'name'=>'attr_louceng','value'=>$attrOptions['attr_louceng'],'msg'=>$Lang['index_attr_louceng_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_attr_cengshu'],'name'=>'attr_cengshu','value'=>$attrOptions['attr_cengshu'],'msg'=>$Lang['index_attr_cengshu_msg']),"input");
        $attr_lease_type_item = array(1=>$Lang['index_attr_lease_type_1'], 2=>$Lang['index_attr_lease_type_2']);
        tomshowsetting(true,array('title'=>$Lang['index_attr_lease_type'],'name'=>'attr_lease_type','value'=>$attrOptions['attr_lease_type'],'msg'=>$Lang['index_attr_lease_type_msg'],'item'=>$attr_lease_type_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_attr_rent_type'],'name'=>'attr_rent_type','value'=>$attrOptions['attr_rent_type'],'msg'=>$Lang['index_attr_rent_type_msg'],'item'=>$rentTypeArr),"radio");
        $attr_elevator_item = array(1=>$Lang['index_attr_elevator_1'], 2=>$Lang['index_attr_elevator_2']);
        tomshowsetting(true,array('title'=>$Lang['index_attr_elevator'],'name'=>'attr_elevator','value'=>$attrOptions['attr_elevator'],'msg'=>$Lang['index_attr_elevator_msg'],'item'=>$attr_elevator_item),"radio");
        
        $attrTestTagsArr = explode('|', trim($attrOptions['attr_tese_tags'],'|'));
        $teseTagsStr = '<tr class="header"><th>'.$Lang['index_attr_tese_tags'].'</th><th></th></tr>';
        $teseTagsStr.= '<tr><td width="300">';
        foreach ($teseTagList as $key => $value){
            if(in_array($value, $attrTestTagsArr)){
                $teseTagsStr.=  '<label><input type="checkbox" name="attr_tese_tags[]" value="'.$key.'" checked>'.$value.'</label>&nbsp;&nbsp;';
            }else{
                $teseTagsStr.=  '<label><input type="checkbox" name="attr_tese_tags[]" value="'.$key.'">'.$value.'</label>&nbsp;&nbsp;';
            }
        }
        $teseTagsStr.= '</select></td><td>'.$Lang['index_attr_tese_tags_msg'].'</td></tr>';
        echo $teseTagsStr;
        
        $attrPeitaoTagsArr = explode('|', trim($attrOptions['attr_peitao_tags'],'|'));
        $peitaoTagsStr = '<tr class="header"><th>'.$Lang['index_attr_peitao_tags'].'</th><th></th></tr>';
        $peitaoTagsStr.= '<tr><td width="300">';
        foreach ($chuzuPeitaoArr as $key => $value){
            if(in_array($value['name'], $attrPeitaoTagsArr)){
                $peitaoTagsStr.=  '<label><input type="checkbox" name="attr_peitao_tags[]" value="'.$value['name'].'" checked>'.$value['name'].'</label>&nbsp;&nbsp;';
            }else{
                $peitaoTagsStr.=  '<label><input type="checkbox" name="attr_peitao_tags[]" value="'.$value['name'].'">'.$value['name'].'</label>&nbsp;&nbsp;';
            }
        }
        $peitaoTagsStr.= '</select></td><td>'.$Lang['index_attr_peitao_tags_msg'].'</td></tr>';
        echo $peitaoTagsStr;
        
    }else if($options['model_id'] == 'shangpu' || $options['model_id'] == 'xiezilou' || $options['model_id'] == 'changfang' || $options['model_id'] == 'cangku' || $options['model_id'] == 'tudi'){
        
        tomshowsetting(true,array('title'=>$Lang['index_mianji'],'name'=>'mianji','value'=>$options['mianji'],'msg'=>$Lang['index_mianji_msg']),"input");
        $fangchan_nature_item = array(1=>$Lang['index_fangchan_nature_1'], 2=>$Lang['index_fangchan_nature_2'], 3=>$Lang['index_fangchan_nature_3']);
        tomshowsetting(true,array('title'=>$Lang['index_fangchan_nature'],'name'=>'fangchan_nature','value'=>$options['fangchan_nature'],'msg'=>$Lang['index_fangchan_nature_msg'],'item'=>$fangchan_nature_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_price'],'name'=>'price','value'=>$options['price'],'msg'=>$Lang['index_price_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_zhuanrang_price'],'name'=>'zhuanrang_price','value'=>$options['zhuanrang_price'],'msg'=>$Lang['index_zhuanrang_price_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_rent'],'name'=>'rent','value'=>$options['rent'],'msg'=>$Lang['index_rent_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['index_attr_rent_unit'],'name'=>'attr_rent_unit','value'=>$attrOptions['attr_rent_unit'],'msg'=>$Lang['index_attr_rent_unit_msg'],'item'=>$rentUnitArr),"radio");
        tomshowsetting(true,array('title'=>$Lang['index_attr_rent_type'],'name'=>'attr_rent_type','value'=>$attrOptions['attr_rent_type'],'msg'=>$Lang['index_attr_rent_type_msg'],'item'=>$rentTypeArr),"radio");
        
        if($options['model_id'] == 'shangpu'){
            tomshowsetting(true,array('title'=>$Lang['index_attr_shangpu_type'],'name'=>'attr_shangpu_type','value'=>$attrOptions['attr_shangpu_type'],'msg'=>$Lang['index_attr_shangpu_type_msg'],'item'=>$shangpuTypeArr),"radio");
            tomshowsetting(true,array('title'=>$Lang['index_attr_louceng'],'name'=>'attr_louceng','value'=>$attrOptions['attr_louceng'],'msg'=>$Lang['index_attr_louceng_msg']),"input");
            tomshowsetting(true,array('title'=>$Lang['index_attr_cengshu'],'name'=>'attr_cengshu','value'=>$attrOptions['attr_cengshu'],'msg'=>$Lang['index_attr_cengshu_msg']),"input");
        }
        if($options['model_id'] == 'xiezilou'){
            tomshowsetting(true,array('title'=>$Lang['index_attr_louceng'],'name'=>'attr_louceng','value'=>$attrOptions['attr_louceng'],'msg'=>$Lang['index_attr_louceng_msg']),"input");
            tomshowsetting(true,array('title'=>$Lang['index_attr_cengshu'],'name'=>'attr_cengshu','value'=>$attrOptions['attr_cengshu'],'msg'=>$Lang['index_attr_cengshu_msg']),"input");
        }
        
        $attrTestTagsArr = explode('|', trim($attrOptions['attr_tese_tags'],'|'));
        $teseTagsStr = '<tr class="header"><th>'.$Lang['index_attr_tese_tags'].'</th><th></th></tr>';
        $teseTagsStr.= '<tr><td width="300">';
        foreach ($teseTagList as $key => $value){
            if(in_array($value, $attrTestTagsArr)){
                $teseTagsStr.=  '<label><input type="checkbox" name="attr_tese_tags[]" value="'.$key.'" checked>'.$value.'</label>&nbsp;&nbsp;';
            }else{
                $teseTagsStr.=  '<label><input type="checkbox" name="attr_tese_tags[]" value="'.$key.'">'.$value.'</label>&nbsp;&nbsp;';
            }
        }
        $teseTagsStr.= '</select></td><td>'.$Lang['index_attr_tese_tags_msg'].'</td></tr>';
        echo $teseTagsStr;
        
    }
    tomshowsetting(true,array('title'=>$Lang['index_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['index_content_msg']),"text");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['edit'],"",true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',false);
        tomshownavli($Lang['doDao_title_1'],$adminBaseUrl.'&tmod=doDaoFangchan',false);
        tomshownavli($Lang['index_guanggao_title'],$adminBaseUrl.'&tmod=guanggao',false);
        tomshownavli($Lang['index_list_jubao'],$adminBaseUrl.'&tmod=jubao',false);
        tomshownavli($Lang['config_list_title'],$adminBaseUrl.'&tmod=config',false);
        tomshownavli($Lang['config_tag_list_title'],$adminBaseUrl.'&tmod=config_tag',false);
        tomshownavli($Lang['index_common_title'],$adminBaseUrl.'&tmod=common',false);
    }
    
    tomshownavfooter();
}