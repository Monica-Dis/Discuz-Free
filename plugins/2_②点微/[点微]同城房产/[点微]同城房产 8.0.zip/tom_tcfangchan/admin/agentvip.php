<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=agentvip';
$modListUrl = $adminListUrl.'&tmod=agentvip';
$modFromUrl = $adminFromUrl.'&tmod=agentvip';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_agent_vip')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $vipInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent_vip')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($vipInfo);
        C::t('#tom_tcfangchan#tom_tcfangchan_agent_vip')->update($vipInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($vipInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcfangchan#tom_tcfangchan_agent_vip')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $vipList = C::t('#tom_tcfangchan#tom_tcfangchan_agent_vip')->fetch_all_list(""," ORDER BY vsort ASC,id DESC ",$start,$pagesize);
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['agentvip_name'] . '</th>';
    echo '<th>' . $Lang['agentvip_logo'] . '</th>';
    echo '<th>' . $Lang['agentvip_days'] . '</th>';
    echo '<th>' . $Lang['agentvip_price'] . '</th>';
    echo '<th>' . $Lang['agentvip_fabu_num'] . '</th>';
    echo '<th>' . $Lang['agentvip_total_fabu_num'] . '</th>';
    echo '<th>' . $Lang['agentvip_refresh_num'] . '</th>';
    echo '<th>' . $Lang['agentvip_top_zhekou'] . '</th>';
    echo '<th>' . $Lang['agentvip_free_shenhe'] . '</th>'; 
    echo '<th>' . $Lang['agentvip_open_visitor'] . '</th>';   
    echo '<th>' . $Lang['mendianvip_max_num'] . '</th>';   
    echo '<th>' . $Lang['agentvip_status'] . '</th>';
    echo '<th>' . $Lang['paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($vipList as $key => $value) {
        
        $top_zhekou = $value['top_zhekou'] / 10;
        $top_zhekou = trim($top_zhekou, '.0');
        
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td><img width="40" src="' . tomgetfileurl($value['logo']) . '"></td>';
        echo '<td>' . $value['days'] . '</td>';
        echo '<td><font color="#f00">' . $value['price'] . '</font></td>';
        echo '<td>' . $value['fabu_num'] . '</td>';
        if($value['total_fabu_num'] > 0){
            echo '<td>' . $value['total_fabu_num'] . '</td>';
        }else{
            echo '<td>' . $Lang['agentvip_total_fabu_num_0'] . '</td>';
        }
        echo '<td>' . $value['refresh_num'] . '</td>';
        if($value['top_zhekou'] > 0){
            echo '<td>' . $top_zhekou .$Lang['zhe']. '</td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['free_shenhe'] == 1){
            echo '<td><font color="#0a9409">' .$Lang['agentvip_free_shenhe_1']. '</font></td>';
        }else{
            echo '<td><font color="#f70404">' .$Lang['agentvip_free_shenhe_0']. '</font></td>';
        }
        if($value['open_visitor'] == 1){
            echo '<td><font color="#0a9409">' .$Lang['agentvip_open_visitor_1']. '</font></td>';
        }else{
            echo '<td><font color="#f70404">' .$Lang['agentvip_open_visitor_0']. '</font></td>';
        }
        if($value['max_num'] > 0){
            echo '<td>' .$value['max_num']. '</td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['status'] == 1){
            echo '<td><font color="#0a9409">' .$Lang['agentvip_status_1']. '</font></td>';
        }else{
            echo '<td><font color="#f70404">' .$Lang['agentvip_status_0']. '</font></td>';
        }
        echo '<td>' . $value['vsort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $days               = isset($_GET['days'])? intval($_GET['days']):0;
    $fabu_num           = isset($_GET['fabu_num'])? intval($_GET['fabu_num']):0;
    $total_fabu_num     = isset($_GET['total_fabu_num'])? intval($_GET['total_fabu_num']):0;
    $refresh_num        = isset($_GET['refresh_num'])? intval($_GET['refresh_num']):0;
    $top_zhekou         = isset($_GET['top_zhekou'])? intval($_GET['top_zhekou']):0;
    $free_shenhe        = isset($_GET['free_shenhe'])? intval($_GET['free_shenhe']):0;
    $open_visitor       = isset($_GET['open_visitor'])? intval($_GET['open_visitor']):0;
    $price              = isset($_GET['price'])? floatval($_GET['price']):0.00;
    $max_num            = isset($_GET['max_num'])? intval($_GET['max_num']):0;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $vsort              = isset($_GET['vsort'])? intval($_GET['vsort']):100;
    
    $logo = "";
    if($_GET['act'] == 'add'){
        $logo     = tomuploadFile("logo");
    }else if($_GET['act'] == 'edit'){
        $logo     = tomuploadFile("logo",$infoArr['logo']);
    }
    
    if($top_zhekou > 100){
        $top_zhekou = 0;
    }
    
    if($top_zhekou > 0 && $top_zhekou < 10){
        $top_zhekou = 10;
    }
    
    $data['name']               = $name;
    $data['logo']               = $logo;
    $data['days']               = $days;
    $data['fabu_num']           = $fabu_num;
    $data['total_fabu_num']     = $total_fabu_num;
    $data['refresh_num']        = $refresh_num;
    $data['top_zhekou']         = $top_zhekou;
    $data['free_shenhe']        = $free_shenhe;
    $data['open_visitor']       = $open_visitor;
    $data['price']              = $price;
    $data['max_num']            = $max_num;
    $data['status']             = $status;
    $data['vsort']              = $vsort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'              => '',
        'logo'              => '',
        'days'              => 0,
        'fabu_num'          => 0,
        'total_fabu_num'    => 0,
        'refresh_num'       => 0,
        'top_zhekou'        => 0,
        'free_shenhe'       => 0,
        'open_visitor'      => 0,
        'price'             => '',
        'max_num'           => 0,
        'status'            => 1,
        'vsort'             => 100,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['agentvip_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['agentvip_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['agentvip_logo'],'name'=>'logo','value'=>$options['logo'],'msg'=>$Lang['agentvip_logo_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['agentvip_days'],'name'=>'days','value'=>$options['days'],'msg'=>$Lang['agentvip_days_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['agentvip_fabu_num'],'name'=>'fabu_num','value'=>$options['fabu_num'],'msg'=>$Lang['agentvip_fabu_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['agentvip_total_fabu_num'],'name'=>'total_fabu_num','value'=>$options['total_fabu_num'],'msg'=>$Lang['agentvip_total_fabu_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['agentvip_refresh_num'],'name'=>'refresh_num','value'=>$options['refresh_num'],'msg'=>$Lang['agentvip_refresh_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['agentvip_top_zhekou'],'name'=>'top_zhekou','value'=>$options['top_zhekou'],'msg'=>$Lang['agentvip_top_zhekou_msg']),"input");
    $free_shenhe_item = array(0=>$Lang['agentvip_free_shenhe_0'],1=>$Lang['agentvip_free_shenhe_1']);
    tomshowsetting(true,array('title'=>$Lang['agentvip_free_shenhe'],'name'=>'free_shenhe','value'=>$options['free_shenhe'],'msg'=>$Lang['agentvip_free_shenhe_msg'],'item'=>$free_shenhe_item),"radio");
    $open_visitor_item = array(0=>$Lang['agentvip_open_visitor_0'],1=>$Lang['agentvip_open_visitor_1']);
    tomshowsetting(true,array('title'=>$Lang['agentvip_open_visitor'],'name'=>'open_visitor','value'=>$options['open_visitor'],'msg'=>$Lang['agentvip_open_visitor_msg'],'item'=>$open_visitor_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['agentvip_price'],'name'=>'price','value'=>$options['price'],'msg'=>$Lang['agentvip_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['mendianvip_max_num'],'name'=>'max_num','value'=>$options['max_num'],'msg'=>$Lang['mendianvip_max_num_msg']),"input");
    $status_item = array(0=>$Lang['agentvip_status_0'],1=>$Lang['agentvip_status_1']);
    tomshowsetting(true,array('title'=>$Lang['agentvip_status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['agentvip_status_msg'],'item'=>$status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'vsort','value'=>$options['vsort'],'msg'=>$Lang['sort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['agentvip_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['agentvip_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['agentvip_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['agentvip_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['agentvip_edit'],"",true);
    }else{
        tomshownavli($Lang['agentvip_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['agentvip_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}