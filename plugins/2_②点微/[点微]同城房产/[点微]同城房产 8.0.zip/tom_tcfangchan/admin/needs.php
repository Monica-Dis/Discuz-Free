<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=needs';
$modListUrl = $adminListUrl.'&tmod=needs';
$modFromUrl = $adminFromUrl.'&tmod=needs';

$get_list_url_value = get_list_url("tom_tcfangchan_admin_needs_list");

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $data = __get_post_data($needsInfo);
        $insertData = array();
        $insertData = $data;
        $insertData['status']           = 0;
        $insertData['shenhe_status']    = 1;
        $insertData['expire_status']    = 3;
        $insertData['refresh_time']     = TIMESTAMP;
        $insertData['add_time']         = TIMESTAMP;
        if(C::t('#tom_tcfangchan#tom_tcfangchan_needs')->insert($insertData)){
            $needs_id = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->insert_id();
            $needsInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($needs_id);
            update_needs_tongcheng($needsInfo['id']);
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
        
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($needsInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $needsInfo = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $data = __get_post_data($needsInfo);
        $updateData = array();
        $updateData = $data;
        $updateData['refresh_time']     = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($needsInfo['id'],$updateData);
        
        $needsInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($needsInfo['id']);
        
        update_needs_tongcheng($needsInfo['id']);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($needsInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status'] = 1;
    $updateData['status']        = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($_GET['id'],$updateData);
    
    update_needs_tongcheng($_GET['id']);
    
    $needsInfo = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);

    $shenhe = str_replace('{CONTENT}', $needsInfo['content'], $Lang['index_template_needs_shenhe_ok']);
    $cpmsg = $Lang['tcfangchan_shenhe_tz_succ'];
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$needsInfo['site_id']}&mod=needsinfo&needs_id=".$needsInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcfangchanConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
        }else{
            $cpmsg = $Lang['tcfangchan_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $needsInfo = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($_GET['id'],$updateData);
        
        update_needs_tongcheng($_GET['id']);
        
        $shenhe = str_replace('{TITLE}', $needsInfo['content'], $Lang['index_template_needs_shenhe_no']);
        $cpmsg = $Lang['tcfangchan_shenhe_tz_succ'];
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$needsInfo['site_id']}&mod=edit_needs&needs_id=".$needsInfo['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
            }else{
                $cpmsg = $Lang['tcfangchan_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tcfangchan_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tcfangchan_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcfangchan_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($_GET['id'],$updateData);
    
    update_needs_tongcheng($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status']     = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($_GET['id'],$updateData);
    
    update_needs_tongcheng($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $needs_id  = isset($_GET['id'])? intval($_GET['id']):0;
    
    C::t('#tom_tcfangchan#tom_tcfangchan_needs')->delete_by_id($_GET['id']);
    
    delete_needs_tongcheng($needs_id);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refresh'){
    
    $updateData = array();
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($_GET['id'],$updateData);
    
    update_needs_tongcheng($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'edittop'){
    $info = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $top_time     = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
        $top_time     = strtotime($top_time);
        $updateData = array();
        if($top_time < TIMESTAMP){
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
        }else{
            $updateData['top_status']   = 1;
            $updateData['refresh_time'] = TIMESTAMP;
            $updateData['top_time']     = $top_time;
        }
        C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($_GET['id'],$updateData);
        
        update_needs_tongcheng($_GET['id']);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edittop&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_top_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_top_time'],'name'=>'top_time','value'=>$info['top_time'],'msg'=>$Lang['edit_top_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editexpire'){
    $info = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $expire_time     = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
        $expire_time     = strtotime($expire_time);
        $updateData = array();
        if($expire_time < TIMESTAMP){
            $updateData['expire_status']    = 2;
            $updateData['expire_time']      = 0;
            $updateData['status']           = 0;
        }else{
            $updateData['expire_status']    = 1;
            $updateData['refresh_time']     = TIMESTAMP;
            $updateData['expire_time']      = $expire_time;
        }
        C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($_GET['id'],$updateData);
        
        update_needs_tongcheng($_GET['id']);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editexpire&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_expire_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_expire_time'],'name'=>'expire_time','value'=>$info['expire_time'],'msg'=>$Lang['edit_expire_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'pay_ok'){
    
    $updateData = array();
    $updateData['pay_status'] = 2;
    C::t("#tom_tcfangchan#tom_tcfangchan_needs")->update($_GET['id'], $updateData);
    
    update_needs_tongcheng($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_refresh'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['refresh_time']     = TIMESTAMP;
            C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($value,$updateData);
            update_needs_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_shenhe1'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
        
            $updateData = array();
            $updateData['shenhe_status']    = 1;
            $updateData['status']           = 1;
            C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($value,$updateData);
            
            update_needs_tongcheng($value);

            $needsInfo = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($value);
            $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);

            $shenhe = str_replace('{CONTENT}', $needsInfo['content'], $Lang['index_template_needs_shenhe_ok']);
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$needsInfo['site_id'].'&mod=needsinfo&needs_id='.$needsInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($tcUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$needsInfo['site_id']}&mod=needsinfo&needs_id=".$needsInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $insertData = array();
            $insertData['user_id']      = $tcUserInfo['id'];
            $insertData['type']         = 1;
            $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
            $insertData['is_read']      = 0;
            $insertData['tz_time']      = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
            
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_shenhe3'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            
            $needsInfo = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($value);
            $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);

            $updateData = array();
            $updateData['shenhe_status']    = 3;
            C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($value,$updateData);
            
            update_needs_tongcheng($value);
            
            $shenhe = str_replace('{TITLE}', $needsInfo['content'], $Lang['index_template_needs_shenhe_no']);
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$needsInfo['site_id'].'&mod=edit&needs_id='.$needsInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($tcUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$needsInfo['site_id']}&mod=edit&needs_id=".$needsInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                    $cpmsg = $Lang['tcfangchan_shenhe_tz_succ'];
                }else{
                    $cpmsg = $Lang['tcfangchan_shenhe_tz_fail'];
                }
            }

            $insertData = array();
            $insertData['user_id']      = $tcUserInfo['id'];
            $insertData['type']         = 1;
            $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.$Lang['tcfangchan_shenhe_fail_title'].'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
            $insertData['is_read']      = 0;
            $insertData['tz_time']      = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);

        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_del'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            
            C::t('#tom_tcfangchan#tom_tcfangchan_needs')->delete_by_id($value);
            
            delete_needs_tongcheng($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_show'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){

            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($value,$updateData);
            
            update_needs_tongcheng($value);
            
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_hide'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){

            $updateData = array();
            $updateData['status'] = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($value,$updateData);
            
            update_needs_tongcheng($value);
            
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{  
 
    set_list_url("tom_tcfangchan_admin_needs_list");
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ width: 100px;float: left;list-style-type: none;height: 32px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;color: #6a6d6a;width: 90px;height: 25px;line-height: 25px;display: block;text-align: center; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
</style>
EOF;
    echo $csstr;
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $needs_id           = isset($_GET['needs_id'])? intval($_GET['needs_id']):0;
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $pay_status         = isset($_GET['pay_status'])? intval($_GET['pay_status']):0;
    $expire_status      = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
    $search             = isset($_GET['search'])? intval($_GET['search']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    if($area_id > 0){
        $where.= " AND area_id='{$area_id}' ";
    }
    if($street_id > 0){
        $where.= " AND street_id='{$street_id}' ";
    }
    if(!empty($needs_id)){
        $where.= " AND id={$needs_id} ";
    }
    if($status == 1){
        $where.= " AND status=1 ";
    }else if($status == 2){
        $where.= " AND status=0 ";
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    if($pay_status > 0){
        $where.= " AND pay_status = {$pay_status} ";
    }
    if($top_status > 0){
        if($top_status == 1){
            $where.= " AND top_status = 1 ";
        }else if($top_status == 2){
            $where.= " AND top_status = 0 ";
        }
    }
    
    if($expire_status > 0){
        if($expire_status == 1){
            $where.= " AND ((expire_status = 1 AND expire_time > ".TIMESTAMP.") OR (expire_status = 3)) ";
        }else if($expire_status == 2){
            $where.= " AND expire_status = 2 ";
        } 
    }
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_count($where);
    $needsList = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&user_id={$user_id}&status={$status}&shenhe_status={$shenhe_status}&top_status={$top_status}&search={$search}&area_id={$area_id}&street_id={$street_id}&expire_status={$expire_status}&pay_status={$pay_status}";
    
    showformheader($modFromUrl."&search={$search}&formhash=".FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '<a href="'.$modBaseUrl.'&search=1"><font color="#F90B0B">('.$Lang['search_gaoji'].')</font></a></th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,10000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id" onChange="getCity();">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    echo '<tr><td width="100" align="right"><b>'.$Lang['needs_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="needs_id" value="'.$needs_id.'"></td></tr>';
    
    if($search == 1){
        echo '<tr><td width="100" align="right"><b>'.$Lang['user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';
        

        $__CityInfo  = array('id'=>0,'name'=>'');
        if($site_id > 1){
            $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
            if($sitesInfoTmp){
                $__SitesInfo = $sitesInfoTmp;
                if(!empty($__SitesInfo['city_id'])){
                    $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                    if($cityInfoTmp){
                        $__CityInfo = $cityInfoTmp;
                    }
                }
            }
        }else if($site_id == 1){
            $cityInfoTmp = array();
            if(!empty($tongchengConfig['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
            }
            if(!empty($cityInfoTmp)){
                $__CityInfo = $cityInfoTmp;
            }
        }
        $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
        $areaStr.= '<tr><td width="100" align="right"><b>'.$Lang['needs_search_diqu'].'</b></td>';
        $areaStr.= '<td ><select style="width: 130px;" name="area_id" id="area_id" onChange="getStreet();">';
        $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
        foreach ($areaList as $key => $value){
            if($area_id == $value['id']){
                $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $areaStr.= '</select>';

        $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
        $areaStr.= '<select style="width: 130px;" name="street_id" id="street_id">';
        $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
        foreach ($streetList as $key => $value){
            if($street_id == $value['id']){
                $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $areaStr.= '</select></td></tr>';
        echo $areaStr;
        
        $expire_status_1 = $expire_status_2 = '';
        if($expire_status == 1){
            $expire_status_1 = 'selected';
        }else if($expire_status == 2){
            $expire_status_2 = 'selected';
        }
        $expireStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['expire_status'].'</b></td>';
        $expireStatusStr.= '<td><select style="width: 260px;" name="expire_status" id="expire_status">';
        $expireStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
        $expireStatusStr.=  '<option value="1" '.$expire_status_1.'>'.$Lang['expire_status_1'].'</option>';
        $expireStatusStr.=  '<option value="2" '.$expire_status_2.'>'.$Lang['expire_status_2'].'</option>';
        $expireStatusStr.= '</select></td></tr>';
        echo $expireStatusStr;

        $pay_status_1 = $pay_status_2 = '';
        if($pay_status == 1){
            $pay_status_1 = 'selected';
        }else if($pay_status == 2){
            $pay_status_2 = 'selected';
        }
        $payStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['pay_status'].'</b></td>';
        $payStatusStr.= '<td><select style="width: 260px;" name="pay_status" id="pay_status">';
        $payStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
        $payStatusStr.=  '<option value="1" '.$pay_status_1.'>'.$Lang['pay_status_1'].'</option>';
        $payStatusStr.=  '<option value="2" '.$pay_status_2.'>'.$Lang['pay_status_2'].'</option>';
        $payStatusStr.= '</select></td></tr>';
        echo $payStatusStr;
    
    }
    
    $statusStr = '<tr><td width="100" align="right"><b>' . $Lang['needs_status'] . '</b></td><td><select style="width:260px;" name="status" >';
    $statusStr.= '<option value="0">'.$Lang['needs_status'].'</option>';
    $status1_selected = $status2_selected = "";
    if(1 == $status){
        $status1_selected = "selected";
    }
    if(2 == $status){
        $status2_selected = "selected";
    }
    $statusStr.= '<option value="1" '.$status1_selected.'>'.$Lang['needs_status_1'].'</option>';
    $statusStr.= '<option value="2" '.$status2_selected.'>'.$Lang['needs_status_2'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    $shenhe_status_1 = $shenhe_status_2 = $shenhe_status_3 = '';
    if($shenhe_status == 1){
        $shenhe_status_1 = 'selected';
    }else if($shenhe_status == 2){
        $shenhe_status_2 = 'selected';
    }else if($shenhe_status == 3){
        $shenhe_status_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['needs_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['needs_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$shenhe_status_1.'>'.$Lang['needs_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$shenhe_status_2.'>'.$Lang['needs_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$shenhe_status_3.'>'.$Lang['needs_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    $top_status_1 = $top_status_0 = '';
    if($top_status == 1){
        $top_status_1 = 'selected';
    }else if($top_status == 2){
        $top_status_0 = 'selected';
    }
    $topStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['top_status'].'</b></td>';
    $topStatusStr.= '<td><select style="width: 260px;" name="top_status" id="top_status">';
    $topStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $topStatusStr.=  '<option value="1" '.$top_status_1.'>'.$Lang['top_status_1'].'</option>';
    $topStatusStr.=  '<option value="2" '.$top_status_0.'>'.$Lang['top_status_0'].'</option>';
    $topStatusStr.= '</select></td></tr>';
    echo $topStatusStr;
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
    
    __create_nav_html();
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return batch_do();">'.
        '<input type="hidden" name="formhash" value="'.FORMHASH.'" />';
    showtableheader();
    echo '<tr class="header">';
    echo '<th style="width: 60px;">' . $Lang['needs_id'] . '</th>';
    echo '<th style="width: 60px;">' . $Lang['sites_title'] . '</th>';
    echo '<th style="width: 60px;">' . $Lang['needs_type'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['needs_content'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['needs_user_info'] . '</th>';
    echo '<th>' . $Lang['needs_status2'] . '</th>';
    echo '<th>' . $Lang['refresh_time'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($needsList as $key => $value) {
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $content  = cutstr($value['content'],30,"...");
        
        echo '<tr>';
        echo '<td><label><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" >' . $value['id'] . '</label></td>';
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</font></td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</font></td>';
        }
        if($value['type'] == 1){
            echo '<td><font color="#0894fb">' . $Lang['qiugou'] . '</td>';
        }else{
            echo '<td><font color="#238206">' . $Lang['qiuzu'] . '</td>';
        }
        echo '<td><div class="tc_content_box" style="width:200px;"><ul>';
        echo '<li>' .$content . '</li>';
        echo '</ul></div></td>';
        echo '<td><div class="tc_content_box" style="width:200px;"><ul>';
        echo '<li>'.$Lang['needs_fabu_user_id'].'&nbsp;:&nbsp;<font color="#0a9409">' . $userInfoTmp['nickname'] . '</font><font color="#f70404">(ID:'.$value['user_id'].')</font></li>';
        if($value['xm']){
            echo '<li>'.$Lang['needs_xm'].'&nbsp;:&nbsp;' . $value['xm'] . '</li>';
        }
        if($value['tel']){
            echo '<li>'.$Lang['needs_tel'].'&nbsp;:&nbsp;' . $value['tel'] . '</li>';
        }
        if($value['wx']){
            echo '<li>'.$Lang['needs_wx'].'&nbsp;:&nbsp;' . $value['wx'] . '</li>';
        }
        
        if(!empty($value['client_ip_port'])){
            echo '<p style="line-height:20px;">' . $Lang['index_client_ip_port'].$Lang['fenghao']. '<font color="#0a9409">'.$value['client_ip_port'].'</font></p>';
        }
        echo '</ul></div></td>';
        echo '<td><div class="tc_content_box"><ul>';
        if($value['top_status'] == 1){
            echo '<p style="line-height:20px;">' . $Lang['top_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['top_status_1'].'</font> <font color="#f70404">('.dgmdate($value['top_time'], 'Y-m-d H:i',$tomSysOffset).')</font></p>';
        }else{
            echo '<p style="line-height:20px;">' . $Lang['top_status'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['top_status_0'].'</font></p>';
        }
        if($value['expire_status'] == 1){
            echo '<p style="line-height:20px;">' . $Lang['expire_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['expire_status_1'].'</font><font color="#f70404">('.dgmdate($value['expire_time'], 'Y-m-d H:i',$tomSysOffset).')</font></p>';
        }else if($value['expire_status'] == 2){
            echo '<p style="line-height:20px;">' . $Lang['expire_status'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['expire_status_2'].'</font></p>';
        }else if($value['expire_status'] == 3){
            echo '<p style="line-height:20px;">' . $Lang['expire_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['expire_status_3'].'</font></p>';
        }
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['needs_shenhe_btn_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['needs_shenhe_btn_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<p style="line-height:20px;">' . $Lang['needs_shenhe_status'].$Lang['fenghao']. '<font color="#0a9409">' . $Lang['needs_shenhe_btn_1']. '</font>'.$sheheBtnStr.'</p>';
        }else if($value['shenhe_status'] == 2 ){
            echo '<p style="line-height:20px;">' . $Lang['needs_shenhe_status'].$Lang['fenghao']. '<font color="#f70404">' . $Lang['needs_shenhe_btn_2']. '</font>'.$sheheBtnStr.'</p>';
        }else if($value['shenhe_status'] == 3 ){
            echo '<p style="line-height:20px;">' . $Lang['needs_shenhe_status'].$Lang['fenghao']. '<font color="#f70404">' . $Lang['needs_shenhe_btn_3']. '</font>'.$sheheBtnStr.'</p>';
        }
        if($value['pay_status'] == 1){
            echo '<p style="line-height:20px;">' . $Lang['pay_status'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['pay_status_1'].'</font><a href="javascript:void(0);" onclick="pay_confirm(\''.$modBaseUrl.'&act=pay_ok&id='.$value['id'].'&formhash='.FORMHASH.'\');">('.$Lang['pay_status_2'].')</a></p>';
        }else if($value['pay_status'] == 2){
            echo '<p style="line-height:20px;">' . $Lang['pay_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['pay_status_2'].'</font></p>';
        }
        if($value['status'] == 1 ){
            echo '<p style="line-height:20px;">' . $Lang['needs_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['needs_status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['needs_status_2']. ')</font></a></p>';
        }else{
            echo '<p style="line-height:20px;">' . $Lang['needs_status'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['needs_status_2'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['needs_status_1']. ')</font></a></p>';
        }
        echo '</ul></div></td>';
        echo '<td>' . dgmdate($value['refresh_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['needs_edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=refresh&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['refresh']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edittop&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_top_title']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        if($value['expire_status'] == 2 || $value['expire_status'] == 1){
            echo '<a href="'.$modBaseUrl.'&act=editexpire&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_expire_title']. '</a><br/>';
        }
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function pay_confirm(url){
  var r = confirm("{$Lang['makesure_pay_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
    $formstr = <<<EOF
        <tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="batch_refresh">{$Lang['batch_refresh']}</option>
                    <option value="batch_shenhe1">{$Lang['batch_shenhe1']}</option>
                    <option value="batch_shenhe3">{$Lang['batch_shenhe3']}</option>
                    <option value="batch_del">{$Lang['batch_del']}</option>
                    <option value="batch_show">{$Lang['batch_show']}</option>
                    <option value="batch_hide">{$Lang['batch_hide']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>
        <script type="text/javascript">
        function batch_do(){
          var r = confirm("{$Lang['batch_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        </script>
EOF;
    echo $formstr;
    showformfooter(); /*Dism_taobao-com*/
}

$jsstr = <<<EOF
<script type="text/javascript">
function getCity(){
  var site_id = jq("#site_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcfangchan:ajax",
        data: "act=admin_area&site="+site_id,
        dataType : "json",
        success: function(json){
            var areaHtml = '<option value="0">{$Lang['all']}</option>';
            jq.each(json,function(k,v){
                areaHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#area_id").html(areaHtml);
            jq("#area_id").show();
        }
    });
}
function getStreet(){
  var area_id = jq("#area_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcfangchan:ajax",
        data: "act=admin_street&area_id="+area_id,
        dataType : "json",
        success: function(json){
            var streetHtml = '<option value="0">{$Lang['all']}</option>';
            jq.each(json,function(k,v){
                streetHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            console.log(streetHtml);
            jq("#street_id").html(streetHtml);
            jq("#street_id").show();
        }
    });
}
</script>
EOF;
echo $jsstr;

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):1;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $xm                 = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $wx                 = isset($_GET['wx'])? addslashes($_GET['wx']):'';
    $city_id            = isset($_GET['city_id'])? intval($_GET['city_id']):0;
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $paixu              = isset($_GET['paixu'])? intval($_GET['paixu']):1000;
    
    $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    
    $data['site_id']            = $site_id;
    $data['user_id']            = $user_id;
    $data['type']               = $type;
    $data['content']            = $content;
    $data['xm']                 = $xm;
    $data['tel']                = $tel;
    $data['wx']                 = $wx;
    $data['area_id']            = $area_id;
    $data['street_id']          = $street_id;
    $data['address']            = $address;
    $data['address']            = $address;
    $data['longitude']          = $longitude;
    $data['latitude']           = $latitude;
    $data['admin_edit']         = $admin_edit;
    $data['paixu']              = $paixu;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$tongchengConfig,$tcfangchanConfig;
    $options = array(
        'site_id'           => 0,
        'user_id'           => '',
        'type'              => 1,
        'content'           => '',
        'xm'                => '',
        'tel'               => '',
        'wx'                => '',
        'city_id'           => 0,
        'area_id'           => 0,
        'street_id'         => 0,
        'address'           => '',
        'longitude'         => '',
        'latitude'          => '',
        'admin_edit'        => 0,
        'paixu'             => 1000,
    );
    $options = array_merge($options, $infoArr);
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($options['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($options['site_id']);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
        }
    }else if($options['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id" onChange="getCity();">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_title'].'</option>';
    if(1 == $options['site_id']){
        $sitesStr.=  '<option value="1" selected>'.$Lang['sites_one'].'</option>';
    }else{
        $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    }
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    
    tomshowsetting(true,array('title'=>$Lang['needs_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['needs_user_id_msg']),"input");
    $type_item = array(1=>$Lang['qiugou'],2=>$Lang['qiuzu']);
    tomshowsetting(true,array('title'=>$Lang['needs_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['needs_type_msg'],'item'=>$type_item),"radio");
    
    $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
    $areaStr.= '<tr><td width="100" ><b>'.$Lang['needs_search_diqu'].'</b></td></tr>';
    $areaStr.= '<tr><td ><select style="width: 130px;" name="area_id" id="area_id" onChange="getStreet();">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($areaList as $key => $value){
        if($options['area_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select>';

    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($options['area_id']);
    $areaStr.= '<select style="width: 130px;" name="street_id" id="street_id">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($streetList as $key => $value){
        if($options['street_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select><input type="hidden" name="city_id" value="'.$__CityInfo['id'].'"></td><td>'.$Lang['goods_diqu_msg'].'</td></tr>';
    echo $areaStr;
    tomshowsetting(true,array('title'=>$Lang['needs_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['needs_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['needs_latitude'],'name'=>'latitude','value'=>$options['latitude'],'msg'=>$Lang['needs_latitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['needs_longitude'],'name'=>'longitude','value'=>$options['longitude'],'msg'=>$Lang['needs_longitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['needs_xm'],'name'=>'xm','value'=>$options['xm'],'msg'=>$Lang['needs_xm_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['needs_tel'],'name'=>'tel','value'=>$options['tel'],'msg'=>$Lang['needs_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['needs_wx'],'name'=>'wx','value'=>$options['wx'],'msg'=>$Lang['needs_wx_msg']),"input");
    $admin_edit_item = array(0=>$Lang['needs_admin_edit_0'],1=>$Lang['needs_admin_edit_1']);
    //tomshowsetting(true,array('title'=>$Lang['needs_admin_edit'],'name'=>'admin_edit','value'=>$options['admin_edit'],'msg'=>$Lang['needs_admin_edit_msg'],'item'=>$admin_edit_item),"radio");
    //tomshowsetting(true,array('title'=>$Lang['needs_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['needs_paixu_msg']),"input");
    //tomshowsetting(true,array('title'=>$Lang['needs_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['needs_content_msg']),"text");
    tomshowsetting(true,array('title'=>$Lang['needs_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['needs_content_msg']),"textarea");
        
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['needs_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['needs_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['needs_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['needs_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['needs_edit'],"",true);
    }else{
        tomshownavli($Lang['needs_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['needs_add'],$modBaseUrl."&act=add",false);
        //tomshownavli($Lang['doDao_title_2'],$adminBaseUrl.'&tmod=doDaoNeeds',false);
    }
    tomshownavfooter();
}