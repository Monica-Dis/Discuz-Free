<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$mendian_id = isset($_GET['mendian_id'])? intval($_GET['mendian_id']):0;

$modBaseUrl = $adminBaseUrl.'&tmod=agent&mendian_id='.$mendian_id;
$modListUrl = $adminListUrl.'&tmod=agent&mendian_id='.$mendian_id;
$modFromUrl = $adminFromUrl.'&tmod=agent&mendian_id='.$mendian_id;

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['is_ok']            = 1;
        $insertData['shenhe_status']    = 1;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_agent')->insert($insertData);
        if($insertData['mendian_id'] > 0){
            update_mendian_xinxi($insertData['mendian_id']);
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($agentInfo);
        $updateData['is_ok'] = 1;
        C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($agentInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($agentInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status']     = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($_GET['id'],$updateData);

    $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($agentInfo['user_id']);

    $shenhe = str_replace('{TITLE}', $agentInfo['name'], $Lang['agent_template_shenhe_ok']);
    $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$agentInfo['site_id'].'&mod=agentinfo&agent_id='.$agentInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$agentInfo['site_id']}&mod=agentinfo&agent_id=".$agentInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcfangchanConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['shenhe_tz_fail'];
        }
    }
    
    if($agentInfo['mendian_id'] > 0){
        update_mendian_xinxi($agentInfo['mendian_id']);
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'editvip'){
    
    $info = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($_GET['agent_id']);
    if(submitcheck('submit')){
        $vip_id         = intval($_GET['vip_id'])>0 ? intval($_GET['vip_id']):0;
        $expire_time    = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
        $expire_time    = strtotime($expire_time);
        $updateData = array();
        if($expire_time > TIMESTAMP){
            $updateData['vip_id']          = $vip_id;
            $updateData['expire_status']   = 1;
            $updateData['expire_time']     = $expire_time;
            $updateData['vip_add_time']    = TIMESTAMP;
        }else{
            $updateData['expire_status']   = 0;
            $updateData['expire_time']     = $expire_time;
        }
        C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($_GET['agent_id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editvip&agent_id='.$_GET['agent_id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['agent_edit_vip'] .'</th></tr>';
        
        $vipList = C::t('#tom_tcfangchan#tom_tcfangchan_agent_vip')->fetch_all_list(" AND status=1 "," ORDER BY vsort ASC,id DESC ",0,100);
        $vipStr = '<tr class="header"><th>'.$Lang['agentvip_name'].'</th><th></th></tr>';
        $vipStr.= '<tr><td width="300"><select style="width: 260px;" name="vip_id" id="vip_id">';
        foreach ($vipList as $key => $value){
            if($value['id'] == $info['vip_id']){
                $vipStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $vipStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $vipStr.= '</select></td><td></td></tr>';
        echo $vipStr;
        tomshowsetting(true,array('title'=>$Lang['edit_vip_time'],'name'=>'expire_time','value'=>$info['expire_time'],'msg'=>$Lang['edit_vip_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'edittop'){
    
    $info = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($_GET['agent_id']);
    if(submitcheck('submit')){
        $top_time     = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
        $top_time     = strtotime($top_time);
        $updateData = array();
        if($top_time < TIMESTAMP){
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
        }else{
            $updateData['top_status']   = 1;
            $updateData['top_time']     = $top_time;
        }
        C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($_GET['agent_id'],$updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edittop&agent_id='.$_GET['agent_id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['top_edit'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['top_time'],'name'=>'top_time','value'=>$info['top_time'],'msg'=>''),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($_GET['id']);
    C::t('#tom_tcfangchan#tom_tcfangchan_agent')->delete_by_id($_GET['id']);
    
    DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET source_type=2 WHERE user_id = {$agentInfo['user_id']} ", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET expire_status=2,status=0 WHERE user_id = {$agentInfo['user_id']} AND expire_status=3 ", 'UNBUFFERED');
    
    $tcfangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_id_list(" AND user_id = {$agentInfo['user_id']} AND expire_status=2 ");
    if(is_array($tcfangchanListTmp) && !empty($tcfangchanListTmp)){
        foreach($tcfangchanListTmp as $key => $value){
            update_fangchan_tongcheng($value['id']);
        }
    }
    
    update_mendian_xinxi($agentInfo['mendian_id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $name       = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tel        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $site_id    = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $agent_id   = isset($_GET['agent_id'])? intval($_GET['agent_id']):0;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($name)){
        $name = str_replace(array('%', '_'),'',$name);
        $where .= " AND name LIKE '%{$name}%' ";
    }
    if(!empty($tel)){
        $tel = str_replace(array('%', '_'),'',$tel);
        $where .= " AND tel LIKE '%{$tel}%' ";
    }
    if($mendian_id > 0){
        $where .= " AND mendian_id={$mendian_id} ";
    }
    if($site_id > 0){
        $where .= " AND site_id={$site_id} ";
    }
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_count($where);
    $agentList = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_agent_list($where," ORDER BY id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&mendian_id={$mendian_id}";
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['agent_help_0'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['agent_name'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="name" value="'.$name.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['agent_tel'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="tel" value="'.$tel.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['mendian_id'].'</b></td><td ><input style="width: 260px;" type="number" name="mendian_id" value="'.$mendian_id.'"></td></tr>';
    
    $site_select_1 = '';
    if($site_id == 1){
        $site_select_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_select_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['user_id'] . '</th>';
    echo '<th>' . $Lang['agent_name'] . '</th>';
    echo '<th>' . $Lang['agent_avatar'] . '</th>';
    echo '<th>' . $Lang['agent_mendian'] . '</th>';
    echo '<th>' . $Lang['agent_tel'] . '</th>';
    echo '<th>' . $Lang['agent_wx_qrcode'] . '</th>';
    echo '<th>' . $Lang['agent_vip'] . '</th>';
    echo '<th>' . $Lang['agent_vip_status'] . '</th>';
    echo '<th>' . $Lang['top_time'] . '</th>';
    echo '<th>' . $Lang['agent_is_ok'] . '</th>';
    echo '<th>' . $Lang['shenhe_status'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($agentList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($value['mendian_id']);
        $vipInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent_vip')->fetch_by_id($value['vip_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $userInfo['nickname'] .'<font color="#f70404">(ID:'.$value['user_id']. ')</font></td>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td><a href="'.tomgetfileurl($value['avatar']).'" target="_blank"><img src="'.tomgetfileurl($value['avatar']).'" width="40" /></a></td>';
        echo '<td>' . $mendianInfo['name'] . '<font color="#f70404">(ID:'.$value['mendian_id']. ')</font></td>';
        echo '<td>' . $value['tel'] . '</td>';
        echo '<td><a href="'.tomgetfileurl($value['wx_qrcode']).'" target="_blank"><img src="'.tomgetfileurl($value['wx_qrcode']).'" width="40" /></a></td>';
        
        if($value['vip_id'] > 0){
            echo '<td>' . $vipInfo['name'] .'<font color="#f70404">(ID:'.$value['vip_id']. ')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if($value['expire_status'] == 1 && $value['expire_time'] > TIMESTAMP){
            echo '<td><font color="#0a9409">'.$Lang['expire_status_1'].'</font><font color="#f70404">('.dgmdate($value['expire_time'], 'Y-m-d H:i:s',$tomSysOffset).')</font></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['expire_status_2'].'</font></td>';
        }
        if($value['top_status'] == 1 && $value['top_time'] > TIMESTAMP){
            echo '<td><font color="#0a9409">'.$Lang['top_status_1'].'</font><font color="#f70404">('.dgmdate($value['top_time'], 'Y-m-d H:i:s',$tomSysOffset).')</font></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['top_status_0'].'</font></td>';
        }
        if($value['is_ok'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['agent_is_ok_1']. '</font></td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['agent_is_ok_0']. '</font></td>';
        }
        
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_status_1']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['shenhe_status_1']. '</font></td>';
        }else if($value['shenhe_status'] == 2 ){
            echo '<td><font color="#f70404">' . $Lang['shenhe_status_2']. '</font>'.$sheheBtnStr.'</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        
        echo '<td style="line-height: 25px;">';
        if($tcfangchanConfig['open_agent_vip'] == 1){
            echo '<a href="'.$modBaseUrl.'&act=editvip&agent_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['agent_edit_vip']. '</a><br/>';
        }
        echo '<a href="'.$modBaseUrl.'&act=edittop&agent_id='.$value['id'].'">' . $Lang['top_edit']. '</a>&nbsp;|&nbsp;';
        //echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a><br/>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    global $tongchengConfig;
    $data = array();
    
    $mendian_id = isset($_GET['mendian_id'])? intval($_GET['mendian_id']):0;
    $user_id    = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name       = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tel        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($mendian_id);
    
    $avatar = $wx_qrcode = "";
    if($_GET['act'] == 'add'){
        $avatar     = tomuploadFile("avatar");
        $wx_qrcode  = tomuploadFile("wx_qrcode");
    }else if($_GET['act'] == 'edit'){
        $avatar     = tomuploadFile("avatar",$infoArr['avatar']);
        $wx_qrcode  = tomuploadFile("wx_qrcode",$infoArr['wx_qrcode']);
    }
    
    $data['site_id']            = $mendianInfo['site_id'];
    $data['mendian_id']         = $mendian_id;
    $data['user_id']            = $user_id;
    $data['name']               = $name;
    $data['avatar']             = $avatar;
    $data['tel']                = $tel;
    $data['wx_qrcode']          = $wx_qrcode;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$mendian_id;
    $options = array(
        'mendian_id'    => 0,
        'user_id'       => 0,
        'name'          => '',
        'avatar'        => '',
        'tel'           => '',
        'wx_qrcode'     => '',
    );
    
    if($_GET['act'] == 'add' && $mendian_id > 0){
        $options['mendian_id'] = $mendian_id;
    }
    
    $options = array_merge($options, $infoArr);
    tomshowsetting(true,array('title'=>$Lang['mendian_id'],'name'=>'mendian_id','value'=>$options['mendian_id'],'msg'=>''),"input");
    tomshowsetting(true,array('title'=>$Lang['user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['agent_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['agent_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['agent_avatar'],'name'=>'avatar','value'=>$options['avatar'],'msg'=>$Lang['agent_avatar_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['agent_tel'],'name'=>'tel','value'=>$options['tel'],'msg'=>$Lang['agent_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['agent_wx_qrcode'],'name'=>'wx_qrcode','value'=>$options['wx_qrcode'],'msg'=>$Lang['agent_wx_qrcode_msg']),"file");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['agent_list_title'],$modBaseUrl,false);
        //tomshownavli($Lang['agent_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['agent_list_title'],$modBaseUrl,false);
        //tomshownavli($Lang['agent_add'],$modBaseUrl."&act=add",false);
        //tomshownavli($Lang['agent_edit'],"",true);
    }else{
        tomshownavli($Lang['agent_list_title'],$modBaseUrl,true);
        //tomshownavli($Lang['agent_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}