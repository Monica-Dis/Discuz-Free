<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=doDaoNeeds';
$modListUrl = $adminListUrl.'&tmod=doDaoNeeds';
$modFromUrl = $adminFromUrl.'&tmod=doDaoNeeds';

$day_type       = isset($_GET['day_type'])? intval($_GET['day_type']):1;
$days           = isset($_GET['days'])? intval($_GET['days']):0;
$type           = isset($_GET['type'])? intval($_GET['type']):1;
$dao_tel        = isset($_GET['dao_tel'])? intval($_GET['dao_tel']):0;
$dao_type       = isset($_GET['dao_type'])? intval($_GET['dao_type']):2;

$site_ids = '';
$site_ids_url = '';
if(is_array($_GET['site_ids']) && !empty($_GET['site_ids'])){
    $site_ids = implode(',', $_GET['site_ids']);
    $site_ids_url = implode('_', $_GET['site_ids']);
}

tomloadcalendarjs();
showformheader($modFromUrl.'&submit_do=1&formhash='.FORMHASH);
showtableheader();
echo '<tr><th colspan="15" class="partition">' . $Lang['doDao_site_title'] .'</th></tr>';

$siteList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY add_time ASC,id DESC ",0,1000);
$sitesStr   = '<tr class="header"><th>'.$Lang['doDao_site'].'</th><th></th></tr>';
$sitesStr.= '<tr><td width="800" style="line-height: 30px;">';
if(in_array(1, $_GET['site_ids'])){
    $sitesStr.=  '<label><input name="site_ids[]" type="checkbox" value="1" checked />'.$tongchengConfig['plugin_name'].'</label>';
}else if(!empty($_GET['site_ids'])){    
    $sitesStr.=  '<label><input name="site_ids[]" type="checkbox" value="1" />'.$tongchengConfig['plugin_name'].'</label>';
}else{
    $sitesStr.=  '<label><input name="site_ids[]" type="checkbox" value="1" checked />'.$tongchengConfig['plugin_name'].'</label>';
}
foreach ($siteList as $key => $value){
    if(in_array($value['id'], $_GET['site_ids'])){
        $sitesStr.=  '<label><input name="site_ids[]" type="checkbox" value="'.$value['id'].'" checked />'.$value['name'].'</label>&nbsp;&nbsp;';
    }else if(!empty($_GET['site_ids'])){
        $sitesStr.=  '<label><input name="site_ids[]" type="checkbox" value="'.$value['id'].'" />'.$value['name'].'</label>';
    }else{
        $sitesStr.=  '<label><input name="site_ids[]" type="checkbox" value="'.$value['id'].'" checked />'.$value['name'].'</label>';
    }
}
$sitesStr.= '</td><td></td></tr>';
echo $sitesStr;

$type_1 = $type_2 = '';
if($type == 1){ $type_1 = 'checked';}
if($type == 2){ $type_2 = 'checked';}
$typeStr = '<tr class="header"><th>'.$Lang['doDao_day_type'].'</th><th></th></tr>';
$typeStr.= '<tr><td width="300"><label><input type="radio" name="type" value="1" '.$type_1.'>'.$Lang['qiugou'].'<label>&nbsp;&nbsp;&nbsp;';
$typeStr.=  '<label><input type="radio" name="type" value="2" '.$type_2.'>'.$Lang['qiuzu'].'<label>';
$typeStr.= '</td><td></td></tr>';
echo $typeStr;

$day_type_1 = $day_type_2 = '';
if($day_type == 1){ $day_type_1 = 'checked';}
if($day_type == 2){ $day_type_2 = 'checked';}
$day_typeStr = '<tr class="header"><th>'.$Lang['doDao_day_type'].'</th><th></th></tr>';
$day_typeStr.= '<tr><td width="300"><label><input type="radio" name="day_type" value="1" '.$day_type_1.'>'.$Lang['doDao_day_type_1'].'<label>&nbsp;&nbsp;&nbsp;';
$day_typeStr.=  '<label><input type="radio" name="day_type" value="2" '.$day_type_2.'>'.$Lang['doDao_day_type_2'].'<label>';
$day_typeStr.= '</td><td></td></tr>';
echo $day_typeStr;

$daysStr = '<tr class="header"><th>'.$Lang['doDao_days'].'</th><th></th></tr>';
$daysStr.= '<tr><td width="300"><select style="width: 260px;" name="days" id="days">';
$daysStr.=  '<option value="0">'.$Lang['doDao_days_0'].'</option>';
for($i = 1; $i<= 30 ;$i++){
    if($i == $days){
        $daysStr.=  '<option value="'.$i.'" selected>'.$i.''.$Lang['doDao_days_msg'].'</option>';
    }else{
        $daysStr.=  '<option value="'.$i.'">'.$i.''.$Lang['doDao_days_msg'].'</option>';
    }
}
$daysStr.= '</select></td><td></td></tr>';
echo $daysStr;

$dao_tel_0 = $dao_tel_1 = '';
if($dao_tel == 0){ $dao_tel_0 = 'checked';}
if($dao_tel == 1){ $dao_tel_1 = 'checked';}
$sourceTypeStr = '<tr class="header"><th>'.$Lang['doDao_dao_tel'].'</th><th></th></tr>';
$sourceTypeStr.= '<tr><td width="300">';
$sourceTypeStr.=  '<label><input type="radio" name="dao_tel" value="0" '.$dao_tel_0.'>'.$Lang['doDao_dao_tel_0'].'<label>';
$sourceTypeStr.=  '<label><input type="radio" name="dao_tel" value="1" '.$dao_tel_1.'>'.$Lang['doDao_dao_tel_1'].'<label>';
$sourceTypeStr.= '</td><td></td></tr>';
echo $sourceTypeStr;

$dao_type_1 = $dao_type_2 = '';
if($dao_type == 1){ $dao_type_1 = 'checked';}
if($dao_type == 2){ $dao_type_2 = 'checked';}
$sourceTypeStr = '<tr class="header"><th>'.$Lang['doDao_dao_type'].'</th><th></th></tr>';
$sourceTypeStr.= '<tr><td width="300">';
$sourceTypeStr.=  '<label><input type="radio" name="dao_type" value="2" '.$dao_type_2.'>'.$Lang['doDao_dao_type_2'].'<label>';
$sourceTypeStr.=  '<label><input type="radio" name="dao_type" value="1" '.$dao_type_1.'>'.$Lang['doDao_dao_type_1'].'<label>';
$sourceTypeStr.= '</td><td></td></tr>';
echo $sourceTypeStr;

showsubmit('submit',$Lang['daDao_btn']);

showtablefooter(); /*dism��taobao��com*/
showformfooter(); /*Dism_taobao-com*/

$where = " AND shenhe_status = 1 AND status = 1 AND ((pay_status = 0) OR (pay_status = 2))  AND ((expire_status = 1 AND expire_time > ".TIMESTAMP.") OR expire_status = 3 OR expire_status = 0) ";

if(!empty($site_ids)){
    $where.= " AND site_id IN({$site_ids}) ";
}else{
    $where.= " AND site_id = 0 ";
}
if(!empty($type)){
    $where.= " AND type = {$type} ";
}
if($days > 0){
    $minTime = TIMESTAMP - $days * 86400;
    if($day_type == 1){
        $where.= " AND refresh_time > {$minTime} ";
    }else{
        $where.= " AND add_time > {$minTime} ";
    }
}

$count = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_count($where);

$doDaoUrl = $_G['siteurl']."plugin.php?id=tom_tcfangchan:doDaoNeeds&site_ids={$site_ids_url}&type={$type}&day_type={$day_type}&days={$days}&dao_tel={$dao_tel}&dao_type={$dao_type}";

if($_GET['submit_do'] == 1){
    if($count > 0){
        showtableheader();
        echo '<tr>';
        echo '<td><a href="'.$doDaoUrl.'" target="_blank" style="color: #FA6A03; padding:2px 7px; font-weight:600; margin-left: 10px; border-radius: 5px; border: 1px solid #FA6A03;">'.$Lang['daDao_url'].'</a></td>';
        echo '</tr>';
        showtablefooter(); /*dism��taobao��com*/
        if($dao_type == 2){
            echo '<br/><b><font color="#0894fb">'.$Lang['daDao_chu_msg'].'</font></b>';
        }
    }else{
        echo '<br/><b><font color="#fd0d0d">'.$Lang['daDao_no_msg'].'</font></b>';
    }
}