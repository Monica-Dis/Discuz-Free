<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=newhouses';
$modListUrl = $adminListUrl.'&tmod=newhouses';
$modFromUrl = $adminFromUrl.'&tmod=newhouses';

if($_GET['act'] == 'info'){
    
    $info = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_by_id($_GET['id']);
    $photoList = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND newhouses_id = {$info['id']} ", 'ORDER BY psort ASC,id ASC', 0, 100);
    if($info['site_id'] > 1){
        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($info['site_id']);
        $sitename = $sitesInfo['name'];
    }else{
        $sitename = $Lang['sites_one'];
    }
    
    $typeArr = explode('|', trim($info['type'], '|'));
    $typeStr = '';
    if(is_array($houseTypeArr) && !empty($houseTypeArr)){
        foreach($houseTypeArr as $key => $value){
            if(in_array($key,$typeArr)){
                $typeStr .= $houseTypeArr[$key].' ';
            }
        }
    }
    
    $teseArr = explode('|', trim($info['tese_tags'], '|'));
    $teseTagsStr = '';
    if(is_array($teseArr) && !empty($teseArr)){
        $teseTagsStr = implode(' ', $teseArr);
    }
    
    $fenghao = $Lang['fenghao'];
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['info'] . '</th></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_name'].$fenghao.'</b></td><td>'.$info['name'].'</td></tr>';
    
    if($info['sell_status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['newhouses_sell_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['newhouses_sell_status_1'].'</font></td></tr>';
    }else if($info['sell_status'] == 2){
        echo '<tr><td align="right"><b>'.$Lang['newhouses_sell_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['newhouses_sell_status_2'].'</font></td></tr>';
    }else if($info['sell_status'] == 3){
        echo '<tr><td align="right"><b>'.$Lang['newhouses_sell_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['newhouses_sell_status_3'].'</font></td></tr>';
    }
    
    if($info['status'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['newhouses_status'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['newhouses_status_1'].'</font></td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['newhouses_status'].$fenghao.'</b></td><td><font color="#f70404">'.$Lang['newhouses_status_0'].'</font></td></tr>';
    }
    echo '<tr><td align="right"><b>'.$Lang['newhouses_start_time'].$fenghao.'</b></td><td>'.dgmdate($info['start_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_jiaofang_time'].$fenghao.'</b></td><td>'.dgmdate($info['jiaofang_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
    
    echo '<tr><td align="right"><b>'.$Lang['sites_title'].$fenghao.'</b></td><td>'.$sitename.'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_type'].$fenghao.'</b></td><td>'.$typeStr.'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_tese_tags'].$fenghao.'</b></td><td>'.$teseTagsStr.'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_diqu'].$fenghao.'</b></td><td>'.$info['area_name'].'--'.$info['street_name'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_average_price'].$fenghao.'</b></td><td>'.$info['average_price'].$Lang['newhouses_average_price_unit'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_zhuangxiu_type'].$fenghao.'</b></td><td>'.$zhuangxiuTypeArr[$info['zhuangxiu_type']].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_chanquan'].$fenghao.'</b></td><td>'.$info['chanquan'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_address'].$fenghao.'</b></td><td>'.$info['address'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_sales_address'].$fenghao.'</b></td><td>'.$info['sales_address'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_developer_company'].$fenghao.'</b></td><td>'.$info['developer_company'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_parking_space'].$fenghao.'</b></td><td>'.$info['parking_space'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_plot_ratio'].$fenghao.'</b></td><td>'.$info['plot_ratio'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_greening_rate'].$fenghao.'</b></td><td>'.$info['greening_rate'].'%</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_households_num'].$fenghao.'</b></td><td>'.$info['households_num'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_land_mianji'].$fenghao.'</b></td><td>'.$info['land_mianji'].$Lang['pingmi'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_house_mianji'].$fenghao.'</b></td><td>'.$info['house_mianji'].$Lang['pingmi'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_house_total_mianji'].$fenghao.'</b></td><td>'.$info['house_total_mianji'].$Lang['pingmi'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_huode_ratio'].$fenghao.'</b></td><td>'.$info['huode_ratio'].'%</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_property_company'].$fenghao.'</b></td><td>'.$info['property_company'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_property_price'].$fenghao.'</b></td><td>'.$info['property_price'].$Lang['newhouses_property_price_unit'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_property_tel'].$fenghao.'</b></td><td>'.$info['property_tel'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_vr_link'].$fenghao.'</b></td><td width="50%"><a href="'.$info['vr_link'].'" target="_blank">'.$info['vr_link'].'</a></td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['newhouses_content'].$fenghao.'</b></td><td width="50%">'.$info['content'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['update_time'].$fenghao.'</b></td><td>'.dgmdate($info['update_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['add_time'].$fenghao.'</b></td><td>'.dgmdate($info['add_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
    
    echo '<tr><td align="right"><b>'.$Lang['houses_photo'].$fenghao.'</b></td><td>';
    if(is_array($photoList) && !empty($photoList)){
        foreach($photoList as $key => $value){
            echo '<a style="margin-right:10px;" href="' . $value['picurlTmp'] . '" target="_blank"><img height="60" src="' . $value['picurlTmp'] . '"></a>';
        }
    }
    echo '</td></tr>';
    
    showtablefooter(); /*dism��taobao��com*/
    
}else if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $returnData = __get_post_data();
        
        $insertData = array();
        $insertData = $returnData['data'];
        $insertData['update_time']  = TIMESTAMP;
        $insertData['add_time']     = TIMESTAMP;
        if(C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->insert($insertData)){
            
            $newhouses_id = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->insert_id();
            
            if(is_array($returnData['configTagList']) && !empty($returnData['configTagList'])){
                foreach($returnData['configTagList'] as $key => $value){
                    $insertData = array();
                    $insertData['newhouses_id']     = $newhouses_id;
                    $insertData['config_tag_id']    = $value['id'];
                    $insertData['config_tag_ids']   = $returnData['attrTeseTagsIdsStr'];
                    $insertData['name']             = $value['name'];
                    $insertData['add_time']         = TIMESTAMP;
                    C::t("#tom_tcfangchan#tom_tcfangchan_tag")->insert($insertData);
                }
            }
            
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $newhousesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $returnData = __get_post_data($newhousesInfo);
        
        $updateData = array();
        $updateData = $returnData['data'];
        $updateData['update_time']  = TIMESTAMP;
        if(C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->update($newhousesInfo['id'],$updateData)){
            
            DB::query("UPDATE ".DB::table('tom_tcfangchan_newhouses_adviser')." SET newhouses_name='{$updateData['name']}' WHERE newhouses_id = {$newhousesInfo['id']} ", 'UNBUFFERED');
            
            C::t("#tom_tcfangchan#tom_tcfangchan_tag")->delete_by_newhouses_id($newhousesInfo['id']);
            
            if(is_array($returnData['configTagList']) && !empty($returnData['configTagList'])){
                foreach($returnData['configTagList'] as $key => $value){
                    $insertData = array();
                    $insertData['newhouses_id']     = $newhousesInfo['id'];
                    $insertData['config_tag_id']    = $value['id'];
                    $insertData['config_tag_ids']   = $returnData['attrTeseTagsIdsStr'];
                    $insertData['name']             = $value['name'];
                    $insertData['add_time']         = TIMESTAMP;
                    C::t("#tom_tcfangchan#tom_tcfangchan_tag")->insert($insertData);
                }
            }
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($newhousesInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status']       = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->update($_GET['id'], $updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status']       = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->update($_GET['id'], $updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'edittop'){
    $info = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $top_time     = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
        $top_time     = strtotime($top_time);
        $updateData = array();
        if($top_time < TIMESTAMP){
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
        }else{
            $updateData['top_status']   = 1;
            $updateData['top_time']     = $top_time;
        }
        C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->update($_GET['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edittop&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['top_edit'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['top_time'],'name'=>'top_time','value'=>$info['top_time'],'msg'=>''),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->delete_by_id($_GET['id']);
    C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_newhousesall_id($_GET['id']);
    C::t("#tom_tcfangchan#tom_tcfangchan_tag")->delete_by_newhouses_id($_GET['id']);
    C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->delete_by_newhouses_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'addphoto'){
    if(submitcheck('submit')){
        
        $id             = isset($_GET['id'])? intval($_GET['id']):0;
        $type           = isset($_GET['type'])? intval($_GET['type']):1;
        $house_huxing   = isset($_GET['house_huxing'])? addslashes($_GET['house_huxing']):'';
        $house_mianji   = isset($_GET['house_mianji'])? floatval($_GET['house_mianji']):0.00;
        $psort          = isset($_GET['psort'])? intval($_GET['psort']):10;
        $picurl         = tomuploadFile("picurl");
        
        $insertData = array();
        $insertData['newhouses_id'] = $id;
        $insertData['picurl']       = $picurl;
        $insertData['type']         = $type;
        if($type == 3){
            $insertData['house_huxing']         = $house_huxing;
            $insertData['house_mianji']         = $house_mianji;
        }
        $insertData['psort']        = $psort;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_photo')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl.'&act=photo&id='.$id, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        tomshownavheader();
        tomshownavli($Lang['houses_photo_add'],'',true);
        tomshownavfooter();
        showformheader($modFromUrl.'&act=addphoto&id='.$_GET['id'],'enctype');
        showtableheader();
        
        tomshowsetting(true,array('title'=>$Lang['houses_photo'],'name'=>'picurl','value'=>'','msg'=>$Lang['houses_photo_msg']),"file");
        $type_item = array(1=>$Lang['newhouses_photo_type_1'],2=>$Lang['newhouses_photo_type_2'],3=>$Lang['newhouses_photo_type_3']);
        tomshowsetting(true,array('title'=>$Lang['newhouses_photo_type'],'name'=>'type','value'=>1,'msg'=>$Lang['newhouses_photo_type_msg'],'item'=>$type_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['newhouses_house_huxing'],'name'=>'house_huxing','value'=>'','msg'=>$Lang['newhouses_house_huxing_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['newhouses_house_mianji'],'name'=>'house_mianji','value'=>'','msg'=>$Lang['newhouses_house_mianji_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'psort','value'=>10,'msg'=>$Lang['sort_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl.'&act=photo&id='.$_GET['newhouses_id'], 'succeed');
    
}else if($_GET['act'] == 'photo'){
    
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $id         = intval($_GET['id'])>0? intval($_GET['id']):0;
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $newhousesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_by_id($id);
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_count(" AND newhouses_id = {$id} ");
    $photoList = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND newhouses_id = {$id} "," ORDER BY psort ASC,id ASC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&act=photo&site_id={$site_id}";
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' .$newhousesInfo['name'].'&gt;'. $Lang['houses_photo'] . '</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    tomshownavheader();
    tomshownavli($Lang['houses_photo_add'],$modBaseUrl."&act=addphoto&id=".$id,false);
    tomshownavfooter();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['houses_photo'] . '</th>';
    echo '<th>' . $Lang['newhouses_photo_type'] . '</th>';
    echo '<th>' . $Lang['newhouses_house_huxing'] . '</th>';
    echo '<th>' . $Lang['newhouses_house_mianji'] . '</th>';
    echo '<th>' . $Lang['sort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($photoList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a href="' . $value['picurlTmp'] . '" target="_blank"><img height="40" src="' . $value['picurlTmp'] . '"></a></td>';
        if($value['type'] == 1){
            echo '<td>' . $Lang['newhouses_photo_type_1'] . '</td>';
        }else if($value['type'] == 2){
            echo '<td>' . $Lang['newhouses_photo_type_2'] . '</td>';
        }else if($value['type'] == 3){
            echo '<td>' . $Lang['newhouses_photo_type_3'] . '</td>';
        }
        if(!empty($value['house_huxing'])){
            echo '<td>' . $value['house_huxing'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        if(!empty($value['house_mianji'])){
            echo '<td>' . $value['house_mianji'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $value['psort'] . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&newhouses_id='.$id.'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}else if($_GET['act'] == 'guanzulist'){
    
    $newhouses_id   = intval($_GET['newhouses_id'])>0? intval($_GET['newhouses_id']):0;
    $type           = intval($_GET['type'])>0? intval($_GET['type']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($newhouses_id);
    
    $where = " AND newhouses_id = {$newhouses_id} ";
    if($type > 0){
        $where .= " AND type = {$type} ";
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_guanzu')->fetch_all_count($where);
    $guanzuList = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_guanzu')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);

    $modBasePageUrl = $modBaseUrl."&act=guanzulist&newhouses_id={$newhouses_id}&type={$type}";
    
    tomshownavheader();
    if($type > 0){
        if($type == 1){
            tomshownavli($Lang['doDao_title_type_1'],$adminBaseUrl."&tmod=doDaoNewhousesGuanzu&newhouses_id={$newhouses_id}&type=1",false);
        }else if($type == 2){
            tomshownavli($Lang['doDao_title_type_2'],$adminBaseUrl."&tmod=doDaoNewhousesGuanzu&newhouses_id={$newhouses_id}&type=2",false);
        }else if($type == 3){
            tomshownavli($Lang['doDao_title_type_3'],$adminBaseUrl."&tmod=doDaoNewhousesGuanzu&newhouses_id={$newhouses_id}&type=3",false);
        }
    }
    tomshownavfooter();
    
    showtableheader();
    if($type > 0){
        if($type == 1){
            echo '<tr><th colspan="15" class="partition">' . $newhousesInfo['name'] .'&nbsp;&nbsp;&gt;&gt;&gt;&nbsp;&nbsp;'.$Lang['newhouses_guanzu_title']. '</th></tr>';
        }else if($type == 2){
            echo '<tr><th colspan="15" class="partition">' . $newhousesInfo['name'] .'&nbsp;&nbsp;&gt;&gt;&gt;&nbsp;&nbsp;'.$Lang['newhouses_bianjia_title']. '</th></tr>';
        }else if($type == 3){
            echo '<tr><th colspan="15" class="partition">' . $newhousesInfo['name'] .'&nbsp;&nbsp;&gt;&gt;&gt;&nbsp;&nbsp;'.$Lang['newhouses_kaipan_title']. '</th></tr>';
        }
    }
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['index_user'] . '</th>';
    echo '<th>' . $Lang['newhouses_guanzu_type'] . '</th>';
    echo '<th>' . $Lang['newhouses_guanzu_tel'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($guanzuList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f70404">(ID:'.$value['user_id']. ')</font></td>';
        if($value['type'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['newhouses_guanzu_type_1'] . '</font></td>';
        }else if($value['type'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['newhouses_guanzu_type_2'] . '</font></td>';
        }else if($value['type'] == 3){
            echo '<td><font color="#0a9409">' . $Lang['newhouses_guanzu_type_3'] . '</font></td>';
        }
        if(!empty($value['tel'])){
            echo '<td>' . $value['tel'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        echo '<td> -- </td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $min_price      = isset($_GET['min_price'])? intval($_GET['min_price']):'';
    $max_price      = isset($_GET['max_price'])? intval($_GET['max_price']):'';
    $area_id        = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id      = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $house_type     = isset($_GET['house_type'])? intval($_GET['house_type']):0;
    $sell_status    = isset($_GET['sell_status'])? intval($_GET['sell_status']):0;
    $top_status     = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if($site_id > 0){
        $where.= " AND site_id={$site_id} ";
    }
    if(intval($min_price) > 0){
        $min_price = intval($min_price);
        $where.= " AND average_price>={$min_price} ";
    }
    if(intval($max_price) > 0){
        $max_price = intval($max_price);
        $where.= " AND average_price<={$max_price} ";
    }
    if($area_id > 0){
        $where.= " AND area_id={$area_id} ";
    }
    if($street_id > 0){
        $where.= " AND street_id={$street_id} ";
    }
    if($house_type > 0){
        $house_type = str_replace(array('%', '_'),'',$house_type);
        $where .= " AND type LIKE '%|{$house_type}|%'";
    }
    if($sell_status > 0){
        $where.= " AND sell_status={$sell_status} ";
    }
    if($top_status > 0){
        if($top_status == 1){
            $where.= " AND top_status = 1 ";
        }else if($top_status == 2){
            $where.= " AND top_status = 0 ";
        }
    }
    if($status > 0){
        if($status == 1){
            $where.= " AND status = 1 ";
        }else if($status == 2){
            $where.= " AND status = 0 ";
        }
    }
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_count($where,$name);
    $newhousesList = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_list($where," ORDER BY site_id ASC,id DESC ",$start,$pagesize,$name);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&sell_status={$sell_status}&top_status={$top_status}&status={$status}&min_price={$min_price}&max_price={$max_price}&house_type={$house_type}&area_id={$area_id}&street_id={$street_id}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
    $site_select_1 = '';
    if($site_id == 1){
        $site_select_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id" onChange="getCity();">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_select_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    echo '<tr><td width="100" align="right"><b>'.$Lang['newhouses_name'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="name" value="'.$name.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['newhouses_price'].'</b></td><td width="100"><input type="text" style="width:124px;" name="min_price" value="'.$min_price.'" placeholder="'.$Lang['newhouses_min_price_msg'].'"><input type="text" style="width:124px;" name="max_price" value="'.$max_price.'" placeholder="'.$Lang['newhouses_max_price_msg'].'"></td></tr>';
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
    $areaStr.= '<tr><td width="100" align="right"><b>'.$Lang['newhouses_search_diqu'].'</b></td>';
    $areaStr.= '<td ><select style="width: 130px;" name="area_id" id="area_id" onChange="getStreet();">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($areaList as $key => $value){
        if($area_id == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select>';
    
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
    $areaStr.= '<select style="width: 130px;" name="street_id" id="street_id">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($streetList as $key => $value){
        if($street_id == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select></td></tr>';
    echo $areaStr;
    
    $houseingTypeStr = '<tr><td width="100" align="right"><b>'.$Lang['newhouses_type'].'</b></td>';
    $houseingTypeStr.= '<td><select style="width: 260px;" name="house_type" id="house_type">';
    $houseingTypeStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach($houseTypeArr as $key => $value){
        if($house_type == $key){
            $houseingTypeStr.=  '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            $houseingTypeStr.=  '<option value="'.$key.'" >'.$value.'</option>';
        }
    }
    $houseingTypeStr.= '</select></td></tr>';
    echo $houseingTypeStr;
    
    $sell_status_1 = $sell_status_2 = $sell_status_3 = '';
    if($sell_status == 1){
        $sell_status_1 = 'selected';
    }else if($sell_status == 2){
        $sell_status_2 = 'selected';
    }else if($sell_status == 3){
        $sell_status_3 = 'selected';
    }
    $sellStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['newhouses_sell_status'].'</b></td>';
    $sellStatusStr.= '<td><select style="width: 260px;" name="sell_status" id="sell_status">';
    $sellStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $sellStatusStr.=  '<option value="1" '.$sell_status_1.'>'.$Lang['newhouses_sell_status_1'].'</option>';
    $sellStatusStr.=  '<option value="2" '.$sell_status_2.'>'.$Lang['newhouses_sell_status_2'].'</option>';
    $sellStatusStr.=  '<option value="3" '.$sell_status_3.'>'.$Lang['newhouses_sell_status_3'].'</option>';
    $sellStatusStr.= '</select></td></tr>';
    echo $sellStatusStr;
    
    $top_status_1 = $top_status_2 = '';
    if($top_status == 1){
        $top_status_1 = 'selected';
    }else if($top_status == 2){
        $top_status_2 = 'selected';
    }
    $topStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['top_status'].'</b></td>';
    $topStatusStr.= '<td><select style="width: 260px;" name="top_status" id="top_status">';
    $topStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $topStatusStr.=  '<option value="1" '.$top_status_1.'>'.$Lang['top_status_1'].'</option>';
    $topStatusStr.=  '<option value="2" '.$top_status_2.'>'.$Lang['top_status_0'].'</option>';
    $topStatusStr.= '</select></td></tr>';
    echo $topStatusStr;
    
    $status_1 = $status_2 = '';
    if($status == 1){
        $status_1 = 'selected';
    }else if($status == 2){
        $status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['index_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['index_status_0'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['newhouses_name'] . '</th>';
    echo '<th>' . $Lang['newhouses_type'] . '</th>';
    echo '<th>' . $Lang['newhouses_average_price'] . '</th>';
    echo '<th>' . $Lang['newhouses_chanquan'] . '</th>';
    echo '<th width="120px;">' . $Lang['newhouses_address'] . '</th>';
    echo '<th>' . $Lang['newhouses_sell_status'] . '</th>';
    echo '<th>' . $Lang['newhouses_status'] . '</th>';
    echo '<th>' . $Lang['top_status'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($newhousesList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $typeArr = explode('|', $value['type']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $value['name'] . '</td>';
        
        if(is_array($typeArr) && !empty($typeArr)){
            echo '<td>';
            foreach($typeArr as $k => $v){
                echo '<div style="line-height:20px; color:#0a9409;">'.$houseTypeArr[$v].'</div>';
            }
            echo '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $value['average_price'] .$Lang['newhouses_average_price_unit']. '</td>';
        echo '<td>' . $value['chanquan'] .$Lang['year']. '</td>';
        echo '<td>' . $value['address'] . '</td>';
        
        if($value['sell_status'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['newhouses_sell_status_1'].'</font></td>';
        }else if($value['sell_status'] == 2){
            echo '<td><font color="#f70404">'.$Lang['newhouses_sell_status_2'].'</font></td>';
        }else if($value['sell_status'] == 3){
            echo '<td><font color="#f70404">'.$Lang['newhouses_sell_status_3'].'</font></td>';
        }
        
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['newhouses_status_1']. '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#f70404">' . $Lang['newhouses_status_0']. '</font></a>)</td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['newhouses_status_0']. '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#0a9409">' . $Lang['newhouses_status_1']. '</font></a>)</td>';
        }
        
        if($value['top_status'] == 1 && $value['top_time'] > TIMESTAMP){
            echo '<td><font color="#0a9409">'.$Lang['top_status_1'].'</font>(<font color="#f70404">'.dgmdate($value['top_time'], 'Y-m-d H:i',$tomSysOffset).'</font>)</td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['top_status_0'].'</font></td>';
        }
        
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=edittop&id='.$value['id'].'">' . $Lang['top_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'" target="_blank">' . $Lang['info']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=photo&id='.$value['id'].'">' . $Lang['houses_photo_title']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=guanzulist&newhouses_id='.$value['id'].'&type=1&formhash='.FORMHASH.'">' . $Lang['newhouses_guanzu_title']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=guanzulist&newhouses_id='.$value['id'].'&type=2&formhash='.FORMHASH.'">' . $Lang['newhouses_bianjia_title']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=guanzulist&newhouses_id='.$value['id'].'&type=3&formhash='.FORMHASH.'">' . $Lang['newhouses_kaipan_title']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        if($tcfangchanConfig['open_newhouses_sale_adviser'] && $value['open_sale_adviser'] == 1){
            echo '<a href="'.$adminBaseUrl.'&tmod=adviser&newhouses_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['newhouses_sale_adviser_title']. '</a><br/>';
        }
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    global $tongchengConfig;
    $data = array();
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $sub_title          = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $sell_status        = isset($_GET['sell_status'])? intval($_GET['sell_status']):0;
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = strtotime($start_time);
    $jiaofang_time      = isset($_GET['jiaofang_time'])? addslashes($_GET['jiaofang_time']):'';
    $jiaofang_time      = strtotime($jiaofang_time);
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $average_price      = isset($_GET['average_price'])? floatval($_GET['average_price']):0.00;
    $zhuangxiu_type     = isset($_GET['zhuangxiu_type'])? intval($_GET['zhuangxiu_type']):0;
    $chanquan           = isset($_GET['chanquan'])? intval($_GET['chanquan']):0;
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $sales_tel          = isset($_GET['sales_tel'])? addslashes($_GET['sales_tel']):'';
    $sales_address      = isset($_GET['sales_address'])? addslashes($_GET['sales_address']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $developer_company  = isset($_GET['developer_company'])? addslashes($_GET['developer_company']):'';
    $parking_space      = isset($_GET['parking_space'])? intval($_GET['parking_space']):0;
    $plot_ratio         = isset($_GET['plot_ratio'])? floatval($_GET['plot_ratio']):0.00;
    $greening_rate      = isset($_GET['greening_rate'])? intval($_GET['greening_rate']):0;
    $households_num     = isset($_GET['households_num'])? intval($_GET['households_num']):0;
    $land_mianji        = isset($_GET['land_mianji'])? intval($_GET['land_mianji']):0;
    $house_mianji       = isset($_GET['house_mianji'])? intval($_GET['house_mianji']):0;
    $house_total_mianji = isset($_GET['house_total_mianji'])? intval($_GET['house_total_mianji']):0;
    $huode_ratio        = isset($_GET['huode_ratio'])? intval($_GET['huode_ratio']):0;
    $huode_ratio        = isset($_GET['huode_ratio'])? intval($_GET['huode_ratio']):0;
    $property_company   = isset($_GET['property_company'])? addslashes($_GET['property_company']):'';
    $property_price     = isset($_GET['property_price'])? floatval($_GET['property_price']):0.00;
    $property_tel       = isset($_GET['property_tel'])? addslashes($_GET['property_tel']):'';
    $vr_link            = isset($_GET['vr_link'])? addslashes($_GET['vr_link']):'';
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $status             = isset($_GET['status'])? addslashes($_GET['status']):'';
    
    $open_sale_adviser  = isset($_GET['open_sale_adviser'])? intval($_GET['open_sale_adviser']):0;
    //$sale_adviser_price = isset($_GET['sale_adviser_price'])? floatval($_GET['sale_adviser_price']):0.00;
    $sale_adviser_num   = isset($_GET['sale_adviser_num'])? intval($_GET['sale_adviser_num']):0;
    $sale_adviser_price_list = isset($_GET['sale_adviser_price_list'])? addslashes($_GET['sale_adviser_price_list']):'';
    
    $typeStr = '';
    if(is_array($_GET['type']) && !empty($_GET['type'])){
        $typeArr = array();
        foreach($_GET['type'] as $key => $value){
            if(!empty($value)){
                $typeArr[] = $value;
            }
        }
        if(is_array($typeArr) && !empty($typeArr)){
            $typeStr = '|'.implode('|', $typeArr).'|';
        }
    }
    
    $teseTagsIdsArr = array();
    if(is_array($_GET['tese_tags']) && !empty($_GET['tese_tags'])){
        foreach($_GET['tese_tags'] as $key => $value){
            if(intval($value) > 0){
                $teseTagsIdsArr[] = intval($value);
            }
        }
    }

    $configTagList = array();
    $teseTagsStr = $attrTeseTagsIdsStr = '';
    if(is_array($teseTagsIdsArr) && !empty($teseTagsIdsArr)){
        $teseTagsIdsCount = count($teseTagsIdsArr);
        $attrTeseTagsIdsStr = implode(',', $teseTagsIdsArr);
        $configTagListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_all_list(" AND id IN({$attrTeseTagsIdsStr}) ", 'ORDER BY tsort ASC,id DESC', 0, $teseTagsIdsCount);
        $configTagNameArr = array();
        if(is_array($configTagListTmp) && !empty($configTagListTmp)){
            foreach($configTagListTmp as $key => $value){
                $configTagList[$key] = $value;
                $configTagNameArr[] = $value['name'];
            }
        }

        if(is_array($configTagNameArr) && !empty($configTagNameArr)){
            $teseTagsStr = '|'.implode('|', $configTagNameArr).'|';
        }
    }
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $city_id = $__SitesInfo['city_id'];
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $city_id = $tongchengConfig['city_id'];
        }
    }
    
    $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    
    $data['site_id']            = $site_id;
    $data['user_id']            = $user_id;
    $data['name']               = $name;
    $data['sub_title']          = $sub_title;
    $data['type']               = $typeStr;
    $data['tese_tags']          = $teseTagsStr;
    $data['sell_status']        = $sell_status;
    $data['start_time']         = $start_time;
    $data['jiaofang_time']      = $jiaofang_time;
    $data['city_id']            = $city_id;
    $data['area_id']            = $area_id;
    $data['area_name']          = $areaInfo['name'];
    $data['street_id']          = $street_id;
    $data['street_name']        = $streetInfo['name'];
    $data['average_price']      = $average_price;
    $data['zhuangxiu_type']     = $zhuangxiu_type;
    $data['chanquan']           = $chanquan;
    $data['address']            = $address;
    $data['sales_tel']          = $sales_tel;
    $data['sales_address']      = $sales_address;
    $data['latitude']           = $latitude;
    $data['longitude']          = $longitude;
    $data['developer_company']  = $developer_company;
    $data['parking_space']      = $parking_space;
    $data['plot_ratio']         = $plot_ratio;
    $data['greening_rate']      = $greening_rate;
    $data['households_num']     = $households_num;
    $data['land_mianji']        = $land_mianji;
    $data['house_mianji']       = $house_mianji;
    $data['house_total_mianji'] = $house_total_mianji;
    $data['huode_ratio']        = $huode_ratio;
    $data['property_company']   = $property_company;
    $data['property_price']     = $property_price;
    $data['property_tel']       = $property_tel;
    $data['vr_link']            = $vr_link;
    $data['admin_edit']         = $admin_edit;
    $data['content']            = $content;
    $data['status']             = $status;
    $data['open_sale_adviser']  = $open_sale_adviser;
    //$data['sale_adviser_price'] = $sale_adviser_price;
    $data['sale_adviser_price_list'] = $sale_adviser_price_list;
    $data['sale_adviser_num']   = $sale_adviser_num;
    
    $returnData['data']                 = $data;
    $returnData['configTagList']        = $configTagList;
    $returnData['attrTeseTagsIdsStr']   = $attrTeseTagsIdsStr;
    
    return $returnData;
}

function __create_info_html($infoArr = array()){
    global $Lang,$houseTypeArr,$tongchengConfig,$zhuangxiuTypeArr;
    $options = array(
        'site_id'           => 1,
        'user_id'           => 0,
        'name'              => '',
        'sub_title'         => '',
        'open_sale_adviser' => 0,
        'sale_adviser_price' => 0.00,
        'sale_adviser_price_list' => '',
        'sale_adviser_num'  => 0,
        'type'              => '',
        'tese_tags'         => '',
        'sell_status'       => 1,
        'start_time'        => time(),
        'jiaofang_time'     => time(),
        'city_id'           => 0,
        'area_id'           => 0,
        'street_id'         => 0,
        'average_price'     => 0.00,
        'zhuangxiu_type'    => 0,
        'chanquan'          => 0,
        'address'           => '',
        'sales_tel'         => '',
        'sales_address'     => '',
        'latitude'          => '',
        'longitude'         => '',
        'developer_company' => '',
        'parking_space'     => 0,
        'plot_ratio'        => 0.00,
        'greening_rate'     => 0,
        'households_num'    => 0,
        'land_mianji'       => 0,
        'house_mianji'      => 0,
        'house_total_mianji'=> 0,
        'huode_ratio'       => 0,
        'property_company'  => '',
        'property_tel'      => '',
        'property_price'    => 0.00,
        'vr_link'           => '',
        'content'           => '',
        'admin_edit'        => 0,
        'status'            => 0,
        
    );
    $options = array_merge($options, $infoArr);
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id"  onChange="getCity();">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    
    tomshowsetting(true,array('title'=>$Lang['user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['newhouses_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_sub_title'],'name'=>'sub_title','value'=>$options['sub_title'],'msg'=>$Lang['newhouses_sub_title_msg']),"input");
    $open_sale_adviser_item = array(0=>$Lang['newhouses_open_sale_adviser_0'],1=>$Lang['newhouses_open_sale_adviser_1']);
    tomshowsetting(true,array('title'=>$Lang['newhouses_open_sale_adviser'],'name'=>'open_sale_adviser','value'=>$options['open_sale_adviser'],'msg'=>$Lang['newhouses_open_sale_adviser_msg'],'item'=>$open_sale_adviser_item),"radio");
    //tomshowsetting(true,array('title'=>$Lang['newhouses_sale_adviser_price'],'name'=>'sale_adviser_price','value'=>$options['sale_adviser_price'],'msg'=>$Lang['newhouses_sale_adviser_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_sale_adviser_price_list'],'name'=>'sale_adviser_price_list','value'=>$options['sale_adviser_price_list'],'msg'=>$Lang['newhouses_sale_adviser_price_list_msg']),"textarea");
    tomshowsetting(true,array('title'=>$Lang['newhouses_sale_adviser_num'],'name'=>'sale_adviser_num','value'=>$options['sale_adviser_num'],'msg'=>$Lang['newhouses_sale_adviser_num_msg']),"input");
    
    $typeArr = explode('|', trim($options['type'], '|'));
    $typeStr = '<tr class="header"><th>'.$Lang['newhouses_type'].'</th><th></th></tr>';
    $typeStr.= '<tr><td width="300">';
    foreach($houseTypeArr as $key => $value){
        if(is_array($typeArr) && !empty($typeArr) && in_array($key, $typeArr)){
            $typeStr.=  '<label><input type="checkbox" name="type[]" value="'.$key.'" checked>'.$value.'</label>';
        }else{
            $typeStr.=  '<label><input type="checkbox" name="type[]" value="'.$key.'">'.$value.'</label>';
        }
    }
    $typeStr.= '</td><td>'.$Lang['newhouses_type_msg'].'</td></tr>';
    echo $typeStr;
    
    $teseTagListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config_tag")->fetch_all_list(" AND model_id = 'newhouses' ", 'ORDER BY tsort ASC,id DESC', 0, 30);
    $teseTagList = array();
    if(is_array($teseTagListTmp) && !empty($teseTagListTmp)){
        foreach($teseTagListTmp as $key => $value){
            $teseTagList[$value['id']] = $value['name'];
        }
    }
    
    $teseTagsArr = explode('|',  trim($options['tese_tags'], '|'));
    $teseTagsStr = '<tr class="header"><th>'.$Lang['newhouses_tese_tags'].'</th><th></th></tr>';
    $teseTagsStr.= '<tr><td width="300">';
    foreach($teseTagList as $key => $value){
        if(is_array($teseTagsArr) && !empty($teseTagsArr) && in_array($value, $teseTagsArr)){
            $teseTagsStr.=  '<label><input type="checkbox" name="tese_tags[]" value="'.$key.'" checked>'.$value.'</label>';
        }else{
            $teseTagsStr.=  '<label><input type="checkbox" name="tese_tags[]" value="'.$key.'">'.$value.'</label>';
        }
    }
    $teseTagsStr.= '</td><td>'.$Lang['newhouses_tese_tags_msg'].'</td></tr>';
    echo $teseTagsStr;
    
    $sell_status_item = array(1=>$Lang['newhouses_sell_status_1'],2=>$Lang['newhouses_sell_status_2'],3=>$Lang['newhouses_sell_status_3']);
    tomshowsetting(true,array('title'=>$Lang['newhouses_sell_status'],'name'=>'sell_status','value'=>$options['sell_status'],'msg'=>$Lang['goods_sell_status_msg'],'item'=>$sell_status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['newhouses_start_time'],'name'=>'start_time','value'=>$options['start_time'],'msg'=>$Lang['newhouses_start_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['newhouses_jiaofang_time'],'name'=>'jiaofang_time','value'=>$options['jiaofang_time'],'msg'=>$Lang['newhouses_jiaofang_time_msg']),"calendar");
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($options['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($options['site_id']);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
        }
    }else if($options['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
    $areaStr.= '<tr><td width="100"><b>'.$Lang['houses_diqu'].'</b></td></tr>';
    $areaStr.= '<tr><td ><select style="width: 100px;" name="area_id" id="area_id" onChange="getStreet();">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($areaList as $key => $value){
        if($options['area_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select>';
    
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($options['area_id']);
    $areaStr.= '<select style="width: 100px;" name="street_id" id="street_id">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($streetList as $key => $value){
        if($options['street_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select></td><td>'.$Lang['houses_diqu_msg'].'</td></tr>';
    echo $areaStr;
    
    tomshowsetting(true,array('title'=>$Lang['newhouses_average_price'],'name'=>'average_price','value'=>$options['average_price'],'msg'=>$Lang['newhouses_average_price_msg']),"input");

    $zhuangxiuTypeStr.= '<tr><td width="100"><b>'.$Lang['newhouses_zhuangxiu_type'].'</b></td></tr>';
    $zhuangxiuTypeStr.= '<tr><td ><select style="width: 100px;" name="zhuangxiu_type" id="zhuangxiu_type">';
    foreach ($zhuangxiuTypeArr as $key => $value){
        if($options['zhuangxiu_type'] == $key){
            $zhuangxiuTypeStr.=  '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            $zhuangxiuTypeStr.=  '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    $zhuangxiuTypeStr.= '</select>';
    echo $zhuangxiuTypeStr;
    
    tomshowsetting(true,array('title'=>$Lang['newhouses_chanquan'],'name'=>'chanquan','value'=>$options['chanquan'],'msg'=>$Lang['newhouses_chanquan_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['newhouses_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_latitude'],'name'=>'latitude','value'=>$options['latitude'],'msg'=>$Lang['newhouses_latitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_longitude'],'name'=>'longitude','value'=>$options['longitude'],'msg'=>$Lang['newhouses_longitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_sales_tel'],'name'=>'sales_tel','value'=>$options['sales_tel'],'msg'=>$Lang['newhouses_sales_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_sales_address'],'name'=>'sales_address','value'=>$options['sales_address'],'msg'=>$Lang['newhouses_sales_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_developer_company'],'name'=>'developer_company','value'=>$options['developer_company'],'msg'=>$Lang['newhouses_developer_company_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_parking_space'],'name'=>'parking_space','value'=>$options['parking_space'],'msg'=>$Lang['newhouses_parking_space_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_plot_ratio'],'name'=>'plot_ratio','value'=>$options['plot_ratio'],'msg'=>$Lang['newhouses_plot_ratio_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_greening_rate'],'name'=>'greening_rate','value'=>$options['greening_rate'],'msg'=>$Lang['newhouses_greening_rate_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_households_num'],'name'=>'households_num','value'=>$options['households_num'],'msg'=>$Lang['newhouses_households_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_land_mianji'],'name'=>'land_mianji','value'=>$options['land_mianji'],'msg'=>$Lang['newhouses_land_mianji_msg']),"input");
    //tomshowsetting(true,array('title'=>$Lang['newhouses_house_mianji'],'name'=>'house_mianji','value'=>$options['house_mianji'],'msg'=>$Lang['newhouses_house_mianji_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_house_total_mianji'],'name'=>'house_total_mianji','value'=>$options['house_total_mianji'],'msg'=>$Lang['newhouses_house_total_mianji_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_huode_ratio'],'name'=>'huode_ratio','value'=>$options['huode_ratio'],'msg'=>$Lang['newhouses_huode_ratio_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_property_company'],'name'=>'property_company','value'=>$options['property_company'],'msg'=>$Lang['newhouses_property_company_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_property_price'],'name'=>'property_price','value'=>$options['property_price'],'msg'=>$Lang['newhouses_property_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_property_tel'],'name'=>'property_tel','value'=>$options['property_tel'],'msg'=>$Lang['newhouses_property_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['newhouses_vr_link'],'name'=>'vr_link','value'=>$options['vr_link'],'msg'=>$Lang['newhouses_vr_link_msg']),"input");
    $status_item = array(0=>$Lang['newhouses_status_0'],1=>$Lang['newhouses_status_1']);
    tomshowsetting(true,array('title'=>$Lang['newhouses_status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['goods_status_msg'],'item'=>$status_item),"radio");
    $admin_edit_item = array(0=>$Lang['newhouses_admin_edit_0'],1=>$Lang['newhouses_admin_edit_1']);
    tomshowsetting(true,array('title'=>$Lang['newhouses_admin_edit'],'name'=>'admin_edit','value'=>$options['admin_edit'],'msg'=>$Lang['newhouses_admin_edit_msg'],'item'=>$admin_edit_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['newhouses_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['newhouses_content_msg']),"text");
    
    return;
}

$jsstr = <<<EOF
<script type="text/javascript">
function getCity(){
  var site_id = jq("#site_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcfangchan:ajax",
        data: "act=admin_area&site="+site_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var areaHtml = '<option value="0">{$Lang['all']}</option>';
            jq.each(json,function(k,v){
                areaHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#area_id").html(areaHtml);
            jq("#area_id").show();
        }
    });
}
function getStreet(){
  var area_id = jq("#area_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcfangchan:ajax",
        data: "act=admin_street&area_id="+area_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var streetHtml = '<option value="0">{$Lang['all']}</option>';
            jq.each(json,function(k,v){
                streetHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            console.log(streetHtml);
            jq("#street_id").html(streetHtml);
            jq("#street_id").show();
        }
    });
}
</script>
EOF;
echo $jsstr;
    
function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['newhouses_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['newhouses_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['newhouses_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['newhouses_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['newhouses_edit'],"",true);
    }else if($_GET['act'] == 'photo'){
        
    }else{
        tomshownavli($Lang['newhouses_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['newhouses_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['newhouses_sale_adviser_title'],$adminBaseUrl."&tmod=adviser",false);
        tomshownavli($Lang['newhouses_manage_title'],$adminBaseUrl."&tmod=newhouses_manage",false);
    }
    tomshownavfooter();
}