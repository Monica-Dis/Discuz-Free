<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$newhouses_id = intval($_GET['newhouses_id'])>0? intval($_GET['newhouses_id']):0;

$modBaseUrl = $adminBaseUrl.'&tmod=adviser&newhouses_id='.$newhouses_id;
$modListUrl = $adminListUrl.'&tmod=adviser&newhouses_id='.$newhouses_id;
$modFromUrl = $adminFromUrl.'&tmod=adviser&newhouses_id='.$newhouses_id;

if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['shenhe_status']    = 1;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'edit'){
    
    $adviserInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($adviserInfo);
        C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->update($adviserInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($adviserInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status']     = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->update($_GET['id'],$updateData);

    $adviserInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($adviserInfo['user_id']);
    $newhousesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_by_id($adviserInfo['newhouses_id']);

    $shenhe = str_replace('{NAME}', $adviserInfo['name'], $Lang['adviser_template_shenhe_ok']);
    $shenhe = str_replace('{NEWHOUSES}', $newhousesInfo['name'], $shenhe);
    $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$adviserInfo['site_id'].'&mod=myadviserlist">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$adviserInfo['site_id']}&mod=myadviserlist");
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcfangchanConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $adviserInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $adviserInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_by_id($_GET['id']);
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($adviserInfo['user_id']);
        $newhousesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_by_id($adviserInfo['newhouses_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->update($_GET['id'],$updateData);

        $shenhe = str_replace('{NAME}', $adviserInfo['name'], $Lang['adviser_template_shenhe_no']);
        $shenhe = str_replace('{NEWHOUSES}', $newhousesInfo['name'], $shenhe);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$adviserInfo['site_id'].'&mod=myadviserlist">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        
        $cpmsg = $Lang['act_success'];
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$adviserInfo['site_id']}&mod=myadviserlist");
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tcfangchan_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tcfangchan_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.$Lang['tcfangchan_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tcfangchan_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcfangchan_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'pay_ok'){
    
    $updateData = array();
    $updateData['pay_status'] = 2;
    C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->update($_GET['id'], $updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editexpire'){
    
    $info = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $expire_status   = intval($_GET['expire_status'])>0? addslashes($_GET['expire_status']):0;
        $expire_time     = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
        $expire_time     = strtotime($expire_time);
        $updateData = array();
        if($expire_status == 3){
            $updateData['expire_status']    = 3;
        }else{
            if($expire_status == 2 || $expire_time < TIMESTAMP){
                $updateData['expire_status']    = 2;
                $updateData['expire_time']      = 0;
                $updateData['status']           = 0;
            }else{
                $updateData['expire_status']    = 1;
                $updateData['expire_time']      = $expire_time;
            }
        }
        C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->update($_GET['id'],$updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editexpire&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_expire_title'] .'</th></tr>';
        $expire_status_item = array('1' => $Lang['expire_status_1'],'2' => $Lang['expire_status_2'],'3' => $Lang['expire_status_3']);
        tomshowsetting(true,array('title'=>$Lang['expire_status'],'name'=>'expire_status','value'=>$info['expire_status'],'msg'=>$Lang['expire_status_msg'],'item' => $expire_status_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['edit_expire_time'],'name'=>'expire_time','value'=>$info['expire_time'],'msg'=>$Lang['edit_expire_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $adviser_id     = isset($_GET['adviser_id'])? intval($_GET['adviser_id']):0;
    $expire_status  = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($name)){
        $name = str_replace(array('%', '_'),'',$name);
        $where .= " AND name LIKE '%{$name}%' ";
    }
    if(!empty($tel)){
        $tel = str_replace(array('%', '_'),'',$tel);
        $where .= " AND tel LIKE '%{$tel}%' ";
    }
    if($newhouses_id > 0){
        $where .= " AND newhouses_id={$newhouses_id} ";
    }
    if($site_id > 0){
        $where .= " AND site_id={$site_id} ";
    }
    if($adviser_id > 0){
        $where .= " AND id={$adviser_id} ";
    }
    
    if($expire_status > 0){
        if($expire_status == 1){
            $where.= " AND ((expire_status = 1 AND expire_time > ".TIMESTAMP.") OR (expire_status = 3)) ";
        }else if($expire_status == 2){
            $where.= " AND expire_status = 2 ";
        }
    }
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count($where);
    $adviserList = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_list($where," ORDER BY asort ASC,id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&newhouses_id={$newhouses_id}&expire_status={$expire_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b> ID </b></td><td width="100"><input type="text" style="width: 260px;" name="adviser_id" value="'.$adviser_id.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['adviser_name'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="name" value="'.$name.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['adviser_tel'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="tel" value="'.$tel.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['adviser_newhouses_id'].'</b></td><td ><input style="width: 260px;" type="number" name="newhouses_id" value="'.$newhouses_id.'"></td></tr>';
    
    $site_select_1 = '';
    if($site_id == 1){
        $site_select_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_select_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;

    $expire_status_1 = $expire_status_2 = '';
    if($expire_status == 1){
        $expire_status_1 = 'selected';
    }else if($expire_status == 2){
        $expire_status_2 = 'selected';
    }
    $expireStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['expire_status'].'</b></td>';
    $expireStatusStr.= '<td><select style="width: 260px;" name="expire_status" id="expire_status">';
    $expireStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $expireStatusStr.=  '<option value="1" '.$expire_status_1.'>'.$Lang['expire_status_1'].'</option>';
    $expireStatusStr.=  '<option value="2" '.$expire_status_2.'>'.$Lang['expire_status_2'].'</option>';
    $expireStatusStr.= '</select></td></tr>';
    echo $expireStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['adviser_newhouses_id'] . '</th>';
    echo '<th>' . $Lang['user_id'] . '</th>';
    echo '<th>' . $Lang['adviser_avatar'] . '</th>';
    echo '<th>' . $Lang['adviser_name'] . '</th>';
    echo '<th>' . $Lang['adviser_tel'] . '</th>';
    echo '<th>' . $Lang['adviser_wx_qrcode'] . '</th>';
    echo '<th>' . $Lang['adviser_work_picurl'] . '</th>';
    echo '<th width="150px;">' . $Lang['adviser_sub_desc'] . '</th>';
    echo '<th>' . $Lang['pay_status'] . '</th>';
    echo '<th>' . $Lang['expire_status'] . '</th>';
    echo '<th>' . $Lang['index_status'] . '</th>';
    echo '<th>' . $Lang['shenhe_status'] . '</th>';
    echo '<th>' . $Lang['sort'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($adviserList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $value['newhouses_name'] . '<font color="#f70404">(ID:'.$value['newhouses_id']. ')</font></td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f70404">(ID:'.$value['user_id']. ')</font></td>';
        echo '<td><a href="'.tomgetfileurl($value['avatar']).'" target="_blank"><img src="'.tomgetfileurl($value['avatar']).'" width="40" /></a></td>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['tel'] . '</td>';
        echo '<td><a href="'.tomgetfileurl($value['wx_qrcode']).'" target="_blank"><img src="'.tomgetfileurl($value['wx_qrcode']).'" width="40" /></a></td>';
        echo '<td><a href="'.tomgetfileurl($value['work_picurl']).'" target="_blank"><img src="'.tomgetfileurl($value['work_picurl']).'" width="40" /></a></td>';
        echo '<td>' . $value['sub_desc'] . '</td>';
        if($value['pay_status'] == 1){
            echo '<td><font color="#f70404">' . $Lang['pay_status_1']. '</font>&nbsp;<a href="javascript:void(0);" onclick="pay_confirm(\''.$modBaseUrl.'&act=pay_ok&id='.$value['id'].'&formhash='.FORMHASH.'\');">('.$Lang['pay_status_2'].')</a></td>';
        }else if($value['pay_status'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['pay_status_2']. '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['expire_status'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['expire_status_1'].'</font><font color="#f70404">('.dgmdate($value['expire_time'], 'Y-m-d H:i',$tomSysOffset).')</font></td>';
        }else if($value['expire_status'] == 2){
            echo '<td><font color="#f70404">'.$Lang['expire_status_2'].'</font></td>';
        }else if($value['expire_status'] == 3){
            echo '<td><font color="#0a9409">'.$Lang['expire_status_3'].'</font></td>';
        }
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">'.$Lang['index_status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['index_status_0']. ')</font></a></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['index_status_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['index_status_1']. ')</font></a></td>';
        }
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_status_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_status_3']. '</a>)';
        if($value['shenhe_status'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['shenhe_status_1']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 2){
            echo '<td><font color="#f70404">' . $Lang['shenhe_status_2']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 3){
            echo '<td><font color="#f70404">' . $Lang['shenhe_status_3']. '</font>'.$sheheBtnStr.'</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $value['asort'] . '</td>';
        echo '<td>' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=editexpire&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_expire_title']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a><br/>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function pay_confirm(url){
  var r = confirm("{$Lang['makesure_pay_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    global $tongchengConfig;
    $data = array();
    
    $newhouses_id   = isset($_GET['newhouses_id'])? intval($_GET['newhouses_id']):0;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $sub_desc       = isset($_GET['sub_desc'])? addslashes($_GET['sub_desc']):'';
    $tel            = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $asort          = isset($_GET['asort'])? intval($_GET['asort']):10;
    
    $newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($newhouses_id);
    
    $avatar = $wx_qrcode = $work_picurl = "";
    if($_GET['act'] == 'add'){
        $avatar         = tomuploadFile("avatar");
        $wx_qrcode      = tomuploadFile("wx_qrcode");
        $work_picurl    = tomuploadFile("work_picurl");
    }else if($_GET['act'] == 'edit'){
        $avatar         = tomuploadFile("avatar",$infoArr['avatar']);
        $wx_qrcode      = tomuploadFile("wx_qrcode",$infoArr['wx_qrcode']);
        $work_picurl    = tomuploadFile("work_picurl",$infoArr['work_picurl']);
    }
    
    $data['site_id']            = $newhousesInfo['site_id'];
    $data['newhouses_id']       = $newhouses_id;
    $data['newhouses_name']     = $newhousesInfo['name'];
    $data['user_id']            = $user_id;
    $data['name']               = $name;
    $data['sub_desc']           = $sub_desc;
    $data['avatar']             = $avatar;
    $data['work_picurl']        = $work_picurl;
    $data['tel']                = $tel;
    $data['wx_qrcode']          = $wx_qrcode;
    $data['asort']              = $asort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$mendian_id;
    $options = array(
        'newhouses_id'  => 0,
        'user_id'       => 0,
        'name'          => '',
        'sub_desc'      => '',
        'avatar'        => '',
        'work_picurl'   => '',
        'tel'           => '',
        'wx_qrcode'     => '',
        'asort'         => 10,
    );
    
    if($_GET['act'] == 'add' && $newhouses_id > 0){
        $options['newhouses_id'] = $newhouses_id;
    }
    
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['adviser_newhouses_id'],'name'=>'newhouses_id','value'=>$options['newhouses_id'],'msg'=>$Lang['adviser_newhouses_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['adviser_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['adviser_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['adviser_sub_desc'],'name'=>'sub_desc','value'=>$options['sub_desc'],'msg'=>$Lang['adviser_sub_desc_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['adviser_avatar'],'name'=>'avatar','value'=>$options['avatar'],'msg'=>$Lang['adviser_avatar_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['adviser_work_picurl'],'name'=>'work_picurl','value'=>$options['work_picurl'],'msg'=>$Lang['adviser_work_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['adviser_wx_qrcode'],'name'=>'wx_qrcode','value'=>$options['wx_qrcode'],'msg'=>$Lang['adviser_wx_qrcode_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['adviser_tel'],'name'=>'tel','value'=>$options['tel'],'msg'=>$Lang['adviser_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'asort','value'=>$options['asort'],'msg'=>$Lang['sort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['adviser_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['adviser_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['adviser_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['adviser_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['edit'],"",true);
    }else{
        tomshownavli($Lang['adviser_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['adviser_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}