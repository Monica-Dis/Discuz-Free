<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=doDaoNewhousesGuanzu';
$modListUrl = $adminListUrl.'&tmod=doDaoNewhousesGuanzu';
$modFromUrl = $adminFromUrl.'&tmod=doDaoNewhousesGuanzu';

$newhouses_id   = isset($_GET['newhouses_id'])? intval($_GET['newhouses_id']):0;
$type           = isset($_GET['type'])? intval($_GET['type']):0;
$days           = isset($_GET['days'])? intval($_GET['days']):0;

$newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($newhouses_id);

tomloadcalendarjs();
showformheader($modFromUrl."&submit_do=1&newhouses_id={$newhouses_id}&formhash=".FORMHASH);
showtableheader();
if($type > 0){
    if($type == 1){
        echo '<tr><th colspan="15" class="partition">'.$newhousesInfo['name'] .'&nbsp;&nbsp;&gt;&gt;&gt;&nbsp;&nbsp;'. $Lang['doDao_title_type_1'] .'</th></tr>';
    }else if($type == 2){
        echo '<tr><th colspan="15" class="partition">'.$newhousesInfo['name'] .'&nbsp;&nbsp;&gt;&gt;&gt;&nbsp;&nbsp;'. $Lang['doDao_title_type_2'] .'</th></tr>';
    }else if($type == 3){
        echo '<tr><th colspan="15" class="partition">'.$newhousesInfo['name'] .'&nbsp;&nbsp;&gt;&gt;&gt;&nbsp;&nbsp;'. $Lang['doDao_title_type_3'] .'</th></tr>';
    }
}

$type_1 = $type_2 = $type_3 = '';
if($type == 1){
    $type_1 = 'selected';
}else if($type == 2){
    $type_2 = 'selected';
}else if($type == 3){
    $type_3 = 'selected';
}

$typeStr = '<tr class="header"><th>'.$Lang['doDao_guanzu_type'].'</th><th></th></tr>';
$typeStr.= '<tr><td width="300"><select style="width: 260px;" name="type" id="type">';
$typeStr.=  '<option value="0">'.$Lang['doDao_guanzu_type_0'].'</option>';
$typeStr.=  '<option value="1" '.$type_1.'>'.$Lang['doDao_guanzu_type_1'].'</option>';
$typeStr.=  '<option value="2" '.$type_2.'>'.$Lang['doDao_guanzu_type_2'].'</option>';
$typeStr.=  '<option value="3" '.$type_3.'>'.$Lang['doDao_guanzu_type_3'].'</option>';
$typeStr.= '</select></td><td></td></tr>';
echo $typeStr;

$daysStr = '<tr class="header"><th>'.$Lang['doDao_days'].'</th><th></th></tr>';
$daysStr.= '<tr><td width="300"><select style="width: 260px;" name="days" id="days">';
$daysStr.=  '<option value="0">'.$Lang['doDao_days_0'].'</option>';
for($i = 1; $i<= 30 ;$i++){
    if($i == $days){
        $daysStr.=  '<option value="'.$i.'" selected>'.$i.''.$Lang['doDao_days_msg'].'</option>';
    }else{
        $daysStr.=  '<option value="'.$i.'">'.$i.''.$Lang['doDao_days_msg'].'</option>';
    }
}
$daysStr.= '</select></td><td></td></tr>';
echo $daysStr;

showsubmit('submit',$Lang['daDao_btn']);

showtablefooter(); /*dism��taobao��com*/
showformfooter(); /*Dism_taobao-com*/

$where = " AND newhouses_id={$newhouses_id} ";

if($type > 0){
    $where.= " AND type = {$type} ";
}
if($days > 0){
    $minTime = TIMESTAMP - $days * 86400;
    $where.= " AND add_time > {$minTime} ";
}

$count = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_guanzu')->fetch_all_count($where);

$doDaoUrl = $_G['siteurl']."plugin.php?id=tom_tcfangchan:doDaoNewhousesGuanzu&newhouses_id={$newhouses_id}&type={$type}&days={$days}";

if($_GET['submit_do'] == 1){
    if($count > 0){
        showtableheader();
        echo '<tr>';
        echo '<td><a href="'.$doDaoUrl.'" target="_blank" style="color: #FA6A03; padding:2px 7px; font-weight:600; margin-left: 10px; border-radius: 5px; border: 1px solid #FA6A03;">'.$Lang['daDao_url'].'</a></td>';
        echo '</tr>';
        showtablefooter(); /*dism��taobao��com*/
    }else{
        echo '<br/><b><font color="#fd0d0d">'.$Lang['daDao_no_msg'].'</font></b>';
    }
}