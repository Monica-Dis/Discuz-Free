<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=mendian';
$modListUrl = $adminListUrl.'&tmod=mendian';
$modFromUrl = $adminFromUrl.'&tmod=mendian';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $data = __get_post_data();
        
        $insertData = array();
        $insertData = $data['mendianInfo'];
        $insertData['shenhe_status']    = 1;
        $insertData['admin_edit']       = 1;
        $insertData['add_time']         = TIMESTAMP;
        if(C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->insert($insertData)){

            $mendian_id = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->insert_id();
            $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($mendian_id);
            $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($mendianInfo['user_id']);
            
            update_mendian_tcshop($mendian_id);
            
            if(!empty($data['logo'])){
                $insertData = array();
                $insertData['mendian_id']       = $mendian_id;
                $insertData['type']             = 5;
                $insertData['picurl']           = $data['logo'];
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
            
            if(!empty($data['business_licence'])){
                $insertData = array();
                $insertData['mendian_id']       = $mendian_id;
                $insertData['type']             = 7;
                $insertData['picurl']           = $data['business_licence'];
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
            
            $insertData = array();
            $insertData['site_id']              = $mendianInfo['site_id'];
            $insertData['mendian_id']           = $mendian_id;
            $insertData['user_id']              = $userInfo['id'];
            $insertData['avatar']               = $tcfangchanConfig['default_agent_avatar'];
            $insertData['name']                 = $userInfo['nickname'];
            $insertData['tel']                  = $userInfo['tel'];
            $insertData['is_ok']                = 0;
            $insertData['shenhe_status']        = 1;
            $insertData['add_time']             = TIMESTAMP;
            if(C::t("#tom_tcfangchan#tom_tcfangchan_agent")->insert($insertData)){
                
                DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET source_type=1 WHERE user_id = {$userInfo['id']} ", 'UNBUFFERED');
                if(!empty($tongchengConfig['template_id'])){

                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($userInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mymendian");
                        $smsData = array(
                            'first'         => lang('plugin/tom_tcfangchan', 'template_edit_mymendian_xinxi_msg'),
                            'keyword1'      => $tcfangchanConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );

                        @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                    }
                }
            }
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'edit'){
    
    $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($_GET['mendian_id']);
    if(submitcheck('submit')){
        
        $data = __get_post_data($mendianInfo);
        
        $updateData = array();
        $updateData = $data['mendianInfo'];
        $updateData['admin_edit']   = 1;
        $updateData['part1']        = TIMESTAMP;
        if(C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendianInfo['id'],$updateData)){
            
            update_mendian_tcshop($mendianInfo['id']);
            
            $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($mendianInfo['user_id']);
            if($mendianInfo['id'] > 0){
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->delete_all_list(" AND mendian_id = {$mendianInfo['id']} AND type IN(5,7) ");
            }
            
            if(!empty($data['logo'])){
                $insertData = array();
                $insertData['mendian_id']       = $mendianInfo['id'];
                $insertData['type']             = 5;
                $insertData['picurl']           = $data['logo'];
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
            
            if(!empty($data['business_licence'])){
                $insertData = array();
                $insertData['mendian_id']       = $mendianInfo['id'];
                $insertData['type']             = 7;
                $insertData['picurl']           = $data['business_licence'];
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
            
            
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&mendian_id='.$_GET['mendian_id'],'enctype');
        showtableheader();
        __create_info_html($mendianInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){
    $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($_GET['mendian_id']);

    $updateData = array();
    $updateData['shenhe_status']    = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendianInfo['id'],$updateData);
    
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($mendianInfo['user_id']);

    update_mendian_tcshop($_GET['mendian_id']);
    
    $shenhe = str_replace('{NAME}', $mendianInfo['name'], $Lang['index_template_mendian_shenhe_ok']);
    $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$mendianInfo['site_id'].'&mod=mendianinfo&mendian_id='.$mendianInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$mendianInfo['site_id']}&mod=mendianinfo&mendian_id=".$mendianInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcfangchanConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['tcfangchan_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['tcfangchan_shenhe_tz_fail'];
        }
    }
    
    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($_GET['mendian_id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($mendianInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status'] = 3;
        C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendianInfo['id'],$updateData);
        
        update_mendian_tcshop($_GET['mendian_id']);
        
        $shenhe = str_replace('{NAME}', $mendianInfo['name'], $Lang['index_template_mendian_shenhe_no']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$mendianInfo['site_id'].'&mod=mendianedit">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$mendianInfo['site_id']}&mod=mendianedit");
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tcfangchan_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tcfangchan_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.$Lang['tcfangchan_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&mendian_id='.$_GET['mendian_id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tcfangchan_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcfangchan_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'editvip'){
    
    $info = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($_GET['mendian_id']);
    if(submitcheck('submit')){
        $vip_id         = intval($_GET['vip_id'])>0 ? intval($_GET['vip_id']):0;
        $expire_time    = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
        $expire_time    = strtotime($expire_time);
        $updateData = array();
        if($expire_time > TIMESTAMP){
            $updateData['vip_id']          = $vip_id;
            $updateData['expire_status']   = 1;
            $updateData['expire_time']     = $expire_time;
            $updateData['vip_add_time']    = TIMESTAMP;
        }else{
            $updateData['expire_status']   = 0;
            $updateData['expire_time']     = $expire_time;
        }
        C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($_GET['mendian_id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editvip&mendian_id='.$_GET['mendian_id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['mendian_edit_vip'] .'</th></tr>';
        
        $vipList = C::t('#tom_tcfangchan#tom_tcfangchan_mendian_vip')->fetch_all_list(" AND status=1 "," ORDER BY vsort ASC,id DESC ",0,100);
        $vipStr = '<tr class="header"><th>'.$Lang['mendianvip_name'].'</th><th></th></tr>';
        $vipStr.= '<tr><td width="300"><select style="width: 260px;" name="vip_id" id="vip_id">';
        foreach ($vipList as $key => $value){
            if($value['id'] == $info['vip_id']){
                $vipStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $vipStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $vipStr.= '</select></td><td></td></tr>';
        echo $vipStr;
        tomshowsetting(true,array('title'=>$Lang['edit_vip_time'],'name'=>'expire_time','value'=>$info['expire_time'],'msg'=>$Lang['edit_vip_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'edittop'){
    
    $info = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($_GET['mendian_id']);
    if(submitcheck('submit')){
        $top_time     = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
        $top_time     = strtotime($top_time);
        $updateData = array();
        if($top_time < TIMESTAMP){
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
        }else{
            $updateData['top_status']   = 1;
            $updateData['top_time']     = $top_time;
        }
        C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($_GET['mendian_id'],$updateData);
        
        update_mendian_tcshop($_GET['mendian_id']);
    
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edittop&mendian_id='.$_GET['mendian_id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['top_edit'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['top_time'],'name'=>'top_time','value'=>$info['top_time'],'msg'=>''),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->delete_by_id($_GET['mendian_id']);
    
    $agentList = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_agent_list(" AND mendian_id = {$_GET['mendian_id']} ");
    
    if(is_array($agentList) && !empty($agentList)){
        foreach($agentList as $key => $value){
            DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET source_type=2 WHERE user_id = {$value['user_id']} ", 'UNBUFFERED');
        }
    }
    C::t('#tom_tcfangchan#tom_tcfangchan_agent')->delete_by_mendian_id($_GET['mendian_id']);
    C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_mendian_id($_GET['mendian_id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'viplog'){
    
    $mendian_id     = intval($_GET['mendian_id'])>0? intval($_GET['mendian_id']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($mendian_id);
    
    $where = " AND mendian_id = {$mendian_id} ";
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_log')->fetch_all_count($where);
    $logList = C::t('#tom_tcfangchan#tom_tcfangchan_log')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);

    $modBasePageUrl = $modBaseUrl."&act=viplog&mendian_id={$mendian_id}";
    
    __create_nav_html();
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $mendianInfo['name'] .'&nbsp;&nbsp;&gt;&gt;&gt;&nbsp;&nbsp;'.$Lang['mendian_vip_log']. '</th></tr>';
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['index_user'] . '</th>';
    echo '<th>' . $Lang['mendian_log_agent'] . '</th>';
    echo '<th>' . $Lang['mendian_log_type'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($logList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($value['agent_id']);
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f70404">(ID:'.$value['user_id']. ')</font></td>';
        echo '<td>' . $agentInfo['name'] .'<font color="#f70404">(ID:'.$value['agent_id']. ')</font></td>';
        if($value['type'] == 1){
            echo '<td><font color="#0a9409">'.$Lang['mendian_log_type_1']. '</font></td>';
        }else if($value['type'] == 2){
            echo '<td><font color="#0a9409">'.$Lang['mendian_log_type_2']. '</font></td>';
        }
        echo '<td>' . dgmdate($value['log_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        echo '<td> -- </td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['act'] == 'addphoto'){
    
    if(submitcheck('submit')){
        
        $mendian_id     = isset($_GET['mendian_id'])? intval($_GET['mendian_id']):0;
        $psort          = isset($_GET['psort'])? intval($_GET['psort']):10;
        $picurl         = tomuploadFile("picurl");
        
        $insertData = array();
        $insertData['mendian_id']       = $mendian_id;
        $insertData['picurl']           = $picurl;
        $insertData['type']             = 6;
        $insertData['psort']            = $psort;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_photo')->insert($insertData);
        update_mendian_tcshop($mendian_id);
    
        cpmsg($Lang['act_success'], $modListUrl.'&act=photo&mendian_id='.$mendian_id, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        tomshownavheader();
        tomshownavli($Lang['houses_photo_add'],'',true);
        tomshownavfooter();
        showformheader($modFromUrl.'&act=addphoto&mendian_id='.$_GET['mendian_id'],'enctype');
        showtableheader();
        
        tomshowsetting(true,array('title'=>$Lang['houses_photo'],'name'=>'picurl','value'=>'','msg'=>$Lang['houses_photo_msg']),"file");
        tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'psort','value'=>10,'msg'=>$Lang['sort_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_id($_GET['id']);
    update_mendian_tcshop($_GET['mendian_id']);
    
    cpmsg($Lang['act_success'], $modListUrl.'&act=photo&mendian_id='.$_GET['mendian_id'], 'succeed');
    
}else if($_GET['act'] == 'photo'){
    
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $mendian_id = intval($_GET['mendian_id'])>0? intval($_GET['mendian_id']):0;
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($mendian_id);
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_count(" AND mendian_id = {$mendian_id} AND type = 6 ");
    $photoList = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND mendian_id = {$mendian_id} AND type = 6  "," ORDER BY psort ASC,id ASC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&act=photo&site_id={$site_id}";
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' .$mendianInfo['name'].'&gt;'. $Lang['houses_photo'] . '</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    tomshownavheader();
    tomshownavli($Lang['houses_photo_add'],$modBaseUrl."&act=addphoto&mendian_id=".$mendian_id,false);
    tomshownavfooter();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['index_photo'] . '</th>';
    echo '<th>' . $Lang['sort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($photoList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a href="' . $value['picurlTmp'] . '" target="_blank"><img height="40" src="' . $value['picurlTmp'] . '"></a></td>';
        echo '<td>' . $value['psort'] . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&mendian_id='.$mendian_id.'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'edituser'){
    
    $info = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($_GET['mendian_id']);
    if(submitcheck('submit')){
        
        $user_id = isset($_GET['user_id'])? intval($_GET['user_id']):0;
        
        if($info['user_id'] == $user_id){
            cpmsg($Lang['mendian_edituser_error1'], $modListUrl, 'error');exit;
        }
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
        if($userInfo && $userInfo['id'] > 0){}else{
            cpmsg($Lang['mendian_edituser_error2'], $modListUrl, 'error');exit;
        }
        $isHaveMendian = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_user_id($user_id);
        if($isHaveMendian && $isHaveMendian['id'] > 0){
            cpmsg($Lang['mendian_edituser_error3'], $modListUrl, 'error');exit;
        }
        
        $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($user_id);
        if($agentInfo && $agentInfo['id'] > 0 && $agentInfo['mendian_id'] != $info['id']){
            cpmsg($Lang['mendian_edituser_error4'], $modListUrl, 'error');exit;
        }
        
        DB::query("UPDATE ".DB::table('tom_tcfangchan_mendian')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tcfangchan_log')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tcfangchan_order')." SET user_id={$user_id} WHERE user_id='{$info['user_id']}'", 'UNBUFFERED');
        
        if($agentInfo && $agentInfo['id'] > 0){ }else{
            
            $insertData = array();
            $insertData['site_id']              = $info['site_id'];
            $insertData['mendian_id']           = $info['id'];
            $insertData['user_id']              = $user_id;
            $insertData['avatar']               = $tcfangchanConfig['default_agent_avatar'];
            $insertData['name']                 = $userInfo['nickname'];
            $insertData['tel']                  = $userInfo['tel'];
            $insertData['is_ok']                = 0;
            $insertData['shenhe_status']        = 1;
            $insertData['add_time']             = TIMESTAMP;
            if(C::t("#tom_tcfangchan#tom_tcfangchan_agent")->insert($insertData)){
            
                DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET source_type=1 WHERE user_id = {$user_id} ", 'UNBUFFERED');

                if(!empty($tongchengConfig['template_id'])){

                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($userInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mymendian");
                        $smsData = array(
                            'first'         => lang('plugin/tom_tcfangchan', 'template_edit_mymendian_xinxi_msg'),
                            'keyword1'      => $tcfangchanConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );

                        @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
                    }
                }
            }
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edituser&mendian_id='.$_GET['mendian_id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['mendian_edituser_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['mendian_edituser'],'name'=>'user_id','value'=>$info['user_id'],'msg'=>$Lang['mendian_edituser_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else{
    
    $keyword        = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $mendian_id     = isset($_GET['mendian_id'])? intval($_GET['mendian_id']):0;
    $shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $top_status     = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if($site_id > 0){
        $where.= " AND site_id={$site_id} ";
    }
    if($user_id > 0){
        $where.= " AND user_id={$user_id} ";
    }
    if($mendian_id > 0){
        $where.= " AND id={$mendian_id} ";
    }
    if($shenhe_status > 0){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    if($top_status > 0){
        if($top_status == 1){
            $where.= " AND top_status=1 ";
        }else if($top_status == 2){
            $where.= " AND top_status=0 ";
        }
    }

    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_count($where,$keyword);
    $mendianList = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize,$keyword);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&shenhe_status={$shenhe_status}&top_status={$top_status}&keyword=".urlencode($keyword);
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['index_search_text'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="keyword" value="'.$keyword.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['mendian_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="mendian_id" value="'.$mendian_id.'"></td></tr>';
    
    $site_select_1 = '';
    if($site_id == 1){
        $site_select_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_select_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $status_shenhe_1 = $status_shenhe_2 = $status_shenhe_3 = '';
    if($shenhe_status == 1){
        $status_shenhe_1 = 'selected';
    }else if($shenhe_status == 2){
        $status_shenhe_2 = 'selected';
    }else if($shenhe_status == 3){
        $status_shenhe_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$status_shenhe_1.'>'.$Lang['shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$status_shenhe_2.'>'.$Lang['shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$status_shenhe_3.'>'.$Lang['shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    $top_status_1 = $top_status_2 = '';
    if($top_status == 1){
        $top_status_1 = 'selected';
    }else if($top_status == 2){
        $top_status_2 = 'selected';
    }
    $topStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['top_status'].'</b></td>';
    $topStatusStr.= '<td><select style="width: 260px;" name="top_status" id="top_status">';
    $topStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $topStatusStr.=  '<option value="1" '.$top_status_1.'>'.$Lang['top_status_1'].'</option>';
    $topStatusStr.=  '<option value="2" '.$top_status_2.'>'.$Lang['top_status_0'].'</option>';
    $topStatusStr.= '</select></td></tr>';
    echo $topStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['mendian_user_id'] . '</th>';
    echo '<th width="100">' . $Lang['mendian_name'] . '</th>';
    echo '<th>' . $Lang['mendian_agent_num'] . '</th>';
    echo '<th>' . $Lang['mendian_house_num'] . '</th>';
    echo '<th>' . $Lang['mendian_vip'] . '</th>';
    echo '<th>' . $Lang['mendian_vip_status'] . '</th>';
    echo '<th >'. $Lang['shenhe_status'] . '</th>';
    echo '<th>' . $Lang['top_time'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($mendianList as $key => $value) {
        
        update_mendian_xinxi($value['id']);
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $vipInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian_vip')->fetch_by_id($value['vip_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        
        echo '<td>' . $userInfo['nickname'] .'<font color="#f70404">(ID:'.$value['user_id']. ')</font>&nbsp;<a href="'.$modBaseUrl.'&act=edituser&mendian_id='.$value['id'].'&formhash='.FORMHASH.'">(' . $Lang['mendian_edituser_title']. ')</a></td>';
        
        echo '<td>' . $value['name'] .'<font color="#f70404">(ID:'.$value['id']. ')</font></td>';
        echo '<td>' . $value['agent_num'] . '</td>';
        echo '<td>' . $value['house_num'] . '</td>';
        
        if($value['vip_id'] > 0){
            echo '<td>' . $vipInfo['name'] .'<font color="#f70404">(ID:'.$value['vip_id']. ')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if($value['expire_status'] == 1 && $value['expire_time'] > TIMESTAMP){
            echo '<td><font color="#0a9409">'.$Lang['expire_status_1'].'</font><font color="#f70404">('.dgmdate($value['expire_time'], 'Y-m-d H:i:s',$tomSysOffset).')</font></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['expire_status_2'].'</font></td>';
        }
        
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&mendian_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_status_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&mendian_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_status_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['shenhe_status_1']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 2 ){
            echo '<td><font color="#f70404">' . $Lang['shenhe_status_2']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 3 ){
            echo '<td><font color="#f70404">' . $Lang['shenhe_status_3']. '</font>'.$sheheBtnStr.'</td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if($value['top_status'] == 1 && $value['top_time'] > TIMESTAMP){
            echo '<td><font color="#0a9409">'.$Lang['top_status_1'].'</font><font color="#f70404">('.dgmdate($value['top_time'], 'Y-m-d H:i:s',$tomSysOffset).')</font></td>';
        }else{
            echo '<td><font color="#f70404">'.$Lang['top_status_0'].'</font></td>';
        }
        
        echo '<td>' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        
        echo '<td style="line-height: 25px;">';
        if($tcfangchanConfig['open_mendian_vip'] == 1){
            echo '<a href="'.$modBaseUrl.'&act=editvip&mendian_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['mendian_edit_vip']. '</a>&nbsp;|&nbsp;';
        }
        echo '<a href="'.$adminBaseUrl.'&tmod=agent&mendian_id='.$value['id'].'&formhash='.FORMHASH.'" target="_blank">' . $Lang['agent_list_title']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edittop&mendian_id='.$value['id'].'">' . $Lang['top_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=viplog&mendian_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['mendian_vip_log']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edit&mendian_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=photo&mendian_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['houses_photo_title']. '</a><br/>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&mendian_id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    global $tongchengConfig;
    $data = array();
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):1;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $business_hours     = isset($_GET['business_hours'])? addslashes($_GET['business_hours']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $shopkeeper_tel     = isset($_GET['shopkeeper_tel'])? addslashes($_GET['shopkeeper_tel']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $city_id = $__SitesInfo['city_id'];
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $city_id = $tongchengConfig['city_id'];
        }
    }
    
    $logo = $business_licence = "";
    if($_GET['act'] == 'add'){
        $logo               = tomuploadFile("logo");
        $business_licence   = tomuploadFile("business_licence");
    }else if($_GET['act'] == 'edit'){
        $logo               = tomuploadFile("logo",$infoArr['logo']);
        $business_licence   = tomuploadFile("business_licence",$infoArr['business_licence']);
    }
    
    $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    
    $mendianInfo['site_id']            = $site_id;
    if($_GET['act'] == 'add'){
        $mendianInfo['user_id']             = $user_id;
    }
    $mendianInfo['name']               = $name;
    $mendianInfo['city_id']            = $city_id;
    $mendianInfo['area_id']            = $area_id;
    $mendianInfo['area_name']          = $areaInfo['name'];
    $mendianInfo['street_id']          = $street_id;
    $mendianInfo['street_name']        = $streetInfo['name'];
    $mendianInfo['address']            = $address;
    $mendianInfo['latitude']           = $latitude;
    $mendianInfo['longitude']          = $longitude;
    $mendianInfo['business_hours']     = $business_hours;
    $mendianInfo['tel']                = $tel;
    $mendianInfo['shopkeeper_tel']     = $shopkeeper_tel;
    $mendianInfo['content']            = $content;
    $mendianInfo['search_text']        = $name.'|++++|'.$tel.'|++++|'.$address;;
    
    $data['mendianInfo']        = $mendianInfo;
    $data['logo']               = $logo;
    $data['business_licence']   = $business_licence;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$houseTypeArr,$tongchengConfig;
    $options = array(
        'site_id'           => 1,
        'user_id'           => 0,
        'name'              => '',
        'logo'              => '',
        'city_id'           => 0,
        'area_id'           => 0,
        'street_id'         => 0,
        'address'           => '',
        'latitude'          => '',
        'longitude'         => '',
        'business_hours'    => '',
        'business_licence'  => '',
        'tel'               => '',
        'shopkeeper_tel'    => '',
        'content'           => '',
    );
    $options = array_merge($options, $infoArr);
    
    if($_GET['act'] == 'edit' && $infoArr['id'] > 0){
        $photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND mendian_id={$infoArr['id']} AND type IN (5,7) "," ORDER BY type DESC,psort ASC,id ASC ",0,2);
        $photoList = array();
        $logo = $business_licence = '';
        if(is_array($photoListTmp) && !empty($photoListTmp)){
            foreach($photoListTmp as $key => $value){
                if($value['type'] == 5){
                    $options['logo'] = $value['picurl'];
                }else if($value['type'] == 7){
                    $options['business_licence'] = $value['picurl'];
                }
            }
        }
    }
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id"  onChange="getCity();">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    
    tomshowsetting(true,array('title'=>$Lang['mendian_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['mendian_user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['mendian_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['mendian_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['mendian_logo'],'name'=>'logo','value'=>$options['logo'],'msg'=>$Lang['mendian_logo_msg']),"file");
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($options['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($options['site_id']);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
            
        }
    }else if($options['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
    $areaStr.= '<tr><td width="100"><b>'.$Lang['houses_diqu'].'</b></td></tr>';
    $areaStr.= '<tr><td ><select style="width: 100px;" name="area_id" id="area_id" onChange="getStreet();">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($areaList as $key => $value){
        if($options['area_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select>';
    
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($options['area_id']);
    $areaStr.= '<select style="width: 100px;" name="street_id" id="street_id">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($streetList as $key => $value){
        if($options['street_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select></td><td>'.$Lang['houses_diqu_msg'].'</td></tr>';
    echo $areaStr;
    
    tomshowsetting(true,array('title'=>$Lang['houses_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['houses_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_latitude'],'name'=>'latitude','value'=>$options['latitude'],'msg'=>$Lang['houses_latitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_longitude'],'name'=>'longitude','value'=>$options['longitude'],'msg'=>$Lang['houses_longitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['mendian_business_hours'],'name'=>'business_hours','value'=>$options['business_hours'],'msg'=>$Lang['mendian_business_hours_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['mendian_business_licence'],'name'=>'business_licence','value'=>$options['business_licence'],'msg'=>$Lang['mendianbusiness_licence_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['mendian_tel'],'name'=>'tel','value'=>$options['tel'],'msg'=>$Lang['mendian_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['mendian_shopkeeper_tel'],'name'=>'shopkeeper_tel','value'=>$options['shopkeeper_tel'],'msg'=>$Lang['mendian_shopkeeper_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['mendian_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['mendian_content_msg']),"text");
    
    return;
}

$jsstr = <<<EOF
<script type="text/javascript">
function getCity(){
  var site_id = jq("#site_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcfangchan:ajax",
        data: "act=admin_area&site="+site_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var areaHtml = '<option value="0">{$Lang['all']}</option>';
            jq.each(json,function(k,v){
                areaHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#area_id").html(areaHtml);
            jq("#area_id").show();
        }
    });
}
function getStreet(){
  var area_id = jq("#area_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcfangchan:ajax",
        data: "act=admin_street&area_id="+area_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var streetHtml = '<option value="0">{$Lang['all']}</option>';
            jq.each(json,function(k,v){
                streetHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            console.log(streetHtml);
            jq("#street_id").html(streetHtml);
            jq("#street_id").show();
        }
    });
}
</script>
EOF;
echo $jsstr;

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['mendian_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['mendian_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['mendian_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['mendian_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['mendian_edit'],"",true);
    }else{
        tomshownavli($Lang['mendian_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['mendian_add'],$modBaseUrl."&act=add",false);
        //tomshownavli($Lang['agent_list_title'],$adminBaseUrl."&tmod=agent",false);
    }
    tomshownavfooter();
}