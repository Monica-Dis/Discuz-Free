<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=houses';
$modListUrl = $adminListUrl.'&tmod=houses';
$modFromUrl = $adminFromUrl.'&tmod=houses';

if($_GET['act'] == 'info'){
    
    $info = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($_GET['id']);
    $photoList = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND houses_id = {$info['id']} ", 'ORDER BY psort ASC,id ASC', 0, 100);
    if($info['site_id'] > 1){
        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($info['site_id']);
        $sitename = $sitesInfo['name'];
    }else{
        $sitename = $Lang['sites_one'];
    }
    if($info['user_id'] > 0){
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($info['user_id']);
    }
    
    $typeArr = explode('|', trim($info['type'], '|'));
    $typeStr = '';
    if(is_array($houseTypeArr) && !empty($houseTypeArr)){
        foreach($houseTypeArr as $key => $value){
            if(in_array($key,$typeArr)){
                $typeStr .= $houseTypeArr[$key].' ';
            }
        }
    }
    
    $fenghao = $Lang['fenghao'];
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['info'] . '</th></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_name'].$fenghao.'</b></td><td>'.$info['name'].'</td></tr>';
    if($info['user_id'] > 0){
        echo '<tr><td align="right"><b>'.$Lang['user_id'].$fenghao.'</b></td><td>'.$userInfo['nickname'].'<font color="#f00">(ID:'.$userInfo['id'].')</font></td></tr>';
    }
    echo '<tr><td align="right"><b>'.$Lang['sites_title'].$fenghao.'</b></td><td>'.$sitename.'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_type'].$fenghao.'</b></td><td>'.$typeStr.'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_diqu'].$fenghao.'</b></td><td>'.$info['area_name'].'--'.$info['street_name'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_year'].$fenghao.'</b></td><td>'.$info['year'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_average_price'].$fenghao.'</b></td><td>'.$info['average_price'].$Lang['houses_average_price_unit'].'</td></tr>';
    if($info['open_auto_average'] == 1){
        echo '<tr><td align="right"><b>'.$Lang['houses_open_auto_average'].$fenghao.'</b></td><td><font color="#0a9409">'.$Lang['houses_open_auto_average_1'].'</font></td></tr>';
    }else{
        echo '<tr><td align="right"><b>'.$Lang['houses_open_auto_average'].$fenghao.'</b></td><td><font color="#f00">'.$Lang['houses_open_auto_average_0'].'</font></td></tr>';
    }
    
    echo '<tr><td align="right"><b>'.$Lang['houses_chanquan'].$fenghao.'</b></td><td>'.$info['chanquan'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_address'].$fenghao.'</b></td><td>'.$info['address'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_developer_company'].$fenghao.'</b></td><td>'.$info['developer_company'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_parking_space'].$fenghao.'</b></td><td>'.$info['parking_space'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_plot_ratio'].$fenghao.'</b></td><td>'.$info['plot_ratio'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_greening_rate'].$fenghao.'</b></td><td>'.$info['greening_rate'].'%</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_property_company'].$fenghao.'</b></td><td>'.$info['property_company'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_property_price'].$fenghao.'</b></td><td>'.$info['property_price'].$Lang['houses_property_price_unit'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['houses_property_tel'].$fenghao.'</b></td><td>'.$info['property_tel'].'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['update_time'].$fenghao.'</b></td><td>'.dgmdate($info['update_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
    echo '<tr><td align="right"><b>'.$Lang['add_time'].$fenghao.'</b></td><td>'.dgmdate($info['add_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td></tr>';
    
    echo '<tr><td align="right"><b>'.$Lang['houses_photo'].$fenghao.'</b></td><td>';
    if(is_array($photoList) && !empty($photoList)){
        foreach($photoList as $key => $value){
            echo '<a style="margin-right:10px;" href="' . $value['picurlTmp'] . '" target="_blank"><img height="60" src="' . $value['picurlTmp'] . '"></a>';
        }
    }
    echo '</td></tr>';
    
    showtablefooter(); /*dism��taobao��com*/
    
}else if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['update_time']  = TIMESTAMP;
        $insertData['shenhe_status']= 1;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_houses')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $housesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($housesInfo);
        $updateData['update_time']  = TIMESTAMP;
        if(C::t('#tom_tcfangchan#tom_tcfangchan_houses')->update($housesInfo['id'],$updateData)){
            if($housesInfo['name'] != $updateData['name']){
                $newHousesName = $updateData['name'];
                $fangchanList = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_search_list(" AND houses_id={$housesInfo['id']} ", 'ORDER BY id DESC');
                if(is_array($fangchanList) && !empty($fangchanList)){
                    foreach($fangchanList as $key => $value){
                        
                        $updateData = array();
                        $updateData['houses_name'] = $newHousesName;
                        $updateData['search_text'] = $value['title'].'|++++|'.$value['house_no'].'|++++|'.$newHousesName;
                        C::t('#tom_tcfangchan#tom_tcfangchan')->update($value['id'],$updateData);
                    }
                }
            }
        }
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($housesInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status']    = 1;
    $updateData['status']           = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_houses')->update($_GET['id'],$updateData);
    
    $housesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($housesInfo['user_id']);

    $shenhe = str_replace('{NAME}', $housesInfo['name'], $Lang['index_template_houses_shenhe_ok']);
    $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$housesInfo['site_id'].'&mod=housesinfo&houses_id='.$housesInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
    
    $cpmsg = $Lang['act_success'];
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$housesInfo['site_id']}&mod=housesinfo&houses_id=".$housesInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcfangchanConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['tcfangchan_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['tcfangchan_shenhe_tz_fail'];
        }
    }
    
    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $housesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($housesInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcfangchan#tom_tcfangchan_houses')->update($_GET['id'],$updateData);
        
        $shenhe = str_replace('{NAME}', $housesInfo['name'], $Lang['index_template_houses_shenhe_no']);
        $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$housesInfo['site_id'].'&mod=housesedit&houses_id='.$housesInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        
        $cpmsg = $Lang['act_success'];
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$housesInfo['site_id']}&mod=housesedit&houses_id=".$housesInfo['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tcfangchan_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tcfangchan_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.$Lang['tcfangchan_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tcfangchan_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcfangchan_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status']       = 1;
    $updateData['update_time']  = TIMESTAMP;
    C::t('#tom_tcfangchan#tom_tcfangchan_houses')->update($_GET['id'], $updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status']       = 0;
    $updateData['update_time']  = TIMESTAMP;
    C::t('#tom_tcfangchan#tom_tcfangchan_houses')->update($_GET['id'], $updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcfangchan#tom_tcfangchan_houses')->delete_by_id($_GET['id']);
    C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_houses_id($_GET['id']);
    DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET houses_id=0 WHERE houses_id = {$_GET['id']} ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'addphoto'){
    if(submitcheck('submit')){
        
        $id       = isset($_GET['id'])? intval($_GET['id']):0;
        $psort    = isset($_GET['psort'])? intval($_GET['psort']):10;
        $picurl   = tomuploadFile("picurl");
        
        $insertData = array();
        $insertData['houses_id']    = $id;
        $insertData['type']         = 1;
        $insertData['picurl']       = $picurl;
        $insertData['psort']        = $psort;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_photo')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl.'&act=photo&id='.$id, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        tomshownavheader();
        tomshownavli($Lang['houses_photo_add'],'',true);
        tomshownavfooter();
        showformheader($modFromUrl.'&act=addphoto&id='.$_GET['id'],'enctype');
        showtableheader();
        
        tomshowsetting(true,array('title'=>$Lang['houses_photo'],'name'=>'picurl','value'=>'','msg'=>$Lang['houses_photo_msg']),"file");
        tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'psort','value'=>10,'msg'=>$Lang['sort_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl.'&act=photo&id='.$_GET['houses_id'], 'succeed');
    
}else if($_GET['act'] == 'photo'){
    
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $id         = intval($_GET['id'])>0? intval($_GET['id']):0;
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $housesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($id);
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_count(" AND houses_id = {$id} ");
    $photoList = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND houses_id = {$id} "," ORDER BY psort ASC,id ASC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&act=photo&site_id={$site_id}";
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' .$housesInfo['name'].'&gt;'. $Lang['houses_photo'] . '</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    tomshownavheader();
    tomshownavli($Lang['houses_photo_add'],$modBaseUrl."&act=addphoto&id=".$id,false);
    tomshownavfooter();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['houses_photo'] . '</th>';
    echo '<th>' . $Lang['sort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($photoList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a href="' . $value['picurlTmp'] . '" target="_blank"><img height="40" src="' . $value['picurlTmp'] . '"></a></td>';
        echo '<td>' . $value['psort'] . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&houses_id='.$id.'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}else if($_GET['act'] == 'guanzulist'){
    
    $houses_id      = intval($_GET['houses_id'])>0? intval($_GET['houses_id']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $housesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_houses")->fetch_by_id($houses_id);
    
    $where = " AND houses_id = {$houses_id} ";
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_houses_guanzu')->fetch_all_count($where);
    $guanzuList = C::t('#tom_tcfangchan#tom_tcfangchan_houses_guanzu')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);

    $modBasePageUrl = $modBaseUrl."&act=guanzulist&houses_id={$houses_id}";
    
    __create_nav_html();
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $housesInfo['name'] .'&nbsp;&nbsp;&gt;&gt;&gt;&nbsp;&nbsp;'.$Lang['index_guanzulist_title']. '</th></tr>';
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['index_user'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($guanzuList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f70404">(ID:'.$value['user_id']. ')</font></td>';
        echo '<td>' . dgmdate($value['add_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
        
        echo '<td> -- </td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $houses_id      = isset($_GET['houses_id'])? intval($_GET['houses_id']):0;
    $min_price      = isset($_GET['min_price'])? intval($_GET['min_price']):'';
    $max_price      = isset($_GET['max_price'])? intval($_GET['max_price']):'';
    $area_id        = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id      = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $house_type     = isset($_GET['house_type'])? intval($_GET['house_type']):0;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if($houses_id > 0){
        $where.= " AND id={$houses_id} ";
    }
    if(intval($min_price) > 0){
        $min_price = intval($min_price);
        $where.= " AND average_price>={$min_price} ";
    }
    if(intval($max_price) > 0){
        $max_price = intval($max_price);
        $where.= " AND average_price<={$max_price} ";
    }
    if($area_id > 0){
        $where.= " AND area_id={$area_id} ";
    }
    if($street_id > 0){
        $where.= " AND street_id={$street_id} ";
    }
    if($house_type > 0){
        $house_type = str_replace(array('%', '_'),'',$house_type);
        $where .= " AND type LIKE '%|{$house_type}|%'";
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    if($status > 0){
        if($status == 1){
            $where.= " AND status=1 ";
        }
        if($status == 2){
            $where.= " AND status=0 ";
        }
    }
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_count($where, $name);
    $housesList = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_list($where," ORDER BY site_id ASC,id DESC ",$start,$pagesize, $name);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&min_price={$min_price}&max_price={$max_price}&house_type={$house_type}&area_id={$area_id}&street_id={$street_id}&status={$status}&shenhe_status={$shenhe_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
    
    $site_select_1 = '';
    if($site_id == 1){
        $site_select_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id" onChange="getCity();">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_select_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    echo '<tr><td width="100" align="right"><b>'.$Lang['houses_name'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="name" value="'.$name.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['houses_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="houses_id" value="'.$houses_id.'"></td></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['newhouses_price'].'</b></td><td width="100"><input type="text" style="width:124px;" name="min_price" value="'.$min_price.'" placeholder="'.$Lang['newhouses_min_price_msg'].'"><input type="text" style="width:124px;" name="max_price" value="'.$max_price.'" placeholder="'.$Lang['newhouses_max_price_msg'].'"></td></tr>';
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
    $areaStr.= '<tr><td width="100" align="right"><b>'.$Lang['newhouses_search_diqu'].'</b></td>';
    $areaStr.= '<td ><select style="width: 130px;" name="area_id" id="area_id" onChange="getStreet();">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($areaList as $key => $value){
        if($area_id == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select>';
    
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
    $areaStr.= '<select style="width: 130px;" name="street_id" id="street_id">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($streetList as $key => $value){
        if($street_id == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select></td></tr>';
    echo $areaStr;
    
    $houseingTypeStr = '<tr><td width="100" align="right"><b>'.$Lang['newhouses_type'].'</b></td>';
    $houseingTypeStr.= '<td><select style="width: 260px;" name="house_type" id="house_type">';
    $houseingTypeStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach($houseTypeArr as $key => $value){
        if($house_type == $key){
            $houseingTypeStr.=  '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            $houseingTypeStr.=  '<option value="'.$key.'" >'.$value.'</option>';
        }
    }
    $houseingTypeStr.= '</select></td></tr>';
    echo $houseingTypeStr;
    
    $status_shenhe_1 = $status_shenhe_2 = $status_shenhe_3 = '';
    if($shenhe_status == 1){
        $status_shenhe_1 = 'selected';
    }else if($shenhe_status == 2){
        $status_shenhe_2 = 'selected';
    }else if($shenhe_status == 3){
        $status_shenhe_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$status_shenhe_1.'>'.$Lang['shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$status_shenhe_2.'>'.$Lang['shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$status_shenhe_3.'>'.$Lang['shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    $status_1 = $status_2 = '';
    if($status == 1){
        $status_1 = 'selected';
    }else if($status == 2){
        $status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['index_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['index_status_0'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['houses_name'] . '</th>';
    echo '<th>' . $Lang['user_id'] . '</th>';
    echo '<th>' . $Lang['houses_type'] . '</th>';
    echo '<th>' . $Lang['houses_average_price'] . '</th>';
    echo '<th>' . $Lang['houses_year'] . '</th>';
    echo '<th>' . $Lang['houses_chanquan'] . '</th>';
    echo '<th width="120px;">' . $Lang['houses_address'] . '</th>';
    echo '<th>' . $Lang['shenhe_status'] . '</th>';
    echo '<th>' . $Lang['index_status'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($housesList as $key => $value) {
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $typeArr = explode('|', trim($value['type'], '|'));
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $value['name'] . '</td>';
        if($value['user_id'] > 0){
            echo '<td>' . $userInfo['nickname'] .'<font color="#f00">(ID:'.$value['user_id'].')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if(is_array($typeArr) && !empty($typeArr)){
            echo '<td>';
            foreach($typeArr as $k => $v){
                echo '<div style="line-height:20px; color:#0a9409;">'.$houseTypeArr[$v].'</div>';
            }
            echo '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '<td>' . $value['average_price'] .$Lang['houses_average_price_unit']. '</td>';
        echo '<td>' . $value['year'] .$Lang['year']. '</td>';
        echo '<td>' . $value['chanquan'] .$Lang['year']. '</td>';
        echo '<td>' . $value['address'] . '</td>';
        
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_status_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_status_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<td ><font color="#0a9409">' . $Lang['shenhe_status_1']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 2 ){
            echo '<td ><font color="#f70404">' . $Lang['shenhe_status_2']. '</font>'.$sheheBtnStr.'</td>';
        }else if($value['shenhe_status'] == 3 ){
            echo '<td ><font color="#f70404">' . $Lang['shenhe_status_3']. '</font>'.$sheheBtnStr.'</td>';
        }
        
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['index_status_1']. '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#f70404">' . $Lang['index_status_0']. '</font></a>)</td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['index_status_0']. '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#0a9409">' . $Lang['index_status_1']. '</font></a>)</td>';
        }
        
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=info&id='.$value['id'].'" target="_blank">' . $Lang['info']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=photo&id='.$value['id'].'">' . $Lang['houses_photo_title']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=guanzulist&houses_id='.$value['id'].'">' . $Lang['index_guanzulist_title']. '</a><br/>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    global $tongchengConfig;
    $data = array();
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $year               = isset($_GET['year'])? intval($_GET['year']):0;
    $average_price      = isset($_GET['average_price'])? floatval($_GET['average_price']):0.00;
    $open_auto_average  = isset($_GET['open_auto_average'])? intval($_GET['open_auto_average']):0;
    $chanquan           = isset($_GET['chanquan'])? intval($_GET['chanquan']):0;
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $developer_company  = isset($_GET['developer_company'])? addslashes($_GET['developer_company']):'';
    $parking_space      = isset($_GET['parking_space'])? intval($_GET['parking_space']):0;
    $plot_ratio         = isset($_GET['plot_ratio'])? floatval($_GET['plot_ratio']):0.00;
    $greening_rate      = isset($_GET['greening_rate'])? intval($_GET['greening_rate']):0;
    $property_company   = isset($_GET['property_company'])? addslashes($_GET['property_company']):'';
    $property_price     = isset($_GET['property_price'])? floatval($_GET['property_price']):0.00;
    $property_tel       = isset($_GET['property_tel'])? addslashes($_GET['property_tel']):'';
    
    $typeStr = '';
    if(is_array($_GET['type']) && !empty($_GET['type'])){
        $typeArr = array();
        foreach($_GET['type'] as $key => $value){
            if(!empty($value)){
                $typeArr[] = $value;
            }
        }
        if(is_array($typeArr) && !empty($typeArr)){
            $typeStr = '|'.implode('|', $typeArr).'|';
        }
    }
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $city_id = $__SitesInfo['city_id'];
            }
        }
    }else if($site_id == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $city_id = $tongchengConfig['city_id'];
        }
    }
    
    $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
    
    $data['site_id']            = $site_id;
    $data['name']               = $name;
    $data['user_id']            = $user_id;
    $data['type']               = $typeStr;
    $data['city_id']            = $city_id;
    $data['area_id']            = $area_id;
    $data['area_name']          = $areaInfo['name'];
    $data['street_id']          = $street_id;
    $data['street_name']        = $streetInfo['name'];
    $data['year']               = $year;
    $data['average_price']      = $average_price;
    $data['open_auto_average']  = $open_auto_average;
    $data['chanquan']           = $chanquan;
    $data['address']            = $address;
    $data['latitude']           = $latitude;
    $data['longitude']          = $longitude;
    $data['developer_company']  = $developer_company;
    $data['parking_space']      = $parking_space;
    $data['plot_ratio']         = $plot_ratio;
    $data['greening_rate']      = $greening_rate;
    $data['property_company']   = $property_company;
    $data['property_price']     = $property_price;
    $data['property_tel']       = $property_tel;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$houseTypeArr,$tongchengConfig;
    $options = array(
        'site_id'           => 1,
        'name'              => '',
        'user_id'           => '',
        'type'              => '',
        'city_id'           => 0,
        'area_id'           => 0,
        'street_id'         => 0,
        'year'              => 0,
        'average_price'     => 0.00,
        'open_auto_average' => 0,
        'chanquan'          => 0,
        'address'           => '',
        'latitude'          => '',
        'longitude'         => '',
        'developer_company' => '',
        'parking_space'     => 0,
        'plot_ratio'        => 0.00,
        'greening_rate'     => 0,
        'property_company'  => '',
        'property_price'    => 0.00,
        'property_tel'      => '',
    );
    $options = array_merge($options, $infoArr);
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id"  onChange="getCity();">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    tomshowsetting(true,array('title'=>$Lang['houses_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['houses_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['user_id_msg']),"input");
    
    $typeArr = explode('|', $options['type']);
    $typeStr = '<tr class="header"><th>'.$Lang['houses_type'].'</th><th></th></tr>';
    $typeStr.= '<tr><td width="300">';
    foreach($houseTypeArr as $key => $value){
        if(is_array($typeArr) && !empty($typeArr) && in_array($key, $typeArr)){
            $typeStr.=  '<label><input type="checkbox" name="type[]" value="'.$key.'" checked>'.$value.'</label>';
        }else{
            $typeStr.=  '<label><input type="checkbox" name="type[]" value="'.$key.'">'.$value.'</label>';
        }
    }
    $typeStr.= '</td><td>'.$Lang['houses_type_msg'].'</td></tr>';
    echo $typeStr;
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($options['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($options['site_id']);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
            
        }
    }else if($options['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
    $areaStr.= '<tr><td width="100"><b>'.$Lang['houses_diqu'].'</b></td></tr>';
    $areaStr.= '<tr><td ><select style="width: 100px;" name="area_id" id="area_id" onChange="getStreet();">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($areaList as $key => $value){
        if($options['area_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select>';
    
    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($options['area_id']);
    $areaStr.= '<select style="width: 100px;" name="street_id" id="street_id">';
    $areaStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach ($streetList as $key => $value){
        if($options['street_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select></td><td>'.$Lang['houses_diqu_msg'].'</td></tr>';
    echo $areaStr;
    
    tomshowsetting(true,array('title'=>$Lang['houses_year'],'name'=>'year','value'=>$options['year'],'msg'=>$Lang['houses_year_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_average_price'],'name'=>'average_price','value'=>$options['average_price'],'msg'=>$Lang['houses_average_price_msg']),"input");
    $open_auto_average_item = array(1=>$Lang['houses_open_auto_average_1'], 0=>$Lang['houses_open_auto_average_0']);
    tomshowsetting(true,array('title'=>$Lang['houses_open_auto_average'],'name'=>'open_auto_average','value'=>$options['open_auto_average'],'msg'=>$Lang['houses_open_auto_average_msg'],'item'=>$open_auto_average_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['houses_chanquan'],'name'=>'chanquan','value'=>$options['chanquan'],'msg'=>$Lang['houses_chanquan_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['houses_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_latitude'],'name'=>'latitude','value'=>$options['latitude'],'msg'=>$Lang['houses_latitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_longitude'],'name'=>'longitude','value'=>$options['longitude'],'msg'=>$Lang['houses_longitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_developer_company'],'name'=>'developer_company','value'=>$options['developer_company'],'msg'=>$Lang['houses_developer_company_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_parking_space'],'name'=>'parking_space','value'=>$options['parking_space'],'msg'=>$Lang['houses_parking_space_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_plot_ratio'],'name'=>'plot_ratio','value'=>$options['plot_ratio'],'msg'=>$Lang['houses_plot_ratio_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_greening_rate'],'name'=>'greening_rate','value'=>$options['greening_rate'],'msg'=>$Lang['houses_greening_rate_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_property_company'],'name'=>'property_company','value'=>$options['property_company'],'msg'=>$Lang['houses_property_company_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_property_price'],'name'=>'property_price','value'=>$options['property_price'],'msg'=>$Lang['houses_property_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['houses_property_tel'],'name'=>'property_tel','value'=>$options['property_tel'],'msg'=>$Lang['houses_property_tel_msg']),"input");
    
    return;
}

$jsstr = <<<EOF
<script type="text/javascript">
function getCity(){
  var site_id = jq("#site_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcfangchan:ajax",
        data: "act=admin_area&site="+site_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var areaHtml = '<option value="0">{$Lang['all']}</option>';
            jq.each(json,function(k,v){
                areaHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#area_id").html(areaHtml);
            jq("#area_id").show();
        }
    });
}
function getStreet(){
  var area_id = jq("#area_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcfangchan:ajax",
        data: "act=admin_street&area_id="+area_id,
        dataType : "jsonp",
        jsonpCallback:"jsonpCallback",
        cache : false,
        success: function(json){
            var streetHtml = '<option value="0">{$Lang['all']}</option>';
            jq.each(json,function(k,v){
                streetHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            console.log(streetHtml);
            jq("#street_id").html(streetHtml);
            jq("#street_id").show();
        }
    });
}
</script>
EOF;
echo $jsstr;

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['houses_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['houses_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['houses_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['houses_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['houses_edit'],"",true);
    }else{
        tomshownavli($Lang['houses_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['houses_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}