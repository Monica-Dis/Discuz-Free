<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=jubao'; 
$modListUrl = $adminListUrl.'&tmod=jubao';
$modFromUrl = $adminFromUrl.'&tmod=jubao';

if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcfangchan#tom_tcfangchan_jubao')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $page         = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_jubao')->fetch_all_count('');
    $jubaoList = C::t('#tom_tcfangchan#tom_tcfangchan_jubao')->fetch_all_list(""," ORDER BY id DESC ",$start,$pagesize);

    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['jubao_user'] . '</th>';
    echo '<th>' . $Lang['jubao_type'] . '</th>';
    echo '<th>' . $Lang['jubao_title'] . '</th>';
    echo '<th>' . $Lang['jubao_content'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';

    $i = 1;
    foreach ($jubaoList as $key => $value) {
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($value['tcfangchan_id']);
        $needsInfo = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($value['needs_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f00">(ID:'.$value['user_id']. ')</font></td>';
        if($value['type'] == 1){
            echo '<td>' . $Lang['jubao_type_1'] . '</td>';
            echo '<td><a href="'.$adminBaseUrl.'&tmod=index&tcfangchan_id='.$value['tcfangchan_id']. '" target="_blank">' . $tcfangchanInfo['title'] .'<font color="#f00">(ID:'.$value['tcfangchan_id']. ')</font></a></td>';
        }else if($value['type'] == 2){
            echo '<td>' . $Lang['jubao_type_2'] . '</td>';
            echo '<td><a href="'.$adminBaseUrl.'&tmod=needs&needs_id='.$value['needs_id']. '" target="_blank">' . cutstr($needsInfo['content'],30,"...") .'<font color="#f00">(ID:'.$value['needs_id']. ')</font></a></td>';
        }
        echo '<td>' . $value['content'] .'</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);

    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    
    tomshownavli($Lang['jubao_list_title'],$modBaseUrl,true);
    
    tomshownavfooter();
}