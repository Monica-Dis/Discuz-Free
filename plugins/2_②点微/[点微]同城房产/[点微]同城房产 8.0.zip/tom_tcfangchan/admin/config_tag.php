<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=config_tag';
$modListUrl = $adminListUrl.'&tmod=config_tag';
$modFromUrl = $adminFromUrl.'&tmod=config_tag';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $configInfo = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($configInfo);
        C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->update($configInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($configInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'import'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/config/import.data.php';
    
    foreach ($configTagArr as $key => $value){
        
        foreach ($value as $k => $v){
            $insertData = array();
            $insertData['name']         = $v;
            $insertData['model_id']     = $key;
            $insertData['tsort']        = $k;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->insert($insertData);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $model_id   = isset($_GET['model_id'])? addslashes($_GET['model_id']):'ershoufang';
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($model_id)){
        $where.= " AND model_id = '{$model_id}' ";
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_all_count($where);
    $configTagList = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_all_list($where," ORDER BY tsort ASC,id DESC ",$start,$pagesize);
    
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $Lang['config_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=import&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['config_import_1'].'</font></a></li>';
    echo '</ul></td></tr>';
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
    showtablefooter(); /*dism��taobao��com*/
    
    $modBasePageUrl = $modBaseUrl."&model_id={$model_id}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    $modelIdsArr = array(
        'ershoufang' => $Lang['ershoufang'],
        'chuzu' => $Lang['chuzu'],
        'shangpu' => $Lang['shangpu'],
        'xiezilou' => $Lang['xiezilou'],
        'changfang' => $Lang['changfang'],
        'cangku' => $Lang['cangku'],
        'tudi' => $Lang['tudi'],
        'newhouses' => $Lang['newhouses'],
        ) ;
    $modelIdsStr = '<tr><td width="100" align="right"><b>'.$Lang['config_tag_model'].'</b></td>';
    $modelIdsStr.= '<td><select style="width: 260px;" name="model_id" id="model_id">';
    $modelIdsStr.=  '<option value="0">'.$Lang['all'].'</option>';
    foreach($modelIdsArr as $key => $value){
        if($model_id == $key){
            $modelIdsStr.=  '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            $modelIdsStr.=  '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    $modelIdsStr.= '</select></td></tr>';
    echo $modelIdsStr;
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['config_tag_name'] . '</th>';
    echo '<th>' . $Lang['config_tag_model'] . '</th>';
    echo '<th>' . $Lang['sort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($configTagList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $modelIdsArr[$value['model_id']] . '</td>';
        echo '<td>' . $value['tsort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function import_confirm(url){
  var r = confirm("{$Lang['config_import_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    global $Lang;
    $data = array();
    
    $model_id       = isset($_GET['model_id'])? addslashes($_GET['model_id']):'';
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $tsort          = isset($_GET['tsort'])? intval($_GET['tsort']):10;
    
    $data['model_id']   = $model_id;
    $data['name']       = $name;
    $data['tsort']      = $tsort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'model_id'      => '',
        'name'          => '',
        'tsort'         => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['config_tag_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['config_tag_name_msg']),"input");
    
    $modelIdsArr = array(
        'ershoufang' => $Lang['ershoufang'],
        'chuzu' => $Lang['chuzu'],
        'shangpu' => $Lang['shangpu'],
        'xiezilou' => $Lang['xiezilou'],
        'changfang' => $Lang['changfang'],
        'cangku' => $Lang['cangku'],
        'tudi' => $Lang['tudi'],
        'newhouses' => $Lang['newhouses'],
        ) ;
    tomshowsetting(true,array('title'=>$Lang['index_model_id'],'name'=>'model_id','value'=>$options['model_id'],'msg'=>$Lang['index_model_id_msg'],'item'=>$modelIdsArr),"select");
    
    tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'tsort','value'=>$options['tsort'],'msg'=>$Lang['sort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['config_tag_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['config_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['config_tag_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['config_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['config_edit'],"",true);
    }else{
        tomshownavli($Lang['config_tag_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['config_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}