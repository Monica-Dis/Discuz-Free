<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcfangchan'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcfangchan&pmod=admin';
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcfangchan&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcfangchan&pmod=admin';

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){}else{
    echo " no install https://dism.taobao.com/?@tom_tongcheng.plugin";exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/class/function.a.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/class/function.core.php';
$tcfangchanConfig = get_plugin_config($pluginid);
$Lang = formatLang($Lang);

$fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
if($fangchanSetting && $fangchanSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_setting')->insert($insertData);
    $fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
}

$tongchengPlugin = C::t('#tom_tcfangchan#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/config/config.data.php';

if($_GET['tmod'] == 'index'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/index.php';
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/addon.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/focuspic.php';
}else if($_GET['tmod'] == 'houses'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/houses.php';
}else if($_GET['tmod'] == 'newhouses'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/newhouses.php';
}else if($_GET['tmod'] == 'agent'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/agent.php';
}else if($_GET['tmod'] == 'agentvip'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/agentvip.php';
}else if($_GET['tmod'] == 'mendian'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/mendian.php';
}else if($_GET['tmod'] == 'mendianvip'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/mendianvip.php';
}else if($_GET['tmod'] == 'jubao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/jubao.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/order.php';
}else if($_GET['tmod'] == 'doDaoFangchan'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/doDaoFangchan.php';
}else if($_GET['tmod'] == 'doDaoNewhousesGuanzu'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/doDaoNewhousesGuanzu.php';
}else if($_GET['tmod'] == 'trade'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/trade.php';
}else if($_GET['tmod'] == 'config'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/config.php';
}else if($_GET['tmod'] == 'config_tag'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/config_tag.php';
}else if($_GET['tmod'] == 'diynav'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/diynav.php';
}else if($_GET['tmod'] == 'common'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/common.php';
}else if($_GET['tmod'] == 'guanggao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/guanggao.php';
}else if($_GET['tmod'] == 'adviser'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/adviser.php';
}else if($_GET['tmod'] == 'newhouses_manage'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/newhouses_manage.php';
}else if($_GET['tmod'] == 'needs'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/needs.php';
}else if($_GET['tmod'] == 'doDaoNeeds'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/doDaoNeeds.php';
}else if($_GET['tmod'] == 'setting'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/setting.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/admin/index.php';
}