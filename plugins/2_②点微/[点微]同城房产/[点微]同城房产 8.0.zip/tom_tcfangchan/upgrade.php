<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = '';
$tom_tcfangchan_agent_field = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_field();
if (!isset($tom_tcfangchan_agent_field['vip_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_agent')." ADD `vip_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_agent_field['top_status'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_agent')." ADD `top_status` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_agent_field['top_time'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_agent')." ADD `top_time` int(11) unsigned DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_agent_field['expire_status'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_agent')." ADD `expire_status` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_agent_field['expire_time'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_agent')." ADD `expire_time` int(11) unsigned DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_agent_field['vip_add_time'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_agent')." ADD `vip_add_time` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_agent_field['mendian_name'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_agent')." ADD `mendian_name` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcfangchan_agent_field['mendian_shenhe_status'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_agent')." ADD `mendian_shenhe_status` tinyint(4) DEFAULT '1';\n";
}
if (!isset($tom_tcfangchan_agent_field['mendian_shenhe_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_agent')." ADD `mendian_shenhe_id` int(11) DEFAULT '0';\n";
}

$tom_tcfangchan_order_field = C::t('#tom_tcfangchan#tom_tcfangchan_order')->fetch_all_field();
if (!isset($tom_tcfangchan_order_field['agent_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_order')." ADD `agent_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_order_field['agent_vip_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_order')." ADD `agent_vip_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_order_field['agent_vip_days'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_order')." ADD `agent_vip_days` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_order_field['top_zhekou'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_order')." ADD `top_zhekou` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_order_field['adviser_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_order')." ADD `adviser_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_order_field['needs_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_order')." ADD `needs_id` int(11) DEFAULT '0';\n";
}

$tom_tcfangchan_mendian_field = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_field();
if (!isset($tom_tcfangchan_mendian_field['vip_add_time'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_mendian')." ADD `vip_add_time` int(11) unsigned DEFAULT '0';\n";
}

$tom_tcfangchan_mendian_vip_field = C::t('#tom_tcfangchan#tom_tcfangchan_mendian_vip')->fetch_all_field();
if (!isset($tom_tcfangchan_mendian_vip_field['top_zhekou'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_mendian_vip')." ADD `top_zhekou` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_mendian_vip_field['free_shenhe'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_mendian_vip')." ADD `free_shenhe` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_mendian_vip_field['open_visitor'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_mendian_vip')." ADD `open_visitor` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_mendian_vip_field['total_agent_fabu_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_mendian_vip')." ADD `total_agent_fabu_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_mendian_vip_field['max_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_mendian_vip')." ADD `max_num` int(11) DEFAULT '0';\n";
}

$tom_tcfangchan_field = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_field();
if (isset($tom_tcfangchan_field['mianji']) && $tom_tcfangchan_field['mianji']['Type'] == 'int(11)') {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan')." CHANGE `mianji` `mianji` decimal(10,2) DEFAULT '0.00';\n";
}
if (isset($tom_tcfangchan_field['price']) && $tom_tcfangchan_field['price']['Type'] == 'int(11)') {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan')." CHANGE `price` `price` decimal(10,1) DEFAULT '0.0';\n";
}
if (isset($tom_tcfangchan_field['zhuanrang_price']) && $tom_tcfangchan_field['zhuanrang_price']['Type'] == 'int(11)') {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan')." CHANGE `zhuanrang_price` `zhuanrang_price` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcfangchan_field['deleted'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan')." ADD `deleted` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_field['pay_type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan')." ADD `pay_type` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_field['client_ip_port'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan')." ADD `client_ip_port` varchar(255) DEFAULT NULL;\n";
}

$tom_tcfangchan_photo_field = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_field();
if (isset($tom_tcfangchan_photo_field['house_mianji']) && $tom_tcfangchan_photo_field['house_mianji']['Type'] == 'int(11)') {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_photo')." CHANGE `house_mianji` `house_mianji` decimal(10,2) DEFAULT '0.00';\n";
}

$tom_tcfangchan_houses_field = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_field();
if (!isset($tom_tcfangchan_houses_field['user_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_houses')." ADD `user_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_houses_field['shenhe_status'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_houses')." ADD `shenhe_status` tinyint(4) DEFAULT '1';\n";
}

$tom_tcfangchan_newhouses_field = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_field();
if (!isset($tom_tcfangchan_newhouses_field['open_sale_adviser'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_newhouses')." ADD `open_sale_adviser` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_newhouses_field['sale_adviser_price'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_newhouses')." ADD `sale_adviser_price` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcfangchan_newhouses_field['sale_adviser_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_newhouses')." ADD `sale_adviser_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_newhouses_field['sale_adviser_price_list'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_newhouses')." ADD `sale_adviser_price_list` text;\n";
}
if (!isset($tom_tcfangchan_newhouses_field['user_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_newhouses')." ADD `user_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_newhouses_field['admin_edit'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_newhouses')." ADD `admin_edit` int(11) DEFAULT '1';\n";
}

$tom_tcfangchan_log_field = C::t('#tom_tcfangchan#tom_tcfangchan_log')->fetch_all_field();
if (!isset($tom_tcfangchan_log_field['needs_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_log')." ADD `needs_id` int(11) DEFAULT '0';\n";
}

$tom_tcfangchan_jubao_field = C::t('#tom_tcfangchan#tom_tcfangchan_jubao')->fetch_all_field();
if (!isset($tom_tcfangchan_jubao_field['type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_jubao')." ADD `type` tinyint(4) DEFAULT '1';\n";
}
if (!isset($tom_tcfangchan_jubao_field['needs_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_jubao')." ADD `needs_id` int(11) DEFAULT '0';\n";
}

$tom_tcfangchan_attr_field = C::t('#tom_tcfangchan#tom_tcfangchan_attr')->fetch_all_field();
if (!isset($tom_tcfangchan_attr_field['attr_rent_unit'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_attr')." ADD `attr_rent_unit` int(11) DEFAULT '1';\n";
}

if (!empty($sql)) {
	runquery($sql);
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_tom_tcfangchan_agent_vip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `days` int(11) DEFAULT '0',
  `fabu_num` int(11) DEFAULT '0',
  `total_fabu_num` int(11) DEFAULT '0',
  `refresh_num` int(11) DEFAULT '0',
  `top_zhekou` int(11) DEFAULT '0',
  `free_shenhe` tinyint(4) DEFAULT '0',
  `open_visitor` tinyint(4) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `status` int(11) DEFAULT '0',
  `vsort` int(11) unsigned DEFAULT '100',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcfangchan_visitor_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tcfangchan_id` int(11) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `update_time` int(11) unsigned DEFAULT '0',
  `last_smstp_time` int(11) unsigned DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcfangchan_newhouses_adviser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `newhouses_id` int(11) DEFAULT '0',
  `newhouses_name` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `sub_desc` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `wx` varchar(255) DEFAULT NULL,
  `work_picurl` varchar(255) DEFAULT NULL,
  `wx_qrcode` varchar(255) DEFAULT NULL,
  `asort` int(11) DEFAULT '10',
  `status` tinyint(4) DEFAULT '0',
  `pay_status` tinyint(4) DEFAULT '0',
  `shenhe_status` tinyint(4) DEFAULT '0',
  `expire_status` tinyint(4) DEFAULT '3',
  `expire_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_newhouses_id` (`newhouses_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcfangchan_newhouses_manage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `beizu` text,
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
   
CREATE TABLE IF NOT EXISTS `pre_tom_tcfangchan_needs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `wx` varchar(255) DEFAULT NULL,
  `admin_edit` int(11) DEFAULT '0',
  `content` text,
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `street_id` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT '',
  `clicks` int(11) DEFAULT '0',
  `expire_status` tinyint(4) DEFAULT '0',
  `expire_time` int(11) DEFAULT '0',
  `pay_status` tinyint(4) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `refresh_time` int(11) DEFAULT '0',
  `top_status` int(11) DEFAULT '0',
  `top_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '1000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_pay_status` (`pay_status`),
  KEY `idx_top_status` (`top_status`),
  KEY `idx_top_time` (`top_time`),
  KEY `idx_refresh_time` (`refresh_time`),
  KEY `idx_type` (`type`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcfangchan_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `open_video` tinyint(4) DEFAULT '0',
  `open_vr` tinyint(4) DEFAULT '0',
  `open_house_no` tinyint(4) DEFAULT '0',
  `open_house_tel` tinyint(4) DEFAULT '0',
  `open_attr_chanquan` tinyint(4) DEFAULT '0',
  `open_attr_elevator` tinyint(4) DEFAULT '0',
  `mendianinfo_share_title` varchar(255) DEFAULT NULL,
  `mendianinfo_share_desc` varchar(255) DEFAULT NULL,
  `agentinfo_share_title` varchar(255) DEFAULT NULL,
  `agentinfo_share_desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$sql = '';
$tom_tcfangchan_newhouses_adviser_field = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_field();
if (!isset($tom_tcfangchan_newhouses_adviser_field['wx_qrcode'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_newhouses_adviser')." ADD `wx_qrcode` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcfangchan_newhouses_adviser_field['expire_status'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_newhouses_adviser')." ADD `expire_status` tinyint(4) DEFAULT '3';\n";
}
if (!isset($tom_tcfangchan_newhouses_adviser_field['expire_time'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_newhouses_adviser')." ADD `expire_time` int(11) unsigned DEFAULT '0';\n";
}

$tom_tcfangchan_agent_vip_field = C::t('#tom_tcfangchan#tom_tcfangchan_agent_vip')->fetch_all_field();
if (!isset($tom_tcfangchan_agent_vip_field['total_fabu_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_agent_vip')." ADD `total_fabu_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_agent_vip_field['max_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_agent_vip')." ADD `max_num` int(11) DEFAULT '0';\n";
}

$tom_tcfangchan_needs_field = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_field();
if (!isset($tom_tcfangchan_needs_field['client_ip_port'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_needs')." ADD `client_ip_port` varchar(255) DEFAULT NULL;\n";
}

$tom_tcfangchan_setting_field = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_all_field();
if (!isset($tom_tcfangchan_setting_field['fabu_top_style'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_setting')." ADD `fabu_top_style` tinyint(4) DEFAULT '2';\n";
}
if (!isset($tom_tcfangchan_setting_field['open_over_expire_status3'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_setting')." ADD `open_over_expire_status3` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcfangchan_setting_field['over_expire_status3_days'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcfangchan_setting')." ADD `over_expire_status3_days` int(11) DEFAULT '30';\n";
}

if (!empty($sql)) {
	runquery($sql);
}

$finish = TRUE;