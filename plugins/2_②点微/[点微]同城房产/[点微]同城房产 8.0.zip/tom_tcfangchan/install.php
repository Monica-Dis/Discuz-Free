<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcfangchan`;
CREATE TABLE `pre_tom_tcfangchan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `model_id` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `house_no` varchar(255) DEFAULT NULL,
  `house_tel` varchar(255) DEFAULT NULL,
  `trade_id` int(11) DEFAULT '0',
  `trade_name` varchar(255) DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `area_name` varchar(255) DEFAULT NULL,
  `street_id` int(11) DEFAULT '0',
  `street_name` varchar(255) DEFAULT NULL,
  `houses_id` int(11) DEFAULT '0',
  `houses_name` varchar(255) DEFAULT NULL,
  `mianji` decimal(10,2) DEFAULT '0.00',
  `price` decimal(10,1) DEFAULT '0.0',
  `rent` int(11) DEFAULT '0',
  `zhuanrang_price` decimal(10,2) DEFAULT '0.00',
  `fangchan_nature` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `wx` varchar(255) DEFAULT NULL,
  `content` text,
  `search_text` text,
  `vr_link` varchar(255) DEFAULT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  `top_status` tinyint(4) DEFAULT '0',
  `top_time` int(11) unsigned DEFAULT '0',
  `shenhe_status` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `finish` tinyint(4) DEFAULT '0',
  `expire_status` tinyint(4) DEFAULT '0',
  `expire_time` int(11) unsigned DEFAULT '0',
  `refresh_time` int(11) unsigned DEFAULT '0',
  `source_type` tinyint(4) DEFAULT '0',
  `pay_status` tinyint(4) DEFAULT '0',
  `client_ip_port` varchar(255) DEFAULT NULL,
  `clicks` int(11) DEFAULT '0',
  `deleted` tinyint(4) DEFAULT '0',
  `pay_type` tinyint(4) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_model_id` (`model_id`),
  KEY `idx_area_id` (`area_id`),
  KEY `idx_street_id` (`street_id`),
  KEY `idx_price` (`price`),
  KEY `idx_mianji` (`mianji`),
  KEY `idx_source_type` (`source_type`),
  KEY `idx_fangchan_nature` (`fangchan_nature`),
  KEY `idx_rent` (`rent`),
  KEY `idx_latitude` (`latitude`),
  KEY `idx_longitude` (`longitude`),
  KEY `idx_top_status` (`top_status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_status` (`status`),
  KEY `idx_finish` (`finish`),
  KEY `idx_expire_status` (`expire_status`),
  KEY `idx_refresh_time` (`refresh_time`),
  KEY `idx_site_id` (`site_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_agent`;
CREATE TABLE `pre_tom_tcfangchan_agent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `mendian_id` int(11) DEFAULT '0',
  `mendian_name` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `vip_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `wx_qrcode` varchar(255) DEFAULT NULL,
  `clicks` int(11) DEFAULT '0',
  `top_status` tinyint(4) DEFAULT '0',
  `top_time` int(11) unsigned DEFAULT '0',
  `expire_status` tinyint(4) DEFAULT '0',
  `expire_time` int(11) unsigned DEFAULT '0',
  `vip_add_time` int(11) DEFAULT '0',
  `shenhe_status` tinyint(4) DEFAULT '0',
  `mendian_shenhe_status` tinyint(4) DEFAULT '1',
  `mendian_shenhe_id` int(11) DEFAULT '0',
  `is_ok` tinyint(4) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mendian_id` (`mendian_id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_is_ok` (`is_ok`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_agent_vip`;
CREATE TABLE `pre_tom_tcfangchan_agent_vip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `days` int(11) DEFAULT '0',
  `fabu_num` int(11) DEFAULT '0',
  `total_fabu_num` int(11) DEFAULT '0',
  `refresh_num` int(11) DEFAULT '0',
  `top_zhekou` int(11) DEFAULT '0',
  `free_shenhe` tinyint(4) DEFAULT '0',
  `open_visitor` tinyint(4) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `max_num` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `vsort` int(11) unsigned DEFAULT '100',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_attr`;
CREATE TABLE `pre_tom_tcfangchan_attr` (
  `attr_id` int(11) NOT NULL AUTO_INCREMENT,
  `tcfangchan_id` int(11) DEFAULT '0',
  `attr_zhuangxiu_type` int(11) DEFAULT '0',
  `attr_house_type` int(11) DEFAULT '0',
  `attr_chaoxiang_type` int(11) DEFAULT '0',
  `attr_shi` int(11) unsigned DEFAULT '0',
  `attr_ting` int(11) DEFAULT '0',
  `attr_wei` int(11) DEFAULT '0',
  `attr_louceng` int(11) DEFAULT '0',
  `attr_cengshu` int(11) DEFAULT '0',
  `attr_chanquan` int(11) DEFAULT '0',
  `attr_elevator` int(11) DEFAULT '0',
  `attr_tese_tags` varchar(255) DEFAULT NULL,
  `attr_lease_type` int(11) DEFAULT '0',
  `attr_shangpu_type` int(11) DEFAULT '0',
  `attr_rent_type` int(11) DEFAULT '0',
  `attr_rent_unit` int(11) DEFAULT '1',
  `attr_peitao_tags` varchar(255) DEFAULT NULL,
  `attr_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`attr_id`),
  KEY `idx_tcfangchan_id` (`tcfangchan_id`),
  KEY `idx_attr_zhuangxiu_type` (`attr_zhuangxiu_type`),
  KEY `idx_attr_housing_type` (`attr_house_type`),
  KEY `idx_attr_chaoxiang_type` (`attr_chaoxiang_type`),
  KEY `idx_attr_elevator` (`attr_elevator`),
  KEY `idx_attr_lease` (`attr_lease_type`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_common`;
CREATE TABLE `pre_tom_tcfangchan_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `xieyi_txt` text,
  `clicks` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_config`;
CREATE TABLE `pre_tom_tcfangchan_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `min` int(11) DEFAULT '0',
  `max` int(11) DEFAULT '0',
  `csort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_config_tag`;
CREATE TABLE `pre_tom_tcfangchan_config_tag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `model_id` varchar(255) DEFAULT NULL,
  `tsort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_diynav`;
CREATE TABLE `pre_tom_tcfangchan_diynav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `model_id` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `add_time` varchar(255) DEFAULT '0',
  `dsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_focuspic`;
CREATE TABLE `pre_tom_tcfangchan_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_guanggao`;
CREATE TABLE `pre_tom_tcfangchan_guanggao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `gsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_guanzu`;
CREATE TABLE `pre_tom_tcfangchan_guanzu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcfangchan_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tcfangchan_id` (`tcfangchan_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_houses`;
CREATE TABLE `pre_tom_tcfangchan_houses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `area_name` varchar(255) DEFAULT NULL,
  `street_id` int(11) DEFAULT '0',
  `street_name` varchar(255) DEFAULT NULL,
  `year` int(11) DEFAULT '0',
  `chanquan` int(11) DEFAULT '0',
  `average_price` int(11) DEFAULT '0',
  `open_auto_average` int(11) DEFAULT '0',
  `last_auto_time` int(11) unsigned DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `developer_company` varchar(255) DEFAULT NULL,
  `parking_space` int(11) DEFAULT '0',
  `plot_ratio` decimal(10,2) DEFAULT '0.00',
  `greening_rate` int(11) DEFAULT '0',
  `property_company` varchar(255) DEFAULT NULL,
  `property_price` decimal(10,2) DEFAULT '0.00',
  `property_tel` varchar(255) DEFAULT NULL,
  `clicks` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `shenhe_status` tinyint(4) DEFAULT '1',
  `update_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_area_id` (`area_id`),
  KEY `idx_street_id` (`street_id`),
  KEY `idx_average_price` (`average_price`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_houses_guanzu`;
CREATE TABLE `pre_tom_tcfangchan_houses_guanzu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `houses_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_houses_id` (`houses_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_jubao`;
CREATE TABLE `pre_tom_tcfangchan_jubao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT '1',
  `tcfangchan_id` int(11) DEFAULT '0',
  `needs_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `content` text,
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tcfangchan_id` (`tcfangchan_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_log`;
CREATE TABLE `pre_tom_tcfangchan_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `mendian_id` int(11) DEFAULT '0',
  `agent_id` int(11) DEFAULT '0',
  `needs_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `today_time` int(11) DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mendian_id` (`mendian_id`),
  KEY `idx_type` (`type`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_mendian`;
CREATE TABLE `pre_tom_tcfangchan_mendian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `tcshop_id` int(11) DEFAULT '0',
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `area_name` varchar(255) DEFAULT NULL,
  `street_id` int(11) DEFAULT '0',
  `street_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `business_hours` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `shopkeeper_tel` varchar(255) DEFAULT NULL,
  `content` text,
  `vip_id` int(11) DEFAULT '0',
  `agent_num` int(11) DEFAULT '0',
  `house_num` int(11) DEFAULT '0',
  `search_text` text,
  `shenhe_status` tinyint(4) DEFAULT '0',
  `top_status` tinyint(4) DEFAULT '0',
  `top_time` int(11) unsigned DEFAULT '0',
  `expire_status` tinyint(4) DEFAULT '0',
  `expire_time` int(11) unsigned DEFAULT '0',
  `vip_add_time` int(11) unsigned DEFAULT '0',
  `admin_edit` tinyint(4) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_expire_status` (`expire_status`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_top_status` (`top_status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_mendian_vip`;
CREATE TABLE `pre_tom_tcfangchan_mendian_vip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `days` int(11) DEFAULT '0',
  `agent_num` int(11) DEFAULT '0',
  `agent_fabu_num` int(11) DEFAULT '0',
  `total_agent_fabu_num` int(11) DEFAULT '0',
  `agent_refresh_num` int(11) DEFAULT '0',
  `top_zhekou` int(11) DEFAULT '0',
  `free_shenhe` tinyint(4) DEFAULT '0',
  `open_visitor` tinyint(4) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `max_num` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `vsort` int(11) unsigned DEFAULT '100',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_newhouses`;
CREATE TABLE `pre_tom_tcfangchan_newhouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `tese_tags` varchar(255) DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `area_name` varchar(255) DEFAULT NULL,
  `street_id` int(11) DEFAULT '0',
  `street_name` varchar(255) DEFAULT NULL,
  `average_price` int(11) DEFAULT '0',
  `zhuangxiu_type` int(11) DEFAULT '0',
  `chanquan` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `sales_tel` varchar(255) DEFAULT NULL,
  `sales_address` varchar(255) DEFAULT NULL,
  `developer_company` varchar(255) DEFAULT NULL,
  `parking_space` int(11) DEFAULT '0',
  `plot_ratio` decimal(10,2) DEFAULT '0.00',
  `greening_rate` int(11) DEFAULT '0',
  `households_num` int(11) DEFAULT '0',
  `land_mianji` int(11) DEFAULT '0',
  `house_mianji` varchar(255) DEFAULT NULL,
  `house_total_mianji` int(11) DEFAULT '0',
  `huode_ratio` int(11) DEFAULT '0',
  `property_company` varchar(255) DEFAULT NULL,
  `property_price` decimal(10,2) DEFAULT '0.00',
  `property_tel` varchar(255) DEFAULT NULL,
  `open_sale_adviser` tinyint(4) DEFAULT '0',
  `sale_adviser_price` decimal(10,2) DEFAULT '0.00',
  `sale_adviser_price_list` text,
  `sale_adviser_num` int(11) DEFAULT '0',
  `content` text,
  `vr_link` varchar(255) DEFAULT NULL,
  `clicks` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `sell_status` int(11) DEFAULT '0',
  `update_time` int(11) unsigned DEFAULT '0',
  `top_status` int(11) DEFAULT '0',
  `top_time` int(11) unsigned DEFAULT '0',
  `start_time` int(11) unsigned DEFAULT '0',
  `jiaofang_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `admin_edit` int(11) DEFAULT '1',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_area_id` (`area_id`),
  KEY `idx_street_id` (`street_id`),
  KEY `idx_average_price` (`average_price`),
  KEY `idx_sell_status` (`sell_status`),
  KEY `idx_status` (`status`),
  KEY `idx_top_status` (`top_status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_newhouses_adviser`;
CREATE TABLE `pre_tom_tcfangchan_newhouses_adviser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `newhouses_id` int(11) DEFAULT '0',
  `newhouses_name` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `sub_desc` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `wx` varchar(255) DEFAULT NULL,
  `work_picurl` varchar(255) DEFAULT NULL,
  `wx_qrcode` varchar(255) DEFAULT NULL,
  `asort` int(11) DEFAULT '10',
  `status` tinyint(4) DEFAULT '0',
  `pay_status` tinyint(4) DEFAULT '0',
  `expire_status` tinyint(4) DEFAULT '3',
  `expire_time` int(11) unsigned DEFAULT '0',
  `shenhe_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_newhouses_id` (`newhouses_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_newhouses_guanzu`;
CREATE TABLE `pre_tom_tcfangchan_newhouses_guanzu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `newhouses_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `tel` varchar(255) DEFAULT NULL,
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_newhouses_id` (`newhouses_id`),
  KEY `idx_type` (`type`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_newhouses_manage`;
CREATE TABLE `pre_tom_tcfangchan_newhouses_manage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `beizu` text,
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_newhouses_history`;
CREATE TABLE `pre_tom_tcfangchan_newhouses_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `newhouses_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `last_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_order`;
CREATE TABLE `pre_tom_tcfangchan_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tcfangchan_id` int(11) DEFAULT '0',
  `needs_id` int(11) DEFAULT '0',
  `adviser_id` int(11) DEFAULT '0',
  `mendian_id` int(11) DEFAULT '0',
  `mendian_vip_id` int(11) DEFAULT '0',
  `mendian_vip_days` int(11) DEFAULT '0',
  `agent_id` int(11) DEFAULT '0',
  `agent_vip_id` int(11) DEFAULT '0',
  `agent_vip_days` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `order_no` varchar(255) DEFAULT NULL,
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `pay_time` int(11) DEFAULT '0',
  `fabu_days` int(11) DEFAULT '0',
  `fabu_price` decimal(10,2) DEFAULT '0.00',
  `top_days` int(11) DEFAULT '0',
  `top_price` decimal(10,2) DEFAULT '0.00',
  `top_zhekou` int(11) DEFAULT '0',
  `order_status` tinyint(4) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_tcfangchan_id` (`tcfangchan_id`),
  KEY `idx_type` (`type`),
  KEY `idx_order_status` (`order_status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_photo`;
CREATE TABLE `pre_tom_tcfangchan_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcfangchan_id` int(11) DEFAULT '0',
  `newhouses_id` int(11) DEFAULT '0',
  `houses_id` int(11) DEFAULT '0',
  `mendian_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `house_huxing` varchar(255) DEFAULT NULL,
  `house_mianji` decimal(10,2) DEFAULT '0.00',
  `picurl` varchar(255) DEFAULT NULL,
  `oss_picurl` varchar(255) DEFAULT NULL,
  `oss_status` int(11) DEFAULT '0',
  `qiniu_picurl` varchar(255) DEFAULT NULL,
  `qiniu_status` int(11) DEFAULT '0',
  `psort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tcfangchan_id` (`tcfangchan_id`),
  KEY `idx_newhouses_id` (`newhouses_id`),
  KEY `idx_houses_id` (`houses_id`),
  KEY `idx_type` (`type`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_tag`;
CREATE TABLE `pre_tom_tcfangchan_tag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tcfangchan_id` int(11) DEFAULT '0',
  `newhouses_id` int(11) DEFAULT '0',
  `config_tag_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `config_tag_ids` varchar(255) DEFAULT NULL,
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_trade`;
CREATE TABLE `pre_tom_tcfangchan_trade` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `name` varchar(255) DEFAULT NULL,
  `tsort` int(11) DEFAULT '100',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_visitor_log`;
CREATE TABLE `pre_tom_tcfangchan_visitor_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `tcfangchan_id` int(11) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `update_time` int(11) unsigned DEFAULT '0',
  `last_smstp_time` int(11) unsigned DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_needs`;
CREATE TABLE `pre_tom_tcfangchan_needs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `wx` varchar(255) DEFAULT NULL,
  `admin_edit` int(11) DEFAULT '0',
  `content` text,
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `street_id` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT '',
  `clicks` int(11) DEFAULT '0',
  `expire_status` tinyint(4) DEFAULT '0',
  `expire_time` int(11) DEFAULT '0',
  `pay_status` tinyint(4) DEFAULT '0',
  `client_ip_port` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `refresh_time` int(11) DEFAULT '0',
  `top_status` int(11) DEFAULT '0',
  `top_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '1000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_pay_status` (`pay_status`),
  KEY `idx_top_status` (`top_status`),
  KEY `idx_top_time` (`top_time`),
  KEY `idx_refresh_time` (`refresh_time`),
  KEY `idx_type` (`type`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcfangchan_setting`;
CREATE TABLE `pre_tom_tcfangchan_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `open_video` tinyint(4) DEFAULT '0',
  `open_vr` tinyint(4) DEFAULT '0',
  `open_house_no` tinyint(4) DEFAULT '0',
  `open_house_tel` tinyint(4) DEFAULT '0',
  `open_attr_chanquan` tinyint(4) DEFAULT '0',
  `open_attr_elevator` tinyint(4) DEFAULT '0',
  `mendianinfo_share_title` varchar(255) DEFAULT NULL,
  `mendianinfo_share_desc` varchar(255) DEFAULT NULL,
  `agentinfo_share_title` varchar(255) DEFAULT NULL,
  `agentinfo_share_desc` varchar(255) DEFAULT NULL,
  `fabu_top_style` tinyint(4) DEFAULT '2',
  `open_over_expire_status3` tinyint(4) DEFAULT '0',
  `over_expire_status3_days` int(11) DEFAULT '30',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;