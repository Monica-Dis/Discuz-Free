<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function update_mendian_xinxi($mendian_id, $mendianInfo = array()){
    
    if(empty($mendianInfo)){
        $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($mendian_id);
    }else{
        $mendian_id = $mendianInfo['id'];
    }
    
    if($mendian_id > 0){}else{
        return false;
    }
    
    $housesCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_agent_houses_count( " AND m.id = {$mendian_id} AND t.status=1 AND t.shenhe_status=1 AND t.finish = 0 ");
    $agentCount = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_count( " AND mendian_id = {$mendian_id} AND shenhe_status = 1 ");
    
    $updateData = array();
    if($mendianInfo['house_num'] != $housesCount){
        $updateData['house_num'] = $housesCount;
    }
    
    if($mendianInfo['agent_num'] != $agentCount){
        $updateData['agent_num'] = $agentCount;
    }

    if(is_array($updateData) && !empty($updateData)){
        C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->update($mendian_id, $updateData);
    }
    
    return true;
    
}

function update_fangchan_tongcheng($tcfangchan_id,$paramArr = array()){
    
    if(is_array($paramArr) && !empty($paramArr)){
        $tcfangchanConfig   = $paramArr['tcfangchanConfig'];
        $tongchengConfig    = $paramArr['tongchengConfig'];
        $zhuangxiuTypeArr   = $paramArr['zhuangxiuTypeArr'];
        $houseTypeArr       = $paramArr['houseTypeArr'];
        $chaoxiangTypeArr   = $paramArr['chaoxiangTypeArr'];
        $rentTypeArr        = $paramArr['rentTypeArr'];
        $shangpuTypeArr     = $paramArr['shangpuTypeArr'];
        $rentUnitArr        = $paramArr['rentUnitArr'];
    }else{
        global $tcfangchanConfig,$tongchengConfig,$zhuangxiuTypeArr,$houseTypeArr,$chaoxiangTypeArr,$rentTypeArr,$rentUnitArr,$shangpuTypeArr;
    }
    
    $tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($tcfangchan_id);
    if($tcfangchanInfo && $tcfangchanInfo['id'] > 0){}else{
        return false;
    }
    
    $type_id = 0;
    if($tcfangchanInfo['model_id'] == 'ershoufang'){
        $type_id = $tcfangchanConfig['tc_ershoufang_type_id'];
    }else if($tcfangchanInfo['model_id'] == 'chuzu'){
        $type_id = $tcfangchanConfig['tc_chuzu_type_id'];
    }else if($tcfangchanInfo['model_id'] == 'shangpu'){
        $type_id = $tcfangchanConfig['tc_shangpu_type_id'];
    }else if($tcfangchanInfo['model_id'] == 'xiezilou'){
        $type_id = $tcfangchanConfig['tc_xiezilou_type_id'];
    }else if($tcfangchanInfo['model_id'] == 'changfang'){
        $type_id = $tcfangchanConfig['tc_changfang_type_id'];
    }else if($tcfangchanInfo['model_id'] == 'cangku'){
        $type_id = $tcfangchanConfig['tc_cangku_type_id'];
    }else if($tcfangchanInfo['model_id'] == 'tudi'){
        $type_id = $tcfangchanConfig['tc_tudi_type_id'];
    }
    
    if($tcfangchanConfig['open_tongbu_tongcheng'] == 1 && $type_id > 0){}else{
        return false;
    }
    
    $tongchengTypeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($type_id);
    if($tongchengTypeInfo && $tongchengTypeInfo['id'] > 0){}else{
        return false;
    }
    
    $attrInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_attr")->fetch_all_list(" AND tcfangchan_id = {$tcfangchan_id} ", 'ORDER BY attr_id DESC', 0, 1);
    $attrInfo = array();
    if(is_array($attrInfoTmp) && !empty($attrInfoTmp[0])){
        $attrInfo = $attrInfoTmp[0];
    }else{
        return false;
    }
    
    $photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id={$tcfangchan_id} AND type IN (1,4) "," ORDER BY type DESC,psort ASC,id ASC ",0,20);
    $photoList = array();
    $video_pic = '';
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach($photoListTmp as $key => $value){
            if($value['type'] == 1){
                $photoList[] = $value['picurl'];
            }else if($value['type'] == 4){
                $video_pic = $value['picurl'];
            }
        }
    }
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_tcfangchan_id($tcfangchanInfo['id']);
    
    $attrArr = array();
    
    if($tcfangchanInfo['model_id'] == 'ershoufang'){
        $attrArr[0]['name']  = lang("plugin/tom_tcfangchan", "tongbu_fangchan_ershoufang_title");
        $attrArr[0]['value'] = $tcfangchanInfo['title'];
        $attrArr[0]['unit']  = '';
        
        $attrArr[1]['name']  = lang("plugin/tom_tcfangchan", "tongbu_mianji_title");
        $attrArr[1]['value'] = $tcfangchanInfo['mianji'].lang('plugin/tom_tcfangchan','pingmi').'&nbsp;/&nbsp;'.$attrInfo['attr_shi'].lang("plugin/tom_tcfangchan", "shi").$attrInfo['attr_ting'].lang("plugin/tom_tcfangchan", "ting").$attrInfo['attr_wei'].lang("plugin/tom_tcfangchan", "wei");
        $attrArr[1]['unit']  = '';
        
        $attrArr[2]['name']  = lang("plugin/tom_tcfangchan", "tongbu_shoujia_title");
        if($tcfangchanInfo['price'] > 0){
            $attrArr[2]['value'] = $tcfangchanInfo['price'];
            $attrArr[2]['unit']  = lang('plugin/tom_tcfangchan','price_unit');
        }else{
            $attrArr[2]['value'] = lang('plugin/tom_tcfangchan','index_mianyi');
            $attrArr[2]['unit']  = '';
        }
        
        $attrArr[3]['name']  = lang("plugin/tom_tcfangchan", "tongbu_houses_name_title");
        $attrArr[3]['value'] = $tcfangchanInfo['houses_name'];
        $attrArr[3]['unit']  = '';
        if($tcfangchanConfig['open_trade'] == 1){
            $attrArr[4]['name']  = lang("plugin/tom_tcfangchan", "tongbu_trade_name_title");
            $attrArr[4]['value'] = $tcfangchanInfo['trade_name'];
            $attrArr[4]['unit']  = '';
        }
        
        if($attrInfo['attr_zhuangxiu_type'] > 0){
            $attrArr[6]['name']  = lang("plugin/tom_tcfangchan", "tongbu_zhuangxiu_type_title");
            $attrArr[6]['value'] = $zhuangxiuTypeArr[$attrInfo['attr_zhuangxiu_type']];
            $attrArr[6]['unit']  = '';
        }
        
        if($attrInfo['attr_house_type'] > 0){
            $attrArr[7]['name']  = lang("plugin/tom_tcfangchan", "tongbu_house_type_title");
            $attrArr[7]['value'] = $houseTypeArr[$attrInfo['attr_house_type']];
            $attrArr[7]['unit']  = '';
        }
        
        if($attrInfo['attr_chaoxiang_type'] > 0){
            $attrArr[8]['name']  = lang("plugin/tom_tcfangchan", "tongbu_chaoxiang_type_title");
            $attrArr[8]['value'] = $chaoxiangTypeArr[$attrInfo['attr_chaoxiang_type']];
            $attrArr[8]['unit']  = '';
        }
        
        if($attrInfo['attr_louceng'] > 0){
            $attrArr[10]['name']  = lang("plugin/tom_tcfangchan", "tongbu_louceng_title");
            if($attrInfo['attr_louceng'] == 1){
                $attrArr[10]['value'] = lang("plugin/tom_tcfangchan", "tongbu_louceng_one").'/'.lang("plugin/tom_tcfangchan", "gong").$attrInfo['attr_cengshu'].lang("plugin/tom_tcfangchan", "ceng");
            }else if($attrInfo['attr_louceng'] == $attrInfo['attr_cengshu']){
                $attrArr[10]['value'] = lang("plugin/tom_tcfangchan", "tongbu_louceng_top").'/'.lang("plugin/tom_tcfangchan", "gong").$attrInfo['attr_cengshu'].lang("plugin/tom_tcfangchan", "ceng");
            }else if($attrInfo['attr_louceng'] <= 3 && $attrInfo['attr_cengshu'] > 8){
                $attrArr[10]['value'] = lang("plugin/tom_tcfangchan", "tongbu_louceng_di").'/'.lang("plugin/tom_tcfangchan", "gong").$attrInfo['attr_cengshu'].lang("plugin/tom_tcfangchan", "ceng");
            }else if($attrInfo['attr_louceng'] > 25 && $attrInfo['attr_cengshu'] > 25){
                $attrArr[10]['value'] = lang("plugin/tom_tcfangchan", "tongbu_louceng_gao").'/'.lang("plugin/tom_tcfangchan", "gong").$attrInfo['attr_cengshu'].lang("plugin/tom_tcfangchan", "ceng");
            }else{
                $attrArr[10]['value'] = lang("plugin/tom_tcfangchan", "tongbu_louceng_zhong").'/'.lang("plugin/tom_tcfangchan", "gong").$attrInfo['attr_cengshu'].lang("plugin/tom_tcfangchan", "ceng");
            }
            $attrArr[10]['unit']  = '';
        }
        
        if($attrInfo['attr_chanquan'] > 0){
            $attrArr[11]['name']  = lang("plugin/tom_tcfangchan", "tongbu_chanquan_title");
            $attrArr[11]['value'] = $attrInfo['attr_chanquan'];
            $attrArr[11]['unit']  = lang("plugin/tom_tcfangchan", "year");
        }
        
        if($attrInfo['attr_elevator'] == 1){
            $attrArr[12]['name']  = lang("plugin/tom_tcfangchan", "tongbu_elevator_title");
            $attrArr[12]['value'] = lang("plugin/tom_tcfangchan", "tongbu_elevator_1");
            $attrArr[12]['unit']  = '';
        }
        
    }else if($tcfangchanInfo['model_id'] == 'chuzu'){
        
        $attrArr[0]['name']  = lang("plugin/tom_tcfangchan", "tongbu_fangchan_chuzu_title");
        $attrArr[0]['value'] = $tcfangchanInfo['title'];
        $attrArr[0]['unit']  = '';
        
        $attrArr[1]['name']  = lang("plugin/tom_tcfangchan", "tongbu_mianji_title");
        $attrArr[1]['value'] = $tcfangchanInfo['mianji'].lang('plugin/tom_tcfangchan','pingmi').'&nbsp;/&nbsp;'.$attrInfo['attr_shi'].lang("plugin/tom_tcfangchan", "shi").$attrInfo['attr_ting'].lang("plugin/tom_tcfangchan", "ting").$attrInfo['attr_wei'].lang("plugin/tom_tcfangchan", "wei");
        $attrArr[1]['unit']  = '';
        
        $attrArr[2]['name']  = lang("plugin/tom_tcfangchan", "tongbu_rent_title");
        if($tcfangchanInfo['rent'] > 0){
            $attrArr[2]['value'] = $tcfangchanInfo['rent'];
            $attrArr[2]['unit']  = $rentUnitArr[$attrInfo['attr_rent_unit']];
        }else{
            $attrArr[2]['value'] = lang('plugin/tom_tcfangchan','index_mianyi');
            $attrArr[2]['unit']  = '';
        }
        
        $attrArr[3]['name']  = lang("plugin/tom_tcfangchan", "tongbu_houses_name_title");
        $attrArr[3]['value'] = $tcfangchanInfo['houses_name'];
        $attrArr[3]['unit']  = '';
        
        if($tcfangchanConfig['open_trade'] == 1){
            $attrArr[4]['name']  = lang("plugin/tom_tcfangchan", "tongbu_trade_name_title");
            $attrArr[4]['value'] = $tcfangchanInfo['trade_name'];
            $attrArr[4]['unit']  = '';
        }
        
        if($attrInfo['attr_zhuangxiu_type'] > 0){
            $attrArr[5]['name']  = lang("plugin/tom_tcfangchan", "tongbu_zhuangxiu_type_title");
            $attrArr[5]['value'] = $zhuangxiuTypeArr[$attrInfo['attr_zhuangxiu_type']];
            $attrArr[5]['unit']  = '';
        }
        
        if($attrInfo['attr_house_type'] > 0){
            $attrArr[6]['name']  = lang("plugin/tom_tcfangchan", "tongbu_house_type_title");
            $attrArr[6]['value'] = $houseTypeArr[$attrInfo['attr_house_type']];
            $attrArr[6]['unit']  = '';
        }
        
        if($attrInfo['attr_chaoxiang_type'] > 0){
            $attrArr[7]['name']  = lang("plugin/tom_tcfangchan", "tongbu_chaoxiang_type_title");
            $attrArr[7]['value'] = $chaoxiangTypeArr[$attrInfo['attr_chaoxiang_type']];
            $attrArr[7]['unit']  = '';
        }
        
        if($attrInfo['attr_louceng'] > 0){
            $attrArr[9]['name']  = lang("plugin/tom_tcfangchan", "tongbu_louceng_title");
            $attrArr[9]['value'] = $attrInfo['attr_louceng'].lang("plugin/tom_tcfangchan", "lou").'/'.lang("plugin/tom_tcfangchan", "gong").$attrInfo['attr_cengshu'].lang("plugin/tom_tcfangchan", "ceng");
            $attrArr[9]['unit']  = '';
        }
        
        if($attrInfo['attr_lease_type'] > 0){
            $attrArr[10]['name']  = lang("plugin/tom_tcfangchan", "tongbu_lease_title");
            $attrArr[10]['value'] = lang("plugin/tom_tcfangchan", "tongbu_lease_".$attrInfo['attr_lease_type']);
            $attrArr[10]['unit']  = '';
        }
        
        if($attrInfo['attr_rent_type'] > 0){
            $attrArr[11]['name']  = lang("plugin/tom_tcfangchan", "tongbu_rent_type_title");
            $attrArr[11]['value'] = $rentTypeArr[$attrInfo['attr_rent_type']];
            $attrArr[11]['unit']  = '';
        }
        
    }else if($tcfangchanInfo['model_id'] == 'shangpu' || $tcfangchanInfo['model_id'] == 'xiezilou' || $tcfangchanInfo['model_id'] == 'changfang' || $tcfangchanInfo['model_id'] == 'cangku' || $tcfangchanInfo['model_id'] == 'tudi'){
        
        $attrArr[0]['name']  = lang("plugin/tom_tcfangchan", "tongbu_fangchan_shangpu_title");
        $attrArr[0]['value'] = $tcfangchanInfo['title'];
        $attrArr[0]['unit']  = '';
        
        $attrArr[1]['name']  = lang("plugin/tom_tcfangchan", "tongbu_fangchan_nature_title");
        $attrArr[1]['value'] = lang('plugin/tom_tcfangchan','tongbu_fangchan_nature_'.$tcfangchanInfo['fangchan_nature']);
        $attrArr[1]['unit']  = '';
        
        $attrArr[2]['name']  = lang("plugin/tom_tcfangchan", "tongbu_mianji_title");
        $attrArr[2]['value'] = $tcfangchanInfo['mianji'];
        $attrArr[2]['unit']  = lang('plugin/tom_tcfangchan','pingmi');
        
        if($tcfangchanConfig['open_trade'] == 1 && $tcfangchanInfo['trade_id'] > 0){
            $attrArr[3]['name']  = lang("plugin/tom_tcfangchan", "tongbu_trade_name_title");
            $attrArr[3]['value'] = $tcfangchanInfo['trade_name'];
            $attrArr[3]['unit']  = '';
        }
        
        if($tcfangchanInfo['fangchan_nature'] == 1){
            
            $attrArr[4]['name']  = lang("plugin/tom_tcfangchan", "tongbu_rent_title");
            if($tcfangchanInfo['rent'] > 0){
                $attrArr[4]['value'] = $tcfangchanInfo['rent'];
                $attrArr[4]['unit']  = $rentUnitArr[$attrInfo['attr_rent_unit']];
            }else{
                $attrArr[4]['value'] = lang('plugin/tom_tcfangchan','index_mianyi');
                $attrArr[4]['unit']  = '';
            }
            
            if($attrInfo['attr_rent_type'] > 0){
                $attrArr[5]['name']  = lang("plugin/tom_tcfangchan", "tongbu_rent_type_title");
                $attrArr[5]['value'] = $rentTypeArr[$attrInfo['attr_rent_type']];
                $attrArr[5]['unit']  = '';
            }
            
        }else if($tcfangchanInfo['fangchan_nature'] == 2){
            
            $attrArr[4]['name']  = lang("plugin/tom_tcfangchan", "tongbu_shoujia_title");
            if($tcfangchanInfo['price'] > 0){
                $attrArr[4]['value'] = $tcfangchanInfo['price'];
                $attrArr[4]['unit']  = lang('plugin/tom_tcfangchan','price_unit');
            }else{
                $attrArr[4]['value'] = lang('plugin/tom_tcfangchan','index_mianyi');
                $attrArr[4]['unit']  = '';
            }
            
        }else if($tcfangchanInfo['fangchan_nature'] == 3){
            
            $attrArr[4]['name']  = lang("plugin/tom_tcfangchan", "tongbu_zhuanrang_title");
            if($tcfangchanInfo['zhuanrang_price'] > 0){
                $attrArr[4]['value'] = $tcfangchanInfo['zhuanrang_price'];
                $attrArr[4]['unit']  = lang('plugin/tom_tcfangchan','price_unit');
            }else{
                $attrArr[4]['value'] = lang('plugin/tom_tcfangchan','index_mianyi');
                $attrArr[4]['unit']  = '';
            }
            
        }
           
        if($tcfangchanInfo['model_id'] == 'shangpu'){
            if($attrInfo['attr_shangpu_type'] > 0){
                $attrArr[6]['name']  = lang("plugin/tom_tcfangchan", "tongbu_shangpu_type_title");
                $attrArr[6]['value'] = $shangpuTypeArr[$attrInfo['attr_shangpu_type']];
                $attrArr[6]['unit']  = '';
            }
        }
        
        if($tcfangchanInfo['model_id'] == 'shangpu' || $tcfangchanInfo['model_id'] == 'xiezilou'){
            if($attrInfo['attr_louceng'] > 0){
                $attrArr[7]['name']  = lang("plugin/tom_tcfangchan", "tongbu_louceng_title");
                $attrArr[7]['value'] = $attrInfo['attr_louceng'].lang("plugin/tom_tcfangchan", "lou").'/'.lang("plugin/tom_tcfangchan", "gong").$attrInfo['attr_cengshu'].lang("plugin/tom_tcfangchan", "ceng");
                $attrArr[7]['unit']  = '';
            }
        }
        
        
    }
    
    $testTagsArr = explode('|', trim($attrInfo['attr_tese_tags'], '|'));
    $tagArr = array();
    if(is_array($testTagsArr) && !empty($testTagsArr)){
        foreach($testTagsArr as $k => $v){
            if(!empty($v)){
                $tagArr[] = $v;
            }
        }
    }
    if($tcfangchanInfo['model_id'] == 'chuzu'){
        $peitaoTagsArr = explode('|', trim($attrInfo['attr_peitao_tags'], '|'));
        if(is_array($peitaoTagsArr) && !empty($peitaoTagsArr)){
            foreach($peitaoTagsArr as $k => $v){
                if(!empty($v)){
                    $tagArr[] = $v;
                }
            }
        }
    }
    
    $tcfangchanInfo['content'] = stripslashes($tcfangchanInfo['content']);
    $tcfangchanInfo['content'] = strip_tags($tcfangchanInfo['content']);
    $tcfangchanInfo['content'] = str_replace('&nbsp;', '', $tcfangchanInfo['content']);

    if($tongchengInfo && $tongchengInfo['id'] > 0){
        
        $updateData = array();
        $updateData['site_id']      = $tcfangchanInfo['site_id'];
        $updateData['user_id']      = $tcfangchanInfo['user_id'];
        $updateData['model_id']     = $tongchengTypeInfo['model_id'];
        $updateData['type_id']      = $tongchengTypeInfo['id'];
        $updateData['tcfangchan_id'] = $tcfangchanInfo['id'];
        $updateData['area_id']      = $tcfangchanInfo['area_id'];
        $updateData['street_id']    = $tcfangchanInfo['street_id'];
        $updateData['title']        = $tcfangchanInfo['title'];
        $updateData['xm']           = $tcfangchanInfo['xm'];
        $updateData['tel']          = $tcfangchanInfo['tel'];
        $updateData['video_url']    = $tcfangchanInfo['video_url'];
        $updateData['video_pic']    = $video_pic;
        $updateData['content']      = $tcfangchanInfo['content'].'|+|+|+|+|+|+|+|+|+|'.'-'.$tcfangchanInfo['search_text'].'-'.  mt_rand(111111, 666666);
        if($tongchengTypeInfo['open_dingwei'] == 1){
            $updateData['is_dingwei']       = 1;
            $updateData['latitude']         = $tcfangchanInfo['latitude'];
            $updateData['longitude']        = $tcfangchanInfo['longitude'];
            $updateData['address']          = $tcfangchanInfo['address'];
        }else{
            $updateData['is_dingwei']       = 0;
        }
        if($tcfangchanConfig['open_tongbu_top'] == 1 && $tcfangchanInfo['top_status'] == 1){
            $updateData['topstatus']            = $tcfangchanInfo['top_status'];
            $updateData['toprand']              = 1;
            $updateData['toptime']              = $tcfangchanInfo['top_time'];
        }else{
            $updateData['topstatus']            = 0;
            $updateData['toprand']              = 1;
            $updateData['toptime']              = 0;
        }
        if($tcfangchanInfo['status'] == 1 && ($tcfangchanInfo['expire_status'] == 3 || ($tcfangchanInfo['expire_status'] == 1 && $tcfangchanInfo['expire_time'] > TIMESTAMP))){
            $updateData['status']               = 1;
        }else{
            $updateData['status']               = 0;
        }
        $updateData['finish']               = $tcfangchanInfo['finish'];
        $updateData['pay_status']           = $tcfangchanInfo['pay_status'];
        $updateData['shenhe_status']        = $tcfangchanInfo['shenhe_status'];
        $updateData['refresh_time']         = $tcfangchanInfo['refresh_time'];
        $updateData['add_time']             = $tcfangchanInfo['add_time'];
        $updateData['part1']                = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongchengInfo['id'],$updateData);
        
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_tag')->delete_by_tongcheng_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_photo')->delete_by_tongcheng_id($tongchengInfo['id']);
        
        if(is_array($attrArr) && !empty($attrArr)){
            foreach ($attrArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengInfo['id'];
                $insertData['attr_id']      = 0;
                $insertData['attr_name']    = $value['name'];
                $insertData['value']        = $value['value'];
                $insertData['unit']         = $value['unit'];
                $insertData['paixu']        = $key;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
        
        $i = 1;
        if(is_array($tagArr) && !empty($tagArr)){
            foreach ($tagArr as $key => $value){
                if($i > 5) break;
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengInfo['id'];
                $insertData['tag_id']       = 0;
                $insertData['tag_name']     = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_tag')->insert($insertData);
                $i++;
            }
        }
        
        if(is_array($photoList) && !empty($photoList)){
            foreach($photoList as $key => $value){
                $insertData = array();
                $insertData['tongcheng_id'] = $tongchengInfo['id'];
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_photo')->insert($insertData);
            }
        }
        
    }else if($tcfangchanInfo && $tcfangchanInfo['status'] == 1 && $tcfangchanInfo['shenhe_status'] == 1 && ($tcfangchanInfo['pay_status'] == 0 || $tcfangchanInfo['pay_status'] == 2)){
        
        $insertData = array();
        $insertData['site_id']      = $tcfangchanInfo['site_id'];
        $insertData['user_id']      = $tcfangchanInfo['user_id'];
        $insertData['model_id']     = $tongchengTypeInfo['model_id'];
        $insertData['type_id']      = $tongchengTypeInfo['id'];
        $insertData['tcfangchan_id'] = $tcfangchanInfo['id'];
        $insertData['area_id']      = $tcfangchanInfo['area_id'];
        $insertData['street_id']    = $tcfangchanInfo['street_id'];
        $insertData['title']        = $tcfangchanInfo['title'];
        $insertData['xm']           = $tcfangchanInfo['xm'];
        $insertData['tel']          = $tcfangchanInfo['tel'];
        $insertData['video_url']    = $tcfangchanInfo['video_url'];
        $insertData['video_pic']    = $video_pic;
        $insertData['content']      = $tcfangchanInfo['content'].'|+|+|+|+|+|+|+|+|+|'.'-'.$tcfangchanInfo['search_text'].'-'.  mt_rand(111111, 666666);
        if($tongchengTypeInfo['open_dingwei'] == 1){
            $insertData['is_dingwei']       = 1;
            $insertData['latitude']         = $tcfangchanInfo['latitude'];
            $insertData['longitude']        = $tcfangchanInfo['longitude'];
            $insertData['address']          = $tcfangchanInfo['address'];
        }else{
            $insertData['is_dingwei']       = 0;
        }
        if($tcfangchanConfig['open_tongbu_top'] == 1 && $tcfangchanInfo['top_status'] == 1){
            $insertData['topstatus']            = $tcfangchanInfo['top_status'];
            $insertData['toprand']              = 1;
            $insertData['toptime']              = $tcfangchanInfo['top_time'];
        }else{
            $insertData['topstatus']            = 0;
            $insertData['toprand']              = 1;
            $insertData['toptime']              = 0;
        }
        if($tcfangchanInfo['expire_status'] == 3 || ($tcfangchanInfo['expire_status'] == 1 && $tcfangchanInfo['expire_time'] > TIMESTAMP)){
            $insertData['status']               = 1;
        }else{
            $insertData['status']               = 0;
        }
        $insertData['client_ip_port']       = $tcfangchanInfo['client_ip_port'];
        $insertData['finish']               = $tcfangchanInfo['finish'];
        $insertData['pay_status']           = $tcfangchanInfo['pay_status'];
        $insertData['shenhe_status']        = $tcfangchanInfo['shenhe_status'];
        $insertData['refresh_time']         = $tcfangchanInfo['refresh_time'];
        $insertData['add_time']             = $tcfangchanInfo['add_time'];
        C::t('#tom_tongcheng#tom_tongcheng')->insert($insertData);
        $tongchengId = C::t('#tom_tongcheng#tom_tongcheng')->insert_id();
        
        if(is_array($attrArr) && !empty($attrArr)){
            foreach ($attrArr as $key => $value){
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['attr_id']      = 0;
                $insertData['attr_name']    = $value['name'];
                $insertData['value']        = $value['value'];
                $insertData['unit']         = $value['unit'];
                $insertData['paixu']        = $key;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
            }
        }
        
        $i = 1;
        if(is_array($tagArr) && !empty($tagArr)){
            foreach ($tagArr as $key => $value){
                if($i > 5) break;
                $insertData = array();
                $insertData['model_id']     = $tongchengTypeInfo['model_id'];
                $insertData['type_id']      = $tongchengTypeInfo['id'];
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['tag_id']       = 0;
                $insertData['tag_name']     = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_tag')->insert($insertData);
                $i++;
            }
        }
        
        if(is_array($photoList) && !empty($photoList)){
            foreach($photoList as $key => $value){
                $insertData = array();
                $insertData['tongcheng_id'] = $tongchengId;
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tongcheng#tom_tongcheng_photo')->insert($insertData);
            }
        }
    }
    
    return true;
}

function delete_fangchan_tongcheng($tcfangchan_id){
    global $tcfangchanConfig,$tongchengConfig;
    
    if($tcfangchanConfig['open_tongbu_tongcheng'] == 1){}else{
        return false;
    }
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_tcfangchan_id($tcfangchan_id);
    if($tongchengInfo){
        C::t('#tom_tongcheng#tom_tongcheng')->delete_by_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_tag')->delete_by_tongcheng_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_photo')->delete_by_tongcheng_id($tongchengInfo['id']);
    }
    return true;
}

function update_mendian_tcshop($mendian_id,$paramArr = array()){
    
    if(is_array($paramArr) && !empty($paramArr)){
        $tcfangchanConfig   = $paramArr['tcfangchanConfig'];
    }else{
        global $tcfangchanConfig;
    }
    
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($mendian_id);
    if($mendianInfo && $mendianInfo['id'] > 0){}else{
        return false;
    }

    if($tcfangchanConfig['open_tongbu_tcshop'] == 1){}else{
        return false;
    }
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($mendianInfo['tcshop_id']);
    if($tcfangchanConfig['tongbu_tcshop_type'] == 1 && $tcshopInfo && $tcshopInfo['id'] > 0){
        return false;
    }
    
    $vipInfo = C::t("#tom_tcshop#tom_tcshop_vip")->fetch_by_id($tcfangchanConfig['tcshop_vip_id']);
    if($vipInfo && $vipInfo['id'] > 0){}else{
        return false;
    }
    
    $cateInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($tcfangchanConfig['tcshop_cate_id']);
    $cateChildInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($tcfangchanConfig['tcshop_cate_child_id']);
    if($cateInfo['id'] > 0 && $cateChildInfo['id'] > 0){}else{
        return false;
    }

    $photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND mendian_id={$mendian_id} AND type IN (5,6,7) "," ORDER BY type DESC,psort ASC,id ASC ",0,20);
    $photoList = array();
    $logo = $business_licence = '';
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach($photoListTmp as $key => $value){
            if($value['type'] == 5){
                $logo = $value['picurl'];
            }else if($value['type'] == 6){
                $photoList[] = $value['picurl'];
            }else if($value['type'] == 7){
                $business_licence = $value['picurl'];
            }
        }
    }
    
    if($tcshopInfo && $tcshopInfo['id'] > 0){
        
        $updateData = array();
        $updateData['site_id']          = $mendianInfo['site_id'];
        $updateData['user_id']          = $mendianInfo['user_id'];
        $updateData['name']             = $mendianInfo['name'];
        $updateData['cate_id']          = $cateInfo['id'];
        $updateData['cate_child_id']    = $cateChildInfo['id'];
        $updateData['city_id']          = $mendianInfo['city_id'];
        $updateData['area_id']          = $mendianInfo['area_id'];
        $updateData['street_id']        = $mendianInfo['street_id'];
        $updateData['address']          = $mendianInfo['address'];
        $updateData['latitude']         = $mendianInfo['latitude'];
        $updateData['longitude']        = $mendianInfo['longitude'];
        $updateData['business_hours']   = $mendianInfo['business_hours'];
        $updateData['tel']              = $mendianInfo['tel'];
        $updateData['shopkeeper_tel']   = $mendianInfo['shopkeeper_tel'];
        $updateData['content']          = $mendianInfo['content'];
        $updateData['picurl']           = $logo;
        $updateData['business_licence'] = $business_licence;
        $updateData['part1']            = TIMESTAMP;
        C::t('#tom_tcshop#tom_tcshop')->update($tcshopInfo['id'],$updateData);
        
        C::t('#tom_tcshop#tom_tcshop_photo')->delete_by_tcshop_id($tcshopInfo['id']);
        
        if(is_array($photoList) && !empty($photoList)){
            foreach ($photoList as $key => $value){
                $insertData = array();
                $insertData['tcshop_id'] = $tcshopInfo['id'];
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcshop#tom_tcshop_photo')->insert($insertData);
            }
        }
        
    }else if($mendianInfo && $mendianInfo['shenhe_status'] == 1){
        
        $insertData = array();
        $insertData['site_id']          = $mendianInfo['site_id'];
        $insertData['user_id']          = $mendianInfo['user_id'];
        $insertData['name']             = $mendianInfo['name'];
        $insertData['cate_id']          = $cateInfo['id'];
        $insertData['cate_child_id']    = $cateChildInfo['id'];
        $insertData['city_id']          = $mendianInfo['city_id'];
        $insertData['area_id']          = $mendianInfo['area_id'];
        $insertData['street_id']        = $mendianInfo['street_id'];
        $insertData['address']          = $mendianInfo['address'];
        $insertData['latitude']         = $mendianInfo['latitude'];
        $insertData['longitude']        = $mendianInfo['longitude'];
        $insertData['business_hours']   = $mendianInfo['business_hours'];
        $insertData['tel']              = $mendianInfo['tel'];
        $insertData['shopkeeper_tel']   = $mendianInfo['shopkeeper_tel'];
        $insertData['content']          = $mendianInfo['content'];
        $insertData['picurl']           = $logo;
        $insertData['business_licence'] = $business_licence;
        $insertData['is_ok']            = 1;
        $insertData['status']           = 1;
        $insertData['shenhe_status']    = 1;
        $insertData['vip_id']           = $vipInfo['id'];
        $insertData['vip_rank']         = $vipInfo['rank'];
        $insertData['vip_status']       = 1;
        $insertData['vip_time']         = TIMESTAMP + $tcfangchanConfig['tcshop_vip_time']*86400;
        $insertData['ruzhu_time']       = TIMESTAMP;
        C::t('#tom_tcshop#tom_tcshop')->insert($insertData);
        
        $tcshop_id = C::t('#tom_tcshop#tom_tcshop')->insert_id();
        
        $updateData = array();
        $updateData['tcshop_id']   = $tcshop_id;
        C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendianInfo['id'],$updateData);
        
        if(is_array($photoList) && !empty($photoList)){
            foreach ($photoList as $key => $value){
                $insertData = array();
                $insertData['tcshop_id'] = $tcshop_id;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcshop#tom_tcshop_photo')->insert($insertData);
            }
        }
    }
    
    return true;
}

function update_needs_tongcheng($needs_id,$paramArr = array()){
    
    if(is_array($paramArr) && !empty($paramArr)){
        $tcfangchanConfig    = $paramArr['tcfangchanConfig'];
        $tongchengConfig    = $paramArr['tongchengConfig'];
    }else{
        global $tcfangchanConfig,$tongchengConfig;
    }
    
    if($tcfangchanConfig['open_tongbu_tongcheng'] == 1 && ($tcfangchanConfig['tc_needs_qiugou_type_id'] > 0 || $tcfangchanConfig['tc_needs_qiuzu_type_id'] > 0)){}else{
        return false;
    }
    
    $needsInfo = C::t("#tom_tcfangchan#tom_tcfangchan_needs")->fetch_by_id($needs_id);
    if($needsInfo && $needsInfo['id'] > 0){}else{
        return false;
    }
    
    if($needsInfo['type'] == 1){
        $tongchengTypeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tcfangchanConfig['tc_needs_qiugou_type_id']);
    }elseif($needsInfo['type'] == 2){
        $tongchengTypeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tcfangchanConfig['tc_needs_qiuzu_type_id']);
    }
    
    if($tongchengTypeInfo && $tongchengTypeInfo['id'] > 0){}else{
        return false;
    }
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_tcfangchan_needs_id($needsInfo['id']);
    
    $needsInfo['content'] = stripslashes($needsInfo['content']);
    $needsInfo['content'] = strip_tags($needsInfo['content']);
    $needsInfo['content'] = str_replace('&nbsp;', '', $needsInfo['content']);

    if($tongchengInfo && $tongchengInfo['id'] > 0){
        
        $updateData = array();
        $updateData['site_id']           = $needsInfo['site_id'];
        $updateData['user_id']           = $needsInfo['user_id'];
        $updateData['model_id']          = $tongchengTypeInfo['model_id'];
        $updateData['type_id']           = $tongchengTypeInfo['id'];
        $updateData['tcfangchan_needs_id'] = $needsInfo['id'];
        $updateData['area_id']           = $needsInfo['area_id'];
        $updateData['street_id']    = $needsInfo['street_id'];
        $updateData['xm']           = $needsInfo['xm'];
        $updateData['tel']          = $needsInfo['tel'];
        $updateData['content']      = $needsInfo['content'];
        if($tongchengTypeInfo['open_dingwei'] == 1){
            $updateData['is_dingwei']       = 1;
            $updateData['latitude']         = $needsInfo['latitude'];
            $updateData['longitude']        = $needsInfo['longitude'];
            $updateData['address']          = $needsInfo['address'];
        }else{
            $updateData['is_dingwei']       = 0;
        }
        if($tcfangchanConfig['open_tongbu_top'] == 1 && $needsInfo['top_status'] == 1){
            $updateData['topstatus']            = $needsInfo['top_status'];
            $updateData['toprand']              = 1;
            $updateData['toptime']              = $needsInfo['top_time'];
        }else{
            $updateData['topstatus']            = 0;
            $updateData['toprand']              = 1;
            $updateData['toptime']              = 0;
        }
        if($needsInfo['status'] == 1 && ($needsInfo['expire_status'] == 3 || ($needsInfo['expire_status'] == 1 && $needsInfo['expire_time'] > TIMESTAMP))){
            $updateData['status']               = 1;
        }else{
            $updateData['status']               = 0;
        }
        $updateData['finish']               = 0;
        $updateData['pay_status']           = $needsInfo['pay_status'];
        $updateData['shenhe_status']        = $needsInfo['shenhe_status'];
        $updateData['refresh_time']         = $needsInfo['refresh_time'];
        $updateData['add_time']             = $needsInfo['add_time'];
        $updateData['part1']                = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongchengInfo['id'],$updateData);
        
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongchengInfo['id']);
        
    }else if($needsInfo && $needsInfo['status'] == 1 && $needsInfo['shenhe_status'] == 1 && ($needsInfo['pay_status'] == 0 || $needsInfo['pay_status'] == 2)){
        
        $insertData = array();
        $insertData['site_id']      = $needsInfo['site_id'];
        $insertData['user_id']      = $needsInfo['user_id'];
        $insertData['model_id']     = $tongchengTypeInfo['model_id'];
        $insertData['type_id']      = $tongchengTypeInfo['id'];
        $insertData['tcfangchan_needs_id'] = $needsInfo['id'];
        $insertData['area_id']      = $needsInfo['area_id'];
        $insertData['street_id']    = $needsInfo['street_id'];
        $insertData['xm']           = $needsInfo['xm'];
        $insertData['tel']          = $needsInfo['tel'];
        $insertData['wx']           = $needsInfo['wx'];
        $insertData['content']        = $needsInfo['content'];
        if($tongchengTypeInfo['open_dingwei'] == 1){
            $insertData['is_dingwei']       = 1;
            $insertData['latitude']         = $needsInfo['latitude'];
            $insertData['longitude']        = $needsInfo['longitude'];
            $insertData['address']          = $needsInfo['address'];
        }else{
            $insertData['is_dingwei']       = 0;
        }
        if($tcfangchanConfig['open_tongbu_top'] == 1 && $needsInfo['top_status'] == 1){
            $insertData['topstatus']            = $needsInfo['top_status'];
            $insertData['toprand']              = 1;
            $insertData['toptime']              = $needsInfo['top_time'];
        }else{
            $insertData['topstatus']            = 0;
            $insertData['toprand']              = 1;
            $insertData['toptime']              = 0;
        }
        if($needsInfo['status'] == 1 && ($needsInfo['expire_status'] == 3 || ($needsInfo['expire_status'] == 1 && $needsInfo['expire_time'] > TIMESTAMP))){
            $insertData['status']               = 1;
        }else{
            $insertData['status']               = 0;
        }
        $insertData['client_ip_port']       = $needsInfo['client_ip_port'];
        $insertData['pay_status']           = $needsInfo['pay_status'];
        $insertData['shenhe_status']        = $needsInfo['shenhe_status'];
        $insertData['refresh_time']         = $needsInfo['refresh_time'];
        $insertData['add_time']             = $needsInfo['add_time'];
        C::t('#tom_tongcheng#tom_tongcheng')->insert($insertData);
        $tongchengId = C::t('#tom_tongcheng#tom_tongcheng')->insert_id();
        
    }
    
    return true;
}

function delete_needs_tongcheng($needs_id){
    global $tcfangchanConfig,$tongchengConfig;
    
    if($tcfangchanConfig['open_tongbu_tongcheng'] == 1){}else{
        return false;
    }
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_tcfangchan_needs_id($needs_id);
    if($tongchengInfo){
        C::t('#tom_tongcheng#tom_tongcheng')->delete_by_id($tongchengInfo['id']);
        C::t('#tom_tongcheng#tom_tongcheng_attr')->delete_by_tongcheng_id($tongchengInfo['id']);
    }
    return true;
}
