<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;

$fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
if($fangchanSetting && $fangchanSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_setting')->insert($insertData);
    $fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
}

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
if($_GET['act'] == 'district' && submitcheck('parent_id')){
    $outArr = array(
        'code'=> 1,
    );

    $site_id = intval($_GET['site_id'])>0 ? intval($_GET['site_id']):0;
    $parent_id = intval($_GET['parent_id'])>0 ? intval($_GET['parent_id']):0;
    
    if($site_id > 0){
        if($site_id > 1){
            $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
            if($sitesInfoTmp){
                $__SitesInfo = $sitesInfoTmp;
                if(!empty($__SitesInfo['city_id'])){
                    $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                    if($cityInfoTmp){
                        $parent_id = $cityInfoTmp['id'];
                    }
                }
            }
        }else if($site_id == 1){
            $cityInfoTmp = array();
            if(!empty($tongchengConfig['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
            }
            if(!empty($cityInfoTmp)){
                $parent_id = $cityInfoTmp['id'];
            }
        }
    }
    
    $areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($parent_id);
    $areaList = array();
    if(is_array($areaListTmp) && !empty($areaListTmp)){
        foreach ($areaListTmp as $key => $value){
            
            $arrTmp = array();
            $arrTmp['id'] = $value['id'];
            $arrTmp['name'] = diconv($value['name'],CHARSET,'utf-8');
            
            $areaList[] = $arrTmp;
        }
    }
    
    $outArr = array(
        'code'  => 200,
        'list'  => $areaList,
    );    
    echo json_encode($outArr); exit;
}else{
    echo 'error';exit;
}