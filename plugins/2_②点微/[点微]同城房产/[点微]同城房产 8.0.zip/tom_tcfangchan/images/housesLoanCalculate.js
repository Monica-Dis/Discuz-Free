var hlcalcute = {
    
    onlyDk: function (type, num, year, lilv) {
        var that = this;
        
        if (type == 1) {
            return that.benxi(num, year, lilv)
        } else if (type == 2) {
            return that.benjin(num, year, lilv)
        }
    },

    zuheDk: function (type, year, sdnum, gjjnum, sdlilv, gjjlilv) {
        var that = this;
        if (type == 1) {
            var sdObj = that.benxi(sdnum, year, sdlilv);
            var gjjObj = that.benxi(gjjnum, year, gjjlilv);
            if (sdObj.mouthdataArray.length > gjjObj.mouthdataArray.length) {
                var mergemouthdataArray = sdObj.mouthdataArray.map(function (item, index) {
                    if (index < gjjObj.mouthdataArray.length) {
                        return {
                            monthName: item.monthName,
                            yuelixi: item.yuelixi + gjjObj.mouthdataArray[index].yuelixi,
                            yuebenjin: item.yuebenjin + gjjObj.mouthdataArray[index].yuebenjin,
                            syFund: item.syFund + gjjObj.mouthdataArray[index].syFund
                        }
                    } else {
                        return {
                            monthName: item.monthName,
                            yuelixi: item.yuelixi,
                            yuebenjin: item.yuebenjin,
                            syFund: item.syFund
                        }
                    }

                })
            } else {
                var mergemouthdataArray = gjjObj.mouthdataArray.map(function (item, index) {
                    if (index < sdObj.mouthdataArray.length) {
                        return {
                            monthName: item.monthName,
                            yuelixi: item.yuelixi + sdObj.mouthdataArray[index].yuelixi,
                            yuebenjin: item.yuebenjin + sdObj.mouthdataArray[index].yuebenjin,
                            syFund: item.syFund + sdObj.mouthdataArray[index].syFund
                        }
                    } else {
                        return {
                            monthName: item.monthName,
                            yuelixi: item.yuelixi,
                            yuebenjin: item.yuebenjin,
                            syFund: item.syFund
                        }
                    }
                })
            }
            return {
                yuegong: sdObj.yuegong + gjjObj.yuegong,
                totalLixi: sdObj.totalLixi + gjjObj.totalLixi,
                totalPrice: sdObj.totalPrice + gjjObj.totalPrice,
                mouthdataArray: mergemouthdataArray,
                totalDknum: parseFloat(sdObj.totalDknum) + parseFloat(gjjObj.totalDknum),
                year: year
            }

        } else if (type == 2) {
            var sdObj = that.benjin(sdnum, year, sdlilv);
            var gjjObj = that.benjin(gjjnum, year, gjjlilv);
            if (sdObj.mouthdataArray.length > gjjObj.mouthdataArray.length) {
                var mergemouthdataArray = sdObj.mouthdataArray.map(function (item, index) {
                    if (index < gjjObj.mouthdataArray.length) {
                        return {
                            monthName: item.monthName,
                            yuelixi: item.yuelixi + gjjObj.mouthdataArray[index].yuelixi,
                            yuebenjin: item.yuebenjin + gjjObj.mouthdataArray[index].yuebenjin,
                            syFund: item.syFund + gjjObj.mouthdataArray[index].syFund
                        }
                    } else {
                        return {
                            monthName: item.monthName,
                            yuelixi: item.yuelixi,
                            yuebenjin: item.yuebenjin,
                            syFund: item.syFund
                        }
                    }

                })
            } else {
                var mergemouthdataArray = gjjObj.mouthdataArray.map(function (item, index) {
                    if (index < sdObj.mouthdataArray.length) {
                        return {
                            monthName: item.monthName,
                            yuelixi: item.yuelixi + sdObj.mouthdataArray[index].yuelixi,
                            yuebenjin: item.yuebenjin + sdObj.mouthdataArray[index].yuebenjin,
                            syFund: item.syFund + sdObj.mouthdataArray[index].syFund
                        }
                    } else {
                        return {
                            monthName: item.monthName,
                            yuelixi: item.yuelixi,
                            yuebenjin: item.yuebenjin,
                            syFund: item.syFund
                        }
                    }
                })
            }
            return {
                yuegong: sdObj.yuegong + gjjObj.yuegong,
                totalLixi: sdObj.totalLixi + gjjObj.totalLixi,
                totalPrice: sdObj.totalPrice + gjjObj.totalPrice,
                yuegongdijian: sdObj.yuegongdijian + gjjObj.yuegongdijian,
                totalDknum: parseFloat(sdObj.totalDknum) + parseFloat(gjjObj.totalDknum),
                year: year,
                mouthdataArray: mergemouthdataArray
            }
        }

    },

    benxi: function ( num, year, lilv) {
        var mouth = parseInt(year) * 12,
            mouthlilv = parseFloat(lilv) / 12,
            dknum = parseFloat(num) * 10000;
        var yuegong = (dknum * mouthlilv * Math.pow((1 + mouthlilv), mouth)) / (Math.pow((1 + mouthlilv), mouth) - 1);
        var totalLixi = mouth * yuegong - dknum;
        var totalPrice = totalLixi + dknum,
            syFund = totalLixi + dknum;

        var mouthdataArray = [],
            nowmouth = new Date().getMonth(),
            realmonth = 0;

        for (var i = 1; i <= mouth; i++) {
            realmonth = nowmouth + i;
            var yearlist = Math.floor(i / 12);

            realmonth = realmonth - 12 * yearlist;

            if (realmonth > 12) {
                realmonth = realmonth - 12
            }
            
            var yuelixi = dknum * mouthlilv * (Math.pow((1 + mouthlilv), mouth) - Math.pow((1 + mouthlilv), i - 1)) / (Math.pow((1 + mouthlilv), mouth) - 1);
            var yuebenjin = dknum * mouthlilv * Math.pow((1 + mouthlilv), i - 1) / (Math.pow((1 + mouthlilv), mouth) - 1);
            syFund = syFund - (yuelixi + yuebenjin);
            if (syFund < 0) {
                syFund = 0
            }
            mouthdataArray[i - 1] = {
                monthName: realmonth,
                yuelixi: yuelixi,
                yuebenjin: yuebenjin,
                syFund: syFund
            }
        }
        return {
            yuegong: yuegong,
            totalLixi: totalLixi,
            totalPrice: totalPrice,
            mouthdataArray: mouthdataArray,
            totalDknum: num,
            year: year
        };
    },
    
    benjin: function (num, year, lilv) {
        var mouth = parseInt(year) * 12,
            mouthlilv = parseFloat(lilv) / 12,
            dknum = parseFloat(num) * 10000,
            yhbenjin = 0;
        var everymonthyh = dknum / mouth
        var yuegong = everymonthyh + (dknum - yhbenjin) * mouthlilv;
        var yuegongdijian = everymonthyh * mouthlilv;
        var totalLixi = ((everymonthyh + dknum * mouthlilv) + dknum / mouth * (1 + mouthlilv)) / 2 * mouth - dknum;
        var totalPrice = totalLixi + dknum,
            syFund = totalLixi + dknum;

        var mouthdataArray = [],
            nowmouth = new Date().getMonth(),
            realmonth = 0;

        for (var i = 1; i <= mouth; i++) {
            realmonth = nowmouth + i;
            var yearlist = Math.floor(i / 12);

            realmonth = realmonth - 12 * yearlist;

            if (realmonth > 12) {
                realmonth = realmonth - 12
            }
            yhbenjin = everymonthyh * (i - 1);
            var yuebenjin = everymonthyh + (dknum - yhbenjin) * mouthlilv;
            var yuelixi = (dknum - yhbenjin) * mouthlilv;
            syFund = syFund - yuebenjin;
            if (syFund < 0) {
                syFund = 0
            }
            mouthdataArray[i - 1] = {
                monthName: realmonth,
                yuelixi: yuelixi,
                yuebenjin: everymonthyh,
                syFund: syFund
            }
        }
        return {
            yuegong: yuegong,
            totalLixi: totalLixi,
            totalPrice: totalPrice,
            yuegongdijian: yuegongdijian,
            mouthdataArray: mouthdataArray,
            totalDknum: num,
            year: year
        }

    }

}